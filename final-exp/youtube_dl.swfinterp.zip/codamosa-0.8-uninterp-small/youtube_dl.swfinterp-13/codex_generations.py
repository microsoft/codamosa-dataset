

# Generated at 2022-06-26 13:55:29.094202
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    str_0 = "*Nf'$. .ox22+"
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    str_1 = "*Nf".rstrip('+')
    str_2 = str_1[2:]
    str_3 = str_2[:1]
    str_1 = str_2[2:]
    str_2 = str_1[:1]
    v_0 = s_w_f_interpreter_0.extract_function(str_3, str_2)


# Generated at 2022-06-26 13:55:40.018810
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    str_0 = "*Nf'$. .ox22+"
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    assert s_w_f_interpreter_0.__class__ == SWFInterpreter

if __name__ == '__main__':
    # test_SWFInterpreter()
    # test_case_0()
    from .extractors.common import InfoExtractor
    from .compat import compat_HTTPError

    class SWFIE(InfoExtractor):
        IE_DESC = 'Flash SWF files'
        _VALID_URL = r'.*\.swf'

        def report_download_webpage(self, video_id):
            pass

        def _real_download(self, url):
            s = self._download_web

# Generated at 2022-06-26 13:55:42.581581
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    x_0 = SWFInterpreter('')
    x_0.extract_function('a','b')


# Generated at 2022-06-26 13:55:44.938654
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    class_0 = _AVMClass('0')
    dic_0 = {}
    dic_0['0'] = 0
    dic_0['1'] = 1
    dic_0['2'] = 2
    class_0.register_methods(dic_0)

if __name__ == '__main__':
    test_case_0()
    test__AVMClass_register_methods()

# Generated at 2022-06-26 13:55:49.584696
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    assert not hasattr(SWFInterpreter.patch_function, 'patched')
    _patch_SWFInterpreter_patch_function()
    assert hasattr(SWFInterpreter.patch_function, 'patched')
    SWFInterpreter.patch_function._unpatch()
    assert not hasattr(SWFInterpreter.patch_function, 'patched')


# Generated at 2022-06-26 13:55:53.270383
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    s_w_f_interpreter_0 = SWFInterpreter(b"", 0, 0, 0, 0, 0, 0, 0, 0, b"")
    class_0 = s_w_f_interpreter_0.extract_class(0, 0)


# Generated at 2022-06-26 13:55:59.042953
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swfinterpreter = SWFInterpreter()
    test_case_0()

try:
    import guppy
    heapy = guppy.hpy()
    print(heapy.heap())
except ImportError:
    import pympler.tracker
    heapy = pympler.tracker.SummaryTracker()
print(heapy.print_diff())

test_SWFInterpreter_extract_function()

# Generated at 2022-06-26 13:56:02.830993
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    str_0 = '$<~?.  .@$a@"'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    #
    # Test extract_function
    #
    # TODO: test for name == 'TSW'
    pass


# Generated at 2022-06-26 13:56:07.183490
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_cases = [
		(test_case_0,),
    ]

    for idx, test_case in enumerate(test_cases):
        func_args, expected = test_case
        res = None
        try:
            res = func_args[0]()
        except Exception as e:
            print('Test case failed: %s\nFailed with exception: %s' % (func_args, e))
        if res != expected:
            print('Test case failed: %s\nExpected: %s\nGot: %s' % (func_args, expected, res))

test_SWFInterpreter()

# Generated at 2022-06-26 13:56:12.267833
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    str_0 = "*Nf'$. .ox22+"
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    assert s_w_f_interpreter_0.version == 18


if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-26 13:57:57.057164
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s_w_f_interpreter_0 = SWFInterpreter()
    with open(os.path.join(SWF_TEST_DATA_ROOT, 'swf-version-7-0.swf'), 'rb') as f:
        data = f.read()
    s_w_f_interpreter_0.read(data)


# Generated at 2022-06-26 13:57:59.459721
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s_w_f_interpreter_1 = SWFInterpreter()
    s_w_f_interpreter_1.extract_function(_SWF_Class__AVMClass_Object, 'test')


# Generated at 2022-06-26 13:58:01.278350
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    if not has_lxml:
        pytest.skip(
            'cannot test because lxml package is unavailable')
    
    test_case_0()


# Generated at 2022-06-26 13:58:10.112355
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from SWFInterpreter import SWFInterpreter
    s_w_f_interpreter_0 = SWFInterpreter()

    test_cases = (
        (s_w_f_interpreter_0.extract_function,
         'Method %r of class %r should exist'
         % ('extract_function', 'SWFInterpreter')),)
    for test_case, expected in test_cases:
        actual = test_case()
        if actual != expected:
            print('- Test failed: actual %s, expected %s' % (actual, expected))
        else:
            print('- Test passed!')

if __name__ == '__main__':
    test_case_0()
    test_SWFInterpreter_extract_function()

# Generated at 2022-06-26 13:58:20.213486
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    print('Testing function SWFInterpreter')
    s_w_f_interpreter_0 = SWFInterpreter()

# Generated at 2022-06-26 13:58:24.070756
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    s_w_f_interpreter_0 = SWFInterpreter()
    root = etree.parse('data/continuation_0.xml').getroot()
    s_w_f_interpreter_0.extract_class(root)


# Generated at 2022-06-26 13:58:27.876059
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    print('Testing constructor of class SWFInterpreter')
    try:
        s_w_f_interpreter_0 = SWFInterpreter()
        print('Construction successfull')
    except Exception as e:
        print(e)
        print('Construction failed')


# Generated at 2022-06-26 13:58:30.933817
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    s_w_f_interpreter_0 = SWFInterpreter()
    assert isinstance(s_w_f_interpreter_0, SWFInterpreter)


# Generated at 2022-06-26 13:58:32.220981
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    avm_interpreter = SWFInterpreter()



# Generated at 2022-06-26 13:58:38.565267
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s_w_f_interpreter_0 = SWFInterpreter()

    class _AVMClass_0(object):
        class_name = '_AVMClass_0'
        extends = ''
        constructor = None
        static_properties = {}
        static_method_names = set()
        method_names = set()
        method_pyfunctions = {}
        method_names_removed = set()
        tmp_method_pyfunctions = {}

    # Extracting method '_Method_0'
    avm_class = _AVMClass_0()
    avm_class.constructor = '_Method_0'
    name = '_Method_0'

# Generated at 2022-06-26 14:00:01.775668
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_case_0()


# Generated at 2022-06-26 14:00:07.181966
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-26 14:00:08.867427
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    s_w_f_interpreter_0 = SWFInterpreter()
    assert isinstance(s_w_f_interpreter_0, SWFInterpreter)


# Generated at 2022-06-26 14:00:11.425573
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s_w_f_interpreter_0 = SWFInterpreter()
    s_w_f_interpreter_0.extract_function((), 'ExtractFunction_0')


# Generated at 2022-06-26 14:00:18.104544
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interpreter = SWFInterpreter()
    assert isinstance(interpreter, SWFInterpreter)
    assert interpreter.major_version == 17
    assert interpreter.minor_version == 0
    assert interpreter.file_attributes == []
    assert interpreter.file_len == None
    assert interpreter.frame_size == None
    assert interpreter.frame_rate == None
    assert interpreter.frame_count == None
    assert interpreter.tags == []
    assert interpreter.abcs == []

# Test if we can load a file

# Generated at 2022-06-26 14:00:27.880336
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    s_w_f_interpreter_0 = SWFInterpreter()
    s_w_f_interpreter_0.parse_file('tests/swfs/vimeo_dl_mp4_20170521.swf')

    def _make_patched_function(interpreter, function_index, code_index, code):
        '''Create a new function from an existing one with patched bytecode,
        without modifying the original one'''

        # Store the original bytecode
        original_function = interpreter.function_bytecode_pairs[function_index]
        original_bytecode = original_function[code_index]

        # Create a new one by copying the original and patching the bytecode
        patched_function = []

# Generated at 2022-06-26 14:00:36.752848
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from . import _amf_data
    s_w_f_interpreter_0 = SWFInterpreter()
    s_w_f_interpreter_0.multinames = _amf_data.multinames
    s_w_f_interpreter_0.constant_strings = _amf_data.constant_strings
    s_w_f_interpreter_0.code = _amf_data.code
    s_w_f_interpreter_0.registers = _amf_data.registers
    s_w_f_interpreter_0.traits = _amf_data.traits

# Generated at 2022-06-26 14:00:38.975447
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_interpreter = SWFInterpreter()



# Generated at 2022-06-26 14:00:41.402855
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    s_w_f_interpreter_0 = SWFInterpreter()
    assert_raises(NotImplementedError, s_w_f_interpreter_0.patch_function)


# Generated at 2022-06-26 14:00:44.747098
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    s_w_f_interpreter_0 = SWFInterpreter()
    assert s_w_f_interpreter_0.patch_function(None, None, None, None) is None


# Generated at 2022-06-26 14:03:29.424291
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    s_w_f_interpreter = SWFInterpreter()



# Generated at 2022-06-26 14:03:37.697212
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    s_w_f_interpreter_0 = SWFInterpreter()

    # Test for method extract_class( )
    extracted_class_0 = s_w_f_interpreter_0.extract_class(0)

    assert isinstance(extracted_class_0, _AVMClass),\
        'Not an _AVMClass instance'
    assert extracted_class_0.name == 'int',\
        'Class name is not correct'
    assert extracted_class_0.is_final,\
        'Class is not final'
    assert extracted_class_0.is_sealed,\
        'Class is not sealed'
    assert extracted_class_0.superclass == 'Object',\
        'Superclass is not Object'

    # Test for method extract_class( )
    extracted_class_0

# Generated at 2022-06-26 14:03:41.856031
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    tests = [
        (None, None),
        (None, None),
        (None, None),
        (None, None)
    ]
    for params, expected in tests:
        with pytest.raises(expected):
            SWFInterpreter(*params)

test_SWFInterpreter()


# Generated at 2022-06-26 14:03:51.176485
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s_w_f_interpreter_1 = SWFInterpreter()

# Generated at 2022-06-26 14:03:52.727526
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    s_w_f_interpreter_0 = SWFInterpreter()



# Generated at 2022-06-26 14:03:57.121806
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # Test preconditions
    s_w_f_interpreter_1 = SWFInterpreter()
    assert (isinstance(s_w_f_interpreter_1, SWFInterpreter))
    # Call method
    s_w_f_interpreter_1.patch_function()
    # Test postconditions
    assert (True)


# Generated at 2022-06-26 14:03:58.726053
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    try:
        s_w_f_interpreter_0 = SWFInterpreter()
    except:
        assert False



# Generated at 2022-06-26 14:04:01.985906
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    s_w_f_interpreter_0 = SWFInterpreter()
    abc_data = b''
    s_w_f_interpreter_0.abc_data = abc_data
    s_w_f_interpreter_0.extract_class()


# Generated at 2022-06-26 14:04:02.821066
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    pass


# Generated at 2022-06-26 14:04:04.225122
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    """ Unit test for constructor of class SWFInterpreter """
    s_w_f_interpreter_0 = SWFInterpreter()
    assert True # TODO: implement your test here
