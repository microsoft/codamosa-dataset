

# Generated at 2022-06-26 13:55:53.721027
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-26 13:56:02.793069
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import re
    from collections import namedtuple
    from io import BytesIO
    from itertools import islice, repeat

    class TestException(Exception):
        pass

    class _TestAVMClass(object):
        def __init__(self, name, method_names, static_properties,
                     instance_properties):
            self.name = name
            self.method_names = method_names
            self.static_properties = static_properties
            self.instance_properties = instance_properties
            self.variables = {}
            self.method_pyfunctions = {}
            self.parent_class = ObjectClass

        def make_object(self):
            return _TestAVMClass_Object(self)

        def __getitem__(self, key):
            return self.variables[key]


# Generated at 2022-06-26 13:56:04.052024
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    pass


# Generated at 2022-06-26 13:56:15.675675
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-26 13:56:26.388185
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from pyamf.amf0 import Undefined
    from pyamf.remoting.client import RemotingService

    swf_content = pkg_resources.resource_string(
        __name__, 'data/a0.swf')

    avm_class = SWFInterpreter(swf_content).extract_class()

    assert avm_class.method_names == set([
        'a009', 'a002', 'a008', 'a001', 'a005', 'a006', 'a003', 'a007', 'a004'])
    assert avm_class.variable_names == set(['this', 'a100'])


# Generated at 2022-06-26 13:56:34.067633
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interpreter_0 = SWFInterpreter()
    with io.open('testcase/0/test.swf', 'rb') as file_0:
        testcase_0 = file_0.read()
        file_0.close()
    with io.open('testcase/0/test.abc', 'rb') as file_0:
        testcase_abc_0 = file_0.read()
        file_0.close()
    interpreter_0.extract_class(testcase_0, testcase_abc_0, 30)
    assert len(interpreter_0.constant_strings) == 27
    assert interpreter_0.constant_strings[0] == '%c'
    assert interpreter_0.constant_strings[1] == '%s:%d'
    assert interpreter_0.constant_strings

# Generated at 2022-06-26 13:56:37.527388
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter()
    swf.decode('\x01\x01\x00\x02\x01\x00\x00')
    assert swf.version == 1
    assert swf.file_length == 3


# Generated at 2022-06-26 13:56:45.727243
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from yalafi.parser.parser_plain import ParserPlain
    from yalafi.parser.defs import DefsParser
    defs = DefsParser.read_file('plain')
    parser = ParserPlain(defs)
    text = '\\switch{ a }{ b }'
    lst = parser.parse(text)
    assert lst[0].ttype == 'switch'
    interpreter = SWFInterpreter(parser.get_parameters())
    interpreter.extract_function('Switch', lst[0].cmdname)


# Generated at 2022-06-26 13:56:50.481882
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass('', '')
    avm_class.register_methods({'previousFrame': 0, 'isNaN': 48})
    assert avm_class.method_names == {'previousFrame': 0, 'isNaN': 48}
    assert avm_class.method_idxs == {0: 'previousFrame', 48: 'isNaN'}



# Generated at 2022-06-26 13:56:59.686546
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-26 13:58:02.057163
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    """
    Extraction of class
    """

# Generated at 2022-06-26 13:58:04.900682
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    undefined_0 = _Undefined()
    var_0 = undefined_0.__bool__()
    assert var_0 == False


# Generated at 2022-06-26 13:58:13.660770
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interp = SWFInterpreter()
    avm_class = _AVMClass(interp)
    avm_method_info = _AVMMethodInfo()
    avm_method_info.body = _AVMMethodBody()
    avm_method_info.body.max_stack = 1
    avm_method_info.body.max_regs = 0
    avm_method_info.body.method = avm_method_info
    avm_method_info.body.code = compat_strtobytes(
        '\x10\x00\x2a')
    avm_method_info.body.exceptions = []
    avm_method_info.body.trait = _AVMTrait(avm_class, 'booger')
    avm_method_info.body.init

# Generated at 2022-06-26 13:58:24.072380
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    case_0_avm_class = _AVMClass(
        init_function=lambda args: None,
        variables={},
        static_properties={},
        instance_properties={},
        methods={},
    )
    case_0_avm_class.name = 'test_case_0'
    case_0_avm_class.init_function_name = 'test_case_0'
    case_0_avm_class.method_names = set(['__init__', '__bool__'])
    avm_class = case_0_avm_class
    method_name = '__bool__'

    swfi = SWFInterpreter(b'')
    swfi.patch_function(avm_class, method_name)


# Generated at 2022-06-26 13:58:33.492015
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    def func_0(args):
        assert args == []
        return undefined_0

    interpreter = SWFInterpreter()
    interpreter.multinames = [0]
    interpreter.constant_strings = ['Array']
    interpreter.constant_namespaces = []
    interpreter.constant_namespace_sets = []
    interpreter.constant_multinames = [_Multiname('Array', ['Array'])]
    interpreter.methods = [
        _Method(
            'func_0', [], func_0,
            '0 +pushundefined\n'
            '18 +returnvalue\n'
        )]

# Generated at 2022-06-26 13:58:45.489799
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter.load(test_case_0)
    assert interpreter.global_scope == {}
    assert interpreter.constant_strings == []
    assert interpreter.constant_int == []
    assert interpreter.constant_uint == []
    assert interpreter.constant_float == []
    assert interpreter.constant_namespace == []
    assert interpreter.constant_namespace_set == []
    assert interpreter.multinames == []
    assert interpreter.metadata == []
    # assert interpreter.scripts == [(1, '', '', [])]
    assert interpreter.method_bodies == [([], [])]
    assert interpreter.avm_classes == {}
    res = interpreter.extract_function()
    assert res is undefined_0.__bool__
    assert interpreter.global_scope == {}
    assert interpreter.const

# Generated at 2022-06-26 13:58:54.964507
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-26 13:58:56.135580
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swfinterpreter = SWFInterpreter()
    assert isinstance(swfinterpreter, SWFInterpreter)



# Generated at 2022-06-26 13:58:57.344686
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_case_0()

if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-26 13:59:04.367887
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    undefined_0 = _Undefined()
    var_0 = undefined_0.__bool__()
    var_1 = SWFInterpreter()
    var_1.flags = [{}]
    var_1.methods = [{}]
    var_1.traits = [{}]
    var_1.constant_ints = [{}]
    var_1.constant_uints = [{}]
    var_1.constant_doubles = [{}]
    var_1.constant_strings = [{}]
    var_1.multinames = [{}]
    var_1.namespaces = [{}]
    var_2 = var_1.extract_function([], [])
    var_1.methods = [{}]
    var_1

# Generated at 2022-06-26 14:01:02.872477
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from io import BytesIO

    # Constructor test
    avm_interpreter = SWFInterpreter()

    # You can use _get_method_code to retrieve the bytecode of a method
    # (such as public function 'test').
    expected_res = b'\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    method_code = avm_interpreter._get_method_code(
        test_case_0, b'\x00\x00\x00\x00\x00\x00\x00\x00')
    assert method_code == expected_res, 'Wrong method code retrieved!'

    # You can use _decode_method to decode and extract the
    # instructions inside a method
    expected

# Generated at 2022-06-26 14:01:11.018916
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    undefined = _Undefined()

# Generated at 2022-06-26 14:01:17.985632
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO

    # From issue #17863
    swf_file = BytesIO(SWF_DATA_17863)
    interpreter = SWFInterpreter(swf_file)
    # In the tested SWF, class_name = u'videoConfigData'
    var_1 = interpreter.extract_class(u'videoConfigData')
    # AssertionError: {
    #   'new': function new()
    # } != {
    #   'new': function new()
    # }
    assert var_1 == {
        u'new': func_0,
    }


# Generated at 2022-06-26 14:01:25.415481
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    fname = os.path.join(os.path.dirname(__file__), 'SWFTags.abc')
    with open(fname, 'rb') as f:
        abc_tags = [t for t in _SWFTag.gen_tags(f)
                    if isinstance(t, _DoABCTag)]

    avm_classes = [t.avm_class for t in abc_tags]
    interpreter = SWFInterpreter(avm_classes)
    avm_class = interpreter.avm_classes[0]
    interpreter.extract_class(avm_class)



# Generated at 2022-06-26 14:01:29.488727
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    coder = compat_BytesIO()
    _write_byte(coder, 39)  # pushfalse
    _write_byte(coder, 4)  # returnvalue
    _write_byte(coder, 0)  # end

    interpreter = SWFInterpreter()
    func = interpreter.patch_function(coder)
    res = func()
    assert res is False


# Generated at 2022-06-26 14:01:32.855889
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = SWFInterpreter()
    swf.file_name = 'file_name'
    func = 'func'
    argv = []
    actual = swf.patch_function(func, argv)
    assert actual is None
    assert swf.stack == [swf.stack_obj, swf.stack_pos, swf.stack_pos]


# Generated at 2022-06-26 14:01:41.191404
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    method_name = 'extract_class'
    case_0_args = [{'method_name': 'test_case_0'}]
    case_0_kwargs = {}
    case_0_expected = SWFInterpreter
    args_0 = (case_0_args[0], case_0_kwargs)
    for arg_0 in args_0:
        with pytest.raises(NotImplementedError):
            res_0 = SWFInterpreter.extract_class(*case_0_args, **case_0_kwargs)
        res_0 = getattr(SWFInterpreter, method_name)(*case_0_args, **case_0_kwargs)
        assert res_0 == case_0_expected

if __name__ == '__main__':
    test_

# Generated at 2022-06-26 14:01:48.201659
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    f = io.BytesIO(open(os.path.join(TEST_DATA_DIR, 'opcodes1.swf'), 'rb').read())
    interp = SWFInterpreter()
    interp.parse_swf(f)
    interp.extract_function('Frame1_mc.Test', 'testCase0')
    assert len(interp.avm_classes['Frame1_mc.Test'].method_pyfunctions) == 1
    assert interp.avm_classes['Frame1_mc.Test'].method_pyfunctions['testCase0'] == test_case_0



# Generated at 2022-06-26 14:01:55.780578
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    abc_data = open(test_abc_swf_path, 'rb').read()
    decoder = _SWFDecoder(abc_data)
    decoder.parse_header()
    decoder.parse_body()
    abc1 = decoder.abc_tags[0].abc

    # Test constructor and method add_abc
    SWFInterpreter_obj = SWFInterpreter()
    SWFInterpreter_obj.add_abc(abc1)

    abc2 = ABC()
    class_name = 'TestClass'
    new_class = _AVMClass(abc2, _builtin_classes['Object'], class_name)

    var_name = 'testProp'
    new_class.static_properties[var_name] = 1

    def test_func(args):
        return undefined_

# Generated at 2022-06-26 14:02:06.202742
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    global undefined
    undefined = _Undefined()
    interpreter = SWFInterpreter()

    assert len(interpreter.constant_strings) == 0
    assert len(interpreter.methods) == 0
    assert len(interpreter.multinames) == 0
    assert len(interpreter.classes) == 0
    assert len(interpreter.avm_classes) == 0
    assert len(interpreter.as2_classes) == 0

    with open('tests/swf/version_8.swf', 'rb') as f:
        f.read(8)
        file_size = read_u32_le(f)
        file_data = f.read(file_size)
        file_data = zlib.decompress(file_data)