

# Generated at 2022-06-26 13:56:50.944610
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # Create a new instance of SWFInterpreter
    swfi_0 = SWFInterpreter()

    # Call method extract_function of swfi_0
    res_0 = swfi_0.extract_function()
    return res_0

if __name__ == '__main__':
    res = test_SWFInterpreter_extract_function()
    print(res)

# Generated at 2022-06-26 13:56:55.266720
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-26 13:57:05.425862
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    obj = SWFInterpreter()
    obj.extract_function(undefined_0, '0')
    obj.extract_function(undefined_0, '1')
    obj.extract_function(undefined_0, '2')
    obj.extract_function(undefined_0, '3')
    obj.extract_function(undefined_0, '4')
    obj.extract_function(undefined_0, '5')
    obj.extract_function(undefined_0, '6')
    obj.extract_function(undefined_0, '7')
    obj.extract_function(undefined_0, '8')
    obj.extract_function(undefined_0, '9')
    obj.extract_function(undefined_0, '10')
    obj

# Generated at 2022-06-26 13:57:14.794211
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # Test code extracted from SWF file
    # test_SWFInterpreter_extract_function.swf
    # Date: Sat Apr  5 18:59:51 2014
    # Code extracted by decompyle2
    # Uncompyle6 version 2.9.6+
    # Python bytecode 2.7
    # Decompiled from: Python 2.7.9 (default, Dec 10 2014, 12:24:55)
    # [GCC 4.9.2]
    # Embedded file name: test_SWFInterpreter_extract_function.py
    # Compiled at: Mon Apr  6 18:03:42 2015
    # Size of source mod 2**32: 3444 bytes
    import sys
    import pyamf
    pyamf.register_package(u'com.example', u'.')

# Generated at 2022-06-26 13:57:21.830433
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf_file = 'test_data/extract_function.swf'
    # assert_raises(NotImplementedError, SWFInterpreter, swf_file)
    interpreter = SWFInterpreter(swf_file)

    # Do not call the function
    # interpreter.extract_function(None, None)

    class AVMClass(object):
        method_pyfunctions = dict()
        method_names = dict()
        static_properties = dict()
        variables = dict()

    avm_class = AVMClass()
    interpreter.extract_function(
        avm_class, 'extractFunction',
        (None, None))


# Generated at 2022-06-26 13:57:23.285094
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    assert SWFInterpreter.patch_function is patch_function


# Generated at 2022-06-26 13:57:34.099534
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO

    # Verify that the method extract_function works as expected with the class
    # SWFInterpreter under the following scenario:
    # case0: undefined
    undefined_0 = _Undefined()
    undefined_1 = _Undefined()
    undefined_2 = _Undefined()
    undefined_3 = _Undefined()
    undefined_4 = _Undefined()
    undefined_5 = _Undefined()
    undefined_6 = _Undefined()
    undefined_7 = _Undefined()
    undefined_8 = _Undefined()

# Generated at 2022-06-26 13:57:41.736998
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_interpreter = SWFInterpreter('test.swf')
    undefined_0 = _Undefined()
    assert swf_interpreter.version == 12
    assert swf_interpreter.file_length == 179712
    assert swf_interpreter.frame_rate == 0x63
    assert swf_interpreter.frame_count == 1
    assert swf_interpreter.rect == {'x0': 0, 'x1': 0, 'x2': 0, 'y0': 0, 'y1': 0, 'y2': 0}
    assert swf_interpreter.constant_integers == [1, 2, 3, 4, 5]

# Generated at 2022-06-26 13:57:48.155551
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    extract_class = SWFInterpreter.extract_class

    with open('tests/test.swf', 'rb') as f:
        swf = f.read()
    interp = SWFInterpreter(swf)
    test_class = interp.extract_class(interp.avm2_classes[1])
    assert 'multireddit_url' in test_class.method_pyfunctions


# Generated at 2022-06-26 13:57:57.206638
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    avm_class_0 = _AVMClass()

    # Create new class 'Script' inheriting from class 'Object' in the global
    # namespace.
    ScriptClass = _create_class('Script', ObjectClass, avm_class_0)
    avm_class_0.name = 'Script'
    avm_class_0.variables['Script'] = ScriptClass
    avm_class_0.variables['Script'].variables['Script'] = ScriptClass
    avm_class_0.static_properties['Script'] = ScriptClass


    int_0 = 3
    flt_0 = 3.0
    bool_0 = False
    str_0 = 'undefined'
    method_return_value_0 = undefined_0

    def method_pyfunction_0(arg_undefined_0):
        undefined

# Generated at 2022-06-26 13:58:53.838750
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    bytes_0 = b'&"\xe0v\x985\xac\x8c\x00\xcflc\xd8|\xd7\x95'
    s_w_f_interpreter_0 = SWFInterpreter(bytes_0)
    s_w_f_interpreter_0.patch_function()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:59:01.245362
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-26 13:59:06.139442
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    bytes_0 = b'&"\xe0v\x985\xac\x8c\x00\xcflc\xd8|\xd7\x95'
    s_w_f_interpreter_0 = SWFInterpreter(bytes_0)
    s_w_f_interpreter_0.patch_function('', '', 0)


# Generated at 2022-06-26 13:59:15.426018
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-26 13:59:16.644644
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 13:59:23.408336
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-26 13:59:26.379738
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    for i in range(100):
        try:
            test_case_0()
        except NotImplementedError:
            pass


if __name__ == '__main__':
    from tests.test_utils import run_test
    run_test(SWFInterpreter)

# Generated at 2022-06-26 13:59:33.026003
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    bytes_0 = b'&"\xe0v\x985\xac\x8c\x00\xcflc\xd8|\xd7\x95'
    s_w_f_interpreter_0 = SWFInterpreter(bytes_0)

    def method_0(args):
        return args[0] + args[0]
    def method_1(args):
        return args[0] + args[1]
    def method_2(args):
        return args[0].as_str() + args[1].as_str()
    def method_3(args):
        return args[0].as_str()

    class _AVMClass_0():
        def __init__(self):
            self.method_names = ['method_1', 'method_0', 'method_2']


# Generated at 2022-06-26 13:59:42.157902
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-26 13:59:51.661510
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-26 14:01:40.628854
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-26 14:01:49.428792
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-26 14:01:55.121444
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    bytes_0 = b'&"\xe0v\x985\xac\x8c\x00\xcflc\xd8|\xd7\x95'
    s_w_f_interpreter_0 = SWFInterpreter(bytes_0)
    func_name = '_get_video'
    args = [1, 2]
    res = s_w_f_interpreter_0.extract_function(
        s_w_f_interpreter_0.classes[0],
        func_name)(args)
    assert res == None


# Generated at 2022-06-26 14:02:05.263153
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-26 14:02:13.529777
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-26 14:02:21.561240
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-26 14:02:24.598022
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    s = SWFInterpreter(b'&"\xe0v\x985\xac\x8c\x00\xcflc\xd8|\xd7\x95')
    s.patch_function()


# Generated at 2022-06-26 14:02:29.792898
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # AssertionError is raised if the following statement is true, vice versa
    assert(test_case_0() is None), 'test_case_0() returns None, expected AssertionError'

if __name__ == '__main__':
    test_SWFInterpreter()
    print('Everything non-error is a success')

# Generated at 2022-06-26 14:02:35.769035
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    bytes_0 = b'&"\xe0v\x985\xac\x8c\x00\xcflc\xd8|\xd7\x95'
    swf_interpreter_0 = SWFInterpreter(bytes_0)
    s_w_f_method_header_dict_0 = dict()
    swf_interpreter_0.method_headers = s_w_f_method_header_dict_0
    swf_interpreter_0.patch_function()


# Generated at 2022-06-26 14:02:40.550111
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    bytes_0 = b'&"\xe0v\x985\xac\x8c\x00\xcflc\xd8|\xd7\x95'
    s_w_f_interpreter_0 = SWFInterpreter(bytes_0)
    string_0 = 'test_string'
    string_1 = 'test_string'
    s_w_f_interpreter_0.patch_function(string_0, string_1)
