

# Generated at 2022-06-26 13:56:48.423286
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter()
    swf.constant_strings = [
        '',
        '_0',
        '_1',
    ]
    swf.multinames = []
    swf.multiname_types = []
    swf.multiname_namespaces = []
    swf.namespace_kinds = []
    swf.namespace_names = []
    swf.namespace_sets = []

# Generated at 2022-06-26 13:56:50.946015
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import unittest

    class SWFInterpreter_patch_function_TestCase(unittest.TestCase):
        def test_0(self):
            pass

    unittest.main()


# Generated at 2022-06-26 13:57:00.255951
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    class_name = 'test_SWFInterpreter_extract_class'

    with open('tests/unit/swf/extract-class-0.swf', 'rb') as f:
        data = memoryview(f.read())
        avm_class = SWFInterpreter.Interpreter.extract_class(data)
        assert avm_class.namespace == ''
        assert avm_class.name == class_name
        assert avm_class.super_name == 'Object'
        assert len(avm_class.static_properties) == 2
        assert len(avm_class.method_names) == 1
        assert len(avm_class.method_pyfunctions) == 1
        assert avm_class.static_properties['undefined_0'] == undefined_0
        assert avm_

# Generated at 2022-06-26 13:57:10.401584
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-26 13:57:12.845729
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swfInterpreter = SWFInterpreter()
    swfInterpreter._SWFInterpreter__init__()


# Generated at 2022-06-26 13:57:13.810335
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    pass


# Generated at 2022-06-26 13:57:22.197683
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # Create a dummy method that returns a fixed value,
    # and has the expected function signature
    _MockFunction = namedtuple('_MockFunction', ['name', 'idx'])
    _mock = _MockFunction(name='foo', idx=17)
    def func(): pass
    func.__name__ = _mock.name
    func.__code__ = _mock
    # Create a SWFInterpreter object
    swfinterpreter = SWFInterpreter('dummy.swf')
    # Invoke the method being tested
    swfinterpreter.patch_function(func)
    # Verify the resulting mock object state
    assert swfinterpreter.func_idx_to_func[_mock.idx] == func
    assert swfinterpreter.func_name_to_

# Generated at 2022-06-26 13:57:24.718606
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    t = SWFInterpreter()
    assert t.classes == {u'Object': t.ObjectClass}
    return t



# Generated at 2022-06-26 13:57:30.185597
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter()
    if (swf.method_names != ["getArgument", "getLength", "getType", "getValue", "toString"]):
        raise RuntimeError("Expected %s, got %s" % ("[\"constant_strings\", \"classes\", \"multinames\", \"extract_function\"]", swf.method_names))


# Generated at 2022-06-26 13:57:39.309976
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swfinterp = SWFInterpreter(None)
    coder = compat_BytesIO(
        b'\x00\x09\x04\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        b'\x02\x00\x03\x01\x00\x00\x04\x01\x02\x00\x00\x01\x05\x01\x00'
        b'\x00\x00\x2e\x00\x0c\x70\x61\x72\x61\x6d\x73\x2e\x74\x6f\x6f'
        b'\x70'
    )
    res = swfinterp

# Generated at 2022-06-26 13:58:41.218884
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    test_case_0()


# Generated at 2022-06-26 13:58:51.809012
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    val_0 = b"\xac\xed"

# Generated at 2022-06-26 13:58:59.901688
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # a case that should not raise an exception
    test_case_0()
    # a case that should raise an exception
    try:
        lst_0 = [None, None]
        dict_0 = {lst_0: lst_0}
        bytes_0 = b'~\xda\x85'
        s_w_f_interpreter_0 = SWFInterpreter(bytes_0)
    except Exception as err:
        print(err)
    # a case that should raise an exception

# Generated at 2022-06-26 13:59:02.887944
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    with open(os.path.join(
            os.path.dirname(__file__), 'testcase_swf.bin'), 'rb') as f:
            bytes_0 = f.read()

    s_w_f_interpreter_0 = SWFInterpreter(bytes_0)

# Generated at 2022-06-26 13:59:12.686409
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24 = {}
    dict_25 = {}
    dict_26 = {}
    dict_27 = {}
    dict_

# Generated at 2022-06-26 13:59:20.187516
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    import nose
    import common
    import sys

    if sys.version_info[:2] < (2, 7):
        # Test passed in python 2.7 and not in 2.6
        raise nose.SkipTest('Test does not support Python 2.6')

    with open(common.swf_movie_filename('flvplayback_test_case_0.swf')) as f:
        s_w_f_interpreter_0 = SWFInterpreter(f.read())
        avm_class_0 = s_w_f_interpreter_0.extract_class(0)
        nose.tools.eq_(avm_class_0.static_properties['__constructor__'](), None)

# Generated at 2022-06-26 13:59:22.284497
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    import doctest
    doctest.testmod()

if __name__ == '__main__':
#    test_case_0()
    test_SWFInterpreter_extract_class()

# Generated at 2022-06-26 13:59:29.206285
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    str_0 = '_eMz,'
    dict_0 = {str_0: str_0, str_0: str_0}
    bytes_0 = b'~\xda\x85'
    s_w_f_interpreter_0 = SWFInterpreter(bytes_0)
    str_1 = 'bFx5'
    dict_1 = {str_1: str_1}
    dict_2 = {str_1: str_1}
    dict_0['_eMz,'] = dict_1
    dict_0['_eMz,'] = dict_2
    s_w_f_interpreter_0.patch_function(dict_0)

if __name__ == '__main__':
    test_case_0()
    test_SWFInterpreter

# Generated at 2022-06-26 13:59:30.509421
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # TODO write test case
    return True


# Generated at 2022-06-26 13:59:35.281566
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    str_0 = 'h\xfb\x0c'
    dict_0 = {str_0: str_0, str_0: str_0}
    bytes_0 = b'~\xda\x85'
    s_w_f_interpreter_0 = SWFInterpreter(bytes_0)
    bytes_1 = b'~\xda\x85'
    s_w_f_interpreter_0.patch_function(bytes_1)


# Generated at 2022-06-26 14:01:45.819332
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-26 14:01:48.769186
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    bytes_0 = b'~\xda\x85'
    s_w_f_interpreter_0 = SWFInterpreter(bytes_0)


# Generated at 2022-06-26 14:01:52.473414
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():

    # Test case 0
    bytes_0 = None
    s_w_f_interpreter_0 = SWFInterpreter(bytes_0)
    assert (
        s_w_f_interpreter_0.extract_function(s_w_f_interpreter_0.avm_class, '')
        is None)


# Generated at 2022-06-26 14:01:54.425189
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_case_0()

if __name__ != "__main__":
    test_SWFInterpreter()
    print('Test finished')

# Generated at 2022-06-26 14:01:56.492544
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert SWFInterpreter is not None,\
        "Failed to import the class 'SWFInterpreter' from module 'swf_interpreter'"
    test_case_0()


# Generated at 2022-06-26 14:02:06.898423
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-26 14:02:14.713176
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-26 14:02:23.111024
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Test case 1
    bytes_0 = b'\xe6?"\x07\x02\x00\x00\x00\x0c\x04\x00\x00\x00\x02@\x00\x00'
    s_w_f_interpreter_0 = SWFInterpreter(bytes_0)
    # Test case 2
    bytes_0 = b'\x9f\x03\x1c\x00\x04\x00\x00\x00\x08>\x00\x00\x00\x02\x00\x07\x00'
    s_w_f_interpreter_0 = SWFInterpreter(bytes_0)
    # Test case 3

# Generated at 2022-06-26 14:02:28.591781
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    bytes_0 = b'~\xda\x85'
    s_w_f_interpreter_0 = SWFInterpreter(bytes_0)
    s_w_f_interpreter_0.extract_function(
        s_w_f_interpreter_0.avm_classes[0], 'abc')


# Generated at 2022-06-26 14:02:36.215211
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from os import path
    from binascii import a2b_base64
    script_path = os.path.dirname(__file__)
    script_path = os.path.join(script_path, 'script')
    fd = open(os.path.join(script_path, 'youtube.as'), 'rb')
    contents = fd.read()
    fd.close()
    s_w_f_interpreter_0 = SWFInterpreter(contents)
    avm_classes_0 = s_w_f_interpreter_0.classes
    return avm_classes_0['YoutubeStream'].variables['no_video_message']
