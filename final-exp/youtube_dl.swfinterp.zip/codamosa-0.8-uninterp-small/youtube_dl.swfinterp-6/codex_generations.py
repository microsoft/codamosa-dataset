

# Generated at 2022-06-26 13:56:15.156012
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    test_case_0()

if __name__ == '__main__':
    test_SWFInterpreter_extract_function()

# Generated at 2022-06-26 13:56:25.880429
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    avm_interpreter = SWFInterpreter(r'c:\temp\alloy.swf')
    avm_interpreter.extract_classes()
    for avm_class in avm_interpreter.avm_classes:
        avm_interpreter.extract_class_pyfunctions(avm_class)
        avm_class.extract_objects(avm_interpreter)
    avm_interpreter.extract_pyfunctions()

    for name, func in avm_interpreter.avm_class_pyfunctions.items():
        print('=== %s ===' % name)
        print(func.__doc__)
        print(inspect.getsourcelines(func)[0])


# Generated at 2022-06-26 13:56:30.875290
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    func = test_case_0
    test_obj = SWFInterpreter()

    # Test with no dependancies
    var_1 = test_obj.patch_function(func)
    assert var_1 == "undefined"

    # Test with dependancies
    test_obj.constant_strings = ['']
    var_2 = test_obj.patch_function(func)
    assert var_2 == "undefined"


# Generated at 2022-06-26 13:56:31.811183
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # Constructor test
    obj = SWFInterpreter()



# Generated at 2022-06-26 13:56:36.756820
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from purl import URL
    from pyamf import remoting
    from .fetch_swf import fetch_sockplayer_swf

    # Fetch SWF from SockPlayer
    url = URL('http://sockplayer.net/s/splayer.swf')
    url = url.add_query_param('url', 'http://www.youtube.com/watch?v=1V6UaA-3qFI')
    content = fetch_sockplayer_swf(url)

    # Decompile it
    interp = SWFInterpreter()
    interp.feed(content)

    # Extract main class
    main_class = interp.extract_class('Main')
    assert isinstance(main_class, _AVMClass)

    # Extract method _player_init

# Generated at 2022-06-26 13:56:38.664241
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # Both positional and keyword parameters are used
    # (Parameters are not used)
    # Return value is ignored
    test_case_0()


# Generated at 2022-06-26 13:56:49.418776
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interp = SWFInterpreter()
    class AVMClass_0(object):
        name = 'class_0'
        method_names = set()
        method_pyfunctions = {}
        static_properties = {}
    class AVMClass_1(object):
        name = 'class_1'
        method_names = set(['func_1'])
        method_pyfunctions = {'func_1': lambda *args: args}
        static_properties = {}
    interp.patch_function(AVMClass_0, 'func_0', lambda *args: args)
    interp.patch_function(AVMClass_1, 'func_1', lambda *args: args)
    assert ('class_0', 'func_0') in interp.function_cache

# Generated at 2022-06-26 13:56:56.166291
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    method_name = 'patch_function'
    class_name = 'SWFInterpreter'
    method_args = ['self', 'avm_class', 'f', 'func_name']

    # Init
    var_0 = SWFInterpreter()
    var_1 = _AVMClass()
    var_2 = _MethodBody()
    # Code run
    var_3 = var_0.patch_function(var_1, var_2, 'func', 'func_str')
    if not isinstance(var_3, types.FunctionType):
        raise AssertionError()


# Generated at 2022-06-26 13:57:01.042421
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf_interp = SWFInterpreter(None)

    # std::vector<ASObject*, std::allocator<ASObject*> >*
    as_object_vec = []

    # ASObject*
    str_0 = StringClass.make_object()
    str_0.static_properties['length'] = 32

    # ASObject*
    str_1 = StringClass.make_object()
    str_1.static_properties['length'] = 1

    as_object_vec.append(str_0)
    as_object_vec.append(str_1)

    # ASObject*
    as_object_ptr_0 = ArrayClass.make_object()
    as_object_ptr_0.static_properties['length'] = 2

    # ASObject*
    as_object_ptr_1 = as_object

# Generated at 2022-06-26 13:57:10.891602
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    coder = compat_BytesIO(b'\x00\x29\x01\x00')
    const_strings = []
    const_multinames = []
    const_namespaces = []
    const_namespace_sets = []
    const_method_info = []
    const_metadata_info = []
    const_instances = []
    const_classes = []
    const_scripts = []
    const_method_bodies = []
    SWFInterpreter_0 = SWFInterpreter(coder, const_strings, const_multinames, const_namespaces, const_namespace_sets, const_method_info, const_metadata_info, const_instances, const_classes, const_scripts, const_method_bodies)


# Generated at 2022-06-26 13:58:18.273553
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert len(s_w_f_interpreter_0.constant_strings) == 482
    assert len(s_w_f_interpreter_0.constant_strings[0]) == 11
    assert len(s_w_f_interpreter_0.constant_strings[481]) == 4
    assert len(s_w_f_interpreter_0.constant_namespaces) == 231
    assert len(s_w_f_interpreter_0.constant_namespace_sets) == 1
    assert len(s_w_f_interpreter_0.constant_namespace_sets[0]) == 3

    assert len(s_w_f_interpreter_0.constant_multi_names) == 548

# Generated at 2022-06-26 13:58:26.841324
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf_interpreter = SWFInterpreter()
    with open(os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'as_swf_data_functions',
        'test_extract_function_0.swf'), 'rb') as f:
        avm_class = swf_interpreter.parse(f)
    swf_interpreter.extract_function(avm_class, 'test0')
    swf_interpreter.extract_function(avm_class, 'test1')


# Generated at 2022-06-26 13:58:28.229814
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert s_w_f_interpreter_0


# Generated at 2022-06-26 13:58:36.118072
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    local_interpreter = SWFInterpreter()
    # print(local_interpreter.constant_strings)
    # print(local_interpreter.constant_ints)
    # print(local_interpreter.constant_floats)
    local_interpreter.patch_function('ord', lambda x: x)
    local_interpreter.patch_function('parseInt', lambda x: x)

# Generated at 2022-06-26 13:58:47.564822
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # Test case SWFInterpreter_extract_function_0
    s_w_f_interpreter_0 = SWFInterpreter()
    avm_class_0 = AVMClass_Object()
    func_name_0 = 'String'

    # Test case SWFInterpreter_extract_function_1
    s_w_f_interpreter_1 = SWFInterpreter()
    avm_class_1 = AVMClass_Object()
    func_name_1 = 'String'

    # Test case SWFInterpreter_extract_function_2
    s_w_f_interpreter_2 = SWFInterpreter()
    avm_class_2 = AVMClass_Object()
    func_name_2 = 'String'

    # Test case SWFInterpreter_

# Generated at 2022-06-26 13:58:49.628696
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert SWFInterpreter() is not None

# Unit test of the AVMFile class

# Generated at 2022-06-26 13:58:56.247023
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    s_w_f_interpreter_1 = SWFInterpreter()

    def func_1(args):
        return 0
    def func_2(args):
        return 0

    s_w_f_interpreter_1.method_pyfunctions[0] = func_1
    s_w_f_interpreter_1.patch_function(0, func_2)
    res_0_0 = s_w_f_interpreter_1.method_pyfunctions[0]
    assert res_0_0 == func_2



# Generated at 2022-06-26 13:58:59.849761
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s_w_f_interpreter_0 = SWFInterpreter()
    filename = 'test.py'
    avm_class = AnyType()
    func_name = 'function'
    s_w_f_interpreter_0.extract_function(avm_class, func_name)
    return None


# Generated at 2022-06-26 13:59:02.856825
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    s_w_f_interpreter_0 = SWFInterpreter()

if __name__ == '__main__':
    import sys
    import doctest

    if doctest.testmod().failed == 0:
        sys.exit(0)
    else:
        sys.exit(1)

# Generated at 2022-06-26 13:59:12.348891
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s_w_f_interpreter_0 = SWFInterpreter(
        constant_strings=['foo', 'bar'],
        multinames=['foo', 'bar'],
    )
    method_info = {
        'code': b'\x2d\x00\x00\x00\x00\x00\x00\x00\x00',
        'name': 'bar',
        'param_types': [],
    }
    avm_class_0 = _AVMClass('foo', [], [], [])
    actual_0 = s_w_f_interpreter_0.extract_function(avm_class_0, method_info)
    expected_0 = undefined
    assert actual_0 == expected_0

# Generated at 2022-06-26 14:00:16.769810
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    str_0 = '\nh8;})\x0cg+BxwrAZQ#2U'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    retval_0 = s_w_f_interpreter_0.extract_class()
    assert retval_0 == _AVMClass


# Generated at 2022-06-26 14:00:19.844297
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf_interpreter = SWFInterpreter(0)
    assert swf_interpreter.patch_function(0, 0, 0) is None


# Generated at 2022-06-26 14:00:26.155408
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    str_0 = '\nh8;})\x0cg+BxwrAZQ#2U'
    str_1 = '\nh8;})\x0cg+BxwrAZQ#2U'
    __repr__0 = None
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    s_w_f_interpreter_0.patch_function('__repr__', __repr__0)


# Generated at 2022-06-26 14:00:35.047432
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-26 14:00:41.249387
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    s_w_f_interpreter_0 = SWFInterpreter()
    # Set some members of s_w_f_interpreter_0

# Generated at 2022-06-26 14:00:51.627017
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    str_0 = '\nh8;})\x0cg+BxwrAZQ#2U'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    func_name_0 = 'onTextData'
    s_w_f_func_0 = s_w_f_interpreter_0.extract_function(func_name_0)
    arg_count_0 = 0
    args_0 = []
    s_w_f_func_0(args_0)

# Generated at 2022-06-26 14:00:59.635444
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    str_0 = '\nh8;})\x0cg+BxwrAZQ#2U'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    a_v_m_class_0 = AVMClass('\x12\x00\x05VideoPlayer\x00\x06Object', s_w_f_interpreter_0, {'\x12\x00\x05VideoPlayer\x00\x06Object': []})

# Generated at 2022-06-26 14:01:05.805128
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    str_0 = '\nh8;})\x0cg+BxwrAZQ#2U'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    assert s_w_f_interpreter_0.file_version == 22
    assert len(s_w_f_interpreter_0.constant_strings) == 6
    assert len(s_w_f_interpreter_0.multinames) == 30
    assert len(s_w_f_interpreter_0.methods) == 36
    assert len(s_w_f_interpreter_0.traits) == 37
    assert len(s_w_f_interpreter_0.classes) == 26

# Generated at 2022-06-26 14:01:09.438567
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    str_0 = '\nh8;})\x0cg+BxwrAZQ#2U'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    assert s_w_f_interpreter_0.extract_function(None, '6') is None


# Generated at 2022-06-26 14:01:17.462460
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import re
    str_0 = '\nh8;})\x0cg+BxwrAZQ#2U'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    avm_class_0 = s_w_f_interpreter_0.classes[0]
    re_0 = re.compile('(?P<fun>[a-z_]+)\\((?P<params>[a-z,_]+)\\)')
    str_1 = '_0x(?P<name>[a-z_]+)(?P<param>\\(.*?\\))'
    re_1 = re.compile(str_1)

# Generated at 2022-06-26 14:03:28.784302
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    str_0 = '\nh8;})\x0cg+BxwrAZQ#2U'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    assert s_w_f_interpreter_0.extract_function(
        s_w_f_interpreter_0.avm_class, 'decode')
    assert s_w_f_interpreter_0.extract_function(
        s_w_f_interpreter_0.avm_class, 'encode')


# Generated at 2022-06-26 14:03:32.869125
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    str_0 = '\nh8;})\x0cg+BxwrAZQ#2U'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    class_0 = s_w_f_interpreter_0.extract_class()


# Generated at 2022-06-26 14:03:39.837181
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    str_0 = '9n\'<\x7f\x1fN\x0f\x0f\x17\x0f\t\x17\x1f\x0fY\x1d\x1f\x02\x07'
    str_1 = '9n\'<\x7f\x1fN\x1f\x02\x07'
    int_4 = 1
    int_3 = 1
    int_2 = 0
    int_1 = 0
    str_2 = '9n\'<\x7f\x1fN\x0f\x0f\x17\x0f\t\x17\x1f\x0fY\x1d\x1f\x02\x07'

# Generated at 2022-06-26 14:03:44.213885
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    str_0 = '\nh8;})\x0cg+BxwrAZQ#2U'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)


if __name__ == '__main__':
    test_case_0()
    test_SWFInterpreter_extract_function()
    # TODO add tests

# Generated at 2022-06-26 14:03:49.142289
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():

    str_0 = 'p\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)


    class_0 = s_w_f_interpreter_0.extract_class(0)
    # AssertionError: Class 0 not found


# Generated at 2022-06-26 14:03:50.865439
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    test_case_0()


# Generated at 2022-06-26 14:03:59.243329
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-26 14:04:00.953469
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    try:
        test_case_0()
        print("OK")
    except Exception as e:
        print("Failed:", e)




# Generated at 2022-06-26 14:04:07.842333
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    str_0 = '\nh8;})\x0cg+BxwrAZQ#2U'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    str_1 = 'y'
    str_2 = 'h'
    int_0 = 0
    avm_class_0 = s_w_f_interpreter_0.extract_class(
        str_1, str_2, int_0)
    assert isinstance(avm_class_0, _AVMClass)
    assert avm_class_0.class_name == 'y'
    assert avm_class_0.super_class.class_name == 'h'
    assert avm_class_0.instance_info == {}


# Generated at 2022-06-26 14:04:10.483582
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    str_0 = '\nh8;})\x0cg+BxwrAZQ#2U'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    s_w_f_interpreter_0.patch_function(None, None)


if __name__ == '__main__':
    test_SWFInterpreter_patch_function()
    test_case_0()