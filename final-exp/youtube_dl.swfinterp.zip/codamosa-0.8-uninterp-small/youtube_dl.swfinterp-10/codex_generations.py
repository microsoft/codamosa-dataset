

# Generated at 2022-06-26 13:55:28.318845
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert SWFInterpreter() is not None



# Generated at 2022-06-26 13:55:31.152857
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    func_name = 'test_case_0'
    avm_class = _AVMClass()
    interpreter = SWFInterpreter()
    interpreter.extract_function(avm_class, func_name)


# Generated at 2022-06-26 13:55:42.749813
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter()

    swf.constant_pool = [
        'testing',
        'test_method',
        'test_method',
        'test_attr',
        'test_slot',
    ]
    swf.unparsed_class = _AVMClass(
        traits=[
            _AVMClassSlot(
                name='test_slot',
                value=undefined),
        ])
    swf.string_lookup = {
        0: 'testing',
        1: 'test_method',
        2: 'test_method',
        3: 'test_attr',
        4: 'test_slot',
    }

# Generated at 2022-06-26 13:55:50.391571
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # Unknown types in arguments
    with pytest.raises(TypeError):
        undefined_0 = _Undefined()
        var_0 = SWFInterpreter.patch_function(undefined_0, test_case_0)

    # Assertion error
    with pytest.raises(AssertionError):
        var_0 = SWFInterpreter.patch_function(0, test_case_0)

    # Assertion error
    with pytest.raises(AssertionError):
        var_0 = SWFInterpreter.patch_function(0, None)

    # Assertion error
    with pytest.raises(AssertionError):
        var_0 = SWFInterpreter.patch_function(
            _Undefined(),
            test_case_0)

    # Assertion error

# Generated at 2022-06-26 13:55:55.455605
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .test_data import SWFInterpreter_extract_class_cases

    for i, (desc, bin_data) in enumerate(
        SWFInterpreter_extract_class_cases()):
        intpr = SWFInterpreter()
        intpr.read(bin_data)

        avm_class = intpr.extract_class(desc)
        # print(avm_class)

        if avm_class.name == 'test_0':
            test_case_0()


# Generated at 2022-06-26 13:56:03.782824
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-26 13:56:15.405720
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from ctypes import windll

    interp = SWFInterpreter()

    method_body_data = BytesIO()
    method_body_data.write(b'\x00\x00\x00\x00')  # method_body_len
    method_body_data.write(b'\x00\x00\x00\x00')  # method_id
    method_body_data.write(b'\x00')  # max_stack
    method_body_data.write(b'\x00\x00')  # local_count
    method_body_data.write(b'\x00\x00')  # init_scope_depth
    method_body_data.write(b'\x00\x00')  # max_scope_depth
   

# Generated at 2022-06-26 13:56:18.728784
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_file_path = './tests/swfs/test_0000.swf'
    assert os.path.exists(test_file_path)
    SWFInterpreter(test_file_path)



# Generated at 2022-06-26 13:56:20.750863
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    si = SWFInterpreter()
    si.extract_function(None, None)


# Generated at 2022-06-26 13:56:30.361674
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    coder = BytesIO()

    # Write a single method that does nothing
    _write_ubyte(coder, 0x10)  # header_size
    _write_ubyte(coder, 0x02)  # version
    _write_ubyte(coder, 0x00)  # file_length, Part 1
    _write_ubyte(coder, 0x00)  # file_length, Part 2

    _write_ubyte(coder, 0x00)  # file_length, Part 3
    _write_ubyte(coder, 0x00)  # file_length, Part 4
    _write_ubyte(coder, 0x01)  # frame_size, Part 1
    _write_ubyte(coder, 0x00)  # frame_size

# Generated at 2022-06-26 13:57:14.752535
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    s_w_f_interpreter_0 = SWFInterpreter()
    s_w_f_interpreter_0.extract_class(None, None)


# Generated at 2022-06-26 13:57:23.198039
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    s_w_f_interpreter_0 = SWFInterpreter()
    assert_equals(s_w_f_interpreter_0.AVM2, False)
    assert_equals(s_w_f_interpreter_0.constant_strings, [])
    assert_equals(s_w_f_interpreter_0.constant_ints, [])
    assert_equals(s_w_f_interpreter_0.constant_uints, [])
    assert_equals(s_w_f_interpreter_0.constant_doubles, [])
    assert_equals(s_w_f_interpreter_0.constant_namespaces, [])

# Generated at 2022-06-26 13:57:28.999858
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    avm_class_0 = _AVMClass(0)
    s_w_f_interpreter_0 = SWFInterpreter()
    avm_class_1 = s_w_f_interpreter_0.extract_class(avm_class_0)
    assert avm_class_0 == avm_class_1


# Generated at 2022-06-26 13:57:36.575251
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert_raises(NotImplementedError, s_w_f_interpreter_0.extract_function)
    assert_raises(NotImplementedError, s_w_f_interpreter_0.run_function)
    assert_raises(NotImplementedError, s_w_f_interpreter_0.dump_all)
    assert_raises(NotImplementedError, s_w_f_interpreter_0.dump_class)
    assert_raises(NotImplementedError, s_w_f_interpreter_0.dump_function)
# Test Case End

# Generated at 2022-06-26 13:57:41.583050
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    print('%s: ' % ('test_SWFInterpreter_extract_function', ))
    # Case 0
    s_w_f_interpreter_0 = SWFInterpreter()
    s_w_f_interpreter_0.extract_function(None, None)


if __name__ == '__main__':
    test_case_0()
    test_SWFInterpreter_extract_function()

# Generated at 2022-06-26 13:57:44.613374
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert isinstance(s_w_f_interpreter_0, SWFInterpreter)


"""Unit test for method _read_byte() in class SWFInterpreter"""


# Generated at 2022-06-26 13:57:55.026885
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter()

    # Test case SWFInterpreter_extract_function_0
    avm_class = _AVMClass([], {}, {}, {}, {})

    # Test case SWFInterpreter_extract_function_0
    swf._read_constant_strings(['test1', 'test2'])
    swf._read_constant_namespaces([None])

    # Test case SWFInterpreter_extract_function_0
    swf.multinames = [
        _Multiname(0, 'test1'),
        _Multiname(0, 'test2'),
    ]

    # Test case SWFInterpreter_extract_function_0
    coder = io.BytesIO()

# Generated at 2022-06-26 13:58:01.339183
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s_w_f_interpreter_0 = SWFInterpreter()
    _avm_class_0 = _AVMClass()
    s_w_f_interpreter_0.extract_function(_avm_class_0, 'func_name')

    try:
        s_w_f_interpreter_0.extract_function(_avm_class_0, 'func_name_0')
        assert False
    except AssertionError:
        pass

    try:
        s_w_f_interpreter_0.extract_function(_avm_class_0, 'func_name_1')
        assert False
    except AssertionError:
        pass


# Generated at 2022-06-26 13:58:07.009595
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    print('Testing patch_function')
    s_w_f_interpreter_0 = SWFInterpreter()

    # Case 0
    try:
        s_w_f_interpreter_0.patch_function()
    except:
        pass

    # Case 1
    try:
        s_w_f_interpreter_0.patch_function(1)
    except:
        pass


# Generated at 2022-06-26 13:58:15.759948
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    s_w_f_interpreter_0 = SWFInterpreter()

# Generated at 2022-06-26 14:00:55.621220
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    s_w_f_interpreter_0 = SWFInterpreter()
    s_w_f_extractor_0 = SWFExtractor()
    f = open(os.path.join(BASE_PATH, 'test_data', 'vpaid_test.swf'), 'rb')
    coder = io.BytesIO(f.read())
    f.close()
    avm_class = s_w_f_interpreter_0.extract_class(coder, s_w_f_extractor_0, 'SVObject')
    assert avm_class
    assert 'getFlashVars' in avm_class.method_pyfunctions
    assert avm_class.method_pyfunctions['getFlashVars'](['k', 'v']) == undefined


# Generated at 2022-06-26 14:00:56.994516
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_case_0()

if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-26 14:00:57.768204
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    s_w_f_interpreter_0 = SWFInterpreter()


# Generated at 2022-06-26 14:01:04.100945
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    with open(os.path.join(DATA_DIR, 'egg.swf'), 'rb') as f:
        swf_data = f.read()
    swf = SWF(swf_data)
    assert swf.valid
    s_w_f_interpreter_0 = SWFInterpreter()
    s_w_f_interpreter_0.parse_swf(swf_data)
    assert s_w_f_interpreter_0.swf != ''
    assert s_w_f_interpreter_0.contexts != {}
    assert s_w_f_interpreter_0.scripts != {}
    assert s_w_f_interpreter_0.constants != {}
    assert s_w_f_interpreter_0.functions != {}
    assert s

# Generated at 2022-06-26 14:01:11.555203
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf_interpreter_obj_0 = SWFInterpreter()

    case_name = '0'

    avm_class_obj_0 = _AVMClass(None)
    avm_class_obj_0.static_properties = {}

    func_name = 'method_name'

    exception_raised = False
    try:
        swf_interpreter_obj_0.extract_function(avm_class_obj_0, func_name)
    except NotImplementedError:
        exception_raised = True
    if exception_raised is False:
        assert False, 'Test %s failed: %s' % (case_name, 'SWFInterpreter.extract_function did not raise NotImplementedError')

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 14:01:16.491103
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s_w_f_interpreter_0 = SWFInterpreter()
    avm_class_0 = SWFClass()
    func_name_0 = 'test1'
    s_w_f_interpreter_0.extract_function(avm_class_0, func_name_0)
    assert avm_class_0.method_names == ['test1']


# Generated at 2022-06-26 14:01:20.237076
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Example (see Flash documentation)
    with open('fixtures/test_0.swf', 'rb') as f:
        s = f.read()
    sc = SWFInterpreter()
    sc.read_bytes(s)
    sc.extract_class('Test')


# Generated at 2022-06-26 14:01:22.849983
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # Code generated from this call
    # SWFInterpreter()
    s_w_f_interpreter_0 = SWFInterpreter()


# Generated at 2022-06-26 14:01:23.999714
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    s_w_f_interpreter_0 = SWFInterpreter()


# Generated at 2022-06-26 14:01:31.726559
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    coder = BytesIO()
    _write_byte(coder, 4)  # OP_pushbyte
    _write_byte(coder, 0)
    _write_byte(coder, 4)  # OP_pushbyte
    _write_byte(coder, 1)
    _write_byte(coder, 21)  # OP_iflt
    _write_byte(coder, 0)
    _write_byte(coder, 188)
    _write_byte(coder, 0)
    _write_byte(coder, 0)
    _write_byte(coder, 5)  # OP_pushbyte
    _write_byte(coder, 0)
    _write_byte(coder, 38)  # OP_pushtrue
    _write_byte(coder, 0)
    _write_

# Generated at 2022-06-26 14:03:16.507086
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    s_w_f_interpreter_0 = SWFInterpreter()

test_case_0()

# Generated at 2022-06-26 14:03:20.057850
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s_w_f_interpreter_0 = SWFInterpreter()

    s_w_f_interpreter_0.extract_function(
        avm_class=None,
        func_name=None,
    )


# Generated at 2022-06-26 14:03:31.045539
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    s_w_f_interpreter_0 = SWFInterpreter()
    with open(os.path.join(os.path.split(__file__)[0],
                           '../test/test_0.swf'), 'rb') as f:
        swf_0 = f.read()
    s_w_f_interpreter_0.extract_script(swf_0)
    assert s_w_f_interpreter_0.extract_function(
        s_w_f_interpreter_0.AVMClass_Start, 'AVM1_0')
    assert 'function_0' in \
        s_w_f_interpreter_0.AVMClass_Start.method_pyfunctions
    assert 'function_1' in \
        s_w_f_interpre

# Generated at 2022-06-26 14:03:33.891017
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    s_w_f_interpreter_0 = SWFInterpreter()
    func = lambda args: None
    _ = s_w_f_interpreter_0.patch_function(
        func)



# Generated at 2022-06-26 14:03:40.431316
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s_w_f_interpreter_0 = SWFInterpreter()
    assert not hasattr(s_w_f_interpreter_0, 'method_pyfunctions')
    assert not hasattr(s_w_f_interpreter_0, 'constant_strings')
    assert not hasattr(s_w_f_interpreter_0, 'multinames')

    def avm_class(func_name):
        res = _AVMClass()

# Generated at 2022-06-26 14:03:47.292423
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    py_codes = [
        'PUSHSCOPE',
        'PUSHSTRING "foo"',
        'PUSHINT 0',
        'GETPROPERTY Multiname {Namespace [Namespace public] Name "foo"}',
        'COERCE_A',
        'PUSHSTRING "bar"',
        'SETPROPERTY Multiname {Namespace [Namespace public] Name "bar"}',
        'RETURNVALUE',
    ]
    res = s_w_f_interpreter_0.patch_function(py_codes)
    assert res == 'bar'


# Generated at 2022-06-26 14:03:56.671402
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    avm_interpreter = SWFInterpreter()

    # Test with an empty script
    abc_data = b''
    class_name, avm_class = avm_interpreter.extract_class(abc_data)
    assert class_name is None
    assert avm_class is None

    # Test with a correctly formed script
    # The script is
    #   class Test {
    #     public function test_method(a, b) {
    #       return a + b;
    #     }
    #   }

# Generated at 2022-06-26 14:04:04.080847
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s_w_f_interpreter_0 = SWFInterpreter()

    class TestAVMClass(object):
        """Built-in class for testing"""
        @staticmethod
        def method_get_0(context):
            pass
        @staticmethod
        def method_set_0(context):
            pass

    test_class_0 = TestAVMClass()
    test_class_1 = TestAVMClass()

    s_w_f_interpreter_0.extract_function(test_class_0, 'get')
    s_w_f_interpreter_0.extract_function(test_class_0, 'set')

# Generated at 2022-06-26 14:04:07.220094
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    assert isinstance(test_case_0().s_w_f_interpreter_0, SWFInterpreter)
    with pytest.raises(NotImplementedError):
        test_case_0().s_w_f_interpreter_0.extract_class(
            None, None, None, None)


# Generated at 2022-06-26 14:04:09.017046
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s_w_f_interpreter_1 = SWFInterpreter()
    s_w_f_interpreter_1.extract_function()
