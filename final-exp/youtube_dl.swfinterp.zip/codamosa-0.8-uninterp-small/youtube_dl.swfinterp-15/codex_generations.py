

# Generated at 2022-06-26 13:56:32.945482
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = dbg_SWF(SWF_TEST_CASES[0])

    si = SWFInterpreter(swf)
    si.extract_function(si.do_action_get_main_class(), 'run')


# Generated at 2022-06-26 13:56:40.790516
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # Create an instance
    swf_interpreter = SWFInterpreter()
    print('Instantiating successful!')

    # Call patch_function with empty value
    swf_interpreter.patch_function('', '')
    print('Call patch_function with empty value successful!')

    # Call patch_function with correct value
    swf_interpreter.patch_function('patch_function', test_case_0)
    print('Call patch_function with correct value successful!')

    # Call patch_function with correct value
    swf_interpreter.patch_function('patch_function', test_case_0)
    print('Call patch_function with correct value successful!')


# Generated at 2022-06-26 13:56:43.557083
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swfbytes = b''
    swf = SWFInterpreter(swfbytes)



# Generated at 2022-06-26 13:56:49.748932
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # SWFInterpreter.extract_class returns an _AVMClass instance
    # _AVMClass instance is created as _AVMClass(_AVMClass_Object)
    s = SWFInterpreter(avm1_actionscript_swf_data('as2', 'empty'))
    assert type(s.extract_class('avmplus')) is _AVMClass
    assert type(s.extract_class('avmplus').make_object()) is _AVMClass_Object


# Generated at 2022-06-26 13:56:58.765789
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import io
    import binascii
    from .tagreader import TagReader


# Generated at 2022-06-26 13:57:07.287214
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf_interpreter = SWFInterpreter()
    swf_interpreter.method_bodies = {1: {
        'activation': {},
        'method_info': {'flags': 0,
                        'name': 'undefined_0'},
        'max_regs': 1,
        'max_scope': 0,
        'min_regs': 1,
        'opcodes': [
            {'opcode': 41, 'operand': 0},
        ],
    }}
    undefined_0 = swf_interpreter.extract_function(None, None)
    undefined_0()



# Generated at 2022-06-26 13:57:16.362133
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # Test with args (dict(int -> list<Variable>), dict(int -> list<Variable>))
    # Should be same as test_case_0
    avm_class = _AVMClass(None)
    avm_class.add_method(
        'test_method', [], [])
    assert avm_class.method_names == ['test_method']
    assert avm_class.method_pyfunctions == {}
    assert avm_class.static_properties == {}
    assert avm_class.static_constants == {}
    assert avm_class.variables == {}

    interpreter = SWFInterpreter('', avm_class, False, False)

    assert interpreter.extract_function(avm_class, 'test_method') is undefined_0


# Generated at 2022-06-26 13:57:17.322185
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interpreter = SWFInterpreter()


# Generated at 2022-06-26 13:57:20.849361
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_interpreter = SWFInterpreter()
    swf_interpreter.extract_class(
        test_case_0, 'constant_strings',
        ['null', 'undefined', 'getVersion'],
        ['null', 'undefined'],
        {
            'null': None,
            'undefined': undefined_0,
        },
        ['null', 'String', 'undefined'],
        {
            'String': StringClass,
        },
        {},
    )
    swf_interpreter.classes['test_case_0'] = swf_interpreter.classes[0]


# Generated at 2022-06-26 13:57:24.591244
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    avm_interpreter = SWFInterpreter()
    avm_interpreter.extract_function(None, None)


if __name__ == '__main__':
    test_SWFInterpreter_extract_function()

# Generated at 2022-06-26 13:58:29.702787
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # Create test case
    from swf.utils import swf_dump
    from swf.show import Show
    from swf.compression import uncompress_data
    from swf.compression import decompress_data
    from swf.compression import compress_data
    from swf.avm import AVMClass
    from swf.avm import AVMMethod
    from swf.avm import AVM2Code
    from swf.avm import AVM2ConstantString
    from swf.avm import AVM2ConstantInt
    from swf.avm import AVM2Multiname
    from swf.avm import AVM2ConstantFloat
    from swf.avm import AVM2ConstantsPool
    from swf.tag import ScriptLimits
    from swf.tag import ProductInfo
   

# Generated at 2022-06-26 13:58:31.788596
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    bytes_0 = b'\x4a\x00\x00\x00'
    s_w_f_interpreter_0 = SWFInterpreter(bytes_0)
    string_0 = 'String'
    s_w_f_interpreter_0.extract_function(string_0)


# Generated at 2022-06-26 13:58:32.455634
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    assert False, "Not implemented"


# Generated at 2022-06-26 13:58:34.314054
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    print('Testing constructor of class SWFInterpreter')
    test_case_0()



# Generated at 2022-06-26 13:58:36.412442
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_case_0()

if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-26 13:58:48.126526
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    print('Testing SWFInterpreter.extract_function')

    # Test case 0

# Generated at 2022-06-26 13:58:57.349994
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    """SWFInterpreter: testing method extract_function"""
    bytes_0 = b''
    s_w_f_interpreter_0 = SWFInterpreter(bytes_0)
    abc_file_0 = ABCFile()
    abc_file_0.bytes = b'byta'
    abc_file_0.method_body_infos = [None]
    abc_file_0.constant_strings = ['a']
    abc_file_0.constant_ints = []
    abc_file_0.method_names = ['a']
    abc_file_0.method_param_counts = [0]
    abc_file_0.multinames = [_Multiname(namespace=0, name=2)]
    abc_file_0.namespaces

# Generated at 2022-06-26 13:58:59.128873
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_case_0()

if __name__ == "__main__":
    test_SWFInterpreter()

# Generated at 2022-06-26 13:59:05.405846
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # case1
    bytes_2 = b''
    s_w_f_interpreter_2 = SWFInterpreter(bytes_2)
    # check s_w_f_interpreter_2
    assert (s_w_f_interpreter_2.version == 0)
    assert (s_w_f_interpreter_2.avm_class is None)
    assert (s_w_f_interpreter_2.method_names == [])
    assert (s_w_f_interpreter_2.constant_integers == [])
    assert (s_w_f_interpreter_2.constant_unsigned_integers == [])
    assert (s_w_f_interpreter_2.constant_doubles == [])

# Generated at 2022-06-26 13:59:15.144954
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .swf_parser import SWFParser
    from io import BytesIO
    avm_class = SWFParser(['./SWFTags/ScriptLimitsTag.swf']).parse()
    func_name = 'ScriptLimitsTag'
    avm_class.method_pyfunctions[func_name] = None
    patch_indices = [0]
    reference_indices = [0]
    s_w_f_interpreter_0 = SWFInterpreter(None)
    s_w_f_interpreter_0.patch_function(avm_class, func_name, patch_indices, reference_indices)

if __name__ == '__main__':
    test_case_0()
    test_SWFInterpreter_patch_function()

# Generated at 2022-06-26 14:00:21.488554
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_case_0()


# Generated at 2022-06-26 14:00:24.340264
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    bytes_0 = b''
    s_w_f_interpreter_0 = SWFInterpreter(bytes_0)
    s_w_f_interpreter_0.extract_function('_')



# Generated at 2022-06-26 14:00:27.405844
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Test for extract_class(self, offset)
    # Test for extract_class(self, offset, do_extract_code=True)
    assert False  # TODO: implement your test here


# Generated at 2022-06-26 14:00:36.348677
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    bytes_0 = b'\x10\x00\x2e\x00\x00\x00\x00\x00'
    bytes_0 += b'\x03\x00\x00\x00\x00\x00\x00\x00'
    bytes_0 += b'\x05\x00\x00\x00\x00\x00\x00\x00'
    bytes_0 += b'\x07\x00\x00\x00\x00\x00\x00\x00'
    bytes_0 += b'\x02\x00\x00\x00\x00\x00\x00\x00'
    s_w_f_interpreter_0 = SWFInterpreter(bytes_0)
    s_w_f_interpre

# Generated at 2022-06-26 14:00:41.928736
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    bytes_0 = b'\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00'
    s_w_f_interpreter_0 = SWFInterpreter(bytes_0)
    # The init function is missing


# Generated at 2022-06-26 14:00:51.941123
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-26 14:00:56.186685
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    bytes_0 = b''
    s_w_f_interpreter_0 = SWFInterpreter(bytes_0)
    args_0 = []
    try:
        s_w_f_interpreter_0.extract_function(0, 0)
        assert False
    except IndexError:
        pass


# Generated at 2022-06-26 14:00:57.026211
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # test_case_0()
    pass



# Generated at 2022-06-26 14:01:03.273664
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    bytes_0 = b'\x0a'
    s_w_f_interpreter_0 = SWFInterpreter(bytes_0)
    multiname_0 = Multiname()
    multiname_0.name = 'MustBeString'
    bool_0 = multiname_0.is_string()
    #assert bool_0
    multiname_1 = Multiname()
    multiname_1.name = 'MustBePublic'
    bool_1 = multiname_1.is_public()
    #assert bool_1
    multiname_2 = Multiname()
    multiname_2.name = 'MustBeProtected'
    bool_2 = multiname_2.is_protected()
    #assert bool_2
    multiname_3 = Multiname()

# Generated at 2022-06-26 14:01:09.125651
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    p = SWFInterpreter.extract_function

# Generated at 2022-06-26 14:02:19.617166
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Testing for exception AttributeError
    # The interpreter always extracts the class 'Main'
    with pytest.raises(AttributeError):
        SWFInterpreter(b'').extract_class('undefined')


# Generated at 2022-06-26 14:02:20.825440
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_case_0()

FILE_CACHE = {}



# Generated at 2022-06-26 14:02:30.295083
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-26 14:02:38.627908
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-26 14:02:46.059066
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-26 14:02:54.410374
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-26 14:03:04.506266
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    global s_w_f_interpreter_0
    global avm_function_0
    global _SWFInterpreter_extract_function__avm_class_0
    global _SWFInterpreter_extract_function__func_name_0
    global _SWFInterpreter_extract_function__max_stack_0
    global _SWFInterpreter_extract_function__reg_count_0
    global _SWFInterpreter_extract_function__scope_depth_0

    s_w_f_interpreter_0 = SWFInterpreter(bytes_0)

# Generated at 2022-06-26 14:03:05.552209
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_case_0()


# Generated at 2022-06-26 14:03:08.072301
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    test_SWFInterpreter_extract_function_0()
    test_SWFInterpreter_extract_function_1()


# Generated at 2022-06-26 14:03:13.556708
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    bytes_0 = b'\x04\x00\x01\x00\x00\x00\x00\x00\x00\x01\x07\x00\x04\x01\x00'
    bytes_0 += b'\x0B\x02\x03\x00\x01\x02\x00\x00\x01\x00\x00\x00\x01\x00\x00'
    bytes_0 += b'\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'