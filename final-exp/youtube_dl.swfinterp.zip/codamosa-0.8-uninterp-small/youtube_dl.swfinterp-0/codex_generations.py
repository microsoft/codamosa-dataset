

# Generated at 2022-06-26 13:55:40.018889
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_file = open(EXAMPLE_SWF_FILENAME, 'rb').read()
    interpreter = SWFInterpreter(swf_file)
    interpreter.extract_class(None)
    assert interpreter.extract_class(interpreter.constant_strings[1]) == \
        _AVMClass_Object(False)
    assert interpreter.extract_class(interpreter.constant_strings[2]) == \
        _AVMClass_Object(True)
    assert interpreter.extract_class(interpreter.constant_strings[3]) == \
        _AVMClass_Object(0)
    assert interpreter.extract_class(interpreter.constant_strings[4]) == \
        _AVMClass_Object(1)

# Generated at 2022-06-26 13:55:44.493956
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf_interpreter_0 = SWFInterpreter(bool_0)
    a_v_m_class_1 = _AVMClass(bool_0)
    bool_2 = True
    swf_interpreter_0.extract_function(a_v_m_class_1, bool_2)


# Generated at 2022-06-26 13:55:47.906535
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    dict_0 = dict()
    dict_0['a'] = 'a'
    dict_0['b'] = 'b'
    dict_0['c'] = 'c'
    dict_0['d'] = 'd'
    dict_0['e'] = 'e'
    dict_0['f'] = 'f'
    dict_0['g'] = 'g'
    dict_0['h'] = 'h'
    dict_0['i'] = 'i'
    dict_0['j'] = 'j'
    dict_0['k'] = 'k'
    dict_0['l'] = 'l'
    dict_0['m'] = 'm'
    dict_0['n'] = 'n'
    dict_0['o'] = 'o'
    dict_0['p'] = 'p'

# Generated at 2022-06-26 13:55:56.404775
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    string_0 = '0'
    string_1 = '1'
    string_2 = '2'
    string_3 = '3'
    string_4 = '4'
    string_5 = '5'
    string_6 = '6'
    string_7 = '7'
    string_8 = '8'
    string_9 = '9'
    string_10 = '10'
    string_11 = '11'
    string_12 = '12'
    string_13 = '13'
    string_14 = '14'
    string_15 = '15'
    string_16 = '16'
    string_17 = '17'
    string_18 = '18'
    string_19 = '19'
    string_20 = '20'
    string_21 = '21'
   

# Generated at 2022-06-26 13:56:01.413217
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter()
    # TODO: should we test it with a file?
    testfunc = interpreter.extract_function(
        avm_class=_AVMClass(
            name='Object', static_properties={},
            getters={}, setters={},
            method_names=['toString']),
        func_name='toString')
    # TODO: should we test the output?


# Generated at 2022-06-26 13:56:03.293791
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_interpreter_0 = SWFInterpreter()
    swf_interpreter_0.extract_class(0, 0, 0)


# Generated at 2022-06-26 13:56:04.294790
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    pass


# Generated at 2022-06-26 13:56:15.855244
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    a_v_m_class_0 = _AVMClass('Object')
    u30_0 = 3
    a_v_m_class_0.min_num_args = u30_0
    u30_1 = 3
    a_v_m_class_0.num_class_traits = u30_1
    u30_0 = 2
    a_v_m_class_0.min_num_args = u30_0
    a_v_m_class_0.extract_function()
    a_v_f_class_0 = _AVMClass('Date')
    a_v_f_class_0.extract_function()
    a_v_f_class_1 = _AVMClass('Array')
    a_v_f_class_1.extract_function()


# Generated at 2022-06-26 13:56:18.368295
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    bool_0 = True
    a_v_m_class__object_0 = _ScopeDict(bool_0)



# Generated at 2022-06-26 13:56:19.397490
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    test_case_0()


# Generated at 2022-06-26 13:57:55.365037
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert '_AVMClass_Object' in globals()
    assert '_AVMClass' in globals()
    assert '_Multiname' in globals()
    assert '_ScopeDict' in globals()
    assert 'SWFInterpreter' in globals()

    with open(os.path.join(os.path.dirname(__file__), 'test_case_0.swf'), 'rb') as f:
        bin_data = f.read()
    interpreter = SWFInterpreter(bin_data)

    assert 'test_case_0' in interpreter.avm_classes
    assert 'bool' in interpreter.avm_classes
    assert 'String' in interpreter.avm_classes
    assert 'Number' in interpreter.avm_classes
    assert 'Object' in interpreter.avm_classes


# Generated at 2022-06-26 13:58:01.759923
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-26 13:58:03.275480
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    test_case_0()


# Generated at 2022-06-26 13:58:12.120554
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    func_name = 'public function aname'
    a_v_m_class__function_0 = None
    a_v_m_class__function_0 = _AVMClass_Function()
    a_v_m_class__function_0.set_method_name(func_name)
    a_v_m_class__function_0.add_param_name('bool_0')
    a_v_m_class__function_0.add_param_name('a_v_m_class__object_0')
    a_v_m_class__function_0.add_param_name('a_v_m_class__object_1')
    a_v_m_class__function_0.set_code([])

# Generated at 2022-06-26 13:58:22.859683
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf_interpreter_0 = SWFInterpreter()
    swf_class_0 = swf_interpreter_0.parse_class(
        'Dummy.as',
        open(os.path.join(os.path.dirname(__file__), 'SWFTests/Dummy.as'), 'rb'))
    f = swf_interpreter_0.extract_function(swf_class_0, 'main')
    assert f() == 3
    f = swf_interpreter_0.extract_function(swf_class_0, 'test')
    assert f([2, 3, 4]) == 3
    f = swf_interpreter_0.extract_function(swf_class_0, 'test2')
    assert f([5, 7, 18]) == 18

# Generated at 2022-06-26 13:58:32.449494
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    global _builtin_classes, _avm_class_0, _avm_class_1, _avm_class_2
    global _avm_class_3, _avm_class_4
    global _avm_class_5, _avm_class_6, _avm_class_7, _avm_class_8
    global _avm_class_9, _avm_class_10, _avm_class_11
    assert {} == _builtin_classes
    _builtin_classes['Object'] = _avm_class_0
    _builtin_classes['Class'] = _avm_class_1
    _builtin_classes['Boolean'] = _avm_class_2
    _builtin_classes['Function'] = _avm_class_3
    _builtin_classes

# Generated at 2022-06-26 13:58:33.183927
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    assert False # Unimplemented


# Generated at 2022-06-26 13:58:36.303965
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf_interpreter_0 = SWFInterpreter(_SWF())
    return swf_interpreter_0.patch_function()


# Generated at 2022-06-26 13:58:47.963543
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    method_name = 'test_SWFInterpreter_patch_function'
    swfinterpreter = SWFInterpreter(
        '',
        '',
        '',
        None,
        None,
        None,
        None,
        None)
    # Set up for call to SWFInterpreter.avm_class_object
    bool_0 = True
    a_v_m_class__object_0 = _AVMClass_Object(bool_0)
    result_avm_class_object = swfinterpreter.avm_class_object(a_v_m_class__object_0)
    # Set up for call to SWFInterpreter.patch_function

# Generated at 2022-06-26 13:58:57.158518
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-26 14:01:04.902895
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interp = SWFInterpreter()
    interp.extract_class('0', [], [], [], [], 0)



# Generated at 2022-06-26 14:01:10.635822
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    global _imported_classes
    _imported_classes = {}
    _imported_classes[int] = int
    _imported_classes[compat_str] = compat_str
    _imported_classes[list] = list

    avm_interpreter_0 = SWFInterpreter()
    avm_interpreter_0.multinames = [None]
    avm_interpreter_0.constant_strings = []
    avm_interpreter_0.method_body_infos = [
        (0, {
            'max_registers': 4,
            'max_stack': 6,
            'scope_depth': 0,
            'name': None,
            'nargs': 0
        })
    ]

# Generated at 2022-06-26 14:01:17.954647
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from ._swf.utils import _s_s_s___s__s____s
    tmp_0 = _s_s_s___s__s____s()
    test_0 = False
    res_0 = True
    stack_0 = []
    regs_0 = [None, None, None, None]
    scopes_0 = []
    res_1 = tmp_0.extract_function(test_0, res_0, stack_0, regs_0, scopes_0)
    assert tmp_0.avm_class.method_pyfunctions['test_SWFInterpreter_extract_function'] is not None


# Generated at 2022-06-26 14:01:18.969880
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    test_case_0()
    assert True # TODO: implement your test here


# Generated at 2022-06-26 14:01:28.541190
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-26 14:01:35.860135
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():

    avm_interp_0 = SWFInterpreter()
    func_0 = avm_interp_0.extract_function(_AVMClass_Object, 'Boolean')

    res = func_0([])
    assert res is _AVMClass_Boolean
    res = func_0([False])
    assert res.class_ == _AVMClass_Boolean
    assert res.value == False
    res = func_0([True])
    assert res.class_ == _AVMClass_Boolean
    assert res.value == True
    assert_raises(NotImplementedError, func_0, [555])
    assert_raises(NotImplementedError, func_0, [None])

    func_1 = avm_interp_0.extract_function(_AVMClass_Object, 'Object')

# Generated at 2022-06-26 14:01:38.144017
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    data = compat_bytes()

    swf_interpreter = SWFInterpreter(data)
    assert swf_interpreter.file_data == data



# Generated at 2022-06-26 14:01:46.395687
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-26 14:01:48.039418
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    namespace_dict_0 = _ScopeDict(bool_0)



# Generated at 2022-06-26 14:01:55.686219
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    script = io.BytesIO(compat_bytes(
'''
\x63\x61\x6c\x6c\x65\x72\x20\x74\x65\x73\x74\x7b\x73\x74\x61\x74\x69\x63\x20\x76\x61\x72\x20\x75\x72\x6c\x20\x3d\x20\x22\x68\x74\x74\x70\x3a\x2f\x2f\x74\x65\x73\x74\x2e\x74\x78\x74\x22\x3b\x7d
'''.replace('\n', '')))
    interpreter = SWFInterpreter(script)
    interpreter.ext