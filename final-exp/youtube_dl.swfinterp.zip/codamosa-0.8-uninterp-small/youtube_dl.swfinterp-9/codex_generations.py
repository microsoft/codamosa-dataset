

# Generated at 2022-06-26 13:56:11.013247
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # extract_function method is tested in the function test_SWFInterpreter_run
    pass


# Generated at 2022-06-26 13:56:22.074713
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    m_0 = _Multiname(12)
    m_1 = _Multiname(0)
    m_2 = _Multiname(0)
    m_3 = _Multiname(3)
    m_4 = _Multiname(0)
    m_5 = _Multiname(0)
    m_6 = _Multiname(12)
    m_7 = _Multiname(0)
    m_8 = _Multiname(0)
    m_9 = _Multiname(3)
    m_10 = _Multiname(0)
    m_11 = _Multiname(0)
    m_12 = _Multiname(3)
    m_13 = _Multiname(3)
    m_14 = _Multiname(14)
    m_15

# Generated at 2022-06-26 13:56:26.388346
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # - test_case_0
    L = []
    L.append(undefined_0)
    # the expected result
    L_expect = [_Undefined()]
    assert test_case_0() == L_expect, 'test_case_0 failed!'



# Generated at 2022-06-26 13:56:31.708500
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swfdump = SWFDump()
    swfdump.add_file(test_case_0)

    si = SWFInterpreter()
    si.add_swf_dump(swfdump)

    methods = list(si.get_methods_by_name('undefined_0'))
    assert len(methods) == 1
    method = methods[0]

    func = si.extract_function(method[0], 'undefined_0')
    assert func([]) is undefined_0


# Generated at 2022-06-26 13:56:33.559386
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    avm = SWFInterpreter()
    avm.extract_function = MagicMock(side_effect=test_case_0)
    avm.extract_function()



# Generated at 2022-06-26 13:56:37.613451
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(
        filename='tests/swfs/FrameLabelTest.swf',
        set_vars=['_root', 'stage.width', 'stage.height'])
    swf.extract_class('FrameLabelTest')
    swf.extract_class('Stage')


# Generated at 2022-06-26 13:56:38.634333
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    s = SWFInterpreter()



# Generated at 2022-06-26 13:56:39.946614
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert SWFInterpreter(binary_data='')



# Generated at 2022-06-26 13:56:50.554427
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    class SWFInterpreter(object):
        def extract_function(self, avm_class, func_name):
            return avm_class.method_pyfunctions[func_name]
    from io import BytesIO
    class SWF(object):
        def __init__(self, data):
            self.data = data
        def read_constant(self, coder):
            assert coder.tell() == len(self.data)
    swf = SWF(b'')
    interp = SWFInterpreter(swf)
    class _AVMClass_Object(object):
        def __init__(self):
            self.method_pyfunctions = {'func_name': 'func_pyfunction'}
    assert interp.extract_function(_AVMClass_Object(), 'func_name')

# Generated at 2022-06-26 13:56:59.726121
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    global _SWFInterpreter_patch_function_all_functions

    global _SWFInterpreter_patch_function_call_pyfunc_count
    _SWFInterpreter_patch_function_call_pyfunc_count = 0
    if not hasattr(test_SWFInterpreter_patch_function, '_orig_call_pyfunc'):
        setattr(test_SWFInterpreter_patch_function, '_orig_call_pyfunc',
                SWFInterpreter._call_pyfunc)
    def _SWFInterpreter_patch_function_call_pyfunc(self, coder, frame_stack, scope, avm_class, func_name, args):
        global _SWFInterpreter_patch_function_all_functions
        global _SWFInterpreter_patch_function_

# Generated at 2022-06-26 13:57:55.520210
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    test_case_0()


# Generated at 2022-06-26 13:57:56.859452
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    str_0 = '?+'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)


# Generated at 2022-06-26 13:57:59.672823
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    str_0 = '?+'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    str_1 = '?+'
    class_0 = s_w_f_interpreter_0.extract_class(str_1)


# Generated at 2022-06-26 13:58:08.370825
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    test_case_0()

import os.path
import re
from .compat import (
    compat_urllib_request,
)
from .utils import (
    ExtractorError,
    float_or_none,
    int_or_none,
    url_basename,
)
from .swfdec import (
    avm2_ed,
    avm2_opcodes,
    avm2_vartypes,
    ed_abc,
    swfdec_amf,
)
from .aes import (
    aes_cbc_decrypt,
)
from .common import (
    InfoExtractor,
    SearchInfoExtractor,
)
from .ooyala import (
    OoyalaIE,
    OoyalaBaseIE,
)

# Generated at 2022-06-26 13:58:11.203816
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    str_0 = '?+'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    str_1 = '+'
    s_w_f_interpreter_0.patch_function(str_1)


# Generated at 2022-06-26 13:58:21.522140
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    str_0 = '?+<'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    str_1 = 'x'
    int_0 = 0
    int_1 = 0
    s_w_f_interpreter_0.extract_function(str_1, int_0, int_1)
    s_w_f_interpreter_0.extract_function(str_1, int_0, int_1)
    s_w_f_interpreter_0.extract_function(str_1, int_0, int_1)
    s_w_f_interpreter_0.extract_function(str_1, int_0, int_1)
    s_w_f_interpreter_0.extract_function

# Generated at 2022-06-26 13:58:22.771266
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_case_0()

# Generated at 2022-06-26 13:58:27.966659
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    str_0 = '?+'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    avm_class = s_w_f_interpreter_0.extract_class(0)
    assert avm_class.static_properties['length'] == 1
    assert avm_class.static_properties['toString']() == '3'


# Generated at 2022-06-26 13:58:31.691483
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    fname = 'str'
    s_w_f_interpreter_0 = SWFInterpreter(fname)
    body = '<body>'
    s_w_f_interpreter_0.patch_function(body)
    return


# Generated at 2022-06-26 13:58:34.222318
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    assert SWFInterpreter.patch_function('a') == 'a',\
        'SWFInterpreter.patch_function("a") returns a, not %s'\
        % SWFInterpreter.patch_function('a')


# Generated at 2022-06-26 14:01:35.890927
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    test_case_0()


# Generated at 2022-06-26 14:01:39.958013
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_str_0 = """
    0x00040000
    61552
    """
    swf_interpreter_0 = SWFInterpreter(swf_str_0)

    assert swf_interpreter_0.extract_class(0)
    assert swf_interpreter_0.extract_class(1)



# Generated at 2022-06-26 14:01:45.156769
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # t.expect_exception SwfParseError do
    #   SwfInterpreter.extract_class(nil)
    # end
    str_0 = '?+'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    s_w_f_interpreter_0.extract_class()
    # t.assert_nothing_raised do
    #   SwfInterpreter.extract_class('??')
    # end


# Generated at 2022-06-26 14:01:54.010038
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    str_0 = io.open('ressources/test_SWFInterpreter_patch_function.bin', 'r+b').read()
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    [res_str_0, res_str_1, res_str_2, res_str_3, res_str_4, res_str_5, res_str_6, res_str_7, res_str_8, res_str_9, res_str_10, res_str_11, res_str_12] = s_w_f_interpreter_0.patch_function('main')
    assert (res_str_0 == '?')
    assert (res_str_1 == '+')
    assert (res_str_2 == '????')

# Generated at 2022-06-26 14:01:56.120497
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    s_w_f_interpreter_0 = SWFInterpreter('?+')
    assert isinstance(s_w_f_interpreter_0, SWFInterpreter)



# Generated at 2022-06-26 14:02:06.603312
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf_interpreter = SWFInterpreter('%SWF%')

    # Unit test for method decrypt of class SWFInterpreter
    def test_SWFInterpreter_decrypt():
        str_0 = 'Y%\x90\x8c\x94'
        int_0 = len(str_0)
        int_1 = int_0 - 1
        int_2 = 0
        bytearray_0 = bytearray(1)
        while int_2 < int_0:
            int_3 = (int_2 + 1) % int_0
            int_4 = ord(str_0[int_2]) ^ int_1
            and_result_0 = int_4 & 1
            if and_result_0 == 0:
                int_5 = int_4 << 1
           

# Generated at 2022-06-26 14:02:07.789875
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_case_0()


# Generated at 2022-06-26 14:02:10.186570
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_interpreter = SWFInterpreter('/tmp/foo')
    swf_interpreter.extract_class('')

if __name__ == '__main__':
    test_SWFInterpreter_extract_class()

# Generated at 2022-06-26 14:02:15.806835
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_case_0()

if __name__ == '__main__':
    test_SWFInterpreter()

STRUCT_TYPES = {
    'lstring': 's',
    'c_string': 's',
    'uint16': 'H',
    'uint32': 'I',
    'int32': 'i',
    'uint8': 'B',
}

ENDIAN_CHAR = {
    '<': '<',
    '>': '>',
    '^': '@',
}


# Generated at 2022-06-26 14:02:16.710217
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_case_0()

