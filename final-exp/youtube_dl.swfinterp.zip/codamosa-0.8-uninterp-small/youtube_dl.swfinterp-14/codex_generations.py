

# Generated at 2022-06-26 13:56:42.507753
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    si = SWFInterpreter()
    si.extract_function(si.avm_class, 'test_case_0')


# Generated at 2022-06-26 13:56:45.430096
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    undefined_0 = _Undefined()
    var_0 = undefined_0.__hash__()
    var_1 = _AVMClass()
    var_2 = var_1.extract_class()


# Generated at 2022-06-26 13:56:50.955400
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    avm_classes = {
        'Class0': _AVMClass(super_classes=frozenset({'Object', 'Class0'})),
        'Object': _AVMClass(super_classes=frozenset({'Object'})),
    }
    expected = avm_classes['Object']
    actual = SWFInterpreter(avm_classes).extract_class(
        avm_classes['Class0'], 'Object')
    assert actual == expected


# Generated at 2022-06-26 13:56:56.166057
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    source_code = """
var_0 = undefined.__hash__()
return var_0
""".strip().split('\n')

    abcfile = ABCFile()
    avm_class = SWFInterpreter(abcfile)
    avm_class.setup_method(
        'method1', source_code, ['var_0'], 'int')
    res = avm_class.method1()
    assert res is None



# Generated at 2022-06-26 13:57:00.021583
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    t0 = SWFInterpreter()
    t1 = t0.extract_class(t0.abc_block[0], 0)
    assert isinstance(t1, _AVMClass)
    var_0 = t1.method_pyfunctions
    assert isinstance(var_0, dict)
    var_1 = t1.static_properties
    assert isinstance(var_1, dict)
    var_2 = t1.variable_names
    assert isinstance(var_2, list)
    var_3 = t1.class_id
    assert var_3 == 0


# Generated at 2022-06-26 13:57:10.200924
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-26 13:57:19.046423
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = io.BytesIO(compat_urllib_request.urlopen(
        'http://dev.tweepy.org/tweepy/raw/5df5e5f4b4ff4b8e9fc9d7e79bb2ab13bf7e8da4/tweepy/streaming.py').read())
    swf = swf.read(10)
    swf = io.BytesIO(swf)
    interpreter = _SWFInterpreter.from_swf(swf)


# Generated at 2022-06-26 13:57:23.108569
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    filename = 'tests/data/test.swf'

    with open(filename, 'rb') as swf_f:
        swf = swf_f.read()

    interpreter = SWFInterpreter(swf)
    interpreter.extract_function(interpreter.avm_classes['TestClass'], 'method_0')


# Generated at 2022-06-26 13:57:25.333453
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert SWFInterpreter(b'') is not None, 'Failed to create object'


# Generated at 2022-06-26 13:57:27.005960
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():

    assert test_case_0() == None


# Generated at 2022-06-26 13:58:28.574129
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    with open(get_test_data_file('test_case_0.swf'), 'rb') as f:
        swf = SWF(f)
        avm_class = AVMClass(swf)
        avm_class.file_version = 9

# Generated at 2022-06-26 13:58:34.658352
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    c = SWFInterpreter()

    # Test case SWFInterpreter::extract_class::cp_1
    # cp_1 tests whether a class with the identifier array can be extracted
    c.doabc[1].classes.append(ABCClass('Array', [], [], c.doabc[1].methods[0]))
    ArrayClass = c.extract_class('Array')
    assert ArrayClass.__name__ == 'Array'
    assert ArrayClass.method_names == [
        'pop', 'slice', 'join', 'reverse', 'push']


# Generated at 2022-06-26 13:58:46.676385
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():

    global undefined_0


# Generated at 2022-06-26 13:58:48.952643
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    assert 'undefined_0' in globals()
    assert isinstance(undefined_0, _Undefined)


# Generated at 2022-06-26 13:58:57.079633
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Create an instance of SWFInterpreter for testing
    module_SWFInterpreter = sys.modules[__name__]
    SWFInterpreter_class_object = module_SWFInterpreter.SWFInterpreter

    # Call method extract_class of SWFInterpreter on undefined_0
    res_SWFInterpreter_class_0 = SWFInterpreter_class_object.extract_class(undefined_0)

    # Verify that _AVMClass_Object was created
    assert res_SWFInterpreter_class_0.avm_class == None
    assert res_SWFInterpreter_class_0.avm_parent == undefined_0


# Generated at 2022-06-26 13:59:03.374561
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    c = _swfdata(b'\x46\x57\x53\x09\x00\x00\x00\x00')
    swf = swfdecompiler.SWF(c)
    s = SWFInterpreter(swf)
    assert s.major_version == 9
    assert s.minor_version == 0
    assert s.file_length == 0
    assert s.frame_size is None
    assert s.frame_rate == 0
    assert s.frame_count == 0
    assert s.tags == []
    assert s.constant_pool is None
    assert s.method_bodies == []


# Generated at 2022-06-26 13:59:07.329966
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swfinterpreter = SWFInterpreter()

if __name__ == '__main__':
    # Run all the tests for this class
    test_case_0()
    test_SWFInterpreter()

# Generated at 2022-06-26 13:59:10.665141
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Extract class from a sample SWF object
    test_case_0.swf_interpreter.extract_class(
        test_case_0.swf_interpreter.avm_classes[0],
        'SampleClass')


# Generated at 2022-06-26 13:59:18.714223
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():

    swfi = SWFInterpreter()
    method_pyfunctions = {}
    method_names = []
    method_names.append('patch_function')
    pyfunctions = []
    pyfunctions.append(SWFInterpreter.patch_function)
    swfi.method_pyfunctions = method_pyfunctions
    swfi.method_names = method_names
    swfi.pyfunctions = pyfunctions

    avm_class = _AVMClass()
    avm_class.method_pyfunctions = {'patch_function': test_case_0}
    avm_class.method_names = ['patch_function']
    avm_class.instance_pyfunctions = {'patch_function': test_case_0}
    avm_class.instance_names = ['patch_function']
   

# Generated at 2022-06-26 13:59:22.162102
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter()
    assert swf.constant_numbers == []
    assert swf.constant_strings == []
    assert swf.methods == {}
    assert swf.multinames == []
    assert swf.namespaces == []
    assert swf.classes == []



# Generated at 2022-06-26 14:00:29.659580
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from pyamf.remoting.gateway import AMFGateway

    s_w_f_interpreter_0 = SWFInterpreter('G@7*gBAR.=paq\\CSF(zx')
    s_w_f_interpreter_0.amf_data = {'version': 1, 'encrypted': True}
    s_w_f_interpreter_0.plugin = AMFGateway({})
    s_w_f_interpreter_0.patch_function()


# Generated at 2022-06-26 14:00:32.306402
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert 'G@7*gBAR.=paq\\CSF(zx' == SWFInterpreter('G@7*gBAR.=paq\\CSF(zx')._string_0



# Generated at 2022-06-26 14:00:36.032205
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    str_0 = 'G@7*gBAR.=paq\\CSF(zx'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)

    assert s_w_f_interpreter_0.abcDecompiler.abcStream == b'F(zx'


# Generated at 2022-06-26 14:00:37.179930
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # case0
    test_case_0()


# Generated at 2022-06-26 14:00:39.011538
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # TODO:
    #  * Implement it
    assert False


# Generated at 2022-06-26 14:00:39.980116
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    test_case_0()


# Generated at 2022-06-26 14:00:44.783271
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    str_0 = 'G@7*gBAR.=paq\\CSF(zx'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    str_1 = '<init>'
    s_w_f_interpreter_0.extract_function(None, str_1)


# Generated at 2022-06-26 14:00:46.758071
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_case_0()

###############################################################################


# Generated at 2022-06-26 14:00:55.924459
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    s_w_f_interpreter_0 = SWFInterpreter("G@7*gBAR.=paq\\CSF(zx")
    a_v_m_function_0 = s_w_f_interpreter_0.patch_function()
    m_name_0 = '_'
    s_w_f_interpreter_0.patch_function(m_name_0)
    m_name_0 = ''
    s_w_f_interpreter_0.patch_function(m_name_0)
    m_name_0 = '$'
    s_w_f_interpreter_0.patch_function(m_name_0)
    m_name_0 = 'A'

# Generated at 2022-06-26 14:01:02.517938
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # import string
    str_0 = 'Dmcmgvcgnb*9jqx+H[ZWQ2R=wTi'
    i_0 = SWFInterpreter(str_0)
    s_0 = '8V$fYBz]tV`An#T=k'
    arr_0 = bytearray(s_0)
    b_0 = bytes(arr_0)
    f_0 = i_0.extract_function(i_0.classes['Class_0'], 'Method_0', b_0)
    def f_1(args):
        return i_0.classes['Class_0'].method_pyfunctions['Method_0'](f_0, args)
    assert f_1([]) == None

# Generated at 2022-06-26 14:03:13.030139
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s_w_f_interpreter_1 = SWFInterpreter('G@7*gBAR.=paq\\CSF(zx')
    s_w_f_interpreter_1.extract_function(None, None)


# Generated at 2022-06-26 14:03:14.090810
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # Test Case #0
    test_case_0()



# Generated at 2022-06-26 14:03:21.481331
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    str_0 = '~>g+#^JhG=}@!5Q5'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    str_1 = 'km9X6b'
    int_0 = s_w_f_interpreter_0.patch_function(str_1, 'dX=s5!H')
    str_2 = 'o#%jaUN.dJ'
    int_1 = s_w_f_interpreter_0.patch_function(str_2, 'o*^0o}Z\\@+1')
    str_3 = '8s($M^`'

# Generated at 2022-06-26 14:03:24.435967
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    try:
        test_case_0()
        print('pass test_SWFInterpreter')
    except:
        print('fail test_SWFInterpreter')


# Generated at 2022-06-26 14:03:34.919964
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # Prints out a trace of the execution of the function
    def patched_avm2_interpreter(self, avm_class, func_name, func_body, registers, args, stack, scopes):
        print('-' * 80)
        for line in inspect.getsourcelines(func_body)[0]:
            if not line.startswith('#'):
                print(line.strip())
        print('-' * 80)

        # Continue with default opcode implementation
        res = self.avm2_interpreter(avm_class, func_name, func_body, registers, args, stack, scopes)
        return res

    swf_interpreter = SWFInterpreter('G@7*gBAR.=paq\\CSF(zx')
    swf_interpreter.avm2_inter

# Generated at 2022-06-26 14:03:44.215889
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-26 14:03:45.552596
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    test_case_0()


# Generated at 2022-06-26 14:03:52.093327
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert_equals(type(SWFInterpreter), type)
    assert_equals(SWFInterpreter.__bases__, (object,))
    assert_equals(SWFInterpreter.__module__, 'kxmovie.avm')
    swf_interpreter_0 = SWFInterpreter('q')
    assert_equals(type(swf_interpreter_0), SWFInterpreter)
    assert_equals(swf_interpreter_0.__class__, SWFInterpreter)


# Generated at 2022-06-26 14:03:56.405678
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    str_0 = 'G@7*gBAR.=paq\\CSF(zx'
    str_1 = '0A8081B;5'
    str_2 = 'G@7*gBAR.=paq\\CSF(zx'
    str_3 = '73B9C'
    str_4 = 'G@7*gBAR.=paq\\CSF(zx'
    str_5 = '1F'
    str_6 = 'G@7*gBAR.=paq\\CSF(zx'
    str_7 = '0BC1'
    str_8 = 'G@7*gBAR.=paq\\CSF(zx'
    str_9 = '1D8A1C'

# Generated at 2022-06-26 14:03:59.666009
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    str_0 = 'G@7*gBAR.=paq\\CSF(zx'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    s_w_f_interpreter_0.extract_class(str_1)
