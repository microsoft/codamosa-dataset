

# Generated at 2022-06-26 13:55:51.853721
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    def f(undefined_0):
        pass
    swf = SWFInterpreter(FakeExtractor())

# Generated at 2022-06-26 13:55:55.604912
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swftagdata import SWFTagData

    assert isinstance(SWFInterpreter(SWFTagData(b'')), SWFInterpreter)

    # Test that SWFInterpreter raises exception on invalid tag_data
    with pytest.raises(AssertionError):
        SWFInterpreter(b'')
        SWFInterpreter(5)



# Generated at 2022-06-26 13:56:02.907883
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter()
    assert len(interpreter.method_pyfunctions) == 0
    avm_class = _AVMClass('X')
    avm_class.static_properties['a'] = 3
    avm_class.static_properties['b'] = 4
    avm_class.make_object()

    # Building method body
    coder = compat_StringIO()
    _write_byte(coder, 0x24)  # pushbyte a
    _write_byte(coder, 0x24)  # pushbyte b
    _write_byte(coder, 0x2a)  # add
    _write_byte(coder, 0x2b)  # returnvalue

    interpreter.patch_function(avm_class, 'foo', coder)

    assert 'foo' in av

# Generated at 2022-06-26 13:56:15.071605
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    patch_function_0_closure_upvalues = (
        test_SWFInterpreter_patch_function,
        _AVMClass_Object,
        _ScopeDict,
        _SWFInterpreter,
        _builtin_classes,
        undefined,
        undefined_0,
    )
    def patch_function_0(arg_0):
        closure_upvalues = patch_function_0_closure_upvalues
        (test_SWFInterpreter_patch_function, _AVMClass_Object, _ScopeDict,
         _SWFInterpreter, _builtin_classes, undefined, undefined_0) = closure_upvalues

        # This is a "patch" function
        return undefined_0
    swf = _SWFInterpreter()

# Generated at 2022-06-26 13:56:25.809650
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-26 13:56:28.842986
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter()
    swf.extract_class('Dummy', {'name': 'Dummy'})
    assert swf.classes['Dummy'].name == 'Dummy'


# Generated at 2022-06-26 13:56:29.774153
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    f = SWFInterpreter()



# Generated at 2022-06-26 13:56:30.806836
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter()
    assert swf



# Generated at 2022-06-26 13:56:34.278283
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # assert_raises(NotImplementedError, SWFInterpreter(test_case_0).extract_function, ClassName('test_case_0'), 'undefined_0', None, None)
    SWFInterpreter(test_case_0).extract_function('test_case_0', 'undefined_0', None, None)


# Generated at 2022-06-26 13:56:44.660368
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # Loading AS3 code from some swf file
    swf=open('as3.swf','rb')
    swf_data = swf.read()
    swf.close()
    interpreter = SWFInterpreter(swf_data)
    # Checking method_names of class SWFInterpreter
    assert list(sorted(interpreter.method_names)) == [
        'avmplus', 'nextName', 'nextNameIndex', 'nextValue', 'send', 'sendAndLoad',
        'sendToURL', 'setUseE4X', 'toString']
    # Checking method SWFInterpreter.get_method_pyfunction()
    assert interpreter.get_method_pyfunction('SWFInterpreter', 'send') is not None
    # Checking method SWFInterpreter.extract_function()

# Generated at 2022-06-26 13:58:44.732558
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(
        BytesIO(compat_urllib_request.urlopen(
            'http://dev.universalsubtitles.org/static/unisubs_compiled.swf').read())
    )
    swf.extract_class('Config')


# Generated at 2022-06-26 13:58:47.040553
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    d = SWFInterpreter()
    d.method_pyfunctions = {}
    code = [0, -1, 60, 0]
    d.patch_function('test_case_0', code, [], [])
    assert isinstance(d.method_pyfunctions['test_case_0'](undefined_0), _Undefined)


# Generated at 2022-06-26 13:58:56.118019
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swfinterpreter = swftools.SWFInterpreter()
    assert isinstance(swfinterpreter, swftools.SWFInterpreter)
    assert swfinterpreter.abc_classes == {}
    assert swfinterpreter.abc_constant_pool == []
    assert swfinterpreter.abc_constant_strings == []
    assert swfinterpreter.abc_files == {}
    assert swfinterpreter.abc_multinames == []
    assert swfinterpreter.input_files == []
    assert swfinterpreter.output_file == None
    assert swfinterpreter.swf_classes == {}
    assert swfinterpreter.swf_files == {}


# Generated at 2022-06-26 13:58:59.404323
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    with open('assets/avm_class_1.swc', 'rb') as f:
        swc = SWCFile(f)

    swc_interpreter = SWCInterpreter(swc)
    swc_interpreter.extract_class('Script1')



# Generated at 2022-06-26 13:59:05.588856
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter(None)

    def f0(a):
        return a

    def f1(a, b):
        return a, b

    def f2(a, b, c=5):
        return a, b, c

    def f3(a, b, c=5, d=6):
        return a, b, c, d

    @interpreter.patch_function
    def f4(a, b, c, d=6, e=7):
        return a, b, c, d, e

    def f5(a, *args, **kwargs):
        return a, args, kwargs

    def f6(a, b=1, *args, **kwargs):
        return a, b, args, kwargs


# Generated at 2022-06-26 13:59:10.139682
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # We use a little test SWF
    with open(os.path.join(os.path.dirname(__file__),
                           'samples',
                           'test.swf'), 'rb') as f:
        swf_data = f.read()

    swf = SWF(BytesIO(swf_data))
    assert swf.file_header.signature == b'CWS'
    assert swf.file_header.version == 9
    assert swf.file_header.file_len == len(swf_data)
    assert swf.file_header.frame_size == RectangleRecord(
        0, 0, 3200, 2400, twips=True)
    assert swf.file_header.frame_rate == 30
    assert swf.file_header.frame_count == 1

    f

# Generated at 2022-06-26 13:59:16.935613
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Find a pre-compiled binary for the test case
    unittest_dir = os.path.dirname(sys._getframe(1).f_code.co_filename)
    test_case_dir = os.path.join(unittest_dir, 'test_case_0')
    swfdata = open(os.path.join(test_case_dir, 'test_case_0.swf'), 'rb').read()
    swf = SWFInterpreter(swfdata)
    swf.extract_class('undefined_0')
    assert isinstance(undefined_0, _AVMClass)


# Generated at 2022-06-26 13:59:20.349913
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    print('Testing SWFInterpreter.extract_function')
    undefined_0 = _Undefined()
    interpreter = SWFInterpreter()
    avm_class = _AVMClass('TestClass')
    interpreter.extract_function(avm_class, 'testMethod')
    assert avm_class.method_pyfunctions['testMethod'] == undefined_0


# Generated at 2022-06-26 13:59:27.338525
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import io
    import os
    import sys


# Generated at 2022-06-26 13:59:28.110146
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    pass


# Generated at 2022-06-26 14:00:24.586946
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # Put test code here...
    pass


# Generated at 2022-06-26 14:00:28.221767
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(Test___init__))
    runner = unittest.TextTestRunner()
    runner.run(suite)

# Unit test class for __init__

# Generated at 2022-06-26 14:00:36.892803
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf_interpreter_0 = SWFInterpreter(tuple_0)
    scopes_0 = []
    registers_0 = []
    locals_0 = []
    # TODO: test more opcodes
    coder_0 = io.BytesIO(b'\x41\x00\x00\x00\x01\x0a\x0b\x00\x00\x01\x0c\x0b\x00')
    func_0 = swf_interpreter_0.patch_function(
        a_v_m_class__object_0, 'func_0', 0, registers_0, locals_0, coder_0,
        scopes_0)
    res_0 = func_0(None)
    expected_0 = 11
    assert res_0 == expected_

# Generated at 2022-06-26 14:00:39.945693
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter()
    interpreter.extract_function(
        _AVMClass(dict(), dict(), None, None), 'dummy')


# Generated at 2022-06-26 14:00:41.434942
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    expected = _builtin_classes['Object']
    result = test_case_0()
    assert result == expected


# Generated at 2022-06-26 14:00:51.875267
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    creator = SWFInterpreter()
    avm_class = _AVMClass()
    method_name_index = 115
    def expected_result():
        stack = []
        scope = {}
        registers = [None, None, None, None]
        if len(stack) > 0:
            stack = []
        if len(registers) > 0:
            registers = []
        if len(scope) > 0:
            scope = {}
        avm_class_0 = _AVMClass()
        tuple_0 = ()
        a_v_m_class__object_0 = _AVMClass_Object(tuple_0)
        avm_class_0.make_object = lambda : a_v_m_class__object_0
        avm_class_0.method_names = set()
        avm_

# Generated at 2022-06-26 14:00:55.147825
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_interpreter_0 = SWFInterpreter()
    swf_interpreter_0.extract_class(None)
    swf_interpreter_0.extract_class(None)


# Generated at 2022-06-26 14:00:56.897745
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    filename = 'test_swf_interpreter'
    swf_interpreter_0 = SWFInterpreter(filename)


# Generated at 2022-06-26 14:01:03.260032
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    tuple_0 = ()
    a_v_m_class__object_0 = _AVMClass_Object(tuple_0)

    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}

# Generated at 2022-06-26 14:01:05.600236
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf_interpreter_0 = SWFInterpreter(tuple_0, tuple_0, str())
    swf_interpreter_0.extract_function(a_v_m_class__object_0, str())


# Generated at 2022-06-26 14:03:04.539881
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swfinterpreter__0 = SWFInterpreter()
    swfinterpreter__0.patch_function('test_case_0', test_case_0)
    swfinterpreter__0.call_function('test_case_0', [])

# Test for sample action scripts

# Generated at 2022-06-26 14:03:06.002179
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    main_0 = SWFInterpreter(None)


# Generated at 2022-06-26 14:03:14.426308
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-26 14:03:22.581309
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    with io.open('../demo.swf', 'rb') as f:
        swf = SWFInterpreter.parse_swf_file(f)

    swf.decode_all_scripts()

    args = dict()
    res = swf.extract_function(swf.avm_main, 'main')(args)


# Generated at 2022-06-26 14:03:32.985875
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    tuple_0 = ()
    a_v_m_class_0 = _AVMClass(tuple_0)
    a_v_m_class_0.method_names = ['method_0']
    code_0 = _ByteArray('ascii', '\x03\x09\x0A\x03\x01\x00\x02')
    coder_0 = _Coder(code_0)
    a_v_m_class_0.method_codes = {'method_0': coder_0}

# Generated at 2022-06-26 14:03:39.934642
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    int_0 = 0
    int_1 = 1
    int_5 = 5
    function_0 = Function(int_0)
    function_1 = Function(int_0)
    assert function_0.num_params == int_0
    assert function_1.num_params == int_0
    _swf_interpreter_0 = SWFInterpreter()
    _swf_interpreter_0.register_class(int_0, function_0)
    _swf_interpreter_0.register_class(int_1, function_1)
    _swf_interpreter_0.patch_function(int_0, int_5)
    assert function_0.num_params == int_5
    assert function_1.num_params == int_0


# Generated at 2022-06-26 14:03:44.284758
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    file_0 = open(os.path.join(os.path.dirname(__file__), 'sample-0.swf'), 'rb')
    swf_interpreter_0 = SWFInterpreter(file_0)
    file_0.close()

if __name__ == '__main__':
    test_case_0()
    test_SWFInterpreter()

# Generated at 2022-06-26 14:03:54.084656
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s = SWFInterpreter()
    test_case_0.__globals__ = {
        '_builtin_classes': s.builtin_classes,
        '_AVMClass_Object': s.classes['Object']
    }
    with io.BytesIO(b'\x0d') as _bytes_io:
        for _ in range(1):
            f = s.extract_function(s.classes['Object'], 'new')
            f()
            f = s.extract_function(s.classes['Object'], 'new')
            f()
            f = s.extract_function(s.classes['Object'], 'new')
            f()
            f = s.extract_function(s.classes['Object'], 'new')
            f()
            f = s.extract_function

# Generated at 2022-06-26 14:04:01.605344
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-26 14:04:08.424537
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    tuple_0 = ()
    a_v_m_class__object_0 = _AVMClass_Object(tuple_0)
    tuple_1 = ()
    a_v_m_class__object_1 = _AVMClass_Object(tuple_1)
    tuple_2 = ()
    a_v_m_class__object_2 = _AVMClass_Object(tuple_2)
    tuple_3 = ()
    a_v_m_class__object_3 = _AVMClass_Object(tuple_3)
    tuple_4 = (a_v_m_class__object_0, a_v_m_class__object_1, a_v_m_class__object_2, a_v_m_class__object_3)
    a_v_m_class_0 = _