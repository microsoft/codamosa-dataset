

# Generated at 2022-06-12 09:11:42.308780
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = App()

    @app.middleware
    def middleware1(request):
        return None

    @app.middleware('request')
    def request_middleware1(request):
        return None

    @app.middleware('response')
    def response_middleware1(request, response):
        return None

    @app.on_request
    def on_request(request):
        return None

    @app.on_response
    def on_response(request, response):
        return None


# Generated at 2022-06-12 09:11:51.954746
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.testing import HOST, PORT

    app = Sanic(__name__)

    @app.get('/middleware-test')
    async def middleware_test(request):
        return text('OK')

    @app.middleware('request')
    async def add_key_to_context(request):
        request['user_agent'] = 'Sanic'

    @app.on_request
    async def add_second_key_to_context(request):
        request['ip'] = '127.0.0.1'

    _, response = app.test_client.get(
        '/middleware-test',
        headers={
            'Host': HOST,
            'Connection': 'close',
            'Accept': '*/*'
        })

    assert response.status

# Generated at 2022-06-12 09:11:56.394076
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(self, *args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            print(middleware)

    TestMiddlewareMixin().on_request(lambda x: x)

# Generated at 2022-06-12 09:11:57.936665
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin().on_request == MiddlewareMixin().middleware


# Generated at 2022-06-12 09:12:08.429167
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    def test_middleware_1(request: Request):
        return HTTPResponse("test_middleware_1")

    @app.middleware("request")
    def test_middleware_2(request: Request):
        return HTTPResponse("test_middleware_2")

    @app.middleware("response")
    def test_middleware_3(request: Request):
        return HTTPResponse("test_middleware_3")

    @app.middleware("request", apply=False)
    def test_middleware_4(request: Request):
        return HTTPR

# Generated at 2022-06-12 09:12:14.651602
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    mock_response = "mock_response"
    future_middleware = FutureMiddleware("request", mock_response)
    mock_request = "mock_request"
    test_result = {}
    def test(request):
        test_result['test'] = "test"
        
    test_instance = MiddlewareMixin()
    test_instance._apply_middleware = test_result
    test_instance.on_request(mock_request)(test)
    assert test_result['test'] == "test"


# Generated at 2022-06-12 09:12:21.084163
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestClass(MiddlewareMixin):
        def __init__(self):
            super(TestClass, self).__init__()

        def _apply_middleware(self, middleware):
            pass

    t = TestClass()
    # Test when we pass a function for the middleware
    @t.on_response(middleware=None)
    def request_func(request):
        pass
    # Test when we just pass the middleware
    @t.on_response()
    def response_func(request, response):
        pass



# Generated at 2022-06-12 09:12:21.969364
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert MiddlewareMixin.middleware


# Generated at 2022-06-12 09:12:25.445810
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class FakeInherit_one(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []


# Generated at 2022-06-12 09:12:34.654479
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def print_on_request(request):
        print("Request middleware called")

    @app.middleware("response")
    async def print_on_response(request, response):
        print("Response middleware called")

    @app.route("/")
    async def handler(request):
        return json({"test": True})

    @app.listener("before_server_start")
    def before_start(app, loop):
        pass

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.json == {"test": True}


# Generated at 2022-06-12 09:12:39.349224
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    def middleware():
        print("I'm middleware!")
    app = Sanic()
    app.on_response(middleware)
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == 'response'

# Generated at 2022-06-12 09:12:40.789734
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    m = MiddlewareMixin()
    m.on_response(middleware=None)


# Generated at 2022-06-12 09:12:45.714334
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Test1(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            print("apply_middleware")

    test = Test1()
    def test_middleware(request, response):
        print("test_middleware")
    test.on_response(test_middleware)

# Generated at 2022-06-12 09:12:46.847398
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
  pass


# Generated at 2022-06-12 09:12:49.157778
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = MiddlewareMixin()
    assert callable(app.on_request())


# Generated at 2022-06-12 09:12:58.932794
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.response import text
    app = Sanic("test_middleware_on_request")

    @app.middleware("request")
    def request_middleware(request):
        """request middleware"""
        return request

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.text == "OK"

    @app.middleware("request")
    def request_middleware2(request):
        """request middleware"""
        return request

    request, response = app.test_client.get("/")
    assert response.text == "OK"

# Unit

# Generated at 2022-06-12 09:13:09.174353
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.server import HttpProtocol, StreamProtocol

    class FakeMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()

    verify_MiddlewareMixin_on_response = FakeMiddlewareMixin()

    class FakeClass:
        def __init__(self):
            super().__init__()

        def __call__(*args, **kwargs):
            raise NotImplementedError

    assert verify_MiddlewareMixin_on_response.on_request(
        FakeClass()
    ) == verify_MiddlewareMixin_on_response.on_request(
        FakeClass()
    )

# Generated at 2022-06-12 09:13:10.588196
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert callable(MiddlewareMixin().on_request())


# Generated at 2022-06-12 09:13:20.785176
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.exceptions import ServerError
    from sanic.models.futures import FutureMiddleware
    from sanic.response import text
    from sanic.server import Server
    server=Server(None, None, None, None, None, None, None, None, None, None)
    server_middleware=MiddlewareMixin()
    ret=server_middleware.on_response(middleware=None)
    assert ret()
    #assert server_middleware._future_middleware[0] is of class FutureMiddleware
    try:
        server._apply_middleware(FutureMiddleware(None, None))
    except ServerError:
        assert True
    else:
        assert False
    def middleware(request):
        return text("OK")
    ret=server_middleware.on_response(middleware=middleware)

# Generated at 2022-06-12 09:13:32.109751
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    @Sanic.middleware("request")
    def request_middleware(request):
        pass

    @Sanic().on_request
    def request_middleware(request):
        pass

    # Unit test for method on_response of class MiddlewareMixin
    def test_MiddlewareMixin_on_response():
        from sanic.app import Sanic

        @Sanic.middleware("response")
        def response_middleware(request, response):
            pass

        @Sanic().on_response
        def response_middleware(request, response):
            pass

        # Unit test for method middleware of class MiddlewareMixin
        def test_MiddlewareMixin_middleware():
            from sanic.app import Sanic


# Generated at 2022-06-12 09:13:41.398793
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    
    app = Sanic()
    @app.middleware
    def request_and_response(request, response):
        response.headers['test'] = 'middleware'
    
    request, response = app.test_client.get('/')
    assert response.headers['test'] == 'middleware'


# Generated at 2022-06-12 09:13:43.171778
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = MiddlewareMixin()
    assert app.on_request == partial(app.middleware, attach_to="request")

# Generated at 2022-06-12 09:13:47.678976
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    mixin = MiddlewareMixin(app)
    @mixin.middleware('response') 
    def f1(request):
        pass
    @mixin.middleware('request')
    async def f2(request):
        pass
    assert isinstance(f1, partial)
    assert isinstance(f2, partial)

# Generated at 2022-06-12 09:13:48.533798
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-12 09:13:57.108768
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    test = MiddlewareMixin()
    assert test._future_middleware == []

    @test.on_request
    def test_request(request):
        pass

    @test.on_response
    def test_response(request, response):
        pass

    assert len(test._future_middleware) == 2
    assert test._future_middleware[0].middleware == test_request
    assert test._future_middleware[0].attach_to == "request"
    assert test._future_middleware[1].middleware == test_response
    assert test._future_middleware[1].attach_to == "response"

# Generated at 2022-06-12 09:14:04.305215
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_on_request')

    @app.on_request()
    def request_middleware(request):
        request['foo'] = 'bar'

    @app.route('/')
    async def handler(request):
        assert request['foo'] == 'bar'
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'



# Generated at 2022-06-12 09:14:08.585664
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic("MiddlewareMixin_middleware")
    app.middleware("test")(print)
    assert all("test" in i.attach_to for i in app._future_middleware)

# Generated at 2022-06-12 09:14:16.189941
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        _future_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)
            print("application_middleware")

    test = TestMiddlewareMixin()
    @test.on_request
    def test_middleware(request):
        return request

    assert len(test._future_middleware) == 1
    assert test._future_middleware[0].middleware is test_middleware
    assert test._future_middleware[0].attach_to == "request"


# Generated at 2022-06-12 09:14:25.051604
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.middleware
    async def middleware(request: Request):
        print('middleware exe request')
    @app.on_request
    async def on_request(request: Request):
        print('on_request exe')
    assert len(app._future_middleware) == 2
    assert isinstance(app._future_middleware[0].middleware, partial)
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[0].middleware.func == on_request
    assert isinstance(app._future_middleware[1].middleware, partial)
    assert app._future_middleware[1].attach_to == 'request'
   

# Generated at 2022-06-12 09:14:28.965742
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Test:
        def __init__(self):
            self._future_middleware = []

        def _apply_middleware(self, middleware):
            return

    o = MiddlewareMixin()
    o.on_request(Test)

    assert o._future_middleware == []


# Generated at 2022-06-12 09:14:45.209455
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import sanic.app
    app = sanic.app.Sanic(__name__)

    def middleware(middleware_or_request):
        def register_middleware(middleware, attach_to="request"):
            future_middleware = FutureMiddleware(middleware, attach_to)
            return future_middleware
        return register_middleware(middleware_or_request, attach_to="request")

    assert isinstance(app.middleware, type(middleware))
    assert isinstance(app.middleware('request'), type(middleware))


# Generated at 2022-06-12 09:14:48.596176
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MidlewareMixin_middleware')

    @app.middleware('response')
    def test(request, response):
        pass

    assert app._future_middleware



# Generated at 2022-06-12 09:14:51.238720
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic(__name__)

    @app.middleware
    def middleware(request):
        pass

    assert len(app.request_middleware)  == 1

# Generated at 2022-06-12 09:14:52.647775
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    a=MiddlewareMixin()
    a.middleware(middleware_or_request, attach_to="request")

# Generated at 2022-06-12 09:14:57.430321
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError #noqa

    testMiddlewareMixin = TestMiddlewareMixin()
    assert testMiddlewareMixin.middleware('request')

# Generated at 2022-06-12 09:15:00.014458
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-12 09:15:09.424466
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """Unit test for method middleware of class MiddlewareMixin."""
    class Test(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.middleware_list = [
                "Middleware_1", "Middleware_2", "Middleware_3"
            ]
            self.middleware_hook_type = [
                "request", "request", "response"
            ]
            for i in range(3):
                self.middleware(self.middleware_list[i], self.middleware_hook_type[i])
            
    test = Test()


# Generated at 2022-06-12 09:15:14.920725
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    @MiddlewareMixin.middleware
    async def middleware(request: Request) -> Response:
        pass

    @MiddlewareMixin.middleware(attach_to='request')
    async def middleware(request: Request) -> Response:
        pass

    @MiddlewareMixin.middleware(attach_to='response')
    async def middleware(request: Request) -> Response:
        pass



# Generated at 2022-06-12 09:15:24.949107
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    def on_request(request):
        return request

    def on_response(request, response):
        return response

    app = Sanic("test_MiddlewareMixin_middleware")

    app.middleware(on_request, apply=False)
    app.middleware(on_response, attach_to="response", apply=False)

    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[1].middleware == on_response
    assert app._future_middleware[1].attach_to == "response"



# Generated at 2022-06-12 09:15:31.780831
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddle(MiddlewareMixin):
        def __init__(self,*args):
            super().__init__(args)

        def _apply_middleware(self,middleware):
            raise NotImplementedError

    test = TestMiddle()
    test.middleware('dummy middleware')
    assert len(test._future_middleware) == 1
    assert test._future_middleware[0].middleware == 'dummy middleware'
    assert test._future_middleware[0].attach_to == 'request'

# Generated at 2022-06-12 09:15:45.978398
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert False

# Generated at 2022-06-12 09:15:52.132820
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic(__name__)

    @app.middleware
    async def test_middleware(request):
        return text("This is a middleware")

    @app.route("/")
    async def index(request):
        return text("OK")

    response = app.test_client.get("/")
    assert response.text == "This is a middleware"



# Generated at 2022-06-12 09:15:56.519470
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # AssertionError: TypeError not raised
    class MiddlewareMixin1(MiddlewareMixin) :
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    middlewaremixin1 = MiddlewareMixin1()
    middlewaremixin1.middleware('request', apply=False)
    middlewaremixin1.on_request()
    middlewaremixin1.on_response()


# Generated at 2022-06-12 09:16:02.309430
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    from sanic.request import Request

    from sanic.response import HTTPResponse

    from sanic.views import CompositionView

    app = Sanic()

    # Intentionally skipped unit test part 1
    # Intentionally skipped unit test part 2
    # Unit test part 3
    def test_middleware_1(request):
        print("middleware 1 called")
        print("{} middleware 1 request".format(request))
        return request

    def test_middleware_2(request):
        print("middleware 2 called")
        print("{} middleware 2 request".format(request))
        return request

    async def test_middleware_async_1(request):
        print("async middleware 1 called")
        print("{} async middleware 1 request".format(request))

# Generated at 2022-06-12 09:16:09.463886
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()

    @MiddlewareMixin.middleware(app, attach_to='request')
    def middleware(request):
        return True

    assert isinstance(app._future_middleware, list)
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-12 09:16:18.665013
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.models import FutureMiddleware

    app = Sanic('sanic-swing-api')

    async def common_middleware(request):
        return request

    @app.middleware
    async def test_middleware(request):
        return request

    @app.middleware('request')
    async def test_request_middleware(request):
        return request

    @app.middleware('response')
    async def test_response_middleware(request, response):
        return response

    # Test if middleware has been added to the app
    assert len(app._future_middleware) == 4

    # Tests if middleware is in the right format
    assert isinstance(app._future_middleware[0], FutureMiddleware)

# Generated at 2022-06-12 09:16:25.108459
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixin_middleware_class(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware = middleware

    middleware_mixin = MiddlewareMixin_middleware_class()
    @middleware_mixin.middleware()
    def middleware():
        pass
    assert middleware is not None
    assert middleware_mixin.middleware
    assert middleware_mixin.middleware.middleware is middleware
    assert middleware_mixin.middleware.attach_to == 'request'


# Generated at 2022-06-12 09:16:29.864786
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    class __Test:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

    class Test(__Test, MiddlewareMixin):
        pass

    app = Sanic("Test")

    app.on_request(lambda x: x)

    assert len(app._future_middleware) == 1



# Generated at 2022-06-12 09:16:40.255360
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware

    app = Sanic()

    @app.middleware
    def mid1(request):
        pass

    @app.middleware('response')
    def mid2(request, response):
        pass

    assert app._future_middleware[0].middleware == mid1
    assert app._future_middleware[1].middleware == mid2

    # Define a mock middleware to avoid calling the target middleware
    class MockMiddleware:
        def __call__(self, *args, **kwargs):
            pass

    assert app._apply_middleware == Sanic._apply_middleware
    app._apply_middleware(FutureMiddleware(MockMiddleware, 'request'))

# Generated at 2022-06-12 09:16:49.704685
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic("test_MiddlewareMixin_middleware")
    assert MiddlewareMixin not in Sanic.__bases__
    app.__class__.__bases__ = (MiddlewareMixin,) + app.__class__.__bases__
    Sanic.__bases__ = MiddlewareMixin.__bases__ + Sanic.__bases__

    @app.middleware
    async def before_request(request):
        """Test middleware before_request"""
        pass

    @app.middleware
    async def after_request(request, response):
        """Test middleware after_request"""
        pass

    @app.middleware("request")
    async def before_request(request):
        """Test middleware before_request"""
        pass


# Generated at 2022-06-12 09:17:24.238259
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()

    # Try to register middleware function
    @app.middleware
    def example_middleware(req, resp):
        pass
    assert isinstance(app._future_middleware[0], FutureMiddleware)

    # Try to register middleware function for response
    @app.on_response
    def example_response_middleware(req, resp):
        pass
    assert isinstance(app._future_middleware[1], FutureMiddleware)

    # Try to register middleware function for request
    @app.on_request
    def example_request_middleware(req):
        pass
    assert isinstance(app._future_middleware[2], FutureMiddleware)



# Generated at 2022-06-12 09:17:33.015913
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    asyn = False
    app = Sanic(__name__)

    @app.middleware
    async def test_middleware1(request):
        """
        Apply middleware on request.
        """
        return json({"request":"request1"})

    @app.middleware('response')
    async def test_middleware2(request, response):
        """
        Apply middleware on response.
        """
        return json({"response":"response2"})
    
    @app.middleware('request')
    async def test_middleware3(request):
        """
        Apply middleware on request.
        """
        return json({"request":"request3"})


# Generated at 2022-06-12 09:17:41.258832
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.views import CompositionView
    from sanic.response import json
    from sanic.request import Request
    from sanic.router import Router
    from sanic.websocket import WebSocketProtocol

    sanic_implement = Sanic('test_MiddlewareMixin')
    sanic_implement.config.KEEP_ALIVE = False
    sanic_implement.config.KEEP_ALIVE_TIMEOUT = 5
    sanic_implement.router = Router()

    @sanic_implement.middleware('response')
    async def middleware_middleware(request, response):
        # request 和 response 都是 sanic 程式庫提供的
        if request.path == "/json":
            response.body

# Generated at 2022-06-12 09:17:47.794008
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """Unit test for method middleware of class MiddlewareMixin"""

    # tests if middleware works
    class MyClass(MiddlewareMixin):
        def __init__(self):
            super().__init__()

    def middleware(request):
        return

    my_class = MyClass()
    my_class.middleware(middleware)

    # tests if on_request works
    my_class.on_request(middleware)

    # tests if on_response works
    my_class.on_response(middleware)

# Generated at 2022-06-12 09:17:54.928425
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MyApp(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self._future_middleware = []

        def _apply_middleware(self, middleware):
            raise NotImplementedError

    # Test '@app.middleware'
    app = MyApp()
    @app.middleware
    def middleware_func_1():
        pass

    assert len(app._future_middleware) == 1

    # Test '@app.middleware('request')'
    app = MyApp()
    @app.middleware('request')
    def middleware_func_2():
        pass

    assert len(app._future_middleware) == 1



# Generated at 2022-06-12 09:17:55.697553
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-12 09:17:58.942783
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MockClassMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            self.name = "middleware"

        def _apply_middleware(self, middleware):
            super()._apply_middleware(middleware)

    mcm = MockClassMiddlewareMixin()
    mcm.middleware()
    mcm.on_request()
    mcm.on_response()

# Generated at 2022-06-12 09:18:07.878957
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app=Sanic()
    assert len(app._future_middleware)==0
    @app.middleware
    async def handler(request):
        pass
    assert len(app._future_middleware)==1
    assert app._future_middleware[0].middleware==handler
    assert app._future_middleware[0].attach_to=="request"
    @app.middleware("response")
    async def handler(request):
        pass
    assert app._future_middleware[1].middleware==handler
    assert app._future_middleware[1].attach_to=="response"
    @app.middleware("request")
    async def handler(request):
        pass
    assert app._future_middleware[2].middleware==handler

# Generated at 2022-06-12 09:18:08.682863
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # insert your test code here
    pass



# Generated at 2022-06-12 09:18:17.406595
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MockMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self.request_middlewares = []
            self.response_middlewares = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            if middleware.attach_to == "request":
                self.request_middlewares.append(middleware)
            elif middleware.attach_to == "response":
                self.response_middlewares.append(middleware)

    class MockMiddleware:
        def __init__(self):
            self.a = 1
            self.b = 2

    instance = MockMiddlewareMixin()
    middleware1 = MockMiddleware()

    instance.middleware(middleware1)

# Generated at 2022-06-12 09:19:16.234494
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    tmp = MiddlewareMixin(1, 2, 3)
    tmp.middleware(middleware_or_request=None, attach_to="request", apply=True)

# Generated at 2022-06-12 09:19:24.844819
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import Response
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol

    app = Sanic('test_MiddlewareMixin_middleware')
    app.middleware('request')(lambda x: x)
    app.middleware('response')(lambda x: x)

    async def get(request, *args, **kwargs):
        return text("OK")

    class SimpleView(HTTPMethodView):
        def get(self, request, *args, **kwargs):
            return text("OK")

    @app.route("/6")
    async def handler(request):
        return text("OK")


# Generated at 2022-06-12 09:19:31.960691
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class FakeMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    fake_middleware_mixin = FakeMiddlewareMixin()
    fake_middleware = lambda request, response: response

    fake_middleware_mixin.middleware(fake_middleware, 'request')
    assert len(fake_middleware_mixin._future_middleware) == 1
    assert isinstance(fake_middleware_mixin._future_middleware[0], FutureMiddleware)
    assert fake_middleware_mixin._future_middleware[0].attach_to == 'request'

    fake_middleware_mixin.middleware

# Generated at 2022-06-12 09:19:34.158071
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test(MiddlewareMixin):
        def _apply_middleware(self, *args, **kwargs):
            ...
    test = Test()
    test.middleware()

# Generated at 2022-06-12 09:19:40.175113
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.blueprints import Blueprint

    def middleware_function(request: Request):
        return HTTPResponse("Ok", status=200)

    app = Sanic()
    app.blueprint(Blueprint(name="blueprint_test"))
    app.middleware(middleware_function)
    app.blueprint(Blueprint(name="blueprint_test_2"))
    blueprint_test: Blueprint = app.blueprint(name="blueprint_test")
    blueprint_test.middleware(middleware_function)

    blueprint_test_2: Blueprint = app.blueprint(name="blueprint_test_2")
    blueprint_test

# Generated at 2022-06-12 09:19:48.477573
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def middleware1(request):
        request['middleware1'] = 1

    @app.middleware('request')
    def middleware2(request):
        request['middleware2'] = 2

    @app.middleware('response')
    def middleware3(request):
        request['middleware3'] = 3

    assert len(app._future_middleware) == 3
    assert all(
        isinstance(middleware, FutureMiddleware)
        for middleware in app._future_middleware
    )

# Generated at 2022-06-12 09:19:54.968503
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json

    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def hello(request):
        print('i am hello')
        return await request

    @app.route('/')
    async def test(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.json['test']
    assert response.status == 200

# Generated at 2022-06-12 09:20:04.120366
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic, response
    app = Sanic('test')
    app.config.REQUEST_MAX_SIZE = 0

    @app.middleware('request')
    def print_on_request(request):
        print('I print when a request is made')

    @app.middleware('response')
    def print_on_response(request, response):
        print('I print when a response is returned')
        return response

    @app.route('/')
    async def handler(request):
        return response.text('I remembered!')

    req, resp = app.test_client.get('/')

    assert resp.status == 200
    assert resp.text == 'I remembered!'

    assert len(app._future_middleware) == 2

# Generated at 2022-06-12 09:20:14.206145
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    request = Request("GET", "http://example.com/")
    response = Response("Example")
    app = Sanic("test_MiddlewareMixin_middleware")
    app.middleware("request")(lambda request: None)
    app.middleware("response")(lambda request, response: None)
    app.middleware("request")(lambda request: None)
    app.middleware("response")(lambda request, response: None)
    list_request_middlewares = app._future_middleware[:2]
    list_response_middlewares = app._future_middleware[2:]
    assert len(list_request_middlewares) == 2
    assert len(list_response_middlewares) == 2

# Generated at 2022-06-12 09:20:21.177404
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()

    @app.middleware
    async def hello_mw(request):
        print('hello!')

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].future_middleware == hello_mw
    assert app._future_middleware[0].attach_to == 'request'

