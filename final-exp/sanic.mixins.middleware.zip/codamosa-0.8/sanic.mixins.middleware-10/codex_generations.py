

# Generated at 2022-06-12 09:11:33.571000
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():

    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_on_response')

    @app.on_response()
    def test_MiddlewareMixin_on_response_middleware(request, response):
        return text('Pass')

    @app.get('/')
    async def test_MiddlewareMixin_on_response_handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.text == 'OK'

# Generated at 2022-06-12 09:11:34.330263
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass


# Generated at 2022-06-12 09:11:39.402494
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class derived_class(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass
    my_app = derived_class()
    @my_app.on_request()
    def my_on_request(request):
        pass
    for fut_middle in my_app._future_middleware:
        assert fut_middle._middleware.__name__ == "my_on_request"
        assert fut_middle._attach_to == "request"


# Generated at 2022-06-12 09:11:48.636680
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic_plugins.aiohttp_plugin.middleware import AiohttpPlugin
    
    app = Sanic()
    app.plugin(AiohttpPlugin(timeout=3))
    app.config.PLUGIN_CONFIG = {
        AiohttpPlugin.name: {
            "MIDDLEWARE_INIT_FUNC": {"param": 5}
        }
    }
    assert isinstance(app.middleware, MiddlewareMixin)
    assert app.middleware._future_middleware == []
    @app.middleware
    def middleware_one():
        pass
    @app.middleware('request')
    def middleware_two():
        pass
    @app.middleware('response')
    def middleware_three():
        pass

# Generated at 2022-06-12 09:11:53.245616
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Create a class inherited from MiddlewareMixin
    class C(MiddlewareMixin):
        pass

    c = C()
    assert c.on_request == partial(c.middleware, attach_to="request")
    assert c.on_request(lambda x:x) == c.middleware(lambda x:x, attach_to="request")

# Generated at 2022-06-12 09:11:57.537417
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    from sanic.app import Sanic
    from sanic.response import HTTPResponse

    async def m1(request):
        return HTTPResponse(status=200, text="m1")

    # test on_response
    app = Sanic()
    app.on_response(m1)
    assert(len(app._future_middleware) == 1)

    # test on_request
    app = Sanic()
    app.on_request(m1)
    assert(len(app._future_middleware) == 1)



# Generated at 2022-06-12 09:12:05.474927
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class MM(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
    app = MM()
    def on_response(request, response):
        response.text = "yolo"
    app.on_response(on_response)
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware_type == "response"


# Generated at 2022-06-12 09:12:09.198550
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic('test')

    @app.on_request
    def process1(request):
        print('OK')

    @app.middleware('request')
    def process2(request):
        print('OK')

    assert len(app._future_middleware) == 2



# Generated at 2022-06-12 09:12:11.159183
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic()

    @app.on_request
    async def test(request):
        return request

    assert app._future_middleware != []



# Generated at 2022-06-12 09:12:21.879282
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    if test_MiddlewareMixin_on_request.__doc__ is None:
        test_MiddlewareMixin_on_request.__doc__ = ""
    else:
        test_MiddlewareMixin_on_request.__doc__ += "\n"
    test_MiddlewareMixin_on_request.__doc__ += """Test for method on_request of class MiddlewareMixin."""
    test_MiddlewareMixin_on_request.__doc__ += "\n"
    test_MiddlewareMixin_on_request.__doc__ += "\n"
    test_MiddlewareMixin_on_request.__doc__ += "    Args:\n"
    test_MiddlewareMixin_on_request.__doc__ += "        middleware: Optional parameter to use for\n"
    test_MiddlewareMixin_on_request

# Generated at 2022-06-12 09:12:26.418148
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    obj=MiddlewareMixin()
    # Function call for obj.on_request()
    assert callable(obj.on_request())



# Generated at 2022-06-12 09:12:33.925061
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    my_app = MiddlewareMixin()
    print(type(my_app.middleware))
    print(type(my_app.middleware('response')))
    print(type(my_app.middleware(partial(MiddlewareMixin._apply_middleware, my_app))))
    print(type(my_app.middleware(MiddlewareMixin._apply_middleware, attach_to='request')))

    # print the class of object
    # print(type(my_app.middleware(print('hello world'))))


if __name__ == '__main__':
    test_MiddlewareMixin_middleware()

# Generated at 2022-06-12 09:12:42.324213
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    def test_middleware():
        pass
    app = Sanic()
    r = app.middleware(test_middleware)
    assert test_middleware == r
    app._apply_middleware = test_middleware
    r = app.middleware(test_middleware, attach_to='request')
    assert test_middleware == r
    app._apply_middleware = test_middleware
    r = app.middleware(test_middleware, attach_to='response')
    assert test_middleware == r
    app._apply_middleware = test_middleware
    r = app.middleware(attach_to='request')(test_middleware)
    assert test_middleware == r
    app._apply_middleware = test_middleware

# Generated at 2022-06-12 09:12:51.364910
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import pytest
    from parameterized import parameterized

    class MiddlewareMixinClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    @parameterized.expand([([],)])
    def test_on_request(self):
        fm = MiddlewareMixinClass()
        fm.on_request(lambda x: x)
        assert len(fm._future_middleware) == 1



# Generated at 2022-06-12 09:12:52.943243
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin().on_request()("request") == "request"

# Generated at 2022-06-12 09:13:01.105785
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    class MiddlewareMixin_:
        def __init__(self):
            self._future_middleware = []
        def _apply_middleware(self,middleware):
            pass
    obj = MiddlewareMixin_()
    obj.middleware = MiddlewareMixin.middleware.__get__(obj, MiddlewareMixin_)
    obj.on_request = MiddlewareMixin.on_request.__get__(obj, MiddlewareMixin_)
    obj.on_response = MiddlewareMixin.on_response.__get__(obj, MiddlewareMixin_)
    app = Sanic('sanic_server')
    @app.middleware('request')
    @app.middleware('response')
    async def test_middleware(request):
        print("inside the middleware")

# Generated at 2022-06-12 09:13:11.163199
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App:
        def __init__(self, *args, **kwargs):
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa


# Generated at 2022-06-12 09:13:21.251279
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class FakeApp(MiddlewareMixin):
        pass

    app = FakeApp()

    def _assert_middleware(middleware, attach_to, apply):
        assert isinstance(app._future_middleware[0], FutureMiddleware)
        assert app._future_middleware[0].middleware == middleware
        assert app._future_middleware[0].attach_to == attach_to
        assert app._future_middleware[0].applied == apply

    def middleware_A():
        pass

    def middleware_B():
        pass

    app.middleware(middleware_A)
    _assert_middleware(middleware_A, "request", True)

    app.middleware(middleware_B, "response")
    _assert_middleware(middleware_B, "response", True)

    app.middle

# Generated at 2022-06-12 09:13:22.043637
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass


# Generated at 2022-06-12 09:13:22.537018
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass

# Generated at 2022-06-12 09:13:27.777691
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass


# Generated at 2022-06-12 09:13:36.132882
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class A(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        async def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    a = A()
    a.on_request()
    a.on_request(lambda r,s: print(r,s))
    a.on_response()
    a.on_response(lambda r,s: print(r,s))
    assert True == True


# Generated at 2022-06-12 09:13:40.806428
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')
    test_middleware = lambda request, response: response
    app.middleware(test_middleware, attach_to="request")
    assert app._future_middleware[0].middleware == test_middleware


# Generated at 2022-06-12 09:13:48.906249
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    request = Mock()
    request.app = Mock()
    request.app.middleware = MiddlewareMixin()

    @request.app.middleware.on_request
    def request_handler(request):
        return request.app

    assert request_handler(request) == request.app

    request = Mock()
    request.app = Mock()
    request.app.middleware = MiddlewareMixin()

    @request.app.middleware.on_request()
    def request_handler(request):
        return request.app

    assert request_handler(request) == request.app

    request = Mock()
    request.app = Mock()
    request.app.middleware = MiddlewareMixin()

    foo = functools.partial(request_handler, request)
    foo.__wrapped__ = request_handler

    assert foo()

# Generated at 2022-06-12 09:13:53.359788
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Setup

    # Exercise
    expect_result = partial(MiddlewareMixin.middleware, attach_to='request')
    actual_result = MiddlewareMixin.on_request()

    # Verify
    assert expect_result == actual_result



# Generated at 2022-06-12 09:13:59.518391
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic()
    # Test case 1: middleware is None, attach_to is not None
    attach_to_1 = "request"
    app.on_request(attach_to=attach_to_1)
    # Test case 2: middleware is not None, attach_to is None
    def b_middleware(request):
        print("b_middleware")
    app.on_request(middleware=b_middleware)



# Generated at 2022-06-12 09:14:01.991283
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    _on_request = MiddlewareMixin.on_request
    # _on_request(middleware=None)
    def f1(request):
        return request
    _on_request(middleware=f1)



# Generated at 2022-06-12 09:14:05.325829
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    test_MiddlewareMixin = MiddlewareMixin()
    test_MiddlewareMixin.on_request()
    test_MiddlewareMixin.on_request(middleware='test')



# Generated at 2022-06-12 09:14:15.881134
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Arrange
    class stub_middleware(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self._future_middleware = []

        def _apply_middleware(self, future_middleware: FutureMiddleware):
            # Instead of applying middleware, assert the type of the object
            assert isinstance(future_middleware, FutureMiddleware)
            
    # Act:
    midd = stub_middleware()
    midd.on_request(on_request_is_a_middleware)

    # Assert:
    assert len(midd._future_middleware) == 1
    assert midd._future_middleware[0].middleware == on_request_is_a_middleware
    assert midd._future_middleware[0].attach_to == "request"


# Generated at 2022-06-12 09:14:18.769603
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestClass:
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test = TestClass()
    test.on_request(middleware=None)


# Generated at 2022-06-12 09:14:36.031932
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Build MiddlewareMixin
    middleware_mixin = MiddlewareMixin(None)
    middleware_mixin.middleware(None)
    assert len(middleware_mixin._future_middleware) == 1
    middleware_mixin.on_request(None)
    assert len(middleware_mixin._future_middleware) == 2
    middleware_mixin.on_response(None)
    assert len(middleware_mixin._future_middleware) == 3
    middleware_mixin.middleware(None, apply=False)
    middleware_mixin.on_request(None, apply=False)
    middleware_mixin.on_response(None, apply=False)
    assert len(middleware_mixin._future_middleware) == 6
    assert middleware_mixin._future_

# Generated at 2022-06-12 09:14:37.754682
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    def middleware(request):
        return request

    app = MiddlewareMixin()
    test = app.on_request(middleware)

    assert test == middleware


# Generated at 2022-06-12 09:14:43.180838
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.server import HttpProtocol

    async def async_middleware(request):
        pass

    app = HttpProtocol()
    assert not app._future_middleware

    app.middleware(async_middleware)
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == async_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-12 09:14:47.575731
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    @MiddlewareMixin.on_request()
    def test_on_request():
        return "hello_world"
    @MiddlewareMixin.on_response()
    def test_on_response():
        return "hello_world"
    assert test_on_request() == "hello_world"
    assert test_on_response() == "hello_world"

# Generated at 2022-06-12 09:14:55.453746
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.request import Request
    from sanic.response import HTTPResponse

    class MiddlewareMixin_on_request(MiddlewareMixin, Sanic):
        """
        This class performs unit test for method on_request of class MiddlewareMixin
        """

        def _apply_middleware(self, middleware):
            return middleware.run(Request(self, "GET", "/"))

    app = MiddlewareMixin_on_request()

    @app.route("/")
    def handler(request):
        return text("OK")


# Generated at 2022-06-12 09:14:56.005984
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass



# Generated at 2022-06-12 09:15:01.427395
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic('middleware-test')

    @app.middleware
    def middleware(request):
        print('ok')

    assert app._future_middleware[0].handler == middleware


# Generated at 2022-06-12 09:15:05.037049
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import sanic
    @sanic.app.middleware
    def simple_middleware(request):
        print('hello world')

    app = sanic.app.Sanic(__name__)
    app.on_request(simple_middleware)


# Generated at 2022-06-12 09:15:09.019020
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    app = Sanic('test_on_request')

    class HandleRequest:
        def __call__(self, request):
            return request

    @app.on_request(HandleRequest())
    async def test(request):
        pass

    assert len(app._future_middleware) == 1


# Generated at 2022-06-12 09:15:11.283708
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert callable(MiddlewareMixin().on_request(lambda x: x))
    assert callable(MiddlewareMixin().on_request())


# Generated at 2022-06-12 09:15:25.372926
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic("test_sanic")

    def middleware(request):
        return "Middleware"

    # Test the method on_request without request
    assert app.on_request() == partial(app.middleware, attach_to="request")

    # Test the method on_request with request
    app.on_request(middleware)
    assert app._future_middleware[0]._attach_to == "request"
    assert app._future_middleware[0]._middleware(None) == "Middleware"


# Generated at 2022-06-12 09:15:34.371211
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.router import Router

    class App(MiddlewareMixin):
        def __init__(self, router=None, request_class=None, loop=None):
            super(App, self).__init__(loop = loop)
            self.app = self
            self.router = router or Router()
            
    @App.middleware
    async def middleware_1(request):
        return request
    
    @App.middleware
    async def middleware_2(request):
        return request
    
    app = App()
    assert app._future_middleware[0].middleware is middleware_1
    assert app._future_middleware[1].middleware is middleware_2


# Generated at 2022-06-12 09:15:36.433880
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    @MiddlewareMixin.on_request()
    def middleware(request):
        return request

    assert MiddlewareMixin.middleware.__name__ == "register_middleware"


# Generated at 2022-06-12 09:15:38.630254
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin.on_request.__name__ == "on_request"
    assert callable(MiddlewareMixin.on_request)


# Generated at 2022-06-12 09:15:40.206573
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin.on_request(MiddlewareMixin, None) != None


# Generated at 2022-06-12 09:15:43.224908
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic()
    @app.on_request
    def testMiddleware(req):
        print("OK")
    

# Generated at 2022-06-12 09:15:52.563198
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Create a new object of class MiddlewareMixin
    mwMixin = MiddlewareMixin()
    assert(mwMixin._future_middleware == [])
    # Unit test for method on_request of class MiddlewareMixin
    def test_middleware(request):
        return request
    # Add the middleware test_middleware as request middleware 
    mwMixin.on_request(test_middleware)
    assert (len(mwMixin._future_middleware) == 1)
    assert (mwMixin._future_middleware[0].middleware == test_middleware)
    assert (mwMixin._future_middleware[0].attach_to == "request")


# Generated at 2022-06-12 09:15:59.592554
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware

    app = Sanic()

    app.middleware(middleware=3)

    assert len(app._future_middleware)==1
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].middleware==3
    assert (app._future_middleware[0].attach_to=="request")
    assert app._future_middleware[0].is_applied==False

    app.middleware("response", attach_to=middleware_or_request)
    assert len(app._future_middleware)==2
    assert isinstance(app._future_middleware[1], FutureMiddleware)

# Generated at 2022-06-12 09:16:05.660028
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic(__name__)
    # Comment out following line to be tested
    # return app.middleware(middleware_or_request, attach_to="request")
    # Comment out following line to be tested
    # return partial(register_middleware, attach_to=middleware_or_request)

    # Replace the following code with your test code
    code = print(app.on_request)
    assert True == __is_sample_code(code)


# Generated at 2022-06-12 09:16:10.790465
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Create an instance of class MiddlewareMixin
    middleware_mixin = MiddlewareMixin()

    # Call method middleware of class MiddlewareMixin
    middleware = middleware_mixin.middleware("request")

    # Check if the value of property _future_middleware in instance middleware_mixin is an instance of list
    assert isinstance(middleware_mixin._future_middleware, list)