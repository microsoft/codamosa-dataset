

# Generated at 2022-06-12 09:11:32.368664
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert True

# Generated at 2022-06-12 09:11:35.270461
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    class App(MiddlewareMixin):
        pass

    app = App()

    @app.on_request()
    def m1(request):
        pass

    @app.on_request(apply=False)
    def m2(request):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == m1
    assert app._future_middleware[1].middleware == m2

# Generated at 2022-06-12 09:11:42.109563
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A:
        def __init__(self):
            self._future_middleware = []

    MiddlewareMixin.__bases__ = (A,)
    m = MiddlewareMixin()
    assert m._future_middleware == []
    m.middleware(middleware_or_request=lambda: 1)
    assert m._future_middleware != []
    m.middleware(middleware_or_request=lambda: 1, attach_to="request")
    assert m._future_middleware != []
    m.middleware(middleware_or_request=lambda: 1, apply=True)
    assert m._future_middleware != []
    m.middleware(lambda: 1, attach_to="request", apply=True)
    assert m._future_middleware != []


# Generated at 2022-06-12 09:11:48.352408
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    """
    Tests the on_response method of MiddlewareMixin class
    """
    assert MiddlewareMixin.on_response.__name__ == "on_response"
    assert MiddlewareMixin.on_response.__doc__ == (
        "Decorate and register middleware to be called after a response.\n"
        "Can either be called as *@app.on_response* or\n"
        "*@app.on_response('response')*"
    )

# Generated at 2022-06-12 09:11:49.837966
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:11:58.315730
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.response import text

    class App(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

            self.handle_request = lambda request: text("application")

        def _apply_middleware(self, middleware):
            middleware.result = lambda request: text("middleware")

    app = App()

    # return the registered middleware without attaching to the app
    @app.middleware(attach_to="request", apply=False)
    def middleware(request):
        return text("middleware")

    # return the registered middleware while attaching to the app
    @app.middleware(attach_to="request", apply=True)
    def apply_middleware(request):
        return text("middleware")

    # send a

# Generated at 2022-06-12 09:12:01.313626
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    test_obj = MiddlewareMixin()
    test_obj.on_response(None)


# Generated at 2022-06-12 09:12:02.598902
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Given: no instance
    # When:
    # Then:
    print('test')

# Generated at 2022-06-12 09:12:09.186513
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    # Create an instance of class Sanic, which is inherited from
    # class MiddlewareMixin
    app = Sanic()
    # Decorate the handle_request method of class Sanic with the partial
    # object returned by the on_response method of class Sanic
    @app.on_response
    def handle_request(request, response):
        print("I process the response")
        return response
    # Call ugettext in the handle_request method
    # As a result, the handle_request method should be executed
    app.handle_request("request", "response")

# Generated at 2022-06-12 09:12:16.634532
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import unittest
    import types

    class testClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    k = testClass()

    result = k.on_response()
    assert isinstance(result, types.PartialType)

    result = k.on_response(lambda x: 1)
    assert isinstance(result, types.FunctionType)

    result = k.on_response(3)
    assert isinstance(result, types.PartialType)



# Generated at 2022-06-12 09:12:22.971776
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-12 09:12:26.224596
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_sanic_MiddlewareMixin_on_response')
    MiddlewareMixin.on_response(app)
    return app

# Generated at 2022-06-12 09:12:32.835883
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    m = MiddlewareMixin()
    assert callable(m.on_response())
    assert callable(m.on_response(None))
    assert callable(m.on_response(1))
    assert callable(m.on_response("a"))
    assert callable(m.on_response(1.0))
    assert callable(m.on_response([]))
    assert callable(m.on_response(()))
    assert callable(m.on_response({}))


# Generated at 2022-06-12 09:12:37.541188
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class FakeMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def on_request(self, middleware=None):
            pass

        def on_response(self, middleware=None):
            pass

        def _apply_middleware(self, middleware):
            pass

    m = FakeMiddlewareMixin()
    assert callable(m.on_response())
    assert callable(m.on_response(lambda x: x))

# Generated at 2022-06-12 09:12:40.680163
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin = MiddlewareMixin()
    response_middleware = middleware_mixin.on_response()

    assert response_middleware.args == tuple()
    assert response_middleware.keywords == {'attach_to': 'response'}
    assert response_middleware.func == func



# Generated at 2022-06-12 09:12:52.405233
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import unittest
    import twint

    class test_MiddlewareMixin(unittest.TestCase, MiddlewareMixin):

        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass


# Generated at 2022-06-12 09:13:00.690761
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware

    future_middleware: List[FutureMiddleware] = []
    app = Sanic("test")
    app._future_middleware = future_middleware
    app._apply_middleware = lambda m : future_middleware.append(m)
    app.config.middleware = []
    app.middleware = Sanic.middleware
    app.on_response = MiddlewareMixin.on_response

    @app.on_response
    def test(request, response):
        pass

    assert len(app.config.middleware) == 1
    assert future_middleware[0].middleware == test
    assert future_middleware[0].attach_to == "response"


# Generated at 2022-06-12 09:13:10.800999
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    print()
    print(inspect.getframeinfo(inspect.currentframe()).function)
    # on_request() calls both MiddlewareMixin.on_request() and
    # MiddlewareMixin.on_response()
    from sanic.utils import sanic_endpoint_test
    from sanic import Sanic
    app = Sanic('test_on_response')

    # Testing the function decorator
    @app.on_response
    async def handler_response(request, response):
        return response

    # Testing the async partial
    @app.on_response()
    async def handler_response2(request, response):
        return response

    @app.route('/')
    async def handler(request):
        return response.text('OK')

    request, response = sanic_endpoint_test(app)




# Generated at 2022-06-12 09:13:14.283870
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_on_response')

    def a(request):
        return request

    app.on_response(a)
    assert a in app.request_middleware



# Generated at 2022-06-12 09:13:17.287924
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Create an instance of class MiddlewareMixin
    middlewareMixin = MiddlewareMixin()
    assert middlewareMixin.on_response() == partial(middlewareMixin.middleware, attach_to="response")

# Generated at 2022-06-12 09:13:24.242675
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m = MiddlewareMixin()
    class TestMiddleware: pass
    ret = m.middleware(TestMiddleware, 'request')
    assert len(m._future_middleware) == 1
    assert ret == TestMiddleware


# Generated at 2022-06-12 09:13:28.281724
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Class(MiddlewareMixin):
        pass
    obj = Class()
    assert not obj._future_middleware
    obj.middleware(lambda s: None)
    assert len(obj._future_middleware) == 1

# Generated at 2022-06-12 09:13:34.553910
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic import response
    from sanic.request import Request

    app = Sanic(__name__)

    @app.middleware
    async def print_on_request(request):
        print("I print when a request is made")

    @app.middleware('request')
    async def halt_request(request):
        return response.json({"test": True}, status=200)

# Generated at 2022-06-12 09:13:36.035718
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # TODO: make test for this
    pass


# Generated at 2022-06-12 09:13:36.637613
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert True

# Generated at 2022-06-12 09:13:38.353203
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m = MiddlewareMixin()
    m.middleware = ""
    assert m._future_middleware == []

# Generated at 2022-06-12 09:13:45.325643
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    try:
        MiddlewareMixin._apply_middleware("No_Implement")
    except NotImplementedError:
        pass

    assert MiddlewareMixin.middleware("")("")

    @MiddlewareMixin.middleware("")
    def test_callback():
        return True

    assert hasattr(test_callback, "__call__")

    assert MiddlewareMixin.on_request("")("")
    assert MiddlewareMixin.on_response("")("")
    assert MiddlewareMixin._future_middleware == []

# Generated at 2022-06-12 09:13:52.745893
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic(__name__)

    @app.middleware
    async def middleware_request(request):
        print('before request')
        response = await handler(request)
        print('after request')
        return response

    async def handler(request):
        return text('Hello world!')

# Conclusion: The function middleware can be used to add middleware, but it will not be helpful for decorators. According to the guide, middleware is very useful for decorators.
    # app.middleware('request')(middleware_request)

# Generated at 2022-06-12 09:13:57.789782
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m1 = MagicMock()

    class M(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    m = M()
    m.middleware(m1)

    assert len(m._future_middleware) == 1
    assert m._future_middleware[0].middleware is m1



# Generated at 2022-06-12 09:14:01.669458
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    dummy_middleware = lambda x, y: None

    class DummyClass(MiddlewareMixin):
        pass

    dummy = DummyClass()
    dummy.middleware(dummy_middleware)
    assert len(dummy._future_middleware) == 1

# Generated at 2022-06-12 09:14:07.529763
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert True

# Generated at 2022-06-12 09:14:15.919213
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    #from sanic import middleware
    from sanic.request import Request
    from sanic.response import HTTPResponse
    import asyncio
    app = Sanic('test_request')
    async def handler(request):
        return request
    @app.middleware
    async def process_response(request):
        request.response.headers["Processed"] = "OK"
    app.add_route(handler, '/info/')
    request, response = app.test_client.get('/info/')
    assert response.headers['Processed'] == 'OK'
    



# Generated at 2022-06-12 09:14:21.395935
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # class Test(MiddlewareMixin):
    #     def _apply_middleware(self, middleware: FutureMiddleware):
    #         print(middleware)
    #     def __init__(self, *args, **kwargs):
    #         super().__init__(*args, **kwargs)
    # test = Test()
    # mw = test.middleware()
    # mw()
    pass

# Generated at 2022-06-12 09:14:21.987656
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert 1 == 1

# Generated at 2022-06-12 09:14:31.293856
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m = MiddlewareMixin()
    assert m._future_middleware == []

    @m.middleware
    def middleware_mock_1(request):
        return request
    @m.middleware('request')
    def middleware_mock_2(request):
        return request
    @m.middleware('response')
    def middleware_mock_3(request):
        return request

    assert len(m._future_middleware) == 3
    assert m._future_middleware[0].middleware_func == middleware_mock_1
    assert m._future_middleware[0].attach_to == "request"
    assert m._future_middleware[1].middleware_func == middleware_mock_2
    assert m._future_middleware[1].attach_to == "request"
   

# Generated at 2022-06-12 09:14:40.521001
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.exceptions import ServerError
    from sanic.models.middleware import Middleware
    from sanic.types import RequestParameters, Sanic, ResponseParameters
    from sanic.types import Server
    import pytest

    test_app = Sanic("test_app")

    TestMiddleware = Middleware
    TestMiddleware.__abstractmethods__ = set()


# Generated at 2022-06-12 09:14:43.221107
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic()

    async def test_middleware(request):
        return

    app.middleware(test_middleware, "request")

    result = app._future_middleware[0].middleware

    assert(result == test_middleware)


# Generated at 2022-06-12 09:14:51.794634
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic(__name__)

    @app.middleware('request')
    async def test(request):
        pass

    assert len(app._future_middleware) == 1
    middleware_one = app._future_middleware[0]
    assert middleware_one.middleware == test
    assert middleware_one.attach_to == 'request'

    @app.middleware
    async def test_2(request):
        pass

    assert len(app._future_middleware) == 2
    middleware_two = app._future_middleware[1]
    assert middleware_two.middleware == test_2
    assert middleware_two.attach_to == 'request'


# Generated at 2022-06-12 09:14:52.332254
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert True

# Generated at 2022-06-12 09:15:03.961876
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestClass(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware) -> None:
            pass

    test_class = TestClass()

    @test_class.middleware()
    def middleware1(request):
        """middleware1"""
        pass

    @test_class.middleware(attach_to='response')
    def middleware2(request):
        """middleware2"""
        pass

    assert test_class._future_middleware[0].middleware == middleware1
    assert test_class._future_middleware[0].attach_to == 'request'
    assert test_class._future_middleware[0].middleware.__name__ == 'middleware1'

# Generated at 2022-06-12 09:15:14.410780
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:15:15.018983
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:15:22.356578
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """Unit Test for MiddlewareMixin.middleware(middleware_or_request, attach_to="request", apply=True)"""
    from sanic.app import Sanic

    sanic_app = Sanic('test_MiddlewareMixin_middleware')
    assert isinstance(sanic_app, MiddlewareMixin)

    @sanic_app.middleware
    def test_middleware():
        return "middleware"

    assert sanic_app._future_middleware[0].middleware() == "middleware"


# Generated at 2022-06-12 09:15:28.704504
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    class MyMiddleWare(MiddlewareMixin):
        pass

    app = MyMiddleWare(__name__)

    class TestMiddleware:
        pass

    middleware = app.middleware(TestMiddleware, attach_to='request')
    assert isinstance(middleware, TestMiddleware)

    middleware = app.middleware(attach_to='request')
    assert callable(middleware)
    assert middleware.keywords['attach_to'] == 'request'



# Generated at 2022-06-12 09:15:34.636003
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixinObj(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self._request_middleware = []
            self._response_middleware = []
            self._future_middleware = []

        def _apply_middleware(self, future_middleware):
            if future_middleware.attach_to == 'request':
                self._request_middleware.append(future_middleware.middleware)
            elif future_middleware.attach_to == 'response':
                self._response_middleware.append(future_middleware.middleware)
            else:
                raise NotImplementedError

    obj = MiddlewareMixinObj()

    def req():
        pass
    def res():
        pass


# Generated at 2022-06-12 09:15:41.347720
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():# -*- coding: utf-8 -*-
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        pass

    @app.middleware('response')
    async def response_middleware(request, response):
        pass

    @app.middleware
    async def response_or_request(request, response=None):
        if response:
            pass

    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[0].attach_to == 'request'

    assert app._future_middleware[1].middleware == response_middleware
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-12 09:15:50.635626
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    @MiddlewareMixin.middleware('request')
    # must be a callable with one parameter
    def request_middleware(request):
        pass

    @MiddlewareMixin.middleware('response')
    # must be a callable with two parameters
    def response_middleware(request, response):
        pass
    
    # test that can not be called as an instance method
    @MiddlewareMixin.on_request
    # must be a callable with one parameter
    def request_middleware(request):
        pass

    @MiddlewareMixin.on_response
    # must be a callable with two parameters
    def response_middleware(request, response):
        pass

# Generated at 2022-06-12 09:15:57.128627
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic('middleware_test')
        
    @app.middleware
    async def m1(request):
        pass

    @app.middleware('request')
    async def m2(request):
        pass

    @app.middleware('response')
    async def m3(request, response):
        pass
    
    @app.route('/middleware')
    async def handler(request):
        return text('OK')
    client = app.test_client
    request, response = client.get('/middleware')
    assert response.status == 200
    

# Generated at 2022-06-12 09:16:00.058182
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert hasattr(MiddlewareMixin, "middleware")
    assert callable(MiddlewareMixin.middleware)
    assert hasattr(MiddlewareMixin, "_apply_middleware")
    assert callable(MiddlewareMixin._apply_middleware)


# Generated at 2022-06-12 09:16:08.227998
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic(__name__)

    app.middleware(None)
    app.on_request(None)
    app.on_response(None)
    app.middleware(None, True)
    app.on_request(None, True)
    app.on_response(None, True)

    assert app._future_middleware is not None
    assert app._future_middleware == []
    assert callable(app.middleware)
    assert callable(app.on_request)
    assert callable(app.on_response)


# Generated at 2022-06-12 09:16:40.607158
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.sanic import Sanic

    async def middleware(request):
        return request
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            print("applying middleware")

    app = Sanic("test_MiddlewareMixin_middleware")
    app.add_task(None)
    app.request_middleware = []
    app.response_middleware = []
    TestMiddlewareMixin._future_middleware = []
    TestMiddlewareMixin._future_middleware.append(middleware)
    TestMiddlewareMixin._apply_middleware(middleware)
    TestMiddlewareMixin.middleware(middleware, "response")
    TestMiddleware

# Generated at 2022-06-12 09:16:50.051931
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_obj = TestMiddlewareMixin()
    # case1:
    # test_middleware = lambda request: request
    # test_obj.middleware(test_middleware, "request", True)
    # assert test_obj._future_middleware[0] == FutureMiddleware(test_middleware, "request")

    # case2:
    test_middleware = lambda request: request
    test_obj.middleware(test_middleware)("request")
    assert test_obj._future_middleware[1] == FutureMiddleware(test_middleware, "request")

    # case3:
    test

# Generated at 2022-06-12 09:16:56.412073
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MyApp(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    #test1
    @MyApp.middleware('request')
    def middleware(request):
        pass
    assert len(MyApp._future_middleware) == 1
    #test2
    my_app = MyApp()
    @my_app.middleware('request')
    def middleware(request):
        pass
    assert len(my_app._future_middleware) == 2

    #test3
    my_app = MyApp()
    assert my_app._future_middleware == []

# Generated at 2022-06-12 09:17:05.032505
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Arrange
    from sanic.exceptions import NotFound
    from sanic.models.dictionary import Dictionary

    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()

            self.test_field = 'test_field'

        def _apply_middleware(self, middleware: FutureMiddleware) -> None:
            raise NotFound(self.test_field)

    # Action & Assert
    with pytest.raises(NotFound) as err:
        test_middleware = TestMiddlewareMixin()
        setattr(test_middleware, 'test_field', 'test_field')

        test_middleware.middleware(
            Dictionary({'a': 1, 'b': 2}), attach_to="request", apply=True)


# Generated at 2022-06-12 09:17:13.098126
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.models.sanic_model import SanicModel
    from sanic.models.futures import FutureMiddleware
    from sanic.response import HTTPResponse
    from sanic.request import Request

    app = Sanic()

    class DemoApp(SanicModel, MiddlewareMixin):
        # Test middleware in class SanicModel and MiddlewareMixin
        pass

    @app.middleware("request")
    async def request_middleware(request):
        request["test"] = "test"

    middleware = DemoApp().middleware(request_middleware, attach_to="request")
    assert(isinstance(middleware, FutureMiddleware))
    assert(middleware.attach_to == "request")


# Generated at 2022-06-12 09:17:20.875817
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    @app.middleware
    async def handler(request):
        return request
    @app.middleware("response")
    async def response(request, response):
        return response

    assert app.on_request == app.middleware("request")
    assert app.on_response == app.middleware("response")
    
    assert handler == app._future_middleware[0].factory
    assert "request" == app._future_middleware[0].attach_to
    assert response == app._future_middleware[1].factory
    assert "response" == app._future_middleware[1].attach_to

# Generated at 2022-06-12 09:17:26.372638
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.testing import SanicTestClient

    app = Sanic("test_sanic")

    async def handler(request):
        return HTTPResponse(b"OK")

    @app.route("/middleware")
    @app.middleware("request")
    async def handler(request):
        return HTTPResponse(b"OK")

    client = SanicTestClient(app)
    request, response = client.get("/middleware")

    assert response.text == "OK"

# Generated at 2022-06-12 09:17:34.446021
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    _middleware     = MiddlewareMixin()
    _middleware._apply_middleware = lambda x: x

    @_middleware.middleware
    async def _inner_middleware(request):
        return request
    assert _inner_middleware.__name__ == '_inner_middleware'

    _sanic = Sanic('test_sanic_MiddlewareMixin_middleware')
    _sanic.listeners['before_server_start'].append(
        _middleware._run_middleware
    )

    _sanic.listeners['before_server_stop'].append(
        _middleware._end_middleware
    )

    _sanic.middleware(_inner_middleware)

    assert _middleware._future_middleware
    

# Generated at 2022-06-12 09:17:41.496150
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    test = Sanic()
    func = lambda f: True
    test.middleware(func)
    assert test._future_middleware[0].middleware == func
    assert test._future_middleware[0].attach_to == "request"
    test.middleware(func, "response")
    assert test._future_middleware[1].middleware == func
    assert test._future_middleware[1].attach_to == "response"
    test.middleware(func, "exception")
    assert test._future_middleware[2].middleware == func
    assert test._future_middleware[2].attach_to == "exception"


# Generated at 2022-06-12 09:17:47.791811
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixin1(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    @MiddlewareMixin1.middleware('response')
    def a(request):
        pass

    assert len(MiddlewareMixin1()._future_middleware) == 1
    assert MiddlewareMixin1()._future_middleware[0].attach_to == 'response'
    assert MiddlewareMixin1()._future_middleware[0].middleware == a


# Generated at 2022-06-12 09:18:37.204159
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware

    app = Sanic(__name__)

    assert len(app._future_middleware) == 0

    # test partial
    @app.middleware('request')
    def _(request):
        pass

    assert isinstance(app._future_middleware[0], FutureMiddleware)

    # test full
    @app.middleware(attach_to='response')
    def _(request, response):
        pass

    assert isinstance(app._future_middleware[1], FutureMiddleware)



# Generated at 2022-06-12 09:18:45.558279
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super(TestMiddlewareMixin, self).__init__()
    
    future_middleware = FutureMiddleware(None, 'request')
    obj = TestMiddlewareMixin()

    @obj.middleware(attach_to='request')
    def test_middle(request):
        print('inside test_middle')

    @obj.on_request
    def test_on_request(request):
        print('inside test_on_request')

    assert len(obj._future_middleware) == 2
    assert len(obj._future_middleware[0].middleware) == 1
    assert len(obj._future_middleware[1].middleware) == 1
    assert obj._future_middleware[0].attach_to == 'request'

# Generated at 2022-06-12 09:18:55.205389
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.futures import FutureMiddleware
    from sanic.models.index import IndexMiddleware
    from sanic.models.static import StaticMiddleware

    assert MiddlewareMixin.middleware.__name__ == "middleware"

    model_test = MiddlewareMixin(None)
    model_test.middleware(IndexMiddleware)
    model_test.middleware(StaticMiddleware)

    assert len(model_test._future_middleware) == 2
    assert isinstance(model_test._future_middleware[0], FutureMiddleware)
    assert isinstance(model_test._future_middleware[1], FutureMiddleware)


# Generated at 2022-06-12 09:19:05.699215
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.request_handler_stack = []
            self.response_handler_stack = []
        def _apply_middleware(self, future_middleware: FutureMiddleware) -> None:
            if future_middleware.attach_to == "request":
                self.request_handler_stack.append(future_middleware.middleware)
            elif future_middleware.attach_to == "response":
                self.response_handler_stack.append(future_middleware.middleware)

    # Use -- @middleware
    test = Test()
    @test.middleware
    async def test1(request):
        pass
    test.request_handler_

# Generated at 2022-06-12 09:19:11.503275
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.models.middleware import Middleware
    class TestClass(MiddlewareMixin):
        # Unit test for method _apply_middleware of class MiddlewareMixin
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    testclass = TestClass()
    testclass.middleware = Middleware()
    testclass.middleware(attach_to="response")

    app = Sanic()
    app.middleware = Middleware()
    app.middleware(attach_to="response")


# Generated at 2022-06-12 09:19:12.138359
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-12 09:19:16.118400
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # 1. Test if the parameter passed is not callable
    assert MiddlewareMixin().middleware() == partial(MiddlewareMixin().middleware, attach_to="request")
    # 2. Test if the parameter passed is callable
    assert callable(MiddlewareMixin().middleware(middleware_or_request=lambda x: x))


# Generated at 2022-06-12 09:19:24.753735
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixin_test(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(MiddlewareMixin_test, self).__init__(*args, **kwargs)
            self.middleware_function = None

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware_function = middleware.middleware
            print(self.middleware_function)

    class MiddlewareMixin_test_test:
        def middleware(self):
            print("MiddlewareMixin_test_test.middleware")

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware_function = middleware.middleware
            print(self.middleware_function)

    obj = MiddlewareMixin_test()

# Generated at 2022-06-12 09:19:27.059046
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = Sanic(__name__)
    app.middleware(middleware, attach_to='request')
    assert isinstance(app.middleware, types.MethodType)


# Generated at 2022-06-12 09:19:27.783282
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass