

# Generated at 2022-06-12 09:11:46.977126
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixinTest:
        def __init__(self):
            self._future_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            return

        middleware = MiddlewareMixin.middleware

    test = MiddlewareMixinTest()
    test.middleware(lambda request: 0)
    test.middleware(lambda request: 1, attach_to="request")
    assert test._future_middleware[0].middleware(None) == 0
    assert test._future_middleware[1].middleware(None) == 1


# Generated at 2022-06-12 09:11:54.223325
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import HTTPResponse
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def request_first(request):
        request['first'] = 'first'
    @app.on_request
    def request_second(request):
        request['second'] = 'second'
    @app.route('/')
    def handler(request):
        return HTTPResponse(request['first'])
    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'first'


# Generated at 2022-06-12 09:11:56.040720
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    def f(request):
        pass
    assert f == m.on_request(f)

# Generated at 2022-06-12 09:12:02.935073
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    try:
        from sanic import Sanic
        from sanic.response import json

        def handler(request):
            return json({"hello": "world"})

        def middleware(request):
            return json({"hello": "world2"})

        app = Sanic("test_MiddlewareMixin_on_request")
        app.on_request(middleware)
        app.add_route(handler, '/')
        # app.run(host="localhost", port=0)
        request, response = app.test_client.get('/')
        assert response.json == {"hello": "world2"}
    except Exception as err:
        print("test_MiddlewareMixin_on_request has failed : " + str(err))


# Generated at 2022-06-12 09:12:04.215954
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    m.on_request(middleware='response')

# Generated at 2022-06-12 09:12:10.228560
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            return

    def middleware():
        return

    assert TestMiddlewareMixin().middleware(middleware, "request") is middleware
    assert TestMiddlewareMixin().on_request(middleware) is middleware


# Generated at 2022-06-12 09:12:14.440642
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    Sanic('test').on_request()


# Generated at 2022-06-12 09:12:17.302457
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = MiddlewareMixin()
    assert app.on_request() != None
    assert app.on_request() != None


# Generated at 2022-06-12 09:12:23.267820
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestClass(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            return middleware

    def test_fun(request):
        pass

    test_obj = TestClass()

    test_obj.on_request(test_fun)()
    assert test_obj._future_middleware[-1].middleware_function == test_fun



# Generated at 2022-06-12 09:12:33.509463
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    class Middleware(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self._future_middleware = []
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    app = Sanic()
    middleware = Middleware()
    response = HTTPResponse()
    request = Request("GET", "/", headers={"Host": "example.com"})
    @middleware.middleware
    async def process_request(request):
        return response
    @middleware.on_request
    async def process_request2(request):
        return response
    assert process_request == process_request2
    res = middleware.middle

# Generated at 2022-06-12 09:12:42.020089
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    a = A()
    MiddlewareMixin.__init__(a)
    callable_request = partial(print, 'request')
    MiddlewareMixin.middleware(a, callable_request)
    # assert a._future_middleware[0].middleware == callable_request
    # assert a._future_middleware[0].attach_to == "request"
    # assert a._future_middleware[0].run_async

    callable_response = partial(print, 'response')
    MiddlewareMixin.middle

# Generated at 2022-06-12 09:12:52.253249
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from unittest.mock import MagicMock


    handler = MiddlewareMixin()
    handler._apply_middleware = MagicMock()
    @handler.middleware()
    def test_middleware():
        return {}

    assert len(handler._future_middleware) == 1
    assert isinstance(handler._future_middleware[0], FutureMiddleware)
    assert callable(handler._future_middleware[0].func)
    assert handler._future_middleware[0].attach_to == "request"
    assert handler._apply_middleware.call_count == 1
    assert handler._apply_middleware.call_args[0][0] == handler._future_middleware[0]


# Generated at 2022-06-12 09:13:00.801955
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A(MiddlewareMixin):
        pass
    a = A()

    def foo(request):
        pass

    def bar(request):
        pass

    # @middleware
    a.middleware(foo)
    assert isinstance(a.middleware(foo), partial)
    assert len(a._future_middleware) == 1
    assert a._future_middleware[0]._middleware_func == foo
    assert a._future_middleware[0].attach_to == "request"

    # @middleware('request')
    a.middleware(bar, 'request')
    assert isinstance(a.middleware(bar, 'request'), partial)
    assert len(a._future_middleware) == 2
    assert a._future_middleware[1]._middleware_func == bar
    assert a._future_

# Generated at 2022-06-12 09:13:01.784951
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert MiddlewareMixin.middleware



# Generated at 2022-06-12 09:13:05.973947
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def on_request(self, middleware):
            return middleware

    def middleware(*args, **kwargs):
        pass

    test = TestMiddlewareMixin()
    wrapped = test.on_request(middleware='request')
    assert wrapped == middleware

# Generated at 2022-06-12 09:13:16.207368
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        return request

    @app.middleware('request')
    def test_request_middleware(request):
        return request

    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].middleware == test_request_middleware
    assert app._future_middleware[1].attach_to == 'request'

    @app.middleware('response')
    def test_response_middleware(request, response):
        return response


# Generated at 2022-06-12 09:13:22.221648
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        pass

    class TestMiddleware:
        pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(TestMiddleware)

    assert isinstance(
        test_middleware_mixin._future_middleware[-1].middleware,
        TestMiddleware
    )

    assert test_middleware_mixin._future_middleware[-1].attach_to == "request"


# Generated at 2022-06-12 09:13:34.058010
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware("request")
    async def end_request(request):
        return json({"BODY": request.body})

    @app.middleware("request")
    async def end_request(request):
        return json({"BODY": request.body})

    @app.middleware("response")
    async def end_request(request):
        return json({"BODY": request.body})

    @app.middleware("response")
    async def end_request(request):
        return json({"BODY": request.body})

    @app.middleware("request")
    async def end_request(request):
        return json({"BODY": request.body})



# Generated at 2022-06-12 09:13:44.325682
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic, __version__
    from sanic.models.middleware import Middleware
    from sanic.types import RequestParam

    m = Middleware()

    app = Sanic('test_MiddlewareMixin_middleware')

# Generated at 2022-06-12 09:13:51.632534
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')
    assert app._future_middleware == []

    @app.middleware
    async def handler(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == 'request'

    app.middleware('response')(handler)
    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].attach_to == 'response'

# Generated at 2022-06-12 09:14:02.990956
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    test_inst = MiddlewareMixin()
    def midd_func(*args, **kwargs):
        pass
    midd_obj = MagicMock()
    test_inst.middleware(midd_func)
    assert isinstance(test_inst._future_middleware[0], FutureMiddleware) == True # noqa
    assert test_inst._future_middleware[0].middleware == midd_func
    assert test_inst._future_middleware[0].attach_to == "request" # noqa
    test_inst.middleware(midd_obj, attach_to="response")
    assert isinstance(test_inst._future_middleware[1], FutureMiddleware) == True # noqa
    assert test_inst._future_middleware[1].middleware == midd_obj
    assert test_inst._future_

# Generated at 2022-06-12 09:14:14.155044
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Test calling @MiddlewareMixin.middleware with all optionals as defaults
    class TestMiddleware(MiddlewareMixin):
        pass
    test_obj = TestMiddleware()
    # test_middleware is just a dummy function
    test_middleware = lambda x: x
    # Calling @test_obj.middleware and testing that it was registered
    test_obj.middleware(test_middleware)
    assert len(test_obj._future_middleware) == 1
    assert test_obj._future_middleware[0].middleware == test_middleware
    # Calling @test_obj.middleware with an attach_to value
    test_obj.on_response(test_middleware)
    assert len(test_obj._future_middleware) == 2

# Generated at 2022-06-12 09:14:20.997823
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Create class
    middleware_mixin = MiddlewareMixin()

    # Check method returns NotImplementedError when method is called
    with pytest.raises(NotImplementedError):
        middleware_mixin._apply_middleware(None)

    # Assert property _future_middleware is set
    assert middleware_mixin._future_middleware == []

    # Set method
    def register_middleware(middleware: FutureMiddleware, attach_to: str):
        middleware_mixin._future_middleware.append(middleware)
        if attach_to == "request":
            middleware_mixin.on_request_middleware = middleware.middleware
        elif attach_to == "response":
            middleware_mixin.on_response_middleware = middleware.middleware
        return middle

# Generated at 2022-06-12 09:14:30.216999
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class DummyMiddlewareMixin(MiddlewareMixin):
        def middleware(self, middleware, attach_to="request"):
            pass
    dummy = DummyMiddlewareMixin()

    # test when call @middleware
    @dummy.middleware
    def f(request):
        pass
    assert isinstance(f, partial) # verify the function f is partial function
    # test when call @middleware('request')
    @dummy.middleware('request')
    def f(request):
        pass
    assert isinstance(f, partial) # verify the function f is partial function
    # test when call @middleware('response')
    @dummy.middleware('response')
    def f(request):
        pass
    assert isinstance(f, partial) # verify the function f is partial function
    # test when call

# Generated at 2022-06-12 09:14:37.925611
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic(__name__)

    @app.middleware('request')
    async def request_middle(request):
        pass

    @app.middleware('response')
    async def response_middle(request, response):
        pass

    assert app._future_middleware[0].middleware == request_middle
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].middleware == response_middle
    assert app._future_middleware[1].attach_to == 'response'
    assert len(app._future_middleware) == 2


# Generated at 2022-06-12 09:14:38.450463
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:14:39.315845
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-12 09:14:48.303865
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.response import text
    from sanic import Sanic
    from sanic.request import Request
    app = Sanic("middleware_test")

    @app.middleware("response")
    async def add_hello(request, response):
        response.text = f"hello {response.text}"

    @app.middleware("request")
    async def add_req(request):
        request.ctx["name"] = request.json["name"]

    @app.middleware("request")
    async def add_req1(request):
        request.ctx["name1"] = request.json["name"]

    @app.route("/")
    async def test(request):
        return text("world")

    request, response = app.test_client.post("/", json=dict(name="test"))

    assert response.status

# Generated at 2022-06-12 09:14:49.168295
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-12 09:14:55.889799
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import response    

    class DummyMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            super()._apply_middleware(middleware)
    
    class DummyMiddleware:
        def __init__(self, *args, **kwargs) -> None:
            pass

        async def __call__(self, request, handler):
            return await handler(request)

    async def async_handler(request):
        return response.text("OK")

    dummy_middleware_mixin: DummyMiddlewareMixin = DummyMiddlewareMixin()

# Generated at 2022-06-12 09:15:10.674530
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware
    from sanic.handlers import ErrorHandler
    from unittest import mock

    app = Sanic()

    # FutureMiddleware([], [])
    future_middleware = FutureMiddleware(app.error_handler.default, "error")
    future_middleware.middleware = ErrorHandler.default
    future_middleware.attach_to = "error"

    # FutureMiddleware([], [])
    test_middleware = FutureMiddleware(app.error_handler.default, "response")
    test_middleware.middleware = ErrorHandler.default
    test_middleware.attach_to = "response"

    app._future_middleware = [future_middleware]


# Generated at 2022-06-12 09:15:21.562519
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestClass(MiddlewareMixin):
        def __init__(self, app, *args, **kwargs) -> None:
            super().__init__(self, *args, **kwargs)
            self._future_middleware = []
            self.app = app
    
    app = Sanic("unit_tests")
    mw = TestClass(app)

    @mw.middleware("request")
    def mw_func():
        pass
    
    assert len(mw._future_middleware) == 1

    @mw.on_response
    def mw_func():
        pass
    assert len(mw._future_middleware) == 2

    @mw.on_request
    def mw_func():
        pass
    assert len(mw._future_middleware) == 3



# Generated at 2022-06-12 09:15:31.499664
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixinTestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware):
            pass

    class LoginMiddleware:
        def __init__(self, request):
            pass

    class LoginMiddleware2:
        def __init__(self, request):
            pass

    class LoginMiddleware3:
        def __init__(self, request):
            pass

    test_class = MiddlewareMixinTestClass()
    test_class.middleware(LoginMiddleware, attach_to = 'request')
    test_class.middleware(LoginMiddleware2)
    test_class.middleware(LoginMiddleware3, attach_to = 'response')


# Generated at 2022-06-12 09:15:32.851625
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert MiddlewareMixin.middleware

	

# Generated at 2022-06-12 09:15:36.724051
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Foo(MiddlewareMixin):
        pass
    foo = Foo()
    def bar(request):
        return request
    foo.middleware(bar, attach_to="request", apply=True)
    assert foo._apply_middleware(bar) == None
    assert foo._future_middleware == [bar]


# Generated at 2022-06-12 09:15:42.579489
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json

    def request_middleware(request):
        request['test1'] = 1

    def response_middleware(request, response):
        response['test2'] = 2

    app = Sanic('test_MiddlewareMixin_middleware')

    app.middleware(request_middleware, attach_to='request')
    app.middleware(response_middleware, attach_to='response')

    @app.route('/')
    async def hello(request):
        return json({})

    request, response = app.test_client.get('/')

    request_json = json.loads(request.text)
    response_json = json.loads(response.text)

    assert request_json == {}
    assert response_json == {'test2': 2}


# Generated at 2022-06-12 09:15:51.029777
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Server(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.f = 0
        def _apply_middleware(self, middleware: FutureMiddleware):
            self.f = 1
    server = Server()
    def m(request, h):
        return h
    server.middleware(m)
    assert server.f == 1
    assert server._future_middleware[0].middleware == m
    assert server._future_middleware[0].attach_to == "request"


# Generated at 2022-06-12 09:15:53.387021
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("test_sanic")
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-12 09:15:57.899453
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    def attach_stuff(request):
        request['foo'] = 'bar'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert 'bar' in request
    assert response.text == 'OK'

# Generated at 2022-06-12 09:16:04.893842
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    def middleware():
        pass
    class MyClass(MiddlewareMixin):
        def __init__(self):
            self.request = None
            self.response = None

        def _apply_middleware(self, middleware):
            self.middleware = middleware

    myClass = MyClass()
    assert myClass._future_middleware == []
    @myClass.middleware
    def middleware():
        pass
    assert myClass._future_middleware != []
    assert myClass._future_middleware[0].handler == middleware
    assert myClass._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-12 09:16:24.297244
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test:
        def __init__(self):
            self._future_middleware = []

        def _apply_middleware(self, middleware):
            pass
    test = Test()
    test.middleware(partial(print, 'app.middleware'))
    test.middleware(partial(print, 'app.middleware2'))
    assert len(test._future_middleware) == 2


# Generated at 2022-06-12 09:16:26.303597
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class test_MiddlewareMixin(MiddlewareMixin):
        pass
    obj = test_MiddlewareMixin()
    obj.middleware(3)



# Generated at 2022-06-12 09:16:31.756143
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def handler(request):
        pass

    @app.middleware("response")
    async def handler_two(request, response):
        pass

    assert len(app._future_middleware) == 2
    assert len(app._middleware) == 2

# Generated at 2022-06-12 09:16:41.440950
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.request import Request
    import json

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.route('/')
    async def handler(request):
        return text('OK')

    async def response_middleware(request, response):
        return text('Middleware')

    async def request_middleware(request):
        return text('Middleware')

    app.middleware(request_middleware)
    app.middleware(response_middleware)

    @app.listener('before_server_start')
    def apply_middleware(app, loop):
        for middleware in app._future_middleware:
            app._apply_middleware(middleware)


# Generated at 2022-06-12 09:16:46.824525
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic(__name__)

    from sanic.middleware import CORSMiddleware

    app.middleware(CORSMiddleware)

    list_of_middlewares = app._middleware

    for i in list_of_middlewares:
        assert len(i) == 2
        handler, args = i
        assert len(args) == 0



# Generated at 2022-06-12 09:16:55.326846
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from unittest import TestCase

    from sanic import Sanic

    class Test(TestCase):
        def test_middleware(self):
            app = Sanic("test_middleware")

            @app.middleware
            async def first_middleware_run(request):
                request["message"] = request["message"].upper()

            @app.middleware('response')
            async def second_middleware_run(request, response):
                response.text += " and this was added by second_middleware_run"

            @app.route("/")
            def handler(request):
                return request["message"]

            request, response = app.test_client.get("/")
            self.assertEqual(request["message"].upper(), "HELLO WORLD!")

# Generated at 2022-06-12 09:17:04.242036
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.blueprints import Blueprint

    class BlueprintMixin:
        def register_blueprint(self, blueprint, **options):
            return None

    class App(BlueprintMixin, MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(App, self).__init__(*args, **kwargs)

        def _apply_middleware(self, future_middleware):
            pass
    
    @BlueprintMixin.middleware
    async def test_middleware(request):
        return request

    # test app
    app = App()
    app.middleware(test_middleware)
    assert test_middleware.__name__ == 'test_middleware'

    # test blueprint
    bp = Blueprint(__name__)

# Generated at 2022-06-12 09:17:12.538181
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.models.future import FutureMiddleware

    app = Sanic()
    assert len(app._future_middleware) == 0

    # Test the partial
    @app.middleware
    def foo(request):
        pass
    assert len(app._future_middleware) == 0

    # Test the full
    @app.middleware()
    def barbaz(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0] == FutureMiddleware(barbaz)

    # Test the partial with attach_to
    @app.middleware('response')
    def baz(request):
        pass
    assert len(app._future_middleware) == 2
    assert app._future_middleware[1] == Future

# Generated at 2022-06-12 09:17:18.479242
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixinFixture(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError
    obj = MiddlewareMixinFixture()
    obj._future_middleware.append(FutureMiddleware(middleware, attach_to="request"))
    assert obj._future_middleware


# Generated at 2022-06-12 09:17:25.656000
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    #arrange
    from sanic import Sanic
    from sanic.router import Router
    from sanic.server import serve
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import NotFound

    app = Sanic("test_app")

    router = Router(app)
    serve(app, port=81, router=router)

    # act
    @app.middleware
    async def handler(request):
        print("before request")
        response = await handler(request)
        print("after request")
        return response

    # assert
    assert app._future_middleware[0].middleware == handler
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-12 09:17:58.093464
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic(__name__)
    @app.middleware
    def before_request(request):
        return "request"
    
    @app.middleware
    def after_response(request, response):
        return "response"
    
    @app.route("/")
    def test(request):
        return "test", 200
    
    request, response = app.test_client.get('/')
    assert response.text == "test"
    
    

# Generated at 2022-06-12 09:18:07.140677
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A(MiddlewareMixin):
        def __init__(self, a1, a2):
            self.a1 = a1
            self.a2 = a2
            super().__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            print("_apply_middleware")
            print(middleware.__dict__)

    class B(MiddlewareMixin):
        def __init__(self, b1, b2):
            self.b1 = b1
            self.b2 = b2
            super().__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            print("_apply_middleware")
            print(middleware.__dict__)

    def F1(request):
        print("F1")

# Generated at 2022-06-12 09:18:11.537864
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class test_MiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super(MiddlewareMixin, self).__init__()
        
        def _apply_middleware(self, middleware):
            return middleware
    
    MiddlewareMixin_test = test_MiddlewareMixin()
    @MiddlewareMixin_test.middleware('test1')
    def test():
        return 1
    
    assert MiddlewareMixin_test._future_middleware[0].middlewares[0] == test



# Generated at 2022-06-12 09:18:16.900938
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json

    async def foo(request):
        return json({"Hello":"Word"})

    app = Sanic("test_MiddlewareMixin_middleware")

    app.add_route(foo, '/test') 
    app.middleware(middleware_or_request='re', apply=True)

    request, response = app.test_client.get('/test')
    assert response.json == {'Hello':'Word'}


# Generated at 2022-06-12 09:18:18.810500
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Given
    m = MiddlewareMixin()
    # When
    m.middleware(1)
    # Then



# Generated at 2022-06-12 09:18:25.967088
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MyClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            
    obj = MyClass()
    assert(len(obj._future_middleware) == 0)
    
    @obj.middleware
    def middleware_function(request):
        pass
    assert(len(obj._future_middleware) == 1)
    assert(obj._future_middleware[0].middleware == middleware_function)
    
    @obj.middleware('request')
    def middleware_function2(request):
        pass
    assert(len(obj._future_middleware) == 2)
    assert(obj._future_middleware[1].middleware == middleware_function2)

# Generated at 2022-06-12 09:18:33.633905
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.server import HttpProtocol
    from sanic.response import text

    class MiddlewareMixinTest(MiddlewareMixin):

        async def handle_request(self):
            return text('OK')

        async def log(self, request, response):
            return response

    app = MiddlewareMixinTest()

    app.middleware(app.log)
    protocol = HttpProtocol(app, None)

    assert app._future_middleware[0].middleware == app.log
    assert app._future_middleware[0].attach_to == "request"
    assert app.log

    app.middleware(app.log, apply=False)
    assert app._future_middleware[1].middleware == app.log
    assert app._future_middleware[1].attach_to == "request"

    app

# Generated at 2022-06-12 09:18:36.591465
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware  # noqa
    async def my_middleware(request):
        pass

    assert app._future_middleware



# Generated at 2022-06-12 09:18:43.198003
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic import response

    class A:
        def __init__(self):
            pass

    app = Sanic("test_MiddlewareMixin_middleware")

    def handler(request):
        return response.text("OK")

    @app.middleware("request")
    def handler_middleware_request(request):
        request["processed"] = True

    @app.middleware("response")
    def handler_middleware_response(request, response):
        response.headers["Content-Type"] = "text/plain; charset=utf-8"

    app.add_route(handler, "/")

    request, response = app.test_client.get("/")

    assert request["processed"]
    assert response.text == "OK"
    assert response.headers["Content-Type"]

# Generated at 2022-06-12 09:18:50.271690
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
  m1 = MiddlewareMixin()

  @m1.on_request()
  def hw(request):
      return 'hello!'

  assert str(m1) == '<MiddlewareMixin>'
  assert hw is not None
  assert m1._future_middleware[0].attach_to == 'request'
  assert m1._future_middleware[0].middleware(None) == 'hello!'

  m2 = MiddlewareMixin()
  @m2.on_response()
  def he(request,response):
      return response
  
  assert str(m2) == '<MiddlewareMixin>'
  assert he is not None
  assert m2._future_middleware[0].attach_to == 'response'
  assert m2._future_middleware[0].middleware(None, None)

# Generated at 2022-06-12 09:19:53.607537
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.response import json
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic import Sanic
    from sanic.exceptions import RequestTimeout
    from sanic.response import text
    import time

    class TimeoutMiddleware:
        def __init__(self, request):
            request["middleware"] = time.time()

        def response(self, request, response):
            response.body += b"Middleware!"
            return response

    class VeryShortTimeoutMiddleware:
        def response(self, request, response):
            response.body += b"Middleware!"
            return response

    class TimeoutException(Exception):
        pass

    app = Sanic("test_MiddlewareMixin_middleware")


# Generated at 2022-06-12 09:20:02.742052
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class PMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super(PMiddlewareMixin, self).__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    p = PMiddlewareMixin()
    def middleware1(request):
        return None
    def middleware2(request):
        return None
    p.middleware(middleware1, attach_to='request', apply=True)
    p.middleware(middleware1, apply=True)
    assert len(p._future_middleware) == 2
    assert len(p._future_middleware[0].args) == 1
    assert len(p._future_middleware[1].args) == 1

    # test register_middleware
    p._future_middleware = []

# Generated at 2022-06-12 09:20:09.095052
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    #########
    ### Prepare data
    #########
    class Test(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)

    test = Test()
    #########
    ### Start testing
    #########


# Generated at 2022-06-12 09:20:15.508733
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class _EmptyOne(MiddlewareMixin):
        pass

    class _EmptyTwo(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            self._future_middleware: List[FutureMiddleware] = []
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            super()._apply_middleware(middleware)

    _EmptyOne().middleware(None, 'request')
    _EmptyTwo().middleware(None, 'request')

# Generated at 2022-06-12 09:20:25.396133
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Initialize a instance
    obj = MiddlewareMixin()
    # Check the property of '_future_middleware'
    assert obj._future_middleware == []
    # Check the property of '_future_request'
    assert obj._future_request == []
    # Check the property of '_future_response'
    assert obj._future_response == []
    # Check the property of '_middleware'
    assert obj._middleware == {}
    # Check the property of '_middleware_order'
    assert obj._middleware_order == []
    # Check the property of '_middleware_lock'
    assert obj._middleware_lock == True

# Generated at 2022-06-12 09:20:34.278096
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import HTTPResponse
    from sanic.test import SanicTestClient

    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def pre_middleware(request):
        return "pre_middleware"

    @app.middleware('request')
    async def pre_middleware_req(request):
        return "pre_middleware_req"

    @app.middleware('response')
    async def post_middleware(request, response):
        return "post_middleware"

    @app.middleware('request')
    async def pre_middleware_req2(request):
        return "pre_middleware_req2"


# Generated at 2022-06-12 09:20:42.312191
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    class App(MiddlewareMixin):
        pass

    app = App()

    def middleware1(request):
        return request

    def middleware2(request):
        return request

    def middleware3(request):
        return request

    app.middleware(middleware1, request=True)
    app.middleware(middleware2, request=True)
    app.middleware(middleware3, request=True)

    assert app._future_middleware == [
        FutureMiddleware(middleware1, "request"),
        FutureMiddleware(middleware2, "request"),
        FutureMiddleware(middleware3, "request"),
    ]

    app.middleware(middleware1, "request")
    app.middleware(middleware2, "request")
    app.middleware

# Generated at 2022-06-12 09:20:43.482743
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert MiddlewareMixin.middleware.__doc__ is not None

# Generated at 2022-06-12 09:20:49.890170
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    
    app = Sanic(__name__)

    @app.middleware
    def add_x_to_response(request, response):
        response.headers.update({"X-Header": "value"})
        return response

    @app.middleware('request')
    async def add_args_to_request(request):
        request.args["y"] = "y"

    @app.route("/")
    def handler(request):
        return json(request.args)


    request = app.test_client.get('/')

    assert request.status == 200
    assert request.json.get('y') == 'y'
    assert request.headers.get('X-Header') == 'value'



# Generated at 2022-06-12 09:20:57.953920
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic(__name__)

    @app.middleware
    def handler_middleware(request):
        pass

    @app.middleware('response')
    def response_middleware(request, response):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == handler_middleware
    assert app._future_middleware[0].attach_to == "request"

    assert (
        app._future_middleware[1].middleware == response_middleware
    )
    assert app._future_middleware[1].attach_to == "response"
