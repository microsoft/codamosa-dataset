

# Generated at 2022-06-12 09:11:38.513173
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    
    class Middleware:
        def __call__(self, request, handler):
            return handler(request)

    @Sanic.middleware('request')
    def request_middleware2(request, handler):
        return handler(request)

    @Sanic.middleware('response')
    def response_middleware2(request, response, handler):
        return handler(request, response)

    @Sanic.middleware
    def default_middleware(request, handler):
        return handler(request)

    app = Sanic('test_MiddlewareMixin_middleware')
    request, response = app.test_client.get('/')

    @app.route('/')
    def handler(request):
        return json({'test': True})



# Generated at 2022-06-12 09:11:41.490916
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddleware(MiddlewareMixin):
        pass
    app=TestMiddleware()
    assert app._future_middleware == []

    @app.middleware("request")
    def request_mid(request):
        request.response="request middleware"

    assert app._future_middleware == [FutureMiddleware(request_mid, "request")]

# Generated at 2022-06-12 09:11:44.521890
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    mixin = MiddlewareMixin()
    assert callable(mixin.on_response(test_MiddlewareMixin_on_response))

# Generated at 2022-06-12 09:11:46.293438
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app=Sanic()
    assert app._future_middleware == []

# Generated at 2022-06-12 09:11:46.994628
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-12 09:11:51.915699
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic import response
    from sanic.response import text

    app = Sanic()

    # Function to test whether app calls provided function
    called = False
    def on_response(request, response):
        nonlocal called
        called = True

    # Register response and make request
    app.on_response(on_response)
    request, response = app.test_client.get('/')
    assert called == True

# Generated at 2022-06-12 09:11:55.141507
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response("request") ==  partial(MiddlewareMixin.middleware, attach_to="request")

# Generated at 2022-06-12 09:12:02.139229
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.exceptions import MethodNotSupported

    class MiddlewareMixin_Test(MiddlewareMixin):

        def _apply_middleware(self, middleware):
            pass

    @MiddlewareMixin_Test.middleware
    async def request_middleware(request):
        pass

    @MiddlewareMixin_Test.middleware('response')
    async def response_middleware(request, response):
        pass

    instance = MiddlewareMixin_Test()

    assert len(instance._future_middleware) == 2
    assert instance._future_middleware[0].attach_to == 'request'
    assert instance._future_middleware[1].attach_to == 'response'

# Generated at 2022-06-12 09:12:11.107920
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def pre(request):
        return request

    @app.middleware('response')
    def post(request, response):
        return response

    # Test __init__
    assert app._future_middleware == []

    # Test _apply_middleware
    with pytest.raises(NotImplementedError):
        app._apply_middleware(None)

    # Test middleware
    assert app.middleware == app.middleware

    # Test on_request
    assert app.on_request == app.on_request
    app.on_request(pre)

    # Test on_response
    assert app.on_response == app.on_response
    app.on_response(post)

# Generated at 2022-06-12 09:12:21.878696
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Test:
        def __init__(self):
            self.middleware_or_request = None
            self.attach_to = None
            self.apply = None
            self._future_middleware = []

        def middleware(self, middleware_or_request, attach_to, apply):
            self.middleware_or_request = middleware_or_request
            self.attach_to = attach_to
            self.apply = apply

    test = Test()
    mixin = MiddlewareMixin()
    mixin.middleware = test.middleware
    mixin.on_response()
    assert test.middleware_or_request == None
    assert test.attach_to == "response"
    assert test.apply
    test.middleware_or_request = None
    test.attach_to = None
    test

# Generated at 2022-06-12 09:12:24.103529
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:12:29.773401
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic(__name__)

    @app.middleware
    async def print_on_response(request, response):
        print('Response from the handler.')
        return response

    assert(len(app._future_middleware) == 1)
    assert(app._future_middleware[0]._attach_to == 'response')


# Generated at 2022-06-12 09:12:35.108393
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic()

    @app.middleware('response')
    async def test_middleware(request, response):
        response.body = 'test response middleware'

    @app.route('/')
    async def index(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.status == 200

# Generated at 2022-06-12 09:12:41.489355
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import HTTPResponse
    from sanic import request

    app = Sanic('test')
    mw1_called = [False]
    mw2_called = [False]
    mw3_called = [False]

    @app.middleware
    async def mw1(request):
        mw1_called[0] = True

    @app.middleware('request')
    async def mw2(request):
        mw2_called[0] = True

    @app.on_response
    async def mw3(request, response):
        mw3_called[0] = True

    @app.route('/')
    async def handler(request):
        return HTTPResponse()

    request, response = app.test_client

# Generated at 2022-06-12 09:12:50.930057
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    import unittest

    @Sanic.middleware
    async def a_middleware(request):
        print("a_middleware")
  

    def b_middleware(request):
        print("b_middleware")

    app = Sanic("test_sanic")

    @app.listener("before_server_start")
    def on_before_server_start(app, loop):
        app.add_task(a_middleware)
        app.on_response(b_middleware)

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-12 09:12:51.573462
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

# Generated at 2022-06-12 09:12:54.806673
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    def middleware(request):
        return request

    obj = MiddlewareMixin()
    func = obj.on_response(middleware)

    assert callable(func)
    assert func() == middleware


# Generated at 2022-06-12 09:12:55.959597
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass


# Generated at 2022-06-12 09:13:00.468459
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.views import HTTPMethodView

    class MyTestView(HTTPMethodView):
        pass


    def my_middleware(request):
        return request

    v = MyTestView()
    v.on_response(my_middleware)


if __name__ == "__main__":
    test_MiddlewareMixin_on_response()

# Generated at 2022-06-12 09:13:10.492572
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self.register_middleware_calls = 0

        def _apply_middleware(self, middleware: FutureMiddleware):
            # self._future_middleware.append(FutureMiddleware(middleware, attach_to))
            self.register_middleware_calls += 1
    
    # Testing MiddlewareMixin.middleware
    t.testMiddlewareMixin = TestMiddlewareMixin()

    @t.testMiddlewareMixin.middleware()
    def middlewareMethod():
        print("middlewareMethod")
    
    t.testMiddlewareMixin.middleware(middlewareMethod)

    assert t.testMiddlewareMixin.register_middleware_calls == 2

# Generated at 2022-06-12 09:13:17.821244
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    t = MiddlewareMixin()
    assert t._future_middleware == []
    t.middleware()
    assert t._future_middleware == []



# Generated at 2022-06-12 09:13:25.157499
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.server import HttpProtocol
    from sanic.response import HTTPResponse

    class ApplicationTest(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    @ApplicationTest.middleware('response')
    async def after_request(request, response):
        return response

    app = ApplicationTest()

    # Unit test for method middleware of class Server
    app.request_middleware = []
    app.response_middleware = []
    app.error_handler = {}
    app._after_request = None

    # Unit test for method middleware of class HttpProtocol
    protocol = HttpProtocol(app, None)
    request = protocol.request_handler.request_class("/")

    response = HTTPResponse("OK")

# Generated at 2022-06-12 09:13:36.452942
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    from sanic.constants import SERVER_SOFTWARE

    from idex.middleware.server_header import server_header

    app = Sanic()
    app.middleware(server_header, attach_to="response")

    @app.route("/")
    async def handler(request):
        return json({"hello": "world"})

    async def test():
        request, response = app.test_client.get("/")
        # Check that response contains correct server header.
        if server_header not in response.headers[SERVER_SOFTWARE]:
            raise AssertionError

    app.add_task(test)
    app.run(debug=True)


# Generated at 2022-06-12 09:13:41.295946
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('response')
    def test_middleware(request):
        request['test'] = True

    request, response = app.test_client.get('/')
    assert request['test'] is True

# Generated at 2022-06-12 09:13:41.884949
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:13:44.368203
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    obj = MiddlewareMixin()

    @obj.middleware
    def middleware():
        return 'middleware'

    assert middleware() == 'middleware'


# Generated at 2022-06-12 09:13:50.107833
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def handler_request(request):
        return request
    assert isinstance(app._future_middleware[0], FutureMiddleware)

    @app.middleware('response')
    def handler_response(request, response):
        return response
    assert isinstance(app._future_middleware[1], FutureMiddleware)


# Generated at 2022-06-12 09:13:56.533568
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixinTest(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    
    MiddlewareMixin_middleware_result = MiddlewareMixinTest(None)
    MiddlewareMixin_middleware_result.middleware = MiddlewareMixinTest.middleware
    test_middleware = MiddlewareMixin_middleware_result.middleware

# Generated at 2022-06-12 09:14:01.647079
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Arrange
    class TestMiddleware(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.test_var = 0

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.test_var += 1

    obj = TestMiddleware()

    # Act
    obj.on_request(lambda request: None)

    # Assert
    assert obj.test_var == 1

# Generated at 2022-06-12 09:14:09.888667
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class FakeMiddleware(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            return middleware.middleware

    # Method middleware of class MiddlewareMixin
    def test_request_middleware():
        def request_middleware(request):
            return request

        fake_middleware = FakeMiddleware()
        fake_middleware.middleware(request_middleware)
        assert fake_middleware._future_middleware[0].middleware == request_middleware

    test_request_middleware()


# Generated at 2022-06-12 09:14:24.396971
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    test_middleware_mixin = TestMiddlewareMixin()

    # Test middleware
    # 函数式三元表达式
    # lambda a, b, c: x if y else z
    # 语法
    # lambda argument_list: expression
    # 函数参数列表格式为：参数1，参数2，参数3

# Generated at 2022-06-12 09:14:32.127852
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import sanic.app
    app = sanic.app.Sanic("test app")

    def on_request(request):
        pass

    def on_response(request, response):
        pass

    app.middleware(on_request)
    app.middleware(on_response, 'response')

    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[1].middleware == on_response
    assert app._future_middleware[1].attach_to == "response"



# Generated at 2022-06-12 09:14:32.693957
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
  pass

# Generated at 2022-06-12 09:14:39.237348
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def custom_middleware(request):
        request['middleware'] = True
        response = await response
        response['middleware'] = True
        return response

    assert len(app._future_middleware) == 0
    assert custom_middleware == app.middleware(custom_middleware)
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == custom_middleware


# Generated at 2022-06-12 09:14:48.220642
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    async def test_middleware(request):
        return HTTPResponse('middleware')

    class TestSanic(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware):
            super()._apply_middleware(middleware)

    app = TestSanic()

    @app.route('/test')
    async def handler_test(request):
        return HTTPResponse('test')

    app.middleware(test_middleware)

    @app.middleware('response')
    def response_middleware(request, response):
        return HTT

# Generated at 2022-06-12 09:14:56.508180
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        pass

    test = TestMiddlewareMixin()
    @test.middleware
    def test_middleware(request):
        return request

    @test.middleware("request")
    def test_middleware2(request):
        return request

    @test.on_request
    def test_middleware3(request):
        return request

    @test.on_response
    def test_middleware4(request, response):
        return response

    assert len(test._future_middleware) == 4
    
    assert test._future_middleware[0].middleware == test_middleware
    assert test._future_middleware[0].attach_to == "request"
    
    assert test._future_middleware[1].middleware == test_middleware2

# Generated at 2022-06-12 09:15:08.184466
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    mm = MiddlewareMixin()
    mm._apply_middleware = lambda x: None
    def foo():
        return 1
    mm.middleware(foo)
    assert mm._future_middleware[0].middleware == foo
    assert mm._future_middleware[0].attach_to == 'request'
    assert mm._future_middleware[0].args == ()
    assert mm._future_middleware[0].kwargs == {}
    assert len(mm._future_middleware) == 1
    mm.middleware('response')(foo)
    assert mm._future_middleware[1].middleware == foo
    assert mm._future_middleware[1].attach_to == 'response'
    assert mm._future_middleware[1].args == ()
    assert mm._future_middleware[1].kwargs == {}
   

# Generated at 2022-06-12 09:15:14.217320
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic(__name__)
    def m1(request):
        pass
    def m2(request):
        pass

    # Test invalid argument
    with pytest.raises(NotImplementedError):
        app.middleware(m1)

    # Test valid called
    app.middleware(m1)
    assert app._future_middleware == [
        FutureMiddleware(m1, 'request')
    ]

    # Test invalid attach_to argument
    with pytest.raises(ValueError):
        app.middleware(m2, 'invalid_attach')

    # Test valid attach_to argument
    app.middleware(m2, 'request')

# Generated at 2022-06-12 09:15:24.649401
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
  app = MiddlewareMixin()

  def _middleware_1():
    pass

  def _middleware_2():
    pass

  def _middleware_3():
    pass

  # It works if there's no middleware at all.
  assert len(app._future_middleware) == 0

  # It works if there's one middleware at all.
  app.middleware(_middleware_1)
  assert len(app._future_middleware) == 1
  assert app._future_middleware[0].middleware == _middleware_1
  assert app._future_middleware[0].attach_to == "request"

  # It works if there're many middlewares at all.
  app.middleware(_middleware_2)
  app.middleware(_middleware_3)

# Generated at 2022-06-12 09:15:34.426735
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware

    class CustomMiddleware(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            return True

    app = CustomMiddleware()
    assert len(app._future_middleware) == 0

    @app.middleware(attach_to="request")
    async def request_middleware(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == request_middleware

# Generated at 2022-06-12 09:15:44.482625
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:15:54.227798
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """Unit tests to check the functionality of method middleware in class MiddlewareMixin

    Arguments:
        None

    Returns:
        None

    Raises:
        None
    """

    # Case 1: Unit test to check the functionality of method middleware of class MiddlewareMixin without providing any arguments
    class App(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

        def run(self):
            pass

    app = App()
    assert not app._future_middleware

    @app.middleware
    def midd(request):
        pass

    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].middleware is midd


# Generated at 2022-06-12 09:15:54.893808
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-12 09:15:58.777477
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    def middleware(request):
        return 'middleware'

    app = Sanic()

    # Unit test for method middleware of class MiddlewareMixin
    app.middleware(middleware)

    # Unit test for method on_request of class MiddlewareMixin
    app.on_request(middleware)

    # Unit test for method on_response of class MiddlewareMixin
    app.on_response(middleware)


# Generated at 2022-06-12 09:16:08.819815
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.futures import FutureMiddleware
    from sanic.response import HTTPResponse

    async def middleware_1(request):
        return request
    async def middleware_2(request):
        return request
    async def middleware_3(response):
        return response

    # Apply middleware to testing class
    class TestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass


    # Create an instance of the test class
    t = TestClass()

    # Test for a decorator with no arguments, attach to request handler
    t.middleware(middleware_1)

    # Check if the middle

# Generated at 2022-06-12 09:16:17.901790
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.exceptions import NotFound
    from sanic.response import text
    from sanic.websocket import WebSocketProtocol
    from sanic.blueprints import Blueprint
    from sanic.static import static
    from sanic.compat import is_coroutine_function

    def url_for_bp(name, *args, **kwargs):
        raise NotFound("http://")

    def url_for_websocket(*args, **kwargs):
        raise NotFound("ws://")

    @static("/static")
    def static(request):
        return text("Hello World!")

    class ServeStatic(Blueprint):
        @static("/static")
        def static(request):
            return text("Hello World!")

    def req_handler(request):
        return

# Generated at 2022-06-12 09:16:18.740960
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    ...


# Generated at 2022-06-12 09:16:20.991940
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic()
    app = MiddlewareMixin()
    app.middleware(middleware_or_request="request")

# Generated at 2022-06-12 09:16:26.268856
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic(__name__)

    # middleware is None
    if(app.middleware(middleware_or_request=None) != None):
        raise AssertionError()

    # middleware is not None
    def use_middleware(request):
        return 10

    if(app.middleware(middleware_or_request=use_middleware) != use_middleware):
        raise AssertionError()


# Generated at 2022-06-12 09:16:36.892869
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestApp(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.middleware_register = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware_register.append(middleware)

    app = TestApp()
    @app.middleware
    def test(request, response):
        pass

    assert len(app.middleware_register) == 1
    assert issubclass(type(app.middleware_register[0].middleware), partial)
    assert app.middleware_register[0].attach_to == "request"
    assert app.middleware_register[0].is_coroutine is False
    assert app.middleware_register[0].is_stream is False

# Generated at 2022-06-12 09:16:58.769923
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    t = Test()
    t.middleware('request')

# Generated at 2022-06-12 09:17:05.788072
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from . import MiddlewareMixin
    from sanic.models.futures import Future

    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass

    def on_request(req):
        pass

    def on_response(res):
        pass

    class Test1(Sanic):
        def __init__(self, *args, **kwargs):
            self.future_middlewares = []

        def middleware(self, fn):
            fm = Future(fn, "request")
            self.future_middlewares.append(fm)

    app = Test1()
    mixin = TestMiddlewareMixin()
    assert mixin._future_middleware == []

# Generated at 2022-06-12 09:17:13.528668
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()
    request = app.middleware(middleware_or_request="request")
    response = app.middleware(middleware_or_request="response")

    @request
    async def middleware_request(request):
        return request

    @response
    async def middleware_response(request, response):
        return response

    test_middleware = app.middleware()
    assert test_middleware.__closure__[0].cell_contents == middleware_request
    assert test_middleware.__closure__[1].cell_contents == 'request'
    assert test_middleware.__closure__[2].cell_contents == True

    test_middleware = app.middleware(middleware_or_request="response")
    assert test_middleware.__closure__

# Generated at 2022-06-12 09:17:20.674960
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic()

    @app.middleware
    async def before_request(request):
        pass

    @app.middleware('response')
    async def after_request(request, response):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[0].middleware == before_request
    assert app._future_middleware[1].attach_to == 'response'
    assert app._future_middleware[1].middleware == after_request


# Generated at 2022-06-12 09:17:30.323089
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.response import json

    app = Sanic("test_MiddlewareMixin_middleware")

    # test
    @app.middleware("request")
    async def validate_request(request):
        return True

    @app.middleware("response")
    async def validate_response(response):
        return True

    @app.route("/test")
    async def valid_test(request):
        return json({"test": True})

    request, response = app.test_client.get("/test")
    assert response.json == {"test": True}

    # test with protocol
    app = Sanic("test_MiddlewareMixin_middleware")

    # test

# Generated at 2022-06-12 09:17:35.902601
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware):
            nonlocal middleware_called
            middleware_called = True


    middleware_called = False

    def test_middleware(request):
        nonlocal middleware_called
        middleware_called = True

    mixin = TestMiddlewareMixin()
    mixin.middleware(test_middleware, 'request')
    assert not middleware_called

    mixin._apply_middleware(mixin._future_middleware[0])
    assert middleware_called

# Generated at 2022-06-12 09:17:42.685228
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Set up mock sanic.app.Sanic
    mock_sanic = mock.Mock()
    mock_sanic._populate_request_middleware = mock.Mock()
    mock_sanic._populate_response_middleware = mock.Mock()
    mock_sanic.middleware = MiddlewareMixin.middleware
    mock_sanic.on_request = MiddlewareMixin.on_request
    mock_sanic.on_response = MiddlewareMixin.on_response
    mock_sanic._future_middleware = []

    # Mock the middleware for testing
    middleware_test_one = mock.Mock()
    middleware_test_one.return_value = None
    middleware_test_two = mock.Mock()
    middleware_test_two.return_value = None

   

# Generated at 2022-06-12 09:17:47.710147
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # arrange
    from sanic.app import Sanic
    from sanic.exceptions import SanicException
    from sanic_prometheus_exporter import SanicExporter

    app = Sanic()
    app.config['METRICS_EXPORTER'] = SanicExporter

    # act and assert
    with pytest.raises(SanicException) as e:
        app.middleware()

# Generated at 2022-06-12 09:17:55.768438
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.futures import FutureMiddleware

    class MiddlewareMixinChild(MiddlewareMixin):
        _future_middleware = [] # type: List[FutureMiddleware]
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass   # pragma: no cover

    m = MiddlewareMixinChild()
    assert len(m._future_middleware) == 0
    assert m.middleware(None) is None
    assert len(m._future_middleware) == 1

    def func():
        pass

    func = m.middleware(func)
    assert len(m._future_middleware) == 2
    assert m.on_request()(func) is func
    assert len(m._future_middleware) == 3

    func = m.on_response()(func)


# Generated at 2022-06-12 09:17:56.306351
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert MiddlewareMixin().middleware

# Generated at 2022-06-12 09:18:42.051828
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    from sanic.request import Request

    app = Sanic()

    # Test for register middleware to request
    @app.middleware('request')
    async def print_on_request(request: Request):
        print('middleware print_on_request')

    @app.route('/')
    async def test(request: Request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

    # Test for register middleware to response
    @app.middleware('response')
    async def print_on_response(request: Request, response):
        print('middleware print_on_response')
        return response


# Generated at 2022-06-12 09:18:46.714118
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = MiddlewareMixin()
    app.middleware('')
    app.middleware(attach_to='request')
    app.middleware(middleware_or_request='')
    app.middleware(attach_to='request', apply=True)
    app.middleware(middleware_or_request='', apply=False)
    app.middleware(middleware_or_request='')
    app.middleware(middleware_or_request='')

# Generated at 2022-06-12 09:18:49.200216
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    def testcase():
        pass
    test = MiddlewareMixin()
    assert test.middleware(testcase) == testcase


# Generated at 2022-06-12 09:18:57.826569
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixinTest(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            return middleware

    app = MiddlewareMixinTest()
    @app.middleware
    def middleware_test(req):
        pass
    assert len(app._future_middleware) == 1
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].middleware == middleware_test
    assert app._future_middleware[0].attach_to == 'request'



# Generated at 2022-06-12 09:19:02.148881
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # create instance 
    from sanic.app import Sanic
    app1 = Sanic()
    # arrange
    middleware = app1.middleware
    # act
    result = middleware(lambda x:x)
    # assert
    assert type(result) == type(lambda x:x)


# Generated at 2022-06-12 09:19:08.672205
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class User:
        pass
    user = User()
    user.middleware = MiddlewareMixin.middleware

    def middleware_test(request):
        return

    user.middleware(middleware_test)
    # TODO: fixme
    # assert user._future_middleware[0].middleware == middleware_test
    # assert user._future_middleware[0].attached_to == "request"



# Generated at 2022-06-12 09:19:09.248264
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:19:12.090163
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # create a new object
    from sanic import Sanic
    app = Sanic()

    @app.middleware
    async def middleware_function(request):
        pass

    assert len(app._future_middleware) == 1, 'middleware failed to register'


# Generated at 2022-06-12 09:19:21.125187
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Mixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware = []
            self._apply_middleware = lambda mid: None

    mix = Mixin()

    # Test @middleware
    @mix.middleware
    def my_middleware(request):
        return None

    assert isinstance(my_middleware, FutureMiddleware)
    assert my_middleware.middleware == my_middleware
    assert mix._future_middleware[0] == my_middleware

    # Test @middleware('response')
    @mix.middleware('response')
    def my_middleware(request):
        return None

    assert my_middleware.middleware == my_middleware
   

# Generated at 2022-06-12 09:19:27.879091
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            pass
    test = TestMiddlewareMixin()
    @test.middleware('request')
    def test(request):
        return 'test'
    print(test.middleware('request'))
    print(test.on_request())
    print(test.on_response())
    # def test_with_no_input(request):
    #     return 'test'
    # test(test_with_no_input)

if __name__ == '__main__':
    test_MiddlewareMixin_middleware()

# Generated at 2022-06-12 09:20:53.900244
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
	print("To be implemented")


# Generated at 2022-06-12 09:21:02.436377
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.models import FutureMiddleware

    class MockClass:
        def __init__(self):
            self.middleware_called = False

        async def __call__(self, request):
            self.middleware_called = True

    app = Sanic('test_MiddlewareMixin_middleware')
    decorator_obj = app.middleware
    callable_middleware_obj = MockClass()
    middleware_obj = decorator_obj(callable_middleware_obj, apply=False)
    assert isinstance(middleware_obj, FutureMiddleware)
    assert not callable_middleware_obj.middleware_called
    middleware_obj.apply_to_request(None)
    assert callable_middleware_obj.middleware_called


# Generated at 2022-06-12 09:21:10.099071
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.log import logger

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    def test(request):
        return request
    @app.middleware('request')
    def test2(request):
        return request
    @app.middleware('response')
    def test3(request, response):
        return response

    assert test in app._future_middleware
    assert test2 in app._future_middleware
    assert test3 in app._future_middleware


# Generated at 2022-06-12 09:21:17.503579
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware("response")
    def response_middleware(request):
        return request

    @app.middleware("request")
    def request_middleware(request):
        return request

    assert response_middleware == app._future_middleware[0].middleware
    assert "response" == app._future_middleware[0].attach_to

    assert request_middleware == app._future_middleware[1].middleware
    assert "request" == app._future_middleware[1].attach_to



# Generated at 2022-06-12 09:21:18.430609
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-12 09:21:28.369721
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MyApp: pass
    myApp = MyApp()
    assert not hasattr(myApp, '_future_middleware')
    MiddlewareMixin.__init__(myApp)
    assert hasattr(myApp, '_future_middleware')
    callable_obj = lambda request: 1
    myApp._apply_middleware = lambda x: 2
    assert myApp.middleware(callable_obj) == callable_obj
    # callable_obj = lambda x: 1
    # assert myApp.middleware(callable_obj) == callable_obj
    # myApp._apply_middleware = lambda x: 0
    # assert myApp.middleware(callable_obj) == callable_obj
    # assert myApp.middleware(callable_obj, apply=True) == callable_obj
    #

# Generated at 2022-06-12 09:21:32.000537
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m = MiddlewareMixin()
    assert len(m._future_middleware) == 0
    m.middleware(print)
    assert len(m._future_middleware) == 1
    assert m.middleware(print) == print
    assert len(m._future_middleware) == 2
