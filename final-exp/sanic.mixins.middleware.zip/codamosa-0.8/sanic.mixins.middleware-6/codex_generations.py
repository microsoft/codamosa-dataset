

# Generated at 2022-06-12 09:11:35.829836
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import NotFound
    import asyncio, json

    app = Sanic()

    class HttpProtocol(HttpProtocol):
        def __init__(self):
            self._future_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = HttpProtocol()
    app.middleware(middleware_or_request='request')

# Generated at 2022-06-12 09:11:40.828145
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, middleware):
            self._future_middleware.append(middleware)

    middleware = MiddlewareMixin()
    app = TestMiddlewareMixin()
    app.on_request(middleware)

    assert middleware == app._future_middleware[0].middleware
    assert "request" == app._future_middleware[0].attach_to


# Generated at 2022-06-12 09:11:42.871384
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin = MiddlewareMixin()
    assert callable(middleware_mixin.on_request())


# Generated at 2022-06-12 09:11:45.351493
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    mw_obj = MiddlewareMixin()
    assert isinstance(mw_obj.on_request, partial)

# Generated at 2022-06-12 09:11:51.632150
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from unittest import TestCase
    from sanic.response import text

    class MyTest(TestCase):
        def setUp(self):
            self.app = Sanic()

        def test_on_request(self):
            @self.app.on_request
            def handle_request(request):
                return text("ok")

            request, response = self.app.test_client.get('')
            self.assertEqual(response.text, "ok")

    MyTest().setUp().test_on_request()



# Generated at 2022-06-12 09:11:54.860266
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert 1 == 1


# Generated at 2022-06-12 09:11:57.691039
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # arrange
    m = MagicMock()
    # act
    MiddlewareMixin.on_request(m)
    # assert
    m.assert_called_once_with(middleware = None, attach_to = 'request')


# Generated at 2022-06-12 09:12:03.041987
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic


    class App(Sanic):
        pass

    app = App(__name__)

    @app.on_request
    async def on_request(request):
        return
    print(app._future_middleware)


# Generated at 2022-06-12 09:12:09.348636
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        pass
    test = TestMiddlewareMixin()
    assert test._future_middleware == []
    mw_func = lambda x: x
    test.middleware(middleware_or_request=mw_func)
    assert len(test._future_middleware) == 1
    future_middleware = test._future_middleware[0]
    assert future_middleware.attach_to == 'request'
    assert future_middleware.middleware == mw_func
    assert future_middleware.run_async == False

# Generated at 2022-06-12 09:12:17.127370
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MyClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            MiddlewareMixin.__init__(self)

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    myClass = MyClass()

    assert callable(myClass.on_request())
    assert myClass.on_request()("") == ""
    assert callable(myClass.on_request(lambda:0))
    assert myClass.on_request(lambda:0)() == 0


# Generated at 2022-06-12 09:12:30.509670
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    class MyMiddlewareMixin:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            return middleware

        def on_request(self, middleware=None):
            if callable(middleware):
                return self.middleware(middleware, "request")
            else:
                return partial(self.middleware, attach_to="request")
    MiddlewareMixin.__bases__ = (MyMiddlewareMixin, )
    MiddlewareMixin.__init__ = MyMiddlewareMixin.__init__

# Generated at 2022-06-12 09:12:36.689355
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class WebSubclass(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    web = WebSubclass()

    @web.middleware
    def middleware_func(request):
        return None

    assert middleware_func == web._future_middleware[0].middleware



# Generated at 2022-06-12 09:12:43.990282
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class FakeClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    fake_class = FakeClass()
    middleware_func1 = lambda: 1
    middleware_func2 = lambda: 1
    fake_class.middleware(middleware_func1, 'request', apply=False)
    fake_class.middleware(middleware_func2, 'request', apply=False)
    assert fake_class._future_middleware[0].middleware == middleware_func1
    assert fake_class._future_middleware[0].attach_to == 'request'
    assert fake_class._future_middleware[1].middleware == middleware_

# Generated at 2022-06-12 09:12:51.415445
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.response import text
    from sanic.request import Request

    app = Sanic("test_MiddlewareMixin_on_request")

    @app.on_request
    def handler(request: Request):
        return text("Hello, world!")

    request, response = app.test_client.get("/")
    assert response.text == "Hello, world!"
    assert response.status == 200


# Generated at 2022-06-12 09:12:52.990899
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin().on_request


# Generated at 2022-06-12 09:13:01.131304
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.futures import FutureMiddleware
    from sanic.models.middleware import MiddlewareMixin
    class A(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplemented   
    a = A()
    # callable middleware
    def middleware(request):
        pass
    b = a.on_request(middleware)
    assert len(a._future_middleware) == 1 and isinstance(b, type(middleware))
    # Not callable middleware
    def on_request(middleware):
        pass
    c = a.on_request()

# Generated at 2022-06-12 09:13:03.611842
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    m.on_request(lambda _: None)
    assert len(m._future_middleware) == 1



# Generated at 2022-06-12 09:13:13.595424
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import pytest
    from sanic import Sanic

    app = Sanic('test_MiddlewareMixin_on_request')

    @app.on_request
    async def on_request(request):
        return request

    @app.middleware
    async def on_request_middleware(request):
        return request

    @app.middleware('request')
    async def on_request_attach_to_request_middleware(request):
        return request

    @app.middleware('response')
    async def on_request_attach_to_response_middleware(request):
        return request

    request, response = app.test_client.get('/test_MiddlewareMixin_on_request')

    assert on_request_middleware.called
    assert on_request_attach_to_request_middleware.called

# Generated at 2022-06-12 09:13:23.076224
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import unittest
    import unittest.mock as mock

    class SampleClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.registerd_middleware_list = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.registerd_middleware_list.append(middleware)

    class TestMiddlewareMixin(unittest.TestCase):
        @mock.patch("sanic.models.futures.FutureMiddleware")
        def test_on_request(self, mock_middleware):
            sample_class = SampleClass()
            sample_class.on_request(mock_middleware)

# Generated at 2022-06-12 09:13:23.695158
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
   ...

# Generated at 2022-06-12 09:13:29.037596
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin().on_request(middleware=None)() == MiddlewareMixin().middleware(middleware=None, attach_to="request")

# Generated at 2022-06-12 09:13:30.500300
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    def middleware(request):
        print(request)
    o = MiddlewareMixin()
    o.on_request(middleware)
    print(o._future_middleware)


# Generated at 2022-06-12 09:13:41.733291
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixinTester(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.apply_middleware(middleware)

        def apply_middleware(self, middleware: FutureMiddleware):
            pass

    @MiddlewareMixinTester.middleware
    async def test_middleware(request):
        return request

    assert isinstance(test_middleware, FutureMiddleware)
    assert test_middleware.priority == 0
    assert test_middleware.attach_to == "request"
    assert test_middleware.middleware == test_middleware


# Generated at 2022-06-12 09:13:47.490685
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import json

    def f(request):
        return json({})

    app = Sanic('test_on_request')
    app.on_request(f)
    app.on_request(f)

    assert len(app._future_middleware) == 2

    request = Request.empty()
    request.app = app

    for middleware in app._future_middleware:
        response = middleware.handle_request(request)
        assert response.status == 200

# Generated at 2022-06-12 09:13:54.038897
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_on_request')

    called = False
    @app.on_request
    def handle(request):
        nonlocal called
        called = True

    @app.route('/')
    def handler(request):
        return text('OK')

    _, response = app.test_client.get('/')
    assert response.status == 200
    assert called


# Generated at 2022-06-12 09:13:58.227184
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.blueprints import Blueprint

    bp = Blueprint.create("test_blueprint_on_request")
    bp.on_request(middleware=None)
    bp.on_request(middleware=None)
    bp.on_request(middleware=None)


# Generated at 2022-06-12 09:14:04.472491
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # create a MiddlewareMixin oject
    middlewareMixin = MiddlewareMixin()
    # build a new middleware
    def new_middleware():
        # do something
        return "new middleware"
    # get the function
    function = middlewareMixin.on_request(new_middleware)
    # see if the function is the same with new_middleware
    assert function() == "new middleware"



# Generated at 2022-06-12 09:14:11.190840
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Foo(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass

    foo = Foo()

    @foo.on_request
    async def a(request):
        pass

    assert len(foo._future_middleware) == 1
    assert foo._future_middleware[0].middleware == a
    assert foo._future_middleware[0].when == "request"


# Generated at 2022-06-12 09:14:16.379328
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    
    app = Sanic()

    @app.middleware
    def simple_middleware(request):
        pass

    @app.on_request
    def simple_on_request_middleware(request):
        pass

    @app.request_middleware
    def simple_request_middleware(request):
        pass

    assert len(app._future_middleware) == 3



# Generated at 2022-06-12 09:14:23.973441
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Dummy:
        pass
    class DummyApp(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    app = DummyApp()
    def dummy_middleware(request):
        return request
    app.middleware(dummy_middleware)
    assert app._future_middleware[0].middleware is dummy_middleware
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].middleware_name == "dummy_middleware"
    assert app._future_middleware[0].run_func(Dummy()) == Dummy()

# Generated at 2022-06-12 09:14:32.346370
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware = MiddlewareMixin()
    class Foo(object):
        def f1():
            pass
    assert middleware.on_request(Foo)
    assert middleware.on_request()

# Generated at 2022-06-12 09:14:34.061702
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin.on_request(MiddlewareMixin) == "request"


# Generated at 2022-06-12 09:14:42.991089
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # prepare data
    class Sanic(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            middleware.middleware
    def handler(req):
        return req
    sanic = Sanic()
    sanic.middleware(handler)
    sanic.middleware(handler, attach_to="response")
    sanic.middleware(attach_to="response")(handler)

    # assert result
    assert sanic._future_middleware[0].attach_to == "request"
    assert sanic._future_middleware[1].attach_to == "response"
    assert sanic._future_middleware[2].attach_to == "response"
    assert sanic._future_middleware[0].middleware == handler
    assert sanic._future_middleware[1].middleware == handler
   

# Generated at 2022-06-12 09:14:43.859326
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
  pass


# Generated at 2022-06-12 09:14:52.359841
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic, response
    from sanic.request import Request

    from . import TestSuite, assert_route_result

    app = Sanic("test_MiddlewareMixin_middleware")
    request, response = TestSuite.create_templates(app)

    # ----------------------------------------------------------------------- #
    # @app.middleware
    @app.middleware
    async def print_on_request(request):
        assert request is not None
        print("Request_1")

    @app.middleware("response")
    async def record_on_response(request, response):
        assert request is not None
        assert response is not None

    @app.middleware("request")
    async def print_on_request_2(request):
        assert request is not None
        print("Request_2")

    assert record_on_response

# Generated at 2022-06-12 09:15:00.898763
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass

    mixin = TestMiddlewareMixin()

    class Example:
        def __init__(self):
            self.y = "hello"

    example = Example()
    mixin.middleware(lambda request, y=example.y: request)
    assert mixin._future_middleware[0] == FutureMiddleware(lambda request, y=example.y: request,
                                                            attach_to="request")


# Generated at 2022-06-12 09:15:06.780633
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic()

    @app.on_request
    def log_request(request):
        pass

    @app.route("/")
    async def test(request):
        return json({"hello": "world"})

    request, response = app.test_client.get("/")
    response.json.should.equal({"hello": "world"})



# Generated at 2022-06-12 09:15:10.135106
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MockMiddleware():
        def __init__(self): pass

    # create a new MiddlewareMixin object
    mixin = MiddlewareMixin()

    # test the on_request method of MiddlewareMixin class
    f = mixin.on_request(MockMiddleware)
    assert isinstance(f, partial)
    assert f.func == MiddlewareMixin.middleware
    assert f.args == ()
    assert f.keywords["attach_to"] == "request"

# Generated at 2022-06-12 09:15:15.389209
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_on_request')
    app.on_request(lambda x: None)
    app.on_request(middleware=lambda x: None)
    @app.on_request() 
    def fun_on_request():
        print('fun_on_request')
    fun_on_request()


# Generated at 2022-06-12 09:15:17.170171
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin().on_request()() == None


# Generated at 2022-06-12 09:15:30.363930
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = MiddlewareMixin()
    mw = lambda x: x
    app.on_request(mw)
    assert mw in app._future_middleware


# Generated at 2022-06-12 09:15:38.694315
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class SanicApp(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []
        
        def _apply_middleware(self, middleware: FutureMiddleware):
            return

    app = SanicApp()

    middlewar_pre = []
    middlewar_af = []

    @app.middleware
    def mw_middleware(request, middleware_next):
        middlewar_pre.append('middleware')
        response = middleware_next()
        middlewar_af.append('middleware')
        return response

    @app.on_request
    def mw_on_request(request):
        middlewar_pre.append('on_request')



# Generated at 2022-06-12 09:15:49.986094
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Obj1(MiddlewareMixin):
        pass
        # exemple of implementation for _apply_middleware:
        # def apply_middleware(self, middleware: FutureMiddleware):
        #     if middleware.attach_to == "request":
        #         self.blueprint._requests.insert(0, middleware)
        #     else:
        #         self.blueprint._responses.append(middleware)

    class Obj2(MiddlewareMixin):
        pass
        # exemple of implementation for _apply_middleware:
        # def apply_middleware(self, middleware: FutureMiddleware):
        #     if middleware.attach_to == "request":
        #         self.blueprint._requests.insert(0, middleware)
        #     else:
        #         self.blueprint._

# Generated at 2022-06-12 09:15:56.695164
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Mixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()

    mixin = Mixin()
    @mixin.middleware
    def middleware_1():
        pass
    @mixin.middleware(attach_to='response')
    def middleware_2():
        pass
    @mixin.on_request
    def middleware_3():
        pass
    @mixin.on_response
    def middleware_4():
        pass
    assert len(mixin._future_middleware) == 4
    assert mixin._future_middleware[0].middleware is middleware_1
    assert mixin._future_middleware[1].middleware is middleware_2
    assert mixin._future_middleware[2].middleware is middleware_3
    assert mix

# Generated at 2022-06-12 09:16:04.033818
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class test(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            MiddlewareMixin.__init__(self)
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    t1 = test()
    t1.on_request(print)
    assert t1._future_middleware[0].wrapper == print
    assert t1._future_middleware[0].attach_to == 'request'

    t2 = test()
    t2.on_request()(print)
    assert t2._future_middleware[0].wrapper == print
    assert t2._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-12 09:16:09.499802
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = MiddlewareMixin()
    @app.on_request
    def handle_request(request):
        print("Before request")
        response = yield request
        print("After request")
        return response
    @app.route("/1")
    async def handler(request):
        return text("Hello, world!")
    app.run(host="127.0.0.1", port=8000)


# Generated at 2022-06-12 09:16:10.997960
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # TODO: Unit test for method middleware of class MiddlewareMixin

    assert True  # TODO: May fail later

# Generated at 2022-06-12 09:16:17.560870
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.exceptions import MethodNotSupported
    from sanic.response import json

    app = Sanic(__name__)

    @app.middleware
    def in_app_middlware(request):
        pass

    @app.on_request
    def request_middlware(request):
        pass

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    assert len(app._future_middleware) == 2



# Generated at 2022-06-12 09:16:26.205463
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.models.middleware import MiddlewareMixin
    from sanic.models.futures import FutureMiddleware
    from sanic.models.signals import request_started, request_finished
    import pytest

    app = Sanic()

    @app.middleware
    async def before_request(request):
        request["data"] = "abc"

    @app.middleware("request")
    async def before_request_with_keyword(request):
        assert request.get("data") == "abc"

    assert len(app._future_middleware) == 2
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert isinstance(app._future_middleware[1], FutureMiddleware)

# Generated at 2022-06-12 09:16:28.598277
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class A(MiddlewareMixin):
        pass
    a = A()
    assert a.on_request(None) == partial(a.middleware, attach_to="request")

# Generated at 2022-06-12 09:17:03.478124
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass

    app = App()

    def test_middleware(request):
        pass

    @app.middleware('request')
    def second_test_middleware(request):
        pass

    @app.on_request
    def third_test_middleware(request):
        pass

    assert len(app._future_middleware) == 3
    assert app._future_middleware[0].middleware is test_middleware
    assert app._future_middleware[1].middleware is second_test_middleware
    assert app._future_middleware[2].middleware is third_test_middleware

    assert (
        app._future_middleware[0].attach_to is "request"
    )

# Generated at 2022-06-12 09:17:11.818189
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test(MiddlewareMixin):
        pass

    test = Test()
    @test.middleware
    def func():
        pass

    assert len(test._future_middleware) == 1
    assert test._future_middleware[0].middleware == func
    assert test._future_middleware[0].attach_to == "request"

    @test.middleware(attach_to="response")
    def func2():
        pass

    assert len(test._future_middleware) == 2
    assert test._future_middleware[1].middleware == func2
    assert test._future_middleware[1].attach_to == "response"

    @test.middleware("response")
    def func3():
        pass

    assert len(test._future_middleware) == 3

# Generated at 2022-06-12 09:17:21.033184
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class M:
        def __init__(self,*args,**kwargs):
            self._future_middleware = []
        def _apply_middleware(self, middleware):
            self._future_middleware.append(middleware)
    # test if there is no middleware
    m = M()
    assert len(m._future_middleware)==0

    # test if there is only one middleware
    def middleware(request):
        return 1

    m.middleware(middleware)
    assert len(m._future_middleware)==1

    # test if there are several middlewares
    def middleware2(request):
        return 2
    def middleware3(request):
        return 3

    m.middleware(middleware2)
    m.middleware(middleware3)

# Generated at 2022-06-12 09:17:27.483761
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import sys

    import pathlib

    parent_path = pathlib.Path(__file__).parent.parent
    sys.path.append(str(parent_path))

    from sanic import Sanic

    app = Sanic("testing")

    class FakeMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    assert FakeMiddlewareMixin.middleware
    assert FakeMiddlewareMixin.on_request
    assert FakeMiddlewareMixin.on_response

    class FakeMiddleware:
        def __init__(self, app, *args):
            self.app = app
            self.args = args

    class FakeMiddlewareMix:
        def __init__(self, *args):
            pass


# Generated at 2022-06-12 09:17:35.178969
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """
    1. Case no param
    2. Case middleware not callable
    3. Case attach_to not in ['request', 'response']
    4. Case callable and attach_to in ['request', 'response']
    """
    # 1. Case no param
    # 2. Case middleware not callable
    with pytest.raises(TypeError):
        MiddlewareMixin().middleware()

    # 3. Case attach_to not in ['request', 'response']
    with pytest.raises(ValueError):
        MiddlewareMixin().middleware(partial(print, 'test'))

    # 4. Case callable and attach_to in ['request', 'response']
    mmw = MiddlewareMixin()
    mmw.middleware(partial(print, 'test'), attach_to='request')

# Generated at 2022-06-12 09:17:39.531566
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test:
        def __init__(self):
            self._future_middleware = []
        @MiddlewareMixin.middleware
        def test(self, request):
            pass
    obj = Test()
    assert len(obj._future_middleware) == 1
    assert obj._future_middleware[0].middleware_func.__name__ == 'test'


# Generated at 2022-06-12 09:17:45.724295
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            print(middleware.middleware)
            assert middleware.middleware != None

    test = TestMiddlewareMixin()
    test.middleware(middleware_or_request=lambda x: print(x))



# Generated at 2022-06-12 09:17:53.748884
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Arrange
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass

    instance = TestMiddlewareMixin()
    middleware = lambda *args, **kwargs: None
    attach_to = 'request'
    # Act
    @instance.middleware(attach_to)
    def wrapped_method():
        pass
    # Assert
    assert wrapped_method is not None
    assert instance._future_middleware is not None
    assert len(instance._future_middleware) == 1
    assert instance._future_middleware[0].attach_to == attach_to
    assert instance._future_middleware[0].middleware is not None


# Generated at 2022-06-12 09:17:58.356693
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic('sanic')
    app.middleware(lambda x: x)
    test_app = Sanic('test_app')
    test_app.middleware(lambda x: x)
    assert app.__dict__['_future_middleware'][0].middleware == test_app.__dict__['_future_middleware'][0].middleware
    assert app.__dict__['_future_middleware'][0]._attach_to == test_app.__dict__['_future_middleware'][0]._attach_to


# Generated at 2022-06-12 09:18:05.273469
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    # Create an instance of a server object
    app = Sanic("test_MiddlewareMixin")

    # Decorate the handle request method with middleware
    @app.middleware
    def before_request(request):
        pass

    # Ensure that the before_request method is called before the request
    @app.get("/")
    async def handler(request):
        return text("OK")

    # Make a request to the server and store the response
    request, response = app.test_client.get("/")


# Generated at 2022-06-12 09:18:52.964493
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
        
    app = Sanic(__name__)
    
    assert len(app._future_middleware) == 0

    @app.middleware
    def test_middleware(request):
        print("I am middleware!")
    
    # the test suite passes if the assert statement belowe does not raise an exception
    assert len(app._future_middleware) == 1
    # You can visualize the test result manually on the terminal
    test_middleware(None)

# Generated at 2022-06-12 09:19:02.650653
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic(__name__)

    # Test @app.middleware
    def request_middleware(request):
        return request

    @app.middleware
    def response_middleware(request, response):
        return response

    @app.middleware('request')
    def request_middleware_v2(request):
        return request

    @app.middleware('response')
    def response_middleware_v2(request, response):
        return response

    assert len(app._future_middleware) == 4
    assert len(app.request_middleware) == 2
    assert len(app.response_middleware) == 1



# Generated at 2022-06-12 09:19:10.417254
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text, HTTPResponse
    from sanic.request import Request, StreamBuffer
    from sanic.exceptions import SanicException
    from sanic.config import Config
    import pytest

    async def middleware_request(request):
        return text("Middleware_request")

    async def middleware_response(request, response):
        return text("Middleware_response")

    sanic_app = Sanic("test_MiddlewareMixin_middleware")
    sanic_app.config.from_object(Config())
    sanic_app.middleware(middleware_request)
    sanic_app.middleware(middleware_response, attach_to="response")


# Generated at 2022-06-12 09:19:16.440773
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic('test_Sanic_middleware')

    assert app._future_middleware == []

    @app.middleware('request')
    def request_middleware(request):
        pass

    @app.middleware('response')
    def response_middleware(request, response):
        pass

    assert len(app._future_middleware) == 2
    assert len(app._future_middleware[0]._middleware_list) == 0
    assert len(app._future_middleware[1]._middleware_list) == 0

    app._apply_middleware(app._future_middleware[0])

    assert len(app._future_middleware[0]._middleware_list) == 1

    app._apply_middleware(app._future_middleware[1])

# Generated at 2022-06-12 09:19:24.996998
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.router import Router
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic("test_MiddlewareMixin_middleware")
    router = Router()
    app.router = router

    # Test partial(register_middleware, attach_to="request")
    @app.middleware("request")
    def request_middleware(request):
        request["test"] = True

    client = app.test_client

    @app.route("/middleware")
    def handler(request):
        return text("OK")

    request, response = client.get("/middleware")

    assert response.status == 200
    assert request.get("test", False) is True

    # Test partial(register_middleware, attach_to="

# Generated at 2022-06-12 09:19:25.502255
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:19:32.475392
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json, text
    from sanic.views import HTTPMethodView

    class Client:
        def __init__(self):
            pass

        def send(self, request):
            return (request, "test")

    class View(HTTPMethodView):
        def get(self, request):
            return text("OK")

        def put(self, request):
            return json({"received": True})

    def middleware_handler(request):
        return text("OK")

    app = Sanic("test_MiddlewareMixin_middleware")
    app.add_route(View.as_view(), "/view")
    app.middleware(middleware_handler)
    app.client = Client()


# Generated at 2022-06-12 09:19:35.446104
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert MiddlewareMixin.middleware.__doc__.splitlines()[0] == \
        'Decorate and register middleware to be called before a request.', \
        'method middleware of class MiddlewareMixin has wrong docstring'


# Generated at 2022-06-12 09:19:35.846983
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    assert True

# Generated at 2022-06-12 09:19:39.561420
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    import pytest
    
    with pytest.raises(NotImplementedError) as excinfo:
        app = Sanic()
        app.middleware(123)
        assert MiddlewareMixin._apply_middleware == excinfo.type

# Generated at 2022-06-12 09:21:17.503365
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic, Blueprint
    from sanic.request import Request

    def middleware_test_1(request):
        print("success")

    def middleware_test_2(request):
        print("success")

    def middleware_test_3(request):
        print("success")

    def middleware_test_4(request):
        print("success")

    def middleware_test_5(request):
        print("success")

    def middleware_test_6(request):
        print("success")

    # Case 1: middleware_or_request is a function.
    app = Sanic('test_MiddlewareMixin_middleware_1')
    app.middleware(middleware_test_1)
    # Make sure that the middleware is not applied again
    # after it has been applied once.


# Generated at 2022-06-12 09:21:19.063067
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # No asserts as only __init__ is used currently
    MiddlewareMixin()


# Generated at 2022-06-12 09:21:29.054061
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic(__name__)

    def my_middleware(request):
        pass

    app.middleware(my_middleware)

    assert app._future_middleware[0].middleware == my_middleware
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[0]._app is None

    def my_middleware2(request):
        pass

    app.middleware(my_middleware2, "response")

    assert app._future_middleware[1].middleware == my_middleware2
    assert app._future_middleware[1].attach_to == 'response'
    assert app._future_middleware[1]._app is None

    def my_middleware3(request):
        pass

