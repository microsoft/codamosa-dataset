

# Generated at 2022-06-12 09:11:41.126294
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse, stream, text
    from sanic.router import RouteExists

    blueprint = Blueprint('test_blueprint', url_prefix='blueprint/')

    @blueprint.middleware()
    def print_on_request(request):
        print('I am a request middlware')

    @blueprint.middleware('response')
    def print_on_response(request, response):
        print('I am a response middlware')

    @blueprint.route('/')
    def handler(request):
        return text('OK')

    blueprint.add_route(handler, '/test')

    app = Mock()
    app.blueprints = [blueprint]
    app.middleware = Middleware

# Generated at 2022-06-12 09:11:46.293207
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic('test_on_response')

    @app.route('/')
    async def handler(request):
        return response.json({"test": True})
    resp = app.test_client.get('/')
    assert resp.status == 200
    assert resp.json == {'test': True}

# Generated at 2022-06-12 09:11:46.994129
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-12 09:11:55.520868
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic()

    # Test @app.middleware
    @app.middleware
    def app_middleware(request, call_next):
        return call_next

    assert app._future_middleware[0].middleware is app_middleware

    # Test @app.middleware('request')
    @app.middleware('request')
    def app_middleware_request(request, call_next):
        return call_next

    assert app._future_middleware[1].middleware is app_middleware_request

    # Test @app.middleware('response')
    @app.middleware('response')
    def app_middleware_response(request, call_next):
        return call_next

    assert app._future_middleware[2].middleware is app_middleware

# Generated at 2022-06-12 09:12:03.009064
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_middleware')

    assert len(app._future_middleware) == 0

    @app.middleware
    def middleware1(request):
        print('middleware1 request')
        return request

    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].middleware == middleware1

    # with app.middleware('response') as middleware2:
    @app.middleware('response')
    def middleware2(request, response):
        print('middleware2 response')
        return response

    assert isinstance(app._future_middleware[1], FutureMiddleware)
    assert app._future_middleware[1].middleware == middle

# Generated at 2022-06-12 09:12:08.894109
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models import MiddlewareMixin as mm
    instance = mm()

    @instance.on_request
    async def on_mw(x, y):
        ...

    # Test
    assert type(on_mw) is partial

    # Test the registration of on_mw in the list of middlewares
    assert len(instance._future_middleware) is 1
    assert instance._future_middleware[0].middleware == on_mw
    assert instance._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-12 09:12:14.133268
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """Unit test for method middleware of class MiddlewareMixin"""
    # arragement
    from sanic import Sanic

    app = Sanic()

    # action
    @app.middleware('request')
    async def bar_request(request):
        return

    # assertion
    assert app._future_middleware[0].middleware == bar_request
    assert app._future_middleware[0].attach_to == "request"



# Generated at 2022-06-12 09:12:18.030102
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    m = MiddlewareMixin(0)

    f = m.on_response(None)
    assert f is not None

    f = m.on_response(middleware=None)
    assert f is not None


# Generated at 2022-06-12 09:12:19.495921
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    m = MiddlewareMixin
    m.on_response()

# Generated at 2022-06-12 09:12:21.105340
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    a= MiddlewareMixin()
    a.on_response()

# Generated at 2022-06-12 09:12:33.585621
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import sys
    import os
    import unittest

    from argparse import Namespace
    from unittest.mock import patch

    from sanic import Sanic
    from sanic.exceptions import (
        ServerError,
        InvalidUsage,
        NotFound,
        RequestTimeout,
    )
    from sanic.response import json
    from sanic.router import RouteExists


    app = Sanic("sanic-server-test-mwm")

    @app.middleware("response")
    async def add_header(request, response):
        response.headers["X-Version"] = "1.0"

    @app.middleware("response")
    async def fail_with_error(request, response):
        raise ServerError("You did a bad", status_code=500)


# Generated at 2022-06-12 09:12:42.096378
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    """Unit test for method on_response of class MiddlewareMixin"""

    class Sanic(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(Sanic, self).__init__(*args, **kwargs)
            self._future_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = Sanic()
    middleware_handler = app.on_response()
    assert callable(middleware_handler)
    assert not app._future_middleware

    @middleware_handler
    async def handle_request(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].handler == handle_request

# Generated at 2022-06-12 09:12:43.538975
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response(MiddlewareMixin) == 'response'

# Generated at 2022-06-12 09:12:50.878741
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Arrange
    class MockClass:
        def __init__(self, *args, **kwargs):
            self._future_middleware = []
        def _apply_middleware(self, middleware):
            pass
    middleware_mixin = MiddlewareMixin()

    # Act
    middleware_result = middleware_mixin.on_response(MockClass)
    
    # Assert
    assert isinstance(middleware_result, partial)

# Generated at 2022-06-12 09:12:57.751477
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Create a class which inherits from MiddlewareMixin
    class A(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
    # Initialize a instance of class A
    a = A()
    # Called method on_response with a middleware
    a.on_response(middleware=lambda request, response: print(response))
    # Verify the length of list _future_middleware is 1
    assert len(a._future_middleware) == 1

# Generated at 2022-06-12 09:13:08.006340
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import pytest
    from sanic.sanic import Sanic
    
    app = Sanic()
    
    @app.middleware
    def middleware1(request):
        print('middleware1')
        response = await request

    @app.middleware('response')
    def middleware2(request, response):
        print('middleware2')

    @app.middleware('response')
    def middleware3(request, response):
        print('middleware3')

    @app.route('/')
    def handler0(request):
        return response.text('OK')

    @app.listener('before_server_start')
    def before_server_start(app, loop):
        app.middleware('response')(middleware4)


# Generated at 2022-06-12 09:13:11.381906
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Server:
        def __init__(self):
            self._future_middleware = []

        def _apply_middleware(self, middleware):
            pass

    server = Server()
    server.on_response()



# Generated at 2022-06-12 09:13:13.439989
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Foo:
        def on_response(self): pass

    f = Foo()
    f.on_response()


# Generated at 2022-06-12 09:13:22.980604
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import HTTPResponse
    import pytest
    import asyncio

    app = Sanic('test_on_response')
    results = []
    @app.middleware('response')
    async def handling_response(request, response):
        results.append(response)

    @app.route('/')
    async def handler(request):
        return HTTPResponse(b'OK')

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'OK'
    assert len(results) == 1
    assert isinstance(results[0], HTTPResponse)
    assert results[0].body == b'OK'
    assert results[0].status == 200

# Generated at 2022-06-12 09:13:35.083639
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # MiddlewareMixin is properly extended
    assert issubclass(MiddlewareMixin, MiddlewareMixin)

    # MiddlewareMixin has property _future_middleware
    assert hasattr(MiddlewareMixin, "_future_middleware")

    # MiddlewareMixin has property _on_response
    assert hasattr(MiddlewareMixin, "_on_response")

    # MiddlewareMixin has method middleware
    assert hasattr(MiddlewareMixin, "middleware")
    assert callable(MiddlewareMixin.middleware)
    
    # MiddlewareMixin has method on_response
    assert hasattr(MiddlewareMixin, "on_response")
    assert callable(MiddlewareMixin.on_response)

    # MiddlewareMixin has method _apply_middleware

# Generated at 2022-06-12 09:13:43.624938
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # arrange
    class Test:
        def __init__(self):
            self._future_middleware = []
            self._apply_middleware = lambda m: m
    # arrange
    test = Test()
    # act
    test.on_response(None)
    # assert
    assert callable(test.on_response(None)) == True


# Generated at 2022-06-12 09:13:53.170110
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.handlers import ErrorHandler

    temp_app = Sanic('test_MiddlewareMixin_middleware')

    assert isinstance(temp_app, MiddlewareMixin)
    assert isinstance(temp_app, ErrorHandler)

    assert callable(temp_app.middleware)

    @temp_app.middleware
    def simple_middleware(request):
        print("Hi from simple middleware")

    assert 1 == len(temp_app._future_middleware)
    assert isinstance(
        temp_app._future_middleware, list
    )

    assert isinstance(
        temp_app._future_middleware[0],
        FutureMiddleware
    )



# Generated at 2022-06-12 09:14:01.958254
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_object = TestMiddlewareMixin()
    assert len(test_object._future_middleware) == 0

    @test_object.middleware('request')
    def valid_middleware():
        pass

    assert len(test_object._future_middleware) == 1
    valid_middleware()
    fm = test_object._future_middleware[0]
    assert fm.handler == valid_middleware
    assert fm.attach_to == 'request'

    @test_object.middleware('response')
    def valid_middleware():
        pass

    assert len(test_object._future_middleware) == 2
    valid_middleware()
    fm

# Generated at 2022-06-12 09:14:05.780255
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    assert not hasattr(Sanic, 'middleware')
    MiddlewareMixin.__init__(Sanic)
    assert hasattr(Sanic, 'middleware')


# Generated at 2022-06-12 09:14:08.848936
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    m = MiddlewareMixin()
    assert m.on_response
    assert m.on_response()('something')


# Generated at 2022-06-12 09:14:09.433156
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin().on_response()

# Generated at 2022-06-12 09:14:11.556641
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    m = MiddlewareMixin()
    m.on_rresponse(on_response)
    assert m._future_middleware[0].middleware_func == on_response
    assert m._future_middleware[0].attach_to == "response"


# Generated at 2022-06-12 09:14:19.570617
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from unittest.mock import patch
    import json

    with patch('sanic.app.Sanic.middleware') as  mocked_middleware:
        app = Sanic('test_Sanic')
        @app.get('/on_response')
        async def on_response(request):
            return response.html('<b>Awesomeness</b>')
        @app.middleware('response')
        async def print_on_response(request, response):
            print(response.text)
        request, response = app.test_client.get('/on_response')
        assert response.status == 200
        assert response.headers['Content-Type'] == "text/html; charset=utf-8"
        assert response.text == "<b>Awesomeness</b>"

# Generated at 2022-06-12 09:14:28.482012
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import sanic.app as app
    class SanicTest(app.Sanic, MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass

    test = SanicTest()

    # case: attach_to is string
    def test_request(request):
        pass

    def test_response(request, response):
        pass

    test.middleware(test_request, attach_to="request")
    test.middleware(test_response, attach_to="response")
    assert test._future_middleware[0].middleware == test_request
    assert test._future_middleware[0].attach_to == "request"
    assert test._future_middleware[1].middleware == test_response
    assert test._future_middleware[1].attach_to == "response"

    # case:

# Generated at 2022-06-12 09:14:37.701890
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
	def get_class():
		class MyClass(MiddlewareMixin):
			def __init__(self):
				self._future_middleware: List[FutureMiddleware] = []
		return MyClass

	middleware = get_class()()
	middleware.on_response(get_class)
	assert middleware._future_middleware
	assert middleware._future_middleware[0].middleware == get_class
	assert middleware._future_middleware[0].attach_to == "response"
	
	middleware = get_class()()
	middleware.on_response()
	middleware.on_response("test")
	assert not middleware._future_middleware
	assert middleware._future_middleware == []
	

# Generated at 2022-06-12 09:14:44.742118
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
	assert True

# Generated at 2022-06-12 09:14:53.037708
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic, Blueprint
    from sanic import response
    from sanic.request import Request
    from sanic.response import HTTPResponse
    app = Sanic(__name__)
    bp = Blueprint('test')
    @bp.middleware
    async def request_middleware(request: Request):
        request['middleware'] = [1]
        return await response.text('request_middleware_called')
    @bp.middleware('response')
    async def response_middleware(request: Request, response: HTTPResponse):
        request['middleware'] += [2]
        response.text += 'response_middleware_called'
    @bp.middleware
    async def request_middleware2(request: Request):
        request['middleware'] += [3]
        return await response.text

# Generated at 2022-06-12 09:14:54.728186
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin().on_response()
    assert MiddlewareMixin().on_response('response')

# Generated at 2022-06-12 09:15:06.518402
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():   
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(MiddlewareMixin, self).__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            if middleware.attach_to == "request":
                print("request")
            elif middleware.attach_to == "response":
                print("response")

    t = TestMiddlewareMixin()
    @t.on_request
    async def name(request):
        print("Jack")

    @t.on_response
    async def age(request,response):
        print("20")

    @t.middleware("request")
    async def gender(request):
        print("male")


# Generated at 2022-06-12 09:15:07.801845
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response.__doc__ == \
           MiddlewareMixin.middleware.__doc__

# Generated at 2022-06-12 09:15:10.950457
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic(__name__)
    @app.on_response(lambda _r, _rsp, _e: None)
    def test(r):
        pass

# Generated at 2022-06-12 09:15:14.674539
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class A(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            return middleware
    a = A()
    @a.on_response
    def b(request, response):
        pass
    assert()

# Generated at 2022-06-12 09:15:25.143074
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = MiddlewareMixin()
    app.middleware(lambda x: x)
    assert len(app._future_middleware) == 1
    m = app._future_middleware[0]
    assert m.attach_to == 'request'

# Generated at 2022-06-12 09:15:34.863985
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    MiddleWareMixin = MiddlewareMixin()
    app = MagicMock()
    result = MagicMock()
    MiddleWareMixin._apply_middleware = MagicMock(return_value=result)

    # Test all types of middleware
    middleware = (
        "request",
        "response",
        "exception",
    )
    attach_to = "request"
    for type_middleware in middleware:
        MiddleWareMixin.middleware(type_middleware, attach_to=attach_to)
        MiddleWareMixin._apply_middleware.assert_called_once_with(result)

    # Test register middleware
    MiddleWareMixin.middleware(MagicMock(), attach_to=attach_to)
    MiddleWareMixin._apply_middleware.assert_called_once_with(result)

# Generated at 2022-06-12 09:15:43.182153
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class MockMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass

    # Middleware without parameter
    instance = MockMiddlewareMixin()
    with pytest.raises(TypeError, match="is not callable"):
        instance.on_response()

    # Middleware with parameter
    def dummy_middleware():
        pass

    assert instance.on_response(dummy_middleware) == dummy_middleware

    # Build and return partial function
    partial_func = instance.on_response(dummy_middleware)
    assert partial_func.func == dummy_middleware
    assert partial_func.args == ()
    assert partial_func.keywords == {'attach_to': 'response'}

# Generated at 2022-06-12 09:16:05.222527
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m = MiddlewareMixin("/", "utf-8")
    m.middleware(on_request)
    assert isinstance(m._future_middleware[0].function, partial)



# Generated at 2022-06-12 09:16:08.416511
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    test = MiddlewareMixin()
    test.middleware(middleware_or_request="request")
    test.middleware(middleware_or_request="response")



# Generated at 2022-06-12 09:16:14.585509
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    # Test with @middleware
    async def middleware_before_request(request):
        request['test'] = 1

    @app.middleware
    async def middleware_after_request(request, response):
        response['test'] = 1

    # Test with @middleware('request')
    @app.middleware('request')
    async def request_2(request):
        request['test2'] = 1

    # Test with @middleware('response')
    @app.middleware('response')
    async def response_2(request, response):
        response['test2'] = 1

    @app.route('/')
    async def handler1(request):
        return text('OK')

    request, response = app.test

# Generated at 2022-06-12 09:16:22.869388
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixinTest(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    middleware_mixin_test = MiddlewareMixinTest()
    middleware_mixin_test.middleware(lambda response: response , "request")
    assert len(middleware_mixin_test._future_middleware) == 1

# Generated at 2022-06-12 09:16:28.305194
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestClass():
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
            self._apply_middleware = self.mock_apply_middleware

        def mock_apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)

    test_class = TestClass()
    @test_class.middleware
    def test_middleware():
        return

    assert len(test_class._future_middleware) == 1


# Generated at 2022-06-12 09:16:29.267269
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert 1 == 1

# Generated at 2022-06-12 09:16:38.986672
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    # test middleware
    class TestMiddleware:
        pass

    app = TestMiddlewareMixin()
    app.middleware(TestMiddleware())
    assert len(app._future_middleware) == 1

    # test on_request
    app = TestMiddlewareMixin()
    app.on_request(TestMiddleware())
    assert len(app._future_middleware) == 1

    # test on_response
    app = TestMiddlewareMixin()
    app.on_response(TestMiddleware())
    assert len(app._future_middleware) == 1

# Generated at 2022-06-12 09:16:45.132469
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixinTest(MiddlewareMixin):

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError

    test_obj = MiddlewareMixinTest()

    class _test_middleware_class():
        def __init__(self, app, request):
            pass

    is_success = False
    test_middleware_obj = _test_middleware_class(None, None)
    test_obj.middleware(test_middleware_obj, attach_to="request", apply=False)

# Generated at 2022-06-12 09:16:54.048151
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super(TestMiddlewareMixin, self).__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass


    t = TestMiddlewareMixin()
    @t.middleware("request")
    def request_middleware(request):
        pass
    @t.middleware("response")
    def response_middleware(request, response):
        pass

    assert len(t._future_middleware) == 2
    assert t._future_middleware[0].middleware == request_middleware
    assert t._future_middleware[0].attach_to == "request"
    assert t._future_middleware[1].middleware == response_middleware

# Generated at 2022-06-12 09:17:03.445878
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.testing import HOST, PORT

    app = Sanic("MiddlewareMixin_middleware")

    @app.middleware
    async def middleware(request):
        pass

    assert "middleware" in dir(app)
    assert "middleware" in app.__dir__()
    assert "middleware" in app.__dict__

    assert "middleware" in dir(app.middleware)
    assert "middleware" in app.middleware.__dir__()
    assert "middleware" in app.middleware.__dict__

    assert "middleware" in dir(app.middleware)
    assert "middleware" in app.middleware.__dir__()
    assert "middleware" in app.middleware.__dict__


# Generated at 2022-06-12 09:17:31.101970
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert MiddlewareMixin.middleware.__name__ == "register_middleware"
    assert isinstance(MiddlewareMixin.middleware, partial)


# Generated at 2022-06-12 09:17:38.402716
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic("middleware_mixin_test")
    @app.middleware
    async def a(request):
        return request
    @app.middleware("response")
    async def b(request, response):
        return response

    assert type(app.middleware(a, apply=False)) == types.FunctionType
    assert type(app.middleware("request", apply=False)) == types.FunctionType
    assert type(app.on_request(a)) == types.FunctionType
    assert type(app.on_response(b)) == types.FunctionType

# Generated at 2022-06-12 09:17:43.317198
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from typing import List

    from sanic.models.futures import FutureMiddleware

    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(middleware_or_request='request')

# Generated at 2022-06-12 09:17:43.830282
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass



# Generated at 2022-06-12 09:17:46.762164
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    #@on_request(middleware1)
    #@on_request(middleware1)
    #on_request(middleware1)
    #on_response(middleware1)
    pass

# Generated at 2022-06-12 09:17:49.213323
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    mixin = MiddlewareMixin()
    assert isinstance(mixin, MiddlewareMixin)
    assert mixin._future_middleware == []



# Generated at 2022-06-12 09:17:56.835363
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixinTester(MiddlewareMixin):
        def __init__(self):
            super().__init__()
        def _apply_middleware(self, middleware):
            pass
    mwt = MiddlewareMixinTester()
    @mwt.middleware
    def request_middleware(request):
        pass
    assert isinstance(request_middleware, FutureMiddleware)
    assert request_middleware.middleware == request_middleware
    assert request_middleware.attach_to == 'request'
    @mwt.middleware('response')
    def response_middleware(request, response):
        pass
    assert isinstance(response_middleware, FutureMiddleware)
    assert response_middleware.middleware == response_middleware
    assert response_middleware.attach_to == 'response'




# Generated at 2022-06-12 09:18:02.379620
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixin1 (MiddlewareMixin):
        _applied_middleware: List[FutureMiddleware]=[]
        def _apply_middleware(self, middleware: FutureMiddleware):
            self._applied_middleware.append(middleware)
    mm=MiddlewareMixin1()
    mm.middleware("request")(lambda:None)
    assert mm._future_middleware[0].attach_to=="request"
    assert mm._applied_middleware[0].attach_to=="request"

# Generated at 2022-06-12 09:18:11.600758
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import requests
    import os
    os.environ['SANIC_CONFIG'] = "./config/test_config.py"

    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware
    from sanic.models.middleware import Middleware
    from sanic.models.middleware_handler import MiddlewareHandler

    app = Sanic(__name__)

    @app.middleware
    def example_middleware(request):
        return True

    # Prepare test data
    middleware_obj = MiddlewareHandler(example_middleware, "request")
    future_middleware = FutureMiddleware(middleware_obj, "request")
    app._future_middleware.append(future_middleware)

    # Run the test

# Generated at 2022-06-12 09:18:20.052190
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.router import Router
    from sanic.request import Request
    from sanic.server import HttpProtocol
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.exceptions import (
        SanicException,
        NotFound,
        MethodNotSupported,
    )
    from sanic.blueprints import Blueprint
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import ServerError

    from sanic.app import Sanic
    import os

    app = Sanic()

    @app.middleware
    async def middleware1(request):
        request["middleware1"] = True

    # Verify that a middleware is added to request middlewares
    assert len(app.request_middleware) == 1

# Generated at 2022-06-12 09:19:16.403558
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    from sanic.request import Request

    app = Sanic(__name__)

    #
    # @app.middleware('request')  # Same as @app.middleware
    # def request_middleware(request):
    #
    # @app.middleware('request')  # Same as @app.middleware('request')
    # async def request_middleware(request):
    #
    # @app.middleware()  # Same as @app.middleware('request')
    # def request_middleware(request):
    #
    # @app.middleware()  # Same as @app.middleware('request')
    # async def request_middleware(request):
    #
    # @app.middleware('response')
    # def response_

# Generated at 2022-06-12 09:19:24.996928
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    obj = MiddlewareMixin()
    response = obj.middleware(lambda x:x+1)
    assert response(1) == 2
    response = obj.middleware(lambda x:x+1, "response")
    assert response(1) == 2
    response = obj.middleware(lambda x:x+1, apply = False)
    assert response(1) == 2
    response = obj.middleware(lambda x:x+1, apply = False)
    assert response(1) == 2
    response = obj.middleware(lambda x:x+1, apply = True)
    assert response(1) == 2
    response = obj.middleware(lambda x:x+1, apply = True)
    assert response(1) == 2

# Generated at 2022-06-12 09:19:27.527376
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    @app.middleware
    async def handler(request):
        pass
    assert len(app._future_middleware) == 1


# Generated at 2022-06-12 09:19:33.675276
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super(MiddlewareMixin, self).__init__()

        def _apply_middleware(self, middleware):
            pass

    # Testing with middleware register
    request_method = TestMiddlewareMixin().middleware
    response_method = TestMiddlewareMixin().middleware

    # Testing with decorator
    request_decorator = TestMiddlewareMixin().on_request
    response_decorator = TestMiddlewareMixin().on_response

    # Testing middleware method
    @request_method
    def test_middleware(request):
        pass

    assert TestMiddlewareMixin()._future_middleware[0].middleware == test_middleware
    assert TestMiddlewareMixin()._future_middleware[0].attach

# Generated at 2022-06-12 09:19:34.301633
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-12 09:19:38.885284
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Dummy(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(Dummy, self).__init__(*args, **kwargs)
        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)
    def _middleware1(content: str) -> str:
        return 'middleware1'
    def _middleware2(content: str) -> str:
        return 'middleware2'
    test1 = Dummy()
    test2 = Dummy()
    test1.middleware(_middleware1)
    test2.middleware(_middleware2, "request")
    assert test1._future_middleware[0].middleware() == _middleware1

# Generated at 2022-06-12 09:19:49.122398
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import inspect

    class Test_Class(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(Test_Class, self).__init__(*args, **kwargs)

    def test1(request):
        return request

    def test2(request):
        return request

    def test3(request):
        return request

    @Test_Class.middleware(test1)
    @Test_Class.middleware('request')
    def test4(request):
        return request

    @Test_Class.middleware
    def test5(request):
        return request

    @Test_Class.middleware('response')
    def test6(request):
        return request

    assert inspect.iscoroutinefunction(test1) != True
    assert inspect.iscoroutinefunction(test2) != True

# Generated at 2022-06-12 09:19:49.768907
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert False

# Generated at 2022-06-12 09:19:50.822114
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert hasattr(MiddlewareMixin, 'middleware')
    assert callable(MiddlewareMixin.middleware)


# Generated at 2022-06-12 09:19:56.145748
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Application(MiddlewareMixin):
        def __init__(self):
            super().__init__()
        def _apply_middleware(self, middleware):
            pass
    app = Application()
    app.middleware(lambda a: a)
    assert app._future_middleware[0].middleware(lambda a: a) == "lambda a: a"
    assert app._future_middleware[0].attach_to == "request"
