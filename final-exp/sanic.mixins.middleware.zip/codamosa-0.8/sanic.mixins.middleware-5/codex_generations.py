

# Generated at 2022-06-12 09:11:40.740737
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Mixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    mObj = Mixin()
    def mw1():
        pass

    def mw2():
        pass

    def mw3():
        pass

    mObj.middleware(mw1)
    mObj.middleware(mw2, 'request')
    mObj.middleware(mw3, 'response')

    assert len(mObj._future_middleware) == 3
    assert mObj._future_middleware[0]._middleware == mw1
    assert mObj._future_middleware[1]._middleware == mw2
    assert mObj._future_middleware[2]._middleware == mw3

# Generated at 2022-06-12 09:11:47.059448
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class App(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    app = App()
    @app.on_request()
    def middleware(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-12 09:11:49.012271
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    m = MiddlewareMixin()
    @m.on_response
    def response(request, response):
        return response

# Generated at 2022-06-12 09:11:54.825792
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_on_request')

    @app.on_request
    async def before_request(request):
        print("Middleware before_request")

    @app.on_response
    async def after_request(request, response):
        print("Middleware after_request")

    @app.route("/")
    async def handler(request):
        return text("OK")


# Generated at 2022-06-12 09:12:02.364526
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Sanic():
        def __init__(self, *args, **kwargs):
            self._future_middleware = []

    s = Sanic()

    def test_middleware(request):
        return request

    # try whether the parameter request is callable
    s.middleware(test_middleware)
    assert len(s._future_middleware) == 1
    assert s._future_middleware[0]._function == test_middleware
    assert s._future_middleware[0].attach_to == "request"
    # try whether the parameter request is not callable
    s.middleware('test_middleware')
    assert len(s._future_middleware) == 2
    assert s._future_middleware[1].attach_to == 'request'



# Generated at 2022-06-12 09:12:08.629735
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')
    # Verify expect result to be None
    assert app is not None
    
    @app.middleware('request')
    def a(request):
        return request
    
    assert a(1) == 1

    # Verify expect result to be an object of FutureMiddleware
    @app.middleware()
    def b(request):
        return request

    assert isinstance(b, FutureMiddleware)
    assert b.middleware(2) == 2



# Generated at 2022-06-12 09:12:14.525328
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert MiddlewareMixin.middleware(MiddlewareMixin, middleware_or_request=object)
    assert MiddlewareMixin.middleware(MiddlewareMixin, middleware_or_request=object, attach_to="request")
    assert MiddlewareMixin.middleware(MiddlewareMixin, middleware_or_request=object, attach_to="response")
    assert MiddlewareMixin.middleware(MiddlewareMixin, middleware_or_request=object, apply=False)



# Generated at 2022-06-12 09:12:22.317901
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.views import HTTPMethodView

    app = Sanic(__name__)

    class TestView(HTTPMethodView):
        @app.on_response("response")
        def response_middleware(self, request, response):
            from sanic.response import text
            response = text("response middleware")

        def get(self, request):
            pass  # pragma: no cover

    testview = TestView.as_view()
    request, response = app.test_client.get(
        "/", allow_redirects=True, catch_response=True
    )
    assert response.body == b"response middleware"

# Generated at 2022-06-12 09:12:26.225232
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test')
    assert callable(app.on_request)
    assert isinstance(app.on_request(None), partial)
    assert callable(app.on_request(None))


# Generated at 2022-06-12 09:12:27.916641
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert callable(MiddlewareMixin.on_response(MiddlewareMixin))

# Generated at 2022-06-12 09:12:39.380964
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    import functools, inspect
    app = Sanic('test_MiddlewareMixin_middleware')
    # __init__ of class MiddlewareMixin
    assert hasattr(app, '_future_middleware')
    # __init__ of class FutureMiddleware
    assert hasattr(MiddlewareMixin._apply_middleware, '_future_middleware')
    # _apply_middleware of class FutureMiddleware
    assert hasattr(MiddlewareMixin._apply_middleware, '_apply_middleware')
    # @MiddlewareMixin.register
    assert hasattr(app.middleware, 'register_middleware')
    assert inspect.isfunction(app.middleware.register_middleware)
    # @MiddlewareMixin.register('request')

# Generated at 2022-06-12 09:12:50.579038
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    a = MiddlewareMixin()
    def test():
        return "a"
    @a.middleware
    def foo():
        return "foo"
    assert a._future_middleware[0].middleware == foo
    assert a._future_middleware[0].attach_to == "request"
    assert a._apply_middleware == "foo"
    @a.middleware("request")
    def request():
        return "request"
    assert a._future_middleware[1].middleware == request
    assert a._future_middleware[1].attach_to == "request"
    assert a._apply_middleware == "foo"
    @a.on_request
    def on_request():
        return "on_request"
    assert a._future_middleware[2].middleware == on_request
    assert a

# Generated at 2022-06-12 09:12:59.841853
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    request = Request({
        'type': 'http',
        'headers': [('Host', '127.0.0.1:3128')],
        'host': '127.0.0.1',
        'path': '/',
        'version': '1.1',
        'method': 'GET',
        'port': 3128,
        'remote_addr': '127.0.0.1',
        'transport': {},
    })
    response = Response(" ", headers={})
    sanic = Sanic('test_sanic_backends')

# Generated at 2022-06-12 09:13:08.305232
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    print("test_MiddlewareMixin_middleware")
    class MiddlewareMixinTest(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    mm = MiddlewareMixinTest()
    mm.middleware(lambda: print("hello"))
    mm.on_request(lambda: print("hello"))
    mm.on_response(lambda: print("hello"))
    from functools import partial
    pp = partial(mm.middleware, attach_to="request")
    pp(lambda: print("hello"))
    pp2 = partial(mm.middleware, attach_to="response")
    pp2(lambda: print("hello"))

# Generated at 2022-06-12 09:13:18.718402
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class MyMiddleware:
        def __init__(self):
            pass

        def __call__(self, *args, **kwargs):
            pass

    # 1. test when middleware is a method
    my_middleware = MyMiddleware()
    assert(callable(my_middleware))
    # TODO: How to unit test this?
    # app.on_response(my_middleware)

    # 2. test when middleware is a class name
    app2 = MiddlewareMixin()
    assert(not callable(MyMiddleware))
    func_on_response = app2.on_response(MyMiddleware)
    assert(callable(func_on_response))
    # TODO: How to unit test this?
    # func_on_response()

    # 3. test when middleware is not provided


# Generated at 2022-06-12 09:13:21.851878
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import sanic.app
    app = sanic.app.Sanic(__name__)

    app.on_request(add_method_to_on_request_function)
    assert add_method_to_on_request_function in app._future_middleware


# Generated at 2022-06-12 09:13:29.968758
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            return middleware

    test_class_instance = TestClass()
    
    test_class_instance.middleware(middleware_or_request="request")
    test_class_instance.on_request(middleware=lambda x: x)
    test_class_instance.on_response(middleware=lambda x: x)

# Generated at 2022-06-12 09:13:33.165581
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    TestMiddlewareMixin = MiddlewareMixin()
    testFunction = TestMiddlewareMixin.on_response()
    assert testFunction == TestMiddlewareMixin.on_response

# Generated at 2022-06-12 09:13:36.034878
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixinTest(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    MiddlewareMixinTest()

# Generated at 2022-06-12 09:13:40.307513
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Test function of argument middleware_or_request is not callabe
    @MiddlewareMixin.middleware('request')
    def _do_nothing():
        pass
    assert callable(MiddlewareMixin.middleware)
    assert _do_nothing._future_middleware == []


# Generated at 2022-06-12 09:13:59.629474
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic(__name__)

    @app.middleware
    async def my_middleware(request, response):
        response.text = 'Hi, this is my middleware'
        return response

    assert app._future_middleware[0]._future_middleware.__name__ == 'my_middleware'

    # Unit test for method on_request of class MiddlewareMixin
    def test_MiddlewareMixin_on_request():
        from sanic.app import Sanic
        app = Sanic(__name__)

    @app.on_request
    async def my_middleware(request, response):
        response.text = 'Hi, this is my middleware'
        return response

    assert app._future_middleware[0]._future_middleware.__name__

# Generated at 2022-06-12 09:14:05.993179
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    from sanic.exceptions import ServerError
    from sanic.models.futures import MiddlewareResult

    app = Sanic(__name__)

    async def middleware1(request):
        request['middleware1'] = 'm1'
        return request

    async def middleware2(request):
        if 'middleware1' not in request:
            return request
        if request['middleware1'] != 'm1':
            raise ServerError('Can not find middleware1')
        return request

    class TestMiddlewareMixin:
        pass

    mixin = MiddlewareMixin()
    mixin._future_middleware = []
    mixin._middlewares = {}
    mixin._apply_middleware = lambda x: None

    TestMiddleware

# Generated at 2022-06-12 09:14:06.649313
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:14:16.820585
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.futures import FutureMiddleware
    from sanic.models.functions import RequestMethods

    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_middleware = None

        def _apply_middleware(self, middleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(RequestMethods.GET)
    assert len(test_middleware_mixin._future_middleware) == 0

    test_middleware_mixin.on_request(
        lambda request: request.body["args"]
    )

# Generated at 2022-06-12 09:14:25.516086
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.futures import FutureMiddleware

    class Test:
        middleware_or_request = None
        attach_to = "request"
        apply = False

        def __init__(self):
            pass

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    def call_middleware_method():
        test = Test()
        test.middleware(test.middleware_or_request, attach_to=test.attach_to, apply=test.apply)

    test_cases = (
        (None, 'request', True),
        ('request', None, False)
    )

    for test_case in test_cases:
        Test.middleware_or_request = test_case[0]
        Test.attach_to = test_case[1]

# Generated at 2022-06-12 09:14:28.384503
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')
    app.middleware('test')
    assert app._future_middleware != []

# Generated at 2022-06-12 09:14:31.465700
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('sanic')

    import pytest
    with pytest.raises(NotImplementedError):
        app._apply_middleware(None)

# Generated at 2022-06-12 09:14:37.448540
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddleware:
        def __init__(self, *args, **kwargs):
            pass

    mm = MiddlewareMixin()
    mm.middleware(TestMiddleware)
    assert(isinstance(mm._future_middleware, type([])))
    assert(len(mm._future_middleware) == 1)
    assert(mm._future_middleware[0].middleware_class == TestMiddleware)
    assert(mm._future_middleware[0].attach_to == "request")


# Generated at 2022-06-12 09:14:38.285167
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-12 09:14:39.478603
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # TODO: Add tests
    pass


# Generated at 2022-06-12 09:14:51.795846
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # test MiddlewareMixin.middleware()
    # We do not have access to the application object, need to mock.
    class MiddlewareMixin_mock(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    mw = MiddlewareMixin_mock()

    def mw_decorator(func):
        # add a dummy attribute
        func.mw_decorator = True
        return func

    # call without arguments, mw_decorator should not be called, but
    # we should get a dummy decorator function
    dec = mw.middleware()
    assert callable(dec)
    assert not hasattr(dec, 'mw_decorator')

    # call with middleware, mw_decorator should be called

# Generated at 2022-06-12 09:15:03.383625
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    middleware_mixin = TestMiddlewareMixin()
    assert middleware_mixin._future_middleware == []  # _future_middleware of class MiddlewareMixin is empty
    middleware_mixin.on_request(middleware=lambda x: x)
    middleware_mixin.on_response(middleware=lambda x: x)
    assert len(middleware_mixin._future_middleware) == 2
    for future_middleware in middleware_mixin._future_middleware:
        assert callable(future_middleware.middleware)

# Generated at 2022-06-12 09:15:11.851875
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    # correct return value
    assert app.middleware(middleware_or_request=None) is not None
    # check middleware_or_request
    assert app.middleware(middleware_or_request=None, attach_to="request") is not None
    assert app.middleware(middleware_or_request=None, attach_to="response") is not None
    # check attach_to
    assert app.middleware(middleware_or_request=None, attach_to="request") is not None
    assert app.middleware(middleware_or_request=None, attach_to="response") is not None
    # check apply
    assert app.middleware(middleware_or_request=None, apply=True) is not None
    assert app.middleware

# Generated at 2022-06-12 09:15:22.080370
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Application(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            print(middleware)
    app = Application()
    def _middleware_func(request):
        print(request)
    _middleware = app.middleware(_middleware_func)
    _middleware_request = app.middleware(_middleware_func, attach_to="request")
    _middleware_response = app.middleware(_middleware_func, attach_to="response")
    _middleware_request("request")
    _middleware_response("response")
    app._apply_middleware(_middleware)
    app._apply_middleware(_middleware_request)
    app._apply_middleware(_middleware_response)


# Generated at 2022-06-12 09:15:30.111997
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class SanicMock(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError

    app = SanicMock()

    @app.middleware
    async def test_middleware(request):
        pass

    assert len(app._future_middleware) == 1
    assert hasattr(test_middleware, "_sanic_middleware")



# Generated at 2022-06-12 09:15:38.539022
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic("test_app")
    Mid = MiddlewareMixin(app)
    @Mid.middleware
    def normal_middleware(request):
        pass
    @Mid.middleware("request")
    def request_middleware(request):
        pass
    @Mid.middleware("response")
    def response_middleware(request, response):
        pass
    @Mid.on_request
    def req_middleware(request):
        pass
    @Mid.on_response
    def res_middleware(request, response):
        pass
    @Mid.on_request
    async def req_middleware_async(request):
        pass

# Generated at 2022-06-12 09:15:48.466001
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    '''
    test method MiddlewareMixin.middleware
    '''
    app = MiddlewareMixin()
    @app.middleware("request")
    def test_middleware(request):
        print("request middleware")

    assert app._future_middleware[0].name == "test_middleware"
    assert app._future_middleware[0].attach_to == "request"
    @app.middleware("response")
    def test_middleware(request):
        print("response middleware")
    assert app._future_middleware[1].name == "test_middleware"
    assert app._future_middleware[1].attach_to == "response"


# Generated at 2022-06-12 09:15:54.059390
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # initialize the class for unit test
    arg = MiddlewareMixin()
    arg.middleware = lambda x: None

    def register_middleware(middleware, attach_to="response"):
        global middleware_arg
        middleware_arg = (middleware, attach_to)
        return middleware

    # call the unit_test method middleware
    middleware_return = arg.middleware(register_middleware, "request")
    assert middleware_return == register_middleware

    assert middleware_arg[0] == register_middleware
    assert middleware_arg[1] == "request"


# Generated at 2022-06-12 09:16:00.717186
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.exceptions import MethodNotSupported

    app = Sanic()

    @app.middleware
    async def before_request(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == before_request

    with pytest.raises(MethodNotSupported):
        app._apply_middleware(app._future_middleware[0])

    @app.middleware(attach_to='response')
    async def after_request(request, response):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == after_request
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-12 09:16:10.692535
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, *args):
            return self

    test_mixin = TestMixin()
    # Testing if attach_to is empty string
    res = test_mixin.middleware(lambda x: 'test_middleware', '')
    assert res.__name__ == "test_middleware"

    # Testing if attach_to is 'request'
    res = test_mixin.middleware(lambda x: 'test_middleware', 'request')
    assert res.__name__ == "test_middleware"

    # Testing if attach_to is 'response'
    res = test_mixin.middleware(lambda x: 'test_middleware', 'response')
    assert res.__

# Generated at 2022-06-12 09:16:20.514809
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = MiddlewareMixin()
    @app.middleware
    def example_middleware(request):
        return request

    assert app._future_middleware == []

# Generated at 2022-06-12 09:16:21.758054
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert False

# Generated at 2022-06-12 09:16:29.166630
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    sanic_instance = Sanic('test_middleware')
    assert sanic_instance._future_middleware == []
    a = sanic_instance.middleware('request')
    assert sanic_instance._future_middleware == [FutureMiddleware(a, 'request')]
    b = sanic_instance.middleware('response')
    assert sanic_instance._future_middleware == [FutureMiddleware(a, 'request'), FutureMiddleware(b, 'response')]
    c = sanic_instance.middleware(a)
    assert sanic_instance._future_middleware == [FutureMiddleware(a, 'request'), FutureMiddleware(b, 'response'), FutureMiddleware(a, 'request')]
    d = sanic_instance.middleware(b, "request")
    assert sanic

# Generated at 2022-06-12 09:16:29.705997
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert False

# Generated at 2022-06-12 09:16:40.423768
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    class RequestReporter:
        def __call__(self, request: Request):
            request.ctx.response_middleware.append(str(self))
            return request

        def __str__(self):
            return "RequestReporter"

    class ResponseReporter:
        def __call__(self, request: Request, response: HTTPResponse):
            request.ctx.response_middleware.append(str(self))
            return response

        def __str__(self):
            return "ResponseReporter"

    app = Sanic()


# Generated at 2022-06-12 09:16:45.681121
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    a = Sanic("test_MiddlewareMixin_middleware")
    mm = MiddlewareMixin()
    mm.middleware(None)
    mm.middleware("request")
    mm.on_request()
    mm.on_response()

    def test_middleware(request):
        return True
    print(mm.middleware(test_middleware))

# Generated at 2022-06-12 09:16:54.449169
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test:
        def __init__(self, *args, **kwargs):
            self._future_middleware = []

        def _apply_middleware(self, future_middleware):
            pass
    
    middleware_mixin = MiddlewareMixin()
    test = Test()
    test.middleware = middleware_mixin.middleware
    test.on_request = middleware_mixin.on_request
    test.on_response = middleware_mixin.on_response

    @test.middleware('request')
    def test_middleware(request):
        pass
    assert len(test._future_middleware) == 1

    @test.middleware('response')
    def test_middleware(request):
        pass
    assert len(test._future_middleware) == 2


# Generated at 2022-06-12 09:17:02.819420
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import pytest
    from sanic.models.futures import FutureMiddleware

    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
    
    @TestMiddlewareMixin.middleware
    def test_middleware(request):
        print("Test")
    
    app = TestMiddlewareMixin()

    assert len(app._future_middleware) == 1, "Test middleware was not added"
    assert app._future_middleware[0] == "request", "The wrong middleware was added"
    
test_MiddlewareMixin_middleware()

# Generated at 2022-06-12 09:17:10.952780
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware("request")
    def print_on_request(request: Request):
        print("I am a request middleware")

    @app.middleware("response")
    def print_on_response(request: Request, response: HTTPResponse):
        print("I am a response middleware")

    assert len(app._future_middleware) == 2

    future_middleware_request = app._future_middleware[0]
    future_middleware_response = app._future_middleware[1]

    assert future_middleware_request.middleware == print_on_request
    assert future_middleware_request

# Generated at 2022-06-12 09:17:20.096709
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.route('/')
    async def handler(request):
        return text('OK')

    @app.exception(NotFound)
    async def handler_404(request, exception):
        return text('NOT FOUND', status=404)

    @app.listener('before_start')
    async def setup_service(sanic, loop):
        (lambda: None).__class__.__qualname__ == '<lambda>'

    @app.listener('after_start')
    async def setup_service(sanic, loop):
        (lambda: None).__class__.__qualname__ == '<lambda>'



# Generated at 2022-06-12 09:17:38.244543
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.core import Sanic
    app = Sanic(__name__)

    app.middleware('request', 'attach_to')
    app.middleware(attach_to='request')
    app.middleware('response', 'attach_to')
    app.middleware(attach_to='response')

# Generated at 2022-06-12 09:17:45.555962
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(TestMiddlewareMixin, self).__init__(*args, **kwargs)
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    test_middleware_mixin = TestMiddlewareMixin()
    @test_middleware_mixin.middleware('request')
    async def test_middleware(request):
        return request
    expect_result = FutureMiddleware(test_middleware, "request")
    assert test_middleware_mixin._future_middleware[0] == expect_result


# Generated at 2022-06-12 09:17:50.781396
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    test_obj1 = Test()

    @test_obj1.middleware()
    def test_method():
        return True



# Generated at 2022-06-12 09:17:56.805672
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.sanic import Sanic
    import asyncio
    app=Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def before_request(request):
        print("Before request")

    @app.middleware('response')
    async def after_request(request, response):
        print("After request")

    @app.route('/test')
    async def test(request):
        return response.json({"test": True})

    request, response = app.test_client.get('/test')
    assert response.json == {"test": True}


# Generated at 2022-06-12 09:18:05.675009
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.futures import FutureMiddleware
    from sanic.models.middleware import MiddlewareMixin

    class TestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    testclass = TestClass()
    assert len(testclass._future_middleware) == 0

    testclass.middleware('request')(lambda req: True)
    assert len(testclass._future_middleware) == 1

# Generated at 2022-06-12 09:18:13.904221
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import sanic
    class M(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    app = M()

    @app.middleware
    async def test_middleware_1(request):
        assert True

    @app.middleware('request')
    async def test_middleware_2(request, something):
        assert True

    @app.middleware('response')
    async def test_middleware_3(request, response):
        assert True

    @app.on_request
    async def test_middleware_4(request):
        assert True

    @app.on_response
    async def test_middleware_5(request, response):
        assert True


# Generated at 2022-06-12 09:18:16.983820
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.exceptions import NotFound

    from main import app

    @app.middleware('request')
    async def handler(request):
        return request

    @app.middleware('response')
    async def handler(request, response):
        return response

    assert len(app._future_middleware) == 2

# Generated at 2022-06-12 09:18:24.894714
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    class Custom:
        pass

    async def async_func(request):
        return "test"

    async def async_test_function(request: Request, response: HTTPResponse):
        pass

    async def async_test_function_two(request: Request, response: HTTPResponse):
        pass

    async def async_test_function_two(request: Request, response: HTTPResponse):
        pass

    async def async_test_function_three(request: Request, response: HTTPResponse):
        pass

    async def async_test_function_four(request: Request, response: HTTPResponse):
        pass


# Generated at 2022-06-12 09:18:34.976006
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    # 创建 Sanic 实例
    app = Sanic("test_sanic_MiddlewareMixin_middleware")

    # 添加中间件
    @app.middleware("request")
    def test_middleware(request):
        print("test middleware")

    # 通过调用 request 来向服务器发送请求来测试中间件。
    request, response = app.test_client.get("/")
    assert response.status == 200
    assert response.text == "Hello, world!"
    assert request["test_middleware"] == True


# Generated at 2022-06-12 09:18:42.049882
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(TestMiddlewareMixin, self).__init__(*args, **kwargs)
            self.app = None

        def _apply_middleware(self, middleware: FutureMiddleware):
            # In the Sanic library, _apply_middleware will add middleware to app.
            self.app = middleware

    test_middleware_mixin = TestMiddlewareMixin()
    # Test middleware decorator without attach_to parameter.
    def test_middleware_func(request):
        pass
    # In the Sanic library, middleware will return a decorator.
    test_middleware = test_middleware_mixin.middleware(test_middleware_func)
    # In

# Generated at 2022-06-12 09:19:21.332956
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    async def async_middle_ware_1(request):
        return request

    async def async_middle_ware_2(request):
        return request

    class TestMiddleWareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass

    test = TestMiddleWareMixin()
    test.middleware(async_middle_ware_1)
    test.middleware(async_middle_ware_2, "response")

    assert len(test._future_middleware) == 2
    assert test._future_middleware[0].name == "request"
    assert test._future_middleware[0].middleware == async_middle_ware_1
    assert test._future_middleware[1].name == "response"
    assert test._future_middleware[1].middleware == async_middle

# Generated at 2022-06-12 09:19:24.804785
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class app:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

    test = MiddlewareMixin()
    test.__init__(app)
    test.middleware(app)



# Generated at 2022-06-12 09:19:28.210507
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    @MiddlewareMixin.middleware('request')
    def handle_request(request):
        return None

    assert callable(handle_request)

    @MiddlewareMixin.middleware('response')
    def handle_response(request, response):
        return response

    assert callable(handle_response)



# Generated at 2022-06-12 09:19:36.168738
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Foo:

        def __init__(self, *args, **kwargs):
            self._future_middleware: List[FutureMiddleware] = []
            self._future_middleware.append(middleware)
            self._middleware_applied: bool = True

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

        def middleware(
            self, middleware_or_request, attach_to="request", apply=True
        ):

            def register_middleware(middleware, attach_to="request"):
                nonlocal apply
                future_middleware = FutureMiddleware(middleware, attach_to)
                self._future_middleware.append(future_middleware)
                if apply:
                    self._apply_middleware(future_middleware)
                return middleware

            # Detect

# Generated at 2022-06-12 09:19:46.036989
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Test the middleware is registered.
    class TestClass(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            middleware.apply(self)
    test_obj = TestClass()
    # Case 1
    # Call @app.middleware
    test_obj.middleware(lambda request: request)
    assert test_obj._future_middleware[-1].middleware(None) == None
    assert test_obj._future_middleware[-1].attach_to == "request"

    # Case 2
    # Call @app.middleware('AT')
    test_obj.middleware('response')(lambda request: request)
    assert test_obj._future_middleware[-1].middleware(None) == None

# Generated at 2022-06-12 09:19:52.831344
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    class request():
        pass

    class response():
        pass
    
    class A(MiddlewareMixin):
        def _apply_middleware(self, future_middleware):
            self._future_middleware.append(future_middleware)

    a = A()
    @a.middleware
    def b(request, response):
        pass
    
    @a.on_response
    def c(request, response):
        pass
    assert a._future_middleware[0]._middleware == b

# Generated at 2022-06-12 09:19:57.336591
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class m_MiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, future_middleware):
            pass
    m_m = m_MiddlewareMixin()
    m_m.middleware()
    m_m.on_request()
    m_m.on_response()

# Generated at 2022-06-12 09:20:07.061687
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic, Blueprint
    from sanic.response import json
    from sanic.request import Request
    from sanic.models import Blueprint as BlueprintModel
    from sanic.models.futures import FutureMiddleware
    app = Sanic()
    bp = Blueprint("test_bp")
    @bp.middleware('response')
    def response_middleware(request, response):
        return json({})
    @bp.middleware('request')
    def request_middleware(request):
        return json({})
    model_bp = BlueprintModel(bp)
    assert model_bp.register_middleware(response_middleware, attach_to="response") == response_middleware
    assert model_bp.register_middleware(request_middleware, attach_to="request") == request_middleware
    assert model_bp

# Generated at 2022-06-12 09:20:16.115368
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic()

    @app.middleware
    async def middleware_test(request):
        print("On request middleware")

    assert isinstance(app, MiddlewareMixin)
    assert isinstance(app, Sanic)
    assert hasattr(app, "_future_middleware")

    # check _future_middleware
    assert isinstance(app._future_middleware, list)
    assert len(app._future_middleware) == 1

    future_middleware = app._future_middleware[0]
    assert isinstance(future_middleware, FutureMiddleware)
    assert future_middleware.middleware_func == middleware_test
    assert future_middleware.attach == "request"
    assert future_middleware.incoming is None
    assert future_middleware.out

# Generated at 2022-06-12 09:20:22.547371
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    try:
        middlewareMixin = MiddlewareMixin()
        middlewareMixin.middleware("request")
    except NotImplementedError:
        print("test_MiddlewareMixin_middleware passes.")
    else:
        print("test_MiddlewareMixin_middleware fails.")

# Unit teset for method on_request of class MiddlewareMixin

# Generated at 2022-06-12 09:21:33.532288
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestClass(MiddlewareMixin):
        def __init__(self):
            super(TestClass, self).__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    tester = TestClass()
    assert not tester._future_middleware
    @tester.middleware
    def test():
        pass
    assert len(tester._future_middleware) == 1
