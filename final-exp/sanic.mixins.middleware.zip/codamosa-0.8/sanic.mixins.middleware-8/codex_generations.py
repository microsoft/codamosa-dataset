

# Generated at 2022-06-12 09:11:46.920217
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import json

    app = Sanic("test_on_request")

    @app.middleware("response")
    async def handle_response(request, response):
        response.body = response.body.upper()

    @app.route("/")
    async def handler(request):
        return json({"test": True})

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.body == b'{"TEST": true}'

# Generated at 2022-06-12 09:11:55.482292
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    from sanic.app import Sanic

    app = Sanic("middleware")

    async def middleware(request):
        pass

    app.middleware(middleware)
    assert app._future_middleware == [
        FutureMiddleware(middleware, "request")
    ]

    app.middleware("request")(middleware)
    assert app._future_middleware == [
        FutureMiddleware(middleware, "request"),
        FutureMiddleware(middleware, "request"),
    ]

    app.middleware("response")(middleware)
    assert app._future_middleware == [
        FutureMiddleware(middleware, "request"),
        FutureMiddleware(middleware, "request"),
        FutureMiddleware(middleware, "response"),
    ]

    # Test on_request, on_response decorators
    app.on

# Generated at 2022-06-12 09:12:02.581200
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response.__defaults__ is None
    assert MiddlewareMixin.on_response.__code__.co_argcount == 2
    assert MiddlewareMixin.on_response.__code__.co_varnames == ('middleware',)
    assert MiddlewareMixin.on_response.__closure__ is None
    assert MiddlewareMixin.on_response.__kwdefaults__ is None
    assert MiddlewareMixin.on_response.__annotations__ == {}
    assert MiddlewareMixin.on_response.__dict__ == {}
    assert MiddlewareMixin.on_response.__name__ == 'on_response'
    assert MiddlewareMixin.on_response.__doc__ is None


# Generated at 2022-06-12 09:12:07.184774
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic("test_on_response_of_MiddlewareMixin")
    app.on_response(lambda request, response: response)
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == app.on_response
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-12 09:12:09.297217
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class FakeMiddleware:
        def __init__(self, *args, **kwargs) -> None:
            pass
    app = MiddlewareMixin()
    app.on_request(FakeMiddleware())

# Generated at 2022-06-12 09:12:19.066770
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class App(MiddlewareMixin):
        def __init__(self):
            self._future_middleware = []
            self._after_request_middleware = []
            self._before_request_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            if middleware.attach_to == "request":
                self._before_request_middleware.append(middleware)
            else:
                self._after_request_middleware.append(middleware)

    def on_request_mw_1(request):
        return request

    def on_request_mw_2(request):
        return request

    def on_response_mw_1(request, response):
        return response

    def on_response_mw_2(request, response):
        return response


# Generated at 2022-06-12 09:12:22.971503
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    server = None
    for i in range(1):
        middleware = MiddlewareMixin()
        server = middleware.on_response(middleware=None)
        
        server()
        middleware.on_response(middleware=None)
    return server
#test_MiddlewareMixin_on_response()

# Generated at 2022-06-12 09:12:28.937349
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from unittest.mock import MagicMock

    middleware_mock = MagicMock()

    app = MiddlewareMixin()
    app.middleware = MagicMock()

    app.on_response(middleware=middleware_mock)

    app.middleware.assert_called_once_with(
        middleware_mock, attach_to="response"
    )



# Generated at 2022-06-12 09:12:32.602024
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    s = Sanic('test_MiddlewareMixin_on_response')

    @s.on_response
    def middleware_response(request, response):
        response.text = "hello world"

    @s.route('/')
    async def handler(request):
        return response.text("")

    request, response = s.test_client.get('/')
    assert response.text == "hello world"

# Generated at 2022-06-12 09:12:41.862453
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.request import Request

    def response_middleware(request: Request, response):
        pass

    def request_middleware(request: Request):
        pass

    app = Sanic()
    i = MiddlewareMixin(app)
    # on_response(response_middleware)
    i.on_response(response_middleware)
    assert len(i._future_middleware) == 1
    assert i._future_middleware[0].attach_to == "response"
    assert i._future_middleware[0].middleware == response_middleware

    # on_response()(request_middleware)
    i.on_response()(request_middleware)
    assert len(i._future_middleware) == 2
    assert i._future_middleware[1].attach_to

# Generated at 2022-06-12 09:12:44.833690
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:12:47.095673
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MyClass(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    instance = MyClass()
    instance.middleware(middleware_or_request, attach_to="request", apply=True)
    instance.middleware(middleware_or_request, apply=True)
    instance.middleware(middleware_or_request)


# Generated at 2022-06-12 09:12:57.790905
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class MiddlewareMixinMock:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa


# Generated at 2022-06-12 09:13:02.130683
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    results = []
    class A(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            results.append(middleware.attach_to)
            
    a = A()
    a.on_request()(None)
    assert results == ["request"]


# Generated at 2022-06-12 09:13:05.397381
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    m = TestMiddlewareMixin()
    m.on_response(m)


# Generated at 2022-06-12 09:13:15.809006
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class FakeMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)

    fake_mixin = FakeMiddlewareMixin()
    
    def middleware1():
        pass

    def middleware2():
        pass
    
    fake_mixin.on_request(middleware1)
    fake_mixin.on_request(middleware2)

    assert fake_mixin._future_middleware[0].middleware == middleware1
    assert fake_mixin._future_middleware[0].attach_to == 'request'
    assert fake_mixin._future_middleware[1].middleware == middleware2
    assert fake_mixin._future_middleware[1].attach_to == 'request'


# Generated at 2022-06-12 09:13:24.228603
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import asyncio
    from sanic.blueprints import Blueprint
    from sanic.constants import HTTP_METHODS
    from sanic.request import Request
    from sanic.response import json
    from sanic.views import HTTPMethodView

    from . import _test_server

    blueprint = Blueprint("test_MiddlewareMixin_on_request")

    async def check_middleware(request):
        assert request.test_data == "passed"
        return await json({"test_middleware": "passed"})

    @blueprint.route("/request_middleware")
    @blueprint.middleware(attach_to="request")
    async def check_middleware_params(request):
        assert request.json.get("test_data") == "passed"

# Generated at 2022-06-12 09:13:26.872571
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert app.on_response(middleware=None) == partial(app.middleware, attach_to="response")


# Generated at 2022-06-12 09:13:29.349306
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    instance = MiddlewareMixin()
    instance.on_response(middleware=lambda: None)
    assert instance


# Generated at 2022-06-12 09:13:32.158159
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    object_MiddlewareMixin = MiddlewareMixin()
    object_MiddlewareMixin.on_request()


# Generated at 2022-06-12 09:13:44.802175
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    @MiddlewareMixin.on_response
    async def on_response(request, response):
        pass

    assert on_response.__name__ == 'on_response'
    assert on_response.__qualname__ == 'MiddlewareMixin.<locals>.on_response'
    assert on_response.__module__ == 'tests.unit.test_middleware_mixin'
    assert on_response.__doc__ == MiddlewareMixin.on_response.__doc__


# Generated at 2022-06-12 09:13:52.561812
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Create a MiddlewareMixin object
    middlewareMixin = MiddlewareMixin()

    # Test that on_response works correctly
    # Create a function to test the on_response
    def onResponse(request, response_or_stream):
        return 'response'

    # Check that on_response is called correctly
    assert middlewareMixin.on_response(middleware=onResponse)

    # Check that on_response is called correctly, with second parameter being 'request'
    assert middlewareMixin.on_response('request').keywords == {'attach_to': 'request'}


# Generated at 2022-06-12 09:13:57.993479
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test')
    test_response = dict()
    test_response['test'] = 'test'

    @app.on_response()
    def response(request, response):
        assert response == test_response
        return response

    app.add_task(lambda: response({}, test_response))
    app.run(debug=True)


# Generated at 2022-06-12 09:14:09.556535
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import InvalidUsage

    app = Sanic("test_MiddlewareMixin_on_response")

    async def request_middleware(request):
        request["request_middleware"] = True

    async def response_middleware(request, response):
        response.headers["response_middleware"] = True

    app.on_request(request_middleware)
    app.on_response(response_middleware)

    @app.route("/")
    async def handler(request):
        return response.text("OK")

    request, response = app.test_client.get("/")

    assert request["request_middleware"] is True

# Generated at 2022-06-12 09:14:10.910793
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    ret = MiddlewareMixin()
    ret = ret.on_response(middleware="")
    assert ret is not None

# Generated at 2022-06-12 09:14:14.560660
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()

    @app.middleware('request')
    async def on_request(request):
        pass

    @app.middleware('response')
    async def on_response(request, response):
        pass

# Generated at 2022-06-12 09:14:17.755353
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin().on_response(middleware) == \
           MiddlewareMixin().middleware(middleware, attach_to="response")


# Generated at 2022-06-12 09:14:18.638212
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass


# Generated at 2022-06-12 09:14:24.435246
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    
    class Tester(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    tester = Tester()
    @tester.on_response
    def hi():
        pass
    
    assert isinstance(tester._future_middleware[0], FutureMiddleware) 
    assert tester._future_middleware[0].middleware == hi
    assert tester._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-12 09:14:27.798498
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic(__name__)

    test = app.on_response(middleware=None)
    assert callable(test)
    assert test.__name__ == 'register_middleware'


# Generated at 2022-06-12 09:14:45.005085
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.route('/1')
    async def handler1(request):
        return json({'test': 'OK'})

    @app.middleware('response')
    def on_response(request, response):
        response.headers['Custom'] = 'Middlware'
        return response

    request, response = app.test_client.get('/1')
    assert response.headers['Custom'] == 'Middlware'



# Generated at 2022-06-12 09:14:50.981368
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    t = TestMiddlewareMixin()
    assert len(t._future_middleware) == 0
    t.middleware(attach_to="request", middleware=lambda request: None)
    assert len(t._future_middleware) == 1
    t.middleware(attach_to="response", middleware=lambda request: None)
    assert len(t._future_middleware) == 2



# Generated at 2022-06-12 09:15:02.349873
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MyMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            assert False

    # tests for @app.middleware('request')
    @MyMiddlewareMixin()
    @MyMiddlewareMixin.middleware()
    @MyMiddlewareMixin.middleware('request')
    def dummy():
        pass

    assert len(MyMiddlewareMixin()._future_middleware) == 3
    assert len(MyMiddlewareMixin._future_middleware) == 3

    # tests for @app.middleware('response')

# Generated at 2022-06-12 09:15:09.416785
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic("middleware")

    assert len(app._future_middleware) == 0

    @app.middleware
    async def middleware1(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0]._middleware == middleware1
    assert app._future_middleware[0]._attach_to == "request"

    @app.middleware("response")
    async def middleware2(request):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1]._middleware == middleware2
    assert app._future_middleware[1]._attach_to == "response"

# Generated at 2022-06-12 09:15:10.310894
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-12 09:15:21.164445
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixinTest(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    m = MiddlewareMixinTest()
    assert not m._future_middleware

    @m.middleware
    async def middleware_test(request):
        pass

    assert len(m._future_middleware) == 1
    assert m._future_middleware[0].middleware == middleware_test
    assert m._future_middleware[0].attach_to == "request"

    @m.middleware('response')
    async def middleware_test2(request):
        pass

    assert len(m._future_middleware) == 2
    assert m._future_middleware[1].middleware == middleware_test2
    assert m._future_middleware[1].attach

# Generated at 2022-06-12 09:15:21.831952
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = MiddlewareMixin()
    app.middleware('request', middleware=None, apply=True)

# Generated at 2022-06-12 09:15:27.398631
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    '''
    Unit test for method middleware of class MiddlewareMixin
    '''

    @MiddlewareMixin.middleware(attach_to="request")
    async def middleware_request(request):
        return request

    @MiddlewareMixin.middleware(attach_to="response")
    async def middleware_response(request, response):
        return response

    assert middleware_request
    assert middleware_response

# Generated at 2022-06-12 09:15:33.489975
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    from sanic.server import HttpProtocol
    server = HttpProtocol()
    server.middleware = MiddlewareMixin()

    @server.middleware
    def middleware_request(request):
        return request

    @server.middleware
    def middleware_response(request, response):
        return response

    assert len(server._future_middleware) == 2
    assert len(server._middleware_stack) == 2

    middleware_request(middleware_response)

# Generated at 2022-06-12 09:15:42.153430
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMid(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            new_middleware = FutureMiddleware(middleware, 'at')
            self._future_middleware.append(new_middleware)

    mid = TestMid()

    @mid.middleware('at1')
    def mid_func(request):
        pass

    @mid.middleware('at2')
    def mid_func2(request):
        pass

    mid_func.__name__ = "mid_func"
    mid_func2.__name__ = "mid_func2"

    assert len(mid._future_middleware) == 2
    assert mid._future_middleware[0].middleware.__name__ == "mid_func"
    assert mid._future_middleware[1].middleware

# Generated at 2022-06-12 09:16:06.211341
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    def mid(request, response):
        return response
    app = Sanic('test_MiddlewareMixin_middleware')
    app.add_task(lambda : None)
    app.middleware(mid)
    assert len(app._future_middleware) == 1
    assert app._future_middleware[-1].attach_to == 'request'
    assert app._future_middleware[-1].future_middleware(None, None) is None



# Generated at 2022-06-12 09:16:08.270113
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # TODO: Actually implement...
    pass


# Generated at 2022-06-12 09:16:09.088447
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert 1 == 1

# Generated at 2022-06-12 09:16:09.587479
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:16:18.818021
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Create a new MiddlewareMixin object.
    MiddlewareMixin_object = MiddlewareMixin()
    # Call method middleware of MiddlewareMixin_object
    # and generate an error if called incorrectly.

# Generated at 2022-06-12 09:16:27.225508
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.middlewareMixin = MiddlewareMixin()
        
        def test_apply_middleware(self):
            with self.assertRaises(NotImplementedError):
                self.middlewareMixin._apply_middleware()

        def test_middleware(self):
            # Test the situation that @middleware('request')
            register_middleware_1 = self.middlewareMixin.on_request(MiddlewareMixin)
            with self.assertRaises(TypeError):
                register_middleware_1()
            # Test the situation that @middleware('request')(middleware)
            register_middleware_2 = self.middlewareMixin.on_request(MiddlewareMixin)

# Generated at 2022-06-12 09:16:38.010737
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Unit test for method middleware of class MiddlewareMixin
    from ..request import Request, RequestParameters

    def test_function():
        pass

    class TestClass:
        def __init__(self) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa
        def middleware(self, middleware_or_request, attach_to="request", apply=True):
            nonlocal test_function

            def register_middleware(middleware, attach_to="request"):
                nonlocal apply

                future_middleware = FutureMiddleware(middleware, attach_to)
                self._future_middleware.append(future_middleware)
                if apply:
                    self._apply_

# Generated at 2022-06-12 09:16:44.214491
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class ListMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(ListMiddlewareMixin,self).__init__()
            self.middleware_list = []
            self._apply_middleware = self._apply_middleware_test
        def _apply_middleware_test(self, middleware: FutureMiddleware):
            self.middleware_list.append(middleware)
    class TestObject:
        pass
    test_object = TestObject()
    # test_object1 = TestObject1()
    test_object.middleware = ListMiddlewareMixin().middleware
    test_object.on_request = ListMiddlewareMixin().on_request
    test_object.on_response = ListMiddlewareMixin().on_response

# Generated at 2022-06-12 09:16:53.391850
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    args = (1, 2)
    kwargs = {'a': 1, 'b': 2}
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(TestMiddlewareMixin, self).__init__(*args, **kwargs)
            self._future_middleware = []
        def on_request_m(self, request):
            return
        def on_response_m(self, request, response):
            return response
        def _apply_middleware(self, middleware: FutureMiddleware):
            return
    test_case = TestMiddlewareMixin(*args, **kwargs)
    middleware_test = test_case.on_request_m

# Generated at 2022-06-12 09:16:58.977240
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic_skeleton.app import middleware
    from sanic_skeleton.app import Application
    from sanic_skeleton.server.middleware import ServerlessMiddleware

    app = Application(middleware=middleware)
    assert isinstance(app.middleware(ServerlessMiddleware), ServerlessMiddleware)
    assert len(app._future_middleware) == 1

# Generated at 2022-06-12 09:17:42.560756
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic import request

    app = Sanic("test_MiddlewareMixin_middleware")
    assert hasattr(app, "middleware")
    assert callable(app.middleware)

    # __call__
    @app.middleware
    async def test_middleware1(request):
        pass

    @app.middleware("response")
    async def test_middleware2(request, response):
        pass

    # attach_to=request
    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[1].attach_to == "response"

    # attach_to=response

# Generated at 2022-06-12 09:17:51.632422
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    '''
    This unit test is for testing method middleware of class MiddlewareMixin
    This method is a decorator for methods of request and response.
    The method middleware can be called in two ways.

    The first way is use middleware as a decorator. We call this way as 'Way 1'

    The second way is use middleware as a decorator with parameters.
    We call this way as 'Way 2'

    The following test case will validate the following points.
    - Way 1 is checked with method middleware by passing a valid
    callable function
    - Way 2 is checked with method middleware by passing a valid
    callable function and a request type
    - Way 1 and Way 2 are checked with method middleware by passing
    invalid callable function

    '''
    _object = MiddlewareMixin()

    def fun():
        return None

# Generated at 2022-06-12 09:17:58.566022
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Fake(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            '''Fake'''
            pass

        def request(self):
            '''Fake'''
            pass

    app = Fake()
    @app.on_request()
    def r(request):
        '''Fake'''
        pass

    @app.middleware('response')
    def m(request, response):
        '''Fake'''
        pass

    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].middleware is r
    assert app._future_middleware[0].attach_to == "request"

# Generated at 2022-06-12 09:18:07.649090
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = MiddlewareMixin()

    class MyMiddleware:
        def __init__(self, attach_to):
            self.attach_to = attach_to

    @app.middleware
    def mw1():
        return MyMiddleware('request')

    @app.middleware('request')
    def mw2():
        return MyMiddleware('request')

    @app.middleware('response')
    def mw3():
        return MyMiddleware('response')

    @app.on_request
    def mw4():
        return MyMiddleware('request')

    @app.on_response
    def mw5():
        return MyMiddleware('response')

    assert len(app._future_middleware) == 5
    assert app._future_middleware[0].middleware_func is mw1

# Generated at 2022-06-12 09:18:11.753286
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.request import Request

    app = Sanic(__name__)

    @app.middleware
    def middleware1(request: Request):
        return print('Middleware 1')

    @app.middleware('response')
    def middleware2(request: Request, response):
        return print('Middleware 2')

    assert len(app._future_middleware) == 2
    assert isinstance(app._future_middleware[0], FutureMiddleware)


# Generated at 2022-06-12 09:18:14.264284
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware): pass
    obj = TestMiddlewareMixin()
    obj.middleware(print)

# Generated at 2022-06-12 09:18:17.662628
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixin_test(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            print("_apply_middleware")
        
    m = MiddlewareMixin_test()
    m.middleware(middleware_or_request=None)
    m.on_request(middleware=None)
    m.on_response(middleware=None)

# Generated at 2022-06-12 09:18:25.340428
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    obj = TestMiddlewareMixin()
    assert obj._future_middleware == []

    @obj.middleware
    def my_middleware(request):
        pass

    assert len(obj._future_middleware) == 1
    assert obj._future_middleware[0].middleware(None) == my_middleware(None)
    assert obj._future_middleware[0].attach_to == "request"

    @obj.middleware
    def my_response_middleware(request, response):
        pass

    assert len(obj._future_middleware) == 2

# Generated at 2022-06-12 09:18:30.936333
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic("middleware_mixin_middleware_test")

    assert len(app._future_middleware) == 0
    @app.middleware
    async def handler(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == handler



# Generated at 2022-06-12 09:18:39.877804
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    class BaseClass:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

    class TestClass(MiddlewareMixin, BaseClass):
        def __init__(self, *args, **kwargs) -> None:
            super(MiddlewareMixin, self).__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    testClass = TestClass()

    def register_middleware(middleware_or_request, attach_to="request"):
        nonlocal testClass

        future_middleware = FutureMiddleware(middleware_or_request, attach_to)
        testClass._future_middleware.append(future_middleware)
        return middleware_or_