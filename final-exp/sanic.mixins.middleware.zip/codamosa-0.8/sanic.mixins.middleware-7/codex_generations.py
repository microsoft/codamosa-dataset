

# Generated at 2022-06-12 09:11:33.404634
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    sanic = Sanic()
    sanic.on_response(middleware=None)
    sanic.on_response(middleware=sanic.__init__)


# Generated at 2022-06-12 09:11:38.243155
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    a = A()
    a.middleware(lambda request: None)
    assert len(a._future_middleware) == 1

    a.on_request(lambda request: None)
    assert len(a._future_middleware) == 2

    a.on_response(lambda request: None)
    assert len(a._future_middleware) == 3

# Generated at 2022-06-12 09:11:43.559917
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.constants import HTTP_METHODS
    from sanic.request import RequestParameters
    from sanic.response import HTTPResponse

    class App(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = App()

    async def middleware_request(request):
        return request

    async def middleware_response(request, response):
        return response

    @app.middleware('request')
    def middleware_decorator(request):
        return request

    @app.middleware('response')
    def middleware_decorator_response(request, response):
        return response

    @app.middleware
    def middleware_decorator(request):
        return request


# Generated at 2022-06-12 09:11:49.058239
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
	server = Sanic('test_Sanic')
	
	@server.middleware
	def my_middleware(request):
		key = request.args.get('key')
		if key != 'value':
			raise Exception("Invalid key")
	
	request, response = server.test_client.get("/")
	
	assert request.args.get('key') == 'value'

# Generated at 2022-06-12 09:11:50.796552
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    def _on_request(self, request):
        pass
    MiddlewareMixin.on_request(_on_request)

# Generated at 2022-06-12 09:11:51.755166
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-12 09:11:59.107107
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            self._future_middleware = []
            self.count = 0

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.count += 1

    m = TestMiddlewareMixin()

    def middleware(request):
        pass

    m.middleware(middleware)
    assert len(m._future_middleware) == 1
    assert m._future_middleware[0].middleware == middleware
    assert m._future_middleware[0].attach_to == "request"
    assert m.count == 1

    m.on_response(middleware)
    assert len(m._future_middleware) == 2
    assert m._future_middleware[1].middleware == middleware
    assert m

# Generated at 2022-06-12 09:12:02.419610
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import sanic
    app = sanic.Sanic()
    method = MiddlewareMixin()
    method._future_middleware = []
    method._apply_middleware = lambda x: None
    method.middleware(lambda x: x)
    assert len(method._future_middleware) == 1



# Generated at 2022-06-12 09:12:02.966831
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

# Generated at 2022-06-12 09:12:03.561474
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    MiddlewareMixin()

# Generated at 2022-06-12 09:12:19.259173
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    app = MiddlewareMixin()
    check = app.on_response()
    assert check("A") == "A"
    assert check.__kwdefaults__['attach_to'] == 'response'
    check = app.on_response("B")
    assert check == "B"
    assert check.__kwdefaults__['attach_to'] == 'response'
    check = app.on_response(lambda a: "C")
    check(lambda a: "D")
    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].name == "C"
    assert app._future_middleware[1].name == "D"
    assert "apply" in check.__kwdefaults__
    assert check.__kwdefaults__['apply'] == True

# Generated at 2022-06-12 09:12:23.224258
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Tmp(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware = middleware
    tmp = Tmp()
    tmp.on_response(lambda req, res: res)
    assert tmp.middleware.attach_to == "response"

# Generated at 2022-06-12 09:12:25.305278
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # MiddlewareMixin, on_response
    assert callable(MiddlewareMixin.on_response)


# Generated at 2022-06-12 09:12:25.883721
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    ...

# Generated at 2022-06-12 09:12:35.220398
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin._future_middleware == [], "_future_middleware should be [] at the beginning of the testing"

    test_middleware1 = MiddlewareMixin() #create instance
    test_middleware2 = MiddlewareMixin() #create instance
    test_middleware3 = MiddlewareMixin() #create instance

    def my_middleware(request):
       print("my_middleware is called")

    def my_middleware1(request):
        print("my_middleware1 is called")
    
    @test_middleware1.on_response(my_middleware)
    def test_middleware1():
        print("test_middleware1")

    @test_middleware2.on_response(my_middleware1)
    def test_middleware2():
        print("test_middleware2")



# Generated at 2022-06-12 09:12:39.350995
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    # test on_response
    mm = TestMiddlewareMixin()
    mm.on_response()
    assert mm._future_middleware

# Generated at 2022-06-12 09:12:50.527420
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import unittest
    import sys
    import os

    # Import sanic project
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from sanic.app import Sanic
    from sanic import response
    from sanic.models.middleware import MiddlewareMixin

    class MyMiddleware(MiddlewareMixin):
        pass

    class MyApp(Sanic):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    test_app = MyApp()

    @test_app.on_response
    def hello_world(self, response):
        response.text = "hello world"


# Generated at 2022-06-12 09:12:59.288898
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol

    app = Sanic("websocket_test")

    @app.middleware("response")
    async def my_middleware_response(request: Request, response: Response):
        return text("Hello from middleware")

    @app.route("/", websocket=True)
    async def handler(request, ws):
        await ws.send("Hello")

    _, response = app.test_client.get("/", protocol=WebSocketProtocol, headers={})
    assert response.status == 400
    assert response.body == b"Hello from middleware"


# Generated at 2022-06-12 09:13:02.558481
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from local.MockApp import MockApp
    from local.MiddlewareExample import MiddlewareExample
    app = MockApp(__name__)
    app.middleware(MiddlewareExample())
    assert app.middleware_count == 2

# Generated at 2022-06-12 09:13:05.089396
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    app_test = MiddlewareMixin()
    assert callable(app_test.on_response())
    # assert app_test.on_response()("test") == None

# Generated at 2022-06-12 09:13:15.391805
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.middleware import MiddlewareMixin

    class MiddlewareMixinTest(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    m = MiddlewareMixinTest()
    m.middleware(lambda x: x+1, 'request')
    assert(m._future_middleware[0].middleware(0)==1)

# Generated at 2022-06-12 09:13:16.805330
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    instance = MiddlewareMixin()
    assert callable(instance.on_response())

# Generated at 2022-06-12 09:13:24.759817
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.models.middleware import MiddlewareMixin
    from sanic.models.futures import FutureMiddleware
    from unittest.mock import Mock

    def test_middleware(mock_obj, request):
        pass
    
    mock_obj = Mock()

    middleware_mixin_obj = MiddlewareMixin()
    middleware_mixin_obj.middleware = Mock()
    middleware_mixin_obj.middleware.return_value = partial(test_middleware, mock_obj)

    result = middleware_mixin_obj.on_response()
    assert isinstance(result, partial)
    assert result.func == test_middleware
    assert result.args == ()
    assert result.keywords == {'mock_obj': mock_obj}

# Generated at 2022-06-12 09:13:29.092595
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response.__name__ == "on_response"
    assert MiddlewareMixin.on_response.__qualname__ == \
        "MiddlewareMixin.on_response"


# Generated at 2022-06-12 09:13:33.738912
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Temp:
        pass

    instance = Temp()
    MiddlewareMixin.__init__(instance)
    assert instance._future_middleware == []

    str1 = 'abc'
    def _attach_to(middleware, attach_to="request"):
        return middleware, attach_to
    def _apply_middleware(future_middleware):
        print('_apply_middleware')
    instance._attach_to = _attach_to
    instance._apply_middleware = _apply_middleware
    decorator = MiddlewareMixin.middleware(instance, str1)(str1)
    rep = decorator(str1)
    assert rep == 'abc'
    assert instance._future_middleware == [('abc', 'abc')]

    decorator = decorator(str1)
    rep = decorator('abc')

# Generated at 2022-06-12 09:13:36.545605
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    @MiddlewareMixin.on_response
    def middleware_1(request, response):
        return response

    assert middleware_1.attach_to == 'response'

# Generated at 2022-06-12 09:13:42.601199
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    # initialization
    app1 = Sanic("sanic-test-on_response")
    class MyResponseMiddleware:
        async def __call__(self, request, response):
            # contents of the middleware
            return "test"
    # set the middleware
    app1.on_response(MyResponseMiddleware())
    assert len(app1._future_middleware) == 1


# Generated at 2022-06-12 09:13:49.392586
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')

    def test_server_error_handler(request, exception):
        # Check if given function as middleware is called
        return text('on_response')
    app.on_response(test_server_error_handler)

    @app.route('/test_MiddlewareMixin_on_response')
    async def test(request):
        # Check if the response of given middleware function is returned
        return text('sanic')

    _, response = app.test_client.get('/test_MiddlewareMixin_on_response')
    assert response.text == 'on_response'
    assert response.status == 200


# Generated at 2022-06-12 09:13:50.010981
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

# Generated at 2022-06-12 09:13:56.026681
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Test_class(MiddlewareMixin):
        def __init__(self):
            super(Test_class, self).__init__()

    a = Test_class()
    assert a.on_response().__class__.__name__ == "partial"
    assert a.on_response().keywords["attach_to"] == "response"


# Generated at 2022-06-12 09:14:16.646498
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.models.futures import FutureMiddleware
        
    app = Sanic()
    app._apply_middleware = MagicMock()
    
    @app.middleware('request')
    def test_request(request):
        pass
        
    @app.middleware('response')
    def test_response(request, response):
        pass
        
    @app.middleware('error')
    def test_error(request, response):
        pass
        
    @app.middleware
    def test_normal(request):
        pass
        
    response_middleware = FutureMiddleware(
        test_response, 'response'
    )
    request_middleware = FutureMiddle

# Generated at 2022-06-12 09:14:17.295017
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:14:21.801991
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('Sanic')

    @app.middleware('response')
    async def halt(request):
        return request.environ
    
    assert halt.__name__ in app._future_middleware[0].middleware.__name__
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-12 09:14:31.042704
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.request import Request

    async def middleware_processor(request: Request):
        return text('OK')

    app = Sanic("MiddlewareMixin_middleware")
    app.middleware(middleware_processor)

    assert len(app._future_middleware) == 1
    assert len(app.request_middleware) == 0
    assert len(app.response_middleware) == 0

    app.request["middleware"] = app.middleware._apply
    req: Request = Request(b"GET", "/", {}, b"")

    resp = app.request["middleware"](req)
    assert resp.body == b'OK'
    assert resp.text == 'OK'


# Generated at 2022-06-12 09:14:40.080157
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import pytest
    from sanic import Sanic
    
    class MyMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass
    
    app = Sanic(__name__)
    app.__class__ = MyMiddlewareMixin
    app_middleware = app.middleware

    # Verify a parameter middleware is a callable.
    @app.middleware
    def middleware(request):
        pass

    assert isinstance(middleware, partial)

    # Verify if the attach_to of middleware is 'request'.
    @app.middleware('request')
    def middleware_request(request):
        pass

    assert isinstance(middleware_request, partial)
    assert middleware_request.args[1] == 'request'

    # Verify if the attach

# Generated at 2022-06-12 09:14:44.021842
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic("test_MiddlewareMixin_middleware")
    request_middleware = app.on_request(
        lambda request: print("request middleware called")
    )
    response_middleware = app.on_response(
        lambda response: print("response middleware called")
    )

    assert request_middleware
    assert response_middleware
    assert app._future_middleware
    assert len(app._future_middleware) == 2

# Generated at 2022-06-12 09:14:45.625833
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    Sanic().middleware(middleware_or_request='response')

# Generated at 2022-06-12 09:14:51.830282
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import unittest
    from unittest.mock import MagicMock
    class mock_middleware:
        pass
    # TODO: maybe a mock class implementing MiddlewareMixin will be better here?
    m_MiddlewareMixin = MiddlewareMixin()
    m_MiddlewareMixin._apply_middleware = MagicMock()
    m_middleware = mock_middleware()
    m_MiddlewareMixin.middleware(m_middleware)
    m_MiddlewareMixin._apply_middleware.assert_called_once()



# Generated at 2022-06-12 09:15:03.429402
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import pytest
    from sanic import app
    from sanic.exceptions import InvalidUsage

    @app.middleware("request")
    def request_middleware(request):
        """ method request_middleware """
        pass

    @app.middleware("response")
    def response_middleware(request, response):
        """ method response_middleware """
        pass


    class TestMiddleware:

        def test_request_middleware(self):
            @app.middleware("request")
            def request_middleware_func(request):
                assert request is True

            middleware = FutureMiddleware(request_middleware_func, "request")
            assert type(middleware) == FutureMiddleware
            assert middleware.middleware(True) is True


# Generated at 2022-06-12 09:15:11.893136
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic_middleware_cors import CORSMiddleware
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import text

    app = Sanic('middleware_test')
    app.blueprint(bp)

    @app.middleware
    def test_middleware(request):
        return text('OK')

    assert app.request_middleware == [app.router.middleware['request'][0]]
    assert app.response_middleware == [app.router.middleware['response'][0]]
    assert app._request_middleware == [app.router._middleware['request'][0]]
    assert app._response_middleware == [app.router._middleware['response'][0]]
    assert app.middleware