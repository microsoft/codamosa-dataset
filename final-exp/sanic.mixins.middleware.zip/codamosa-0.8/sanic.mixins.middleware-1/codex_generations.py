

# Generated at 2022-06-12 09:11:37.488110
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    middleware_op = Sanic().middleware(middleware_or_request=None)
    assert middleware_op(middleware=None) is not None


# Generated at 2022-06-12 09:11:38.279987
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin().on_response()

# Generated at 2022-06-12 09:11:39.387214
# Unit test for method middleware of class MiddlewareMixin

# Generated at 2022-06-12 09:11:46.977160
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.server import HttpProtocol
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware('request')
    async def request_middleware(request):
        request.ctx.test = 'middleware'
        return request
    @app.route('/')
    async def handler1(request):
        return text('OK', status=200)
    request, response = app.test_client.get('/')
    assert response.status == 200
    assert request.ctx.test == 'middleware'


# Generated at 2022-06-12 09:11:51.591017
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic

    app = Sanic(__name__)

    @app.on_response
    def test_response(request, response):
        pass

    app.add_task(test_response)
    app.add_task(test_response)

    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].attach_to == "response"



# Generated at 2022-06-12 09:12:02.013920
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.exceptions import SanicException
    from sanic.models.futures import FutureMiddleware
    from sanic.views import HTTPMethodView
    from sanic.response import json, text

    def response_middleware(request, response):
        assert isinstance(response, SanicException)
        return json({"easy": "peasy lemon squeezy"})

    class MyHttpView(HTTPMethodView):
        @staticmethod
        def get(request):
            return text("I'm not found.")

    app = Sanic("test_MiddlewareMixin_on_response")
    app.add_route(MyHttpView.as_view(), '/')
    app.on_response(response_middleware)

# Generated at 2022-06-12 09:12:11.070925
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import pytest
    from sanic import Sanic, response
    from sanic.request import Request

    # Set up
    @MiddlewareMixin.on_response
    async def response_middleware(request: Request, response: Response):
        return response

    # Test
    assert response_middleware(lambda request, response: response) == response_middleware

    # Set up
    class MySanic(MiddlewareMixin, Sanic):
        def __init__(self, *args, **kwargs):
            MiddlewareMixin.__init__(self, *args, **kwargs)
            Sanic.__init__(self, *args, **kwargs)
    
    # Test
    my_app = MySanic()
    response_middleware(my_app)

    # Set up

# Generated at 2022-06-12 09:12:14.544757
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    app = MiddlewareMixin()
    def middleware(request):
        pass
    app.on_response(middleware)
    assert app._future_middleware[0]._attach_to == 'response'

# Generated at 2022-06-12 09:12:16.681749
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response("response")



# Generated at 2022-06-12 09:12:28.637582
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Dummy class
    class DummyClass:
        a = 10
        b = 10

    # Call method middleware of class MiddlewareMixin
    DummyClass.middleware = MiddlewareMixin.middleware
    DummyClass.on_request = MiddlewareMixin.on_request
    DummyClass.on_response = MiddlewareMixin.on_response
    instance = DummyClass()

    # middleware('request')
    dummy_function1 = lambda x: x + 1
    instance.middleware(dummy_function1, attach_to='request')
    assert isinstance(instance._future_middleware[0], FutureMiddleware)
    assert instance._future_middleware[0].listener == dummy_function1
    assert instance._future_middleware[0].attach_to == 'request'
    # middleware('response

# Generated at 2022-06-12 09:12:32.338566
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    base_app = MiddlewareMixin()
    base_app.on_response()

# Unit tes for method on_request of class MiddlewareMixin

# Generated at 2022-06-12 09:12:41.334181
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    """
    This method is testing the on_response method of the class MiddlewareMixin
    """
    app = MockSanic()
    """app = MockSanic()
    This mock object is creating and testing for the on_response method of the class MiddlewareMixin
    """
    class TestClass(MiddlewareMixin):
        pass

    test_class = TestClass()
    """test_class = TestClass()
    This tests the TestClass class and its methods/attributes
    """
    assert test_class.on_response(middleware=app.blue) == test_class.middleware(app.blue, "response")
    """
    This tests if that the on_response method of the TestClass class was created successfully if it is equal to the method middleware("response")
    """

# Generated at 2022-06-12 09:12:49.880486
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import text

    def my_middleware(request):
        return text('request_middleware')


    async def handler(request):
        return text('OK')

    app = Sanic('test_MiddlewareMixin_on_response')
    app.add_route(handler, '/')

    app.on_response(my_middleware)

    request, response = app.test_client.get('/')

    assert response.text == 'request_middleware'


# Generated at 2022-06-12 09:12:52.656165
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    def middleware(request):
        pass
    Sanic("test").on_response(middleware)


# Generated at 2022-06-12 09:12:55.784227
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    app = sanic.Sanic("test_MiddlewareMixin_on_response")

    app.on_response("response")

    assert app._future_middleware[0].attach_to == "response"

# Generated at 2022-06-12 09:13:05.133941
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from unittest import TestCase
    from sanic.server import HttpProtocol
    from sanic.models.http import HttpRequest, HttpResponse

    import asyncio
    from unittest.mock import patch, MagicMock
    from unittest.mock import Mock as mock

    class fake_sanic_app(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            return

    class TestMiddleware(TestCase):
        def setUp(self) -> None:
            self.app = fake_sanic_app()

        def tearDown(self) -> None:
            self.app = None


# Generated at 2022-06-12 09:13:05.931725
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

# Generated at 2022-06-12 09:13:08.104739
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response('hoge')==partial(MiddlewareMixin.middleware, attach_to="response")

# Generated at 2022-06-12 09:13:18.465672
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Create a request instance
    req = Request({
        'type': 'http',
        'headers': [('Host', 'example.com')],
        'args': {},
        'cookies': {},
        'data': b'',
        'files': {},
        'form': {},
        'parsed_json': None,
        'parsed_args': {},
    },
    socket_info={
        'socket': 'socket'
    },
    app=None,
    transport=None,
    protocol=None)
    # Test if req is a request
    assert isinstance(req, Request)
    # Create a response instance
    resp = HTTPResponse(b'', status=0)
    # Test if resp is a response
    assert isinstance(resp, HTTPResponse)


# Generated at 2022-06-12 09:13:23.057989
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class ClassTest(MiddlewareMixin):
        def __init__(self):
            super().__init__()

    @ClassTest.on_response()
    def method1():
        return

    @ClassTest.on_response()
    def method2():
        return

    ClassTest()._future_middleware[0]._attach_to == "response"
    ClassTest()._future_middleware[1]._attach_to == "response"

# Generated at 2022-06-12 09:13:32.805786
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    class MiddlewareMixinMock(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            pass

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    MiddlewareMixinMock()
    app = Sanic(__name__)
    app.middleware(None)

# Generated at 2022-06-12 09:13:38.276406
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.response import json

    class A(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(A, self).__init__(*args, **kwargs)

    a = A()
    @a.middleware
    def test(request):
        return json({'test': 1})

    a._future_middleware[0].middleware(None)

# Generated at 2022-06-12 09:13:43.215407
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixinTestClass(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            assert middleware == FutureMiddleware(middleware, "request")

    obj = MiddlewareMixinTestClass()
    obj.middleware(middleware=FutureMiddleware, attach_to="request")



# Generated at 2022-06-12 09:13:46.804167
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    mixer.blend(MiddlewareMixin)
    app = mixer.blend(Sanic)
    def login_required(request):
        return True
    app._future_middleware.append(FutureMiddleware(login_required, 'request'))
    




# Generated at 2022-06-12 09:13:53.939883
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import HTTPResponse

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def test(request):
        return HTTPResponse('test')

    @app.get('/')
    def handle_request(request):
        return HTTPResponse('ok')

    request, response = app.test_client.get('/')
    assert response.text == 'ok'
    assert response.status == 200



# Generated at 2022-06-12 09:13:59.666301
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    
    def middleware(request):
        print("middleware")
        pass

    def middleware1(request):
        print("middleware1")
        pass

    m = MiddlewareMixin()
    m.middleware(middleware)()
    m.middleware(middleware, attach_to='response')()
    m.middleware(middleware1, attach_to='response')()
    m.middleware(middleware, attach_to='request')()



# Generated at 2022-06-12 09:14:07.145513
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    class MockMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(MockMiddlewareMixin, self).__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            print('---apply middleware---')

    mock = MockMiddlewareMixin()

    @mock.middleware
    def mid(request):
        print('middleware request ...')
        return request

    assert mock._future_middleware != []
    
    

# Generated at 2022-06-12 09:14:14.107731
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()

    try:
        app.middleware(None, None)
    except NotImplementedError:
        pass
    else:
        raise Exception("Should return NotImplementedError")

    middleware = lambda request: None
    assert app.middleware(middleware, attach_to="request") == middleware
    assert app.middleware(middleware, attach_to="response") == middleware



# Generated at 2022-06-12 09:14:16.202800
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # init the class
    obj = MiddlewareMixin()
    # the function is not implemented yet, so we expect to raise NotImplementedError
    with pytest.raises(NotImplementedError):
        # call the function
        obj._apply_middleware()



# Generated at 2022-06-12 09:14:22.193581
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app_class = Sanic

    app = app_class(__name__, load_env=False)

    @app.middleware('request')
    async def handler(request):
        pass

    @app.middleware
    async def handler2(request):
        pass

    assert len(app._future_middleware) == 2

    @app.middleware('request')
    def handler3(request):
        pass

    assert len(app._future_middleware) == 3

# Generated at 2022-06-12 09:14:35.221316
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixinTest:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    test_MiddlewareMixin_object = MiddlewareMixinTest()
    @test_MiddlewareMixin_object.middleware
    async def middlewareTest(request):
        return True
    assert middlewareTest(None)
    assert test_MiddlewareMixin_object._future_middleware != None 


# Generated at 2022-06-12 09:14:40.709920
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    def request_middleware(request):
        request['value'] = 'request_middleware'

    def response_middleware(request, response):
        response.text += request['value']

    app = Sanic('test_MiddlewareMixin_middleware')
    app.register_middleware(request_middleware, 'request')
    app.register_middleware(response_middleware, 'response')

    @app.route('/')
    def handler(request):
        return text('response')

    request, response = app.test_client.get('/')
    assert response.text == 'responserequest_middleware'


# Generated at 2022-06-12 09:14:45.470159
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass
    m = TestMiddlewareMixin()
    @m.on_request()
    async def before_request():
        pass
    @m.on_response()
    async def after_response():
        pass
    assert len(m._future_middleware) == 2
    assert m._future_middleware[0].attach_to == "request"
    assert m._future_middleware[0].handler == before_request
    assert m._future_middleware[1].attach_to == "response"
    assert m._future_middleware[1].handler == after_response

# Generated at 2022-06-12 09:14:53.532458
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import unittest

    class test_MiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError

    class test_middleware(unittest.TestCase):
        def test_middleware(self):
            self.assertEqual(MiddlewareMixin._future_middleware, [])
            self.assertEqual(
                MiddlewareMixin.middleware,
                self.MiddlewareMixin_middleware,
            )


# Generated at 2022-06-12 09:14:54.412508
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert MiddlewareMixin.middleware

# Generated at 2022-06-12 09:14:56.550836
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    try:
        MiddlewareMixin().middleware(None)
    except NotImplementedError:
        pass


# Generated at 2022-06-12 09:15:08.223705
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestData:
        pass
    
    class DummyMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    dummyMiddlewareMixin = DummyMiddlewareMixin()
    testData = TestData()
    testData.middleware = dummyMiddlewareMixin.middleware
    testData.on_request = dummyMiddlewareMixin.on_request
    testData.on_response = dummyMiddlewareMixin.on_response

    # Test middleware
    @testData.middleware
    def func1(request):
        return 'I am func1!'
    assert func1(None) == 'I am func1!'
    assert dummyMiddlewareMixin._future_middleware[0].middleware(None) == 'I am func1!'
    assert dummy

# Generated at 2022-06-12 09:15:10.321206
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = MiddlewareMixin()
    def mw(request):
        request.a = 'b'
        return request
    app.middleware(mw)
    request = app.request_class(app, '')
    assert request.a == 'b'


# Generated at 2022-06-12 09:15:13.987507
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    app.__class__ = type
    app.__class__.__bases__ = (MiddlewareMixin, )
    app._apply_middleware = lambda middleware: None

# Generated at 2022-06-12 09:15:18.199743
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # GIVEN: Initialize class
    class View(MiddlewareMixin):
        pass

    # WHEN: Call method middleware
    # THEN: An exception should be raised
    with pytest.raises(NotImplementedError):
        _ = View().middleware(None)

# Generated at 2022-06-12 09:15:36.044185
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    import sys, os
    sys.path.append(os.path.dirname(os.path.abspath(os.path.dirname(__file__))))
    from main import app
    def middleware_response(request):
        pass
    def middleware_request(request):
        pass
    result = app.middleware(middleware_request, attach_to="request")
    print("test_MiddlewareMixin_middleware result : ", result)
    result = app.middleware(middleware_response, attach_to="response")
    print("test_MiddlewareMixin_middleware result : ", result)
    # result = (middleware_request, middleware_response)


# Generated at 2022-06-12 09:15:43.013999
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    mw = MiddlewareMixin()
    mw.middleware(middleware_or_request=True, attach_to='request')
    mw.middleware(lambda x: x, attach_to='request')
    mw.middleware(middleware_or_request=True, attach_to='request', apply=True)
    mw.middleware(lambda x: x, attach_to='request', apply=True)
    mw.middleware = lambda x: x
    mw.middleware = partial(lambda x: x, attach_to='request')


# Generated at 2022-06-12 09:15:53.276255
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.exceptions import RequestTimeout

    app = Sanic('test')

    @app.middleware  # noqa
    async def print_on_request(request):
        print('I run before every request')

    @app.middleware('request')  # noqa
    async def halt_request_if_too_slow(request):
        if request.timeout > 0.2:
            raise RequestTimeout('That took too long')


    @app.middleware('response')  # noqa
    async def print_on_response(request, response):
        print('I run after every response')
        return response


# Generated at 2022-06-12 09:15:59.793865
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.request import Request

    app = Sanic()

    @app.middleware('request')
    async def middleware1(request):
        return 1
    
    def middleware2(request):
        return 2

    @app.middleware()
    async def middleware3(request):
        return 3

    middleware4 = app.middleware(attach_to='response')
    @middleware4
    async def middleware5(request, response):
        return 5

    assert issubclass(MiddlewareMixin, object)
    assert str(MiddlewareMixin) == "<Class MiddlewareMixin>"
    assert repr(MiddlewareMixin) == "<Class MiddlewareMixin>"
    assert len(app._future_middleware) == 4

# Generated at 2022-06-12 09:16:09.777475
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    def request_middleware(request: Request):
        assert request is not None # noqa

    def response_middleware(request: Request, response: HTTPResponse):
        assert request is not None # noqa
        assert response is not None # noqa

    # test callable with attach_to
    app = Sanic('test_sanic')
    app.middleware(request_middleware, attach_to='request')
    app.middleware(response_middleware, attach_to='response')
    assert app._future_middleware is not None # noqa
    assert len(app._future_middleware) == 2 # noqa

    # test callable without attach_to
    app = Sanic

# Generated at 2022-06-12 09:16:19.182229
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Sanic:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    Sanic.__bases__ = (MiddlewareMixin,)

    @Sanic.middleware('request')
    def request(request):
        pass

    @Sanic.middleware('response')
    def response(request, response):
        pass

    @Sanic.middleware
    def dummy(request):
        pass

    @Sanic.on_request
    def request_triggered(request):
        pass

    @Sanic.on_response
    def response_triggered(request, response):
        pass

   

# Generated at 2022-06-12 09:16:27.422904
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.response import json

    class dummy_MiddlewareMixin:
        def __init__(self):
            self.middleware_func = lambda request: json("middleware")
            self.on_request_func = lambda request: json("on_request")
            self.on_response_func = lambda request: json("on_response")

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    mixin = dummy_MiddlewareMixin()
    mixin.middleware(mixin.middleware_func)
    assert len(mixin._future_middleware) == 1

    mixin = dummy_MiddlewareMixin()
    mixin.on_request(mixin.on_request_func)
    assert len(mixin._future_middleware) == 1

    mixin = dummy_Middle

# Generated at 2022-06-12 09:16:34.418146
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    @MiddlewareMixin.middleware
    def my_middleware(request):
        pass
    
    @MiddlewareMixin.on_request
    def my_request_middleware(request):
        pass

    @MiddlewareMixin.on_response
    def my_response_middleware(request, response):
        pass


if __name__ == "__main__":
    test_MiddlewareMixin_middleware()

# Generated at 2022-06-12 09:16:42.118608
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import sanic
    app = sanic.Sanic("sanic-server")
    mw = MiddlewareMixin("sanic-server")
    mw.middleware("response")("response-middleware")
    mw.middleware("request")("request-middleware")

    assert mw._future_middleware[0][0] == "request-middleware"
    assert mw._future_middleware[0][1] == "request"
    assert mw._future_middleware[1][0] == "response-middleware"
    assert mw._future_middleware[1][1] == "response"


# Generated at 2022-06-12 09:16:51.509052
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    class TestMiddlewareMixin(MiddlewareMixin):
        pass
    test_app = TestMiddlewareMixin()

    assert len(test_app._future_middleware) == 0

    @test_app.middleware('request')
    def test_request_middleware(request):
        pass

    assert len(test_app._future_middleware) == 1
    assert (
        test_app._future_middleware[0].attach_to == "request"
    ), "attach_to should be 'request'"

    @test_app.middleware('response')
    def test_response_middleware(request, response):
        pass

    assert len(test_app._future_middleware) == 2

# Generated at 2022-06-12 09:17:14.708869
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class middleware(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            self._future_middleware = FutureMiddleware('middleware', 'request')
    obj = middleware()
    assert callable(obj)
    assert obj.__dict__['_future_middleware'] == FutureMiddleware(
        'middleware', 'request')



# Generated at 2022-06-12 09:17:18.226343
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestClass(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    app = TestClass()
    @app.on_request
    @app.on_response
    def middleware(request):
        pass

# Generated at 2022-06-12 09:17:25.717635
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Case 1: @app.middleware()
    # Case 2: @app.middleware('request')
    # Case 3: @app.middleware('response')
    # Case 4: @app.middleware(middleware_or_request, attach_to= 'request')
    # Case 5: @app.middleware(middleware_or_request, attach_to= 'response')
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, middleware):
            raise NotImplementedError  # noqa

    app = TestMiddlewareMixin()

    # Test Case 1
    @app.middleware()
    def middleware1(request):
        print("Run middleware1")


# Generated at 2022-06-12 09:17:34.107744
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    class Test_app(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    Test_app_Instance = Test_app()
    test_middleware = Test_app_Instance.middleware
    test_future_middleware = Test_app_Instance._future_middleware
    def func():
        pass
    func = test_middleware(func)
    func()
    assert len(test_future_middleware) == 1
    assert test_future_middleware[0].middleware == func
    assert test_future_middleware[0].attach_to == "request"
    assert test_future_middleware[0].app == Test_app_Instance

    func2 = test_middleware(func, attach_to="response")
    assert len

# Generated at 2022-06-12 09:17:41.146352
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware  # type: ignore
    async def pre_handler_function(request):
        pass

    assert app._future_middleware[0].middleware == pre_handler_function
    assert app._future_middleware[0].attach_to == "request"

    @app.middleware('response')  # type: ignore
    def post_handler_function(request, response):
        pass

    assert app._future_middleware[2].middleware == post_handler_function
    assert app._future_middleware[2].attach_to == "response"

# Generated at 2022-06-12 09:17:41.998594
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert MiddlewareMixin

# Generated at 2022-06-12 09:17:51.055222
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Subclass(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            self._return_value = middleware

        def __init__(self, *args, **kwargs) -> None:
            self._return_value = None
            super().__init__(*args, **kwargs)

    sp = Subclass()
    assert sp._future_middleware == []
    def mware(request):
        return request
    sp.middleware(mware)
    assert len(sp._future_middleware) == 1
    assert isinstance(sp._future_middleware[0],FutureMiddleware)
    sp.middleware(attach_to="request")(mware)
    assert len(sp._future_middleware) == 2

# Generated at 2022-06-12 09:17:55.733698
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.server import Sanic

    app = Sanic("test_sanic")

    def test_middleware(request):
        request["data"] = "request"

    app.middleware(test_middleware, attach_to="request")

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-12 09:17:56.809141
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = Sanic(__name__)
    assert app._future_middleware == []



# Generated at 2022-06-12 09:17:59.087290
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert callable(MiddlewareMixin.middleware)
    assert callable(MiddlewareMixin.on_request)
    assert callable(MiddlewareMixin.on_response)