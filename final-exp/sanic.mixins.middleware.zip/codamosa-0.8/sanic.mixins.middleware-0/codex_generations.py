

# Generated at 2022-06-12 09:11:46.454759
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # FutureWarning: The create_server() method is a coroutine and
    # should be called with await
    # I don't now why but this method is not a coroutine
    # I'll fix it later
    a = MiddlewareMixin()
    b = a.on_response()
    assert b == partial(a.middleware, attach_to="response")

# Generated at 2022-06-12 09:11:47.071292
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin() is not None

# Generated at 2022-06-12 09:11:49.635519
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Set up
    app = sanic.Sanic()
    test = MiddlewareMixin()

    # Test that the method returns a partial function
    assert isinstance(test.on_response(), partial)

# Generated at 2022-06-12 09:11:58.100338
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic, Blueprint
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    # create fake app to call the method of clas MiddlewareMixin
    class FakeApp(MiddlewareMixin, object):
        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware = middleware
            return middleware
    app = FakeApp()
    # create fake request and response to test middleware
    async def fake_request(request):
        return "FakeRequest"
    async def fake_response(request, response):
        return response
    # fake the function of add_route
    def fake_add_route(location):
        app.location = location
        return location

# Generated at 2022-06-12 09:12:08.429912
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware
    from sanic.log import logger

    class CustomSanic(Sanic):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    # @middleware
    app = CustomSanic(__name__)

    @app.middleware
    def middleware1(request):
        logger.info("middleware1-1")

    # @middleware('request')

# Generated at 2022-06-12 09:12:16.949317
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Test:
        def f(self):
            return 0
        def g(self):
            return 1

    middlewareMixin = MiddlewareMixin()
    assert middlewareMixin._future_middleware == []
    assert middlewareMixin.on_response(middleware=Test().g) == MiddlewareMixin.middleware
    assert middlewareMixin._future_middleware == [MiddlewareMiddleware(Test().g, 'response')]

if __name__ == "__main__":
    print("\033[1;32;40m\n=== Run unit test: MiddlewareMixin ===\n\033[0;37;40m")
    _test()

# Generated at 2022-06-12 09:12:22.589691
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Setup
    class TestClass(MiddlewareMixin):
        def __init__(self):
            super().__init__()
    
    obj = TestClass()

    # Exercise
    result = obj.on_response(lambda x: x)
    assert (result.func == obj.middleware)
    
    # Cleanup - None

# Generated at 2022-06-12 09:12:32.956442
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Arrange
    from unittest.mock import Mock
    from unittest.mock import call
    from unittest.mock import patch
    from unittest.mock import MagicMock
    mm = MiddlewareMixin()
    mm.middleware = Mock()
    mm.middleware.return_value = None
    m0 = Mock()
    m1 = Mock()
    m2 = Mock()
    mm.middleware.return_value.assert_has_calls(call(m1, 'response'))

    # Act
    mm.on_response(m0, m1, m2)

    # Assert
    mm.middleware.assert_has_calls([call(m0, 'response'),call(m1, 'response'), call(m2, 'response')])



# Generated at 2022-06-12 09:12:37.108829
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import InvalidUsage, RequestTimeout

    app = Sanic(__name__)
    @app.middleware('request')
    async def before_request(request):
        return json({'before': 'request'})

    request, response = app.test_client.get('/')
    assert response.json == {'before': 'request'}

# Generated at 2022-06-12 09:12:47.229415
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import types
    import unittest

    from sanic import _main as main

    # TODO: This is a bit of a flaky test
    class Main(main.Main):
        pass

    class TestCase(unittest.TestCase):
        pass

    app = Main(__name__)

    @app.on_response
    def _middleware_function(request, response):
        return response

    @app.on_response(None)
    def _middleware_function2(request, response):
        return response

    @app.on_response(attach_to="junk")
    def _middleware_function3(request, response):
        return response

    test_case = TestCase()

    test_case.assertIsInstance(_middleware_function, types.FunctionType)

# Generated at 2022-06-12 09:12:59.324284
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestClass(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    # instantiate class TestClass and test method middleware
    test_instance = TestClass()
    middleware_or_request = 'request'
    attach_to = 'request'
    apply = True
    test_instance.middleware(middleware_or_request, attach_to, apply)
    assert not test_instance._future_middleware


# Generated at 2022-06-12 09:13:01.095775
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # TODO: Add unit test
    """
    def test_MiddlewareMixin_middleware():
    """
    pass

# Generated at 2022-06-12 09:13:10.753348
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Mock:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
            
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    obj = Mock()
    obj.middleware = MiddlewareMixin.middleware
    obj.on_request = MiddlewareMixin.on_request
    obj.on_response = MiddlewareMixin.on_response

    @obj.middleware
    def mock_middleware(request):
        pass

    assert len(obj._future_middleware) == 1
    assert obj._future_middleware[0].handler == mock_middleware
    assert obj._future_middleware[0].attach_to == "request"

# Generated at 2022-06-12 09:13:20.946685
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.models.futures import FutureMiddleware
    from sanic.log import log
    from sanic.exceptions import ServerError
    
    app = Sanic(__name__)
    # Example of a request middleware
    @app.middleware("response")
    def print_on_response(request, response):
        log.info("I print when a response is returned")

    @app.middleware("request")
    def halt_request(request):
        raise ServerError("I halt any request that comes in")

    @app.route("/")
    async def test(request):
        return json({"hello": "world"})
    

# Generated at 2022-06-12 09:13:22.648651
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # 了解所有的入参和返回值
    assert False


# Generated at 2022-06-12 09:13:34.649522
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    import asyncio

    app = Sanic("test_sanic")

    @app.middleware("request")
    async def request_middleware(request):
        print("request_middleware")
        await asyncio.sleep(0.5)

    @app.middleware("response")
    async def response_middleware(request, response):
        print("response_middleware")
        await asyncio.sleep(0.5)

    @app.route("/")
    async def handler(request):
        print("handler")
        return text("OK")

    @app.listener("before_server_start")
    def start(sanic, loop):
        print("before_server_start")

# Generated at 2022-06-12 09:13:44.841717
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    import pytest
    from pytest_mock import mocker
    from sanic.response import json
    import json
    import asyncio
    app = Sanic('test_MiddlewareMixin_middleware')
    app.config.LOGO = None
    app.config.REQUEST_MAX_SIZE = 100000000
    app.config.REQUEST_BUFFER_QUEUE_SIZE = 100
    app.config.REQUEST_TIMEOUT = 120
    app.config.RESPONSE_TIMEOUT = 120
    app.config.KEEP_ALIVE = True
    app.config.KEEP_ALIVE_TIMEOUT = 5
    app.config.GRACEFUL_SHUTDOWN_TIMEOUT = 15
    app.config.ERROR_LOGGER = True
    app.config.ACCESS_LOG

# Generated at 2022-06-12 09:13:53.026070
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic(__name__)

    @app.middleware('request')
    async def request(request):
        request['middleware'] = 'request'

    @app.middleware('response')
    async def response(request, response):
        response['middleware'] = 'response'
    
    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json['middleware'] == 'response'
    assert request['middleware'] == 'request'

# Generated at 2022-06-12 09:13:53.601274
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:13:54.342146
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:14:05.801672
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    print ()
    app = MiddlewareMixin()
    assert isinstance(app, MiddlewareMixin)
    assert app._future_middleware == []
    middleware_handler = app.middleware(middleware_or_request=None)
    assert isinstance(middleware_handler, partial)
    assert middleware_handler.args == (None,)
    assert middleware_handler.keywords == {"attach_to": "request", "apply": True}
    assert isinstance(middleware_handler.func, partial)
    assert middleware_handler.func.args == ()
    assert middleware_handler.func.keywords == {"attach_to": None}
    assert isinstance(middleware_handler.func.func, type(MiddlewareMixin.middleware))
    middleware_handler2 = app.middleware(attach_to="request")

# Generated at 2022-06-12 09:14:06.852181
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-12 09:14:14.805196
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic("x")

    @app.middleware("response")
    def response_middleware(request, response):
        assert isinstance(response, dict)
        assert "response" in response
        response["response"] = "Middleware"
        return request, response

    @app.route("/")
    def handler(request):
        return {"response": "OK"}

    _, response = app.test_client.get("/")
    assert response.status == 200
    assert response.json["response"] == "Middleware"



# Generated at 2022-06-12 09:14:23.894471
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic("sanic-server")
    @app.middleware
    def middleware(request):
        pass
    assert app._future_middleware[0].middleware == middleware

    @app.middleware('request')
    def request_middleware(request):
        pass    
    assert app._future_middleware[1].middleware == request_middleware
    assert app._future_middleware[1].attach_to == 'request'

    @app.middleware('response')
    def response_middleware(request, response):
        pass
    assert app._future_middleware[2].middleware == response_middleware
    assert app._future_middleware[2].attach_to == 'response'

# Generated at 2022-06-12 09:14:28.676432
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Setup MiddlewareMixin
    MiddlewareMixin = MiddlewareMixin
    middleware_mixin = MiddlewareMixin()

    # Setup function middleware
    def middleware(): pass

    # Call method middleware
    middleware_mixin_middleware_result = middleware_mixin.middleware(middleware, "response")
    assert middleware_mixin_middleware_result == middleware

# Generated at 2022-06-12 09:14:37.530801
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App(MiddlewareMixin):
        def __init__(self):
            MiddlewareMixin.__init__(self)

    app = App()

    @app.on_request
    async def request_middleware(request):
        pass

    @app.on_response
    async def response_middleware(request, response):
        pass

    @app.middleware
    async def other_middleware(request):
        pass

    assert len(app._future_middleware) == 3
    assert app._future_middleware[0].registered_at == "request"
    assert app._future_middleware[1].registered_at == "response"
    assert app._future_middleware[2].registered_at == "request"

# Generated at 2022-06-12 09:14:41.351305
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    @app.middleware("request")
    def request_middleware_f(request):
        return request

    assert request_middleware_f == app._future_middleware[0].middleware

# Generated at 2022-06-12 09:14:46.648704
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    class CustomSanic(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(CustomSanic, self).__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = CustomSanic()

    @app.middleware
    def test_middleware_without_attach(request):
        pass

    @app.middleware('request')
    def test_middleware_with_request(request):
        pass

    @app.middleware('response')
    def test_middleware_with_response(request, response):
        pass

    @app.on_response
    def test_middleware_on_response(request, response):
        pass

    _expected_middle

# Generated at 2022-06-12 09:14:49.250259
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    @MiddlewareMixin.middleware('test')
    def test_middleware(request):
        print('test succeed!')
    
    test_middleware()
    print('test middleware succeed!')



# Generated at 2022-06-12 09:14:55.572644
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Sanic_app(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = Sanic_app()
    @app.middleware('request')
    async def request_middleware(request):
        print("before request")
        await print("after request")
        return print("before response")

    @app.middleware('response')
    async def response_middleware(request, response):
        print("before response")
        await print("after response")
        return print("before request")

    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[1].middleware == response_middleware

    
    

# Generated at 2022-06-12 09:15:12.892498
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Initialize a instance of class MiddlewareMixin for test
    test_instance = MiddlewareMixin()

    # Test method middleware of class MiddlewareMixin if function middleware_or_request is callable
    # Set arguments of function middleware_or_request
    def middleware_or_request(request, response):
        pass
    def attach_to(request, response):
        pass

    # Call function middleware of class MiddlewareMixin
    object_middleware = test_instance.middleware(middleware_or_request, attach_to)
    assert callable(object_middleware)

    # Test method middleware of class MiddlewareMixin if function middleware_or_request is not callable
    # Set arguments of function middleware_or_request
    attach_to = 1

    # Call function middleware of class MiddlewareMix

# Generated at 2022-06-12 09:15:23.324230
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Model:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        # Apply middleware
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

        def middleware(self, middleware_or_request):
            """
            Decorate and register middleware to be called before a request.
            Can either be called as *@app.middleware* or *@app.middleware('request')*
            """

            def register_middleware(middleware, attach_to="request"):
                future_middleware = FutureMiddleware(middleware, attach_to)
                self._future_middleware.append(future_middleware)
                # Apply middleware

# Generated at 2022-06-12 09:15:32.493084
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class SUT(sanic.Sanic):
        def _apply_middleware(self, middleware):
            pass

    request_middleware = lambda x: x
    response_middleware = lambda x: x

    app = SUT()
    app.middleware(request_middleware)
    app.middleware(response_middleware, attach_to="response")

    assert isinstance(app._future_middleware[0].middleware, type(request_middleware))
    assert app._future_middleware[0].attach_to == "request"
    assert isinstance(app._future_middleware[1].middleware, type(response_middleware))
    assert app._future_middleware[1].attach_to == "response"

# Generated at 2022-06-12 09:15:35.498506
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic(__name__)
    mid = MiddlewareMixin()
    res = mid.middleware()
    assert res.func(app).func == app.middleware.__wrapped__

# Generated at 2022-06-12 09:15:39.512516
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Class:
        def f(self, x):
            return x
    class Mixin:
        def f(self, x):
            return x + 1
    class Class_with_mixin(Class, Mixin):
        pass
    c_m = Class_with_mixin()
    assert c_m.f(3) == 4

test_MiddlewareMixin_middleware()

# Generated at 2022-06-12 09:15:40.038881
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:15:43.055984
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def testMiddleware():
        pass

# Generated at 2022-06-12 09:15:51.148544
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import time
    class MiddlewareMixin_Test_Class(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            return

    obj = MiddlewareMixin_Test_Class()
    obj.middleware(time.sleep)(0.35)
    assert len(obj._future_middleware) == 1
    assert isinstance(obj._future_middleware[0].handler, type(time.sleep))


# Generated at 2022-06-12 09:15:57.866925
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestClass(MiddlewareMixin):
        pass
    test = TestClass()
    # test_callback_without_attach_to
    @test.middleware
    def callback(request):
        pass
    assert test._future_middleware[0].middleware is callback
    assert test._future_middleware[0].attach_to is "request"
    # test_callback_with_string_attach_to
    @test.middleware('response')
    def callback2(request):
        pass
    assert test._future_middleware[1].middleware is callback2
    assert test._future_middleware[1].attach_to is "response"
    # test_callback_with_partial_attach_to
    @test.middleware(attach_to="response")
    def callback3(request):
        pass
    assert test._

# Generated at 2022-06-12 09:16:01.860970
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Create the mock objects
    middleware_mixin1 = MiddlewareMixin()
    # Call the testable method
    assert middleware_mixin1.middleware() == partial(middleware_mixin1.middleware, attach_to='request')
    assert middleware_mixin1.middleware('request') == partial(middleware_mixin1.middleware, attach_to='request')


# Generated at 2022-06-12 09:16:30.185142
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = Sanic(__name__)
    assert isinstance(app, MiddlewareMixin)
    assert isinstance(app, Sanic)

    @app.middleware
    async def test_middleware(request):
        pass

    @app.middleware('request')
    async def test_request_middleware(request):
        pass

    @app.middleware('response')
    async def test_response_middleware(request, response):
        pass


# Generated at 2022-06-12 09:16:36.104613
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass

    a = A()
    @a.middleware
    def test_middleware(request):
        return request
    assert len(a._future_middleware) == 1
    assert a._future_middleware[0].middleware == test_middleware


# Generated at 2022-06-12 09:16:37.799740
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    result = MiddlewareMixin.middleware

    assert result()
    assert result()()()()()

# Generated at 2022-06-12 09:16:47.156531
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic("__main__")
    mixin = MiddlewareMixin()
    assert mixin._future_middleware == []

    def test_middleware(request):
        print("Middleware is working...")

    @app.middleware(apply=False)
    def apply_test_middleware(request):
        print("Middleware is working with apply=False...")

    mixin.middleware(test_middleware)
    app._apply_middleware(apply_test_middleware)

    assert len(app._future_middleware) == 2

    # Unit test for method on_resquest of class MiddlewareMixin
    def test_MiddlewareMixin_on_request():
        from sanic.app import Sanic

        app = Sanic("__main__")
        mixin

# Generated at 2022-06-12 09:16:55.329626
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert(isinstance(app, MiddlewareMixin))
    assert(app._future_middleware == [])

    def test_middleware(request):
        print("test_middleware")
        return request

    # Currently, when using mode 'test', middleware are not really
    # registered.
    app.middleware(test_middleware)
    assert(app._future_middleware == [])

    # When test mode is disabled, middleware are registered and applied.
    app.middleware(test_middleware, apply=False)
    assert(len(app._future_middleware) == 1)
    assert(app._future_middleware[0].middleware == test_middleware)

# Generated at 2022-06-12 09:17:04.243632
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MockMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        
        def _apply_middleware(self, middleware):
            pass

    instance: MockMiddlewareMixin = MockMiddlewareMixin()
    assert isinstance(instance, MiddlewareMixin)
    @instance.middleware
    async def handler(request):
        return True
    assert isinstance(handler, partial)
    future_middleware: FutureMiddleware = instance._future_middleware.pop()
    assert future_middleware.middleware == handler
    assert future_middleware.attach_to == 'request'
    assert future_middleware.request(None) is True
    # 第二种形式的装

# Generated at 2022-06-12 09:17:08.679007
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A:
        def __init__(self):
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError

    a = A()
    assert isinstance(a, MiddlewareMixin)
    a.middleware('a', 'b')



# Generated at 2022-06-12 09:17:15.021928
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MockMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            return middleware

    def att_request_func(mock_req, middl_req):
        pass

    def att_resp_func(mock_resp, middl_resp):
        pass

    mock_app = MockMiddlewareMixin()
    mock_app.middleware(att_request_func)
    mock_app.middleware(att_resp_func, attach_to="response")

    last_req_idx = len(mock_app._future_middleware) - 1
    last_resp_idx = len(mock_app._future_middleware) - 2
    assert mock_app._future_middleware[last_req_idx].middleware == att

# Generated at 2022-06-12 09:17:23.392145
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class ClassThatInherits(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

        # Unit test: return bool
        def bool_test(self):
            bool_test = bool(self._future_middleware)
            return bool_test

    # Use ClassThatInherits to set up assert of function middleware
    class_test = ClassThatInherits()

    # Check for default response
    assert class_test.bool_test() == False
    assert class_test._future_middleware == []

    # Check response for default attach_to
    attach_to = "request"


# Generated at 2022-06-12 09:17:31.019242
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Arrange
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test = TestMiddlewareMixin()
    middleware_or_request = partial(test.on_request, middleware=None)
    
    # Act
    f = test.middleware(middleware_or_request, attach_to="request")

    # Assert
    assert f == None



# Generated at 2022-06-12 09:18:17.588322
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic('sanic-middleware')

    @app.middleware('response')
    def response_middleware(request, response):
        print('request', request)
        print('response', response)

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'

# Generated at 2022-06-12 09:18:25.286015
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import asyncio
    from sanic.app import Sanic
    from sanic.testing import SanicTestClient
    from sanic.response import text
    from sanic.request import Request
    from sanic.models.futures import FutureMiddleware


    app = Sanic('test_MiddlewareMixin_middleware')
    request_result = {}
    response_result = {}

    @app.middleware('request')
    async def request_middleware(request: Request):
        request_result['middleware'] = 'request_middleware'

    @app.middleware('response')
    async def response_middleware(request: Request, response: str):
        response_result['middleware'] = 'response_middleware'
        return response

    @app.route('/')
    async def handler(request: Request):
        return

# Generated at 2022-06-12 09:18:35.649221
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert len(app._future_middleware) == 0
    assert app.middleware is MiddlewareMixin.middleware
    def middleware(request):
        pass
    app.middleware(middleware)
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == 'request'

    app.middleware(middleware, attach_to='response')
    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == middleware
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-12 09:18:36.608765
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    MiddlewareMixin_ = MiddlewareMixin()

    assert isinstance(MiddlewareMixin_.middleware, partial)


# Generated at 2022-06-12 09:18:43.225461
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MockMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)
    # Test case: call middleware with no argument
    mock_middleware = MockMiddlewareMixin()
    mock_middleware.middleware()
    assert len(mock_middleware._future_middleware) == 0
    # Test case: call middleware with an argument which is not callable
    mock_middleware = MockMiddlewareMixin()
    mock_middleware.middleware(1)
    assert len(mock_middleware._future_middleware) == 0
    # Test case: call middleware with an argument which is callable
    mock_middleware = MockMiddlewareMixin()

# Generated at 2022-06-12 09:18:50.302696
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from unittest import mock

    app = MiddlewareMixin()

    class Middleware:
        def __init__(self, expected_args, expected_kwargs):
            self.expected_args = expected_args
            self.expected_kwargs = expected_kwargs

        def __call__(self, *args, **kwargs):
            assert self.expected_args == args
            assert self.expected_kwargs == kwargs

    # Use a mock object to replace the method _apply_middleware
    app._apply_middleware = mock.Mock()

    # Decorate a middleware
    args = ('arg1', 'arg2')
    kwargs = {'kwarg1': 'kwarg1', 'kwarg2': 'kwarg2'}
    middleware = Middleware(args, kwargs)
    middleware

# Generated at 2022-06-12 09:18:51.805087
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """Test middleware method of the class MiddlewareMixin"""
    pass

# Generated at 2022-06-12 09:19:03.072882
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app._future_middleware == []
    app.middleware(None, attach_to="request")
    assert app._future_middleware == []
    @app.middleware
    def test1():
        print("test1")
    
    @app.middleware('request')
    def test2():
        print("test2")
    
    assert len(app._future_middleware) == 2
    assert type(app._future_middleware[0]) == FutureMiddleware
    assert type(app._future_middleware[1]) == FutureMiddleware

    # test middleware.__call__()
    app.middleware.on_request(None)
    assert len(app._future_middleware) == 3

# Generated at 2022-06-12 09:19:10.312549
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic import response

    app = Sanic()

    @app.middleware('response')
    def middleware_response(request, response):
        response.headers['server'] = 'my custom server'
        return response

    @app.route('/')
    async def handler(request):
        return response.text('OK')

    _, response = app.test_client.get('/')

    assert response.headers.get('server') == 'my custom server'



# Generated at 2022-06-12 09:19:13.827421
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
  class MockMiddlewareMixin(MiddlewareMixin):
    def _apply_middleware(self, middleware: FutureMiddleware):
      return None
  def mock_middleware(request: Request, response: Response):
    return None
  middleware_mixin = MockMiddlewareMixin()
  middleware_mixin.middleware(middleware_or_request=mock_middleware)


# Generated at 2022-06-12 09:20:52.443272
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestClass(MiddlewareMixin):
        
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test = TestClass()

    @test.middleware('request')
    async def test_func(request):
        return request

    @test.middleware('response')
    async def test_func2(request, response):
        return response

    @test.middleware('request')
    async def test_func3(request):
        return request

    @test.middleware('response')
    async def test_func4(request, response):
        return response

    assert test._future_middleware[0].attach_to == 'request'
    assert test._future_middleware[0].func == test_func

    assert test._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-12 09:21:01.316130
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware
    app = Sanic()
    assert isinstance(app.__class__.middleware, partial)
    assert isinstance(app.__class__.on_request, partial)
    assert isinstance(app.__class__.on_response, partial)
    assert app._future_middleware == []
    @app.middleware
    def mw_test(request, response):
        pass
    mw_test2 = app.middleware()(mw_test)
    assert mw_test is mw_test2
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].attach_to == 'request'

# Generated at 2022-06-12 09:21:02.851262
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    a = MiddlewareMixin()
    a.middleware(request_middleware)
    print(a)


# Generated at 2022-06-12 09:21:08.544496
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Arrange
    future_middleware = FutureMiddleware(middleware=lambda x: x.upper(), attach_to="request")
    # Act
    assert future_middleware.attach_to == "request"
    assert future_middleware.middleware("asdf") == "ASDF"

if __name__=="__main__":
    test_MiddlewareMixin_middleware()

# Generated at 2022-06-12 09:21:09.052306
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:21:18.211685
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
             self._future_middleware.append(middleware)

    test_object = TestMiddlewareMixin()

    def test_middleware_1(request):
        return
    test_object.middleware(test_middleware_1, 'request')

    def test_middleware_2(request):
        return
    test_object.middleware(test_middleware_2, attach_to='response')

    if not isinstance(test_object._future_middleware[0], FutureMiddleware):
        raise TypeError('the _future_middleware\'s element must be an instance of FutureMiddleware')

# Generated at 2022-06-12 09:21:28.163142
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from multiprocessing import Process
    from sanic import Sanic
    from sanic.response import json
    from time import time

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print("I am a request middleware, and I am printing")

    @app.middleware('request')
    async def print_on_request2(request):
        print("I am another request middleware, and I am printing")

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I am a response middleware, and I am printing")

    @app.route('/')
    async def handler(request):
        return json({'test': 123})

    def run_server():
        app

# Generated at 2022-06-12 09:21:29.052085
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert False, "Test not implemented"


# Generated at 2022-06-12 09:21:31.369387
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    import pytest
    app = Sanic('test_regular')
    assert isinstance(app, MiddlewareMixin)


# Generated at 2022-06-12 09:21:38.281601
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Test coverage
    class TestMiddlewareMixin(MiddlewareMixin):
        # Define class variables
        def __init__(self, *args, **kwargs):
            self.counter = 0
        def _apply_middleware(self, middleware: FutureMiddleware):
            self.counter = self.counter + 1
    # Initialize TestMiddlewareMixin
    TestMiddlewareMixin()
    # Test case 1
    TestMiddlewareMixin().middleware(1)
    # Test case 2
    TestMiddlewareMixin().middleware(1, 'request')
    # Test case 3
    TestMiddlewareMixin().on_request()
    # Test case 4
    TestMiddlewareMixin().on_response()
    # Test case 5
    TestMiddlewareMixin().middleware(lambda x: x)
    # Test case