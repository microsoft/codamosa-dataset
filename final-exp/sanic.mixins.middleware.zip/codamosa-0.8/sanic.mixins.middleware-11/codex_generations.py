

# Generated at 2022-06-12 09:11:37.022457
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A:
        pass
    a = A()
    a.middleware(middleware_or_request="request", attach_to="response", apply=False)
    a.middleware(middleware_or_request="response", attach_to="request", apply=False)
    a.on_request(middleware="request"), a.on_response(middleware="response")


# Generated at 2022-06-12 09:11:38.371062
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Test(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            assert middleware.attach_to == "request"

    Test().on_request(middleware=lambda: print("hello"))

# Generated at 2022-06-12 09:11:42.766474
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic()
    @app.middleware
    async def foo(request):
        return text('abc')
    assert isinstance(foo, partial)
    assert foo.func == app.middleware
    assert foo.keywords == {'attach_to': 'request'}
    assert app._future_middleware[0].middleware == foo

# Generated at 2022-06-12 09:11:46.020664
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    obj = MiddlewareMixin()

    @obj.on_request()
    async def mw(request):
        pass

    assert mw.__name__ == "mw"

# Generated at 2022-06-12 09:11:49.712614
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class _MiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
    
        def _apply_middleware(self, middleware: FutureMiddleware):
            return
    def func_middleware_1():
        return
    middleware_mixin = _MiddlewareMixin()
    middleware_mixin.on_request(func_middleware_1)
    assert middleware_mixin._future_middleware[0] == FutureMiddleware(func_middleware_1, "request")


# Generated at 2022-06-12 09:11:58.193005
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.middleware import MiddlewareModel
    from sanic.models.middleware import MiddlewareMixin
    from sanic.asgi import ASGIFramework
    from sanic.config import Config
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureModel
    from sanic.models.request import RequestModel
    from sanic.models.response import ResponseModel
    from sanic.models.websocket import WebSocketModel
    import sanic.log
    sanic.log.LOGGING_CONFIG_DEFAULTS['disable_existing_loggers'] = False
    sanic.log.logger.setLevel(10)

    @MiddlewareMixin.middleware
    async def example_middleware1(request):
        return await RequestModel.from_

# Generated at 2022-06-12 09:12:04.472345
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic("test_MiddlewareMixin_on_request")

    assert callable(app.on_request)

    @app.on_request
    async def test_on_request(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-12 09:12:07.561318
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert hasattr(MiddlewareMixin, 'on_request')
    assert callable(MiddlewareMixin.on_request)



# Generated at 2022-06-12 09:12:12.149905
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MyApp():
        def _apply_middleware(self, middleware): pass
        def execute(self): pass

    app = MyApp()
    app.middleware(None)
    assert app._future_middleware
    app.on_request(None)
    assert app._future_middleware
    app.on_response(None)
    assert app._future_middleware

# Generated at 2022-06-12 09:12:21.878292
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Fail if return value of on_request is not a function
    assert callable(MiddlewareMixin.on_request)

    # Fail if function returned by on_request is not a partial function
    assert type(MiddlewareMixin.on_request()) is partial

    # Fail if partial function returned by on_request is not callable
    assert callable(MiddlewareMixin.on_request())

    # Fail if MiddlewareMixin is callable
    assert not callable(MiddlewareMixin)

    # Fail if MiddlewareMixin is partial function
    assert type(MiddlewareMixin) is not partial

    # Fail if function returned by on_request has incorrect parameters
    assert MiddlewareMixin.on_request.__code__.co_varnames == ('self', 'middleware')

    # Fail if function returned by on_request has incorrect parameters


# Generated at 2022-06-12 09:12:29.497403
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    Http_Prortocol = HttpProtocol()
    Sanic_app = Sanic()
    Sanic_app._app_middleware.append(Http_Prortocol)
    assert Sanic_app._app_middleware



# Generated at 2022-06-12 09:12:37.540770
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class App:
        def __init__(self, *args, **kwargs):
            self.middlewares = []
        def middleware(self, middleware, attach_to):
            self.middlewares.append(middleware)
    # function for check if in list
    def isInList(function, listMiddleware):
        for item in listMiddleware:
            if item == function:
                return True
            else:
                return False
    # Intance
    app = App()
    # Test
    m_m = MiddlewareMixin()
    m_m.on_request(app.middleware)
    assert isInList(m_m.on_request, app.middlewares)
    m_m.on_request(app.middleware)(app)

# Generated at 2022-06-12 09:12:40.064124
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = MiddlewareMixin()
    assert app.on_request(middleware=1) == partial(app.middleware, attach_to="request")
    assert app.on_request() == partial(app.middleware, attach_to="request")

# Generated at 2022-06-12 09:12:41.851913
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin.on_request(MiddlewareMixin) != None


# Generated at 2022-06-12 09:12:49.209829
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    a = MiddlewareMixin()

    def m():
        pass

    a.middleware(m)
    print(a._future_middleware[0].middleware)
    print(a._future_middleware[0].attach_to)
    assert a._future_middleware[0].middleware == m
    assert a._future_middleware[0].attach_to == "request"


if __name__ == "__main__":
    test_MiddlewareMixin_middleware()

# Generated at 2022-06-12 09:12:58.969156
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.futures import FutureMiddleware

    # setup
    class MockApp():
        def __init__(self, *args, **kwargs):
            self.middleware_called = False

        def middleware(self, middleware, attach_to='request'):
            self.middleware_called = True
            self.middleware_called_middleware = middleware
            self.middleware_called_attach_to = attach_to

    middleware_called = False

    def mocked_middleware(request):
        nonlocal middleware_called
        middleware_called = True

    app = MockApp()

    # call
    app.on_request(mocked_middleware)

    # validate
    assert middleware_called == False
    assert app.middleware_called == True

# Generated at 2022-06-12 09:13:02.896291
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    server = Server()

    @server.on_request
    def request(request):
        return request

    assert server._future_middleware[0]._middleware_func == request
    assert server._future_middleware[0]._attach_to == "request"

# Generated at 2022-06-12 09:13:11.426727
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic("test_MiddlewareMixin_on_request")

    @app.route("/")
    async def handler(request):
        return text("OK")

    @app.middleware("request")
    async def process_request(request):
        return text("OK")

    # No need @app.on_request, it is a duplicate of @app.middleware('request')
    # @app.on_request
    # async def process_request(request):
    #     return text("OK")

    request, response = app.test_client.get("/")
    assert response.text == "OK"



# Generated at 2022-06-12 09:13:14.934203
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.futures import FutureMiddleware
    middleware_mixin = MiddlewareMixin()
    middleware = middleware_mixin._apply_middleware(FutureMiddleware(None, "test"))
    assert middleware is None

# Generated at 2022-06-12 09:13:23.740716
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # mock class Sanic
    class Sanic:
        def __init__(self):
            self._future_middleware = []

    # mock class MiddlewareMixin
    class MiddlewareMixin:
        def __init__(self):
            self._future_middleware = []

        def middleware(self, middleware_or_request, attach_to="request", apply=True):
            def register_middleware(middleware, attach_to="request"):
                nonlocal apply
                future_middleware = FutureMiddleware(middleware, attach_to)
                self._future_middleware.append(future_middleware)
                return middleware
            if callable(middleware_or_request):
                return register_middleware(
                    middleware_or_request, attach_to=attach_to
                )

# Generated at 2022-06-12 09:13:37.526166
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("test_sanic")

    @app.middleware
    def process_before_request(request):
        pass

    @app.middleware('response')
    def process_after_request(request, response):
        pass

    # Tests if process_before_request is registered
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == process_before_request

    # Tests if process_after_request is registered
    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == process_after_request

# Generated at 2022-06-12 09:13:43.944148
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    assert len(app._future_middleware) == 0

    @app.middleware
    async def middleware1(request):
        pass

    assert len(app._future_middleware) == 1

    @app.middleware('response')
    async def middleware2(request, response):
        pass

    assert len(app._future_middleware) == 2

# Generated at 2022-06-12 09:13:50.633895
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import sanic
    app = sanic.Sanic(__name__)
    method1 = app.middleware
    assert method1

    method2 = app.middleware('request')
    assert method2

    @method2
    def check_request_middleware(request):
        return request

    assert check_request_middleware is app.request_middleware[0][0]

    @method1
    def check_middleware(request):
        return request

    assert check_middleware is app.request_middleware[1][0]


# Generated at 2022-06-12 09:14:00.708860
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            assert middleware.attach_to == "response"
            assert callable(middleware)

    test_middleware = TestMiddlewareMixin()
    test_middleware_response = test_middleware.middleware(
        lambda x: x, attach_to="response"
    )
    assert callable(test_middleware_response)

    test_middleware_on_response = test_middleware.on_response(
        lambda x: x
    )
    assert callable(test_middleware_on_response)

    test_middleware_on_request = test_middleware.on_request(
        lambda x: x
    )

# Generated at 2022-06-12 09:14:08.993541
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixinTestCase(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            assert middleware.middleware is _middleware_test1
            assert middleware.attach_to == 'request'
            assert middleware.future
            assert self._future_middleware[-1] is middleware
    mmtc = MiddlewareMixinTestCase()
    _middleware_test1 = lambda x: x
    mmtc.middleware(_middleware_test1)


# Generated at 2022-06-12 09:14:14.924754
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic import response
    import pytest

    app = Sanic()

    @app.middleware
    def response_middleware(request) :
        return response.text('<h1>This is a middleware</h1>')

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.text == '<h1>This is a middleware</h1>'


# Generated at 2022-06-12 09:14:18.973313
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    @MiddlewareMixin.middleware()
    # output: [FutureMiddleware(middleware=<bound method setup of MiddlewareMixin object at 0x7f11f8408fd0>, attach_to='request')]
    def setup():
        pass



# Generated at 2022-06-12 09:14:24.653559
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    future_middleware = FutureMiddleware()
    app.middleware(future_middleware.middleware, attach_to="request")
    # other test case
    app.middleware('request', future_middleware.middleware)
    app.middleware(future_middleware.middleware, attach_to="response")
    # other test case
    app.middleware('response', future_middleware.middleware)



# Generated at 2022-06-12 09:14:34.288149
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.exceptions import NotFound

    app = Sanic('test_sanic')

    @app.middleware
    def test_middleware(request):
        raise NotFound()

    # These are builtin middleware, and are purposely omitted for the test
    app._future_middleware = []

    assert len(app._future_middleware) == 0
    assert app.middleware is not None

    @app.middleware
    def add(a, b):
        return a + b

    assert len(app._future_middleware) == 1

    @app.middleware('response')
    def add(a, b):
        return a + b

    @app.middleware('request')
    def add(a, b):
        return a + b


# Generated at 2022-06-12 09:14:43.101711
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    def hello_world(request):
        return response.json({"hello": "world"})
    def hello_world_after(request, response):
        response.body = response.body.replace(b'world', b'earth')
        return response


    app = Sanic('test_MiddlewareMixin_middleware')
    app.add_route(hello_world, '/')

    @app.middleware
    def print_on_request(request):
        print('I run before every request')

    @app.middleware('response')
    def print_on_response(request, response):
        print('I run after every response')

    request, response = app.test_client.get('/')

    assert response.json == {"hello": "world"}

    # bool(app._future

# Generated at 2022-06-12 09:14:56.507095
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Arrange
    from sanic.app import Sanic

    class CustomMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    custom_middleware = Sanic('TestMiddlewareMixin_middleware')

    # Act
    @custom_middleware.middleware('request')
    async def test_middleware(request):
        return request

    @custom_middleware.middleware
    async def test2_middleware(request):
        return request

    # Assert
    assert custom_middleware._future_middleware[0].middleware._name == \
                'test_middleware'
    assert custom_middleware._future_middleware[1].middleware._name == \
                'test2_middleware'
    assert custom_middleware._future

# Generated at 2022-06-12 09:15:02.792410
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test_MiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            print('middleware applied')
    m = Test_MiddlewareMixin()
    m.middleware(lambda a: a)
    assert len(m._future_middleware) == 1

# Generated at 2022-06-12 09:15:04.695192
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin")
    assert False  # TODO: implement your test here


# Generated at 2022-06-12 09:15:05.271030
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:15:11.312749
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            print(middleware)

    test_mixin = TestMiddlewareMixin()
    def my_middleware_handler(request, response):
        pass

    test_mixin.middleware(my_middleware_handler, attach_to="request")



# Generated at 2022-06-12 09:15:22.171983
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import sanic
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware
    from sanic.models.middleware import Middleware
    from sanic.models.middleware import RequestResponse
    from sanic.models.middleware import RequestResponseStrict

    a = Sanic("test_MiddlewareMixin_middleware")

    @a.on_request
    def a_on_request(request):
        pass

    @a.middleware("request")
    def a_middleware_request(request):
        pass

    @a.on_response
    def a_on_response(request, response):
        pass

    @a.middleware("response")
    def a_middleware_response(request, response):
        pass

    fm = a._future_middleware

# Generated at 2022-06-12 09:15:26.548941
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    MIXIN_MIDDLEWARE = MiddlewareMixin()
    assert callable(MIXIN_MIDDLEWARE.on_request())
    assert callable(MIXIN_MIDDLEWARE.on_response())
    assert callable(MIXIN_MIDDLEWARE.middleware(print, 'response'))

# Generated at 2022-06-12 09:15:34.806514
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self.middleware_result = False

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware_result = True

    test = TestMiddlewareMixin()
    test.middleware(print, apply=False)
    test.middleware(print, attach_to="request", apply=False)
    test.middleware(print, attach_to="response", apply=False)
    assert not test.middleware_result  # noqa
    assert len(test._future_middleware) == 3  # noqa

# Generated at 2022-06-12 09:15:35.270302
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert True == True

# Generated at 2022-06-12 09:15:44.394963
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.blueprints import Blueprint
    from sanic.response import json
    import sanic
    from sanic.request import Request
    from sanic.models.futures import FutureMiddleware
    import asyncio

    middleware_bp = Blueprint('middleware')

    @middleware_bp.middleware('response')
    async def response_middleware(request, response):
        response.headers['my_custom_header'] = 'custom_header'

    @middleware_bp.middleware('request')
    async def request_middleware(request):
        return json({'method': request.method})

    @middleware_bp.route('/')
    async def handler(request):
        return json({'hello': 'world'})

    app = sanic.Sanic('test_middleware')

# Generated at 2022-06-12 09:16:01.144860
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.config import Config
    from sanic.handlers import RequestHandler
    from sanic.log import log
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import CompositionView
    from sanic.response import HTTPResponse as UnitTestHTTPResponse

    config = Config()
    config.REQUEST_TIMEOUT = 1
    config.RESPONSE_TIMEOUT = 1
    config.REQUEST_MAX_SIZE = 100
    config.GRACEFUL_SHUTDOWN_TIMEOUT = 0.1
    config.KEEP_ALIVE = True
    config.KEEP_ALIVE_TIMEOUT = 5
    config.REQUEST_HANDLER_CLASS = RequestHandler
    config.REQUEST_

# Generated at 2022-06-12 09:16:08.895888
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from asynctest import CoroutineMock
    app = Sanic(__name__)
    m_name = "middleware"
    m_attach_to = "request"
    m_func = CoroutineMock()
    m = app.middleware(m_name, m_attach_to, m_func)
    assert app._future_middleware
    assert app._future_middleware[0].attach_to == m_attach_to
    assert app._future_middleware[0].middleware == m_func


# Generated at 2022-06-12 09:16:10.602556
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic('name')

    app.middleware(None)
    app.middleware('request')

# Generated at 2022-06-12 09:16:18.195996
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        return request

    @app.middleware('response')
    async def response_middleware(request, response):
        return response

    assert app._future_middleware[0].is_request_middleware
    assert app._future_middleware[0].middleware == request_middleware

    assert not app._future_middleware[1].is_request_middleware
    assert app._future_middleware[1].middleware == response_middleware

# Generated at 2022-06-12 09:16:25.860287
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class testMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    testMixin = testMiddlewareMixin()

    @testMixin.middleware
    async def middleware(request):
        return ""

    assert(testMixin._future_middleware[0].middleware==middleware)
    assert(testMixin._future_middleware[0].attach_to=="request")


# Generated at 2022-06-12 09:16:35.592156
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    async def m1(request):
        request['middleware_1'] = True
        return await m2(request)

    async def m2(request):
        request['middleware_2'] = True
        return text('OK')

    app = Sanic()
    app.middleware(m1)
    app.middleware(m2)

    @app.route('/')
    def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert request['middleware_1'] is True
    assert request['middleware_2'] is True


# Generated at 2022-06-12 09:16:44.922335
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from unittest import mock

    app = Sanic()

    @app.middleware
    def attach_something(request):
        request['new'] = 'new_value'
        return request

    request, response = mock.Mock(), mock.Mock()

    # calling the middleware method on the request object
    new_request = attach_something(request)
    assert new_request['new'] == 'new_value'
    assert new_request == request

    # Use future middleware to apply middleware on the fly
    future_middleware = app._future_middleware
    for middleware in future_middleware:
        app._apply_middleware(middleware)

    new_request = attach_something(request)
    assert new_request['new']

# Generated at 2022-06-12 09:16:53.853813
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class DummyMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
            
    dummymw = DummyMiddlewareMixin()
    assert len(dummymw._future_middleware) == 0
    
    @dummymw.middleware
    def dummy_func():
        pass
    assert len(dummymw._future_middleware) == 1
    
    @dummymw.middleware('response')
    def dummy_func1():
        pass
    assert len(dummymw._future_middleware) == 2
    

# Generated at 2022-06-12 09:17:00.017932
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixinT:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa
    app_middleware = MiddlewareMixinT()
    app_middleware.middleware(middleware_or_request="request")


# Generated at 2022-06-12 09:17:02.183879
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic(__name__)

    @app.middleware('request')
    async def request(request):
        pass



# Generated at 2022-06-12 09:17:31.706477
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App(MiddlewareMixin):
        async def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = App()
    @app.middleware('a')
    def m1():
        pass

    @app.middleware
    def m2(request):
        return locals()

    @app.middleware('c', apply=False)
    def m3():
        pass

    @app.middleware('d')
    def m4():
        pass

    _ = m3

    assert(app._future_middleware == [
        FutureMiddleware(m1, 'a'),
        FutureMiddleware(m2, 'request'),
        FutureMiddleware(m4, 'd')
    ])



# Generated at 2022-06-12 09:17:40.467079
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App(Sanic):

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    app = App()
    assert app._future_middleware == []
    assert type(app.middleware) == type(app.on_request) == type(app.on_response)
    assert callable(app.middleware)
    def mid():
        pass
    app.middleware(mid)
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == mid
    assert app._future_middleware[0].attach_to == "request"
    app.middleware(mid, "response")
    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == mid
    assert app._future_

# Generated at 2022-06-12 09:17:43.957186
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert MiddlewareMixin_test.middleware.__name__ == "register_middleware"
    assert MiddlewareMixin_test.middleware.__qualname__ == \
        "MiddlewareMixin_test.register_middleware"


# Generated at 2022-06-12 09:17:52.635322
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic import response

    async def request_handler(request):
        return response.text("OK")

    def middleware1(request):
        return response.text("Middleware1")

    def middleware2(request):
        return response.text("Middleware2")

    app = Sanic("test_MiddlewareMixin")
    app.add_route(request_handler, "/")
    app.middleware(middleware1, attach_to="request")
    app.middleware(middleware2, attach_to="response")

    _, response_ = app.test_client.get("/")
    # assert response_.text == "Middleware1"  # TODO: fix after #1809
    assert response_.text == "OK"

# Generated at 2022-06-12 09:17:56.013246
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
  class MiddlewareMixinTest(MiddlewareMixin):
    def _apply_middleware(self, middleware: FutureMiddleware):
      pass

  middlewareMixinTest = MiddlewareMixinTest()
  middlewareMixinTest.middleware(None)
  middlewareMixinTest.on_request(None)
  middlewareMixinTest.on_response(None)

# Generated at 2022-06-12 09:18:04.763938
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic()

    # test usage @app.middleware
    @app.middleware()
    def test_middleware(request):
        pass

    assert app._future_middleware[0].middleware == test_middleware

    # test usage @app.middleware('request')
    @app.middleware('request')
    def test_middleware2(request):
        pass

    assert app._future_middleware[1].middleware == test_middleware2
    assert app._future_middleware[1].attach_to == "request"

    # test usage @app.middleware('response')
    @app.middleware('response')
    def test_middleware3(request, response):
        pass

    assert app._future_middleware[2].middleware == test_middleware3

# Generated at 2022-06-12 09:18:13.672910
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic("tet")
    app.config.REQUEST_HANDLER_CLASS = 'sanic.views.CompositionView'

    @app.middleware("request")
    async def hello(request):
        request["is_middleware"] = True

    @app.middleware("response")
    async def good_bye(request, response):
        response.text += " goodbye"

    @app.route("/")
    async def handler(request):
        return json({"test": True})

    _, response = app.test_client.get("/")

    assert response.status == 200
    assert response.json["test"]

    assert response.text == '{"test": true} goodbye'
    assert request["is_middleware"]

# Generated at 2022-06-12 09:18:16.776838
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware = middleware

    TestMiddlewareMixin().middleware(lambda x, y: x + y)
    assert TestMiddlewareMixin().middleware == (lambda x, y: x + y)



# Generated at 2022-06-12 09:18:22.803019
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware
    
    app = Sanic('test_sanicmiddlwaremixin')
    app._future_middleware = []
    app._apply_middleware = lambda middleware: None
    app.middleware(lambda request: None)
    assert app._future_middleware[0].__class__ == FutureMiddleware
    app.middleware(lambda response: None, 'response')
    assert app._future_middleware[1].__class__ == FutureMiddleware


# Generated at 2022-06-12 09:18:33.636038
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    print('test_MiddlewareMixin_middleware')

    import asyncio
    from sanic import Sanic
    from sanic.response import json

    app = Sanic()

    @app.middleware
    async def add_local_to_request(request):
        try:
            request["local"] = kwargs["local"]
        except KeyError:
            request["local"] = {}

        try:
            request["local"]["hello"] = "world"
        except KeyError:
            request["local"]["hello"] = 0

    @app.middleware('response')
    async def increment_on_response(request, response):
        request["local"]["hello"] += 1

    @app.route("/")
    async def test(request):
        return json({"test": True})
