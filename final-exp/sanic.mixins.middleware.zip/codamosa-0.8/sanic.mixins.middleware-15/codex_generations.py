

# Generated at 2022-06-12 09:11:38.988908
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Foo(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    foo = Foo()

    def f():
        pass

    assert foo.on_request(f) is f

# Generated at 2022-06-12 09:11:40.791035
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    MiddlewareMixin.on_request(self, middleware)
    middleware.assert_called_with(
        middleware, attach_to="request"
    )


# Generated at 2022-06-12 09:11:41.459706
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert MiddlewareMixin().middleware


# Generated at 2022-06-12 09:11:48.665608
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class A(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            self._future_middleware: List[FutureMiddleware] = []
            self._apply_middleware = lambda middleware: None
        def __call__(self, *args, **kwargs):
            pass

    a = A()
    @a.on_response
    def m():
        pass

    assert len(a._future_middleware) == 1
    assert a._future_middleware[0].middleware is m

# Generated at 2022-06-12 09:11:55.156148
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    testapp = TestMiddlewareMixin()
    def testmiddleware(request):
        pass
    testapp.on_request(testmiddleware)
    assert testapp._future_middleware[-1].middleware == testmiddleware


# Generated at 2022-06-12 09:11:56.722485
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin().on_request()("request") == "request"


# Generated at 2022-06-12 09:12:01.520500
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Foo:
        def __init__(self):
            super(Foo, self).__init__()
            self.on_request = self._on_request
            self._middleware = []

        def _on_request(self, middleware):
            self._middleware.append(middleware())
            
    def bar():
        return 1
    
    foo = Foo()
    foo.on_request(bar)
    assert foo._middleware[0] == 1

# Generated at 2022-06-12 09:12:07.546756
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixinChild(MiddlewareMixin):
        def __init__(self, attach_to=''):
            super().__init__()
            self.attach_to = attach_to
        def _apply_middleware(self, middleware):
            self.attach_to = middleware.attach_to

    m = MiddlewareMixinChild()

    assert m.attach_to == ''
    m.middleware(lambda *args, **kwargs: None, attach_to='middleware')
    assert m.attach_to == 'middleware'

# Generated at 2022-06-12 09:12:13.351990
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class App(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.ready = False

        def prepare(self) -> None:
            self.ready = True

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = App()
    assert app.on_response(lambda r, s, i: i)
    assert not app.ready



# Generated at 2022-06-12 09:12:16.126276
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    assert m.on_request() == partial(m.middleware, attach_to="request")

# Generated at 2022-06-12 09:12:25.256777
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Create new instance of MiddlewareMixin
    obj = MiddlewareMixin()
    # Create parameters for MiddlewareMixin.middleware
    middleware = None
    attach_to = "request"
    apply = True
    # Call function with parameters
    res = obj.middleware(middleware, attach_to, apply)


# Generated at 2022-06-12 09:12:32.000768
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # SUT
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware

    s = Sanic()

    middleware = lambda x: x
    attach_to = 'response'
    on_response_result = s.on_response(middleware)
    on_response_result = FutureMiddleware(on_response_result, attach_to)
    assert on_response_result.handler == middleware
    assert on_response_result.attach == attach_to



# Generated at 2022-06-12 09:12:39.533948
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.router import Router
    from sanic.models.application import Sanic
    import sys
    
    mw = MiddlewareMixin()
    app = Sanic(__name__)
    assert isinstance(app, MiddlewareMixin)

    @app.on_request
    async def some_middleware(request):
        return request

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].middleware == some_middleware


# Generated at 2022-06-12 09:12:43.313029
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.models.middleware import Middleware

    app = Sanic('test_MiddlewareMixin_on_response')
    middleware = Middleware(app)

    @app.on_response
    def test_response_middleware(request, response):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_response_middleware
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-12 09:12:54.952028
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Test:
        def __init__(self):
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            return

        def on_request(self, middleware=None):
            if callable(middleware):
                return self.middleware(middleware, "request")
            else:
                return partial(self.middleware, attach_to="request")
    
        def on_response(self, middleware=None):
            if callable(middleware):
                return self.middleware(middleware, "response")
            else:
                return partial(self.middleware, attach_to="response")
    

# Generated at 2022-06-12 09:13:04.378250
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.future import BaseFuture
    from sanic.models.request import Request

    class Future:
        def __init__(self):
            self.value = None

        def set_result(self, value):
            self.value = value

    class TestFuture(BaseFuture):
        def __init__(self):
            self.result = Future()

    class TestRequest(Request):
        def __init__(self):
            self.result = Future()

    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            self.app = None

        def _apply_middleware(self, middleware):
            self.app = middleware

    def callback():
        return "callback"

    test = TestMiddlewareMixin()
    test.on_request(callback)()

# Generated at 2022-06-12 09:13:12.863324
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware

    app = Sanic(__name__)
    app._apply_middleware = lambda x: x

    @app.middleware_event('response')
    def example_middleware(request):
        request

    @app.route('/middleware')
    async def handler(request):
        return request.app_response_middleware_count + 1

    request, response = app.test_client.get('/middleware')

    assert response.text == '1'
    assert len(app._future_middleware) == 1
    assert isinstance(app._future_middleware[0], FutureMiddleware)

# Generated at 2022-06-12 09:13:19.459261
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic('test_middlwaremixin_on_request')

    @app.on_request
    def middleware_on_request(request):
        pass

    assert str(app._future_middleware) == "[<FutureMiddleware(middleware=<function MiddlewareMixin_on_request.<locals>.middleware_on_request at 0x7ff7a13a3268>, attach_to='request')>]"


# Generated at 2022-06-12 09:13:20.061700
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass

# Generated at 2022-06-12 09:13:30.467945
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic(__name__)
    def testing_middleware(request, response = None):
        response = response or request.app.response_class(body = b"None", status = 200)
        print("Add Some Stuff to the response")
        return response

    app.on_request(testing_middleware)
    app.router.add_route("GET","/", testing_middleware)
    resource_base_path = app.config.RESOURCE_BASE_PATH
    endpoint_host = app.config.ENDPOINT_HOST
    endpoint_port = app.config.ENDPOINT_PORT
    total_host_port = endpoint_host + str(endpoint_port)
    test_host = "http://" + total_host_port
    response = None


# Generated at 2022-06-12 09:13:39.454425
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic(__name__)

    # 1
    @app.middleware("request")
    def request_middleware(request):
        return request

    # 2
    @app.on_request
    def request_middleware(request):
        return request

    assert app._future_middleware == [
        FutureMiddleware(request_middleware, "request"),
        FutureMiddleware(request_middleware, "request"),
    ]



# Generated at 2022-06-12 09:13:41.398628
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    Sanic().on_request(lambda x: x)

# Generated at 2022-06-12 09:13:45.847456
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic("test_MiddlewareMixin_middleware")
    # To execute the code of method middleware, add a decorator as the test case
    @app.middleware
    def add_field(request):
        request['version'] = 4

    # To set the value of _future_middleware
    return app



# Generated at 2022-06-12 09:13:56.311295
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert MiddlewareMixin.middleware.__doc__ is not None
    # assert MiddlewareMixin.middleware.__annotations__ == {}
    assert MiddlewareMixin.middleware.__defaults__ == (None, "request", True)
    assert MiddlewareMixin.middleware.__kwdefaults__ is not None
    assert MiddlewareMixin.middleware.__code__ is not None
    assert MiddlewareMixin.middleware.__dict__ == {}
    assert MiddlewareMixin.middleware.__closure__ is None
    assert MiddlewareMixin.middleware.__globals__ is not None
    assert MiddlewareMixin.middleware.__module__ is not None
    assert MiddlewareMixin.middleware.__name__ == "middleware"

# Generated at 2022-06-12 09:13:58.675883
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    @MiddlewareMixin.middleware()
    async def some_function():
        return "test middleware"

    assert some_function() == MiddlewareMixin.middleware()(some_function)



# Generated at 2022-06-12 09:14:03.345031
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.route('/')
    @app.on_response
    def test_function(request, response):
        pass
    assert app._future_middleware
        

# Generated at 2022-06-12 09:14:14.396333
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.constants import HTTP_METHODS
    from sanic.router import Router
    from sanic.exceptions import NotFound

    class Sanic:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

        def handle_request(self, request, *args, **kwargs):
            try:
                (
                    uri,
                    method,
                    http_version,
                ) = request.url, request.method, request.version
            except AttributeError:
                raise NotFound("Requested URL {} not found".format(uri))


# Generated at 2022-06-12 09:14:21.985081
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Foo():
        _future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware) -> None:
            self._future_middleware.append(middleware)

    foo = Foo()
    @foo.on_request
    def middleware1(request):
        print("middleware1")
        print(request)

    foo._apply_middleware(None)
    assert len(foo._future_middleware) == 2
    assert foo._future_middleware[0].middleware == "middleware1"


# Generated at 2022-06-12 09:14:31.243756
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.main import Sanic

    app = Sanic("test_MiddlewareMixin_middleware")
    assert callable(app.middleware)
    assert callable(app.middleware("response"))
    assert callable(app.middleware("request"))

    # Test method on_request
    assert callable(app.on_request)
    assert callable(app.on_request("response"))
    assert callable(app.on_request("request"))
    decorator_on_request = app.on_request
    assert callable(decorator_on_request)
    decorator_on_request("response")
    decorator_on_request("request")

    # Test method on_response
    assert callable(app.on_response)
    assert callable(app.on_response("response"))
    assert call

# Generated at 2022-06-12 09:14:35.566570
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    def middleware(request):
        request['test'] = 'test'
        return request

    @MiddlewareMixin.on_response(middleware)
    def request_handler(request):
        return request

    req = {'test': 'response'}
    request_handler(req)
    assert req['test'] == 'test'


# Generated at 2022-06-12 09:14:41.022869
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    '''
    Test the method on_response of class MiddlewareMixin
    '''
    assert middleware(middleware, "response") == partial(middleware, attach_to="response")


# Generated at 2022-06-12 09:14:43.367569
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    new_instance = MiddlewareMixin("request")
    try:
        new_instance.on_response("response")
    except Exception as except_instance:
        if type(except_instance) is NotImplementedError:
            return True
    return False


# Generated at 2022-06-12 09:14:51.941842
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from unittest import TestCase, main

    from sanic import Sanic

    from iai_middleware.mixin import MiddlewareMixin

    class TestClass1(MiddlewareMixin):
        pass

    class TestClass2(Sanic):
        pass

    class TestMethods(TestCase):
        def test_override(self):
            tc1 = TestClass1()
            self.assertEqual(tc1.on_response(), tc1.middleware("response"))
            self.assertEqual(tc1.on_response("arg1"), tc1.middleware("response"))
            self.assertEqual(tc1.on_response("arg1", "arg2"), tc1.middleware("response"))

            tc2 = TestClass2()

# Generated at 2022-06-12 09:14:56.370702
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # arrange
    class MyMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, middleware):
            # assert
            assert middleware.attach_to == "response"

    @MyMiddlewareMixin().on_response
    def test(request):
        pass



# Generated at 2022-06-12 09:14:56.995401
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:15:08.570778
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    instance_MiddlewareMixin = MiddlewareMixin()
    # Test 1
    @app.on_response('response')
    def func_on_response(response):
        response.headers['response'] = 'response'

    # Test 2
    @app.on_response
    def func_on_response(response):
        response.headers['request'] = 'request'
        return response

    # Test 3
    @app.middleware('response')
    def func_middleware(request):
        request.headers['response'] = 'response'

    # Test 4
    @app.middleware
    def func_middleware(request):
        request.headers['request'] = 'request'
        return request

    # Test 5


# Generated at 2022-06-12 09:15:19.144677
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic()

    @app.middleware
    def execution_order(request):
        request["executed"] = True

    @app.middleware
    def m1(request):
        request["m1"] = True

    @app.middleware
    def m2(request):
        request["m2"] = True

    @app.middleware('response')
    def rm1(request, response):
        response.text = "rm1"

    @app.middleware('response')
    def rm2(request, response):
        response.text = "rm2"

    @app.route('/')
    def handler(request):
        if not request.get("executed", False):
            return text('fail')

# Generated at 2022-06-12 09:15:20.593198
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    MiddlewareMixin.on_response('test')


# Generated at 2022-06-12 09:15:21.922264
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # TODO: Should create a testcase for class MiddlewareMixin
    pass

# Generated at 2022-06-12 09:15:25.222858
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic

    class Server(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass

    server = Server()

    server.on_response(middleware=None)
    server.on_response()

# Generated at 2022-06-12 09:15:37.931468
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import SanicException

    app = Sanic("test_sanic")

    @app.route("/")
    def handler(request):
        return response

    # Test for method on_response with middleware
    with pytest.raises(SanicException) as e:
        @app.on_response(None)
        async def response_handler(request, response):
            pass
    assert e.value.status_code == 500

    @app.on_response
    async def response_handler(request, response):
        pass

    global request, response

    request = Request(b"GET", b"/", [], None, app)

# Generated at 2022-06-12 09:15:40.499267
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin')
    assert isinstance(app.on_response, partial)
    assert callable(app.on_response())


# Generated at 2022-06-12 09:15:42.153155
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # TODO: fix this
    assert False

# Generated at 2022-06-12 09:15:48.095212
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    class Test_MiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)

    test_case = Test_MiddlewareMixin()
    test_case.middleware(middleware_or_request=None, attach_to="request")
    assert test_case._future_middleware

# Generated at 2022-06-12 09:15:50.290563
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class MockClass(MiddlewareMixin):
        pass

    mock = MockClass()
    mock.middleware(None)
    mock.on_request(None)
    mock.on_response(None)

# Generated at 2022-06-12 09:15:54.221587
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Given that I have a middleware "on_response" function
    class Cls(MiddlewareMixin):
        def __init__(self):
            super().__init__()
    # When I call on_response
    func = Cls.on_response(Cls)
    # Then I get an "on_response" function
    assert func() == partial(Cls.middleware, attach_to="response")
    

# Generated at 2022-06-12 09:15:58.565854
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import asyncio
    class E(MiddlewareMixin):
        def __init__(self):
            super(E, self).__init__()

    @E.on_response()
    async def a(request, response):
        pass
    
    e = E()

    assert len(e._future_middleware) == 1
    assert e._future_middleware[0].middleware == a
    assert e._future_middleware[0].attach_to == "response"

# Generated at 2022-06-12 09:16:03.859817
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from typing import Callable
    from sanic import Sanic, response

    async def handler(request):
        return response.text("OK")

    async def request_middleware(request):
        return request

    async def response_middleware(request, response):
        return response

    app = Sanic(__name__)
    app.add_route(handler, '/test')
    # 

    @app.middleware('response')
    async def another_response_middleware(request, response):
        return response

    assert app.middleware(response_middleware, apply=False)
    assert app.middleware(request_middleware, apply=False)
    assert app.on_response(response_middleware)
    assert app.on_request(request_middleware)

# Generated at 2022-06-12 09:16:11.018975
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: "pass")
    assert len(test_middleware_mixin._future_middleware) == 1
    assert len(test_middleware_mixin._future_middleware[0]._middleware) == 1
    assert test_middleware_mixin._future_middleware[0]._middleware == (lambda x: "pass")


# Generated at 2022-06-12 09:16:17.992829
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_function(request):
        request['middleware_function'] = 'test'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'
    assert request.get('middleware_function') == 'test'


# Generated at 2022-06-12 09:16:26.476603
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert True

# Generated at 2022-06-12 09:16:37.157092
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import asyncio
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic()

    # Decorate and register middleware to be called before a request.
    @app.middleware
    def m1(request):
        request.ctx.middleware.append('m1_was_here')
        return request

    @app.middleware('request')
    def m2(request):
        request.ctx.middleware.append('m2_was_here')
        return request

    @app.middleware('response')
    def m3(request, response):
        response.ctx.middleware.append('m3_was_here')
        return response


# Generated at 2022-06-12 09:16:40.093466
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin = MiddlewareMixin()
    # middleware function
    def f():
        pass
    middleware_mixin.on_response(f)
    assert(middleware_mixin._future_middleware is not None)

# Generated at 2022-06-12 09:16:40.665960
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

# Generated at 2022-06-12 09:16:50.128764
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class App:
        def __init__(self):
            self._future_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

        def on_response(self, middleware=None):
            if callable(middleware):
                return self.middleware(middleware, "response")
            else:
                return partial(self.middleware, attach_to="response")

        def middleware(
            self, middleware_or_request, attach_to="request", apply=True
        ):
            if callable(middleware_or_request):
                future_middleware = FutureMiddleware(middleware_or_request, attach_to)
                self._future_middleware.append(future_middleware)
                return middleware_or_request

# Generated at 2022-06-12 09:16:52.321857
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    mixin = MiddlewareMixin()
    with pytest.raises(NotImplementedError):
        mixin._apply_middleware(None)
    # TODO: extend this test

# Generated at 2022-06-12 09:16:57.096576
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super(TestMiddlewareMixin, self).__init__()

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda request, response: response)
    test_middleware_mixin.on_request(lambda request, response: response)
    test_middleware_mixin.on_response(lambda request, response: response)
    assert True

# Generated at 2022-06-12 09:17:00.205237
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    try:
        class Example(MiddlewareMixin): pass
        instance = Example()
        assert callable(instance.on_response())
    except:
        print("Failed!")


# Generated at 2022-06-12 09:17:04.055789
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class A(MiddlewareMixin): ...
    a = A()
    def f(): ...
    m = a.on_response(f)
    assert m.__name__ == 'f'
    assert m.__closure__[0].cell_contents == 'response'
    assert m.__closure__[1].cell_contents == True


# Generated at 2022-06-12 09:17:09.778165
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic()
    flag_request = False
    flag_response = False

    @app.middleware
    def custom_middleware(request):
        nonlocal flag_request
        flag_request = True

    @app.middleware
    def custom_middleware(response):
        nonlocal flag_response
        flag_response = True

    @app.middleware
    def custom_middleware(request, response):
        pass

    assert flag_request
    assert flag_response

# Generated at 2022-06-12 09:17:28.401234
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    @app.middleware
    async def test(request):
        return request

    assert app._future_middleware.pop().middleware.__name__ == "test"


# Generated at 2022-06-12 09:17:29.300338
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-12 09:17:36.058328
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middware_mixin = TestMiddlewareMixin()
    temp_middleware_name = ['test', 'test2']
    test_middware_mixin.middleware(temp_middleware_name[0], 'request', False)
    test_middware_mixin.middleware(temp_middleware_name[1], 'response', False)
    assert len(test_middware_mixin._future_middleware) == 2
    assert test_middware_mixin._future_middleware[0].middleware ==\
           temp_middleware_name[0] and\
           test_middware_mixin._future_middleware[1].middle

# Generated at 2022-06-12 09:17:42.747191
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.models.middleware import Middleware
    from sanic.models.futures import FutureMiddleware
    from sanic.response import text

    def handler_a(request):
        return text("OK")
    def handler_b(request):
        return text("OK")

    sanic_app = Sanic("test_op_code_name")

    class FakeMiddlewareMixin(MiddlewareMixin):
        pass

    fake_middleware_mixin: FakeMiddlewareMixin = FakeMiddlewareMixin()

    @fake_middleware_mixin.middleware('request')
    def a_test_middleware(request):
        return text("OK")


# Generated at 2022-06-12 09:17:51.483213
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            return middleware.middleware, middleware.attach_to

    a = A()
    @a.middleware
    def m1():
        pass
    @a.middleware('request')
    def m2():
        pass
    @a.middleware('response')
    def m3():
        pass
    assert a._apply_middleware(a._future_middleware[0]) == (m1, None)
    assert a._apply_middleware(a._future_middleware[1]) == (m2, 'request')
    assert a._apply_middleware(a._future_middleware[2]) == (m3, 'response')


# Generated at 2022-06-12 09:17:56.614282
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from unittest.mock import Mock

    from sanic import Sanic

    m = MiddlewareMixin()
    m.middleware = Mock(return_value=42)

    app = Sanic("test")
    assert app.middleware(1) == 42
    assert app.middleware(None, 2) == 42
    assert app.middleware(None, None, 3) == 42
    # This one is not tested.
    # assert app.middleware(1, 2) == 42
    m.middleware.assert_called_with()



# Generated at 2022-06-12 09:17:57.630882
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-12 09:18:06.507580
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()

    assert len(app._future_middleware) == 0

    @app.middleware
    def example_middleware_1(request):
        return request

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == example_middleware_1

    @app.middleware('request')
    def example_middleware_2(request):
        return request

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == example_middleware_2

    @app.middleware('response')
    def example_middleware_3(request):
        return request

    assert len(app._future_middleware) == 3

# Generated at 2022-06-12 09:18:15.255163
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class DummyMiddlewareMixin:
        def __init__(self):
            self._future_middleware = []

        def _apply_middleware(self, future_middleware):
            print(future_middleware)

    middleware_mixin = MiddlewareMixin()

    @middleware_mixin.middleware('request')
    def process_request(request):
        return 'process request'

    @middleware_mixin.middleware('response')
    def process_response(request, response):
        return 'process response'

    assert process_request(None) == 'process request'
    assert process_response(None, None) == 'process response'

# Generated at 2022-06-12 09:18:23.484291
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Test case data
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    class TestMiddleware:
        def __init__(self, app, request):
            pass

    # Construct test object
    test_mixin = TestMiddlewareMixin()

    # Test
    test_middleware_1 = test_mixin.middleware(TestMiddleware)
    test_middleware_2 = test_mixin.middleware(
        TestMiddleware, attach_to="request"
    )
    test_middleware_3 = test_mixin.middleware(
        TestMiddleware, attach_to="response"
    )

    # Assert
    assert isinstance(test_middleware_1, TestMiddleware)

# Generated at 2022-06-12 09:18:52.748050
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:19:03.664106
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.request import Request

    class MiddlewareMixinTest(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    def handler(request: Request):
        return 'ok'

    test = MiddlewareMixinTest()
    mw1 = test.on_response(lambda x: x)
    mw2 = test.on_request(lambda x: x)

    assert len(test._future_middleware) == 2
    assert isinstance(mw1, FutureMiddleware)
    assert mw1.attach_to == 'response'
    assert isinstance(mw2, FutureMiddleware)
    assert mw

# Generated at 2022-06-12 09:19:10.771499
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # 生成的middleware的装饰器的返回函数是middleware，且第二个参数是attach_to
    # 对于request来说，第三个参数是实际register的函数，对于response来说，是空函数
    request_middleware = MiddlewareMixin().middleware
    response_middleware = MiddlewareMixin().middleware('response')
    assert callable(request_middleware)
    assert callable(response_middleware)
    assert request_middleware.__code__.co_argcount == 2
    assert request_middleware.__code__.co_varnames

# Generated at 2022-06-12 09:19:15.273282
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
        
        def _apply_middleware(self, middleware: FutureMiddleware) -> None:
            pass

    test_middleware = TestMiddlewareMixin()
    test_middleware.middleware("test")
    assert len(test_middleware._future_middleware) > 0
    assert test_middleware._future_middleware[-1].attach_to == "test"


# Generated at 2022-06-12 09:19:20.619818
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic(name="sanic")
    assert len(app._future_middleware) == 0

    @app.middleware
    def middleware(request):
        print(request)

    assert len(app._future_middleware) == 1

    @app.middleware
    def middleware2(response):
        print(response)

    assert len(app._future_middleware) == 2



# Generated at 2022-06-12 09:19:28.300455
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test = Test()
    assert test._future_middleware == []
    @test.middleware('request')
    def _middleware():
        pass
    assert len(test._future_middleware) == 1
    assert test._future_middleware[0].function == _middleware
    assert test._future_middleware[0].attach_to == 'request'
    @test.middleware
    def _middleware():
        pass
    assert len(test._future_middleware) == 2
    assert test._future_middleware[1].function == _middleware
    assert test._future_middleware[1].attach_to == 'request'



# Generated at 2022-06-12 09:19:36.233529
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    #
    # Test method "middleware" of class MiddlewareMixin.
    #

    # Create class MiddlewareMixin
    middlewareMixin = MiddlewareMixin()
    assert isinstance(middlewareMixin, MiddlewareMixin)

    # Test method middleware of class MiddlewareMixin
    # Case 1: Test method middleware of class MiddlewareMixin
    #         with paramaters: middleware_or_request = ... /
    #         attach_to = ... / apply = ...
    # Expect:
    #         AttributeError with message "NotImplementedError"
    with pytest.raises(Exception) as excinfo:
        middlewareMixin.middleware(None, None, None)
    the_exception = excinfo.value

# Generated at 2022-06-12 09:19:46.071014
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App():
        async def is_request(self, *args, **kwargs):
            pass

        async def is_response(self, *args, **kwargs):
            pass

    def test_middleware(self):
        pass

    def test_middleware_request(self):
        pass

    def test_middleware_response(self):
        pass

    app = App()
    app.middleware = MiddlewareMixin()
    app.middleware.middleware(test_middleware)
    app.middleware.middleware(test_middleware_request, "request")
    app.middleware.middleware(test_middleware_response, "response")
    assert app.middleware._future_middleware[0].middleware == test_middleware
    assert app.middleware._future_middleware[1].middleware

# Generated at 2022-06-12 09:19:56.176005
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    def fire_middleware(request, response, middleware):
        for mid in middleware:
            if mid.attach_to == 'request':
                request.app.loop.run_until_complete(mid.middleware(request))
            if mid.attach_to == 'response':
                response = request.app.loop.run_until_complete(mid.middleware(request, response))
        return response

    obj_MiddlewareMixin = MiddlewareMixin()
    def test_middleware_1(rq, rs):
        if 'resp' in rs:
            rs['resp'] = True
        else:
            rs['resp'] = False
        return rs

    def test_middleware_2(rq, rs):
        if 'req' in rq:
            rq['req'] = True
        else:
            r

# Generated at 2022-06-12 09:20:01.951129
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic("MiddlewareMixin_middleware")

    # Define a middleware function
    def middleware_function(request):
        return "middleware_function"

    app.middleware(middleware_function)

    # Define a request handler
    @app.route("/")
    async def request_handler(request):
        return "request_handler"

    request, response = app.test_client.get("/")
    assert response.text == "middleware_function"

# Generated at 2022-06-12 09:21:10.513047
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixin_Test(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            MiddlewareMixin.__init__(*args, **kwargs)
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    middlewareMixin = MiddlewareMixin_Test()
    @middlewareMixin.middleware
    def middleware_or_request(middleware, attach_to):
        return True
    results = middleware_or_request()
    assert(results)

# Generated at 2022-06-12 09:21:12.643612
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    @MiddlewareMixin.middleware('request')
    async def before_request(request):
        print(request)
        return request


# Generated at 2022-06-12 09:21:14.538549
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert len(MiddlewareMixin()._future_middleware) == 0


# Generated at 2022-06-12 09:21:20.938065
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """
    test_MiddlewareMixin_middleware

    test the method middleware of class MiddlewareMixin
    """
    def test_m_war(request):
        pass
    from sanic.config import Config
    from sanic.server import HttpProtocol
    from sanic.middleware import Middleware
    from sanic.websocket import WebSocketProtocol
    config = Config()
    http_protocol = HttpProtocol(config)
    websocket_protocol = WebSocketProtocol(config)
    middleware = Middleware(config, http_protocol, websocket_protocol)

    test_m_war(middleware)
    assert(middleware.middleware_list)
    assert(middleware.middleware_list[0] == None)
    middleware.middleware(test_m_war)

# Generated at 2022-06-12 09:21:26.700845
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    obj = MiddlewareMixin()
    assert not obj._future_middleware
    obj.middleware(middleware=lambda x: x, attach_to="request")
    assert obj._future_middleware
    assert [i.middleware for i in obj._future_middleware] == [lambda x:x]
    assert [i.attach_to for i in obj._future_middleware] == ["request"]


# Generated at 2022-06-12 09:21:27.549552
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-12 09:21:28.414749
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:21:36.245731
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic()
    @app.middleware
    def other_test(request: Request):
        key = request.app.name + "other_test"
        request[key] = 1
        response = HTTPResponse()
        response.dummy = 1
        return response

    assert len(app._future_middleware) == 1

    @app.middleware('response')
    def test(request: Request, response: HTTPResponse):
        response.dummy = 1
        if not request.ctx._middleware_has_run_once:
            request.ctx._middleware_has_run_once = True
            return response