

# Generated at 2022-06-12 09:11:38.173234
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class App(MiddlewareMixin):
        def __init__(self):
            super().__init__()

    app = App()
    def mw1(request):
        pass

    def mw2(request, response):
        pass
    
    app.on_request(partial(mw1, attach_to="request"))
    app.on_response(partial(mw2, attach_to="response"))

# Generated at 2022-06-12 09:11:40.385904
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic(__name__)
    app.on_request(print)
    print(app._future_middleware)
    assert app._future_middleware[0]._middleware == print


# Generated at 2022-06-12 09:11:42.131298
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    inst= MiddlewareMixin()
    inst.on_request(inst.on_request)
    # pass


# Generated at 2022-06-12 09:11:51.794498
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.request import Request
    from sanic.response import HTTPResponse
    class App(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            middleware.add_async_middleware(self)

    app = App()
    class Middleware:
        def response(self, request: Request):
            return HTTPResponse("test")
        async def request(self, request: Request):
            return HTTPResponse("test_request")

    @app.middleware(attach_to='response')
    def response(request: Request):
        return HTTPResponse("test")
    @app.middleware
    async def request(request: Request):
        return HTTPResponse("test_request")
    assert len(app._future_middleware) == 2
   

# Generated at 2022-06-12 09:11:54.750572
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    x = MiddlewareMixin()
    x.middleware(None)

# Generated at 2022-06-12 09:11:58.551786
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    assert len(app._middleware) == 0
    app._future_middleware = []
    @app.middleware('test')
    async def test(request):
        pass
    assert len(app._future_middleware) == 1


# Generated at 2022-06-12 09:12:00.764850
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass # Constructor will take arguments, implement it if needed

# Generated at 2022-06-12 09:12:07.064067
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class App(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self.middlewares = dict()

        def _apply_middleware(self, middleware):
            self.middlewares[middleware.point] = middleware
    
    app = App()
    decorator = app.on_request()

    @decorator
    def middleware():
        assert True
    
    assert len(app.middlewares) == 1
    assert app.middlewares['request'].middleware == middleware


# Generated at 2022-06-12 09:12:10.264339
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    a = MiddlewareMixin()
    middleware1 = lambda request1: None
    middleware2 = lambda request2: None
    a.on_request(middleware1)
    a.on_request(middleware2)


# Generated at 2022-06-12 09:12:14.438454
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    result = MiddlewareMixin().on_request(middleware="middleware")
    assert result is not None


# Generated at 2022-06-12 09:12:19.892361
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
            super().__init__(*args, **kwargs)

    obj_test = Test()
    assert obj_test.middleware is not None



# Generated at 2022-06-12 09:12:24.562519
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.middleware import MiddlewareMixin
    from sanic.models.middleware import FutureMiddleware
    class middle(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    c = middle()
    assert isinstance(c.on_request(), partial)


# Generated at 2022-06-12 09:12:26.721023
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = MagicMock()
    # Call method
    MiddlewareMixin.on_request(app, lambda request: None)


# Generated at 2022-06-12 09:12:34.724814
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    
    class C(MiddlewareMixin):
        __init__ = MiddlewareMixin.__init__
        _apply_middleware = lambda m, c: 0
        
    app = Sanic('test_MiddlewareMixin_middleware')
    app.middleware(None, 'request', apply=True)
    assert app.on_request(None) is not None
    assert app.on_response(None) is not None
    app = C()
    app.middleware(None, 'request', apply=True)
    assert app.on_request(None) is not None
    assert app.on_response(None) is not None

# Generated at 2022-06-12 09:12:42.789984
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic


    class DemoAppWithMiddlewareMixin(MiddlewareMixin, Sanic):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware):
            assert True


    app = DemoAppWithMiddlewareMixin()
    app.on_request(lambda r: True)(lambda r: True)

    app1 = DemoAppWithMiddlewareMixin()
    app1.on_request(lambda r: True)

# test partial
# def test_MiddlewareMixin_on_request_partial():
#     from sanic import Sanic


#     class DemoAppWithMiddlewareMixin(MiddlewareMixin, Sanic):
#         def __init__(self, *args

# Generated at 2022-06-12 09:12:54.453276
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    test_object = MiddlewareMixin()
    test_object._future_middleware = []

    def test_middleware(request):
        pass

    def test_middleware2():
        pass

    test_object.on_request(test_middleware)
    assert len(test_object._future_middleware)==1
    assert test_object._future_middleware[0]._middleware == test_middleware
    assert test_object._future_middleware[0]._attach_to == "request"
    test_object.on_request()(test_middleware2)
    assert len(test_object._future_middleware)==2
    assert test_object._future_middleware[1]._middleware == test_middleware2

# Generated at 2022-06-12 09:13:03.805203
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.blueprints import Blueprint

    app = Sanic('test_MiddlewareMixin_middleware')

    async def request_middleware(request):
        request['in_middleware'] = True

    async def response_middleware(request, response):
        response.cookies['test'] = 'works'

    assert not app.middleware_stack

    app.middleware('request')(request_middleware)
    assert len(app.middleware_stack) == 1
    assert app.request_middleware[0] == request_middleware

    app.middleware('response')(response_middleware)
    assert len(app.middleware_stack) == 2
    assert app.response_middle

# Generated at 2022-06-12 09:13:13.852657
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic import request
    from sanic.response import json
    from sanic.response import text
    from sanic.log import logger
    import time
    import pytest

    # Define middleware function
    async def simple_middleware(request, handler):
        logger.info("middleware start")
        response = await handler(request)
        return response

    # Unit test
    async def test():
        app = Sanic("test_inject_middleware")


        # Test register new middleware with on_request
        @app.on_request(lambda request: time.sleep(1))
        def handler(request):
            return text("OK")

        # Inject middleware
        app._inject_middleware(request, simple_middleware, "request")

        # Test case 1:

# Generated at 2022-06-12 09:13:17.505793
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    @on_request
    def m1(r):
        return r

    # test_MiddlewareMixin_on_request
    assert isinstance(m1, partial)
    assert m1.func is MiddlewareMixin.middleware



# Generated at 2022-06-12 09:13:20.826983
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()

    def middlware(request):
        pass

    app.middleware(middlware)

    assert len(app._future_middleware) == 1

# Generated at 2022-06-12 09:13:37.744931
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import pytest
    from unittest.mock import Mock

    class TestClass(MiddlewareMixin):
        pass

    test_obj = TestClass()
    callback = Mock()
    test_obj.middleware(callback)

    test_obj.middleware(callback)
    test_obj.middleware(callback)
    test_obj.middleware(callback)

    assert hasattr(test_obj, '_future_middleware')

    # test _apply_middleware()
    def test_apply_middleware(self, middleware):
        # raise NotImplementedError  # noqa
        self._apply_middleware(middleware)

    with pytest.raises(NotImplementedError):
        test_obj.test_apply_middleware(test_obj._future_middleware[0])

# Generated at 2022-06-12 09:13:45.164845
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def print_on_request(request):
        print('before request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('after response')

    @app.route('/')
    def handler(request):
        return text('Hello')

    request, response = app.test_client.get('/')
    assert response.text == 'Hello'


# Generated at 2022-06-12 09:13:47.430587
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    args = ()
    kwargs = {}
    test_obj = MiddlewareMixin(*args, **kwargs)
    assert test_obj._future_middleware == []



# Generated at 2022-06-12 09:13:53.550988
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    class TestMiddlewareMixin(MiddlewareMixin, Sanic):
        pass
    obj = TestMiddlewareMixin()
    res = obj.middleware('request')
    assert isinstance(res, partial)
    res = obj.middleware('response')
    assert isinstance(res, partial)
    assert "request" == res.keywords.get('attach_to')


# Generated at 2022-06-12 09:14:02.212454
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # create a subclass of MiddlewareMixin and call MiddlewareMixin.__init__ to
    # initialize _future_middleware
    class Test(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            MiddlewareMixin.__init__(self)
    test = Test()
    # middleware should be an empty list
    assert test._future_middleware == []
    # attach a dummy function as a future middleware
    m = test.middleware(lambda x: x)
    # middleware should be a list with one element
    assert test._future_middleware == [FutureMiddleware(lambda x: x, 'request')]
    # the attached function should be the same that was inserted

# Generated at 2022-06-12 09:14:02.642934
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:14:11.088419
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import raw
    app = Sanic()

    @app.middleware('request')
    async def handler(request):
        request['request_handler'] = 'request_handler'
        return request

    @app.middleware('response')
    async def handler(request, response):
        response['request_handler'] = 'request_handler'
        return response

    request, response = app.test_client.get('/')
    assert response.get('request_handler') == 'request_handler'


# Generated at 2022-06-12 09:14:11.672389
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:14:18.633637
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()

    @middleware_mixin.middleware
    async def test_middleware(request):
        return request

    assert test_middleware == middleware_mixin._future_middleware[0].middleware
    assert 'request' == middleware_mixin._future_middleware[0].attach_to

    @middleware_mixin.middleware('request')
    async def test_middleware(request):
        return request

    assert test_middleware == middleware_mixin._future_middleware[1].middleware
    assert 'request' == middleware_mixin._future_middleware[1].attach_to


# Generated at 2022-06-12 09:14:25.629642
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    class DummyMiddleware:
        async def response_handler(self, request, response):
            return response

    app = Sanic('test_MiddlewareMixin_middleware')
    assert app._future_middleware == []
    app.middleware(DummyMiddleware)
    assert app._future_middleware != []
    app.middleware(DummyMiddleware)
    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == DummyMiddleware
    assert app._future_middleware[1].middleware == DummyMiddleware


# Generated at 2022-06-12 09:14:38.165315
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware

    app = Sanic()

    @app.middleware
    async def middleware(request):
        pass

    middleware_request = FutureMiddleware(middleware, "request")
    middleware_response = FutureMiddleware(middleware, "response")

    assert middleware_request.middleware == middleware
    assert middleware_request.attach_to == "request"
    assert middleware_response.middleware == middleware
    assert middleware_response.attach_to == "response"


# Generated at 2022-06-12 09:14:39.028537
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sani

# Generated at 2022-06-12 09:14:48.008376
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic(__name__)

    @app.middleware
    def global_middleware(request):
        print('Middleware executed!')

    @app.middleware('request')
    def request_middleware(request):
        print('Middleware executed!')

    @app.middleware('response')
    async def response_middleware(request, response):
        print('Middleware executed!')

    # test self._future_middleware
    assert len(app._future_middleware) == 3

    # test attach_to
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].attach_to == 'response'

    # test _apply_middleware
    # will raise NotImplementedError, so need to comment it

# Generated at 2022-06-12 09:14:52.928946
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Server:
        def __init__(self):
            self._future_middleware: List[FutureMiddleware] = []
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    server=Server()
    class Request:
        pass
    request=Request()
    @server.middleware
    async def request_middelware(request):
        return True
    request.middleware = server._future_middleware
    assert request.middleware[0].middleware(request) ==True

# Generated at 2022-06-12 09:15:04.670999
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.server import HttpProtocol
    from sanic.utils import get_working_loop
    from sanic.server import serve
    from sanic.app import Sanic

    app = Sanic("test_MiddlewareMixin_middleware")

    class Test_MiddlewareMixin_middleware():
        def __init__(self, *args, **kwargs):
            self.app = None

        def test_add_before_serve(self):
            """Unit test for method middleware of class MiddlewareMixin"""
            request_middleware_added = []
            response_middleware_added = []

            @app.middleware('request')
            def request_middleware(request):
                request_middleware_added.append(True)


# Generated at 2022-06-12 09:15:12.294717
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.exceptions import SanicException
    from sanic.models.futures import FutureMiddleware

    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware) -> None:
            pass

    def test_middleware(middleware, attach_to):
        assert isinstance(middleware, FutureMiddleware)
        assert attach_to in ['request', 'response']

    mm = TestMiddlewareMixin()
    assert mm._future_middleware == []

    assert mm.middleware(test_middleware) == test_middleware
    mm._future_middleware = []
    mm.middleware(test_middleware, 'request')
    assert mm._future_middleware == [FutureMiddleware(test_middleware, 'request')]
    mm._future_

# Generated at 2022-06-12 09:15:19.003509
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    def middleware(request):
        pass

    app = Sanic()
    app.middleware(middleware, attach_to="request")

    assert app._future_middleware == [FutureMiddleware(middleware, "request")]
    assert app._middleware_stack == []

    app._apply_middleware(app._future_middleware[0])
    assert app._middleware_stack == [middleware]


# Generated at 2022-06-12 09:15:25.372156
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestClass(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            print(middleware)

    test_obj = TestClass()
    print(test_obj._future_middleware)
    @test_obj.middleware(attach_to="test")
    def test_middleware(request):
        pass
    print(test_obj._future_middleware)
    print(test_obj._future_middleware[0].attach_to)


# Generated at 2022-06-12 09:15:35.101844
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A:
        pass

    class Sanic(MiddlewareMixin):
        pass

    sanic = Sanic()
    # @middleware()
    request_middleware = sanic.middleware
    # @middleware('request')
    request_middleware1 = sanic.on_request

    # @middleware()
    response_middleware = sanic.middleware
    # @middleware('repsonse')
    response_middleware1 = sanic.on_response

    @request_middleware
    async def request_middleware_handler(request):
        return request

    @request_middleware1
    async def request_middleware_handler1(request):
        return request

    @response_middleware
    async def response_middleware_handler(request, response):
        return response


# Generated at 2022-06-12 09:15:41.640844
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.response import json
    from sanic.response import text, html

    app = Sanic("Sanic-Test")

    @app.middleware("request")
    async def test_middleware(request, x):
        request.x = x
        request.y = y
        return request

    @app.middleware("response")
    async def test_middleware_text(request, response):
        if isinstance(response, HTTPResponse):
            response.text += ".2"
        else:
            response = text(response + ".2")
        return response

    @app.route("/")
    async def root(request):
        return text("test")


# Generated at 2022-06-12 09:15:54.312846
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    with pytest.raises(NotImplementedError):
        MiddlewareMixin().middleware(lambda x:x, "request")


# Generated at 2022-06-12 09:16:00.258708
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    mx = MiddlewareMixin()
    assert len(mx._future_middleware) == 0
    mx.middleware(object)
    assert len(mx._future_middleware) == 1
    mx.middleware(object, 'request')
    assert len(mx._future_middleware) == 2
    mx.middleware(object, 'response')
    assert len(mx._future_middleware) == 3
    assert mx.middleware(object, 'request', apply=False) == object
    assert len(mx._future_middleware) == 4
    assert mx.middleware(object, 'response', apply=False) == object
    assert len(mx._future_middleware) == 5


# Generated at 2022-06-12 09:16:04.124712
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MyClass(MiddlewareMixin):
        def __init__(self):
            super().__init__()
    def middleware(request):
        print(request)
    a = MyClass()
    assert isinstance(a.middleware(middleware), partial)


# Generated at 2022-06-12 09:16:12.639838
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic import server
    from sanic.exceptions import NotFound
    from sanic.log import logger
    from random import shuffle
    from unittest.mock import Mock
    from fastapi.testclient import TestClient

    app = Sanic("test_MiddlewareMixin_middleware")

    ###########################################################################
    # Example 1: Function
    ###########################################################################

    global request_counter
    request_counter = 0

    @app.middleware
    def test_middleware(request):
        global request_counter
        request["counter"] = request_counter
        request_counter += 1


# Generated at 2022-06-12 09:16:21.919418
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
   from sanic.app import Sanic
   from sanic.response import json
   from sanic.models.futures import FutureMiddleware

   app = Sanic('test_MiddlewareMixin_middleware')

   @app.middleware
   async def print_on_request(request):
       print('before request')

   @app.middleware('response')
   async def print_on_response(request, response):
       print('after response')

   @app.middleware('request')
   async def print_on_request2(request):
       print('before request 2')

   @app.middleware('response')
   async def print_on_response2(request, response):
       print('after response 2')

   @app.middleware('response')
   async def print_on_response3(request, response):
       print

# Generated at 2022-06-12 09:16:25.936351
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic(__name__)
    app.middleware(middleware=middleware_test)
    assert app.middleware == middleware_test
    assert app.on_request == middleware_test
    assert app.on_response == middleware_test
    assert app._future_middleware[0].future == middleware_test
    


# Generated at 2022-06-12 09:16:36.393123
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import HTTPResponse
    from sanic_http3_adapter.middleware import Middleware, MiddlewareMixin

    async def middleware_request(request: Request) -> Request:
        return request

    async def middleware_response(request: Request, response: HTTPResponse) -> HTTPResponse:
        return response

    class TestSanic(MiddlewareMixin, Sanic):
        pass

    app = TestSanic()
    middleware1 = Middleware(middleware_request, "request")
    middleware2 = Middleware(middleware_response, "response")
    app.middleware(middleware1)
    app.middleware(middleware2)
    assert app._future_middleware[0] == middleware1
    assert app._

# Generated at 2022-06-12 09:16:40.092576
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m = MiddlewareMixin()
    assert type(m.middleware) == type(MiddlewareMixin.middleware)
    assert m.middleware == MiddlewareMixin.middleware
    m.middleware("test")
    assert m._future_middleware[0].attach_to == "test"


# Generated at 2022-06-12 09:16:46.001663
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.router import Router
    from sanic.blueprints import Blueprint

    app = Sanic(__name__)
    router = Router()
    blueprint = Blueprint('test')
    app.blueprint(blueprint)

    def middleware():
        pass

    def error_middleware():
        pass

    @app.middleware(middleware)
    @app.error_handler(error_middleware)
    @blueprint.middleware(middleware)
    @blueprint.error_handler(error_middleware)
    @router.middleware(middleware)
    @router.error_handler(error_middleware)
    def test(request):
        pass

    assert middleware in app._future_middleware
    assert error_middleware in app._future_error_

# Generated at 2022-06-12 09:16:53.812284
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MixinTest:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    mixin = MiddlewareMixin()
    @mixin.middleware('request')
    def middleware(request):
        return request
    test = MixinTest()
    test.on_request(middleware)
    assert len(test._future_middleware) == 1
    assert test._future_middleware[0].middleware == middleware
    assert test._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-12 09:17:17.087327
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # TODO
    pass

# Generated at 2022-06-12 09:17:20.954654
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    '''
    Unit test for method middleware of class MiddlewareMixin
    
    middleware(middleware_or_request)
    '''
    middleware_mixin = MiddlewareMixin()
    middleware_mixin.middleware(middleware_or_request, attach_to="request", apply=True)
    

# Generated at 2022-06-12 09:17:23.224940
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.middleware import MiddlewareMixin
    from sanic.models.futures import FutureMiddleware

    # Code coverage provided by unit tests middleware_test.py
    assert MiddlewareMixin

# Generated at 2022-06-12 09:17:32.779181
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MyMiddlewareMixin(MiddlewareMixin):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.middleware_one = 1
            self.middleware_two = 2
            self.middleware_three = 3

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware_three = middleware


    instance = MyMiddlewareMixin()
    assert instance.middleware_one == 1
    assert instance.middleware_two == 2
    assert instance.middleware_three == 3

    # Check function MiddlewareMixin.middleware
    @instance.middleware
    def my_middleware(request):
        return request

    assert isinstance(my_middleware, FutureMiddleware)
    assert my_

# Generated at 2022-06-12 09:17:41.087671
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MockSanic(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.middleware_applied = None

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware_applied = middleware
    
    # Call @MiddlewareMixin.middleware(middleware, attach_to)
    app = MockSanic()
    @app.middleware
    def middleware_example_1(request):
        pass
    assert app.middleware_applied and app.middleware_applied.middleware == middleware_example_1 and app.middleware_applied.attach_to == "request"
    # Call @MiddlewareMixin.middleware('request')
    app

# Generated at 2022-06-12 09:17:46.951796
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    def middleware(request):
        pass

    app = Sanic("test_MiddlewareMixin_middleware")
    app.middleware(middleware)
    assert app._future_middleware[0].middleware
    assert app.on_response(middleware)
    assert app._future_middleware[1].middleware
    assert app.on_request(middleware)
    assert app._future_middleware[2].middleware

# Generated at 2022-06-12 09:17:52.597785
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            return middleware._call(None, None)

    @Test.on_request()
    async def request(request, call_next):
        assert request is None
        return await call_next()

    @Test.on_response()
    async def response(request, response, call_next):
        assert request is None
        assert response is None
        return await call_next()



# Generated at 2022-06-12 09:17:56.954074
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    # Create Sanic object
    app = Sanic(__name__)
    
    # Create middleware object
    async def m1(request):
        pass
    # Apply middleware to the Sanic object
    app.middleware(m1, "request")
    
    # Create another middleware object
    async def m2(request):
        pass
    # Apply middleware to the Sanic object
    app.on_request(m2)

# Generated at 2022-06-12 09:18:05.753735
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m = MiddlewareMixin()

    assert not m._future_middleware

    @m.middleware
    def middleware1(request):
        pass

    assert m._future_middleware[0].middleware == middleware1
    assert m._future_middleware[0].attach_to == "request"

    @m.middleware('response')
    def middleware2(request):
        pass

    assert m._future_middleware[1].middleware == middleware2
    assert m._future_middleware[1].attach_to == "response"

    # test by register middleware after created middleware mixin
    @m.on_request
    def middleware3(request):
        pass

    assert m._future_middleware[2].middleware == middleware3
    assert m._future_middleware[2].attach_

# Generated at 2022-06-12 09:18:09.230516
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = Sanic("TestSanicApp")

    @app.middleware
    def middleware(request):
        return request

    assert isinstance(app._future_middleware, list)
    assert isinstance(middleware, partial)
    assert len(app._future_middleware) == 1



# Generated at 2022-06-12 09:18:58.671248
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic("sanic-middleware-mixin-test-Sanic")
    middleware = MiddlewareMixin()

    @middleware.middleware()
    def mw(request):
        pass

    assert middleware._future_middleware[0].middleware == mw
    assert middleware._future_middleware[0].attach_to == "request"


# Generated at 2022-06-12 09:18:59.727097
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-12 09:19:01.196134
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    with pytest.raises(NotImplementedError):
        MiddlewareMixin().middleware(lambda: None)

# Generated at 2022-06-12 09:19:08.449320
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('response')
    async def response_middleware(request, response):
        response.headers['Content-Type'] = 'text/html'
        return response

    @app.route('/')
    async def handler(request):
        return response.text('Hello!')

    request, response = app.test_client.get('/')
    assert response.headers['Content-Type'] == 'text/html'


# Generated at 2022-06-12 09:19:15.221959
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MagicMock:
        def __init__(self):
            self._future_middleware = []

    instance = MagicMock()
    try:
        instance.middleware(0)
    except NotImplementedError as e:
        raise AssertionError("_apply_middleware Method not implemented")
    else:
        pass
    try:
        instance.on_request(0)
    except NotImplementedError as e:
        raise AssertionError("_apply_middleware Method not implemented")
    else:
        pass
    try:
        instance.on_response(0)
    except NotImplementedError as e:
        raise AssertionError("_apply_middleware Method not implemented")
    else:
        pass

# Generated at 2022-06-12 09:19:22.521288
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MockMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    mixin = MockMiddlewareMixin()

    def dummy_middleware():
        pass

    mixin.middleware(dummy_middleware, 'request')
    assert len(mixin._future_middleware) == 1

    mixin.middleware(dummy_middleware, 'response')
    assert len(mixin._future_middleware) == 2

    mixin.middleware(dummy_middleware)
    assert len(mixin._future_middleware) == 3



# Generated at 2022-06-12 09:19:25.201262
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A(MiddlewareMixin):
        pass
    a = A()
    middleware = lambda x: x
    a.middleware(middleware)
    assert len(a._future_middleware) == 1

# Generated at 2022-06-12 09:19:28.642925
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    def middleware(request):
        return text("OK")

    app = Sanic()
    app.middleware(middleware)
    request, response = app.test_client.get("/")
    assert response.text == 'OK'

# Generated at 2022-06-12 09:19:36.296408
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Test case data
    custom_middleware = None
    attach_to = None
    apply = None

    # Expected data
    expected_future_middleware = None
    expected_return = None

    # Create test model
    test_middleware_mixin = MiddlewareMixin()

    # Set test case data
    custom_middleware = None
    attach_to = None
    apply = None

    # Perform the test
    result = test_middleware_mixin.middleware(
        custom_middleware, attach_to=attach_to, apply=apply)

    # Perform assertions
    assert result == expected_return

    # Return test data
    return custom_middleware, attach_to, apply, expected_future_middleware, expected_return



# Generated at 2022-06-12 09:19:44.635447
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.protocol import HttpProtocol
    from sanic.server import Sanic
    sanic_app = Sanic()

    def request_middleware():
        pass

    def response_middleware():
        pass

    sanic_app.middleware(request_middleware)
    sanic_app.middleware(response_middleware)

    sanic_app.on_request(request_middleware)
    sanic_app.on_response(response_middleware)

    protocol = HttpProtocol(sanic_app)

    assert protocol.request_middleware == [request_middleware]
    assert protocol.response_middleware == [response_middleware]

# Generated at 2022-06-12 09:21:17.214917
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-12 09:21:21.259221
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')
    assert app._future_middleware == []  # noqa

    @app.middleware
    def foo(request):
        pass

    assert len(app._future_middleware) == 1  # noqa
    assert type(app._future_middleware[0]) == FutureMiddleware  # noqa
    assert app._future_middleware[0].target == foo  # noqa
    assert app._future_middleware[0].attach_to == 'request'  # noqa

# Generated at 2022-06-12 09:21:27.550329
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    try:
        @MiddlewareMixin.middleware(middleware_or_request='attachement')
        def middleware_function():
            pass

        assert callable(middleware_function)
    except NotImplementedError:
        assert True

    try:
        MiddlewareMixin().middleware(
            middleware=lambda request: "response",
            attach_to="response"
        )
        assert True
    except NotImplementedError:
        assert False

# Generated at 2022-06-12 09:21:30.081397
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m = MiddlewareMixin()
    m.middleware(lambda x: x + 1)
    assert len(m._future_middleware) == 1



# Generated at 2022-06-12 09:21:33.778788
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test_MiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    X = Test_MiddlewareMixin()
    XX = X.middleware
    X.middleware(None)
    X.middleware(None, None)
