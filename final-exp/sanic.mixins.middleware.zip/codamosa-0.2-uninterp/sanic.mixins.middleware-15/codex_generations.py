

# Generated at 2022-06-18 05:41:23.819341
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app.on_request(test_on_request) == test_on_request


# Generated at 2022-06-18 05:41:27.486816
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:41:32.158454
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_request(middleware=lambda request: request)
    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:41:39.052218
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic(__name__)

    @app.middleware
    async def middleware(request):
        request['middleware'] = 'test'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'
    assert request['middleware'] == 'test'


# Generated at 2022-06-18 05:41:46.814699
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:41:49.966795
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_request == app.middleware('request')


# Generated at 2022-06-18 05:41:53.812824
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        pass
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:42:00.846433
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:42:07.913511
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    assert app.on_request() == partial(app.middleware, attach_to="request")
    assert app.on_request(middleware=None) == partial(app.middleware, attach_to="request")
    assert app.on_request(middleware=lambda x: x) == app.middleware(lambda x: x, attach_to="request")


# Generated at 2022-06-18 05:42:19.849369
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app.middleware(middleware_or_request=None, attach_to="request", apply=True) is None
    assert app.middleware(middleware_or_request=None, attach_to="response", apply=True) is None
    assert app.middleware(middleware_or_request=None, attach_to="request", apply=False) is None
    assert app.middleware(middleware_or_request=None, attach_to="response", apply=False) is None
    assert app.middleware(middleware_or_request=None, attach_to=None, apply=True) is None
    assert app.middleware(middleware_or_request=None, attach_to=None, apply=False) is None

# Generated at 2022-06-18 05:42:26.455538
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_request(middleware=None)

# Generated at 2022-06-18 05:42:37.931707
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def middleware_test(request):
        pass

    assert app._future_middleware[0].middleware == middleware_test
    assert app._future_middleware[0].attach_to == 'request'

    @app.middleware('response')
    def middleware_test2(request):
        pass

    assert app._future_middleware[1].middleware == middleware_test2
    assert app._future_middleware[1].attach_to == 'response'

    @app.middleware('request')
    def middleware_test3(request):
        pass

    assert app._future_middleware[2].middleware == middleware_test3
    assert app._future_middle

# Generated at 2022-06-18 05:42:41.332379
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        return request
    assert app.middleware_stack[0].middleware == on_request


# Generated at 2022-06-18 05:42:52.102949
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_a(request):
        return text('Passed through middleware A')

    @app.middleware('request')
    async def middleware_b(request):
        return text('Passed through middleware B')

    @app.middleware('response')
    async def middleware_c(request, response):
        return text('Passed through middleware C')

    @app.route('/')
    async def handler(request):
        return text('OK')


# Generated at 2022-06-18 05:42:58.599426
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic()

    @app.middleware
    async def middleware_test(request):
        return text('Middleware test')

    request, response = app.test_client.get('/')
    assert response.text == 'Middleware test'


# Generated at 2022-06-18 05:43:03.773114
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:43:09.218858
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[0].middleware == on_request


# Generated at 2022-06-18 05:43:16.569468
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import ServerError

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        request['middleware'] = 'this is a request middleware'

    @app.middleware('response')
    async def response_middleware(request, response):
        response.text += ' this is a response middleware'

    @app.route('/')
    async def handler(request):
        return text('OK')

    @app.route('/error')
    async def error_handler(request):
        raise ServerError('OK')

    request, response = app.test_client.get('/')

# Generated at 2022-06-18 05:43:20.360618
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')

    @app.on_request
    def on_request(request):
        return request

    assert app.on_request(on_request) == on_request


# Generated at 2022-06-18 05:43:24.613899
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic(__name__)
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:43:36.300535
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_request(middleware=None)


# Generated at 2022-06-18 05:43:42.949717
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_request()


# Generated at 2022-06-18 05:43:50.172944
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_request(middleware=None)


# Generated at 2022-06-18 05:43:55.126154
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:44:06.804881
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    from sanic.models.futures import FutureMiddleware

    app = Sanic()

    @app.middleware
    def middleware_1(request):
        pass

    @app.middleware('request')
    def middleware_2(request):
        pass

    @app.middleware('response')
    def middleware_3(request, response):
        pass

    @app.middleware('request')
    def middleware_4(request):
        pass

    @app.middleware('response')
    def middleware_5(request, response):
        pass

    @app.middleware
    def middleware_6(request):
        pass

    @app.middleware('response')
    def middleware_7(request, response):
        pass

# Generated at 2022-06-18 05:44:10.406170
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic()
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request


# Generated at 2022-06-18 05:44:18.010571
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import Future
    from sanic.models.futures import FutureResult

    app = Sanic()

    @app.middleware
    async def middleware1(request):
        return request

    @app.middleware('request')
    async def middleware2(request):
        return request

    @app.middleware('response')
    async def middleware3(request, response):
        return response

    @app.middleware('request')
    async def middleware4(request):
        return request


# Generated at 2022-06-18 05:44:25.005877
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:44:33.026145
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_class = TestClass()
    test_class.on_request(middleware=test_class)
    assert test_class._future_middleware[0].middleware == test_class
    assert test_class._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:44:37.456334
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:44:45.455143
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:44:48.164569
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_request == app.middleware


# Generated at 2022-06-18 05:44:53.773412
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')

    @app.on_request
    def on_request(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:45:02.284136
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        pass

    @app.middleware('response')
    async def response_middleware(request, response):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].middleware == response_middleware
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-18 05:45:09.943166
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.middleware
    def test_MiddlewareMixin_on_request_middleware(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_MiddlewareMixin_on_request_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:45:13.624632
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:45:21.246561
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_request(middleware=None)


# Generated at 2022-06-18 05:45:28.948335
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic()

    @app.middleware('request')
    async def request_middleware(request):
        pass

    @app.middleware('response')
    async def response_middleware(request, response):
        pass

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'OK'


# Generated at 2022-06-18 05:45:33.140454
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware_stack[0].middleware == test_on_request


# Generated at 2022-06-18 05:45:35.131569
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:45:49.294772
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def request_handler(request):
        pass
    assert app._future_middleware[0].middleware == request_handler
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:45:53.459445
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    assert app._future_middleware == []
    assert app._apply_middleware is None


# Generated at 2022-06-18 05:45:59.458589
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware_stack[0].middleware == test_on_request


# Generated at 2022-06-18 05:46:07.578161
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound
    from sanic.models.futures import FutureMiddleware

    app = Sanic(__name__)

    @app.middleware
    async def middleware1(request):
        return text('Pass')

    @app.middleware('request')
    async def middleware2(request):
        return text('Pass')

    @app.middleware('response')
    async def middleware3(request, response):
        return text('Pass')

    @app.route('/')
    async def handler(request):
        return text('OK')

    @app.exception(NotFound)
    async def handler(request, exception):
        return text('OK')


# Generated at 2022-06-18 05:46:10.052207
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_request is app.middleware


# Generated at 2022-06-18 05:46:17.581465
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_request(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:46:22.439613
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()

    @app.on_request
    def on_request(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:46:29.070158
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:46:35.259561
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic()
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:46:43.189594
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.request import Request
    from sanic.models.futures import FutureMiddleware

    app = Sanic(__name__)

    @app.middleware
    def middleware_1(request):
        return request

    @app.middleware('request')
    def middleware_2(request):
        return request

    @app.middleware('response')
    def middleware_3(request, response):
        return response

    @app.route('/')
    def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'OK'

    assert len(app._future_middleware) == 3

# Generated at 2022-06-18 05:47:14.050305
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:47:21.377184
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def test_middleware(request):
        pass

    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'

    @app.middleware('response')
    def test_middleware(request):
        pass

    assert app._future_middleware[1].middleware == test_middleware
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-18 05:47:29.031563
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware(middleware_or_request='request')
    assert app.middleware(middleware_or_request='response')
    assert app.middleware(middleware_or_request=lambda x: x)
    assert app.on_request(middleware=lambda x: x)
    assert app.on_response(middleware=lambda x: x)


# Generated at 2022-06-18 05:47:34.979097
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.text == "OK"

# Generated at 2022-06-18 05:47:40.225529
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        pass
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:47:52.604137
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        request['middleware'] = 'this is a request middleware'

    @app.middleware('response')
    async def response_middleware(request, response):
        response.text += ' | this is a response middleware'

    @app.route('/')
    async def handler(request):
        return text('this is a normal response')

    request, response = app.test_client.get('/')

    assert response.text == 'this is a normal response | this is a response middleware'
    assert request['middleware'] == 'this is a request middleware'


# Generated at 2022-06-18 05:48:00.948225
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.models.futures import FutureMiddleware

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def middleware_1(request):
        return json({"middleware_1": "middleware_1"})

    @app.middleware('request')
    async def middleware_2(request):
        return json({"middleware_2": "middleware_2"})

    @app.middleware('response')
    async def middleware_3(request, response):
        return json({"middleware_3": "middleware_3"})

    assert len(app._future_middleware) == 3
    assert isinstance(app._future_middleware[0], FutureMiddleware)

# Generated at 2022-06-18 05:48:08.678803
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return request
    assert isinstance(app._future_middleware, list)
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:48:16.901736
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()

    @app.middleware
    async def middleware_1(request):
        pass

    @app.middleware('request')
    async def middleware_2(request):
        pass

    @app.middleware('response')
    async def middleware_3(request, response):
        pass

    assert len(app._future_middleware) == 3
    assert app._future_middleware[0].middleware == middleware_1
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].middleware == middleware_2
    assert app._future_middleware[1].attach_to == 'request'
    assert app._future_middleware[2].middleware == middleware_3

# Generated at 2022-06-18 05:48:27.140597
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()

    @app.middleware
    def middleware_test(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == middleware_test
    assert app._future_middleware[0].attach_to == "request"

    @app.middleware('response')
    def middleware_test2(request):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == middleware_test2
    assert app._future_middleware[1].attach_to == "response"

    @app.middleware('request')
    def middleware_test3(request):
        pass


# Generated at 2022-06-18 05:49:00.357176
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    assert app._future_middleware == []
    @app.middleware
    def middleware(request):
        pass
    assert app._future_middleware != []
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:49:10.323957
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        pass

    @app.middleware('response')
    async def response_middleware(request, response):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].middleware == response_middleware
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-18 05:49:15.430486
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:49:22.660807
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def print_on_request(request):
        print('I run on each request')
    @app.route('/')
    async def handler(request):
        return json({'test': True})
    request, response = app.test_client.get('/')
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:49:28.519192
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def test_middleware(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.text == "OK"

# Generated at 2022-06-18 05:49:35.517928
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic()

    @app.middleware
    async def middleware1(request):
        request['middleware1'] = True

    @app.middleware('request')
    async def middleware2(request):
        request['middleware2'] = True

    @app.middleware('response')
    async def middleware3(request, response):
        response.body = json(request)

    @app.route('/')
    async def handler(request):
        return json(request)

    request, response = app.test_client.get('/')

    assert response.json['middleware1'] is True
    assert response.json['middleware2'] is True
    assert response.json['middleware3'] is None


# Generated at 2022-06-18 05:49:47.940730
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.exceptions import SanicException
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def middleware_1(request):
        return request

    @app.middleware('request')
    def middleware_2(request):
        return request

    @app.middleware('response')
    def middleware_3(request, response):
        return response

    @app.middleware('request')
    def middleware_4(request):
        return request

    @app.middleware('response')
    def middleware_5(request, response):
        return response


# Generated at 2022-06-18 05:49:59.637051
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app._future_middleware == []
    @app.middleware('request')
    def test_middleware(request):
        return request
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'
    @app.middleware('response')
    def test_middleware2(request, response):
        return response
    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == test_middleware2
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-18 05:50:04.008983
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:50:14.079530
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import ServerError

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        request['middleware'] = 'this is a request middleware'

    @app.middleware('response')
    async def response_middleware(request, response):
        response.body = 'this is a response middleware'

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    @app.exception(ServerError)
    def handler_exception(request, exception):
        return json({'test': True})

    request, response = app.test_client.get('/')

# Generated at 2022-06-18 05:51:23.447439
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        return text('Pass')

    @app.middleware('request')
    async def middleware2(request):
        return text('Pass')

    @app.middleware('response')
    async def middleware3(request, response):
        return text('Pass')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'Pass'
    assert len(app._future_middleware) == 3
    assert isinstance