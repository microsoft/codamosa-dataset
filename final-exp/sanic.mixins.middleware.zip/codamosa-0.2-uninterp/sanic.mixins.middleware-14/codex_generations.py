

# Generated at 2022-06-18 05:41:27.594578
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None


# Generated at 2022-06-18 05:41:29.268997
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    assert app._future_middleware == []
    assert app._apply_middleware is None

# Generated at 2022-06-18 05:41:40.567535
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def middleware_1(request: Request):
        return json({"middleware": 1})

    @app.middleware("request")
    async def middleware_2(request: Request):
        return json({"middleware": 2})

    @app.middleware("response")
    async def middleware_3(request: Request, response: HTTPResponse):
        return json({"middleware": 3})

    @app.middleware("request")
    async def middleware_4(request: Request):
        return json({"middleware": 4})



# Generated at 2022-06-18 05:41:47.298356
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, middleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_response(middleware=None)

# Generated at 2022-06-18 05:41:54.740940
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic(__name__)

    @app.middleware
    async def middleware1(request):
        request['middleware1'] = True

    @app.middleware('response')
    async def middleware2(request, response):
        response.text += ' middleware2'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK middleware2'
    assert request.get('middleware1') is True


# Generated at 2022-06-18 05:42:03.299845
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_on_response')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('Response from {}'.format(request.url))

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'OK'


# Generated at 2022-06-18 05:42:08.683718
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('Pass')

    request, response = app.test_client.get('/')
    assert response.text == 'Pass'


# Generated at 2022-06-18 05:42:14.477769
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic(__name__)
    assert app.on_response()
    assert app.on_response(middleware=None)
    assert app.on_response(middleware=lambda x: x)
    assert app.on_response(middleware='response')


# Generated at 2022-06-18 05:42:16.878593
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    app.on_response(middleware=None)

# Generated at 2022-06-18 05:42:26.293101
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic()

    @app.middleware
    async def middleware(request):
        request['middleware'] = True
        response = await app.handle_request(request)
        response.headers['middleware'] = True
        return response

    @app.middleware('request')
    async def request_middleware(request):
        request['request_middleware'] = True

    @app.middleware('response')
    async def response_middleware(request, response):
        response.headers['response_middleware'] = True

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request,

# Generated at 2022-06-18 05:42:35.902948
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')

    @app.middleware('request')
    async def request_middleware(request):
        pass

    @app.middleware('response')
    async def response_middleware(request, response):
        pass

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'OK'

# Generated at 2022-06-18 05:42:40.866228
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        response.text = 'test_on_response'
    request, response = app.test_client.get('/')
    assert response.text == 'test_on_response'


# Generated at 2022-06-18 05:42:51.649590
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()

    @test_middleware_mixin.middleware
    def test_middleware(request):
        pass

    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].middleware == test_middleware
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:42:53.412024
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    app.middleware(None)

# Generated at 2022-06-18 05:42:57.111238
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:43:01.671376
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic()
    assert app.on_response() == partial(app.middleware, attach_to="response")
    assert app.on_response(lambda x: x) == app.middleware(lambda x: x, "response")


# Generated at 2022-06-18 05:43:06.533205
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic()
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:43:10.857177
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return request

    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:43:16.521291
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def response_middleware(request, response):
        print('response_middleware')
    assert app._future_middleware[0].middleware == response_middleware
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:43:22.673103
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_response(middleware=None)


# Generated at 2022-06-18 05:43:34.963123
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('response')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'


# Generated at 2022-06-18 05:43:43.791189
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def print_on_request(request):
        print('I run on each request!')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('I run on each response!')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:43:46.462692
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic(__name__)
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:43:53.087503
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware.__get__(app)
    assert app.on_request is MiddlewareMixin.on_request.__get__(app)
    assert app.on_response is MiddlewareMixin.on_response.__get__(app)


# Generated at 2022-06-18 05:44:03.432384
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddlewareType
    from sanic.models.futures import FutureMiddlewareAttachType

    app = Sanic("test_MiddlewareMixin_middleware")
    @app.middleware
    def middleware_1(request):
        return request

    @app.middleware('request')
    def middleware_2(request):
        return request

    @app.middleware('response')
    def middleware_3(request, response):
        return response

    @app.middleware('request')
    def middleware_4(request):
        return request


# Generated at 2022-06-18 05:44:10.306158
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic(__name__)
    @app.middleware
    async def test_middleware(request):
        return text('test_middleware')
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:44:14.610474
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic()

    @app.middleware
    async def handler(request):
        return text('OK')

    assert app._future_middleware[0].middleware == handler
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:44:26.448932
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def middleware_1(request):
        return text("OK")

    @app.middleware("request")
    async def middleware_2(request):
        return text("OK")

    @app.middleware("response")
    async def middleware_3(request, response):
        return text("OK")

    assert len(app._future_middleware) == 3
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert isinstance(app._future_middleware[1], FutureMiddleware)

# Generated at 2022-06-18 05:44:36.793347
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        return text('Pass')

    @app.middleware('request')
    async def middleware2(request):
        return text('Pass')

    @app.middleware('response')
    async def middleware3(request, response):
        return text('Pass')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

# Generated at 2022-06-18 05:44:37.331069
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert True

# Generated at 2022-06-18 05:44:43.704728
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:44:54.085837
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.models.futures import FutureMiddleware

    app = Sanic(__name__)

    @app.middleware
    def middleware_1(request: Request):
        return request

    @app.middleware('request')
    def middleware_2(request: Request):
        return request

    @app.middleware('response')
    def middleware_3(request: Request, response: HTTPResponse):
        return response

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

# Generated at 2022-06-18 05:45:01.002502
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:45:07.941235
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware('response')
    async def test(request):
        pass
    assert app._future_middleware[0].middleware == test
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:45:11.970947
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('pass')

    request, response = app.test_client.get('/')
    assert response.text == 'pass'


# Generated at 2022-06-18 05:45:16.747096
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic()

    @app.middleware
    async def print_on_request(request):
        print("I print when a request is received by the server")

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I print when a response is returned by the server")

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}

# Generated at 2022-06-18 05:45:18.459120
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic()
    @app.middleware
    async def test_middleware(request):
        return text('test')
    assert app._future_middleware[0].middleware == test_middleware


# Generated at 2022-06-18 05:45:20.522008
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.text == "OK"



# Generated at 2022-06-18 05:45:26.883464
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:45:31.130294
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response


# Generated at 2022-06-18 05:45:41.065920
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware
    assert app.on_request is MiddlewareMixin.on_request
    assert app.on_response is MiddlewareMixin.on_response

# Generated at 2022-06-18 05:45:48.043609
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware(None)
    assert app.middleware(None, 'request')
    assert app.middleware(None, 'response')
    assert app.on_request(None)
    assert app.on_response(None)


# Generated at 2022-06-18 05:45:56.250938
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    test_middleware_mixin.middleware(lambda x: x, attach_to='request')
    assert len(test_middleware_mixin._future_middleware) == 2

# Generated at 2022-06-18 05:46:06.450876
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic()

    @app.middleware
    async def middleware_a(request):
        request["middleware"] = "a"

    @app.middleware("request")
    async def middleware_b(request):
        request["middleware"] += "b"

    @app.middleware("response")
    async def middleware_c(request, response):
        response.text += "c"

    @app.route("/")
    async def handler(request):
        return text(request["middleware"])

    request, response = app.test_client.get("/")
    assert response.text == "abc"


# Generated at 2022-06-18 05:46:18.657464
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.views import HTTPMethodView

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def middleware1(request):
        request["middleware1"] = True

    @app.middleware("request")
    async def middleware2(request):
        request["middleware2"] = True

    @app.middleware("response")
    async def middleware3(request, response):
        response.headers["middleware3"] = True

    @app.middleware("request")
    async def middleware4(request):
        request["middleware4"] = True


# Generated at 2022-06-18 05:46:25.133469
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:46:30.225258
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    from sanic.request import Request

    app = Sanic()

    @app.middleware
    async def handler(request):
        return text('OK')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:46:40.341007
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda request: None)
    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"
    assert test_middleware_mixin._future_middleware[0].middleware is not None


# Generated at 2022-06-18 05:46:45.318821
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    from sanic.exceptions import ServerError

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return json({'test': True})

    @app.route('/')
    async def handler(request):
        raise ServerError("Something bad happened", status_code=500)

    request, response = app.test_client.get('/')

    assert response.status == 500
    assert response.json == {'test': True}

# Generated at 2022-06-18 05:46:52.124109
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware == MiddlewareMixin._apply_middleware


# Generated at 2022-06-18 05:47:08.546926
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()
    @app.middleware
    def middleware(request):
        return request
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:47:19.842833
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        pass

    @app.middleware('response')
    async def response_middleware(request, response):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].middleware == response_middleware
    assert app._future_middleware[1].attach_to == 'response'

    @app.middleware
    async def middleware(request):
        pass

    assert len(app._future_middleware) == 3

# Generated at 2022-06-18 05:47:30.179841
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        request['middleware'] = 'this is a request middleware'

    @app.middleware('response')
    async def response_middleware(request, response):
        response.text = 'response middleware was here'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'response middleware was here'
    assert request['middleware'] == 'this is a request middleware'


# Generated at 2022-06-18 05:47:32.568826
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def middleware_test(request):
        pass
    assert app._future_middleware[0].middleware == middleware_test


# Generated at 2022-06-18 05:47:38.382943
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware('request')
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:47:49.760414
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware(middleware_or_request=None, attach_to='request', apply=True) == None
    assert app.middleware(middleware_or_request=None, attach_to='response', apply=True) == None
    assert app.middleware(middleware_or_request=None, attach_to='request', apply=False) == None
    assert app.middleware(middleware_or_request=None, attach_to='response', apply=False) == None
    assert app.middleware(middleware_or_request=None, attach_to=None, apply=True) == None

# Generated at 2022-06-18 05:47:56.429238
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:48:07.988576
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()

    @app.middleware
    def test_middleware(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"

    @app.middleware('response')
    def test_middleware_response(request, response):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == test_middleware_response
    assert app._future_middleware[1].attach_to == "response"

    @app.middleware('request')
    def test_middleware_request(request):
        pass


# Generated at 2022-06-18 05:48:16.236716
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.views import HTTPMethodView

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.json == {'test': True}

    # Unit test for method on_request of class MiddlewareMixin

# Generated at 2022-06-18 05:48:26.761718
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.views import HTTPMethodView

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('In request middleware')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('In response middleware')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    @app.route('/class')
    class Handler(HTTPMethodView):
        async def get(self, request):
            return json({'test': True})

    request, response = app.test_client.get('/')
    assert response

# Generated at 2022-06-18 05:48:53.477052
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:48:58.587366
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    app.middleware(middleware_or_request=None, attach_to='request', apply=True)
    app.middleware(middleware_or_request=None, attach_to='response', apply=True)
    app.on_request(middleware=None)
    app.on_response(middleware=None)


# Generated at 2022-06-18 05:49:04.338476
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        return text('Pass')

    @app.middleware('request')
    async def middleware2(request):
        return text('Pass')

    @app.middleware('response')
    async def middleware3(request, response):
        return text('Pass')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'Pass'

    request, response = app.test_client.get('/')

# Generated at 2022-06-18 05:49:14.034777
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_1(request):
        pass

    @app.middleware('request')
    async def middleware_2(request):
        pass

    @app.middleware('response')
    async def middleware_3(request, response):
        pass

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.text == 'OK'


# Generated at 2022-06-18 05:49:23.077902
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:49:26.755762
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'

# Generated at 2022-06-18 05:49:34.743747
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    assert test_middleware_mixin._future_middleware == []

    @test_middleware_mixin.middleware
    def test_middleware(request):
        pass

    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].middleware == test_middleware
    assert test_middleware_mixin._

# Generated at 2022-06-18 05:49:47.143375
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic(__name__)
    assert app._future_middleware == []
    assert app.middleware(middleware_or_request='request')
    assert app._future_middleware == []
    assert app.middleware(middleware_or_request='response')
    assert app._future_middleware == []
    assert app.middleware(middleware_or_request=lambda x: x)
    assert app._future_middleware == []
    assert app.middleware(middleware_or_request=lambda x: x, attach_to='request')
    assert app._future_middleware == []
    assert app.middleware(middleware_or_request=lambda x: x, attach_to='response')
    assert app._future_middleware == []
    assert app.middleware

# Generated at 2022-06-18 05:49:49.105131
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:49:55.478808
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('I run on each request')

    @app.middleware('request')
    async def halt_request(request):
        return json({'test': True})

    @app.middleware('response')
    async def print_on_response(request, response):
        print('I run on each response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200