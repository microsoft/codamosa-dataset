

# Generated at 2022-06-18 05:41:39.872585
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_request(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:41:45.624665
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_response == app.middleware
    assert app.on_response('response') == app.middleware('response')
    assert app.on_response(lambda x: x) == app.middleware(lambda x: x)


# Generated at 2022-06-18 05:41:50.233358
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:41:54.314726
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        return request
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:42:02.629757
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_response(middleware=None)

# Generated at 2022-06-18 05:42:08.127037
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic()

    @app.on_request
    def on_request(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].middleware == on_request


# Generated at 2022-06-18 05:42:12.733119
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        return request
    assert app.on_request == on_request


# Generated at 2022-06-18 05:42:17.480515
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None


# Generated at 2022-06-18 05:42:22.631676
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        pass
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:42:26.052932
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_response() == partial(app.middleware, attach_to="response")
    assert app.on_response(lambda x: x) == app.middleware(lambda x: x, "response")


# Generated at 2022-06-18 05:42:30.136684
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        return request
    assert app.on_request == on_request


# Generated at 2022-06-18 05:42:33.226717
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic(__name__)
    assert app.on_response(middleware=None)
    assert app.on_response(middleware=lambda x: x)

# Generated at 2022-06-18 05:42:43.629242
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()

    @app.middleware
    async def middleware1(request):
        pass

    @app.middleware('request')
    async def middleware2(request):
        pass

    @app.middleware('response')
    async def middleware3(request, response):
        pass

    assert len(app._future_middleware) == 3
    assert app._future_middleware[0].middleware == middleware1
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].middleware == middleware2
    assert app._future_middleware[1].attach_to == 'request'
    assert app._future_middleware[2].middleware == middleware3
    assert app._future_middleware

# Generated at 2022-06-18 05:42:48.934953
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:42:53.183268
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response


# Generated at 2022-06-18 05:42:59.986194
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request

    assert app.on_request == app.middleware
    assert app.on_request(test_on_request) == test_on_request


# Generated at 2022-06-18 05:43:04.040312
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None


# Generated at 2022-06-18 05:43:08.433786
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response


# Generated at 2022-06-18 05:43:12.305051
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def handler(request, response):
        pass
    assert app._future_middleware[0].middleware == handler
    assert app._future_middleware[0].attach_to == 'response'

# Generated at 2022-06-18 05:43:15.993782
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:43:25.632238
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('pass')

    request, response = app.test_client.get('/')
    assert response.text == 'pass'


# Generated at 2022-06-18 05:43:30.953579
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    assert app._future_middleware == []


# Generated at 2022-06-18 05:43:39.340528
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.request import Request

    app = Sanic(__name__)

    @app.middleware
    def test_middleware(request):
        request['test'] = True

    @app.route('/')
    def handler(request):
        assert request['test']
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.json == {'test': True}



# Generated at 2022-06-18 05:43:43.331052
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic(__name__)
    @app.middleware
    def middleware(request):
        return request
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:43:49.140246
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def handler(request):
        return text('OK')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.text == 'OK'


# Generated at 2022-06-18 05:43:52.610733
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:44:03.023586
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    # test for @middleware
    @app.middleware
    def middleware(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == 'request'
    # test for @middleware('request')
    @app.middleware('request')
    def middleware(request):
        pass
    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == middleware
    assert app._future_middleware[1].attach_to == 'request'
    # test for @middleware('response')

# Generated at 2022-06-18 05:44:08.499191
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    app.middleware(None)
    app.middleware(None, 'request')
    app.middleware(None, 'response')
    app.on_request(None)
    app.on_response(None)


# Generated at 2022-06-18 05:44:13.365631
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:44:25.284138
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(middleware_or_request=None)
    test_middleware_mixin.middleware(middleware_or_request=None, attach_to="request")
    test_middleware_mixin.middleware(middleware_or_request=None, attach_to="response")
    test_middleware_mixin.middleware(middleware_or_request=None, attach_to="error")

# Generated at 2022-06-18 05:44:40.380346
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        return text('OK')

    @app.middleware('response')
    async def response_middleware(request, response):
        return text('OK')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:44:48.129098
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        request['middleware'] = 'this is a request middleware'

    @app.middleware('response')
    async def response_middleware(request, response):
        response.text += ' | this is a response middleware'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK | this is a response middleware'
    assert request['middleware'] == 'this is a request middleware'



# Generated at 2022-06-18 05:44:56.001161
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.request import Request

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:44:58.357678
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:45:01.792832
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:45:09.035470
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app._future_middleware == []
    assert app.middleware == app._future_middleware
    assert app.middleware('request') == app._future_middleware
    assert app.middleware('response') == app._future_middleware
    assert app.on_request == app._future_middleware
    assert app.on_response == app._future_middleware

# Generated at 2022-06-18 05:45:12.869479
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def middleware(request):
        return request
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:45:15.900816
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware
    assert app.on_request is MiddlewareMixin.on_request
    assert app.on_response is MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware is None


# Generated at 2022-06-18 05:45:27.855639
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    app.middleware(None)
    app.middleware(None, 'request')
    app.middleware(None, 'response')
    app.on_request(None)
    app.on_response(None)
    app.middleware(None, apply=False)
    app.middleware(None, 'request', apply=False)
    app.middleware(None, 'response', apply=False)
    app.on_request(None, apply=False)
    app.on_response(None, apply=False)
    app.middleware(None, apply=True)
    app.middleware(None, 'request', apply=True)
    app.middleware(None, 'response', apply=True)
   

# Generated at 2022-06-18 05:45:30.998879
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:45:51.916073
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def handler(request):
        return text('OK')
    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:46:04.352658
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.models.futures import FutureMiddleware

    app = Sanic(__name__)

    @app.middleware
    def test_middleware(request: Request):
        return json({"test": True})

    @app.middleware('request')
    def test_middleware_request(request: Request):
        return json({"test": True})

    @app.middleware('response')
    def test_middleware_response(request: Request, response: HTTPResponse):
        return json({"test": True})

    assert len(app._future_middleware) == 3

# Generated at 2022-06-18 05:46:09.833088
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware('request')
    async def request_middleware(request):
        pass
    @app.middleware('response')
    async def response_middleware(request, response):
        pass
    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].middleware == response_middleware
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-18 05:46:14.346727
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response

# Generated at 2022-06-18 05:46:18.616573
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware


# Generated at 2022-06-18 05:46:25.770191
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware(request):
        pass

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'


# Generated at 2022-06-18 05:46:32.889953
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def print_on_request(request):
        print("I am a request middleware")

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I am a response middleware")

    @app.route("/")
    async def handler(request):
        return json({"test": True})

    request, response = app.test_client.get("/")
    assert response.status == 200
    assert response.json == {"test": True}



# Generated at 2022-06-18 05:46:42.248947
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware is not None
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'
    @app.middleware('response')
    async def test_middleware_response(request, response):
        return response
    assert len(app._future_middleware) == 2

# Generated at 2022-06-18 05:46:48.526367
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app._future_middleware == []
    @app.middleware
    def middleware(request):
        pass
    assert app._future_middleware != []
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:46:56.812713
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware == MiddlewareMixin._apply_middleware
    assert app.middleware('request') == MiddlewareMixin.middleware(app, 'request')
    assert app.on_request() == MiddlewareMixin.on_request(app)
    assert app.on_response() == MiddlewareMixin.on_response(app)

# Generated at 2022-06-18 05:47:40.006996
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic()

    @app.middleware
    def middleware_1(request):
        return text("OK")

    @app.middleware('request')
    def middleware_2(request):
        return text("OK")

    @app.middleware('response')
    def middleware_3(request, response):
        return text("OK")

    assert len(app._future_middleware) == 3
    assert app._future_middleware[0].middleware == middleware_1
    assert app._future_middleware[1].middleware == middleware_2
    assert app._future_middleware[2].middleware == middleware_3


# Generated at 2022-06-18 05:47:46.307789
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        pass
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:47:57.265658
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'
    @app.middleware('response')
    async def test_middleware(request):
        return request
    assert app._future_middleware[1].middleware == test_middleware
    assert app._future_middleware[1].attach_to == 'response'

# Generated at 2022-06-18 05:48:08.867018
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import ServerError

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def middleware_test(request):
        request["test"] = "test"

    @app.middleware("response")
    async def middleware_test_response(request, response):
        response.body = b"test"

    @app.middleware("request")
    async def middleware_test_request(request):
        request["test"] = "test"

    @app.middleware("request")
    async def middleware_test_request_2(request):
        request["test"] = "test"


# Generated at 2022-06-18 05:48:14.111038
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].middleware(1) == 1
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"

    test_middleware_mixin = Test

# Generated at 2022-06-18 05:48:24.804322
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(middleware_or_request=lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    test_middleware_mixin.middleware(middleware_or_request='request', attach_to='request')
    assert len(test_middleware_mixin._future_middleware) == 2

# Generated at 2022-06-18 05:48:32.876806
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.middleware_called = False

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware_called = True

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert test_middleware_mixin.middleware_called


# Generated at 2022-06-18 05:48:40.791880
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        request['middleware1'] = True

    @app.middleware('request')
    async def middleware2(request):
        request['middleware2'] = True

    @app.middleware('response')
    async def middleware3(request, response):
        response.headers['middleware3'] = True

    @app.route('/')
    async def handler(request):
        return json({})

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.json == {}
    assert request['middleware1'] == True

# Generated at 2022-06-18 05:48:43.887557
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    app.middleware('request')(lambda x: x)
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:48:48.927596
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic()
    @app.middleware
    async def test_middleware(request):
        return text('test_middleware')
    @app.route('/')
    async def test(request):
        return text('test')
    request, response = app.test_client.get('/')
    assert response.text == 'test_middleware'