

# Generated at 2022-06-18 05:41:22.703224
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:41:25.890254
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def handle_request(request):
        return request
    assert app.on_request == app.middleware


# Generated at 2022-06-18 05:41:29.591520
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_on_request')

    @app.on_request
    def on_request(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'


# Generated at 2022-06-18 05:41:35.398176
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')

    @app.on_request
    def test_on_request(request):
        return request

    assert app.middleware[0].middleware == test_on_request


# Generated at 2022-06-18 05:41:40.485329
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic()

    @app.middleware
    async def test_middleware(request):
        return text("OK")

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:41:47.904336
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:41:53.306402
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic(__name__)

    @app.middleware
    def request_middleware(request):
        request["middleware"] = "test"

    @app.route("/")
    async def handler(request):
        return text(request["middleware"])

    request, response = app.test_client.get("/")

    assert response.text == "test"


# Generated at 2022-06-18 05:42:01.866532
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_test(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == middleware_test
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:42:13.531780
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.views import HTTPMethodView

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:42:24.287901
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()

    @app.middleware
    def middleware(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == "request"

    @app.middleware('response')
    def middleware(request):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == middleware
    assert app._future_middleware[1].attach_to == "response"

    @app.middleware('request')
    def middleware(request):
        pass

    assert len(app._future_middleware) == 3

# Generated at 2022-06-18 05:42:32.240524
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')

    @app.on_request
    def on_request(request):
        return request

    assert app.on_request(on_request) == on_request


# Generated at 2022-06-18 05:42:42.726089
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.views import HTTPMethodView

    app = Sanic('test_MiddlewareMixin_on_request')

    class SimpleView(HTTPMethodView):
        def get(self, request):
            return text('I am get')

        def post(self, request):
            return text('I am post')

    @app.on_request
    def before_request(request):
        request['test'] = 'test'

    app.add_route(SimpleView.as_view(), '/')

    _, response = app.test_client.get('/')
    assert response.text == 'I am get'
    assert response.request['test'] == 'test'


# Generated at 2022-06-18 05:42:47.561985
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware[0].middleware == test_on_request
    assert app.middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:42:52.614051
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_on_request')

    @app.on_request
    def test_on_request(request):
        pass

    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:42:58.688443
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(middleware_or_request=lambda x: x, attach_to="request")
    assert len(test_middleware_mixin._future_middleware) == 1
    test_middleware_mixin.middleware(middleware_or_request=lambda x: x, attach_to="response")

# Generated at 2022-06-18 05:43:03.872633
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:43:10.346884
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.views import HTTPMethodView

    app = Sanic("test_MiddlewareMixin_on_request")

    @app.on_request
    def before_request(request):
        return text("OK")

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")

    assert response.text == "OK"



# Generated at 2022-06-18 05:43:16.059809
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        response.body = b'on_response'
        return response
    request, response = app.test_client.get('/')
    assert response.body == b'on_response'


# Generated at 2022-06-18 05:43:20.701755
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:43:23.596141
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_response() == partial(app.middleware, attach_to="response")

# Generated at 2022-06-18 05:43:39.773945
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        pass

    @app.middleware('response')
    async def response_middleware(request, response):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].middleware == response_middleware
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-18 05:43:48.767851
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    @app.middleware
    def test_middleware(request):
        pass
    @app.on_request
    def test_on_request(request):
        pass
    @app.on_response
    def test_on_response(request, response):
        pass
    assert app._future_middleware is not None
    assert len(app._future_middleware) == 3
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'

# Generated at 2022-06-18 05:43:53.817871
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def test_middleware(request):
        return text("OK")

    request, response = app.test_client.get("/")

    assert response.text == "OK"

# Generated at 2022-06-18 05:44:05.362476
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def middleware1(request):
        return request

    @app.middleware('request')
    def middleware2(request):
        return request

    @app.middleware('response')
    def middleware3(request, response):
        return response

    @app.route('/')
    def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.json == {'test': True}
    assert len(app._future_middleware) == 3

# Generated at 2022-06-18 05:44:10.254407
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('pass')

    request, response = app.test_client.get('/')
    assert response.text == 'pass'

# Generated at 2022-06-18 05:44:17.276929
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    app = Sanic()

    @app.middleware
    async def print_on_request(request):
        print("I print when a request is received by the server")

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I print when a response is returned by the server")

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:44:28.790038
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware is test_middleware
    assert app._future_middleware[0].attach_to == 'request'
    @app.on_request
    async def test_on_request(request):
        return request
    assert app._future_middleware[1].middleware is test_on_request
    assert app._future_middleware[1].attach_to == 'request'

# Generated at 2022-06-18 05:44:34.199333
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'


# Generated at 2022-06-18 05:44:44.678773
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    assert app._future_middleware == []
    @app.middleware
    def middleware_1(request):
        pass
    assert app._future_middleware == [FutureMiddleware(middleware_1, "request")]
    @app.middleware("response")
    def middleware_2(request, response):
        pass
    assert app._future_middleware == [FutureMiddleware(middleware_1, "request"), FutureMiddleware(middleware_2, "response")]
    @app.middleware("request")
    def middleware_3(request):
        pass

# Generated at 2022-06-18 05:44:49.693590
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_test(request):
        return request

    assert app._future_middleware[0].middleware == middleware_test
    assert app._future_middleware[0].attach_to == 'request'

    @app.middleware('response')
    async def middleware_test2(request):
        return request

    assert app._future_middleware[1].middleware == middleware_test2
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-18 05:44:59.526070
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    @app.middleware
    def middleware(request):
        pass
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].args == ()
    assert app._future_middleware[0].kwargs == {}
    assert app._future_middleware[0].apply == True


# Generated at 2022-06-18 05:45:06.072469
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response


# Generated at 2022-06-18 05:45:14.371197
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import NotFound
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        request['middleware'] = 'this is a request middleware'

    @app.middleware('response')
    async def response_middleware(request, response):
        response.body = 'this is a response middleware'

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.status == 200

# Generated at 2022-06-18 05:45:20.957040
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware
    assert app.on_request is MiddlewareMixin.on_request
    assert app.on_response is MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware is None


# Generated at 2022-06-18 05:45:31.354386
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_1(request):
        request['middleware_1'] = 'middleware_1'

    @app.middleware('request')
    async def middleware_2(request):
        request['middleware_2'] = 'middleware_2'

    @app.middleware('response')
    async def middleware_3(request, response):
        response.text = response.text + 'middleware_3'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OKmiddleware_3'

# Generated at 2022-06-18 05:45:37.541107
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware
    assert app.on_request is MiddlewareMixin.on_request
    assert app.on_response is MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware is None


# Generated at 2022-06-18 05:45:43.185267
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware('request')
    async def request_middleware(request):
        pass
    @app.middleware('response')
    async def response_middleware(request, response):
        pass
    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-18 05:45:54.143756
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app._future_middleware == []
    @app.middleware
    def middleware1(request):
        pass
    assert app._future_middleware[0].middleware == middleware1
    assert app._future_middleware[0].attach_to == "request"
    @app.middleware('response')
    def middleware2(request, response):
        pass
    assert app._future_middleware[1].middleware == middleware2
    assert app._future_middleware[1].attach_to == "response"
    @app.middleware('request')
    def middleware3(request):
        pass
    assert app._future_middleware[2].middleware == middleware3
    assert app._future_middleware[2].attach_to

# Generated at 2022-06-18 05:46:01.614897
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware == MiddlewareMixin._apply_middleware

# Generated at 2022-06-18 05:46:06.127962
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    app.middleware(middleware_or_request=None, attach_to="request", apply=True)
    app.middleware(middleware_or_request=None, attach_to="response", apply=True)
    app.on_request(middleware=None)
    app.on_response(middleware=None)


# Generated at 2022-06-18 05:46:21.211574
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.request import Request

    app = Sanic()

    @app.middleware
    async def middleware(request):
        request['middleware'] = True
        return request

    @app.route('/')
    async def handler(request):
        assert request['middleware']
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:46:28.231216
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:46:32.572443
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    middleware_or_request = 'request'
    attach_to = 'request'
    apply = True
    app.middleware(middleware_or_request, attach_to, apply)
    assert app._future_middleware == []
    assert app._apply_middleware == NotImplementedError


# Generated at 2022-06-18 05:46:41.109316
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def print_on_request(request):
        print("I am a request middleware")

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I am a response middleware")

    @app.route('/')
    async def handler(request):
        return json({"test": True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {"test": True}


# Generated at 2022-06-18 05:46:46.600944
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import ServerError

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def handler(request):
        return text("OK")

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.status == 200
    assert response.text == "OK"

    @app.middleware("request")
    async def handler(request):
        return text("OK")

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.status == 200

# Generated at 2022-06-18 05:46:54.816893
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app.middleware(lambda x: x)
    assert app.on_request(lambda x: x)
    assert app.on_response(lambda x: x)
    assert app._future_middleware != []
    assert len(app._future_middleware) == 3

# Generated at 2022-06-18 05:47:02.569542
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import ServerError

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_test(request):
        request['middleware'] = 'works'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.text == 'OK'
    assert request['middleware'] == 'works'

    @app.middleware('request')
    async def middleware_test2(request):
        request['middleware2'] = 'works'


# Generated at 2022-06-18 05:47:05.618237
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:47:08.937325
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:47:20.347294
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def middleware1(request):
        pass
    @app.middleware('request')
    async def middleware2(request):
        pass
    @app.middleware('response')
    async def middleware3(request, response):
        pass
    assert len(app._future_middleware) == 3
    assert app._future_middleware[0].middleware == middleware1
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].middleware == middleware2
    assert app._future_middleware[1].attach_to == 'request'
    assert app._future_middleware[2].middleware == middleware

# Generated at 2022-06-18 05:47:46.385172
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:47:57.307410
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.views import HTTPMethodView
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_1(request):
        pass

    @app.middleware('request')
    async def middleware_2(request):
        pass

    @app.middleware('response')
    async def middleware_3(request, response):
        pass

    @app.middleware('request')
    async def middleware_4(request):
        pass

    @app.middleware('response')
    async def middleware_5(request, response):
        pass


# Generated at 2022-06-18 05:48:02.726057
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        pass
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:48:07.102947
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:48:11.091516
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware


# Generated at 2022-06-18 05:48:17.472559
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:48:26.565742
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic(__name__)

    @app.middleware
    async def print_on_request(request):
        print("I print when a request is received by the server")

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I print when a response is returned by the server")

    @app.route('/')
    async def handler(request):
        return json({'hello': 'world'})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'hello': 'world'}


# Generated at 2022-06-18 05:48:36.586445
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddlewareType

    app = Sanic()

    @app.middleware
    async def middleware_request(request):
        request['middleware'] = True

    @app.middleware('response')
    async def middleware_response(request, response):
        response.headers['middleware'] = 'True'

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert request.json.get('test')
    assert request

# Generated at 2022-06-18 05:48:41.282714
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test')
    assert app.middleware(middleware_or_request='request')
    assert app.middleware(middleware_or_request='response')
    assert app.middleware(middleware_or_request=lambda x: x)


# Generated at 2022-06-18 05:48:45.158740
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:49:36.835147
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        def get(self, request):
            return text("OK")

    app = Sanic("test_MiddlewareMixin_middleware")
    app.add_route(MyView.as_view(), "/")

    @app.middleware
    async def test_middleware(request):
        request["test"] = True

    request, response = app.test_client.get("/")
    assert request["test"] is True



# Generated at 2022-06-18 05:49:48.463067
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []

    @app.middleware('request')
    def test_middleware(request):
        return request

    assert app._future_middleware == [FutureMiddleware(test_middleware, 'request')]
    assert app.middleware(test_middleware) == test_middleware
    assert app.middleware(test_middleware, 'response') == test_middleware
    assert app.on_request(test_middleware) == test_middleware
    assert app.on_

# Generated at 2022-06-18 05:49:59.035207
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        pass

    @app.middleware('response')
    async def response_middleware(request, response):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].middleware == response_middleware
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-18 05:50:02.838223
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()

    @app.middleware
    async def middleware(request):
        return request

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == "request"

    @app.middleware('response')
    async def middleware(request):
        return request

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == middleware
    assert app._future_middleware[1].attach_to == "response"

    @app.middleware('request')
    async def middleware(request):
        return request

    assert len(app._future_middleware) == 3
    assert app._

# Generated at 2022-06-18 05:50:07.864225
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:50:12.758085
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    app.middleware(None)
    app.middleware(None, 'request')
    app.middleware(None, 'response')
    app.on_request(None)
    app.on_response(None)


# Generated at 2022-06-18 05:50:19.660207
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('I run on each request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('I run on each response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:50:32.513053
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.request import Request
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddlewareAttachType
    from sanic.models.futures import FutureMiddlewareAttachType
    from sanic.models.futures import FutureMiddlewareAttachType

    app = Sanic()

    @app.middleware
    def middleware_1(request):
        return text("OK")

    @app.middleware('request')
    def middleware_2(request):
        return text("OK")

    @app.middleware('response')
    def middleware_3(request, response):
        return text("OK")


# Generated at 2022-06-18 05:50:41.921441
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1

# Generated at 2022-06-18 05:50:52.966223
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda request: request)
    assert len(test_middleware_mixin._future_middleware) == 1
    test_middleware_mixin.middleware(lambda request: request, attach_to="request")
    assert len(test_middleware_mixin._future_middleware) == 2