

# Generated at 2022-06-18 05:41:32.382922
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:41:37.207446
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_request() == partial(app.middleware, attach_to="request")
    assert app.on_request(lambda x: x) == app.middleware(lambda x: x, "request")


# Generated at 2022-06-18 05:41:41.206635
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:41:47.582161
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic()
    @app.on_request
    def on_request(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].middleware == on_request


# Generated at 2022-06-18 05:41:52.523422
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        print('test_on_request')
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:42:00.847291
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:42:12.632558
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.middleware_list = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware_list.append(middleware)

    test_middleware_mixin = TestMiddlewareMixin()
    @test_middleware_mixin.on_request()
    def test_middleware(request):
        pass
    assert len(test_middleware_mixin.middleware_list) == 1
    assert test_middleware_mixin.middleware_list[0].attach_to == "request"
    assert test_middleware_mixin.middleware_list[0].middleware == test

# Generated at 2022-06-18 05:42:22.719397
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    assert len(test_middleware_mixin._future_middleware) == 0

    @test_middleware_mixin.on_request
    def test_middleware(request):
        pass

    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"
    assert test_middleware_mixin._future_middleware[0].middleware == test_middleware


# Generated at 2022-06-18 05:42:26.944013
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:42:32.070279
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app.on_request(test_on_request) == test_on_request


# Generated at 2022-06-18 05:42:38.357903
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_test(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'


# Generated at 2022-06-18 05:42:43.672559
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:42:48.188214
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic(__name__)
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:42:53.227541
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_on_request")
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:42:56.199546
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:43:07.948356
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import ServerError
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware

# Generated at 2022-06-18 05:43:15.709339
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(middleware_or_request=None)
    test_middleware_mixin.middleware(middleware_or_request=None, attach_to="request")
    test_middleware_mixin.middleware(middleware_or_request=None, attach_to="response")
    test_middleware_mixin.middleware(middleware_or_request=None, attach_to="request", apply=True)
    test_middleware

# Generated at 2022-06-18 05:43:19.693544
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic()
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:43:25.518913
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    app.middleware(None)
    app.middleware(None, 'request')
    app.middleware(None, 'response')
    app.middleware(None, apply=True)
    app.middleware(None, 'request', apply=True)
    app.middleware(None, 'response', apply=True)
    app.on_request(None)
    app.on_response(None)


# Generated at 2022-06-18 05:43:37.774049
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.testing import HOST, PORT

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        request['middleware1'] = True

    @app.middleware('request')
    async def middleware2(request):
        request['middleware2'] = True

    @app.middleware('response')
    async def middleware3(request, response):
        response.text += ' middleware3'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert request.json.get('middleware1') is True
    assert request.json

# Generated at 2022-06-18 05:43:44.230631
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_request() == partial(app.middleware, attach_to="request")
    assert app.on_request(lambda x: x) == app.middleware(lambda x: x, attach_to="request")


# Generated at 2022-06-18 05:43:49.526059
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import json
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        return json({'test': 'test_MiddlewareMixin_on_request'})
    request, response = app.test_client.get('/')
    assert response.json == {'test': 'test_MiddlewareMixin_on_request'}


# Generated at 2022-06-18 05:43:52.403190
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        return request
    assert app.middleware_stack[0].attach_to == 'request'
    assert app.middleware_stack[0].middleware == on_request


# Generated at 2022-06-18 05:43:57.979591
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[0].middleware == on_request


# Generated at 2022-06-18 05:44:01.958485
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware[0].middleware == test_on_request


# Generated at 2022-06-18 05:44:08.602148
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:44:12.789549
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        return request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:44:20.969933
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_on_request')

    @app.on_request
    def on_request_middleware(request):
        request['test'] = 'test'

    @app.route('/')
    async def handler(request):
        return text(request['test'])

    request, response = app.test_client.get('/')

    assert response.text == 'test'

# Generated at 2022-06-18 05:44:25.884602
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:44:28.687402
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test')
    assert app.on_request == app.middleware(attach_to='request')


# Generated at 2022-06-18 05:44:38.156846
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    app = Sanic()

    @app.on_request
    def on_request(request):
        pass

    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:44:43.731877
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:44:53.816462
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return json({'test': 'middleware'})

    @app.route('/')
    async def handler(request):
        return json({'test': 'handler'})

    request, response = app.test_client.get('/')

    assert response.json == {'test': 'middleware'}

    request, response = app.test_client.get('/')

    assert response.json == {'test': 'handler'}



# Generated at 2022-06-18 05:44:57.943990
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    app.on_request(lambda request: request)

# Generated at 2022-06-18 05:45:04.986566
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    assert app._future_middleware == []
    assert app._apply_middleware is None
    assert app.middleware('request') is not None
    assert app.middleware('response') is not None
    assert app.on_request() is not None
    assert app.on_response() is not None

# Generated at 2022-06-18 05:45:10.021178
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware_stack[0].middleware == test_on_request


# Generated at 2022-06-18 05:45:13.689110
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:45:15.721516
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_request(middleware=None)


# Generated at 2022-06-18 05:45:27.675428
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic(__name__)

    @app.middleware('request')
    async def request_middleware(request):
        request['middleware'] = 'this is a request middleware'

    @app.middleware('response')
    async def response_middleware(request, response):
        response.text += ' this is a response middleware'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK this is a response middleware'
    assert request['middleware'] == 'this is a request middleware'


# Generated at 2022-06-18 05:45:31.530815
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_on_request")
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware_stack[0].middleware == test_on_request


# Generated at 2022-06-18 05:45:48.278312
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_test(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:45:52.946629
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:46:00.223617
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request_middleware(request):
        return request
    assert app._future_middleware[0].middleware == on_request_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:46:08.090020
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def middleware_1(request):
        return json({'middleware_1': 'middleware_1'})

    @app.middleware('request')
    def middleware_2(request):
        return json({'middleware_2': 'middleware_2'})

    @app.middleware('response')
    def middleware_3(request, response):
        return json({'middleware_3': 'middleware_3'})

    @app.route('/')
    def handler(request):
        return json({'test': 'test'})



# Generated at 2022-06-18 05:46:10.517237
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_request(middleware=None)


# Generated at 2022-06-18 05:46:12.947361
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:46:17.803232
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic()
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware_stack[0].attach_to == "request"
    assert app.middleware_stack[0].middleware == test_on_request


# Generated at 2022-06-18 05:46:21.739343
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic(__name__)
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:46:28.859630
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:46:36.281907
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic(__name__)
    @app.on_request
    def test_on_request(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].middleware == test_on_request


# Generated at 2022-06-18 05:47:07.801076
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def middleware1(request):
        return json({'middleware1': 'middleware1'})
    @app.middleware('request')
    async def middleware2(request):
        return json({'middleware2': 'middleware2'})
    @app.middleware('response')
    async def middleware3(request, response):
        return json({'middleware3': 'middleware3'})

    assert len(app._future_middleware) == 3
    assert isinstance(app._future_middleware[0], FutureMiddleware)

# Generated at 2022-06-18 05:47:14.392493
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware.__get__(app)
    assert app.on_request is MiddlewareMixin.on_request.__get__(app)
    assert app.on_response is MiddlewareMixin.on_response.__get__(app)


# Generated at 2022-06-18 05:47:25.838621
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic(__name__)

    @app.middleware('request')
    async def request_middleware(request):
        request['middleware'] = 'this is a request middleware'

    @app.middleware('response')
    async def response_middleware(request, response):
        response.text += ' this is a response middleware'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK this is a response middleware'
    assert request['middleware'] == 'this is a request middleware'


# Generated at 2022-06-18 05:47:33.041541
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app._future_middleware == []
    @app.middleware
    def test_middleware(request):
        pass
    assert len(app._future_middleware) == 1
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"
    @app.middleware('response')
    def test_middleware2(request):
        pass
    assert len(app._future_middleware) == 2
    assert isinstance(app._future_middleware[1], FutureMiddleware)
    assert app._future_middleware[1].middleware == test_middleware2
    assert app

# Generated at 2022-06-18 05:47:40.303980
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app.middleware(lambda x: x)
    assert app.on_request(lambda x: x)
    assert app.on_response(lambda x: x)
    assert app._future_middleware != []

# Generated at 2022-06-18 05:47:43.863867
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:47:49.367759
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware
    assert app.on_request is MiddlewareMixin.on_request
    assert app.on_response is MiddlewareMixin.on_response


# Generated at 2022-06-18 05:47:55.365377
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response


# Generated at 2022-06-18 05:48:02.226754
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic("test_MiddlewareMixin_middleware")
    @app.middleware
    async def middleware1(request):
        return text("OK")
    @app.middleware('request')
    async def middleware2(request):
        return text("OK")
    @app.middleware('response')
    async def middleware3(request, response):
        return text("OK")
    @app.middleware('request')
    async def middleware4(request):
        return text("OK")
    @app.middleware('response')
    async def middleware5(request, response):
        return text("OK")

# Generated at 2022-06-18 05:48:12.896347
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import NotFound
    from sanic.models.futures import FutureMiddleware

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def middleware1(request):
        request["middleware1"] = True

    @app.middleware("request")
    async def middleware2(request):
        request["middleware2"] = True

    @app.middleware("response")
    async def middleware3(request, response):
        response.headers["middleware3"] = True

    @app.route("/")
    async def handler(request):
        return json({"test": True})

    request, response = app.test_client.get("/")

    assert request

# Generated at 2022-06-18 05:48:57.616346
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware('request')
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:49:00.294915
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware


# Generated at 2022-06-18 05:49:09.994800
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic(__name__)

    @app.middleware
    async def middleware1(request):
        return text('pass')

    @app.middleware('request')
    async def middleware2(request):
        return text('pass')

    @app.middleware('response')
    async def middleware3(request, response):
        return text('pass')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:49:20.824101
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import SanicException
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        return json({'middleware1': 'OK'})

    @app.middleware('request')
    async def middleware2(request):
        return json({'middleware2': 'OK'})

    @app.middleware('response')
    async def middleware3(request, response):
        return json({'middleware3': 'OK'})

    @app.route('/')
    async def handler(request):
        return json({'test': 'OK'})

    request, response = app

# Generated at 2022-06-18 05:49:28.558153
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    test_middleware_mixin.middleware(lambda x: x, attach_to="request")
    assert len(test_middleware_mixin._future_middleware) == 2

# Generated at 2022-06-18 05:49:31.780486
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware


# Generated at 2022-06-18 05:49:35.906596
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('pass')

    request, response = app.test_client.get('/')
    assert response.text == 'pass'

# Generated at 2022-06-18 05:49:41.459291
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic()
    @app.middleware
    async def test_middleware(request):
        return text('test')
    assert app._future_middleware[0].middleware == test_middleware


# Generated at 2022-06-18 05:49:51.287353
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(middleware_or_request=lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    test_middleware_mixin.middleware(middleware_or_request=lambda x: x, attach_to="request")
    assert len(test_middleware_mixin._future_middleware) == 2
    test

# Generated at 2022-06-18 05:49:57.416014
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()
    assert app.middleware is MiddlewareMixin.middleware
    assert app.on_request is MiddlewareMixin.on_request
    assert app.on_response is MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware is MiddlewareMixin._apply_middleware

# Generated at 2022-06-18 05:51:20.331536
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('pass')

    request, response = app.test_client.get('/')
    assert response.text == 'pass'


# Generated at 2022-06-18 05:51:26.099664
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def handler(request):
        return text("OK")

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.text == "OK"