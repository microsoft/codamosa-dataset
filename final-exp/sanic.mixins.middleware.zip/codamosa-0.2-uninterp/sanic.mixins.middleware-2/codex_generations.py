

# Generated at 2022-06-18 05:41:26.691839
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic(__name__)

    @app.middleware
    def test_middleware(request):
        return request

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"

    @app.middleware('response')
    def test_middleware_response(request, response):
        return response

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == test_middleware_response
    assert app._future_middleware[1].attach_to == "response"


# Generated at 2022-06-18 05:41:32.199867
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(middleware_or_request=None)



# Generated at 2022-06-18 05:41:37.733182
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_on_request')

    @app.on_request
    def on_request(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:41:41.229784
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def response_middleware(request, response):
        return response
    assert app._future_middleware[0].middleware == response_middleware
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:41:51.765311
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        return text('Pass')

    @app.middleware('request')
    async def middleware2(request):
        return text('Pass')

    @app.middleware('response')
    async def middleware3(request, response):
        return text('Pass')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'Pass'

    request, response = app.test_client.get('/')
    assert response.text == 'Pass'

    request, response = app.test_

# Generated at 2022-06-18 05:41:55.471852
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware == MiddlewareMixin._apply_middleware


# Generated at 2022-06-18 05:42:07.581173
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_on_request')

    @app.route('/')
    async def handler(request):
        return text('OK')

    @app.middleware('request')
    async def handler_middleware(request):
        return text('OK')

    @app.on_request(handler_middleware)
    async def handler_middleware(request):
        return text('OK')

    @app.exception(NotFound)
    async def ignore_404s(request, exception):
        return text("Yep, I totally found the page: {}".format(request.url))


# Generated at 2022-06-18 05:42:13.579870
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('pass')

    request, response = app.test_client.get('/')
    assert response.text == 'pass'


# Generated at 2022-06-18 05:42:22.939065
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def print_on_request(request):
        print('I run on each request!')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('I run on each response!')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    _, response = app.test_client.get('/')
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:42:26.798757
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def response_middleware(request, response):
        pass
    assert app._future_middleware[0].middleware == response_middleware
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:42:34.146122
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:42:44.390130
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware

    app = Sanic()

    @app.middleware('request')
    async def request_middleware(request):
        request['middleware'] = 'this is a test'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'OK'
    assert request['middleware'] == 'this is a test'

    @app.middleware('response')
    async def response_middleware(request, response):
        response.headers['Server'] = 'Sanic'


# Generated at 2022-06-18 05:42:54.508720
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic()

    @app.middleware
    async def middleware1(request):
        request['middleware1'] = True

    @app.middleware('request')
    async def middleware2(request):
        request['middleware2'] = True

    @app.middleware('response')
    async def middleware3(request, response):
        response.text += 'middleware3'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OKmiddleware3'
    assert request['middleware1'] is True
    assert request['middleware2'] is True



# Generated at 2022-06-18 05:43:01.477509
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:43:11.128842
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1

# Generated at 2022-06-18 05:43:16.553199
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware[0].middleware == test_on_request
    assert app.middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:43:21.416964
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:43:25.139951
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware_stack[0].middleware == test_on_request


# Generated at 2022-06-18 05:43:29.750311
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic(__name__)
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:43:35.319947
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic()
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:43:43.459821
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:43:51.213365
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_on_request')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    @app.exception(NotFound)
    async def ignore_404s(request, exception):
        return json({'test': True})

    @app.on_request
    async def before_request(request):
        request['test'] = True

    request, response = app.test_client.get('/')
    assert response.json == {'test': True}
    assert request['test'] is True

    request, response = app.test_client.get('/a_random_page')
    assert response.json

# Generated at 2022-06-18 05:43:56.199723
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware[0].middleware == test_on_request
    assert app.middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:44:01.958485
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:44:09.589686
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    app.middleware(middleware_or_request=None, attach_to="request", apply=True)
    app.middleware(middleware_or_request=None, attach_to="response", apply=True)
    app.on_request(middleware=None)
    app.on_response(middleware=None)


# Generated at 2022-06-18 05:44:17.593061
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import NotFound
    from sanic.exceptions import ServerError
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import Unauthorized
    from sanic.exceptions import Forbidden
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import NotFound
    from sanic.exceptions import ServerError
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import InvalidUsage

# Generated at 2022-06-18 05:44:23.809232
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')

    @app.on_request
    def on_request(request):
        return request

    assert app.middleware_stack[0].middleware == on_request
    assert app.middleware_stack[0].attach_to == 'request'


# Generated at 2022-06-18 05:44:28.943313
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware[0].middleware == test_on_request
    assert app.middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:44:34.333879
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:44:40.376187
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_on_request")
    @app.on_request
    def test(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:44:52.099938
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:44:56.374489
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware.__get__(app)
    assert app.on_request is MiddlewareMixin.on_request.__get__(app)
    assert app.on_response is MiddlewareMixin.on_response.__get__(app)

# Generated at 2022-06-18 05:45:00.650233
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_request(lambda x: x)
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:45:07.710278
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic(__name__)

    @app.on_request
    def on_request(request):
        return text('on_request')

    request, response = app.test_client.get('/')
    assert response.text == 'on_request'


# Generated at 2022-06-18 05:45:10.213617
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    @app.on_request
    def on_request(request):
        return request
    assert app.on_request == on_request


# Generated at 2022-06-18 05:45:15.601356
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware(None)
    assert app.middleware(None, 'request')
    assert app.middleware(None, 'response')
    assert app.on_request(None)
    assert app.on_response(None)


# Generated at 2022-06-18 05:45:21.975275
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_on_request")
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:45:27.345566
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:45:33.317944
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')

    @app.on_request
    def on_request(request):
        print('on_request')

    assert app.on_request == app.middleware
    assert app.on_request == app.middleware('request')
    assert app.on_request('request') == app.middleware('request')


# Generated at 2022-06-18 05:45:39.514535
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request

    assert app.on_request(test_on_request) == test_on_request
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:46:02.806188
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.middleware_called = False

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware_called = True

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert test_middleware_mixin.middleware_called


# Generated at 2022-06-18 05:46:13.518796
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].middleware(1) == 1
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"

    test_middleware_mixin.middleware(lambda x: x, attach_to="response")
    assert len

# Generated at 2022-06-18 05:46:22.344589
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import ServerError
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        request['middleware1'] = True

    @app.middleware('request')
    async def middleware2(request):
        request['middleware2'] = True

    @app.middleware('response')
    async def middleware3(request, response):
        response.body = b'middleware3'

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert request

# Generated at 2022-06-18 05:46:29.070715
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    from sanic.request import Request

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:46:39.605902
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()

    @test_middleware_mixin.middleware
    def test_middleware(request):
        pass

    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].middleware == test_middleware
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:46:45.441082
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('I run on each request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('I run on each response')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:46:50.913961
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    app = Sanic()

    @app.middleware
    async def handler(request):
        return json({"test": True})

    request, response = app.test_client.get("/")
    assert response.json == {"test": True}

# Generated at 2022-06-18 05:46:58.106661
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    test_middleware_mixin.middleware(lambda x: x, attach_to="request")
    assert len(test_middleware_mixin._future_middleware) == 2
    test_middleware_mixin.middleware(lambda x: x, attach_to="response")
    assert len(test_middleware_mixin._future_middleware) == 3

# Generated at 2022-06-18 05:47:03.147284
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic()

    @app.middleware
    async def middleware(request):
        request["middleware"] = True

    @app.route("/")
    async def handler(request):
        assert request["middleware"]
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.text == "OK"

# Generated at 2022-06-18 05:47:10.904489
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_test(request):
        return text('OK')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

    @app.middleware('request')
    async def middleware_test(request):
        return text('OK')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:47:49.626194
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(middleware_or_request=lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    test_middleware_mixin.middleware(middleware_or_request=lambda x: x, attach_to="response")
    assert len(test_middleware_mixin._future_middleware) == 2
    test

# Generated at 2022-06-18 05:47:59.803694
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic()

    @app.middleware
    async def middleware_1(request):
        request['middleware_1'] = True

    @app.middleware('request')
    async def middleware_2(request):
        request['middleware_2'] = True

    @app.middleware('response')
    async def middleware_3(request, response):
        response.text = 'middleware_3'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'middleware_3'
    assert request['middleware_1'] is True
    assert request['middleware_2'] is True


# Generated at 2022-06-18 05:48:04.306365
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert isinstance(app, MiddlewareMixin)
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response

# Generated at 2022-06-18 05:48:08.298544
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic(__name__)
    app.middleware(None)
    app.on_request(None)
    app.on_response(None)


# Generated at 2022-06-18 05:48:16.694081
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.exceptions import SanicException

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def test_middleware(request):
        return json({'test': True})

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.json == {'test': True}

    @app.middleware('request')
    def test_middleware(request):
        return json({'test': True})


# Generated at 2022-06-18 05:48:25.554448
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    app.middleware(None)
    app.middleware(None, attach_to="request")
    app.middleware(None, attach_to="response")
    app.middleware(None, apply=False)
    app.middleware(None, attach_to="request", apply=False)
    app.middleware(None, attach_to="response", apply=False)
    app.middleware(None, apply=True)
    app.middleware(None, attach_to="request", apply=True)
    app.middleware(None, attach_to="response", apply=True)


# Generated at 2022-06-18 05:48:31.909311
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    app.middleware('request')(lambda x: x)
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == 'request'

# Generated at 2022-06-18 05:48:35.727140
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:48:42.743045
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    app = Sanic(__name__)

    @app.middleware
    async def print_on_request(request):
        print("I print when a request is received by the server")

    @app.middleware('request')
    async def halt_request(request):
        return json({'test': True})

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I print when a response is returned by the server")

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}

    request

# Generated at 2022-06-18 05:48:52.570885
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware is test_middleware
    assert app._future_middleware[0].attach_to == 'request'
    @app.middleware('response')
    async def test_middleware_response(request):
        return request
    assert app._future_middleware[1].middleware is test_middleware_response
    assert app._future_middleware[1].attach_to == 'response'

# Generated at 2022-06-18 05:49:56.257880
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        pass

    @app.middleware('response')
    async def response_middleware(request, response):
        pass

    @app.middleware
    async def default_middleware(request):
        pass

    assert len(app._future_middleware) == 3
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].attach_to == 'response'
    assert app._future_middleware[2].attach_to == 'request'


# Generated at 2022-06-18 05:50:02.026276
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:50:12.370911
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware
    from sanic.models.middleware import Middleware
    from sanic.models.middleware import RequestMiddleware
    from sanic.models.middleware import ResponseMiddleware

    app = Sanic()

    @app.middleware
    def middleware(request):
        pass

    @app.middleware('request')
    def request_middleware(request):
        pass

    @app.middleware('response')
    def response_middleware(request, response):
        pass

    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert isinstance(app._future_middleware[0].middleware, Middleware)
    assert isinstance(app._future_middleware[1], FutureMiddleware)

# Generated at 2022-06-18 05:50:16.468112
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:50:23.437680
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        def get(self, request):
            return text("I am get method")

        def post(self, request):
            return text("I am post method")

    app = Sanic("test_MiddlewareMixin_middleware")
    app.add_route(MyView.as_view(), "/test")

    @app.middleware
    async def print_on_request(request):
        print("I am request middleware")

    @app.middleware("response")
    async def print_on_response(request, response):
        print("I am response middleware")

    request, response = app.test_client.get("/test")


# Generated at 2022-06-18 05:50:27.375749
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:50:37.933957
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('I run on each request')

    @app.middleware('request')
    async def print_on_request2(request):
        print('I run on each request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('I run on each response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:50:42.649536
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_MiddlewareMixin_middleware_middleware(request):
        pass
    assert app._future_middleware[0].middleware == test_MiddlewareMixin_middleware_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:50:47.152842
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:50:57.813997
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware