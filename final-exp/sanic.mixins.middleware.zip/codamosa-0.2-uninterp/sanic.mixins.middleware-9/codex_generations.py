

# Generated at 2022-06-18 05:41:29.830986
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:41:39.354287
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_on_response')

    @app.middleware
    async def print_on_request(request):
        print('before request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('after response')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'OK'


# Generated at 2022-06-18 05:41:49.755578
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_request(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:41:58.176349
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        return text('Passed')

    @app.middleware('request')
    async def middleware2(request):
        return text('Passed')

    @app.middleware('response')
    async def middleware3(request, response):
        return text('Passed')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'Passed'

   

# Generated at 2022-06-18 05:42:09.970223
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware

    app = Sanic()

    @app.middleware('request')
    async def request_middleware(request):
        request['middleware'] = 'this is a request middleware'

    @app.middleware('response')
    async def response_middleware(request, response):
        response.text = 'this is a response middleware'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert request['middleware'] == 'this is a request middleware'
    assert response.text == 'this is a response middleware'


# Generated at 2022-06-18 05:42:21.855685
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware
    assert app.on_request is MiddlewareMixin.on_request
    assert app.on_response is MiddlewareMixin.on_response

    @app.middleware
    def test_middleware(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"

    @app.middleware('response')
    def test_middleware_response(request, response):
        pass

    assert len(app._future_middleware) == 2

# Generated at 2022-06-18 05:42:26.217586
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:42:37.514334
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic()

    @app.middleware
    async def middleware1(request):
        request['middleware1'] = True

    @app.middleware('request')
    async def middleware2(request):
        request['middleware2'] = True

    @app.middleware('response')
    async def middleware3(request, response):
        response.text += ' middleware3'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK middleware3'
    assert request['middleware1']
    assert request['middleware2']


# Generated at 2022-06-18 05:42:41.219496
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware_stack[0].middleware == test_on_request


# Generated at 2022-06-18 05:42:52.008618
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    @app.middleware
    def test_middleware(request):
        pass
    @app.on_request
    def test_on_request(request):
        pass
    @app.on_response
    def test_on_response(request, response):
        pass
    assert len(app._future_middleware) == 3
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[1].middleware == test_on_request
    assert app._future_middleware[2].middleware == test_on_response

# Generated at 2022-06-18 05:43:02.589794
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:43:06.623807
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response


# Generated at 2022-06-18 05:43:11.572041
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:43:16.028836
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic(__name__)
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app.middleware_stack[0].middleware == test_on_response


# Generated at 2022-06-18 05:43:21.138600
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:43:25.828456
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')

    @app.on_response
    def response_middleware(request, response):
        return response

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == 'response'
    assert app._future_middleware[0].middleware == response_middleware


# Generated at 2022-06-18 05:43:37.068782
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('I run on each request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('I run on each response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:43:38.866111
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        response.headers["X-Test"] = "test"
    request, response = app.test_client.get('/')
    assert response.headers["X-Test"] == "test"


# Generated at 2022-06-18 05:43:43.549145
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:43:48.478855
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('Response from {}'.format(request.url))

    assert app.on_response() == app.middleware('response')
    assert app.on_response(print_on_response) == app.middleware('response')


# Generated at 2022-06-18 05:43:55.920328
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response


# Generated at 2022-06-18 05:44:01.296105
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:44:07.847139
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def handler(request, response):
        pass
    assert app._future_middleware[0].middleware == handler
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:44:16.161185
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app._future_middleware == []
    @app.middleware
    def test_middleware(request):
        pass
    assert app._future_middleware != []
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'
    @app.middleware('response')
    def test_middleware2(request, response):
        pass
    assert app._future_middleware[1].middleware == test_middleware2
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-18 05:44:27.674447
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import SanicException
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('I run on each request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('I run on each response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.status == 200

# Generated at 2022-06-18 05:44:29.508304
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_response is not None

# Generated at 2022-06-18 05:44:37.252627
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic()

    @app.middleware
    async def print_on_request(request):
        print("I am a request middleware")

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I am a response middleware")

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'OK'

# Generated at 2022-06-18 05:44:42.944126
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_on_response")
    @app.on_response
    def on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:44:50.712522
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    app.middleware(middleware_or_request='request')
    app.middleware(middleware_or_request='response')
    app.middleware(middleware_or_request=lambda request: None)
    app.middleware(middleware_or_request=lambda response: None)
    app.on_request(middleware=lambda request: None)
    app.on_response(middleware=lambda response: None)


# Generated at 2022-06-18 05:44:55.397710
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_on_response")
    @app.on_response
    def response_middleware(request, response):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "response"
    assert app._future_middleware[0].middleware == response_middleware


# Generated at 2022-06-18 05:45:07.588972
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:45:12.803057
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic("test_MiddlewareMixin_on_response")

    @app.on_response
    def on_response(request, response):
        response.text = "on_response"

    @app.route("/")
    def handler(request):
        return text("test")

    request, response = app.test_client.get("/")

    assert response.text == "on_response"



# Generated at 2022-06-18 05:45:16.935255
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.middleware('response')
    async def process_response(request, response):
        response.headers['X-Served-By'] = 'sanic'
        return response
    @app.route('/')
    async def handler(request):
        return text('OK')
    request, response = app.test_client.get('/')
    assert response.headers.get('X-Served-By') == 'sanic'


# Generated at 2022-06-18 05:45:25.591771
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import json

    app = Sanic('test_MiddlewareMixin_on_response')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('Before response sent to client')

    @app.route('/')
    async def handler(request):
        return json({'test': 42})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': 42}


# Generated at 2022-06-18 05:45:33.051312
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic("test_MiddlewareMixin_on_response")

    @app.on_response
    def on_response(request, response):
        response.headers["X-Served-By"] = "sanic"

    @app.route("/")
    async def handler(request):
        return json({"hello": "world"})

    request, response = app.test_client.get("/")

    assert response.headers["X-Served-By"] == "sanic"


# Generated at 2022-06-18 05:45:40.242211
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_on_response')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('Response from {}'.format(request.url))

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'OK'


# Generated at 2022-06-18 05:45:48.047941
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def middleware(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:45:52.732672
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:46:03.436140
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = TestMiddlewareMixin()

    @app.on_response
    def test_middleware(request, response):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "response"



# Generated at 2022-06-18 05:46:14.449742
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import ServerError
    from sanic.models.futures import FutureMiddleware

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    def middleware_test(request):
        return json({"middleware": "test"})

    @app.middleware("request")
    def middleware_request(request):
        return json({"middleware": "request"})

    @app.middleware("response")
    def middleware_response(request, response):
        return json({"middleware": "response"})

    @app.route("/")
    def handler(request):
        return json({"test": True})


# Generated at 2022-06-18 05:46:42.764098
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        return text('Pass')

    @app.middleware('request')
    async def middleware2(request):
        return text('Pass')

    @app.middleware('response')
    async def middleware3(request, response):
        return text('Pass')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'Pass'

    request, response = app.test_client.get('/')
    assert response.text == 'Pass'


# Generated at 2022-06-18 05:46:52.681489
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def test_middleware(request):
        return text("OK")

    assert len(app._future_middleware) == 1
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:47:01.991622
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware == MiddlewareMixin._apply_middleware
    assert app.middleware(None) == MiddlewareMixin.middleware(app, None)
    assert app.on_request(None) == MiddlewareMixin.on_request(app, None)
    assert app.on_response(None) == MiddlewareMixin.on_response(app, None)

# Generated at 2022-06-18 05:47:06.664565
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def test_middleware(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.text == "OK"

# Generated at 2022-06-18 05:47:08.996122
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:47:15.245585
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:47:26.702629
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    test_middleware_mixin.middleware(lambda x: x, attach_to='request')
    assert len(test_middleware_mixin._future_middleware) == 2
    test_middleware_mixin.middleware(lambda x: x, attach_to='response')

# Generated at 2022-06-18 05:47:30.790039
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic(__name__)
    @app.middleware
    async def test_middleware(request):
        return request
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:47:37.431985
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()
    assert isinstance(app, MiddlewareMixin)
    assert app._future_middleware == []
    @app.middleware
    def test_middleware(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:47:43.175025
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return request

    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:48:15.176948
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def test_middleware(request):
        pass

    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'

    @app.middleware('response')
    def test_middleware(request):
        pass

    assert isinstance(app._future_middleware[1], FutureMiddleware)
    assert app._future_middleware[1].middleware == test_middleware
    assert app._future_middleware[1].attach_to == 'response'

#

# Generated at 2022-06-18 05:48:25.675980
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    from sanic.request import Request

    app = Sanic()

    @app.middleware
    async def middleware1(request):
        request['middleware1'] = True

    @app.middleware('request')
    async def middleware2(request):
        request['middleware2'] = True

    @app.middleware('response')
    async def middleware3(request, response):
        response.headers['middleware3'] = True

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}
    assert request.get('middleware1')


# Generated at 2022-06-18 05:48:35.945695
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        request['middleware'] = 'this is a test'

    @app.middleware('response')
    async def response_middleware(request, response):
        response.headers['Server'] = 'Ubuntu; Ubuntu; Ubuntu; Ubuntu;'

    @app.route('/')
    async def handler(request):
        return text('OK')


# Generated at 2022-06-18 05:48:45.101970
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    @app.middleware
    def test_middleware(request):
        return request
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    @app.on_response
    def test_on_response(request, response):
        return response

# Generated at 2022-06-18 05:48:48.447490
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.request import Request

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:48:58.762363
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(middleware_or_request=None)
    test_middleware_mixin.middleware(middleware_or_request=None, attach_to="request")
    test_middleware_mixin.middleware(middleware_or_request=None, attach_to="response")
    test_middleware_mixin.middleware(middleware_or_request=None, attach_to="request", apply=True)
    test_middleware

# Generated at 2022-06-18 05:49:04.477570
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    test_middleware_mixin.middleware(lambda x: x, attach_to="response")
    assert len(test_middleware_mixin._future_middleware) == 2

# Generated at 2022-06-18 05:49:14.195244
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    app = Sanic()

    @app.middleware
    async def print_on_request(request):
        print("I print when a request is received by the server")

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I print when a response is returned by the server")

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:49:24.543966
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    assert test_middleware_mixin._future_middleware == []
    test_middleware_mixin.middleware(middleware_or_request=lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1

# Generated at 2022-06-18 05:49:29.608519
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    assert app._future_middleware == []
    @app.middleware
    def middleware_test(request):
        return request
    assert app._future_middleware[0].middleware == middleware_test
    assert app._future_middleware[0].attach_to == "request"
    @app.middleware("response")
    def middleware_test2(request):
        return request
    assert app._future_middleware[1].middleware == middleware_test2
    assert app._future_middleware[1].attach_to == "response"


# Generated at 2022-06-18 05:50:20.995495
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware == MiddlewareMixin._apply_middleware


# Generated at 2022-06-18 05:50:29.355635
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware.__get__(app)
    assert app.on_request is MiddlewareMixin.on_request.__get__(app)
    assert app.on_response is MiddlewareMixin.on_response.__get__(app)
    assert app._future_middleware == []
    assert app._apply_middleware is MiddlewareMixin._apply_middleware.__get__(app)

# Generated at 2022-06-18 05:50:39.735487
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda request: None)
    assert len(test_middleware_mixin._future_middleware) == 1
    test_middleware_mixin.middleware(lambda request: None, attach_to="request")
    assert len(test_middleware_mixin._future_middleware) == 2

# Generated at 2022-06-18 05:50:44.192180
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic()
    @app.middleware
    async def middleware(request):
        return text('hello')
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:50:53.044130
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app._future_middleware == []
    app.middleware(lambda x: x)
    assert app._future_middleware != []

# Generated at 2022-06-18 05:50:59.388310
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:51:07.342954
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.request import Request

    app = Sanic(__name__)

    @app.middleware
    async def middleware_a(request):
        request['a'] = 'a'

    @app.middleware('request')
    async def middleware_b(request):
        request['b'] = 'b'

    @app.middleware('response')
    async def middleware_c(request, response):
        response.text += 'c'

    @app.route('/')
    async def handler(request):
        return text('d')

    request, response = app.test_client.get('/')
    assert request.get('a') == 'a'
    assert request.get('b') == 'b'
    assert response

# Generated at 2022-06-18 05:51:19.035377
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        request['middleware'] = 'this is a request middleware'

    @app.middleware('response')
    async def response_middleware(request, response):
        response.text += ' | this is a response middleware'

    @app.route('/')
    async def handler(request):
        return text('this is a normal response')

    request, response = app.test_client.get('/')

    assert response.text == 'this is a normal response | this is a response middleware'
    assert request['middleware'] == 'this is a request middleware'


# Generated at 2022-06-18 05:51:27.910863
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic(__name__)
    app.middleware('request')(lambda x: x)
    app.middleware('response')(lambda x: x)
    app.middleware(lambda x: x)
    app.on_request(lambda x: x)
    app.on_response(lambda x: x)
    assert len(app._future_middleware) == 5
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].attach_to == 'response'
    assert app._future_middleware[2].attach_to == 'request'
    assert app._future_middleware[3].attach_to == 'request'
    assert app._future_middleware[4].attach_to == 'response'