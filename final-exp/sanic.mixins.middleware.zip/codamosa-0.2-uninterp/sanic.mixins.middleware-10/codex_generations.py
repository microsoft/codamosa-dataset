

# Generated at 2022-06-18 05:41:31.134957
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def middleware1(request):
        return text("OK")

    @app.middleware("request")
    async def middleware2(request):
        return text("OK")

    @app.middleware("response")
    async def middleware3(request, response):
        return text("OK")

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.text == "OK"

    request, response = app.test_client.get("/")
    assert response.text == "OK"

    request, response = app.test_

# Generated at 2022-06-18 05:41:36.885287
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic(__name__)
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:41:41.206243
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware[0].middleware == test_on_request
    assert app.middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:41:47.609545
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:41:52.781432
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic("test_MiddlewareMixin_on_request")
    assert app.on_request is app.middleware
    assert app.on_request("request") is app.middleware
    assert app.on_request("response") is app.middleware
    assert app.on_request("request") is app.middleware
    assert app.on_request("response") is app.middleware


# Generated at 2022-06-18 05:42:01.413772
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request_middleware(request):
        pass
    assert app._future_middleware[0].middleware == on_request_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:42:06.726139
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    assert app.on_request() == partial(app.middleware, attach_to="request")
    assert app.on_request(lambda x: x) == app.middleware(lambda x: x, "request")


# Generated at 2022-06-18 05:42:09.404884
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('pass')

    request, response = app.test_client.get('/')
    assert response.text == 'pass'


# Generated at 2022-06-18 05:42:21.765002
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddlewareType
    from sanic.models.futures import FutureMiddlewareAttachType
    from sanic.models.futures import FutureMiddlewareAttachType

    app = Sanic()

    @app.middleware
    async def middleware_request(request):
        request["middleware"] = True

    @app.middleware("response")
    async def middleware_response(request, response):
        response.text += "!"

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")

# Generated at 2022-06-18 05:42:25.948663
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:42:32.393498
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:42:34.572370
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('pass')

    request, response = app.test_client.get('/')
    assert response.text == 'pass'


# Generated at 2022-06-18 05:42:44.768433
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    assert app._future_middleware == []

    @app.middleware
    async def test_middleware(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"

    @app.middleware("response")
    async def test_middleware2(request):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == test_middleware2
    assert app._future_middleware[1].attach_to == "response"


# Generated at 2022-06-18 05:42:49.477688
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('pass')

    request, response = app.test_client.get('/')
    assert response.text == 'pass'

# Generated at 2022-06-18 05:43:01.082565
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    from sanic.request import Request

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('I am a request middleware')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('I am a response middleware')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.json == {'test': True}
    assert response.text == '{"test": true}'


# Generated at 2022-06-18 05:43:09.847168
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.request import Request

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('response')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'
    assert request.app == app
    assert isinstance(request, Request)


# Generated at 2022-06-18 05:43:20.068758
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app._future_middleware == []
    @app.middleware
    def test_middleware(request):
        return request
    assert app._future_middleware == [FutureMiddleware(test_middleware, "request")]
    @app.middleware('response')
    def test_middleware(request):
        return request
    assert app._future_middleware == [FutureMiddleware(test_middleware, "request"), FutureMiddleware(test_middleware, "response")]
    @app.middleware('request')
    def test_middleware(request):
        return request

# Generated at 2022-06-18 05:43:27.379344
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json

    app = Sanic(__name__)

    @app.middleware
    async def print_on_request(request):
        print("I print when a request is received by the server")

    @app.middleware('request')
    async def halt_request(request):
        return json({'test': True})

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I print when a response is returned by the server")

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}

    request, response

# Generated at 2022-06-18 05:43:39.645073
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda request: None)
    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"
    assert test_middleware_mixin._future_middleware[0].middleware(None) is None

    test_middleware_mixin.middle

# Generated at 2022-06-18 05:43:44.715484
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    app.middleware('request')(lambda x: x)
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == 'request'

# Generated at 2022-06-18 05:43:57.879337
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = App()
    @app.middleware
    def test_middleware(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:44:09.590210
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    from sanic.exceptions import NotFound
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('I run on each request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('I run on each response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    @app.exception(NotFound)
    async def ignore_404s(request, exception):
        return json({'status': 404})

    request, response = app.test_client.get('/')

# Generated at 2022-06-18 05:44:17.414392
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('I run on each request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('I run on each response')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:44:22.597862
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None


# Generated at 2022-06-18 05:44:31.300914
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:44:36.625354
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:44:46.122804
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app.middleware(middleware_or_request=None)
    assert app.middleware(middleware_or_request=None, attach_to="request")
    assert app.middleware(middleware_or_request=None, attach_to="response")
    assert app.middleware(middleware_or_request=None, apply=True)
    assert app.middleware(middleware_or_request=None, apply=False)
    assert app.middleware(middleware_or_request=None, attach_to="request", apply=True)
    assert app.middleware(middleware_or_request=None, attach_to="response", apply=False)

# Generated at 2022-06-18 05:44:51.324944
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware
    assert app.on_request is MiddlewareMixin.on_request
    assert app.on_response is MiddlewareMixin.on_response
    assert app._future_middleware == []


# Generated at 2022-06-18 05:44:55.322243
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app._future_middleware == []

    @app.middleware
    async def test_middleware(request):
        pass

    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:45:02.941389
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1

# Generated at 2022-06-18 05:45:13.198581
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:45:24.973042
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    test_middleware_mixin.middleware(lambda x: x, attach_to="response")
    assert len(test_middleware_mixin._future_middleware) == 2

# Generated at 2022-06-18 05:45:35.027319
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware):
            pass

    test_class = TestClass()
    test_class.middleware(lambda x: x)
    assert len(test_class._future_middleware) == 1
    assert test_class._future_middleware[0].attach_to == "request"

# Generated at 2022-06-18 05:45:41.029915
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Arrange
    from sanic.app import Sanic
    app = Sanic(__name__)
    # Act
    @app.middleware
    async def test_middleware(request):
        pass
    # Assert
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:45:50.583302
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app._future_middleware == []
    @app.middleware
    def middleware_test(request):
        pass
    assert app._future_middleware != []
    assert app._future_middleware[0].middleware == middleware_test
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].args == ()
    assert app._future_middleware[0].kwargs == {}
    assert app._future_middleware[0].apply == True


# Generated at 2022-06-18 05:45:58.566100
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda request: request)
    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"
    assert test_middleware_mixin._future_middleware[0].middleware(None) is None

    test_middleware_mixin.middle

# Generated at 2022-06-18 05:46:04.776211
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic(__name__)

    @app.middleware('request')
    async def request_middleware(request):
        request['middleware'] = 'this is a request middleware'

    @app.middleware('response')
    async def response_middleware(request, response):
        response.text += ' this is a response middleware'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK this is a response middleware'
    assert request['middleware'] == 'this is a request middleware'


# Generated at 2022-06-18 05:46:11.350283
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic()

    @app.middleware
    async def handler(request):
        return text("OK")

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")

    assert response.text == "OK"

# Generated at 2022-06-18 05:46:18.202862
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    app.middleware('request')(lambda x: x)
    app.middleware('response')(lambda x: x)
    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-18 05:46:29.488718
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    test_middleware_mixin.middleware(lambda x: x, attach_to="response")
    assert len(test_middleware_mixin._future_middleware) == 2
    test_middleware_mixin.middleware(lambda x: x, attach_to="request")
    assert len(test_middleware_mixin._future_middleware) == 3

# Generated at 2022-06-18 05:46:52.721749
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:47:01.819978
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware('request')
    async def request_middleware(request):
        pass
    @app.middleware('response')
    async def response_middleware(request, response):
        pass
    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].middleware == response_middleware
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-18 05:47:07.337330
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware
    assert app.on_request is MiddlewareMixin.on_request
    assert app.on_response is MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware is MiddlewareMixin._apply_middleware

# Generated at 2022-06-18 05:47:13.485385
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:47:18.778633
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def test_middleware(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:47:28.271200
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('response')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'
    assert response.status == 200


# Generated at 2022-06-18 05:47:40.650231
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.models.futures import FutureMiddleware

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def test_middleware(request):
        return text("OK")

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.text == "OK"

    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"

    #

# Generated at 2022-06-18 05:47:52.647768
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()

    @app.middleware
    def middleware_test(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == middleware_test
    assert app._future_middleware[0].attach_to == "request"

    @app.middleware('response')
    def middleware_test2(request, response):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == middleware_test2
    assert app._future_middleware[1].attach_to == "response"

    @app.middleware('request')
    def middleware_test3(request):
        pass


# Generated at 2022-06-18 05:47:57.489194
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()
    @app.middleware
    async def test_middleware(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:48:09.150297
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app._future_middleware == []
    app.middleware(middleware_or_request=None, attach_to="request", apply=True)
    assert app._future_middleware == []
    app.middleware(middleware_or_request=None, attach_to="response", apply=True)
    assert app._future_middleware == []
    app.middleware(middleware_or_request=None, attach_to="request", apply=False)
    assert app._future_middleware == []
    app.middleware(middleware_or_request=None, attach_to="response", apply=False)
    assert app._future_middleware == []

# Generated at 2022-06-18 05:48:42.836333
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    app.middleware('request')(lambda x: x)
    app.middleware('response')(lambda x: x)
    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-18 05:48:47.202408
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    assert app._future_middleware == []
    assert app._apply_middleware is None


# Generated at 2022-06-18 05:48:57.616025
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].middleware(1) == 1
    test_middleware_mixin.middleware(lambda x: x, attach_to="response")

# Generated at 2022-06-18 05:49:07.944384
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return json({'test': 'test_middleware'})

    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'

    @app.middleware('response')
    async def test_middleware_response(request, response):
        return json({'test': 'test_middleware_response'})


# Generated at 2022-06-18 05:49:18.018480
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic(__name__)

    @app.middleware
    async def middleware_1(request):
        request['middleware_1'] = True

    @app.middleware('request')
    async def middleware_2(request):
        request['middleware_2'] = True

    @app.middleware('response')
    async def middleware_3(request, response):
        response.text += 'middleware_3'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OKmiddleware_3'
    assert request['middleware_1']
    assert request['middleware_2']



# Generated at 2022-06-18 05:49:26.850768
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    test_middleware_mixin.middleware(lambda x: x, attach_to="response")
    assert len(test_middleware_mixin._future_middleware) == 2
    test_middleware_mixin.middleware(lambda x: x, attach_to="request")
    assert len(test_middleware_mixin._future_middleware) == 3


# Generated at 2022-06-18 05:49:32.729528
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    app.middleware(None)
    app.middleware(None, attach_to="request")
    app.middleware(None, attach_to="response")
    app.middleware(None, apply=True)
    app.middleware(None, attach_to="request", apply=True)
    app.middleware(None, attach_to="response", apply=True)
    app.on_request(None)
    app.on_response(None)


# Generated at 2022-06-18 05:49:44.172018
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware == MiddlewareMixin._apply_middleware
    assert app.middleware('request') == MiddlewareMixin.middleware(app, 'request')
    assert app.middleware('response') == MiddlewareMixin.middleware(app, 'response')
    assert app.on_request() == MiddlewareMixin.on_request(app)
    assert app.on_response() == MiddlewareMixin.on_response(app)
    assert app

# Generated at 2022-06-18 05:49:52.651586
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()

    @test_middleware_mixin.middleware
    def test_middleware(request):
        pass

    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].middleware == test_middleware
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"

    @test_middleware_mixin.middleware("response")
    def test_middleware_response(request):
        pass

    assert len(test_middleware_mixin._future_middleware) == 2
   

# Generated at 2022-06-18 05:49:58.281896
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'


# Generated at 2022-06-18 05:50:57.688646
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    app.middleware(None)
    app.middleware(None, 'request')
    app.middleware(None, 'response')
    app.on_request(None)
    app.on_response(None)


# Generated at 2022-06-18 05:51:02.920261
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:51:07.733710
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    assert app._apply_middleware is not None
    assert app._future_middleware is not None
    assert app.middleware('request') is not None
    assert app.on_request() is not None
    assert app.on_response() is not None

# Generated at 2022-06-18 05:51:14.559315
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware == MiddlewareMixin._apply_middleware


# Generated at 2022-06-18 05:51:24.466384
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    app = Sanic()

    @app.middleware
    async def print_on_request(request):
        print("I print when a request is received by the server")

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I print when a response is returned by the server")

    @app.route('/')
    async def handler(request):
        return json({'hello': 'world'})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'hello': 'world'}
