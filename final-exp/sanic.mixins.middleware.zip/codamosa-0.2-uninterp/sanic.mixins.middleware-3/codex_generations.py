

# Generated at 2022-06-18 05:41:39.051826
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:41:51.040985
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.models.futures import FutureMiddleware

    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = Sanic("test_MiddlewareMixin_middleware")
    test_middleware_mixin = TestMiddlewareMixin()
    @test_middleware_mixin.middleware
    async def test_middleware(request: Request):
        return HTTPResponse(text="test_middleware")

    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middle

# Generated at 2022-06-18 05:41:54.752727
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:42:01.371976
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:42:07.402684
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:42:12.265405
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        pass
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:42:23.468147
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware


# Generated at 2022-06-18 05:42:27.994392
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:42:33.584376
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')

    @app.on_response
    def test_on_response(request, response):
        return response

    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == "response"

# Generated at 2022-06-18 05:42:37.798290
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_response() == partial(app.middleware, attach_to="response")
    assert app.on_response(lambda x: x) == app.middleware(lambda x: x, "response")


# Generated at 2022-06-18 05:42:45.676828
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_on_response")
    @app.on_response
    def on_response(request, response):
        response.text = "test_MiddlewareMixin_on_response"
    request, response = app.test_client.get("/")
    assert response.text == "test_MiddlewareMixin_on_response"


# Generated at 2022-06-18 05:42:49.736314
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_response() == partial(app.middleware, attach_to="response")
    assert app.on_response(lambda x: x) == app.middleware(lambda x: x, "response")

# Generated at 2022-06-18 05:42:54.592484
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:42:59.986223
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:43:05.182920
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:43:10.185194
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic(__name__)

    @app.on_response
    def on_response(request, response):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "response"
    assert app._future_middleware[0].middleware == on_response


# Generated at 2022-06-18 05:43:15.461123
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:43:19.657880
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:43:24.481811
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def handler(request, response):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == 'response'
    assert app._future_middleware[0].middleware == handler


# Generated at 2022-06-18 05:43:32.241526
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')

    @app.middleware
    async def print_on_request(request):
        print('before')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('after')

    @app.route('/')
    async def handler(request):
        return response.text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:43:46.049123
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import NotFound
    from sanic.exceptions import ServerError
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import RequestEntityTooLarge
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import UnprocessableEntity
    from sanic.exceptions import InternalServerError
    from sanic.exceptions import ServiceUnavailable
    from sanic.exceptions import GatewayTimeout

# Generated at 2022-06-18 05:43:54.462399
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_on_response')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('Request: {}, Response: {}'.format(request, response))

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'OK'


# Generated at 2022-06-18 05:44:06.125527
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketTimeout
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketWriter

# Generated at 2022-06-18 05:44:08.602865
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:44:13.435373
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic("test_MiddlewareMixin_on_response")
    @app.on_response
    def on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:44:17.794754
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic(__name__)
    @app.on_response
    def on_response(request, response):
        return response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:44:22.919121
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_response() == partial(app.middleware, attach_to="response")
    assert app.on_response(lambda x: x) == app.middleware(lambda x: x, "response")

# Generated at 2022-06-18 05:44:25.156293
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:44:32.071539
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_MiddlewareMixin_on_response_middleware(request, response):
        return response
    assert app._future_middleware[0].middleware == test_MiddlewareMixin_on_response_middleware
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:44:40.695268
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.request import Request

    app = Sanic()

    @app.middleware
    async def middleware_1(request):
        request['middleware_1'] = True

    @app.middleware('request')
    async def middleware_2(request):
        request['middleware_2'] = True

    @app.middleware('response')
    async def middleware_3(request, response):
        response.body = b"middleware_3"

    @app.middleware('request')
    async def middleware_4(request):
        request['middleware_4'] = True

    @app.middleware('response')
    async def middleware_5(request, response):
        response.body = b"middleware_5"

# Generated at 2022-06-18 05:44:53.574946
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:45:00.836090
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import SanicException

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_1(request):
        return text('Pass')

    @app.middleware('request')
    async def middleware_2(request):
        return text('Pass')

    @app.middleware('response')
    async def middleware_3(request, response):
        return text('Pass')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

# Generated at 2022-06-18 05:45:06.866025
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app._future_middleware == []
    assert app.middleware(lambda x: x) == app.middleware(lambda x: x)
    assert app._future_middleware == [FutureMiddleware(app.middleware(lambda x: x), 'request')]
    assert app.middleware(lambda x: x, 'response') == app.middleware(lambda x: x, 'response')
    assert app._future_middleware == [FutureMiddleware(app.middleware(lambda x: x), 'request'), FutureMiddleware(app.middleware(lambda x: x, 'response'), 'response')]


# Generated at 2022-06-18 05:45:07.973896
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app.middleware is not None

# Generated at 2022-06-18 05:45:13.810319
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'
    assert isinstance(app._future_middleware[0], FutureMiddleware)


# Generated at 2022-06-18 05:45:25.779711
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.views import HTTPMethodView

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('request')

    @app.middleware('request')
    async def print_on_request2(request):
        print('request2')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('response')

    @app.middleware('response')
    async def print_on_response2(request, response):
        print('response2')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test

# Generated at 2022-06-18 05:45:30.769968
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic()

    @app.middleware
    async def handler(request):
        return text('OK')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:45:36.085456
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware('request')
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:45:40.829506
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_test(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'


# Generated at 2022-06-18 05:45:44.368013
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:46:08.393857
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    @app.middleware('request')
    async def request_middleware(request):
        pass
    @app.middleware('response')
    async def response_middleware(request, response):
        pass
    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].middleware == response_middleware
    assert app._future_middleware[1].attach_to == 'response'

# Generated at 2022-06-18 05:46:19.255542
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def middleware_1(request):
        pass

    @app.middleware('request')
    def middleware_2(request):
        pass

    @app.middleware('response')
    def middleware_3(request, response):
        pass

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert len(app._future_middleware) == 3
    assert isinstance(app._future_middleware[0], FutureMiddleware)

# Generated at 2022-06-18 05:46:26.041206
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic(__name__)

    @app.middleware
    async def middleware_1(request):
        request['middleware_1'] = True

    @app.middleware('request')
    async def middleware_2(request):
        request['middleware_2'] = True

    @app.middleware('response')
    async def middleware_3(request, response):
        response.text += 'middleware_3'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OKmiddleware_3'
    assert request.get('middleware_1') is True
    assert request.get

# Generated at 2022-06-18 05:46:33.666664
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic(__name__)

    @app.middleware
    async def middleware1(request):
        request['middleware1'] = True

    @app.middleware('request')
    async def middleware2(request):
        request['middleware2'] = True

    @app.middleware('response')
    async def middleware3(request, response):
        response.text += 'middleware3'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OKmiddleware3'
    assert request['middleware1'] is True
    assert request['middleware2'] is True

# Unit test

# Generated at 2022-06-18 05:46:38.321039
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware
    assert app.on_request is MiddlewareMixin.on_request
    assert app.on_response is MiddlewareMixin.on_response


# Generated at 2022-06-18 05:46:45.628885
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def middleware_test(request):
        return text('OK')

    @app.route('/')
    def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'
    assert len(app._future_middleware) == 1
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].middleware == middleware_test
    assert app._future_middleware[0].attach_to == 'request'

# Unit test

# Generated at 2022-06-18 05:46:51.286932
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    assert app._future_middleware is not None
    assert app._apply_middleware is not None

# Generated at 2022-06-18 05:46:55.869179
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    assert app._future_middleware == []
    @app.middleware
    async def test_middleware(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:47:05.618324
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def middleware_1(request):
        return HTTPResponse("OK")

    @app.middleware("request")
    async def middleware_2(request):
        return HTTPResponse("OK")

    @app.middleware("response")
    async def middleware_3(request, response):
        return HTTPResponse("OK")

    @app.middleware("request")
    async def middleware_4(request):
        return HTTPResponse("OK")

    @app.middleware("response")
    async def middleware_5(request, response):
        return

# Generated at 2022-06-18 05:47:11.975725
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        request['middleware'] = 'this is a request middleware'

    @app.middleware('response')
    async def response_middleware(request, response):
        response.text = 'this is a response middleware'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'this is a response middleware'
    assert request['middleware'] == 'this is a request middleware'



# Generated at 2022-06-18 05:47:55.735589
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def middleware1(request):
        return text("OK")

    @app.middleware("request")
    async def middleware2(request):
        return text("OK")

    @app.middleware("response")
    async def middleware3(request, response):
        return text("OK")

    @app.middleware("request")
    async def middleware4(request):
        return text("OK")

    @app.middleware("response")
    async def middleware5(request, response):
        return text("OK")

# Generated at 2022-06-18 05:48:07.846284
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app.middleware(middleware_or_request=None, attach_to=None, apply=None)
    assert app.middleware(middleware_or_request=None, attach_to=None, apply=None)
    assert app.middleware(middleware_or_request=None, attach_to=None, apply=None)
    assert app.middleware(middleware_or_request=None, attach_to=None, apply=None)
    assert app.middleware(middleware_or_request=None, attach_to=None, apply=None)
    assert app.middleware(middleware_or_request=None, attach_to=None, apply=None)

# Generated at 2022-06-18 05:48:11.752170
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware
    assert app.on_request is MiddlewareMixin.on_request
    assert app.on_response is MiddlewareMixin.on_response

# Generated at 2022-06-18 05:48:15.327831
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:48:24.804401
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def print_on_request(request):
        print('I run on each request!')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('I run on each response!')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:48:35.169069
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic(__name__)
    assert app._future_middleware == []
    app.middleware(lambda x: x)
    assert len(app._future_middleware) == 1

# Generated at 2022-06-18 05:48:39.745879
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def middleware(request):
        pass
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:48:44.435556
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware(middleware_or_request='request')
    assert app.middleware(middleware_or_request='response')
    assert app.middleware(middleware_or_request=lambda x: x)
    assert app.on_request()
    assert app.on_response()


# Generated at 2022-06-18 05:48:48.382107
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def test_middleware(request):
        return request

    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:48:57.447924
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('response')

    @app.route('/')
    async def handler(request):
        return json({'test': 42})

    request, response = app.test_client.get('/')
    assert response.json == {'test': 42}


# Generated at 2022-06-18 05:50:08.204563
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'


# Generated at 2022-06-18 05:50:17.515112
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import ServerError

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        request['middleware1'] = True

    @app.middleware('request')
    async def middleware2(request):
        request['middleware2'] = True

    @app.middleware('response')
    async def middleware3(request, response):
        response.body = b'middleware3'

    @app.route('/')
    async def handler(request):
        return json({'test': True})


# Generated at 2022-06-18 05:50:29.490660
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import SanicException

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def middleware_1(request):
        pass

    @app.middleware("request")
    async def middleware_2(request):
        pass

    @app.middleware("response")
    async def middleware_3(request, response):
        pass

    @app.route("/")
    async def handler(request):
        return json({"test": True})

    request, response = app.test_client.get("/")
    assert response.json == {"test": True}

    request, response = app.test_client.get("/")

# Generated at 2022-06-18 05:50:34.968492
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:50:43.287480
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound
    from sanic.models.futures import FutureMiddleware

    app = Sanic()

    @app.middleware
    def middleware1(request):
        pass

    @app.middleware('request')
    def middleware2(request):
        pass

    @app.middleware('response')
    def middleware3(request, response):
        pass

    @app.middleware('request')
    def middleware4(request):
        pass

    @app.middleware('response')
    def middleware5(request, response):
        pass

    @app.route('/')
    def handler(request):
        return text('OK')


# Generated at 2022-06-18 05:50:50.779459
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def handler(request):
        return text('OK')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'

# Generated at 2022-06-18 05:51:01.831318
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    assert test_middleware_mixin._future_middleware == []

    @test_middleware_mixin.middleware
    def test_middleware(request):
        pass

    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].middleware == test_middleware
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:51:09.844017
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'
    @app.middleware('response')
    async def test_middleware(request):
        return request
    assert app._future_middleware[1].middleware == test_middleware
    assert app._future_middleware[1].attach_to == 'response'

# Generated at 2022-06-18 05:51:20.412900
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    @app.middleware
    def test_middleware(request):
        pass
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'
    @app.middleware('response')
    def test_middleware2(request):
        pass
    assert app._future_middleware[1].middleware == test_middleware2
    assert app._future_middleware[1].attach_to == 'response'

# Generated at 2022-06-18 05:51:28.918479
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(middleware_or_request=lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    test_middleware_mixin.middleware(middleware_or_request=lambda x: x, attach_to="request")
    assert len(test_middleware_mixin._future_middleware) == 2
    test