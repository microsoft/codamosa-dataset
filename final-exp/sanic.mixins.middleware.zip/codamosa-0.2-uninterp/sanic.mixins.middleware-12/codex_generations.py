

# Generated at 2022-06-18 05:41:20.821425
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response(MiddlewareMixin, middleware=None) is not None

# Generated at 2022-06-18 05:41:26.799637
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware.__get__(app)
    assert app.on_request is MiddlewareMixin.on_request.__get__(app)
    assert app.on_response is MiddlewareMixin.on_response.__get__(app)
    assert app._future_middleware == []
    assert app._apply_middleware is MiddlewareMixin._apply_middleware.__get__(app)

# Generated at 2022-06-18 05:41:28.604952
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        return request
    assert app.on_request == on_request


# Generated at 2022-06-18 05:41:39.586015
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        request['middleware1'] = True

    @app.middleware('request')
    async def middleware2(request):
        request['middleware2'] = True

    @app.middleware('response')
    async def middleware3(request, response):
        response.headers['middleware3'] = True

    @app.middleware('request')
    async def middleware4(request):
        request['middleware4'] = True

    @app.middleware('response')
    async def middleware5(request, response):
        response.headers['middleware5']

# Generated at 2022-06-18 05:41:46.903681
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == 'response'

# Generated at 2022-06-18 05:41:54.034676
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.views import HTTPMethodView

    app = Sanic('test_MiddlewareMixin_on_request')

    @app.middleware('request')
    async def print_on_request(request):
        print('In request middleware')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'


# Generated at 2022-06-18 05:42:00.846254
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def middleware_test(request):
        pass
    assert app._future_middleware[0].middleware == middleware_test
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:42:06.865700
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:42:11.269551
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic()
    @app.middleware
    async def handler(request):
        return text('OK')
    assert app.on_response(handler) == app.middleware(handler, 'response')

# Generated at 2022-06-18 05:42:18.426256
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    assert app._future_middleware == []
    @app.middleware
    def test_middleware(request):
        return request
    assert app._future_middleware != []
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:42:28.023353
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    @test_middleware_mixin.on_request()
    def test_middleware():
        pass
    assert test_middleware_mixin._future_middleware[0].middleware == test_middleware
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:42:33.637660
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_on_request')

    @app.on_request
    def on_request(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'


# Generated at 2022-06-18 05:42:43.968217
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    @app.middleware
    def test_middleware(request):
        return request
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app.middleware is not None

# Generated at 2022-06-18 05:42:50.957628
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic()

    @app.middleware('response')
    async def process_response(request, response):
        response.headers['X-Served-By'] = 'sanic'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.headers.get('X-Served-By') == 'sanic'


# Generated at 2022-06-18 05:42:54.939749
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app.on_request(test_on_request) == test_on_request


# Generated at 2022-06-18 05:43:07.304450
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    # test middleware
    @app.middleware
    def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'
    # test on_request
    @app.on_request
    def test_on_request(request):
        return request
    assert app._future_middleware[1].middleware == test_on_request
    assert app._future_middleware[1].attach_to == 'request'
    # test on_response
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_

# Generated at 2022-06-18 05:43:14.116425
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def test_middleware(request):
        return text('OK')

    @app.route('/')
    def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'



# Generated at 2022-06-18 05:43:19.396324
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def response_middleware(request, response):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == response_middleware
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:43:23.991545
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic(__name__)
    @app.on_response
    def test_on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:43:29.131559
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    def test_middleware(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"

    @app.middleware("response")
    def test_middleware(request):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == test_middleware
    assert app._future_middleware[1].attach_to == "response"

    @app.middleware("request")
    def test_middleware(request):
        pass


# Generated at 2022-06-18 05:43:39.252790
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()

    @app.on_response
    def response_middleware(request, response):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "response"
    assert app._future_middleware[0].middleware == response_middleware


# Generated at 2022-06-18 05:43:41.361073
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response


# Generated at 2022-06-18 05:43:45.919515
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'



# Generated at 2022-06-18 05:43:57.246825
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app.middleware(middleware_or_request=None)
    assert app.middleware(middleware_or_request=None, attach_to="request")
    assert app.middleware(middleware_or_request=None, attach_to="response")
    assert app.middleware(middleware_or_request=None, attach_to="request", apply=True)
    assert app.middleware(middleware_or_request=None, attach_to="response", apply=True)
    assert app.middleware(middleware_or_request=None, apply=True)
    assert app.middleware(middleware_or_request=None, attach_to="request", apply=False)

# Generated at 2022-06-18 05:44:01.649923
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic()
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app.middleware[0].attach_to == "response"
    assert app.middleware[0].middleware == test_on_response


# Generated at 2022-06-18 05:44:12.658741
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware == MiddlewareMixin._apply_middleware
    assert app.middleware(lambda x: x) == MiddlewareMixin.middleware(lambda x: x)
    assert app.on_request(lambda x: x) == MiddlewareMixin.on_request(lambda x: x)
    assert app.on_response(lambda x: x) == MiddlewareMixin.on_response(lambda x: x)

# Generated at 2022-06-18 05:44:19.202824
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_on_response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    @app.exception(NotFound)
    async def ignore_404s(request, exception):
        return json({'status': 404, 'message': 'Not found'},
                    status=404)

    @app.middleware('response')
    async def process_response(request, response):
        response.headers['Server'] = 'Sanic'
        return response

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.headers['Server'] == 'Sanic'

# Generated at 2022-06-18 05:44:25.192963
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic()

    @app.on_response
    def response_middleware(request, response):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == response_middleware
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:44:29.915961
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic(__name__)
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:44:39.537848
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        def get(self, request):
            return text("OK")

    app = Sanic("test_MiddlewareMixin_middleware")
    app.add_route(MyView.as_view(), "/")

    @app.middleware
    async def test_middleware(request):
        return text("OK")

    @app.middleware("request")
    async def test_middleware_request(request):
        return text("OK")

    @app.middleware("response")
    async def test_middleware_response(request, response):
        return text("OK")


# Generated at 2022-06-18 05:44:55.181409
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:44:59.530556
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:45:07.365674
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    @app.middleware
    def middleware(request):
        pass
    assert middleware.__name__ == "middleware"
    assert middleware.__module__ == "__main__"
    assert middleware.__qualname__ == "test_MiddlewareMixin_on_response.<locals>.middleware"


# Generated at 2022-06-18 05:45:11.791014
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:45:18.251665
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:45:23.705048
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('request')

    @app.middleware('request')
    async def print_on_request2(request):
        print('request2')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('response')

    @app.middleware('response')
    async def print_on_response2(request, response):
        print('response2')

    @app.route('/')
    async def handler(request):
        return text('OK')


# Generated at 2022-06-18 05:45:34.002140
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()
    # Test for method middleware of class MiddlewareMixin
    @app.middleware
    async def test_middleware(request):
        return request

    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"

    # Test for method middleware of class MiddlewareMixin
    @app.middleware('response')
    async def test_middleware_response(request):
        return request

    assert app._future_middleware[1].middleware == test_middleware_response
    assert app._future_middleware[1].attach_to == "response"

    # Test for method middleware of class MiddlewareMixin

# Generated at 2022-06-18 05:45:38.048046
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert callable(app.on_response)
    assert callable(app.on_response(None))
    assert callable(app.on_response(lambda x: x))


# Generated at 2022-06-18 05:45:45.414741
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1

# Generated at 2022-06-18 05:45:51.641545
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_on_response")
    @app.on_response
    def handler(request, response):
        return response
    assert app._future_middleware[0].middleware == handler
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:46:09.019556
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        def get(self, request):
            return text("OK")

    app = Sanic("test_MiddlewareMixin_on_response")
    app.add_route(MyView.as_view(), "/")

    @app.on_response
    def response_middleware(request, response):
        response.text = "OK"

    request, response = app.test_client.get("/")
    assert response.text == "OK"

# Generated at 2022-06-18 05:46:13.571026
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic(__name__)
    @app.on_response
    def on_response(request, response):
        print(request, response)
    assert app._future_middleware[0].attach_to == "response"

# Generated at 2022-06-18 05:46:18.962623
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_on_response")
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:46:22.803450
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:46:29.121442
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.middleware
    def test_middleware(request):
        return request
    assert test_middleware == app._future_middleware[0].middleware
    assert 'request' == app._future_middleware[0].attach_to


# Generated at 2022-06-18 05:46:36.619801
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_response(middleware=None)

# Generated at 2022-06-18 05:46:40.450244
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:46:43.807130
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:46:48.773568
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware
    assert app.on_request is MiddlewareMixin.on_request
    assert app.on_response is MiddlewareMixin.on_response


# Generated at 2022-06-18 05:46:54.263500
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic()
    @app.on_response
    def test_on_response(request, response):
        print(request, response)
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:47:54.443784
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware == MiddlewareMixin._apply_middleware


# Generated at 2022-06-18 05:48:00.977749
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.json == {'test': True}

# Generated at 2022-06-18 05:48:06.590771
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def handler(request):
        return request
    assert handler == app._future_middleware[0].middleware
    assert 'request' == app._future_middleware[0].attach_to


# Generated at 2022-06-18 05:48:09.932803
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic(__name__)
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None


# Generated at 2022-06-18 05:48:19.981943
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        request['middleware1'] = True

    @app.middleware('request')
    async def middleware2(request):
        request['middleware2'] = True

    @app.middleware('response')
    async def middleware3(request, response):
        response.text += ' middleware3'

    @app.route('/')
    async def handler(request):
        return text('OK')


# Generated at 2022-06-18 05:48:31.409894
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].middleware(1) == 1
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"
    test_middleware_mixin.middle

# Generated at 2022-06-18 05:48:39.035907
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import ServerError
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_1(request):
        return json({'middleware_1': 'middleware_1'})

    @app.middleware('request')
    async def middleware_2(request):
        return json({'middleware_2': 'middleware_2'})

    @app.middleware('response')
    async def middleware_3(request, response):
        return json({'middleware_3': 'middleware_3'})


# Generated at 2022-06-18 05:48:44.399596
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic()
    @app.middleware
    async def test_middleware(request):
        return text('test_middleware')
    @app.route('/')
    async def test(request):
        return text('test')
    request, response = app.test_client.get('/')
    assert response.text == 'test_middleware'


# Generated at 2022-06-18 05:48:53.820888
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.views import HTTPMethodView

    app = Sanic()

    @app.middleware
    async def middleware_a(request):
        return text("pass")

    @app.middleware("request")
    async def middleware_b(request):
        return text("pass")

    @app.middleware("response")
    async def middleware_c(request, response):
        return text("pass")

    @app.route("/")
    async def handler(request):
        return text("OK")

    @app.middleware("request")
    async def middleware_d(request):
        return text("pass")


# Generated at 2022-06-18 05:49:01.801838
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"

    test_middleware_mixin.middleware(lambda x: x, attach_to="response")

# Generated at 2022-06-18 05:50:02.172867
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'


# Generated at 2022-06-18 05:50:07.865772
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware
    assert app.on_request is MiddlewareMixin.on_request
    assert app.on_response is MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware is MiddlewareMixin._apply_middleware


# Generated at 2022-06-18 05:50:17.272066
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def middleware_1(request):
        return request

    @app.middleware('request')
    def middleware_2(request):
        return request

    @app.middleware('response')
    def middleware_3(request, response):
        return response

    @app.middleware('request')
    def middleware_4(request):
        return request

    @app.middleware('response')
    def middleware_5(request, response):
        return response

    @app.route('/')
    async def handler(request):
        return json

# Generated at 2022-06-18 05:50:23.889182
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.views import HTTPMethodView

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def middleware_a(request):
        request["middleware"] = "a"

    @app.middleware("request")
    async def middleware_b(request):
        request["middleware"] = "b"

    @app.middleware("response")
    async def middleware_c(request, response):
        response.text = "c"

    @app.middleware("request")
    async def middleware_d(request):
        request["middleware"] = "d"


# Generated at 2022-06-18 05:50:27.960487
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    app.middleware(None)
    app.middleware(None, 'request')
    app.middleware(None, 'response')
    app.on_request(None)
    app.on_response(None)

# Generated at 2022-06-18 05:50:38.484342
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(middleware_or_request=None)
    test_middleware_mixin.middleware(middleware_or_request=None, attach_to="request")
    test_middleware_mixin.middleware(middleware_or_request=None, attach_to="response")

# Generated at 2022-06-18 05:50:42.738434
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:50:54.122154
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1

# Generated at 2022-06-18 05:51:04.826428
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware

    app = Sanic()

    @app.middleware
    def middleware1(request):
        return text("OK")

    @app.middleware('request')
    def middleware2(request):
        return text("OK")

    @app.middleware('response')
    def middleware3(request, response):
        return text("OK")

    @app.middleware('request')
    def middleware4(request):
        return text("OK")

    @app.middleware('response')
    def middleware5(request, response):
        return text("OK")

    assert len(app._future_middleware) == 5

# Generated at 2022-06-18 05:51:15.568513
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic(__name__)

    @app.middleware
    async def middleware1(request):
        request['middleware1'] = True

    @app.middleware('request')
    async def middleware2(request):
        request['middleware2'] = True

    @app.middleware('response')
    async def middleware3(request, response):
        response.text += 'middleware3'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OKmiddleware3'
    assert request['middleware1'] is True
    assert request['middleware2'] is True

# Unit test