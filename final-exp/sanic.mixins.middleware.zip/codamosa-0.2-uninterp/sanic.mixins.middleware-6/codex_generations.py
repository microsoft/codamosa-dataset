

# Generated at 2022-06-18 05:41:26.001760
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    assert app._future_middleware == []
    assert app._apply_middleware is None

# Generated at 2022-06-18 05:41:31.259005
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_on_response')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('Request: {0}'.format(request))
        print('Response: {0}'.format(response))

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'
    assert response.status == 200


# Generated at 2022-06-18 05:41:36.874780
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    @app.on_response
    def test_on_response(request, response):
        return response
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:41:41.390345
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:41:51.805763
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    test_middleware_mixin = TestMiddlewareMixin()
    @test_middleware_mixin.middleware
    def test_middleware(request):
        pass
    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].middleware == test_middleware
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"
    @test_middleware_mixin.middleware("response")
    def test_middleware(request):
        pass
    assert len(test_middleware_mixin._future_middleware) == 2
    assert test

# Generated at 2022-06-18 05:41:59.641199
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_request(lambda request: request)
    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:42:06.075109
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app.on_request(test_on_request) == test_on_request


# Generated at 2022-06-18 05:42:09.405082
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware[0].middleware == test_on_request
    assert app.middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:42:15.229594
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_response() == partial(app.middleware, attach_to="response")
    assert app.on_response(lambda x: x) == app.middleware(lambda x: x, "response")


# Generated at 2022-06-18 05:42:23.379361
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(None)
    test_middleware_mixin.on_request(None)
    test_middleware_mixin.on_response(None)

# Generated at 2022-06-18 05:42:32.547099
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def middleware(request):
        return request
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:42:36.412113
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    @app.on_request
    def test_on_request(request):
        return request
    assert app.on_request(test_on_request) == test_on_request


# Generated at 2022-06-18 05:42:38.472445
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic()
    assert app.on_request == app.middleware


# Generated at 2022-06-18 05:42:42.671469
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app.on_request == app.middleware


# Generated at 2022-06-18 05:42:48.288439
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_on_response')

    @app.on_response
    def response_middleware(request, response):
        return response

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == 'response'
    assert app._future_middleware[0].middleware == response_middleware


# Generated at 2022-06-18 05:42:53.318951
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic(__name__)

    @app.on_response
    def on_response(request, response):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "response"
    assert app._future_middleware[0].middleware == on_response

# Generated at 2022-06-18 05:42:59.760871
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:43:03.818168
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    app.on_request(lambda request: None)
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:43:12.668109
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.request import Request

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def middleware_1(request):
        return text("OK")

    @app.middleware("request")
    async def middleware_2(request):
        return text("OK")

    @app.middleware("response")
    async def middleware_3(request, response):
        return text("OK")

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.text == "OK"

    assert len(app._future_middleware) == 3
    assert app._future_middle

# Generated at 2022-06-18 05:43:19.245123
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_response(middleware=None)

# Generated at 2022-06-18 05:43:26.103767
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:43:34.087272
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:43:38.499196
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic(__name__)
    assert app.on_response() == partial(app.middleware, attach_to="response")
    assert app.on_response(lambda x: x) == app.middleware(lambda x: x, "response")


# Generated at 2022-06-18 05:43:43.923769
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_request(middleware=None)

# Generated at 2022-06-18 05:43:51.483615
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    test_middleware_mixin.middleware(lambda x: x, attach_to="request")
    test_middleware_mixin.middleware(lambda x: x, attach_to="response")
    test_middleware_mixin.middleware(lambda x: x, attach_to="request")
    test_middleware_mixin

# Generated at 2022-06-18 05:43:56.427928
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:44:00.593129
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response


# Generated at 2022-06-18 05:44:07.154915
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    @app.on_request
    def on_request(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].middleware == on_request


# Generated at 2022-06-18 05:44:12.915961
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_request(middleware=None)


# Generated at 2022-06-18 05:44:15.553809
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_response == app.middleware('response')


# Generated at 2022-06-18 05:44:31.145562
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:44:40.065512
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import SanicException

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def middleware_1(request):
        return HTTPResponse("OK")

    @app.middleware("request")
    async def middleware_2(request):
        return HTTPResponse("OK")

    @app.middleware("response")
    async def middleware_3(request, response):
        return HTTPResponse("OK")

    @app.route("/")
    async def handler(request):
        return HTTPResponse("OK")

    request, response = app.test_client.get("/")

# Generated at 2022-06-18 05:44:43.398129
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def middleware(request):
        pass
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:44:53.893122
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic(__name__)

    @app.middleware
    async def middleware(request):
        pass

    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == "request"

    @app.middleware('response')
    async def middleware(request):
        pass

    assert app._future_middleware[1].middleware == middleware
    assert app._future_middleware[1].attach_to == "response"

    @app.middleware('request')
    async def middleware(request):
        pass

    assert app._future_middleware[2].middleware == middleware
    assert app._future_middleware[2].attach_to == "request"


# Generated at 2022-06-18 05:44:58.451142
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:45:03.174762
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(middleware_or_request=None, attach_to="request", apply=True)

# Generated at 2022-06-18 05:45:09.242521
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('pass')

    request, response = app.test_client.get('/')
    assert response.text == 'pass'


# Generated at 2022-06-18 05:45:13.066538
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def test_middleware(request):
        return request

    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:45:24.966459
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    test_middleware_mixin.middleware(lambda x: x, attach_to="request")
    assert len(test_middleware_mixin._future_middleware) == 2
    test_middleware_mixin.middleware(lambda x: x, attach_to="response")

# Generated at 2022-06-18 05:45:28.304518
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.views import HTTPMethodView

    app = Sanic()

    @app.middleware('request')
    async def request_middleware(request):
        request['middleware'] = 'this is a request middleware'

    @app.middleware('response')
    async def response_middleware(request, response):
        response.text += ' this is a response middleware'

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.json['test'] is True
    assert request['middleware'] == 'this is a request middleware'

# Generated at 2022-06-18 05:45:47.989988
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic("test_MiddlewareMixin_middleware")
    @app.middleware
    def test_middleware(request):
        return json({"test": True})
    request, response = app.test_client.get("/")
    assert response.json == {"test": True}


# Generated at 2022-06-18 05:45:52.249652
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:46:04.436550
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    assert app._apply_middleware is not None
    assert app._future_middleware is not None
    assert app._future_middleware == []
    assert app.middleware._partial_method is not None
    assert app.on_request._partial_method is not None
    assert app.on_response._partial_method is not None
    assert app.middleware._partial_method.args == ()
    assert app.on_request._partial_method.args == ()
    assert app.on_response._partial_method.args == ()

# Generated at 2022-06-18 05:46:16.038419
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_1(request):
        request['middleware_1'] = True

    @app.middleware('request')
    async def middleware_2(request):
        request['middleware_2'] = True

    @app.middleware('response')
    async def middleware_3(request, response):
        response.text += ' middleware_3'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK middleware_3'
    assert request.get('middleware_1') is True

# Generated at 2022-06-18 05:46:20.498066
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:46:24.619300
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic(__name__)
    @app.middleware
    def middleware_test(request):
        return request
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == middleware_test
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].apply == True


# Generated at 2022-06-18 05:46:32.982188
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.views import HTTPMethodView

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:46:38.320501
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:46:42.732503
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware
    assert app.on_request is MiddlewareMixin.on_request
    assert app.on_response is MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware is MiddlewareMixin._apply_middleware

# Generated at 2022-06-18 05:46:48.400272
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:47:25.229252
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    app.middleware(middleware_or_request=None)
    app.middleware(middleware_or_request=None, attach_to='request')
    app.middleware(middleware_or_request=None, attach_to='response')
    app.middleware(middleware_or_request=None, attach_to='request', apply=True)
    app.middleware(middleware_or_request=None, attach_to='response', apply=True)
    app.on_request(middleware=None)
    app.on_response(middleware=None)


# Generated at 2022-06-18 05:47:29.106086
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    app = Sanic()

    @app.middleware
    async def test_middleware(request):
        return json({"test": True})

    request, response = app.test_client.get('/')
    assert response.json == {"test": True}



# Generated at 2022-06-18 05:47:40.724429
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_1(request):
        return text('pass')

    @app.middleware('request')
    async def middleware_2(request):
        return text('pass')

    @app.middleware('response')
    async def middleware_3(request, response):
        return text('pass')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'pass'
    assert len(app._future_middleware) == 3
   

# Generated at 2022-06-18 05:47:45.837142
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic()
    @app.middleware
    async def test_middleware(request):
        return text('test')
    assert app._future_middleware[0].middleware == test_middleware


# Generated at 2022-06-18 05:47:52.465055
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic()

    @app.middleware
    async def handler(request):
        return json({"test": True})

    @app.route("/")
    async def handler(request):
        return json({"test": True})

    request, response = app.test_client.get("/")
    assert response.json == {"test": True}

# Generated at 2022-06-18 05:47:58.190522
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app.middleware._apply_middleware == MiddlewareMixin._apply_middleware


# Generated at 2022-06-18 05:48:09.531892
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.views import HTTPMethodView

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('I am a request middleware')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('I am a response middleware')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:48:12.075373
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None


# Generated at 2022-06-18 05:48:17.998055
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        pass
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:48:28.156352
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.models.futures import FutureMiddleware

    app = Sanic()

    @app.middleware
    async def middleware1(request):
        return text("OK")

    @app.middleware('request')
    async def middleware2(request):
        return text("OK")

    @app.middleware('response')
    async def middleware3(request, response):
        return text("OK")

    @app.route('/')
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:49:28.373701
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def print_on_request(request):
        print('request')
    @app.middleware('response')
    async def print_on_response(request, response):
        print('response')
    @app.route('/')
    async def handler(request):
        return json({'test': True})
    request, response = app.test_client.get('/')
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:49:35.448413
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(middleware_or_request=lambda x: x)
    test_middleware_mixin.middleware(middleware_or_request=lambda x: x, attach_to="request")
    test_middleware_mixin.middleware(middleware_or_request=lambda x: x, attach_to="response")
    test_middleware_mixin.on_

# Generated at 2022-06-18 05:49:47.900709
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app._future_middleware == []
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    @app.middleware('request')
    def test_middleware(request):
        pass
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'
    @app.middleware
    def test_middleware2(request):
        pass
    assert app._future_middleware[1].middleware == test_middleware2

# Generated at 2022-06-18 05:49:51.513287
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return text('OK')
    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:49:57.415807
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:50:06.556976
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def print_on_request(request):
        print('I run on each request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('I run on each response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:50:15.487405
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware('request')
    def request_middleware(request):
        pass
    @app.middleware('response')
    def response_middleware(request, response):
        pass
    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].middleware == response_middleware
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-18 05:50:19.511314
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware('request')
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:50:32.345955
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    test_middleware_mixin.middleware(lambda x: x, attach_to="request")
    assert len(test_middleware_mixin._future_middleware) == 2

# Generated at 2022-06-18 05:50:36.824567
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
