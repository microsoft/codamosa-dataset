

# Generated at 2022-06-18 05:41:22.593042
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:41:26.463077
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def middleware(request):
        pass
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:41:30.199807
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    assert app._apply_middleware is not None
    assert app._future_middleware is not None
    assert app._future_middleware == []


# Generated at 2022-06-18 05:41:36.414264
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware


# Generated at 2022-06-18 05:41:39.742909
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware_stack[0].middleware == test_on_request


# Generated at 2022-06-18 05:41:46.058384
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware
    assert app.on_request is MiddlewareMixin.on_request
    assert app.on_response is MiddlewareMixin.on_response


# Generated at 2022-06-18 05:41:52.798258
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_request(middleware=None)
    test_middleware_mixin.on_request(middleware=lambda x: x)


# Generated at 2022-06-18 05:41:59.773633
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic()
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:42:11.421108
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic(__name__)

    @app.middleware('request')
    async def print_on_request(request):
        print('I run on each request!')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('I run on each response!')

    @app.route('/')
    async def handler(request):
        return json({'hello': 'world'})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'hello': 'world'}


# Generated at 2022-06-18 05:42:17.776582
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic(__name__)

    @app.on_request
    def on_request(request):
        return json({'msg': 'on_request'})

    request, response = app.test_client.get('/')
    assert response.json == {'msg': 'on_request'}


# Generated at 2022-06-18 05:42:25.119678
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware == MiddlewareMixin._apply_middleware


# Generated at 2022-06-18 05:42:31.343185
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_request(middleware=None)

# Generated at 2022-06-18 05:42:40.789188
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_request() == partial(app.middleware, attach_to="request")
    assert app.on_request("request") == partial(app.middleware, attach_to="request")
    assert app.on_request("response") == partial(app.middleware, attach_to="response")
    assert app.on_request(lambda x: x) == app.middleware(lambda x: x, "request")
    assert app.on_request(lambda x: x, "request") == app.middleware(lambda x: x, "request")
    assert app.on_request(lambda x: x, "response") == app.middleware(lambda x: x, "response")


# Generated at 2022-06-18 05:42:46.107185
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_on_request')

    @app.on_request
    def on_request(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'


# Generated at 2022-06-18 05:42:52.148478
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic(__name__)

    @app.middleware
    def test_middleware(request):
        return text('pass')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'pass'

# Generated at 2022-06-18 05:42:54.549465
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test')
    assert app.on_request() == partial(app.middleware, attach_to="request")


# Generated at 2022-06-18 05:43:06.896026
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware(request):
        pass

    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == 'request'

    @app.middleware('response')
    async def middleware(request):
        pass

    assert app._future_middleware[1].middleware == middleware
    assert app._future_middleware[1].attach_to == 'response'

    @app.middleware('request')
    async def middleware(request):
        pass

    assert app._future_middleware[2].middleware == middleware
    assert app._future_middleware[2].attach_to == 'request'

   

# Generated at 2022-06-18 05:43:11.205607
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_on_request")
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware_stack[0].middleware == test_on_request
    assert app.middleware_stack[0].attach_to == "request"


# Generated at 2022-06-18 05:43:16.585589
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_class = TestClass()
    test_class.on_request(middleware=None)

# Generated at 2022-06-18 05:43:23.629187
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    test_middleware_mixin = TestMiddlewareMixin()
    @test_middleware_mixin.on_request
    def test_middleware(request):
        pass
    assert test_middleware_mixin._future_middleware[0].middleware == test_middleware
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:43:39.644781
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    test_middleware_mixin.middleware(lambda x: x, attach_to="request")
    test_middleware_mixin.middleware(lambda x: x, attach_to="response")
    test_middleware_mixin.on_request(lambda x: x)
    test_middleware_mixin.on_response(lambda x: x)


# Generated at 2022-06-18 05:43:44.361604
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware[0].attach_to == 'request'
    assert app.middleware[0].middleware == test_on_request


# Generated at 2022-06-18 05:43:51.323237
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    @TestMiddlewareMixin.on_request()
    def test_middleware(request):
        pass

    assert len(TestMiddlewareMixin._future_middleware) == 1
    assert TestMiddlewareMixin._future_middleware[0].attach_to == "request"
    assert TestMiddlewareMixin._future_middleware[0].middleware == test_middleware


# Generated at 2022-06-18 05:43:56.294077
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:44:02.049755
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def handler(request):
        return text("OK")

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.text == "OK"

# Generated at 2022-06-18 05:44:07.498966
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def handler(request):
        return request
    assert handler.__name__ == 'handler'


# Generated at 2022-06-18 05:44:15.400297
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('I am a request middleware')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('I am a response middleware')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.json == {'test': True}

# Generated at 2022-06-18 05:44:26.797046
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()

    @test_middleware_mixin.on_request()
    def test_middleware(request):
        pass

    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].middleware == test_middleware
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:44:36.363760
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin.on_request.__name__ == "on_request"
    assert MiddlewareMixin.on_request.__qualname__ == "MiddlewareMixin.on_request"
    assert MiddlewareMixin.on_request.__doc__ == "Decorate and register middleware to be called before a request.\n        Can either be called as *@app.middleware* or\n        *@app.middleware('request')*\n\n        `See user guide re: middleware\n        <https://sanicframework.org/guide/basics/middleware.html>`__\n\n        :param: middleware_or_request: Optional parameter to use for\n            identifying which type of middleware is being registered."


# Generated at 2022-06-18 05:44:42.120786
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware_stack[0].middleware == test_on_request
    assert app.middleware_stack[0].attach_to == 'request'


# Generated at 2022-06-18 05:45:00.149924
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"
    test_middleware_mixin.middleware(lambda x: x, "response")

# Generated at 2022-06-18 05:45:11.867337
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    from sanic.views import HTTPMethodView

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def middleware_1(request):
        request['middleware_1'] = True

    @app.middleware('request')
    def middleware_2(request):
        request['middleware_2'] = True

    @app.middleware('response')
    def middleware_3(request, response):
        response['middleware_3'] = True

    @app.middleware('request')
    def middleware_4(request):
        request['middleware_4'] = True


# Generated at 2022-06-18 05:45:19.056917
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic()

    @app.middleware
    async def handler(request):
        request['foo'] = 'bar'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert request['foo'] == 'bar'


# Generated at 2022-06-18 05:45:29.447752
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_1(request):
        request['middleware_1'] = True

    @app.middleware('request')
    async def middleware_2(request):
        request['middleware_2'] = True

    @app.middleware('response')
    async def middleware_3(request, response):
        response.text += ' middleware_3'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert request.get('middleware_1')
    assert request.get('middleware_2')
    assert response

# Generated at 2022-06-18 05:45:34.718061
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        pass
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:45:43.666102
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware
    app = Sanic()
    app.middleware(None)
    assert app._future_middleware == []
    app.middleware(None, attach_to="request")
    assert app._future_middleware == []
    app.middleware(None, attach_to="response")
    assert app._future_middleware == []
    app.middleware(None, attach_to="request", apply=False)
    assert app._future_middleware == []
    app.middleware(None, attach_to="response", apply=False)
    assert app._future_middleware == []
    app.middleware(None, attach_to="request", apply=True)
    assert app._future_middleware == []
    app.middleware

# Generated at 2022-06-18 05:45:54.287470
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.request import Request
    from sanic.models.futures import FutureMiddleware

    app = Sanic()

    @app.middleware
    async def middleware1(request):
        return text("OK")

    @app.middleware('request')
    async def middleware2(request):
        return text("OK")

    @app.middleware('response')
    async def middleware3(request, response):
        return text("OK")

    @app.middleware('request')
    async def middleware4(request):
        return text("OK")

    @app.middleware('response')
    async def middleware5(request, response):
        return text("OK")


# Generated at 2022-06-18 05:46:03.784598
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:46:09.419315
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        print('test_middleware')
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:46:19.111138
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic()

    @app.middleware
    async def print_on_request(request):
        print("I print when a request is received by the server")

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I print when a response is returned by the server")

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:46:37.430385
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:46:44.590183
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []

    @app.middleware('request')
    async def request_middleware(request):
        pass

    @app.middleware('response')
    async def response_middleware(request, response):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[0].attach_to == 'request'

# Generated at 2022-06-18 05:46:55.284715
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(middleware_or_request=lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    test_middleware_mixin.middleware(middleware_or_request=lambda x: x, attach_to="request")
    assert len(test_middleware_mixin._future_middleware) == 2
    test

# Generated at 2022-06-18 05:47:03.068424
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app.middleware == MiddlewareMixin.middleware
    assert app.middleware('request') == MiddlewareMixin.middleware('request')
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response

# Generated at 2022-06-18 05:47:10.291291
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    app = Sanic()

    @app.middleware
    async def print_on_request(request):
        print("I print when a request is received by the server")

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I print when a response is returned by the server")

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:47:17.675237
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware
    assert app.on_request is MiddlewareMixin.on_request
    assert app.on_response is MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware is MiddlewareMixin._apply_middleware


# Generated at 2022-06-18 05:47:28.863268
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import Future

    app = Sanic(__name__)

    @app.middleware
    def middleware_test(request):
        return request

    @app.middleware('request')
    def middleware_test_request(request):
        return request

    @app.middleware('response')
    def middleware_test_response(request, response):
        return response

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
   

# Generated at 2022-06-18 05:47:40.720727
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        return text('Passed middleware1')

    @app.middleware('request')
    async def middleware2(request):
        return text('Passed middleware2')

    @app.middleware('response')
    async def middleware3(request, response):
        return text('Passed middleware3')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'Passed middleware1'

    request, response = app

# Generated at 2022-06-18 05:47:52.648186
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].middleware(1) == 1
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:48:00.977639
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddlewareType

    app = Sanic()

    @app.middleware
    async def middleware(request):
        return text("OK")

    assert len(app._future_middleware) == 1
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == FutureMiddlewareType.REQUEST

    @app.middleware("response")
    async def middleware(request):
        return text("OK")

    assert len(app._future_middleware) == 2

# Generated at 2022-06-18 05:48:31.654473
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return text('pass')
    request, response = app.test_client.get('/')
    assert response.text == 'pass'


# Generated at 2022-06-18 05:48:35.799622
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'


# Generated at 2022-06-18 05:48:42.799020
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        request['middleware1'] = True

    @app.middleware('request')
    async def middleware2(request):
        request['middleware2'] = True

    @app.middleware('response')
    async def middleware3(request, response):
        response.text += ' middleware3'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert request['middleware1'] is True

# Generated at 2022-06-18 05:48:51.554637
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic()

    @app.middleware
    async def print_on_request(request):
        print("I print when a request is received by the server")

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I print when a response is returned by the server")

    @app.route('/')
    async def handler(request):
        return json({'hello': 'world'})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'hello': 'world'}

# Generated at 2022-06-18 05:48:53.777442
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:48:58.203410
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware


# Generated at 2022-06-18 05:49:03.003629
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        return text('Pass')

    @app.middleware('response')
    async def middleware2(request, response):
        return text('Pass')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'Pass'
    assert response.text == 'Pass'


# Generated at 2022-06-18 05:49:14.314157
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    assert isinstance(app, MiddlewareMixin)
    assert app._future_middleware == []

    @app.middleware
    async def test_middleware(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"

    @app.middleware("response")
    async def test_middleware_response(request):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == test_middleware_response
    assert app._future_middleware[1].attach_to

# Generated at 2022-06-18 05:49:19.625638
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'


# Generated at 2022-06-18 05:49:28.028132
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_a(request):
        return text('Pass')

    @app.middleware('request')
    async def middleware_b(request):
        return text('Pass')

    @app.middleware('response')
    async def middleware_c(request, response):
        return text('Pass')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'Pass'

    request, response = app.test_client.get('/')
    assert response

# Generated at 2022-06-18 05:50:25.934765
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'

# Generated at 2022-06-18 05:50:36.654058
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    assert test_middleware_mixin._future_middleware == []
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1

# Generated at 2022-06-18 05:50:41.537709
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware == MiddlewareMixin._apply_middleware


# Generated at 2022-06-18 05:50:47.483933
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import ServerError

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware("request")
    async def process_request(request):
        request["processed_by_request"] = True

    @app.middleware("response")
    async def process_response(request, response):
        response.headers["processed_by_response"] = "True"

    @app.route("/")
    async def handler(request):
        return json({"test": True})

    @app.exception(ServerError)
    async def handler_exception(request, exception):
        return json({"exception": True}, status=500)


# Generated at 2022-06-18 05:50:58.062514
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        request['middleware1'] = True

    @app.middleware('request')
    async def middleware2(request):
        request['middleware2'] = True

    @app.middleware('response')
    async def middleware3(request, response):
        response.text += ' middleware3'

    @app.route('/')
    async def handler(request):
        return text('OK')


# Generated at 2022-06-18 05:51:06.366432
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def handler1(request):
        return text("OK")

    @app.middleware("request")
    async def handler2(request):
        return text("OK")

    @app.middleware("response")
    async def handler3(request, response):
        return text("OK")

    assert len(app._future_middleware) == 3
    assert app._future_middleware[0].middleware == handler1
    assert app._future_middleware[1].middleware == handler2
    assert app._future_middleware[2].middleware == handler3

# Generated at 2022-06-18 05:51:11.957796
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        pass
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:51:16.575239
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic(__name__)
    @app.middleware
    def test_middleware(request):
        return text('test')
    assert app._future_middleware[0].middleware == test_middleware
