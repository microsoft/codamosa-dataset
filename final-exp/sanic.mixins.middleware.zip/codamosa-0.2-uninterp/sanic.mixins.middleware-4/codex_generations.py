

# Generated at 2022-06-18 05:41:37.831805
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'


# Generated at 2022-06-18 05:41:43.407991
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def before_request(request):
        request['test'] = 'before'

    @app.middleware('response')
    def after_request(request, response):
        response.body = 'after'

    @app.route('/')
    def handler(request):
        return json({'test': request['test']})

    @app.websocket('/feed')
    async def feed(request, ws):
        await ws.send('hello')

    request, response = app.test_client.get('/')
   

# Generated at 2022-06-18 05:41:49.714601
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    test_middleware_mixin = TestMiddlewareMixin()
    @test_middleware_mixin.middleware
    def test_middleware():
        pass
    assert test_middleware_mixin._future_middleware[0].middleware == test_middleware
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:41:53.066993
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    app.middleware(None, attach_to="request")
    app.middleware(None, attach_to="response")
    app.on_request(None)
    app.on_response(None)


# Generated at 2022-06-18 05:42:00.846299
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic("test_MiddlewareMixin_on_response")
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:42:11.421097
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware('request')
    async def request_middleware(request):
        return request
    @app.middleware('response')
    async def response_middleware(request, response):
        return response
    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].middleware == response_middleware
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-18 05:42:18.174206
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app._future_middleware == []
    @app.middleware
    def middleware(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:42:22.541567
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return request

    assert app._future_middleware[0].middleware == test_middleware


# Generated at 2022-06-18 05:42:29.446795
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware

    app = Sanic()

    @app.middleware
    def middleware_1(request):
        return text("OK")

    @app.middleware("request")
    def middleware_2(request):
        return text("OK")

    @app.middleware("response")
    def middleware_3(request, response):
        return text("OK")

    assert len(app._future_middleware) == 3
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert isinstance(app._future_middleware[1], FutureMiddleware)
    assert isinstance(app._future_middleware[2], FutureMiddleware)
    assert app._future_middle

# Generated at 2022-06-18 05:42:31.721705
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    @app.on_response
    def on_response(request, response):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:42:39.306350
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic()

    @app.middleware('response')
    async def handler(request, response):
        response.text = 'Hello world!'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'Hello world!'

# Generated at 2022-06-18 05:42:42.152974
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware
    assert app.on_request is MiddlewareMixin.on_request
    assert app.on_response is MiddlewareMixin.on_response


# Generated at 2022-06-18 05:42:47.210398
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    @app.on_request
    def on_request(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].middleware == on_request


# Generated at 2022-06-18 05:42:57.606087
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app._future_middleware == []
    @app.middleware
    def middleware(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == "request"
    @app.middleware('response')
    def middleware(request):
        pass
    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == middleware
    assert app._future_middleware[1].attach_to == "response"


# Generated at 2022-06-18 05:43:04.309343
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:43:09.391733
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        print("test_on_request")
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:43:12.665640
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_request(middleware=None) == partial(app.middleware, attach_to="request")
    assert app.on_request(middleware=app.middleware) == app.middleware


# Generated at 2022-06-18 05:43:17.129032
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_request(middleware=None)

# Generated at 2022-06-18 05:43:26.053011
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_test(request):
        pass

    assert app._future_middleware[0].middleware == middleware_test
    assert app._future_middleware[0].attach_to == 'request'

    @app.middleware('response')
    async def middleware_test(request):
        pass

    assert app._future_middleware[1].middleware == middleware_test
    assert app._future_middleware[1].attach_to == 'response'

    @app.middleware('request')
    async def middleware_test(request):
        pass

    assert app._future_middleware[2].middleware == middleware_test
    assert app._future_middleware

# Generated at 2022-06-18 05:43:31.869810
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def middleware(request):
        return request
    assert middleware == app._future_middleware[0].middleware
    assert 'request' == app._future_middleware[0].attach_to


# Generated at 2022-06-18 05:43:43.834128
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_request(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:43:45.831219
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_request == app.middleware


# Generated at 2022-06-18 05:43:53.768587
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_request(middleware=None)
    test_middleware_mixin.on_request(middleware=lambda request: None)


# Generated at 2022-06-18 05:43:58.861268
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:44:03.586639
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:44:10.461659
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_on_request")
    @app.on_request
    def on_request_middleware(request):
        return request
    assert app._future_middleware[0].middleware == on_request_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:44:14.046421
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'


# Generated at 2022-06-18 05:44:18.988062
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware_stack[0].middleware == test_on_request


# Generated at 2022-06-18 05:44:23.951018
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def request_handler(request):
        return request
    assert app.on_request(request_handler) == request_handler


# Generated at 2022-06-18 05:44:29.097111
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:44:37.456263
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic(__name__)

    @app.middleware
    async def test_middleware(request):
        pass

    assert app.on_request(test_middleware) == test_middleware
    assert app.on_request(test_middleware) == app.middleware(test_middleware)


# Generated at 2022-06-18 05:44:46.780508
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware("request")
    async def request_middleware(request):
        request["middleware"] = "ran"

    @app.middleware("response")
    async def response_middleware(request, response):
        response.text += " - middleware ran"

    @app.exception(NotFound)
    async def ignore_404s(request, exception):
        return text("Yep, I totally found the page: {}".format(request.url))

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")


# Generated at 2022-06-18 05:44:52.471950
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_on_request')

    @app.on_request
    def on_request(request):
        pass

    @app.route('/')
    def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'


# Generated at 2022-06-18 05:44:55.935208
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    assert app._future_middleware == []
    assert app._apply_middleware is None


# Generated at 2022-06-18 05:44:59.222045
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        pass
    assert app._future_middleware[0].middleware == test_on_request
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:45:04.305012
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware_stack[0].middleware == test_on_request


# Generated at 2022-06-18 05:45:13.839637
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def middleware1(request):
        return json({'middleware1': 'middleware1'})

    @app.middleware('request')
    def middleware2(request):
        return json({'middleware2': 'middleware2'})

    @app.middleware('response')
    def middleware3(request, response):
        return json({'middleware3': 'middleware3'})

    @app.route('/')
    def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

# Generated at 2022-06-18 05:45:20.779843
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_class = TestClass()
    test_class.on_request(middleware=None)


# Generated at 2022-06-18 05:45:25.686264
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_on_request")
    @app.on_request
    def test_on_request(request):
        return request
    assert app.middleware[0].middleware == test_on_request


# Generated at 2022-06-18 05:45:30.323320
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def on_request(request):
        pass
    assert app._future_middleware[0].middleware == on_request
    assert app._future_middleware[0].attach_to == "request"
