

# Generated at 2022-06-18 05:41:26.947912
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].apply == True


# Generated at 2022-06-18 05:41:30.335716
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app.middleware[0].middleware == test_on_response
    assert app.middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:41:37.441126
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()

    @app.on_response
    def on_response_middleware(request, response):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == on_response_middleware
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:41:41.390009
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:41:45.470641
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:41:51.029851
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test')
    assert app.on_response == app.middleware
    assert app.on_response('response') == app.middleware('response')
    assert app.on_response(lambda x: x) == app.middleware(lambda x: x)
    assert app.on_response(lambda x: x, 'response') == app.middleware(lambda x: x, 'response')


# Generated at 2022-06-18 05:41:54.187052
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware


# Generated at 2022-06-18 05:41:57.816727
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text

    def middleware(request):
        return text("OK")

    app = Sanic("test_MiddlewareMixin_on_response")
    app.on_response(middleware)
    assert app.middleware[0].middleware == middleware
    assert app.middleware[0].attach_to == "response"

# Generated at 2022-06-18 05:42:04.346095
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:42:16.155277
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app._future_middleware == []
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    @app.middleware
    def middleware_test(request):
        return request
    assert app._future_middleware != []
    assert app._future_middleware[0].middleware == middleware_test
    assert app._future_middleware[0].attach_to == 'request'
    @app.middleware('response')
    def middleware_test2(request, response):
        return response
    assert app._future_middleware != []
    assert app._

# Generated at 2022-06-18 05:42:24.967405
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_response(middleware=None)
    test_middleware_mixin.on_response(middleware=lambda x: x)

# Generated at 2022-06-18 05:42:37.707787
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return json({'test': True})

    @app.middleware('request')
    async def test_middleware_request(request):
        return json({'test': True})

    @app.middleware('response')
    async def test_middleware_response(request, response):
        return json({'test': True})

    assert len(app._future_middleware) == 3

# Generated at 2022-06-18 05:42:42.456012
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic()

    @app.middleware
    async def process_response(request, response):
        response.text = "Hello world"

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.text == "OK"

    request, response = app.test_client.get("/")
    assert response.text == "Hello world"

# Generated at 2022-06-18 05:42:52.568784
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.request import Request

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def process_request(request):
        request['processed_by'] = 'process_request'

    @app.middleware('request')
    async def process_request_2(request):
        request['processed_by'] = 'process_request_2'

    @app.middleware('response')
    async def process_response(request, response):
        response.text = 'processed_by: {}'.format(request['processed_by'])

    @app.route('/')
    async def handler(request):
        return text('OK')


# Generated at 2022-06-18 05:42:55.631004
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:43:04.743840
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_on_response')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('test_MiddlewareMixin_on_response')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'OK'

# Generated at 2022-06-18 05:43:09.756190
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].attach_to == 'response'
    assert app._future_middleware[0].middleware == test_on_response


# Generated at 2022-06-18 05:43:17.029532
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.route('/')
    async def handler(request):
        return text('OK')
    @app.on_response
    def on_response(request, response):
        response.headers['X-On-Response'] = 'True'
    request, response = app.test_client.get('/')
    assert response.headers.get('X-On-Response') == 'True'


# Generated at 2022-06-18 05:43:21.765752
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:43:26.062801
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:43:36.121820
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:43:41.676200
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:43:45.481623
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response


# Generated at 2022-06-18 05:43:56.388999
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware == MiddlewareMixin._apply_middleware
    assert app.middleware('request') == MiddlewareMixin.middleware(app, 'request')
    assert app.middleware('response') == MiddlewareMixin.middleware(app, 'response')
    assert app.on_request() == MiddlewareMixin.on_request(app)
    assert app.on_response() == MiddlewareMixin.on_response(app)

# Generated at 2022-06-18 05:43:59.137186
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_response(middleware=None) == partial(app.middleware, attach_to="response")

# Generated at 2022-06-18 05:44:06.275561
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:44:12.178927
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_on_response")
    @app.on_response
    def test_on_response(request, response):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "response"
    assert app._future_middleware[0].middleware == test_on_response


# Generated at 2022-06-18 05:44:16.094590
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:44:22.826625
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def response_middleware(request, response):
        print('response_middleware')
    assert app.middleware_stack[0].middleware == response_middleware
    assert app.middleware_stack[0].attach_to == 'response'


# Generated at 2022-06-18 05:44:25.065075
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def response_middleware(request, response):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:44:45.000102
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_test(request):
        return request

    assert app._future_middleware[0].middleware == middleware_test
    assert app._future_middleware[0].attach_to == 'request'

    @app.middleware('response')
    async def middleware_test2(request):
        return request

    assert app._future_middleware[1].middleware == middleware_test2
    assert app._future_middleware[1].attach_to == 'response'

    @app.middleware('request')
    async def middleware_test3(request):
        return request

    assert app._future_middleware[2].middleware == middleware_test3
   

# Generated at 2022-06-18 05:44:53.734511
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_request(request):
        request['middleware'] = True

    @app.middleware('response')
    async def middleware_response(request, response):
        response.text += ' middleware'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK middleware'
    assert request['middleware'] is True



# Generated at 2022-06-18 05:45:02.218351
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        pass

    @app.middleware('request')
    async def middleware2(request):
        pass

    @app.middleware('response')
    async def middleware3(request, response):
        pass

    assert len(app._future_middleware) == 3
    assert app._future_middleware[0].middleware == middleware1
    assert app._future_middleware[1].middleware == middleware2
    assert app._future_middleware[2].middleware == middleware3


# Generated at 2022-06-18 05:45:12.641708
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        request['middleware1'] = True

    @app.middleware('request')
    async def middleware2(request):
        request['middleware2'] = True

    @app.middleware('response')
    async def middleware3(request, response):
        response.headers['middleware3'] = True

    @app.route('/')
    async def handler(request):
        return text('OK')


# Generated at 2022-06-18 05:45:14.957533
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None


# Generated at 2022-06-18 05:45:19.193689
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:45:29.582764
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import NotFound
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware

    app = Sanic(__name__)

    @app.middleware
    async def middleware_a(request):
        request['middleware'] = 'a'

    @app.middleware('request')
    async def middleware_b(request):
        request['middleware'] = 'b'

    @app.middleware('response')
    async def middleware_c(request, response):
        response.body = 'c'

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test

# Generated at 2022-06-18 05:45:34.494071
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    assert app._future_middleware == []
    assert app._apply_middleware is None

# Generated at 2022-06-18 05:45:43.503695
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app._future_middleware == []
    assert app.middleware(lambda x: x)

# Generated at 2022-06-18 05:45:54.178021
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        return json({'middleware1': 'middleware1'})

    @app.middleware('request')
    async def middleware2(request):
        return json({'middleware2': 'middleware2'})

    @app.middleware('response')
    async def middleware3(request, response):
        return json({'middleware3': 'middleware3'})

    @app.route('/')
    async def handler(request):
        return json({'test': 'test'})

    request, response = app.test_client.get

# Generated at 2022-06-18 05:46:13.056904
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic()
    @app.middleware
    async def middleware(request):
        return text('middleware')
    request, response = app.test_client.get('/')
    assert response.text == 'middleware'


# Generated at 2022-06-18 05:46:21.494777
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware == MiddlewareMixin._apply_middleware
    assert app.middleware('request') == MiddlewareMixin.middleware(app, 'request')
    assert app.on_request() == MiddlewareMixin.on_request(app)
    assert app.on_response() == MiddlewareMixin.on_response(app)


# Generated at 2022-06-18 05:46:27.134763
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:46:33.224177
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:46:42.511468
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()

    assert app._future_middleware == []

    @app.middleware
    async def test_middleware(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"

    @app.middleware("response")
    async def test_middleware_response(request):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == test_middleware_response
    assert app._future_middleware[1].attach_to == "response"


# Generated at 2022-06-18 05:46:47.808564
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_test(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'

# Generated at 2022-06-18 05:46:57.035600
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        return text('Pass')

    @app.middleware('request')
    async def middleware2(request):
        return text('Pass')

    @app.middleware('response')
    async def middleware3(request, response):
        return text('Pass')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'Pass'

    request, response = app.test_client.get('/')

# Generated at 2022-06-18 05:47:01.482306
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        pass
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:47:06.032105
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return request

    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:47:12.178241
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddleware

# Generated at 2022-06-18 05:47:43.781670
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def handler(request):
        return text('OK')
    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:47:54.533517
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test = TestMiddlewareMixin()
    @test.middleware
    def test_middleware(request):
        pass

    assert len(test._future_middleware) == 1
    assert test._future_middleware[0].middleware == test_middleware
    assert test._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:47:58.363822
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    assert app._future_middleware == []
    assert app._apply_middleware is None


# Generated at 2022-06-18 05:48:04.043287
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app.middleware(None) is not None
    assert app.middleware(None, 'request') is not None
    assert app.middleware(None, 'response') is not None
    assert app.on_request(None) is not None
    assert app.on_response(None) is not None

# Generated at 2022-06-18 05:48:09.886438
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('pass')

    request, response = app.test_client.get('/')
    assert response.text == 'pass'


# Generated at 2022-06-18 05:48:17.569102
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def test_middleware(request):
        return text("OK")

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"

    @app.middleware("response")
    async def test_middleware(request):
        return text("OK")

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == test_middleware
    assert app._future_middleware[1].attach_to == "response"

# Generated at 2022-06-18 05:48:26.267429
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic()

    @app.middleware
    async def print_on_request(request):
        print("I print when a request is received by the server")

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I print when a response is returned by the server")

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:48:34.884827
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()
    assert app._future_middleware == []
    @app.middleware
    def middleware(request):
        return request
    assert app._future_middleware != []
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == "request"
    @app.middleware('response')
    def middleware(request):
        return request
    assert app._future_middleware[1].middleware == middleware
    assert app._future_middleware[1].attach_to == "response"


# Generated at 2022-06-18 05:48:44.111947
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.views import HTTPMethodView

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:48:53.809141
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        request['middleware1'] = True

    @app.middleware('request')
    async def middleware2(request):
        request['middleware2'] = True

    @app.middleware('response')
    async def middleware3(request, response):
        response.body = b'middleware3'

    @app.route('/')
    async def handler(request):
        return json({'test': True})


# Generated at 2022-06-18 05:50:02.954219
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.models.futures import FutureMiddleware

    def middleware_request(request: Request):
        return request

    def middleware_response(request: Request, response: HTTPResponse):
        return response

    app = Sanic("test_MiddlewareMixin_middleware")

    # Test for method middleware
    app.middleware(middleware_request)
    app.middleware(middleware_response, attach_to="response")

    assert len(app._future_middleware) == 2
    assert isinstance(app._future_middleware[0], FutureMiddleware)

# Generated at 2022-06-18 05:50:10.467677
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    app = Sanic()
    @app.middleware
    async def test_middleware(request):
        return json({'test': 'test_middleware'})
    @app.route('/test')
    async def test(request):
        return json({'test': 'test'})
    request, response = app.test_client.get('/test')
    assert response.json == {'test': 'test_middleware'}


# Generated at 2022-06-18 05:50:18.935361
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(middleware_or_request=lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    test_middleware_mixin.middleware(middleware_or_request=lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 2
    test_middleware_mixin

# Generated at 2022-06-18 05:50:31.607361
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app._future_middleware == []
    @app.middleware
    def middleware(request):
        pass
    assert app._future_middleware != []
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].args == ()
    assert app._future_middleware[0].kwargs == {}
    @app.middleware('response')
    def middleware(request):
        pass
    assert app._future_middleware[1].middleware == middleware
    assert app._future_middleware[1].attach_to == "response"
    assert app._future_middleware[1].args == ()
    assert app

# Generated at 2022-06-18 05:50:39.488136
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic()

    @app.middleware('request')
    async def print_on_request(request):
        print('I run on each request!')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('I run on each response!')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'OK'


# Generated at 2022-06-18 05:50:49.024342
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json

    app = Sanic()

    @app.middleware
    async def print_on_request(request):
        print("I print when a request is received by the server")

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I print when a response is returned by the server")

    @app.route("/")
    async def test(request):
        return json({"test": True})

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.json == {"test": True}


# Generated at 2022-06-18 05:51:00.528572
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddlewareType
    from sanic.models.futures import FutureMiddlewareAttachType

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware("request")
    async def request_middleware(request):
        request["middleware"] = "request"

    @app.middleware("response")
    async def response_middleware(request, response):
        response.body = b"response"

    @app.route("/")
    async def handler(request):
        return json({"test": True})

   

# Generated at 2022-06-18 05:51:02.682661
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:51:11.733775
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    assert test_middleware_mixin._future_middleware == []
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1

# Generated at 2022-06-18 05:51:23.406815
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app._future_middleware == []
    @app.middleware
    def test_middleware(request):
        pass
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0]._app == app
    assert app._future_middleware[0]._app_id == id(app)
    assert app._future_middleware[0]._app_name == "test_app"
    assert app._future_middleware[0]._app_version == "0.0.1"
    assert app._future_middleware[0]._app_uri == "http://localhost:8000"
    assert app._future_