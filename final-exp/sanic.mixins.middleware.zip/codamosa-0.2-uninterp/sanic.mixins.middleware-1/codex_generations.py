

# Generated at 2022-06-18 05:41:30.002871
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == 'response'
    assert app._future_middleware[0].middleware == test_on_response


# Generated at 2022-06-18 05:41:35.482221
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:41:40.286739
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:41:47.457160
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware == MiddlewareMixin._apply_middleware


# Generated at 2022-06-18 05:41:54.034535
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.middleware
    async def response_middleware(request):
        return text('OK')
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].middleware == response_middleware
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:42:01.372280
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:42:07.046281
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:42:10.289236
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:42:20.516709
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware('request')
    async def request_middleware(request):
        pass
    @app.middleware('response')
    async def response_middleware(request, response):
        pass
    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].middleware == response_middleware
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-18 05:42:22.805748
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test')
    app.on_response(middleware=None)


# Generated at 2022-06-18 05:42:31.541213
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_response() == partial(app.middleware, attach_to="response")
    assert app.on_response(lambda x: x) == app.middleware(lambda x: x, "response")


# Generated at 2022-06-18 05:42:41.353067
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def middleware_1(request):
        return text('Pass')

    @app.middleware('request')
    def middleware_2(request):
        return text('Pass')

    @app.middleware('response')
    def middleware_3(request, response):
        return text('Pass')

    @app.route('/')
    def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')


# Generated at 2022-06-18 05:42:46.709178
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic(__name__)
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:42:58.993969
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        request['middleware'] = 'this is a request middleware'

    @app.middleware('response')
    async def response_middleware(request, response):
        response.text += ' | this is a response middleware'

    @app.route('/')
    async def handler(request):
        return text('this is a normal response')

    request, response = app.test_client.get('/')

    assert response.text == 'this is a normal response | this is a response middleware'
    assert request['middleware'] == 'this is a request middleware'



# Generated at 2022-06-18 05:43:01.527698
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_response == app.middleware(attach_to='response')


# Generated at 2022-06-18 05:43:06.038318
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test')
    assert app.on_response() == partial(app.middleware, attach_to='response')
    assert app.on_response(lambda x: x) == app.middleware(lambda x: x, attach_to='response')


# Generated at 2022-06-18 05:43:11.963530
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'
    assert response.status == 200


# Generated at 2022-06-18 05:43:17.173985
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        pass
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:43:19.696028
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_response(middleware=None)


# Generated at 2022-06-18 05:43:27.133230
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import SanicException
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        return json({'request': True})

    @app.middleware('response')
    async def response_middleware(request, response):
        return json({'response': True})

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.json == {'request': True}

    request, response = app.test_client.get('/')


# Generated at 2022-06-18 05:43:42.940753
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.models.futures import FutureMiddleware

    app = Sanic()

    @app.middleware
    def middleware_1(request):
        return text('OK')

    @app.middleware('response')
    def middleware_2(request, response):
        return text('OK')

    @app.middleware('request')
    def middleware_3(request):
        return text('OK')

    @app.middleware('request')
    def middleware_4(request):
        return text('OK')

    @app.middleware('request')
    def middleware_5(request):
        return text('OK')


# Generated at 2022-06-18 05:43:49.818321
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic()

    @app.middleware
    async def middleware(request):
        return text("OK")

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.text == "OK"

# Generated at 2022-06-18 05:43:54.751612
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()
    @app.middleware
    async def test_middleware(request):
        return request
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:44:06.427180
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware(middleware_or_request=None, attach_to="request", apply=True)
    assert app.middleware(middleware_or_request=None, attach_to="response", apply=True)
    assert app.middleware(middleware_or_request=None, attach_to="request", apply=False)
    assert app.middleware(middleware_or_request=None, attach_to="response", apply=False)
    assert app.middleware(middleware_or_request=None, attach_to="request")
    assert app.middleware(middleware_or_request=None, attach_to="response")
    assert app.middleware(middleware_or_request=None)
   

# Generated at 2022-06-18 05:44:11.238142
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response


# Generated at 2022-06-18 05:44:15.508512
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    assert app._future_middleware == []
    assert app._apply_middleware is None


# Generated at 2022-06-18 05:44:21.727047
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:44:32.513940
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.request import Request
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddlewareType
    from sanic.models.futures import FutureMiddlewareAttachType

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_1(request):
        return text('OK')

    @app.middleware('request')
    async def middleware_2(request):
        return text('OK')

    @app.middleware('response')
    async def middleware_3(request, response):
        return text('OK')

    assert len(app._future_middleware) == 3

# Generated at 2022-06-18 05:44:40.486403
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    test_middleware_mixin.middleware(lambda x: x, attach_to="request")
    assert len(test_middleware_mixin._future_middleware) == 2
    test_middleware_mixin.middleware(lambda x: x, attach_to="response")
    assert len(test_middleware_mixin._future_middleware) == 3


# Generated at 2022-06-18 05:44:45.624336
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware == MiddlewareMixin._apply_middleware


# Generated at 2022-06-18 05:45:00.826550
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware == MiddlewareMixin._apply_middleware
    assert app.middleware('request') == MiddlewareMixin.middleware(app, 'request')
    assert app.on_request() == MiddlewareMixin.on_request(app)
    assert app.on_response() == MiddlewareMixin.on_response(app)


# Generated at 2022-06-18 05:45:07.783264
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        return text('OK')

    @app.middleware('request')
    async def middleware2(request):
        return text('OK')

    @app.middleware('response')
    async def middleware3(request, response):
        return text('OK')

    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert isinstance(app._future_middleware[1], FutureMiddleware)
    assert isinstance(app._future_middleware[2], FutureMiddleware)

# Generated at 2022-06-18 05:45:10.918419
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    assert app._future_middleware == []

# Generated at 2022-06-18 05:45:14.563170
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    app.middleware('request')(lambda x: x)
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == 'request'

# Generated at 2022-06-18 05:45:20.646227
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:45:28.128545
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware == MiddlewareMixin._apply_middleware
    assert app._apply_middleware(None) == NotImplementedError


# Generated at 2022-06-18 05:45:38.685177
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddlewareType

    app = Sanic()

    @app.middleware
    async def middleware_1(request):
        pass

    @app.middleware('request')
    async def middleware_2(request):
        pass

    @app.middleware('response')
    async def middleware_3(request, response):
        pass

    @app.middleware('request')
    async def middleware_4(request):
        pass

    @app.middleware('response')
    async def middleware_5(request, response):
        pass

    @app.middleware('request')
    async def middleware_6(request):
        pass


# Generated at 2022-06-18 05:45:42.649769
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:45:52.473313
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('request')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:45:59.458325
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:46:22.835938
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    from sanic.request import Request

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def middleware_test(request):
        request["test"] = True

    @app.middleware("request")
    async def middleware_test2(request):
        request["test2"] = True

    @app.middleware("response")
    async def middleware_test3(request, response):
        response.text += "test3"

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")

    assert request["test"] is True
    assert request["test2"] is True

# Generated at 2022-06-18 05:46:31.712343
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print("I am a request middleware")

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I am a response middleware")

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'


# Generated at 2022-06-18 05:46:41.506429
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        return text('OK')

    @app.middleware('request')
    async def middleware2(request):
        return text('OK')

    @app.middleware('response')
    async def middleware3(request, response):
        return text('OK')

    assert len(app._future_middleware) == 3
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].middleware == middleware1

# Generated at 2022-06-18 05:46:46.519933
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_test(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == middleware_test
    assert app._future_middleware[0].attach_to == 'request'

    @app.middleware('response')
    async def middleware_test2(request):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == middleware_test2
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-18 05:46:52.083506
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:46:55.732768
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def test_middleware(request):
        pass
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:47:05.619629
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('I run on each request')

    @app.middleware('request')
    async def halt_request(request):
        return json({'test': True})

    @app.middleware('response')
    async def print_on_response(request, response):
        print('I run on each response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.status == 200

# Generated at 2022-06-18 05:47:08.623195
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response


# Generated at 2022-06-18 05:47:13.396685
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None

# Generated at 2022-06-18 05:47:16.469430
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def middleware(request):
        pass
    assert len(app._future_middleware) == 1


# Generated at 2022-06-18 05:47:57.599031
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'
    @app.on_request
    async def test_on_request(request):
        return request
    assert app._future_middleware[1].middleware == test_on_request
    assert app._future_middleware[1].attach_to == 'request'

# Generated at 2022-06-18 05:48:09.244898
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print("I print when a request is received by the server")

    @app.middleware('request')
    async def halt_request(request):
        return json({'test': True})

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I print when a response is returned by the server")

    @app.route('/')
    async def handler(request):
        return json({'test': True})


# Generated at 2022-06-18 05:48:14.459812
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_1(request):
        request['middleware'] = 'middleware_1'

    @app.middleware('request')
    async def middleware_2(request):
        request['middleware'] = 'middleware_2'

    @app.middleware('response')
    async def middleware_3(request, response):
        response.text = 'middleware_3'

    @app.route('/')
    async def handler(request):
        return json({'test': 'OK'})


# Generated at 2022-06-18 05:48:19.283278
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    assert app._future_middleware == []
    assert app._apply_middleware is None


# Generated at 2022-06-18 05:48:30.749636
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import ServerError
    from sanic.models.futures import FutureMiddleware

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def middleware_1(request):
        return text("OK")

    @app.middleware('request')
    async def middleware_2(request):
        return text("OK")

    @app.middleware('response')
    async def middleware_3(request, response):
        return text("OK")

    @app.middleware('request')
    async def middleware_4(request):
        return text("OK")

    @app.middleware('response')
    async def middleware_5(request, response):
        return text

# Generated at 2022-06-18 05:48:38.559515
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import ServerError

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        request['middleware1'] = True
        return await response

    @app.middleware('request')
    async def middleware2(request):
        request['middleware2'] = True
        return await response

    @app.middleware('response')
    async def middleware3(request, response):
        response.headers['middleware3'] = True
        return response

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')


# Generated at 2022-06-18 05:48:43.345748
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('pass')

    request, response = app.test_client.get('/')
    assert response.text == 'pass'


# Generated at 2022-06-18 05:48:47.887208
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return text('pass')
    request, response = app.test_client.get('/')
    assert response.text == 'pass'


# Generated at 2022-06-18 05:48:58.293761
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is MiddlewareMixin.middleware.__get__(app)
    assert app.on_request is MiddlewareMixin.on_request.__get__(app)
    assert app.on_response is MiddlewareMixin.on_response.__get__(app)
    assert app._future_middleware == []
    assert app._apply_middleware is None
    assert app.middleware is not MiddlewareMixin.middleware
    assert app.on_request is not MiddlewareMixin.on_request
    assert app.on_response is not MiddlewareMixin.on_response
    assert app._future_middleware is not MiddlewareMixin._future_middleware
    assert app._apply_middleware

# Generated at 2022-06-18 05:49:04.105413
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.views import HTTPMethodView

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware("request")
    async def request_middleware(request):
        request["middleware"] = "request"

    @app.middleware("response")
    async def response_middleware(request, response):
        response.text = "response"

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.text == "response"
    assert request["middleware"] == "request"


# Generated at 2022-06-18 05:50:16.252564
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.models.futures import FutureMiddleware

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def middleware(request):
        return json({"middleware": True})

    request, response = app.test_client.get("/")
    assert response.json == {"middleware": True}

    assert len(app._future_middleware) == 1
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:50:20.200027
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def test_middleware(request):
        return text('test_middleware')

    request, response = app.test_client.get('/')

    assert response.text == 'test_middleware'

# Generated at 2022-06-18 05:50:32.858992
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    assert test_middleware_mixin._future_middleware == []

    @test_middleware_mixin.middleware
    async def test_middleware(request):
        pass

    assert len(test_middleware_mixin._future_middleware) == 1
    assert test_middleware_mixin._future_middleware[0].middleware == test_middleware
    assert test_middleware_mixin

# Generated at 2022-06-18 05:50:42.221034
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()
    assert app._future_middleware == []
    @app.middleware
    def middleware_1(request):
        pass
    assert app._future_middleware[0].middleware == middleware_1
    assert app._future_middleware[0].attach_to == "request"
    @app.middleware('request')
    def middleware_2(request):
        pass
    assert app._future_middleware[1].middleware == middleware_2
    assert app._future_middleware[1].attach_to == "request"
    @app.middleware('response')
    def middleware_3(request):
        pass
    assert app._future_middleware[2].middleware == middleware_3
    assert app._future_middleware[2].attach

# Generated at 2022-06-18 05:50:53.276213
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def print_on_request(request):
        print('I run on each request!')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('I run on each response!')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}

    # Test for method middleware of class MiddlewareMixin

# Generated at 2022-06-18 05:51:04.312502
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        request['middleware'] = 'this is a request middleware'

    @app.middleware('response')
    async def response_middleware(request, response):
        response.text += ' this is a response middleware'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK this is a response middleware'
    assert request['middleware'] == 'this is a request middleware'


# Generated at 2022-06-18 05:51:14.471971
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def print_on_request(request):
        print('I run on each request')

    @app.middleware('request')
    async def halt_request(request):
        return json({'test': True})

    @app.middleware('response')
    async def print_on_response(request, response):
        print('I run on each response')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200

# Generated at 2022-06-18 05:51:19.810273
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.json == {'test': True}


# Generated at 2022-06-18 05:51:24.283120
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
