

# Generated at 2022-06-18 05:41:25.683618
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import NotFound

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def print_on_request(request):
        print("I am a request middleware")

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I am a response middleware")

    @app.route("/")
    async def handler(request):
        return json({"test": True})

    @app.exception(NotFound)
    async def ignore_404s(request, exception):
        return json({"status": 404, "message": "Not found"})

    request, response = app.test_client.get("/")

# Generated at 2022-06-18 05:41:29.887686
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware == MiddlewareMixin._apply_middleware


# Generated at 2022-06-18 05:41:38.811849
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_request(middleware=lambda x: x)
    assert test_middleware_mixin._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:41:47.974392
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_on_response')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('Before response sent to client')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:41:52.781118
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request: Request):
        return HTTPResponse(text='pass')

    request, response = app.test_client.get('/')
    assert response.text == 'pass'

# Generated at 2022-06-18 05:42:04.796869
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    @app.middleware
    async def middleware1(request):
        return request
    @app.middleware('request')
    async def middleware2(request):
        return request
    @app.middleware('response')
    async def middleware3(request, response):
        return response
    assert app._future_middleware[0].middleware == middleware1
    assert app._future_middleware[1].middleware == middleware2
    assert app._future_middleware[2].middleware == middleware3


# Generated at 2022-06-18 05:42:09.954538
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:42:15.342930
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def handler(request, response):
        pass
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:42:18.339194
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:42:22.719215
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware


# Generated at 2022-06-18 05:42:32.599064
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic()
    @app.on_response
    def response_middleware(request, response):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "response"
    assert app._future_middleware[0].middleware == response_middleware


# Generated at 2022-06-18 05:42:37.659610
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic(__name__)
    @app.middleware
    def middleware_test(request):
        return text('middleware_test')
    request, response = app.test_client.get('/')
    assert response.text == 'middleware_test'


# Generated at 2022-06-18 05:42:43.313665
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:42:50.199988
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app.middleware(middleware_or_request='request')
    assert app.middleware(middleware_or_request='response')
    assert app.middleware(middleware_or_request=lambda x: x)
    assert app.on_request()
    assert app.on_response()
    assert app.on_request(middleware=lambda x: x)
    assert app.on_response(middleware=lambda x: x)


# Generated at 2022-06-18 05:43:02.537483
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.views import HTTPMethodView
    from sanic.models.futures import FutureMiddleware

    app = Sanic(__name__)

    class SimpleView(HTTPMethodView):
        def get(self, request):
            return json({"hello": "world"})

    @app.on_response
    def on_response(request, response):
        response.headers["X-Served-By"] = "sanic"

    app.add_route(SimpleView.as_view(), "/")

    request, response = app.test_client.get("/")
    assert response.status == 200
    assert response.headers.get("X-Served-By") == "sanic"

    # Test that the middleware

# Generated at 2022-06-18 05:43:06.631211
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_response() == partial(app.middleware, attach_to="response")
    assert app.on_response(lambda x: x) == app.middleware(lambda x: x, "response")


# Generated at 2022-06-18 05:43:16.619246
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()

    @app.middleware
    def middleware(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == "request"

    @app.middleware('response')
    def middleware2(request, response):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == middleware2
    assert app._future_middleware[1].attach_to == "response"

    @app.middleware('request')
    def middleware3(request):
        pass

    assert len(app._future_middleware) == 3
    assert app

# Generated at 2022-06-18 05:43:23.893017
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        response.headers['X-Served-By'] = 'sanic'
    @app.route('/')
    def handler(request):
        return text('OK')
    request, response = app.test_client.get('/')
    assert response.headers.get('X-Served-By') == 'sanic'


# Generated at 2022-06-18 05:43:26.442784
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.middleware
    def test_middleware(request):
        return request
    assert test_middleware == app.on_request(test_middleware)


# Generated at 2022-06-18 05:43:35.273861
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test')
    assert app.on_response == app.middleware

    @app.on_response
    def test_on_response(request, response):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == 'response'
    assert app._future_middleware[0].middleware == test_on_response


# Generated at 2022-06-18 05:43:41.361634
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:43:46.255923
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:43:53.191387
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == 'response'
    assert app._future_middleware[0].middleware == on_response


# Generated at 2022-06-18 05:43:58.712516
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:44:01.002836
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_response(middleware=None)


# Generated at 2022-06-18 05:44:07.498442
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:44:12.526829
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-18 05:44:18.204145
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:44:29.717157
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic(__name__)
    assert app._future_middleware == []
    assert app.middleware(middleware_or_request=lambda x: x)
    assert app._future_middleware == [FutureMiddleware(lambda x: x, "request")]
    assert app.middleware(middleware_or_request=lambda x: x, attach_to="response")
    assert app._future_middleware == [FutureMiddleware(lambda x: x, "request"), FutureMiddleware(lambda x: x, "response")]
    assert app.middleware(middleware_or_request=lambda x: x, attach_to="request")

# Generated at 2022-06-18 05:44:32.070997
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_response(middleware=None)

# Generated at 2022-06-18 05:44:44.536662
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def response_middleware(request, response):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == response_middleware
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:44:48.441220
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_on_response")
    @app.on_response
    def test_MiddlewareMixin_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_MiddlewareMixin_on_response
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:44:54.008491
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_on_response")
    @app.on_response
    def test_on_response(request, response):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "response"
    assert app._future_middleware[0].middleware == test_on_response


# Generated at 2022-06-18 05:44:56.596924
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    app.on_response(lambda request, response: response)
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:45:00.371443
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:45:09.613747
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_on_response')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('Response from {}'.format(request.url))

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.text == 'OK'


# Generated at 2022-06-18 05:45:11.376551
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_response == app.middleware('response')


# Generated at 2022-06-18 05:45:14.915795
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic(__name__)

    @app.on_response
    def on_response(request, response):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:45:20.601806
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic()
    @app.on_response
    def response_middleware(request, response):
        pass
    assert app._future_middleware[0].middleware == response_middleware
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:45:25.490583
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_response == app.middleware(attach_to="response")
    assert app.on_response(lambda x: x) == app.middleware(lambda x: x, attach_to="response")


# Generated at 2022-06-18 05:45:43.501252
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        response.body = b'on_response'
    request, response = app.test_client.get('/')
    assert response.body == b'on_response'


# Generated at 2022-06-18 05:45:49.660675
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def response_middleware(request, response):
        pass
    assert app._future_middleware[0].middleware == response_middleware
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:45:56.331069
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic()

    @app.middleware
    async def print_on_request(request):
        print("I print when a request is received by the server")

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I print when a response is returned by the server")

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:46:02.733244
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def test_on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:46:08.905303
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic(__name__)

    @app.middleware
    async def print_on_request(request):
        print("I print when a request is received by the server")

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I print when a response is returned by the server")

    @app.route('/')
    async def handler(request):
        return json({'hello': 'world'})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'hello': 'world'}


# Generated at 2022-06-18 05:46:16.271488
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_response(middleware=None)

# Generated at 2022-06-18 05:46:23.266017
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_on_response")
    @app.on_response
    def test_on_response(request, response):
        pass
    assert app._future_middleware[0].middleware == test_on_response
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-18 05:46:29.780785
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_on_response")
    @app.on_response
    def response_middleware(request, response):
        return response
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "response"
    assert app._future_middleware[0].middleware == response_middleware


# Generated at 2022-06-18 05:46:36.000282
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        return response
    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-18 05:46:43.728860
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json

    app = Sanic(__name__)

    @app.middleware
    async def print_on_request(request):
        print("I print when a request is received by the server")

    @app.middleware('request')
    async def halt_request(request):
        return json({'test': True})

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I print when a response is returned by the server")

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}

    request, response

# Generated at 2022-06-18 05:47:42.868958
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:47:53.037700
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def handler(request):
        pass

    @app.middleware('request')
    async def handler(request):
        pass

    @app.middleware('response')
    async def handler(request, response):
        pass

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.text == 'OK'

# Generated at 2022-06-18 05:48:00.504509
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        pass

    @app.middleware('response')
    async def response_middleware(request, response):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].middleware == response_middleware
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-18 05:48:06.484250
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def middleware_test(request):
        pass
    assert app._future_middleware[0].middleware == middleware_test
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-18 05:48:15.359449
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic()

    @app.middleware
    def middleware_1(request):
        return text('Pass')

    @app.middleware('request')
    def middleware_2(request):
        return text('Pass')

    @app.middleware('response')
    def middleware_3(request, response):
        return text('Pass')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'Pass'

    request, response = app.test_client.get('/')
    assert response.text == 'Pass'

    request, response = app

# Generated at 2022-06-18 05:48:25.839871
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware is not None
    assert app._future_middleware[0].attach_to == 'request'
    @app.middleware('response')
    async def test_middleware(request):
        return request
    assert app._future_middleware[1].middleware is not None
    assert app._future_middleware[1].attach_to == 'response'
    @app.on_request
    async def test_middleware(request):
        return

# Generated at 2022-06-18 05:48:31.493194
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def test_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-18 05:48:39.868878
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(middleware_or_request=lambda x: x)
    assert len(test_middleware_mixin._future_middleware) == 1
    test_middleware_mixin.middleware(middleware_or_request=lambda x: x, attach_to="response")
    assert len(test_middleware_mixin._future_middleware) == 2
    test

# Generated at 2022-06-18 05:48:47.413309
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware_test(request):
        return text('OK')

    @app.middleware('request')
    async def middleware_test_request(request):
        return text('OK')

    @app.middleware('response')
    async def middleware_test_response(request, response):
        return text('OK')

    @app.route('/')
    async def handler(request):
        return text('OK')

    @app.exception(NotFound)
    async def handler_exception(request, exception):
        return text('OK')

    request, response = app.test_client

# Generated at 2022-06-18 05:48:57.895459
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.models.futures import FutureMiddleware

    app = Sanic()

    @app.middleware
    async def middleware(request):
        return HTTPResponse(text="OK")

    @app.middleware("request")
    async def middleware_request(request):
        return HTTPResponse(text="OK")

    @app.middleware("response")
    async def middleware_response(request, response):
        return HTTPResponse(text="OK")

    assert len(app._future_middleware) == 3
    assert isinstance(app._future_middleware[0], FutureMiddleware)

# Generated at 2022-06-18 05:50:07.911240
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(middleware_or_request=None)
    test_middleware_mixin.middleware(middleware_or_request=None, attach_to="request")
    test_middleware_mixin.middleware(middleware_or_request=None, attach_to="response")
    test_middleware_mixin.middleware(middleware_or_request=None, attach_to="request", apply=True)
    test_middleware

# Generated at 2022-06-18 05:50:17.313727
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic(__name__)
    assert app._future_middleware == []
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app.middleware(lambda x: x)

# Generated at 2022-06-18 05:50:20.544903
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def test_middleware(request):
        return request
    assert app._future_middleware[0].middleware == test_middleware


# Generated at 2022-06-18 05:50:31.829281
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def print_on_request(request):
        print('I run on each request')
    @app.middleware('response')
    async def print_on_response(request, response):
        print('I run on each response')
    @app.route('/')
    async def handler(request):
        return json({'test': True})
    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}


# Generated at 2022-06-18 05:50:38.192703
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        return text('Pass')

    @app.middleware('request')
    async def middleware2(request):
        return text('Pass')

    @app.middleware('response')
    async def middleware3(request, response):
        return text('Pass')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'Pass'


# Generated at 2022-06-18 05:50:42.206433
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    app.middleware(None, attach_to="request")
    app.middleware(None, attach_to="response")
    app.on_request(None)
    app.on_response(None)


# Generated at 2022-06-18 05:50:53.240900
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        return text('OK')

    @app.middleware('request')
    async def middleware2(request):
        return text('OK')

    @app.middleware('response')
    async def middleware3(request, response):
        return text('OK')

    assert len(app._future_middleware) == 3
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert isinstance(app._future_middleware[1], FutureMiddleware)

# Generated at 2022-06-18 05:51:04.313408
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    @app.middleware
    async def test_middleware(request):
        return True
    assert test_middleware in app._future_middleware
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'
    @app.middleware('response')
    async def test_middleware2(request):
        return True
    assert test_middleware2 in app._future_middleware
    assert app._future_middleware[1].middleware == test_middleware2
    assert app._future

# Generated at 2022-06-18 05:51:12.815910
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware == MiddlewareMixin._apply_middleware
    assert app.middleware('request') == MiddlewareMixin.middleware(app, 'request')
    assert app.on_request() == MiddlewareMixin.on_request(app)
    assert app.on_response() == MiddlewareMixin.on_response(app)

# Generated at 2022-06-18 05:51:19.133546
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app._future_middleware == []
    assert app.middleware(None) == None
    assert app.middleware(None, None) == None
    assert app.middleware(None, None, None) == None
    assert app.on_request(None) == None
    assert app.on_response(None) == None