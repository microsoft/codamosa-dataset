

# Generated at 2022-06-26 03:37:52.142054
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    ## middleware_or_request is function
    @middleware_mixin_0.middleware
    def middleware_func_0():
        pass

    ## middleware_or_request is string
    middleware_func_1 = middleware_mixin_0.middleware("request")(
        lambda: None
    )

    assert middleware_mixin_0._future_middleware[0].attach_to == "request"
    assert middleware_mixin_0._future_middleware[1].attach_to == "request"




# Generated at 2022-06-26 03:37:54.522218
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware()


# Generated at 2022-06-26 03:38:01.134877
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = lambda response: response

    @middleware_mixin_0.middleware('response')
    def on_response(middleware_0 = middleware_0):
        return middleware_0

    def register_middleware(middleware, attach_to="response"):
        future_middleware_0 = FutureMiddleware(middleware, attach_to)
        middleware_mixin_0._future_middleware.append(future_middleware_0)
        middleware_mixin_0._apply_middleware(future_middleware_0)
        return middleware

    # Detect which way this was called, @middleware or @middleware('AT')

# Generated at 2022-06-26 03:38:05.578290
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Make instance of class MiddlewareMixin
    middleware_mixin_1 = MiddlewareMixin()
    # Call method on_request of class MiddlewareMixin
    middleware_mixin_1.on_request()

# Generated at 2022-06-26 03:38:07.977711
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(None, 'request')


# Generated at 2022-06-26 03:38:11.541358
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()


# Generated at 2022-06-26 03:38:14.834937
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    str_0 = middleware_mixin_0.on_request(middleware=None)
    assert str_0 is not None


# Generated at 2022-06-26 03:38:18.243546
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    @middleware_mixin_0.middleware
    async def foo(request):
        return request

    @middleware_mixin_0.on_response
    async def foo(request, response):
        return response



# Generated at 2022-06-26 03:38:21.473075
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

#test_MiddlewareMixin_on_response()

# Generated at 2022-06-26 03:38:25.567699
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware("request")
    mw = middleware_mixin_1.middleware("request")
    middleware_mixin_1.middleware(mw)


# Generated at 2022-06-26 03:38:29.958954
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_response()


# Generated at 2022-06-26 03:38:40.562188
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Initialization of middleware_mixin_1 with default parameters
    middleware_mixin_1 = MiddlewareMixin()

    def test_case_1(request):
        pass

    # Call of the method on_response of middleware_mixin_1
    assert callable(middleware_mixin_1.on_response())
    assert callable(middleware_mixin_1.on_response)
    assert callable(middleware_mixin_1.on_response(test_case_1))
    assert callable(middleware_mixin_1.on_response(test_case_1))


# Generated at 2022-06-26 03:38:45.399630
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    # Test case 0
    on_response_0 = middleware_mixin_0.on_response()

    # Test case 1
    on_response_1 = middleware_mixin_0.on_response(middleware="")



# Generated at 2022-06-26 03:38:48.702282
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()

    # Call method on_response of class MiddlewareMixin
    # Type warning
    middleware_mixin_0.on_response("response")



# Generated at 2022-06-26 03:38:51.298651
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    test_method_0 = middleware_mixin_0.on_request()
    assert callable(test_method_0)

# Generated at 2022-06-26 03:38:54.479897
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin = MiddlewareMixin()

    @middleware_mixin.on_request()
    def middleware_0(request):
        pass


# Generated at 2022-06-26 03:39:01.866653
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    ans_1_0 = middleware_mixin_0.on_response()
    assert ans_1_0 == partial(middleware_mixin_0.middleware, attach_to="response")
    ans_1_1 = middleware_mixin_0.on_response(func)
    assert ans_1_1 == middleware_mixin_0.middleware(func, attach_to="response")


# Generated at 2022-06-26 03:39:12.677185
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from unittest.mock import MagicMock
    from unittest.mock import Mock
    from unittest.mock import patch

    # Mock for decorator on_response of class MiddlewareMixin
    mock_on_response_0 = Mock(
        side_effect=lambda middleware=None: partial(
            MiddlewareMixin().middleware, attach_to="response"
        )
    )

    # Mocking call to MiddlewareMixin.middleware
    with patch(
        "sanic.models.middleware_mixin.MiddlewareMixin.middleware",
        new_callable=mock_on_response_0,
    ):

        # Call to on_response of class MiddlewareMixin
        middleware_mixin_0 = MiddlewareMixin()
        middleware_mixin_1 = middleware

# Generated at 2022-06-26 03:39:17.687393
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Precondition:
    # test-file-0.py -> test_case_0
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = None
    attach_to = 'request'
    apply = True
    middleware_mixin_0._apply_middleware = lambda middleware: middleware
    # Test
    middleware_mixin_0.middleware(
        middleware_or_request, attach_to=attach_to, apply=apply
    )


# Generated at 2022-06-26 03:39:21.762701
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    middleware = on_request = middleware_mixin_0.on_request()
    assert middleware is not None


# Generated at 2022-06-26 03:39:28.443593
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    @middleware_mixin_0.on_request()
    def request_middleware(request):
        return request


# Generated at 2022-06-26 03:39:30.416183
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()

    middleware_mixin_0.on_request()


# Generated at 2022-06-26 03:39:38.272829
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request_0 = 'middleware_or_request_0'
    attach_to_0 = 'attach_to_0'
    apply_0 = 'apply_0'
    # Call function middleware
    try:
        actual_returned_value_0 = middleware_mixin_0.middleware(middleware_or_request_0, attach_to_0, apply_0)
    except Exception as e:
        print('Caught exception from call to middleware:', e)



# Generated at 2022-06-26 03:39:40.964426
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():    
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = lambda request: None
    middleware_mixin_0.middleware(middleware_0, attach_to='request')


# Generated at 2022-06-26 03:39:48.199838
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    args_0 = MiddlewareMixin()
    middleware_or_request_0 = False
    attach_to_0 = "request"
    apply_0 = False
    # Call the method
    # The try except block is used to catch the Exception raised by the method
    try:
        args_0.middleware(middleware_or_request_0, attach_to_0, apply_0)
    except Exception as e:
        # If an exception is raised, fail the test.
        assert False


# Generated at 2022-06-26 03:39:51.848274
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    ret_val_1 = middleware_mixin_0.middleware
    ret_val_2 = middleware_mixin_0.on_request()
    ret_val_3 = middleware_mixin_0.on_request(5)
    # return ret_val_3


# Generated at 2022-06-26 03:40:01.845844
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_3 = MiddlewareMixin()
    call_vars = {}
    middleware_0 = lambda *args, **kwargs: call_vars.__setitem__('args', args) and call_vars.__setitem__('kwargs', kwargs)
    middleware_1 = lambda *args, **kwargs: call_vars.__setitem__('args', args) and call_vars.__setitem__('kwargs', kwargs)
    middleware_2 = lambda *args, **kwargs: call_vars.__setitem__('args', args) and call_vars.__setitem

# Generated at 2022-06-26 03:40:05.418128
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_request(lambda x: None)


# Generated at 2022-06-26 03:40:08.237102
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    func = NoSignature(0)
    middleware_mixin_0.on_request(func)


# Generated at 2022-06-26 03:40:16.554056
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Test positive case
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_request(middleware=None)

    # Test negative case
    # Test upper bound
    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_2.on_request(middleware=2**64)
    # Test lower bound
    middleware_mixin_3 = MiddlewareMixin()
    middleware_mixin_3.on_request(middleware=-(2**64))

    # Test special case
    middleware_mixin_4 = MiddlewareMixin()
    middleware_mixin_4.on_request(middleware=None)


# Generated at 2022-06-26 03:40:22.539809
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = lambda request: request
    assert middleware_mixin_0.middleware(middleware_0) == middleware_0


# Generated at 2022-06-26 03:40:25.749639
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    # Init call
    # In call
    middleware_mixin_0.middleware()


# Generated at 2022-06-26 03:40:27.759783
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware("test_value_0")


# Generated at 2022-06-26 03:40:35.465307
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # call with correct parameters
    middleware = lambda request, response: None
    middleware_mixin_0.middleware(middleware_or_request=middleware)
    middleware_mixin_0.middleware(middleware_or_request=middleware, attach_to="request")
    middleware_mixin_0.middleware(middleware_or_request=middleware, apply=True)
    middleware_mixin_0.middleware(middleware_or_request=middleware, attach_to="request", apply=True)


# Generated at 2022-06-26 03:40:37.986663
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    def test_function_1():
        pass

    # Call method
    middleware_mixin_0.middleware(test_function_1)



# Generated at 2022-06-26 03:40:39.729855
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(lambda request: future_wrapper_0, "request")


# Generated at 2022-06-26 03:40:43.093989
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.request import Request

    def middleware_0(request: Request):
        from sanic.response import Response
        return Response()

    app_0 = Sanic()
    app_0.middleware(middleware_0, "response")



# Generated at 2022-06-26 03:40:50.095910
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware = MiddlewareMixin.middleware

    # Type hinting for middleware
    def middleware(middleware_or_request, attach_to="request", apply=True):
        ...

    assert middleware(middleware_or_request=middleware_or_request, attach_to=attach_to, apply=apply) is middleware
    pass


# Generated at 2022-06-26 03:40:53.839594
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    try:
        middleware_mixin_0.middleware()
    except NotImplementedError:
        pass

# Generated at 2022-06-26 03:41:03.236747
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    # target method: middleware
    # test method: middleware
    # parameters:
    #   middleware_or_request:
    #   attach_to:
    #   apply:
    #   self:
    # return type:
    middleware_mixin_0.middleware(middleware_or_request=lambda x: [][0], attach_to="response")


# Generated at 2022-06-26 03:41:14.816376
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    # Test for method middleware of class MiddlewareMixin
    # Test for method middleware of class MiddlewareMixin
    #Test when attach_to != 'request'
    @middleware_mixin_0.middleware('response')
    def middleware_0(request):
        print(request)

# Generated at 2022-06-26 03:41:18.873102
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = middleware_mixin_0.middleware
    middleware_0("request")
    middleware_0("response")
    middleware_0("response", apply = False)


# Generated at 2022-06-26 03:41:22.427426
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()
    middleware_mixin_0.middleware('request')
    middleware_mixin_0.middleware(callable, 'request')


# Generated at 2022-06-26 03:41:25.511175
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(middleware_or_request=-1, attach_to=-1, apply=-1)

# Generated at 2022-06-26 03:41:28.115452
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # add your code here, do not change and remove the next line
    pass


# Generated at 2022-06-26 03:41:35.668104
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0._future_middleware == []

    from sanic.response import json
    from sanic.views import CompositionView

    @middleware_mixin_0.middleware(attach_to="request")
    async def middleware(request):
        return json({})

    assert middleware_mixin_0._future_middleware[0].middleware == middleware
    assert middleware_mixin_0._future_middleware[0].attach_to == "request"



# Generated at 2022-06-26 03:41:37.475295
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()


# Generated at 2022-06-26 03:41:41.868278
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    with pytest.raises(NotImplementedError):
        middleware_mixin_0 = MiddlewareMixin()
        middleware_mixin_0.middleware(middleware_or_request=None)


# Generated at 2022-06-26 03:41:49.500011
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # TODO: move the test into file test_server.py
    from sanic.server import HttpProtocol
    from sanic.sanic import Sanic
    import uvloop

    def m0(request):
        pass

    def m1(request):
        pass

    app = Sanic()
    app.middleware(m0)
    app.middleware(m1)
    app.config.load_environment_vars()


    http_protocol = HttpProtocol(app, debug=app.debug)

    assert len(app._future_middleware) == 2



# Generated at 2022-06-26 03:41:53.971284
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware = lambda *args: 0
    attach_to = ""
    apply = True
    method_result_py__MiddlewareMixin_middleware_0 = middleware_mixin_0.middleware(
        middleware, attach_to, apply
    )
    return



# Generated at 2022-06-26 03:42:00.854273
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    def function_callback_0(request, attach_to='request'): # noqa
        pass

    middleware_mixin_0.middleware(function_callback_0, 'request')


# Generated at 2022-06-26 03:42:08.155584
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    def middleware_or_request_1(request_1):
        assert request_1
        return True
    attach_to_1 = "request"
    apply_1 = True
    ret = middleware_mixin_1.middleware(middleware_or_request_1, attach_to_1, apply_1)


# Generated at 2022-06-26 03:42:10.865608
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """
    Test method middleware of class MiddlewareMixin
    """
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = MiddlewareMixin()


# Generated at 2022-06-26 03:42:16.293726
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    def on_request_mw_0(request):
        """
        return a response
        :param request:
        :return:
        """
        return request

    def test_mw_0(request):
        """
        return a response
        :param request:
        :return:
        """
        return request

    middleware_mixin_0.on_request(on_request_mw_0)
    middleware_mixin_0.on_request(test_mw_0)



# Generated at 2022-06-26 03:42:19.790044
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = middleware_mixin_0.middleware
    # TODO: add parameters to test


# Generated at 2022-06-26 03:42:21.058143
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert True



# Generated at 2022-06-26 03:42:28.733656
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Arrange
    middleware_mixin_1 = MiddlewareMixin()

    def func_0():
        pass

    def register_middleware(func_0, attach_to_0=''):
        nonlocal apply_0
        apply_0 = True
        return func_0

    # Act
    middleware_mixin_1_middleware_return_value = middleware_mixin_1.middleware(
        func_0, attach_to='')

    # Assert
    assert apply_0 == True
    assert middleware_mixin_1_middleware_return_value == func_0


# Generated at 2022-06-26 03:42:40.039514
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()

    @middleware_mixin_1.middleware
    async def middleware_func_0():
        pass

    @middleware_mixin_1.middleware('request')
    async def middleware_func_1():
        pass

    @middleware_mixin_1.middleware('response')
    async def middleware_func_2():
        pass

    middleware_func_3 = middleware_mixin_1.middleware(middleware_func_0)
    middleware_func_4 = middleware_mixin_1.middleware('request', middleware_func_1)
    middleware_func_5 = middleware_mixin_1.middleware('response', middleware_func_2)



# Generated at 2022-06-26 03:42:43.795328
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    middleware = object()
    middleware_mixin.middleware(middleware)
    assert middleware_mixin._future_middleware[-1].middleware == middleware
    assert middleware_mixin._future_middleware[-1].attach_to == "request"


# Generated at 2022-06-26 03:42:51.904396
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m = MiddlewareMixin()

    # Test when middleware_or_request is callable
    fun_1 = lambda x: print("middleware_or_request is callable") # noqa: E731
    res_1 = m.middleware(fun_1, attach_to="request", apply=True)
    assert res_1 == fun_1

    # Test when middleware_or_request is not callable
    res_2 = m.middleware("request")
    assert res_2("not callable")("request", apply=True) == "not callable"

