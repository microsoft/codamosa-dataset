

# Generated at 2022-06-26 03:37:55.788756
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_1 = MiddlewareMixin()

    middleware_mixin_1.on_response(middleware = lambda a: None)
    middleware_mixin_1.on_response(middleware = lambda a,b: None)
    middleware_mixin_1.on_response(middleware = lambda a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z: None)
    middleware_mixin_1.on_response(middleware = lambda *args: None)
    middleware_mixin_1.on_response(middleware = lambda **kwargs: None)

# Generated at 2022-06-26 03:37:57.557998
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin = MiddlewareMixin()
    middleware = middleware_mixin.on_response()
    assert callable(middleware)

# Generated at 2022-06-26 03:38:08.777535
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()

    #
    # simple case of calling @middleware
    #
    @middleware_mixin_0.on_request
    async def middleware_on_request(request):
        return request

    assert middleware_mixin_0.on_request(middleware_on_request) == middleware_on_request
    assert middleware_mixin_0.on_request() == middleware_on_request
    assert middleware_mixin_0._future_middleware[0].middleware == middleware_on_request
    assert len(middleware_mixin_0._future_middleware) == 1
    assert middleware_mixin_0._future_middleware[0].middleware == middleware_on_request
    assert middleware_mixin_0._future_

# Generated at 2022-06-26 03:38:11.719421
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_response()

# Generated at 2022-06-26 03:38:13.305585
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()



# Generated at 2022-06-26 03:38:18.820220
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Test with callable
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_response(middleware = partial(
         test_case_0, 10
    ))
    # Test with non-callable
    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_2.on_response(middleware = True)


# Generated at 2022-06-26 03:38:21.226297
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    MiddlewareMixin()


# Generated at 2022-06-26 03:38:23.177179
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin = MiddlewareMixin()
    middleware_mixin.on_response("response")

# Generated at 2022-06-26 03:38:28.729498
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin = MiddlewareMixin()
    assert not middleware_mixin._future_middleware
    middleware_mixin.on_response()
    assert middleware_mixin._future_middleware

# Generated at 2022-06-26 03:38:37.246219
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_1 = MiddlewareMixin()
    partial_middleware_mixin_1 = partial(middleware_mixin_1.on_response, middleware="middleware")
    partial_middleware_mixin_2 = partial(middleware_mixin_1.on_response)
    partial_middleware_mixin_2(middleware="middleware")


# Generated at 2022-06-26 03:38:41.759196
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    def middleware_0(request, response):
        pass
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_0)
    middleware_mixin_0.middleware(middleware_0, "request")


# Generated at 2022-06-26 03:38:44.058856
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware()


# Generated at 2022-06-26 03:38:53.692090
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Test raises NotImplementedError
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = object()
    attach_to = 'request'
    apply = True
    try:
        middleware_mixin_0.middleware(middleware_or_request, attach_to)
    except NotImplementedError:
        pass
    # Test raises NotImplementedError
    middleware_mixin_1 = MiddlewareMixin()
    middleware_or_request = object()
    attach_to = 'response'
    apply = True
    try:
        middleware_mixin_1.middleware(middleware_or_request, attach_to)
    except NotImplementedError:
        pass
    # Test raises NotImplementedError

# Generated at 2022-06-26 03:38:56.620443
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()

    def m1(request):
        pass

    middleware_mixin_1.middleware(m1)


# Generated at 2022-06-26 03:38:59.999905
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0.middleware



# Generated at 2022-06-26 03:39:01.221685
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    test_MiddlewareMixin_middleware_0()


# Generated at 2022-06-26 03:39:02.739157
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert (
        MiddlewareMixin.middleware is MiddlewareMixin.middleware
    )



# Generated at 2022-06-26 03:39:13.722013
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def middleware_or_request(__middleware_or_request: str) -> str:
        return __middleware_or_request

    attach_to = "request"
    apply = True

    # __middleware_or_request is a positional-only parameter.
    # The value passed to __middleware_or_request should be passed as the
    # first argument of the decorated function
    middleware_mixin_0.middleware(middleware_or_request)(middleware_or_request)

    # attach_to is a keyword-only parameter.
    # The value passed to attach_to can be passed as the second argument or
    # using the keyword "attach_to"
    middleware_mixin_0.middleware(middleware_or_request,attach_to)

# Generated at 2022-06-26 03:39:14.588702
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware("response")

# Generated at 2022-06-26 03:39:25.343030
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.exceptions import ServiceUnavailable
    from sanic.response import text

    app = Sanic(__name__)

    @app.route("/")
    def handler(request):
        raise ServiceUnavailable("I'm a teapot")

    @app.exception(ServiceUnavailable)
    def handler_service_unavailable(request, exception):
        return text("I'm not a teapot")

    @app.middleware
    def middleware(request):
        print("Before request")

    @app.middleware("request")
    def request_middleware(request):
        print("Before request")

    @app.middleware("response")
    def response_middleware(request, response):
        print("After request")

    request, response = app.test_client

# Generated at 2022-06-26 03:39:30.871103
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def middleware_0(request, handler):
        return request
    middleware_mixin_0.middleware = middleware_0
    assert middleware_mixin_0.middleware is middleware_0


# Generated at 2022-06-26 03:39:35.757585
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0._future_middleware == []
    middleware_mixin_0.middleware(middleware_or_request=None, attach_to=None, apply=True)
    assert middleware_mixin_0._future_middleware != []


# Generated at 2022-06-26 03:39:40.700336
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = lambda x, y: (x, y)
    attach_to = "request"
    apply = True

    middleware_mixin_0.middleware(
        middleware_or_request, attach_to="request", apply=True
    )


# Generated at 2022-06-26 03:39:42.510063
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_Mixin_1 = MiddlewareMixin()
    middleware_Mixin_1.middleware(FutureMiddleware)

# Generated at 2022-06-26 03:39:45.732892
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    middleware_mixin.middleware()


# Generated at 2022-06-26 03:39:46.697755
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-26 03:39:52.766212
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Arrange 
    middleware_mixin_1 = MiddlewareMixin() # Class MiddlewareMixin
    middleware_or_request_1 = None # type: None
    attach_to_1 = "response" # type: str
    apply_1 = False # type: bool
    return_value_1 = partial(middleware_mixin_1.middleware, attach_to="response") # type: typing.Callable

    # Act
    actual_1 = middleware_mixin_1.middleware(middleware_or_request_1, attach_to_1, apply_1)

    # Assert
    assert actual_1 == return_value_1


# Generated at 2022-06-26 03:39:53.989359
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()


# Generated at 2022-06-26 03:39:56.802222
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    moc = MagicMock()
    middleware_mixin_0.middleware(moc)

# Generated at 2022-06-26 03:39:59.724921
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    attch_to_0 = "request"
    middleware_mixin_0.middleware(None, attch_to_0)


# Generated at 2022-06-26 03:40:10.737219
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    logger.info("Start testing middleware()...")

    def decorator(middleware):
        middleware.value = 'middleware_value'
        return middleware

    @decorator
    def new_middleware(request):
        pass

    # create an instance of MiddlewareMixin
    middleware_mixin = MiddlewareMixin()
    middleware_mixin.middleware(new_middleware)

    assert middleware_mixin._future_middleware[0].value == 'middleware_value'

    logger.info("test middleware()...[Pass]")

# Generated at 2022-06-26 03:40:13.669458
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware()
    middleware_mixin_1.middleware('')


# Generated at 2022-06-26 03:40:16.008696
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    _middleware_or_request = MiddlewareMixin()
    middleware_mixin_0.middleware(_middleware_or_request)


# Generated at 2022-06-26 03:40:19.331294
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    middleware_mixin.middleware(middleware_or_request = None, attach_to = None, apply = None)


# Generated at 2022-06-26 03:40:30.757037
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import unittest

    class TestMiddlewareMixin(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            pass

        def test_middleware_case_0(self):
            middleware_mixin_0 = MiddlewareMixin()
            callable_0 = callable
            middleware_or_request_0 = callable_0()
            apply_0 = True
            attach_to_0 = "request"
            register_middleware_ret_0 = middleware_mixin_0.middleware(
                middleware_or_request_0, attach_to=attach_to_0, apply=apply_0
            )

    suite = unittest.TestLoader().loadTestsFromTestCase(TestMiddlewareMixin)

# Generated at 2022-06-26 03:40:34.609136
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Create a MiddlewareMixin
    middleware_mixin_0 = MiddlewareMixin()

    # Call middleware
    middleware_mixin_0.middleware()
    middleware_mixin_0.middleware('request')
    middleware_mixin_0.middleware('response')


# Generated at 2022-06-26 03:40:37.342568
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request_0 = MiddlewareMixin()
    return middleware_mixin_0.middleware(middleware_or_request_0)

# Generated at 2022-06-26 03:40:42.910780
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    def attach_to_0():
        pass

    def middleware_0():
        pass

    middleware = middleware_mixin_0.middleware(
        middleware_0, attach_to=attach_to_0, apply=True
    )



# Generated at 2022-06-26 03:40:46.639293
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request=None)


# Generated at 2022-06-26 03:40:55.373510
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    test_middleware_or_request_1 = ('request')
    test_middleware_or_request_2 = ('response')
    test_attach_to_1 = ('request')
    test_attach_to_2 = ('response')
    test_apply_1 = True
    test_apply_2 = False
    middleware_mixin_1.middleware(test_middleware_or_request_1, test_attach_to_1, test_apply_1)
    middleware_mixin_1.middleware(test_middleware_or_request_2, test_attach_to_2, test_apply_2)


# Generated at 2022-06-26 03:41:07.927149
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    def register_middleware(middleware, attach_to="request"):
        nonlocal apply
        future_middleware = FutureMiddleware(middleware, attach_to)
        middleware_mixin_1._future_middleware.append(future_middleware)
        if apply:
            middleware_mixin_1._apply_middleware(future_middleware)
        return middleware
    middleware_mixin_1.middleware = register_middleware
    middleware_mixin_1.middleware(None, attach_to="request")


# Generated at 2022-06-26 03:41:10.572290
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    middleware = middleware_mixin.middleware(None)
    middleware(None)
    middleware = middleware_mixin.middleware(None, "middleware")
    middleware(None)


# Generated at 2022-06-26 03:41:17.256157
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0._future_middleware == []
    middleware_mixin_0.middleware('request')
    assert middleware_mixin_0._future_middleware == []
    middleware_mixin_0.middleware(middleware=None)
    assert middleware_mixin_0._future_middleware == []

# Generated at 2022-06-26 03:41:22.154706
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = 'response'
    attach_to = 'response'
    apply = True
    try:
        middleware_mixin_0.middleware(middleware_or_request, attach_to, apply)
    except NotImplementedError as e:
        pass # expected


# Generated at 2022-06-26 03:41:25.556008
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Try to call method middleware of class MiddlewareMixin
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware()



# Generated at 2022-06-26 03:41:31.496388
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request_0: str = 'middleware_or_request_0'
    attach_to_0: str = 'attach_to_0'
    apply_0: bool = True
    middleware_mixin_0.middleware(middleware_or_request_0, attach_to_0, apply_0)


# Generated at 2022-06-26 03:41:32.051882
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()


# Generated at 2022-06-26 03:41:36.573327
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    global middleware_mixin_1

    middleware_mixin_1 = MiddlewareMixin()

    middleware = middleware_mixin_1.middleware
    middleware()
    middleware(attach_to="request")
    middleware(apply=True)
    middleware(attach_to="request", apply=True)
    middleware(middleware_or_request="any_string")



# Generated at 2022-06-26 03:41:38.169181
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin._future_middleware is not None


# Generated at 2022-06-26 03:41:42.800457
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()
    middleware_mixin_0.on_request()
    middleware_mixin_0.on_response()

# Generated at 2022-06-26 03:41:57.339474
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def middleware_or_request_0():
        return 0
    middleware_mixin_0.middleware(middleware_or_request_0)


# Generated at 2022-06-26 03:42:02.758252
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # middleware
    middleware_mixin_0.middleware()


# Generated at 2022-06-26 03:42:11.206372
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # Call function MiddlewareMixin.middleware and check the result
    result_value_0 = middleware_mixin_0.middleware(True, "request")
    assert result_value_0 is not None
    assert result_value_0.__class__.__name__ == "partial"
    # Check the lenght of self._future_middleware
    assert len(middleware_mixin_0._future_middleware) == 0


# Generated at 2022-06-26 03:42:13.904151
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def ret_func_0():
        nonlocal middleware_mixin_0
        return middleware_mixin_0
    ret_func_0()


# Generated at 2022-06-26 03:42:20.317698
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    # Test case 1: MiddlewareMixin.middleware
    middleware_mixin_1.middleware(middleware_or_request=None, attach_to="request", apply=True)


# Generated at 2022-06-26 03:42:28.300205
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.exceptions import RouteExists
    from sanic import Sanic
    middleware_mixin_1 = MiddlewareMixin()

    @middleware_mixin_1.middleware
    async def middleware_0(request):
        pass

    assert isinstance(middleware_mixin_1._future_middleware[0], FutureMiddleware)

    @middleware_mixin_1.middleware("request")
    async def middleware_1(request):
        pass

    assert isinstance(middleware_mixin_1._future_middleware[0], FutureMiddleware)




# Generated at 2022-06-26 03:42:35.627511
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = None
    attach_to = None
    apply = None
    future_middleware = middleware_mixin_0.middleware(middleware_or_request, attach_to, apply)
    assert future_middleware is None
    assert middleware_mixin_0._future_middleware is not None



# Generated at 2022-06-26 03:42:41.048989
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Init test case env and data
    middleware_mixin_1 = MiddlewareMixin()
    middleware_2 = int
    attach_to_3 = "request"
    apply_4 = True
    # Call method middleware of class MiddlewareMixin, store returned result in middleware_5
    middleware_5 = middleware_mixin_1.middleware(
        middleware_2, attach_to=attach_to_3, apply=apply_4
    )


# Generated at 2022-06-26 03:42:51.474169
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    def middleware_0(request):
        pass

    def middleware_1():
        pass

    def middleware_2():
        pass

    # Type check based on PEP 484 type hints
    middleware_mixin_0.middleware(middleware_0)
    middleware_mixin_0.middleware(attach_to="response")(middleware_1)
    middleware_mixin_0.middleware(attach_to="request")(middleware_2)
    assert len(middleware_mixin_0._future_middleware) == 3
    assert middleware_mixin_0._future_middleware[0].middleware == middleware_0

# Generated at 2022-06-26 03:42:54.687515
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    future_middleware = MiddlewareMixin._MiddlewareMixin__future_middleware
    register_middleware = MiddlewareMixin._apply_middleware
    assert future_middleware == []
    assert register_middleware == []


# Generated at 2022-06-26 03:43:22.145629
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware = lambda request : request
    assert middleware_mixin_1.middleware(middleware) == middleware


# Generated at 2022-06-26 03:43:27.672013
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    # middleware_or_request = 'a'
    # attach_to = 'a'
    # apply = True
    result = middleware_mixin_1.middleware(middleware_or_request = 'a', attach_to = 'a', apply = True)
    # assert result is None


# Generated at 2022-06-26 03:43:34.020092
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic_openapi.api import spec

    api = Mock()
    middleware_mixin_1 = MiddlewareMixin()
    @middleware_mixin_1.middleware
    async def middleware(request):
        return True
    @middleware_mixin_1.middleware
    async def middleware(request):
        return True
    middleware_mixin_1.middleware
    middleware_mixin_1.middleware
    middleware_mixin_1.middleware
    middleware_mixin_1.middleware = middleware_mixin_1.middleware

    @middleware_mixin_1.middleware()
    async def middleware(request):
        return True


# Generated at 2022-06-26 03:43:40.713174
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = callable
    attach_to_0 = "request"
    test_0 = middleware_mixin_0.middleware(middleware_0, attach_to_0)


# Generated at 2022-06-26 03:43:45.352928
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def middleware_0():
        pass
    def middleware_1():
        pass
    def middleware_2():
        pass
    middleware_mixin_0.middleware(middleware_0)
    middleware_mixin_0.middleware(middleware_1, attach_to='request')
    middleware_mixin_0.middleware(middleware_2, attach_to='response')


# Generated at 2022-06-26 03:43:53.303040
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_middleware_1 = middleware_mixin_1.middleware
    mid_1 = middleware_middleware_1(attach_to="request")
    mid_2 = middleware_middleware_1(attach_to="response")
    assert middleware_mixin_1
    assert middleware_middleware_1
    assert mid_1
    assert mid_2



# Generated at 2022-06-26 03:43:56.839391
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    try:
        middleware_mixin_0 = MiddlewareMixin()
        # Test for user-specified test 0
        assert False

    except NotImplementedError:
        pass


if __name__ == "__main__":
    test_case_0()
    test_MiddlewareMixin_middleware()

# Generated at 2022-06-26 03:44:03.892122
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Create an instance of MiddlewareMixin
    middleware_mixin_0 = MiddlewareMixin()
    
    # Create an instance of function 'middleware'
    def middleware(request):
        return request

    # Call method 'middleware' of MiddlewareMixin instance middleware_mixin_0
    middleware_mixin_0.middleware(middleware)


# Generated at 2022-06-26 03:44:10.287469
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    @middleware_mixin_1.middleware
    def middleware(request):

        @middleware_mixin_1.middleware
        def middleware_0(request_0):
            return request_0
        @middleware_mixin_1.middleware('request')
        def middleware_1(request_1):

            @middleware_mixin_1.middleware
            def middleware_2(request_2):
                return request_2
            return request_1
        @middleware_mixin_1.middleware('response')
        def middleware_3(request_3):

            @middleware_mixin_1.middleware('response')
            def middleware_4(request_4):
                return request_4
            return request_3

# Generated at 2022-06-26 03:44:13.352745
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    callable_0 = lambda: None
    assert middleware_mixin_0.middleware(callable_0) is callable_0

# Generated at 2022-06-26 03:44:49.410218
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Input Parameters
    middleware_or_request = None
    attach_to = "request"
    apply = True

    # Expected Result
    expected_result = None

    # Test
    result = MiddlewareMixin.middleware(
        middleware_or_request, attach_to=attach_to, apply=apply
    )

    # Compare Results
    # assert result == expected_result


# Generated at 2022-06-26 03:44:51.871600
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(attach_to='request')


# Generated at 2022-06-26 03:45:00.695906
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # Test method middleware for case when attach_to = request
    middleware_mixin_0.middleware(middleware_or_request='request')
    # Test method middleware for case when attach_to = response
    middleware_mixin_0.middleware(middleware_or_request='response')
    # Test method middleware for case when apply = False
    middleware_mixin_0.middleware(middleware_or_request=None, apply=False)

# Generated at 2022-06-26 03:45:10.492312
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Setup
    middleware_mixin_0 = MiddlewareMixin()

    # Testing if TypeError raised when 'middleware_or_request' is of wrong type
    with pytest.raises(TypeError) as excinfo:
        middleware_mixin_0.middleware('s')
        assert "Parameter 'middleware_or_request' expects type 'Callable[[Tuple[Request, Awaitable]], Awaitable]'; got <class 'str'>" in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        middleware_mixin_0.middleware(1.0)

# Generated at 2022-06-26 03:45:13.420943
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    assert middleware_mixin_1.middleware is not None
    assert middleware_mixin_1.middleware is not None
    assert middleware_mixin_1.middleware is not None


# Generated at 2022-06-26 03:45:24.008033
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    register_middleware_1 = middleware_mixin_1.middleware
    # Test for function middleware() with parameter middleware_or_request not callable
    class register_middleware_1_middleware:
        def __call__(self, request):
            pass
    register_middleware_1_middleware_1 = register_middleware_1_middleware()
    # Type hint for middleware_or_request
    register_middleware_1(register_middleware_1_middleware_1, 'request')
    # Test for function middleware() with parameter attach_to missing
    # Type hint for attach_to
    register_middleware_1(register_middleware_1_middleware_1)
    # Test for function middleware() with parameter apply missing


# Generated at 2022-06-26 03:45:28.262684
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_1 = lambda x: 2 * x
    attach_to_1 = "request"
    apply_1 = True
    middleware_mixin_1.middleware(middleware_1, attach_to_1, apply_1)
    assert middleware_mixin_1._future_middleware[0].attach_to == attach_to_1


# Generated at 2022-06-26 03:45:40.745695
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_1 = lambda: None
    attach_to_0 = middleware_mixin_0.middleware(middleware_1)
    attach_to_1 = middleware_mixin_0.middleware(middleware_1, "request")
    attach_to_2 = middleware_mixin_0.middleware(middleware_1, "response")
    # assert middleware_mixin_0._future_middleware  == [FutureMiddleware(middleware_1, "request"), FutureMiddleware(middleware_1, "request"), FutureMiddleware(middleware_1, "response")]
    # assert attach_to_0 == <function no_title_0 at 0x7fe1791d2e18>
    # assert attach_to_1 == <function

# Generated at 2022-06-26 03:45:43.389120
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = on_request(middleware_mixin_0)
    attach_to = "request"
    apply = True
    middleware_mixin_0.middleware(middleware_or_request, attach_to, apply)
    test_case_0()


# Generated at 2022-06-26 03:45:46.585816
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()

    middleware_mixin_1.middleware()
    middleware_mixin_1.middleware('request')
