

# Generated at 2022-06-26 03:37:55.197734
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_1 = MiddlewareMixin()
    partial_callable_0 = partial(middleware_mixin_1.middleware, attach_to="response")
    assert callable(partial_callable_0)


# Generated at 2022-06-26 03:37:57.058055
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()

    middleware_mixin_0.on_response(middleware = None)


# Generated at 2022-06-26 03:38:02.170727
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    # val: Callable[['RequestParameters'], Awaitable['HTTPResponse']]
    def on_request_mock(request: RequestParameters) -> Awaitable['HTTPResponse']:
        return request
    # val: Callable[[], Awaitable['HTTPResponse']]
    callable_1 = middleware_mixin_1.on_request(on_request_mock)


# Generated at 2022-06-26 03:38:04.260724
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()


# Generated at 2022-06-26 03:38:11.225260
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    def the_middleware():
        print("Hello!")

    middleware_mixin_0.on_request(the_middleware)
    assert middleware_mixin_0._future_middleware[0].middleware == the_middleware
    assert middleware_mixin_0._future_middleware[0].attach_to == "request"


# Generated at 2022-06-26 03:38:13.518559
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_response(middleware=middleware)

# Generated at 2022-06-26 03:38:16.386489
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Testing with default arguments
    default_middleware = MiddlewareMixin()

    response = default_middleware.on_request()
    assert callable(response)


# Generated at 2022-06-26 03:38:18.386417
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_on_response = MiddlewareMixin()
    middleware_mixin_on_response.on_response()



# Generated at 2022-06-26 03:38:27.429167
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_var_0 = MiddlewareMixin()
    middleware_mixin_var_1 = MiddlewareMixin()
    partial_var_0 = middleware_mixin_var_1.on_response()
    # Function to call: partial
    # Number of arguments: 1
    # Argument 0 (positional): <sanic.models.futures.MiddlewareMixin object at 0x7f038f085700>

    # Pass
    assert partial_var_0 is not None


# Generated at 2022-06-26 03:38:34.017796
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware("request_0")
    middleware_mixin_1.middleware("request_0")(lambda: None)
    middleware_mixin_1.middleware("request_0")(lambda: None)
    middleware_mixin_1.middleware("response_0")
    middleware_mixin_1.middleware("response_0")(lambda: None)
    middleware_mixin_1.middleware(lambda: None)
    middleware_mixin_1.middleware(lambda: None)("response_0")


# Generated at 2022-06-26 03:38:49.830216
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()

    @middleware_mixin_1.middleware('response')
    def middleware_1(request):
        return request
    @middleware_mixin_1.middleware('response')
    def middleware_2(request):
        return request
    @middleware_mixin_1.middleware('response')
    def middleware_3(request):
        return request

    @middleware_mixin_1.middleware('request')
    def middleware_4(request):
        return request
    @middleware_mixin_1.middleware('request')
    def middleware_5(request):
        return request
    @middleware_mixin_1.middleware('request')
    def middleware_6(request):
        return request


# Unit test

# Generated at 2022-06-26 03:38:54.086399
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Given
    middleware_mixin_0 = MiddlewareMixin()

    # When
    middleware_0 = middleware_mixin_0.on_response()

    # Then
    assert callable(middleware_0)

    # Given
    middleware_mixin_1 = MiddlewareMixin()

    # When
    middleware_1 = middleware_mixin_1.on_response(middleware=lambda request: request)

    # Then
    assert callable(middleware_1)


# Generated at 2022-06-26 03:39:03.431805
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Initialize the class object MiddlewareMixin
    middleware_mixin_object = MiddlewareMixin()
    # Initialize the global variable
    partial_middleware = partial(middleware_mixin_object.middleware, attach_to="request")
    # Call the method on_response of class MiddlewareMixin
    middleware_mixin_object.on_response(partial_middleware)
    # Check the size of future middleware list
    assert len(middleware_mixin_object._future_middleware) == 1
    # Check the attach_to parameter
    assert middleware_mixin_object._future_middleware[0].attach_to == "response"


# Generated at 2022-06-26 03:39:08.749446
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    method_1 = partial(MiddlewareMixin.on_response, attach_to=None)
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_response = method_1
    middleware_mixin_1.on_response()


# Generated at 2022-06-26 03:39:16.165047
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()

    def OnResponseFunc():
        pass

    expect_result_0 = partial(middleware_mixin_0.middleware, attach_to="response")

    actual_result_0 = middleware_mixin_0.on_response()

    assert expect_result_0 == actual_result_0

    middleware_mixin_1 = MiddlewareMixin()

    expect_result_1 = OnResponseFunc

    actual_result_1 = middleware_mixin_1.on_response(OnResponseFunc)

    assert expect_result_1 == actual_result_1



# Generated at 2022-06-26 03:39:18.023264
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # assert isinstance(middleware_mixin.on_response(), partial)
    pass


# Generated at 2022-06-26 03:39:29.605112
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Create an instance of the class
    middleware_mixin_1 = MiddlewareMixin()
    # Create an instance of the class
    middleware_mixin_2 = MiddlewareMixin()
    # Create an instance of the class
    middleware_mixin_3 = MiddlewareMixin()

    # Test the method
    middleware_mixin_1.on_response(middleware=middleware_mixin_2)
    middleware_mixin_1.on_response(middleware=middleware_mixin_2)
    middleware_mixin_1.on_response(middleware=middleware_mixin_3)

    # Test the method
    middleware_mixin_2.on_response(middleware=middleware_mixin_1)

# Generated at 2022-06-26 03:39:31.887722
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0.on_response() is not None

# Generated at 2022-06-26 03:39:33.915945
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    _ = middleware_mixin_0.on_response()


# Generated at 2022-06-26 03:39:41.245335
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    class A:
        def __init__(self, middleware_mixin_0):
            self.middleware_mixin_0 = middleware_mixin_0
        def __call__(self, *args, **kwargs):
            return self.middleware_mixin_0.on_request(lambda request: None, attach_to="response")
    a = A(middleware_mixin_0)
    assert a() == partial(middleware_mixin_0.middleware, attach_to="response")


# Generated at 2022-06-26 03:39:51.212962
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request=None, attach_to='request', apply=True)
    middleware_mixin_0.middleware(middleware_or_request=None, attach_to='request', apply=False)
    middleware_mixin_0.middleware(middleware_or_request='request', attach_to='request', apply=True)
    middleware_mixin_0.middleware(middleware_or_request='request', attach_to='request', apply=False)


# Generated at 2022-06-26 03:39:53.423251
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_1 = middleware_mixin_0.middleware
    assert middleware_1 is not None


# Generated at 2022-06-26 03:39:56.900701
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # It's a function, but there's no good solution to test its functionality.
    out0 = middleware_mixin_0.middleware("request")
    assert out0


# Generated at 2022-06-26 03:40:00.564371
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_function_0 = (lambda x: 0)
    middleware_mixin_0.middleware(middleware_function_0)
    return middleware_function_0


# Generated at 2022-06-26 03:40:12.596287
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Define a mock object to track calls to the object method under test
    class Mock_object:
        __init__ = "Mock_object.__init__"
        _apply_middleware = "Mock_object._apply_middleware"
        _future_middleware = "Mock_object._future_middleware"

        def __init__(self):
            self.__init__ = MagicMock()

        def _apply_middleware(self, arg):
            self._apply_middleware = MagicMock()
            self._apply_middleware.arg = arg

        def _future_middleware(self):
            return self._future_middleware

    # Create an instance of the mocked object
    mock_obj = Mock_object()
    # Create instance of class under test
    middleware_mixin = MiddlewareMixin()



# Generated at 2022-06-26 03:40:14.975844
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """
    Test case for method middleware of class MiddlewareMixin.
    """
    middleware_mixin_0 = MiddlewareMixin()
    test_value = middleware_mixin_0.middleware(0)


# Generated at 2022-06-26 03:40:17.624727
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1._apply_middleware(FutureMiddleware)
    middleware_mixin_1.middleware(FutureMiddleware, "request")
    middleware_mixin_1.middleware()


# Generated at 2022-06-26 03:40:20.207782
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_function_0 = lambda request, response: response
    middleware_mixin_0.middleware(middleware_function_0)


# Generated at 2022-06-26 03:40:23.128664
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    # body of method middleware
    middleware_mixin_1.middleware()


# Generated at 2022-06-26 03:40:25.259151
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()



# Generated at 2022-06-26 03:40:31.513151
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    result_middleware_mixin_0 = middleware_mixin_0.middleware("request")
    assert result_middleware_mixin_0 is not None



# Generated at 2022-06-26 03:40:34.684149
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.model.common import Middleware

    middleware_mixin_1 = MiddlewareMixin()
    middleware_0 = Middleware()
    middleware_mixin_1.middleware(middleware_0)


# Generated at 2022-06-26 03:40:35.322603
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()

# Generated at 2022-06-26 03:40:42.083888
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.middleware import Middleware

    app = MiddlewareMixin()
    foo_middleware = Middleware(lambda req, res: None)

    app.middleware(foo_middleware)

    assert isinstance(app._future_middleware[0].middleware, Middleware)



# Generated at 2022-06-26 03:40:45.801329
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    def middleware_func(request):
        pass

    middleware_mixin.middleware(middleware_func)

# Generated at 2022-06-26 03:40:55.623693
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Case 1
    middleware_mixin_1 = MiddlewareMixin()
    middleware_or_request_1 = object()
    attach_to_1 = object()
    apply_1 = object()
    try:
        middleware_mixin_1.middleware(middleware_or_request_1, attach_to_1, apply_1)
    except NotImplementedError:
        pass
    except Exception as e:
        raise e
    else:
        assert False
    # Case 2
    middleware_mixin_2 = MiddlewareMixin()
    middleware_or_request_2 = object()
    attach_to_2 = object()

# Generated at 2022-06-26 03:41:02.281879
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0 is not None
    def middleware_0(request):
        return None
    register_middleware_0 = middleware_mixin_0.middleware(middleware_0)
    assert register_middleware_0 is not None
    return


# Generated at 2022-06-26 03:41:07.926601
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware = lambda middleware_or_request: None
    attach_to = "request"
    future_middleware = FutureMiddleware(middleware, attach_to)
    register_middleware_result = middleware_mixin_1.middleware(
        middleware, attach_to="request"
    )
    # TODO assert future_middleware == middleware_mixin_1._future_middleware[0]
    assert future_middleware == register_middleware_result


# Generated at 2022-06-26 03:41:09.974089
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    ret_val = middleware_mixin_1.middleware()  # type: ignore
    assert callable(ret_val)


# Generated at 2022-06-26 03:41:12.672223
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Init
    middleware_mixin = MiddlewareMixin()
    middleware = lambda x, y: x + y
    attach_to = 'request'

    # Act
    result = middleware_mixin.middleware(middleware, attach_to)


# Generated at 2022-06-26 03:41:28.531393
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    test_arg_0 = {}
    # Default argument
    test_arg_1 = 'request'
    test_arg_0.update({'middleware_or_request': test_arg_1})

    # Default argument
    test_arg_2 = True
    test_arg_0.update({'apply': test_arg_2})
    # Default argument
    test_arg_1 = 'request'
    test_arg_0.update({'attach_to': test_arg_1})
    def test_func_0(request, *args):
        return request

    assert middleware_mixin_0.middleware.__func__ is MiddlewareMixin.middleware

    # Test with arg
    # Function middleware calls middleware
    # Callable middleware_

# Generated at 2022-06-26 03:41:37.788867
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # Source: sanic\models\middleware.py:25
    # 1. isinstance(middleware, FutureMiddleware)
    # 2. attach_to == request
    # 3. self._future_middleware.append(middleware_or_request)
    middleware_mixin_0.middleware(attach_to="request")
    # 1. isinstance(middleware, FutureMiddleware)
    # 2. attach_to == response
    # 3. self._future_middleware.append(middleware_or_request)
    middleware_mixin_0.middleware(attach_to="response")
    # Source: sanic\models\middleware.py:37
    # 1. callable(middleware_or_request)
    # 2. attach_to

# Generated at 2022-06-26 03:41:48.968786
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    def func_0(value, request):
        return request

    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_3 = MiddlewareMixin()

    middleware_mixin_1._apply_middleware = lambda _: 42
    middleware_mixin_2._apply_middleware = lambda middleware: middleware_mixin_1.middleware(middleware)
    middleware_mixin_3._apply_middleware = lambda middleware: middleware_mixin_1.middleware(middleware)
    middleware_mixin_3._apply_middleware(func_0)

    def func_1(value, request):
        return request

    middleware_mix

# Generated at 2022-06-26 03:41:55.358850
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

# Generated at 2022-06-26 03:41:56.177764
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-26 03:42:01.642072
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    _mock_middleware_1 = mock.Mock(name="middleware_1")
    _mock_middleware_1.__name__ = "middleware_1"
    _mock_attach_to_1 = "request"
    _mock_apply_1 = True
    middleware_mixin_1._apply_middleware = mock.Mock(name="_apply_middleware")
    mock_func_1 = middleware_mixin_1.middleware(_mock_middleware_1, _mock_attach_to_1, _mock_apply_1)

# Generated at 2022-06-26 03:42:06.972609
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    register_middleware_0 = middleware_mixin_0.middleware("request")
    assert callable(register_middleware_0)


# Generated at 2022-06-26 03:42:15.478107
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Hello:
        def __init__(self):
            print('hello')
    class Sanic:
        def __init__(self):
            print('sanic')
    class MyTest(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self._future_middleware = []
            print('__init__')
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    my_test_0 = MyTest()
    f = my_test_0.middleware(Hello, attach_to='request')
    f()
    f = my_test_0.on_request(Sanic)
    f()
    f = my_test_0.on_response()
    print(f)

# Unit test

# Generated at 2022-06-26 03:42:17.457659
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = lambda request: None

    # Test if this call returns without exception
    middleware_mixin_0.middleware(middleware_0, "request")



# Generated at 2022-06-26 03:42:21.844998
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    a_MiddlewareMixin = MiddlewareMixin()
    a_MiddlewareMixin.middleware()
    # assert True  # TODO: implement your test here


# Generated at 2022-06-26 03:42:35.857115
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert True


# Generated at 2022-06-26 03:42:37.776632
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware=123)

# Generated at 2022-06-26 03:42:38.618817
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-26 03:42:41.153032
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(middleware_or_request = "middleware_or_request_1", attach_to = "attach_to_1", apply = True)


# Generated at 2022-06-26 03:42:41.618164
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert 1

# Generated at 2022-06-26 03:42:52.206078
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    def register_middleware(middleware, attach_to="request"):
        nonlocal apply

        future_middleware = FutureMiddleware(middleware, attach_to)
        assert future_middleware != None
        assert future_middleware != ""
        assert future_middleware == FutureMiddleware(middleware, attach_to)
    def callable(middleware_or_request):
        return middleware_or_request
    def partial(register_middleware, attach_to = "request"):
        return attach_to
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware = register_middleware
    middleware_mixin_1.middleware(callable)
    middleware_mixin_1.middleware.func = callable
    middleware_mixin_1.middle

# Generated at 2022-06-26 03:42:54.467935
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    # Object initialization
    middleware_mixin_1 = MiddlewareMixin()

    # method middleware of class MiddlewareMixin
    middleware_mixin_1.middleware("request", "request", True)

# Generated at 2022-06-26 03:43:03.273221
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.models.request import RequestParameters

    # ------------ Prepare environment ------------
    app = Sanic(__name__)

    # ------------ Prepare data ------------
    middleware1 = app.middleware

    # ------------ Run test ------------
    ret_middleware1 = middleware1(RequestParameters)

    # ------------ Prepare data ------------
    middleware2 = app.middleware(RequestParameters)

    # ------------ Run test ------------
    ret_middleware2 = middleware2

    # ------------ Compare result ------------
    assert ret_middleware1 is not None
    assert ret_middleware2 is not None



# Generated at 2022-06-26 03:43:07.841409
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_func_0 = lambda request: response

    future_middleware_0 = middleware_mixin_0.middleware(
        middleware_func_0, attach_to='request'
    )


# Generated at 2022-06-26 03:43:09.070402
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()


# Generated at 2022-06-26 03:43:33.578296
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request: int = 5
    # Type error
    # middleware_mixin_0.middleware(middleware_or_request)


# Generated at 2022-06-26 03:43:42.380951
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    def middleware_0(middleware_or_request, attach_to: str, apply: bool) -> FutureMiddleware:
        assert (isinstance(middleware_or_request, FutureMiddleware))
        assert (isinstance(attach_to, str))
        assert (apply)
        return middleware_0

    middleware_mixin_0.middleware(middleware_0(middleware_mixin_0, 'AT', True))


# Generated at 2022-06-26 03:43:44.644734
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request="request", attach_to=None, apply=True)


# Generated at 2022-06-26 03:43:45.678657
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()


# Generated at 2022-06-26 03:43:53.071981
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_request((lambda request: (yield from (lambda request: (yield from (lambda request: (yield from None))))(request))(request)), (lambda request: (yield from (lambda request: (yield from (lambda request: (yield from None))))(request))(request)))



# Generated at 2022-06-26 03:44:04.347945
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    test_param_0 = dmy_middleware_0

    def test_param_1(request):
        return request

    # Set up test data
    expected_return_value_0 = dmy_middleware_0
    expected_middleware_0 = FutureMiddleware(
        dmy_middleware_0, attach_to="request"
    )
    expected_middleware_1 = FutureMiddleware(
        test_param_1, attach_to="request"
    )

    # Perform the test
    actual_return_value_0 = middleware_mixin_1.middleware(
        test_param_0, apply=False
    )
    actual_middleware_0 = middleware_mixin_1._future_middleware[0]
    actual_

# Generated at 2022-06-26 03:44:08.082515
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = lambda x: x
    attach_to_0 = "request"
    register_middleware_0 = middleware_mixin_0.middleware(middleware_0, attach_to_0)
    result = callable(register_middleware_0)
    assert result is True


# Generated at 2022-06-26 03:44:10.638193
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()


# Generated at 2022-06-26 03:44:13.319225
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    middleware_mixin_0.middleware(middleware_or_request=middleware_mixin_0)

# Generated at 2022-06-26 03:44:17.237718
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(lambda x: x, attach_to="request")
    middleware_mixin_0.middleware(None)


# Generated at 2022-06-26 03:45:07.823016
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    import sanic.response

    def example(request):
        return sanic.response.text("Hello World")

    middleware = MiddlewareMixin()
    # Testing the template defined above with actual parameters
    middleware.middleware(example)
    middleware.on_request(example)
    middleware.on_response(example)

# Generated at 2022-06-26 03:45:11.331230
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    obj0 = MiddlewareMixin()
    obj0._apply_middleware = lambda x: None
    def func0():
        return None
    var0 = obj0.middleware(func0)
    assert obj0._future_middleware == [FutureMiddleware(func0, 'request')]


# Generated at 2022-06-26 03:45:16.661407
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # Call method middleware of class MiddlewareMixin
    middleware_mixin_0.middleware(middleware_or_request='middleware_or_request', attach_to='attach_to', apply=False)
    # AssertionError: NotImplementedError


# Generated at 2022-06-26 03:45:18.696023
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    partial_0 = middleware_mixin_0.middleware
    partial_0('AT')


# Generated at 2022-06-26 03:45:27.471492
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # set up test data
    middleware_mixin_0 = MiddlewareMixin()

    # call method middleware of class MiddlewareMixin
    @middleware_mixin_0.middleware()
    def func_1(request, *args, **kwargs):
        return request

    @middleware_mixin_0.middleware('request')
    def func_2(request, *args, **kwargs):
        return request

    @middleware_mixin_0.on_request()
    def func_3(request, *args, **kwargs):
        return request

    @middleware_mixin_0.on_response()
    def func_4(request, *args, **kwargs):
        return request


test_case_0()
test_MiddlewareMixin_middleware()

# Generated at 2022-06-26 03:45:35.209062
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = None
    attach_to_0 = "request"
    apply_0 = True

    # Test 1: Run without parameters
    middleware_mixin_0.middleware(middleware_0, attach_to_0, apply_0)



# Generated at 2022-06-26 03:45:42.533853
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(None) # should not throw exception
    middleware_mixin_0.middleware(None, "request") # should not throw exception
    middleware_mixin_0.middleware(None, "response") # should not throw exception

    middleware_mixin_0.middleware(lambda: None) # should not throw exception
    middleware_mixin_0.middleware(lambda: None, "request") # should not throw exception
    middleware_mixin_0.middleware(lambda: None, "response") # should not throw exception

    #TODO: assert it actually worked properly


# Generated at 2022-06-26 03:45:44.609956
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    function_0 = middleware_mixin_0.middleware(function_0)


# Generated at 2022-06-26 03:45:47.323769
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    #  uncomment following line to verify the reported issue
    middleware_mixin.middleware(None)

# Generated at 2022-06-26 03:45:50.447562
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_mixin_0._apply_middleware, MiddlewareMixin, "response")
