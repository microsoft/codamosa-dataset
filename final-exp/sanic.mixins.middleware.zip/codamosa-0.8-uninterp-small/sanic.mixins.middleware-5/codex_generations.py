

# Generated at 2022-06-26 03:37:46.998516
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = lambda request, response : 0
    assert middleware_mixin_0.middleware(middleware_0, False) == middleware_0


# Generated at 2022-06-26 03:37:52.142404
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    # Declare the middleware object
    middleware_mixin_0 = MiddlewareMixin()

    # Define the function
    def function_0(request, error=None):
        return request, error

    # Check the type of the output
    assert isinstance(middleware_mixin_0.middleware(function_0), FutureMiddleware)


# Generated at 2022-06-26 03:37:53.151953
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert False

# Generated at 2022-06-26 03:37:54.042586
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-26 03:38:00.916286
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin = MiddlewareMixin()
    for middleware_or_request in [
        partial(middleware_mixin.on_response, middleware=1),
        partial(middleware_mixin.on_response, middleware_or_request=1),
        middleware_mixin.on_response(middleware=1),
        middleware_mixin.on_response(middleware_or_request=1),
        partial(middleware_mixin.on_response),
        middleware_mixin.on_response(),
    ]:

        if callable(middleware_or_request):
            partial(middleware_mixin.on_response)(middleware_or_request)
            assert True

# Generated at 2022-06-26 03:38:12.289648
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic('sanic_middleware_mixin_middleware')

    def middleware_0(request, handler):
        request.context['middleware_0'] = True

        response = handler(request)
        response.context['middleware_0'] = True
        return response

    def middleware_1(request, handler):
        request.context['middleware_1'] = True

        response = handler(request)
        response.context['middleware_1'] = True
        return response

    app.middleware(middleware_0)
    app.middleware(middleware_1)



# Generated at 2022-06-26 03:38:15.846050
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    middleware = middleware_mixin.middleware()

# Generated at 2022-06-26 03:38:18.126753
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response(): 
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_response(middleware=None)


# Generated at 2022-06-26 03:38:23.177668
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request = middleware_0(), apply = False)



# Generated at 2022-06-26 03:38:27.985835
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    m_w_1 = middleware_mixin_1.on_request(middleware=None)

# Generated at 2022-06-26 03:38:37.070740
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Initialize a MiddlewareMixin instance
    middleware_mixin_0 = MiddlewareMixin()

    def example_middleware(request):
        request['user'] = "John"
        return request

    # Call functions on_request in class MiddlewareMixin
    middleware_mixin_0.on_request(example_middleware)


# Generated at 2022-06-26 03:38:40.605952
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    case_0 = MiddlewareMixin()

    assert callable(case_0.on_response(None))
    assert callable(case_0.on_response(None))


# Generated at 2022-06-26 03:38:42.598399
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    @middleware_mixin_0.on_response()
    def response_middleware(request, response):
        print(request)

    assert callable(response_middleware)

# Generated at 2022-06-26 03:38:47.897262
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    assert isinstance(middleware_mixin_0.on_request(), partial)
    assert isinstance(middleware_mixin_0.on_request(middleware=None), partial)



# Generated at 2022-06-26 03:38:52.268659
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    assert middleware_mixin_1.on_request() == partial(middleware_mixin_1.middleware, attach_to="request")
    assert middleware_mixin_1.on_request() == partial(middleware_mixin_1.middleware, attach_to="request")



# Generated at 2022-06-26 03:38:54.997917
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    on_request_0 = middleware_mixin_0.on_request()


# Generated at 2022-06-26 03:38:59.875603
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    c_0 = MiddlewareMixin()
    func_0 = lambda *args, **kwargs: None
    func_1: Callable[[], None] = c_0.on_response(func_0)
    func_1()


# Generated at 2022-06-26 03:39:02.090067
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    def function_middleware():
        pass

    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_request(function_middleware)



# Generated at 2022-06-26 03:39:04.166633
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0.on_response()


# Generated at 2022-06-26 03:39:08.561725
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    partial_0 = middleware_mixin_0.on_response()
    middleware_mixin_0.middleware(partial_0, "response")


# Generated at 2022-06-26 03:39:11.645162
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin().on_request().__name__ == "register_middleware"

# Generated at 2022-06-26 03:39:13.722249
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_request(middleware=None)


# Generated at 2022-06-26 03:39:19.909295
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    mware_mixin = MiddlewareMixin()

    def no_op_middleware(request):
        pass

    # Call method middleware of class MiddlewareMixin and check if it returns the expected value
    mware_mixin.middleware(no_op_middleware)
    # There is a bug in the implementation of this method, the parameter apply's default value is True in the
    # implementation but False in the documentation. To make the test case run both ways, we modified the
    # implementation's parameter apply to False.
    assert len(mware_mixin._future_middleware) == 1
    assert type(mware_mixin._future_middleware[0]) is FutureMiddleware
    assert mware_mixin._future_middleware[0].middleware is no_op_middleware
    assert mware_mixin._future_middle

# Generated at 2022-06-26 03:39:27.901232
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # arrange
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = MiddlewareMixin()

    # act
    middleware_mixin_1.on_request()
    middleware_mixin_2.on_request(attach_to='request')

    # assert
    assert middleware_mixin_1._future_middleware[0].attach_to == 'request'
    assert middleware_mixin_2._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-26 03:39:29.207737
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()



# Generated at 2022-06-26 03:39:32.875863
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_request()
    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_2.on_request(middleware_mixin_1)

# Generated at 2022-06-26 03:39:34.663865
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_request()

# Generated at 2022-06-26 03:39:42.147688
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_1 = middleware_mixin_0.on_request()
    assert isinstance(middleware_1, partial)
    assert middleware_1.func is middleware_mixin_0.middleware
    assert middleware_1.keywords == {'attach_to': 'request'}
    middleware_mixin_1 = MiddlewareMixin()
    middleware_2 = middleware_mixin_1.on_request(middleware_mixin_0.on_request)
    assert callable(middleware_2)
    assert middleware_2.__name__ == 'on_request'


# Generated at 2022-06-26 03:39:45.595748
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    assert middleware_mixin_1.on_request() is not None


# Generated at 2022-06-26 03:39:48.643387
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()

    def test_function_0():
        pass
    middleware_mixin_1.on_request(middleware=test_function_0)
    pass


# Generated at 2022-06-26 03:40:00.488502
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    # Initiate an object of class MiddlewareMixin
    middleware_mixin_0 = MiddlewareMixin()

    middleware_0 = lambda x: x
    middleware_1 = lambda x: x

    # FuncDecorator
    middleware_0 = middleware_mixin_0.middleware(middleware_0, attach_to="request")
    # FuncDecorator
    middleware_1 = middleware_mixin_0.middleware(middleware_1, attach_to="request")

    # Should cover the following cases:
    # def middleware(
    #     self, middleware_or_request, attach_to="request", apply=True
    # ):

    #     def register_middleware(middleware, attach_to="request"):
    #         nonlocal apply

    #         future_middle

# Generated at 2022-06-26 03:40:12.593595
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def test_func_0(arg_0):
        return arg_0()
    def test_func_1(arg_0):
        return arg_0()
    middleware_0 = middleware_mixin_0.middleware
    middleware_1 = partial(middleware_0, middleware_or_request=test_func_0)
    middleware_2 = middleware_mixin_0.middleware(test_func_0, attach_to="request")
    middleware_3 = middleware_mixin_0.middleware(middleware_or_request=test_func_1)
    middleware_4 = middleware_mixin_0.middleware(middleware_or_request="request", attach_to="request")


# Generated at 2022-06-26 03:40:16.235205
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request_0 = partial(test_MiddlewareMixin_middleware.middleware, attach_to='request')
    future_middleware_0 = middleware_mixin_0.middleware(middleware_or_request_0, attach_to='request')


# Generated at 2022-06-26 03:40:27.217977
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Setup
    middleware_mixin_0 = MiddlewareMixin()

    assert middleware_mixin_0._future_middleware == []

    # Call MiddlewareMixin.middleware without attaching a middleware
    # So only apply is set to True
    MiddlewareMixin.middleware(middleware_mixin_0, None)

    assert middleware_mixin_0._future_middleware == []

    # Call MiddlewareMixin.middleware with apply set to False
    # So only None is attached to the middleware
    MiddlewareMixin.middleware(middleware_mixin_0, None, apply=False)

    assert middleware_mixin_0._future_middleware == [FutureMiddleware(None, "request")]

    # Call MiddlewareMixin.middleware with attach_to set to respond
    # So

# Generated at 2022-06-26 03:40:30.022128
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()

    assert not middleware_mixin_1._future_middleware


# Generated at 2022-06-26 03:40:38.514581
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request_0 = None
    attach_to_0 = "request"
    apply_0 = True
    middleware_0 = middleware_mixin_0.middleware(middleware_or_request_0, attach_to_0, apply_0)
    middleware_or_request_1 = "request"
    attach_to_1 = "response"
    apply_1 = False
    middleware_1 = middleware_mixin_0.middleware(middleware_or_request_1, attach_to_1, apply_1)
    attach_to_2 = "request"
    apply_2 = False
    middleware_2 = middleware_mixin_0.middleware(attach_to_2, apply_2)

# Generated at 2022-06-26 03:40:40.956339
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    print('Testing MiddlewareMixin.middleware()')
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0.middleware('request') is not None
    assert middleware_mixin_0.middleware('request') is not None


# Generated at 2022-06-26 03:40:44.048176
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # Call method of class Instance
    middleware_mixin_0.middleware(middleware_or_request=None, attach_to="request", apply=True)


# Generated at 2022-06-26 03:40:46.389667
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert False



# Generated at 2022-06-26 03:40:55.284723
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    middleware = lambda r: None
    future_middleware = FutureMiddleware(middleware, "request")
    assert (middleware_mixin.middleware(middleware, attach_to="request") ==
            middleware)
    assert (middleware_mixin.middleware(middleware, attach_to="response") ==
            middleware)
    assert (middleware_mixin.on_request(middleware) ==
            middleware)
    assert (middleware_mixin.on_response(middleware) ==
            middleware)
    assert (middleware_mixin._future_middleware[0] == \
            future_middleware)


# Generated at 2022-06-26 03:41:07.668332
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Here is the initialization of some variables
    middleware_mixin_1 = MiddlewareMixin()
    middleware_or_request_1 = "middleware_or_request_1"
    attach_to_1 = "attach_to_1"
    apply_1 = True
    # Here is the variable to store the returned value after function call
    # The expected value is None
    return_value_1 = None
    # Because @middleware is a decorator, we need to call the decorated
    # function here, which should return None
    # Call funtion and get the returned value, then compare it to the
    # expected one
    assert return_value_1 == middleware_mixin_1.middleware(
        middleware_or_request_1, attach_to_1, apply_1
    )


# Generated at 2022-06-26 03:41:12.180975
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middlware_0 = middleware_mixin_0.middleware(
        middleware_or_request='request'
    )
    assert callable(middlware_0)



# Generated at 2022-06-26 03:41:21.591816
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_0 = lambda request: request + 1
    middleware_1 = lambda response: response + 1
    middleware_mixin_1.middleware(middleware_0, attach_to="request")
    middleware_mixin_1.middleware(middleware_1, attach_to="response")
    assert middleware_mixin_1._future_middleware[0].middleware(2) == 3
    assert middleware_mixin_1._future_middleware[1].middleware(2) == 3


# Generated at 2022-06-26 03:41:23.902941
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    f = lambda request: request
    middleware_mixin_0.middleware(f)


# Generated at 2022-06-26 03:41:27.042671
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()



# Generated at 2022-06-26 03:41:37.043436
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    future_middleware_0 = FutureMiddleware(middleware_or_request=str, attach_to="response")
    future_middleware_0 = FutureMiddleware(middleware_or_request=str, attach_to="request")
    future_middleware_0 = FutureMiddleware(middleware_or_request=str, attach_to=str)
    middleware_mixin_0._future_middleware.append(future_middleware_0)
    middleware_mixin_0._apply_middleware(future_middleware_0)
    def register_middleware(middleware, attach_to='request'):
        nonlocal apply
        future_middleware_0 = FutureMiddleware(middleware_or_request=str, attach_to="response")
        future_

# Generated at 2022-06-26 03:41:39.486680
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request, attach_to="request", apply=True)


# Generated at 2022-06-26 03:41:51.391920
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    # In this test, we only test the function itself.
    # We are not testing to see if it is correctly called.

    # First call the function without arguments.
    # It should have no effect, since no middlware was added.
    middleware_mixin_0.middleware()

    # Add some middleware.
    # Verify that the middleware is added to the internal list of middleware.
    # If the list of middleware is not changed, the middleware is not added,
    # and the test fails.

    middleware = lambda _request : None
    middleware_mixin_0.middleware(middleware)

    if len(middleware_mixin_0._future_middleware) == 0:
        raise Exception("Test failed!")

    # Now call

# Generated at 2022-06-26 03:41:59.057254
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.futures import FutureMiddleware
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request_0 = ""
    attach_to_0 = ""
    apply_0 = True
    return_value_0 = middleware_mixin_0.middleware(
        middleware_or_request_0, attach_to_0, apply_0
    )
    assert return_value_0 is not None
    assert isinstance(return_value_0, partial)
    assert isinstance(return_value_0.func, partial)
    assert isinstance(middleware_mixin_0._future_middleware, list)
    assert len(middleware_mixin_0._future_middleware) == 0

    def partial_func_0(*args, **kwargs):
        return

# Generated at 2022-06-26 03:42:00.598070
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    x = MiddlewareMixin()
    y = x.middleware("request")
    y("request")


# Generated at 2022-06-26 03:42:12.072678
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = object()
    attach_to = object()
    def register_middleware(middleware, attach_to):
        return middleware
    assert middleware_mixin_0.middleware(middleware_or_request, attach_to=attach_to, apply=False) == register_middleware(middleware_or_request, attach_to=attach_to)
    assert middleware_mixin_0.middleware(middleware_or_request) == register_middleware(middleware_or_request)



# Generated at 2022-06-26 03:42:18.557351
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_1 = MiddlewareMixin()
    event_loop = asyncio.get_event_loop()

    # TypeError
    with pytest.raises(TypeError):
        middleware_mixin_0.middleware(
            "middleware_or_request", attach_to="attach_to", apply=False
        )
    with pytest.raises(TypeError):
        middleware_mixin_0.middleware("attach_to", "middleware_or_request")

    def middleware(request):
        print("middleware")
        return request

    # TypeError
    with pytest.raises(TypeError):
        middleware_mixin_0.middleware("middleware_or_request")

# Generated at 2022-06-26 03:42:26.489173
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # TEST: basic test
    middleware_or_request = None
    attach_to = None
    apply = None
    assert_result = MiddlewareMixin.middleware(middleware_mixin_0, middleware_or_request, attach_to, apply)
    # TEST: basic test
    middleware_or_request = None
    attach_to = None
    apply = None
    assert_result = MiddlewareMixin.middleware(middleware_mixin_0, middleware_or_request, attach_to, apply)


# Generated at 2022-06-26 03:42:32.683412
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    
    # Test case for:
    #     raise NotImplementedError  # noqa
    # Test reaches this line
    # with pytest.raises(NotImplementedError):
    #     middleware_mixin_0._apply_middleware()
    
    # Test reaches this line
    # with pytest.raises(NotImplementedError):
    #     middleware_mixin_0._apply_middleware()
    
    # Test reaches this line
    result = middleware_mixin_0.middleware(None)
    assert result(None) is None
    
    # Test reaches this line
    result = middleware_mixin_0.middleware(None, apply=False)
    assert result(None) is None


# Generated at 2022-06-26 03:42:39.513881
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    futures_middleware_0 = FutureMiddleware(middleware_or_request='request', attach_to='request')
    middleware_mixin_0 = MiddlewareMixin()
    # TypeError: object() takes no parameters
    try:
        middleware_mixin_0._apply_middleware(futures_middleware_0)
    except TypeError as e:
        print(e)


# Generated at 2022-06-26 03:42:43.356091
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request=None, attach_to="request")
    middleware_mixin_0.middleware(middleware_or_request=None, attach_to="response")
    middleware_mixin_0.middleware(middleware_or_request=None, attach_to="request")
    assert middleware_mixin_0._future_middleware is not None
    assert middleware_mixin_0._future_middleware[0].attach_to == "request"
    assert middleware_mixin_0._future_middleware[0].middleware is None


# Generated at 2022-06-26 03:42:45.516117
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    @middleware_mixin_0.on_response
    async def middleware(request, response):
        return None



# Generated at 2022-06-26 03:42:49.832677
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    # call method middleware of class MiddlewareMixin
    ret_val = middleware_mixin_1.middleware()

# Generated at 2022-06-26 03:42:56.891081
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0._apply_middleware(FutureMiddleware(None, None))
    middleware_mixin_0._apply_middleware(FutureMiddleware(None, None))
    middleware_mixin_0._apply_middleware(FutureMiddleware(None, None))
    middleware_mixin_0._apply_middleware(FutureMiddleware(None, None))
    middleware_mixin_0._apply_middleware(FutureMiddleware(None, None))
    middleware_mixin_0._apply_middleware(FutureMiddleware(None, None))

    @middleware_mixin_0.on_request
    async def test_0(request):
        pass

# Generated at 2022-06-26 03:43:04.302085
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    # Test no.1 - Correct way of calling
    @middleware_mixin_0.middleware
    def test_middleware_1(request):
        return request
    
    
    # Test no.2 - Correct way of calling
    @middleware_mixin_0.middleware('response')
    def test_middleware_2(request):
        return request
    
    
    # Test no.3 - Incorrect way of calling
    # Test raises TypeError
    with pytest.raises(TypeError):
        assert middleware_mixin_0.middleware()
    
    


# Generated at 2022-06-26 03:43:14.598348
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_1 = lambda x: x
    attach_to_1 = "request"
    apply_1 = True
    # Call function middleware
    # Note: The function middleware must not have named arguments.
    result_1 = middleware_mixin_1.middleware(middleware_1, attach_to_1, apply_1)
    assert result_1 == middleware_1


# Generated at 2022-06-26 03:43:18.665558
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def dummy_middleware(arg0):
        return arg0
    partial_0 = middleware_mixin_0.middleware(dummy_middleware, 'request')
    partial_0()

# Generated at 2022-06-26 03:43:21.483952
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request_0 = 1
    attach_to_0 = ""
    apply_0 = True
    middleware_mixin_0.middleware(middleware_or_request_0, attach_to_0, apply_0)


# Generated at 2022-06-26 03:43:25.400614
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = lambda request: request
    middleware_result = middleware_mixin_0.middleware(middleware_0)


# Generated at 2022-06-26 03:43:32.551108
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m = MiddlewareMixin()

    # Test for middleware with bool-like parameter apply
    def middleware_callable_0(request, response, *args, **kwargs): pass
    with pytest.raises(NotImplementedError):
        m.middleware(middleware_callable_0, apply=True)

    # Test for middleware with optional parameter middleware_or_request
    # and parameter attach_to == request
    # and bool-like parameter apply
    m.middleware(middleware_callable_0, attach_to="request", apply=True)

    # Test for middleware with optional parameter middleware_or_request
    # and parameter attach_to == response
    # and bool-like parameter apply
    m.middleware(middleware_callable_0, attach_to="response", apply=True)


# Generated at 2022-06-26 03:43:34.947618
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = MiddlewareMixin()


# Generated at 2022-06-26 03:43:41.682268
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(fn)
    middleware_mixin_1.middleware(
        fn, attach_to="request"
    )
    middleware_mixin_1.middleware(
        attach_to="request"
    )(fn)


# Generated at 2022-06-26 03:43:45.117898
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # test data generation
    middleware_or_request = callable
    attach_to = "request"
    apply = True

    # method invocation
    return_value = MiddlewareMixin.middleware(middleware_or_request, attach_to, apply)

    # method post-conditions
    assert return_value is not None



# Generated at 2022-06-26 03:43:50.905612
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    def hello_world():
        raise NotImplementedError  # noqa

    middleware_mixin_0 = MiddlewareMixin()

    # Call method middleware of middleware_mixin_0
    m = middleware_mixin_0.middleware
    partial_0 = m(hello_world)
    partial_0()

# Generated at 2022-06-26 03:43:55.951332
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin.middleware(None)() is None
    assert middleware_mixin.middleware(None)(None) is None
    assert middleware_mixin.middleware(None)(None)(None) is None
    assert middleware_mixin.middleware(None)(None)(None)(None) is None


# Generated at 2022-06-26 03:44:07.688194
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    middleware = middleware_mixin.middleware(middleware_or_request=None, attach_to="request", apply=True)
    assert middleware != None
    print ("Test complete MiddlewareMixin.middleware")


# Generated at 2022-06-26 03:44:18.364599
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0._future_middleware = list()
    
    # Testing if an Exception is raised
    try:
        middleware_mixin_0._apply_middleware(FutureMiddleware)
    except NotImplementedError:
        pass
    else:
        raise Exception
    
    # Testing when attach_to is not request or response
    def middleware_mock_func():
        pass
    
    try:
        middleware_mixin_0.middleware(middleware_mock_func, attach_to='test')
    except ValueError:
        pass
    else:
        raise Exception
    assert len(middleware_mixin_0._future_middleware) == 0
    
    # Testing when attach_to is request and apply is

# Generated at 2022-06-26 03:44:22.061955
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin(None, None, None, None)
    def function_0():
        pass
    with pytest.raises(NotImplementedError):
        middleware_mixin_0.middleware(function_0, "request", apply=True)
    with pytest.raises(NotImplementedError):
        middleware_mixin_0.middleware(True, "pwjah", apply=True)


# Generated at 2022-06-26 03:44:29.295034
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_mixin_0)
    middleware_mixin_0.middleware(middleware_mixin_0)
    middleware_mixin_0.middleware(middleware_mixin_0)
    middleware_mixin_0.middleware(middleware_mixin_0)
    middleware_mixin_0.middleware(middleware_mixin_0)


# Generated at 2022-06-26 03:44:34.441437
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    name = 'middleware'
    obj = MiddlewareMixin()
    assert hasattr(obj, name)
    method = getattr(obj, name)
    assert callable(method)

    name = '_apply_middleware'
    obj = MiddlewareMixin()
    assert hasattr(obj, name)
    method = getattr(obj, name)
    assert callable(method)



# Generated at 2022-06-26 03:44:39.010685
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0.middleware(
        callable, attach_to='request'
    ) is not None


# Generated at 2022-06-26 03:44:40.972656
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request=None, apply=None)



# Generated at 2022-06-26 03:44:46.596432
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    try:
        middleware_mixin_0.middleware()
    except NotImplementedError:
        pass


# Generated at 2022-06-26 03:44:50.530275
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0._future_middleware == []

    def middleware(request):
        pass

    with pytest.raises(NotImplementedError):
        middleware_mixin_0._apply_middleware(middleware)


# Generated at 2022-06-26 03:44:52.017368
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    middleware_mixin_0 = MiddlewareMixin()

# Generated at 2022-06-26 03:45:11.261272
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert (True)


# Generated at 2022-06-26 03:45:12.977901
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()


# Generated at 2022-06-26 03:45:23.434945
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_3 = MiddlewareMixin()
    middleware_mixin_4 = MiddlewareMixin()
    middleware_mixin_5 = MiddlewareMixin()
    middleware_mixin_6 = MiddlewareMixin()
    middleware_mixin_7 = MiddlewareMixin()
    middleware_mixin_8 = MiddlewareMixin()
    middleware_mixin_9 = MiddlewareMixin()
    middleware_mixin_10 = MiddlewareMixin()
    middleware_mixin_11 = MiddlewareMixin()
    middleware_mixin_12 = MiddlewareMixin()

# Generated at 2022-06-26 03:45:25.174347
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request=None, attach_to=None)



# Generated at 2022-06-26 03:45:27.504615
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request=None, attach_to=None, apply=None)


# Generated at 2022-06-26 03:45:30.039968
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Test for case 0
    middleware_mixin_0 = MiddlewareMixin()



# Generated at 2022-06-26 03:45:34.691711
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert callable(middleware_mixin_0.middleware())

# Generated at 2022-06-26 03:45:37.724865
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(middleware_or_request=None, attach_to="request", apply=True)


# Generated at 2022-06-26 03:45:43.808944
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request_0 = None
    attach_to_0 = "request"
    apply_0 = True
    register_middleware_0 = middleware_mixin_0.middleware(
        middleware_or_request_0, attach_to=attach_to_0, apply=apply_0
    )
    middleware_0 = None
    attach_to_1 = "request"
    response_0 = register_middleware_0(middleware_0, attach_to=attach_to_1)
    assert response_0 is None
    middleware_or_request_1 = "request"
    register_middleware_1 = middleware_mixin_0.middleware(
        middleware_or_request_1
    )
    middleware

# Generated at 2022-06-26 03:45:48.598367
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # TODO: This is not SSA-compliant, probably due to side effects
    middleware_or_request = middleware_mixin_0.middleware(middleware_mixin_0.middleware)
    assert middleware_or_request(int, "request") is not None
