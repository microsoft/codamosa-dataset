

# Generated at 2022-06-26 03:37:53.730819
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0._future_middleware == []
    def request_func():
        pass
    request_middle_function = middleware_mixin_0.middleware(request_func)
    assert callable(request_middle_function)
    request_middle_function()
    assert middleware_mixin_0._future_middleware == [FutureMiddleware(
        request_func, 'request')]


# Generated at 2022-06-26 03:37:56.582845
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_response("response").__self__
    middleware_mixin_0.on_response(middleware = 'response').__self__


# Generated at 2022-06-26 03:37:57.895804
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    with pytest.raises(NotImplementedError):
        MiddlewareMixin().middleware()

# Generated at 2022-06-26 03:38:00.786446
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    future_middleware_1 = middleware_mixin_0.on_request()


# Generated at 2022-06-26 03:38:04.883434
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert callable(middleware_mixin_0.middleware)


# Generated at 2022-06-26 03:38:08.855338
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0._future_middleware == []
    middleware_mixin_0.middleware("asd")
    assert middleware_mixin_0._future_middleware == []


# Generated at 2022-06-26 03:38:12.763806
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(middleware_or_request=None)


# Generated at 2022-06-26 03:38:18.206961
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    # Creating method from function
    maybe_partial_callable_0 = partial(middleware_mixin_0.middleware, attach_to = 'request')
    # Creating method from method
    maybe_partial_callable_1 = middleware_mixin_0.on_request


# Generated at 2022-06-26 03:38:22.272748
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_response()



# Generated at 2022-06-26 03:38:24.191685
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    _ = MiddlewareMixin()
    assert False  # TODO: implement your test here



# Generated at 2022-06-26 03:38:35.122960
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def func_0(obj_0):
        obj_0 = Request(obj_0)
        def inner(obj_1, obj_2=None, obj_3=False, obj_4=b'\x00', obj_5=b'\x00', obj_6=b'\x00'):
            obj_1 = BaseHTTPRequestHandler(obj_1, obj_2, obj_3, obj_4, obj_5, obj_6)
            return obj_1
        obj_0 = inner(obj_0)
        return obj_0
    a_1 = middleware_mixin_0.middleware(func_0)
    assert type(a_1) == type(func_0)
    def func_1(obj_0):
        obj

# Generated at 2022-06-26 03:38:46.084855
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    global __name__
    path_0 = os.getcwd()
    path_1 = path_0 + '/../'
    path_0 = path_1 + 'tests/'
    # path_0 = path_0 + '../'
    sys.path.append(path_0)

    from mytest import mytest
    test =mytest.Mytest()

    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0._apply_middleware = MagicMock()
    middleware_mixin_0._future_middleware = MagicMock()
    middleware_mixin_0._future_middleware.append = MagicMock()
    # Case 1
    middleware_or_request_1 = 'request'

# Generated at 2022-06-26 03:38:50.693768
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    decorator_0 = middleware_mixin_0.middleware
    # SUT
    def print_my_name():
        print("Hello, I'm Sanic")
    decorator_0(print_my_name)


# Generated at 2022-06-26 03:39:02.849830
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

# Generated at 2022-06-26 03:39:13.844840
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    assert middleware_mixin_1._future_middleware == []
    def middleware_or_request():
        pass
    assert middleware_mixin_1.middleware(middleware_or_request) == middleware_or_request
    assert middleware_mixin_1._future_middleware[0].middleware == middleware_or_request
    assert middleware_mixin_1._future_middleware[0].attach_to == "request"
    assert middleware_mixin_1._future_middleware[0].middleware == middleware_or_request
    assert middleware_mixin_1.middleware(middleware_or_request, "response") == middleware_or_request

# Generated at 2022-06-26 03:39:16.787712
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def dummy_middleware(middleware_or_request):
        return middleware_or_request
    middleware_mixin_0.middleware(dummy_middleware, 'request')




# Generated at 2022-06-26 03:39:27.501889
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    print("Unit test for method middleware of class MiddlewareMixin")
    print("Test 0:")
    print("Type: ", type(middleware_mixin_0.middleware))
    print("Test 1:")
    func_1 = middleware_mixin_0.middleware("request")
    print("Type: ", type(func_1))
    print("Test 2:")
    func_2 = middleware_mixin_0.middleware("response")
    print("Type: ", type(func_2))
    print("Test 3:")
    func_3 = middleware_mixin_0.middleware
    print("Type: ", type(func_3))


# Generated at 2022-06-26 03:39:29.605366
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin.middleware is not None


# Generated at 2022-06-26 03:39:38.524530
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    future_middleware_1 = FutureMiddleware("middleware_or_request", "request")
    assert future_middleware_1.attach_to == "request"

    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1._future_middleware.append(future_middleware_1)
    middleware_mixin_1.middleware("middleware_or_request", "request")
    assert future_middleware_1 in middleware_mixin_1._future_middleware

    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_2.middleware("middleware_or_request")


# Generated at 2022-06-26 03:39:42.229481
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # check whether the function is callable
    middleware_mixin = MiddlewareMixin()
    callable(middleware_mixin.middleware)



# Generated at 2022-06-26 03:39:52.350957
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    # Call method middleware of middleware_mixin_0
    with pytest.raises(NotImplementedError):
        middleware_mixin_0._apply_middleware(middleware='middleware')

    # Call method middleware of middleware_mixin_0
    with pytest.raises(NotImplementedError):
        middleware_mixin_0._apply_middleware(middleware='middleware', attach_to='request')

    # Call method middleware of middleware_mixin_0
    with pytest.raises(NotImplementedError):
        middleware_mixin_0._apply_middleware(middleware='middleware', attach_to='response')


# Generated at 2022-06-26 03:39:54.373640
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    a_response_0 = middleware_mixin_0.middleware()

# Generated at 2022-06-26 03:39:57.682190
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = None
    attach_to = "response"
    middleware_mixin_0.middleware(middleware_0, attach_to)



# Generated at 2022-06-26 03:40:09.585519
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Create an instance of MiddlewareMixin
    middleware_mixin_0 = MiddlewareMixin()
    # No arguments
    # Call method
    middleware_mixin_0.middleware()
    # No return value
    # No arguments
    # Call method
    middleware_mixin_0.middleware("AT")
    # No return value
    # single positional argument
    # Call method
    middleware_mixin_0.middleware()
    # No return value
    # single keyword argument
    # Call method
    middleware_mixin_0.middleware(attach_to="AT")
    # No return value
    # single positional argument and single keyword argument
    # Call method
    middleware_mixin_0.middleware(attach_to="AT")
    # No return value
    # single keyword argument and single

# Generated at 2022-06-26 03:40:10.531514
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-26 03:40:12.533450
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()

# Generated at 2022-06-26 03:40:14.699175
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(partial(MiddlewareMixin, attach_to="request"))


# Generated at 2022-06-26 03:40:21.874758
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middlware_or_request_arg_0 = mock.MagicMock()
    middlware_or_request_arg_0.foo.return_value = 1
    attach_to_arg_0 = 'request'
    apply_arg_0 = True
    middleware_0 = middleware_mixin_0.middleware(middlware_or_request_arg_0, attach_to_arg_0, apply_arg_0)


# Generated at 2022-06-26 03:40:28.839326
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.exceptions import RequestTimeout

    middleware_mixin_0 = MiddlewareMixin()

    async def middleware_0(request):
        return await request

    @middleware_mixin_0.middleware
    async def middleware_1(request):
        return await request

    @middleware_mixin_0.middleware('response')
    async def middleware_2(request, response):
        return await request, response



# Generated at 2022-06-26 03:40:34.336818
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Arrange
    middleware_mixin_2 = MiddlewareMixin()
    middleware_or_request = None
    attach_to = "request"
    apply = True

    # Act
    actuall = middleware_mixin_2.middleware(middleware_or_request, attach_to, apply)

    # Assert
    assert actuall is not None
    assert isinstance(actuall, partial)


# Generated at 2022-06-26 03:40:43.916834
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # Test case with two parameters
    res_1 = middleware_mixin_0.middleware("request")
    try:
        assert callable(res_1)
    except AssertionError:
        raise AssertionError("Result does not match expected value")
    # Test case with one paramater
    res_2 = middleware_mixin_0.middleware("request")
    try:
        assert callable(res_2)
    except AssertionError:
        raise AssertionError("Result does not match expected value")


# Generated at 2022-06-26 03:40:51.406322
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Create an instance of MiddlewareMixin
    middleware_mixin_0 = MiddlewareMixin()

    #Call method middleware of middleware_mixin_0
    partial_middleware = middleware_mixin_0.middleware('request')
    #Check if the created partial function is equal to the expected partial function
    assert partial_middleware == partial(middleware_mixin_0.middleware, attach_to='request')

# Generated at 2022-06-26 03:40:54.520594
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_0 = middleware_mixin_1.middleware
    middleware_1 = middleware_0(middleware_0)


# Generated at 2022-06-26 03:40:59.077644
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    def middleware(request):
        return request

    middleware_mixin_0.middleware(middleware)


# Generated at 2022-06-26 03:41:04.537983
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1._apply_middleware = _apply_middleware
    middleware_mixin_1.middleware("response")
    assert len(middleware_mixin_1._future_middleware) == 1


# Generated at 2022-06-26 03:41:06.345495
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = middleware_mixin_0.middleware



# Generated at 2022-06-26 03:41:10.821373
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(None, None, False)



# Generated at 2022-06-26 03:41:12.002847
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()



# Generated at 2022-06-26 03:41:15.563509
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    @middleware_mixin_0.middleware
    async def handler(request):
        pass



# Generated at 2022-06-26 03:41:20.284732
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Create a new instance of MiddlewareMixin
    middleware_mixin_0 = MiddlewareMixin()
    # Use the method middleware to register middleware
    middleware_mixin_0.middleware(lambda request:0)
    assert len(middleware_mixin_0._future_middleware) == 1


# Generated at 2022-06-26 03:41:23.076505
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(int())

# Generated at 2022-06-26 03:41:27.785016
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def middleware_or_request():
        return
    attach_to = "request"
    middleware_mixin_0.middleware(middleware_or_request, attach_to)


# Generated at 2022-06-26 03:41:37.112005
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware("request")
    middleware_mixin_1.middleware("response")
    middleware_mixin_1.middleware("request", True)
    middleware_mixin_1.middleware("response", False)
    middleware_mixin_1.middleware("request", attach_to="request", apply=True)
    middleware_mixin_1.middleware("request", attach_to="response", apply=False)
    middleware_mixin_1.middleware("response", attach_to="request", apply=True)
    middleware_mixin_1.middleware("response", attach_to="response", apply=False)


# Generated at 2022-06-26 03:41:48.106437
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # Type error
    try:
        middleware_mixin_0.middleware()
    except TypeError:
        pass
    else:
        assert False
    # Type error
    try:
        middleware_mixin_0.middleware(middleware_or_request=None)
    except TypeError:
        pass
    else:
        assert False
    # Type error
    try:
        middleware_mixin_0.middleware(middleware_or_request=None, attach_to=None)
    except TypeError:
        pass
    else:
        assert False
    # Type error
    try:
        middleware_mixin_0.middleware(middleware_or_request=None, apply=None)
    except TypeError:
        pass

# Generated at 2022-06-26 03:41:51.431530
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    with pytest.raises(NotImplementedError) as exception_info:
        middleware_mixin_0.middleware(None)


# Generated at 2022-06-26 03:41:59.055265
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1._apply_middleware = mock.MagicMock()
    future_middleware_1 = FutureMiddleware(None, "request")

    middleware_mixin_1.middleware(future_middleware_1)
    middleware_mixin_1._apply_middleware.assert_called_once_with(future_middleware_1)
    middleware_mixin_1._apply_middleware.reset_mock()

    middleware_mixin_1.middleware(future_middleware_1, "response")
    middleware_mixin_1._apply_middleware.assert_called_once_with(future_middleware_1)
    middleware_mixin_1._apply_middleware.reset_mock()


#

# Generated at 2022-06-26 03:42:00.815329
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # middleware_mixin_0.middleware()



# Generated at 2022-06-26 03:42:06.844039
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0._future_middleware = []
    middleware_mixin_0._apply_middleware = ''
    middleware_mixin_0.middleware(middleware_or_request = '')


# Generated at 2022-06-26 03:42:10.368619
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    test_middleware_0 = middleware_mixin_0.middleware
    test_middleware_1 = middleware_mixin_0.middleware('response')
    # test_middleware_2 = middleware_mixin_0.middleware('response')

    # print(test_middleware_0)
    # print(test_middleware_1)
    print(test_middleware_1)
    # print(test_middleware_2)



# Generated at 2022-06-26 03:42:16.514006
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Initialization of the objects
    middleware_mixin_1 = MiddlewareMixin()

    # Check if the function raises a TypeError when something else than a
    # callable (middleware) is passed as argument
    try:
        middleware_mixin_1.middleware("Not a middleware")
    except TypeError:
        pass
    else:
        print("TypeError exception not raised")

    # Check if the function raises a TypeError when nothing is passed as
    # argument
    try:
        middleware_mixin_1.middleware()
    except TypeError:
        pass
    else:
        print("TypeError exception not raised")

# Generated at 2022-06-26 03:42:24.099000
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    input_str = "middleware_0"
    output_str = "middleware_0"
    middleware_mixin_0 = MiddlewareMixin()
    output_middleware_0 = middleware_mixin_0.middleware(input_str)
    assert str(output_middleware_0) == output_str


# Generated at 2022-06-26 03:42:26.112899
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()

    @middleware_mixin_1.middleware
    def middleware_x(request):
        pass



# Generated at 2022-06-26 03:42:29.953435
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = lambda request, request_param1=None: None
    middleware_mixin_0.middleware(middleware_or_request)
    middleware_mixin_0.middleware(middleware_or_request, attach_to="request")


# Generated at 2022-06-26 03:42:31.681809
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = {}
    middleware_mixin_1 = MiddlewareMixin(app)



# Generated at 2022-06-26 03:42:37.811113
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = ""
    attach_to = ""
    apply = False
    t_middleware = middleware_mixin_0.middleware(middleware_or_request, attach_to, apply) 
    assert True, "Testcase failed"


# Generated at 2022-06-26 03:42:40.332394
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    for _ in range(100):
        # Register middleware
        middleware_mixin_0.middleware(lambda request: request)



# Generated at 2022-06-26 03:42:44.304905
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    def middleware_0(middleware_or_request, attach_to="request", apply=True):
        return FutureMiddleware(middleware_or_request, attach_to)

    middleware_mixin_0 = MiddlewareMixin()
    future_middleware_0 = middleware_mixin_0.middleware(middleware_0)


# Generated at 2022-06-26 03:42:49.831575
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # TODO: Should we test the third argument 'apply'?
    # It is only used inside the function, so I think this method is not
    # a good target to test.
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware("request")


# Generated at 2022-06-26 03:42:52.421003
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(middleware_or_request=1, attach_to="request", apply=True)


# Generated at 2022-06-26 03:42:59.099961
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def middleware_0():
        pass
    attach_to_0 = "request"
    register_middleware_0 = middleware_mixin_0.middleware(middleware_0, attach_to=attach_to_0)
    assert isinstance(register_middleware_0, partial)


# Generated at 2022-06-26 03:43:13.344966
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MockClass:
        def __init__(self, *args, **kwargs) -> None:
            self.middleware_mixin_0 = MiddlewareMixin()
            self.middleware_mixin_0._future_middleware = []
            self.middleware_mixin_0._apply_middleware = self.apply_middleware

        def apply_middleware(self, middleware):
            test = True
            assert isinstance(middleware, FutureMiddleware)
            assert isinstance(middleware._middleware, callable)
            assert middleware._attach_to == "request"

    mock_class_0 = MockClass()
    mock_class_0.middleware_mixin_0.middleware(lambda request: True)



# Generated at 2022-06-26 03:43:24.646256
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    def m(): ...
    result = middleware_mixin_0.middleware(m)
    assert result.__name__ == m.__name__
    assert result.__qualname__ == m.__qualname__
    assert result.__annotations__ == m.__annotations__
    assert result.__call__ == m.__call__
    assert result.__closure__ == m.__closure__

    try:
        result.__code__
    except:
        assert result.__code__ == m.__code__
    else:
        assert result.__code__.__name__ == m.__code__.__name__
        assert result.__code__.__annotations__ == m.__code__.__annotations__

# Generated at 2022-06-26 03:43:26.813207
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # Varify the method is callable.
    middleware_mixin_0.middleware(object, )


# Generated at 2022-06-26 03:43:33.525759
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import NotFound
    from sanic.request import Request

    def middleware_0(request):
        pass

    def middleware_1(request):
        pass

    def middleware_2(request):
        pass

    def middleware_3(request):
        pass

    middleware_mixin_1 = MiddlewareMixin()

    # Method middleware on object middleware_mixin_1 with the parameter
    # middleware_or_request equals to "request", attach_to equals to "request",
    # apply equals to True
    middleware_mixin_1.middleware(middleware_or_request=middleware_0, attach_to="request", apply=True)

    # Method middleware on object middleware_mix

# Generated at 2022-06-26 03:43:37.840722
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    pass  # unit test for MiddlewareMixin.middleware


# Generated at 2022-06-26 03:43:39.069125
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()


# Generated at 2022-06-26 03:43:41.717778
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert type(middleware_mixin_0.middleware) == MethodType


# Generated at 2022-06-26 03:43:43.791087
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0._apply_middleware(FutureMiddleware(None))



# Generated at 2022-06-26 03:43:46.194388
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = 'request'
    attach_to = 'request'
    apply = True

# Generated at 2022-06-26 03:43:58.024011
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_arg_2: Callable[[], None] = lambda: None
    attach_to_arg_3: str = 'request'
    apply_arg_4: bool = True
    middleware_arg_0 = middleware_arg_2
    attach_to_arg_1 = attach_to_arg_3
    attach_to_arg_0 = attach_to_arg_1
    middleware_or_request_arg_0 = middleware_arg_0
    attach_to_arg_2 = attach_to_arg_0
    apply_arg_1 = apply_arg_4
    middleware_or_request_arg_1 = middleware_or_request_arg_0
    attach_to_arg_4 = attach_to_arg_2
   