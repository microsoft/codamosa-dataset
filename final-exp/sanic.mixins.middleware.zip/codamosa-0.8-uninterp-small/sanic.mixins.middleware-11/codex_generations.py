

# Generated at 2022-06-26 03:37:55.080674
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    assert middleware_mixin_0.middleware == MiddlewareMixin.middleware


# Generated at 2022-06-26 03:37:57.449146
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin() # create an instance
    assert middleware_mixin_0.on_request("request")("request") == "request" # call method


# Generated at 2022-06-26 03:38:00.501886
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    middleware_mixin.middleware(middleware_or_request=None)


# Generated at 2022-06-26 03:38:02.170011
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    test_case_0()


# Generated at 2022-06-26 03:38:05.578744
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    excepted_result = "hello world"
    def hello():
        return "hello world"

    middleware_mixin_0.middleware(hello)

# Generated at 2022-06-26 03:38:12.526191
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    result = middleware_mixin_0.on_response(middleware=None)
    # partial(_register_middleware, attach_to='response')
    assert result.args == ()
    assert result.func.__name__ == '_register_middleware'
    assert result.keywords == {'attach_to': 'response'}



# Generated at 2022-06-26 03:38:18.818337
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = on_request
    attach_to = "request"
    apply = True
    register_middleware = middleware_mixin_0.middleware(middleware_or_request, attach_to, apply)
    return register_middleware(middleware_or_request, attach_to)


# Generated at 2022-06-26 03:38:23.724924
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = middleware_mixin_0.middleware("request")
    assert middleware_0.__name__ == "middleware_0"


# Generated at 2022-06-26 03:38:33.991630
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    assert middleware_mixin_1._future_middleware == []
    def function_middleware_1():
        pass
    assert middleware_mixin_1.middleware(function_middleware_1) == function_middleware_1
    assert middleware_mixin_1._future_middleware[0].middleware == function_middleware_1
    assert middleware_mixin_1._future_middleware[0].attach_to == "request"
    assert middleware_mixin_1._future_middleware[0].args == ()
    def function_middleware_2():
        pass
    assert middleware_mixin_1.middleware("response")(function_middleware_2) == function_middleware_2
    assert middleware_mixin_1

# Generated at 2022-06-26 03:38:40.065670
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def __init__(self, *args, **kwargs) -> None:
        self._future_middleware: List[FutureMiddleware] = []
    assert len(middleware_mixin_0._future_middleware) == 0
    middleware_mixin_0.middleware(middleware_or_request=None, attach_to='request', apply=True)


# Generated at 2022-06-26 03:38:45.711138
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_response()


# Generated at 2022-06-26 03:38:46.688367
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass


# Generated at 2022-06-26 03:38:50.878041
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(lambda x: x)


if __name__ == "__main__":
    test_case_0()
    test_MiddlewareMixin_middleware()

# Generated at 2022-06-26 03:39:02.896155
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from unittest.mock import call
    import pytest

    # Set up mock objects
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1._apply_middleware = lambda middleware: None
    @middleware_mixin_1.middleware
    async def f_middleware_attr_0() -> None:
        pass
    @middleware_mixin_1.middleware
    async def f_middleware_attr_1() -> None:
        pass
    @middleware_mixin_1.middleware
    async def f_middleware_attr_2() -> None:
        pass

# Generated at 2022-06-26 03:39:04.037306
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass


# Generated at 2022-06-26 03:39:14.748046
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from operator import add
    from functools import reduce
    from typing import List
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_response(add)
    middleware_mixin_1.on_response(add)
    middleware_mixin_1.on_request(add)
    middleware_mixin_1.on_request(add)
    middleware_mixin_1.on_request(add)
    middleware_mixin_1.on_response(add)
    middleware_mixin_1.on_response(add)
    middleware_mixin_1.on_response(add)
    middleware_mixin_1.on_request(add)
    middleware_mixin_1.on_response(add)
    middleware_

# Generated at 2022-06-26 03:39:16.712003
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0.on_response()

# Generated at 2022-06-26 03:39:28.363160
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware = lambda middleware=None, attach_to="response": lambda middleware=None: lambda middleware=None: lambda middleware=None: lambda middleware=None: lambda middleware=None: lambda middleware=None: lambda middleware=None: lambda middleware=None: lambda middleware=None: lambda middleware=None: lambda middleware=None: lambda middleware=None: lambda middleware=None: lambda middleware=None: lambda middleware=None: lambda middleware=None: lambda middleware=None: lambda middleware=None: lambda middleware=None: lambda middleware=None: middleware

    # Call method on_response of middleware_mixin_0
    # Variable middleware from closure:

# Generated at 2022-06-26 03:39:33.875578
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    
    def register_middleware(middleware='e'):
        print(middleware)
        middleware_mixin_0._future_middleware.append(middleware)
        return middleware
    
    @register_middleware
    def middleware():
        print('middleware')
        middleware_mixin_0._apply_middleware('a')



# Generated at 2022-06-26 03:39:39.218422
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # TypeError: 'middleware_or_request' is an invalid keyword argument for this function
    # middleware_mixin_0.middleware(middleware_or_request=partial)


if __name__ == "__main__":
    test_case_0()
    test_MiddlewareMixin_middleware()

# Generated at 2022-06-26 03:39:43.080753
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    @middleware_mixin_0.on_response()
    async def on_response_handler(request, response):
        pass


# Generated at 2022-06-26 03:39:47.364720
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_1 = MiddlewareMixin()
    assert middleware_mixin_1.on_response() is partial(middleware_mixin_1.middleware, attach_to="response")


# Generated at 2022-06-26 03:39:49.272377
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_response(middleware="response")


# Generated at 2022-06-26 03:39:52.961173
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0.on_response(middleware=None) is not None


# Generated at 2022-06-26 03:39:59.545266
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # make a middleware_mixin instance
    middleware_mixin_1 = MiddlewareMixin()
    # test param = None
    m_partial = middleware_mixin_1.on_response(middleware = None)
    assert m_partial
    # test param != None
    def test_middleware():
        pass
    m_partial_2 = middleware_mixin_1.on_response(middleware=test_middleware)
    assert m_partial_2


# Generated at 2022-06-26 03:40:03.611726
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_response('wUY7V0c0Spu')


# Generated at 2022-06-26 03:40:06.803914
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = middleware_mixin_0.on_response(middleware=None)
    assert callable(middleware_0)


# Generated at 2022-06-26 03:40:08.761697
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_response()

# Generated at 2022-06-26 03:40:15.868996
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixin_0(MiddlewareMixin):
        def __init__(self):
            self._future_middleware_0 = []
            super().__init__()

        def _apply_middleware(self, middleware):
            self._future_middleware_0.append(middleware)

        def m_0(self):
            pass

        m_0 = middleware(MiddlewareMixin.m_0, attach_to="request", apply=True)

    middleware_mixin_0 = MiddlewareMixin_0()

# NoUnit test for method middleware of class MiddlewareMixin

# Generated at 2022-06-26 03:40:18.678929
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    assert callable(middleware_mixin_0.on_response())


# Generated at 2022-06-26 03:40:25.991243
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_response()



# Generated at 2022-06-26 03:40:28.892523
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(middleware_or_request='request',apply=True)


# Generated at 2022-06-26 03:40:34.375516
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
  try:
    middleware_mixin_0 = MiddlewareMixin()
    run(
      In
        .map(lambda middleware: middleware_mixin_0.on_response(middleware))
        .forall(
          Arbitrary(
            middleware=Arbitrary.function_type(Arbitrary.ANY, Arbitrary.ANY)
          )
        )
        .call()
    )
  except:
    pass


# Generated at 2022-06-26 03:40:36.527846
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    partial_0 = partial(middleware_mixin_0.middleware, attach_to="response")



# Generated at 2022-06-26 03:40:38.344656
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(lambda x: x+1)


# Generated at 2022-06-26 03:40:43.321395
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.response import json

    middleware_mixin_0 = MiddlewareMixin()

    # Test with middleware being unwrapped and attach_to=param
    @middleware_mixin_0.middleware()
    def middleware_0(request):
        return request

    # Test with middleware having the attach_to param and attach_to='request'
    @middleware_mixin_0.middleware(attach_to="request")
    def middleware_1(request):
        return request

    # Test with middleware having the attach_to param and attach_to='response'
    @middleware_mixin_0.middleware(attach_to="response")
    def middleware_2(request, response):
        return json({"message": "OK"})


# Generated at 2022-06-26 03:40:46.073390
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 03:40:48.621177
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    with pytest.raises(NotImplementedError):
        middleware_mixin_4 = MiddlewareMixin()
        middleware_mixin_4.on_response('response')

# Generated at 2022-06-26 03:40:51.146796
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_response()()


# Generated at 2022-06-26 03:40:58.149549
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Setup
    middleware_mixin_1 = MiddlewareMixin()
    middleware = None
    # Exercise
    on_response_method_return_value = middleware_mixin_1.on_response(middleware)
    callable_on_response_method_return_value = on_response_method_return_value()
    # Verify
    assert callable
    assert callable(on_response_method_return_value)
    assert callable_on_response_method_return_value
    assert callable(callable_on_response_method_return_value)
    # Cleanup - N/A


# Generated at 2022-06-26 03:41:10.781789
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """
    TODO: remove the following lines, add your test code here
    """
    pass


# Generated at 2022-06-26 03:41:19.486750
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Declare the component under test
    middleware_mixin = MiddlewareMixin()

    # Setup test accounts with balances
    @middleware_mixin.on_response
    def test_case_1(request, response):
        print("Logging after request")
    # Exercise the component under test
    # Verify the results
    assert hasattr(middleware_mixin, '_future_middleware')
    assert hasattr(test_case_1, '__wrapped__')
    assert hasattr(test_case_1, '__qualname__')


# Generated at 2022-06-26 03:41:20.531925
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

# Generated at 2022-06-26 03:41:28.485407
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    # Test if the method __init__ of class MiddlewareMixin is callable
    assert callable(middleware_mixin_0.__init__)

    # Test the type of the attribute _future_middleware of class MiddlewareMixin
    assert isinstance(middleware_mixin_0._future_middleware, List)

    # Test if the method _apply_middleware of class MiddlewareMixin is callable
    assert callable(middleware_mixin_0._apply_middleware)



# Generated at 2022-06-26 03:41:31.230565
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    with pytest.raises(TypeError):
        middleware_mixin_0.on_response()
    middleware_mixin_0.on_response(True)


# Generated at 2022-06-26 03:41:35.484691
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_11 = MiddlewareMixin()
    middleware_mixin_11.on_response()
    middleware_mixin_11.on_response(middleware=None)
    middleware_mixin_11.on_response(middleware=None)



# Generated at 2022-06-26 03:41:37.223368
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(on_response)


# Generated at 2022-06-26 03:41:44.108946
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    """
    This function tests the "on_response" method of the class MiddlewareMixin
    """
    # Test case where we pass in None for the middleware parameter
    middleware_mixin_0 = MiddlewareMixin()
    partial_0 = middleware_mixin_0.on_response()
    # Test case where we pass in a callable for the middleware parameter
    partial_1 = middleware_mixin_0.on_response(callable)


# Generated at 2022-06-26 03:41:51.237070
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    for i in range(2):
        future_middleware_0 = middleware_mixin_0._future_middleware[i]
        assert middleware_mixin_0._future_middleware[i] == future_middleware_0

        future_middleware_1 = middleware_mixin_0._future_middleware[i]
        assert middleware_mixin_0._future_middleware[i] == future_middleware_1


# Generated at 2022-06-26 03:41:55.224504
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    # Call method middleware of class MiddlewareMixin
    middleware_mixin_1.middleware()
    # Call method middleware of class MiddlewareMixin
    middleware_mixin_1.middleware(middleware_or_request=None)


# Generated at 2022-06-26 03:42:09.569571
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    middleware_mixin_1 = MiddlewareMixin()

    @middleware_mixin_1.middleware('request')
    def auth_middleware(request):
        pass

    assert middleware_mixin_1._future_middleware[0].attach_to == 'request'



# Generated at 2022-06-26 03:42:16.409299
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Initialization
    middleware_mixin_0 = MiddlewareMixin()
    # Variables for test
    middleware_or_request = "request"
    attach_to = "request"
    apply = True

    # Invoke test
    middleware_mixin_0.middleware(
        middleware_or_request=middleware_or_request,
        attach_to=attach_to,
        apply=apply,
    )



# Generated at 2022-06-26 03:42:18.462059
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    raw_middlare_1 = lambda x: x + 1
    middleware_mixin_1.middleware(raw_middlare_1, attach_to="request")


# Generated at 2022-06-26 03:42:24.659594
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    method_middleware_0 = MiddlewareMixin.middleware
    method_middleware_0_0 = MiddlewareMixin.middleware
    method_middleware_0_1 = MiddlewareMixin.middleware
    MiddlewareMixin.middleware(MiddlewareMixin, lambda: None)
    MiddlewareMixin.middleware(MiddlewareMixin, "response")(lambda: None)


# Generated at 2022-06-26 03:42:25.795513
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()



# Generated at 2022-06-26 03:42:28.049009
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    with pytest.raises(NotImplementedError):
        MiddlewareMixin().middleware()


# Generated at 2022-06-26 03:42:28.797320
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

# Generated at 2022-06-26 03:42:31.786610
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request, attach_to="request", apply=True)


# Generated at 2022-06-26 03:42:39.941623
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """
    Test if the middleware decorator works correctly with a request
    """
    class A(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        @MiddlewareMixin.middleware("request")
        def _apply_middleware(self, _middleware: FutureMiddleware):
            return _middleware

        @MiddlewareMixin.middleware("request")
        def test(self):
            return "test"

    a_0 = A()
    assert a_0.test() == "test"

# Generated at 2022-06-26 03:42:43.666961
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    m = lambda : True
    middleware_mixin_0.middleware(m)
    middleware_mixin_0.middleware(m, attach_to = "request")
    middleware_mixin_0.middleware(m, attach_to = "response")


# Generated at 2022-06-26 03:43:02.106196
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware("a0", "request")
    middleware_mixin_0.middleware("a1", "request")

# Generated at 2022-06-26 03:43:14.090155
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = MiddlewareMixin()

    def middleware_0(request):
        return request

    def middleware_1(request):
        return request

    def middleware_2(request):
        return request

    returned_value_0 = middleware_mixin_0.middleware(middleware_0)
    returned_value_1 = middleware_mixin_0.middleware(middleware_1)
    returned_value_2 = middleware_mixin_0.middleware(middleware_2)
    returned_value_3 = middleware_mixin_1.middleware('request', middleware_0)
    returned_value_4 = middleware_mixin_1

# Generated at 2022-06-26 03:43:18.813951
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_middleware_0 = middleware_mixin_0.middleware('request')
    assert callable(middleware_middleware_0)
    assert not hasattr(middleware_middleware_0, 'attach_to')


# Generated at 2022-06-26 03:43:22.125574
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()

    def mock_callable_0():
        pass

    # Test with required arguments
    middleware_mixin_1.middleware(middleware_or_request=mock_callable_0)
    # Test with all arguments
    middleware_mixin_1.middleware(middleware_or_request=mock_callable_0,
                                  attach_to='function',
                                  apply=False)


# Generated at 2022-06-26 03:43:31.260833
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    # TODO: implement your test cases here

    # setup example
    middleware_mixin_0._future_middleware: List[FutureMiddleware] = []
    middleware_mixin_0._apply_middleware: FutureMiddleware = None

    # Case: False
    try:
        middleware_mixin_0.middleware(middleware_mixin_0._apply_middleware)
        assert False
    except NotImplementedError:
        assert True

    # Case: True

# Generated at 2022-06-26 03:43:32.886365
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_0 = MiddlewareMixin()
    middleware_1 = middleware_0.middleware



# Generated at 2022-06-26 03:43:44.375630
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app_0 = Sanic()
    app_0.test_client = True
    # Test exception
    from sanic.exceptions import SanicException
    try:
        def middleware_0(request, response):
            pass
        app_0.middleware(middleware_0)
    except (TypeError, UnboundLocalError):
        assert True
    except SanicException:
        assert False

    # Test exception
    from sanic.exceptions import SanicException
    try:
        def middleware_0(request, response):
            pass
        app_0.middleware('request')(middleware_0)
    except (TypeError, UnboundLocalError):
        assert True
    except SanicException:
        assert False

    # Test exception
    from sanic.exceptions import San

# Generated at 2022-06-26 03:43:46.216668
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    # Arrange
    middleware_mixin_0 = MiddlewareMixin()

    # Act
    middleware_mixin_0.middleware()

    # Assert



# Generated at 2022-06-26 03:43:57.014160
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    test_middleware_or_request = None
    test_attach_to = 'response'
    test_apply = True
    test_middleware = None
    test_middleware_0 = None
    test_attach_to_0 = 'request'
    test_apply_0 = True
    assert middleware_mixin.middleware(test_middleware_or_request,
                                                 test_attach_to,
                                                 test_apply) == test_middleware
    assert middleware_mixin.middleware(test_middleware_0,
                                                 test_attach_to_0,
                                                 test_apply_0) == test_middleware_0


# Generated at 2022-06-26 03:44:07.919092
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_1: FutureMiddleware = FutureMiddleware(lambda x: None, "request")
    arg_1: Optional[FutureMiddleware] = middleware_1
    middleware_mixin_2 = middleware_mixin_1.middleware(middleware_1, "response", True)
    middleware_mixin_2._apply_middleware(arg_1)
    middleware_mixin_3 = middleware_mixin_1.on_request()
    middleware_mixin_4 = middleware_mixin_1.on_response()
    middleware_mixin_5 = MiddlewareMixin()
    middleware_2: FutureMiddleware = FutureMiddleware(lambda x: None, "request")

# Generated at 2022-06-26 03:44:28.398709
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware("request")


# Generated at 2022-06-26 03:44:29.848685
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    hp = MiddlewareMixin()
    hp.middleware('request', apply=True)


# Generated at 2022-06-26 03:44:38.907577
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert isinstance(middleware_mixin_0._future_middleware, list)
    assert len(middleware_mixin_0._future_middleware) == 0
    middleware_mixin_0.middleware(middleware_mixin_0.on_request)
    assert len(middleware_mixin_0._future_middleware) == 1
    middleware_mixin_0.middleware(middleware_mixin_0.on_response)
    assert len(middleware_mixin_0._future_middleware) == 2



# Generated at 2022-06-26 03:44:42.423928
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def test_0():
        assert True
    middleware_mixin_0.middleware(test_0)
    def test_1():
        assert True
    middleware_mixin_0.middleware(test_1, "response")
    def test_2():
        assert True
    middleware_mixin_0.middleware(test_2, "request")


# Generated at 2022-06-26 03:44:51.988881
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    def register_middleware(middleware, attach_to="request"):
        nonlocal apply
        future_middleware = FutureMiddleware(middleware, attach_to)
        middleware_mixin_1._future_middleware.append(future_middleware)
        if apply:
            middleware_mixin_1._apply_middleware(future_middleware)
        return middleware
    middleware_mixin_1._apply_middleware = True
    def register_middleware_1(middleware_or_request, attach_to="request"):
        if callable(middleware_or_request):
            return register_middleware(middleware_or_request_0, attach_to=attach_to)

# Generated at 2022-06-26 03:44:53.687320
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    assert callable(middleware_mixin_1.middleware)


# Generated at 2022-06-26 03:45:00.759091
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    tests_successful = 0
    tests_total = 0

    middleware_mixin_0 = MiddlewareMixin()

    tests_total += 1
    try:
        middleware_mixin_0.middleware()
        tests_successful += 1
    except NotImplementedError:
        pass

    assert tests_successful == tests_total


# Generated at 2022-06-26 03:45:10.578737
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    # Test when middleware_or_request is callable, attach_to is "request"
    @middleware_mixin_0.middleware
    def middleware_0():
        return 0
    assert middleware_0() == 0
    assert middleware_mixin_0._future_middleware[0].middleware == middleware_0

    # Test when middleware_or_request is callable, attach_to is "response"
    @middleware_mixin_0.middleware(attach_to="response")
    def middleware_1():
        return 1
    assert middleware_1() == 1
    assert middleware_mixin_0._future_middleware[1].middleware == middleware_1

    # Test when middleware_or_request is "request

# Generated at 2022-06-26 03:45:12.572728
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request, attach_to)


# Generated at 2022-06-26 03:45:22.965619
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()

    middleware_or_request_0 = {'overwrite_scheme': True}
    attach_to_0 = 'response'
    middleware_0 = middleware_mixin_1.middleware(middleware_or_request_0, attach_to_0)

    middleware_or_request_0 = 'request'
    middleware_1 = middleware_mixin_1.middleware(middleware_or_request_0)

    middleware_or_request_0 = 'request'
    middleware_mixin_1.middleware(middleware_or_request_0)

    middleware_or_request_0 = 'response'
    middleware_2 = middleware_mixin_1.middleware(middleware_or_request_0)

   

# Generated at 2022-06-26 03:46:01.764483
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # Usage of middleware():
    def on_response_0(request, response, **kwargs):
        return response # noqa
    middleware_mixin_0.middleware(on_response_0, attach_to="response")
    # Usage of middleware() as a decorator:
    def on_response_1(request, response, **kwargs):
        return response # noqa
    middleware_mixin_0.middleware(attach_to="response")(on_response_1)
    # Usage of middleware() as a decorator with a defaulted parameter:
    def on_response_2(request, response, **kwargs):
        return response # noqa

# Generated at 2022-06-26 03:46:03.832707
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()



# Generated at 2022-06-26 03:46:06.270936
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request=None, attach_to=None, apply=None)


# Generated at 2022-06-26 03:46:10.500554
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    def my_middleware():
        return "my return value"

    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0.middleware(my_middleware)() == "my return value"



# Generated at 2022-06-26 03:46:18.527717
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    decorator_0 = middleware_mixin_0.middleware(None, None)
    middleware_0 = lambda: None
    middleware_1 = lambda: None
    assert decorator_0(middleware_0) == middleware_0
    assert not middleware_mixin_0._future_middleware
    assert callable(decorator_0)
    assert callable(decorator_0(middleware_1))
    assert callable(middleware_1)
    assert middleware_mixin_0._future_middleware
    assert middleware_mixin_0._future_middleware[0].middleware == middleware_1
    assert middleware_mixin_0._future_middleware[0].attach_to == "request"

# Unit

# Generated at 2022-06-26 03:46:25.718466
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    class C:
        def __init__(self):
            self.middleware_mixin = middleware_mixin_0
            self.register_middleware = middleware_mixin_0.middleware

    c_0 = C()
    c_0.register_middleware(middleware_or_request=None)
    c_0.register_middleware(middleware_or_request=None)
    c_0.register_middleware(middleware_or_request=None)


# Generated at 2022-06-26 03:46:29.052088
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()



# Generated at 2022-06-26 03:46:30.810479
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0.middleware()


# Generated at 2022-06-26 03:46:31.289190
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert True

# Generated at 2022-06-26 03:46:37.242884
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = 'response'
    attach_to = 'response'
    apply = True
    partial_0 = middleware_mixin_0.middleware(middleware_or_request, attach_to, apply)
    middleware = 'response'
    return middleware_mixin_0.middleware(partial_0, middleware)


# Generated at 2022-06-26 03:47:45.478657
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-26 03:47:46.251303
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()


# Generated at 2022-06-26 03:47:47.760020
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    # Put your code here
    assert middleware_mixin_1 != None


# Generated at 2022-06-26 03:47:55.744021
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # ********** Arrange **********
    # Define a variable to store the class instance.
    middleware_mixin_0 = MiddlewareMixin()

    # Define a variable to store local variable method_one, which will be
    # passed to the middleware method as a parameter.
    method_one_0 = None

    # Define a variable to store local variable attach_to, which will be
    # passed to the middleware method as a parameter.
    attach_to_0 = "response"

    # Define a variable to store local variable apply, which will be
    # passed to the middleware method as a parameter.
    apply_0 = True

    # ********** Act **********
    def middleware_0(request):
        pass
    # Call the method.