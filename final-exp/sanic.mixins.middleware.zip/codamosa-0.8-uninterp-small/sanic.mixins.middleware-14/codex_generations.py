

# Generated at 2022-06-26 03:37:53.952270
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    result = middleware_mixin_0.on_response()
    assert result


# Generated at 2022-06-26 03:37:57.656771
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_1 = MiddlewareMixin()
    partial_call = middleware_mixin_1.on_response('response')
    middleware_mixin_1._future_middleware
    assert middleware_mixin_1.on_response(middleware=None).__name__ == 'partial'


# Generated at 2022-06-26 03:38:03.357826
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    @middleware_mixin_0.middleware
    async def middleware_or_request_0(request):
        pass

    @middleware_mixin_0.middleware('request')
    async def middleware_or_request_1(request):
        pass


# Generated at 2022-06-26 03:38:14.914087
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_response_0 = middleware_mixin_0.on_response()
    middleware_response_0('middleware_or_request')
    middleware_response_1 = middleware_mixin_0.on_response('attach_to')
    middleware_response_1('middleware_or_request')
    middleware_response_2 = middleware_mixin_0.on_response(middleware_mixin_0.middleware)
    middleware_response_2('middleware_or_request')

# Generated at 2022-06-26 03:38:16.281706
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_request()

# Generated at 2022-06-26 03:38:20.632075
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_response()
    print("test_case_0")
    print("test_MiddlewareMixin_on_response")


# Generated at 2022-06-26 03:38:21.608305
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-26 03:38:25.696695
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin = MiddlewareMixin()
    actual_result = middleware_mixin.on_response()
    expected_result = partial(middleware_mixin.middleware, attach_to='response')
    assert actual_result == expected_result


# Generated at 2022-06-26 03:38:34.265562
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    try:
        middleware_mixin_1 = MiddlewareMixin()
    except:
        print("Error occur in __init__")
        raise

    try:
        middleware_mixin_1.on_response()
    except:
        print("Error occur in method on_response when middleware_mixin == None")
        raise
    
    try:
        middleware_or_request = 1
        middleware_mixin_1.on_response(middleware_or_request)
    except:
        print("Error occur in method on_response when middleware_mixin == integer")
        raise
    

# Generated at 2022-06-26 03:38:36.126268
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_request(middleware=None)

# Generated at 2022-06-26 03:38:40.170175
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    callable_0 = lambda : None
    future_middleware_0 = middleware_mixin_0.middleware(callable_0)
    assert future_middleware_0



# Generated at 2022-06-26 03:38:42.735936
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    # Call the method on_request of class MiddlewareMixin
    middleware_mixin_0.on_request(middleware=None)


# Generated at 2022-06-26 03:38:45.922575
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = middleware_mixin_0.on_request()


# Generated at 2022-06-26 03:38:50.878070
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    future_middleware_0 = middleware_mixin_0.middleware(None, None, True)
    future_middleware_1 = middleware_mixin_0.on_request(None)
    future_middleware_2 = middleware_mixin_0.on_response(None)

# Generated at 2022-06-26 03:39:00.939951
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    # test for callable parameter
    middleware_mixin_1 = MiddlewareMixin()
    func_0 = lambda request: 'abc'
    decorator_0 = middleware_mixin_1.on_request(func_0)
    assert decorator_0 == func_0

    # test for not callable parameter
    middleware_mixin_2 = MiddlewareMixin()
    func_1 = lambda request: 'abc'
    partial_obj_0 = middleware_mixin_2.on_request()(func_1)
    assert partial_obj_0 == func_1


# Generated at 2022-06-26 03:39:02.775981
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_request()


# Generated at 2022-06-26 03:39:11.556425
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    try:
        del MiddlewareMixin._future_middleware
    except AttributeError:
        pass
    middleware_mixin_1 = MiddlewareMixin()
    middleware_or_request = lambda request: True
    attach_to = 'response'
    apply = True
    middleware_mixin_1.middleware(middleware_or_request, attach_to, apply)
    try:
        assert MiddlewareMixin._future_middleware == [FutureMiddleware(middleware_or_request, attach_to)]
    except AttributeError:
        raise
    return 'ok'


# Generated at 2022-06-26 03:39:18.506992
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    func_0 = middleware_mixin_1.on_request()
    assert isinstance(func_0, functools.partial)
    assert func_0.func == MiddlewareMixin.middleware
    assert func_0.args == tuple()
    assert func_0.keywords == {'attach_to': 'request'}

    def middleware_0(request, handler): pass
    func_1 = middleware_mixin_1.on_request(middleware_0)
    assert func_1 == middleware_0
    assert middleware_mixin_1._future_middleware == [
        FutureMiddleware(middleware_0, 'request')
    ]



# Generated at 2022-06-26 03:39:21.958671
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_request()


# Generated at 2022-06-26 03:39:24.834110
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    def call_1():
        middleware_mixin_0.on_request(middleware=None)
    call_1()


# Generated at 2022-06-26 03:39:30.373974
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    # Test with middleware_or_request as a callable, attach_to as a str
    middleware_mixin_1.middleware(lambda a : a)


# Generated at 2022-06-26 03:39:33.316600
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware('request')
    middleware_mixin_0.middleware()


# Generated at 2022-06-26 03:39:42.223773
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    assert middleware_mixin_1._future_middleware == [], 'No middleware has been registered'

    middleware_0 = lambda request: None
    middleware_mixin_1.middleware(middleware_0)
    assert len(middleware_mixin_1._future_middleware) == 1, 'One middleware has been registered'
    assert middleware_mixin_1._future_middleware[0].middleware is middleware_0, 'The middleware added is the expected'
    assert middleware_mixin_1._future_middleware[0].attach_to == 'request', 'The attach_to attribute is the expected'

# Generated at 2022-06-26 03:39:45.686748
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware("request")


# Generated at 2022-06-26 03:39:53.015765
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Init object for test
    middleware_mixin_0 = MiddlewareMixin()

    # Try to call method middleware with invalid arguments.
    # Should throw an exception
    try:
        middleware_mixin_0.middleware()
    except Exception as exception:
        assert type(exception) is TypeError
        assert str(exception) == \
            "middleware() missing 1 required positional argument: 'middleware_or_request'"
    else:
        assert False, "Expected exception"

    # Try to call method middleware with invalid arguments.
    # Should throw an exception
    try:
        middleware_mixin_0.middleware(None, None)
    except Exception as exception:
        assert type(exception) is TypeError

# Generated at 2022-06-26 03:39:56.490421
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_3 = MiddlewareMixin()
    middleware_mixin_4 = MiddlewareMixin()

# Generated at 2022-06-26 03:40:06.534272
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Test without parameter
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()

    # Test with one parameter
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(lambda: None)

    # Test with two parameter
    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_2.middleware(lambda: None,'request')

    # Test with three parameters
    middleware_mixin_3 = MiddlewareMixin()
    middleware_mixin_3.middleware(lambda: None,'request',True)



# Generated at 2022-06-26 03:40:12.206829
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Test 1: no exception should be raised
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request="request")
    # Test 2: no exception should be raised
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request=lambda request: 15)



# Generated at 2022-06-26 03:40:17.135038
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0._apply_middleware = _apply_middleware_mock
    middleware_mixin_0._future_middleware = _future_middleware_mock

    middleware_mixin_0.middleware(middleware_mock, attach_to_mock, apply_mock)
    _apply_middleware_mock.assert_called_once_with(middleware_mock)


# Generated at 2022-06-26 03:40:20.246508
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(
        middleware_or_request=notcallable,
        attach_to="request",
        apply=True
    )


# Generated at 2022-06-26 03:40:32.869253
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    obj = MiddlewareMixin()
    middleware = object()
    atta = "request"
    apply = True
    result = obj.middleware(middleware, atta, apply)
    assert result == middleware
    assert obj._future_middleware == [FutureMiddleware(middleware, "request")]
    # Testing docstring
    m_result = MiddlewareMixin.middleware.__doc__

# Generated at 2022-06-26 03:40:35.427142
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    print('Test MiddlewareMixin.middleware()...')
    middleware_mixin_0.middleware(middleware=1)


# Generated at 2022-06-26 03:40:37.130047
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()


# Generated at 2022-06-26 03:40:38.837979
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_or_request = None
    method_result_1 = middleware_mixin_1.middleware(middleware_or_request)
    return method_result_1


# Generated at 2022-06-26 03:40:41.684258
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    
    @middleware_mixin_1.middleware('request')
    def middleware_request_1(request):
        return request

    @middleware_mixin_1.middleware('response')
    def middleware_response_1(request, response):
        return request, response



# Generated at 2022-06-26 03:40:53.572421
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    middleware_mixin_0 = MiddlewareMixin()
    test_cases = [
        # Test case #0
        (
            middleware_mixin_0.middleware(None),
            partial(middleware_mixin_0.middleware, attach_to="request"),
        ),
        # Test case #1
        (
            middleware_mixin_0.middleware("request"),
            partial(middleware_mixin_0.middleware, attach_to="request"),
        ),
        # Test case #2
        (
            middleware_mixin_0.middleware("response"),
            partial(middleware_mixin_0.middleware, attach_to="response"),
        ),
    ]

    for test_case_data in test_cases:
        assert test_case_data[0] == test_case

# Generated at 2022-06-26 03:40:59.031694
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    future_middleware_0: FutureMiddleware
    assert middleware_mixin_0.middleware(future_middleware_0) == False


# Generated at 2022-06-26 03:41:03.796850
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()

    @middleware_mixin.middleware("request")
    def test_request_middleware():
        pass

    assert len(middleware_mixin._future_middleware) == 1

# Generated at 2022-06-26 03:41:07.452608
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # middleware_0 = middleware_mixin_0.middleware()
    # middleware_1 = middleware_mixin_0.middleware("request")
    # middleware_2 = middleware_mixin_0.middleware("response")


# Generated at 2022-06-26 03:41:12.181162
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

# Generated at 2022-06-26 03:41:19.020715
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_ = MiddlewareMixin()
    middleware = middleware_mixin_.middleware
    assert callable(middleware), f'method middleware of class MiddlewareMixin is not callable'


# Generated at 2022-06-26 03:41:20.460157
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()



# Generated at 2022-06-26 03:41:24.157734
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # arrange
    middleware_mixin_0 = MiddlewareMixin()

    # act
    middleware_mixin_0.middleware(middleware_or_request='request')

    # assert
    assert len(middleware_mixin_0._future_middleware) == 0


# Generated at 2022-06-26 03:41:35.668785
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    # Test MiddlewareMixin's instance attribute
    assert isinstance(middleware_mixin_0._future_middleware, list)
    assert middleware_mixin_0._future_middleware == []

    # Test MiddlewareMixin's abstract method
    try:
        middleware_mixin_0._apply_middleware(FutureMiddleware)
    except NotImplementedError as e:
        # Test the exception is as expected
        assert str(e) == 'Can\'t instantiate abstract class MiddlewareMixin with abstract methods _apply_middleware'  # noqa
    else:
        assert False  # Shouldn't reach here

    @middleware_mixin_0.middleware
    async def middleware_0(request):
        pass

    # Test MiddlewareMix

# Generated at 2022-06-26 03:41:38.675473
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()

    @middleware_mixin_1.middleware
    def decorator_test_1(request,response):
        return request

    assert isinstance(decorator_test_1, partial)


# Generated at 2022-06-26 03:41:46.544565
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_function_0 = MiddlewareMixin.middleware(
        middleware_mixin_0,
        None,
        None
    )
    middleware_function_1 = MiddlewareMixin.middleware(
        middleware_mixin_0,
        None,
        None
    )
    # Unknown, not sure that middleware_function_1 is callable
    # middleware_function_1()


# Generated at 2022-06-26 03:41:53.480041
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_0 = MiddlewareMixin()
    middleware_1 = middleware_0.middleware(lambda request: request)
    middleware_2 = middleware_0.middleware(lambda request: request, attach_to='response')
    middleware_3 = middleware_1(attach_to='response')
    assert middleware_0._future_middleware == []
    assert middleware_1 != middleware_2
    assert middleware_1 != middleware_3
    assert middleware_2 != middleware_3


# Generated at 2022-06-26 03:41:56.430099
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_fun = lambda req: req
    assert middleware_mixin_1.middleware(middleware_fun) == middleware_fun
    middleware_fun_01 = lambda req, res: (req, res)
    assert middleware_mixin_1.middleware(
        middleware_fun_01, attach_to="response"
    ) == middleware_fun_01



# Generated at 2022-06-26 03:42:02.347480
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(middleware_or_request="request", attach_to="request", apply=True)

# Generated at 2022-06-26 03:42:13.567707
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    middleware_func_0 = lambda x, y, z="", *args, **kwargs: None
    middleware_func_0.__code__ = "test"
    middleware_func_0.__defaults__ = ()
    middleware_func_0.__dict__ = {}
    middleware_func_0.__doc__ = ""
    middleware_func_0.__kwdefaults__ = None
    middleware_func_0.__name__ = "test"
    middleware_func_0.__qualname__ = "test"

    middleware_mixin_0.middleware(middleware_func_0)
    setattr(middleware_mixin_0, "attach_to", lambda x: None)
    middleware_mixin_0