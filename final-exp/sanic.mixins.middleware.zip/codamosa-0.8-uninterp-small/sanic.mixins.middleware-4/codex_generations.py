

# Generated at 2022-06-26 03:37:50.363579
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    test_case_0()
    test_case_1()



# Generated at 2022-06-26 03:37:59.052650
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = None
    attach_to_0 = "request"
    apply_0 = True

    same_middleware_or_request = None
    same_attach_to_0 = "request"

    # Method middleware of the class MiddlewareMixin should return the function
    # register_middleware
    partial_result = middleware_mixin_0.middleware(middleware_or_request)
    assert partial_result == middleware_mixin_0.register_middleware(
        middleware_or_request, attach_to = same_attach_to_0)

    # Method middleware of the class MiddlewareMixin should return partial,
    # which return the function register_middleware

# Generated at 2022-06-26 03:38:02.052981
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    assert isinstance(middleware_mixin_0.on_response(), partial)


# Generated at 2022-06-26 03:38:05.578884
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    def func_middleware_0():
        middleware_mixin_0 = MiddlewareMixin()
        middleware_mixin_0.on_response()(middleware_0)


# Generated at 2022-06-26 03:38:11.170959
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    if middleware_mixin_1.on_request():
        print("Unit test for method on_request of class MiddlewareMixin is failed.")
    else:
        print("Unit test for method on_request of class MiddlewareMixin is passed.")


# Generated at 2022-06-26 03:38:13.486633
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    test_case_0()
    test_case_0()
    test_case_0()

# Generated at 2022-06-26 03:38:17.041035
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    assert callable(middleware_mixin_0.on_request())
    assert callable(middleware_mixin_0.on_request())


# Generated at 2022-06-26 03:38:21.517406
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    assert callable(middleware_mixin_0.on_request())
    assert callable(middleware_mixin_0.on_request)


# Generated at 2022-06-26 03:38:24.921892
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0.on_request() == partial(middleware_mixin_0.middleware, attach_to="request")


# Generated at 2022-06-26 03:38:29.316571
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    method_name = "MiddlewareMixin.on_request"
    method_to_test = MiddlewareMixin.on_request

    @method_to_test
    async def middleware_0(request):
        ...



# Generated at 2022-06-26 03:38:36.717006
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # GIVEN
    middleware_mixin_1 = MiddlewareMixin()
    # WHEN
    actual_return_value = middleware_mixin_1.on_request()
    # THEN
    assert actual_return_value.__name__ == "partial"


# Generated at 2022-06-26 03:38:39.538899
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin = MiddlewareMixin()
    assert callable(middleware_mixin.on_request())


# Generated at 2022-06-26 03:38:42.435506
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    def _f():
        pass
    result = middleware_mixin_0.on_request(_f)
    assert result is not None, 'Expected behavior did not occur'


# Generated at 2022-06-26 03:38:47.707461
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()

    # Check the method 'on_request' of class MiddlewareMixin

    # Call method 'on_request' of class MiddlewareMixin
    assert middleware_mixin_0.on_request is not None



# Generated at 2022-06-26 03:38:50.694203
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    return_value_0 = middleware_mixin_0.on_response()
    assert callable(return_value_0)


# Generated at 2022-06-26 03:39:02.814087
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    # Call method middleware of class MiddlewareMixin
    # with parameters
    # middleware_or_request = 123
    # attach_to = 'str'
    # apply = 123
    #
    # expected __return__ = None

    # Call method middleware of class MiddlewareMixin
    # with parameters
    # middleware_or_request = 123
    # attach_to = 'str'
    # apply = 123
    #
    # expected __return__ = None

    # Call method middleware of class MiddlewareMixin
    # with parameters
    # middleware_or_request = 123
    # attach_to = 'str'
    # apply = 123
    #
    # expected __return__ = None

    # Call method middleware of class MiddlewareMixin


# Generated at 2022-06-26 03:39:08.839423
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = None
    attach_to = "request"
    apply = True
    res = middleware_mixin_0.middleware(middleware_or_request, attach_to, apply)
    # assert res is not None
    # assert isinstance(res, partial)


# Generated at 2022-06-26 03:39:15.637916
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Initialization
    global middleware_mixin_o_r
    middleware_mixin_o_r  = MiddlewareMixin()
    
    # Function to test
    assert middleware_mixin_o_r.on_response() \
           == middleware_mixin_o_r.middleware(attach_to="response")
    assert middleware_mixin_o_r.on_response()(middleware) \
           == middleware_mixin_o_r.middleware(middleware, attach_to="response")
    
    
    
    


# Generated at 2022-06-26 03:39:23.463108
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    param_0 = middleware_mixin_0.on_request()
    assert(callable(param_0))
    assert(type(param_0) == partial)
    assert(param_0.func.__name__ == "middleware")
    assert(param_0.args == ())
    assert(param_0.keywords == {'attach_to': 'request'})


# Generated at 2022-06-26 03:39:29.050434
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_on_response')
    @app.middleware
    async def test(request):
        return request
    assert app._future_middleware[0].middleware == test
    assert app._future_middleware[0].attach_to == "response"
    assert app._future_middleware[0].apply == True


# Generated at 2022-06-26 03:39:39.021797
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    arg_0 = None
    arg_1 = "request"
    arg_2 = True
    # Call method middleware with the given arguments
    middleware_mixin_0.middleware(arg_0, arg_1, arg_2)


# Generated at 2022-06-26 03:39:40.734069
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_response()


# Generated at 2022-06-26 03:39:42.510183
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_response()


# Generated at 2022-06-26 03:39:46.534788
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request, attach_to="request")


# Generated at 2022-06-26 03:39:48.420957
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_response()

# Generated at 2022-06-26 03:39:50.786939
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
	middleware_mixin_0 = MiddlewareMixin()
	middleware_0 = lambda request, response: None
	assert middleware_mixin_0.on_response(middleware_0) == None


# Generated at 2022-06-26 03:39:52.417824
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert callable(MiddlewareMixin.on_response.__func__)


# Generated at 2022-06-26 03:39:55.821595
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import pytest

    # Arrange
    middleware_mixin_0 = MiddlewareMixin()

    # Assert
    with pytest.raises(NotImplementedError):
        middleware_mixin_0.middleware()



# Generated at 2022-06-26 03:39:58.891756
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = lambda request: None
    future_middleware_0 = middleware_mixin_0.middleware(middleware_0)



# Generated at 2022-06-26 03:40:01.276474
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_response()


# Generated at 2022-06-26 03:40:14.592402
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    def middleware_or_request_0():
        return 0
    attach_to_0 = 'request'
    apply_0 = True
    register_middleware_0 = partial(
        middleware_mixin_0._register_middleware, attach_to_0)
    if callable(middleware_or_request_0):
        method_result_0 = register_middleware_0(
            middleware_or_request_0, attach_to=attach_to_0)
    else:
        method_result_0 = partial(
            register_middleware_0, attach_to=middleware_or_request_0)

# Generated at 2022-06-26 03:40:17.795107
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request_0 = ""

# Generated at 2022-06-26 03:40:21.748694
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware('test')
    middleware_mixin_0.middleware(middleware_or_request='test_test', attach_to='test_test')


# Generated at 2022-06-26 03:40:27.065855
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(middleware_or_request=(), attach_to="request", 
                                  apply=True)
    middleware_mixin_1.middleware(middleware_or_request="request", attach_to="request", 
                                  apply=True)


# Generated at 2022-06-26 03:40:36.848281
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    @middleware_mixin_0.middleware
    def middleware_or_request_0():
        pass

    @middleware_mixin_0.middleware('request')
    def middleware_or_request_1():
        pass

    @middleware_mixin_0.middleware
    def middleware_or_request_2():
        pass

    @middleware_mixin_0.middleware('request')
    def middleware_or_request_3():
        pass

    @middleware_mixin_0.middleware('request')
    def middleware_or_request_4():
        pass

    @middleware_mixin_0.middleware('request')
    def middleware_or_request_5():
        pass


# Generated at 2022-06-26 03:40:41.167912
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    test_case_0()

# Generated at 2022-06-26 03:40:46.638211
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Create an instance of MiddlewareMixin
    middleware_mixin = MiddlewareMixin()
    middleware_mixin._future_middleware = []

    # Call method middleware of MiddlewareMixin class
    middleware_mixin.middleware('request')
    assert middleware_mixin._future_middleware == []



# Generated at 2022-06-26 03:40:51.353795
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Setup
    middleware_mixin = MiddlewareMixin()
    attach_to = "request"
    apply = True

    def middleware(request):
        return None

    # Exercise
    actual = middleware_mixin.middleware(middleware, attach_to, apply)

    # Verify
    assert callable(actual)


# Generated at 2022-06-26 03:40:54.202382
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()
    middleware_mixin_0.middleware()


# Generated at 2022-06-26 03:41:06.561684
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    logger_0 = logging.getLogger(__name__)
    rv_0 = middleware_mixin_0.middleware(logger_0)
    assert rv_0 == logger_0
    rv_1 = middleware_mixin_0.middleware('request')
    assert rv_1(logger_0) == logger_0
    middleware_mixin_1 = MiddlewareMixin()
    rv_2 = middleware_mixin_1.middleware(logger_0)
    assert rv_2 == logger_0
    rv_3 = middleware_mixin_1.middleware('response')
    assert rv_3(logger_0) == logger_0

# Generated at 2022-06-26 03:41:17.253769
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    result_0 = middleware_mixin_0.middleware()
    assert isinstance(result_0, partial)


# Generated at 2022-06-26 03:41:21.722348
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    def function_1(middleware_or_request, attach_to="request", apply=True):
        pass

    # Call with same parameters
    # N/A

    # Call with distinct parameters
    # N/A

    # Call with distinct parameters
    # N/A



# Generated at 2022-06-26 03:41:24.339014
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()
    middleware_mixin_0.middleware('request')


# Generated at 2022-06-26 03:41:26.612140
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()



# Generated at 2022-06-26 03:41:35.281785
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request_0 = None
    attach_to_0 = "request"
    apply_0 = True
    register_middleware_0 = middleware_mixin_0.middleware(middleware_or_request_0, attach_to=attach_to_0, apply=apply_0)
    try:
        middleware_0 = None
        attach_to_1 = "request"
        register_middleware_0(middleware_0, attach_to=attach_to_1)
    except NotImplementedError as err:
        print(err)


# Generated at 2022-06-26 03:41:42.729709
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()

    test_middleware_0 = middleware_mixin_1.middleware(None, "request", True)
    assert isinstance(test_middleware_0, partial), f"{repr(test_middleware_0)}"
    assert callable(test_middleware_0), f"{repr(test_middleware_0)}"
    assert test_middleware_0.func == middleware_mixin_1.middleware, f"{repr(test_middleware_0)}"



# Generated at 2022-06-26 03:41:45.670736
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware("request")
    middleware_mixin_0.middleware("response")


# Generated at 2022-06-26 03:41:55.599329
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    
    # Test case when middleware_or_request is callable and attach_to is request.
    f = MiddlewareMixin().middleware
    middleware_or_request = lambda x: x
    attach_to = 'request'
    assert f(middleware_or_request, attach_to) == middleware_or_request
    
    # Test case when middleware_or_request is callable and attach_to is response.
    f = MiddlewareMixin().middleware
    middleware_or_request = lambda x: x
    attach_to = 'response'
    assert f(middleware_or_request, attach_to) == middleware_or_request
    
    # Test case when middleware_or_request is not callable, attach_to is request.

# Generated at 2022-06-26 03:41:59.777527
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    print("test_MiddlewareMixin_middleware")

    def response_middleware(request, response):
        return True

    def request_middleware(request):
        return True

    middleware_mixin_0 = MiddlewareMixin()

    middleware_mixin_0.middleware(response_middleware, "response")
    middleware_mixin_0.middleware(request_middleware, "request")

    assert len(middleware_mixin_0._future_middleware) == 2



# Generated at 2022-06-26 03:42:02.836782
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    @middleware_mixin_0.middleware
    def hello_world(request):
        pass
    @middleware_mixin_0.middleware("request")
    def hello_world(request):
        pass


# Generated at 2022-06-26 03:42:19.713077
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    arg_0 = middleware_mixin_0.on_request()

    assert callable(arg_0)



# Generated at 2022-06-26 03:42:24.488799
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_1 = middleware_mixin_1.middleware(
        middleware_or_request='request'
    )
    middleware_1()
    assert isinstance(middleware_mixin_1._future_middleware, list)


# Generated at 2022-06-26 03:42:27.977768
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = MiddlewareMixin()
    partial_0 = middleware_mixin_0.middleware(middleware_0)
    assert partial_0 is not None


# Generated at 2022-06-26 03:42:39.780928
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()

    def a():
        return 'a'

    def b():
        return 'b'

    assert middleware_mixin_1._future_middleware == []
    middleware_mixin_1.middleware(a)
    assert middleware_mixin_1._future_middleware[0].middleware == a

    middleware_mixin_1.middleware(b, 'response')
    assert middleware_mixin_1._future_middleware[1].attach_to == 'response'

    middleware_mixin_1.middleware(b, apply=False)
    assert middleware_mixin_1._future_middleware[2].attach_to == 'request'
    assert middleware_mixin_1._future_middleware[2].middleware == b

# Generated at 2022-06-26 03:42:41.314004
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    expected = 'foo'
    actual = middleware_mixin_0.middleware(expected)
    assert actual == expected



# Generated at 2022-06-26 03:42:43.697809
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = middleware_mixin_0.middleware(None)
    assert type(middleware_0) is partial

# Generated at 2022-06-26 03:42:53.012445
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    def _register_middleware(middleware, attach_to="request"):
        nonlocal apply

        future_middleware = FutureMiddleware(middleware, attach_to)
        self._future_middleware.append(future_middleware)
        if apply:
            self._apply_middleware(future_middleware)
        return middleware

    # Detect which way this was called, @middleware or @middleware('AT')
    if callable(middleware_or_request):
        return _register_middleware(middleware_or_request, attach_to=attach_to)
    else:
        return partial(_register_middleware, attach_to=middleware_or_request)



# Generated at 2022-06-26 03:42:59.884297
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request: str = "request"
    attach_to: str = "request"
    apply: bool = True
    middleware_mixin_0.middleware(middleware_or_request, attach_to, apply)


# Generated at 2022-06-26 03:43:04.048035
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_func_1 = lambda x: x
    middleware_or_request_1 = "request"
    attachment_1 = middleware_mixin_1.middleware(middleware_or_request_1)(
        middleware_func_1
    )
    assert middleware_mixin_1._future_middleware == [
        FutureMiddleware(middleware_func_1, "request")
    ]


# Generated at 2022-06-26 03:43:14.598010
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    # middleware of class MiddlewareMixin with arguments:
    # middleware=middleware_or_request_0, attach_to=attach_to_0
    # test 0
    middleware_or_request_0 = mock.Mock(side_effect=KeyError)
    attach_to_0 = 'wQZf_6(r'
    middleware_mixin_0.middleware(
        middleware_or_request_0, attach_to=attach_to_0
    )
    # test 1
    middleware_or_request_0 = mock.Mock(side_effect=KeyError)
    attach_to_0 = ''