

# Generated at 2022-06-26 03:37:54.640233
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # Case 1: run the test with middleware("request")
    middleware_mixin_0.middleware("request")
    # Case 2: run the test with middleware("response")
    middleware_mixin_0.middleware("response")


# Generated at 2022-06-26 03:37:58.186381
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware = lambda arg: arg
    assert middleware_mixin_1.middleware(middleware)() == middleware
    assert middleware_mixin_1.middleware(middleware, "request")() == middleware


# Generated at 2022-06-26 03:38:00.771150
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_request()


# Generated at 2022-06-26 03:38:05.578508
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request=None, attach_to="request", apply=True)


# Generated at 2022-06-26 03:38:13.306129
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Test case #0
    middleware_mixin_0 = MiddlewareMixin()

    assert middleware_mixin_0._future_middleware == []

    # Test case #1
    middleware_mixin_1 = MiddlewareMixin()
    def test_func_0():
        pass

    middleware_mixin_1.middleware(test_func_0)
    assert len(middleware_mixin_1._future_middleware) == 1


# Generated at 2022-06-26 03:38:18.355269
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware("request")
    middleware_mixin_1.middleware("response")
    middleware_mixin_1.middleware("request", "request")
    middleware_mixin_1.middleware("response", "response")
    middleware_mixin_1.middleware("request", "response")
    middleware_mixin_1.middleware("response", "request")


# Generated at 2022-06-26 03:38:23.919966
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_request()

    # Call the function on_request of the object middleware_mixin_0
    middleware_mixin_0.on_request()



# Generated at 2022-06-26 03:38:27.986290
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    middleware = lambda request: request
    middleware_mixin_1.on_request(middleware)

# Generated at 2022-06-26 03:38:32.303505
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    # Test 1: input = middleware_or_request="test", attach_to="test", apply=True
    middleware_mixin_1 = MiddlewareMixin()
    middleware_1 = middleware_mixin_1.middleware(
        middleware_or_request="test", attach_to="test", apply=True
    )


# Generated at 2022-06-26 03:38:35.936980
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    if isinstance(middleware_mixin_1.middleware, collections.abc.Callable):
        assert True
    else:
        assert False


# Generated at 2022-06-26 03:38:43.214846
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_or_request_2 = None
    attach_to_2 = "request"
    apply_2 = True

    @middleware_mixin_1.middleware(middleware_or_request_2, attach_to_2, apply_2)
    def middleware_3(request_3, *args_3, **kwargs_3):
        pass
    
    middleware_or_request_4 = None

    @middleware_mixin_1.middleware(middleware_or_request_4)
    def middleware_5(request_5, *args_5, **kwargs_5):
        pass
    


# Generated at 2022-06-26 03:38:48.853047
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request_0 = middleware_mixin_0
    attach_to_0 = middleware_mixin_0
    middleware_mixin_0.middleware(middleware_or_request_0, attach_to_0)


# Generated at 2022-06-26 03:38:55.199555
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
  # Default case (callable middleware)
  middleware_mixin_0 = MiddlewareMixin()
  middleware_or_request = lambda *args, **kwargs: 0
  attach_to = 'request'
  middleware_mixin_0.middleware(middleware_or_request, attach_to)
  
  # Default case (non-callable middleware)
  middleware_mixin_0 = MiddlewareMixin()
  middleware_or_request = 'request'
  attach_to = 'request'
  middleware_mixin_0.middleware(middleware_or_request, attach_to)
  
  # Default case (callable middleware)
  middleware_mixin_0 = MiddlewareMixin()
  middleware_or_request = lambda *args, **kwargs: 0
 

# Generated at 2022-06-26 03:39:01.180926
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    future_middleware_0 = FutureMiddleware()
    def attach_to():
        future_middleware_0.attach_to = "response"
    attach_to()
    middleware_mixin_0.middleware(future_middleware_0)


# Generated at 2022-06-26 03:39:08.469628
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    class TestClass(MiddlewareMixin):

        def __init__(self):
            super(TestClass, self).__init__()

        def _apply_middleware(self, middleware):
            self._future_middleware.append(middleware)

    middleware_mixin = TestClass()
    middleware = 1

    # Call method
    middleware_mixin.middleware(middleware)
    assert middleware_mixin._future_middleware[0].middleware == middleware



# Generated at 2022-06-26 03:39:12.558954
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Tests that middleware method can be used as a decorator
    @MiddlewareMixin().middleware
    def dummy_middleware(request):
        pass

    # Tests that middleware method can be used via partial
    MiddlewareMixin().middleware(dummy_middleware)


# Generated at 2022-06-26 03:39:15.318404
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = MiddlewareMixin()

#    middleware_mixin_1.middleware(middleware_mixin_2._apply_middleware)
    middleware_mixin_1.middleware(middleware_mixin_2)


# Generated at 2022-06-26 03:39:17.643457
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(None)

# Generated at 2022-06-26 03:39:28.517825
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    @middleware_mixin_0.middleware
    def middleware1(request):
        return request

    @middleware_mixin_0.middleware('request')
    def middleware2(request):
        return request

    @middleware_mixin_0.on_request
    def middleware3(request):
        return request

    @middleware_mixin_0.on_response
    def middleware4(request, response):
        return response

    middleware_mixin_0.middleware(middleware=middleware4)
    middleware_mixin_0.on_request(middleware=middleware3)
    middleware_mixin_0.middleware(middleware=[middleware1, middleware2])

# Generated at 2022-06-26 03:39:38.869495
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Initiate test data
    middleware_0 = MiddlewareMixin()
    request_1 = None
    attach_to_2 = "request"
    apply_3 = True
    middleware_4 = FutureMiddleware(attach_to=attach_to_2)
    middleware_mixin_0 = MiddlewareMixin()

    # Test method
    @middleware_mixin_0.middleware
    def fxn():
        return 

    assert middleware_mixin_0._future_middleware[0] == middleware_4

    fxn = middleware_mixin_0.middleware(middleware_4, attach_to_2, apply_3)
    assert middleware_mixin_0._future_middleware[0] == middleware_4

    # Del the var
    del middleware_0

# Generated at 2022-06-26 03:39:48.834122
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_1 = MiddlewareMixin()
    
    middleware_mixin_1.middleware(middleware_or_request=middleware_mixin_0, attach_to="response")

    #assert middleware_mixin_1.middleware == middleware_mixin_0

    def func():
        return middleware_mixin_1
    
    assert func() == middleware_mixin_1

# Generated at 2022-06-26 03:39:53.821499
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_or_request_2 = None
    attach_to_3 = 'request'
    apply_4 = True
    middleware_5 = middleware_mixin_1.middleware(middleware_or_request_2, attach_to_3, apply_4)
    middleware_0 = lambda request: None
    attach_to_1 = 'request'
    middleware_2 = middleware_5(middleware_0, attach_to_1)
    assert middleware_2 == None
    assert middleware_mixin_1._future_middleware == [FutureMiddleware(middleware_0, 'request')]

# Generated at 2022-06-26 03:39:57.035637
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(middleware_or_request=None, attach_to="request", apply=True)



# Generated at 2022-06-26 03:40:08.858639
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    #
    # Test exception
    #

    middleware_mixin_0 = MiddlewareMixin()
    try:
        middleware_mixin_0._apply_middleware(None)
        raise AssertionError("AssertionError")
    except NotImplementedError:
        pass

    #
    # Test valid path
    #

    def test_middleware(request):
        try:
            assert isinstance(request, dict)
            return request
        except AssertionError:
            raise AssertionError("AssertionError")

    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            assert len(self._future_middleware) == 1
            assert isinstance(middleware, FutureMiddleware)

    test_middleware_mix

# Generated at 2022-06-26 03:40:14.433063
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_1 = FutureMiddleware(lambda *arg_1, **kwargs_1: None, attach_to='request')
    middleware_mixin_0._apply_middleware(middleware_1)
    future_middleware_0 = middleware_mixin_0._future_middleware[0]
    assert middleware_1 == future_middleware_0


# Generated at 2022-06-26 03:40:17.715003
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    def middleware(request, response):
        pass

    # middleware
    middleware_0 = middleware_mixin_0.middleware(middleware)


# Generated at 2022-06-26 03:40:28.804830
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0._apply_middleware(FutureMiddleware(middleware=lambda: None))
    middleware_mixin_0.middleware()
    middleware_mixin_0.middleware(middleware_or_request=lambda: None)
    middleware_mixin_0.middleware(middleware_or_request=lambda: None, attach_to='request')
    middleware_mixin_0.middleware(middleware_or_request=lambda: None, attach_to='response')
    middleware_mixin_0.middleware('request')
    middleware_mixin_0.middleware('response')
    middleware_mixin_0.middleware(middleware_or_request='request')

# Generated at 2022-06-26 03:40:34.647621
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0._future_middleware == []

    @middleware_mixin_0.middleware('request')
    async def middleware(request):
        print(request)

    assert middleware_mixin_0._future_middleware[0].value == middleware
    assert middleware_mixin_0._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-26 03:40:37.653551
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def foo_0():
        try:
            assert False
        except:
            MiddlewareMixinTestError()
    middleware_mixin_0.middleware(foo_0)
    

# Generated at 2022-06-26 03:40:38.115505
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-26 03:40:48.719334
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    args = ["request"]
    kwargs = {}
    attach_to_0 = middleware_mixin_0.middleware(*args, **kwargs)


# Generated at 2022-06-26 03:40:55.039430
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Proxy(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)

    proxy = Proxy()
    middleware_0: FutureMiddleware = FutureMiddleware(None, "request")
    proxy.middleware(middleware_0)
    assert len(proxy._future_middleware) == 1
    assert proxy._future_middleware[0] == middleware_0


# Generated at 2022-06-26 03:40:59.117836
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # Test Exception
    with pytest.raises(Exception) as e:
        middleware_mixin_0.middleware()


# Generated at 2022-06-26 03:41:05.238478
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Define arguments
    middleware_or_request = object
    attach_to = "request"
    apply = True

    # Obtain the target instance
    middleware_mixin_0 = MiddlewareMixin()


    # Call the function
    middleware_mixin_0.middleware(middleware_or_request, attach_to, apply)



# Generated at 2022-06-26 03:41:07.007176
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(attach_to="request")


# Generated at 2022-06-26 03:41:14.533129
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_middleware_or_request_0 = lambda middleware, request: middleware(
        request
    )
    middleware_middleware_or_request_1 = lambda request: request
    try:
        middleware_mixin_0.middleware(
            middleware_middleware_or_request_0, attach_to="request", apply=True
        )
    except NotImplementedError:
        pass
    except Exception as e:
        print('Exception in test_MiddlewareMixin_middleware()')
        print(e)
        raise


# Generated at 2022-06-26 03:41:20.284591
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware()
    middleware_mixin_1.middleware('hello')
    middleware_mixin_1.middleware(middleware = 'hi', attach_to = 'hello')
    middleware_mixin_1.middleware(middleware = 'hi', apply = 'hello')


# Generated at 2022-06-26 03:41:25.843517
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request_0 = None
    attach_to_0 = None
    apply_0 = None
    try:
        middleware_mixin_0.middleware(middleware_or_request_0, attach_to_0, 
            apply_0)
    except NotImplementedError:
        pass


# Generated at 2022-06-26 03:41:30.728479
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = 'middleware_or_request'
    attach_to = 'attach_to'
    apply = True
    middleware_mixin_0.middleware(middleware_or_request, attach_to, apply)



# Generated at 2022-06-26 03:41:37.598621
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request_arg = None
    attach_to_arg = "attach_to_arg"
    apply_arg = True
    callable_arg = None

    # Call the method
    middleware_mixin_0.middleware(
        middleware_or_request=middleware_or_request_arg,
        attach_to=attach_to_arg,
        apply=apply_arg
    )

    # Call the method
    middleware_mixin_0.middleware(callable_arg)



# Generated at 2022-06-26 03:41:49.127467
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-26 03:41:51.028510
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()


# Generated at 2022-06-26 03:41:57.628846
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    def test_function_0():
        pass

    test_function_0 = middleware_mixin_0.middleware(test_function_0)
    assert callable(test_function_0)

    test_function_1 = middleware_mixin_0.middleware(attach_to='request')(
        test_function_0
    )
    assert callable(test_function_1)

    test_function_2 = middleware_mixin_0.middleware(test_function_0, 'response')
    assert callable(test_function_2)


# Generated at 2022-06-26 03:41:58.310804
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()

# Generated at 2022-06-26 03:42:00.304972
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(None)


# Generated at 2022-06-26 03:42:01.140515
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()


# Generated at 2022-06-26 03:42:03.569729
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    @middleware_mixin_0.middleware('request')
    def middleware_0():
        pass



# Generated at 2022-06-26 03:42:11.358224
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1._future_middleware = [FutureMiddleware(middleware_mixin_1, "request")]
    middleware_mixin_1._future_middleware.append(FutureMiddleware(middleware_mixin_1, "request"))
    middleware_mixin_1.middleware(middleware_mixin_1, "request")


# Generated at 2022-06-26 03:42:16.623089
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()

    # Define function to replace function-under-test
    def _mock_middleware(middleware, attach_to):
        # mock action
        pass

    setattr(middleware_mixin, "_apply_middleware", _mock_middleware)

    # Create test variables
    b = middleware_mixin
    a = MiddlewareMixin()

    # Call function-under-test
    res = b.middleware(a)

    # Unit test assertions
    assert res is not None


# Generated at 2022-06-26 03:42:17.467255
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-26 03:42:40.080750
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    middleware = middleware_mixin.middleware


# Generated at 2022-06-26 03:42:46.069060
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    def middleware_or_request_0(request, response):
        return response
    middleware_mixin_1.middleware(middleware_or_request_0)
    assert len(middleware_mixin_1._future_middleware) == 1

    def middleware_or_request_1(request, response):
        return response
    middleware_mixin_1.middleware(middleware_or_request_1, attach_to="response")
    assert len(middleware_mixin_1._future_middleware) == 2



# Generated at 2022-06-26 03:42:50.502612
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(attach_to = "request")


# Generated at 2022-06-26 03:42:51.689244
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()


# Generated at 2022-06-26 03:42:53.763619
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # Call the method
    middleware_mixin_0.middleware(None, None)


# Generated at 2022-06-26 03:42:57.055788
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def register_middleware(attach_to):
        return attach_to
    with pytest.raises(NotImplementedError):
        #middleware_mixin_0._apply_middleware("default")
        middleware_mixin_0.middleware = register_middleware
        #middleware_mixin_0.middleware("default")


# Generated at 2022-06-26 03:42:59.254734
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert True

# Generated at 2022-06-26 03:43:05.288472
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_3 = MiddlewareMixin()

    assert middleware_mixin_0._future_middleware == []
    assert middleware_mixin_1._future_middleware == []
    assert middleware_mixin_2._future_middleware == []
    assert middleware_mixin_3._future_middleware == []

    def middleware(request, response): pass
    def middleware_1(request, response): pass
    def middleware_2(request, response): pass
    def middleware_3(request, response): pass

    assert middleware_mixin_0.middleware(middleware) == middleware
   

# Generated at 2022-06-26 03:43:07.795908
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    assert middleware_mixin_1 is not None


# Generated at 2022-06-26 03:43:18.566810
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request=None)
    middleware_mixin_0.middleware(middleware_or_request=None, attach_to="request")
    middleware_mixin_0.middleware(middleware_or_request=None, attach_to="response")
    middleware_mixin_0.middleware(middleware_or_request=None,
                                  attach_to="request", apply=True)
    middleware_mixin_0.middleware(middleware_or_request=None,
                                  attach_to="response", apply=True)
    middleware_mixin_0.on_request(None)
    middleware_mixin_0.on_response(None)


# Generated at 2022-06-26 03:44:05.911671
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    # Case 1:
    @middleware_mixin_0.middleware('response')
    def middleware_response_0(request):
        pass
    assert middleware_mixin_0._future_middleware[0].middleware == middleware_response_0
    assert middleware_mixin_0._future_middleware[0].attach_to == "response"

    # Case 2:
    @middleware_mixin_0.middleware('request')
    def middleware_request_0(request):
        pass
    assert middleware_mixin_0._future_middleware[1].middleware == middleware_request_0
    assert middleware_mixin_0._future_middleware[1].attach_to == "request"

    # Case 3:


# Generated at 2022-06-26 03:44:08.448475
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    result = middleware_mixin_0.middleware('request')


# Generated at 2022-06-26 03:44:19.598799
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    # Valid input - Variable(bool) - False
    middleware_or_request_0 = False
    attach_to_0 = "request"
    apply_0 = False
    test_0 = middleware_mixin_0.middleware(middleware_or_request_0, attach_to_0, apply_0)

    assert callable(test_0)

    # Valid input - Variable(bool) - True
    middleware_or_request_1 = True
    attach_to_1 = adjust_request
    apply_1 = True
    test_1 = middleware_mixin_0.middleware(middleware_or_request_1, attach_to_1, apply_1)

    assert callable(test_1)

    # Valid input - Variable(str

# Generated at 2022-06-26 03:44:22.213754
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # MiddlewareMixin.middleware is a property.
    raise SkipTest  # TODO: implement your test here



# Generated at 2022-06-26 03:44:23.473455
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()

# Generated at 2022-06-26 03:44:29.148713
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = None
    attach_to = "request"
    apply = True
    register_middleware = middleware_mixin_0.middleware(middleware_or_request, attach_to, apply)


# Generated at 2022-06-26 03:44:40.247307
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from random import randrange
    from python_pack_utilities import invoke_method_inherited

    from sanic.config import Config
    from sanic.models.middleware import Middleware
    from sanic.models.futures import FutureMiddleware

    class MockMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    # Initialization:
    middleware_mixin_0 = MockMiddlewareMixin()
    middleware_0 = Middleware(None, None)
    config_0 = Config()
    # Test method calls:
    future_middleware_0 = middleware_mixin_0.middleware(middleware_0)
   

# Generated at 2022-06-26 03:44:44.732131
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    t = MiddlewareMixin()
    t.middleware = {}
    assert isinstance(t.middleware, dict)


# Generated at 2022-06-26 03:44:46.257249
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()



# Generated at 2022-06-26 03:44:49.296207
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # o = MiddlewareMixin()
    result = MiddlewareMixin.middleware("self","middleware_or_request","attach_to")
    assert_equals(result, "Need to implement test")


# Generated at 2022-06-26 03:46:24.553865
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    middleware = middleware_mixin.middleware(None, None)
    middleware = middleware_mixin.middleware("request", None, True)
    middleware(None)



# Generated at 2022-06-26 03:46:25.500883
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()


# Generated at 2022-06-26 03:46:26.188204
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass



# Generated at 2022-06-26 03:46:37.050676
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = MiddlewareMixin()

    def register_middleware(middleware, attach_to="request"):
        nonlocal apply

        future_middleware = FutureMiddleware(middleware, attach_to)
        middleware_mixin_1._future_middleware.append(future_middleware)
        if apply:
            middleware_mixin_1._apply_middleware(future_middleware)
        return middleware


    def middleware_or_request(middleware_or_request, attach_to="request", apply=True):
        if callable(middleware_or_request):
            return register_middleware(middleware_or_request, attach_to=attach_to)

# Generated at 2022-06-26 03:46:40.668177
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    args = (1,)
    kwargs = {'arg1':'val1'}
    middleware_mixin_1 = MiddlewareMixin(*args, **kwargs)
    middleware_middleware = middleware_mixin_1.middleware
    middleware_middleware_result = middleware_middleware(middleware_or_request=1, attach_to='request', apply=True)
    assert callable(middleware_middleware_result)


# Generated at 2022-06-26 03:46:42.236826
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0._apply_middleware = lambda x: None


# Generated at 2022-06-26 03:46:52.359710
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    callable_0 = lambda : None
    str_0 = middleware_mixin_0.middleware(callable_0)
    str_1 = middleware_mixin_0.middleware(callable_0, "request")
    str_2 = middleware_mixin_0.middleware("request")
    str_3 = middleware_mixin_0.middleware("response")
    str_4 = middleware_mixin_0.middleware(callable_0, "response")
    assert str_0 is callable_0
    assert str_1 is callable_0
    assert str_2 is callable_0
    assert str_3 is callable_0
    assert str_4 is callable_0


# Generated at 2022-06-26 03:46:52.987058
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

# Generated at 2022-06-26 03:46:54.246783
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()


# Generated at 2022-06-26 03:46:58.327226
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Create an instance of MiddlewareMixin
    middleware_mixin_1 = MiddlewareMixin()
    # Verify that a call of method middleware of middleware_mixin_1 raises
    # the exception NotImplementedError
    try:
        middleware_mixin_1.middleware()
        raise AssertionError(
            "The method middleware of class MiddlewareMixin didn't raise "
            "the exception NotImplementedError"
        )
    except NotImplementedError:
        pass

