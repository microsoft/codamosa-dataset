

# Generated at 2022-06-26 03:37:59.788357
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    mb_1 = middleware_mixin_0.middleware()
    def mw_0(*args, **kwargs):
        pass
    mb_1(mw_0)
    mb_0 = middleware_mixin_0.middleware(attach_to="response")
    var_0 = middleware_mixin_0.on_response(mw_0)
    # mb_0(mw_0) #Error: TypeError: register_middleware() missing 1 required positional argument: 'middleware'
    # var_0(mw_0) #Error: TypeError: register_middleware() missing 1 required positional argument: 'middleware'

test_MiddlewareMixin_middleware()

# Generated at 2022-06-26 03:38:03.229844
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    var_1 = middleware_mixin_1.on_request()
    var_2 = middleware_mixin_1.on_response()

# Generated at 2022-06-26 03:38:05.189217
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    var_0 = middleware_mixin_0.middleware()


# Generated at 2022-06-26 03:38:07.350873
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    var_1 = middleware_mixin_1.middleware()

# Generated at 2022-06-26 03:38:11.494477
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def func_0():
        nonlocal middleware_mixin_0



# Generated at 2022-06-26 03:38:14.126473
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    var_0 = middleware_mixin_0.middleware("request")
    var_0.__name__ += " "

# Generated at 2022-06-26 03:38:22.226923
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    count = 0
    middleware_mixin_0 = MiddlewareMixin()

    # Call middleware as @app.middleware('request')
    decorator_0 = middleware_mixin_0.middleware('request')
    def middleware_0(request):
        return
    decorator_0(middleware_0)

    # Call middleware as @app.middleware
    decorator_1 = middleware_mixin_0.middleware
    def middleware_1(request):
        return
    decorator_1(middleware_1)



# Generated at 2022-06-26 03:38:32.455471
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    Foo = MiddlewareMixin()
    # Test of a callable object
    #    Test of a callable object
    #    Test of a callable object
    #    Test of a callable object
    #    Test of a callable object
    #    Test of a callable object
    #    Test of a callable object
    #    Test of a callable object
    #    Test of a callable object
    #    Test of a callable object
    #    Test of a callable object
    #    Test of a callable object
    #    Test of a callable object
    #    Test of a callable object
    #    Test of a callable object
    #    Test of a callable object
    #    Test of a callable object
    #    Test of a callable object
    #    Test of a callable object
   

# Generated at 2022-06-26 03:38:42.698073
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """
    Test middleware method of class MiddlewareMixin
    """

    # Create a MiddlewareMixin object
    middleware_mixin_0 = MiddlewareMixin()

    # Call method middleware of object middleware_mixin_0
    var_0 = middleware_mixin_0.middleware()

    # Call method middleware of object middleware_mixin_0
    var_1 = middleware_mixin_0.middleware()

    # Call method middleware of object middleware_mixin_0
    var_2 = middleware_mixin_0.middleware()

    # Call method middleware of object middleware_mixin_0
    var_3 = middleware_mixin_0.middleware()

    # Call method middleware of object middleware_mixin_0
    var_4 = middleware_

# Generated at 2022-06-26 03:38:47.570969
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_func = lambda : None

    middleware_mixin_0 = MiddlewareMixin()
    result_0 = middleware_mixin_0.middleware(middleware_func)

    assert result_0 is middleware_func


# Generated at 2022-06-26 03:38:51.369670
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    middleware_mixin.middleware(middleware_or_request='request')


# Generated at 2022-06-26 03:38:58.708848
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from unittest.mock import patch
    middleware_mixin_1 = MiddlewareMixin()

    # Case 1 - test middleware method
    with patch.object(
        middleware_mixin_1, "_apply_middleware", return_value=None
    ) as mock_apply_middleware:
        middleware_mixin_1.middleware(
            lambda request: None, attach_to="request", apply=True
        )

# Generated at 2022-06-26 03:39:05.118351
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    future_middleware_0 = middleware_mixin_1.middleware(middleware_mixin_1)
    assert isinstance(future_middleware_0, MiddlewareMixin)

    future_middleware_1 = middleware_mixin_1.middleware(middleware_mixin_1, middleware_mixin_1)
    assert isinstance(future_middleware_1, MiddlewareMixin)


# Generated at 2022-06-26 03:39:11.599284
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    sanic_0 = middleware_mixin_1.middleware(middleware_or_request=None, attach_to=None, apply=True)
    sanic_1 = middleware_mixin_1.middleware(middleware_or_request=lambda response: response, attach_to='request', apply=True)


# Generated at 2022-06-26 03:39:16.753976
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert len(middleware_mixin_0._future_middleware) == 0

    def func_0_middleware_0_request(request):
        return request

    func_0_middleware_0_request = middleware_mixin_0.middleware(
        func_0_middleware_0_request
    )
    assert len(middleware_mixin_0._future_middleware) == 1

# Generated at 2022-06-26 03:39:28.362134
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Test if 'MiddlewareMixin.middleware' raises an exception when called without arguments
    with pytest.raises(TypeError):
        MiddlewareMixin().middleware()

    # Test if 'MiddlewareMixin.middleware' raises an exception when called with arguments
    #   'middleware_or_request' of wrong types
    with pytest.raises(TypeError):
        MiddlewareMixin().middleware(middleware_or_request='')

    with pytest.raises(TypeError):
        MiddlewareMixin().middleware(middleware_or_request=0)

    with pytest.raises(TypeError):
        MiddlewareMixin().middleware(middleware_or_request=())


# Generated at 2022-06-26 03:39:34.298577
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    # Parameter attach_to is function return the string "request"
    def attach_to():
        return "request"

    # Parameter middleware is function no paramaters and return None
    def middleware():
        return None

    with pytest.raises(NotImplementedError):
        middleware_mixin_0.middleware(middleware=middleware, attach_to=attach_to)



# Generated at 2022-06-26 03:39:38.524125
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware = middleware_mixin_0.middleware
    # middleware = middleware_mixin_0.middleware('request')



# Generated at 2022-06-26 03:39:41.125071
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Test for method middleware of class MiddlewareMixin (1 of 2)
    middleware_mixin_0 = MiddlewareMixin()
    x_0_0_0 = middleware_mixin_0.middleware()


# Generated at 2022-06-26 03:39:43.942374
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    @middleware_mixin_0.middleware()
    def check_if_authenticated(request):
        request['user'] = 'Michael'
        return request


# Generated at 2022-06-26 03:39:51.113479
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def middleware_or_request_0():
        pass
    attach_to_0 = "request"
    apply_0 = True
    middleware_0 = middleware_mixin_0.middleware(middleware_or_request_0, attach_to=attach_to_0, apply=apply_0)
    from sanic.models.futures import FutureMiddleware
    assert isinstance(middleware_0, FutureMiddleware)


# Generated at 2022-06-26 03:39:55.861250
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    def mw():
        pass
    middleware_mixin_1.middleware(mw)
    middleware_mixin_1.middleware(mw, 'request')
    mw_partial = middleware_mixin_1.middleware('request')
    mw_partial(mw)


# Generated at 2022-06-26 03:40:03.706936
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Create an instance of MiddlewareMixin
    middleware_mixin_1 = MiddlewareMixin()
    # Test the default value of parameter middleware_or_request
    assert middleware_mixin_1.middleware() == partial(middleware_mixin_1.middleware, attach_to='request')
    # Test the default value of parameter attach_to
    assert middleware_mixin_1.middleware() == partial(middleware_mixin_1.middleware, attach_to='request')


# Generated at 2022-06-26 03:40:11.981519
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    partial_middleware_0 = partial(middleware_mixin_0.middleware, attach_to="request")
    partial_on_request_0 = partial(middleware_mixin_0.on_request)
    partial_on_response_0 = partial(middleware_mixin_0.on_response)
    partial_middleware__1 = partial(middleware_mixin_0.middleware, attach_to="response")
    partial_middleware_1 = partial(partial_middleware__1, attach_to="request")


# Generated at 2022-06-26 03:40:14.591120
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    assert middleware_mixin_0._apply_middleware is None
    assert middleware_mixin_0._future_middleware is None



# Generated at 2022-06-26 03:40:16.199949
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()



# Generated at 2022-06-26 03:40:22.143356
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_1 = middleware_mixin_0.middleware
    middleware_2 = middleware_mixin_0.on_request
    middleware_3 = middleware_mixin_0.on_response
    assert middleware_1 is not None
    assert middleware_2 is not None
    assert middleware_3 is not None

# Generated at 2022-06-26 03:40:25.789349
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(middleware_or_request=None, attach_to="request")


# Generated at 2022-06-26 03:40:35.685378
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()

    middleware = middleware_mixin.middleware
    m_middleware = middleware_mixin.middleware
    m_middleware_request = middleware_mixin.middleware.request
    m_middleware_response = middleware_mixin.middleware.response
    m_middleware_attach_to = middleware_mixin.middleware.attach_to
    m_middleware_attach_to_request = middleware_mixin.middleware.attach_to.request
    m_middleware_attach_to_response = middleware_mixin.middleware.attach_to.response

    f = middleware(attach_to="request")
    f = m_middleware(attach_to="request")
    f = m_middleware_request()
    f = m

# Generated at 2022-06-26 03:40:37.342644
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert callable(middleware_mixin_0.middleware)


# Generated at 2022-06-26 03:40:43.106162
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = lambda request: None
    middleware_mixin_0.middleware(middleware_0)

# Generated at 2022-06-26 03:40:54.756096
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def lambda_0():
        middleware_0 = lambda_0
        attach_to_0 = "request"
        def lambda_1():
            nonlocal apply_0
            future_middleware_0 = FutureMiddleware(middleware_0, attach_to_0)
            middleware_mixin_0._future_middleware.append(future_middleware_0)
            if apply_0:
                middleware_mixin_0._apply_middleware(future_middleware_0)
            return middleware_0
        apply_0 = True
        return lambda_1()
    def lambda_2():
        nonlocal attach_to_0
        return partial(lambda_2, attach_to=attach_to_0)

# Generated at 2022-06-26 03:41:06.906488
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # Test case 0:
    def middleware_or_request_0():
        pass
    attach_to_0 = "request"
    return_value_0 = middleware_mixin_0.middleware(
        middleware_or_request=middleware_or_request_0, attach_to=attach_to_0
    )
    # Test case 1:
    def middleware_or_request_1():
        pass
    attach_to_1 = "request"
    return_value_1 = middleware_mixin_0.middleware(
        middleware_or_request=middleware_or_request_1, attach_to=attach_to_1
    )
    # Test case 2:

# Generated at 2022-06-26 03:41:12.387786
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    callback_0 = lambda x, y, z: None
    attach_to_0 = ""
    middleware_mixin_0.middleware(middleware_or_request=callback_0, attach_to=attach_to_0)


# Generated at 2022-06-26 03:41:23.590860
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    def register_middleware(middleware, attach_to="request"):
        nonlocal apply

        future_middleware = FutureMiddleware(middleware, attach_to)
        middleware_mixin_0._future_middleware.append(future_middleware)
        if apply:
            middleware_mixin_0._apply_middleware(future_middleware)
        return middleware

    # Detect which way this was called, @middleware or @middleware('AT')
    if callable(middleware_or_request):
        return register_middleware(
            middleware_or_request, attach_to=attach_to
        )
    else:
        return partial(
            register_middleware, attach_to=middleware_or_request
        )

# Generated at 2022-06-26 03:41:33.073750
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    assert middleware_mixin_1._future_middleware == []
    assert middleware_mixin_1._apply_middleware(FutureMiddleware) == NotImplementedError  # noqa
    assert middleware_mixin_1.middleware(FutureMiddleware, "request", True) == FutureMiddleware  # noqa
    assert middleware_mixin_1.on_request(FutureMiddleware) == FutureMiddleware  # noqa
    assert middleware_mixin_1.on_response(FutureMiddleware) == FutureMiddleware  # noqa

# Generated at 2022-06-26 03:41:34.273338
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()


# Generated at 2022-06-26 03:41:36.118819
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()



# Generated at 2022-06-26 03:41:37.897637
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(None)


# Generated at 2022-06-26 03:41:49.126191
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = "examples.sanic.middleware_0"
    attach_to_0: str = "response"
    apply_0: bool = True
    future_middleware_0: FutureMiddleware
    middleware_mixin_0._future_middleware.append(MiddlewareMixin())
    middleware_mixin_0._future_middleware[0].middleware = middleware_0
    middleware_mixin_0._future_middleware[0].attach_to = attach_to_0
    future_middleware_0 = middleware_mixin_0._future_middleware[0]
    middleware_mixin_0._apply_middleware(future_middleware_0)
    future_middleware_0 = middleware_mixin

# Generated at 2022-06-26 03:41:54.175766
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request="request")
    

# Generated at 2022-06-26 03:41:57.075405
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    result = middleware_mixin_0.middleware('middleware_or_request')
    assert result == middleware_mixin_0.middleware


# Generated at 2022-06-26 03:42:05.923448
# Unit test for method middleware of class MiddlewareMixin

# Generated at 2022-06-26 03:42:08.584734
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    # Test for no exception
    try:
        middleware_mixin_0.middleware()
    except:
        assert False

    # Test for no exception
    try:
        middleware_mixin_0.middleware('request')
    except:
        assert False

    # Test for no exception
    try:
        middleware_mixin_0.middleware(lambda: 0, apply=False)
    except:
        assert False


# Generated at 2022-06-26 03:42:13.332478
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    def _middleware(request):
        return (
            '\x0f\xff\xc6\x06\xbd\xaf\xd8V\x1e\x00\xbb\x00\x13\x04\xa1\x17'
            '\x1a\x00\x17\xc3\x16\x00\xc0'
        )
    middleware_mixin_0.middleware(_middleware)


# Generated at 2022-06-26 03:42:15.315534
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request, attach_to='request', apply=True)

# Generated at 2022-06-26 03:42:17.639442
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware()


# Generated at 2022-06-26 03:42:23.218432
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware(): # noqa
    """Test method middleware of class MiddlewareMixin"""

    # Setup
    result = None

    # Exercise
    middleware_mixin_0 = MiddlewareMixin()
    result = middleware_mixin_0.middleware('request')

    # Verify


# Generated at 2022-06-26 03:42:25.620422
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0.middleware is not None
    assert middleware(middleware_mixin_0.middleware) is None


# Generated at 2022-06-26 03:42:32.210553
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    print("Testing method middleware of class MiddlewareMixin")
    middleware_mixin_0.middleware("request") # Expected args 'middleware_or_request' of type <class 'str'>, but actual is <class 'str'>.
    middleware_mixin_0.middleware("request", "response") # Expected args 'middleware_or_request' of type <class 'str'>, but actual is <class 'str'>.
    middleware_mixin_0.middleware("request", "response", False) # Expected args 'middleware_or_request' of type <class 'str'>, but actual is <class 'str'>.
    middleware_mixin_0.middleware("request", True) # Expected args 'middleware_or_request' of

# Generated at 2022-06-26 03:42:39.681686
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()



# Generated at 2022-06-26 03:42:41.215789
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()


# Generated at 2022-06-26 03:42:50.971375
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # TypeError expected
    middleware_mixin_1 = MiddlewareMixin()
    with raises(TypeError):
        middleware_mixin_1.middleware(
            middleware_or_request=1, attach_to="request")
    # TypeError expected
    middleware_mixin_2 = MiddlewareMixin()
    with raises(TypeError):
        middleware_mixin_2.middleware(
            middleware_or_request=lambda request: request)
    # TypeError expected
    middleware_mixin_3 = MiddlewareMixin()
    with raises(TypeError):
        middleware_mixin_3.middleware(
            middleware_or_request=lambda response: response, attach_to=1)



# Generated at 2022-06-26 03:42:54.777992
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixin_0(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    middleware_mixin_0 = MiddlewareMixin_0()



# Generated at 2022-06-26 03:43:03.952179
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()

    # Test case: middleware_or_request is function, attach_to is string
    middleware_or_request_0 = lambda: 0

    attach_to_0 = 'request'

    assert callable(middleware_mixin_1.middleware(
        middleware_or_request_0, attach_to_0)) is True

    # Test case: middleware_or_request is string, attach_to is string
    middleware_or_request_1 = 'request'

    attach_to_1 = 'response'

    assert callable(middleware_mixin_1.middleware(
        middleware_or_request_1, attach_to_1)) is True

# Generated at 2022-06-26 03:43:14.450593
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware = middleware_mixin_0.middleware(middleware_mixin_0.middleware)
    middleware()
    middleware_mixin_0.middleware()
    middleware_mixin_0.middleware(middleware_mixin_0.middleware)()
    middleware_mixin_0.middleware(middleware_mixin_0.middleware)()
    middleware_mixin_0.middleware(middleware_mixin_0.middleware)(middleware_mixin_0)
    middleware_mixin_0.middleware(middleware_mixin_0.middleware)(middleware_mixin_0)

# Generated at 2022-06-26 03:43:16.870744
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()



# Generated at 2022-06-26 03:43:26.248341
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    test_case_1: List[FutureMiddleware] = [
        FutureMiddleware(x, "request")
        for x in [(lambda request: request), (lambda response: response)]
    ]
    result_1: None = middleware_mixin_0.middleware(test_case_1[0])
    result_2: None = middleware_mixin_0.middleware(
        test_case_1[1], attach_to="response"
    )
    expected_1: None = None
    assert result_1 == expected_1
    assert result_2 == expected_1
    assert middleware_mixin_0._future_middleware == test_case_1


# Generated at 2022-06-26 03:43:27.097137
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-26 03:43:32.636491
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware = lambda x: x
    attach_to = 'request'
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0._future_middleware = []
    middleware_mixin_0._apply_middleware = lambda x: None
    middleware_mixin_0.middleware(middleware, attach_to)
    assert middleware_mixin_0._future_middleware[0].middleware == middleware
    assert middleware_mixin_0._future_middleware[0].attach_to == attach_to

# Test for the correct behavior of method on_request of class MiddlewareMixin

# Generated at 2022-06-26 03:43:46.523734
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware("request")


# Generated at 2022-06-26 03:43:52.682718
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(middleware_or_request='request')
    middleware_mixin_1.middleware(middleware_or_request=middleware_or_request)


# Generated at 2022-06-26 03:44:04.065630
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()

    def middleware():
        return 'middleware'

    def on_request():
        return 'on_request'

    def on_response():
        return 'on_response'

    # Call method middleware of middleware_mixin
    middleware_mixin.middleware(middleware)
    middleware_mixin.middleware(on_request, 'request')
    middleware_mixin.middleware(on_response, 'response')

    # Call method on_request of middleware_mixin
    middleware_mixin.on_request(middleware)
    middleware_mixin.on_request(on_request)

    # Call method on_response of middleware_mixin
    middleware_mixin.on_response(middleware)
    middleware_mixin

# Generated at 2022-06-26 03:44:07.918077
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware("request", middleware=MiddlewareMixin, 
                                  apply=False)
    middleware_mixin_0.on_response("response", middleware=MiddlewareMixin)
    middleware_mixin_0.on_request("request", middleware=MiddlewareMixin)

# Generated at 2022-06-26 03:44:12.344999
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    middleware_mixin.middleware(middleware_or_request=1, attach_to="request")
    middleware_mixin.middleware(middleware_or_request="request", attach_to=1)


# Generated at 2022-06-26 03:44:15.862716
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_2 = MiddlewareMixin()
    def cb_0():
        pass

    for _ in range(0, 6):
        middleware_mixin_2.middleware(cb_0)


# Generated at 2022-06-26 03:44:22.252662
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = middleware_mixin_0.middleware
    middleware_1 = middleware_mixin_0.middleware("request")
    middleware_2 = middleware_mixin_0.middleware("response")
    middleware_3 = middleware_mixin_0.middleware(middleware_or_request="request")
    middleware_4 = middleware_mixin_0.middleware(middleware_or_request="response")
    assert middleware_0 is not None
    assert middleware_1 is not None
    assert middleware_2 is not None
    assert middleware_3 is not None
    assert middleware_4 is not None



# Generated at 2022-06-26 03:44:28.331235
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(attach_to="request")
    middleware_mixin_1.middleware(attach_to="response")
    middleware_mixin_1.middleware(attach_to="middleware")

test_case_0()
test_MiddlewareMixin_middleware()

# Generated at 2022-06-26 03:44:33.705668
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request_0: str = "request"
    attach_to_0: str = "request"
    apply_0: bool = True
    # The next line is expected to fail
    output_0 = middleware_mixin_0.middleware(middleware_or_request_0, attach_to_0, apply_0) # noqa


# Generated at 2022-06-26 03:44:35.435288
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0.middleware()


# Generated at 2022-06-26 03:45:06.060104
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_1 = middleware_mixin_0.middleware
    middle_ware_0 = middleware_1("request")
    middle_ware_0(None)



# Generated at 2022-06-26 03:45:08.203513
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request='request')

# Generated at 2022-06-26 03:45:10.864879
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(middleware_or_request=None, attach_to="request", apply=True)


# Generated at 2022-06-26 03:45:11.673776
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

# Generated at 2022-06-26 03:45:16.066250
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = lambda request, response: None
    assert middleware_mixin_0.middleware(middleware_0) == middleware_0


# Generated at 2022-06-26 03:45:19.662255
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    # Test case 0
    middleware_mixin_0 = MiddlewareMixin()

    first_middleware = middleware_mixin_0.middleware(middleware_or_request=None)
    # Verify that the assumptions are true
    assert middleware_mixin_0._future_middleware == [first_middleware]


# Generated at 2022-06-26 03:45:23.332604
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0._future_middleware = []
    middleware_mixin_0._apply_middleware()
    middleware_mixin_0._apply_middleware()


# Generated at 2022-06-26 03:45:28.088738
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_list = [None for i in range(5)]
    for i in range(5):
        middleware_list[i] = middleware_mixin_1.middleware()
    for i in range(5):
        assert isinstance(middleware_list[i], partial)
    for i in range(5):
        middleware_mixin_1.middleware(middleware_list[i])


# Generated at 2022-06-26 03:45:35.920163
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():  # noqa
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(middleware=17)(middleware=16)
    middleware_mixin_1.middleware(attach_to="request")(middleware=16)
    middleware_mixin_1.middleware(apply=False)(middleware=16)


# Generated at 2022-06-26 03:45:43.570996
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol

    app = Sanic()

    @app.middleware
    def print_on_request(request):
        print("I print when a request is made")

    def print_on_response(request, response):
        print("I print when a response is returned")
        return response

    app.middleware(print_on_response, attach_to="response")

    @app.websocket("/feed")
    async def feed(request, ws):
        while True:
            data = "Hello!"
            print("Sending message: %s" % data)
            await ws.send(data)
            data = await ws.recv()

# Generated at 2022-06-26 03:46:40.165615
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware
    from types import FunctionType

    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0._future_middleware = []
    middleware_mixin_0._apply_middleware = (lambda middleware: middleware)
    # Call to middleware of arg middleware_or_request(
    # type: <class 'function'>) and arg attach_to(type: str)
    type_middleware_0 = middleware_mixin_0.middleware
    with pytest.raises(NotImplementedError):
        type_middleware_0(lambda: None)


# Generated at 2022-06-26 03:46:49.305095
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0._future_middleware == []

    middleware_mixin_0.middleware(lambda a: a * 2)
    assert middleware_mixin_0._future_middleware == [FutureMiddleware(
        lambda a: a * 2, "request")]

    middleware_mixin_0.middleware("request", "hello world")
    assert middleware_mixin_0._future_middleware == [
        FutureMiddleware(lambda a: a * 2, "request"),
        FutureMiddleware("hello world", "request")
    ]


# Generated at 2022-06-26 03:46:51.814420
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = lambda request, response: response
    assert middleware_mixin_0.middleware(middleware_0) == middleware_0


# Generated at 2022-06-26 03:46:53.516068
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_0 = lambda x: x
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_0)


# Generated at 2022-06-26 03:46:56.041415
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()

# Generated at 2022-06-26 03:46:59.358421
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_3 = MiddlewareMixin()
    def middleware_or_request(param0: str, param1: str) -> str:
        return param0 + param1
    attach_to = 'request'
    apply = True
    assert middleware_mixin_3.middleware(middleware_or_request, attach_to, apply) == middleware_or_request


# Generated at 2022-06-26 03:47:01.818479
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    attach_to_1 = "request"
    MiddlewareMixin_middleware_return_2 = middleware_mixin_0.middleware(attach_to=attach_to_1)
    assert MiddlewareMixin_middleware_return_2 is not None


# Generated at 2022-06-26 03:47:06.525494
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert not middleware_mixin_0._future_middleware
    middleware_0 = lambda request: 0 * request
    middleware_mixin_0.middleware(middleware_0)
    assert len(middleware_mixin_0._future_middleware) == 1
    assert middleware_mixin_0._apply_middleware(middleware_mixin_0._future_middleware[0])
    assert middleware_mixin_0._future_middleware[0].middleware == middleware_0


# Generated at 2022-06-26 03:47:09.111899
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    middleware_mixin.middleware("request")
    middleware_mixin.middleware(attach_to="request")
    middleware_mixin.middleware(middleware_or_request="request")


# Generated at 2022-06-26 03:47:11.342859
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = middleware_mixin_0.middleware
    middleware_0(
        middleware_or_request=lambda: None, attach_to='request', apply=True
    )

