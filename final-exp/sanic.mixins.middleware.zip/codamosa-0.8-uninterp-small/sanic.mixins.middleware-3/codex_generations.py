

# Generated at 2022-06-26 03:37:55.354479
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Create a dummy class for testing
    class Dummy:
        def test(self):
            pass
    # Create a instance of dummy class
    dummy = Dummy()
    # Get the partial function of on_response
    on_response = MiddlewareMixin.on_response(middleware_mixin_0)
    # Call the partial function on_response on dummy instance
    dummy.test = on_response(dummy.test)

# Generated at 2022-06-26 03:37:56.492705
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()



# Generated at 2022-06-26 03:38:01.286534
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = lambda x: True
    assert (middleware_mixin_0.middleware(middleware_0) == middleware_0)
    assert (middleware_mixin_0.middleware(middleware_0, 'response') == middleware_0)
    middleware_1 = lambda x: False
    assert (middleware_mixin_0.middleware(middleware_1) == middleware_1)
    assert (middleware_mixin_0.middleware(middleware_1, 'response') == middleware_1)


# Generated at 2022-06-26 03:38:08.317046
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    # Function is given a middleware and this is called
    middleware_mixin_0.on_request('request')('middleware')
    assert hasattr(middleware_mixin_0, '_future_middleware')
    assert middleware_mixin_0._future_middleware == [FutureMiddleware('middleware', 'request')]


# Generated at 2022-06-26 03:38:11.590044
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()


# Generated at 2022-06-26 03:38:14.251995
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # TODO
    assert middleware_mixin_0._future_middleware == []


# Generated at 2022-06-26 03:38:25.186827
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_3 = MiddlewareMixin()
    middleware_mixin_4 = MiddlewareMixin()

    assert middleware_mixin_1._future_middleware == []
    assert middleware_mixin_2._future_middleware == []
    assert middleware_mixin_3._future_middleware == []
    assert middleware_mixin_4._future_middleware == []
    
    def middleware_1():
        pass
    def middleware_2():
        pass
    def middleware_3():
        pass
    def middleware_4():
        pass
    
    # Case 1
    middleware_mixin_1.middleware(middleware_1)


# Generated at 2022-06-26 03:38:26.825736
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # create object
    middleware_mixin_0 = MiddlewareMixin()

# Generated at 2022-06-26 03:38:29.186410
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    nil = MiddlewareMixin
    assert nil.on_request != nil.on_response


# Generated at 2022-06-26 03:38:34.385142
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Initialization of test object
    middleware_mixin_0 = MiddlewareMixin()
    # Typechecking of parameters
    assert isinstance(middleware_mixin_0, MiddlewareMixin)
    # Invocation of method
    result = middleware_mixin_0.middleware()
    # Typechecking of results
    assert isinstance(result, partial)
    assert len(result.args) == 1
    assert len(result.keywords) == 1


# Generated at 2022-06-26 03:38:47.759197
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # mock class
    class MyMiddlewareMixin:
        def __init__(self):
            self.middleware_response_mock = mock.Mock()
            self.middleware_request_mock = mock.Mock()
            self.on_request_mock = mock.Mock()
            self._future_middleware = []

        def middleware(self, middleware, attach_to="request"):
            if attach_to == "request":
                self.middleware_request_mock(middleware)
            if attach_to == "response":
                self.middleware_response_mock(middleware)
            return middleware

        def on_request(self, middleware):
            self.on_request_mock(middleware)

    # mock object
    middleware_mixin_1 = MyMiddleware

# Generated at 2022-06-26 03:38:50.739545
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_response(middleware=None)
    assert True # TODO: implement your test here


# Generated at 2022-06-26 03:38:59.830581
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()

    # Testing if it can be called without a parameter
    # ../utils/middleware.py:MiddlewareMixin.on_request:48
    middleware_mixin_0.on_request()

    # Testing if it can be called with a valid parameter
    # ../utils/middleware.py:MiddlewareMixin.on_request:48
    middleware_mixin_0.on_request(lambda response: response)



# Generated at 2022-06-26 03:39:01.781152
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    assert callable(middleware_mixin_1.on_request())


# Generated at 2022-06-26 03:39:04.524685
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()

    func_0 = middleware_mixin_0.on_response(middleware=None)
    # Call a function
    func_0()



# Generated at 2022-06-26 03:39:08.988944
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    print("---------------")
    print("Unit test for method on_request of class MiddlewareMixin")

    middleware_mixin_0 = MiddlewareMixin()
    print (middleware_mixin_0.on_request)



# Generated at 2022-06-26 03:39:10.742224
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin = MiddlewareMixin()
    middleware_mixin.on_response()


# Generated at 2022-06-26 03:39:12.474596
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    mxin = MiddlewareMixin()
    mxin.on_response(middleware=None)


# Generated at 2022-06-26 03:39:13.401842
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass


# Generated at 2022-06-26 03:39:15.289856
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_request(middleware=None)

# Generated at 2022-06-26 03:39:22.558991
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    """
    Test function on_response of class MiddlewareMixin.
    """
    # Test with error
    case_0 = MiddlewareMixin()
    case_0.on_response(None)

    # Test without error
    case_1 = MiddlewareMixin()
    print(case_1.on_response(on_response_func))


# Generated at 2022-06-26 03:39:26.328609
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin(str())
    middleware = (str(),)
    attach_to = 'str'
    apply = False
    middleware_mixin_1.middleware(middleware, attach_to, apply)


# Generated at 2022-06-26 03:39:28.875991
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()

    assert callable(middleware_mixin_0.on_response())



# Generated at 2022-06-26 03:39:33.714423
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()

    def on_response_mock(self, request: str, response: str) -> str:
        return middleware_mixin_0._apply_middleware(middleware_mixin_0._future_middleware[0])

    middleware_mixin_0.on_response = on_response_mock

# Generated at 2022-06-26 03:39:37.260351
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_1 = MiddlewareMixin()
    try:
        middleware_mixin_1.on_response()
    except NotImplementedError:
        assert True
    except Exception as e:
        assert False


# Generated at 2022-06-26 03:39:38.906990
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin().on_response()


# Generated at 2022-06-26 03:39:45.543124
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    middleware = lambda :None
    attach_to = "request"
    apply = True
    register_middleware = middleware_mixin.middleware(middleware, 
                                                      attach_to, 
                                                      apply)
    assert(middleware == register_middleware)


# Generated at 2022-06-26 03:39:47.517595
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    assert callable(middleware_mixin_0.on_response)


# Generated at 2022-06-26 03:39:50.616313
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Initialize a test case
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = lambda *args: None
    # Assertions
    assert middleware_mixin_0.middleware(middleware_0) == middleware_0


# Generated at 2022-06-26 03:39:56.685362
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(middleware_or_request='request_or_response')
    middleware_mixin_1.middleware(middleware_or_request='request', attach_to='request_or_response')
    middleware_mixin_1.middleware(middleware_or_request=lambda request: request, attach_to='request_or_response')



# Generated at 2022-06-26 03:40:03.935787
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Test with function argument
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_response(str)

    # Test without function argument
    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_2.on_response()


# Generated at 2022-06-26 03:40:14.254823
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    setattr(middleware_mixin_0, '_future_middleware', [])
    middleware_mixin_0.middleware(middleware_or_request=None, attach_to="request", apply=True)
    middleware_mixin_0.middleware(middleware_or_request=None, attach_to="response", apply=True)
    middleware_mixin_0.middleware(middleware_or_request=mock.MagicMock(), attach_to="request", apply=True)
    middleware_mixin_0.middleware(middleware_or_request=mock.MagicMock(), attach_to="response", apply=True)

# Generated at 2022-06-26 03:40:14.831388
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass



# Generated at 2022-06-26 03:40:19.032762
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    # function on_response of class MiddlewareMixin
    arg0 = None
    arg1 = None
    arg2 = None
    ret0 = middleware_mixin_0.on_response(arg0, arg1, arg2)


# Generated at 2022-06-26 03:40:21.145094
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_response()

# Generated at 2022-06-26 03:40:24.764057
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # call on_response with parameter
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_response(middleware=None)



# Generated at 2022-06-26 03:40:34.646762
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from functools import partial
    from types import FunctionType
    from sanic.models.futures import FutureMiddleware

    class MiddlewareMixin:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa


# Generated at 2022-06-26 03:40:37.886103
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import io
    import sys

    f = io.StringIO()
    with redirect_stdout(f):
        m = on_response()
        print(m)

    out = f.getvalue()
    assert out == "<functools.partial object at 0x1114108c8>\n"

# Generated at 2022-06-26 03:40:41.163232
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(middleware_or_request=None, attach_to=None, apply=True)
    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_2.middleware(middleware_or_request=None, attach_to=None, apply=False)


# Generated at 2022-06-26 03:40:46.246319
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Arrange
    middleware_mixin_0 = MiddlewareMixin()
    obj = partial(middleware_mixin_0.middleware, attach_to="response")

    # Act
    result = middleware_mixin_0.on_response()

    # Assert
    assert obj == result

# Generated at 2022-06-26 03:40:51.354404
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_4 = MiddlewareMixin()
    try:
        middleware_mixin_4.on_response('on_response')
    except:
        pass
    else:
        assert False, "Unreachable"


# Generated at 2022-06-26 03:40:58.402260
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    @middleware_mixin_1.middleware('request')
    async def authenticated(request):
        pass

    @middleware_mixin_2.middleware('request')
    async def authenticated(request):
        pass

    @middleware_mixin_3.middleware('request')
    async def authenticated(request):
        pass

    @middleware_mixin_4.middleware('request')
    async def authenticated(request):
        pass

    @middleware_mixin_5.middleware('request')
    async def authenticated(request):
        pass

    @middleware_mixin_6.middleware('request')
    async def authenticated(request):
        pass



# Generated at 2022-06-26 03:41:07.608561
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    response = Response('200 OK', headers={})
    @middleware_mixin_0.on_response
    async def response_middleware(request):
        # Any error on the way down stops everything
        # But if something breaks on the way up (in middleware
        # or the response) then it gets caught here
        try:
            response = await response_handler(request)
        except Exception as error:
            response = response.text('Exception: %s' % str(error), 500)
        return response
    # test method on_response of class MiddlewareMixin
    assert middleware_mixin_0.on_response(response) is not None


# Generated at 2022-06-26 03:41:10.504951
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # initialize
    middleware_mixin = MiddlewareMixin()
    my_lambda = lambda arg1, arg2: arg1 + arg2
    # test
    middleware_mixin.on_response(middleware=my_lambda)
    # assert
    assert middleware_mixin


# Generated at 2022-06-26 03:41:15.607694
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin = MiddlewareMixin()
    result_0 = middleware_mixin.on_response()
    try:
        result_0()
    except TypeError:
        assert True
    except Exception:
        assert False
    else:
        assert False



# Generated at 2022-06-26 03:41:20.318894
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def middleware_or_request(middleware, attach_to='request'):
        return middleware
    register_middleware = middleware_mixin_0.middleware(middleware_or_request)
    register_middleware("register_middleware_0")


# Generated at 2022-06-26 03:41:21.936803
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_response()

# Generated at 2022-06-26 03:41:23.853764
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(None)



# Generated at 2022-06-26 03:41:30.596738
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_1 = MiddlewareMixin()

    print(middleware_mixin_1.on_response(middleware_or_request=None))
    print(middleware_mixin_1.on_response(middleware_or_request=(lambda a, b: None)))

if __name__ == '__main__':
    test_case_0()
    test_MiddlewareMixin_on_response()

# Generated at 2022-06-26 03:41:33.569701
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    try:
        MiddlewareMixin().on_response()
    except NotImplementedError as e:
        assert "NotImplementedError" in str(e)



# Generated at 2022-06-26 03:41:37.509159
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    ret = middleware_mixin_0.middleware(middleware_or_request='request')
    assert middleware_mixin_0 is ret


# Generated at 2022-06-26 03:41:38.297692
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-26 03:41:43.570717
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    try:
        middleware_mixin_1 = MiddlewareMixin()
        middleware_mixin_1.middleware()
    except NotImplementedError:
        test_case_1 = True
    else:
        test_case_1 = False
    assert test_case_1


# Generated at 2022-06-26 03:41:48.354336
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Arrange
    middleware_mixin_0 = MiddlewareMixin()
    def f1(middleware, attach_to):
        return middleware, attach_to

    # Act
    actual = middleware_mixin_0.middleware(f1, "request")

    # Assert
    assert callable(actual)

# Generated at 2022-06-26 03:41:57.174554
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_3 = MiddlewareMixin()

    @middleware_mixin_1.middleware
    def middleware_1(request):
        pass

    @middleware_mixin_2.middleware('request')
    def middleware_2(request):
        pass

    @middleware_mixin_3.middleware('response')
    def middleware_3(request):
        pass

    print(middleware_mixin_1._future_middleware)
    print(middleware_mixin_2._future_middleware)
    print(middleware_mixin_3._future_middleware)


# Generated at 2022-06-26 03:42:03.308091
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request_0 = lambda x: x
    with pytest.raises(NotImplementedError):
        middleware_mixin_0.middleware(middleware_or_request_0)


# Generated at 2022-06-26 03:42:09.532668
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_or_request = "request"
    attach_to = None
    apply = True

    # Call method under unit test
    middleware_mixin_1.middleware(middleware_or_request, attach_to, apply)


# Generated at 2022-06-26 03:42:13.071901
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = 'request'
    attach_to = 'request'
    apply = True
    r = middleware_mixin_0.middleware(middleware_or_request, attach_to, apply)


# Generated at 2022-06-26 03:42:17.761010
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    @middleware_mixin_0.middleware('request', apply=False)
    async def middleware_0(request):
        print('test')
    middleware_mixin_0.middleware('request')(middleware_0)


# Generated at 2022-06-26 03:42:29.037994
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = MiddlewareMixin()
    def middleware_0(middleware_or_request, attach_to="request", apply=True):
        if callable(middleware_or_request):
            return middleware_mixin_0.middleware(
                middleware_or_request, attach_to=attach_to
            )
        else:
            return partial(
                middleware_mixin_0.middleware, attach_to=middleware_or_request
            )
    middleware_mixin_1._future_middleware
    middleware_mixin_2._future_middleware
    middleware_mixin_0.middleware(middleware_0)

#

# Generated at 2022-06-26 03:42:41.215554
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # try:
    print("No argument is passed")
    middleware_mixin_0.middleware()
    # except:
    #     print("No argument is passed")

    print("Passing a callable")
    middleware_mixin_0.middleware(callable)

    # try:
    print("Passing a callable and attach_to is not a string")
    middleware_mixin_0.middleware(callable, True)
    # except:
    #     print("attach_to param is not a String")

    print("Passing a callable and attach_to is request")
    middleware_mixin_0.middleware(callable, "request")

    print("Passing a callable and attach_to is response")
    middleware

# Generated at 2022-06-26 03:42:42.199399
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()


# Generated at 2022-06-26 03:42:52.881574
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    future_middleware_0 = FutureMiddleware(middleware_0, "request")
    assert middleware_mixin_1._future_middleware == []
    middleware_mixin_1._future_middleware.append(future_middleware_0)
    assert middleware_mixin_1._future_middleware == [future_middleware_0]
    middleware_mixin_1.middleware(middleware_0, apply=True)
    assert middleware_mixin_1._future_middleware == [
        future_middleware_0,
        FutureMiddleware(middleware_0, "request"),
    ]
    middleware_mixin_1.middleware(middleware_1, "response")
    assert middleware_mixin_1._future_

# Generated at 2022-06-26 03:43:03.575576
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from typing import Callable, Optional
    from sanic.models.futures import FutureMiddleware

    middleware_or_request = Optional[Callable]  # noqa
    middleware = FutureMiddleware(
        middleware=None,
        attach_to=Optional[str],
    )

    attach_to = Optional[str]  # noqa
    apply = bool  # noqa
    register_middleware = Optional[FutureMiddleware]  # noqa
    register_middleware = Optional[Callable]  # noqa
    register_middleware = FutureMiddleware(
        middleware=None,
        attach_to=Optional[str],
    )
    register_middleware = FutureMiddleware()


# Generated at 2022-06-26 03:43:14.309206
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.exceptions import SanicException

    middleware_mixin = MiddlewareMixin()
    sanic_app = Sanic("sanic-server")
    request = None

    @middleware_mixin.middleware
    async def middleware(request):
        request["processed_by"] = "middleware"
        return request

    request = sanic_app.request("GET", "/")
    assert request["processed_by"] == "middleware"

    # assert that it works as a decorator
    @middleware_mixin.middleware('request')
    async def middleware_request(request):
        request["processed_by"] = "middleware_request"
        return request


# Generated at 2022-06-26 03:43:18.127562
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    result = middleware_mixin_0.middleware(middleware_or_request=(70 - 11))
    assert type(result) == partial


# Generated at 2022-06-26 03:43:26.776522
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_1 = FutureMiddleware(object, str)
    returned_value_1 = middleware_mixin_0.middleware(
        middleware_1,
        attach_to="request",
        apply=True,
    )
    middleware_2 = FutureMiddleware(object, 'response')
    returned_value_2 = middleware_mixin_0.middleware(
        middleware_2,
        attach_to="response",
        apply=False,
    )
    assert returned_value_1 is middleware_1
    assert returned_value_2 is middleware_2


# Generated at 2022-06-26 03:43:27.928217
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()


# Generated at 2022-06-26 03:43:34.158323
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_3 = MiddlewareMixin()
    middleware_mixin_4 = MiddlewareMixin()
    middleware_mixin_5 = MiddlewareMixin()
    middleware_mixin_0._future_middleware = []
    middleware_mixin_1._future_middleware = []
    middleware_mixin_2._future_middleware = [1]
    middleware_mixin_3._future_middleware = []
    middleware_mixin_4._future_middleware = []
    middleware_mixin_5._future_middleware = []
    middleware_0 = lambda: None
   

# Generated at 2022-06-26 03:43:44.440812
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    # No argument
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware()

    # One argument
    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_2.middleware(middleware_or_request=lambda : 0)

    # Two argument
    middleware_mixin_3 = MiddlewareMixin()
    middleware_mixin_3.middleware(middleware_or_request=lambda : 0, attach_to="request")
    middleware_mixin_3.middleware(middleware_or_request=lambda : 0, attach_to="response")


# Generated at 2022-06-26 03:43:56.250468
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    request = Request(Method.GET, URL("http://localhost:8080/test_middleware"))
    future_middleware_0: FutureMiddleware = FutureMiddleware(request)
    future_middleware_1: FutureMiddleware = FutureMiddleware(request)

    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(request)
    assert middleware_mixin_1._future_middleware == [future_middleware_0, future_middleware_1]


# Generated at 2022-06-26 03:43:58.057304
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    middleware_mixin.middleware()

# Generated at 2022-06-26 03:44:05.558478
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def middleware_or_request():
        pass
    attach_to = "request"
    apply = True
    MiddlewareMixin.middleware(middleware_mixin_0, middleware_or_request, attach_to=attach_to, apply=apply)
    assert middleware_mixin_0._future_middleware[0].attach_to == attach_to


# Generated at 2022-06-26 03:44:07.482395
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request = None)


# Generated at 2022-06-26 03:44:09.073071
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    result = middleware_mixin_1.middleware()


# Generated at 2022-06-26 03:44:20.148482
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    middleware_mixin_1 = MiddlewareMixin()

    # Test case 1 - Register a request and response type of middleware into
    # middleware list

    # Check the length of middleware list before register middleware
    assert len(middleware_mixin_1._future_middleware) == 0

    # Register a request and response type of middleware
    @middleware_mixin_1.middleware
    def middleware_handler_1(req, resp):
        pass

    @middleware_mixin_1.middleware('response')
    def middleware_handler_2(req, resp):
        pass

    # Check the length of middleware list after register middleware
    assert len(middleware_mixin_1._future_middleware) == 2

    # Test case 2 - Register a request and response type of middleware into
   

# Generated at 2022-06-26 03:44:22.913718
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def function0(): pass
    result = middleware_mixin_0.middleware(function0)
    assert isinstance(result, partial)


# Generated at 2022-06-26 03:44:26.894051
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware



# Generated at 2022-06-26 03:44:29.922540
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0.middleware("middleware_or_request") == partial(middleware_mixin_0.middleware, attach_to="middleware_or_request")


# Generated at 2022-06-26 03:44:32.644840
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()


# Generated at 2022-06-26 03:44:41.844114
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Create an instance of MiddlewareMixin
    middleware_mixin_0 = MiddlewareMixin()

    # Call method middleware of middleware_mixin_0
    middleware_mixin_0._apply_middleware(middleware_mixin_0._future_middleware[0])


# Generated at 2022-06-26 03:44:50.499013
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    @middleware_mixin_1.middleware
    def middleware_function_0():
        pass

    @middleware_mixin_1.middleware(attach_to="request")
    def middleware_function_1():
        pass

    @middleware_mixin_1.on_request
    def middleware_function_2():
        pass

    @middleware_mixin_1.on_response
    def middleware_function_3():
        pass

# Generated at 2022-06-26 03:44:52.862969
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware


# Generated at 2022-06-26 03:44:55.927210
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware()

# Generated at 2022-06-26 03:44:58.239744
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()


# Generated at 2022-06-26 03:45:03.018146
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """
    Tests for middleware method of class MiddlewareMixin
    """
    # Arrange
    middleware_mixin_0 = MiddlewareMixin()
    def middleware_0():
        pass
    attach_to_0 = "request"
    apply_0 = True
    # Act
    middleware_mixin_0.middleware(middleware_0, attach_to_0, apply_0)
    result_0 = middleware_mixin_0.middleware
    # Assert
    assert callable(result_0)


# Generated at 2022-06-26 03:45:07.284445
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = Any()

    # Case 1
    middleware = middleware_mixin_0.middleware(middleware_or_request)


# Generated at 2022-06-26 03:45:11.707437
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def middlare_0(request):
        return request
    middleware_mixin_0.middleware(middlare_0, 'request', True)
    def middlare_1(request):
        return request
    middleware_mixin_0.middleware(middlare_1, 'request', True)

# Generated at 2022-06-26 03:45:16.482270
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    future_middleware_1 = FutureMiddleware()
    result_1 = middleware_mixin_1.middleware(future_middleware_1)
    assert result_1 == future_middleware_1



# Generated at 2022-06-26 03:45:19.364683
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def middleware_or_request_0():
        return lambda: None
    assert middleware_mixin_0.middleware(middleware_or_request_0)() is None



# Generated at 2022-06-26 03:45:37.628218
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    future_middleware = FutureMiddleware(middleware_or_request=None, attach_to="request")
    middleware_mixin._future_middleware.append(future_middleware)
    assert middleware_mixin._future_middleware[0] != None


# Generated at 2022-06-26 03:45:44.178754
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()

    def middleware_or_request_callback_1(request, response):
        return None

    def register_middleware_1(middleware, attach_to="request"):
        nonlocal middleware_mixin_1

        future_middleware = FutureMiddleware(middleware, attach_to)
        middleware_mixin_1._future_middleware.append(future_middleware)
        middleware_mixin_1._apply_middleware(future_middleware)

        return middleware

    def partial_function_1(middleware, attach_to="response"):
        register_middleware_1(middleware, attach_to)

    partial_function_1(middleware_or_request_callback_1, "request")

# Generated at 2022-06-26 03:45:47.609367
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    assert hasattr(middleware_mixin, "_middleware")
    assert callable(middleware_mixin._middleware)


# Generated at 2022-06-26 03:45:51.005117
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request=lambda x: None, attach_to="response")

# Generated at 2022-06-26 03:45:53.309952
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware()


# Generated at 2022-06-26 03:45:54.567273
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    test_case_0()


# Generated at 2022-06-26 03:45:57.671359
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0.middleware(MiddlewareMixin(), attach_to="request")

# Generated at 2022-06-26 03:46:02.841754
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # Type error
    with pytest.raises(NotImplementedError):
        middleware_mixin_0.middleware(middleware_or_request=0)
    # Type error
    with pytest.raises(NotImplementedError):
        middleware_mixin_0.middleware(middleware_or_request=0, attach_to="request")
    # Type error
    with pytest.raises(NotImplementedError):
        middleware_mixin_0.middleware(middleware_or_request=0, apply=True)
    assert middleware_mixin_0.middleware(middleware_or_request="middleware_or_request", attach_to="middleware_or_request", apply=False)

# Generated at 2022-06-26 03:46:04.871229
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    assert middleware_mixin_1.middleware == MiddlewareMixin._middleware_

# Generated at 2022-06-26 03:46:10.732284
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Define the parameters that should be included in the test case.
    middleware_mixin_1 = MiddlewareMixin()
    middleware_or_request = None
    attach_to = 'request'
    apply = None


    # Execute the tested code
    result = middleware_mixin_1.middleware(middleware_or_request, attach_to, apply)

    # Verify the result
    assert result is None
