

# Generated at 2022-06-26 03:37:47.659996
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    
    assert isinstance(middleware_mixin_0.on_request(), partial)
    assert callable(middleware_mixin_0.on_request())


# Generated at 2022-06-26 03:37:50.520699
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_request(middleware=None)


# Generated at 2022-06-26 03:37:54.640058
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    closure_0 = middleware_mixin_0.on_request()
    closure_0(middleware = lambda request: None,)

# Generated at 2022-06-26 03:37:56.812600
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(attach_to='request', apply=True)


# Generated at 2022-06-26 03:38:01.568012
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    # Value of the first argument: parameter middleware
    middleware_0 = "middleware_0"
    # Value of the second argument
    attach_to_0 = "response"
    # The return value of method on_request(middleware)
    middleware_mixin_0__on_request_middleware_0 = middleware_mixin_0.on_request(middleware_0)
    # Check if the function call pass all test cases
    assert middleware_mixin_0__on_request_middleware_0(attach_to = attach_to_0) == middleware_0


# Generated at 2022-06-26 03:38:06.547471
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    middleware_mixin_0.middleware(None, None, None)
    middleware_mixin_0.on_response(None)
    middleware_mixin_0.on_request(None)

# Generated at 2022-06-26 03:38:11.494995
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin.middleware(middleware_or_request='middleware')

# Generated at 2022-06-26 03:38:14.165943
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    res = middleware_mixin_1.on_request()
    res.__call__(1)


# Generated at 2022-06-26 03:38:18.491457
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # Case 1: ('request', True)
    middleware_or_request = 'request'  # str
    attach_to = 'request'  # str
    middleware_mixin_0.middleware(middleware_or_request, attach_to=attach_to, apply=True)



# Generated at 2022-06-26 03:38:24.323499
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()

    @middleware_mixin.middleware
    def test_middleware(request):
        pass

    def t():
        @middleware_mixin.middleware('request')
        def test_middleware(request):
            pass
    t()



# Generated at 2022-06-26 03:38:32.484033
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_3 = MiddlewareMixin()

    middleware_mixin_1.on_response()
    middleware_mixin_2.on_response(middleware=1)
    middleware_mixin_3.on_response(middleware=2)


# Generated at 2022-06-26 03:38:35.363499
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    # Test case 1
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware("request")


# Generated at 2022-06-26 03:38:38.278652
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = lambda request: None
    result = middleware_mixin_0.middleware(middleware_0)

    assert callable(result)

# Generated at 2022-06-26 03:38:42.338156
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    test_object_0 = MiddlewareMixin()
    result_0 = test_object_0.on_response()
    assert type(result_0) is partial
    assert result_0.args == ()
    assert result_0.keywords == {"attach_to": "response"}


# Generated at 2022-06-26 03:38:45.973335
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Arrange
    middleware_mixin_0 = MiddlewareMixin()

    # Act
    middleware_mixin_0.middleware()

    # Assert


# Generated at 2022-06-26 03:38:54.172027
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from inspect import signature
    from functools import partial
    from typing import Callable
    from typing import Tuple
    from typing import TypeVar
    from typing import Union

    from sanic.models.futures import FutureMiddleware

    _T = TypeVar("_T")
    _U = TypeVar("_U")
    _V = TypeVar("_V")
    _W = TypeVar("_W")

    class MiddlewareMixin:
        def __init__(self, *args: object, **kwargs: object) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa


# Generated at 2022-06-26 03:39:00.900412
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    attach_to = "request"
    apply = True
    middleware_mixin = MiddlewareMixin()
    middleware = object()
    middleware_mixin.middleware(
        middleware, attach_to=attach_to, apply=apply
    )
    assert (
        middleware_mixin
        ._future_middleware[0]
        .middleware == middleware
    )


# Generated at 2022-06-26 03:39:01.780835
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass


# Generated at 2022-06-26 03:39:04.068639
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    """
    Test whether the class MiddlewareMixin' method on_response() can be invoked
    """
    middleware_mixin_0 = MiddlewareMixin()
    assert hasattr(middleware_mixin_0, 'on_response')
    assert callable(middleware_mixin_0.on_response)


# Generated at 2022-06-26 03:39:14.793991
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_1 = MiddlewareMixin()
    # Calling 'on_response()' method. 
    on_response_middleware_1 = middleware_mixin_1.on_response()
    # Calling 'on_response()' method. 
    on_response_middleware_2 = middleware_mixin_1.on_response()
    # Calling 'on_response()' method. 
    on_response_middleware_3 = middleware_mixin_1.on_response()
    # Calling 'on_response()' method. 
    on_response_middleware_4 = middleware_mixin_1.on_response()
    # Calling 'on_response()' method. 
    on_response_middleware_5 = middleware_mixin_1.on_response()
    # Calling '

# Generated at 2022-06-26 03:39:21.918768
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = MiddlewareMixin()

    @middleware_mixin_1.middleware
    def middleware(request):
        pass

    @middleware_mixin_2.middleware('response')
    def middleware(request, response):
        pass



# Generated at 2022-06-26 03:39:25.788491
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = middleware_mixin_1.on_request(middleware=None)
    middleware_mixin_3 = middleware_mixin_2(middleware=None)

# Generated at 2022-06-26 03:39:28.274653
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_request()


# Generated at 2022-06-26 03:39:31.089936
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_request()
    print("unit test for on_request of MiddlewareMixin")


# Generated at 2022-06-26 03:39:32.040378
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    test_case_0()


# Generated at 2022-06-26 03:39:34.505423
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Executing the code below raises an error
    # middleware_mixin_on_request = MiddlewareMixin().on_request()
    # This is because the code is incomplete
    assert False

# Generated at 2022-06-26 03:39:36.974901
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_request()


# Generated at 2022-06-26 03:39:41.304022
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()

    assert middleware_mixin_1._future_middleware == []
    assert middleware_mixin_1.on_request(lambda x: x) == middleware_mixin_1.middleware(
        'request'
    )
    assert middleware_mixin_1._future_middleware != []


# Generated at 2022-06-26 03:39:44.628807
# Unit test for method on_request of class MiddlewareMixin

# Generated at 2022-06-26 03:39:46.986189
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_request()

# Generated at 2022-06-26 03:39:51.146293
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = None
    attach_to = "request"
    apply = True
    assert middleware_mixin_0.middleware(middleware_or_request, attach_to, apply)



# Generated at 2022-06-26 03:39:52.286228
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()



# Generated at 2022-06-26 03:39:58.930704
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()

    # Test middleware_mixin_1._future_middleware as a list
    assert middleware_mixin_1._future_middleware == []

    with pytest.raises(NotImplementedError) as error_info:
        # Test middleware_mixin_1._apply_middleware(middleware)
        middleware_mixin_1._apply_middleware(FutureMiddleware(None, None))
    assert 'not implemented' in str(error_info.value)


# Generated at 2022-06-26 03:40:11.194861
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    call_back = lambda request: request
    attach_to = 'request'
    call_back_1 = lambda request: request
    attach_to_1 = 'request'
    assert middleware_mixin_0.middleware(call_back) == call_back
    assert middleware_mixin_0.middleware(call_back, attach_to, True) == call_back
    assert middleware_mixin_0.middleware(call_back, attach_to_1, False) == call_back
    assert middleware_mixin_0.middleware(call_back_1, attach_to, False) == call_back_1
    assert middleware_mixin_0.middleware(call_back_1, attach_to_1, True) == call_

# Generated at 2022-06-26 03:40:13.928641
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware('request')
    middleware_mixin_0.middleware('response')


# Generated at 2022-06-26 03:40:14.779477
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert MiddlewareMixin().middleware(middleware_or_request="request")

# Generated at 2022-06-26 03:40:16.804065
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(lambda request: request)



# Generated at 2022-06-26 03:40:18.136700
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-26 03:40:21.395167
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def middleware(request, response):
        pass
    middleware_mixin_0.middleware(middleware)


# Generated at 2022-06-26 03:40:24.679305
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0.middleware == MiddlewareMixin.middleware


# Generated at 2022-06-26 03:40:26.952103
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()



# Generated at 2022-06-26 03:40:28.842073
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()


# Generated at 2022-06-26 03:40:29.399011
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()


# Generated at 2022-06-26 03:40:38.086428
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.futures import FutureMiddleware

    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = lambda request: request
    future_middleware_0 = FutureMiddleware(middleware_0)
    middleware_1 = lambda request: request
    future_middleware_1 = FutureMiddleware(middleware_1, "response")
    middleware_2 = lambda request: request
    future_middleware_2 = FutureMiddleware(middleware_2, "request")

    # Test body
    middleware_mixin_0.middleware(middleware_0)
    middleware_mixin_0.middleware(middleware_1, "response")
    middleware_mixin_0.middleware(middleware_2, "request")
    assert middleware_mixin_0._future

# Generated at 2022-06-26 03:40:39.846574
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    assert middleware_mixin_1.middleware(None)
    a = middleware_mixin_1.middleware(None, None)
    assert a(None)



# Generated at 2022-06-26 03:40:42.552477
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware, attach_to)
    middleware_mixin_0.middleware(middleware_or_request)


# Generated at 2022-06-26 03:40:46.293470
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    args = (1, 2)
    kwargs = {3:4}
    middleware_mixin_1 = MiddlewareMixin(*args, **kwargs)



# Generated at 2022-06-26 03:40:48.467145
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(None,None)


# Generated at 2022-06-26 03:40:57.946824
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0._apply_middleware = lambda middleware_0: None
    def middleware_0(request, middleware_1):
        assert request == "request"
        assert middleware_1 == "middleware_1"
        return "middleware_2"
    def middleware_1(request, middleware_3):
        assert request == "request"
        assert middleware_3 == "middleware_3"
        return "middleware_4"
    def middleware_2(request, middleware_5):
        assert request == "request"
        assert middleware_5 == "middleware_5"
        return "middleware_6"
    def middleware_3(request, middleware_7):
        assert request == "request"
       

# Generated at 2022-06-26 03:41:01.971766
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_obj = MiddlewareMixin()
    middleware_mixin_obj.middleware("middleware_or_request")


# Generated at 2022-06-26 03:41:05.833229
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(None)


# Generated at 2022-06-26 03:41:09.423596
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin.middleware(lambda x: x) is not None
    assert middleware_mixin.middleware(lambda x: x, attach_to="request") is not None
    assert middleware_mixin.middleware(lambda x: x, attach_to="response") is not None


# Generated at 2022-06-26 03:41:13.267796
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()

    def my_middleware(request):
        pass

    middleware_mixin_1.middleware(middleware_0=my_middleware)

    # with pytest.raises(NotImplementedError):
    #     middleware_mixin_1._apply_middleware()

    middleware_mixin_1.middleware(my_middleware)


# Generated at 2022-06-26 03:41:18.038064
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    assert middleware_mixin_1.middleware == MiddlewareMixin.middleware
    assert middleware_mixin_1.middleware("request") == MiddlewareMixin.middleware("request")


# Generated at 2022-06-26 03:41:22.204796
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    def my_middleware_0():
        middleware_mixin_0._future_middleware.append(FutureMiddleware)
        return FutureMiddleware

    middleware_mixin_0.middleware(my_middleware_0)
    

# Generated at 2022-06-26 03:41:28.026057
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    # Test for the middleware method
    def test_middleware(middleware_or_request, attach_to="request", apply=True):
        return "MiddlewareMixin"
    assert middleware_mixin.middleware(test_middleware, "request") == "MiddlewareMixin"


# Generated at 2022-06-26 03:41:35.594620
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0._future_middleware == []
    def param_middleware_func_0(): pass
    middleware_mixin_0.middleware(param_middleware_func_0, "attach_to_0")
    assert middleware_mixin_0._future_middleware[0].middleware == param_middleware_func_0
    # assert middleware_mixin_0._future_middleware[0].attach_to == attach_to_0


# Generated at 2022-06-26 03:41:37.207507
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(None)


# Generated at 2022-06-26 03:41:47.187302
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    # case 1.1: no argument
    middleware_mixin_1.middleware()
    # case 1.2: attach_to not in middleware_attach_to_list
    middleware_mixin_1.middleware("request")
    # case 1.3: attach_to in middleware_attach_to_list
    middleware_mixin_1.middleware("request")
    # case 1.4: middleware not callable
    middleware_mixin_1.middleware("request", "useless args")
    # case 1.5: middleware callable
    middleware_mixin_1.middleware("request", lambda x: x)


# Generated at 2022-06-26 03:41:56.741937
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def test_middleware(middleware_or_request, attach_to="request"):
        middleware_mixin_0._future_middleware = []
        middleware_mixin_0._apply_middleware = lambda middleware: ""
        if callable(middleware_or_request):
            return middleware_mixin_0.middleware(middleware_or_request, attach_to=attach_to)
        else:
            return partial(middleware_mixin_0.middleware, attach_to=middleware_or_request)

    def middleware(request):
        """
        request: sanic.request.Request

        """
        return
    assert test_middleware(middleware)

# Generated at 2022-06-26 03:42:02.871557
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic()
    middleware_mixin_1 = MiddlewareMixin()



# Generated at 2022-06-26 03:42:10.970357
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = lambda request, response: None
    register_middleware_0 = middleware_mixin_0.middleware(middleware=middleware_0)
    assert_equal(middleware_mixin_0._future_middleware, [])
    assert_equal(register_middleware_0, middleware_0)
    assert_equal(middleware_mixin_0._future_middleware, [])


# Generated at 2022-06-26 03:42:14.255935
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_function_0 = lambda a: None
    middleware_mixin_0.middleware(middleware_function_0)
    assert middleware_function_0 in middleware_mixin_0._future_middleware


# Generated at 2022-06-26 03:42:17.597182
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware()


# Generated at 2022-06-26 03:42:28.833951
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    args = [(), ()]  # type: List[Tuple[FutureMiddleware, FutureMiddleware]]

    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0._future_middleware = args

    def register_middleware(middleware: FutureMiddleware, attach_to: List) -> FutureMiddleware:
        nonlocal args

        future_middleware = FutureMiddleware(middleware, attach_to)
        args.append((future_middleware, attach_to))
        return future_middleware

    middleware_mixin_0.middleware = register_middleware

    middleware_or_request = FutureMiddleware(FutureMiddleware, List)
    attached_to = [List]


# Generated at 2022-06-26 03:42:30.998458
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert callable(middleware_mixin_0.middleware)
    

# Generated at 2022-06-26 03:42:35.935559
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    assert (middleware_mixin.middleware(middleware_or_request)
    ) == partial(register_middleware, attach_to="request")

# Generated at 2022-06-26 03:42:41.777726
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
  middleware_mixin_1 = MiddlewareMixin()
  middleware_mixin_1._future_middleware = []
  middleware_mixin_1._future_middleware.clear()
  
  @middleware_mixin_1.middleware
  async def a_middleware_0(request):
    pass

  @middleware_mixin_1.middleware('request')
  async def a_middleware_1(request):
    pass

  middleware_mixin_1.on_request(a_middleware_1)
  return


# Generated at 2022-06-26 03:42:44.996477
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = partial(middleware_mixin_0.middleware, None, True)
    ret_0 = middleware_0({})
    assert ret_0 == {}


# Generated at 2022-06-26 03:42:50.932098
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    middleware = [lambda a:a]
    middleware_mixin.middleware(middleware)
    assert len(middleware_mixin._future_middleware) == 1
    assert middleware_mixin._future_middleware[0].middleware == middleware


# Generated at 2022-06-26 03:43:05.345868
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0._future_middleware == []
    def middleware_0(request):
        return request
    # result = middleware_mixin_0.middleware(middleware_0, attach_to="request", apply=True)
    result = middleware_mixin_0.middleware(middleware_0, apply=True)
    # print(result)
    # print(middleware_mixin_0._future_middleware)
    assert len(middleware_mixin_0._future_middleware) == 1
    result = middleware_mixin_0.middleware(middleware_0, apply=True)
    # print(result)
    # print(middleware_mixin_0._future_middleware)

# Generated at 2022-06-26 03:43:15.696459
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()

    # Test case 0
    future_middleware_1 = FutureMiddleware(middleware_or_request="middleware_or_request_0", attach_to="attach_to_0")
    middleware_mixin_1._apply_middleware(future_middleware_1)
    # Test case 1
    future_middleware_2 = FutureMiddleware(middleware_or_request="middleware_or_request_1", attach_to="attach_to_1")
    middleware_mixin_1._future_middleware.append(future_middleware_2)
    middleware_mixin_1._apply_middleware(future_middleware_2)



# Generated at 2022-06-26 03:43:16.908352
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

# Generated at 2022-06-26 03:43:24.918150
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    # Test for callable attached by parameter middleware_or_request
    def f(request):
        pass
    middleware_mixin.middleware(f)
    # Test for callable attached via return value
    def g(request):
        pass
    middleware_mixin.middleware("request")(g)
    middleware_mixin.middleware("response")(g)
    middleware_mixin.middleware("request")("response")(g)
    middleware_mixin.middleware("response")("request")(g)


# Generated at 2022-06-26 03:43:26.778685
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()


# Generated at 2022-06-26 03:43:33.501270
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    def m1():
        print('m1')
    from sanic.response import text
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(m1)()
    middleware_mixin_1.middleware(m1, attach_to='response')()
    #middleware_mixin_1.middleware(m1(), attach_to='response')
    middleware_mixin_1.middleware(m1, attach_to='request')()
    middleware_mixin_1.middleware(text('I am a test'))
    #middleware_mixin_1.middleware(text('I am a test'), attach_to='request')
    from sanic.response import text

# Generated at 2022-06-26 03:43:44.934576
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_3 = MiddlewareMixin()
    middleware_mixin_1.middleware('some_string_1', attach_to='request')
    middleware_mixin_2.middleware('some_string_2', attach_to='request')
    middleware_mixin_3.middleware('some_string_3', attach_to='request')
    assert middleware_mixin_1._future_middleware[0].middleware == 'some_string_1'
    assert middleware_mixin_2._future_middleware[0].middleware == 'some_string_2'

# Generated at 2022-06-26 03:43:46.894393
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request=middleware_mixin_0)

# Generated at 2022-06-26 03:43:54.446374
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request_0 = middleware_mixin_0.middleware
    attach_to_0 = middleware_or_request_0
    # Type error
    with pytest.raises(TypeError):
        middleware_mixin_0.middleware(attach_to=attach_to_0,apply=False)


# Generated at 2022-06-26 03:43:56.627105
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    f = lambda: None
    middleware_mixin_0.middleware(f)


# Generated at 2022-06-26 03:44:19.139558
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    try:
        middleware_mixin_0._apply_middleware()
    except NotImplementedError:
        pass

    try:
        middleware_mixin_0._apply_middleware({})
    except NotImplementedError:
        pass



# Generated at 2022-06-26 03:44:21.042733
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    # Test for method middleware of class MiddlewareMixin
    # Test with middleware(middleware_or_request: Callable, attach_to: str, apply: bool):


# Generated at 2022-06-26 03:44:23.293650
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request = True, attach_to = "request", apply = True)


# Generated at 2022-06-26 03:44:28.922986
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    test_middleware_0_0 = middleware_mixin_0.middleware
    test_middleware_0_1 = middleware_mixin_0.middleware("response")
    assert test_middleware_0_1 != None


# Generated at 2022-06-26 03:44:31.002811
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_1 = MiddlewareMixin.middleware
    assert middleware_1 == middleware_mixin_0.middleware

# Generated at 2022-06-26 03:44:40.495953
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    @middleware_mixin_0.middleware('response')
    async def my_response_middleware(request):
        pass

    @middleware_mixin_0.middleware
    async def my_request_middleware(request):
        pass

    assert isinstance(middleware_mixin_0._future_middleware, list)
    assert len(middleware_mixin_0._future_middleware) == 2
    assert isinstance(middleware_mixin_0._future_middleware[0], FutureMiddleware)
    assert isinstance(middleware_mixin_0._future_middleware[1], FutureMiddleware)


# Generated at 2022-06-26 03:44:46.670142
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    result = middleware_mixin.middleware(middleware_or_request="request")
    assert result is not None
    if callable(result):
        result()
    assert result is not None


# Generated at 2022-06-26 03:44:51.528473
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Instantiation of an object of class MiddlewareMixin
    middleware_mixin_0 = MiddlewareMixin()

    # Declaration of a function to be used as a middleware
    @middleware_mixin_0.middleware
    def handler(request):
        return request

    # Checks that the list of future middlewares of middleware_mixin_0 is not empty
    # after the registration of a middleware
    assert len(middleware_mixin_0._future_middleware) > 0


# Generated at 2022-06-26 03:45:00.501605
# Unit test for method middleware of class MiddlewareMixin

# Generated at 2022-06-26 03:45:03.239294
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    def function_0():
        return 1

    ret = middleware_mixin_0.middleware(function_0)
    assert ret == function_0

