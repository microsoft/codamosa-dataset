

# Generated at 2022-06-26 03:37:55.819024
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    #This is a unit test for method _apply_middleware
    #We need to mock the input parameter. If we can not know the type of the
    # input parameter, we need to mock the input parameter as the base class of
    # the type.
    #middleware_1 = MiddlewareMixin()
    #middleware_mixin_0._apply_middleware(middleware_1)

    # Attach the method to local variable
    method = middleware_mixin_0.middleware

    # This is a unit test for middleware

    # Use partial to set default attach_to as 'request'
    # Therefore, we need to call the method with only one parameter
    #middleware_function_1 = MiddlewareMixin()
    #middleware_mixin_0.middle

# Generated at 2022-06-26 03:37:58.076007
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()
    middleware_mixin_0.middleware("request")


# Generated at 2022-06-26 03:38:00.170838
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    MiddlewareMixin().middleware(middleware_or_request=None)


# Generated at 2022-06-26 03:38:03.833834
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    @middleware_mixin_0.middleware
    async def middleware(request):
        return "middleware"

    assert middleware(1) == "middleware"



# Generated at 2022-06-26 03:38:05.766214
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0._future_middleware == []


# Generated at 2022-06-26 03:38:12.972037
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(attach_to="request")
    middleware_mixin_0.middleware(middleware_or_request="request", apply=True)
    middleware_mixin_0.middleware(
        middleware_or_request=middleware_mixin_0.middleware,
        attach_to="response",
        apply=True,
    )

# Generated at 2022-06-26 03:38:15.574323
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert MiddlewareMixin(
        ).middleware()



# Generated at 2022-06-26 03:38:22.022162
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    # with pytest.raises(NotImplementedError) as err:
    #     middleware_mixin_1.middleware("a", "a")
    # assert err.value.__str__() == "<MiddlewareMixin().middleware>"

if __name__ == "__main__":
    import pytest

    pytest.main(["-v", __file__])

# Generated at 2022-06-26 03:38:29.511894
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    middleware_mixin._apply_middleware = Mock()
    middleware = Mock()
    result = middleware_mixin.middleware(middleware)
    assert result == middleware
    assert middleware_mixin._future_middleware[-1].middleware == middleware
    assert middleware_mixin._future_middleware[-1].attach_to == "request"
    assert middleware_mixin._apply_middleware.call_count == 1

# Generated at 2022-06-26 03:38:42.190649
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0._future_middleware == list()
    middleware_mixin_0.middleware(middleware_or_request='request')
    assert middleware_mixin_0._future_middleware == list()
    middleware_mixin_0.middleware(middleware_or_request='response')
    assert middleware_mixin_0._future_middleware == list()
    middleware_mixin_0.middleware(middleware_or_request=lambda: None)
    assert middleware_mixin_0._future_middleware == list()
    middleware_mixin_0.middleware(middleware_or_request=test_case_0)
    assert middleware_mixin_0._future_middleware == list()


# Generated at 2022-06-26 03:38:47.987206
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request=1)


# Generated at 2022-06-26 03:38:51.000776
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware = lambda: None
    middleware_mixin_1.middleware()



# Generated at 2022-06-26 03:39:01.942403
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    @middleware_mixin_0.middleware
    def coro_0():
        pass
    coro_0()

    def coro_1():
        pass
    coro_1 = middleware_mixin_0.middleware(coro_1)
    coro_1()

    @middleware_mixin_0.middleware('request')
    def coro_2():
        pass
    coro_2()

    def coro_3():
        pass
    coro_3 = middleware_mixin_0.middleware('request')(coro_3)
    coro_3()



# Generated at 2022-06-26 03:39:03.552700
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware("middleware_or_request", attach_to="request", apply=True)


# Generated at 2022-06-26 03:39:04.601192
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-26 03:39:08.223951
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request='request')


# Generated at 2022-06-26 03:39:14.420817
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Instantiation
    middleware = MiddlewareMixin()

    # Initial parameter value
    _future_middleware = middleware._future_middleware
    _middleware_or_request = _future_middleware
    _attach_to = 'request'
    _apply = True

    # Invoke method middleware
    middleware.middleware(_middleware_or_request, _attach_to, _apply)

    # Test result
    assert _future_middleware == middleware._future_middleware


# Generated at 2022-06-26 03:39:24.636238
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0.middleware(middleware_or_request='request', attach_to='request', apply=True)
    assert middleware_mixin_0.middleware(middleware_or_request='response', attach_to='response', apply=True)
    assert middleware_mixin_0.middleware(middleware_or_request='request', attach_to='request', apply=False)
    assert middleware_mixin_0.middleware(middleware_or_request=middleware(), attach_to='request', apply=False)
    assert middleware_mixin_0.middleware(middleware_or_request='response', attach_to='response', apply=False)


# Generated at 2022-06-26 03:39:29.842125
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # args: middleware_or_request: Middleware
    # args: attach_to: str

    middleware_mixin_0.middleware(middleware = partial(True))
    middleware_mixin_0.middleware(middleware = partial(True), attach_to = "attach_to_0")


# Generated at 2022-06-26 03:39:32.199292
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware('request')
