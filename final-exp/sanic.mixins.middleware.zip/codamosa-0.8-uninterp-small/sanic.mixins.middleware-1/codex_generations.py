

# Generated at 2022-06-26 03:37:52.413645
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()


# Generated at 2022-06-26 03:37:57.921339
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware = lambda arg_0, arg_1, arg_2, arg_3: None
    attach_to_str_0 = 'request'
    middleware_or_request_unbound_method = middleware_mixin_0.middleware
    attach_to_str_1 = 'request'
    assert False  # replaced by instrumentation


# Generated at 2022-06-26 03:38:03.356439
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    
    # Call method
    result_0 = middleware_mixin_0.middleware()
    
    assert isinstance(result_0, partial), 'Expected type of call result is "partial", but actually "{}".'.format(type(result_0)) 


# Generated at 2022-06-26 03:38:05.341164
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_request()


# Generated at 2022-06-26 03:38:07.197044
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_response("request")

# Generated at 2022-06-26 03:38:17.761254
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    '''
    Test on_response

    Check that on_response has the expected behavior.
    '''
    # Constants
    '''The default string to initialize an empty string.'''
    EMPTY_STRING = ''
    '''The default integer to initialize zero.'''
    ZERO = 0
    '''The default list to initialize an empty list.'''
    EMPTY_LIST = []
    '''The default dictionary to initialize an empty dictionary.'''
    EMPTY_DICT = {}
    '''The default function to initialize None.'''
    EMPTY_FUNCTION = None

    # Variables
    '''The object to test.'''
    middleware_mixin_0 = MiddlewareMixin()
    '''A function to initialize a middleware.'''
    middleware = EMPTY_FUNCTION

# Generated at 2022-06-26 03:38:25.344178
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_mixin_0.middleware(middleware_mixin_0.middleware))
    middleware_mixin_0.middleware(MiddlewareMixin.middleware)
    middleware_mixin_0.middleware(MiddlewareMixin)



# Generated at 2022-06-26 03:38:30.416677
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_2.middleware = lambda x, apply=True: None
    def register_middleware(attach_to="request"):
        nonlocal attach_to
        return middleware_mixin_2.middleware
    return register_middleware


# Generated at 2022-06-26 03:38:42.227976
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def func_0(arg_0: FutureMiddleware) -> bool:
        return arg_0.is_applied is True
    def func_1(arg_0: 'MiddlewareMixin', arg_1: FutureMiddleware) -> 'MiddlewareMixin':
        if True:
            arg_0._future_middleware.append(arg_1)
        return arg_0
    future_middleware_0 = FutureMiddleware(func_0, 'request')
    future_middleware_0.is_applied = True
    assert future_middleware_0.is_applied is True
    assert future_middleware_0.attach_to == 'request'
    assert future_middleware_0.middleware == func_0

# Generated at 2022-06-26 03:38:48.852934
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_input_arg = None
    attach_to_input_arg = None
    apply_input_arg = None
    return_0 = middleware_mixin_0.middleware(middleware_input_arg, attach_to_input_arg, apply_input_arg)
    assert return_0 == None


# Generated at 2022-06-26 03:38:52.712477
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    partial_0: partial = middleware_mixin_0.on_response()
    assert (type(partial_0).__name__ == 'partial')

# Generated at 2022-06-26 03:39:04.088102
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # test default case
    middleware_mixin_0 = MiddlewareMixin()
    method_ret_value_0 = middleware_mixin_0.on_response(middleware=None)
    assert isinstance(method_ret_value_0, partial)

    # test case where callable passed to middleware
    middleware_mixin_1 = MiddlewareMixin()
    assert not hasattr(middleware_mixin_1, "_future_middleware")
    method_ret_value_1 = middleware_mixin_1.on_response(lambda: 1)
    assert isinstance(method_ret_value_1, partial)
    assert hasattr(middleware_mixin_1, "_future_middleware")
    assert len(middleware_mixin_1._future_middleware) == 1
    assert middleware_

# Generated at 2022-06-26 03:39:06.473582
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_1 = MiddlewareMixin()
    middleware = None
    middleware = middleware_mixin_1.on_response(middleware)


# Generated at 2022-06-26 03:39:09.729030
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_request(middleware=None)

# Generated at 2022-06-26 03:39:14.041023
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Pass no argument
    assert MiddlewareMixin().on_response() is not None and callable(MiddlewareMixin().on_response())
    # Pass argument
    assert MiddlewareMixin().on_response(middleware=None) is not None and callable(MiddlewareMixin().on_response(middleware=None))


# Generated at 2022-06-26 03:39:15.890205
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Setup
    middleware_mixin = MiddlewareMixin()
    middleware_mixin.on_request()



# Generated at 2022-06-26 03:39:18.926467
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_request()
    middleware_mixin_1.on_request(middleware=None)


# Generated at 2022-06-26 03:39:24.792618
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    with pytest.raises(NotImplementedError):
        middleware_mixin_1._apply_middleware(middleware_mixin_1)

    with pytest.raises(NotImplementedError):
        middleware_mixin_1.middleware()


# Generated at 2022-06-26 03:39:28.322377
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    
    # Create a MiddlewareMixin object and call the on_response method to set it
    obj_0 = MiddlewareMixin()
    obj_0.on_response()


# Generated at 2022-06-26 03:39:31.233635
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    @middleware_mixin_0.on_request
    def func_for_test_on_request(request):
        pass


# Generated at 2022-06-26 03:39:38.353877
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = partial(middleware_mixin_0.middleware, attach_to="request")
    middleware_func_0 = middleware_0(middleware_mixin_0.middleware)
    middleware_mixin_0._apply_middleware(middleware_func_0)


# Generated at 2022-06-26 03:39:43.807166
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    future_middleware_0 = FutureMiddleware()
    str_0 = future_middleware_0.attach_to
    str_1 = future_middleware_0.middleware
    middleware_mixin_0._apply_middleware(future_middleware_0)
    middleware_mixin_0._future_middleware.append(future_middleware_0)
    future_middleware_0 = FutureMiddleware()
    middleware_mixin_0._future_middleware.append(future_middleware_0)
    callable_0 = middleware_mixin_0.middleware


# Generated at 2022-06-26 03:39:50.068883
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    middleware_mixin_1 = MiddlewareMixin()

    def x():
        return "hello"
    
    assert x() == "hello"
    assert middleware_mixin_1.middleware(x)() == "hello"

    middleware_mixin_2 = MiddlewareMixin()

    def x(y):
        return y

    assert x(1) == 1
    assert middleware_mixin_2.middleware(x)(2) == 2

# Generated at 2022-06-26 03:39:52.718401
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_request()



# Generated at 2022-06-26 03:39:53.561733
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass


# Generated at 2022-06-26 03:39:56.454428
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    @middleware_mixin_0.on_request
    def handler_0():
        ...



# Generated at 2022-06-26 03:39:59.725934
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    success = False
    try:
        middleware_mixin_1.on_request()
    except:
        success = True

    assert success


# Generated at 2022-06-26 03:40:04.219822
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    for i in range(2):
        middleware_mixin_1.on_request(middleware=None)


# Generated at 2022-06-26 03:40:14.434268
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # case 0
    middleware_mixin_0 = MiddlewareMixin()
    # case 1
    middleware_mixin_1 = MiddlewareMixin()
    def middleware(request: Request) -> Response:
        return Response(b"abc", status=200)
    middleware_mixin_1.on_request(middleware)
    assert middleware_mixin_1._future_middleware[0].attach_to == "request"
    # case 2
    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_2.on_request()(middleware)
    assert middleware_mixin_2._future_middleware[0].attach_to == "request"
    # case 3
    middleware_mixin_3 = MiddlewareMixin()
    middleware_mixin_3

# Generated at 2022-06-26 03:40:16.102960
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.on_request(middleware =None )


# Generated at 2022-06-26 03:40:21.641011
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # unit test for case where attach_to='request'
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(arg0=middleware_mixin_0, attach_to='request')


# Generated at 2022-06-26 03:40:26.279211
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    assert MiddlewareMixin.on_request.__name__ == 'on_request'
    assert MiddlewareMixin.on_request.__doc__ == '\n    ' + \
        'Auto add a request middleware\n    ' + \
        'on_request(middleware=None)'


# Generated at 2022-06-26 03:40:28.476332
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_2.on_request()

# Generated at 2022-06-26 03:40:31.397133
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request=middleware_mixin_0, apply=False)


# Generated at 2022-06-26 03:40:35.909355
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_1 = lambda x: x
    # Apply function
    middleware_mixin_1.on_request(middleware_1)

    # Apply partial function
    middleware_mixin_1.middleware(partial(
        middleware_mixin_1.on_request, middleware_1))


# Generated at 2022-06-26 03:40:42.769771
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    print('Testing middleware')
    middleware_mixin_1 = MiddlewareMixin()
    assert middleware_mixin_1._future_middleware == []
    middleware_mixin_1.middleware('request')
    assert middleware_mixin_1._future_middleware == []


# Generated at 2022-06-26 03:40:47.784357
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    # Make MiddlewareMixin instance
    middleware_mixin = MiddlewareMixin()

    # Call method on_request of MiddlewareMixin
    assert middleware_mixin.on_request() == middleware_mixin.middleware(None, 'request')


# Generated at 2022-06-26 03:40:49.923782
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()

    assert middleware_mixin_0.on_request() is not None


# Generated at 2022-06-26 03:40:54.521276
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # On request method should return a partial function with attach_to as request
    partial_function = MiddlewareMixin.on_request(MiddlewareMixin(), None)
    assert partial_function.args == ()
    assert partial_function.keywords == {'attach_to': 'request'}


# Generated at 2022-06-26 03:41:06.906134
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    request_0 = middleware_mixin_0.middleware
    request_1 = middleware_mixin_0.middleware
    request_2 = middleware_mixin_0.middleware
    request_3 = middleware_mixin_0.middleware
    request_4 = middleware_mixin_0.middleware
    request_5 = middleware_mixin_0.middleware
    request_6 = middleware_mixin_0.middleware
    request_7 = middleware_mixin_0.middleware
    request_8 = middleware_mixin_0.middleware
    request_9 = middleware_mixin_0.middleware
    request_10 = middleware_mixin_0.middleware
    request_11 = middleware_

# Generated at 2022-06-26 03:41:13.223046
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = MiddlewareMixin()
    # Test case 0 - The callable attach_to parameter is set to request
    middleware_mixin_1.middleware(attach_to='request')
    # Test case 1 - The callable attach_to parameter is set to response
    middleware_mixin_2.middleware(attach_to='response')


# Generated at 2022-06-26 03:41:17.714676
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0._future_middleware == []

    # TODO: Implement test for method middleware of class MiddlewareMixin
    pass



# Generated at 2022-06-26 03:41:20.494676
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request="request")


# Generated at 2022-06-26 03:41:25.383207
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware = None
    attach_to = "request"
    apply = True
    assert middleware_mixin_0.middleware(middleware, attach_to, apply) is None
    assert middleware_mixin_0._apply_middleware(middleware) is None


# Generated at 2022-06-26 03:41:28.905619
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    mw = lambda x, y: x + y
    middleware_mixin_0.middleware("request")(mw)


# Generated at 2022-06-26 03:41:36.441243
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()

    # Test default case
    with pytest.raises(NotImplementedError):
        middleware_mixin_1._apply_middleware(
            FutureMiddleware(None, "")
        )

    # Test with partial function
    with pytest.raises(NotImplementedError):
        middleware_mixin_1.middleware(None)

    # Test with partial function
    with pytest.raises(NotImplementedError):
        middleware_mixin_1.middleware(lambda: None)

# Generated at 2022-06-26 03:41:38.269928
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_1 = lambda request, response: 1
    middleware_mixin_0.middleware(middleware_1, True)

# Generated at 2022-06-26 03:41:49.538069
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    future_middleware_0 = FutureMiddleware(middleware=None, attach_to=None)
    future_middleware_1 = FutureMiddleware(middleware=None, attach_to=None)
    middleware_mixin_0.middleware(middleware=partial(FutureMiddleware, future_middleware_0, attach_to="request"), attach_to="request")
    middleware_mixin_0.middleware(middleware=lambda: middleware_mixin_0.middleware(middleware=partial(FutureMiddleware, future_middleware_1, attach_to="request"), attach_to="request"), attach_to="request")
    assert middleware_mixin_0._future_middleware[0] == future_middleware_0
    assert middleware_mixin

# Generated at 2022-06-26 03:41:51.489623
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()


# Generated at 2022-06-26 03:41:56.041086
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_middleware_0 = MiddlewareMixin()
    # Verify that method middleware raises NotImplementedError

    with pytest.raises(NotImplementedError):
        middleware_mixin_middleware_0.middleware(
            middleware_or_request=middleware_or_request,
            attach_to=attach_to,
            apply=True,
        )


# Generated at 2022-06-26 03:42:03.013104
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Arrange
    middleware_mixin = MiddlewareMixin()
    # Act
    middleware_mixin.middleware("request")



# Generated at 2022-06-26 03:42:07.434954
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(None)



# Generated at 2022-06-26 03:42:08.586234
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert callable(MiddlewareMixin.middleware(_, _, _))


# Generated at 2022-06-26 03:42:12.205880
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = FutureMiddleware(
        middleware=lambda request: request, attach_to="request"
    )
    attach_to="request"
    apply=True

    middleware_mixin_0.middleware(middleware_or_request, attach_to, apply)

# Generated at 2022-06-26 03:42:15.893904
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = middleware_mixin_0
    attach_to = 'request'
    apply = True

    # Call method middleware of class MiddlewareMixin
    result = middleware_mixin_0.middleware(middleware_or_request, attach_to, apply)


# Generated at 2022-06-26 03:42:25.248408
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = MiddlewareMixin()

    @middleware_mixin_1.on_request
    def middleware_mixin_1_middleware_1():
        pass

    @middleware_mixin_1.on_request
    def middleware_mixin_2_middleware_2():
        pass

    @middleware_mixin_2.on_request
    def middleware_mixin_3_middleware_3():
        pass

    @middleware_mixin_2.on_request
    def middleware_mixin_4_middleware_4():
        pass



# Generated at 2022-06-26 03:42:28.635220
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = "AT"
    attach_to = "request"
    apply = True
    assert False  # TODO: implement your test here


# Generated at 2022-06-26 03:42:31.974864
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    fm = FutureMiddleware(middleware_or_request=None, attach_to="request")
    middleware_mixin_1._apply_middleware(fm)


# Generated at 2022-06-26 03:42:36.698664
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    form_data_0 = {}
    middleware_mixin_0.middleware(form_data_0)


# Generated at 2022-06-26 03:42:39.407866
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    instance = MiddlewareMixin()
    middleware = lambda request: request
    _attach_to = "request"
    instance.middleware(middleware, _attach_to)



# Generated at 2022-06-26 03:42:50.543395
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    partial_0 = partial(middleware_mixin_0.middleware, attach_to="request")
    partial_1 = partial_0(middleware_mixin_0.on_request)
    middleware_mixin_0._apply_middleware(FutureMiddleware(middleware_mixin_0.on_request, "request"))


# Generated at 2022-06-26 03:42:52.420418
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware("request", True)


# Generated at 2022-06-26 03:42:58.069230
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    # Test Case 0:
    assert middleware_mixin_1.middleware(
        lambda a,b,c,d,e,f,g,h: (a,b,c,d,e,f,g,h)
    )(lambda a,b,c,d,e,f,g,h: (a,b,c,d,e,f,g,h))(1,2,3,4,5,6,7,8) == (1, 2, 3, 4, 5, 6, 7, 8)
    # Test Case 1:

# Generated at 2022-06-26 03:42:59.348605
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    _middleware_or_request = 'request'
    middleware_mixin_1 = MiddlewareMixin()
    assert callable(middleware_mixin_1.middleware(_middleware_or_request))


# Generated at 2022-06-26 03:43:00.586790
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    result = middleware_mixin_0.middleware



# Generated at 2022-06-26 03:43:03.494119
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    main_middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request_0 = True  # type: bool
    middleware_0 = main_middleware_mixin_0.middleware(middleware_or_request_0)
    middleware_0(middleware_or_request_0)


# Generated at 2022-06-26 03:43:05.966057
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware("request")


# Generated at 2022-06-26 03:43:12.216682
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    # Test 1, middleware_or_request equal None, attach_to equal "request"
    middleware_0 = lambda request, response: response
    middleware_mixin_0.middleware(middleware_0)
    assert middleware_mixin_0._future_middleware == [FutureMiddleware(middleware_0, "request")]


# Generated at 2022-06-26 03:43:14.343312
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Arrange
    middleware_mixin_0 = MiddlewareMixin()

    # Act
    middleware_mixin_0.middleware(None)


# Generated at 2022-06-26 03:43:25.589088
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    MiddlewareMixin_0 = MiddlewareMixin()
    # call to_asyncio
    # call sanic.asyncio_compat.open_connection
    # call asyncio.get_event_loop
    # call asyncio.new_event_loop
    # call socket.socket
    # call socket.setblocking
    # call socket.connect
    # call asyncio.set_event_loop
    # call asyncio.get_event_loop
    # call asyncio.get_event_loop
    # call asyncio.new_event_loop
    # call socket.socket
    # call socket.setblocking
    # call socket.connect
    # call asyncio.set_event_loop
    # call asyncio.get_event_loop
    # call asyncio.new_event_loop
    # call socket.socket


# Generated at 2022-06-26 03:43:38.064591
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Init Arguments
    middleware_mixin_1 = MiddlewareMixin()

    with pytest.raises(NotImplementedError,
                       match="(_apply_middleware\(self, middleware: "
                       "FutureMiddleware\))"):
        middleware_mixin_1._apply_middleware(FutureMiddleware(None, None))

    # Init Arguments
    middleware_mixin_2 = MiddlewareMixin()

    with pytest.raises(NotImplementedError,
                       match="(_apply_middleware\(self, middleware: "
                       "FutureMiddleware\))"):
        middleware_mixin_2._apply_middleware(FutureMiddleware(None, None))

    # Case 0: Attach to request
    middleware_mixin_3 = MiddlewareMixin()


# Generated at 2022-06-26 03:43:43.102069
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    callable_0 = lambda : None
    future_middleware_0 = middleware_mixin_0.middleware(
        callable_0, 'request'
    )
    assert future_middleware_0 is not None
    assert isinstance(future_middleware_0, FutureMiddleware)



# Generated at 2022-06-26 03:43:48.621976
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    try:
        _On_request_0 = on_request
    except NameError:
        pass
    else:
        if callable(_On_request_0):
            _On_request_0 = _On_request_0()
        else:
            _On_request_0 = _On_request_0
        _On_request_0 = _On_request_0
    _On_request_0 = _On_request_0
    _On_response_0 = on_response
    if callable(_On_response_0):
        _On_response_0 = _On_response_0()
    else:
        _On_response_0 = _On_response_0
    _On_response_0 = _On_response_0
    _On_response_0 = _On_response_0

# Generated at 2022-06-26 03:43:50.604274
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()



# Generated at 2022-06-26 03:43:53.452183
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    ret = MiddlewareMixin().middleware(FutureMiddleware())
    assert type(ret) is FutureMiddleware


# Generated at 2022-06-26 03:43:56.063122
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(middleware_or_request=str, attach_to="request", apply=True)


# Generated at 2022-06-26 03:44:07.223787
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def test_middleware_0(middleware_or_request, attach_to="request", apply=True):
        nonlocal middleware_mixin_0
        def register_middleware(middleware, attach_to="request"):
            nonlocal middleware_mixin_0
            future_middleware = FutureMiddleware(middleware, attach_to)
            middleware_mixin_0._future_middleware.append(future_middleware)
            if apply:
                middleware_mixin_0._apply_middleware(future_middleware)
            return middleware
        if callable(middleware_or_request):
            return register_middleware(middleware_or_request, attach_to=attach_to)

# Generated at 2022-06-26 03:44:17.858894
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from random import random
    from types import TracebackType
    from typing import (
        Any,
        Callable,
        List,
        Tuple,
        Type,
        TypeVar,
        Union,
    )

    Middleware = Callable[..., Any]
    Request = TypeVar("Request")
    Response = TypeVar("Response")
    Exception = TypeVar("Exception")

    class Context:
        def __init__(self):
            pass

    class MiddlewareMixin:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass


# Generated at 2022-06-26 03:44:19.425752
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()


# Generated at 2022-06-26 03:44:22.967296
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_2 = MiddlewareMixin()
    with pytest.raises(NotImplementedError):
        middleware_mixin_2._apply_middleware(FutureMiddleware("foo", "bar"))


# Generated at 2022-06-26 03:44:46.891212
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    @middleware_mixin_0.middleware
    def middleware_0():
        return True

    assert middleware_0() == True




# Generated at 2022-06-26 03:44:48.580406
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    pass


# Generated at 2022-06-26 03:44:52.902334
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    attach_to_2: str = "request"
    apply_3: bool = True
    middleware_mixin_1.middleware(middleware_mixin_1, attach_to, apply)


# Generated at 2022-06-26 03:44:54.138288
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()



# Generated at 2022-06-26 03:44:59.059128
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = lambda request, a: None
    middleware_1 = lambda request, a = None: None

# Generated at 2022-06-26 03:45:00.467951
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

# Generated at 2022-06-26 03:45:02.963051
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    switcher = {
        0: partial(MiddlewareMixin().middleware, MiddlewareMixin(), "request")
    }

    assert switcher.get(0, lambda: "nothing")() is not None



# Generated at 2022-06-26 03:45:08.117456
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    middleware_or_request_0 = 'request'
    attach_to_0 = 'request'
    apply_0 = True

    assert middleware_mixin_0.middleware(middleware_or_request_0, attach_to_0, apply_0) == None


# Generated at 2022-06-26 03:45:10.112961
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0._future_middleware == []


# Generated at 2022-06-26 03:45:19.097055
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    test_middleware_0 = lambda request: request["arg"]
    try:
        # Test case with arguments
        middleware_mixin_0.middleware(
            test_middleware_0, attach_to="request", apply=True
        )
    except NotImplementedError:
        pass
    try:
        # Test case with arguments
        partial_obj = partial(
            middleware_mixin_0.middleware, attach_to="request"
        )
        middleware_1 = lambda request: request["arg"]
        partial_obj(middleware_1)
    except NotImplementedError:
        pass
    finally:
        pass
