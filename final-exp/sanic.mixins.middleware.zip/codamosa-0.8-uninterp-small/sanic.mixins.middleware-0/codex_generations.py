

# Generated at 2022-06-26 03:37:47.833505
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    # Test if MiddlewareMixin class has method middleware.
    assert hasattr(MiddlewareMixin, 'middleware')
    assert callable(getattr(MiddlewareMixin, 'middleware'))
    if is_lambda(MiddlewareMixin.middleware):
        assert True
    else:
        assert False


# Generated at 2022-06-26 03:37:50.482078
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware("request")

# Generated at 2022-06-26 03:37:53.190760
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    test_case = "middleware()"
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware("request")

# Generated at 2022-06-26 03:37:55.118915
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware(middleware_mixin_1, "request", 2)


# Generated at 2022-06-26 03:37:55.986138
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert True is True



# Generated at 2022-06-26 03:38:04.103945
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_1 = lambda request: request
    arg_0 = middleware_1
    result = middleware_mixin_1.middleware(arg_0)
    assert type(result) == type(middleware_1)
    assert result == middleware_1
    assert middleware_mixin_1._future_middleware == [FutureMiddleware(
        middleware_1, "request"
    )]

    middleware_mixin_2 = MiddlewareMixin()
    middleware_mixin_2._future_middleware = [FutureMiddleware(
        middleware_1, "request"
    )]
    arg_1 = "request"
    result = middleware_mixin_2.middleware(arg_0, arg_1)
    assert type(result)

# Generated at 2022-06-26 03:38:05.014622
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    test_case_0()

# Generated at 2022-06-26 03:38:08.317308
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request=None, attach_to=None, apply=True)


# Generated at 2022-06-26 03:38:17.808087
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    print("Testing MiddlewareMixin.middleware...")
    middleware_mixin = MiddlewareMixin()
    middleware = middleware_mixin.middleware
    assert callable(middleware)
    assert isinstance(middleware, partial)

    middleware_func = lambda x: x
    args_expected = ["middleware_or_request", "attach_to", "apply"]
    assert middleware.args == args_expected
    args_passed = middleware.func.args
    assert len(args_passed) == len(args_expected) + 1
    assert args_passed[0] == "self"
    assert list(args_passed[1:]) == args_expected
    assert middleware.func.keywords is None
    assert middleware.func.__name__ == "register_middleware"


# Generated at 2022-06-26 03:38:23.225050
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware = MiddlewareMixin()
    middleware_mixin_0 = middleware.middleware(middleware_or_request="request",apply=True)
    assert middleware_mixin_0 is not None

# Generated at 2022-06-26 03:38:34.777473
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    ...
    # middleware_mixin_0 = MiddlewareMixin()
    # middleware_mixin_1 = MiddlewareMixin()
    # middleware_mixin_2 = MiddlewareMixin()
    # middleware_mixin_3 = MiddlewareMixin()
    # middleware_mixin_4 = MiddlewareMixin()
    # middleware_mixin_5 = MiddlewareMixin()
    # middleware_mixin_6 = MiddlewareMixin()
    # middleware_mixin_7 = MiddlewareMixin()
    # middleware_mixin_8 = MiddlewareMixin()
    # middleware_mixin_9 = MiddlewareMixin()
    # middleware_mixin_10 = MiddlewareMixin()
    # middleware_mixin_11 = MiddlewareMixin()
    # middleware

# Generated at 2022-06-26 03:38:45.711245
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Case 0: 
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = middleware_mixin_0.middleware("", "", True)
    assert middleware_0("")("") == ""
    middleware_mixin_0.middleware("", "", True)(middleware_0(""))("") == ""
    # Case 1: 
    middleware_mixin_1 = MiddlewareMixin()
    middleware_1 = middleware_mixin_1.middleware("", "", True)
    assert middleware_1("")("") == ""
    middleware_mixin_1.middleware("", "", True)(middleware_1(""))("") == ""
    # Case 2: 
    middleware_mixin_2 = MiddlewareMixin()
    middleware_2

# Generated at 2022-06-26 03:38:47.570346
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    decorator = MiddlewareMixin.middleware



# Generated at 2022-06-26 03:38:48.480074
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # TODO
    pass


# Generated at 2022-06-26 03:38:52.941784
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    future_middleware_0 = FutureMiddleware(middleware_mixin_0, "request")
    # Register middleware
    middleware_mixin_0.middleware(future_middleware_0)
    # Apply middleware
    middleware_mixin_0._apply_middleware(future_middleware_0)


# Generated at 2022-06-26 03:38:55.586441
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request, attach_to)


# Generated at 2022-06-26 03:39:01.181226
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # Python internal test for callable
    middleware_mixin_0.middleware(lambda : None, apply=True)
    lambda x : middleware_mixin_0.middleware(x, apply=True)


# Generated at 2022-06-26 03:39:03.045805
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware


# Generated at 2022-06-26 03:39:09.540356
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()

    def middleware_or_request_0():

        def attach_to_0():
            pass

        attach_to_0()
        pass
    def apply_0():
        pass
    middleware_mixin_1.middleware(middleware_or_request_0, attach_to="request", apply=True)


# Generated at 2022-06-26 03:39:17.878185
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def register_middleware(middleware, attach_to="request"):
        nonlocal apply

        future_middleware = FutureMiddleware(middleware, attach_to)
        middleware_mixin_0._future_middleware.append(future_middleware)
        if apply:
            middleware_mixin_0._apply_middleware(future_middleware)
        return middleware
    # on_request
    def on_request(middleware=None):
        if callable(middleware):
            return middleware_mixin_0.middleware(middleware, "request")
        else:
            return partial(middleware_mixin_0.middleware, attach_to="request")
    # on_response

# Generated at 2022-06-26 03:39:24.435682
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # create object of Class MiddlewareMixin
    middleware_mixin_0 = MiddlewareMixin()
    # call method middleware for class MiddlewareMixin
    middleware_mixin_0.middleware(object(), 'apply_to_request')


# Generated at 2022-06-26 03:39:34.665209
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    def my_middleware(middleware_or_request):
        """
        Decorate and register middleware to be called before a request.
        Can either be called as *@app.middleware* or
        *@app.middleware('request')*

        `See user guide re: middleware
        <https://sanicframework.org/guide/basics/middleware.html>`__

        :param: middleware_or_request: Optional parameter to use for
            identifying which type of middleware is being registered.
        """

    instance_0 = MiddlewareMixin()
    # Case 1: calling on_request
    result_instance0_onreq = MiddlewareMixin.on_request(instance_0)

    # Case 2: calling on_response

# Generated at 2022-06-26 03:39:38.579387
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    future_middleware = middleware_mixin_1.middleware(
        middleware_or_request = None,
        attach_to = "request"
    )


# Generated at 2022-06-26 03:39:40.395430
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()


# Generated at 2022-06-26 03:39:45.734519
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Arrange
    middleware_mixin_0 = MiddlewareMixin()

    # Act
    result_0 = middleware_mixin_0.middleware(lambda request, response: None)

    # Assert

# Generated at 2022-06-26 03:39:47.054156
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0.middleware is not None


# Generated at 2022-06-26 03:39:53.630832
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()

    # member/attribute name: _future_middleware, type: List[FutureMiddleware]
    try:
        # raise Exception('TODO')
        # Code to test if getter function of attribute _future_middleware works
        assert isinstance(middleware_mixin._future_middleware, List[FutureMiddleware])
    except AssertionError as e:
        print('Exception message: {} , attribute name: {}, type: {}'.format(e, "_future_middleware", List[FutureMiddleware]))

    # Test for function decorator pattern
    # Test for function decorator pattern
    # Test for function decorator pattern
    # Test for function decorator pattern
    # Test for function decorator pattern
    # Test for function decorator pattern
    # Test for function decorator pattern



# Generated at 2022-06-26 03:39:57.497711
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0._future_middleware == []
    middleware_mixin_0.middleware(middleware_or_request = 5, attach_to = "request", apply = True)


# Generated at 2022-06-26 03:40:09.388264
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol

    def simple_middleware(request):
        return HTTPResponse('response from middleware')

    def simple_middleware_2(request):
        return HTTPResponse('response from middleware 2')

    app_0 = Sanic('sanic-test')

    @app_0.middleware(apply=False)
    async def attach_key(request):
        print("attach key")
        return request

    app_0.middleware(attach_key)

    protocol_0 = HttpProtocol(
        app_0,
        request_class=Request,
        loop=asyncio.get_event_loop())

    assert app

# Generated at 2022-06-26 03:40:14.590990
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    register_middleware_0 = middleware_mixin_0.middleware
    attach_to_0 = "request"
    apply_0 = True
    middleware_or_request_0 = 123
    assert register_middleware_0(middleware_or_request_0, attach_to_0, apply_0) is None


# Generated at 2022-06-26 03:40:20.044923
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    def dummy_middleware(request):
        assert request == mock.ANY

    # Test for function
    assert middleware_mixin_0.middleware(dummy_middleware) == dummy_middleware


# Generated at 2022-06-26 03:40:23.080376
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    actual = middleware_mixin_0.middleware
    assert callable(actual) == True


# Generated at 2022-06-26 03:40:33.597692
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.response import json

    # def json_response(request):
    #     data = {
    #         "id": 42,
    #         "name": "John Doe",
    #         "occupation": "gardener",
    #     }
    #     return json(data)

    # @middleware_mixin_0.middleware
    # class MyCustomMiddleware:
    #     def __init__(self, request):
    #         self.request = request
    #     def __call__(self, json_response):
    #         print("Do something before the response is returned...")
    #         return json_response(self.request)
    def a(a,b):
        pass
    middleware_mixin_0.middleware(a())

# Generated at 2022-06-26 03:40:34.793028
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    assert True


# Generated at 2022-06-26 03:40:36.886058
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Test 0
    middleware_mixin_0 = MiddlewareMixin()

    # Test 1
    middleware_mixin_1 = MiddlewareMixin()



# Generated at 2022-06-26 03:40:38.706837
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(None, "request", True)


# Generated at 2022-06-26 03:40:41.352845
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    result = middleware_mixin_0.middleware(middleware_or_request='request')
    assert result == partial(middleware_mixin_0.middleware, attach_to='request')


# Generated at 2022-06-26 03:40:43.862506
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    middleware_mixin.middleware(middleware_or_request=1, attach_to=2, apply=True)


# Generated at 2022-06-26 03:40:55.314034
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_lock = threading.Lock()

    class MiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            assert True
            middleware_mixin_lock.release()

    with threading.Lock():
        middleware_mixin_0 = MiddlewareMixin()
        middleware_mixin_lock.acquire()
        middleware_mixin_0.middleware(middleware_mixin_0)
        middleware_mixin_lock.acquire()
        middleware_mixin_0.middleware('request')
        middleware_mixin_lock.acquire()
        middleware_mixin_0.middleware('response')
        middleware_mixin_lock.acquire()
        middleware_mixin_0.middleware

# Generated at 2022-06-26 03:40:58.461633
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    print("test_MiddlewareMixin_middleware")
    middleware_mixin_0 = MiddlewareMixin()
    assert True

# Generated at 2022-06-26 03:41:11.873353
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    mixin_middleware = MiddlewareMixin()
    def method_0(request):
        pass
    def method_1(request):
        pass
    def method_2(request):
        pass
    def method_3(request):
        pass
    def method_4(request):
        pass
    def method_5(request):
        pass

    middleware_0 = mixin_middleware.middleware(method_0)
    middleware_1 = mixin_middleware.middleware(method_1)
    middleware_2 = mixin_middleware.middleware(method_2)
    middleware_3 = mixin_middleware.middleware(method_3)
    middleware_4 = mixin_middleware.middleware(method_4)
    middleware_5 = mixin_middleware.middleware

# Generated at 2022-06-26 03:41:19.834033
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_or_request = partial(middleware_mixin_0.middleware, attach_to="request")
    # middleware_or_request is now a callable object
    # For example, we can call it by using following code
    # middleware_or_request(middleware=None)

if __name__ == "__main__":
    test_case_0()
    test_MiddlewareMixin_middleware()

# Generated at 2022-06-26 03:41:28.434887
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    def middleware_or_request():
        """Mock of middleware_or_request"""
        # pass
    try:
        res_1 = middleware_mixin_1.middleware(middleware_or_request, 'attach_to')
        res_1()
        res_2 = middleware_mixin_1.middleware(middleware_or_request)
        res_2()
        res_3 = middleware_mixin_1.middleware('request', False)
        res_3()
    except Exception as e:
        print(e)


# Generated at 2022-06-26 03:41:32.597502
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request=middleware_mixin_0._future_middleware[1], attach_to="request")

# Generated at 2022-06-26 03:41:38.294909
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Arrange
    middleware_mixin_1 = MiddlewareMixin()
    middleware_1 = 'middleware_1'
    attach_to_1 = 'attach_to_1'
    
    # Act
    ret_val_1 = middleware_mixin_1.middleware(middleware_1, attach_to=attach_to_1)

    # Assert
    assert ret_val_1 == middleware_1


@pytest.mark.asyncio
async def test_case_1():
    middleware_mixin_1 = MiddlewareMixin()


# Generated at 2022-06-26 03:41:39.593958
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
  middleware_mixin_0 = MiddlewareMixin()
  return

# Generated at 2022-06-26 03:41:42.010090
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass # TODO: Implement test


# Generated at 2022-06-26 03:41:42.926990
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    test_case_0()

# Generated at 2022-06-26 03:41:46.770532
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_mixin_0, middleware_mixin_0, attach_to=middleware_mixin_0, apply=False)


# Generated at 2022-06-26 03:41:49.042906
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    middleware_mixin._apply_middleware = lambda x: x

# Generated at 2022-06-26 03:41:57.844193
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    @middleware_mixin_1.middleware
    def case_1(request):
        x = request.args['x'][0]
        request['y'] = int(x) + 1


# Generated at 2022-06-26 03:42:04.528726
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware = lambda x: x
    attach_to = "request"
    future_middleware = FutureMiddleware(middleware, attach_to)
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware, attach_to = "request")
    middleware_mixin_0._apply_middleware(future_middleware)



# Generated at 2022-06-26 03:42:08.629013
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    middleware = lambda request: request
    middleware_mixin.middleware(middleware)


# Generated at 2022-06-26 03:42:12.526999
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert callable(middleware_mixin_0.middleware) # is_true
    assert callable(middleware_mixin_0.middleware()) # is_false
    assert callable(middleware_mixin_0.middleware('hello')) # is_true


# Generated at 2022-06-26 03:42:13.655809
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()



# Generated at 2022-06-26 03:42:16.235921
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware = middleware_mixin_0.middleware
    middleware_0 = middleware('AT', apply=False)
    assert middleware_0.__name__ == 'register_middleware'

# Generated at 2022-06-26 03:42:18.702440
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(lambda request: None)


# Generated at 2022-06-26 03:42:29.045912
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0._future_middleware == []

    @middleware_mixin_0.middleware
    def middleware_0(request):
        return request
    assert middleware_mixin_0._future_middleware == [FutureMiddleware(middleware_0, "request")]

    @middleware_mixin_0.middleware("request")
    def middleware_1(request):
        return request
    assert middleware_mixin_0._future_middleware == [
        FutureMiddleware(middleware_0, "request"),
        FutureMiddleware(middleware_1, "request")
    ]

    @middleware_mixin_0.middleware("response")
    def middleware_2(request):
        return request

# Generated at 2022-06-26 03:42:32.377833
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = middleware_mixin_0.middleware
    middleware = middleware_mixin_0.middleware
    assert middleware_0 is middleware


# Generated at 2022-06-26 03:42:41.314107
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    assert middleware_mixin_1._future_middleware == []
    # Case 1
    middleware_1 = lambda f: f
    attach_to_1 = "request"
    middleware_mixin_1._apply_middleware = lambda middleware: True
    # Test
    assert middleware_mixin_1.middleware(middleware_1, attach_to_1) == middleware_1
    # Test
    assert middleware_mixin_1._future_middleware == [
        FutureMiddleware(middleware_1, attach_to_1)
    ]


# Generated at 2022-06-26 03:42:51.325654
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0.middleware.__name__ == "register_middleware"


# Generated at 2022-06-26 03:42:54.041445
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # arrange
    attach_to = "request"
    middleware = "middleware"
    middleware_mixin = MiddlewareMixin()
    # act
    middleware_mixin.middleware(middleware, attach_to)


# Generated at 2022-06-26 03:42:55.468346
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()

# Generated at 2022-06-26 03:43:01.817332
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.__init__()
    middleware_mixin_0._apply_middleware(None)
    middleware_mixin_0.middleware(middleware_or_request=None, attach_to=None, apply=None)


# Generated at 2022-06-26 03:43:08.680001
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    middleware_mixin._apply_middleware = MagicMock(side_effect=NotImplementedError)
    middleware_mixin.middleware(lambda request, response: None)
    middleware_mixin._apply_middleware.assert_called_with(middleware_mixin._future_middleware[0])


# Generated at 2022-06-26 03:43:16.872535
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    assert len(middleware_mixin._future_middleware) == 0
    result = middleware_mixin.middleware(lambda x: x)
    assert result.__name__ == "lambda"
    assert len(middleware_mixin._future_middleware) == 1
    assert middleware_mixin._future_middleware[0].middleware.__name__ == "lambda"
    assert middleware_mixin._future_middleware[0].attach_to == "request"


# Generated at 2022-06-26 03:43:18.979263
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_middleware = MiddlewareMixin()
    assert middleware_mixin_middleware.middleware == MiddlewareMixin.middleware


# Generated at 2022-06-26 03:43:21.106703
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    assert middleware_mixin_0._future_middleware == []


# Generated at 2022-06-26 03:43:25.281409
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0._apply_middleware()
    middleware_mixin_0.on_request()
    middleware_mixin_0.on_response()

# Generated at 2022-06-26 03:43:30.803858
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware = lambda middleware_or_request, attach_to="request", apply=True: middleware_mixin_0._future_middleware.append(partial(middleware_or_request, 1))
    def function_0(function_parameter_0):
        return function_parameter_0
    middleware_mixin_0.middleware(function_0, 'request')
    assert middleware_mixin_0._future_middleware[-1]() == 1


# Generated at 2022-06-26 03:43:44.067071
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    assert middleware_mixin_0._future_middleware == []


# Generated at 2022-06-26 03:43:54.978225
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1._future_middleware = []
    middleware_mixin_1._apply_middleware = lambda middleware: None
    middleware_or_request_1 = None
    attach_to_1 = "request"
    apply_1 = True
    middleware_1 = middleware_mixin_1.middleware(
        middleware_or_request_1, attach_to_1, apply_1
    )
    middleware_or_request_0 = (
        lambda future, prev_result, *args, **kwargs: None
    )
    attach_to_0 = "response"
    apply_0 = False

# Generated at 2022-06-26 03:43:58.124547
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware(middleware=None)
    middleware_mixin_1.middleware(middleware=None, attach_to='request')

# Generated at 2022-06-26 03:44:04.514065
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    # Test for case 0
    middleware_mixin_1_middleware = middleware_mixin_1.middleware
    # Test for case 1
    middleware_mixin_1_middleware = middleware_mixin_1.middleware


# Generated at 2022-06-26 03:44:09.727204
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from functools import partial
    from typing import List
    def assert_middleware(middleware_mixin: MiddlewareMixin, arg: str, kwarg: str):
        assert middleware_mixin.middleware == arg
        assert middleware_mixin.middleware == kwarg
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware = lambda x, y: assert_middleware(middleware_mixin_0, x, y)
    middleware_mixin_0.middleware("string_arg", kwarg="string_kwarg")


# Generated at 2022-06-26 03:44:12.944776
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request=None, attach_to=None, apply=True)

# Generated at 2022-06-26 03:44:14.332068
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert callable(MiddlewareMixin.middleware)


# Generated at 2022-06-26 03:44:18.410042
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()

    @middleware_mixin_1.middleware
    async def middleware_1(request):
        pass

    @middleware_mixin_1.on_request
    async def middleware_2(request):
        pass

# Generated at 2022-06-26 03:44:19.090278
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware()

# Generated at 2022-06-26 03:44:20.045011
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert middleware_mixin_0._future_middleware == []


# Generated at 2022-06-26 03:44:49.613793
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # assert middleware_mixin_0.middleware() is None
    # assert middleware_mixin_0.middleware() is None
    # assert middleware_mixin_0.middleware() is None


# Generated at 2022-06-26 03:44:50.711370
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()


# Generated at 2022-06-26 03:44:58.168146
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_or_request_1 = None
    attach_to_1 = "request"
    apply_1 = True
    result = middleware_mixin_1.middleware(middleware_or_request_1, attach_to_1, apply_1)
    assert isinstance(result, partial)


# Generated at 2022-06-26 03:45:01.564177
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    try:
        middleware_mixin_1 = MiddlewareMixin()
        test_target = middleware_mixin_1.middleware
        assert callable(test_target)
    except AssertionError:
        raise AssertionError('the target is not callable')



# Generated at 2022-06-26 03:45:06.329082
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    def function():
        pass
    assert middleware_mixin_0.middleware(function, "request_0")

    def function_0():
        pass
    assert middleware_mixin_0.middleware(function_0, "response_0")



# Generated at 2022-06-26 03:45:16.219672
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Given
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_2 = MiddlewareMixin()

    def do_nothing(request, response):
        pass

    # When
    middleware_mixin_1.middleware(do_nothing, attach_to="request", apply=True)
    middleware_mixin_2.middleware(do_nothing, attach_to="request", apply=True)

    # Then
    assert len(middleware_mixin_1._future_middleware) == 1
    assert len(middleware_mixin_2._future_middleware) == 1
    for middleware_mixin in [middleware_mixin_1, middleware_mixin_2]:
        for future_middleware in middleware_mixin._future_middleware:
            assert future_

# Generated at 2022-06-26 03:45:22.427804
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0._future_middleware.append(FutureMiddleware(middleware_or_request = 'request', attach_to = 'request'))
    middleware_mixin_0._future_middleware[0].middleware = middleware_or_request
    middleware_mixin_0._future_middleware[0].attach_to = attach_to
    middleware_mixin_0._future_middleware[0].kwargs = {}


# Generated at 2022-06-26 03:45:27.067728
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_0 = lambda arg: arg
    attach_to_0 = "request"
    apply_0 = True
    actual_returned_value_0 = middleware_mixin_0.middleware(
        middleware_0, attach_to_0, apply_0
    )
    assert actual_returned_value_0 == middleware_0


# Generated at 2022-06-26 03:45:29.707902
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Provided:
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0._apply_middleware = lambda middleware: None

    # Test:
    middleware_mixin_0.middleware(lambda request: None)

    # Teardown:
    del middleware_mixin_0._future_middleware[:]
    del middleware_mixin_0


# Generated at 2022-06-26 03:45:40.870894
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # Create a function to use with the middleware
    def response_middleware(request):
        pass
    # Register the middleware to the 'response' lifecycle
    middleware_mixin_0.middleware(response_middleware, 'response')
    # Make sure the future middleware is registered
    assert middleware_mixin_0._future_middleware[0].func is response_middleware
    assert middleware_mixin_0._future_middleware[0].args == ()
    assert middleware_mixin_0._future_middleware[0].kwargs == {}
    assert middleware_mixin_0._future_middleware[0].attach_to == 'response'
