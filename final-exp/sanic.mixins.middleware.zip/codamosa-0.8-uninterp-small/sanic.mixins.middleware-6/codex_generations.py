

# Generated at 2022-06-26 03:37:43.817189
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    result = middleware_mixin_1.on_request()
    assert result is not None


# Generated at 2022-06-26 03:37:53.150872
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    callable_0 = middleware_mixin_0.on_request()
    assert callable(callable_0)
    callable_1 = middleware_mixin_0.on_response()
    assert callable(callable_1)
    callable_2 = middleware_mixin_0.middleware()
    assert callable(callable_2)
    callable_3 = middleware_mixin_0.middleware('request')
    assert callable(callable_3)
    callable_4 = middleware_mixin_0.middleware('response')
    assert callable(callable_4)


# Generated at 2022-06-26 03:37:56.994178
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class CustomMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            print(middleware)

    middleware_mixin_1 = CustomMiddlewareMixin()
    middleware_mixin_1.middleware(middleware_or_request=lambda request: request)


# Generated at 2022-06-26 03:38:00.052591
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.middleware('request', True)
    middleware_mixin_1.middleware('response', True)
    middleware_mixin_1.on_request(True)
    middleware_mixin_1.on_response(True)

# Generated at 2022-06-26 03:38:02.365741
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    middleware_mixin_1 = MiddlewareMixin()
    response = middleware_mixin_1.on_request()

# Generated at 2022-06-26 03:38:05.243375
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()
    result = middleware_mixin_0.on_request()
    assert result is not None


# Generated at 2022-06-26 03:38:13.622696
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    # Test case 0
    middleware_mixin_0.middleware(attach_to='request')
    # Test case 1
    middleware_mixin_0.middleware(middleware_or_request='request')
    # Test case 2
    middleware_mixin_0.middleware(middleware_or_request='response')
    # Test case 3
    middleware_mixin_0.middleware(middleware_or_request=middleware)


# Generated at 2022-06-26 03:38:25.266343
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Setup
    middleware_mixin_0 = MiddlewareMixin()
    
    # Testing
    # middleware_or_request: Optional parameter to use for identifying which type of middleware is being registered.
    def register_middleware_0(middleware, attach_to="request"):    
        nonlocal apply

        future_middleware_0 = FutureMiddleware(middleware, attach_to)
        middleware_mixin_0._future_middleware.append(future_middleware_0)
        if apply:
            middleware_mixin_0._apply_middleware(future_middleware_0)
        return middleware

    # Detect which way this was called, @middleware or @middleware('AT')

# Generated at 2022-06-26 03:38:28.960387
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    on_response = partial(middleware_mixin_0.middleware, attach_to="response")
    assert callable(on_response)


# Generated at 2022-06-26 03:38:33.277855
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()


# Generated at 2022-06-26 03:38:37.068788
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_result = middleware_mixin_0.on_response()


# Generated at 2022-06-26 03:38:39.012674
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_0 = MiddlewareMixin()


# Generated at 2022-06-26 03:38:43.520128
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware(middleware_or_request=1, attach_to="request")
    middleware_mixin_0.middleware(middleware_or_request=1, attach_to="request", apply=False)


# Generated at 2022-06-26 03:38:46.033828
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin_1 = MiddlewareMixin()
    middleware_mixin_1.on_request()

# Generated at 2022-06-26 03:38:48.527659
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    middleware_mixin_0.middleware("response")


# Generated at 2022-06-26 03:38:53.596765
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # from sanic.app import Sanic
    from sanic.models import MiddlewareMixin

    middleware_mixin_0 = MiddlewareMixin()

    middleware_or_request = None
    attach_to = None
    assert middleware_mixin_0.middleware(middleware_or_request, attach_to) == None
    # assert middleware_mixin_0.middleware(middleware_or_request, attach_to) == None # TODO: check the result.



# Generated at 2022-06-26 03:38:58.413813
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()
    mock_middleware = middleware_mixin_0.middleware
    mock_middleware("request")
    mock_middleware("response")
    mock_middleware("error")



# Generated at 2022-06-26 03:39:09.450117
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin_0 = MiddlewareMixin()

    def mock_register_middleware(middleware, attach_to):
        return middleware

    with mock.patch.object(middleware_mixin_0, "_apply_middleware", lambda: None):
        mock_middleware_or_request = "request"
        middleware_mixin_0.middleware = mock_register_middleware
        assert middleware_mixin_0.middleware(mock_middleware_or_request) == "request"

    def mock_register_middleware(middleware, attach_to):
        return middleware

    with mock.patch.object(middleware_mixin_0, "_apply_middleware", lambda: None):
        mock_middleware_or_request = ""
        middleware_mixin_0.middleware = mock

# Generated at 2022-06-26 03:39:17.825589
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    def test_middleware(request):
        return True

    middleware_mixin_1 = MiddlewareMixin()
    # Call method middleware with argument middleware_or_request
    # and attach_to
    new_middleware = middleware_mixin_1.middleware(test_middleware)
    assert (isinstance(new_middleware, partial))
    # Call method middleware with argument middleware_or_request
    new_middleware = middleware_mixin_1.middleware("request")
    assert (isinstance(new_middleware, partial))
    # Call method middleware with keyword argument middleware_or_request
    # and attach_to
    new_middleware = middleware_mixin_1.middleware(test_middleware,attach_to="request")

# Generated at 2022-06-26 03:39:22.836790
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    class MiddlewareMixinStub(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    middleware_mixin_1 = MiddlewareMixinStub()
    middleware_mixin_1.middleware()