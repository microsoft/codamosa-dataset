

# Generated at 2022-06-24 04:05:53.744135
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class ClassMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(ClassMiddlewareMixin, self).__init__(*args, **kwargs)
    test = ClassMiddlewareMixin()
    assert test._future_middleware == []


# Generated at 2022-06-24 04:06:03.122835
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class SanicMock(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.request = None
            self.response = None

        def _apply_middleware(self, middleware: FutureMiddleware):
            if middleware.attach_to == "request":
                self.request = middleware
            elif middleware.attach_to == "response":
                self.response = middleware

    app = SanicMock()
    @app.middleware
    async def middleware_handler(request):
        pass

    assert type(app.request) == FutureMiddleware
    assert type(app.response) == type(None)

    app = SanicMock()

# Generated at 2022-06-24 04:06:08.505335
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    c = 0
    class MiddlewareMixin_on_response(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            nonlocal c
            c += 1
            assert middleware.attach_to == "response"
    
    test_obj = MiddlewareMixin_on_response()
    test_obj.on_response(lambda : print("response"))()
    assert c == 1


# Generated at 2022-06-24 04:06:11.112405
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    obj = MiddlewareMixin("middleware")
    obj = MiddlewareMixin("middleware", "attach_to")
    obj = MiddlewareMixin("middleware", attach_to="attach_to")
    obj = MiddlewareMixin("middleware", attach_to="attach_to", apply=True)

# Generated at 2022-06-24 04:06:14.791749
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Fake_MiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            print(middleware)

    fake_middlewar_mixin = Fake_MiddlewareMixin()
    fake_middlewar_mixin.middleware(middleware_or_request=None, attach_to="request", apply=True)

# Generated at 2022-06-24 04:06:24.196721
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = App()
    assert len(app._future_middleware) == 0

    @app.middleware
    def middleware_1(request):
        pass

    assert len(app._future_middleware) == 1

    @app.on_response
    def middleware_2(request, response):
        pass

    assert len(app._future_middleware) == 2

    @app.on_request
    def middleware_3(request):
        pass

    assert len(app._future_middleware) == 3

# Generated at 2022-06-24 04:06:33.112166
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware

    # Initialize Sanic server
    app = Sanic('sanic')
    app.config.REQUEST_TIMEOUT = 30
    app.config.RESPONSE_TIMEOUT = 30

    # Register middlewares
    @app.middleware('request')
    async def request_middleware(request):
        request['middleware'] = 'added_by_middleware'

    @app.middleware('response')
    async def response_middleware(request, response):
        response.status = 200

    @app.route('/')
    async def handler(request):
        return response.text('OK')

    # Testing MiddlewareMixin's method middleware() and on_request()

# Generated at 2022-06-24 04:06:39.696289
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    class MockObject:
        pass

    app = Sanic()
    app.on_request(MockObject)
    assert len(app._future_middleware) == 1
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-24 04:06:48.382307
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    class CustomSanic(MiddlewareMixin, Sanic):
        pass

    app = CustomSanic()

    result = []

    @app.on_response
    def record_on_response(request, response):
        result.append(request)
        assert isinstance(response, HTTPResponse)
        return response

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert isinstance(request, Request)

# Generated at 2022-06-24 04:06:55.069615
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # ARRANGE
    from sanic.app import Sanic
    app = Sanic(__name__)

    async def test_method(request):
        return "OK"
    
    @app.on_request
    async def on_request(request):
        return "OK"
    
    # ACT
    app.route("/test", methods=["GET"])(test_method)

    # ASSERT
    client = app.test_client

    _, response = client.get("/test")
    assert response.text == "OK"

# Generated at 2022-06-24 04:07:03.779924
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    log_request_obj = LogRequest()
    app = Sanic('test_MiddlewareMixin_on_response')

    @app.route('/')
    async def handler(request):
        return text('OK')

    @app.on_response
    async def on_response(request, response):
        log_request_obj.store_request(request, response)

    request, response = app.test_client.get('/')

    assert response.status == Status.OK
    assert response.text == 'OK'
    assert log_request_obj.request is not None
    assert log_request_obj.response is not None


# Generated at 2022-06-24 04:07:04.442637
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert False

# Generated at 2022-06-24 04:07:13.852021
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, name, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._name = name

        def _apply_middleware(self, middleware: FutureMiddleware):
            print("{}: applying middleware: {}".format(self._name, middleware))

    @TestMiddlewareMixin("test1").middleware()
    async def middleware_func(request):
        pass

    @TestMiddlewareMixin("test2").middleware("request")
    async def middleware_func(request):
        pass

    @TestMiddlewareMixin("test3").middleware("response")
    async def middleware_func(request, response):
        pass

    # test on_request: same as middleware("request")

# Generated at 2022-06-24 04:07:18.315475
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    print("Unit test for method on_response of class MiddlewareMixin")
    docstring = MiddlewareMixin.on_response.__doc__
    print(docstring)
    a = MiddlewareMixin(1,2)
    # a.on_response()


# Generated at 2022-06-24 04:07:19.999435
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mmix = MiddlewareMixin()
    assert mmix._future_middleware == []

# Generated at 2022-06-24 04:07:26.548013
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    with raises(NotImplementedError):
        MiddlewareMixin()._apply_middleware(1)

    with raises(NotImplementedError):
        MiddlewareMixin().register_middleware(1)

    with raises(NotImplementedError):
        MiddlewareMixin().on_request()

    with raises(NotImplementedError):
        MiddlewareMixin().on_request(middleware=1)

    with raises(NotImplementedError):
        MiddlewareMixin().on_response()

    with raises(NotImplementedError):
        MiddlewareMixin().on_response(middleware=1)

# Generated at 2022-06-24 04:07:28.901648
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Test pass
    a = MiddlewareMixin()
    result = a.on_response("b")
    assert result("test") == "test"

# Generated at 2022-06-24 04:07:38.017039
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class DummyMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []


    def register_middleware(middleware, attach_to):
        nonlocal self

        future_middleware = FutureMiddleware(middleware, attach_to)
        self._future_middleware.append(future_middleware)

    dummy_middleware_mixin = DummyMiddlewareMixin()

    # dummy_middleware_mixin.middleware(register_middleware, "request")
    dummy_middleware_mixin.middleware(register_middleware, "response")

    assert dummy_middleware_mixin._future_middleware[0].attach_to == "response"
    assert dummy_middleware_mix

# Generated at 2022-06-24 04:07:40.340756
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewareMixin = MiddlewareMixin()
    assert isinstance(middlewareMixin._future_middleware, list)


# Generated at 2022-06-24 04:07:42.877184
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-24 04:07:48.146235
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_on_response')

    @app.middleware('response')
    def test_on_response(request, response):
        response.body = b'Custom response'

    request, response = app.test_client.get('/')

    assert response.body == b'Custom response'



# Generated at 2022-06-24 04:07:53.072636
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Root(MiddlewareMixin):
        pass

    root = Root()
    assert isinstance(root._future_middleware, list)
    assert root._future_middleware == []


# Generated at 2022-06-24 04:08:00.974097
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware
    from sanic.server import HttpProtocol

    middle_class = MiddlewareMixin()
    def middleware(request):
        print("this is a middleware")
    middle_class.middleware(middleware)
    assert len(middle_class._future_middleware) == 1
    # A unit test for _apply_middleware()

    # Unit test for method middleware
    sanic_class = Sanic()
    sanic_class.middleware(middleware)
    assert len(sanic_class._future_middleware) == 1
    sanic_class.middleware(middleware, attach_to='request')
    assert len(sanic_class._future_middleware) == 2

    # Unit test for method on_request

# Generated at 2022-06-24 04:08:04.320493
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.testing import HOST, PORT
    app = Sanic(__name__)
    # Test for normal call
    @app.middleware
    async def test(request):
        pass
    app.run(host = HOST, port = PORT + 1)

# Generated at 2022-06-24 04:08:07.662356
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    s = Sanic()
    assert s._future_middleware == []
    assert isinstance(s, MiddlewareMixin)

# Generated at 2022-06-24 04:08:08.169198
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert 0 == 0

# Generated at 2022-06-24 04:08:12.291605
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class DummySanicApp(MiddlewareMixin):
        pass
    app = DummySanicApp()
    assert app._future_middleware == []


# Generated at 2022-06-24 04:08:15.762931
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    @MiddlewareMixin.on_response()
    def new_middleware(request):
        pass

    assert new_middleware.__name__ == "new_middleware"
    assert new_middleware.__middleware__ == "response"


# Generated at 2022-06-24 04:08:16.721147
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewareMixin = MiddlewareMixin()
    assert middlewareMixin._future_middleware == []


# Generated at 2022-06-24 04:08:21.305221
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    def middleware(request):
        pass

    app = Sanic()
    app.middleware(middleware)
    request_middleware = app._future_middleware[0]
    assert request_middleware.attach_to == 'request'
    assert request_middleware.middleware == middleware


# Generated at 2022-06-24 04:08:24.556512
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic

    def middleware_test(request):
        return request

    app = Sanic(__name__)
    response = app.on_response(middleware_test)(request)
    assert response == request


# Generated at 2022-06-24 04:08:26.399318
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    '''
    test method middleware of class MiddlewareMixin
    '''


# Generated at 2022-06-24 04:08:29.400745
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert(MiddlewareMixin().on_response() is not None)

# Generated at 2022-06-24 04:08:38.899815
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import pytest
    import sanic_framework.models.middleware_mixin as middleware_mixin
    
    class ObjectForTest(middleware_mixin.MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            middleware_mixin.MiddlewareMixin.__init__(self, *args, **kwargs)
        
        def _apply_middleware(self, middleware):
            raise NotImplementedError

    class UnitTest:
        unit_test = ObjectForTest()

        def test_on_response_normal_case(self):
            actual = self.unit_test.on_response()
            expected = partial(self.unit_test.middleware, attach_to="response")
            assert actual == expected


# Generated at 2022-06-24 04:08:43.154227
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        
        def _apply_middleware(self, middleware):
            pass

    obj = TestClass()
    assert isinstance(obj, TestClass)


# Generated at 2022-06-24 04:08:43.798321
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-24 04:08:47.949078
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic

    app = Sanic("test_MiddlewareMixin_on_response")

    @app.on_response
    def on_response(request, response):
        pass

    assert app._future_middleware[0].attach_to == 'response'

# Generated at 2022-06-24 04:08:57.311903
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import sanic
    app = sanic.Sanic('test')
    attach_to = "request"

    def register_middleware(middleware, attach_to="request"):
        nonlocal apply

        class FutureMiddleware:
            def __init__(self, middleware, attach_to):
                self.middleware = middleware
                self.attach_to = attach_to

        future_middleware = FutureMiddleware(middleware, attach_to)
        app._future_middleware.append(future_middleware)
        return middleware

    def middleware():
        def d(f):
            return f
        return d

    # Call @middleware()
    register_middleware(middleware())
    assert len(app._future_middleware) == 1
    # Call @middleware('request')
    register_middleware

# Generated at 2022-06-24 04:09:00.037251
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = Sanic()
    app.middleware('request')('test_middleware')
    assert len(app._future_middleware) > 0



# Generated at 2022-06-24 04:09:04.430850
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app=Sanic("test_MiddlewareMixin_on_response")

    @app.on_response("response")
    def test_on_response(request, response):
        response.text += "1"

    request, response = app.test_client.get("/")
    assert response.text == "1"

# Generated at 2022-06-24 04:09:13.166843
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import json
    from sanic import Sanic
    from sanic.response import text

    app = Sanic(__name__)

    @app.middleware
    def my_middleware(request):
        request["called"] = True

        return request

    @app.middleware("request")
    def my_middleware(request):
        request["called"] = True

        return request

    @app.route("/")
    def handler(request):
        return text(json.dumps(request))

    @app.route("/2")
    async def handler2(request):
        return text(json.dumps(request))

    app.config.REQUEST_MAX_MEMORY = 1024

    request, response = app.test_client.get("/")
    assert response.text == '{"called": true}'

   

# Generated at 2022-06-24 04:09:17.580627
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class test_class(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
            self._apply_middleware(MiddlewareMixin.__init__(self, *args, **kwargs))
    test = test_class()
    assert test._future_middleware == []


# Generated at 2022-06-24 04:09:27.169513
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    # Check MiddlewareMixin.middleware() - if middleware_or_request is a callable

    @TestMiddlewareMixin().middleware
    async def middleware_function(request):
        pass

    assert isinstance(middleware_function, types.FunctionType)
    assert middleware_function.__name__ == "middleware_function"

    # Check MiddlewareMixin.middleware() - if middleware_or_request is not a callable

    @TestMiddlewareMixin().middleware('request')
    async def middleware_function(request):
        pass

    assert isinstance(middleware_function, types.FunctionType)

# Generated at 2022-06-24 04:09:34.863756
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic("__main__")

    async def func_middleware(request):
        pass

    app.middleware(func_middleware)

    assert len(app._future_middleware) == 1

    app.middleware('request', func_middleware)

    assert len(app._future_middleware) == 2

    app.middleware('response', func_middleware)

    assert len(app._future_middleware) == 3



# Generated at 2022-06-24 04:09:36.443093
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 04:09:41.903399
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestClass:
        @staticmethod
        def _apply_middleware(middleware): return NotImplementedError

    # Arrange
    middleware: List[FutureMiddleware] = []
    t = TestClass()

    # Act
    t.middleware = MiddlewareMixin.middleware
    t.middleware = MiddlewareMixin.on_request
    t.middleware = MiddlewareMixin.on_response

# Generated at 2022-06-24 04:09:51.012966
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.response import text
    from sanic.request import Request

    class App(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            print("test1")
            assert middleware._middleware(Request('GET', '/'), self) == 'test'

    app = App()

    def middleware(request, app, handler):
        print("test2")
        assert isinstance(request, Request)
        assert app == app
        assert handler is None
        return 'test'

    app.on_response(middleware)


# Generated at 2022-06-24 04:09:55.891959
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import pytest
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_test(request):
        pass

    @app.middleware('response')
    async def response_test(request, response):
        pass

    app.middleware(request_test, 'request', apply=None)
    app.middleware(response_test, 'response', apply=None)



# Generated at 2022-06-24 04:09:58.047442
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    try:
        class testMiddlewareMixin(MiddlewareMixin):
            pass
        obj=testMiddlewareMixin()
        obj.middleware(middleware_or_request=obj,attach_to="request",apply=True)
    except:
        assert False


# Generated at 2022-06-24 04:10:00.507958
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MiddlewareMixinTester(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    tester = MiddlewareMixinTester()
    # Testing without arguments

    # Testing with one argument


# Generated at 2022-06-24 04:10:05.948096
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    from sanic.app import Sanic

    app = Sanic(__name__)
    
    async def middleware(request):
        request['data'] = 'unittest'
        return request        

    app.on_request(middleware)
    
    request = {'data': 'a'}
    app._apply_middleware(app._future_middleware[0])
    assert request['data'] == 'unittest'


# Generated at 2022-06-24 04:10:10.416132
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic

    app = Sanic('sanic-middleware')

    @app.on_response
    def f(request, response):
        pass

    assert app._future_middleware[0].middleware == f

# Generated at 2022-06-24 04:10:12.331358
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Given
    mixin = MiddlewareMixin()

    # Then
    assert mixin._future_middleware == []

# Generated at 2022-06-24 04:10:19.595114
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic(__name__)

    class MyMiddleware:
        def __init__(self, request):
            pass

    @app.middleware
    def echo(request):
        return "middleware"

    @app.on_response
    def on_response(request, response):
        assert response.text == "response"

    @app.route("/")
    async def handler(request):
        return text("response")

    request, response = app.test_client.get("/")
    assert response.text == "middleware"

# Generated at 2022-06-24 04:10:23.930447
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TempClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa
    a = TempClass()
    assert a.on_response(lambda x: x) is None

# Generated at 2022-06-24 04:10:31.852153
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, middleware):
            pass
            
    obj = TestMiddlewareMixin()
    def test_middleware(request, response):
        return response
    # Case 1: pass callable
    assert obj.on_response(test_middleware)
    # Case 2: pass non-callable
    assert obj.on_response()


# Generated at 2022-06-24 04:10:38.765521
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Test(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(self, *args, **kwargs)
        def _apply_middleware(self, future_middleware):
            pass
    test = Test()
    assert test.middleware(on_response = test_MiddlewareMixin_on_response) != None
    assert test.middleware(test_MiddlewareMixin_on_response, "response") != None
    assert test.middleware(test_MiddlewareMixin_on_response, "request") != None

# Generated at 2022-06-24 04:10:43.426000
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class testclass(MiddlewareMixin):
        pass
    test_app = testclass()
    @test_app.middleware
    def test_middleware(request):
        pass
    assert len(test_app._future_middleware) == 1
    assert len(test_app._future_middleware) == 1


# Generated at 2022-06-24 04:10:51.995888
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    
    @sanic.middleware('request')
    def my_middleware(request):
        request['foo'] = 'bar'

    @sanic.middleware
    def my_middleware(request):
        request['foo'] = 'bar'
    
    @sanic.middleware('response')
    def my_middleware(request, response):
        request['foo'] = 'bar'
    
    @sanic.middleware(attach_to='response')
    def my_middleware(request, response):
        request['foo'] = 'bar'
    
    @sanic.middleware(attach_to='request')
    def my_middleware(request):
        request['foo'] = 'bar'


# Generated at 2022-06-24 04:11:00.640866
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class A:
        def __init__(self):
            self.middleware = MiddlewareMixin()

    a = A()
    # on_request(middleware)
    @a.middleware.on_request
    def b(request):
        return 1
    assert isinstance(b, type(a.middleware.on_request))
    assert b() == 1
    # on_request()
    b = a.middleware.on_request()
    assert isinstance(b, type(a.middleware.on_request))
    assert b(1) == 1



# Generated at 2022-06-24 04:11:04.147740
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestClass(MiddlewareMixin):
        def __init__(self):
            super(TestClass, self).__init__()

    test_class = TestClass()
    assert test_class._future_middleware == []


# Generated at 2022-06-24 04:11:12.014751
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # class test
    class test(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa
    t = test()

    # Function middleware
    @t.middleware
    @t.middleware('request')
    @t.middleware('response')
    async def middleware_test(request, response=None):
        pass

    # assert
    assert len(t._future_middleware) == 3
    assert t._future_middleware[0].attach_to == "request"
    assert t._future_middleware[1].attach_to == "response"
    assert t._future

# Generated at 2022-06-24 04:11:18.475726
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    def test_a():
        pass
    def test_b():
        pass
    def test_c():
        pass
    app = Sanic('test_MiddlewareMixin_middleware')
    app.middleware(test_a, 'request')
    app.on_request(test_b)
    app.on_response(test_c)
    assert app._future_middleware == [FutureMiddleware(test_a, 'request'), FutureMiddleware(test_b, 'request'), FutureMiddleware(test_c, 'response')]




# Generated at 2022-06-24 04:11:28.094967
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.router import Router
    from sanic.response import json
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketCommonProtocol
    
    
    app = Sanic(__name__)
    router = Router(app, HOST, PORT, debug=True)
    app.router = router
    # Initialize variables of app
    app._state = {}
    app._is_running = False
    app._is_stopping = False
    app._before_start_callbacks = []
    app._before_server_start_callbacks = []
    app._after_start_callbacks = []
    app._before_stop_callbacks = []
    app._after_

# Generated at 2022-06-24 04:11:34.736796
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.response import json

    async def request_middleware(request):
        return json(
            {
                'Msg': "I am on_request", 
                'request': request, 
                'URL': request.url, 
                'method': request.method,
                'path': request.path,
                'query_string': request.query_string
                }
            )

    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware

    app = Sanic()
    app.on_request(request_middleware)

    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert callable(app._future_middleware[0].middleware) == True
    assert app._future_middleware[0].attach_to == 'request'




# Generated at 2022-06-24 04:11:40.574509
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    def add_1(request):
        request['id'] += 1

    class TestMiddle(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.data = 2

        def _apply_middleware(self, middleware):
            self.data = middleware.on_request(self.data)

    test = TestMiddle()
    add_1 = test.on_request(add_1)
    assert test.data == 3

# Generated at 2022-06-24 04:11:41.585933
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass


# Generated at 2022-06-24 04:11:52.043996
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import json
    import uuid
    from sanic import Sanic


    app = Sanic(__name__)

    class Foo(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []


        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa


    f = Foo()

    f.middleware(lambda x: x, attach_to="request")
    f.middleware(lambda x: x, attach_to="response")
    f.middleware(lambda x: x)


    # Test if all the parameters are the same

# Generated at 2022-06-24 04:12:01.878867
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.models import stream
    import unittest

    class Test(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(Test, self).__init__(*args, **kwargs)
            self.test_list = list()
            self.test_list_expect = list()

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.test_list.append('_apply_middleware')

    def is_test(request):
        test.test_list_expect.append('is_test')

    app = Sanic()
    test = Test(app=app)

    test.on_request(is_test)

    stream.run_uvloop()

    assert test.test_list == test

# Generated at 2022-06-24 04:12:04.288255
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_response == app.middleware


# Generated at 2022-06-24 04:12:11.010884
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text
    # code under test
    app = Sanic('test_MiddlewareMixin_on_response')

    @app.route('/')
    def handler(request):
        return text('OK')

    @app.on_response('response')
    def log_response(request, response):
        print(response)
    # end of code under test

    # construct a mock request and response
    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'OK'



# Generated at 2022-06-24 04:12:13.911562
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            print(middleware)
            pass
    test_m = TestMiddlewareMixin()
    assert test_m._future_middleware == []

# Generated at 2022-06-24 04:12:19.492201
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MyMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            self._future_middleware.append(middleware)

    @MyMiddlewareMixin.on_request()
    async def my_middleware(request):
        return request

    assert len(MyMiddlewareMixin()._future_middleware) == 2


# Generated at 2022-06-24 04:12:28.525168
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.exceptions import abort
    from sanic.response import HTTPResponse, text

    app = Sanic('test_sanic_MiddlewareMixin_on_request_app')

    async def handler(request):
        return text('OK')

    @app.route('/')
    async def handler(request):
        return text('OK')

    @app.middleware('request')
    async def process_before_request(request):
        request['processed_before'] = True

    resp = app.test_client.get('/')
    assert resp.text == 'OK'

    @app.middleware('request')
    def process_before_request(request):
        request['processed_before'] = True

    resp = app.test

# Generated at 2022-06-24 04:12:35.933311
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import sanic

    # Test the case when 2 parameters passed
    app = sanic.Sanic()
    @app.middleware('request')
    def request_middleware(request):
        request['processed_by_middleware'] = True

    # Test the case when 1 parameter passed
    @app.middleware
    def response_middleware(request, response):
        response['processed_by_middleware'] = True
    assert True



# Generated at 2022-06-24 04:12:46.332837
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import unittest

    class TestMiddlewareMixin(MiddlewareMixin, unittest.TestCase):
        def __init__(self, *args, **kwargs):
            self.method_called = False
            self.other_method_called = False

        def _apply_middleware(self, future_middleware):
            if future_middleware.middleware is None:
                pass
            else:
                future_middleware.middleware()

        def test_on_response(self):
            @self.on_response(self.response_middleware)
            def test_on_response():
                pass

            test_on_response()

            self.assertTrue(self.method_called)
            self.assertFalse(self.other_method_called)

        def response_middleware(self):
            self.method_

# Generated at 2022-06-24 04:12:55.898331
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin')

    @app.middleware
    async def middleware1(request):
        assert True
        return await response

    @app.middleware('request')
    def middleware2(request):
        assert True
        return response

    @app.middleware('response')
    def middleware3(request, response):
        assert True
        return response

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'

# Generated at 2022-06-24 04:12:57.595253
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin._future_middleware == []

# Generated at 2022-06-24 04:13:06.711132
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def add_50(request):
        request["number"] += 50
        response = await request.app.handle_request(request, stream=True)
        return response

    @app.route("/")
    async def test(request):
        return json(request["number"])

    @app.middleware("request")
    async def add_20(request):
        request["number"] += 15
        response = await request.app.handle_request(request, stream=True)
        return response

    @app.middleware("response")
    async def add_30(request, response):
        response.text += 5
        return response

    request, response = app

# Generated at 2022-06-24 04:13:13.790050
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
  # Normal usage
  @MiddlewareMixin.on_request()
  async def before_request(request):
    return request

  @MiddlewareMixin.on_response()
  async def after_request(request, response):
    return response

  assert before_request.__name__ == "before_request"
  assert before_request.__wrapped__.__name__ == "before_request"
  assert request.__name__ == "request"

  assert after_request.__name__ == "after_request"
  assert after_request.__wrapped__.__name__ == "after_request"
  assert response.__name__ == "response"

# Generated at 2022-06-24 04:13:25.148003
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class FakeMiddlewareMixin(MiddlewareMixin):
        def __init__(self, apply=True):
            super().__init__()
            self._future_middleware = []
            self.middleware_called = []
            self.attach_to = []
            self.apply=apply

        def _apply_middleware(self, future_middleware):
            self.middleware_called.append(future_middleware.middleware)
            self.attach_to.append(future_middleware.attach_to)

    class FakeOnRequest:
        def __init__(self):
            self.run_called = False
        def run(self):
            self.run_called = True

    fake_on_request = FakeOnRequest()
    fake_middleware_mixin = FakeMiddlewareMixin()
    decorated_on_

# Generated at 2022-06-24 04:13:31.085093
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic(__name__)

    @app.on_response()
    def handler(request, response):
        pass

    assert len(app._future_middleware) == 1
    future_middleware = app._future_middleware[0]
    assert future_middleware.stream == "response"
    assert future_middleware.middleware == handler
    assert future_middleware.args == ()
    assert future_middleware.kwargs == {}

# Generated at 2022-06-24 04:13:37.713675
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic("test_MiddlewareMixin_on_response")

    @app.on_response
    def test_MiddlewareMixin_on_response_handler(request, response):
        response.headers["on_response"] = "on_response"

    @app.route("/")
    async def test_MiddlewareMixin_on_response_handler(request):
        return "ok"

    request, response = app.test_client.get(
        "/", headers={"on_request": "on_request"}
    )
    assert response.headers["on_request"] == "on_request"
    assert response.headers["on_response"] == "on_response"



# Generated at 2022-06-24 04:13:39.175635
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    assert mm._future_middleware == []

# Generated at 2022-06-24 04:13:43.662548
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    def mw():
        return 1
    m.on_request(mw)
    m._apply_middleware(FutureMiddleware(mw, "request"))
    assert m._future_middleware[0].attach_to == "request"


# Generated at 2022-06-24 04:13:50.218802
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.request import Request

    app = Sanic(__name__)

    async def test(request):
        return request

    @app.route("/")
    async def handler(request):
        return text("OK")

    @app.response("application/json")
    async def response_json(request, response):
        return json({"ok": True})

    request, response = app.test_client.get("/")

# Generated at 2022-06-24 04:13:53.770090
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    a = MiddlewareMixin()
    assert not a._future_middleware
    assert a.middleware     # TODO
    assert not a.on_request  # TODO
    assert not a.on_response  # TODO
    print('test_MiddlewareMixin_middleware done')


# Generated at 2022-06-24 04:13:59.645424
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class _MiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    _MiddlewareMixin()


# Generated at 2022-06-24 04:14:09.072095
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    '''单元测试'''
    m = MiddlewareMixin()
    middleware1 = FutureMiddleware(middleware = 'middleware1', attach_to = "request")
    middleware2 = FutureMiddleware(middleware = 'middleware2', attach_to = "request")
    m._future_middleware = [middleware1, middleware2]

    m.middleware = 'middleware3'
    m.attach_to = "request"
    m.apply = True
    future_middleware = FutureMiddleware(middleware=m.middleware, attach_to=m.attach_to)
    m._future_middleware.append(future_middleware)
    m._apply_middleware(future_middleware)

if __name__ == "__main__":
    test_MiddlewareMixin

# Generated at 2022-06-24 04:14:11.270798
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin._future_middleware == []


# Generated at 2022-06-24 04:14:11.869505
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

# Generated at 2022-06-24 04:14:12.914995
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # GIVEN
    MiddlewareMixin()

# Generated at 2022-06-24 04:14:15.684594
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddlewareMixinTest(MiddlewareMixin):
        pass

    m = MiddlewareMixinTest()

    assert m._future_middleware == []


# Generated at 2022-06-24 04:14:18.243320
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    obj = MiddlewareMixin()
    assert type(obj._future_middleware) == list
    assert len(obj._future_middleware) == 0

# Generated at 2022-06-24 04:14:24.274817
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Qux(MiddlewareMixin):
        def __init__(self):
            self.value = True

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.value = False
    q = Qux()
    assert q.value == True
    # @app.middleware
    @q.middleware
    def qux(request):
        return request
    assert q.value == False
    # @app.middleware('request')
    @q.middleware('request')
    def quux(request):
        return request
    assert q.value == False



# Generated at 2022-06-24 04:14:29.682022
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic("test_app")
    app.on_request()

    @app.on_response
    def some_middleware(response):
        response.status = 500

    assert hasattr(app, "middleware")

# Generated at 2022-06-24 04:14:35.109782
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    app.on_request(lambda request: True)
    request, _ = app.asgi.handle_request(
        'GET', '/', {}, b'', ('127.0.0.1', 8000)
    )
    assert request is not None


# Generated at 2022-06-24 04:14:45.842737
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MiddlewareMixinMock():
        def __init__(self, *args, **kwargs):
            super().__init__()
            self._future_middleware = []
        def _apply_middleware(self, middleware):
            raise NotImplementedError
    middleware_mixin_mock = MiddlewareMixinMock()
    class MiddlewareMock():
        def __init__(self, *args, **kwargs):
            super().__init__()
    middleware_mock = MiddlewareMock()
    middleware_mixin_mock.on_request(middleware=middleware_mock)
    assert middleware_mixin_mock._future_middleware[0].middleware == middleware_mock
    assert middleware_mixin_mock._future_middleware[0].attach

# Generated at 2022-06-24 04:14:56.371580
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.models.futures import FutureMiddleware
    from sanic.futures import add_future, is_future
    from sanic.response import text
    from asyncio import coroutine

# Generated at 2022-06-24 04:15:01.180992
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test')
    assert app._future_middleware == []

    @app.middleware('request')
    async def test(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0] == FutureMiddleware(test, attach_to='request')



# Generated at 2022-06-24 04:15:05.141895
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    mm = MiddlewareMixin()

    @mm.on_response
    async def process_response(request, response):
        pass

    assert isinstance(mm._future_middleware[0], FutureMiddleware)
    assert mm._future_middleware[0].middleware == process_response


# Generated at 2022-06-24 04:15:12.127255
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def middleware(self,middleware_or_request, attach_to="request", apply=True):
            self._future_middleware.append(attach_to)
    test = TestMiddlewareMixin()
    # test with middleware = None
    test.on_response(middleware=None)
    assert test._future_middleware == ['response']
    # test with middleware = an anonymous function
    def testFunc():
        pass
    test.on_response(middleware=testFunc)
    assert test._future_middleware == ['response','response']

# Generated at 2022-06-24 04:15:13.771186
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    obj = MiddlewareMixin()
    obj.on_response(middleware=None)



# Generated at 2022-06-24 04:15:17.623900
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import unittest

    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            pass
        def _apply_middleware(self, middleware):
            pass

    success_test = True
    try:
        test = TestMiddlewareMixin()
        @test.on_response()
        def middleware(request):
            pass

    except:
        success_test = False
    finally:
        if success_test:
            unittest.TestCase().assertTrue(success_test)


# Generated at 2022-06-24 04:15:19.769590
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mid = MiddlewareMixin()
    assert mid.middleware(None)



# Generated at 2022-06-24 04:15:23.554529
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    a = MiddlewareMixin()
    assert isinstance(a._future_middleware, List)
    print('Test success: MiddlewareMixin')


# Generated at 2022-06-24 04:15:31.533691
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    @MiddlewareMixin.middleware
    def test_middleware(request):
        return request
    
    @MiddlewareMixin.middleware('response')
    def another_middleware(request, response):
        return response

    assert(test_middleware.__name__ == 'test_middleware')
    assert(another_middleware.__name__ == 'another_middleware')


# Generated at 2022-06-24 04:15:32.627464
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert issubclass(MiddlewareMixin, object)


# Generated at 2022-06-24 04:15:41.036399
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.server import HttpProtocol
    from sanic.app import Sanic

    class SuperTestHttpProtocol(HttpProtocol, MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            MiddlewareMixin.__init__(self)

    server = SuperTestHttpProtocol(Sanic(__name__))
    assert len(server._future_middleware) == 0

# Generated at 2022-06-24 04:15:44.096857
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class App(MiddlewareMixin):
        pass

    @App.on_request
    def middleware(request):
        pass
    middleware_list = App._future_middleware
    assert(len(middleware_list) == 1)

# Generated at 2022-06-24 04:15:45.962396
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    x = MiddlewareMixin()
    assert x._future_middleware == []


# Generated at 2022-06-24 04:15:47.555790
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    obj = MiddlewareMixin()
    assert len(obj._future_middleware) == 0


# Generated at 2022-06-24 04:15:49.333804
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    m = MiddlewareMixin()
    assert(m.on_response() == m.on_response)

# Generated at 2022-06-24 04:15:53.199354
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from unittest.mock import MagicMock
    mockMiddlewareMixin = MagicMock()
    mockMiddlewareMixin.middleware.return_value = None
    obj = MagicMock()
    result = MiddlewareMixin.on_response(mockMiddlewareMixin, obj)
    assert result == None