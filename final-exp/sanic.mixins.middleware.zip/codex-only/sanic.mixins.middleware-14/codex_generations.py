

# Generated at 2022-06-24 04:05:58.119808
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass


# Generated at 2022-06-24 04:06:00.208949
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewaremixin1 = MiddlewareMixin()
    assert middlewaremixin1._future_middleware == []



# Generated at 2022-06-24 04:06:07.796526
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import sanic

    class App(MiddlewareMixin):
        pass

    @App.middleware
    async def middleware(request, handler):
        return 200

    assert isinstance(App.middleware, partial)
    assert isinstance(App.on_request(), partial)
    assert isinstance(App.on_request(middleware), partial)
    assert isinstance(App.on_response(), partial)
    assert isinstance(App.on_response(middleware), partial)


# Generated at 2022-06-24 04:06:12.850656
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    @MiddlewareMixin.on_request()
    def on_request_function(request):
        return True

    middleware_mixin = MiddlewareMixin()
    middleware_mixin._future_middleware = ["request1", "response1", "request2", ]
    # then, the method on_request is called
    on_request_function(middleware_mixin)
    # The length of the list with middlware should be increased after calling on_request_function
    assert len(middleware_mixin._future_middleware) == 4

# Generated at 2022-06-24 04:06:19.553234
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')

    @app.on_response
    def on_response(request, response):
        response.headers["app"] = "app_response"

    assert app.on_response == app.middleware(attach_to='response')
    assert app.on_response(on_response) == app.middleware('response')(on_response)

# Generated at 2022-06-24 04:06:24.952128
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic(__name__)
    assert len(app._future_middleware) == 0

    @app.middleware(attach_to='request')
    async def request_mw(request):
        return None

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-24 04:06:33.158732
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # TODO: Implment test
    class MiddlewareMixin(object):
        def __init__(self):
            self._future_middleware=[]
        def _apply_middleware(self,middleware):
            pass
        def middleware(self,middleware_or_request):
             def register_middleware(middleware_or_request):
                self._future_middleware.append(middleware_or_request)
                return middleware_or_request
             return register_middleware(middleware_or_request)
        def on_request(self,middleware=None):
            if callable(middleware):
                return self.middleware(middleware)
            else:
                return self.middleware

# Generated at 2022-06-24 04:06:34.606012
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    MiddlewareMixin()
    return True


# Generated at 2022-06-24 04:06:43.897319
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text

    class MyTestMiddleware:
        async def response(self, request, handler):
            return text("My Test")

    app = Sanic()

    @app.middleware
    class TestMiddleware:
        async def response(self, request, handler):
            return text("Test")

    app.on_response(MyTestMiddleware())

    @app.route("/")
    async def test(request):
        return text("Hello")

    resp = app.test_client.get("/")
    assert resp.text == "My Test"



# Generated at 2022-06-24 04:06:52.649355
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    t = TestMiddlewareMixin()
    @t.middleware
    def request_mock1(request):
        pass

    assert len(t._future_middleware) == 1
    assert t._future_middleware[0].middleware == request_mock1
    assert t._future_middleware[0].attach_to == "request"
    assert callable(t._future_middleware[0].middleware)
    assert not t._future_middleware[0].has_run

    @t.middleware("response")
    def response_mock1(request, response):
        pass

    assert len(t._future_middleware)

# Generated at 2022-06-24 04:06:54.772421
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class App(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()

    assert App()._future_middleware == []

# Generated at 2022-06-24 04:06:55.787802
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TempClass(MiddlewareMixin):
        pass
    TempClass()

# Generated at 2022-06-24 04:07:06.743660
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # for cases:
    # @middleware
    # @middleware('request')
    # @middleware('response')
    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def middleware_one(request):
        assert request

    @app.middleware('request')
    async def middleware_two(request):
        assert request

    @app.middleware('response')
    async def middleware_three(request, response):
        assert request
        assert response

    app.add_route(lambda r: r, '/middleware/one')
    app.add_route(lambda r: r, '/middleware/two')
    app.add_route(lambda r: r, '/middleware/three')

# Generated at 2022-06-24 04:07:08.001983
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    s = MiddlewareMixin()
    s.on_response()

# Generated at 2022-06-24 04:07:16.469162
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            assert middleware.key == 'request'


# Generated at 2022-06-24 04:07:20.040360
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import sanic
    app = sanic.Sanic()
    assert(app.on_response() == partial(app.middleware, attach_to="response"))

# Generated at 2022-06-24 04:07:21.347930
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []

# Generated at 2022-06-24 04:07:32.189078
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.views import HTTPMethodView

    from sanic_openapi import doc, swagger_blueprint

    class UserView(HTTPMethodView):
        @doc.summary("Get a user")
        @doc.produces({"user": {"name": str, "surname": str}})
        async def get(self, request):
            return text("Not implemented")

        @doc.summary("Create a user")
        @doc.consumes({"user": {"name": str, "surname": str}}, location="body")
        async def post(self, request):
            return text("Not implemented")

    app = Sanic("test_app")
    app.blueprint(swagger_blueprint)

# Generated at 2022-06-24 04:07:34.494207
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        pass
    s = TestMiddlewareMixin()
    t = s.on_response()
    assert callable(t)



# Generated at 2022-06-24 04:07:35.530131
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    obj = MiddlewareMixin()
    assert obj._future_middleware == []

# Generated at 2022-06-24 04:07:43.734777
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic(__name__)

    @app.middleware('response')
    async def test_middleware(request):
        pass

    assert isinstance(app, MiddlewareMixin)
    assert app.on_response(test_middleware)().__name__ == 'test_middleware'
    assert app.on_response('response')(test_middleware)().__name__ == 'test_middleware'
    assert app.on_response(test_middleware)().__name__ == 'test_middleware'


# Generated at 2022-06-24 04:07:48.477651
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app=Sanic()

    # Class MiddlewareMixin is a class without __init__, so its only one instance.
    # We can use dir function to test the method in class MiddlewareMixin.
    m=dir(MiddlewareMixin)
    #print(m)
    assert 'middleware' in m



# Generated at 2022-06-24 04:07:49.227414
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m = MiddlewareMixin()

# Generated at 2022-06-24 04:07:53.041670
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    assert mm._future_middleware == []
    assert mm.middleware

# Generated at 2022-06-24 04:07:54.990335
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    testmiddlewaremixin = MiddlewareMixin()
    assert(testmiddlewaremixin._future_middleware == [])


# Generated at 2022-06-24 04:08:02.271138
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic(__name__)

    @app.on_response
    async def test_middleware(request, response):
        pass

    assert len(app.middleware_routes.get('response')) == 1
    assert app.middleware_routes.get('response')[0].__name__ == 'test_middleware'

# Generated at 2022-06-24 04:08:10.071078
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    @TestMiddlewareMixin().middleware
    def test_middleware(request):
        pass

    assert test_middleware.__name__ == "test_middleware"
    assert test_middleware.__doc__ is None


# Generated at 2022-06-24 04:08:14.631552
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    def m1():
        return True
    def m2():
        return False
    mm = MiddlewareMixin()
    mm.on_request(m1())
    mm.on_request(m2())
    assert mm._future_middleware[0].middleware() == True
    assert mm._future_middleware[1].middleware() == False


# Generated at 2022-06-24 04:08:22.898006
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import json
    from sanic.response import HTTPResponse
    import asyncio
    import pytest

    cb = lambda x, y: json({"test": x})

    app = Sanic('test_middleware_custom')
    app.on_response(cb)

    @app.route('/')
    async def handler(request):
        return HTTPResponse(body='this is a test'.encode('utf-8'))

    request, response = app.test_client.get('/')

    # on_response must return JSON
    assert response.json == {'test': 'this is a test'}



# Generated at 2022-06-24 04:08:29.882714
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    app = Sanic()
    @app.middleware('request')
    async def print_on_request(request):
        print("I print on request")
    @app.middleware('response')
    async def print_on_response(request, response):
        print("I print on response")
    @app.route('/')
    async def handler(request):
        return json({'hello': 'world'})
    return app.test_client.get('/')

# Generated at 2022-06-24 04:08:40.501046
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestClass:
        def __init__(self):
            self._future_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    TestClass.on_response = MiddlewareMixin.on_response
    TestClass.on_request = MiddlewareMixin.on_request

    obj = TestClass()
    assert not obj._future_middleware
    obj.on_request(lambda x: x)
    obj.on_response(lambda x: x)
    assert len(obj._future_middleware) == 2
    assert obj._future_middleware[0].attach_to == "request"
    assert obj._future_middleware[1].attach_to == "response"
    assert callable(obj.on_request())
    assert callable(obj.on_response())


# Generated at 2022-06-24 04:08:51.534389
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MiddlewareMixin_on_request:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa


# Generated at 2022-06-24 04:08:53.552567
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    newMiddlewareMixin = MiddlewareMixin()
    assert newMiddlewareMixin
    assert newMiddlewareMixin._future_middleware == []

# Generated at 2022-06-24 04:09:03.242033
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic(__name__)

    @app.middleware('request')
    async def add_header(request):
        request.headers['Middleware'] = 'True'

    @app.middleware('request')
    async def add_header_other(request):
        request.headers['Middleware-other'] = 'True'

    @app.middleware('response')
    async def add_header_to_response(request, response):
        response.headers['Middleware'] = 'True'

    @app.route("/on_request")
    async def test(request):
        if request.headers.get("Middleware") == "True":
            return text("OK")
        else:
            raise NotFound

# Generated at 2022-06-24 04:09:07.498036
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    from sanic.response import json 
    app = Sanic()

    async def func(request):
        return json(request.json)

    app.add_route(func, '/')

    class MyMiddlewares(MiddlewareMixin):
        pass

# Generated at 2022-06-24 04:09:14.492419
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class FakeClass(MiddlewareMixin):
        pass
    
    # test with default parameter middleware
    f = FakeClass()
    m = f.on_response()
    assert callable(m)
    assert m.__kwdefaults__['attach_to'] == 'response'
    
    # test with parameter middleware
    def hello():
        pass
    m = f.on_response(hello)
    assert m == hello
    assert f._future_middleware[0].middleware == hello
    assert f._future_middleware[0].attach_to == 'response'
    


# Generated at 2022-06-24 04:09:22.119365
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.futures import FutureMiddleware
    from sanic.blueprints import Blueprint
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import json
    from sanic.exceptions import RequestTimeout

# Generated at 2022-06-24 04:09:23.087179
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert False



# Generated at 2022-06-24 04:09:25.823040
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m = MiddlewareMixin()
    m.middleware = lambda x, y, z: x
    val = m.middleware("hello")("world")("!")
    assert val == "hello"

# Generated at 2022-06-24 04:09:33.166085
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddleware:
        def __call__(self, request):
            pass

    from sanic.app import Sanic
    app = Sanic("test_Sanic_middleware")

    assert len(app._future_middleware) == 0

    # 1
    @app.middleware
    async def test_middleware1(request):
        pass

    assert len(app._future_middleware) == 0
    assert len(app._middleware) == 0

    app._apply_middleware(app._future_middleware[0])

    assert len(app._middleware) == 1

    # 2
    @app.middleware('request')
    def test_middleware2(request):
        pass

    assert len(app._future_middleware) == 1
    assert len(app._middleware) == 1

    app._

# Generated at 2022-06-24 04:09:39.447816
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    class Child(MiddlewareMixin):
        def __init__(self):
            super().__init__()
        async def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    child = Child()
    child.on_request()
    child.on_request(middleware=None)
    child.on_request(middleware=lambda x: None)



# Generated at 2022-06-24 04:09:50.313982
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic 

    class MySanic(Sanic, MiddlewareMixin):
        def handle_request(self, request, write_callback, stream_callback):
            pass

        def _apply_middleware(self, middleware):
            pass
    
    @MySanic.middleware
    async def middleware(request):
        pass

    assert len(MySanic._future_middleware) == 1
    assert MySanic._future_middleware[0].middleware == middleware

    MySanic._future_middleware = []

    @MySanic.middleware('request')
    async def middleware(request):
        pass

    assert len(MySanic._future_middleware) == 1
    assert MySanic._future_middleware[0].middleware == middleware
    assert MySanic._future

# Generated at 2022-06-24 04:09:55.720568
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Obj(MiddlewareMixin):
        def __init__(self):
            super().__init__()
        def _apply_middleware(self,middleware):
            pass
    def middleware(req):
        pass
    obj=Obj()
    obj.middleware(middleware,attach_to="request")
    assert obj._future_middleware[0].middleware==middleware

# Generated at 2022-06-24 04:09:58.209762
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Something(MiddlewareMixin):
        def _apply_middleware(self, *args):
            pass

    something = Something()
    assert isinstance(something.on_request(), partial)
    assert isinstance(something.on_request(lambda req, res: res), partial)


# Generated at 2022-06-24 04:10:00.507401
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    mixin = MiddlewareMixin()
    assert mixin.on_response() is not None

# Generated at 2022-06-24 04:10:03.733558
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Arrange
    expected = []
    actual = 0
    # Act
    # Assert
    actual = MiddlewareMixin._future_middleware
    assert expected == actual
    return



# Generated at 2022-06-24 04:10:12.600133
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # create a fake class to test middleware method
    class fakeClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(fakeClass, self).__init__(*args, **kwargs)
            self.test = 0

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.test = 1

    fakeClass = fakeClass()

    # create a fake middleware
    def fake_middleware(request):
        return response

    fakeClass.middleware(fake_middleware)
    assert fakeClass.test == 1
    assert len(fakeClass._future_middleware) == 1


# Generated at 2022-06-24 04:10:19.548429
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from route_app import app, router
    from sanic.response import json
    from functools import wraps

    @app.middleware('request')
    def add_num(request):
        if not hasattr(request, 'num'):
            request['num'] = 0

        request['num'] += 1

    @router.route('/')
    def handler(request):
        return json({'num': request['num']})

    request, response = app.test_client.get('/')
    assert response.json == {'num': 1}

# Generated at 2022-06-24 04:10:20.798988
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert issubclass(MiddlewareMixin, object)



# Generated at 2022-06-24 04:10:22.653113
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.server import Sanic
    app = Sanic()
    assert app.on_response(middleware='response')



# Generated at 2022-06-24 04:10:26.433442
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    stuff = MiddlewareMixin()
    class TestClass:
        pass

    assert stuff.on_response(TestClass)
    assert stuff.on_response(middleware=TestClass)

# Generated at 2022-06-24 04:10:33.029093
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic(__name__)

    @app.middleware
    def before_request_middleware(request):
        return request

    res = app.on_request(before_request_middleware)
    assert res == before_request_middleware

    @app.on_request(before_request_middleware)
    def test(request):
        return request

    assert test == before_request_middleware



# Generated at 2022-06-24 04:10:39.009619
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.response import HTTPResponse, json
    
    class UserMiddlewareMixin(MiddlewareMixin):
        pass

    userMiddlewareMixin = UserMiddlewareMixin()

    @userMiddlewareMixin.on_response
    def on_response(request, response):
        return json({"OK": True})

    request = 1 # Fake
    response = HTTPResponse({}, status=200)

    on_response(request, response)

# Generated at 2022-06-24 04:10:40.422868
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    app = MiddlewareMixin()
    assert app._future_middleware == []

# Generated at 2022-06-24 04:10:49.380660
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic("test_on_response")

    def handler(request):
        return text("OK")

    @app.on_response("response")
    async def m1(request, response):
        pass

    @app.on_response("response")
    async def m2(request, response):
        pass

    @app.on_response("request")
    async def m3(request):
        pass

    app.add_route(handler, "/")
    assert len(app.response_middleware) == 2
    assert app.response_middleware[0] is m1
    assert app.response_middleware[1] is m2
    assert len(app.request_middleware) == 1
    assert app.request_middleware[0] is m3


# Generated at 2022-06-24 04:10:57.600942
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.server import HTTPServer
    from sanic.base import Sanic

    app = Sanic("test_on_response")
    server_settings = {
        "host": "127.0.0.1",
        "port": 8000,
        "request_timeout": 60,
        "keep_alive": 5,
    }
    server_settings_with_ssl = {
        "request_timeout": 60,
        "keep_alive": False,
        "ssl": {"cert": "./tests/unit_tests/test.pem", "key": "./tests/unit_tests/test.key"},
    }
    server = HTT

# Generated at 2022-06-24 04:11:04.587958
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic(__name__)

    @app.middleware
    def test_middleware(request):
        return request

    assert len(app._future_middleware) == 1
    middleware_obj = app._future_middleware[0]
    assert middleware_obj.middleware is test_middleware
    assert middleware_obj.attach_to == "request"



# Generated at 2022-06-24 04:11:11.019176
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
  from sanic import Sanic

  app = Sanic()

  # on_request is the decorator for adding the middleware to the request
  @app.on_request
  async def my_middleware(request):
      print(request)

  # Test whether on_request is a decorator by checking its type
  assert(type(app.on_request) == partial)

  # Test whether on_request binds the decorator to the "request" as an argument
  assert(app.on_request.args[0] == "request")

  # Test whether on_request works as a decorator
  assert(app.middleware._future_middleware[0]._attach_to == "request")


# Generated at 2022-06-24 04:11:15.906581
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.response import text
    from test_server import TestSanic
    app = TestSanic(__name__)
    
    @app.middleware
    def second(request):
        return text("Hello middleware")
    
    @app.middleware
    def first(request):
        return text("Hello middleware")

    @app.middleware('response')
    def third(request, response):
        return text("Hello middleware")

    assert len(app._future_middleware)==3
    assert app._future_middleware[0]._middleware == first
    assert app._future_middleware[0]._attach_to == "request"
    assert app._future_middleware[2]._middleware == third
    assert app._future_middleware[2]._attach_to == "response"


# Generated at 2022-06-24 04:11:22.617470
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    result = {"test": 1}
    class App(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            nonlocal result
            result = middleware

    app = App()
    app.on_response(lambda x: x)
    assert result["middleware"](lambda x: x)
    assert "response" == result["attach_to"]

# Generated at 2022-06-24 04:11:24.457449
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    M = MiddlewareMixin()
    assert M._future_middleware == []


# Generated at 2022-06-24 04:11:31.865760
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self._middleware = []

        def _apply_middleware(self, middleware):
            self._middleware.append(middleware)

    @A.middleware
    def f():
        pass

    a = A()
    assert len(a._middleware) == 1
    assert issubclass(type(a._middleware[0]), FutureMiddleware)

    @a.middleware
    def g():
        pass

    assert len(a._middleware) == 2
    assert issubclass(type(a._middleware[1]), FutureMiddleware)

    assert len(a._future_middleware) == 2
    assert issubclass(type(a._future_middleware[0]), FutureMiddleware)

# Generated at 2022-06-24 04:11:33.210063
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    with pytest.raises(NotImplementedError):
        MiddlewareMixin()

# Generated at 2022-06-24 04:11:34.579450
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    hasattr(MiddlewareMixin(), 'on_response')
    
    

# Generated at 2022-06-24 04:11:35.042120
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-24 04:11:42.776484
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.wrappers.request import Request
    from sanic.wrappers.response import Response
    
    def m1(request):
        return Response('Response in m1')

    
    def m2(request):
        return Response('Response in m2')
    
    def m3(request):
        return Response('Response in m3')

    app = Sanic()
    app.middleware(m1)
    app.middleware(m2)
    app.middleware(m3)
    response = app.test_client.get('/')
    assert response.text == 'Response in m1'
    assert response.status == 200


# Generated at 2022-06-24 04:11:52.181522
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.futures import ResponseFuture
    from sanic.models.futures import RequestFuture
    from sanic.models.futures import MiddlewareFuture

    class TestMiddleware(MiddlewareMixin):
        def _apply_middleware(self, middleware: MiddlewareFuture):
            pass

    class TestRequest:
        pass
    class TestResponse:
        pass

    test_middleware = TestMiddleware()

    @test_middleware.middleware("request")
    def request_middleware(request):
        return request

    @test_middleware.middleware("response")
    def response_middleware(request, response):
        return response

    @test_middleware.middleware("error")
    def error_middleware(request, error):
        return error

    assert test_middleware._future_

# Generated at 2022-06-24 04:12:01.988502
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Parameters:
        def __init__(self):
            self.app = "app"
            self.request = "request"
            self.attach_to="request"
            self.kwargs={}

    class MiddlewareMock:
        l=[]
        def __call__(self, request):
            self.l.append(request)
            return self.l

    class MMMock(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            return [middleware]

    mm = MiddlewareMock()

    mmm = MMMock()
    p = Parameters()
    mm_l_initial = mm.l.copy()
    mm_l_final = [p.request]
    mm_l = mm(p.request)
    mmm_l_initial = mmm._future_

# Generated at 2022-06-24 04:12:08.644961
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    async def handler(request, response):
        print(response)
        return response
    @app.middleware('response')
    async def response_handler(request, response):
        print(response)
        return response
    @app.middleware('request')
    async def request_handler(request):
        return request
    print(app.middleware)
    print(app.on_response)
    print(app.on_request)


# Generated at 2022-06-24 04:12:13.204928
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic("test_app")

    @app.middleware
    def mw(request):
        pass

    @app.middleware("request")
    def mw_req(request):
        pass

    @app.middleware("response")
    def mw_res(request, response):
        pass

    assert len(app._future_middleware) == 3



# Generated at 2022-06-24 04:12:16.881897
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert isinstance(middleware_mixin, MiddlewareMixin)
    assert isinstance(middleware_mixin._future_middleware, list)


# Generated at 2022-06-24 04:12:23.086005
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.request import Request

    async def test(request: Request):
        return "middleware"

    app = Sanic("sanic-middleware")
    app.middleware(test)

    assert len(app._future_middleware) == 1
    future_middleware = app._future_middleware[0]
    assert future_middleware.middleware == test
    assert future_middleware.attach_to == "request"

# Generated at 2022-06-24 04:12:31.590956
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    middleware_called = []

    @app.middleware
    def middleware_a(request):
        middleware_called.append('a')

    @app.middleware('request')
    def middleware_b(request):
        middleware_called.append('b')

    @app.middleware('request')
    def middleware_c(request):
        middleware_called.append('c')

    @app.middleware('response')
    def middleware_d(request, response):
        middleware_called.append('d')

    @app.middleware('response')
    def middleware_e(request, response):
        middleware_called.append('e')

   

# Generated at 2022-06-24 04:12:32.628281
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # todo: need to be implemented
    pass

# Generated at 2022-06-24 04:12:37.293785
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    x = Sanic()
    def test(request):
        pass
    x.on_request(test)
    assert x._future_middleware[-1].handler == test
    assert x._future_middleware[-1].attach_to == 'request'


# Generated at 2022-06-24 04:12:42.376041
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class test_class(MiddlewareMixin):
        def __init__(self,*args, **kwargs):
            super(test_class,self).__init__(*args, **kwargs)
        def _apply_middleware(self, middleware):
            return middleware
    test = test_class()


# Generated at 2022-06-24 04:12:44.816463
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from unittest.mock import Mock

    class TestClass:
        def __init__(self, *args):
            self.middleware = MiddlewareMixin()

    middleware = Mock()
    TestClass().middleware.on_response(middleware)()
    middleware.assert_called_once()

# Generated at 2022-06-24 04:12:52.258158
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.views import HTTPMethodView
    from sanic import response

    app = Sanic('test_MiddlewareMixin_middleware')

    def response_middleware(request, response):
        return response

    def request_middleware(request):
        return response.text('Awesome!')

    @app.middleware
    def global_middleware(request):
        return response.text('Awesome!')

    class B(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self.request = None
            self.response = None
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            if middleware.attach == 'response':
                self

# Generated at 2022-06-24 04:12:54.686092
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic

    app = Sanic()
    assert app._future_middleware is not None

# Generated at 2022-06-24 04:13:02.516086
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestClassToMiddleware(MiddlewareMixin):
        # 实现抽象方法
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    test_inst = TestClassToMiddleware()
    def test_middleware(request, response=None):
        pass
    test_inst.middleware(test_middleware)
    assert test_inst._future_middleware[0].middleware == test_middleware
    assert test_inst._future_middleware[0].attach_to == "request"

# Generated at 2022-06-24 04:13:09.570813
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.futures import FutureMiddleware

    class MockMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            
            self._future_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)
            return middleware

    middleware_mixin = MockMiddlewareMixin()

    @middleware_mixin.on_request()
    async def middleware(request):
        return request

    assert len(middleware_mixin._future_middleware) == 1
    assert isinstance(middleware_mixin._future_middleware[0], FutureMiddleware)
    assert middleware_mixin._future_

# Generated at 2022-06-24 04:13:16.893651
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    print("Testing method on_response of class MiddlewareMixin")
    from sanic.app import Sanic
    def on_request(request):
        print('on_request')
    def on_response(request, response):
        print('on_response')
    app = Sanic()
    app.on_request(on_request) # type: ignore
    app.on_response(on_response) # type: ignore
    assert app.should_execute_middleware(on_request, 'request')
    assert app.should_execute_middleware(on_response, 'response')
    print('\n')

if __name__ == "__main__":
    test_MiddlewareMixin_on_response()

# Generated at 2022-06-24 04:13:18.596531
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    app = Sanic()
    assert (app._future_middleware == [])

# Generated at 2022-06-24 04:13:24.933109
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Scenario: Calling method on_response of class MiddlewareMixin

    # Given that I have a MiddlewareMixin instance
    middleware_mixin = MiddlewareMixin()

    # And I have a callback defined
    def my_callback():
        pass
    
    # When I call on_response with my callback
    on_response = middleware_mixin.on_response(my_callback)

    # Then I expect the on_response function to be the same as my_callback
    assert on_response == my_callback



# Generated at 2022-06-24 04:13:25.909759
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()


# Generated at 2022-06-24 04:13:33.413104
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import json, text

    app = Sanic('test_MiddlewareMixin_on_request')

    @app.on_request
    async def _(request):
        request.test = True

    @app.on_response
    async def _(request, response):
        request.test = False

    @app.route('/')
    def handler(request):
        assert request.test == True
        return json({'test': 'pass'})

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.json == {'test': 'pass'}
    assert request.test == False


# Generated at 2022-06-24 04:13:44.104592
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from unittest import mock
    from sanic.exceptions import InvalidUsage

    @mock.patch('sanic.models.middleware.FutureMiddleware')
    def _test_MiddlewareMixin_middleware(
        mock_FutureMiddleware, *args, **kwargs
    ):
        class TestMiddlewareMixin(MiddlewareMixin):
            def __init__(self, *args, **kwargs) -> None:
                self._future_middleware: List[FutureMiddleware] = []

        test_mw = TestMiddlewareMixin()
        test_mw.middleware(middleware_or_request=mock_FutureMiddleware())
        test_mw.middleware(
            middleware_or_request=mock_FutureMiddleware(),
            attach_to='request', apply=True,
        )
       

# Generated at 2022-06-24 04:13:46.598311
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    test_mixin = MiddlewareMixin()
    assert test_mixin._future_middleware == []

# Generated at 2022-06-24 04:13:56.923621
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Instantiate MiddlewareMixin object
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse
    app = Sanic()
    blueprint = Blueprint('test_bp')
    request = Request(None)
    request.app = app
    request.url = "http://127.0.0.1"
    response = HTTPResponse(body="Testing")

    # on_response
    @blueprint.middleware('response')
    async def print_on_response(request, response):
        print(response)
    blueprint.middleware(print_on_response, apply=False)
    blueprint.middleware(print_on_response, apply=False)
    # on_response is supposed to be called 3 times,

# Generated at 2022-06-24 04:14:00.980112
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Test(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    test = Test()
    assert not test._future_middleware



# Generated at 2022-06-24 04:14:04.496019
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin = MiddlewareMixin()

    @middleware_mixin.on_request
    def test(request):
        pass

    assert middleware_mixin._future_middleware[0]._attach_to == "request"


# Generated at 2022-06-24 04:14:07.062282
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    program = MiddlewareMixin()
    program.middleware(middleware_or_request= "request", attach_to="request")



# Generated at 2022-06-24 04:14:12.492577
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    a = MiddlewareMixin()
    def middleware(request):
        return request
    b = a.on_response(middleware=middleware)
    print(b)
    assert b() == None


if __name__ == '__main__':
    test_MiddlewareMixin_on_response()

# Generated at 2022-06-24 04:14:13.568765
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    a = MiddlewareMixin()
    # noqa

# Generated at 2022-06-24 04:14:17.762485
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(TestMiddlewareMixin, self).__init__(*args, **kwargs)

    m = TestMiddlewareMixin()
    assert m._future_middleware is []

# Generated at 2022-06-24 04:14:20.847452
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewareMixin = MiddlewareMixin()
    assert isinstance(middlewareMixin, MiddlewareMixin)

# Generated at 2022-06-24 04:14:22.953288
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    print("Start test_MiddlewareMixin_on_request...")
    print("End")



# Generated at 2022-06-24 04:14:34.020699
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestModel(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.middleware_list = []
        
        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware_list.append(middleware)

    middleware_list = TestModel()
    def sample_middleware(request):
        pass
    middleware_list.on_request(sample_middleware)
    assert(middleware_list.middleware_list[0].middleware == sample_middleware)
    assert(middleware_list.middleware_list[0].attach_to == "request")


# Generated at 2022-06-24 04:14:37.992625
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    class MyApplication(Sanic, MiddlewareMixin):
        pass

    MyApplication.__init__('test_MiddlewareMixin')
    MyApplication._future_middleware.clear()

    assert len(MyApplication._future_middleware) == 0

    # TODO: Add more unit test for MiddlewareMixin

# Generated at 2022-06-24 04:14:46.809805
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    def _middleware_func(request):
        request["mw_var"] = "Test"
        return request

    app = Sanic()
    @app.middleware
    def _middleware(request):
        request["mw_var"] = "Test"
        return request
    
    @app.route('/')
    async def _handler(request):
        assert request["mw_var"] == "Test"
        return text("OK")

    request, response = app.test_client.get('/')
    assert response.text == "OK"

    # we add the middleware directly, instead of registering it
    # we then call it on the same request and compare it
    request = _middleware_func(request)

# Generated at 2022-06-24 04:14:48.378091
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
   a=MiddlewareMixin()
   assert a._future_middleware == []
   

# Generated at 2022-06-24 04:14:51.479102
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    @MiddlewareMixin.on_request
    def middleware_on_request(request):
        return request

    assert middleware_on_request("TEST") == "TEST"

# Generated at 2022-06-24 04:14:59.592342
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import sanic.models.futures as futures
    import sanic.models.futures_test_helpers as helpers

    future_middleware = futures.FutureMiddleware(helpers.mock_middleware(),
                                                 'response')
    MiddlewareMixin._future_middleware = [future_middleware]

    # mocking
    MiddlewareMixin._apply_middleware = helpers.mock_apply_middleware()

    MiddlewareMixin.on_response()()

    assert helpers.apply_middleware.call_count == 1

    helpers.apply_middleware.assert_called_with(future_middleware)

# Generated at 2022-06-24 04:15:03.651328
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class CMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass

    mw = CMiddlewareMixin()
    assert isinstance(mw, MiddlewareMixin)
    assert mw._future_middleware == []


# Generated at 2022-06-24 04:15:07.650065
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic()

    @app.on_request
    def test_middleware(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware


# Generated at 2022-06-24 04:15:09.106839
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    assert mm._future_middleware == []



# Generated at 2022-06-24 04:15:19.928051
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Arrange
    from sanic.response import json
    from sanic import Sanic
    from sanic.request import Request
    app = Sanic()
    app.config.REQUEST_MAX_SIZE = 1
    app.config.REQUEST_TIMEOUT = 1

    @app.middleware
    async def test_middleware(request, *args, **kwargs):
        # Act & Assert
        assert request.path == "/test"
        return json({"test": True})

    @app.route("/test")
    async def test_route(request: Request):
        return json({"test": True})
    request = app.test_client.get(
        "/test", allow_redirects=False, timeout=1
    )
    # Act & Assert
    assert request.status == 200

# Generated at 2022-06-24 04:15:20.894170
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    MiddlewareMixin()


# Generated at 2022-06-24 04:15:24.802643
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddelwareMixinTestClass1(MiddlewareMixin): pass
    middelwareMixinTestClass1Instance1 = MiddelwareMixinTestClass1()
    assert(middelwareMixinTestClass1Instance1._future_middleware == [])


# Generated at 2022-06-24 04:15:34.509600
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic

    app = Sanic()

    # Register middleware function
    @app.middleware
    def first_response_middleware(request, response):
        request["list"] += ["first_response_middleware"]

    # Same as above
    @app.on_response
    def second_response_middleware(request, response):
        request["list"] += ["second_response_middleware"]

    # This will be called first
    @app.on_response("first")
    def first_response_middleware1(request, response):
        request["list"] += ["first_response_middleware1"]

    # This will be called second

# Generated at 2022-06-24 04:15:46.354193
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """Unit test for method middleware of class MiddlewareMixin
    """
    class TestMiddlewareMixin:
        def __init__(self):
            pass

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    # Test 1, arguments
    t = TestMiddlewareMixin()
    assert callable(t.middleware)
    assert t.on_request is not None
    assert t.on_response is not None

    # Test 2, flow
    @t.middleware
    def middleware(request):
        pass
    assert len(t._future_middleware) == 1
    assert t._future_middleware[0].attach_to == 'request'

    @t.on_request
    def request(request):
        pass
    assert len(t._future_middleware) == 2

# Generated at 2022-06-24 04:15:49.966097
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    server = Sanic('test_MiddlewareMixin_on_request')
    @server.on_request
    def handle_request(request):
        print("hello")
    R = server.on_request()
    assert R('handle_request') == 'handle_request'


# Generated at 2022-06-24 04:15:59.275076
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    _MiddlewareMixin = MiddlewareMixin()

    @_MiddlewareMixin.on_response()
    def on_request_do_somethings(request, call_next):
        return call_next(request)

    @_MiddlewareMixin.on_response(attach_to="request")
    def on_request_do_somethings(request, call_next):
        return call_next(request)

    @_MiddlewareMixin.on_response("response")
    def on_request_do_somethings(request, call_next):
        return call_next(request)

    @_MiddlewareMixin.on_response("request")
    def on_request_do_somethings(request, call_next):
        return call_next(request)

