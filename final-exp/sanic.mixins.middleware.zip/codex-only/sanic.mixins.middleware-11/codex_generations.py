

# Generated at 2022-06-24 04:06:05.960275
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """
    Unit test for method middleware of class MiddlewareMixin
    """
    class MyMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)

    def m():
        pass

    app = MyMiddlewareMixin()

    app.middleware(m)

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == m
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-24 04:06:10.405633
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_on_request")
    app.on_request(lambda request: print(request))
    assert len(app._future_middleware) == 1



# Generated at 2022-06-24 04:06:11.279087
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

# Generated at 2022-06-24 04:06:14.103377
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    """
    Test the method on_response of class MiddlewareMixin
    """
    mm = MiddlewareMixin()
    
    assert mm.on_response(middleware=None)(lambda _: True) == mm.middleware(attach_to="response")(lambda _: True)

# Generated at 2022-06-24 04:06:16.070524
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin._future_middleware == []

# Generated at 2022-06-24 04:06:27.966506
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import pytest
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')
    m = MiddlewareMixin()
    assert m._future_middleware == []
    with pytest.raises(NotImplementedError):
        m._apply_middleware(FutureMiddleware(None, 'response'))
    @m.middleware
    def mw_1(request):
        return request
    assert len(m._future_middleware) == 1
    assert m._future_middleware[0].name == 'mw_1'
    with pytest.raises(TypeError):
        m.middleware(mw_1, attach_to=False)
    with pytest.raises(TypeError):
        m.middleware(partial(mw_1))

# Generated at 2022-06-24 04:06:33.456385
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class MixinClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
        def _apply_middleware(self, middleware: FutureMiddleware):
            return
    A = MixinClass()
    def test_func(request):
       print(request)
    middleware = A.on_response(test_func)
    assert middleware != None
    assert middleware._func == test_func

# Generated at 2022-06-24 04:06:44.497526
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    @app.middleware
    async def test_on_request(request):
        print("called")
        request['called'] = True

    assert len(app._future_middleware) == 1
    assert app._future_middleware[-1].attach_to == 'request'
    assert app._future_middleware[-1].middleware == test_on_request

    @app.middleware("response")
    async def test_on_response(request, response):
        print("called")
        response['called'] = True

    assert len(app._future_middleware) == 2
    assert app._future_middleware[-1].attach_to == 'response'
    assert app._future_middleware[-1].middleware == test_on_response


# Generated at 2022-06-24 04:06:49.559891
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic

    app = Sanic('test_MiddlewareMixin')
    assert isinstance(app, MiddlewareMixin)
    assert hasattr(app, 'middleware')
    assert hasattr(app, 'on_request')
    assert hasattr(app, 'on_response')
    assert isinstance(app._future_middleware, list)


# Generated at 2022-06-24 04:06:55.798036
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic

    assert callable(MiddlewareMixin)

    obj = MiddlewareMixin()
    assert obj._future_middleware == []

    assert callable(obj.middleware)
    assert callable(obj.on_request)
    assert callable(obj.on_response)

    assert callable(obj.on_request())
    assert callable(obj.on_request("request"))
    assert callable(obj.on_request("response"))

    assert callable(obj.on_response())
    assert callable(obj.on_response("request"))
    assert callable(obj.on_response("response"))

    with raises(NotImplementedError):
        obj._apply_middleware(None)

# Generated at 2022-06-24 04:07:02.742412
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    app = Sanic(name='Sanic')

    @app.on_request
    def on_request_handler(request):
        return True

    @app.on_request
    def on_request_handler2(request):
        return True

    assert len(app.on_request_functions) == 2
    assert app.on_request_functions[0] == on_request_handler
    assert app.on_request_functions[1] == on_request_handler2
    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == on_request_handler
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[1].middleware == on_request_handler2
   

# Generated at 2022-06-24 04:07:12.725537
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MyMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    obj = MyMiddlewareMixin()
    obj.middleware(obj.on_request("test1"))
    obj.middleware(obj.on_request("test2"))
    obj.middleware(obj.on_response("test3"))
    obj.middleware(obj.on_response("test4"))


# Generated at 2022-06-24 04:07:20.551755
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic("test_on_request_middleware")
    middleware_decorator = app.on_request(middleware)

    @middleware_decorator
    def test_middleware(request):
        print("test_middleware is called")


    assert test_middleware == app.middleware_manager.request_middleware[0][1]
    assert test_middleware == app.middleware_manager.middleware_functions[0][1]

# Generated at 2022-06-24 04:07:21.224692
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass

# Generated at 2022-06-24 04:07:26.650974
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class SanicMock(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    app = SanicMock()
    @app.middleware
    def test_middleware(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware == [FutureMiddleware(test_middleware)]

# Generated at 2022-06-24 04:07:29.437840
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic("test_MiddlewareMixin_on_request")
    # TODO: 完善
    pass


# Generated at 2022-06-24 04:07:34.566927
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.models import HttpRequest
    app = Sanic(__name__)
    @app.middleware
    async def method_on_request(request):
        return request
    assert app.on_request(method_on_request)(app)(HttpRequest("http://127.0.0.1:3000/")) == HttpRequest("http://127.0.0.1:3000/")


# Generated at 2022-06-24 04:07:43.337812
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.request import Request
    from sanic.response import HTTPResponse

    class TestClass(MiddlewareMixin):
        def __init__(self):
            self._future_middleware: List[FutureMiddleware] = []

    @TestClass.middleware(attach_to="request")
    async def on_request(request: Request):
        return request

    app = TestClass()
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware is on_request



# Generated at 2022-06-24 04:07:45.186852
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin = MiddlewareMixin()
    assert mixin._future_middleware == []

# Generated at 2022-06-24 04:07:48.662736
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    sanicApp = Sanic()
    @sanicApp.middleware('response')  # on_response
    async def response_middleware(request, response):
        pass
    assert sanicApp._future_middleware[0].attach_to == 'response'

# Generated at 2022-06-24 04:07:55.883926
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    from sanic_auth import Auth
    
    def middleware(request):
        # some code
        pass
    
    app = Sanic(__name__)
    auth = Auth(app)
    auth.middleware(middleware)
    response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == '{"hello": "world"}'

# Generated at 2022-06-24 04:07:56.673619
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-24 04:08:04.233088
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic("test_MiddlewareMixin_on_response")

    @app.middleware
    def test_MiddlewareMixin_on_response_middleware(request):
        return request

    app.on_response(test_MiddlewareMixin_on_response_middleware)

    assert len(app._future_middleware) == 2
    assert app._future_middleware[-1].middleware == test_MiddlewareMixin_on_response
    assert app._future_middleware[-1].attach_to == "response"

# Generated at 2022-06-24 04:08:14.632323
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware
    app = Sanic(__name__)
    m1 = future_middleware = FutureMiddleware(middleware=None, attach_to="request")
    app.middleware(future_middleware)
    assert app._future_middleware[0] == m1
    m2 = future_middleware = FutureMiddleware(middleware=None, attach_to="response")
    app.middleware(future_middleware)
    assert app._future_middleware[1] == m2
    m3 = future_middleware = FutureMiddleware(middleware=None, attach_to="request")
    app._apply_middleware(future_middleware)
    assert app._future_middleware[2] == m3
    app.on_

# Generated at 2022-06-24 04:08:16.379548
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic("test_sanic")
    assert app.on_response



# Generated at 2022-06-24 04:08:18.906562
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    a = MiddlewareMixin()
    assert a._future_middleware != None
    assert isinstance(a._future_middleware, list)


# Generated at 2022-06-24 04:08:21.054127
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    mm = MiddlewareMixin()
    
    @mm.on_request()
    def myMiddleware(request):
        return request
    
    assert len(mm._future_middleware) == 1


# Generated at 2022-06-24 04:08:23.522464
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    app = MiddlewareMixin()
    res = app.on_response()
    assert res.keywords["attach_to"] == "response"


# Generated at 2022-06-24 04:08:29.737638
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():

    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    middleware1 = lambda request: HTTPResponse(request.url)

    app = Sanic('test_on_response')
    app.on_response(middleware1)

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'http://localhost/'


# Generated at 2022-06-24 04:08:36.360380
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    """
    Test on_request method of class MiddlewareMixin
    """
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

    # Should work properly when the params are right
    res = TestMiddlewareMixin().on_request(middleware=None)
    assert res == partial(TestMiddlewareMixin().middleware, attach_to="request")

    # Should raise exception when the params are wrong
    with pytest.raises(Exception):
        res = TestMiddlewareMixin().on_request(middleware=1)


# Generated at 2022-06-24 04:08:38.221265
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    test = MiddlewareMixin()
    assert(test._future_middleware == [])


# Generated at 2022-06-24 04:08:49.213835
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    print("Running Tests")
    def middleware():
        print("Middleware")
    def middleware_response():
        print("Middleware Response")
    def middleware_request():
        print("Middleware Request")
    app = Sanic("example") # create Sanic app
    print("Test Middleware")
    app.middleware(middleware)
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == "request"
    print("Test Middleware Request")
    app.on_request(middleware_request)
    assert app._future_middleware[1].middleware == middleware_request
    assert app._future_middleware[1].attach_to == "request"
    print("Test Middleware Response")

# Generated at 2022-06-24 04:08:51.780089
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    new_middleware = MiddlewareMixin()
    new_middleware.on_request()
    new_middleware.middleware(None, "request")


# Generated at 2022-06-24 04:09:00.065199
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class SanicMock(MiddlewareMixin):
        def __init__(self):
            self.attached_to = []
            self._future_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.attached_to.append(middleware.attach_to)

    app = SanicMock()

    @app.middleware
    def middleware1():
        pass

    @app.middleware('request')
    def middleware2():
        pass

    @app.middleware('response')
    def middleware3():
        pass

    assert len(app._future_middleware) == 3
    assert app.attached_to == ['request', 'request', 'response']

    @app.on_request
    def middleware4():
        pass


# Generated at 2022-06-24 04:09:07.401902
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    future_middleware: List[FutureMiddleware] = []

    class TestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass  # noqa

    TestClass()
    obj1 = TestClass()
    obj1.on_response()

    test_list = []
    def test_func():
        pass

    obj1.on_response(test_func)

# Generated at 2022-06-24 04:09:07.960351
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert(True)

# Generated at 2022-06-24 04:09:13.259537
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware
    import os
    import sys

    example_app = Sanic(__name__)

    def middleware():
        return

    example_app.middleware(middleware,"request")

    assert len(example_app._future_middleware) == 1

    assert example_app._future_middleware == ["middleware"]
    


# Generated at 2022-06-24 04:09:21.682040
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    def mw1(request):
        return request

    def mw2(request):
        return request

    app = App()

    mw1 = app.middleware(mw1)
    mw2 = app.middleware(mw2)

    assert mw1._sanic_middleware_handlers == ['request']
    assert mw1._sanic_middleware_has_request_arg == True

    assert mw2._sanic_middleware_handlers == ['request']
    assert mw2._sanic_middleware_has_request_arg == True


# Generated at 2022-06-24 04:09:24.192959
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_on_response')
    assert app.on_response == app.middleware



# Generated at 2022-06-24 04:09:30.500216
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic()
    @app.middleware  # noqa
    async def print_on_request(request):
        pass
    @app.middleware('response')  # noqa
    async def print_on_response(request, response):
        pass
    @app.route('/')
    async def handler(request):
        return text('OK')

# Generated at 2022-06-24 04:09:34.974251
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():    
    class FakeMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware() -> None:
            pass

    fake_middleware = FakeMiddlewareMixin()
    assert fake_middleware.on_request(middleware=None)(lambda x: x)(1) == 1

# Generated at 2022-06-24 04:09:36.120672
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mmix = MiddlewareMixin()

# Generated at 2022-06-24 04:09:45.113057
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol

    app = Sanic(__name__)

    @app.route('/')
    def handler(request):
        return json({'hello': 'world'})

    # Register middlewares
    @app.on_response
    def on_response(request, response):
        # In this example, we just modify the response
        response.headers['content-type'] = 'application/json'

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.headers.get('content-type') == 'application/json'

# Generated at 2022-06-24 04:09:54.526466
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    '''
    Test for method on_request of class MiddlewareMixin
    '''
    from ..core import Sanic
    from ..core import SanicCore
    from ..core import SanicRequest
    from ..core import SanicResponse
    from ..core import request, response
    from ..core import BaseHTTPServer
    from ..core import asyncio
    app = Sanic('test_on_request')

    @app.middleware('request')
    async def print_on_request(request):
        print('print_on_request')
        assert isinstance(request, SanicRequest)
        assert isinstance(request.args, dict)
        assert isinstance(request.body, bytes)
        assert isinstance(request.cookies, dict)
        assert isinstance(request.form, dict)

# Generated at 2022-06-24 04:09:58.847363
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    test_MiddlewareMixin_middleware._future_middleware = []
    test_MiddlewareMixin_middleware._apply_middleware = lambda x: True
    test_MiddlewareMixin_middleware(1, 2, 3)

test_MiddlewareMixin_middleware = MiddlewareMixin(1, 2, 3)
test_MiddlewareMixin_middleware.middleware(1)
test_MiddlewareMixin_middleware.on_request(lambda x: 3)
test_MiddlewareMixin_middleware.on_response(lambda x: 3)


# Generated at 2022-06-24 04:09:59.649295
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    MiddlewareMixin()


# Generated at 2022-06-24 04:10:07.855698
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MyMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError
    obj = MyMiddlewareMixin()
    # Test for method with arguments:
    # middleware_or_request=my_middleware, attach_to='request', apply=True
    def test_middleware_or_request(request):
        return request
    test_for_middleware_or_request = obj.middleware(test_middleware_or_request)
    assert callable(test_for_middleware_or_request)
    assert test_for_middleware_or_request(request=1) == 1
    # Test for method with arguments:
    # middleware_or_request=my_middleware, attach_to='request', apply=False
   

# Generated at 2022-06-24 04:10:18.645923
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.exceptions import RequestTimeout

    app = Sanic("sanic-auth")

    @app.on_request
    def on_request(request):
        return "Hello"

    assert app.middleware(on_request, "request") is on_request
    assert app.middleware("request")(on_request) is on_request

    @app.on_request("request")
    def on_request(request):
        return "Hello"

    assert app.middleware(on_request, "request") is on_request
    assert app.middleware("request")(on_request) is on_request

    @app.on_request("response")
    def on_request(request):
        return "Hello"

    assert app.middleware(on_request, "response") is on_

# Generated at 2022-06-24 04:10:26.166809
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.blueprints import Blueprint
    from sanic.models.sanic import Sanic
    from sanic.views import HTTPMethodView

    class Application(Sanic, MiddlewareMixin):
        pass

    app = Application()

    bp = Blueprint("bp1")
    app.blueprint(bp)

    bp.add_route(HTTPMethodView.as_view(), "/")

    @bp.middleware
    def middleware1(request):
        return request

    @bp.middleware("request")
    def middleware2(request):
        return request

    @app.middleware("request")
    def middleware3(request):
        return request

    @app.on_request()
    def middleware4(request):
        return request


# Generated at 2022-06-24 04:10:32.933296
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    import asyncio

    app = Sanic()
    @app.middleware
    async def middleware(request):
        if request.method == 'GET':
            return 'OK'
        return 'NOT OK'
    assert app._future_middleware[0].middleware == middleware
    assert asyncio.get_event_loop().run_until_complete(app.middleware(app.request('GET'))) == 'OK'

# Generated at 2022-06-24 04:10:34.683541
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewareMixin = MiddlewareMixin();
    assert middlewareMixin._future_middleware == []

# Generated at 2022-06-24 04:10:39.096688
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware = MiddlewareMixin()

    assert(middleware._future_middleware == [])

    assert(middleware.middleware is MiddlewareMixin.middleware)
    assert(middleware.on_request is MiddlewareMixin.on_request)
    assert(middleware.on_response is MiddlewareMixin.on_response)

# Generated at 2022-06-24 04:10:45.806643
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import pytest
    from sanic.models.futures import FutureMiddleware

    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

    app = TestMiddlewareMixin()
    app.register_middleware(1, "response")

    assert(app._future_middleware == [FutureMiddleware(1, "response")])



# Generated at 2022-06-24 04:10:48.361029
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import unittest.mock as mock
    args = mock.Mock()
    args.middleware = []
    mixin = MiddlewareMixin(*args)
    mixin.middleware = mock.Mock()
    middleware = mock.Mock()
    on_request = mixin.on_request
    on_request(middleware)
    mixin.middleware.assert_called_once_with(middleware, 'request')

# Generated at 2022-06-24 04:10:51.937506
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    m = MiddlewareMixin()
    m.on_response(middleware=None)

# Generated at 2022-06-24 04:11:02.711443
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.futures import FutureMiddleware
    from sanic.response import text
    from sanic.exceptions import SanicException

    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self._future_middleware = []
            self._apply_middleware = self._apply_middleware_test

        def _apply_middleware_test(self, middleware):
            assert type(middleware) == FutureMiddleware
            assert middleware.attach_to == 'request'

    class TestException(Exception):
        pass

    # tests
    mm = TestMiddlewareMixin()
    mm.middleware(lambda request : text(request.method))
    assert len(mm._future_middleware) == 1

# Generated at 2022-06-24 04:11:04.487354
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin().on_request == partial(MiddlewareMixin().middleware, attach_to='request')


# Generated at 2022-06-24 04:11:06.759385
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class FakeSanicApp(MiddlewareMixin):
        pass
    app = FakeSanicApp()
    assert isinstance(app._future_middleware, list)

# Generated at 2022-06-24 04:11:09.291174
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Temp(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    assert isinstance(Temp(*(), **{})._future_middleware, list)

# Generated at 2022-06-24 04:11:12.159185
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Foo(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            self._future_middleware = []
            super().__init__()
    assert Foo()._future_middleware == []

# Unit tests for registering middleware

# Generated at 2022-06-24 04:11:18.352594
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MyMiddleware:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def __call__(self, request):
            return "success"

    m = MyMiddleware(1, 2, 3)
    assert m(1) == "success"

    class MyApp(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            self._middlewares = []
            super().__init__(*args, **kwargs)
        def _apply_middleware(self, middleware):
            self._middlewares.append(middleware)

    app = MyApp()
    assert len(app._middlewares) == 0
    callback = app.middleware(m)
    callback(app)
    assert len

# Generated at 2022-06-24 04:11:19.230572
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()

# Generated at 2022-06-24 04:11:28.772065
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Test if return value of function on_request is callable
    try:
        test_on_request = MiddlewareMixin.on_request()
        assert callable(test_on_request)
    except AssertionError:
        print('AssertionError: \'on_request\' is not callable!')
        exit(1)
    # Test if return value of function on_request is of type 'partial'
    try:
        assert isinstance(test_on_request, partial)
    except AssertionError:
        print(
            'AssertionError: \'on_request\' does not return type \'partial\'!'
        )
        exit(1)
    # Test if return value of function on_request is of type 'functools.partial'

# Generated at 2022-06-24 04:11:31.949009
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    card = MiddlewareMixin()
    assert hasattr(card, "_future_middleware")
    assert isinstance(card._future_middleware, list)

# Generated at 2022-06-24 04:11:37.739772
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Test:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    objTest = Test()
    @objTest.on_request()
    def test_1(request, response):
        print(111)
        return

    assert( objTest is not None)

# Generated at 2022-06-24 04:11:47.848526
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin = MiddlewareMixin(app)
    middleware_mixin.on_request()
    
    # Test for middleware_mixin
    assert middleware_mixin.middleware(middleware_or_request = True, attach_to = 'request')
    try:
        assert middleware_mixin.middleware(middleware_or_request = True)
    except:
        pass
    else:
        assert 0, "Shouldn't work"
    middleware_mixin.middleware(middleware_or_request = middleware, attach_to = 'request')
    middleware_mixin.on_response()
    middleware_mixin.on_response(middleware)
    assert middleware_mixin.on_request()(middleware)

# Generated at 2022-06-24 04:11:57.441860
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # create a new MiddlewareMixin class
    class TestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    
    # create an instance of TestClass
    test_class = TestClass()
    
    # test the on_response method with a function
    def test_function():
        # pass
        pass

    # bind the function to the method on_response
    test_function = test_class.on_response(middleware=test_function)

    """
    the on_response method will be called with another function,
    the default value of that function is None
    """
    # bind the function to the method on_response with a None function
    test_function = test_class.on_response(middleware=None)
   

# Generated at 2022-06-24 04:12:06.750902
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')

    # Test 1: ordinary use
    test_obj = app.on_request(middleware='')
    expected = True, 'request'
    result = callable(test_obj), test_obj.keywords['attach_to']
    assert expected == result
    assert expected == result, result

    # Test 2: ordinary use
    test_obj = app.on_request(middleware=lambda request: request)
    expected = True, True, 'request'
    result = callable(test_obj), test_obj.args, test_obj.keywords['attach_to']
    assert expected == result
    assert expected == result, result


# Generated at 2022-06-24 04:12:13.516532
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import HTTPResponse
    from sanic.exceptions import NotFound, ServerError
    from sanic.request import Request
    from sanic.response import HTTPResponse as res_HTTPResponse

    def middleware_factory():
        async def response_middleware(request: Request, response: res_HTTPResponse):
            if request.method == "GET" and response.status == 404:
                response.text = "Custom 404 message"
                response.status = 404
                return response
            else:
                ...
        return response_middleware

    def get_app():
        app = Sanic()
        app.on_response(middleware_factory())
        return app


# Generated at 2022-06-24 04:12:17.374390
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic()

    @app.middleware('request')
    async def add_header(request):
        return text('OK')


# Generated at 2022-06-24 04:12:22.785039
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    caso_prueba = MiddlewareMixin()
    caso_prueba.on_response(None) == partial(caso_prueba.middleware, attach_to="response")
    caso_prueba.on_response(caso_prueba.middleware) == caso_prueba.middleware(caso_prueba.middleware, "response")


# Generated at 2022-06-24 04:12:25.091986
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Constructor of MiddlewareMixin class
    inst = MiddlewareMixin()
    # Check initialization of self._future_middleware
    assert inst._future_middleware == []

# Generated at 2022-06-24 04:12:26.314063
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.models.middleware import MiddlewareMixin
    MiddlewareMixin()

# Generated at 2022-06-24 04:12:33.187809
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddleware(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    t = TestMiddleware()

    @t.on_response('a')
    def test(request):
        pass

    assert t._future_middleware[0].attach_to == 'a'



# Generated at 2022-06-24 04:12:44.288136
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()
    @app.middleware
    async def handle_request(request):
        pass

    @app.middleware('request')
    async def handle_request2(request):
        pass

    @app.middleware('response')
    async def handle_response(request, response):
        pass

    @app.middleware('request')
    async def handle_request3(request, response):
        pass

    @app.middleware('response')
    async def handle_response2(request, response):
        pass

    @app.middleware('response')
    async def handle_response3(request, response):
        pass

    assert len(app.request_middleware) == 3
    assert len(app.response_middleware) == 3


# Generated at 2022-06-24 04:12:48.434075
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Test(MiddlewareMixin):
        pass
    t = Test()
    t._apply_middleware(FutureMiddleware(None, 'None'))
    assert t._future_middleware == [FutureMiddleware(None, 'None')]
    t.middleware(None, 'None')
    t.on_request(None)
    t.on_response(None)

# Generated at 2022-06-24 04:12:57.260073
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic()

    @app.middleware
    async def print_on_request(request):
        print("I run on each request")

    @app.middleware('request')
    async def halt_request(request):
        return text('I halt the request', status=403)

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I run on each response")

    request, response = app.test_client.get('/')

    assert response.text == 'I halt the request'
    assert response.status == 403

# Generated at 2022-06-24 04:13:03.962135
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import sys
    import os
    dir_path = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, dir_path + "/../..")

    from sanic import Sanic
    from middleware.middleware import MiddlewareMixin
    class custom_middleware(Sanic):
        pass

    custom_middleware.on_request(middleware=None)

    print("Unit test for method on_request of class MiddlewareMixin : SUCCESS")


# Generated at 2022-06-24 04:13:14.607346
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    def m1(func):
        return f"m1:{func}"

    def m2(func):
        return f"m2:{func}"

    def m3(func):
        return f"m3:{func}"

    class App(MiddlewareMixin):
        def m1(self):
            pass

        def m2(self):
            pass

        def m3(self):
            pass

    app = App()
    assert not app._future_middleware

    app.middleware(m1)
    assert len(app._future_middleware) == 1

    app.middleware(m2, attach_to="request")
    app.middleware(m1, attach_to="response")
    assert len(app._future_middleware) == 3

# Generated at 2022-06-24 04:13:19.703952
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    assert callable(MiddlewareMixin.middleware)

    app = Sanic('test_MiddlewareMixin_middleware')
    assert not hasattr(app, 'middleware')
    MiddlewareMixin.middleware(app)
    assert callable(app.middleware)

    @app.middleware
    def test_middleware(request):
        return request

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-24 04:13:28.325045
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic('test_MiddlewareMixin_on_request')
    app.config.REQUEST_MAX_SIZE = 10
    app.config.REQUEST_TIMEOUT = 1

    request_counter = 0

    @app.on_request()
    def request_middleware(request):
        nonlocal request_counter
        request_counter += 1

    @app.route('/')
    def handler(request):
        return HTTPResponse()

    request, response = app.test_client.get('/')
    assert request_counter == 1

# Generated at 2022-06-24 04:13:31.622101
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    sanic_app = Sanic(__name__)
    @sanic_app.on_request
    def test_on_request(request):
        pass
    assert len(sanic_app._future_middleware) == 1


# Generated at 2022-06-24 04:13:36.715680
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MyTestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_obj = MyTestMiddlewareMixin()
    test_obj.middleware("test")
    assert test_obj._future_middleware[0].attach_to == "test"

# Generated at 2022-06-24 04:13:38.363757
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    with pytest.raises(NotImplementedError):
        MiddlewareMixin()._apply_middleware(None)

# Generated at 2022-06-24 04:13:48.043457
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    class MiddlewareMixin_test(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self.parameter = None

        def _apply_middleware(self, middleware):
            self.parameter = middleware.name

    app = Sanic('test')
    assert not app.parameter

    # Test when callable(middleware) is True
    mware = app.on_request(middleware='mware')
    assert isinstance(mware, partial)

    # Test when callable(middleware) is False
    mware = app.on_request()
    assert isinstance(mware, partial)
    mware(middleware='mware')

    # Return of partial function
    assert app.parameter == 'mware'

# Generated at 2022-06-24 04:13:58.177449
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import json
    import pytest
    app = Sanic(__name__)
    @app.middleware
    def test_middleware(request, response):
        assert isinstance(request, Sanic.request_class)
        assert isinstance(response, json)
        return
    @app.route("/")
    def test(request):
        assert request.app is app
        return json({"test": 42})

    request, response = app.test_client.get("/")
    assert response.status == 200
    assert response.json == {"test": 42}

    @app.on_response
    def test_on_response(request, response):
        assert isinstance(request, Sanic.request_class)
        assert isinstance(response, json)
        return


# Generated at 2022-06-24 04:14:06.439011
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class A(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            self._future_middleware = []
            self._future_middleware_map = {}
            return super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware_map[middleware.attach_to] = True

    a = A()

    @a.on_response()
    def middleware(request):
        pass

    assert len(a._future_middleware) == 1
    assert a._future_middleware[0].middleware == middleware
    assert a._future_middleware[0].attach_to == "response"
    assert a._future_middleware_map["response"] == True

# Generated at 2022-06-24 04:14:09.213770
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    obj = MiddlewareMixin()
    return obj._future_middleware


# Generated at 2022-06-24 04:14:19.149206
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic(__name__)

    # Decorated with @app.middleware
    @app.middleware
    def request_middleware(request: Request):
        request["middleware"] = True
        return request

    # Decorated with @app.on_request
    @app.on_request
    def request_middleware2(request: Request):
        request["middleware2"] = True
        return request

    # Decorated with @app.middleware('request')
    @app.middleware("request")
    def request_middleware3(request: Request):
        request["middleware3"] = True
        return request


# Generated at 2022-06-24 04:14:26.762341
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text

    async def mw1(request):
        return text('Passed')

    async def mw2(request):
        return text('Passed')

    app = Sanic()
    middleware_mw1 = app.on_response(mw1)
    middleware_mw2 = app.on_response(mw2)
    assert middleware_mw1 is mw1
    assert middleware_mw2 is mw2


# Generated at 2022-06-24 04:14:34.375134
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import unittest
    import sanic.app

    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = sanic.app.Sanic(__name__)
    middleware_mixin = TestMiddlewareMixin()
    @middleware_mixin.middleware
    def my_middleware(request):
        pass
    assert len(middleware_mixin._future_middleware) == 1
    assert middleware_mixin._future_middleware[0].middleware == my_middleware



# Generated at 2022-06-24 04:14:37.854489
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Initialization
    from sanic.app import Sanic
    app = Sanic('test')

    # Apply
    @app.on_response
    async def on_response(request, response):
        response.headers['TEST'] = 'TEST'

    # Verify
    assert app._future_middleware[0]._middleware == on_response
    assert app._future_middleware[0]._attach_to == "response"


# Generated at 2022-06-24 04:14:44.462742
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class testMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware = []
        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)

    mid = testMiddlewareMixin()
    mid.middleware('test')
    assert len(mid._future_middleware) == 1
    assert mid._future_middleware[0].middleware == 'test'

# Generated at 2022-06-24 04:14:47.703955
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic

    app = Sanic()

    class MyMiddleware:
        def __call__(self, request):
            return "mocked middleware"

    my_middleware = MyMiddleware()

    class MyClass(MiddlewareMixin):
        pass

    my_cls = MyClass()

    assert my_middleware == my_cls.on_response(my_middleware)()

# Generated at 2022-06-24 04:14:55.007285
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic 

    app = Sanic("testMiddlewareMixin")

    @app.middleware("response")
    async def print_on_response(request, response):
        print("I am a spartan!")

    @app.route("/")
    async def test(request):
        return text("I am a Spartan!")
    request, response = app.test_client.get("/")
    assert response.status == 200
    assert response.text == "I am a Spartan!"

# Generated at 2022-06-24 04:14:59.345820
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():

    def fake_middleware(request):
        pass

    test = MiddlewareMixin()

# Generated at 2022-06-24 04:15:00.345283
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-24 04:15:06.114070
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Foo(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(Foo, self).__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    foo = Foo(1, 2)
    assert foo._future_middleware == []

# Generated at 2022-06-24 04:15:09.194448
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    app = Sanic("MiddlewareMixin_test")
    assert isinstance(app, Sanic)
    # class Sanic inherits from class MiddlewareMixin
    assert isinstance(app, MiddlewareMixin)
    assert hasattr(app, "_future_middleware")
    assert isinstance(app._future_middleware, list)
    assert len(app._future_middleware) == 0

# Generated at 2022-06-24 04:15:14.903199
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Init class MiddlewareMixin
    middleware_mixin = MiddlewareMixin()

    assert isinstance(middleware_mixin, MiddlewareMixin)
    assert isinstance(middleware_mixin._future_middleware, list)
    assert middleware_mixin._future_middleware == []


# Generated at 2022-06-24 04:15:16.267944
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []

# Generated at 2022-06-24 04:15:18.136094
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    app = MiddlewareMixin(args="args")
    assert app._future_middleware == []

# Generated at 2022-06-24 04:15:19.769008
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    #TODO: test case
    pass


# Generated at 2022-06-24 04:15:23.045229
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    middleware_mixin = MiddlewareMixin()
    middleware_mixin.on_request()

# Generated at 2022-06-24 04:15:25.370930
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response != None
    assert MiddlewareMixin.on_response == MiddlewareMixin.on_response



# Generated at 2022-06-24 04:15:31.569536
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Test 1: with parameter
    def middleware(request, response):
        _assert_true(
            isinstance(request, Request) and isinstance(response, Response)
        )

    MiddlewareMixin.on_response(middleware)
    # TODO: implement the rest of the unit test(s)


# Generated at 2022-06-24 04:15:38.899727
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound
    from sanic.server import HttpProtocol
    import asyncio
    import pytest
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.route('/')
    async def handler(request):
        return text('OK')
    @app.exception(NotFound)
    async def ignore_404s(request, exception):
        return text("Yep, I totally found the page: {}".format(request.url))
    @app.middleware('response')
    async def process_response(request, response):
        return text("I change the response")
    @app.middleware('request')
    async def process_request(request):
        request['test'] = 'test'


# Generated at 2022-06-24 04:15:49.718802
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Test successful case
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    test = TestMiddlewareMixin()
    def new_function():
        print("test")
    assert test.on_request(new_function) == test.middleware(new_function, "request")
    # Test exception case
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middle

# Generated at 2022-06-24 04:15:54.263484
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()

    @app.on_response
    def on_response(request, response):
        return response

    assert len(app._future_middleware) == 1

    assert app._future_middleware[0].middleware == on_response
    assert app._future_middleware[0].attach_to == "response"



# Generated at 2022-06-24 04:15:56.383825
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():

    m = MiddlewareMixin()
    assert m._future_middleware == []


# Generated at 2022-06-24 04:16:01.654438
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    SUT = MiddlewareMixin()
    assert callable(MiddlewareMixin.on_request(SUT))
    result = SUT.on_request
    assert callable(result)
