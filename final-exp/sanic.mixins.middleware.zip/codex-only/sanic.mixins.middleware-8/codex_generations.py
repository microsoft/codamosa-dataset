

# Generated at 2022-06-24 04:05:53.744107
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    #create MiddlewareMixin object
    obj = MiddlewareMixin()
    global count
    count = 0

    # Create a function to be passed with parametr to middleware
    def middleware(request):
        global count
        count = count + 1
        pass

    # Check that _future_middleware is empty
    assert obj._future_middleware == []

    # Call middleware method of class MiddlewareMixin
    obj.middleware(middleware)

    # Check that _future_middleware is not empty
    assert obj._future_middleware != []

    # Check that _future_middleware is list
    assert isinstance(obj._future_middleware, list)

    # Check that count is equal to 1
    assert count == 1


# Generated at 2022-06-24 04:05:55.278621
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin is not None
    # Test properties:
    assert middleware_mixin._future_middleware == []

# Generated at 2022-06-24 04:06:01.497208
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Test 1: Call on_response with a callable
    def request_handler(request):
        return request

    app1 = MiddlewareMixin()
    app1.on_response(request_handler)(sanic.request)

    # Test 2: Call on_response without passing a callable
    app2 = MiddlewareMixin()
    result2 = app2.on_response()
    assert callable(result2)
    result2(request_handler)

# Generated at 2022-06-24 04:06:10.790598
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Middleware:
        def __init__(self):
            self.requests = []
            self.responses = []
            
        async def request(self, request):
            self.requests.append("request")
            return request
        
        async def response(self, request, response):
            self.responses.append("response")
            return response
    
    class App(MiddlewareMixin):
        def __init__(self):
            pass
    
        def _apply_middleware(self, middleware):
            pass
        
    app = App()
    app.on_request(Middleware)
    
    hint = "function middleware() should create a decorator"
    assert callable(app.on_request()), hint
    assert callable(app.on_request(Middleware())), hint
    


# Generated at 2022-06-24 04:06:11.826214
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    @MiddlewareMixin.on_request
    async def foo(request):
        pass

    assert callable(foo)

# Generated at 2022-06-24 04:06:13.824666
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    mm = MiddlewareMixin()
    assert isinstance(mm, MiddlewareMixin)
    assert mm._future_middleware == []


# Generated at 2022-06-24 04:06:14.431797
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

# Generated at 2022-06-24 04:06:16.352151
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin.on_request(MiddlewareMixin,'request')


# Generated at 2022-06-24 04:06:19.909267
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    """
    Test case for the constructor of the class MiddlewareMixin
    """
    _MiddlewareMixin = MiddlewareMixin()
    assert _MiddlewareMixin is not None
    assert _MiddlewareMixin._future_middleware == []

# Generated at 2022-06-24 04:06:21.764936
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin = MiddlewareMixin()
    assert mixin is not None
    assert type(mixin) == MiddlewareMixin



# Generated at 2022-06-24 04:06:30.977371
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.router import Router
    from sanic.server import HttpProtocol

    from sanic.response import text
    from sanic.testing import SanicTestClient, create_server
    from sanic.log import logger

    class CustomRouter(Router):
        pass

    class CustomHttpProtocol(HttpProtocol):
        pass

    class CustomTestClient(SanicTestClient):
        pass

    class App(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(App, self).__init__(*args, **kwargs)

            self.router = CustomRouter()
            self.http_protocol = CustomHttpProtocol

            self.blueprints = []
            self.error_handler = {}
            self.config = {}
            self.before_start = []

# Generated at 2022-06-24 04:06:33.232313
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    t = TestMiddlewareMixin()
    t.on_response('test')

# Generated at 2022-06-24 04:06:39.121793
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.middleware
    def request():
        pass
    @app.on_request
    def request():
        pass
    assert app._future_middleware[0] == app._future_middleware[1]

# Generated at 2022-06-24 04:06:40.150660
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    temp_mixin = MiddlewareMixin()

# Generated at 2022-06-24 04:06:50.292456
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    config = {
        "middlewares": [],
        "error_handler": None,
        "request_class": Request,
        "response_class": HTTPResponse,
        "route_class": Route,
        "router_class": Router,
        "websocket_class": WebSocketProtocol,
        "websocket_ping_interval": None,
        "websocket_ping_timeout": None,
        "subprotocols": [],
        "debug": False,
        "async_blocking_mode": None,
        "request_timeout": 60,
        "keep_alive": True,
        "keep_alive_timeout": 5,
    }
    app = Sanic(__name__)
    app.config.update(config)

# Generated at 2022-06-24 04:06:51.773969
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware = MiddlewareMixin()
    assert middleware._future_middleware == []


# Generated at 2022-06-24 04:06:54.845690
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        pass
    testMiddlewareMixin = TestMiddlewareMixin()
    assert testMiddlewareMixin._future_middleware == []


# Generated at 2022-06-24 04:06:58.574543
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic(__name__)
    @app.middleware('response')
    async def print_on_response(request, response):
        print('print_on_response')             
    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'OK'

# Generated at 2022-06-24 04:06:59.395438
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    pass


# Generated at 2022-06-24 04:07:11.200584
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import sanic.blueprints
    import sanic.response
    import sanic.sanic
    import sanic.views
    import sanic_openapi.swagger_blueprint
    import sanic_openapi.swagger_ui_blueprint

    # Example of method middleware of class MiddlewareMixin
    app = sanic.sanic.Sanic(__name__)
    app.config.REQUEST_TIMEOUT = 10
    app.config.RESPONSE_TIMEOUT = 15


# Generated at 2022-06-24 04:07:14.687716
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddleware(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    test_middleware = TestMiddleware()
    test_middleware.on_request(middleware=None)

# Generated at 2022-06-24 04:07:21.038401
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    async def handler(request):
        return HTTPResponse(status=200)

    async def middleware_response(request):
        pass

    app = Sanic(__name__)
    app.on_response(middleware_response)
    app.add_route(handler, '/')
    _, response = app.test_client.get('/')
    assert response.status == 200

# Generated at 2022-06-24 04:07:24.613082
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App(MiddlewareMixin):
        def __init__(self):
            super().__init__()

    app = App()
    @app.middleware
    async def mid1(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "request"
    assert callable(app._future_middleware[0].middleware)

    @app.middleware("response")
    async def mid2(request, response):
        pass
    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].attach_to == "response"
    assert callable(app._future_middleware[1].middleware)

# Generated at 2022-06-24 04:07:29.804533
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Call the constructor of class MiddlewareMixin
    mixin = MiddlewareMixin()

    # Check _future_middleware is a empty list
    assert isinstance(mixin._future_middleware, list)
    assert len(mixin._future_middleware) == 0

# Generated at 2022-06-24 04:07:37.705979
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.futures import FutureMiddleware
    from .utils import MockFunction

    a=MiddlewareMixin()

    a._future_middleware=[]
    a._apply_middleware=MockFunction()
    a.middleware(1)
    assert a._future_middleware[0].middleware==1
    assert a._future_middleware[0].attach_to=='request'
    assert a._apply_middleware.called==True

    a._future_middleware=[]
    FutureMiddleware(1,'request')
    assert a._future_middleware[0].middleware==1
    assert a._future_middleware[0].attach_to=='request'

    a._future_middleware=[]
    a.middleware(2,'response')

# Generated at 2022-06-24 04:07:45.406226
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.request import Request

    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    async def print_on_request(request: Request):
        print(request.url)

    assert len(app._future_middleware) == 1
    future_middleware: FutureMiddleware = app._future_middleware[0]
    assert future_middleware.attach_to == "request"


# Generated at 2022-06-24 04:07:50.621277
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.models.parameters import PARAMS_POSITIONALS_MAP

    app = Sanic('test_MiddlewareMixin_on_response')
    @app.middleware('response')
    async def test_on_response(request):
        pass

    assert app._middleware == [('response', test_on_response)]
    assert app._middleware == app._future_middleware
    assert app._middleware == [('response', test_on_response)]




# Generated at 2022-06-24 04:07:55.551546
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    """
    This test will pass if method on_request of class MiddlewareMixin is instantiated without any error.
    The test will fail if method on_request of class MiddlewareMixin is not instantiated.
    """
    try:
        MiddlewareMixin.on_request(MiddlewareMixin)
    except Exception as e:
        pytest.fail(str(e))



# Generated at 2022-06-24 04:08:02.877293
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic('sanic-test')

    @app.middleware('response')
    async def response_middleware(request, response):
        pass

    func = app.on_response(response_middleware)
    func()

    assert app._future_middleware[0].middleware == response_middleware
    assert app._future_middleware[0].attach_to == "response"

# Generated at 2022-06-24 04:08:08.401263
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def on_response(request, response):
        response.headers.update(request.headers)

    request, response = app.test_client.get('/', headers={'test-header': 'blah'})

    assert response.headers['test-header'] == 'blah'

# Generated at 2022-06-24 04:08:11.948289
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('test')
    print(app.middleware)

# Generated at 2022-06-24 04:08:15.376268
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    def application(request):
        return response.text('OK')
    app = Sanic(__name__)
    app.request_middleware = [application]
    app.on_request(application)
    assert app.request_middleware[0] == application


# Generated at 2022-06-24 04:08:16.726143
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    assert mm.__init__() is None


# Generated at 2022-06-24 04:08:19.303919
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddleware(MiddlewareMixin):
        pass

    test_middleware = TestMiddleware()

    assert not test_middleware._future_middleware


# Generated at 2022-06-24 04:08:20.624947
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert len(m._future_middleware) == 0


# Generated at 2022-06-24 04:08:29.499173
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.config import Config
    from sanic.exceptions import InvalidUsage

    class MiddlewareMixinTest(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    testMiddlewareMixin = MiddlewareMixinTest(Config())

    # Unit test for _future_middleware
    assert isinstance(testMiddlewareMixin._future_middleware, list)

    # Unit test for _apply_middleware
    with pytest.raises(NotImplementedError):
        testMiddlewareMixin._apply_middleware(None)

# Unit testing for middleware function
# This test was tested in the main function

# Unit testing for on_request function

# Generated at 2022-06-24 04:08:31.708042
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response(MiddlewareMixin, middleware=None)
    assert MiddlewareMixin.on_response(MiddlewareMixin, middleware=lambda: None)


# Generated at 2022-06-24 04:08:39.412980
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def test(request):
        pass

    @app.middleware("request")
    async def request_test(request):
        pass

    @app.middleware("response")
    async def response_test(request, response):
        pass

    @app.on_request
    async def on_request_test(request):
        pass

    @app.on_response
    async def on_response_test(request, response):
        pass

    assert len(app._future_middleware) == 4

# Generated at 2022-06-24 04:08:47.124774
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = Mock()
    app.config.EXAMPLE = 'example'

    @app.middleware
    def middleware(request):
        """ Docstring """
        return request

    attach_to = 'request'
    apply = True
    register_middleware = middleware
    future_middleware = FutureMiddleware(middleware, attach_to)
    assert future_middleware.middleware == middleware
    assert app._future_middleware[0] == future_middleware
    assert app._apply_middleware.called


# Generated at 2022-06-24 04:08:52.061574
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    """
    Test if constructors of class MiddlewareMixin works properly
    :return:
    """

    # Test if MiddlewareMixin class can be initialized
    middleware_mixin = MiddlewareMixin()
    assert type(middleware_mixin) is MiddlewareMixin
    assert isinstance(middleware_mixin, MiddlewareMixin)



# Generated at 2022-06-24 04:09:03.097024
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import pytest
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import Response
    app = Sanic(__name__)

    @app.middleware
    def test_middleware(request):
        assert isinstance(request, Request)
        return Response('OK')

    @app.middleware('request')
    def test_middleware_with_alias(request):
        assert isinstance(request, Request)
        return Response('OK')

    @app.middleware('response')
    def test_middleware_with_alias(request, response):
        assert isinstance(response, Response)
        return response

    @app.route('/')
    def handler(request):
        return Response('OK')

    _, response = app.test_client.get('/')
   

# Generated at 2022-06-24 04:09:12.432522
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    
    app = Sanic(__name__)
    
    def test_middleware(request):
        return request

    app.middleware(test_middleware)
    assert app._future_middleware[0].middleware is test_middleware
    assert app._future_middleware[0].attach_to == "request"
    
    app.middleware(test_middleware, attach_to="response")
    assert app._future_middleware[1].middleware is test_middleware
    assert app._future_middleware[1].attach_to == "response"

    app.middleware("request")(test_middleware)
    assert app._future_middleware[2].middleware is test_middleware
    assert app._future_middleware[2].attach_to == "request"

# Generated at 2022-06-24 04:09:13.479274
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin().on_response()

# Generated at 2022-06-24 04:09:21.608968
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.views import HTTPMethodView
    app = Sanic()

    @app.middleware
    async def middleware1(request):
        ...

    @app.middleware
    async def middleware2(request):
        ...

    @app.middleware('response')
    async def response_middleware1(request, response):
        ...

    @app.middleware('response')
    async def response_middleware2(request, response):
        ...

    class ExampleView(HTTPMethodView):
        ...

    @app.route('/')
    class ExampleResource(HTTPMethodView):
        ...

    assert len(app._future_middleware) == 4


# Generated at 2022-06-24 04:09:31.143160
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class _Test:
        def __init__(self):
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, future_middleware):
            pass

    middleware_mixin = MiddlewareMixin()
    test = _Test()
    test.middleware = middleware_mixin.middleware
    assert test._future_middleware == []
    assert test.middleware == middleware_mixin.middleware

    def _middleware():
        pass

    test.middleware(_middleware)
    assert len(test._future_middleware) == 1
    assert test._future_middleware[0].middleware == _middleware
    assert test._future_middleware[0].attach_to == "request"

    def _middleware_1():
        pass


# Generated at 2022-06-24 04:09:42.176868
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.base import MiddlewareMixin

    class M(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware) -> None:
            pass

    def handler1(request):
        pass

    def handler2(request):
        pass

    m = M()
    assert m._future_middleware == []
    m.on_request(handler1)
    assert m._future_middleware == [FutureMiddleware(handler1, "request")]
    m.on_response(handler2)
    assert m._future_middleware == [
        FutureMiddleware(handler1, "request"),
        FutureMiddleware(handler2, "response"),
    ]
    m.middleware(handler1, "request")

# Generated at 2022-06-24 04:09:51.889583
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import unittest

    class TestMiddlewareMixin_on_response(unittest.TestCase):
        def test_on_response(self):
            from sanic.exceptions import ServerError
            from sanic.response import json
            
            class Test(MiddlewareMixin):
                def __init__(self):
                    self._future_middleware: List[FutureMiddleware] = []
                    @self.on_response
                    def func_on_response(request, response):
                        return json({"a":"a"})
                    

            """
            test_MiddlewareMixin_on_response > test_on_response ERROR
            test_MiddlewareMixin_on_response > test_on_response FAILED (failures=1)
            """
            t = Test()

# Generated at 2022-06-24 04:09:52.849165
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    app = MiddlewareMixin()
    assert app._future_middleware == []

# Generated at 2022-06-24 04:09:55.561888
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    mm = MiddlewareMixin()
    mm.on_request()


# Generated at 2022-06-24 04:10:02.075578
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.exceptions import ServerError
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_on_request')
    @app.middleware('request')
    def request_middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert request.text == 'OK'

    @app.middleware('response')
    def response_middleware(request, response):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == "OK"

    @app.middleware
    def middleware(request):
        return text('OK')

    request, response = app.test_client.get('/')

# Generated at 2022-06-24 04:10:08.919270
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        pass

    @app.middleware('response')
    async def response_middleware(request, response):
        pass

    @app.middleware
    async def arbitrary_middleware(request, response):
        pass

    assert isinstance(request_middleware, partial)
    assert request_middleware.func is app.middleware
    assert request_middleware.args == ()
    assert request_middleware.keywords == {'attach_to': 'request'}

    assert isinstance(response_middleware, partial)
    assert response_middleware.func is app.middleware
    assert response_middleware.args == ()

# Generated at 2022-06-24 04:10:17.011771
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MyMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            assert self._future_middleware == []
    m = MyMiddlewareMixin()
    assert m._future_middleware == []
    assert m.middleware(lambda x: x, attach_to='request')
    assert len(m._future_middleware) == 1

# Generated at 2022-06-24 04:10:22.860503
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    result = []
    s = Sanic()

    @s.on_response
    async def on_response(request, response):
        result.append({"request": request, "response": response})

    assert len(s._future_middleware) == 1
    assert s._future_middleware[0].type == "response"
    assert s._future_middleware[0].middleware == on_response



# Generated at 2022-06-24 04:10:27.595130
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class App(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    app = App()
    assert app._future_middleware == []

# Generated at 2022-06-24 04:10:28.259363
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert True

# Generated at 2022-06-24 04:10:28.913167
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

# Generated at 2022-06-24 04:10:36.334434
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    class TestClass_MiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__()
    test = TestClass_MiddlewareMixin()
    assert isinstance(test, TestClass_MiddlewareMixin)
    assert isinstance(test, MiddlewareMixin)
    assert isinstance(test, Sanic)
    assert test._future_middleware == []

# TODO: find a way to test the _apply_middleware function


# Generated at 2022-06-24 04:10:40.245881
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic import response

    app = Sanic("test_MiddlewareMixin_on_response")

    @app.on_response
    def test_callback(request, response):
        assert request
        assert response

    request, response = app.test_client.get(
        "/", headers={"Cookie": "cookie"}
    )
    assert response.status == 200

# Generated at 2022-06-24 04:10:49.570511
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A:
        def __init__(self):
            self.middleware_stack: List[FutureMiddleware] = []
        def _apply_middleware(self, middleware:FutureMiddleware):
            self.middleware_stack.append(middleware)

    a = A()
    assert a.middleware_stack==[]
    @a.middleware('request')
    def on_request():
        pass
    assert a.middleware_stack!=[]
    assert a.middleware_stack[0].attach_to=='request'

    @a.middleware('response')
    def on_response():
        pass
    assert a.middleware_stack[0].attach_to=='request'
    assert a.middleware_stack[1].attach_to=='response'

# Generated at 2022-06-24 04:10:59.277842
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test')
    def hello(request):
        return text('Hello!')

    @app.middleware
    def add_header(request):
        request['header'] = 'added'

    @app.route('/')
    async def handler(request):
        return text('Hello!')
    
    # When we call on_request with a parameter
    app.on_request(add_header)
    print(app._future_middleware)
    assert app._future_middleware[0].middleware == add_header
    assert app._future_middleware[0].attach_to == "request"
    
    # When we call on_request without a parameter
    app.on_request()
    assert app._future_middleware[1].middleware == None

#

# Generated at 2022-06-24 04:11:05.048400
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    class MiddlewareMixinExample(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    middlewaremixin = MiddlewareMixinExample()
    f = middlewaremixin.on_request()
    m = f(lambda x: x)
    assert m.__name__ == "<lambda>"


# Generated at 2022-06-24 04:11:07.288449
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class test(MiddlewareMixin):
        def __init__(self):
            pass
        def _apply_middleware(self, middleware):
            pass
    a = test()
    assert hasattr(a.on_response, "__call__")


# Generated at 2022-06-24 04:11:09.180509
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
  #Test if 
  try:
    MiddlewareMixin(1, 2, 3, 4)
  except NotImplementedError:
    return True
  return False

# Generated at 2022-06-24 04:11:09.951291
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()

# Generated at 2022-06-24 04:11:16.988493
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.models.mock import MockRequest, MockResponse
    from sanic.models.middleware import MockMiddlewareResponse

    def middleware(request):
        return MockResponse()

    def async_middleware(request):
        return MockResponse()

    app = Sanic(__name__)
    app.on_request(middleware)
    app.on_response(async_middleware)

    app.on_response(async_middleware)
    request = MockRequest(app)
    response = MockResponse()
    assert isinstance(
        app.process_request(request), MockMiddlewareResponse
    ), "Did not correctly call middleware bound to start"

# Generated at 2022-06-24 04:11:23.025772
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    from sanic.config import Config
    from sanic.server import HttpProtocol

    config = Config()
    middleware = MiddlewareMixin()
    app = Sanic(config=config)
    isinstance(app._future_middleware, List)
    assert app._future_middleware == []
    assert app.middleware == middleware.middleware
    assert app.on_request == middleware.on_request
    assert app.on_response == middleware.on_response

# Generated at 2022-06-24 04:11:23.657529
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    asy

# Generated at 2022-06-24 04:11:28.904663
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Test:
        def __init__(self):
            self._future_middleware = []
            self._apply_middleware = None
    mixin = MiddlewareMixin()
    test = Test()
    mixin._future_middleware = test._future_middleware
    mixin._apply_middleware = test._apply_middleware
    assert mixin._future_middleware == []
    assert mixin._apply_middleware is None
    assert test._future_middleware == []
    assert test._apply_middleware is None
    assert mixin != test


# Generated at 2022-06-24 04:11:39.171380
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import pytest
    from sanic.app import Sanic

    app = Sanic()

    # test for case "without middleware"
    @app.route('/')
    async def handler(request):
        return response.json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200

    # test for case "with middleware but not attach_to response"
    @app.middleware('request')
    async def add_test(request):
        request['test'] = 'test'

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert request['test'] != 'test'

    # test for case "with middleware and attach_to response"

# Generated at 2022-06-24 04:11:43.640970
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    try:
        middleware_mixin_instance = MiddlewareMixin()
    except NotImplementedError:
        assert True
        return
    assert False

if __name__ == "__main__":
    test_MiddlewareMixin()

# Generated at 2022-06-24 04:11:48.595929
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
  print(
      "========== test_MiddlewareMixin ===========\n"
      "Testing constructor of class MiddlewareMixin.\n"
      "Check if _future_middleware is initialized to empty list.\n"
  )
  middleware_mixin = MiddlewareMixin()
  assert len(middleware_mixin._future_middleware) == 0
  print("Passed.")


# Generated at 2022-06-24 04:11:50.355210
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    app=MiddlewareMixin()
    assert app._future_middleware==[], 'unit test failed'

# Generated at 2022-06-24 04:11:56.616869
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Service(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.state = 0

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.state += 1

    service = Service()
    service.on_response(middleware=lambda x: x)
    assert service.state == 1

# Generated at 2022-06-24 04:11:57.068681
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass

# Generated at 2022-06-24 04:12:03.954022
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic('test')

    async def middlware_function_request(request):
        return request

    async def middlware_function_response(request, response):
        return response

    app.middleware(middlware_function_request)
    app.on_request(middlware_function_response)

    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response

# Generated at 2022-06-24 04:12:08.823858
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    sanic_app = Sanic(name='test_on_request')
    
    def middleware_func(request):
        return None
    
    middleware_return_value = sanic_app.on_request(middleware_func)

    partial_return_value = middleware_return_value()

    assert partial_return_value == None


# Generated at 2022-06-24 04:12:13.379950
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic(__name__)

    @app.on_request
    def test(request):
        pass

    assert hasattr(app, '_future_middleware')
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-24 04:12:14.765334
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert(MiddlewareMixin.on_response(None)
    == partial(MiddlewareMixin.middleware, attach_to="response"))

# Generated at 2022-06-24 04:12:17.319938
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    _MiddlewareMixin = MiddlewareMixin(1, 2, 3)
    assert _MiddlewareMixin._future_middleware == []


# Generated at 2022-06-24 04:12:25.510678
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    ##################################################
    #    MiddlewareMixin.middleware is tested here.  #
    ##################################################

    # 1.input @sanic.Sanic.middleware and a attach_to
    # 2.get a list of middleware(@middleware)
    import pytest
    from sanic.app import Sanic

    app = Sanic("name")
    app.middleware("test middleware")

    @app.middleware("test middleware")
    async def test_middleware(request):
        pass

    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "test middleware"

# Generated at 2022-06-24 04:12:30.367585
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from serial import Serializer

    serializer = Serializer()

    class Parent:
        pass

    parent = Parent()

    assert hasattr(parent, "on_request")
    assert callable(parent.on_request)
    parent.on_request(serializer.list_to_string)

    res = serializer.string_to_list("a,b,c")
    assert res == ["a", "b", "c"]


# Generated at 2022-06-24 04:12:33.437950
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    app = Sanic(__name__)
    test1 = MiddlewareMixin()
    # test the constructure
    assert test1._future_middleware == []

# Generated at 2022-06-24 04:12:35.934000
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Original():
        pass
    class New(MiddlewareMixin):
        pass
    n = New()
    n.middleware(Original)

# Generated at 2022-06-24 04:12:38.081855
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewareMixin = MiddlewareMixin()
    assert middlewareMixin._future_middleware == []


# Generated at 2022-06-24 04:12:42.172486
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m = MiddlewareMixin()
    m.middleware(middleware=None, attach_to=None, apply=True)
    assert m._future_middleware is not None
    assert m._apply_middleware(middleware=None) is None


# Generated at 2022-06-24 04:12:43.177602
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    obj = MiddlewareMixin
    assert obj

# Generated at 2022-06-24 04:12:51.470731
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class FakeSanic:
        def __init__(self, *args, **kwargs):
            self._future_middleware = []

        def _apply_middleware(self, middleware):
            pass

    fake_sanic = FakeSanic()
    fake_middleware = lambda request: None

    fake_sanic.middleware(fake_middleware)
    fake_sanic.middleware(fake_middleware, "response")

    assert len(fake_sanic._future_middleware) == 2
    assert fake_sanic._future_middleware[0].middleware == fake_middleware
    assert fake_sanic._future_middleware[0].attach_to == "request"
    assert fake_sanic._future_middleware[1].middleware == fake_middleware
    assert fake_sanic._future_middleware

# Generated at 2022-06-24 04:12:55.804832
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Foo(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(Foo, self).__init__(*args, **kwargs)
    
    foo = Foo()
    assert foo._future_middleware == []

# Generated at 2022-06-24 04:12:57.135529
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    mm = MiddlewareMixin()
    mm.on_response(lambda e: e)

# Generated at 2022-06-24 04:12:59.569272
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        pass

    # Test for __init__
    assert TestMiddlewareMixin()._future_middleware == []

# Generated at 2022-06-24 04:13:08.433648
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Api(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(Api, self).__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = Api()

    @app.middleware('request')
    def first_middleware(request):
        pass

    @app.middleware('request')
    def second_middleware(request):
        pass

    @app.middleware('response')
    def third_middleware(request, response):
        pass


# Generated at 2022-06-24 04:13:10.056888
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    foo = Sanic("test")
    foo.middleware(foo)

# Generated at 2022-06-24 04:13:13.532800
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    app = Sanic()
    assert (app._future_middleware == [])

# Generated at 2022-06-24 04:13:16.954422
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    with pytest.raises(NotImplementedError):
        MiddlewareMixin()._apply_middleware(None)

# Generated at 2022-06-24 04:13:19.458850
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class a(MiddlewareMixin):
        def __init__(self):
            super().__init__()
    aa=a()
    assert aa._future_middleware==[]

# Generated at 2022-06-24 04:13:23.863076
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_on_response')

    @app.on_response
    def test_hook_response(request, response):
        response.body = b'dog'

    request, response = app.test_client.get('/')
    assert response.body == b'dog'

# Generated at 2022-06-24 04:13:32.747599
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    '''
    Test case for method on_request
    '''
    _future_middleware = []

    def apply_middleware(middleware: FutureMiddleware):
        _future_middleware.append(middleware)

    class TestCase(MiddlewareMixin):
        '''
        Test case class
        '''
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            '''
            Test case inner method
            '''
            apply_middleware(middleware)

    def test_middleware():
        '''
        Test middleware
        '''
        pass

    test_case = TestCase()
    test_case.on_request(test_middleware)

    assert len(_future_middleware) == 1
    future

# Generated at 2022-06-24 04:13:41.619165
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class fake_middleware(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(fake_middleware,  self).__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError

    middleware = fake_middleware()

    @middleware.middleware
    def a(request):
        pass

    assert len(middleware._future_middleware) == 1
    assert middleware._future_middleware[0].middleware == a
    assert middleware._future_middleware[0].type == 'request'


# Generated at 2022-06-24 04:13:46.606796
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.models.futures import middlewares

    def my_middleware(request):
        pass

    app = Sanic("test")
    app.on_request(my_middleware)

    assert my_middleware == middlewares[0][0]


# Generated at 2022-06-24 04:13:49.569034
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Instantiating object of class MiddlewareMixin
    obj = MiddlewareMixin()

    # Testing for the value of attribute _future_middleware
    assert obj._future_middleware == []

# Generated at 2022-06-24 04:13:58.786579
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    test = MiddlewareMixin()

    def f():
        pass

    def g():
        pass

    def h():
        pass

    test.middleware((f,g), attach_to="request", apply=True)
    test.middleware(h, attach_to="response", apply=False)
    assert test._future_middleware[0].middleware == (f,g)
    assert test._future_middleware[0].attach_to == "request"
    assert test._future_middleware[1].middleware == h
    assert test._future_middleware[1].attach_to == "response"
    assert test._future_middleware[0].apply == test._future_middleware[1].apply


# Generated at 2022-06-24 04:13:59.813065
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass


# Generated at 2022-06-24 04:14:00.689480
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-24 04:14:06.499386
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_on_response')

    @app.middleware('response')
    async def process_response(request, response):
        response.headers['X-Test-Process-Response'] = 'True'
        return response

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.headers['X-Test-Process-Response'] == 'True'
    assert response.text == 'OK'

# Generated at 2022-06-24 04:14:12.444967
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    test_MiddlewareMixin = TestMiddlewareMixin()
    assert test_MiddlewareMixin.on_request(middleware=None)


# Generated at 2022-06-24 04:14:15.773099
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class mw(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            self._future_middleware.append(middleware)

    _mw = mw()
    mw_obj = _mw.on_response()
    assert mw_obj.keywords == {'attach_to': 'response'}


# Generated at 2022-06-24 04:14:16.344080
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    ...

# Generated at 2022-06-24 04:14:28.135733
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from types import FunctionType
    
    app = Sanic('sanic-middlewareMixin-test')
    app.config.KEEP_ALIVE = True
    # Test if a middleware is registed properly
    @app.middleware
    async def example_middleware(request):
        print("Before request")
    assert isinstance(app._future_middleware[0].middleware, FunctionType)
    # Test if a middleware is registed properly with the parameter which type of middleware is being registered.
    @app.middleware('request')
    async def example_middleware2(request):
        print("Before request")
    assert app._future_middleware[1].attach_to == "request"
    # Test if a middleware is registed properly with no parameter.

# Generated at 2022-06-24 04:14:34.714491
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    app = App()
    @app.middleware('request')
    async def test_middleware(request):
        pass
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].middleware(1, 2) == test_middleware(1, 2)

# Generated at 2022-06-24 04:14:40.866797
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic()

    @app.on_response
    def test_Middleware(request, response):
        print(request, response)

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].parent == test_Middleware

# Generated at 2022-06-24 04:14:42.266942
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin_test = MiddlewareMixin()
    assert middleware_mixin_test


# Generated at 2022-06-24 04:14:42.761412
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    assert False

# Generated at 2022-06-24 04:14:47.574417
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class FakeApp:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
            return super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            return True

    app = MiddlewareMixin(FakeApp())      
    app.on_request(lambda request: True)
    assert(len(app._future_middleware) == 1)
    assert(app._future_middleware[0].middleware(None) == True) 


# Generated at 2022-06-24 04:14:52.320221
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    class MiddlewareMixinTest(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            print(middleware)
    a = MiddlewareMixinTest()
    assert a._future_middleware == []


# Generated at 2022-06-24 04:14:59.980465
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    logging.basicConfig(level=logging.DEBUG)
    
    class TestClass(MiddlewareMixin):
        def __init__(self):
            super().__init__()
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    t = TestClass()

    print("\n Test on_request")
    @t.on_request
    def f(request):
        return request

    assert t._future_middleware[0].middleware == f
    assert t._future_middleware[0].attach_to == "request"



# Generated at 2022-06-24 04:15:02.560695
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m_m = MiddlewareMixin()
    m_m.middleware()
    m_m.middleware('request')
    m_m.middleware('response')
    m_m.on_response()
    m_m.on_request()



# Generated at 2022-06-24 04:15:04.433320
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-24 04:15:08.621302
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Create fake args, kwargs
    args = None
    kwargs = None

    # Create fake MiddlewareMixin
    middleware_mixin = MiddlewareMixin(args, kwargs)
    middleware_mixin.on_request()
    middleware_mixin._apply_middleware()



# Generated at 2022-06-24 04:15:12.764921
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Define the parameters
    middleware = None

    # Define the method to be tested
    middleware_mixin = MiddlewareMixin()
    result = middleware_mixin.on_request(middleware)

    # No assert
    # Maybe later
    print("result")
    print(result)
    #result = ("result", "result")
    


# Generated at 2022-06-24 04:15:14.684687
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class M(MiddlewareMixin):
        pass
    obj = M()
    obj.on_request()


# Generated at 2022-06-24 04:15:15.915483
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-24 04:15:26.428744
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic import response
    import asyncio

    app = Sanic("test_MiddlewareMixin_on_response")

    @app.route("/")
    def handler(request):
        @request.app.on_response("test_MiddlewareMixin_on_response")
        def on_response(request, response):
            response.body = b"Hello World"

        return response.text("OK")

    request, response = app.test_client.get("/")
    assert response.status == 200
    assert response.body == b"Hello World"

    @app.route("/2")
    def handler(request):
        @request.app.on_response
        def on_response(request, response):
            response.body = b"Hello World"

        return response.text

# Generated at 2022-06-24 04:15:33.383750
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(MiddlewareMixin, self).__init__(*args, **kwargs)
            self.on_response_called = False

        def _apply_middleware(self, middleware):
            self.on_response_called = True

    server = TestMiddlewareMixin()
    server.on_response()

    assert server.on_response_called

# Generated at 2022-06-24 04:15:41.892781
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    print("\n\nTesting MiddlewareMixin.on_request")
    class TestMiddlewareMixin(MiddlewareMixin):
        pass

    test_middleware = TestMiddlewareMixin()

    @test_middleware.on_request()
    def test_middleware(request):
        return("This is TestMiddlewareMixin")

    assert TestMiddlewareMixin._future_middleware
    print("Passed TestMiddlewareMixin.on_request test.")

# Generated at 2022-06-24 04:15:50.222526
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic('test_sanic_on_response')

    @app.middleware
    async def on_response1(request, response):
        return response

    response = app.on_response(on_response1)
    assert isinstance(response, partial)
    assert response.func == app.middleware
    assert response.keywords['attach_to'] == 'response'

    response = app.on_response()
    assert isinstance(response, partial)
    assert response.func == app.middleware
    assert response.keywords['attach_to'] == 'response'

    response = app.on_response(on_response1())
    assert response is None