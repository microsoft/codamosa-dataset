

# Generated at 2022-06-24 04:06:06.068491
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from . import app
    from . import request
    from . import url
    from . import Sanic
    from . import response
    import json
    import unittest

    # initialization
    app = Sanic(__name__)

    # middleware_or_request is a callable
    @app.on_response(middleware)
    def print_args(request, response):
        print(request.args)

    @app.route('/')
    async def handler(request):
        return response.json(request)

    @app.route('/test_on_response')
    def handler_test_on_response(request):
        return response.json(request)

    # middleware_or_request is a str

# Generated at 2022-06-24 04:06:09.067734
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    obj = TestMiddlewareMixin()
    assert obj._future_middleware == []

# Generated at 2022-06-24 04:06:14.138688
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():


    @app.middleware
    def test_middleware(request):
        return request

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"

# Generated at 2022-06-24 04:06:19.612638
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    entity = MiddlewareMixin()
    from sanic.response import HTTPResponse
    from sanic.config import Config
    from sanic.exceptions import NotFound
    from sanic.views import CompositionView
    from sanic import Sanic
    from sanic.request import Request

    # test_MiddlewareMixin_middleware_with_middleware_or_request_is_function
    def middleware_or_request(request, response=None):
        return HTTPResponse(middleware_or_request)
    middleware_decorator = entity.middleware(middleware_or_request)
    assert middleware_decorator == middleware_or_request
    assert isinstance(middleware_decorator, partial)
    assert len(entity._future_middleware) == 1
    assert entity._future_

# Generated at 2022-06-24 04:06:29.292502
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.futures import MiddlewareFuture
    from sanic.models.futures import FutureMiddleware
    from sanic.models import BaseModel
    from sanic.response import HTTPResponse
    from sanic.exceptions import SanicException
    class TestRequestMiddleware(MiddlewareFuture):
        _middleware = 'request'

        def __call__(self, request):
            try:
                return self.__next__(request)
            except StopIteration:
                raise

    class TestResponseMiddleware(MiddlewareFuture):
        _middleware = 'response'

        def __call__(self, request, response):
            try:
                return self.__next__(request, response)
            except StopIteration:
                raise


# Generated at 2022-06-24 04:06:36.592465
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.models.futures import FutureMiddleware
    from sanic.exceptions import NotFound
    import requests

    app = Sanic("test_MiddlewareMixin_middleware")

    # middleware1 as a one-line function
    @app.middleware
    async def middleware1(request, _next):
        print("middleware1")
        print("before request")
        response = await _next(request)
        print("after response")
        return response

    @app.middleware("request")
    async def middleware2(request, _next):
        print("middleware2")
        print("before request")
        response = await _next(request)
        print("after response")
        return response


# Generated at 2022-06-24 04:06:48.470495
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Prepare test data
    def func_1():
        print("func_1")
    def func_2():
        print("func_2")
    def func_3():
        print("func_3")
    def func_4():
        print("func_4")

    # Begin test
    test_class = MiddlewareMixin()
    # function: return partial
    # parameter middleware_or_request: func_1
    # parameter attach_to: request
    ret_1 = test_class.middleware(func_1)
    assert ret_1 == partial(test_class.middleware, attach_to="request")
    # function: return middleware
    # parameter middleware_or_request: request
    # parameter middleware: func_2

# Generated at 2022-06-24 04:06:54.369451
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.models.middleware import Middleware

    @Sanic.middleware("request")
    def check_ture(request, args):
        assert True

    app = Sanic("CheckMiddlewareMixin")
    middleware = check_ture;
    app.middleware(middleware);
    app.middleware(middleware, "request")

# Generated at 2022-06-24 04:06:58.210128
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert 1==1


# Generated at 2022-06-24 04:07:04.394669
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class MockClass:
        def __init__(self):
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    mixin = MiddlewareMixin()
    mock = MockClass()

    assert isinstance(mixin.on_response(MockClass), partial)
    assert isinstance(mock.on_response(MockClass), partial)
    mock.on_response(MockClass)

# Generated at 2022-06-24 04:07:06.773311
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert callable(MiddlewareMixin().middleware)


# Generated at 2022-06-24 04:07:09.698510
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    test_middleware = TestMiddlewareMixin()
    assert test_middleware._future_middleware == []


# Generated at 2022-06-24 04:07:11.188094
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert (MiddlewareMixin.on_request == MiddlewareMixin.middleware)


# Generated at 2022-06-24 04:07:18.876019
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from .middleware import MiddlewareMixin
    from .request import Request
    from .response import HTTPResponse
    from .exceptions import NotFound

    class RequestProcessing:
        pass

    class RequestHandler:
        def __init__(self):
            self.func = RequestProcessing

    class ResponseHandler:
        def __init__(self):
            self.func = RequestProcessing

    class Application:
        def __init__(self):
            self._future_middleware = []
            self._request_class = Request
            self._response_class = HTTPResponse
            self._error_handler = {}

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    def func(request: Request):
        return True  # noqa


# Generated at 2022-06-24 04:07:27.224867
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.futures import FutureMiddleware
    class Mixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            self._future_middleware: List[FutureMiddleware] = []

    # test 1
    mm = Mixin()
    middleware = lambda:1
    mm.middleware(middleware)

    assert len(mm._future_middleware) == 1
    assert mm._future_middleware[0].middleware == middleware
    assert mm._future_middleware[0].attach_to == 'request'

    mm = Mixin()
    # test 2
    mm = Mixin()
    mm.middleware(middleware)  

    assert len(mm._future_middleware) == 1
    assert mm._future_middleware[0].middleware == middleware

# Generated at 2022-06-24 04:07:36.149499
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import unittest
    import sys
    import os
    import time
    import json
    import asyncio

    import sanic

    from sanic import Sanic
    from sanic.response import text
    from sanic.exceptions import ServerError, NotFound

    class MiddlewareMixinUnitTest(unittest.TestCase):

        def test_MiddlewareMixin_middleware_1(self):
            class SimpleClass:
                def __init__(self):
                    pass

            with self.assertRaises(NotImplementedError):
                middlewaremixin = MiddlewareMixin()
                middlewaremixin._apply_middleware(SimpleClass())


        def test_MiddlewareMixin_middleware_2(self):
            class SimpleClass():
                def __init__(self):
                    pass


# Generated at 2022-06-24 04:07:39.410359
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mw = MiddlewareMixin()


# Generated at 2022-06-24 04:07:47.764751
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddlewareMixinForTest(MiddlewareMixin):
        def __init__(self,args0,**kwargs):
            super().__init__(*args, **kwargs)

        def apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    test_args0 = "ok"
    # test constructor of MiddlewareMixinForTest
    test_middleware_mixin = MiddlewareMixinForTest(test_args0)
    assert len(test_middleware_mixin._future_middleware) == 0
    assert test_middleware_mixin._future_middleware == []


# Generated at 2022-06-24 04:07:54.856089
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class FakeRequest:
        def __init__(self):
            pass


    class FakeResponse:
        def __init__(self):
            pass


    class FakeServer(MiddlewareMixin):
        def __init__(self):
            pass

        def _apply_middleware(self, middleware):
            pass


    fake_server = FakeServer()
    fake_request1 = FakeRequest()
    fake_request2 = FakeRequest()
    fake_response1 = FakeResponse()


    @fake_server.on_request
    async def do_nothing1(request):
        return request


    @fake_server.on_request
    async def do_nothing2(request):
        return request


    @fake_server.on_response
    async def do_nothing3(request, response):
        return response




# Generated at 2022-06-24 04:08:00.818900
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class testMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    a = testMiddlewareMixin()
    assert a._future_middleware == []


# Generated at 2022-06-24 04:08:01.572417
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-24 04:08:03.934162
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin().on_response() == ''


# Generated at 2022-06-24 04:08:05.739553
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass


# Generated at 2022-06-24 04:08:09.960619
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    @Sanic.middleware
    def middleware_middleware(request):
        pass
    assert len(Sanic()._future_middleware) == 1
    assert len(Sanic()._future_middleware) == 1


# Generated at 2022-06-24 04:08:12.134643
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    s = MiddlewareMixin()

    @s.middleware
    def middleware(request):
        return request

    assert middleware == s._future_middleware[0]._middleware

# Generated at 2022-06-24 04:08:13.110722
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewareMixin = MiddlewareMixin()

# Generated at 2022-06-24 04:08:19.858727
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Test(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware):
            return middleware

    t = Test()
    # test with a callable
    def f():
        pass

    t.on_response(f)
    assert len(t._future_middleware) == 1
    assert t._future_middleware[0].func.__name__ == 'f'
    # test with a not callable
    t.on_response(middleware='test')
    assert len(t._future_middleware) == 2
    assert t._future_middleware[1].attach_to == 'test'
    # test with a not callable

# Generated at 2022-06-24 04:08:29.931040
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    temp = MiddlewareMixin()

    def mw_callable():
        pass

    @temp.middleware()
    def test_on_response(request, response):
        pass

    assert test_on_response.__name__ == 'test_on_response'

    test_on_response_assert_callable = temp.on_response(mw_callable)
    assert test_on_response_assert_callable.__name__ == 'mw_callable'
    test_on_response_assert_callable()

    test_on_response_assert_callable = temp.on_response()
    assert test_on_response_assert_callable('request', 'response').__name__ == 'test_on_response'
    test_on_response_assert_callable('request', 'response')

# Generated at 2022-06-24 04:08:40.500739
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            pass

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = App()
    def hi():
        return 'hi'
    def hello():
        return 'hello'

    app.middleware(hi)
    app.middleware(hello)
    # Check _future_middleware is working
    assert len(app._future_middleware) == 3
    assert app._future_middleware[0].middleware == hi
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[1].middleware == hello
    assert app._future_middleware[1].attach_to == "request"

    # Check on_

# Generated at 2022-06-24 04:08:47.584229
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddlewareMixinMock(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    tester = MiddlewareMixinMock()
    assert len(tester._future_middleware) == 0

test_MiddlewareMixin()


# Generated at 2022-06-24 04:08:53.259730
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class A(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    a = A()
    assert isinstance(a._future_middleware, List)

# Generated at 2022-06-24 04:08:59.216193
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            MiddlewareMixin.__init__(self, *args, **kwargs)

    test = TestClass()
    @test.on_request
    def test_middleware(request):
        pass
    assert test._future_middleware == [FutureMiddleware(test_middleware, 'request')]

# Generated at 2022-06-24 04:09:00.728464
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response.__doc__ is not None

# Generated at 2022-06-24 04:09:08.835210
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class A(MiddlewareMixin):
        def __init__(self):
            MiddlewareMixin.__init__(self)
            self._future_middleware: List[FutureMiddleware] = []
        def _apply_middleware(self, middleware):
            self._future_middleware.append(middleware)

    a = A()

    @a.on_request
    def f(request):
        pass

    assert len(a._future_middleware) == 1
    assert a._future_middleware[0].middleware == f
    assert a._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-24 04:09:17.695051
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class FakeMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
            self._middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, future_middleware: FutureMiddleware):
            self._middleware.append(future_middleware)

        def middleware(self, *args, **kwargs):
            pass

    fake_middleware_mixin = FakeMiddlewareMixin()

    def fake_middleware():
        return

    fake_middleware_mixin.on_response(fake_middleware)

    assert (len(fake_middleware_mixin._future_middleware) == 1)

    fake_future_middleware = fake_middleware_mix

# Generated at 2022-06-24 04:09:18.242445
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert True

# Generated at 2022-06-24 04:09:27.785699
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    '''
    def on_request(self, middleware=None):
        if callable(middleware):
            return self.middleware(middleware, "request")
        else:
            return partial(self.middleware, attach_to="request")
    '''
    from sanic.blueprints import Blueprint
    blueprint = Blueprint('test_MiddlewareMixin_on_request', url_prefix='/test')
    blueprint.on_request(None)  # Not a callable, so return partial(self.middleware, attach_to="request")
    blueprint.on_request(blueprint.on_request)  # callable, so return self.middleware(middleware, "request")
    blueprint.on_request(True)  # callable, so return self.middleware(middleware, "request")

# Generated at 2022-06-24 04:09:31.137113
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    func = middleware(middleware_or_request='response', attach_to='request', apply=True)
    assert callable(func)
    assert func.__name__ == 'register_middleware'


# Generated at 2022-06-24 04:09:32.598130
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mix = MiddlewareMixin()
    assert mix._future_middleware == []

# Generated at 2022-06-24 04:09:34.194972
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware = MiddlewareMixin()
    assert middleware is not None

# Generated at 2022-06-24 04:09:43.153058
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Initialization of a instance of class MiddlewareMixin
    middleware_mixin_instance = MiddlewareMixin()

    # Calling method on_request with a function as argument
    def function(request, response):
        print("Hello World!")
    # Expected output: @middleware(middleware, "request")
    assert middleware_mixin_instance.on_request(function) == middleware_mixin_instance.middleware(function, "request")

    # Calling method on_request with no argument
    assert middleware_mixin_instance.on_request() == partial(middleware_mixin_instance.middleware, attach_to="request")



# Generated at 2022-06-24 04:09:48.674487
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class test_MiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    to_test = test_MiddlewareMixin()

    @to_test.middleware('request')
    def test_middleware(request, response):
        return

    assert len(to_test._future_middleware) == 1


# Generated at 2022-06-24 04:09:56.900857
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic(__name__)

    flag = 0

    @app.middleware('response')
    async def function(request):
        nonlocal flag
        flag += 1
        response = await request
        return response

    assert flag == 0
    assert isinstance(app.on_response(), partial)
    assert isinstance(app.on_response(middleware=function), partial)
    assert isinstance(app.on_response(middleware=function), partial)
    assert flag == 1


# Generated at 2022-06-24 04:10:05.420711
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super(TestMiddlewareMixin, self).__init__()
            self.on_response(self.on_response_middleware)

        @on_response
        def on_response_middleware(self_, request, response):
            response = response
            return response

    test_mixin = TestMiddlewareMixin()
    assert hasattr(test_mixin, 'on_response')



# Generated at 2022-06-24 04:10:16.969155
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # CASE1: test for method middleware(middleware_or_request, attach_to="request", apply=True)
    class Test(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test = Test()
    def test_middleware(request):
        pass
    # CASE1.1: @app.middleware
    test.middleware(test_middleware)
    assert test._future_middleware[0].middleware == test_middleware
    assert test._future_middleware[0].attach_to == "request"
    # CASE1.2: @app.middleware('request')
    def test_middleware2(request):
        pass
    test.middleware(test_middleware2, attach_to='request')
    assert test._future_middleware

# Generated at 2022-06-24 04:10:18.646389
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Testable(MiddlewareMixin): pass

    assert Testable()._future_middleware == []


# Generated at 2022-06-24 04:10:19.595004
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    obj = MiddlewareMixin()
    print(obj)

# Generated at 2022-06-24 04:10:20.901843
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    assert mm._future_middleware == []

# Generated at 2022-06-24 04:10:23.064907
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = MiddlewareMixin()
    @app.on_request
    def process_request(request):
        pass

# Generated at 2022-06-24 04:10:33.361564
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():

    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import SanicException

    sanic_app = Sanic('test_on_response')

    @sanic_app.route('/')
    async def index(request):
        return text('Awesome!')

    @sanic_app.middleware('request')
    def halt_request(request):
        raise SanicException('Request was halted!')

    @sanic_app.middleware('response')
    def halt_response(request, response):
        raise SanicException('Response was halted!')

    request, response = sanic_app.test_client.get('/')
    assert response.status == 500

# Generated at 2022-06-24 04:10:42.956728
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.views import HTTPMethodView
    from sanic.exceptions import ServerError

    class TestView(HTTPMethodView):
        async def get(self, request):
            return text("I'm get method")

        async def post(self, request):
            return text("I'm post method")

        async def options(self, request):
            return text("I'm options method")

        async def put(self, request):
            return text("I'm put method")

        async def patch(self, request):
            return text("I'm patch method")

        async def delete(self, request):
            return text("I'm delete method")

        middleware = ("request")

    test_app = Sanic("test_MiddlewareMixin_middleware")


# Generated at 2022-06-24 04:10:51.700702
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_sanic_middleware_mixin')
    @app.middleware('request')
    async def request_middleware(request):
        request['app'] = app
    @app.middleware('response')
    async def response_middleware(request, response):
        response['app'] = app

    assert(app.is_request_stream is False)
    assert(app.is_response_stream is False)

    assert(len(app._future_middleware) == 2)
    assert(app._future_middleware[0].attach_to == 'request')
    assert(app._future_middleware[1].attach_to == 'response')
    assert(app._future_middleware[0].middleware is request_middleware)

# Generated at 2022-06-24 04:10:57.820611
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic()
    @app.middleware
    def middleware(request):
        print('a', request)
    @app.route('/')
    async def handler(request):
        return text('OK')
    request, response = app.test_client.get('/')
    app.stop()

# Generated at 2022-06-24 04:10:59.971401
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # TODO: IMPLEMENT TESTS
    print('Not implemented')


# Generated at 2022-06-24 04:11:06.425801
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MiddlewareMixin_Test(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            assert isinstance(middleware, FutureMiddleware)
            assert callable(middleware.middleware)
            assert middleware.attach_to=="request"

    test = MiddlewareMixin_Test()
    test.on_request(test.on_request)
    test.on_request()(test.on_request)


# Generated at 2022-06-24 04:11:15.878316
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    import pytest
    import asyncio

    def test_middleware(request):
        pass

    @pytest.mark.parametrize(
        "middleware, attach_to",
        [
            ("request", "request"),
            ("response", "response"),
            (test_middleware, "response"),
        ],
    )
    def test_middleware_instances(middleware, attach_to):
        app = Sanic(__name__)
        app.config.update(MIDDLEWARE=[])
        app.on_response(middleware)
        assert app._future_middleware[-1].attach_to == attach_to

    test_middleware_instances()



# Generated at 2022-06-24 04:11:17.829940
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    test = MiddlewareMixin()
    assert(callable(test.on_response()))

# Generated at 2022-06-24 04:11:25.261184
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    @Sanic.middleware
    def middleware(request, response):
        pass
    from sanic.response import text
    @Sanic.middleware('response')
    def middleware(request, response):
        return text('text')
    app = Sanic('test_middleware')
    assert app._future_middleware
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].middleware == middleware
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-24 04:11:32.059530
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TempClass:
        def __init__(self, *args, **kwargs):
            self._future_middleware: object = object
    tempObj = TempClass()
    assert isinstance(tempObj, TempClass)
    assert tempObj._future_middleware == object


# Generated at 2022-06-24 04:11:41.124008
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(TestMiddlewareMixin, self).__init__(*args, **kwargs)
            self._future_middleware = []

        def _apply_middleware(self, middleware):
            print(middleware.middleware)

    m = TestMiddlewareMixin()

    # Test callable param
    def test_middleware_method1(middleware):
        print(middleware)
    m.on_request(test_middleware_method1)

    # Test partial method of decorator
    def test_middleware_method2(middleware):
        print(middleware)
    m.on_request()(test_middleware_method2)

    # Test no passed method
    m.on_

# Generated at 2022-06-24 04:11:51.769093
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from .router import RouteResult
    from .router import Router

    from sanic.exceptions import InvalidUsage
    from sanic.request import Request
    from sanic.response import HTTPResponse

    async def handler(request):
        return HTTPResponse(status=200, headers={"X-Hit": "1"}, text="ok")

    async def middleware_request(request):
        return HTTPResponse(status=200, headers={"X-Hit": "2"}, text="ok")

    async def middleware_response(request, response):
        return HTTPResponse(status=201, headers={"X-Hit": "3"})


# Generated at 2022-06-24 04:11:53.778284
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    mm = MiddlewareMixin()
    assert mm.on_request(middleware="test") != None

# Generated at 2022-06-24 04:12:04.080437
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()

    def middleware_method():
        pass

    assert test_middleware_mixin.middleware(middleware_method) == middleware_method

    assert (
        test_middleware_mixin.middleware(middleware_method)
        == test_middleware_mixin.middleware(middleware_method)(middleware_method)
    )

    assert (
        test_middleware_mixin.middleware(middleware_method)
        is test_middleware_mixin.middleware(middleware_method)(middleware_method)
    )


# Generated at 2022-06-24 04:12:14.512221
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import unittest
    from unittest.mock import Mock
    from sanic.utils import test_utils
    from sanic.models import MiddlewareMixin

    app = test_utils.mock_app(MiddlewareMixin)
    test_func = Mock()

    test_on_request = lambda: app.on_request(test_func)
    print(test_on_request)
    class test_MiddlewareMixin_on_request(unittest.TestCase):
        def test__on_request_returns_partial(self):
            target = app.on_request()
            assert callable(target)
            target()
            test_func.assert_called()
    if __name__ == "__main__":
        unittest.main()

# Generated at 2022-06-24 04:12:24.805422
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    from pprint import pprint
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    class MMM(MiddlewareMixin):

        def _apply_middleware(self, middleware: FutureMiddleware):
            print('Test method middleware: ', middleware)

    mmm = MMM()

    @mmm.middleware
    async def mw1(request):
        print('Test method middleware: ', request)

    @mmm.middleware('request')
    async def mw2(request):
        print('Test method middleware: ', request)

    @mmm.on_request
    async def mw3(request):
        print('Test method middleware: ', request)


# Generated at 2022-06-24 04:12:28.717473
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Initialization of MiddlewareMixin
    app = MiddlewareMixin()
    # Create a function to be used as middleware
    def middleware_function(request):
        return True
    # Call on_request
    on_request = app.on_request(middleware_function)
    # Call on_request
    on_request()

# Generated at 2022-06-24 04:12:34.879615
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    '''
    Register a middleware, but don't apply it by default.
    '''
    class App(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            middleware.apply(self)

    app = App()
    app.on_request(middleware="TestMiddleware")

    assert app._future_middleware[0].middleware == "TestMiddleware"
    assert app._future_middleware[0].attach_to == "request"



# Generated at 2022-06-24 04:12:41.379528
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # No input parameter, return partial object
    app = MiddlewareMixin()
    assert callable(app.on_request())

    # Input parameter is middleware, return middleware
    a = lambda x: x
    assert a == app.on_request(a)

    # Test for mixerin on_request
    assert callable(MiddlewareMixin().on_request())
    assert callable(MiddlewareMixin().on_response())

# Generated at 2022-06-24 04:12:42.224756
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass  # Pass unit test

# Generated at 2022-06-24 04:12:50.788075
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = Application()

    @app.middleware('request')
    async def request_middleware_in_app(request):
        # type: (Request) -> Union[None, Awaitable[None]]
        request['full_path'] = "{}?{}".format(request.path, request.query_string.decode())

    @app.middleware('response')
    async def response_middleware_in_app(request, response):
        # type: (Request, Response) -> Union[None, Awaitable[None]]
        response.headers['Server'] = 'Foo/2.1.1'

    #Unit test for method on_request of class MiddlewareMixin

# Generated at 2022-06-24 04:12:57.771623
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    x = MiddlewareMixin()
    assert x._future_middleware == []

    sanic = Sanic()
    b1 = Blueprint('b1')
    b2 = Blueprint('b2')
    assert sanic._future_middleware == []
    assert b1._future_middleware == []
    assert b2._future_middleware == []

if __name__ == "__main__":
    test_MiddlewareMixin()

# Generated at 2022-06-24 04:12:58.752168
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass


# Generated at 2022-06-24 04:13:06.660692
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # create mock
    mock_MiddlewareMixin = MiddlewareMixin()
    expected_result1 = None
    expected_result2 = partial(MiddlewareMixin.middleware, attach_to="request")

    # run test
    actual_result1 = mock_MiddlewareMixin.middleware() # Note: this is the decorator!
    actual_result2 = actual_result1(partial(MiddlewareMixin.middleware)) # this is the wrapper!

    assert expected_result1 == actual_result2
    assert expected_result2 == actual_result1

# Generated at 2022-06-24 04:13:12.573672
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic()

    @app.on_request
    async def before(request):
        request.foo = 'bar'
     
    @app.route('/')
    async def handler(request):
        return text(request.foo)

    request, response = app.test_client.get('/')
    response.body.decode() == 'bar'


# Generated at 2022-06-24 04:13:23.138181
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text
    import asyncio
    # we create a dummy Sanic app
    app = Sanic(__name__)

    @app.middleware("request")
    async def handler(request):
        await asyncio.sleep(2)

    @app.middleware("response")
    async def handler(request, response):
        await asyncio.sleep(1)
        response.text = "closed"

    @app.middleware("response")
    async def handler1(request, response):
        await asyncio.sleep(2)
        response.text = "closed"

    @app.route("/")
    def dummy_route(request):
        return text("Sanic")

# Generated at 2022-06-24 04:13:24.119709
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert 1 == 1



# Generated at 2022-06-24 04:13:31.165477
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Obj(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(Obj, self).__init__(*args, **kwargs)

        def _apply_middleware(
            self, middleware: FutureMiddleware
        ):
            raise NotImplementedError  # noqa


    obj = Obj()
    @obj.on_request()
    def test(*args, **kwargs):
        print(args, kwargs)

    assert len(obj._future_middleware) == 1
    assert callable(obj._future_middleware[0].middleware)

# Generated at 2022-06-24 04:13:32.182193
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass #TODO


# Generated at 2022-06-24 04:13:34.180106
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    app = MiddlewareMixin()
    assert app._future_middleware == []


# Generated at 2022-06-24 04:13:35.306581
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass



# Generated at 2022-06-24 04:13:35.927535
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert True

# Generated at 2022-06-24 04:13:41.404329
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic(__name__)
    for _ in range(5):
        app.middleware(lambda request, response: None,
                       attach_to="request")
        app.middleware(lambda request, response: None,
                       attach_to="response")
    assert app._future_middleware.__len__() == 10

# Generated at 2022-06-24 04:13:48.104573
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    app = Sanic("test_MiddlewareMixin")

    parameter_to_test = 1
    test_result = 0
    
    @app.on_request
    async def handler(request):
        nonlocal parameter_to_test
        nonlocal test_result
        test_result = parameter_to_test

    assert (test_result == 0)
    parameter_to_test = 2
    assert (test_result == 0)


# Generated at 2022-06-24 04:13:55.315829
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic("test_MiddlewareMixin_on_response")
    assert app.middleware == MiddlewareMixin.middleware
    assert app.on_request == MiddlewareMixin.on_request
    assert app.on_response == MiddlewareMixin.on_response
    response_calls = set()
    request_calls = set()
    called_middlewares = set()

    @app.middleware
    def record_request_middleware(request):
        request_calls.add(1)

    @app.middleware("request")
    def record_request_middleware_with_attach(request):
        request_calls.add(2)

    @app.on_request
    def record_request_partial_middleware(request):
        request_calls

# Generated at 2022-06-24 04:13:59.074248
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    app = Sanic("test_MiddlewareMixin")
    assert "MiddlewareMixin" in str(MiddlewareMixin)
    assert isinstance(app, MiddlewareMixin)



# Generated at 2022-06-24 04:14:00.509241
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    test = MiddlewareMixin()
    assert test._future_middleware == []


# Generated at 2022-06-24 04:14:01.836683
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    obj = MiddlewareMixin()
    obj.on_response()
    assert sys.exc_info() == None


# Generated at 2022-06-24 04:14:12.767065
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware

    app1 = Sanic(__name__)
    app1.middleware('request',  lambda *args, **kwargs: None)
    app1.middleware('request',  lambda *args, **kwargs: None)
    app1.middleware('response', lambda *args, **kwargs: None)
    app1.middleware('response', lambda *args, **kwargs: None)

    assert len(app1._future_middleware) == 4
    assert isinstance(app1._future_middleware[0], FutureMiddleware)
    assert isinstance(app1._future_middleware[1], FutureMiddleware)
    assert isinstance(app1._future_middleware[2], FutureMiddleware)

# Generated at 2022-06-24 04:14:15.557578
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class _MiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

# Generated at 2022-06-24 04:14:23.842481
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.middleware import MiddlewareMixin
    from functools import partial
    from typing import List
    from sanic.models.futures import FutureMiddleware

    mm = MiddlewareMixin()
    mm.middleware = partial(mm.middleware, apply=False)
    mm.middleware(on_request_middleware, "request")
    assert len(mm._future_middleware) == 1
    assert mm._future_middleware[0].middleware == on_request_middleware
    assert mm._future_middleware[0].attach_to == "request"
    del mm

    mm = MiddlewareMixin()
    mm.middleware = partial(mm.middleware, apply=False)
    mm.middleware(on_response_middleware, "response")

# Generated at 2022-06-24 04:14:26.970695
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # arrange
    mixin = MiddlewareMixin()
    # action
    middleware = mixin.on_request()
    # assert
    assert middleware('request') is not None

# Generated at 2022-06-24 04:14:28.748557
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # TODO
    pass


# Generated at 2022-06-24 04:14:38.390460
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.consts import REQUEST_MIDDLEWARES
    assert hasattr(MiddlewareMixin, "_future_middleware")
    assert hasattr(MiddlewareMixin, "_apply_middleware")
    assert hasattr(MiddlewareMixin, "middleware")
    assert hasattr(MiddlewareMixin, "on_request")
    assert hasattr(MiddlewareMixin, "on_response")
    app = Sanic()
    assert app._future_middleware == []
    assert app.middleware(None)
    mf = app._future_middleware[-1]
    assert isinstance(mf, FutureMiddleware)
    assert mf == FutureMiddleware(None, REQUEST_MIDDLEWARES)
    assert mf.middleware == None

# Generated at 2022-06-24 04:14:47.183091
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Example(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            self._future_middleware: List[FutureMiddleware] = []
            self.middleware(partial(self.middleware, attach_to="request"), apply=True)
        def _apply_middleware(self, future_middleware: FutureMiddleware):
            self._future_middleware.append(future_middleware)
    
    class Example2(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            self._future_middleware: List[FutureMiddleware] = []
            self.middleware(partial(self.middleware, attach_to="request"), apply=True)
        def _apply_middleware(self, future_middleware: FutureMiddleware):
            self._future_middle

# Generated at 2022-06-24 04:14:47.745180
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert None == None

# Generated at 2022-06-24 04:14:58.801135
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app=MiddlewareMixin

    # If a middleware is passed to this decorator, it is wrapped in an instance of
    # class FutureMiddleware and registered as a "request" middleware
    @app.on_request(middleware=False)
    def middleware_func(request):
        return True
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == middleware_func
    assert app._future_middleware[0].attach_to == "request"

    # If no middleware is passed to this decorator, a partial function is returned
    # that binds "request" to the attach_to argument of method middleware of class MiddlewareMixin
    app._future_middleware = []
    @app.on_request()
    def middleware_func(request):
        return

# Generated at 2022-06-24 04:15:03.250301
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # arrange
    class Application(MiddlewareMixin):
        def __init__(self):
            pass

    # act
    app = Application()

    # assert
    assert not hasattr(app, '_future_middleware')
    assert not hasattr(app, '_apply_middleware')
    assert app._future_middleware == []

# Generated at 2022-06-24 04:15:11.500765
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class App(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            return middleware

    def test_middleware(request):
        return 'hi'
    app = App()
    assert app.on_request() == partial(app.middleware, attach_to="request")
    app.on_request(test_middleware)
    assert app._future_middleware[0] == FutureMiddleware(test_middleware, "request")
    assert app._future_middleware[0]._attach_to == "request"
    assert app._future_middleware[0]._future == test_middleware


# Generated at 2022-06-24 04:15:20.946937
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    m = TestMiddlewareMixin()

    # Should return a partial of middleware with
    # attach_to='response'
    @m.on_response
    def test_on_response_func():
        pass
    assert test_on_response_func.middleware_name == 'response'

    # Should call partial of middleware with
    # attach_to='response'
    @m.on_response()
    def test_on_response_func2():
        pass
    assert test_on_response_func2.middleware_name == 'response'

# Generated at 2022-06-24 04:15:29.314344
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic()

    @app.on_response
    def response_mw1(request, response):
        pass

    @app.on_response
    def response_mw2(request, response):
        pass

    mw1 = app._future_middleware[0]
    assert mw1.middleware is response_mw1
    assert mw1.attach_to == 'response'

    mw2 = app._future_middleware[1]
    assert mw2.middleware is response_mw2
    assert mw2.attach_to == 'response'


# Generated at 2022-06-24 04:15:31.912533
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic

    app = Sanic("test_MiddlewareMixin")

    # verify
    for middleware in app._future_middleware:
        assert len(middleware) == 0

# Generated at 2022-06-24 04:15:39.325369
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.models import FutureMiddleware

    class FakeMiddlewareMixin(MiddlewareMixin):
        pass

    app = Sanic("sanic-server")
    fake_middleware_mixin = FakeMiddlewareMixin()

    # Here, app.middleware returns partial
    middleware_closure = app.middleware("response")
    assert middleware_closure.func.__name__ == "middleware"
    assert middleware_closure.keywords["attach_to"] == "response"

    # Here, app.middleware returns the decorated function
    @app.middleware("response")
    def foo():
        pass

    assert foo.__name__ == "foo"
    assert app._future_middleware[0].middleware == foo
    assert app._future_middleware[0].attach_to

# Generated at 2022-06-24 04:15:50.067402
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import unittest

    from sanic.models.futures import FutureMiddleware

    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    class TestCase(unittest.TestCase):
        def test_MiddlewareMixin_middleware(self):
            a = TestMiddlewareMixin()
            a.middleware(None)
            a.on_request(None)
            a.on_response(None)
            pass

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-24 04:15:57.383197
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import App
    from sanic import response

    def check_response(req, res):
        assert isinstance(res, response.HTTPResponse)

    app = App(__name__)

    @app.route("/")
    async def test(request):
        return response.text("OK")

    @app.on_response
    def log_request(request, response):
        response.headers['Server'] = "Test"

    request, response = app.test_client.get("/")

    assert response.body == b"OK"
    assert response.headers['Server'] == "Test"

    app.on_response(check_response)

    request, response = app.test_client.get("/")

    assert response.body == b"OK"