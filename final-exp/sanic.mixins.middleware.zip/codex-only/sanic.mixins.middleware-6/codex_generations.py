

# Generated at 2022-06-24 04:05:56.023826
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass


# Generated at 2022-06-24 04:06:03.923866
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test')
    class SubSanic(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(SubSanic, self).__init__(*args, **kwargs)
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    Sub_app = SubSanic(app, 's', '')
    @Sub_app.on_request
    def on_request(request):
        return True
    assert Sub_app._future_middleware[0].middleware == on_request


# Generated at 2022-06-24 04:06:09.490886
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert isinstance(m._future_middleware, list)


# Generated at 2022-06-24 04:06:12.175433
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    app = MySanic()
    assert app.middleware(middleware, attach_to='response') == middleware
    assert app.on_response(middleware) == middleware

# Generated at 2022-06-24 04:06:14.114735
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    test_middleware_mixin = MiddlewareMixin()
    assert test_middleware_mixin._future_middleware == []



# Generated at 2022-06-24 04:06:18.898169
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    import sys
    import types

    def middleware(request):
        pass

    def test():
        app = Sanic("test_MiddlewareMixin_middleware")
        app.middleware(middleware)
        return len(app._future_middleware) > 0 and sys.getrefcount(app._future_middleware[0].middleware) == 2
    
    assert test() == True



# Generated at 2022-06-24 04:06:28.293903
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    import time
    import pytest

    app = Sanic("sanic-app")
    app.config.MIDDLEWARE = []

    # Initialise MiddlewareMixin.
    MiddlewareMixin.__init__(app)

    # Define middleware function.
    @app.on_request
    async def request_middleware(request):
        # sleep to ensure that all requests are processed in the correct order
        time.sleep(0.001)

        return (await Sanic.handle_request(app, request))[:-1]

    # Define request handler.
    @app.route("/")
    async def handler(request):
        return sanic.response.text("OK")

    # Send request and get response.
    request, response = app.test_client.get

# Generated at 2022-06-24 04:06:29.266522
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin()

# Generated at 2022-06-24 04:06:34.354614
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Server(MiddlewareMixin):
        pass
    server = Server()

    # attach_to = 'request'
    @server.middleware('request')
    def process_request(request):
        pass


    # attach_to = 'response'
    @server.middleware('response')
    def process_response(request, response):
        pass

    assert server._future_middleware is not None
    assert len(server._future_middleware) == 2
    assert (server._future_middleware[0].attach_to == 'request')
    assert (server._future_middleware[1].attach_to == 'response')



# Generated at 2022-06-24 04:06:45.477948
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestedClass(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    instance = TestedClass()

    assert callable(instance.on_request())
    assert callable(instance.on_request("req"))

    @instance.on_request()
    def test_func1():
        pass

    @instance.on_request("req")
    def test_func2():
        pass

    assert len(instance._future_middleware) == 2
    assert instance._future_middleware[0].middleware == test_func1
    assert instance._future_middleware[0].attach_to == "request"
    assert instance._future_middleware[1].middleware == test_func2
    assert instance._future_middleware[1].attach_to == "req"



# Generated at 2022-06-24 04:06:46.471301
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Not needed for this project
    pass

# Generated at 2022-06-24 04:06:50.691103
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestClass(MiddlewareMixin):
        def __init__(self):
            super().__init__()
        def _apply_middleware(self, middleware):
            pass
    test_class = TestClass()
    @test_class.on_response
    async def test_func(request):
        pass
    assert test_class._future_middleware[0].middleware == test_func
    assert test_class._future_middleware[0].attach_to == 'response'

# Generated at 2022-06-24 04:06:56.649475
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.router import RouteExistsError
    from sanic.views import HTTPMethodView
    from sanic.response import json
    instance = Sanic('test_sanic')

    class HTV(HTTPMethodView):
        def get(self, request):
            return json({"args": request.args})

    class HTV_DAN_JIE(HTTPMethodView):
        def get(self):
            return json({"got": "it"})

    class BB(Blueprint):
        def register(self, app, options):
            pass

    bp = BB('test_register_blueprint', url_prefix='/blueprint')

# Generated at 2022-06-24 04:07:00.794602
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import json
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.middleware
    async def handler(request):
        return request
    @app.route('/')
    async def handler2(request):
        return json({'test': 'OK'})
    request, response = app.test_client.get('/')
    assert response.status == 200

# Generated at 2022-06-24 04:07:02.152564
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert(False)


# Generated at 2022-06-24 04:07:09.724328
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddleware:
        def __init__(self, app, attach_to):
            pass
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass
    _ = TestMiddlewareMixin()
    _.middleware(TestMiddleware, attach_to="test")
    assert len(_._future_middleware) == 1
    _.middleware(TestMiddleware, attach_to="test2", apply=True)
    assert len(_._future_middleware) == 2



# Generated at 2022-06-24 04:07:11.768792
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class A(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    assert A()._future_middleware == []



# Generated at 2022-06-24 04:07:19.089695
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class A(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    a = A()
    assert a.on_request(middleware=None) == partial(a.middleware, attach_to="request")
    assert a.on_request(middleware=lambda x: x) == a.middleware('request')



# Generated at 2022-06-24 04:07:28.298834
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from unittest import TestCase
    from unittest.mock import Mock

    from sanic import Sanic
    from sanic.models import FutureMiddleware

    class TestApp(MiddlewareMixin, Sanic):
        pass

    app = TestApp(name='TestApp')
    m1 = Mock()
    m2 = Mock()
    m3 = Mock()
    m4 = Mock()
    m1.return_value = 'return value'
    m3.return_value = 'return value'
    m4.return_value = 'return value'

    app.on_request(m1)
    app.middleware(m2, 'request')
    app.on_response(m3)
    app.middleware(m4, 'response')

    assert len(app._future_middleware) == 4

    #

# Generated at 2022-06-24 04:07:37.191131
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import sys
    sys.path.append('../')
    from sanic import Sanic
    from sanic.response import text

    app = Sanic('test_on_response_app')

    @app.middleware('request')
    async def before_request(request):
        pass

    @app.middleware('response')
    async def after_response(request, response):
        pass

    @app.middleware()
    async def before_request_after_response(request, response):
        pass

    @app.route('/')
    def handler(request):
        return text('OK')

    _, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-24 04:07:39.489940
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():

    # TODO: fix this test.
    pass

# Generated at 2022-06-24 04:07:44.313580
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        pass

    tmm = TestMiddlewareMixin()
    print(tmm._future_middleware)
    assert tmm._future_middleware == []

# Test method middleware on class MiddlewareMixin

# Generated at 2022-06-24 04:07:49.865814
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    async def middleware_test_request(request):
        return request
    async def middleware_test_response(request, response):
        return response
    @middleware_mixin_test.on_request
    @middleware_mixin_test.on_response
    def middleware_test():
        pass
    middleware_mixin_test = MiddlewareMixin()
    assert middleware_mixin_test.middleware("request") == middleware_test_request
    assert middleware_mixin_test.middleware("response") == middleware_test_response


# Generated at 2022-06-24 04:07:54.453196
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic(__name__)

    @app.on_response
    def foo(request, response):
        return response

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == foo
    assert app._future_middleware[0].attach_to == "response"



# Generated at 2022-06-24 04:07:59.712564
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # initialize object of class MiddlewareMixin
    middlewareMixin = MiddlewareMixin()
    assert middlewareMixin._future_middleware == []


# Generated at 2022-06-24 04:08:01.072167
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # New client
    client = MiddlewareMixin()
    assert client._future_middleware == []


# Generated at 2022-06-24 04:08:02.188807
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    MiddlewareMixin()

# Generated at 2022-06-24 04:08:03.927760
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    a = MiddlewareMixin()
    assert type(a._future_middleware) == list
    assert a._future_middleware == []

test_MiddlewareMixin()

# Generated at 2022-06-24 04:08:06.256847
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin = MiddlewareMixin()
    assert mixin._future_middleware == []

# Generated at 2022-06-24 04:08:12.638463
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class App(MiddlewareMixin):
        _future_middleware = []

        def _apply_middleware(self, middleware):
            self._future_middleware.append(middleware)

    app = App()

    assert not app._future_middleware

    @app.on_response()
    def middleware():
        pass

    assert app._future_middleware
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-24 04:08:19.082158
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class _TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware = middleware.middleware

    # check if the decorator add middleware to the list
    test_middleware_mixin = _TestMiddlewareMixin()

    def request_middleware_example(request):
        return request

    test_middleware_mixin.on_request(request_middleware_example)
    assert (
        test_middleware_mixin.middleware
        == request_middleware_example.__name__
    )

# Generated at 2022-06-24 04:08:25.587325
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic_restplus import Sanic
    from sanic.response import text
    app = Sanic(__name__)

    @app.on_response
    async def print_on_response(request, response):
        """Middleware printed on response.
        """
        print("Request response middleware.")

    @app.route('/')
    def handler(request):
        await print_on_response(request, text("I am a teapot", 418))
        return text("Hello, world!")



# Generated at 2022-06-24 04:08:36.248180
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware

    app = Sanic()

    app.middleware('request')(request_middleware)

    request_middleware_future_middleware = app._future_middleware

    assert isinstance(request_middleware_future_middleware[0], FutureMiddleware)
    assert request_middleware_future_middleware[0].middleware == request_middleware
    assert request_middleware_future_middleware[0].attach_to == 'request'

    app.middleware(response_middleware)

    response_middleware_future_middleware = app._future_middleware

    assert isinstance(response_middleware_future_middleware[1], FutureMiddleware)
    assert response_middleware_future_middleware[1].middleware == response

# Generated at 2022-06-24 04:08:45.510889
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from ..middlewares import RequestMiddleware
    from ..models import HttpRequest
    from ..commands import RequestCommand
    from ..config import Config
    from ..errors import ServerError
    from .server import Server
    from .server_channel import ServerChannel
    from .channel import Channel
    from .router import Router
    from .app import Sanic
    from .blueprint import Blueprint
    from .exceptions import SanicException

    test_config = Config()
    test_config.REQUEST_MAX_SIZE = 10240
    test_config.REQUEST_MAX_MEMORY_SIZE = 10240
    test_config.KEEP_ALIVE = True
    test_config.KEEP_ALIVE_TIMEOUT = 5
    test_config.RESPONSE_TIMEOUT = 60

    test_channel = ServerChannel()
    test

# Generated at 2022-06-24 04:08:47.303566
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    app = MiddlewareMixin()
    assert isinstance(app, MiddlewareMixin) is True


# Generated at 2022-06-24 04:08:56.062830
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Test: @middleware('request')
    @MiddlewareMixin.on_request('request')
    def test_middleware():
        pass
    assert isinstance(test_middleware, partial)
    
    # Test: @middleware
    @MiddlewareMixin.on_request
    def test_middleware1():
        pass
    assert isinstance(test_middleware1, partial)

    # Test: @middleware()
    @MiddlewareMixin.on_request()
    def test_middleware2():
        pass
    assert isinstance(test_middleware2, partial)


# Generated at 2022-06-24 04:09:07.257682
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import pytest

    from sanic.models import MiddlewareMixin

    from sanic.models.futures.abstract import FutureMiddleware

    class X(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    x = X()
    assert x._future_middleware == []
    x.middleware(lambda y: y)
    assert len(x._future_middleware) == 1
    assert x._future_middleware[0].attach_to == 'request'
    assert x._future_middleware[0].middleware(500) == 500

    with pytest.raises(TypeError):
        x.middle

# Generated at 2022-06-24 04:09:10.046175
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # init MiddlewareMixin
    middleware_mixin = MiddlewareMixin()
    # middleware is None and attach_to is 'request'
    assert middleware_mixin.on_request()('request') == 'request'

# Generated at 2022-06-24 04:09:13.738777
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test:
        def __init__(self):
            self._future_middleware = []

    test = Test()

    @test.middleware
    def request_test():
        pass

    @test.middleware('response')
    def response_test():
        pass

# Generated at 2022-06-24 04:09:15.301774
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin().on_response()


# Generated at 2022-06-24 04:09:21.204413
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()._future_middleware == []
    assert MiddlewareMixin(True, False)._future_middleware == []
    assert MiddlewareMixin(False, True)._future_middleware == []
    assert MiddlewareMixin(False, False)._future_middleware == []

#  Unit test for function middleware of class MiddlewareMixin

# Generated at 2022-06-24 04:09:27.714492
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_on_response')

    def handler(request):
        return text("OK")

    @app.middleware('request')
    async def request(request):
        assert request['type'] == 'request'

    @app.middleware('response')
    async def response(request, response):
        assert request['type'] == 'response'

    app.add_route(handler, '/')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'


# Generated at 2022-06-24 04:09:39.296456
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # [Step 1]
    class TestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._middleware = {}

        def _apply_middleware(self, middleware: FutureMiddleware):
            self._middleware[middleware.attach_to] = middleware

    # [Step 2]
    def middleware(request):
        pass

    test_class = TestClass()
    decorated = test_class.on_request(middleware)
    assert decorated == middleware
    assert len(test_class._future_middleware) == 1
    assert len(test_class._middleware) == 1
    assert (
        test_class._future_middleware[0].attach_to == "request"
    )

# Generated at 2022-06-24 04:09:40.762161
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
  pass

# Generated at 2022-06-24 04:09:47.027862
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Given
    from sanic.app import Sanic

    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = Sanic(__name__)
    app.config.access_log = False

    # When
    @app.on_request()
    def test(request):
        pass

    # Then
    assert "test" in request.middlewares

# Generated at 2022-06-24 04:09:57.623743
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    middleware_mixin_ins = MiddlewareMixin()
    # middleware = None
    try:
        # print(middleware_mixin_ins.on_response())
        # return a function
        middleware_mixin_ins.on_response()
    except Exception as e:
        print(e)
        # print('exception occurred')
        assert False
    else:
        assert True
    # middleware = use on_request which is a function
    try:
        middleware_mixin_ins.on_response(middleware_mixin_ins.on_request)
    except Exception as e:
        print(e)
        # print('exception occurred')
        assert False
    else:
        assert True


# Generated at 2022-06-24 04:10:01.515214
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
	app = Application()
	@app.on_response()
	def middleware(response):
		return response
	assert not app._future_middleware == []


# Generated at 2022-06-24 04:10:08.794709
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Given
    class MockMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    mock_middleware1 = lambda x: x
    mock_middleware2 = lambda x: x

    mixin = MockMiddlewareMixin()

    # When
    middleware1 = mixin.middleware(mock_middleware1)
    middleware2 = mixin.on_response(mock_middleware2)

    # Then
    assert mixin._future_middleware[0].middleware == mock_middleware1
    assert mixin._future_middleware[0].attach_to == "request"

    assert mixin._future_middleware[1].middleware == mock_middleware2

# Generated at 2022-06-24 04:10:11.108415
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert isinstance(MiddlewareMixin()._future_middleware, list)


# Generated at 2022-06-24 04:10:15.217050
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    obj = MiddlewareMixin()
    assert obj._future_middleware == []
    assert raise_exception(obj._apply_middleware, FutureMiddleware)

# Unit tests for function middleware

# Generated at 2022-06-24 04:10:25.297551
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import sanic.config
    class Test(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            MiddlewareMixin.__init__(self, args, kwargs)
        def _apply_middleware(self, middleware):
            self._future_middleware.append(middleware)

    @Test().on_response()
    def fn_middleware(request, response):
        pass

    @Test().on_response
    def fn_middleware2(request, response):
        pass

    t = Test()
    t.on_response(fn_middleware)

    assert len(t._future_middleware) == 3
    assert len([x for x in t._future_middleware if x.attach_to == "response"]) == 3



# Generated at 2022-06-24 04:10:36.854424
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic(__name__)

    @app.middleware('request')
    async def test_request_middleware(request):
        return 'middleware'

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == 'middleware'
    assert app._future_middleware[0].attach_to == 'request'

    @app.middleware('response')
    async def test_response_middleware(request, response):
        return 'middleware'

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == 'middleware'
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-24 04:10:38.535007
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    a = MiddlewareMixin()
    assert a.on_response(a) == a.middleware(a, attach_to = 'response')

# Generated at 2022-06-24 04:10:42.444757
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Arrange
    from sanic.app import Sanic
    from sanic.response import HTTPResponse

    app = Sanic(__name__)

    # Act
    middleware_mixin = MiddlewareMixin()

    # Assert
    assert  isinstance(middleware_mixin, MiddlewareMixin)

# Generated at 2022-06-24 04:10:44.223006
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []


# Generated at 2022-06-24 04:10:50.586247
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.models.middleware import MiddlewareMixin
    from sanic.models.futures import FutureMiddleware
    # make sure the method on_response of class MiddlewareMixin is working fine
    app = Sanic()
    middleware_obj = MiddlewareMixin()
    middleware_obj.on_response(middleware=print)
    assert isinstance(middleware_obj._future_middleware[-1], FutureMiddleware)
    assert middleware_obj._future_middleware[-1]._attach_to == 'response'

# Generated at 2022-06-24 04:10:56.377849
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class MyClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    my_obj=MyClass()
    my_obj.on_response()
    my_obj.on_response("response")

# Generated at 2022-06-24 04:11:00.255089
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    def handler(request):
        pass

    @handler.register
    def _(handler):
        middleware_mixin = MiddlewareMixin()
        return middleware_mixin.on_request(handler)

    assert handler.middleware_handler


# Generated at 2022-06-24 04:11:05.192951
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic(__name__)

    @app.on_response
    def test_app(request, response):
        raise NotImplementedError  # noqa

    @app.route('/')
    async def test(request):
        pass

    request, response = app.test_client.get('/')
    assert response.status == 500




# Generated at 2022-06-24 04:11:08.926339
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestClass(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass

    test_class = TestClass()
    middleware = lambda req, res: res

    assert test_class._future_middleware == []
    assert test_class.middleware(middleware) == middleware



# Generated at 2022-06-24 04:11:14.346930
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    def middleware_test():
        pass

    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.middleware(middleware_test)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test = TestMiddlewareMixin()
    assert middleware_test in test._future_middleware[0].middleware
    assert test._future_middleware[0].attach_to == "request"

# Generated at 2022-06-24 04:11:15.656909
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    request = mock.Mock()
    response = MiddlewareMixin()
    response.middleware(request)

# Generated at 2022-06-24 04:11:22.445119
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    testMiddlewareMixin = TestMiddlewareMixin()
    middleware_or_request = lambda request: None
    attach_to = 'request'
    testMiddlewareMixin.middleware(middleware_or_request, attach_to)

# Generated at 2022-06-24 04:11:24.255630
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic

    app = Sanic()

    assert app._future_middleware == []

# Generated at 2022-06-24 04:11:29.947992
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class C:
        def func1(self):
            pass

        def func2(self):
            pass

    m = MiddlewareMixin()
    m.on_request(C.func1)
    m.on_request(C.func2)
    assert len(m._future_middleware) == 2
    assert m._future_middleware[0].function is C.func1
    assert m._future_middleware[1].function is C.func2


# Generated at 2022-06-24 04:11:39.692087
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    m = MiddlewareMixin()
    assert isinstance(m, MiddlewareMixin)
    assert len(m._future_middleware) == 0

    # Test for @app.middleware
    @m.middleware
    async def handler_middleware_fn1(request):
        pass

    assert len(m._future_middleware) == 1
    assert isinstance(m._future_middleware[0], FutureMiddleware)
    assert m._future_middleware[0].middleware == handler_middleware_fn1
    assert m._future_middleware[0].attach_to == "request"

    # Test for @app.middleware('response')
    @m.middleware('response')
    async def handler_middleware_fn2(request):
        pass


# Generated at 2022-06-24 04:11:50.450384
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.router import Router
    from sanic.response import HTTPResponse
    from sanic.log import logger
    from sanic.exceptions import NotFound
    from sanic.blueprints import Blueprint
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import HTTP_METHODS
    from sanic.helper import is_coroutine_function

    try:
        from .utils import create_test_ssl_context
    except ImportError:
        from . import utils
        create_test_ssl_context = utils.create_test_ssl_context

    def test_MiddlewareMixin_constructor():
        middleware_mixin = MiddlewareMixin()
        assert middleware_mix

# Generated at 2022-06-24 04:11:54.680696
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    test_MiddlewareMixin = MiddlewareMixin()
    @test_MiddlewareMixin.middleware
    def test_middleware():
        res = True
        return res
    test_MiddlewareMixin.middleware.apply = True
    assert test_MiddlewareMixin.middleware()


# Generated at 2022-06-24 04:11:55.512506
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()

# Generated at 2022-06-24 04:11:58.915276
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    #assert m._future_middleware == []
    #assert m._apply_middleware is None


# Generated at 2022-06-24 04:12:01.015514
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()._future_middleware == []

if __name__ == "__main__":
    test_MiddlewareMixin()

# Generated at 2022-06-24 04:12:04.529476
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic

    app = Sanic()

    # Constructor of class MiddlewareMixin
    MiddlewareMixin(app)


# Generated at 2022-06-24 04:12:08.601986
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    obj = MiddlewareMixin()
    obj.on_response(middleware=None)
    obj.on_response(middleware=lambda: print())


# Generated at 2022-06-24 04:12:12.882909
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin')

    @app.middleware('request')
    async def process_request(request):
        pass

    @app.middleware('response')
    async def process_response(request, response):
        pass

    assert app._future_middleware != []
    assert app._future_middleware.pop().middleware != None

# Generated at 2022-06-24 04:12:14.776165
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    obj = MiddlewareMixin()
    obj.on_response()

# Generated at 2022-06-24 04:12:16.442953
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()._future_middleware == []


# Generated at 2022-06-24 04:12:21.385663
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    def middleware_test(request, response):
        print("Middleware works")
        return response

    mixin = MiddlewareMixin
    
    mw = mixin.on_response(mixin, middleware=middleware_test)(mixin)

    res = mw.run_response

    assert res == middleware_test

# Generated at 2022-06-24 04:12:31.053730
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Server(MiddlewareMixin):
        on_request = MiddlewareMixin.on_request
        on_response = MiddlewareMixin.on_response

    # Instantiate an instance of Server
    server = Server()
  
    # Register a middleware
    @server.on_response
    def response_handler(request, response):
        return response

    # Check the correctness of on_response
    assert len(server._future_middleware) == 1
    assert server._future_middleware[0].attach_to == "response"
    assert server._future_middleware[0].middleware == response_handler



if __name__ == '__main__':
    test_MiddlewareMixin_on_response()

# Generated at 2022-06-24 04:12:40.624735
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic()

    @app.middleware
    def first_middleware():
        print("first_middleware")

    @app.middleware('request')
    def second_middleware(request):
        print("second_middleware")

    @app.middleware('response')
    def third_middleware(request, response):
        print("third_middleware")

    @app.route('/')
    def handler(request):
        return text('OK')

    _, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-24 04:12:45.006449
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    HTTP_EXCEPTIONS = ()
    class App:
        middleware = MiddlewareMixin()
        def _apply_middleware(self, middleware):
            self._future_middleware.append(middleware)
    app = App()
    @app.middleware
    def test_middleware(request):
        return 'fuck'
    assert test_middleware in app._future_middleware


# Generated at 2022-06-24 04:12:46.021171
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-24 04:12:54.301050
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.models.futures import FutureMiddleware

    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, future_middleware: FutureMiddleware):
            pass

    app = TestMiddlewareMixin()

    @app.middleware
    def test_middleware(request: Request):
        return HTTPResponse(text='Hi')

    assert len(app._future_middleware) == 1
    assert callable(app._future_middleware[0].middleware)

# Generated at 2022-06-24 04:12:59.159753
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    app = Sanic('test')
    assert app.middleware_name == 'middleware'
    test_inst = MiddlewareMixin()
    assert test_inst._future_middleware == []


# Generated at 2022-06-24 04:13:06.694689
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    @asyncio.coroutine
    def run_client(uri):
        pass

    app = Sanic("test_Sanic_on_response")
    test_middleware = app.on_response(lambda req, res: print("test!!!"))
    assert test_middleware in app._future_middleware
    assert app._future_middleware[0]._attach_to == "response"
    assert app._future_middleware[0]._future.set_result


# Generated at 2022-06-24 04:13:14.751019
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from .log import LOGGING_CONFIGURATION
    from .middleware import InjectorData
    from .request import Request
    from .response import HTTPResponse, text
    from .routing import RouteExpectation, RoutingMiddleware
    from .utils import SanicConfig, import_from_string
    from .websocket import WebSocketProtocol

    SanicConfig.from_env(LOGGING_CONFIGURATION)
    Request._injector = InjectorData(
    )

    class TestClass:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass


# Generated at 2022-06-24 04:13:20.922548
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # create app
    app = Sanic(__name__)
    ctx = app.create_server_context(None, None, None, None)

    class TestMid(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

        def test_function(self):
            pass

    t = TestMid()
    # create middleware
    def mid_req(request):
        pass
    def mid_res(request, response):
        pass

    # test no attach to param
    t.middleware(mid_req)  # noqa
    assert len(t._future_middleware) == 1
    assert isinstance(t._future_middleware[0], FutureMiddleware)
    assert t._future_middleware[0].middleware == mid_req
    assert t._future

# Generated at 2022-06-24 04:13:30.211053
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.protocols.http import HttpProtocol

    proto = HttpProtocol()
    assert len(proto._future_middleware) == 0

    @proto.middleware
    async def test_middleware_1(request):
        print("\n"*3)
        print("test_middleware_1 called.")
        print(request)

    @proto.middleware('request')
    async def test_middleware_2(request):
        print("test_middleware_2 called.")
        print(request)
        print("\n"*3)

    @proto.middleware('response')
    async def test_middleware_3(request, response):
        print("test_middleware_3 called.")
        print(request)
        print(response)

# Generated at 2022-06-24 04:13:32.664024
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    app = Sanic()
    assert isinstance(app, MiddlewareMixin)
    assert app._future_middleware == []


# Generated at 2022-06-24 04:13:35.072291
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    on_request_middleware_test = MiddlewareMixin()
    on_request_middleware_test.on_request(middleware='request')

# Generated at 2022-06-24 04:13:37.168797
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware = MiddlewareMixin()
    assert middleware._future_middleware == []


# Generated at 2022-06-24 04:13:48.000718
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.middleware import CORSMiddleware
    from sanic_cors import CORSMiddleware as MyCORSMiddleware
    from sanic_cors.middleware import decorator_factory
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_on_request')
    app.config.CORS_AUTOMATIC_OPTIONS = True
    app.config.CORS_AUTOMATIC_OPTIONS = True
    app.config.CORS_SUPPORTS_CREDENTIALS = True
    app.config.CORS_RESOURCES = {r"/v1/*": {"origins": "*"}}
    cors = MyCORSMiddleware()

    app.on_request(cors)

# Generated at 2022-06-24 04:13:48.629259
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    ...

# Generated at 2022-06-24 04:13:54.549173
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Sanic:
        def __init__(self):
            self._future_middleware = []
        def _apply_middleware(middleware):
            self._future_middleware.append(middleware)
    app = Sanic()
    app.process_request = lambda: None
    # regiter a middleware
    app.on_request(app.process_request)
    assert len(app._future_middleware) == 1

# Generated at 2022-06-24 04:13:57.922880
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    test_MiddlewareMixin = MiddlewareMixin();
    result = test_MiddlewareMixin.on_request();


# Generated at 2022-06-24 04:13:59.596283
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin = MiddlewareMixin()
    assert mixin._future_middleware == []


# Generated at 2022-06-24 04:14:01.041329
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    my_app = MiddlewareMixin()
    middleware = my_app.on_request()
    assert middleware != None


# Generated at 2022-06-24 04:14:09.013631
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()
    assert app._future_middleware == []
    @app.middleware
    def second(request):
        """second"""
        return request

    assert app._future_middleware[0].middleware == second
    assert app._future_middleware[0].attach_to == "request"
    @app.middleware("response")
    def third(request):
        """third"""
        return request
    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == third
    assert app._future_middleware[1].attach_to == "response"
    @app.middleware("request")
    def first(request):
        """first"""
        return request
    assert len(app._future_middleware) == 3


# Generated at 2022-06-24 04:14:18.979972
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    class MiddlewareMixinTest(MiddlewareMixin): 

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            return middleware

    class MyTest(MiddlewareMixinTest):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    @MyTest.on_request
    async def middleware_request(request):
        return request

    @MyTest.on_response
    async def middleware_response(request, response):
        return response

    m = MyTest()
    assert middleware_request in m._future_middleware
    assert middleware_response in m._future_middleware

# Generated at 2022-06-24 04:14:27.759195
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class _TestClass(MiddlewareMixin):
        def __init__(self):
            super(MiddlewareMixin, self).__init__()

        def _apply_middleware(self, middleware):
            self.middleware = middleware
            self.middleware_type = 'response'

    test_class = _TestClass()
    @test_class.on_response(middleware=lambda request, response: response)
    def on_response_test():
        pass
    assert test_class.middleware == on_response_test
    assert test_class.middleware_type == 'response'


# Generated at 2022-06-24 04:14:31.026653
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin1 = MiddlewareMixin()
    assert(mixin1._future_middleware == [])
    assert(mixin1._apply_middleware == NotImplemented)


# Generated at 2022-06-24 04:14:38.497023
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.models.futures import Future

    class TestClass(MiddlewareMixin):
        pass

    class TestClass2(MiddlewareMixin):
        pass


    @TestClass.on_response()
    async def test_1(request):
        pass

    @TestClass.on_response()
    async def test_2(request):
        pass

    @TestClass2.on_response()
    async def test_3(request):
        pass

    assert test_1 == TestClass._future_middleware[0].future
    assert test_2 == TestClass._future_middleware[1].future
    assert test_3 == TestClass2._future_middleware[0].future


# Generated at 2022-06-24 04:14:39.800174
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert isinstance(MiddlewareMixin(), MiddlewareMixin)

# Generated at 2022-06-24 04:14:48.306117
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.middleware import BaseHTTPMiddleware
    from sanic.exceptions import SanicException

    app = Sanic('test_MiddlewareMixin')

    class CustomHTTPMiddleware(BaseHTTPMiddleware):
        def process_request(self, request):
            raise SanicException('something bad happens')

        @BaseHTTPMiddleware.request
        async def process_response(self, request, response):
            raise SanicException('something good happens')

    # CustomHTTPMiddleware is not registered yet.
    # When registering it, it will be applied as middleware.
    # By default, it will be registered as request middleware and response middleware
    app.middleware(CustomHTTPMiddleware)

    # Filter out the registered middleware
    registered_middleware

# Generated at 2022-06-24 04:14:49.353731
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass


# Generated at 2022-06-24 04:15:00.346039
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import sanic.app


    class MyAppliction(sanic.app.Sanic, MiddlewareMixin):
        pass


    class MyMiddleWare(object):

        def __init__(self, request):
            self.request = request

        async def __call__(self, request):
            return True


    app = MyAppliction()
    app.middleware(MyMiddleWare)

    assert isinstance(app._future_middleware[0].middleware, MyMiddleWare)
    assert app._future_middleware[0].attach_to == "request"

    # If the attach_to is not specified, it equals to request
    app.middleware(MyMiddleWare)

    assert isinstance(app._future_middleware[1].middleware, MyMiddleWare)
    assert app._future_middleware[1].attach_to

# Generated at 2022-06-24 04:15:02.216095
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic()

    @app.on_request
    async def on_request(request):
        return request
        
    assert True

# Generated at 2022-06-24 04:15:07.757739
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from unittest.mock import Mock as MockResponseObject
    from sanic.app import Sanic as SanicApp
    app = SanicApp()

    res = app.on_response(lambda request, response: response)
    assert hasattr(res, "__call__")
    res(MockResponseObject(), MockResponseObject())



# Generated at 2022-06-24 04:15:18.224765
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Test:
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []
            self._apply_middleware_called = False
            self.middleware_arg = None
            self.attach_to_arg = None
            self.middleware_or_request_arg = None
            self.middleware_arg_in_register_middleware = None
            self.attach_to_arg_in_register_middleware = None

        def _apply_middleware(self, middleware: FutureMiddleware):
            self._apply_middleware_called = True
            assert middleware is self.middleware_arg  # noqa


# Generated at 2022-06-24 04:15:28.849352
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    # sanic has not changed middleware
    assert len(app._future_middleware) == 0
    assert app._middleware == []

    # do not use apply middleware
    @app.middleware
    def middleware(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._middleware == []

    # do not use apply middleware
    @app.middleware('response')
    def middleware(request):
        pass
    assert len(app._future_middleware) == 2
    assert app._middleware == []

    # use apply middleware
    @app.middleware(apply=True)
    def middleware(request):
        pass

# Generated at 2022-06-24 04:15:30.159621
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []

# Generated at 2022-06-24 04:15:36.923753
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic(name=__name__)

    @app.middleware
    def example_middleware(request):
        return None

    assert app._future_middleware

    # Just check if this raises
    app.middleware('request')(None)
    app.middleware('response')(None)

    # check on_... methods
    app.on_request(None)
    app.on_response(None)

# Generated at 2022-06-24 04:15:42.329926
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class A:
        def __init__(self):
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    a = A()
    result = a.on_request()
    assert(callable(result) and result == a.middleware)

# Generated at 2022-06-24 04:15:51.753197
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
  # Login
  username = 'admin'
  password = 'admin'
  login_url = 'http://127.1:80/login'
  data = {
    'username' : username,
    'password' : password
  }
  r = requests.post(login_url, data=data)

  # Obtain the CSRF token first
  url = 'http://127.1:80/create_user'
  client = requests.session()
  # Retrieve the CSRF token first
  client.get(url)  # sets cookie
  if 'csrftoken' in client.cookies:
    csrftoken = client.cookies['csrftoken']
  else:
    # CSRF protection not enabled:
    csrftoken = 'NOTPROVIDED'
    # Fallback for tokens that are not set

# Generated at 2022-06-24 04:15:55.473839
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    from .test_blueprint import test_Blueprint_middleware
    import sys
    obj = Test()
    test_Blueprint_middleware(obj, sys.modules[__name__])