

# Generated at 2022-06-24 04:06:06.070790
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import pytest
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.models.futures import FutureMiddleware

    # Arrange test data
    app_ = Sanic("Sanic")
    class Middleware1:
        def __init__(self):
            pass
        async def __call__(request, handler):
            print("this is middleware 1")

    class Middleware2:
        def __init__(self):
            pass
        async def __call__(request, handler):
            print("this is middleware 2")

    test_middleware1 = Middleware1()
    test_middleware2 = Middleware2()

    # Act
    app_.middleware(test_middleware1, "request")
    app_.middleware

# Generated at 2022-06-24 04:06:06.836324
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    pass

# Generated at 2022-06-24 04:06:08.660133
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    obj_MiddlewareMixin = MiddlewareMixin()
    a = obj_MiddlewareMixin.on_response()
    a()


# Generated at 2022-06-24 04:06:17.329882
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, middleware):
            pass

    mmixin = TestMiddlewareMixin()

    @mmixin.on_request
    async def testMiddleware(request):
        pass
    assert len(mmixin._future_middleware) == 1

    @mmixin.on_request()
    async def testMiddleware():
        pass
    assert len(mmixin._future_middleware) == 2

    @mmixin.on_request('abc')
    async def testMiddleware():
        pass
    assert len(mmixin._future_middleware) == 3


# Generated at 2022-06-24 04:06:27.966692
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('')

    # Correct call
    @app.on_response # noqa
    def response_middleware(request, response):
        response.headers['Server'] = 'Awesome-Server'

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.headers.get('Server') == 'Awesome-Server'

    # Incorrect call
    @app.on_response('something') # noqa
    def response_middleware(request, response):
        response.headers['Server'] = 'Awesome-Server'

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.headers.get('Server') == 'Awesome-Server'



# Generated at 2022-06-24 04:06:32.000299
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic('test')

    async def sample_middleware(request):
        print ("middleware")
        response = await app.handle_request(request)
        return response

    app.on_request(sample_middleware)

    assert len(app._future_middleware) == 1


# Generated at 2022-06-24 04:06:35.570044
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class M(MiddlewareMixin):
        def middleware(self, middl, attr):
            pass

    m = M()
    assert m.on_request("middleware")("middleware") == "middleware"


# Generated at 2022-06-24 04:06:41.241982
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import sanic.server  # noqa

    @sanic.server.MiddlewareMixin.middleware('response')
    async def test_middleware(request, response):
        return response

    assert (sanic.server.MiddlewareMixin.middleware is not None)



# Generated at 2022-06-24 04:06:43.550297
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert [] == middleware_mixin._future_middleware



# Generated at 2022-06-24 04:06:49.715402
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()
        
        def _apply_middleware(self, middleware):
            pass
    
    t = TestMiddlewareMixin()
    assert isinstance(t, TestMiddlewareMixin)
    assert isinstance(t, MiddlewareMixin)
    assert hasattr(t, '_future_middleware')
    assert t._future_middleware == []


# Generated at 2022-06-24 04:06:54.574702
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic

    app = Sanic('test_MiddlewareMixin_on_response')

    @app.middleware
    def test_middleware_1(request):
        pass

    @app.on_response
    def test_middleware_2(request, response):
        pass

    assert app._future_middleware[0] == FutureMiddleware(test_middleware_1, 'request')
    assert app._future_middleware[1] == FutureMiddleware(test_middleware_2, 'response')


# Generated at 2022-06-24 04:07:02.930592
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    sanic = Sanic()
    assert sanic._future_middleware == []
    sanic.middleware(None)
    assert sanic._future_middleware[-1].middleware is None
    sanic.middleware(None, attach_to='response')
    assert sanic._future_middleware[-1].middleware is None
    sanic.middleware(None, attach_to='request')
    assert sanic._future_middleware[-1].middleware is None



# Generated at 2022-06-24 04:07:12.802371
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    from sanic import response
    app = Sanic(__name__)

    @app.middleware
    def middleware_factory(request):
        def for_request(r):
            return r

        def for_response(r):
            return r

        return (for_request, for_response)

    @app.middleware('response')
    def response_middleware(request, response):
        response.headers.add("X-Test", "True")
        return response

    @app.middleware('request')
    def request_middleware(request):
        request.headers.add("X-Test", "True")
        return request

    @app.route('/')
    async def handler(request):
        return response.text('OK')


# Generated at 2022-06-24 04:07:14.989230
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert True == True


# Generated at 2022-06-24 04:07:24.412317
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.app import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic("test_sanic")
    bp = Blueprint("test_blueprint")

    def middleware1(request):
        assert isinstance(request, Request)
        return HTTPResponse("OK")

    def middleware2(response):
        assert isinstance(response, HTTPResponse)
        return HTTPResponse("OK")

    app.middleware(middleware1, attach_to="response")
    app.middleware(middleware2, attach_to="request")
    bp.middleware(middleware1)
    bp.middleware(middleware2, attach_to="response")
    app.blueprint(bp)

# Generated at 2022-06-24 04:07:31.279917
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
  class A(MiddlewareMixin):
    def _apply_middleware(self, middleware: FutureMiddleware):
        raise NotImplementedError  # noqa

  a = A()

  assert a.on_request is a.on_request()
  assert a.on_request().__name__ == "on_request"
  assert a.on_request().__self__ == a



# Generated at 2022-06-24 04:07:34.530207
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    assert m.on_request(None)
    assert m.on_request(None)()

    def f(t):
        return lambda: t

    g = m.on_request(lambda: True)
    assert g()



# Generated at 2022-06-24 04:07:43.301070
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.response import text

    def add_name(request):
        request["name"] = "John"
        return request

    def get_name(request):
        request.app["name"] = request.get("name", "Someone")

    app = Sanic()
    app.on_request(add_name)
    app.on_response(get_name)

    @app.route("/")
    async def handler(request):
        return text(request.app["name"])

    request, response = app.test_client.get("/")
    assert response.text == "John"



# Generated at 2022-06-24 04:07:46.903942
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Midd:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []



    middmid = Midd()
    middmid.on_request()

# Generated at 2022-06-24 04:07:55.236483
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self.middleware_applied = False

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware_applied = True
    middleware_mixin = TestMiddlewareMixin()
    assert middleware_mixin.middleware_applied == False

    @middleware_mixin.on_request
    def test_middleware(request):
        assert request == 'request'
        return 'response'
    assert middleware_mixin.middleware_applied == True
    assert middleware_mixin._future_middleware[0].middleware('request') == 'response'


# Generated at 2022-06-24 04:07:57.506813
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()._future_middleware == []


# Generated at 2022-06-24 04:08:03.928568
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Arrange
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    app.config.REQUEST_MAX_SIZE = 10

    @app.middleware('request')
    async def print_on_request(request):
        print('I print on request')
        pass


    @app.middleware('response')
    async def print_on_response(request, response):
        print('I print on response')
        pass

    request, response = app.test_client.get('/')

    # Act
    actual = app.on_response()
    # Assert

# Generated at 2022-06-24 04:08:10.074924
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic()

    @app.middleware
    def register_middleware():
        pass

    sanic_middleware = app._future_middleware

    assert len(sanic_middleware) == 1
    assert sanic_middleware[0].middleware == register_middleware
    assert sanic_middleware[0].attach_to == "request"

# Generated at 2022-06-24 04:08:11.651706
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # MiddlewareMixin instance is created
    MWS = MiddlewareMixin()
    assert MWS is not None

# Generated at 2022-06-24 04:08:20.004862
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            print(middleware)

        def print_future_middleware(self):
            print(self._future_middleware)

    def test_middleware(request):
        print(request)

    def test_middleware_1(request):
        print('test_middleware_1')

    def test_middleware_2(request):
        print('test_middleware_2')

    def test_middleware_3(request):
        print('test_middleware_3')

    def test_middleware_4(request):
        print('test_middleware_4')

    # initial the class
    test_middleware_mixin = TestMiddlewareMixin()

    # test the function middleware

# Generated at 2022-06-24 04:08:22.942719
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    try:
        MiddlewareMixin().on_request()
    except Exception as e:
        assert str(e) == '__call__() missing 1 required positional argument: \'middleware\''



# Generated at 2022-06-24 04:08:31.897249
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class FutureMiddleware(object):
        def __init__(self, middleware, attach_to="request"):
            self.middleware = middleware
            self.attach_to = attach_to
            print(middleware, attach_to)
    
    class Test_MiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
    
        def _apply_middleware(self, future_middleware):
            self._future_middleware.append(future_middleware)
    
    test_MiddlewareMixin = Test_MiddlewareMixin()
    test_middleware = test_MiddlewareMixin.on_request(lambda a: None)
    test_middleware
    


# Generated at 2022-06-24 04:08:33.348480
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin

# Generated at 2022-06-24 04:08:34.938431
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin = MiddlewareMixin()
    assert mixin._future_mi

# Generated at 2022-06-24 04:08:35.733997
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

# Generated at 2022-06-24 04:08:40.359309
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class UnitTestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware):
            pass
    instance = UnitTestMiddlewareMixin()

    assert(instance._future_middleware == [])

# Generated at 2022-06-24 04:08:46.614245
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class myTest:
        pass
    myTest.mixin = MiddlewareMixin()

    @myTest.mixin.on_request
    def on_request(request):
        print("Test on_request")

    assert len(myTest.mixin._future_middleware) == 1
    assert myTest.mixin._future_middleware[0]._middleware == on_request


# Generated at 2022-06-24 04:08:54.234799
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic import response
    from sanic.models.parameters import BaseRequestParameters
    from sanic.middleware import BaseHTTPMiddleware
    
    class TestMiddleware(BaseHTTPMiddleware):
        def __init__(self, request):
            super(TestMiddleware, self).__init__(request)
        def process_request(self, request, call_next):
            return response.html('Testing')

    class TestParameters(BaseRequestParameters):
        def getall(self, name, default=None):
            return []

    app = Sanic('test')
    
    @app.on_request()
    def test_request_middleware(request):
        return response.html('Testing')


# Generated at 2022-06-24 04:08:55.158651
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    MiddlewareMixin()


# Generated at 2022-06-24 04:08:58.868397
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # create a sanic app
    app = Sanic()
    # check the on_request method
    assert app.on_request.__name__ == "on_request"
    assert app.on_request.__doc__ == (
        "Register middleware to be applied for a request.\n" "    "
    )



# Generated at 2022-06-24 04:09:05.938726
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    app = Sanic()

    @app.on_request
    async def func():
        pass

    @app.on_request
    async def func2():
        pass

    @app.on_request('response')
    async def func3():
        pass

    assert len(app._future_middleware) == 2

    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[1].attach_to == "request"



# Generated at 2022-06-24 04:09:10.783138
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    """Test for MiddlewareMixin constructor.

    Test with no arguments. It should create no arguments."""

    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin._future_middleware == []


# Generated at 2022-06-24 04:09:13.185218
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    assert app.on_request(lambda req, res : print(req+res)) == True


# Generated at 2022-06-24 04:09:15.171891
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin._future_middleware == []

# Generated at 2022-06-24 04:09:16.660369
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert 'MiddlewareMixin'
    assert '_future_middleware'

# Generated at 2022-06-24 04:09:21.726762
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestClass:
        def __init__(self):
            self._future_middleware: List[FutureMiddleware] = []
        def _apply_middleware(self, middleware):
            pass

    testable_obj: MiddlewareMixin = TestClass()
    testable_obj.on_response()

# Generated at 2022-06-24 04:09:24.152663
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    assert m.on_request() == partial(m.middleware, attach_to='request')
    assert m.on_request(None) == partial(m.middleware, attach_to='request')



# Generated at 2022-06-24 04:09:29.060692
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    testMixin: TestMixin = TestMixin()
    assert testMixin._future_middleware == []

# Generated at 2022-06-24 04:09:32.499175
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
	# initialization
	test_obj0 = MiddlewareMixin()
	test_func0 = lambda _: None
	# function call
	test_obj0.on_request(test_func0)


# Generated at 2022-06-24 04:09:34.491886
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    def test_middleware(args, kwargs):
        print('MiddlewareMixin called')

    test_middleware(*(), **{})  # noqa

# Generated at 2022-06-24 04:09:36.441274
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestApp:

        def __init__(self):
            pass

    app: TestApp = TestApp()
    MiddlewareMixin.on_request(app, "asd")

# Generated at 2022-06-24 04:09:45.947502
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.response import redirect
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol

    async def custom_middleware(request):
        assert request == [3]
        return True

    def custom_middleware2(request):
        assert request == [3]
        return True

    def custom_middleware3(request):
        assert request == [3]
        return True

    def custom_middleware4(request):
        assert request == [3]
        return True

    app = Sanic('test_MiddlewareMixin_on_response')

    async def handler(request):
        assert request == 3
        return redirect("http://localhost:9999/")

    app.add_route(handler, '/')

# Generated at 2022-06-24 04:09:46.422744
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # No error
    assert 1 == 1

# Generated at 2022-06-24 04:09:57.255621
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware

    class MockedMiddlewareCallable:
        def __init__(self):
            self._call_count = 0

        def __call__(self, request, handler):
            self._call_count += 1
            return handler(request)

    app = Sanic('test_MiddlewareMixin_middleware')
    mocked_middleware_callable = MockedMiddlewareCallable()

    app.middleware(mocked_middleware_callable)
    assert len(app._future_middleware) == 1
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].middleware == mocked_middleware_callable
    assert app._future_middleware[0].attach

# Generated at 2022-06-24 04:10:01.515344
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Arrange
    result = 0
    x = MiddlewareMixin()
    # Act
    x.on_response()
    # Assert
    assert result == 0


# Generated at 2022-06-24 04:10:03.258636
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass


# runs unit tests on what is being called

# Generated at 2022-06-24 04:10:04.917124
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
  m = MiddlewareMixin()
  assert m._future_middleware == []


# Generated at 2022-06-24 04:10:11.037497
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # arrange
    class MiddlewareMixinchild(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    # act
    mm = MiddlewareMixinchild()
    mm._future_middleware = []
    # assert
    assert mm._future_middleware == []
    assert isinstance(mm,MiddlewareMixin)


# Generated at 2022-06-24 04:10:17.061525
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic('test')

    # test
    @app.middleware
    def middleware1(request):
        return True
    
    @app.middleware('request')
    def middleware2(request):
        return True

    assert app.middleware(middleware1, 'request') is middleware1
    assert app.middleware(middleware2, 'request') is middleware2



# Generated at 2022-06-24 04:10:20.180022
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert (
        app.middleware(
            attach_to="response"
        ) == partial(app.middleware, attach_to="response")
    )



# Generated at 2022-06-24 04:10:21.462577
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin = MiddlewareMixin()
    assert mixin._future_middleware == []

# Generated at 2022-06-24 04:10:22.662369
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    m.on_request()

# Generated at 2022-06-24 04:10:24.023370
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert callable(MiddlewareMixin.on_response)

# Generated at 2022-06-24 04:10:36.019991
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Base:
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_middleware = []

        def _apply_middleware(self, middleware):
            raise NotImplementedError

    class A(MiddlewareMixin, Base):
        pass

    class B(A):
        pass

    b = B()

    # Check that the method is not conflicting with any of the future middleware methods
    b.middleware(middleware_or_request=None)
    b.middleware(middleware_or_request=None, attach_to=None)
    b.middleware(middleware_or_request=None, attach_to=None, apply=False)

    # Check that the method is not conflicting with any of the future middleware methods
   

# Generated at 2022-06-24 04:10:42.218508
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic()

    @app.middleware
    async def handler(request):
        return request

    @app.middleware('response')
    async def handler(response):
        return response

    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == handler
    assert app._future_middleware[1].middleware == handler
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-24 04:10:51.135986
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert issubclass(MiddlewareMixin, object)

    obj = MiddlewareMixin()

    with pytest.raises(NotImplementedError):
        assert obj._apply_middleware(1)
    
    arg = "arg"
    res = obj.middleware(arg)
    assert res != None
    res = obj.middleware(arg, "arg2")
    assert res != None
    res = obj.middleware(arg, apply=False)
    assert res != None
    res = obj.middleware(arg, "arg2", apply=False)
    assert res != None

    arg = callable
    res = obj.middleware(arg)
    assert res != None
    res = obj.middleware(arg, "arg2")
    assert res != None

# Generated at 2022-06-24 04:10:56.774855
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Right usage
    assert callable(MiddlewareMixin.middleware)
    instance = MiddlewareMixin()
    assert isinstance(instance, MiddlewareMixin)
    assert callable(instance.middleware)
    assert hasattr(instance, '_future_middleware')
    assert isinstance(instance._future_middleware, list)


# Generated at 2022-06-24 04:11:03.056804
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    print("\n### Unit test for method middleware of class MiddlewareMixin")
    class MiddlewareMixinTest(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    middlewareMixinTest = MiddlewareMixinTest()

    @middlewareMixinTest.middleware
    async def test_middleware_01(request):
        pass

    @middlewareMixinTest.middleware("request")
    async def test_middleware_02(request):
        pass

    @middlewareMixinTest.on_request
    async def test_middleware_03(request):
        pass

    assert middlewareMixinTest._future_middleware[0].attach_to == "request"
    assert middlewareMixinTest._future_middleware[1].attach_to == "request"

# Generated at 2022-06-24 04:11:05.484614
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin(1, 2)
    assert MiddlewareMixin(a='a1', b='b2')
    assert MiddlewareMixin(1, a='a1', b='b2')


# Generated at 2022-06-24 04:11:09.932172
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert hasattr(MiddlewareMixin, 'middleware')
    assert callable(MiddlewareMixin.middleware)
    

# Generated at 2022-06-24 04:11:11.329475
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
	assert middleware_mixin.on_request == middleware_mixin.middleware('request')

# Generated at 2022-06-24 04:11:18.239393
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    mwm = Sanic()
    assert repr(mwm.on_request) == "<bound method Sanic.middleware of <Sanic '<main>'>>"
    assert repr(mwm.on_request(callable)) == "<bound method Sanic.middleware of <Sanic '<main>'>>"


# Generated at 2022-06-24 04:11:22.593484
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class handler(MiddlewareMixin):
        def _apply_middleware(middleware):
            assert middleware.__name__ == 'Middleware'
    handler()

# Generated at 2022-06-24 04:11:24.804132
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    test_MiddlewareMixin = MiddlewareMixin()
    assert isinstance(test_MiddlewareMixin._future_middleware, List)


# Generated at 2022-06-24 04:11:29.085299
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-24 04:11:31.145192
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewareMixin = MiddlewareMixin()


# Generated at 2022-06-24 04:11:37.693987
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic()

    @app.middleware
    async def custom_middleware(request):
        pass

    assert app._future_middleware
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].function == custom_middleware
    assert app._future_middleware[0].args == ()
    assert app._future_middleware[0].kwargs == {}
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-24 04:11:47.825214
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Base:
        pass

    class A(MiddlewareMixin, Base):
        def __init__(self):
            super().__init__()
            self._future_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    a = A()

    @a.middleware
    def func1(request):
        pass

    @a.middleware('request')
    def func2(request):
        pass

    @a.on_request
    def func3(request):
        pass

    @a.on_response
    def func4(response):
        pass

    assert isinstance(a._future_middleware[0], FutureMiddleware)
    assert isinstance(a._future_middleware[1], FutureMiddleware)

# Generated at 2022-06-24 04:11:48.783800
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mw = MiddlewareMixin()

# Generated at 2022-06-24 04:11:53.202987
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    import pytest
    from sanic.app import Sanic

    app = Sanic()
    assert app._future_middleware == []



# Generated at 2022-06-24 04:12:02.997063
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class test:
        def __init__(self):
            self.attach_to = "response"
            self.called = False

    t = test()

    class FakeSanic:
        def __init__(self):
            self._future_middleware = []

        def middleware(self, middleware, attach_to):
            self._future_middleware.append(middleware)

    def mw(request):
        t.called = True
        assert t.attach_to == "response"
        return request

    fake_sanic = FakeSanic()
    fake_sanic.on_request(mw)
    assert len(fake_sanic._future_middleware) == 1
    assert t.called

    t.attach_to = "request"

# Generated at 2022-06-24 04:12:05.779766
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # given
    middleware_mixin = MiddlewareMixin()

    # when
    middleware = middleware_mixin.on_request()

    # then
    assert callable(middleware)


# Generated at 2022-06-24 04:12:09.355486
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class MyMiddlewareMixin(MiddlewareMixin):
        def on_response(self, middleware=None):
            middleware = middleware or self.on_response
            return super().on_response(middleware)
    assert not hasattr(MyMiddlewareMixin, 'on_response')


# Generated at 2022-06-24 04:12:11.511093
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic("test")

    app.on_request(None)



# Generated at 2022-06-24 04:12:22.744081
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareClass(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    # callable(middleware_or_request)
    @MiddlewareClass().on_request
    async def on_request():
        pass
        
    assert isinstance(MiddlewareClass()._future_middleware[0], FutureMiddleware)
    assert MiddlewareClass()._future_middleware[0].handler.__name__ == "on_request"
    assert MiddlewareClass()._future_middleware[0].attach_to == "request"
    
    # callable(middleware_or_request) = False
    @MiddlewareClass().middleware("request")
    async def middleware():
        pass

    assert isinstance(MiddlewareClass()._future_middleware[1], FutureMiddleware)

# Generated at 2022-06-24 04:12:30.629556
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic, response
    from sanic.response import HTTPResponse
    from sanic.testing import SanicTestClient, create_test_server, async_run

    def on_request(request):
        return response.text('On request!')

    app = Sanic(__name__)
    app.on_request(on_request)

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'On request!'


# Generated at 2022-06-24 04:12:32.068979
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    a = MiddlewareMixin()
    assert a._future_middleware == []

# Generated at 2022-06-24 04:12:35.358709
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    assert app.on_response(middleware="response") == partial(app.middleware, attach_to="response")


# Generated at 2022-06-24 04:12:41.822821
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware

    app = Sanic("test_MiddlewareMixin_on_request")
    assert isinstance(app, MiddlewareMixin)

    assert app._future_middleware == []

    @app.on_request()
    async def request_handler(request):
        pass

    assert app._future_middleware[0].type == "request"



# Generated at 2022-06-24 04:12:50.493482
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware

    # test initialization
    app = Sanic('sanic-test')
    assert isinstance(app._future_middleware, list)
    assert len(app._future_middleware) == 0

    # test _apply_middleware function , this function can be tested only with
    # server class as it internally uses server class's method

    http_protocol_instance = HttpProtocol(app, "127.0.0.1", 8080, loop=None)
    http_protocol_instance.request_handler.middleware = None

    def _middleware(request):
        return request

    future_middleware_obj = FutureMiddleware(_middleware, attach_to="request")
   

# Generated at 2022-06-24 04:12:52.428247
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    mm = MiddlewareMixin()
    mm.on_response("response")


# Generated at 2022-06-24 04:12:54.441985
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    app = Sanic('test')
    assert app._future_middleware == []

# Generated at 2022-06-24 04:12:58.515263
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware = MiddlewareMixin()
    assert middleware._future_middleware == []


# Unit tests for _apply_middleware method of class MiddlewareMixin

# Generated at 2022-06-24 04:13:03.416408
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    @MiddlewareMixin.on_response
    def hello(request, response):
        response.hello = 'world'

    assert hello.attach_to == 'response'

# Generated at 2022-06-24 04:13:08.639318
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = MiddlewareMixin()
    @app.on_request
    def request_middleware(request):
        print("This happens on each request")
    # assert app._future_middleware == [FutureMiddleware(request_middleware, 'request')] # noqa
    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].value is None
    assert app._future_middleware[0].loop is None



# Generated at 2022-06-24 04:13:11.368672
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Dummy(MiddlewareMixin):
        def __init__(self):
            super().__init__()

    obj = Dummy()
    assert isinstance(obj._future_middleware, List)


# Generated at 2022-06-24 04:13:13.637085
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    app: MiddlewareMixin = MiddlewareMixin()
    assert app._future_middleware == []


# Generated at 2022-06-24 04:13:17.849562
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """
    Test for method middleware of class MiddlewareMixin
    """
    model = MiddlewareMixin()
    # TODO: write unit test



# Generated at 2022-06-24 04:13:25.264923
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class test_class(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(test_class, self).__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            print(middleware.middleware)

    test_obj = test_class()

    @test_obj.middleware('request')
    def mware(request):
        print(request)

    print(test_obj._future_middleware)

# Generated at 2022-06-24 04:13:28.862525
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    mwm = MiddlewareMixin(Sanic(), 1, 2, 3, name="Kamran")
    assert isinstance(mwm._future_middleware, list)
    assert len(mwm._future_middleware) == 0

# Generated at 2022-06-24 04:13:30.389523
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixMddl = MiddlewareMixin()
    assert mixMddl._future_middleware == []

# Generated at 2022-06-24 04:13:35.854814
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic("sanic_server")
    from sanic.response import text
    from sanic.request import Request
    from sanic.response import HTTPResponse
    # test for on_request
    @app.middleware("request")
    def request_middleware(request: Request):
        return text("OK")
    # test for on_response
    @app.middleware("response")
    def response_middleware(request: Request, response: HTTPResponse):
        return text("OK")
    assert True


# Generated at 2022-06-24 04:13:37.408230
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []

# Generated at 2022-06-24 04:13:46.133818
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # arrange
    class TestClass:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    test_class = TestClass()

    # act
    test_class.middleware = MiddlewareMixin.middleware
    test_class.on_request = MiddlewareMixin.on_request

    # assert
    assert callable(test_class.middleware)
    assert callable(test_class.on_request)



# Generated at 2022-06-24 04:13:48.675556
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware = MiddlewareMixin()
    assert type(middleware) == MiddlewareMixin
    assert middleware._future_middleware == []


# Generated at 2022-06-24 04:13:53.730465
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Set up
    from sanic.app import Sanic
    app = Sanic(__name__)

    # Process
    app.on_response(middleware="middleware")

    # Result
    assert app._future_middleware[0].middleware == "middleware"
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-24 04:14:00.443761
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def fail(self, *args, **kwargs) -> None:
            raise NotImplementedError

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.fail()

    test_MiddlewareMixin = TestMiddlewareMixin()
    assert test_MiddlewareMixin._future_middleware == []


# Generated at 2022-06-24 04:14:03.950812
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
   # first case
   app = MiddlewareMixin()
   @app.on_request()
   async def handler(request):
       return request

   # second case
   app = MiddlewareMixin()
   @app.on_request
   async def handler(request):
       return request



# Generated at 2022-06-24 04:14:09.123975
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic()

    async def func_1(request):
        print('func_1')
    async def func_2(request):
        print('func_2')

    app.on_request(func_1)
    app.on_request(func_2)



# Generated at 2022-06-24 04:14:19.060811
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    import asyncio

    app = Sanic()
    
    # FutureMiddleware
    # 这个类的实例包含两个参数，middleware 和 attach_to
    # middleware: 为自定义的中间件函数，例如：
    # def logger_injector(request):
    #     print(request.headers)
    #     request['logger_context'] = {"logger_context": 1}
    #     return request
    # 这个函数就可以被当作一个中间件，并将 logger_context 写

# Generated at 2022-06-24 04:14:23.686755
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert hasattr(MiddlewareMixin, "on_request")
    assert callable(MiddlewareMixin.on_request)
    assert MiddlewareMixin.on_request.__name__ == "on_request"


# Generated at 2022-06-24 04:14:35.648885
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # 1
    class App(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            assert middleware
    # 2
    app = App()

    # 3
    @app.middleware('request')
    def request_middleware(request):
        pass

    # 4
    assert len(app._future_middleware) == 1
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert isinstance(request_middleware, FutureMiddleware)

    # 5
    @app.middleware
    def another_middleware(request):
        pass

    # 6
    assert len(app._future_middleware) == 2
    assert isinstance(app._future_middleware[1], FutureMiddleware)

# Generated at 2022-06-24 04:14:41.993795
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
  from sanic.app import Sanic
  from sanic.response import json

  class Main(MiddlewareMixin,Sanic):
    def _apply_middleware(self, middleware):
      pass

  add = lambda x,y: x+y

  app = Main()

  @app.on_request()
  async def test_on_request(request):
    return json({"add" : add(1,1)})

  _, response = app.test_client.get('/')

  assert response.json == {"add" : 2}

# Generated at 2022-06-24 04:14:45.367955
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Testing for case: callable(middleware_or_request)
    m = MiddlewareMixin()
    m.middleware(None)

    # Testing for case: not callable(middleware_or_request)
    # TODO: How to test?


# Generated at 2022-06-24 04:14:46.556275
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    _ = MiddlewareMixin()
    _ = Sanic()


# Generated at 2022-06-24 04:14:54.049275
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.middleware_called = False
            
        def _apply_middleware(self, middleware):
            self.middleware_called = True
            pass
            
    test = Test()
    # call @middleware with callable as parameter
    @test.middleware
    def middleware1(self):
        pass
    
    assert test.middleware_called

# Generated at 2022-06-24 04:14:58.848946
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()

    @app.on_request
    def my_middleware(request):
        return "Hello world!"

    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].middleware =="Hello World!"


# Generated at 2022-06-24 04:14:59.887434
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-24 04:15:09.185429
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    with pytest.raises(NotImplementedError):
        middleware_mixin_instance = MiddlewareMixin()
        middleware_mixin_instance._apply_middleware(object())

    middleware_mixin_instance = MiddlewareMixin()
    assert middleware_mixin_instance._future_middleware == []


# Generated at 2022-06-24 04:15:15.202089
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """
    Unit test for method middleware of class MiddlewareMixin
    """
    # TODO: Need to create instance of class MiddlewareMixin.
    #       Need to assign value to arguments of method middleware.
    #       Raise NotImplementedError if unable to implement this method
    raise NotImplementedError  # noqa


# Generated at 2022-06-24 04:15:19.681921
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    def test_middleware(request):
        pass

    app = Sanic()
    app.on_request(test_middleware)

    future = FutureMiddleware(test_middleware, attach_to='request')

    assert future in app._future_middleware


# Generated at 2022-06-24 04:15:26.291102
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    class Mixin(MiddlewareMixin):

        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    mixin = Mixin()
    mixin.on_request(lambda a: 1)

    assert len(mixin._future_middleware) == 1
    assert mixin._future_middleware[0].attach_to == "request"


# Generated at 2022-06-24 04:15:35.094537
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic("test_MiddlewareMixin_middleware")

    def middleware(request):
        pass

    app.middleware(middleware)

    assert len(app._future_middleware) == 1

    middleware_ = app._future_middleware[0]

    assert middleware_ is not None
    assert middleware_.middleware == middleware
    assert middleware_.attach_to == "request"

    # test on_request decorator
    def on_request_middleware(request):
        pass

    on_request_middleware = app.on_request(on_request_middleware)

    assert len(app._future_middleware) == 2

    on_request_middleware_ = app._future_middleware[1]


# Generated at 2022-06-24 04:15:38.420047
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    c = MiddlewareMixin()
    assert c


# Generated at 2022-06-24 04:15:49.239697
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    mixin = MiddlewareMixin()

    @mixin.middleware
    def middleware_1(request):
        pass

    @mixin.on_request
    def middleware_2(request):
        pass

    @mixin.on_response
    def middleware_3(request, response):
        pass

    assert len(mixin._future_middleware) == 3

    # Check middleware decorator
    assert isinstance(mixin._future_middleware[0], FutureMiddleware)
    assert mixin._future_middleware[0].middleware == middleware_1
    assert mixin._future_middleware[0].attach_to == 'request'

    # Check on_request decorator
    assert isinstance(mixin._future_middleware[1], FutureMiddleware)

# Generated at 2022-06-24 04:15:53.921475
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    param = MiddlewareMixin()
    _future_middleware = []
    assert param._future_middleware == _future_middleware
    assert param._future_middleware is not _future_middleware


# Generated at 2022-06-24 04:16:02.327316
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MockMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self._future_middleware = []

    middlewareMixin = MockMiddlewareMixin()

    class FutureMiddleware:
        def __init__(self, middleware, attach_to=None):
            self.middleware = middleware
            self.attach_to = attach_to

    def mockMiddleware1(request):
        return request
    def mockMiddleware2(request):
        return request

    middleware1 = FutureMiddleware(mockMiddleware1)
    middleware2 = FutureMiddleware(mockMiddleware2)
    middlewareMixin._future_middleware.append(middleware1)
    middlewareMixin._future_middleware.append(middleware2)

    assert middleware