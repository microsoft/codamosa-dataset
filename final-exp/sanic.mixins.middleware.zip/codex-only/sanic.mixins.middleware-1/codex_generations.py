

# Generated at 2022-06-24 04:05:51.108128
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert 1 == 1

# Generated at 2022-06-24 04:05:57.027545
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError # noqa

    tm = TestMiddlewareMixin()

    assert tm._future_middleware == []


# Implementation of function register_middleware in class MiddlewareMixin

# Generated at 2022-06-24 04:05:59.830491
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic

    app = Sanic(__name__)

    assert isinstance(app._future_middleware, List)
    assert app._future_middleware == []


# Generated at 2022-06-24 04:06:02.486354
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class M1(MiddlewareMixin):
        def __init__(self):
            super().__init__()
    assert M1()._future_middleware == []

# Generated at 2022-06-24 04:06:03.439935
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
   assert MiddlewareMixin._future_middleware == []

# Generated at 2022-06-24 04:06:11.283247
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    def TestMiddleware():
        pass

    assert app._future_middleware == []
    app.middleware(TestMiddleware)
    assert app._future_middleware == [TestMiddleware]


# Generated at 2022-06-24 04:06:16.477731
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic("test_MiddlewareMixin_middleware")

    async def middleware(request):
        request.ctx.update({"middleware_called": True})

    @app.route("/")
    async def handler(request):
        assert request.ctx.get("middleware_called")
        return text("OK")

    app.middleware(middleware)

    _, response = app.test_client.get("/")
    assert response.text == "OK"



# Generated at 2022-06-24 04:06:20.858613
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # what does it do
    # what does it return

    # Sanity check that it doesn't throw an exception
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin is not None

# Generated at 2022-06-24 04:06:21.677055
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass


# Generated at 2022-06-24 04:06:30.860615
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Sample(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            self._future_middleware = []
            self._middleware_paths = []
            self._middleware_callbacks = []

        async def response(self, request, response):
            for _ in range(len(self._middleware_paths)):
                _, attach_to = self._middleware_paths.pop()
                callback = self._middleware_callbacks.pop()
                if attach_to == "response":
                    response = await callback(request, response)
            return response

        def _apply_middleware(self, middleware: FutureMiddleware):
            self._middleware_paths.append(
                (middleware.path, middleware.attach_to)
            )
            self._middleware_

# Generated at 2022-06-24 04:06:31.952680
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    
    # Test 1
    assert None == None



# Generated at 2022-06-24 04:06:43.424188
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # set up
    class A:
        def __init__(self):
            self.result = None

        def test(self):
            self.result = "test1"

    class B:
        def __init__(self):
            self.result = None

        def test(self):
            self.result = "test"

    a = A()
    b = B()

    # test
    a.on_request(b.test)
    assert a.result == "test"

    a.on_request(b.test)()
    assert a.result == "test"

    a.on_request(b.test)()()
    assert a.result == "test"

    a.on_request()(b.test)
    assert a.result == "test"


# Generated at 2022-06-24 04:06:44.297543
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-24 04:06:53.037782
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    import sys
    sys.path.append('../')
    from utils.sanic.middleware_mixin import MiddlewareMixin
    import unittest
    class TestMiddlewareMixin(unittest.TestCase):
        def setUp(self):
            self.test_class=MiddlewareMixin()

        def test_init(self):
            self.assertEqual(self.test_class._future_middleware,[])

        def test_middleware(self):
            def test_middleware(request):
                pass
            self.test_class.middleware(test_middleware)
            self.assertEqual(self.test_class._future_middleware[0].middleware,test_middleware)

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-24 04:06:59.902003
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddlewareMixin_T(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

    t = MiddlewareMixin_T()
    assert len(t._future_middleware) == 0



# Generated at 2022-06-24 04:07:02.835108
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    try:
        MiddlewareMixin()
        assert True
    except:
        assert False


# Generated at 2022-06-24 04:07:12.725330
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestServer(MiddlewareMixin):
        def reset_middleware_state(self):
            self._future_middleware = []

        def test_after_registration(self):
            _middleware = [m for m in self._future_middleware if
                           m.attach_to == "request" and m.apply]

            return _middleware

        def _apply_middleware(self, middleware):
            middleware.apply = True

    test_server = TestServer()

    def middleware_empty():
        pass

    def middleware_request(request):
        pass

    test_server.on_request(middleware_empty)
    test_server.on_response(middleware_request)

    assert test_server.test_after_registration()

    test_server.reset_middleware_state()

   

# Generated at 2022-06-24 04:07:21.324492
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()

    @app.middleware  # noqa
    def middleware_handler(request):
        pass

    @app.on_request  # noqa
    def on_request_handler(request):
        pass

    assert hasattr(app, 'middleware')
    assert hasattr(app, 'on_request')
    assert middleware_handler in app.middleware.middleware
    assert on_request_handler in app.middleware.middleware
    assert 'request' in app.middleware.middleware
    assert 'response' in app.middleware.middleware

# Generated at 2022-06-24 04:07:28.714723
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class App(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self._future_middleware: List[FutureMiddleware] = []
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa
        def middleware(
            self, middleware_or_request, attach_to="request", apply=True
        ):
            def register_middleware(middleware, attach_to="request"):
                nonlocal apply

                future_middleware = FutureMiddleware(middleware, attach_to)
                self._future_middleware.append(future_middleware)
                if apply:
                    self._apply_middleware(future_middleware)
                return middleware

            if callable(middleware_or_request):
                return

# Generated at 2022-06-24 04:07:30.872025
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Create a dummy class to inherit and use mixin
    class DummyClass(MiddlewareMixin):
        pass
    dummy_class = DummyClass()
    # Test if on_request is working fine
    assert dummy_class.middleware == dummy_class.on_request


# Generated at 2022-06-24 04:07:38.429672
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    '''
    check if the function "middleware" of MiddlewareMixin class works correctly.
    :return:
    '''
    class TestMiddleware(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            self._future_middleware: List[FutureMiddleware] = []
            super().__init__(*args, **kwargs)


    def middleware(request):
        print("start request")
        return request


    b = TestMiddleware()
    b.middleware(middleware)
    assert b._future_middleware[0].middleware==middleware and b._future_middleware[0].attach_to == 'request'
    b.middleware(middleware, attach_to="test")
    assert b._future_middleware[1].middleware == middleware and b._

# Generated at 2022-06-24 04:07:43.078924
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    assert isinstance(TestMiddlewareMixin().on_response(), partial)


# Generated at 2022-06-24 04:07:45.141841
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin().on_request() == None


# Generated at 2022-06-24 04:07:53.451278
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Setup
    from sanic import Sanic
    from sanic.response import json, text

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.route("/")
    async def handler(request):
        return json({"hello": "world"})

    # Run
    @app.middleware("response")
    async def my_middleware(request, response):
        response.headers["new_header"] = "new_value"
        return response

    _, response = app.test_client.get("/")

    # Verify
    assert response.status == 200
    assert response.json["hello"] == "world"
    assert response.headers["new_header"] == "new_value"


# Generated at 2022-06-24 04:08:01.365004
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    param_middleware = 'middleware'
    param_request = 'request'
    param_attach_to = 'attach_to'
    param_apply = 'apply'

    class MiddlewareMixinClass:
        def __init__(self, param_middleware, param_request):
            self._future_middleware = []
            self._middleware_or_request = param_middleware
            self._request = param_request

        def _apply_middleware(self, param_middleware):
            assert param_middleware == self._request

    obj_MiddlewareMixinClass = MiddlewareMixinClass(param_middleware, param_request)

    result = obj_MiddlewareMixinClass.middleware(param_middleware, attach_to=param_attach_to, apply=param_apply)
    assert result == param_request



# Generated at 2022-06-24 04:08:02.458293
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

# Generated at 2022-06-24 04:08:05.739476
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert callable(MiddlewareMixin.on_response)
    assert MiddlewareMixin.on_response.__name__ == 'on_response'

# Generated at 2022-06-24 04:08:08.085925
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    mm = MiddlewareMixin()
    assert mm.on_request()

# Generated at 2022-06-24 04:08:09.843199
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin and middleware_mixin._future_middleware == []


# Generated at 2022-06-24 04:08:15.271965
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic(__name__)

    @app.middleware('request')
    async def before_request(request):
        request['processed_by'] = 'before_request'

    @app.middleware('response')
    async def after_response(request, response):
        response.body = response.body + ' after_response'
        return response

    @app.route('/')
    async def handler(request):
        return text('response')

    request, response = app.test_client.get('/')

    print(request)

# Generated at 2022-06-24 04:08:16.885311
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert isinstance(m._future_middleware, List)

# Generated at 2022-06-24 04:08:21.106947
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    @app.on_response()
    def request_middleware(request):
        pass
    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[0].attach_to == "request"

# Generated at 2022-06-24 04:08:24.002394
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from mock import Mock
    from sanic import Sanic
    sanic1 = Sanic("a", load_env="a")
    assert isinstance(sanic1.on_response(Mock()), partial) is True

# Generated at 2022-06-24 04:08:32.062824
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class App(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

        def on_request(self, middleware=None):
            if callable(middleware):
                return self.middleware(middleware, "request")
            else:
                return partial(self.middleware, attach_to="request")

    app = App()
    class middleware(object):
        def __init__(self, request):
            pass
    app.on_request(middleware)
    print(app._future_middleware)
    assert app._future_middleware != []


# Generated at 2022-06-24 04:08:39.701243
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestClass(MiddlewareMixin):
        pass
    obj = TestClass()
    # assert null
    assert obj.on_request()
    assert obj.on_request(middleware="request")
    assert not obj.on_request(middleware=None)

    obj.on_request(middleware=lambda: None)

    mock_partial = Mock()
    with patch("sanic.models.middlware_mixin.partial", mock_partial):
        mock_partial.assert_called_once()
        assert obj.on_request(middleware=None)
        mock_partial.assert_called_with(obj.middleware, attach_to="request")


# Generated at 2022-06-24 04:08:50.677845
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.exceptions import InvalidUsage
    class MyCls(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(MyCls, self).__init__(*args, **kwargs)

    m = MyCls()

    # test middleware method
    futureMiddleware = FutureMiddleware(None, "request")
    m._future_middleware.append(futureMiddleware)

    # test middleware method
    def x(request):
        return request

    @m.middleware(x)
    def middleware():
        pass

    # test on_request method
    @m.on_request()
    def on_request():
        pass

    # test on_response method
    @m.on_response()
    def on_response():
        pass

   

# Generated at 2022-06-24 04:08:59.325468
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        async def get(self, request):
            return text("Hello")

    def response_middleware(request, response):
        assert type(request) == "Request"
        assert type(response) == "HTTPResponse"
        assert response.body == b"Hello"
        assert response.status == 200

    def request_middleware(request):
        assert type(request) == "Request"
        assert request.method == "GET"

    app = Sanic("test_MiddlewareMixin")
    app.add_route(MyView.as_view(), "/")

    #

# Generated at 2022-06-24 04:09:00.407032
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()._future_middleware==[]

# Generated at 2022-06-24 04:09:04.943520
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    try:
        m=MiddlewareMixin()
        m.on_response()
    except NotImplementedError as e:
        print('test_MiddlewareMixin_on_response NotImplementedError!')

if __name__ == '__main__':
    test_MiddlewareMixin_on_response()

# Generated at 2022-06-24 04:09:07.315450
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    aa = MiddlewareMixin()
    assert isinstance(aa, MiddlewareMixin)
    assert aa._future_middleware == []

# Generated at 2022-06-24 04:09:08.207811
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()

# Generated at 2022-06-24 04:09:10.045692
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    result = MiddlewareMixin.on_response(middleware=None)
    assert isinstance(result, partial)


# Generated at 2022-06-24 04:09:13.961743
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    app = Sanic(__name__)
    @app.on_response
    def on_response():
        print('on_response')

    print(app.middleware)


# Generated at 2022-06-24 04:09:22.333879
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import ServerError
    from sanic import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def record_request(request):
        request['truthy'] = True

    request, response = app.test_client.get('/')
    assert request['truthy']

    @app.middleware('response')
    async def record_response(request, response):
        response.headers['Server'] = 'Mangled'

    request, response = app.test_client.get('/')
    assert response.headers['Server'] == 'Mangled'

    @app.exception(ServerError)
    def server_error_handler(request, exception):
        return

# Generated at 2022-06-24 04:09:25.140214
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic('test')
    assert callable(app.on_response())
    assert callable(app.on_response(lambda request, response: None))

# Generated at 2022-06-24 04:09:26.185480
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    MiddlewareMixin.on_response("AT")

# Generated at 2022-06-24 04:09:30.533289
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class DummyClass(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, middleware):
            pass

    context = DummyClass()
    assert context.on_request() == partial(context.middleware, attach_to='request')
    assert context.on_request(lambda: 1) == context.middleware(lambda: 1, "request")



# Generated at 2022-06-24 04:09:33.352220
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = MiddlewareMixin()
    app.middleware(middleware_or_request = lambda request: request)
    assert len(app._future_middleware) == 1


# Generated at 2022-06-24 04:09:33.981538
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert True

# Generated at 2022-06-24 04:09:36.764291
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class DummyClass(MiddlewareMixin):
        pass

    obj = DummyClass()
    assert obj._future_middleware == []

# Generated at 2022-06-24 04:09:43.507357
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    """
    MiddlewareMixin: Test on_request method
    """
    app = Mock(
        _future_middleware=[],
        _apply_middleware=lambda x: app._future_middleware.append(x)
    )

    def test_middleware():
        pass

    app.on_request(middleware=test_middleware)
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-24 04:09:52.792582
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # mock
    from unittest.mock import Mock

    # target class
    from sanic.server import Server

    # singleton
    server = Server("127.0.0.1", 8000, debug=False)
    server.app = Mock()

    # target method
    server.app.middleware = MiddlewareMixin.middleware

    # params
    # middleware_or_request, attach_to="request", apply=True
    # _middleware: List[FutureMiddleware] = []

    # target test method
    @server.app.middleware
    def middleware(request):
        pass

    # invoke
    server.app.middleware(middleware_or_request=middleware)

    # result

# Generated at 2022-06-24 04:10:00.256030
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Assert the correct error being raised if the method _apply_middleware is not implemented.

    class FakeMiddlewareMixin(MiddlewareMixin):
        pass

    fake_middleware_mixin = FakeMiddlewareMixin()
    with pytest.raises(NotImplementedError):
        fake_middleware_mixin._apply_middleware(FutureMiddleware(None, None))

    # Assert the correct registration of the middleware.

    class FakeMiddlewareMixin:
        def __init__(self):
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    fake_middleware_mixin = FakeMiddlewareMixin()
    middleware = FutureMiddleware(FutureMiddleware, None)
    fake_middleware_

# Generated at 2022-06-24 04:10:02.689595
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert isinstance(middleware_mixin._future_middleware, list)


# Generated at 2022-06-24 04:10:05.717357
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    mixin = MiddlewareMixin()
    response = mixin.on_response(middleware="response")
    assert callable(response)
    assert response.keywords["attach_to"] == "response"



# Generated at 2022-06-24 04:10:14.129210
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import unittest

    class testClass(MiddlewareMixin):
        def __init__(self):
            pass

    def middleware():
        pass

    def middleware2():
        pass

    class testCase(unittest.TestCase):
        def runTest(self):
            t = testClass()
            self.assertTrue(t.on_response(middleware))
            self.assertTrue(t.middleware(middleware2))
            self.assertTrue(t.on_response()(middleware2))

    unittest.main()

# Generated at 2022-06-24 04:10:23.379034
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.response import json
    from sanic.response import text

    app = Sanic('test_on_response')
    res = []

    @app.middleware('request')
    async def handler(request):
        res.append('Start request')

    @app.middleware('response')
    async def handler(request, response):
        res.append('End request')
        return response

    @app.route('/')
    async def handler(request):
        res.append('Request made')
        return json(res)

    request, response = app.test_client.get('/')

    assert response.status == 200

# Generated at 2022-06-24 04:10:35.560641
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # 1. Test using callable
    # -------------------------
    class F:
        def __init__(self, *args, **kwargs):
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

        def middleware(
            self, middleware_or_request, attach_to="request", apply=True
        ):
            def register_middleware(middleware, attach_to="request"):
                nonlocal apply

                future_middleware = FutureMiddleware(middleware, attach_to)
                self._future_middleware.append(future_middleware)
                if apply:
                    self._apply_middleware(future_middleware)
                return middleware

            # Detect which way this

# Generated at 2022-06-24 04:10:40.422494
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import json, text
    app = Sanic()
    @app.on_response
    def handler_on_response(request, response):
        # should always be called
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.status == 200


# Generated at 2022-06-24 04:10:45.311677
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic(__name__)
    @app.on_response
    def on_response(request, response):
        return None
    @app.route('/')
    def handle_request(request):
        return text('OK')
    request, response = app.test_client.get('/')
    assert response.status == 200

# Generated at 2022-06-24 04:10:49.765638
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    a=Sanic(__name__)
    try:
        a.middleware
    except AttributeError:
        print("AttributeError occured when accessing a.middleware and this try failed")
        assert 1==0
    else:
        print("AttributeError did not occur and this test passed")
        assert 1==1
    return

# Generated at 2022-06-24 04:10:54.530187
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    error = False
    try:
        from sanic.server import HttpProtocol
        from types import MethodType
        h = HttpProtocol()
        h.on_response()
        h.on_response(lambda protocol, request, response: None)
        assert isinstance(h.on_response(lambda protocol, request, response: None).__call__, MethodType)
    except Exception as e:
        error = True
    finally:
        assert error == False


# Generated at 2022-06-24 04:10:58.040955
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    """
    Test function on_response of class MiddlewareMixin.
    """
    class A(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    a = A()
    def f():
        pass
    a.on_response(f)


# Generated at 2022-06-24 04:11:08.498998
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from datetime import datetime, timezone
    from sanic.app import Sanic

    app= Sanic()
    app.add_task(lambda: time.sleep(2))

    @app.route("/")
    def handler(request):
        return text("OK")

    @app.on_response("request")
    def on_response(request, response):
        response.body = "hi"
        response.status = 200
        response.headers["custom"] = "test"

    @app.exception(Exception)
    def catch_all_exception_handler(request, exception):
        return text("Unhandled error", 500)
  
    @app.listener("before_server_start")
    def before_server_start(app, loop):
        pass


# Generated at 2022-06-24 04:11:09.291194
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin() is not None

# Generated at 2022-06-24 04:11:10.955363
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test')
    app.on_request(middleware='request')


# Generated at 2022-06-24 04:11:16.842289
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test = Test()
    # 1. callable middleware_or_request
    test.middleware(lambda x: test)
    assert test._future_middleware
    # 2. non-callable middleware_or_request
    def test_middleware(request, response):
        pass
    test.middleware('request')(test_middleware)
    assert test._future_middleware

# Generated at 2022-06-24 04:11:25.707354
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():

    class ClassWithMiddleware(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            MiddlewareMixin.__init__(self, *args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            print("Applying middleware...")

    class_with_middleware = ClassWithMiddleware()

    # @class_with_middleware.on_response
    # def middleware_func_1():
    #     pass
    #
    # # same as:
    # class_with_middleware.middleware(middleware_func_1, attach_to="response")
    #
    # @class_with_middleware.on_response("request")
    # def middleware_func_2():
    #     pass
    #


# Generated at 2022-06-24 04:11:29.657576
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    mm = MiddlewareMixin()
    assert mm.on_request(middleware) is not None

# Generated at 2022-06-24 04:11:35.203678
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class NewMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

    new_middleware_mixin = NewMiddlewareMixin()
    assert new_middleware_mixin.on_response() == partial(MiddlewareMixin.middleware, attach_to="response")

# Generated at 2022-06-24 04:11:41.507488
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    request = 'request'
    middleware = Mock(return_value = 'middleware')
    MiddlewareMixin_ = MiddlewareMixin()
    assert isinstance(MiddlewareMixin_.on_request(middleware = None), partial)
    MiddlewareMixin_.on_request(middleware = middleware)
    assert isinstance(MiddlewareMixin_.on_request(middleware = middleware), MiddlewareMixin)
    assert middleware.assert_called_once_with(request, 'request')
    middleware.assert_called_once_with(request, 'request')


# Generated at 2022-06-24 04:11:43.543469
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Code here
    MiddlewareMixin()

# Generated at 2022-06-24 04:11:52.966483
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    my_middleware = MiddlewareMixin()
    assert (my_middleware._future_middleware == [])

    def first_middleware(request, response):
        return response

    def second_middleware(request, response):
        return response

    def third_middleware(request, response):
        return response

    def fourth_middleware(request, response):
        return response

    my_middleware = MiddlewareMixin()
    assert (my_middleware._future_middleware == [])

    my_middleware.middleware(first_middleware)
    assert (my_middleware._future_middleware == [
        FutureMiddleware(
            first_middleware, "request"
        )
    ])

    my_middleware.middleware(second_middleware, "response")

# Generated at 2022-06-24 04:11:55.399836
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    @app.on_request
    async def f(req):
        return req

    assert (app.on_request(f) is f)


# Generated at 2022-06-24 04:11:58.858301
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        pass
    # test initialization
    test_MiddlewareMixin()


# Generated at 2022-06-24 04:12:03.854673
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MockMiddlewareMixin(MiddlewareMixin):
        pass

    mock_middleware_mixin = MockMiddlewareMixin()
    mock_middleware = mock_middleware_mixin.middleware
    import pytest
    with pytest.raises(NotImplementedError):
        mock_middleware.__call__(mock_middleware, "request", False)


# Generated at 2022-06-24 04:12:06.982860
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    a = MiddlewareMixin()
    assert not a
    assert gc.collect() == 0
    assert sys.getrefcount(a) == 2 # one for testing and one at local


# Generated at 2022-06-24 04:12:13.073356
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    class A(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    a = A()

    @a.on_request
    def fn():
        pass

    assert len(a._future_middleware) == 1
    assert a._future_middleware[0].attach_to == 'request'
    assert a._future_middleware[0].handler == fn

    @a.on_request('request')
    def fn2():
        pass

    assert len(a._future_middleware) == 2
    assert a._future_middleware[1].attach_to == 'request'
    assert a._future_middleware[1].handler == fn2


# Generated at 2022-06-24 04:12:16.381233
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    sanic = Sanic("sanic-middleware")

    # Decorator
    @sanic.on_request
    def test_decorator_on_request(request):
        assert request is not None

    # partial decorator
    on_request = sanic.on_request()
    @on_request
    def test_partial_on_request(request):
        assert request is not None


# Generated at 2022-06-24 04:12:18.361477
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    app = Sanic()
    assert app._future_middleware == []

# Generated at 2022-06-24 04:12:22.871554
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.hi = "hi"

    # test constructor
    tc = TestClass()
    assert (tc._future_middleware == [])
    assert (tc.hi == "hi")

# Generated at 2022-06-24 04:12:30.377112
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = MiddlewareMixin()
    @app.on_request
    def middleware1(request):
        print(request)

    @app.on_request
    def middleware2(request):
        print(request.headers)

    print(app._future_middleware)
    # [<functools.partial object at 0x7f1d95b3c0e0>, <functools.partial object at 0x7f1d95b3c0e0>]


# Generated at 2022-06-24 04:12:39.297398
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    assert test_middleware_mixin._future_middleware == []

    def test_middleware(request):
        pass

    test_middleware_mixin.middleware(test_middleware)
    assert test_middleware_mixin._future_middleware == \
           [FutureMiddleware(test_middleware, "request")]

    test_middleware_mixin1 = TestMiddlewareMixin()
    assert test_middleware_mixin1._future_middleware == []

    test_middleware_mixin1.on_response(test_middleware)
    assert test_middleware_mixin1._future

# Generated at 2022-06-24 04:12:43.526888
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test:
        def __init__(self):
            self.name = "aa"
            self.name2 = "cc"
        def test_func(self):
            return self.name
    A = Test()
    A = MiddlewareMixin.middleware(A, Test.test_func, apply = True)
    print(A.test_func())



# Generated at 2022-06-24 04:12:46.475852
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic(__name__)

    def middleware_test(request):
        pass
    app.middleware(middleware_test)
    assert len(app._future_middleware) == 1



# Generated at 2022-06-24 04:12:50.146651
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = Sanic("test_MiddlewareMixin_on_request")
    def middleware(request):
        return request

    on_request = app.on_request(middleware)
    on_request(app)


# Generated at 2022-06-24 04:13:00.605680
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic import response

    app = Sanic(__name__) 

    @app.middleware
    def test_middleware(request):
        request['test'] = 'test_middleware_has_been_applied'

    @app.route('/test_middleware/')
    async def test_handler(request):
        # Test to check if middleware function has been applied
        if request['test'] == 'test_middleware_has_been_applied':
            return response.json({'test': 'success'})
        else:
            return response.text('request did not go through the middleware')

    request, response = app.test_client.get('/test_middleware/')

    assert response.status == 200
    assert response.json == {'test': 'success'}

# Generated at 2022-06-24 04:13:08.230127
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import unittest
    from pynet.analysers.http.sanic import SanicAnalyser

    class TestMiddlewareMixin(unittest.TestCase):

        def setUp(self):
            self.analyser = SanicAnalyser()

        def test_on_response(self):
            from sanic.exceptions import NotFound

            @self.analyser.on_response
            def test_middleware(request, response):
                if isinstance(response, NotFound):
                    return text("Not Found")
                else:
                    return text("Hello")

            # the decorator works
            response = self.analyser.handle_request(self.analyser.request)
            self.assertEqual(response.status, 200)

    suite = unittest.TestLoader().loadTestsFromTest

# Generated at 2022-06-24 04:13:13.732326
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic()

    @app.middleware("request")
    def before_request(request):
        pass

    @app.middleware("response")
    def before_response(request, response):
        pass

    @app.route("/")
    def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.status == 200
    assert response.text == "OK"


# Generated at 2022-06-24 04:13:25.070650
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()

    @app.middleware
    def middleware(request):
        pass

    @app.middleware('request')
    def request_middleware(request):
        pass

    @app.middleware('response')
    def response_middleware(request, response):
        pass

    assert len(app._future_middleware) == 3
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[1].attach_to == "request"
    assert app._future_middleware[1].middleware == middleware
    assert app._future_middleware[2].attach_to == "response"

# Generated at 2022-06-24 04:13:30.210648
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    try:
        assert issubclass(MiddlewareMixin, object)
    except AssertionError as e:
        print(MiddlewareMixin, 'MiddlewareMixin is not a subclass of object')
        raise(e)

    try:
        m = MiddlewareMixin()
        m.on_response(m)
    except TypeError as e:
        print('Exception raised as expected from MiddlewareMixin.on_response')

# Generated at 2022-06-24 04:13:33.423435
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Test_MiddlewareMixin(MiddlewareMixin):
        pass

    test = Test_MiddlewareMixin()
    assert test._future_middleware == []


# unit test of function middleware of class MiddlewareMixin

# Generated at 2022-06-24 04:13:42.823799
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    from sanic import response

    app = Sanic(__name__)

    @app.middleware
    async def handle_request(request):
        request['parsed'] = True

    @app.middleware('response')
    async def handle_response(request, response):
        response.headers['Processed-By'] = 'Sanic'

    @app.route('/')
    async def handler(request):
        return response.json({'test': True})

    request, response = app.test_client.get('/')
    assert response.headers['Processed-By'] == 'Sanic'
    assert request['parsed'] == True

# Generated at 2022-06-24 04:13:53.489678
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Define a class to be a partial of class MiddlewareMixin
    class MiddlewareMixin_test(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    # Test the calling pattern of @MiddlewareMixin_test.middleware
    # 1. call with only one argument, callable object
    MiddlewareMixin_test_1 = MiddlewareMixin_test()
    # Define a callable object
    def test_middleware(request):
        pass
    assert MiddlewareMixin_test_1.middleware(test_middleware) == test_middleware

    # 2. call with two arguments, callable object and string
    MiddlewareMixin_test_2 = MiddlewareMixin_test()

# Generated at 2022-06-24 04:13:55.151055
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert callable(MiddlewareMixin.on_response)

# Generated at 2022-06-24 04:14:04.220387
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    """
    This function tests function on_response of MiddlewareMixin.
    """
    import unittest
    from sanic.app import Sanic

    from sanic.models.futures import FutureMiddleware

    app = Sanic("test_MiddlewareMixin_on_response")

    class TestMiddleWareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            assert isinstance(
                middleware, FutureMiddleware
            )

    t_middleware_mixin = TestMiddleWareMixin()

    @t_middleware_mixin.on_response()
    async def middleware_response_func(request, response):
        return response

    @app.route("/")
    def handler(request):
        return

    app._apply_middleware(app._future_middleware)

# Generated at 2022-06-24 04:14:06.824535
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    obj = MiddlewareMixin()
    result = obj.on_request()
    assert callable(result)


# Generated at 2022-06-24 04:14:08.687542
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
  test = MiddlewareMixin()
  assert isinstance(test,MiddlewareMixin)


# Generated at 2022-06-24 04:14:12.914767
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')

    @app.on_request
    def middleware_request(request):
        assert request

    request, response = app.test_client.get('/')
    assert response.status == 404


# Generated at 2022-06-24 04:14:14.488811
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    test = MiddlewareMixin()
    assert test._future_middleware == []

# Generated at 2022-06-24 04:14:22.740416
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    # TODO: Add test for method middleware of class MiddlewareMixin

    @app.middleware("request")
    async def request_middleware(request):
        pass

    @app.middleware("response")
    async def response_middleware(request, response):
        pass

    assert len(app._future_middleware) == 2
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert isinstance(app._future_middleware[1], FutureMiddleware)
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-24 04:14:28.325111
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')
    path = '/test_MiddlewareMixin_middleware'

    @app.middleware
    def test_MiddlewareMixin_middleware(request):
        pass

    @app.route(path)
    def handler(request):
        return text('OK')

    request, response = app.test_client.get(path)

    assert response.text == 'OK'

# Generated at 2022-06-24 04:14:33.779913
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic()

    @app.on_request
    async def on_request(request):
        pass

    assert len(app._future_middleware) == 1

    for middleware in app._future_middleware:
        assert middleware.function is on_request
        assert middleware.attach_to == "request"

# Generated at 2022-06-24 04:14:35.796429
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert callable(MiddlewareMixin)
    assert hasattr(MiddlewareMixin, "on_request")
    assert callable(MiddlewareMixin.on_request)

# Generated at 2022-06-24 04:14:44.641808
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Test_MiddlewareMixin:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa
    testClass = Test_MiddlewareMixin()
    def test_callable():
        def test_middleware(request):
            return request
        assert testClass.on_response(test_middleware) == testClass.middleware(test_middleware, 'response')
    test_callable()

    def test_not_callable():
        assert testClass.on_response() == partial(testClass.middleware, attach_to = 'response')
    test_not_callable()


# Generated at 2022-06-24 04:14:46.155237
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()

    @app.middleware  # type: ignore
    async def my_middleware(request):
        # Do something before request is processed
        print("hello")



# Generated at 2022-06-24 04:14:53.755873
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Test(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(Test, self).__init__(*args, **kwargs)

    @Test.on_request
    async def handler1(request):
        print("request1")
        return None

    @Test().on_request
    async def handler2(request):
        print("request2")
        return None

    @Test.on_response
    async def handler3(request, response):
        print("response1")
        return response

    @Test().on_response
    async def handler4(request, response):
        print("response2")
        return response

    test = Test()
    assert len(test._future_middleware) == 0
    test.middleware(handler1)

# Generated at 2022-06-24 04:14:58.601641
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    instance = Sanic(__name__)

    def dummy():
        return 'hello world'

    instance.on_request(dummy)
    assert instance._future_middleware[0].attach_to == 'request'

if __name__ == '__main__':
    test_MiddlewareMixin_on_request()

# Generated at 2022-06-24 04:14:59.198921
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert True

# Generated at 2022-06-24 04:15:08.639794
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from unittest.mock import MagicMock
    from unittest.mock import patch

    _future_middleware_mock = MagicMock()
    _middleware_mock = MagicMock()
    _attach_to_mock = MagicMock()

    with patch(
        "sanic.models.mixins.MiddlewareMixin._future_middleware",
        new_callable=MagicMock,
    ) as future_middleware_mock:
        future_middleware_mock.return_value = _future_middleware_mock

# Generated at 2022-06-24 04:15:18.195489
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import json, text
    import asyncio

    app = Sanic(__name__)

    @app.middleware('request')
    async def print_on_request(request):
        print('I run always before any request')

    @app.route('/')
    async def handler(request):
        return text('OK')

    @app.listener('after_server_start')
    async def notify_server_started(sanic, loop):
        resp = await sanic.test_client.get('/')
        assert resp.status == 200
        assert await resp.text() == 'OK'

    app.run(debug=True)


# Generated at 2022-06-24 04:15:21.394274
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.models.futures import FutureMiddleware
    from sanic.middleware import MiddlewareMixin

    obj = MiddlewareMixin()
    assert obj._future_middleware == []

# Generated at 2022-06-24 04:15:27.830896
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddlewareMixinMock(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    test = MiddlewareMixinMock()
    assert isinstance(test._future_middleware, list)
    assert test._future_middleware == []

# Generated at 2022-06-24 04:15:35.921253
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.server import HttpProtocol
    app = Sanic("test_MiddlewareMixin_middleware")

    # Test if the middleware is initialized well
    assert app._future_middleware == []

    # Test if the middleware is added well
    @app.middleware
    def middleware_test():
        return

    assert type(app._future_middleware[0]) == FutureMiddleware
    assert app._future_middleware[0].middleware == middleware_test
    assert app._future_middleware[0].attach_to == "request"
    
    # Test if the middleware can be added but not applied
    @app.middleware(apply=False)
    def middleware_test2():
        return

    assert type(app._future_middleware[1])

# Generated at 2022-06-24 04:15:47.068114
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            return middleware

    mm = TestMiddlewareMixin()

    def test_middleware(req):
        return req

    # partial function
    middleware_func = mm.on_request(test_middleware)
    middleware_object = mm.middleware(middleware_func)
    assert len(mm._future_middleware) == 1
    assert middleware_func == mm._future_middleware[0].middleware
    assert mm._future_middleware[0] == middleware_object

    # normal function
    middleware_func = mm.on_request()(test_middleware)
    middleware_object = mm.middleware(middleware_func)
    assert len(mm._future_middleware)

# Generated at 2022-06-24 04:15:51.468945
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Sample(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
    
    s = Sample()
    assert isinstance(s._future_middleware, list)
    assert len(s._future_middleware) == 0
