

# Generated at 2022-06-24 04:05:53.743995
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    import pytest

    app = Sanic()
    assert app._future_middleware == []
    middleware = 'fake'

    @app.middleware('request')
    def request(request):
        pass

    @app.middleware('response')
    def response(request, response):
        pass

    @app.middleware
    def just_middleware(a, b, c=None, d=None, e=None):
        pass

    assert len(app._future_middleware) == 3
    assert app._future_middleware[0].args == ()
    assert app._future_middleware[0].kwargs == {}
    assert isinstance(app._future_middleware[0].handler, partial)
    assert app._future_middleware[1].args == ()
    assert app

# Generated at 2022-06-24 04:05:57.438052
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class App(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    @App.on_request
    async def fn1(request):
        return True

    @App.on_request()
    async def fn2(request):
        return True

    app = App()
    assert len(app._future_middleware) == 2

# Generated at 2022-06-24 04:06:01.778524
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    obj = MiddlewareMixin()

    def middleware(request):
        raise RuntimeError("Invalid Middleware")

    # Without parameter
    assert type(obj.on_response()) is partial
    assert_raises(TypeError, obj.on_response)

    # With parameter
    assert_raises(RuntimeError, obj.on_response, middleware)

# Generated at 2022-06-24 04:06:03.633927
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    app = MiddlewareMixin()
    assert(isinstance(app._future_middleware, list))

# Generated at 2022-06-24 04:06:11.527957
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic

    app = Sanic("sanic-test")

    @app.middleware("response")
    async def response_middleware_a(request, response):
        pass

    @app.on_response
    async def response_middleware_b(request, response):
        pass

    assert len(app._future_middleware) == 2

# Generated at 2022-06-24 04:06:12.287091
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    pass


# Generated at 2022-06-24 04:06:15.937983
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Server(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass
        
    @Server.on_request()
    def middleware_func(request):
        pass

    assert Server._future_middleware[0].attach_to == "request"


# Generated at 2022-06-24 04:06:27.308772
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    obj = MiddlewareMixin()
    class Test:
        def __init__(self, *args, **kwargs):
            pass
        def __call__(self, middleware=None):
            if callable(middleware):
                return middleware, 'attach_to=response'
            else:
                return 'partial(self.middleware, attach_to=response)', middleware
    class TestMiddleWare:
        def __init__(self, *args, **kwargs):
            pass
        def attach_to(self, *args, **kwargs):
            return 'request'
    obj.middleware = Test()

    result = obj.on_response('request')
    assert [result[0]] == ['partial(self.middleware, attach_to=response)']
    assert [result[1]] == ['request']

   

# Generated at 2022-06-24 04:06:31.410228
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic(__name__)

    def middleware():
        pass

    # test return value of middleware with no parameter
    assert callable(app.middleware(middleware))
    # test return value of middleware with parameter
    assert callable(app.middleware(middleware))


# Generated at 2022-06-24 04:06:32.858864
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
  assert MiddlewareMixin.__init__(MiddlewareMixin, [], {}) == None

# Generated at 2022-06-24 04:06:35.145617
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    @MiddlewareMixin.on_request
    def test_request(request):
        return request
    assert test_request(1) == 1

# Generated at 2022-06-24 04:06:35.884013
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass

# Generated at 2022-06-24 04:06:46.957578
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.models.middleware import MiddlewareMixin
    class TestMiddlewareMixin(MiddlewareMixin):
        pass
    test_middleware_mixin = TestMiddlewareMixin()
    assert test_middleware_mixin._future_middleware == []
    @test_middleware_mixin.on_response()
    def response_callback(request):
        return None
    assert test_middleware_mixin._future_middleware != []
    assert test_middleware_mixin._future_middleware[-1].middleware_name == 'response_callback'
    assert test_middleware_mixin._future_middleware[-1].attach_to == 'response'
    

# Generated at 2022-06-24 04:06:48.517713
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    test_middleware_mixin = MiddlewareMixin()
    assert test_middleware_mixin is not None


# Generated at 2022-06-24 04:06:50.543929
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class App(MiddlewareMixin):
        def __init__(self):
            super(App, self).__init__()

    app = App()
    assert app._future_middleware == []


# Generated at 2022-06-24 04:06:53.316628
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Arrange
    class App(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass
    app = App()

    # Act
    middleware = app.on_request()

    # Assert
    middleware(None)

# Generated at 2022-06-24 04:06:55.863734
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    #pass
    request = 'POST'
    attach_to = 'request'
    apply = True
    middleware_or_request =1
    assert callable(middleware_or_request) != False
    #assert register_middleware(middleware_or_request, attach_to=attach_to)



# Generated at 2022-06-24 04:07:02.807171
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Request-response pairs are fixed
    input = [{'request': [{'initial': '0', 'final': '1'}], 'response': {'initial': '0', 'final': '2'}}]
    # Output from dummy middleware
    output = [{'request': [{'initial': '0', 'final': '1'}], 'response': {'initial': '0', 'final': '2'}}]

    class Base(MiddlewareMixin):
        def on_response(self, request, response):
            response['final'] = str(int(response['initial']) + 1)

    class MyMiddleware(Base):
        def on_response(self, request, response):
            response['initial'] = str(int(response['initial']) + 1)
            response['middleware'] = 'middleware'
           

# Generated at 2022-06-24 04:07:08.079510
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass

    @TestMiddlewareMixin.middleware
    def test_middleware(request):
        pass

    middleware = TestMiddlewareMixin._future_middleware[0]
    assert middleware.apply_async == test_middleware



# Generated at 2022-06-24 04:07:16.115359
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    path = ""
    method = ""
    handler = None
    uri = ""
    host = ""
    headers = {}
    version = (1, 1)
    transport = None
    protocols = []
    request = Request(path, method, handler, uri, host, headers, version, transport, protocols)
    class foo():
        def __init__(self, request):
            self.request = request
        @method
        def test_MiddlewareMixin_middleware(self):
            assert request.path == ""
            assert request.method == ""
            assert request.handler == None
            assert request.uri == ""
            assert request.host == ""
            assert request.headers == {}
            assert request.version == (1, 1)
            assert request.transport == None
            assert request.protocols == []

# Generated at 2022-06-24 04:07:19.316185
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    x = MiddlewareMixin()
    x.on_request()


# Generated at 2022-06-24 04:07:28.492205
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Test:
        def __init__(self):
            self._future_middleware: List[FutureMiddleware] = []
        
        def middleware(self, middleware_or_request, attach_to="request", apply=True):
            def register_middleware(middleware, attach_to="request"):
                nonlocal apply
                future_middleware = FutureMiddleware(middleware, attach_to)
                self._future_middleware.append(future_middleware)
                return middleware
            if callable(middleware_or_request):
                return register_middleware(middleware_or_request, attach_to=attach_to)
            else:
                return partial(register_middleware, attach_to=middleware_or_request)
        

# Generated at 2022-06-24 04:07:37.951977
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.models.middlewares import MiddlewareMixin

    class Test:
        def __init__(self):
            self._future_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    t = Test()
    t.on_response = MiddlewareMixin.on_response.__get__(t)
    @t.on_response
    def m1(request, response):
        pass
    m = t._future_middleware[0]
    assert m.attach_to == "response"
    assert (m.middleware is m1)

    @t.on_response()
    def m2(request, response):
        pass
    m = t._future_middleware[1]
    assert m.attach_to == "response"

# Generated at 2022-06-24 04:07:42.658726
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Given
    from sanic.app import Sanic

    app = Sanic(__name__)

    # When
    # Then
    assert app.middleware is not None


# Generated at 2022-06-24 04:07:45.098188
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Test(MiddlewareMixin):
        ...
    assert Test().on_response('bla')

# Generated at 2022-06-24 04:07:46.678805
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    test = MiddlewareMixin()
    assert test._future_middleware == []


# Generated at 2022-06-24 04:07:48.051179
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    app = MiddlewareMixin()
    pass


# Generated at 2022-06-24 04:07:56.215275
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.log import log

    import time

    app = Sanic("test_MiddlewareMixin")

    @app.middleware
    async def print_on_request(request):
        log.info("I happen on a request!")

    @app.middleware("response")
    async def halt_response(request, response):
        response.text = "HALT: " + response.text

    @app.route("/")
    async def handler(request):
        return response.text("Not Halted")

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.text == "HALT: Not Halted"
    # assert log.info.called

# Generated at 2022-06-24 04:07:57.566532
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    app = Sanic('Test')
    assert app._future_middleware == []

# Generated at 2022-06-24 04:08:00.939055
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddleware(MiddlewareMixin):
        pass
    test_mw = TestMiddleware()
    mw = test_mw.on_response(lambda request, response: response)
    test_request = object()
    test_response = object()
    assert mw(test_request, test_response) == test_response


# Generated at 2022-06-24 04:08:02.422779
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Server(MiddlewareMixin):
        pass

    server = Server()
    assert server._future_middleware == []

# Generated at 2022-06-24 04:08:05.367938
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response.__name__ == "on_response"
    m = MiddlewareMixin()
    fn = lambda req: req
    m.on_response(fn)
    assert m._future_middleware[-1].middleware == fn

# Generated at 2022-06-24 04:08:08.042178
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []

# Generated at 2022-06-24 04:08:14.778406
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    app = Sanic("helloWorld",log_config=False)
    assert len(app._future_middleware) == 0
    # test for request middleware
    @app.middleware('request')
    async def testMiddleware(request):
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "request"
    # test for response middleware
    @app.middleware('response')
    async def testMiddleware2(request, response):
        pass
    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].attach_to == "response"

# Generated at 2022-06-24 04:08:17.321901
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test')
    app.on_request(request_handler)
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-24 04:08:19.502183
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Application(MiddlewareMixin):
        pass
    app = Application()
    assert app._future_middleware == []


# Generated at 2022-06-24 04:08:29.610155
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MiddlewareMixinStub(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
            self._args = args
            self._kwargs = kwargs

        def _apply_middleware(self, middleware: FutureMiddleware):
            _ = middleware

    stub = MiddlewareMixinStub("arg1", arg2="kwarg2")

    assert callable(stub.on_request())
    assert stub.on_request()("middleware_func") == "middleware_func"

    stub.on_request("middleware_func")
    assert len(stub._future_middleware) == 1
    assert stub._future_middleware[0].middleware == "middleware_func"

# Generated at 2022-06-24 04:08:30.090833
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-24 04:08:35.590238
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """
    This is our unit test for method middleware of class MiddlewareMixin.
    """
    # creating an instance of MiddlewareMixin
    _middleware_mixin = MiddlewareMixin()


# Generated at 2022-06-24 04:08:39.030583
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Arrange
    args = ()
    kwargs = {}

    # Act
    obj = MiddlewareMixin(*args, **kwargs)

    # Assert
    assert obj._future_middleware == []


# Generated at 2022-06-24 04:08:42.330944
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Setup
    args = ()
    kwargs = {}

    # Exercise
    sut = MiddlewareMixin(*args, **kwargs)

    # Verify
    assert hasattr(sut, "on_response")

    # Cleanup - none necessary

# Generated at 2022-06-24 04:08:45.087886
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()

    # Test with valid args
    assert app.middleware(None)()

# Generated at 2022-06-24 04:08:55.069300
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # fake class Body
    class Body():
        def __init__(self):
            self.data = 0
            self.size = 0
            self.chunked = False

    class a:
        def b(self, middleware):
            self.x = middleware
    class c:
        def __init__(self):
            self.a = a
    # make an instance of class Body
    body = Body()
    # input
    data = {}
    # make an instance of class MiddlewareMixin
    MiddlewareMixin_instance = MiddlewareMixin()
    # check the parameters are valid
    middleware_or_request = 'request'
    assert MiddlewareMixin_instance.on_request(middleware_or_request)['attach_to'] == 'request'
    # check the return type is correct
    result_

# Generated at 2022-06-24 04:08:56.898389
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin.on_request("request") == partial(MiddlewareMixin.middleware,
                                                            attach_to="request")

# Generated at 2022-06-24 04:08:59.821541
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        pass

    test = TestMiddlewareMixin()
    assert test._future_middleware == []


# Generated at 2022-06-24 04:09:01.859848
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Sanic(MiddlewareMixin):
        pass

    s = Sanic()

    assert s._future_middleware == []

# Generated at 2022-06-24 04:09:03.852879
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()

    assert len(middleware_mixin._future_middleware) == 0


# Generated at 2022-06-24 04:09:12.869653
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Sanic(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self._future_middleware = []
            self.request = None
            self.response = None

        def _apply_middleware(self, middleware):
            if middleware.attach_to == "request":
                middleware.apply(self, self.request)
            elif middleware.attach_to == "response":
                middleware.apply(self, self.response)
                
    class Request:
        def __init__(self):
            self.args = None
            self.kwargs = None
            self.response = None
            self.next_middleware = None

    class Response:
        def __init__(self):
            self.name = None
            

# Generated at 2022-06-24 04:09:17.673408
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    # TODO: complete unit test for method middleware of class MiddlewareMixin


# Generated at 2022-06-24 04:09:27.286010
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    app = MiddlewareMixin()
    assert app._future_middleware == []

    # test _apply_middleware not implemented, noqa
    test_app = MiddlewareMixin()
    test_middleware = FutureMiddleware(None, 'request')
    with pytest.raises(NotImplementedError):
        test_app._apply_middleware(test_middleware)

    # test register_middleware
    test_app._apply_middleware = lambda x: None
    test_app.middleware(test_middleware, 'request', apply=True)
    assert test_app._future_middleware == [test_middleware]

    # test middleware
    test_app_2 = MiddlewareMixin()
    test_middleware_2 = FutureMiddleware(None, 'response')
    test_app_2._apply

# Generated at 2022-06-24 04:09:29.245180
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewaremixin = MiddlewareMixin()
    assert middlewaremixin._future_middleware == []



# Generated at 2022-06-24 04:09:37.526783
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import json
    from sanic.exceptions import NotFound

    app = Sanic()

    @app.on_response
    def add_header(request, response):
        response.headers["x_middleware"] = "true"

    @app.route("/")
    def handler(request):
        return json({"x": "y"})

    request, response = app.test_client.get("/")
    assert response.headers["x_middleware"] == "true"



# Generated at 2022-06-24 04:09:38.952944
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # 测试传参
    app = MiddlewareMixin("ok", 1, 2)
    assert app._future_middleware == []

# Generated at 2022-06-24 04:09:40.763842
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin._future_middleware == []

# Generated at 2022-06-24 04:09:50.750896
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    response_mock = Mock(name="response_mock", spec=["text"])
    request_mock = Mock(name="request_mock")
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            self._future_middleware: List[FutureMiddleware] = []
            super().__init__(*args, **kwargs)
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    test_middleware_mixin = TestMiddlewareMixin()
    on_response_middleware = test_middleware_mixin.on_response()
    on_response_func = on_response_middleware(Mock(name='on_response_func', spec=[]))

# Generated at 2022-06-24 04:09:54.918433
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic('test')

    @app.on_response
    async def response(request, response):
        print('on_response')

    print(app.middleware_info)
    assert app._future_middleware != []
    assert app._future_middleware[0].middleware_func == response
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-24 04:09:56.284996
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
  type_test=isinstance(MiddlewareMixin(),MiddlewareMixin)
  assert type_test


# Generated at 2022-06-24 04:10:01.378237
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.models.middleware import MiddlewareMixin
    
    s = MiddlewareMixin()
    f = s.on_response()
    
    

# Generated at 2022-06-24 04:10:06.750196
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_class=Test()

    test_class.middleware(middleware_or_request='reuqest')
    test_class.on_request(middleware='test')
    test_class.on_response(middleware='test')

# Generated at 2022-06-24 04:10:08.144799
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin().on_request() is not None

# Generated at 2022-06-24 04:10:15.571360
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    print("mm._future_middleware = ", mm._future_middleware)
    assert mm._future_middleware == []
    print("mm.middleware = ", mm.middleware)
    assert callable(mm.middleware)
    print("mm.on_request = ", mm.on_request)
    assert callable(mm.on_request)
    print("mm.on_response = ", mm.on_response)
    assert callable(mm.on_response)

# Generated at 2022-06-24 04:10:21.073559
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    """
    on_request method check
    """

    # Create object MiddlewareMixin
    middleware = MiddlewareMixin()

    # Call on_request with parameter
    on_request = middleware.on_request("request")

    # Check result
    assert callable(on_request)


# Generated at 2022-06-24 04:10:24.984278
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    """
    Test the method on_response of class MiddlewareMixin
    """
    def tmp_method():
        pass
    middleware_mixin = MiddlewareMixin()
    middleware_mixin.middleware = MagicMock()
    middleware_mixin.middleware.attach_to = 'response'
    assert middleware_mixin.on_response() == middleware_mixin.middleware


# Generated at 2022-06-24 04:10:28.312272
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    mm = MiddlewareMixin()
    assert mm.on_request("request")("request") == "request"



# Generated at 2022-06-24 04:10:38.335860
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    import sanic.models.futures as fs
    import sys
    import unittest
    from functools import partial

    super_MiddlewareMixin = MiddlewareMixin
    class MiddlewareMixin(super_MiddlewareMixin):
        pass

    class TestMiddlewareMixin(unittest.TestCase):
        def test_MiddlewareMixin(self):
            # Arrange
            # Nothing to arrange

            # Act
            test_obj = MiddlewareMixin()

            # Assert
            self.assertIsInstance(test_obj._future_middleware, list)
            self.assertEqual(len(test_obj._future_middleware), 0)

    ##########################################################
    # MiddlewareMixin.middleware method
    ##########################################################


# Generated at 2022-06-24 04:10:47.738536
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware("request")
    async def add_remote_addr(request):
        request["remote_addr"] = "127.0.0.1"

    @app.middleware("response")
    async def header_stuff(request, response):
        response.headers["Server"] = "Bob"
        response.headers["X-Parachutes"] = "parachutes are cool"

    @app.route("/")
    async def handler(request):
        return text("OK")

    @app.middleware("request")
    async def add_remote_addr2(request):
        request["remote_addr"] = "127.0.0.1"


# Generated at 2022-06-24 04:10:56.166379
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.exceptions import SanicException

    app = Sanic('test_MiddlewareMixin_on_response')
    called = [False]

    def simple_middleware(request):
        called[0] = True

    @app.middleware('response')
    def simple_middleware(request, response):
        called[0] = True

    app.on_response(simple_middleware)
    app.on_response(simple_middleware)


# Generated at 2022-06-24 04:10:58.370040
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    @MiddlewareMixin.on_request()
    def some() -> str:
        return 'some'

    @MiddlewareMixin.on_request
    def some() -> str:
        return 'some'

# Generated at 2022-06-24 04:11:06.803075
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.middleware import MiddlewareMixin
    from sanic.models.futures import FutureMiddleware
    from types import FunctionType
    
    app = MiddlewareMixin()
    @app.on_request
    def test_middleware(request):
        return request
    assert(isinstance(test_middleware, FunctionType))
    assert(len(app._future_middleware) == 1)
    assert(isinstance(app._future_middleware[0], FutureMiddleware))
    assert(app._future_middleware[0].attach_to == "request")


# Generated at 2022-06-24 04:11:07.894921
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    m.middleware(None, 'request')

# Generated at 2022-06-24 04:11:15.254341
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()
    @app.middleware
    async def level0_test(request):
        pass

    assert isinstance(app.middleware, MiddlewareMixin)
    assert app.middleware._apply_middleware(None) is None
    assert app.middleware._future_middleware == []
    assert callable(app.middleware)
    assert callable(app.middleware('request'))
    assert callable(app.middleware('request', apply = False))
    assert callable(app.middleware('response'))
    assert callable(app.middleware('response', apply = False))
    assert callable(app.on_request)
    assert callable(app.on_request(level0_test))
    assert callable(app.on_response)

# Generated at 2022-06-24 04:11:26.455377
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Testmodels(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.response = None
        def _apply_middleware(self, middleware):
            self.response = middleware.middleware(None)
    def my_middleware(request):
        return request

    test = Testmodels()
    # test.middleware(my_middleware)
    # The type of self._future_middleware is `List[FutureMiddleware]`
    # We can add elements to it without any problem.
    test._future_middleware.append(None)
    # The function _apply_middleware() is implemented in derived class
    # We can't call it using super()
    # test._apply_middleware(FutureMiddleware(my_

# Generated at 2022-06-24 04:11:32.365618
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Partition for boolean: True
    # Minimal coverage

    # Arrange
    mmx = MiddlewareMixin()

    # Act
    mmx.middleware(middleware_or_request='test')

    # Assert
    assert True == True # Don't know how to unit test this


# Generated at 2022-06-24 04:11:35.971632
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass


# Generated at 2022-06-24 04:11:44.221253
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    from sanic import response

    app = Sanic("test")

    # check if on_request is also a partial if no argument is provided
    assert callable(app.on_request)

    @app.middleware("request")
    def test_middleware(request):
        assert request is not None
        return

    @app.middleware
    def test_middleware_no_args(request):
        assert request is not None
        return

    @app.on_request
    def test_on_request(request):
        assert request is not None
        return

    @app.on_response
    def test_on_response_request(request, response):
        # also check on_response parameters
        assert request is not None
        assert response is not None
        return


# Generated at 2022-06-24 04:11:54.010771
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    import sanic
    app = sanic.Sanic()

    assert type(app._future_middleware) == list

    # Unit test for on_request function
    @app.on_request
    async def func_onrequest(request):
        msg = 'Hi func_onrequest'
        return msg

    """
    Equivalent code for test_onrequest and test_onresponse
    def func_onrequest(request):
        msg = 'Hi func_onrequest'
        return msg
    app.on_request(func_onrequest)
    """

    #Unit test for on_response function
    @app.on_response
    async def func_onresponse(request, response):
        msg = 'Hi func_onresponse'
        return msg


# Generated at 2022-06-24 04:11:58.595743
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class App(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    def some_middleware(request):
        pass

    app = App()
    app.on_request(some_middleware)


# Generated at 2022-06-24 04:12:03.618962
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic("test_app")

    @app.on_request
    def test_handler(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].handler == test_handler
    assert app._future_middleware[0].attach_to == "request"



# Generated at 2022-06-24 04:12:06.066818
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    a = MiddlewareMixin()
    assert isinstance(a, MiddlewareMixin)

if __name__ == "__main__":
    test_MiddlewareMixin()

# Generated at 2022-06-24 04:12:07.571032
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    assert mm._future_middleware, []

# Generated at 2022-06-24 04:12:14.373920
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MM(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()

        def _apply_middleware(self, middleware):
            pass


    @MM.on_request()
    def mw1(request):
        pass

    @MM.on_request
    def mw2(request):
        pass

    mm = MM()
    assert len(mm._future_middleware) == 2
    for fm in mm._future_middleware:
        assert fm.attach_to == "request"


# Generated at 2022-06-24 04:12:16.066669
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    _ = MiddlewareMixin.on_response


# Generated at 2022-06-24 04:12:23.800432
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_on_request')
    _call_log = []

    @app.middleware('request')
    async def add_log(request):
        _call_log.append('add_log')

        return

    @app.route('/')
    def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert 'add_log' in _call_log
    assert response.status == 200



# Generated at 2022-06-24 04:12:30.407025
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MyClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_middleware = []
            self._apply_middleware = lambda fm: fm

    obj = MyClass()

    @obj.on_request
    def middleware(request):
        pass

    assert len(obj._future_middleware) == 1
    assert obj._future_middleware[0].middleware == middleware
    assert obj._future_middleware[0].attach_to == "request"


# Generated at 2022-06-24 04:12:37.464269
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MyMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

    mixin = MyMiddlewareMixin()
    request = None
    assert mixin.on_request() == partial(mixin.middleware, attach_to="request")
    assert mixin.on_request(request) == partial(mixin.middleware, attach_to=None)
    assert callable(mixin.on_request())
    assert callable(mixin.on_request(request))


# Generated at 2022-06-24 04:12:41.379506
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.log import logger
    app = Sanic('test_app')

    logger.info(app._future_middleware) # []
    assert app._future_middleware == []


# Generated at 2022-06-24 04:12:47.052530
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class App(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    mw = MagicMock()
    app = App()
    app.on_request(middleware=mw)
    assert(app._future_middleware[0].middleware == mw)

# Generated at 2022-06-24 04:12:48.475559
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class SanicApp(MiddlewareMixin):
        def __init__(self):
            sup

# Generated at 2022-06-24 04:12:49.933478
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    objClass = MiddlewareMixin()
    return 


# Generated at 2022-06-24 04:12:57.634759
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass

    app = TestMiddlewareMixin()

    def middleware(app, request, handler):
        pass

    # middleware(app, request, handler)
    # app.middleware(middleware)
    # app.middleware('request')(middleware)
    # app.middleware('response')(middleware)
    # app.on_request(middleware)
    # app.on_response(middleware)

# Generated at 2022-06-24 04:13:04.809066
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    import asyncio

    async def create_app():
        app = Sanic()

        @app.on_request
        async def on_request_middleware(request):
            return request

        @app.on_response
        async def on_response_middleware(request, response):
            return response

        @app.route("/")
        async def index(request):
            return response.text("Instructor")

        return app

    app = create_app
    request, response = app.test_client.get('/')
    assert response.text == "Instructor"

# Generated at 2022-06-24 04:13:11.532151
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import sanic
    app = sanic.Sanic()
    foo_middleware = lambda request: 'foo'
    app.middleware(foo_middleware, 'request')
    app.build_middleware_stack()

    assert foo_middleware in app.request_middleware
    assert foo_middleware not in app.response_middleware


# Generated at 2022-06-24 04:13:22.180940
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic("sanic-middleware")

    @app.middleware("response")
    async def add_server_header(request, response):
        response.headers["Server"] = "Fake-Server"

    @app.listener("before_server_start")
    async def add_version_header(app, loop):
        @app.middleware("response")
        async def add_version_header(request, response):
            response.headers["Version"] = "8.8.8"

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.headers.get("Server") == "Fake-Server"

# Generated at 2022-06-24 04:13:24.353264
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin().on_response() is not None
    assert MiddlewareMixin().on_response() is not None
    return True


# Generated at 2022-06-24 04:13:30.059853
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import sanic
    """
    Test middleware of class MiddlewareMixin
    """
    @sanic.response.html("index.html")
    async def get_index(request):
        return request
    print("\nUnit test for method middleware of class MiddlewareMixin")
    M = MiddlewareMixin()
    result = M.middleware(get_index)
    print("Result:\n", result)
    assert result == get_index


# Generated at 2022-06-24 04:13:31.862418
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    app = Sanic('test')
    assert app._future_middleware == []


# Generated at 2022-06-24 04:13:33.019419
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert True



# Generated at 2022-06-24 04:13:34.978333
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
  testInstance = MiddlewareMixin()
  assert testInstance.middleware(1, 'response') is not None

# Generated at 2022-06-24 04:13:37.350568
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # GIVEN
    given = MiddlewareMixin()

    # THEN
    assert given._future_middleware == []



# Generated at 2022-06-24 04:13:44.796712
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()

    @app.middleware
    async def handler(request):
        return request

    # Testing the return value of the method
    expected = '<function MiddlewareMixin.middleware.<locals>.register_middleware at 0x7f14616a4a60>'
    assert str(app.middleware) == expected

    # Testing the value of the attribute self._future_middleware
    assert app._future_middleware == [FutureMiddleware(handler, 'request')]

# Generated at 2022-06-24 04:13:48.001420
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    m = MiddlewareMixin()
    assert m.on_response(middleware=1) == 1
    assert callable(m.on_response())
    assert callable(m.on_response(1))

# Generated at 2022-06-24 04:13:50.809114
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('test_sanic_MiddlewareMixin_middleware')
    assert 'middleware' in dir(app)
    # TODO: More asserts


# Generated at 2022-06-24 04:13:53.567487
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []



# Generated at 2022-06-24 04:13:55.836653
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    obj=MiddlewareMixin()
    assert isinstance(obj._future_middleware, List)


# Generated at 2022-06-24 04:13:58.717840
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic(__name__)

    middleware = object()
    result = app.on_request(middleware)
    assert result == middleware
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-24 04:14:03.791506
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    def fake_middleware(request):
        return request
    
    app.on_response(fake_middleware)
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == fake_middleware
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-24 04:14:14.893743
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MyMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware):
            pass
    
    import asyncio
    async def on_request(request):
        return request
    async def on_response(request, response):
        return response

    my_middleware_mixin = MyMiddlewareMixin()
    on_request_middleware = my_middleware_mixin.on_request(on_request)
    on_response_middleware = my_middleware_mixin.on_response(on_response)

    assert on_request_middleware == on_request
    assert on_response_middleware == on_response



# Generated at 2022-06-24 04:14:17.716105
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Test if the constructor of class MiddlewareMixin works
    mixin = MiddlewareMixin()
    assert isinstance(mixin._future_middleware, list)
    assert len(mixin._future_middleware) == 0

# Generated at 2022-06-24 04:14:20.550719
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddlewareMixinTest(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
      
    MiddlewareMixinTest()

# Generated at 2022-06-24 04:14:21.828328
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()

# Generated at 2022-06-24 04:14:26.493176
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic("test_MiddlewareMixin_middleware")
    app.middleware("response")(lambda x: None)
    assert app._future_middleware[0].attach_to == "response"
    assert callable(app._future_middleware[0].middleware)
    

# Generated at 2022-06-24 04:14:37.446632
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic()

    @app.middleware
    async def test_middleware(request):
        """
        Modify the incoming request
        """
        request["test"] = "test"
        request["app"] = "app"

    @app.middleware('request')
    async def test_request_middleware1(request):
        """
        Modify the incoming request
        """
        request["test"] = "test1"

    @app.middleware('request')
    async def test_request_middleware2(request):
        """
        Modify the incoming request
        """
        request["test"] = "test2"


# Generated at 2022-06-24 04:14:42.623997
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    obj = MiddlewareMixin()
    # Step 1. Call on_response method with middleware defined and check.
    m1 = obj.on_response(middleware='m1')
    assert m1().attach_to == "response"
    # Step 2. Call on_response method with middleware not defined and check.
    m2 = obj.on_response
    assert m2(middleware='m2')()().attach_to == "response"

# Generated at 2022-06-24 04:14:48.443801
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import json

    app = Sanic('test_MiddlewareMixin_on_response')

    @app.route('/')
    async def handler(request):
        return json({'test': 'OK'}, headers={'X-From-Sanic': 'OK'})

    @app.middleware('response')
    async def print_on_response(request, response):
        print('Middleware response')
        response.headers['X-From-Middleware'] = 'OK'

    request, response = app.test_client.get('/')

    assert response.headers['X-From-Middleware'] == 'OK'
    assert response.headers['X-From-Sanic'] == 'OK'
    assert "print('Middleware response')" in str(print_on_response)


# Generated at 2022-06-24 04:14:53.623075
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin._apply_middleware(MiddlewareMixin, FutureMiddleware) == NotImplementedError  # noqa
    assert MiddlewareMixin.on_request(MiddlewareMixin) == NotImplementedError  # noqa
    assert MiddlewareMixin.on_response(MiddlewareMixin) == NotImplementedError  # noqa

# Generated at 2022-06-24 04:14:56.537917
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic('test_app')
    assert app.on_request(middleware="request")


# Generated at 2022-06-24 04:15:02.958141
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    assert m.on_request() == m.on_request()
    assert m.on_request(None) == m.on_request(None)

    def test_middlware(middlware):
        pass
    m.on_request(test_middlware)
    assert type(m.on_request(test_middlware)) == types.FunctionType
    assert m.on_request(test_middlware) == partial(m.middleware, attach_to='request')
    assert m.on_request(test_middlware)("test")() == "test"


# Generated at 2022-06-24 04:15:04.491012
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass


# Generated at 2022-06-24 04:15:12.676156
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Serv(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    serv = Serv()

    @serv.middleware('request')
    async def middleware_request(req):
        pass

    assert serv._future_middleware[0].middleware == middleware_request
    assert serv._future_middleware[0].attach_to == 'request'

    @serv.middleware
    async def middleware_response(req):
        pass

    assert serv._future_middleware[1].middleware == middleware_response
    assert serv._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-24 04:15:18.673973
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()

    assert not app.__dict__.get("_future_middleware")

    @app.middleware
    def midleware(request):
        pass

    @app.middleware('request')
    def midleware2(request):
        pass

    assert len(app._future_middleware) == 2

# Generated at 2022-06-24 04:15:24.978142
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    """
    Unit test for method on_response of class MiddlewareMixin
    """

    class TestMiddleware(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    l = []
    m = TestMiddleware()
    m.on_response(lambda x, y: l.append(x))
    m.on_response(lambda x, y: x.append(3))(l)
    assert l == [3]

# Generated at 2022-06-24 04:15:29.197869
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddlewareMixinTest(MiddlewareMixin):
        pass
    mixin = MiddlewareMixinTest()
    assert isinstance(mixin, MiddlewareMixin)



# Generated at 2022-06-24 04:15:32.267290
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = MiddlewareMixin()
    @app.on_request()
    async def on_request(request):
        print("request: ", request)

    print("app.on_request(): ", app.on_request)


# Generated at 2022-06-24 04:15:44.335065
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.server import HttpProtocol
    from sanic.response import json
    from sanic.testing import HOST, PORT
    from sanic.app import Sanic

    app = Sanic(__name__)

    @app.route("/")
    def handler(request):
        return json({"test": True})

    @app.middleware("response")
    def handler_middleware(request, response):
        response.headers["test"] = "testing"

    @app.on_response
    def on_response_handler(request, response):
        response.headers["test"] = "testing on response"

    loop = asyncio.get_event_loop()