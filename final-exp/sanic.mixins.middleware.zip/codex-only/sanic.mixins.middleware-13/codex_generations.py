

# Generated at 2022-06-24 04:05:56.515413
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin._future_middleware == []

# Generated at 2022-06-24 04:05:57.485972
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # TODO
    pass


# Generated at 2022-06-24 04:06:01.382846
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    obj = MiddlewareMixin()
    assert isinstance(obj, MiddlewareMixin)


# Generated at 2022-06-24 04:06:06.431114
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    assert app.middleware.__func__.__name__ == "register_middleware"
    assert app.on_request.__func__.__name__ == "on_request"
    assert app.on_response.__func__.__name__ == "on_response"

# Generated at 2022-06-24 04:06:09.946454
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    test_MiddlewareMixin = MiddlewareMixin()
    def test_func():
        pass
    result = test_MiddlewareMixin.on_response(test_func)
    assert result == test_func
    result = test_MiddlewareMixin.on_response()
    assert callable(result)

# Generated at 2022-06-24 04:06:12.503158
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MixIn(MiddlewareMixin):
        pass
    x = MixIn()
    assert x._future_middleware == []

# Generated at 2022-06-24 04:06:23.830185
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.futures import FutureMiddleware
    from sanic.models.server import Server
    from sanic.config.server import ServerConfig
    import json

    class test_MiddlewareMixin_on_request_MiddlewareMixin(MiddlewareMixin):
        def __init__(self, *arg, **kwargs):
            super().__init__(*arg, **kwargs)


    class test_MiddlewareMixin_on_request_Server(Server):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        async def request_middleware(self, request):
            return await request

        async def response_middleware(self, request, response):
            return await response


# Generated at 2022-06-24 04:06:29.516457
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def on_request(self, middleware=None):
            if callable(middleware):
                return self.middleware(middleware, "request")
            else:
                return partial(self.middleware, attach_to="request")
    test = TestMiddlewareMixin()

    assert(not test.on_request())


# Generated at 2022-06-24 04:06:34.498987
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():

    class TestMiddlewareMixin(MiddlewareMixin):
        pass

    middleware_mixin = TestMiddlewareMixin()

    def middlewre_fnc(request, response):
        return response

    middleware_mixin.on_response(middlewre_fnc)
    assert len(middleware_mixin._future_middleware) == 1

# Generated at 2022-06-24 04:06:39.472394
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()

    test_instance = TestMiddlewareMixin()
    assert test_instance._future_middleware == []


# Generated at 2022-06-24 04:06:46.787513
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_unit')
    converted_app = MiddlewareMixin()
    # test 1: middleware is callable
    def middleware():
        return "test middleware"
    assert converted_app.on_response(middleware) == middleware
    # test 2: middleware is not callable
    assert converted_app.on_response() == partial(converted_app.middleware, attach_to="response")



# Generated at 2022-06-24 04:06:49.118370
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    """
    This is a unit test for initializing the MiddlewareMixin class
    """
    from sanic.app import Sanic

    app=MiddlewareMixin()

    assert app._future_middleware == []
    assert isinstance(app, Sanic)

# Generated at 2022-06-24 04:06:56.146674
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = MiddlewareMixin()

    # callable
    # on_request(middleware)
    @app.on_request
    def on_request():
        pass
    assert app._future_middleware[0].attach_to == 'request'

    # not callable
    # on_request(middleware)
    @app.on_request(attach_to="response")
    def on_response():
        pass
    assert app._future_middleware[1].attach_to == 'response'

    # not callable
    # on_request()
    @app.on_request()
    def on_response():
        pass
    assert app._future_middleware[2].attach_to == 'request'



# Generated at 2022-06-24 04:06:58.536048
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert True == False


# Generated at 2022-06-24 04:07:02.971246
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from unittest.mock import Mock
    app = Mock()
    app.middleware = MiddlewareMixin.middleware
    app.on_response = MiddlewareMixin.on_response
    mw = Mock()
    assert app.on_response()(mw) == app.middleware()(mw)

# Generated at 2022-06-24 04:07:12.808213
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestClass_MiddlewareMixin_middleware(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self.middleware_counter = 0
            self.middleware_attach_to_counter = 0

        def _apply_middleware(self, future_middleware):
            self.middleware_counter += 1
            if future_middleware.attach_to == 'request':
                self.middleware_attach_to_counter += 1

    test_instance = TestClass_MiddlewareMixin_middleware()
    test_instance.middleware(lambda request: None)
    assert test_instance.middleware_counter == 1
    assert test_instance.middleware_attach_to_counter == 1
    test_instance.middleware(lambda request: None, attach_to='request')
    assert test

# Generated at 2022-06-24 04:07:15.706405
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin.on_request.__name__ == 'on_request'

# Generated at 2022-06-24 04:07:26.343126
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # 1. Arrange
    from sanic.utils import get_function_name
    from sanic.request import Request
    from sanic import Sanic

    app = Sanic()

    app.request_middleware = []
    app.response_middleware = []

    # 2. Act
    @app.middleware('response')
    async def response_middleware(request, response):
        app.response_middleware.append(
            get_function_name(response_middleware))

    @app.middleware
    async def request_middleware(request):
        app.request_middleware.append(get_function_name(request_middleware))

    @app.route('/')
    async def handler(request):
        return text('OK')

    # 3. Assert

# Generated at 2022-06-24 04:07:35.482078
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # create a MiddlewareMixin object and a middleware object
    mixin = MiddlewareMixin()
    middleware = lambda x: x

    # register the middleware to middleware list of MiddlewareMixin object
    mixin.middleware(middleware)
    # check the size of middleware list
    assert len(mixin._future_middleware) == 1

    # create a second MiddlewareMixin object
    mixin2 = MiddlewareMixin()
    # register the middleware to middleware list of Second MiddlewareMixin object
    mixin2.middleware(middleware, "request")
    # check the size of middleware list
    assert len(mixin2._future_middleware) == 1

    # create a third MiddlewareMixin object
    mixin3 = MiddlewareMixin()

    # create a partial object
    partial

# Generated at 2022-06-24 04:07:44.293925
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Function to test and functions which can be called in this function
    def func_to_test():
        return 1

    def func_to_call_inside_test(middleware=None):
        if callable(middleware):
            return middleware
        else:
            return True

    # MiddlewareMixin object
    middleware_mixin = MiddlewareMixin()
    middleware_mixin.middleware = func_to_call_inside_test

    # Check
    assert middleware_mixin.on_request() == True
    assert middleware_mixin.on_request(func_to_test) == func_to_test

# Generated at 2022-06-24 04:07:47.144374
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from unittest.mock import Mock
    from sanic.server import Sanic
    app = Sanic()
    app.on_response(Mock())
    assert len(app._future_middleware) == 1

# Generated at 2022-06-24 04:07:51.621424
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_on_request')

    @app.on_request
    def handler_middleware(request):
        return text('OK')

    @app.route('/')
    def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'OK'


# Generated at 2022-06-24 04:07:59.695099
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(TestMiddlewareMixin,self).__init__()
            self._future_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            return self._future_middleware.append(middleware)

        def test_on_request(self):
            return self.middleware(None, "request")

        def test_on_response(self):
            return self.middleware(None, "response")

        def test_on_request_middleware(self, middleware=None):
            return self.middleware(middleware, "request")


# Generated at 2022-06-24 04:08:05.415179
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixin_Test(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    instance = MiddlewareMixin_Test()
    instance.middleware('AT')
    len(instance._future_middleware).should.equal(0)
    instance.middleware('AT')(lambda: 'middleware')
    len(instance._future_middleware).should.equal(1)
    instance._future_middleware[0].middleware().should.equal('middleware')
    instance._future_middleware[0].attach_to().should.equal('AT')


# Generated at 2022-06-24 04:08:14.023554
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
        
        def _apply_middleware(self, middleware: FutureMiddleware):
            self._request_middleware.append(middleware)

    mixin = TestMiddlewareMixin()
    mixin.middleware(middleware)
    mixin.middleware(middleware, attach_to="request")
    mixin.middleware(middleware, attach_to="response")
    mixin.on_request(middleware)
    mixin.on_response(middleware)

    assert len(mixin._future_middleware) == 5



# Generated at 2022-06-24 04:08:17.006131
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    mm.middleware(middleware_or_request="request")
    mm.middleware(middleware_or_request="response")
    mm.on_request(middleware=None)
    mm.on_response(middleware=None)

# Generated at 2022-06-24 04:08:24.707618
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Create a mock class to test
    class MockClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    
    # Create a mock function
    def mock_func(request, *args, **kwargs):
        pass
    
    # Create an instance of class MockClass and call method middleware
    instance_MockClass = MockClass()
    assert instance_MockClass.middleware == MiddlewareMixin.middleware
    assert instance_MockClass.middleware(mock_func) == mock_func


# Generated at 2022-06-24 04:08:28.468571
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def test_middleware(request):
        pass
    
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-24 04:08:38.299590
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.middleware
    def mw(request):
        pass
    @app.listener('before_server_start')
    def before_server_start(sanic, loop):
        pass
    @app.listener('after_server_start')
    def after_server_start(sanic, loop):
        pass
    @app.listener('before_server_stop')
    def before_server_stop(sanic, loop):
        pass
    @app.listener('after_server_stop')
    def after_server_stop(sanic, loop):
        pass

# Generated at 2022-06-24 04:08:43.944713
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    print ("Test unit test function for on_response method of class MiddlewareMixin")
    app = Sanic('test_on_response')
    test_middleware = lambda request, response: response
    app.on_response(test_middleware)
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-24 04:08:54.182384
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    def test_func(request):
        return {'text': 'testing the middleware'}

    app = Sanic('test_MiddlewareMixin_middleware')
    app.add_route(test_func, '/')

    # test with attach_to = request
    @app.middleware('request')
    async def request_middleware(request):
        request['data'] = {}

    # test with attach_to = response
    @app.middleware('response')
    async def response_middleware(request, response):
        response.text = 'hello world'

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'hello world'
    assert request.get('data') == {}



# Generated at 2022-06-24 04:09:00.011665
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()
    app.middleware('request_fixture')(lambda: 'response_fixture')
    assert app._future_middleware[0].middleware == 'request_fixture'
    assert app._future_middleware[0].attach_to == 'request'
    app.middleware('response_fixture')(lambda: 'response_fixture')
    assert app._future_middleware[1].middleware == 'response_fixture'
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-24 04:09:02.821162
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
	# Arrange
	TestMiddlewareMixin = MiddlewareMixin()

	# Act
	# Assert
	assert TestMiddlewareMixin._future_middleware == []

# Generated at 2022-06-24 04:09:12.966300
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.models import MiddlewareMixin
    from sanic.models.futures import FutureMiddleware

    # Create an instance of class MiddlewareMixin
    mixin = MiddlewareMixin()

    # Create a simple function
    function_A = "funcA"
    function_B = "funcB"

    result_list = []

    # Test default
    result = mixin.on_response(function_A)
    result_list.append(result)

    # Test invalid parameter
    try:
        mixin.on_response(None)
    except TypeError:
        result_list.append(True)
    else:
        result_list.append(False)

    # Test normal case
    result = mixin.on_response(function_B)
    result_list.append(result)

    # Test identity

# Generated at 2022-06-24 04:09:16.771474
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    self = MiddlewareMixin()
    self._future_middleware = []
    assert self._future_middleware == []
    self.middleware(middleware_or_request='response')
    assert len(self._future_middleware) == 1
    print("test MiddlewareMixin.on_response() passed")


# Generated at 2022-06-24 04:09:18.322949
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert False



# Generated at 2022-06-24 04:09:25.837288
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import asyncio

    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.middleware_dict: dict = dict()

        def _apply_middleware(self, middleware : FutureMiddleware):
            self.middleware_dict[middleware.attach_to] = middleware

    async def middleware_request(): pass
    async def middleware_response(): pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_request(middleware_request)
    test_middleware_mixin.on_response(middleware_response)

    assert test_middleware_mixin.middleware_dict['request'].middleware == middleware

# Generated at 2022-06-24 04:09:28.499773
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddlewareMixinTest(MiddlewareMixin):
        def __init__(self):
            super().__init__()

    m = MiddlewareMixinTest()
    assert isinstance(m, MiddlewareMixin)


# Generated at 2022-06-24 04:09:29.099282
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass

# Generated at 2022-06-24 04:09:40.656580
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    class Base:
        def __init__(self):
            self._future_middleware: List[FutureMiddleware] = []

    class Middleware(MiddlewareMixin, Base):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            return middleware

    middleware_obj = Middleware()
    future_middleware = FutureMiddleware(middleware_or_request="",
                                         attach_to="request")
    future_middleware2 = FutureMiddleware(middleware_or_request="",
                                          attach_to="response")

    # Check the return value of method middleware

# Generated at 2022-06-24 04:09:47.101907
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.exceptions import RequestTimeout
    try:
        # default middleware_or_request
        m = MiddlewareMixin()
        @m.middleware
        def test():
            print("test middleware")
            print(m._future_middleware)
            if any(isinstance(x, RequestTimeout) for x in m._future_middleware):
                print("haha")

    except Exception as e:
        print(e)

# Generated at 2022-06-24 04:09:52.022420
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    sanic = Sanic('test')
    sanic.on_response(lambda request,response: response.json())

# Generated at 2022-06-24 04:09:53.174692
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert isinstance(MiddlewareMixin, MiddlewareMixin)


# Generated at 2022-06-24 04:09:54.279157
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    test = MiddlewareMixin()
    assert isinstance(test, MiddlewareMixin)

# Generated at 2022-06-24 04:10:00.280629
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Application(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_middleware = []
            self._middleware = []

        def _apply_middleware(self, middleware):
            self._middleware.append(middleware)

    app = Application()
    @app.on_request()
    def request_1():
        pass
    # Assert that _middleware is not empty
    assert len(app._middleware) == 1
    assert app._middleware[0].middleware == request_1
    assert app._middleware[0].attach_to == "request"
    @app.on_request(attach_to="response")
    def request_2():
        pass
    # Assert that _middleware

# Generated at 2022-06-24 04:10:04.574737
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    try:
        assert type(MiddlewareMixin.on_response) == types.FunctionType
    except AssertionError:
        print("AssertionError: ", MiddlewareMixin.on_response)
    except Exception as error:
        print("An exception has occurred: " + str(error))


# Generated at 2022-06-24 04:10:11.437123
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = Configurable()
    app.config.MIDDLEWARE = []
    MiddlewareMixin.middleware(app, apply=False)
    MiddlewareMixin.middleware(app, attach_to='response', apply=False)
    MiddlewareMixin.middleware(app, attach_to='request', apply=False)
    MiddlewareMixin.middleware(app, attach_to='wrong', apply=False)
    print(app.config.MIDDLEWARE) # output: []


# Generated at 2022-06-24 04:10:13.979039
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    result = middleware_mixin.middleware(middleware_or_request = "request")
    assert callable(result) == True

# Generated at 2022-06-24 04:10:14.753142
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass

# Generated at 2022-06-24 04:10:17.657252
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Call initialization method
    middleware_mixin = MiddlewareMixin()
    # Check if all attributes have the correct values
    assert middleware_mixin._future_middleware == []


# Generated at 2022-06-24 04:10:23.200473
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import sanic.server
    
    server = sanic.server.SanicServer()
    # check the type of sanic.server.SanicServer.on_request(sanic.request_middleware.RequestRewriteMiddleware)
    server.on_request(sanic.request_middleware.RequestRewriteMiddleware).__name__ == "RequestRewriteMiddleware"
    # check the type of sanic.server.SanicServer.on_request()
    server.on_request().__name__ == "partial"

# Generated at 2022-06-24 04:10:24.229402
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    a = MiddlewareMixin()

# Generated at 2022-06-24 04:10:26.433935
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # We cannot test this method because it uses decorator
    pass


# Generated at 2022-06-24 04:10:29.027906
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Prepare
    mixin = MiddlewareMixin()

    # Assert
    assert isinstance(mixin, MiddlewareMixin)


# Generated at 2022-06-24 04:10:33.034702
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin')
    app._future_middleware = []
    assert app._future_middleware == []


# Generated at 2022-06-24 04:10:34.015148
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin.on_request

# Generated at 2022-06-24 04:10:36.476115
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class middlewareMixin(MiddlewareMixin):
        def __init__(self):
            super(MiddlewareMixin).__init__()
    middlewareMixin()

# Generated at 2022-06-24 04:10:39.434275
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class A():
        def __init__(self):
            self._future_middleware: List[FutureMiddleware] = []

    a=A()
    assert a._future_middleware==[]

# Generated at 2022-06-24 04:10:42.871819
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class _async_:
        async def __aenter__():
            pass
        async def __aexit__():
            pass

    async def _await_():
        pass

    @MiddlewareMixin.middleware("request")
    def m1():
        pass


# Generated at 2022-06-24 04:10:49.243464
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Test without parameter
    def test_method1():
        assert True
    obj = MiddlewareMixin()
    obj.on_response(test_method1)
    assert obj._future_middleware[0].middleware(1, 2) == None

    # Test with parameter
    def test_method2(a):
        assert True
    obj1 = MiddlewareMixin()
    obj1.on_response(test_method2(1))
    assert obj1._future_middleware[1].middleware(1, 2) == None


# Generated at 2022-06-24 04:10:53.048770
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    app = Sanic()
    assert hasattr(app, '_future_middleware')
    assert isinstance(app._future_middleware, list)

# Generated at 2022-06-24 04:11:00.465024
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic('test_on_response')

    async def middleware(request):
        return request

    @app.middleware
    async def middleware_2(request):
        return request

    @app.middleware(apply=False)
    async def middleware_3(request):
        return request

    @app.on_request
    async def middleware_4(request):
        return request

    @app.on_response
    async def middleware_5(request, response):
        return response

    assert len(app._future_middleware) == 5
    assert app._future_middleware[0].__dict__ == {
        "apply": True,
        "type": "request",
        "middleware": middleware
    }

# Generated at 2022-06-24 04:11:02.784968
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    @app.middleware
    def cors():
        return None
    assert app.middlewares[0].middleware == cors


# Generated at 2022-06-24 04:11:06.535905
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()

    @app.middleware
    async def test(req):
        pass

    print (app._future_middleware)
    for i in app._future_middleware:
        if i.middleware == test:
            print (i.attach_to)


# Generated at 2022-06-24 04:11:08.248321
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.models.middleware import MiddlewareMixin
    m = MiddlewareMixin()
    assert m._future_middleware == []

# Generated at 2022-06-24 04:11:09.332144
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
  mm1 = MiddlewareMixin()
  assert mm1._future_middleware == []

# Generated at 2022-06-24 04:11:11.327493
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    flag = middleware_mixin_obj._future_middleware
    flag.append(FutureMiddleware)
    assert isinstance(flag,list)


# Generated at 2022-06-24 04:11:12.693941
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # The function test_MiddlewareMixin_on_response doesn\'t do anything.
    assert True

# Generated at 2022-06-24 04:11:17.661607
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    try:
        class test(MiddlewareMixin):
            pass
        assert hasattr(test, 'on_response')
    except AssertionError as e:
        print('test_MiddlewareMixin_on_response')
        print(e)


# Generated at 2022-06-24 04:11:26.294890
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView

    class SimpleView(HTTPMethodView):
        def get(self, request):
            return HTTPResponse("works")

    class AttachWhereTestMiddleware:
        def __init__(self, attach_where):
            self.attach_where = attach_where

        async def request(self, request):
            request["test"] = "test"

        async def response(self, request, response):
            response.headers["test"] = "test"

    app = Sanic("test_MiddlewareMixin_middleware")
    app.add_route(SimpleView.as_view(), "/")


# Generated at 2022-06-24 04:11:29.183632
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response()

# Generated at 2022-06-24 04:11:39.377345
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic("test_MiddlewareMixin_middleware")
    @app.route("/")
    def handler(request):
        return text("OK")

    @app.middleware("request")
    async def request_middleware_1(request):
        request["test"] = 1
        return request

    @app.middleware("request")
    async def request_middleware_2(request):
        assert request["test"] == 1
        return request

    @app.middleware("response")
    async def response_middleware_1(request, response):
        assert request["test"] == 1
        response.text = "OK"
        return response


# Generated at 2022-06-24 04:11:44.934223
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin = MiddlewareMixin()
    assert mixin._future_middleware == []
    assert mixin._apply_middleware(FutureMiddleware) == NotImplementedError
    assert callable(mixin.middleware)
    assert callable(mixin.on_request)
    assert callable(mixin.on_response)


# Generated at 2022-06-24 04:11:48.633779
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test')
    assert app.on_request

# Generated at 2022-06-24 04:11:50.402597
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import sanic
    app = MiddlewareMixin()
    app.on_response(middleware='request')

# Generated at 2022-06-24 04:11:58.325911
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware):
            pass

    test_middlewaremixin = TestMiddlewareMixin()
    test_middleware = lambda request: None
    test_middlewaremixin.middleware(test_middleware)
    test_middlewaremixin.middleware(test_middleware, 'response')
    test_middlewaremixin.on_response(test_middleware)
    test_middlewaremixin.on_request(test_middleware)


# Generated at 2022-06-24 04:12:07.725822
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareTest(MiddlewareMixin):
        def __init__(self):
            super(MiddlewareTest, self).__init__()

        def middleware(self, middleware_or_request, attach_to):
            return super(MiddlewareTest, self).middleware(middleware_or_request, attach_to)

        def _apply_middleware(self, middleware: FutureMiddleware):
            return middleware

    def dummy():
        pass

    obj = MiddlewareTest()
    assert isinstance(obj.middleware(dummy), FutureMiddleware) == True
    assert isinstance(obj.middleware(dummy, attach_to="request"), FutureMiddleware) == True
    assert isinstance(obj.middleware(attach_to="request")(dummy), FutureMiddleware) == True

# Generated at 2022-06-24 04:12:08.499499
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass



# Generated at 2022-06-24 04:12:13.355849
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.request import Request

    def middleware_function(req: Request):
        assert isinstance(req, Request)
        return req

    assert hasattr(Sanic(), 'on_request'), "Sanic does not have on_request"
    s = Sanic()
    # should not raise exception
    assert middleware_function == s.on_request(middleware_function), 'Middleware was not properly added'


# Generated at 2022-06-24 04:12:15.987544
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic(__name__)
    def hello_world(request):
        return text('Hello World!')

    @app.route('/')
    async def test(request):
        pass

    # the value of variable is None
    assert app.on_response()(hello_world) != None

# Generated at 2022-06-24 04:12:20.960344
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddlewareMixinTest(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    MiddlewareMixinTest()._future_middleware

# Generated at 2022-06-24 04:12:23.568309
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    def middleware(request):
        return request
    middleware_obj = MiddlewareMixin()
    response = middleware_obj.on_response(middleware)
    print(response)

# Generated at 2022-06-24 04:12:25.854100
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    app = Sanic()
    MiddlewareMixin(app)
    assert(app._future_middleware.__class__ is list)

# Generated at 2022-06-24 04:12:26.489315
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass


# Generated at 2022-06-24 04:12:35.486767
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class SanicFake:
        def __init__(self, *args, **kwargs):
            self.called = False
            self._future_middleware = []
        
        def middleware(self, middleware, attach_to=None):
            self.called = True
            assert attach_to == "request"
            self._future_middleware.append(middleware)

    # This is a fake object for on_request() decorator
    def middleware():
        pass

    sanic = SanicFake()
    assert sanic.called == False
    sanic.on_request(middleware)
    assert sanic.called == True
    assert middleware in sanic._future_middleware


# Generated at 2022-06-24 04:12:38.092446
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class DummyClass(MiddlewareMixin):
        pass
    dummy: DummyClass = DummyClass()
    assert dummy._future_middleware == []

# Generated at 2022-06-24 04:12:47.807375
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        return
    @app.middleware('response')
    async def response_middleware(request, response):
        return

    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert isinstance(app._future_middleware[1], FutureMiddleware)
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].attach_to == 'response'

    # Test error

# Generated at 2022-06-24 04:12:52.577454
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_sanic')

    def request_middleware(request):
        pass

    def response_middleware(request, response):
        pass

    app.middleware(request_middleware)
    app.middleware(response_middleware)

# Generated at 2022-06-24 04:13:01.653012
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic("test_MiddlewareMixin_on_response")
    @app.route("/middleware")
    async def handler(request):
        response = text("Hello, world!")
        return response
    
    @app.middleware("response")
    async def add_header(request, response):
        response.headers["X-Served-By"] = "Sanic"
        return response
    request, response = app.test_client.get('/middleware')
    assert response.status == 200
    assert response.headers['X-Served-By'] == 'Sanic'



# Generated at 2022-06-24 04:13:03.037080
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    def test_middleware(request):
        return request
    assert test_middleware(object) is not None

# Generated at 2022-06-24 04:13:06.464892
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    app = MiddlewareMixin()
    @app.on_response(middleware=None)
    def f():
        pass
    assert 'middleware<locals>.f' in sys.modules
    assert 'response' in sys.modules['middleware<locals>.f'].__name__

# Test for method on_request of class MiddlewareMixin

# Generated at 2022-06-24 04:13:08.852852
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mw = MiddlewareMixin()
    assert mw._future_middleware == []


# Generated at 2022-06-24 04:13:15.143993
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    mixin_test = MiddlewareMixin()

    # Test for method MiddlewareMixin.on_request
    @mixin_test.on_request
    def _():
        pass

    assert len(mixin_test._future_middleware) == 1



# Generated at 2022-06-24 04:13:17.203387
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert isinstance(m._future_middleware, List)
    assert len(m._future_middleware) == 0

# Generated at 2022-06-24 04:13:26.651637
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.blueprints import Blueprint
    from sanic.constants import METH_ANY

    blueprint = Blueprint("test_middleware")
    blueprint.middleware('request')(lambda x: x)

    assert isinstance(blueprint, MiddlewareMixin)

    blueprint.middleware(lambda x: x)
    blueprint.middleware('request')(lambda x: x)
    blueprint.middleware('response')(lambda x: x)

    blueprint.register(METH_ANY)(lambda x: x)

    assert len(blueprint._future_middleware) == 3

    def test_func():
        pass

    blueprint.register(lambda x: x, METH_ANY)
    blueprint.register(lambda x: x, METH_ANY)

    blueprint_app = blueprint.add(METH_ANY)(lambda x: x)
   

# Generated at 2022-06-24 04:13:29.402119
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Creating an instance of a class MiddlewareMixin
    middleware_mixin = MiddlewareMixin()
    
    assert middleware_mixin._future_middleware == []
    

# Generated at 2022-06-24 04:13:30.596118
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    obj = MiddlewareMixin()
    assert obj is not None

# Generated at 2022-06-24 04:13:32.351340
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    assert m.on_request == partial(m.middleware, attach_to="request")


# Generated at 2022-06-24 04:13:37.168827
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_on_request")
    @app.on_request
    def test_middleware(request):
        pass
    assert app._future_middleware[0].middleware == test_middleware


# Generated at 2022-06-24 04:13:48.000656
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__()

        def _apply_middleware(self, middleware):
            return middleware

    t = TestMixin()
    t.middleware(lambda x: x)
    assert t._future_middleware == \
        [FutureMiddleware(lambda x: x, "request")]

    t.middleware('request', lambda x: x)
    assert t._future_middleware == \
        [FutureMiddleware(lambda x: x, "request"), FutureMiddleware(lambda x: x, 'request')]

    t.middleware(attach_to='response', middleware=lambda x: x)

# Generated at 2022-06-24 04:13:55.073784
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.exceptions import PayloadTooLarge
    from sanic.request import Request
    from sanic.utils import text

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def handler(request):
        pass

    request = Request(
        "GET", "/test", headers={"content-type": "application/json"},
    )

    # print(app._future_middleware)
    # print(app._middleware)

    middleware = app._future_middleware[0]
    assert isinstance(middleware, FutureMiddleware)
    assert middleware.matches(request, "request")
    assert not middleware.matches(request, "response")



# Generated at 2022-06-24 04:14:04.142689
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    from sanic.exceptions import Forbidden

    app = Sanic()

    def simple_middleware(request):
        request["middleware"] = "this is a middleware"

    def simple_middleware_response(request, response):
        response.append("middleware")

    app.middleware(simple_middleware)
    app.middleware(simple_middleware_response, "response")

    @app.route("/")
    def simple(request):
        return request["middleware"]

    request, response = app.test_client.get("/")
    assert response.text == "this is a middleware"
    assert response.body == b"middleware"

    app.on_request(simple_middleware)
    app.on_response(simple_middleware_response)
    request,

# Generated at 2022-06-24 04:14:07.208401
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    class TestApp(MiddlewareMixin, Sanic):
        pass

    app = TestApp()

    assert app._future_middleware == []

# Generated at 2022-06-24 04:14:10.225204
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    ret = app.middleware()
    isinstance(ret, partial)


# Generated at 2022-06-24 04:14:16.766315
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            self._future_middleware: List[Middleware] = []

        def _apply_middleware(self, middleware: Middleware):
            return

    middleware_mixin = TestMiddlewareMixin()
    future_middleware: List[Middleware] = middleware_mixin._future_middleware
    assert future_middleware == []


# Generated at 2022-06-24 04:14:17.914252
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert callable(MiddlewareMixin().on_response())

# Generated at 2022-06-24 04:14:28.780749
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # The monkey patch is used to avoid dealing with creating a Sanic app
    # instance, which involves a lot of other dependencies and not easy to
    # mock.
    orig_middleware = MiddlewareMixin.middleware

    class MyMiddleware:
        pass

    with patch.object(MiddlewareMixin, "middleware") as patch_middleware:
        MiddlewareMixin.middleware = orig_middleware
        m = MyMiddleware()

        m.middleware("param")  # noqa
        assert not patch_middleware.called

        m.middleware("param1", "param2")  # noqa
        assert not patch_middleware.called

        m.middleware
        assert not patch_middleware.called

        m.middleware("param1")("param2")
        patch_middleware.assert_called_once_

# Generated at 2022-06-24 04:14:29.898445
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    MiddlewareMixin()


# Generated at 2022-06-24 04:14:33.570983
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Obj(MiddlewareMixin):
        pass

    o = Obj()
    o._apply_middleware(None)
    o.middleware(None)
    o.on_request(None)
    o.on_response(None)

# Generated at 2022-06-24 04:14:37.846983
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    """ Unit test for method on_response of class MiddlewareMixin """
    from sanic.app import Sanic

    app = Sanic()

    @app.on_response()
    def test_response_middleware_decorator(request, response):
        ...

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-24 04:14:40.159088
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    @app.middleware
    async def middleware(request):
        pass

# Generated at 2022-06-24 04:14:47.569788
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class _test1:
        def __init__(self):
            self._future_middleware = []
        def _apply_middleware(self, future_middleware):
            pass
        def on_response(self, middleware=None):
            if callable(middleware):
                return self.middleware(middleware, "response")
            else:
                return partial(self.middleware, attach_to="response")
        def middleware(
        self, middleware_or_request, attach_to="request", apply=True
        ):
            def register_middleware(middleware, attach_to="request"):
                nonlocal apply

                future_middleware = FutureMiddleware(middleware, attach_to)
                self._future_middleware.append(future_middleware)
                if apply:
                    self._apply_middle

# Generated at 2022-06-24 04:14:49.403762
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []


# Generated at 2022-06-24 04:14:53.356977
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    assert TestMiddlewareMixin()._future_middleware == []

# Generated at 2022-06-24 04:15:00.985696
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import HTTPResponse
    from sanic.response import text
    app = Sanic(__name__)

    @app.route('/')
    async def handler(request):
        return text('OK')

    def modifier(request):
        request.ctx.test = 'pass'

    app.middleware(modifier)
    test_client = app.test_client

    request, response = test_client.get('/')
    assert response.status == 200
    assert response.text == 'OK'


# Generated at 2022-06-24 04:15:12.381806
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestApp(MiddlewareMixin):
        def __init__(self):
            super().__init__(None)
            self.registration_log = []
            self.execution_log = []

        def _apply_middleware(self, middleware):
            self.registration_log.append(middleware)

        def execute_middleware(self, middleware, *args, **kwargs):
            self.execution_log.append(middleware)

    def middleware_func():
        assert False

    app = TestApp()

    assert app._future_middleware == []
    assert app.registration_log == []
    assert app.execution_log == []

    middleware_1 = app.on_response(middleware_func)
    middleware_2 = app.on_response(middleware_func)

# Generated at 2022-06-24 04:15:18.481709
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    def middleware(req):
        return req

    app = Sanic("test_on_request_app")
    app.on_request(middleware)

    assert app._future_middleware[0].middleware is middleware
    assert app._future_middleware[0].attach_to == "request"

# Generated at 2022-06-24 04:15:24.292057
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MyClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(MyClass, self).__init__(*args, **kwargs)

    my_obj = MyClass()
    assert my_obj._future_middleware == []

# Generated at 2022-06-24 04:15:34.464704
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass


    app = App()

    @app.middleware
    def foo(request):
        pass

    assert len(app._future_middleware) == 0

    @app.middleware('request')
    def bar(request):
        pass

    assert len(app._future_middleware) == 1
    assert isinstance(app._future_middleware[0].middleware, partial)
    assert app._future_middleware[0].attach_to == "request"

    @app.middleware('response')
    def biz(request, response):
        pass

    assert len(app._future_middleware) == 2
    assert isinstance(app._future_middleware[1].middleware, partial)


# Generated at 2022-06-24 04:15:40.883431
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    obj = MiddlewareMixin()
    assert callable(obj.on_request())
    assert callable(obj.on_request("response"))
    assert not callable(obj.on_request)
    assert obj.on_request("response")("myfunc") == "myfunc"


# Generated at 2022-06-24 04:15:48.775152
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def test(request):
        return request

    @app.middleware('request')
    def test2(request):
        return request

    @app.middleware('response')
    def test3(request, response):
        return response

    @app.middleware('request', apply=False)
    def test4(request):
        return request

    assert app._future_middleware[0].middleware is test
    assert app._future_middleware[1].middleware is test2
    assert app._future_middleware[2].middleware is test3
    assert app._future_middleware[3].middleware is test4


# Generated at 2022-06-24 04:15:55.084761
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Check if the MiddlewareMixin has been defined correctly
    instance = MiddlewareMixin()
    assert isinstance(instance, MiddlewareMixin)

# # Unit test for middleware function of class MiddlewareMixin
# def testmiddleware():
#     instance = MiddlewareMixin()
#     mw = instance.middleware
#     assert mw

# Generated at 2022-06-24 04:15:59.710210
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # on_response: middleware is not set -> raise an error
    obj = MiddlewareMixin()
    with pytest.raises(TypeError):
        obj.on_response()

    # on_response: middleware is callable -> return a callable
    def fn():
        pass

    assert callable(obj.on_response(fn))

    # on_response: middleware is not callable -> return a partial object
    assert isinstance(obj.on_response("request"), partial)