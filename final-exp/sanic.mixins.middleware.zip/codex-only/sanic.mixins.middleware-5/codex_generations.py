

# Generated at 2022-06-24 04:05:56.515093
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mw = MiddlewareMixin()
    assert isinstance(mw, MiddlewareMixin)


# Generated at 2022-06-24 04:06:02.487597
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class App:
        def __init__(self):
            self._future_middleware = []
        
        def _apply_middleware(self, middleware: FutureMiddleware):
            print("apply middleware")
    
    app = App()
    mixin = MiddlewareMixin()
    mixin.on_request(app.on_request)
    assert app._future_middleware
    assert app._future_middleware[0].middleware == app.on_request


# Generated at 2022-06-24 04:06:04.630875
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin')

    assert isinstance(app, MiddlewareMixin)

# Generated at 2022-06-24 04:06:15.295224
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import unittest
    from sanic.models.middleware.base import BaseHTTPMiddleware

    class MiddlewareMixinTest(MiddlewareMixin, unittest.TestCase):
        def test_on_request(self):

            def middleware():
                pass

            m = MiddlewareMixinTest()
            m.on_request(middleware=middleware)

            assert m._future_middleware[0].middleware == middleware
            assert m._future_middleware[0]._type == "request"

            m.on_request()(middleware)
            assert m._future_middleware[1].middleware == middleware
            assert m._future_middleware[1]._type == "request"


# Generated at 2022-06-24 04:06:19.039690
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    mm = MiddlewareMixin()
    assert mm.on_request()


# Generated at 2022-06-24 04:06:22.245495
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Test the function 'middleware' of class MiddlewareMixin.
    # Create a instance.
    instance = MiddlewareMixin()
    # Assert the function 'middleware' can be called.
    instance.middleware('middleware')

# Generated at 2022-06-24 04:06:31.001029
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    m = MiddlewareMixin(*[])
    @m.middleware('request')
    async def test_middleware(request, handler):
        return handler()
    assert len(m._future_middleware) == 1
    assert m._future_middleware[0].middleware == test_middleware
    assert m._future_middleware[0].attach_to == "request"
    m.middleware = None
    m.on_request = None
    m.on_response = None
    del m
    m = MiddlewareMixin(*[])
    @m.on_request()
    async def test_middleware(request, handler):
        return handler()
    assert len(m._future_middleware) == 1
    assert m._future_middleware[0].middleware == test_middleware

# Generated at 2022-06-24 04:06:34.210760
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic("test_MiddlewareMixin_on_response")

    # Way 1
    @app.on_response
    def test_response_func(request, response):
        pass

    # Way 2
    @app.on_response(lambda request, response: True)
    def test_response_func2(request, response):
        pass


# Generated at 2022-06-24 04:06:36.250618
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin().on_request == MiddlewareMixin().middleware



# Generated at 2022-06-24 04:06:39.204697
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert isinstance(MiddlewareMixin(), MiddlewareMixin)


# Generated at 2022-06-24 04:06:40.200847
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    MiddlewareMixin()


# Generated at 2022-06-24 04:06:42.762267
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    def test_on_request():
        pass
    #app = MiddlewareMixin()
    #app.on_request(test_on_request)


# Generated at 2022-06-24 04:06:46.959591
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    """
    name: test_MiddlewareMixin_on_response
    test_MiddlewareMixin_on_response
    """
    pass


# Generated at 2022-06-24 04:06:47.715678
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert 1 == 1


# Generated at 2022-06-24 04:06:56.396442
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():

    import pytest

    from sanic.app import Sanic

    from sanic.request import Request

    from sanic.response import HTTPResponse

    class TestMiddleware:
        def response(self, request, response):

            return HTTPResponse(
                "HELLO",
                status=201,
                headers={"Content-Type": "text/html"},
            )

    app = Sanic(__name__)

    #Register a middleware
    app.on_response(TestMiddleware)

    @app.route("/test")
    async def test(request):
        
        return HTTPResponse("OK")

    request, response = app.test_client.get("/test")

    #Test to see if response is different from what we are expecting
    assert response.status == 200

# Generated at 2022-06-24 04:06:59.998743
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from ...utils.tcp_server import Server
    from ...utils.tcp_client import Client

    class MyMiddleware(MiddlewareMixin):
        def _apply_middleware(self, middleware: Middleware):
            # do something
            pass

    my_middleware = MyMiddleware()
    my_middleware.middleware = 'test_string'


# Generated at 2022-06-24 04:07:03.309594
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    args = [[]]
    kwargs = {}
    obj = MiddlewareMixin(*args, **kwargs)
    assert obj

# Generated at 2022-06-24 04:07:07.316301
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    @app.on_request
    def before_request(request):
        print("Before request")

    # Verify that on_request attaches middleware to 'request'
    assert any([middleware.attach_to == "request" for middleware in app._future_middleware])


# Generated at 2022-06-24 04:07:16.074961
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.futures import FutureMiddleware
    from unittest import mock
    from unittest.mock import MagicMock
    
    class Dummy:
        pass
    dummy = Dummy()
    dummy.middleware = MagicMock()
    dummy._future_middleware = MagicMock()
    dummy._apply_middleware = MagicMock()    
    
    middleware_or_request = MagicMock()
    middleware_or_request.__call__ = MagicMock()
    with mock.patch("sanic.models.middleware_mixin.partial") as patch:
        patch.return_value = MagicMock()
        middleware = MiddlewareMixin.on_request(dummy, middleware_or_request)

# Generated at 2022-06-24 04:07:23.130908
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddlewareMixin_test(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(MiddlewareMixin, self).__init__(*args, **kwargs)
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    instance = MiddlewareMixin_test()
    print(instance)

test_MiddlewareMixin()

# Generated at 2022-06-24 04:07:34.566478
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.sanic import Sanic
    from sanic.response import json
    app = Sanic('test_app')
 
    def handle_response(request, response):
        """ add hello to response """
        return json({'hello': 'world'})
 
    @app.middleware('response')
    async def response_middleware_factory(request):
        return handle_response
 
    @app.route('/')
    async def test(request):
        # return json({"hello": request.hello}, dumps=dumps)
        return json({'hello': 'world'})
 
    request, response = app.test_client.get('/')
    assert response.json == {'hello': 'world'}

# Generated at 2022-06-24 04:07:44.693321
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.models.middlewares import MiddlewareMixin

    async def test_middleware(request):
        return request

    test_middleware_2 = test_middleware
    app = Sanic('test_MiddlewareMixin_on_response')

    @app.middleware('response')
    async def test_middleware_3(request):
        return request

    app.on_response(test_middleware)

    assert len(app.middleware_names) == 3

    assert test_middleware in app.middleware_names['response']
    assert test_middleware_2 in app.middleware_names['response']
    assert test_middleware_3 in app.middleware_names['response']


# Generated at 2022-06-24 04:07:51.621878
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import text
    from sanic.websocket import ConnectionClosed, WebSocketProtocol
    from sanic.websocket import WebSocketResponse

    def on_request(request):
        return text("hello world")

    def on_response(request, response):
        return response

    def on_websocket_connect(request, ws):
        ws.send("Hello World")

    def on_websocket_disconnect(request, ws):
        pass

    def on_websocket_request(request):
        return text("Hello World")

    # test normal mode
    sanic_app = Sanic()
    sanic_app.on_request(on_request)


# Generated at 2022-06-24 04:07:57.177461
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_on_response')

    @app.on_response
    def test_on_response(request, response):
        return response

    assert app._future_middleware[0].middleware == test_on_response
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].attach_to == 'response'



# Generated at 2022-06-24 04:08:03.840867
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Arrange
    class Test:
        def middleware(self, middleware_or_request, attach_to="request", apply=True):
            assert attach_to == 'request'
            assert apply == True
            return middleware_or_request

    test = Test()

    # Act
    on_request = test.on_request

    # Assert
    def test_func(self):
        pass

    assert on_request(test_func) == test_func


# Generated at 2022-06-24 04:08:07.707139
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestGlobal(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    TestGlobal()


# Generated at 2022-06-24 04:08:08.450898
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    obj=MiddlewareMixin()

# Generated at 2022-06-24 04:08:11.361085
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    async def _request(request):
        pass

    class TestMiddleware(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            self.middleware = middleware
    test = TestMiddleware(None, None)
    test.on_request(_request)
    assert test.middleware.handler == _request
    

# Generated at 2022-06-24 04:08:14.400833
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class FakeApp(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    app = FakeApp()
    assert app.on_request() == partial(app.middleware, attach_to="request")

# Generated at 2022-06-24 04:08:16.750948
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware = MiddlewareMixin()
    @middleware.on_request()
    async def test(request, handler):
        return await handler(request)
    assert test.__name__ == 'test'

# Generated at 2022-06-24 04:08:18.153410
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    obj = MiddlewareMixin()    
    assert obj is not None

# Generated at 2022-06-24 04:08:18.761707
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

# Generated at 2022-06-24 04:08:19.747332
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mw = MiddlewareMixin()

# Generated at 2022-06-24 04:08:29.784366
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert callable(MiddlewareMixin.on_response) # first test of function determin if the function is callable
    
    
    assert callable(MiddlewareMixin.on_response(lambda x: None)) # second test of callable. It returns a callable object.
    assert callable(MiddlewareMixin.on_response(lambda x: None)(lambda y: None)) # third test of callable. It returns a callable object.
    
    
    assert isinstance(MiddlewareMixin.on_response(), partial) # fourth test of function. It returns a partial object.
    assert isinstance(MiddlewareMixin.on_response()(lambda y: None), partial) # fifth test of function. It returns a partial object.
    
    
    class TestMiddleware(MiddlewareMixin):
        pass
    

# Generated at 2022-06-24 04:08:40.474352
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic()

    @app.middleware
    def before_request_middleware(request):
        request["middlewares"].append("1")

    @app.middleware('request')
    def before_request_middleware2(request):
        request["middlewares"].append("2")

    @app.middleware('response')
    def before_request_middleware3(request, response):
        request["middlewares"].append("3")

    @app.route("/middleware")
    def handler(request):
        return json({"middlewares": request.get("middlewares", [])})

    request, response = app.test_client.get("/middleware")


# Generated at 2022-06-24 04:08:42.405430
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # act
    result = MiddlewareMixin.on_response()

    # assert
    assert result is not None

# Generated at 2022-06-24 04:08:46.452625
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic(__name__)
    @app.on_response
    def response(request, response):
        return response
    assert len(app.__dict__) == 0
    
    

# Generated at 2022-06-24 04:08:49.593954
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Object(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass
    object = Object()
    object.middleware("a", "b")
    object.on_request("a")
    object.on_response("b")

# Generated at 2022-06-24 04:08:53.143995
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Arrange
    import sanic
    app = sanic.Sanic()

    # Act
    @app.on_request
    def foo(request):
        return request

    # Assert
    assert getattr(foo, "__middleware_name__") == "request"

# Generated at 2022-06-24 04:08:56.558561
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    try:
        MiddlewareMixin()
    except:
        assert 0, 'Fail: constructor of class MiddlewareMixin'
    else:
        assert 1


# Generated at 2022-06-24 04:08:58.801776
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    print("test_MiddlewareMixin_middleware")
    obj = MiddlewareMixin()


# Generated at 2022-06-24 04:09:08.997744
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.exceptions import NotFound
    from sanic.websocket import WebSocketProtocol

    app = Sanic()

    @app.middleware
    def cors(request):
        print("CORS")

    @app.middleware('response')
    def cors_response(request, response):
        print("CORS Response")

    @app.websocket('/ws')
    async def ws(request, ws):
        while True:
            msg = 'Hello!'
            print('Sending: ' + msg)
            await ws.send(msg)
            data = await ws.recv()
            print('Received: ' + data)


# Generated at 2022-06-24 04:09:12.986155
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    import pytest
    from sanic import Sanic

    app = Sanic('test_MiddlewareMixin')

    # test middleware instance
    middleware_ins = MiddlewareMixin()

    # test attribute: future_middleware
    assert isinstance(middleware_ins._future_middleware, list)



# Generated at 2022-06-24 04:09:15.436100
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    new_sanic_server=Sanic()
    assert isinstance(new_sanic_server,MiddlewareMixin)


# Generated at 2022-06-24 04:09:25.305312
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # setup
    class App(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)

    app = App()

    # test
    @app.on_response
    def on_response(request, response):
        return response

    # assert
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware(None, None) == None
    assert app._future_middleware[0].attach_to == "response"


# Generated at 2022-06-24 04:09:27.507622
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    future_middleware = MiddlewareMixin()
    assert future_middleware._future_middleware == []
    

# Generated at 2022-06-24 04:09:32.648049
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    print("Testing method on_request of MiddlewareMixin")
    from sanic.app import Sanic

    app = Sanic("test_MiddlewareMixin_on_request")

    @app.on_request
    def test_on_request(request):
        pass

    assert len(app._future_middleware) == 1


# Generated at 2022-06-24 04:09:42.709743
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class FakeApp:
        def __init__(self):
            self._future_middleware = []
            self._apply_middleware = lambda x: None

    app = FakeApp()
    fake_middleware = lambda x: x
    app.middleware(fake_middleware)
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == fake_middleware
    assert app._future_middleware[0].attach_to == "request"
    app._future_middleware = []
    app.middleware(fake_middleware, "response")
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "response"

# Generated at 2022-06-24 04:09:44.629384
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []


# Generated at 2022-06-24 04:09:53.599436
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = MiddlewareMixin()

    @app.middleware('request')
    async def request_middleware(request):
        request['test'] = True

    assert app._future_middleware is not None
    assert len(app._future_middleware) == 1

    request_middleware = app._future_middleware[0]
    assert request_middleware.attach_to == 'request'
    assert request_middleware.middleware(None) is None

    # Test for the other method
    @app.on_request
    async def request_middleware1(request):
        request['test1'] = True

    assert app._future_middleware is not None
    assert len(app._future_middleware) == 2

    request_middleware = app._future_middleware[1]
    assert request_middleware.attach_to

# Generated at 2022-06-24 04:10:00.649460
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """
    Test decorator that wraps a middleware function and registers it
    to be called later, when a request comes in.
    """
    class TestApp(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.request_in_mw = None
            self.response_in_mw = None
            self.request_is_mw = False
            self.response_is_mw = False
            self.expected_request = None
            self.expected_response = None

        async def test_request_middleware(self, request):
            self.request_in_mw = request
            self.request_is_mw = True


# Generated at 2022-06-24 04:10:07.825840
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    try:
        middleware_mixin = MiddlewareMixin()
        # Show this case is not supported
        middleware_mixin._apply_middleware(None)
    except NotImplementedError as e :
        print(e)
    
    # test for function on_request
    middleware_mixin = MiddlewareMixin()
    @middleware_mixin.on_request()
    def test_on_request():
        pass
    
    # test for function on_response
    middleware_mixin = MiddlewareMixin()
    @middleware_mixin.on_response()
    def test_on_response():
        pass

test_MiddlewareMixin_middleware()

# Generated at 2022-06-24 04:10:13.496055
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = MiddlewareMixin()
    assert app._future_middleware == []
    @app.middleware
    def _():
        pass
    assert len(app._future_middleware) == 1
    assert isinstance(app._future_middleware[0].middleware, partial)
    assert app._future_middleware[0].attach_to == "request"

# Generated at 2022-06-24 04:10:17.940720
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    instance = MiddlewareMixin()
    middleware = "test"

    # Normal case
    assert callable(instance.on_response(middleware))
    # Test on_response without parameter
    assert callable(instance.on_response())

# Generated at 2022-06-24 04:10:25.682948
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
  from sanic.server import app
  from sanic.models.futures import FutureMiddleware, future_middleware
  from sanic.config import Config
  from sanic.server import ServerCfg
  import sys
  import os

  sanic_app = app.Sanic(__name__)
  sanic_app.config.KEEP_ALIVE = False
  sanic_app.config.REQUEST_MAX_SIZE = 1024
  sanic_app.config.REQUEST_TIMEOUT = 60


# Generated at 2022-06-24 04:10:32.502951
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    request = ""
    handler = ""
    event = ""

    def run_request_middleware(request, handler, event):
        if request == "request" and handler == "handler" and event == "event":
            return True

    test_object = MiddlewareMixin()
    test_object.on_request(run_request_middleware)(request, handler, event)

 # Unit test for method on_response of class MiddlewareMixin

# Generated at 2022-06-24 04:10:37.894219
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    def middleware(request):
        print('middleware')
        return request

    assert app._future_middleware
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[0].middleware


# Generated at 2022-06-24 04:10:43.880213
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    #arrange
    app = Sanic(__name__)
    instance = MiddlewareMixin()
    instance._apply_middleware = MagicMock()
    #act
    result = instance.on_request(middleware=app.request_middleware)
    #assert
    assert instance._apply_middleware.call_count == 0
    assert result.attach_to == "request"
    assert result.middleware == app.request_middleware
    assert result.mw_instance == None


# Generated at 2022-06-24 04:10:52.181738
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import sanic
    app = sanic.Sanic(__name__)

    @app.on_request
    def do_on_request(request):
        pass

    assert app._future_middleware[0].middleware is do_on_request
    assert app._future_middleware[0].attach_to == "request"

    @app.on_response
    def do_on_response(request, response):
        pass

    assert app._future_middleware[1].middleware is do_on_response
    assert app._future_middleware[1].attach_to == "response"

    # Decorator is registered but not applied
    @app.middleware("request", apply=False)
    def do_on_req_not_applied(request):
        pass

    assert app._future_middleware[2].middle

# Generated at 2022-06-24 04:11:02.929420
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            assert False

    app = App()
    @app.middleware('request')
    def middleware1():
        raise NotImplementedError  # noqa

    @app.middleware
    def middleware2():
        raise NotImplementedError  # noqa

    @app.middleware('response')
    def middleware3():
        raise NotImplementedError

    @app.middleware('response')
    def middleware4():
        raise NotImplementedError

    assert len(app._future_middleware) == 4
    assert app._future_middleware[0].request == "middleware1"
    assert app._future_middleware[1].request == "middleware2"
    assert app._

# Generated at 2022-06-24 04:11:09.987632
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    app = App()
    def middleware_or_request(request):
        return request
    # Test for case without register_middleware
    app.middleware(middleware_or_request)
    assert middleware_or_request in app._future_middleware
    # Test for case with register_middleware
    app.middleware(middleware_or_request, "request")
    assert middleware_or_request in app._future_middleware


# Generated at 2022-06-24 04:11:10.681175
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass  # TODO


# Generated at 2022-06-24 04:11:12.512484
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Case 1
    @MiddlewareMixin.on_response
    def middleware1(request):
        pass

    # Case 2
    @MiddlewareMixin.on_response("response")
    def middleware2(request):
        pass

# Generated at 2022-06-24 04:11:19.025539
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(TestMiddlewareMixin, self).__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []
        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)

    a = TestMiddlewareMixin()
    @a.on_request()
    def f():
        pass

    assert a._future_middleware[0].on_request == f
    assert a._future_middleware[0].attach_to == "request"


# Generated at 2022-06-24 04:11:28.570341
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    # Test case for the situation of the first parameter is not a callable object
    with pytest.raises(TypeError):
        test_middleware_mixin.middleware(1)
    # Test case for the situation that the second parameter is not string
    with pytest.raises(TypeError):
        test_middleware_mixin.middleware(lambda x: x, 1)

    # Check whether the middleware is registered successfully
    @test_middleware_mixin.middleware(attach_to="request")
    def test_middleware(request):
        pass
    assert test_middleware_mixin._future_

# Generated at 2022-06-24 04:11:39.070346
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from unittest import mock
    from sanic.app import Sanic
    from sanic.response import text

    # Whether the middleware_or_request is callable or not, it will still be processed and replace with "response" first
    # Then the called function middleware(middleware, attach_to) will be called with "response" as the attach_to
    # The code path will be:
    #   MiddlewareMixin.middleware ->
    #   MiddlewareMixin.on_response ->
    #   MiddlewareMixin.middleware ->
    #   MiddlewareMixin._future_middleware.append ->
    #   MiddlewareMixin._apply_middleware

    # First test: Without middleware_or_request
    app = Sanic("test_sanic")
    partial_mock = mock.Mock()

# Generated at 2022-06-24 04:11:47.904042
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m = MiddlewareMixin()

    def first_middleware(request, response):
        pass

    def second_middleware(request, response):
        pass
    
    m.middleware(first_middleware, 'request')
    m.middleware(second_middleware, 'response')

    assert m._future_middleware[0].middleware == first_middleware
    assert m._future_middleware[0].attach_to == 'request'
    assert m._future_middleware[1].middleware == second_middleware
    assert m._future_middleware[1].attach_to == 'response'



# Generated at 2022-06-24 04:11:52.255361
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(
            self, *args, **kwargs
        ):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    TestMiddlewareMixin()

# Generated at 2022-06-24 04:11:55.811698
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import sys
    import os
    import pytest
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_server import _test_on_response
    _test_on_response()



# Generated at 2022-06-24 04:11:58.542090
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    test_MiddlewareMixin = MiddlewareMixin()
    test_MiddlewareMixin.on_response()

# Generated at 2022-06-24 04:12:03.253791
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    assert m.on_request() == partial(m.middleware, attach_to="request")
    assert m.on_request(lambda req: req) == m.middleware(lambda req: req, attach_to="request")
    assert m.on_request(lambda req: req) == m._future_middleware[0].middleware


# Generated at 2022-06-24 04:12:05.105299
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Test constructor of class MiddlewareMixin
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin._future_middleware == []

# Generated at 2022-06-24 04:12:16.081197
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.exceptions import InvalidUsage
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.server import serve
    from sanic.views import HTTPMethodView

    async def mid_req(request):
        assert isinstance(request, Request)
        return request

    async def mid_res(request, response):
        assert isinstance(request, Request)
        assert isinstance(response, HTTPResponse)
        return response

    @mid_req
    async def mid_req_keyword(request):
        assert isinstance(request, Request)
        return request

    @mid_res
    async def mid_res_keyword(request, response):
        assert isinstance(request, Request)

# Generated at 2022-06-24 04:12:24.236926
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.core import Sanic
    from middleware_mixin import MiddlewareMixin
    from sanic import response

    app = Sanic('test_MiddlewareMixin_middleware')

    class TestMiddlewareMixin(MiddlewareMixin):
        pass

    test_middleware = TestMiddlewareMixin()

    @test_middleware.middleware
    async def handler(request):
        return response.html('OK')

    @app.route('/')
    async def test(request):
        return response.html('OK')

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.text == 'OK'

# Generated at 2022-06-24 04:12:32.549757
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.models.futures import FutureMiddleware
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.middleware import ResponseMiddleware

    app = Sanic('sanic')
    @app.middleware  # type: ignore
    def ValidateJsonMiddleware(request):
        return

    @app.middleware  # type: ignore
    def ValidateHeadersMiddleware(request):
        return

    @app.middleware
    def ProxyMiddleware(request):
        pass

    @app.route('/post', methods=['POST'])
    def post(request):
        return text('OK')

    @app.get('/get')
    def get(request):
        return text('OK')

    middleware_list = app._future_middleware
    assert len

# Generated at 2022-06-24 04:12:35.833285
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    test1 = MiddlewareMixin()
    test1.on_response("OK") # attach_to will be "response"
    assert test1._future_middleware[0].attach_to == "response"



# Generated at 2022-06-24 04:12:43.883121
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixinObject(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass

    obj = MiddlewareMixinObject()

    @obj.middleware
    def hello(request):
        return "hello"

    assert hello(None) == "hello"

    @obj.on_request
    def world(request):
        return "world"

    assert world(None) == "world"

    @obj.on_response
    def foo(request):
        return "foo"

    assert foo(None) == "foo"

# Generated at 2022-06-24 04:12:44.419973
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

# Generated at 2022-06-24 04:12:55.060691
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    def handler(request):
        return text("OK")

    def middleware(request):
        return text("OK")

    app = Sanic("test_middleware")
    app.add_route(handler, "/1")
    # those two are equal
    app.middleware(middleware)
    app.on_request(middleware)
    # but we expect only one middleware to be in the stack
    assert len(app._future_middleware) == 1
    # and request to be attached to it
    assert app._future_middleware[0].attach_to == "request"

    app.add_route(handler, "/2")
    app.middleware(middleware, "request")
    assert len(app._future_middleware) == 2



# Generated at 2022-06-24 04:13:04.933815
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from futurist import ArrivedEvent

    my_mixin = MiddlewareMixin()
    assert len(my_mixin._future_middleware) == 0

    @my_mixin.on_request
    async def middleware_request(request):
        print("Request")
        # print(request)

    @my_mixin.on_response
    async def middleware_response(request, response):
        print("Response")
        # print(request)
        # print(response)

    assert len(my_mixin._future_middleware) == 2
    future_middleware1 = my_mixin._future_middleware[0]
    assert future_middleware1.middleware == middleware_request
    assert future_middleware1.attach_to == "request"
    future_middleware2 = my_mixin._

# Generated at 2022-06-24 04:13:14.670402
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.response import json
    from sanic.views import HTTPMethodView
    from sanic.exceptions import NotFound
    from sanic.router import Router
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.testing import SanicTestClient

    class Users(HTTPMethodView):
        def get(self, request):
            return json({"Hello": "World"})

    class RouterWithApplyMiddleware(Router):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware):
            if middleware.attach_to == "response":
                self.middleware.append(middleware)


# Generated at 2022-06-24 04:13:22.829343
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    ## test_MiddlewareMixin_middleware_1 ##
    def _test():
        from sanic.app import Sanic
        from sanic.middleware import BaseHTTPMiddleware
        from sanic.models.futures import FutureMiddleware
        import sanic

        app = Sanic()

        class Middleware(BaseHTTPMiddleware):
            def resolve(self, request, handler=None):
                pass

        Middleware_instance = Middleware()

        sanic.app.middleware(Middleware_instance)
        try: raise AssertionError
        except AssertionError: pass
        else: raise Exception

    _test()

    ## test_MiddlewareMixin_middleware_2 ##
    def _test():
        from sanic.app import Sanic
        from sanic.middleware import BaseHTTPM

# Generated at 2022-06-24 04:13:24.675789
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    assert mm._future_middleware == []


# Generated at 2022-06-24 04:13:27.169369
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    TestMiddlewareMixin(*(), **{})

# Generated at 2022-06-24 04:13:32.851469
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    objMiddlewareMixin = MiddlewareMixin()
    on_request = objMiddlewareMixin.on_request()
    assert callable(on_request)
    assert on_request.__name__ == "register_middleware"
    assert on_request.__self__.__class__.__name__ == "MiddlewareMixin"
    assert on_request.__self__._future_middleware == []
    assert on_request.keywords["attach_to"] == "request"


# Generated at 2022-06-24 04:13:34.770446
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin().on_request().__name__ == '<lambda>'


# Generated at 2022-06-24 04:13:43.789580
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')
    count = 0

    @app.middleware
    async def primitive_middleware(request):
        nonlocal count
        count += 1
        return await response(text('Success'))

    request, response = app.test_client.get('/')
    assert count == 0
    assert request.status == 200

    app._apply_middleware(app._future_middleware[0])
    request, response = app.test_client.get('/')
    assert count == 1
    assert request.status == 200



# Generated at 2022-06-24 04:13:48.312648
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    def response_middleware(request, response):
        return True

    app = Sanic(__name__)
    app.on_response(response_middleware)
    assert app._future_middleware[0].attach_to == "response"

# Generated at 2022-06-24 04:13:58.034602
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response.__doc__ is not None
    assert MiddlewareMixin.on_response.__annotation__ is not None
    assert MiddlewareMixin.on_response.__module__ is not None
    assert MiddlewareMixin.on_response.__name__ is not None
    assert MiddlewareMixin.on_response.__qualname__ is not None
    assert MiddlewareMixin().on_response.__doc__ is not None
    assert MiddlewareMixin().on_response.__annotation__ is not None
    assert MiddlewareMixin().on_response.__module__ is not None
    assert MiddlewareMixin().on_response.__name__ is not None
    assert MiddlewareMixin().on_response.__qualname__ is not None


# Generated at 2022-06-24 04:14:04.954598
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class test_MiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            MiddlewareMixin.__init__(self, *args, **kwargs)

        def _apply_middleware(self, middleware):
            pass
    # Create one instance of test_MiddlewareMixin
    instance = test_MiddlewareMixin()
    # Test on_request method
    assert callable(instance.on_request(middleware='response')(middleware='request'))
    # Test _future_middleware
    assert len(instance._future_middleware) == 2


# Generated at 2022-06-24 04:14:13.901036
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # 1. Arrange
    from sanic import Sanic
    from sanic.response import json


    def request_middleware(request):
        request['foo'] = 'bar'

    app = Sanic()

    # 2. Act
    @app.middleware
    async def attach_foo(request):
        request['foo'] = 'bar'

    @app.route('/')
    async def handler(request):
        return json({'test': True, 'foo': request.get('foo', None)})

    # 3. Assert
    request, response = app.test_client.get('/')
    assert response.json == {'test': True, 'foo': 'bar'}

# Generated at 2022-06-24 04:14:22.140026
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware):
            return middleware

    def do_something():
        return True

    mw = TestMiddlewareMixin()
    assert mw.on_request(do_something) is do_something

    assert mw.on_request() is not do_something
    assert isinstance(mw.on_request(), partial)
    assert mw.on_request().func is mw.middleware
    assert mw.on_request().keywords.get('attach_to', None) == 'request'



# Generated at 2022-06-24 04:14:25.802028
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # class MiddlewareMixin:
    # def __init__(self, *args, **kwargs) -> None:
    #     self._future_middleware: List[FutureMiddleware] = []
    srv = MiddlewareMixin()
    assert srv._future_middleware == []

# Generated at 2022-06-24 04:14:37.113321
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic("test_middleware_mixin")

    # Unit test for method on_response of class MiddlewareMixin
    def test_middleware_function(request, handler):
        return handler(request)

    app.on_response(test_middleware_function)

    future_middleware = app._future_middleware.pop()
    assert future_middleware.name == test_middleware_function
    assert future_middleware.attach_to == "response"

    # Unit test for method on_response of class MiddlewareMixin
    def test_middleware_decorator(request, handler):
        return handler(request)

    app.on_response(test_middleware_decorator)()

    future_middleware = app._future_middleware.pop()

# Generated at 2022-06-24 04:14:40.474552
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic_wtf import SanicForm
    from sanic.models.futures import FutureMiddleware

    class FormWithMiddleware(SanicForm):
        pass

    FormWithMiddleware.middleware(FutureMiddleware(lambda x: x, "request"))

# Generated at 2022-06-24 04:14:46.728858
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware('request')
    async def print_on_request(request):
        return text("Request")

    assert hasattr(app, '_future_middleware')
    assert len(app._future_middleware) == 1

    @app.middleware('response')
    async def print_on_response(request, response):
        return text("Response")

    assert hasattr(app, '_future_middleware')
    assert len(app._future_middleware) == 2


# Generated at 2022-06-24 04:14:55.549625
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class S(MiddlewareMixin):
        _apply_middleware = staticmethod(lambda x: x)
    s = S()
    f1 = lambda x:x
    f2 = lambda x:x
    s.on_request(f1)
    s.on_request(f1)
    s.on_request(f2)
    assert len(s._future_middleware) == 3
    assert s._future_middleware[0].middleware == f1
    assert s._future_middleware[1].middleware == f1
    assert s._future_middleware[2].middleware == f2


# Generated at 2022-06-24 04:14:56.248078
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass


# Generated at 2022-06-24 04:15:06.030890
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError

    a = TestMiddlewareMixin()
    class TestClass1:
        pass
    class TestClass2:
        pass
    a.middleware(TestClass1)
    a.middleware(TestClass2, 'response')
    assert len(a._future_middleware) == 2
    assert isinstance(a._future_middleware[0].middleware, type(TestClass1))
    assert isinstance(a._future_middleware[1].middleware, type(TestClass2))
    assert a._future_middleware[0].attach_to == 'request'
    assert a._future_middleware[1].attach_to == 'response'

# Unit test

# Generated at 2022-06-24 04:15:12.574727
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def foo(request):
        pass

    assert app._future_middleware[0].middleware == foo
    assert app._future_middleware[0].attach_to == 'request'

    @app.middleware('response')
    def bar(request):
        pass

    assert app._future_middleware[1].middleware == bar
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-24 04:15:13.711514
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    app = MiddlewareMixin()
    assert app._future_middleware == []


# Generated at 2022-06-24 04:15:24.802500
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # MiddlewareMixin()
    mw_mixin = MiddlewareMixin()
    assert isinstance(mw_mixin, MiddlewareMixin)
    assert not hasattr(mw_mixin, '_future_middleware')

    # MiddlewareMixin(args)
    mw_mixin = MiddlewareMixin(None)
    assert isinstance(mw_mixin, MiddlewareMixin)
    assert not hasattr(mw_mixin, '_future_middleware')
    
    # MiddlwareMixin(**kwargs)
    mw_mixin = MiddlewareMixin(test = None)
    assert isinstance(mw_mixin, MiddlewareMixin)
    assert not hasattr(mw_mixin, '_future_middleware')
    
    # MiddlewareMixin(

# Generated at 2022-06-24 04:15:31.350409
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('middleware_mixin_test')
    @app.request_middleware
    def print_request_id(request):
        print(request.id)
    
    # Unit test for on_request of MiddlewareMixin
    assert app.on_request == app.request_middleware


# Generated at 2022-06-24 04:15:33.956645
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    MiddlewareMixin.on_request() == partial(MiddlewareMixin.middleware, attach_to="request")
    MiddlewareMixin.on_request(middleware) == MiddlewareMixin.middleware(middleware, "request")


# Generated at 2022-06-24 04:15:34.587411
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-24 04:15:45.110761
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic(loa='The test')

    def f():
        pass

    def f1():
        pass

    app.middleware(f)
    # app._future_middleware is a list type, which can be appended directly
    assert isinstance(app._future_middleware, list)
    assert app._future_middleware[0].middleware == f
    assert app._future_middleware[0].attach_to == 'request'

    app.middleware(f1, 'response')
    assert app._future_middleware[1].middleware == f1
    assert app._future_middleware[1].attach_to == 'response'

# Generated at 2022-06-24 04:15:51.170116
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Test:
        def __init__(self, *args, **kwargs):
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError
    Test.__bases__ = (MiddlewareMixin,)
    Test.__init__ = MiddlewareMixin.__init__

    t = Test()
    assert t._future_middleware == []

# Generated at 2022-06-24 04:15:58.465836
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def simple_middleware(request):
        print ("yay this is a great middleware")

    app.middleware(simple_middleware)

    @app.middleware('request')
    def request_middleware(request):
        print ("this is a simple request middleware")

    app.middleware(request_middleware, 'request')

    @app.middleware('response')
    def response_middleware(request, response):
        print ("this is a simple response middleware")

    app.middleware(response_middleware, 'response')

