

# Generated at 2022-06-24 04:06:06.058599
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware

    app = Sanic("test_MiddlewareMixin_middleware")
    
    @app.middleware('request')
    def request_mw(request):
        request['foo'] = 'bar'

    @app.middleware('response')
    def response_mw(request, response):
        response.body = response.body + b" RESPONSE MW"

    @app.route("/")
    def handler(request):
        return "hello"

    request, response = app.test_client.get("/")
    assert response.text == 'hello RESPONSE MW'
    assert request['foo'] == 'bar'

    mw_tmp = app._future_middleware[0]
    assert mw_tmp.middleware

# Generated at 2022-06-24 04:06:06.593107
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-24 04:06:12.503923
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        pass

    test = TestMiddlewareMixin()
    assert test._future_middleware == []

    # register middleware
    test.on_response()(lambda request, response: response)
    assert len(test._future_middleware) == 1

    # check variable attach_to of instance _future_middleware
    assert test._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-24 04:06:15.012501
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin.on_response() != None

# Generated at 2022-06-24 04:06:23.975202
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = Sanic("test_MiddlewareMixin_middleware")

    assert app._future_middleware == []

    def test_middleware(request):
        return request

    app.middleware(test_middleware, "response")

    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].middleware is test_middleware

    app.middleware()(test_middleware, "response")

    assert len(app._future_middleware) == 2
    assert isinstance(app._future_middleware[1], FutureMiddleware)
    assert app._future_middleware[1].middleware is test_middleware

# Generated at 2022-06-24 04:06:29.810496
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    class TestServer(MiddlewareMixin):
        async def _apply_middleware(self, future_middleware: FutureMiddleware):
            pass

    test_server = TestServer()
    print(test_server)
    print(type(test_server))

    @test_server.middleware
    async def test_middleware_a(request):
        print(request)

    @test_server.on_request(test_middleware_a)
    async def test_middleware_b(request):
        print(request)



# Generated at 2022-06-24 04:06:36.714691
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.models import FutureMiddleware
    from sanic.handlers import RequestHandler
    class MyHandlers(RequestHandler): pass
    class MyClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            self._middleware.append(middleware)
    app = Sanic('test_MiddlewareMixin_middleware')
    app.config.from_object('sanic.config.DEFAULTS')
    myclass = MyClass()
    my_middleware_or_route = lambda x: 'my_middleware_or_route'
    my_middleware_or_route

# Generated at 2022-06-24 04:06:48.511553
# Unit test for method on_response of class MiddlewareMixin

# Generated at 2022-06-24 04:06:51.141127
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddlewareMixin_test(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    test_MiddlewareMixin_obj = MiddlewareMixin_test()
    assert test_MiddlewareMixin_obj is not None

# Generated at 2022-06-24 04:06:57.759732
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():  # noqa
    class MiddlewareMixin_test_1(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa
    test1 = MiddlewareMixin_test_1()
    test1.middleware(lambda x: x)
    test1.middleware(lambda x: x, attach_to="request")
    test1.middleware(lambda x: x, attach_to="response")
    test1.on_request(lambda x: x)
    test1.on_response(lambda x: x)
    class MiddlewareMixin_test_2(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa
    test2 = MiddlewareMixin

# Generated at 2022-06-24 04:06:58.971777
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []

# Generated at 2022-06-24 04:07:05.608957
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    expected_result = [
        FutureMiddleware(middleware_or_request, attach_to="request")
    ]
    actual_result = []

    class TestMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware):
            actual_result.append(middleware)

    test_instance = TestMixin()

    @test_instance.middleware
    def middleware_or_request():
        pass



# Generated at 2022-06-24 04:07:12.296746
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class test_middleware(MiddlewareMixin):
        def __init__(self):
            MiddlewareMixin.__init__(self)
        def test_middleware_request(self,request):
            print('from test_middleware middleware request')
        def test_middleware_response(self,request, response):
            print('from test_middleware middleware response')
    test_middleware().middleware(test_middleware().test_middleware_request())
test_MiddlewareMixin_middleware()



# Generated at 2022-06-24 04:07:19.422550
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    mixin = MiddlewareMixin()
    def middleware():
        print("middleware")
    check_mixin = mixin.on_request(middleware)
    check_attach_to = check_mixin.attach_to
    check_middleware = check_mixin.middleware
    assert check_attach_to == "request"
    assert callable(check_middleware)


# Generated at 2022-06-24 04:07:25.205427
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class K:
        def __init__(self, *args, **kwargs):
            self._future_middleware = []

        def _apply_middleware(self, middleware):
            self._future_middleware.append(middleware)
            return middleware

    k = K()
    def f(): pass
    def f2(): pass
    middleware = k.on_request(f)
    assert callable(middleware)
    middleware()
    assert len(k._future_middleware) == 1


# Generated at 2022-06-24 04:07:35.248576
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():

    # Setup code
    class MiddlewareMixinClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware = []
        def _apply_middleware(self, middleware: FutureMiddleware):
            return
    test_target = MiddlewareMixinClass()
    test_middleware_callable = lambda x: None

    # Exercise code
    test_result = test_target.on_response(test_middleware_callable)

    # Verify expectations
    assert test_target._future_middleware
    assert len(test_target._future_middleware) == 1
    assert isinstance(test_target._future_middleware[0], FutureMiddleware)
    assert test_target._future_middleware

# Generated at 2022-06-24 04:07:44.327662
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    _sanic_middleware = [MiddlewareMixin]

    for _middleware in _sanic_middleware:

        # Case 1: normal call
        middleware1 = _middleware()
        result1 = middleware1.on_response()
        expected_result1 = partial(middleware1.middleware, attach_to="response")
        assert result1 == expected_result1

        # Case 2: normal call
        middleware2 = _middleware()
        result2 = middleware2.on_response(lambda x : x)
        expected_result2 = middleware2.middleware(lambda x : x, "response")
        assert result2 == expected_result2


# Generated at 2022-06-24 04:07:44.938644
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    MiddlewareMixin()

# Generated at 2022-06-24 04:07:46.742584
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    @m.on_request()
    def fun(req):
        return True
    assert type(fun) == function



# Generated at 2022-06-24 04:07:55.706777
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text

    test_app = Sanic("test_MiddlewareMixin_on_request")
    called = []

    @test_app.middleware
    def middleware_function(request):
        called.append(request)
        return request

    @test_app.middleware('request')
    def request_middleware_function(request):
        called.append(request)
        return request

    @test_app.middleware('response')
    def response_middleware_function(request, response):
        called.append(response)
        return response

    @test_app.route('/')
    async def handler(request):
        return text('OK')

    request, response = test_app.test_client.get('/')

# Generated at 2022-06-24 04:07:58.119050
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    try:
        MiddlewareMixin.on_response
    except AttributeError as e:
        print(e)
        assert False


# Generated at 2022-06-24 04:08:07.021080
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    class MyMiddleware:
        def __init__(self, request):
            pass

        async def response_middleware(self, request, response):
            return response

    class MySanic(Sanic, MiddlewareMixin):
        def __init__(self, name=None, router=None, error_handler=None,
                     load_env=True, log_config=None, request_class=Request,
                     strict_slashes=None):
            super(MySanic, self).__init__()

        async def handle_request(self, request, *args, **kwargs):
            return HTTPResponse("OK")

    app = MySanic()
    app.middleware(MyMiddleware)

# Generated at 2022-06-24 04:08:09.468133
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    test_mixin = MiddlewareMixin()
    assert test_mixin._future_middleware == []
    middleware = FutureMiddleware("test", "request")
    test_mixin._apply_middleware(middleware)

# Generated at 2022-06-24 04:08:14.382673
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import HTTPResponse

    async def test_middleware(request):
        return HTTPResponse(status=200, text='hello world')

    app = Sanic('test_MiddlewareMixin_on_response')
    app.on_response(test_middleware)
    assert app._future_middleware[0].middleware == test_middleware
    assert app._future_middleware[0].attach_to == 'response'



# Generated at 2022-06-24 04:08:16.952938
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware()
    async def test_middleware(request):
        return


# Generated at 2022-06-24 04:08:18.017170
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    app = Sanic()

# Generated at 2022-06-24 04:08:19.416491
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    assert mm._future_middleware == []


# Generated at 2022-06-24 04:08:22.027141
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    logger=logging.getLogger(__name__)
    logger.info("Test: Start to test the on_response method.")
    assert 1 == 1
    logger.info("Test passed.")

# Generated at 2022-06-24 04:08:31.978239
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m = types.ModuleType("m")
    setattr(m, "MiddlewareMixin", MiddlewareMixin)
    exec("import json", m.__dict__)
    exec("import logging", m.__dict__)
    exec("import unittest", m.__dict__)
    exec("import types", m.__dict__)
    exec("import sanic", m.__dict__)
    exec("import sanic.testing as testing", m.__dict__)
    exec("import sanic.response as response", m.__dict__)
    exec("import sanic.log as log", m.__dict__)
    exec("import sanic.config as config", m.__dict__)
    exec("import sanic.exceptions as exceptions", m.__dict__)

# Generated at 2022-06-24 04:08:35.458260
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
  tmp = MiddlewareMixin()
  assert callable(tmp.on_response())
  assert callable(tmp.on_response(middleware=lambda x: x))

# Generated at 2022-06-24 04:08:36.907983
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    a = 1
    assert a == 1


# Generated at 2022-06-24 04:08:37.562874
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    MiddlewareMixin()

# Generated at 2022-06-24 04:08:40.614100
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert callable(MiddlewareMixin.on_response(MiddlewareMixin, None))
    assert callable(MiddlewareMixin.on_response(MiddlewareMixin, lambda: None))


# Generated at 2022-06-24 04:08:51.627393
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from unittest.mock import MagicMock
    from sanic.app import Sanic

    app = Sanic("test_MiddlewareMixin_middleware")

    def test_middleware(request):
        return request

    def test_async_middleware(request):
        return request

    app.middleware(test_middleware)
    app.middleware(test_async_middleware)
    assert len(app._future_middleware) == 2

    # For Sanic app, _apply_middleware should call app.add_route
    # Check that calling middleware function sets defaults correctly
    app.add_route = MagicMock()

    app._apply_middleware(app._future_middleware[0])

# Generated at 2022-06-24 04:08:52.204842
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass

# Generated at 2022-06-24 04:08:55.448928
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    mm = MiddlewareMixin()
    mm.on_request()


# Generated at 2022-06-24 04:09:00.413068
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')

    @app.on_response()
    async def on_response(request, response):
        pass

    assert len(app._future_middleware) == 1

    @app.on_response()
    async def on_response1(request, response):
        pass

    assert len(app._future_middleware) == 2


# Generated at 2022-06-24 04:09:10.387303
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from .utils import Sanic
    from sanic.response import text
    from unittest import mock

    app = Sanic()

    async def response_handler(request, response):
        pass

    app.on_response(response_handler)

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "response"
    assert app._future_middleware[0].handler == response_handler

    request, _ = app.test_client.get('/')
    response = text('Response.')

    with mock.patch(
        'sanic.models.futures.FutureMiddleware.execute',
        return_value=response
    ) as mock_method:
        result = app._future_middleware[0].execute(request, response)

        assert result == response


# Generated at 2022-06-24 04:09:14.447692
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    init = MiddlewareMixin(1, 2, a=3, b=4)
    assert init._future_middleware == []
    assert init.on_request(5) == init.middleware(5, 'request')
    assert init.on_response(5) == init.middleware(5, 'response')

# Generated at 2022-06-24 04:09:16.227409
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    print("\tUnit test for MiddlewareMixin method on_request")
    assert True

# Generated at 2022-06-24 04:09:22.850058
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic()
    app.middleware(middleware_or_request='request', attach_to='request')
    app.middleware({}, 'response', apply=True)
    app.middleware(middleware_or_request=middleware, attach_to='response')
    app.on_request({})
    app.on_response(lambda f: f)
    app.on_response()(lambda f: f)

# Generated at 2022-06-24 04:09:24.151900
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    def func():
        pass
    assert MiddlewareMixin().on_request(middleware=func)

# Generated at 2022-06-24 04:09:31.942313
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import os
    import sys
    import pytest
    from pathlib import Path

    myPath = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, myPath + "/../")

    from sanic.app import Sanic

    app = Sanic()

    @app.middleware
    def my_middleware(request):
        print("I am middleware")

    assert app._future_middleware
    assert app._middleware
    assert app._middleware[0].function.__name__ == 'my_middleware'
    assert app._middleware[0].attach_to == 'request'

    @app.middleware('response')
    def my_middleware2(request, response):
        print("I am middleware2")

    assert app._future_middleware

# Generated at 2022-06-24 04:09:42.833368
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import unittest
    
    class CustomMiddleware(MiddlewareMixin):
        def __init__():
            super().__init__()
        
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
        
    class TestMiddlewareMixin(unittest.TestCase):

        def test_on_response(self):
            """
            Checking whether the function on_response() behaves as expected.
            """
            app = CustomMiddleware()

            def middleware1(request):
                return request

            def middleware2(request):
                return request

            self.assertEqual(
                app.on_response(), partial(app.middleware, attach_to="response")
            )
            self.assertEqual(app.on_response(middleware1), middleware1)

# Generated at 2022-06-24 04:09:45.207491
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic

    app = Sanic(__name__)
    assert isinstance(app, MiddlewareMixin)

# Generated at 2022-06-24 04:09:52.752593
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware):
            pass

    middleware_mixin = TestMiddlewareMixin()
    middleware_mixin.middleware(lambda: None, "request", True)
    assert len(middleware_mixin._future_middleware) == 1
    assert middleware_mixin._future_middleware[0].middleware is not None
    assert middleware_mixin._future_middleware[0].attach_to == "request"



# Generated at 2022-06-24 04:09:56.225521
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.protocol import HttpProtocol

    # setup
    http_protocol = HttpProtocol(app=None, loop=None)
    # action
    http_protocol.on_request(middleware=None)

    # assert
    assert hasattr(http_protocol, 'on_request')
    


# Generated at 2022-06-24 04:10:01.378556
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    a = MiddlewareMixin()
    assert isinstance(a._future_middleware, list)
    assert len(a._future_middleware) == 0


# Generated at 2022-06-24 04:10:07.199512
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class App(MiddlewareMixin):
        def __init__(
            self,
            *args,
            **kwargs,
        ):
            super().__init__(*args, **kwargs)

        def assert_MiddlewareMixin_on_response():
            _self = App()

            @_self.on_response(middleware=None)
            def _test_on_response():
                return True

            # todo:
            # assert _test_on_response()

        assert_MiddlewareMixin_on_response()

# Generated at 2022-06-24 04:10:10.678386
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Arrange
    # Act
    inst = MiddlewareMixin()
    # Assert
    assert type(inst._future_middleware) is list
    assert isinstance(inst, MiddlewareMixin)



# Generated at 2022-06-24 04:10:19.641128
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # 1. Test if middleware is being called
    class TestMiddleware(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            assert middleware.middleware == True

    middleware = TestMiddleware()

    @middleware
    def middleware_func():
        pass

    # 2. Test if middleware is implemented correctly.
    class TestMiddleware(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            assert middleware.middleware == True

    middleware = TestMiddleware()

    @middleware.middleware
    def middleware_func():
        pass

# Generated at 2022-06-24 04:10:26.849548
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from pathlib import Path
    from sanic.app import Sanic
    import sanic.response
    import requests
    import time

    # Create the Sanic app
    app = Sanic("test_MiddlewareMixin_on_response")

    # This is the response modification middleware
    @app.middleware("response")
    def example_middleware(request, response):
        assert isinstance(response, sanic.response.HTTPResponse)
        return response

    # This is the response modification middleware
    @app.on_response("response")
    def example_middleware(request, response):
        assert isinstance(response, sanic.response.HTTPResponse)
        return response

    # Override the default test client

# Generated at 2022-06-24 04:10:28.662577
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    x = MiddlewareMixin()
    assert x.on_request()(object)
    assert x.on_request(1)()(object) is not None


# Generated at 2022-06-24 04:10:32.552282
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    mwmix = MiddlewareMixin()
    @mwmix.on_request()
    def handler(request):
        return request
    assert handler() == None
    assert mwmix._future_middleware[0].middleware() == None


# Generated at 2022-06-24 04:10:36.962732
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class App(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass
    app = App()
    app.on_request()


# Generated at 2022-06-24 04:10:45.755620
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic import response
    assert issubclass(Sanic, MiddlewareMixin) is True
    assert callable(Sanic.middleware) is True
    assert callable(Sanic.on_request) is True
    assert callable(Sanic.on_response) is True

    app = Sanic(__name__)
    @app.middleware
    async def m1(request):
        return response.text('OK')

    @app.on_request
    async def m2(request):
        return response.text('OK')

    @app.on_response
    async def m3(request, response):
        return await response.text('OK')

# Generated at 2022-06-24 04:10:46.326588
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

# Generated at 2022-06-24 04:10:49.381640
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
  # mock request object
  req = Mock()
  # mock middleware
  mid = MagicMock()
  mid.return_value = None
  mix = MiddlewareMixin()
  mix.on_request(middleware=mid)(req)
  mid.assert_called_with(req)

# Generated at 2022-06-24 04:10:59.094924
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("MiddlewareMixin_middleware")

    @app.route("/")
    async def handler(request):
        return text("OK")

    @app.middleware("request")
    async def request_middleware(request):
        pass

    @app.middleware("response")
    async def response_middleware(request, response):
        pass

    @app.middleware("request")
    async def request_middleware2(request):
        pass

    @app.middleware("response")
    async def response_middleware2(request, response):
        pass

    @app.route("/response_error")
    async def handler2(request):
        return text("OK")


# Generated at 2022-06-24 04:11:03.348759
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.sanic import Sanic
    app = Sanic(__name__)
    # test for constructor
    assert app._future_middleware == []


# Generated at 2022-06-24 04:11:11.108353
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    from sanic import Blueprint

    class FooMiddleware:
        async def request(self):
            return True

        async def response(self):
            return False

    m = MiddlewareMixin()
    assert m._future_middleware == []

    m = Sanic()
    assert m._future_middleware == []
    assert m.on_response is not None

    m = Blueprint()
    assert m._future_middleware == []
    assert m.on_response is not None

# Generated at 2022-06-24 04:11:17.825000
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Given
    from sanic.app import Sanic
    import asyncio
    import sys
    app = Sanic(__name__)

    # When
    app.config.REQUEST_TIMEOUT = 30
    app.config.KEEP_ALIVE = False
    app.config.REQUEST_MAX_SIZE = 100000
    app.config.RESPONSE_TIMEOUT = 30
    test_loop = asyncio.new_event_loop()
    asyncio.set_event_loop(test_loop)
    loop = asyncio.get_event_loop()

    # Then
    assert app.loop is None
    assert app.name == 'sanic.app'
    assert app.config.REQUEST_TIMEOUT == 30
    assert app.config.KEEP_ALIVE == False
    assert app.config.REQUEST_

# Generated at 2022-06-24 04:11:23.759760
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
 
    from sanic.app import Sanic
 
    app = Sanic(__name__)
    assert type(app.middleware('request')) is partial
    assert app._future_middleware == []
    assert app.middleware == app.on_request
    assert type(app.middleware('response')) is partial
    assert app.middleware == app.on_response

# Generated at 2022-06-24 04:11:30.851207
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.sanic import Sanic
    app = Sanic("asdf")
    del app._future_middleware[:]
    assert app._future_middleware == []
    @app.middleware
    def default(request):
        pass
    assert isinstance(default,partial)
    assert app._future_middleware == [FutureMiddleware(default, 'request')]
    assert default.attach_to == 'request'
    assert default.middleware == default.func
    @app.middleware("response")
    def custom(request):
        pass
    assert isinstance(custom,partial)
    assert app._future_middleware == [FutureMiddleware(default, 'request'), FutureMiddleware(custom, 'response')]
    assert custom.attach_to == 'response'
    assert custom.middleware == custom.func

#

# Generated at 2022-06-24 04:11:40.120546
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from unittest import TestCase
    from unittest.mock import Mock

    class _MiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.middleware = Mock()

    # 0. on_response with no middleware
    _MiddlewareMixin().on_response()()
    assert _MiddlewareMixin.middleware.assert_called_with(
        attach_to='response'
    )

    # 1. on_response with a middleware
    class Middleware: pass
    middleware = Mock(spec_set=Middleware)
    _MiddlewareMixin().on_response(middleware)()
    assert middleware.attach_to == 'response'

# Generated at 2022-06-24 04:11:40.761755
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

# Generated at 2022-06-24 04:11:45.860738
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    m = MiddlewareMixin()
    def middleware(request):
        return request

    m.on_response(middleware)
    assert m._future_middleware[0]._future_middleware == middleware
    assert m._future_middleware[0]._when == "response"
    m.on_response()

# Generated at 2022-06-24 04:11:55.509006
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            assert middleware.middleware_or_request is not None
            assert middleware.attach_to is not None

    testMixin=TestMixin()

    # test _apply_middleware
    testMixin._apply_middleware(FutureMiddleware(lambda request: None, "response"))
    # test middleware decorator
    @testMixin.middleware
    def test_middleware_decorator():
        assert True

    @testMixin.middleware('response')
    def test_middleware_decorator2():
        assert True

    assert len(testMixin._future_middleware) == 2
    # test two another decorator

# Generated at 2022-06-24 04:12:03.035393
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic

    app = Sanic()

    @app.on_response
    def on_response(request, *response):
        assert response[0].text == "hi"
        assert request.on_response_called is True

    @app.route("/")
    async def test(request):
        request.on_response_called = True
        return text("hi")

    request, response = app.test_client.get("/")

    assert response.text == "hi"



# Generated at 2022-06-24 04:12:11.783521
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestReq:
        def __init__(self):
            self.middles = []

    class TestRes:
        def __init__(self):
            self.middles = []

    def test_middleware_func(req, res):
        assert isinstance(req, TestReq)
        assert isinstance(res, TestRes)
        req.middles.append(req)
        res.middles.append(res)

    class ChildClass(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            test_middleware = middleware.middleware(
                TestReq(), TestRes()
            )
            assert test_middleware is middleware.middleware

    child_class = ChildClass()

    # decorator
    assert child_class.middleware == child_class

# Generated at 2022-06-24 04:12:15.148815
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    TestMiddlewareMixin()

# Generated at 2022-06-24 04:12:22.527822
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    @app.middleware('request')
    async def add_timestamp(request):
        request['time'] = time.time()

    class F(MiddlewareMixin):
        def __init__(self):
            super(MiddlewareMixin,self).__init__()
            self.time = None
        def _apply_middleware(self, middleware: FutureMiddleware):
            if middleware.attach_to == 'request':
                self.time = middleware.middleware(self)

    f = F()
    assert f.time != None

# Generated at 2022-06-24 04:12:24.501962
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app=Sanic()
    assert app.middleware(lambda x:x)


# Generated at 2022-06-24 04:12:30.893406
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    class FutureMiddleware:
        def __init__(self, middleware, attach_to):
            self.middleware = middleware
            self.attach_to = attach_to

    app = Sanic()

    # test not callable
    app.on_response()('response')

    # test callable
    app.on_response(lambda r, s: 'Next')('response')

# Generated at 2022-06-24 04:12:37.939283
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')

    @app.on_request
    async def test_on_request(request):
        return request

    @app.on_response
    async def test_on_response(request, response):
        return response

    @app.route('/test_on_response')
    @app.on_response
    async def handler(request):
        return response


# Generated at 2022-06-24 04:12:44.361153
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class _MiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    instance_MiddlewareMixin = _MiddlewareMixin()

    def _middleware():
        pass
    instance_MiddlewareMixin.middleware(_middleware)
    assert instance_MiddlewareMixin._future_middleware

# Generated at 2022-06-24 04:12:45.833595
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    obj = MiddlewareMixin()
    assert obj.on_response()



# Generated at 2022-06-24 04:12:56.860309
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Foo(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    foo = Foo()
    assert foo._future_middleware == []
    foo.middleware(None)
    foo._future_middleware[0].middleware == None
    foo._future_middleware[0].attach_to == "request"
    foo.middleware(attach_to="request")
    def test_foo():
        pass
    foo.middleware(test_foo)
    foo._future_middleware[1].middleware == test_foo
    foo._future_middleware[1].attach_to == "request"
    foo.middleware(attach_to="response")
    foo._future_middleware[2].middleware == test_foo

# Generated at 2022-06-24 04:13:00.022577
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestApp(MiddlewareMixin):
        pass

    app = TestApp()
    assert app.on_response == app.middleware('response')
    assert app.on_response('test') == 'test'


# Generated at 2022-06-24 04:13:04.194108
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # TODO: test no arguments
    assert isinstance(MiddlewareMixin(), MiddlewareMixin)
    assert isinstance(MiddlewareMixin(5), MiddlewareMixin)
    # TODO: test args and kwargs


# Generated at 2022-06-24 04:13:13.844767
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic()

    @app.middleware('request')
    async def before_request(request):
        request['test_before'] = True

    @app.middleware('response')
    async def after_request(request, response):
        response.headers['test_after'] = True
        return response

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert request.get('test_before') == True
    assert response.headers.get('test_after') == True


# Generated at 2022-06-24 04:13:16.026275
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()._future_middleware == []

# Generated at 2022-06-24 04:13:19.303770
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    m = MiddlewareMixin()
    @m.on_response()
    def response(request, response):
        return response
    assert m._future_middleware[0].middleware() == response

# Generated at 2022-06-24 04:13:23.384890
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class App(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

    @App().on_request
    def test_request():
        pass
    assert len(App._future_middleware) == 1

# Generated at 2022-06-24 04:13:28.862929
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()

    @app.on_response
    def process_response(request, response):
        assert request.method == "GET"
        assert response.method == "GET"

    @app.route("/")
    async def test(request):
        return response.text("OK")

    _, response = app.test_client.get("/")
    assert response.text == "OK"

# Generated at 2022-06-24 04:13:33.001987
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    """
    Test MiddlewareMixin.on_response method.
    """
    def _assert_response_middleware(middleware=None):
        """
        Test if the middleware is registered to the response.
        """
        if callable(middleware):
            return middleware, "response"
        else:
            return partial(middleware, middleware_args="response")

# Generated at 2022-06-24 04:13:38.234666
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
  import sanic
  def on_request(request):
    pass
  app = sanic.Sanic('test')
  app.on_request(on_request)
  assert app._future_middleware == [sanic.middleware.FutureMiddleware(on_request, 'request')]
  # key: app._future_middleware
  # value: middleware
  

# Generated at 2022-06-24 04:13:46.550881
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    test = MiddlewareMixin()

    # Use decorator
    @test.on_response
    def first_method(): return

    # Use decorator with attach_to
    # (i.e. use callback directly)
    @test.on_response('response')
    def second_method(): return

    # Use callback with attach_to
    # (i.e. use callback directly)
    test.middleware(
        lambda x: x,
        attach_to="response",
        apply=False
    )

    for middleware in test._future_middleware:
        assert middleware.attach_to == 'response'

# Generated at 2022-06-24 04:13:53.654764
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import json

    from sanic import Sanic
    from sanic.response import text

    app = Sanic("test_MiddlewareMixin_on_request")

    @app.on_request
    def f(request):
        return text("test_MiddlewareMixin_middleware")

    request, response = app.test_client.get(
        "/", headers={"Accept-Encoding": "gzip"}
    )

    assert json.loads(response.text) == "test_MiddlewareMixin_middleware"


# Generated at 2022-06-24 04:14:02.913705
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    @Sanic().middleware
    async def example_middleware(request):
        return text('Passed through middleware')


    # Make sure it calls the middleware
    request, response = Sanic().test_client.get('/')
    assert response.text == 'Passed through middleware'

    # Make sure decorators work
    @Sanic().middleware('response')
    async def example_response_middleware(request, response):
        response.text = response.text + ' Passed through middleware'


    request, response = Sanic().test_client.get('/')
    assert response.text == 'Passed through middleware Passed through middleware'



# Generated at 2022-06-24 04:14:05.540780
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # prelamb
    # act
    newInstance = MiddlewareMixin()
    newInstance.on_response(middleware=None)


# Generated at 2022-06-24 04:14:16.252220
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text
    from sanic.exceptions import ServerError
    from sanic import Blueprint

    app = Sanic("test_MiddlewareMixin_on_response")

    # Unit test for method on_response of class Sanic
    @app.on_response
    def say_hello(request, response):
        print("hello")

    @app.listener("before_server_start")
    async def before_server_start(app_obj, loop):
        return "before_server_start"

    assert app._middleware["response"] == [say_hello]
    assert app._listeners["before_server_start"] == [before_server_start]
    assert app.before_server_start([]) == "before_server_start"
    result = app._apply_middleware

# Generated at 2022-06-24 04:14:24.382838
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddleware(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError

    app = TestMiddleware()
    @app.on_request()
    async def mw1(request):
        return 'mw1'

    async def mw2(request):
        return 'mw2'

    @TestMiddleware.on_request(app)
    async def mw3(request):
        return 'mw3'

    @TestMiddleware.on_request(app)
    def mw4(request):
        return 'mw4'


# Generated at 2022-06-24 04:14:34.501433
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    app = Sanic()

    @app.middleware
    async def print_on_request(request):
        print("I am in on_request middleware")

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I am in on_response middleware")

    @app.route('/')
    async def handler(request):
        print("I am in request")
        return HTTPResponse(status = 200)

    app.test_client.get('/')

# Generated at 2022-06-24 04:14:37.117332
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    instance_of_MiddlewareMixin = MiddlewareMixin()
    assert isinstance(instance_of_MiddlewareMixin, MiddlewareMixin)
    assert instance_of_MiddlewareMixin._future_middleware == []


# Generated at 2022-06-24 04:14:38.680663
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    deco = on_request(test_MiddlewareMixin_on_request)



# Generated at 2022-06-24 04:14:42.122480
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    for middleware_or_request in [lambda x: x, 'request']:
        mixin = MiddlewareMixin()
        mixin.middleware(middleware_or_request)
        assert len(mixin._future_middleware) == 1



# Generated at 2022-06-24 04:14:43.914203
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    def f(request):
        return 'request'
    # Call static method on_request of class MiddlewareMixin
    result = MiddlewareMixin.on_request(f)
    print(result)
    assert result == 'request'

# Generated at 2022-06-24 04:14:45.412646
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic("sanic-server")
    assert app.on_request(middleware=None) is not None

# Generated at 2022-06-24 04:14:55.995362
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """Tests for method middleware of class Middleware."""
    from sanic.exceptions import SanicException

    @MiddlewareMixin.middleware  # noqa
    def middleware_decorator(request):
        pass

    @MiddlewareMixin.middleware('request')  # noqa
    def middleware_decorator_request(request):
        pass

    @MiddlewareMixin.middleware('response')  # noqa
    def middleware_decorator_response(request):
        pass

    @MiddlewareMixin.middleware  # noqa
    def middleware_decorator_with_default_request(request, response):
        pass

    @MiddlewareMixin.middleware  # noqa
    def middleware_decorator_result_is_response(request, response):
        return response



# Generated at 2022-06-24 04:14:58.207200
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    m = MiddlewareMixin()

    @m.on_response()
    def onresponse():
        pass

    assert isinstance(onresponse, partial)

# Generated at 2022-06-24 04:15:00.394731
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    @Sanic.on_response(middleware=None)
    def test_func():
        pass

# Generated at 2022-06-24 04:15:03.651821
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class T(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self.init = True


    t = T()
    assert t.init is True
    assert t._future_middleware == []

# Generated at 2022-06-24 04:15:05.950378
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    with pytest.raises(NotImplementedError):
        mid_mix = MiddlewareMixin()
        mid_mix._apply_middleware(FutureMiddleware(None, None))

# Generated at 2022-06-24 04:15:13.184527
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic()

    @app.on_response
    def test_on_response_middleware_with_args(request, response):
        return

    @app.on_response()
    def test_on_response_middleware_without_args(request, response):
        return

    @app.on_response("response_middleware_with_args", "response")
    def test_on_response_middleware_with_args(request, response):
        return

    @app.on_response("response_middleware_without_args")
    def test_on_response_middleware_without_args(request, response):
        return



# Generated at 2022-06-24 04:15:17.372495
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    self = MiddlewareMixin()
    self._future_middleware = []
    self._apply_middleware = lambda x: None

    @self.middleware
    def middleware():
        pass

    assert len(self._future_middleware) == 1



# Generated at 2022-06-24 04:15:22.307353
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    class Sanic_test(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    s = Sanic_test()
    assert s.middleware(None, attach_to="request")() == s.on_request()()


# Generated at 2022-06-24 04:15:29.499842
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
    testMiddlewareMixin = TestMiddlewareMixin()
    test_middleware = testMiddlewareMixin.on_response(middleware=None)
    assert test_middleware.keywords['attach_to'] == 'response'
    assert test_middleware.func == testMiddlewareMixin.middleware


# Generated at 2022-06-24 04:15:38.277675
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert MiddlewareMixin.middleware.__doc__.startswith(
        "Decorate and register middleware to be called before a request.\n"
        "Can either be called as *@app.middleware* or\n"
        "*@app.middleware('request')*\n"
        "\n"
        "`See user guide re: middleware\n"
        "<https://sanicframework.org/guide/basics/middleware.html>`__\n"
        "\n"
        ":param: middleware_or_request: Optional parameter to use for\n"
        "    identifying which type of middleware is being registered.\n"
    )



# Generated at 2022-06-24 04:15:49.003054
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware
    from sanic.models.middleware import Middleware
    from sanic.models.middleware import MiddlewareManager

    app = Sanic("test_MiddlewareMixin_middleware")

    # test for MiddlewareMixin.middleware
    def middleware_test(request):
        pass

    app.middleware(middleware_test)
    assert isinstance(app._future_middleware[0], FutureMiddleware)

    # test for MiddlewareMixin.on_request
    app.on_request(middleware_test)
    assert isinstance(app._future_middleware[1], FutureMiddleware)
    assert app._future_middleware[1].attach_to == "request"

    # test for MiddlewareMixin.on

# Generated at 2022-06-24 04:15:51.468253
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    on_response_test = MiddlewareMixin()
    on_response_test.on_response(on_response_test)
    assert on_response_test._future_middleware is not None

# Generated at 2022-06-24 04:15:55.756990
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from unittest.mock import MagicMock
    from collections import namedtuple

    middleware: MiddlewareMixin = MiddlewareMixin()
    app = MagicMock(middleware=middleware)
    fn = MagicMock()
    fn("on_response")
    app.middleware.on_response("on_response")
    assert fn.call_count == 1