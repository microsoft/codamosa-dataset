

# Generated at 2022-06-24 04:05:53.744042
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert middleware.middleware is MiddlewareMixin.middleware



# Generated at 2022-06-24 04:05:55.511063
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    a=MiddlewareMixin()
    register_middleware(middleware, attach_to='request')
    return middleware

# Generated at 2022-06-24 04:06:05.922425
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    print('class MiddlewareMixin: def on_request(self, middleware=None):')
    class MiddlewareMixin_test(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    middleware_mixin_test = MiddlewareMixin_test()
    def middleware_test(middleware, attach_to="request"):
        middleware_mixin_test._future_middleware.append(FutureMiddleware(middleware, attach_to))
    middleware_mixin_test.register_middleware = middleware_test
    middleware_mixin_test.on_request(middleware_test)
    assert middleware_mixin_test._future_middleware[0].middleware == middleware_test
    assert middleware_mixin_test._future_middleware

# Generated at 2022-06-24 04:06:09.534876
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class SampleClass(MiddlewareMixin):
        pass
   
    sc = SampleClass()
    sc.on_response()

# Generated at 2022-06-24 04:06:11.355004
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert middleware

# Generated at 2022-06-24 04:06:18.014073
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
  from sanic.app import Sanic
  from sanic.blueprints import Blueprint
  from sanic_restplus import Api, Resource, Namespace

  app = Sanic()
  api = Api(app)
  instance_api = Api(app,prefix="/api")

  assert len(list(instance_api.spec.operation_ids)) == 0
  
  bp = Blueprint("test_bp", url_prefix="/test")
  bp_api = Api(bp, prefix="/bp")

  bp2 = Blueprint("test_bp2")
  bp2_api = Api(bp2, prefix="/bp2")

  bp3 = Blueprint("test_bp3", url_prefix="/bp3")
  bp3_api = Api(bp3, prefix="/bp3", decorators=[])


# Generated at 2022-06-24 04:06:26.203088
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.called = False

        def _apply_middleware(self, middleware: FutureMiddleware):
            if middleware.attach_to == "request" and callable(middleware.middleware):
                self.called = True

    testClass = TestClass()
    test_func = lambda x, y: x + y
    testClass.on_request(test_func)
    assert testClass.called


# Generated at 2022-06-24 04:06:29.753880
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin = MiddlewareMixin()
    callable_on_request = middleware_mixin.on_request(middleware=None)
    not_callable_on_request = middleware_mixin.on_request(middleware=None)
    print(callable_on_request, not_callable_on_request)



# Generated at 2022-06-24 04:06:33.007864
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test:
        def __init__(self):
            self._future_middleware = []
    test = Test()
    assert test._future_middleware == []
    @test.middleware
    def test_middleware(request):
        return "output"
    assert test._future_middleware[0].middleware == test_middleware
    assert test.middleware


# Generated at 2022-06-24 04:06:39.249669
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    assert app.middleware is MiddlewareMixin.middleware
    assert app.on_request is MiddlewareMixin.on_request
    assert app.on_response is MiddlewareMixin.on_response



# Generated at 2022-06-24 04:06:47.569532
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []


        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    obj = Test()
    assert obj._future_middleware == []
    obj.middleware(None)
    assert obj._future_middleware == []
    obj.middleware(None, attach_to="OK")
    assert obj._future_middleware == []
    obj.middleware(None, attach_to="OK", apply=True)
    assert len(obj._future_middleware) == 1

# Generated at 2022-06-24 04:06:48.295212
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-24 04:06:53.547435
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    mymiddlewaremixin = MiddlewareMixin()

    assert callable(mymiddlewaremixin.on_request())
    assert callable(mymiddlewaremixin.on_request(None))
    assert hasattr(mymiddlewaremixin, '_future_middleware')


# Generated at 2022-06-24 04:07:01.069352
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class FakeMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    m = FakeMiddlewareMixin

    def handle(request):
        pass
    m.on_response(handle)
    assert m._future_middleware[0].middleware == handle

# Generated at 2022-06-24 04:07:08.657289
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test')
    test_state = {'test' : False}
    @app.on_request
    def handler(req):
        test_state['test'] = True
    assert not test_state['test']
    @app.route('/')
    def handler(req):
        assert test_state['test']
        return text('OK')
    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-24 04:07:11.019878
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    assert type(mm._future_middleware) is list
    assert len(mm._future_middleware) == 0

test_MiddlewareMixin()

# Generated at 2022-06-24 04:07:12.887112
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin._future_middleware == []


# Generated at 2022-06-24 04:07:16.709720
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    app = Sanic(__name__)
    assert isinstance(app, MiddlewareMixin)

# Generated at 2022-06-24 04:07:19.363114
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin = MiddlewareMixin()

    assert mixin == None

# Generated at 2022-06-24 04:07:22.481117
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Test for instance of class MiddlewareMixin
    async def test_function():
        pass
    middleware_mixin = MiddlewareMixin()
    middleware = middleware_mixin.on_request(test_function)
    middleware()

# Generated at 2022-06-24 04:07:29.510129
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixinTest(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            self._future_middleware = []
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware):
            self._future_middleware.append(middleware)

    @MiddlewareMixinTest.middleware
    async def append_before(request):
        return request

    @MiddlewareMixinTest.middleware('response')
    async def append_after(request, response):
        return response

    mm = MiddlewareMixinTest()
    assert len(mm._future_middleware) == 2
    
    assert mm._future_middleware[0].name == "append_before"

# Generated at 2022-06-24 04:07:32.498591
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert(
        MiddlewareMixin.on_request(lambda x:x) 
        == partial(MiddlewareMixin.middleware, attach_to="request")
    )


# Generated at 2022-06-24 04:07:33.570415
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert callable(MiddlewareMixin.on_response)


# Generated at 2022-06-24 04:07:40.170076
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Instantiation
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    # Test middleware
    @app.middleware
    async def test_middleware(request):
        return 'Hello World!'

    from sanic.response import text

    @app.get('/')
    async def handler(request):
        return text('OK')

    # Sanic client
    from sanic import SanicTestClient
    client = SanicTestClient(app)

    # Prepare request
    request, _ = client.get(url_='/')

    # Call handler
    resp = handler(request)
    assert resp.body == b'OK'
    assert resp.body == b'Hello World!'


# Generated at 2022-06-24 04:07:46.985459
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super(TestMiddlewareMixin, self).__init__()

        def _apply_middleware(self, middleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(lambda request, response: None)
    assert len(test_middleware_mixin._future_middleware) == 1


# Generated at 2022-06-24 04:07:48.046094
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mid = MiddlewareMixin()
    assert mid._future_middleware == []

# Generated at 2022-06-24 04:07:55.906694
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Server:
        def __init__(self, *args, **kwargs):
            self._future_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)

        def on_request(self, middleware=None):
            if callable(middleware):
                return self.middleware(middleware, "request")
            else:
                return partial(self.middleware, attach_to="request")

        def middleware(self, middleware_or_request, attach_to="request", apply=True):
            def register_middleware(middleware, attach_to="request"):
                nonlocal apply

                future_middleware = FutureMiddleware(middleware, attach_to)

# Generated at 2022-06-24 04:08:00.262975
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware
    import pytest
    app = Sanic(__name__)
    app.config.from_pyfile('test.cfg')
    instance = MiddlewareMixin(app)
    assert isinstance(instance,MiddlewareMixin)
    assert isinstance(instance._future_middleware, list)
    assert app.config['DEBUG'] == True

# Generated at 2022-06-24 04:08:02.281244
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    example = MiddlewareMixin()
    assert len(example._future_middleware) == 0



# Generated at 2022-06-24 04:08:11.001049
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.middleware import MiddlewareMixin
    from sanic.models.futures import FutureMiddleware
    from inspect import isfunction
    import types

    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    tmm=TestMiddlewareMixin()
    # using @tmm.middleware
    @tmm.middleware
    def middleware():
        pass

    assert isfunction(middleware)
    assert isinstance(tmm._future_middleware[0].middleware,types.FunctionType)
    assert(middleware == tmm._future_middleware[0].middleware)
    assert(tmm._future_middleware[0].when=="request")

    # using @tmm.middleware('response')


# Generated at 2022-06-24 04:08:15.376059
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    def _mw(request):
        assert request.path == "/"
        return request
    mm = MiddlewareMixin()
    mm._apply_middleware = _mw
    assert mm.middleware(_mw, attach_to="request")
    assert mm.on_request(_mw)
    assert mm.on_response(_mw)


# Generated at 2022-06-24 04:08:23.306527
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class X(MiddlewareMixin):
        pass
    x = X()
    # test for register_middleware that called by partial
    @x.middleware('request')
    def middleware(request):
        pass
    assert len(x._future_middleware) == 1
    fut_middleware = x._future_middleware[0]
    assert fut_middleware.middleware == middleware
    assert fut_middleware.attach_to == 'request'
    # test for register_middleware that called by @middleware('request') directly
    @x.middleware('response')
    def middleware2(request):
        pass
    assert len(x._future_middleware) == 2
    fut_middleware = x._future_middleware[1]
    assert fut_middleware.middleware == middleware2
    assert fut

# Generated at 2022-06-24 04:08:25.536331
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = MiddlewareMixin()
    @app.on_request
    def hello(request):
        print("hello")



# Generated at 2022-06-24 04:08:27.326068
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin


# Generated at 2022-06-24 04:08:29.149808
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    test_var = MiddlewareMixin()
    assert test_var._future_middleware == []


# Generated at 2022-06-24 04:08:33.011218
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # callable(middleware)
    test = MiddlewareMixin()
    test.on_response(on_response_handler_1)
    assert (test._future_middleware[0].handle == on_response_handler_1)
    # not callable(middleware)
    test.on_response(middleware="request")
    assert (test._future_middleware[1].handle == None)



# Generated at 2022-06-24 04:08:44.403708
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import unittest

    class MiddlewareMixinTest(unittest.TestCase):
        class TestObj(MiddlewareMixin):
            def __init__(self):
                MiddlewareMixin.__init__(self)
                self._middleware_registry = []

            def _apply_middleware(self, middleware: FutureMiddleware):
                self._middleware_registry.append(middleware)

        def test_MiddlewareMixin_middleware(self):
            testObj = MiddlewareMixinTest.TestObj()
            testObj.middleware(lambda *arg: None, 'request')
            self.assertEqual(len(testObj._future_middleware), 1,
                             'When call middleware method, _future_middleware should increase by 1.')

    unittest.main()



# Generated at 2022-06-24 04:08:45.153775
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    MiddlewareMixin()

# Generated at 2022-06-24 04:08:47.533914
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
	mm = MiddlewareMixin()
	if not mm._future_middleware:
		assert True
	else:
		assert False


# Generated at 2022-06-24 04:08:56.996840
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic("test_aio_server")

    @app.on_response
    def test_on_response(request, response):
        """
        Print successful request's response.
        """
        if request.method == "GET" and request.path == "/":
            print("On response: {}".format(response))

    assert "test_on_response" in [
        i.middleware.__name__ for i in app._future_middleware
    ]

    app.future_middleware = []

    @app.middleware("response")
    def test_middleware_response(request, response):
        """
        Print successful request's response.
        """

# Generated at 2022-06-24 04:08:59.821541
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    app = Sanic()
    assert isinstance(app, MiddlewareMixin)
    assert "middleware" not in dir(app)


# Generated at 2022-06-24 04:09:05.976229
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic(__name__)

    @app.middleware
    async def print_on_request(request):
        print("I am in print_on_request middleware")

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.text == "OK"



# Generated at 2022-06-24 04:09:15.613878
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic(name="sanic19_unit_test")

    @app.on_request
    def simple_request_middleware(request):
        return request

    @app.on_response
    def simple_response_middleware(request, response):
        return response

    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == simple_request_middleware
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[1].middleware == simple_response_middleware
    assert app._future_middleware[1].attach_to == "response"


# Generated at 2022-06-24 04:09:21.009550
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    async def before_request(request):
        print('Before request')

    request, response = app.test_client.get('/')
    assert response.status == 404
    assert response.text == '404: Not Found'


# Generated at 2022-06-24 04:09:23.541579
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MyMiddlewareMixin(MiddlewareMixin):
        pass

    mixin = MyMiddlewareMixin()
    assert isinstance(mixin._future_middleware, List)

# Generated at 2022-06-24 04:09:25.223710
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Test function middleware
    assert 1 == 2
    # Test partial middleware
    assert 1 == 2

# Generated at 2022-06-24 04:09:34.999432
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test:
        def __init__(self):
            self._future_middleware = []
            self._apply_middleware = lambda m: self._future_middleware.append(m)
            self.middleware = MiddlewareMixin.middleware
            self.on_request = MiddlewareMixin.on_request
            self.on_response = MiddlewareMixin.on_response

    # 1. Test method middleware
    # test middleware as decorator
    test = Test()
    @test.middleware
    def test_middleware(request):
        return request
    assert len(test._future_middleware) == 0
    assert test._future_middleware == []
    assert type(test.middleware) == types.MethodType
    assert type(test.on_request) == types.MethodType

# Generated at 2022-06-24 04:09:37.089768
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    try:
        MiddlewareMixin()
        assert True
    except:
        assert False


# Generated at 2022-06-24 04:09:46.354899
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.models import FutureMiddleware
    from sanic.request import Request
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    def response_middleware(request, response):
        return text('OK')

    def request_middleware(request):
        return text('OK')

    app.middleware(response_middleware)
    assert app._future_middleware == [
        FutureMiddleware(response_middleware, 'response')
    ]

    app.middleware(request_middleware,'request')
    assert app._future_middleware == [
        FutureMiddleware(response_middleware, 'response'),
        FutureMiddleware(request_middleware, 'request')
    ]


# Generated at 2022-06-24 04:09:49.121994
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin is not None
    assert isinstance(middleware_mixin, MiddlewareMixin)
    assert isinstance(middleware_mixin, object)

# Generated at 2022-06-24 04:09:58.465429
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware
    import unittest

    class MiddlewareMixinTest(unittest.TestCase):
        def test_MiddlewareMixin_on_response(self):
            app = Sanic('test_MiddlewareMixin_on_response')
            @app.middleware
            async def test_on_response(request):
                pass
            test_FutureMiddleware = FutureMiddleware(test_on_response, 'response')
            self.assertEqual(app._future_middleware[0],test_FutureMiddleware)
            @app.route('/')
            async def handler(request):
                return text('OK')
            request, response = app.test_client.get('/')
            self.assertE

# Generated at 2022-06-24 04:10:01.655250
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    target = MiddlewareMixin()
    register_middleware = target.on_response(partial(callable))
    assert register_middleware is not None


# Generated at 2022-06-24 04:10:04.824514
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    # Initialization and call
    m = MiddlewareMixin()
    m.on_request(middleware=None)

    # Update the properties
    m.on_request(middleware=lambda x: 0)

# Generated at 2022-06-24 04:10:07.218311
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    @MiddlewareMixin.on_request
    def func():
        return 1
    assert(func() == 1)


# Generated at 2022-06-24 04:10:16.963462
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    class MyMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            middleware.apply()

    @MyMiddlewareMixin.middleware
    def test_middleware(request):
        return request + ' test middleware'

    @MyMiddlewareMixin.middleware(attach_to='response')
    def test_middleware_response(request, response):
        return response + ' test middleware response'

    app = Sanic(__name__)

    assert test_middleware('test') == 'test test middleware'
    assert test_middleware_response('test', 'test') == 'test test middleware response'

# Generated at 2022-06-24 04:10:18.960580
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # create instance
    mm = MiddlewareMixin()

    # check that 0 _future_middleware has been added
    assert mm._future_middleware == []

# Generated at 2022-06-24 04:10:21.933330
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def handler(request):
        print(request)
    raise Exception(app._future_middleware)

# Generated at 2022-06-24 04:10:33.632077
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic("test_middleware_mixin")

    # check that partial function is returned if no middleware is provided
    assert isinstance(app.on_response(), partial)

    @app.on_response
    def global_middleware(request, response):
        pass

    # ensure that the global middleware is registered
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "response"
    assert app._future_middleware[0].middleware == global_middleware

    @app.on_response("request")
    def request_custom_middleware(request, response):
        pass

    # ensure that the custom middleware is registered
    assert len(app._future_middleware) == 2
    assert app._future_

# Generated at 2022-06-24 04:10:36.477382
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    args = []
    kwargs = {}

    mixin = MiddlewareMixin(*args, **kwargs)

    result = mixin.on_response()

    assert partial == type(result)

# Generated at 2022-06-24 04:10:38.779554
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Test_MiddlewareMixin(MiddlewareMixin):
        pass

    mm = Test_MiddlewareMixin()
    assert mm._future_middleware == []

# Generated at 2022-06-24 04:10:42.284257
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import json
    app = Sanic('test')

    @app.on_request
    def log_request(request):
        print(request)

    @app.route('/')
    def handler(request):
        return json({'hello': 'world'})

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.json == {'hello': 'world'}


# Generated at 2022-06-24 04:10:51.206544
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class test_MiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    class test_middleware:
        def __init__(self, x):
            pass

        def __call__(self, a=1, b=2):
            return a + b

    app = test_MiddlewareMixin()

    @app.on_request(test_middleware(1))
    def test(request):
        return request

    assert app._future_middleware[0].middleware is test_middleware
    assert type(app._future_middleware[0].middleware(1)) is test_middleware
    assert app._future_middleware[0].middleware(1)(3, 5) == 8
    assert app._future_middleware[0].attach_to

# Generated at 2022-06-24 04:10:59.191142
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from typing import Callable
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.sanic import Sanic
    from sanic.blueprints import Blueprint
    # No request middleware
    app = Sanic('test_middleware_app')
    # No blueprint
    blueprint = Blueprint('test_middleware_bp')

    # test_MiddlewareMixin_middleware
    request_middleware = app.middleware
    # test_MiddlewareMixin_on_request
    request_callback = app.on_request
    # test_MiddlewareMixin_on_response
    response_callback = app.on_response

    @request_middleware('response')
    def response_middleware_test(request: Request):
        return request


# Generated at 2022-06-24 04:11:06.098732
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = App()
    app.middleware(middleware_or_request="test_MiddlewareMixin_middleware")
    app.middleware(middleware_or_request=lambda x: x, attach_to="AT")

    assert len(app._future_middleware) == 2


# Generated at 2022-06-24 04:11:12.305102
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin')

    @app.middleware('response')
    async def handle_response(request, response):
        response.text += ' added by middleware'

    @app.route('/')
    async def handler(request):
        return text('response')

    request, response = app.test_client.get('/')
    assert response.text == 'response added by middleware'

# Generated at 2022-06-24 04:11:17.674143
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    def middleware(request: Request) -> HTTPResponse:
        return HTTPResponse('OK')

    app = Sanic(__name__)
    app.middleware(middleware)

    assert middleware in app._future_middleware
    assert app._middleware[0] == middleware

# Generated at 2022-06-24 04:11:19.934483
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin._future_middleware == []



# Generated at 2022-06-24 04:11:23.759411
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    @MiddlewareMixin.on_request()
    def middleware_request(request):
        pass

    assert middleware_request.__name__ == "middleware_request"


# Generated at 2022-06-24 04:11:25.563170
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewareMixin = MiddlewareMixin()
    assert middlewareMixin._future_middleware == []


# Generated at 2022-06-24 04:11:34.842629
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.futures import FutureMiddleware
    from typing import List
    class MiddlewareMixin:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
    MiMi = MiddlewareMixin()
    def register_middleware(middleware="", attach_to="request"):
        nonlocal apply
        future_middleware = FutureMiddleware(middleware, attach_to)
        MiMi._future_middleware.append(future_middleware)
        return middleware
    def test_function_1(arguments):
        return 'test_function_1'
    assert MiMi._future_middleware == []
    MiMi.on_request(test_function_1)

# Generated at 2022-06-24 04:11:39.416378
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic_openapi import doc
    from sanic import Blueprint
    from sanic.response import json

    app = Blueprint(__name__)
    app.on_request(doc.inject_docs)

    @app.route("/")
    @doc.summary("Test route")
    async def test(request):
        return json({"received": True})

# Generated at 2022-06-24 04:11:46.101566
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class FakeMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super(FakeMiddlewareMixin, self).__init__()
    
    _obj = FakeMiddlewareMixin()
    _obj.middleware(lambda *a, **kw: None)
    # Expect success because the _apply_middleware method is not implemented.
    # Do not need to implement the method because it is only used internally.


# Generated at 2022-06-24 04:11:52.291737
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    class FakeMiddlewareMixin(MiddlewareMixin):
        pass

    obj = FakeMiddlewareMixin()

    # test without a parameter
    res = obj.on_request()
    assert res.func == obj.middleware
    assert res.keywords == {"attach_to": "request"}

    # test with a callable parameter
    def f():
        pass

    res = obj.on_request(f)
    assert res.func == obj.middleware
    assert res.args == (f, )
    assert res.keywords == {"attach_to": "request"}


# Generated at 2022-06-24 04:11:54.736682
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    isinstance(MiddlewareMixin(), MiddlewareMixin)
    
if __name__ == '__main__':
    test_MiddlewareMixin()

# Generated at 2022-06-24 04:12:05.100782
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    # Defines a class which inherit MiddlewareMixin and Sanic
    class TestMiddlewareMixin(MiddlewareMixin, Sanic):
        pass

    server = TestMiddlewareMixin()

    # Test the function register_middleware
    @server.middleware
    async def test_register_middleware(request):
        pass

    assert len(server._future_middleware) == 1

    # Test the function register_middleware
    @server.middleware("request")
    async def test_register_middleware_1(request):
        pass

    assert len(server._future_middleware) == 2

    # Test the function register_middleware
    @server.middleware("response")
    async def test_register_middleware_2(request):
        pass


# Generated at 2022-06-24 04:12:12.549135
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class App(MiddlewareMixin):

        def __init__(self, *args, **kwargs):
            self._future_middleware = []

        def _apply_middleware(self, middleware):
            pass

    def middleware(request):
        request['hello'] = 'Hello World'
        return request

    app = App()

    app.on_request()(middleware)

    assert len(app._future_middleware) == 1



# Generated at 2022-06-24 04:12:14.724185
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    a = MiddlewareMixin()
    assert a._future_middleware == []

# Generated at 2022-06-24 04:12:15.374372
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    ...

# Generated at 2022-06-24 04:12:24.807548
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A:
        def __init__(self, *args, **kwargs):
            self.val=args
    
    a=A(1) 
    b=A(1,2) 
    c=A(1,2,3) 
    d=A(1,2,3,4)
    
    @a.middleware
    async def test_a(request, *args):
        print(4)
    
    assert a.val==(1,)
    assert b.val==(1,2)
    assert c.val==(1,2,3)
    assert d.val==(1,2,3,4)
    print(a, b, c, d)
    

# Generated at 2022-06-24 04:12:29.973471
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.response import json
    from sanic.views import CompositionView

    app = MiddlewareMixin()

    @app.on_request
    def process_request(request):
        return request

    @app.route("/test")
    async def test(request):
        return json({"test": True})

    uri = "/test"
    req = Request.blank(uri)

    # resp = app.handle_request(req)
    # assert resp.text == '{"test": true}'

    # test view
    view = CompositionView()
    view.add(test)
    resp = app.handle_request(req, view)
    # assert resp.text == '{"test": true}'

# Generated at 2022-06-24 04:12:38.988282
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.server import HttpProtocol
    from sanic.router import Router
    from sanic.models import ServeModel
    # NOTE: This test is not beautiful. In order to test the route method
    # of class Sanic, we need to construct, initialize and start an instance
    # of Sanic, which is not that easy to achieve. 
    # Thus, we will construct a mock instance of class HttpProtocol,
    # and test method middleware of class MiddlewareMixin with this mock
    # instance. This mock instance will be set as the attribute `server` of
    # the mock instance of class Sanic.
    # The following tests are mostly copied from unit test for method
    # route of class Sanic.

    mock_instance = Mock(HttpProtocol)
    mock_instance.http

# Generated at 2022-06-24 04:12:47.393793
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    class App(Sanic):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    app = App(__name__)

    @app.on_request
    def f(request):
        return request

    @app.on_request()
    def g(request):
        return request

    @app.on_request(attach_to='response')
    def h(request):
        return request

    assert app.middleware_stack[0]._func == f
    assert app.middleware_stack[1]._func == g
    assert app.middleware_stack[2]._func == h


# Generated at 2022-06-24 04:12:52.527822
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    test_MiddlewareMixin = MiddlewareMixin()
    class TestMiddleware(MiddlewareMixin):
        def __init__(self):
            super(TestMiddleware, self).__init__()

            
    test_middleware = TestMiddleware()
    test_middleware.middleware(test_MiddlewareMixin.on_response())

# Generated at 2022-06-24 04:12:54.094430
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    assert mm._future_middleware

# Generated at 2022-06-24 04:13:00.582383
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    @app.on_response
    def s_middleware_response():
        print("this is MiddlewareMixin on_response")

    # test whether the method returns a partial object or not
    if isinstance(app.on_response,partial):
        print('Test for class MiddlewareMixin method on_response successfully!')
    else:
        raise Exception('Test for class MiddlewareMixin method on_response failed!')

# Generated at 2022-06-24 04:13:09.454547
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.exceptions import InvalidUsage
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.views import CompositionView
    from sanic.response import json
    from asyncio import sleep

    app = Sanic('test_MiddlewareMixin_middleware')
    test_value = {}
    test_value["msg"] = None

    async def record_value(request):
        test_value["msg"] = "executed"
        return json({"msg": "hello"})

    app.add_route(record_value, "/")
    server = app.create_server(host=HOST, port=PORT, return_asyncio_server=True)

    async def test(app, loop):
        await server

# Generated at 2022-06-24 04:13:15.501896
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    obj = MiddlewareMixin()
    assert isinstance(obj.on_request, partial)
    assert obj.on_request.func == obj.middleware
    assert obj.on_request.args == ()
    assert obj.on_request.keywords == {'attach_to': 'request'}



# Generated at 2022-06-24 04:13:21.523608
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestingClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test = TestingClass()
    assert test._future_middleware == []

    @test.middleware('request')
    async def middleware1(request):
        pass

    assert test._future_middleware[0].attach_to == 'request'
    assert test._future_middleware[0].middleware == middleware1

    @test.middleware
    async def middleware2(request):
        pass

    assert test._future_middleware[1].attach_to == 'request'
    assert test._future_middleware[1].middleware == middleware2

# Generated at 2022-06-24 04:13:28.486723
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin')

    @app.route('/')
    def handler(request):
        return text('OK')

    @app.middleware('response')
    def process_response(request, response):
        response.set_cookie('foo', 'bar')

    test_client = app.test_client
    request, response = test_client.get('/')
    assert response.cookies
    assert response.cookies.get('foo') == 'bar'

# Generated at 2022-06-24 04:13:36.340264
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.middleware_executed = False

        def _apply_middleware(self, future_middleware: FutureMiddleware):
            if future_middleware.middleware == test_middleware:
                self.middleware_executed = True

    def test_middleware(request):
        return True

    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.middleware(test_middleware)
    test_middleware_mixin._apply_middleware(test_middleware_mixin._future_middleware[0])

# Generated at 2022-06-24 04:13:46.065796
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json

    app = Sanic("test_MiddlewareMixin_middleware")

    # No args
    @app.middleware
    async def middleware(request):
        return json("hello")
        
    # Middleware with args, then attach_to = 'request'
    @app.middleware("request")
    async def middleware2(request, args=None):
        return json("hello")

    # Middleware with args, then attach_to = 'response'
    @app.middleware("response")
    async def middleware3(request, args=None):
        return json("hello")

    # Attach_to = 'request'
    @app.on_request
    async def on_request(request):
        return json("hello")

    # Attach_

# Generated at 2022-06-24 04:13:49.685323
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin = MiddlewareMixin()
    middleware_mixin.middleware(middleware_or_request="request")

    middleware_mixin.on_response(lambda request, response: response)



# Generated at 2022-06-24 04:13:50.665809
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()

# Generated at 2022-06-24 04:14:01.946107
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.exceptions import SanicException

    app = Sanic("test_Sanic_middleware")

    app.sanic_middleware_mixin_test = 0
    app.sanic_middleware_mixin_test_exception = 0

    @app.middleware("request")
    async def request_middleware(request):
        app.sanic_middleware_mixin_test += 1

    @app.middleware("response")
    async def response_middleware(request, response):
        app.sanic_middleware_mixin_test += 1
        return response

    @app.middleware("request")
    async def request_middleware_exception(request):
        app.sanic_middle

# Generated at 2022-06-24 04:14:04.896942
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    mixin = MiddlewareMixin("")
    assert mixin.on_response("test")("test") == "test"


# Generated at 2022-06-24 04:14:07.456428
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    @MiddlewareMixin.on_request
    async def test_middleware(request):
        print(request)



# Generated at 2022-06-24 04:14:09.271837
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # set up
    pass
    # exercise
    pass
    # verify
    pass


# Generated at 2022-06-24 04:14:12.106258
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class fake_middleware(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass
    fake_middleware()

# Generated at 2022-06-24 04:14:18.576200
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.middleware('response')
    def handler(request, response):
        response.body += b'1'
        return response
    @app.route('/')
    def handler(request):
        return text('OK')
    request, response = app.test_client.get('/')
    assert response.text == 'OK1'



# Generated at 2022-06-24 04:14:23.636278
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class A(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    a = A()
    assert a._future_middleware == []


# Generated at 2022-06-24 04:14:26.689017
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class My_Class(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    My_Class()


# Generated at 2022-06-24 04:14:29.024936
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    instance = MiddlewareMixin()
    assert isinstance(instance, MiddlewareMixin)

# Generated at 2022-06-24 04:14:37.879705
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class FakeSanic(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    fake_sanic = FakeSanic()

    @fake_sanic.middleware()
    async def fake_middleware_1(*args, **kwargs):
        raise NotImplementedError  # noqa

    @fake_sanic.middleware
    async def fake_middleware_2(*args, **kwargs):
        raise NotImplementedError  # noqa

    @fake_sanic.middleware('request')
    async def fake_middleware_3(*args, **kwargs):
        raise NotImplementedError  # noqa


# Generated at 2022-06-24 04:14:39.086459
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert callable(MiddlewareMixin.on_request)


# Generated at 2022-06-24 04:14:45.967925
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware = TestMiddlewareMixin()

    @test_middleware.on_response
    def response_middleware(request, response):
        pass

    assert len(test_middleware._future_middleware) == 1
    assert test_middleware._future_middleware[0].name == "response_middleware"

# Generated at 2022-06-24 04:14:49.601352
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MyMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    my_middleware_mixin = MyMiddlewareMixin()
    assert my_middleware_mixin._future_middleware == []



# Generated at 2022-06-24 04:14:56.678258
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Given
    class TestOnRequest(MiddlewareMixin):
        def __init__(self) -> None:
            super(TestOnRequest, self).__init__()
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    # When
    m=TestOnRequest()
    # Then
    assert m.on_request()(lambda x: x)
    assert m.on_request(lambda x: x)


# Generated at 2022-06-24 04:15:00.885352
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa
    test_middleware_mixin = TestMiddlewareMixin()
    test_middleware_mixin.on_request()



# Generated at 2022-06-24 04:15:12.381138
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import asyncio
    from sanic.response import text, HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic import Sanic
    from sanic.testing import HOST, PORT


    app = Sanic('test_MiddlewareMixin_on_request')

    @app.middleware('request')
    async def print_on_request(request):
        print('I am a request middleware before handler')

    @app.route('/')
    async def handler(request):
        return text('OK')

    @app.websocket('/feed')
    async def feed(request, ws):
        while True:
            data = 'Hello!'
            print('Sending: ' + data)
            await ws.send(data)
            data = await ws.recv()

# Generated at 2022-06-24 04:15:14.990812
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    a = MiddlewareMixin()
    b = a.on_request
    c = b(lambda x: x)
    d = c(1)
    assert(d == 1)



# Generated at 2022-06-24 04:15:22.545862
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    app = Sanic()
    assert app.on_response == app.middleware
    assert app.on_response('response') == partial(app.middleware, attach_to='response')

    @app.middleware
    def global_middleware(request):
        pass

    @app.on_response
    def global_middleware_on_response(request, response):
        pass

    @app.route('/')
    def handler(request):
        return json({"test": True})

    request, response = app.test_client.get('/')
    assert response.status == 200

# Generated at 2022-06-24 04:15:24.524921
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewaremixin = MiddlewareMixin()
    assert middlewaremixin._future_middleware == []

# Generated at 2022-06-24 04:15:31.015245
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    middleware = MiddlewareMixin()
    assert middleware.on_response(middleware) 
    assert middleware.on_response(middleware).__name__ == "register_middleware"


# Generated at 2022-06-24 04:15:37.020833
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Temp(MiddlewareMixin):
        def __init__(self):
            super(Temp, self).__init__()
            self._future_middleware = []
            self.middleware_called = False
        def _apply_middleware(self, middleware):
            self.middleware_called = True
    obj = Temp()
    @obj.middleware
    async def middleware(request):
        return request
    assert obj.middleware_called == True


# Generated at 2022-06-24 04:15:46.785105
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class middlware_test(MiddlewareMixin):
        def __init__(self):
            self.request = True
            self.response = True
            self._future_middleware = []
            MiddlewareMixin.__init__(self)

        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)
    
    @middlware_test().on_request()
    def handler(request):
        pass
    
    assert middlware_test()._future_middleware[0].attach_to == "request"
    assert middlware_test()._future_middleware[0].future_middleware() == handler


# Generated at 2022-06-24 04:15:47.704947
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert 0



# Generated at 2022-06-24 04:15:54.759300
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
  # Assert
  try:
    middleware = MiddlewareMixin()
    # Assert
    assert middleware.on_response()
  except:
    assert False
  finally:
    # Assert
    try:
      middleware = MiddlewareMixin()
      # Assert
      assert middleware.on_response(middleware)
    except:
      assert False
    finally:
      # Assert
      try:
        middleware = MiddlewareMixin()
        # Assert
        assert middleware.on_response(MiddlewareMixin)
      except:
        assert False
      finally:
        pass
        
