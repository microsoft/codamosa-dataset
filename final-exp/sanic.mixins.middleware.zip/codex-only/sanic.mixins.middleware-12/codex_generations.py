

# Generated at 2022-06-24 04:05:56.883605
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    class MyMiddleware:
        def __init__(self, *args, **kwargs):
            pass

    # create object of midlleware which is subclass of MiddlewareMixin
    class MyApp(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(MyApp, self).__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    MyApp().middleware(MyMiddleware)



# Generated at 2022-06-24 04:06:06.770846
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    from sanic.models.middleware import MiddlewareMixin

    class MWMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
            self._middleware = []

        def _apply_middleware(self, middleware):
            self._middleware.append(middleware)

    app = Sanic("middleware_test")
    app.config.REQUEST_MAX_SIZE = 10 * 1024 * 1024
    app.config.REQUEST_TIMEOUT = 60

    assert hasattr(app, "_middlewares")
    assert hasattr(app, "middleware")
    assert hasattr(app, "on_request")

# Generated at 2022-06-24 04:06:08.768044
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert True

# Generated at 2022-06-24 04:06:11.921705
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    assert mm._future_middleware == []

# Generated at 2022-06-24 04:06:12.395938
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    pass

# Generated at 2022-06-24 04:06:16.306087
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Dummy:
        pass
    dummy = Dummy()
    mixin = MiddlewareMixin()
    dummy.mixin = mixin
    assert dummy.mixin._future_middleware == []


# Generated at 2022-06-24 04:06:26.659283
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    blueprint_instance = Blueprint('test')
    blueprint_instance.middleware(None).__name__

    sanic_instance = Sanic(__name__)
    sanic_instance.middleware(None).__name__

    sanic_instance = Sanic(__name__)
    sanic_instance.middleware(None, None).__name__

    sanic_instance = Sanic(__name__)
    sanic_instance.middleware(None, 'response').__name__
    sanic_instance.middleware(None, 'request').__name__
    sanic_instance.middleware(None, 'both').__name__


# Generated at 2022-06-24 04:06:28.171666
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    instance = MiddlewareMixin()
    assert callable(instance.on_request())


# Generated at 2022-06-24 04:06:30.251122
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    m = MiddlewareMixin()
    assert m.on_response(middleware=1) == partial(m.middleware, attach_to='response')

# Generated at 2022-06-24 04:06:34.183857
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # mock
    mock_middleware = Mock()
    middleware_mixin = MiddlewareMixin()
    # call
    middleware_mixin.on_response(middleware=mock_middleware)
    assert middleware_mixin._future_middleware[0].middleware == mock_middleware
    assert middleware_mixin._future_middleware[0].attach_to == "response"


# Generated at 2022-06-24 04:06:34.817774
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert True

# Generated at 2022-06-24 04:06:40.093811
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        pass

    instance = TestMiddlewareMixin()
    assert isinstance(instance, MiddlewareMixin)
    assert isinstance(instance._future_middleware, list)
    assert instance._future_middleware == []



# Generated at 2022-06-24 04:06:50.258655
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    from sanic.server import HttpProtocol

    app = Sanic('test_MiddlwareMixin')
    @app.middleware('response')
    def middlware_response(request, response):
        return text('OK')

    @app.middleware('request')
    def middlware_request(request):
        return text('OK')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.router.find('/', method='GET')
    server_protocol = HttpProtocol(None, '127.0.0.1', 8000, loop=app.loop)
    handler = await app.handler_for_request(request, server_protocol)


# Generated at 2022-06-24 04:06:56.933573
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    from sanic.app import Sanic
    from sanic.response import json

    m = MiddlewareMixin()

    @m.middleware('request')
    def method_1():
        print(1)
        return

    print(method_1)
    print(m._future_middleware)

    @m.middleware('response')
    def method_2():
        print(2)
        return

    print(method_2)
    print(m._future_middleware)

    app = Sanic('test')
    app.middleware('request')(method_1)
    app.middleware('response')(method_2)
    print(app._future_middleware)

    @app.route('/')
    async def _(request):
        return json({})


# Generated at 2022-06-24 04:06:57.974317
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert not MiddlewareMixin(None, "213")._future_middleware

# Generated at 2022-06-24 04:07:03.042829
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
    test_middleware = TestMiddlewareMixin()
    _future_middleware = []
    assert test_middleware._future_middleware == _future_middleware


# Generated at 2022-06-24 04:07:12.252581
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):

        def _apply_middleware(self, middleware):
            self.middleware = middleware

    with pytest.raises(NotImplementedError):
        m = MiddlewareMixin()
        m._apply_middleware(None)
    m = TestMiddlewareMixin()
    assert len(m._future_middleware) == 0
    m.on_response(lambda a, b: b)
    assert len(m._future_middleware) == 1
    assert m._future_middleware[0].middleware == m.middleware
    assert m.middleware.name == 'TestMiddlewareMixin.<lambda>'
    assert m.middleware.attach_to == 'response'

# Generated at 2022-06-24 04:07:18.827590
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic


    class TestMiddlewareMixin(MiddlewareMixin):
        pass

    test = Sanic(__name__)

    # apply on_response middleware
    @test.on_response
    def test(request, response):
        print("Test Ok")

    assert(test.on_response == test.middleware)

# Generated at 2022-06-24 04:07:27.223763
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.models.middleware import Middleware
    from sanic.request import Request

    def request_handler(request, _):
        return request

    def response_handler(request, _):
        return request

    app = Sanic('Sanic')

    # Test that middleware method is callable
    try:
        app.middleware
    except:
        assert False

    # Test that middleware method() returns a partial object
    try:
        app.middleware()
    except:
        assert False

    # Test that the app adds the middleware to its _future_middleware list
    assert len(app._future_middleware) == 0
    app.middleware(Middleware(request_handler, "request"))
    assert len(app._future_middleware) == 1

    #

# Generated at 2022-06-24 04:07:33.692808
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    app = Sanic()

    @app.listener('before_server_start')
    def on_before_server_start(app, loop):
        def on_request(request):
            pass

        app.on_request(on_request)

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[0].middleware == on_request


# Generated at 2022-06-24 04:07:34.178666
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert True

# Generated at 2022-06-24 04:07:37.446583
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    test_MiddlewareMixin_instance = TestMiddlewareMixin()
    assert isinstance(test_MiddlewareMixin_instance, TestMiddlewareMixin)


# Generated at 2022-06-24 04:07:48.281658
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    class Sanic(MiddlewareMixin):
        def __init__(self):
            super().__init__()

    # Case 1
    obj = Sanic()
    @obj.middleware
    def cb(request):
        pass
    assert isinstance(cb, partial)     # Check if the cb is a partial object

    # Case 2
    obj = Sanic()
    cb = obj.middleware(cb)
    assert isinstance(cb, partial)     # Check if the cb is a partial object

    # Case 3
    obj = Sanic()
    # attach_to is 'respone'
    cb = obj.middleware('respone')
    assert isinstance(cb, partial)     # Check if the cb is a partial object
    # attach_to is 'request'
    cb = obj.middleware

# Generated at 2022-06-24 04:07:58.491297
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.views import HTTPMethodView

    app = Sanic("test_MiddlewareMixin_middleware")

    class TestView(HTTPMethodView):
        def get(self, request):
            return json({"hello": "world"})

    class TestMiddleware:
        @staticmethod
        async def response(request, response):
            response.headers["middleware"] = "true"

    app.add_route(TestView.as_view(), "/")
    app.middleware(TestMiddleware.response, attach_to="response")
    request, response = app.test_client.get("/")
    assert response.headers.get("middleware", None) == "true"



# Generated at 2022-06-24 04:08:06.587097
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    class MySanic(MiddlewareMixin, Sanic):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware):
            pass
    app = MySanic()

    @app.on_request()
    def handle_request(request):
        pass

    @app.on_request
    def handle_request2(request):
        pass

    # assert len(app._future_middleware) == 2
    # assert app._future_middleware[0].name == "handle_request"
    # assert app._future_middleware[1].name == "handle_request2"



# Generated at 2022-06-24 04:08:10.587007
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Arrange
    class TestClass(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    testobj = TestClass()

    # Act
    wrapped = testobj.middleware(None)

    # Assert
    assert wrapped



# Generated at 2022-06-24 04:08:11.124587
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-24 04:08:13.069450
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    o = MiddlewareMixin()
    assert o._future_middleware == []
    assert o._apply_middleware == None


# Generated at 2022-06-24 04:08:19.191867
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic("name")
    assert app._future_middleware == []
    @app.middleware
    async def test(request):
        pass
    assert app._future_middleware[0].middleware == test
    assert app._future_middleware[0].attach_to == "request"
    @app.middleware("response")
    def test2(request):
        pass
    assert app._future_middleware[1].middleware == test2
    assert app._future_middleware[1].attach_to == "response"

# Generated at 2022-06-24 04:08:29.251663
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.request import Request
    app = Sanic()
    @app.middleware('request')
    def test_middleware1(request):
        pass
    @app.middleware('response')
    def test_middleware2(request, response):
        pass
    @app.middleware('request')
    def test_middleware3(request):
        pass
    @app.middleware('request')
    def test_middleware4(request):
        pass
    @app.middleware('request')
    def test_middleware5(request):
        pass
    @app.middleware('request')
    def test_middleware6(request):
        pass
    @app.middleware
    def test_middleware7(request, response):
        pass

# Generated at 2022-06-24 04:08:33.928195
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.response import json
    class app(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__()
        def _apply_middleware(self, middleware):
            pass
    @app.on_response
    def test(request, response):
        response.headers['hello'] = 'world'
        return response
    _, res = app.test(None, json({}))
    assert res.headers['hello'] == 'world'



# Generated at 2022-06-24 04:08:41.590074
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MM(MiddlewareMixin):
        pass
    mm = MM()
    
    def first_middleware(request):
        pass
    def second_middleware(request):
        pass

    mm.on_request(first_middleware)
    mm.on_request(second_middleware)
    assert mm._future_middleware == []
    mm.on_request()(second_middleware)
    assert mm._future_middleware == [FutureMiddleware(second_middleware, attach_to='request')]

# Generated at 2022-06-24 04:08:44.913566
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        pass

    test_obj = TestMiddlewareMixin()
    assert test_obj._future_middleware == []

# Generated at 2022-06-24 04:08:49.792892
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')


    @app.middleware
    def test(request):
        pass


    assert len(app.middleware_stack) == 1
    assert app.middleware_stack[0].attach_to == "request"


# Generated at 2022-06-24 04:08:52.669610
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # TODO: Test MiddlewareMixin._apply_middleware
    # TODO: Test MiddlewareMixin.on_request
    # TODO: Test MiddlewareMixin.on_response
    pass

# Generated at 2022-06-24 04:08:59.479088
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic as app
    app_object1 = app(__name__)
    app_object = MiddlewareMixin()
    @app_object1.middleware('response')
    def test_middleware(request):
        return 'This is a request'
    response = app_object1.handle_request(request='This is a test')
    assert response == 'This is a request'
    return response


# Generated at 2022-06-24 04:09:06.049969
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MixinTest(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_middleware = []

    import sanic
    app = sanic.Sanic()
    mixin_test = MixinTest()
    @mixin_test.on_request()
    def test_method(request):
        pass

    assert len(mixin_test._future_middleware) == 1


# Generated at 2022-06-24 04:09:08.817361
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():  
    MiddlewareMixin_instance = MiddlewareMixin()
    result = MiddlewareMixin_instance.on_response()
    assert type(result).__name__ == 'partial'

# Generated at 2022-06-24 04:09:10.045219
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    assert m._future_middleware == []

# Generated at 2022-06-24 04:09:16.981887
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from . import App
    from .router import UrlDispatcher
    from .server import HttpProtocol

    app = App(__name__)
    http_protocol = HttpProtocol(app, app.loop, UrlDispatcher(app), 1)
    app.middleware_instances = []
    app.middleware_instances.append(http_protocol)

    @app.on_request
    async def on_request(request):
        print("on_request")

    @app.route("/")
    async def handler(request):
        print("handler")
        return "hello world"



# Generated at 2022-06-24 04:09:20.226551
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    '''
    Test for the constructor of class MiddlewareMixin
    '''
    instance = MiddlewareMixin()
    assert isinstance(instance, MiddlewareMixin)


# Generated at 2022-06-24 04:09:21.962286
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()

    assert isinstance(m, MiddlewareMixin)


# Generated at 2022-06-24 04:09:25.139972
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Dummy(MiddlewareMixin):
        def __init__(self):
            super().__init__()
    assert issubclass(Dummy, MiddlewareMixin)
    assert Dummy()._future_middleware == []


# Generated at 2022-06-24 04:09:32.680604
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import sanic
    from sanic.models.router import Router
    from sanic.models.futures import FutureMiddleware
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import add_status_code

    class CustomHttpError(HTTPResponse, Exception):
        def __init__(self, content, status=400):
            self.content = content
            self.status = status
            super().__init__(body=content, status=status)

    add_status_code(418)

    app = sanic.Sanic(__name__)

    app.request_middleware = []
    app.response_middleware = []
    app.error_handler = {}
    app.router = Router()

# Generated at 2022-06-24 04:09:37.251762
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    def middleware(request):
        return request

    app = Sanic('test_MiddlewareMixin_on_response')
    app.on_response(middleware)
    assert app._future_middleware[0].attach_to == 'response'

# Generated at 2022-06-24 04:09:46.463218
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text
    def my_middleware(request):
        return text('Hello world!')
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.middleware
    def request_middleware(request):
        return text('Hello world!')
    @app.middleware('response')
    def response_middleware(request, response):
        return text('Hello world!')
    @app.middleware
    def request_middleware_1(request):
        return text('Hello world!')
    app.on_response(my_middleware)

    assert len(app._future_middleware) == 1
    assert isinstance(app._future_middleware[0], FutureMiddleware)


# Generated at 2022-06-24 04:09:47.457333
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # This method is expected to always return partial object
    # of function register_middleware
    pass


# Generated at 2022-06-24 04:09:53.561395
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class mock_MiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(mock_MiddlewareMixin, self).__init__(*args, **kwargs)
            self._future_middleware = []

        def _apply_middleware(self, middleware):
            self._future_middleware.append(middleware)

    m = mock_MiddlewareMixin()
    assert isinstance(m._future_middleware, list)
    assert len(m._future_middleware) == 0


# Generated at 2022-06-24 04:09:55.887607
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    app.middleware


# Generated at 2022-06-24 04:09:58.549098
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic()

    @app.on_request
    def test_middleware(request):
        return True

    assert len(app._middleware) == 1
    assert callable(app._middleware[0][0])
    assert app._middleware[0][1] == "request"


# Generated at 2022-06-24 04:10:05.276786
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class DummyMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            self._future_middleware = []

        def _apply_middleware(self, middleware):
            pass

    d = DummyMiddlewareMixin()
    func = d.on_response(DummyMiddlewareMixin)
    assert func == DummyMiddlewareMixin
    assert d._future_middleware == []
    assert len(d._future_middleware) == 0

# Generated at 2022-06-24 04:10:09.787696
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    t = TestMiddlewareMixin()
    assert t._future_middleware == []



# Generated at 2022-06-24 04:10:11.906943
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    app = Sanic()
    assert isinstance(app, MiddlewareMixin)

# Generated at 2022-06-24 04:10:21.624342
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    app = Sanic()
    # check __init__
    assert app._future_middleware == []
    print("test_MiddlewareMixin :: test_MiddlewareMixin() :: test1 Passed!")
    # check _apply_middleware not implemented
    try:
        app._apply_middleware(None)
        print("Variable is not None")
    except NotImplementedError:
        print("test_MiddlewareMixin :: test_MiddlewareMixin() :: test2 Passed!")
    # check middleware
    assert app.middleware(None, 'request') is not None
    print("test_MiddlewareMixin :: test_MiddlewareMixin() :: test3 Passed!")
    assert app.middleware(None, 'response') is not None

# Generated at 2022-06-24 04:10:25.626948
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Sanic(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    sanic = Sanic()
    # test method middleware of class MiddlewareMixin
    @sanic.middleware()
    def middleware():
        pass

    assert len(sanic._future_middleware) == 1
    assert sanic._future_middleware[0]._func == middleware



# Generated at 2022-06-24 04:10:28.849877
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    obj = MiddlewareMixin()
    print('test_MiddlewareMixin')
    assert obj is not None;
    

# Generated at 2022-06-24 04:10:38.668265
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.exceptions import NotFound
    from sanic.request import Request
    from sanic.response import HTTPResponse, json

    @Sanic.middleware
    def first_middleware(request):
        return request

    @Sanic.middleware
    def second_middleware(request):
        return request

    app = Sanic()

    @app.exception(NotFound)
    def ignore_404s(request, exception):
        return json({"error": "Not found"}, status=404)

    @app.route("/")
    async def handler(request):
        return json({"test": True})

    request, response = app.test_client.get("/")
    assert response.status == 200
    assert response.json["test"] is True


# Generated at 2022-06-24 04:10:46.107868
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class ASanic:
        def __init__(self):
            self._response_middleware = list()

        def _apply_middleware(self, middleware):
            self._response_middleware.append(middleware)


    app = ASanic()
    app.on_response(lambda request: lambda response: True)
    assert len(app._response_middleware) == 1
    assert isinstance(app._response_middleware[0].middleware, type(lambda: True))
    assert app._response_middleware[0].attach_to == 'response'

# Generated at 2022-06-24 04:10:50.392443
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import pytest
    from sanic import Sanic

    app = Sanic()

    def test_middleware(request, handler):
        assert request.path == "/"

    app.on_request(test_middleware)

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.text == "OK"

    with pytest.raises(TypeError):
        app.on_request()


# Generated at 2022-06-24 04:11:01.061990
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test_MiddlewareMixin:
        def __init__(self):
            pass

        def _apply_middleware(self, middleware):
            pass

        def on_request(self, middleware=None):
            if callable(middleware):
                return self.middleware(middleware, "request")
            else:
                return partial(self.middleware, attach_to="request")

        def on_response(self, middleware=None):
            if callable(middleware):
                return self.middleware(middleware, "response")
            else:
                return partial(self.middleware, attach_to="response")

    test_middleware_mixin = Test_MiddlewareMixin()

    @test_middleware_mixin.on_request()
    async def test_middleware(request):
        pass


# Generated at 2022-06-24 04:11:05.999040
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import sanic
    class app(MiddlewareMixin):
        def __init__(self):
            MiddlewareMixin.__init__(self)
    app = app()
    @app.middleware
    def middleware(request):
        pass
    assert app._future_middleware[0].middleware is middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-24 04:11:09.971343
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class A(MiddlewareMixin): pass
    a = A()
    assert a._future_middleware == []


# Generated at 2022-06-24 04:11:10.470353
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-24 04:11:17.376051
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Sanic(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    class TestMiddlewareMiddleware(MiddlewareMixin):

        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    s = Sanic()
    t = TestMiddlewareMiddleware()

    # Test that a class that includes MiddlewareMixin works

# Generated at 2022-06-24 04:11:19.685647
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    app = Sanic('test_sanic')
    assert isinstance(app, MiddlewareMixin)

# Generated at 2022-06-24 04:11:23.589112
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    _ = m.on_request()
    m.on_request(middleware=m)



# Generated at 2022-06-24 04:11:26.911783
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    mm = MiddlewareMixin()

    def mw_func(request):
        return 'mw_func is called'

    assert mm.on_response(mw_func) == mm.middleware(mw_func, 'response')


# Generated at 2022-06-24 04:11:29.249957
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()

# Generated at 2022-06-24 04:11:32.064691
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    def middleware(request):
        print(request)
    t = MiddlewareMixin()
    t.on_request(middleware)



# Generated at 2022-06-24 04:11:39.052255
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic()
    @app.middleware
    async def print_on_request(request):
        # before request
        print("I print on request")
        response = await handler(request)
        # after request
        print("I print on response")
        return response

    @app.route("/")
    async def handler(request):
        return json({"hello": "world"})

    app.run(host="0.0.0.0", port=8000)

# Generated at 2022-06-24 04:11:44.244196
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    f = lambda: print("this is a function")
    m.on_request(f) == f
    m.middleware("request")
    m.on_request == m.middleware("request")
    m.middleware("request")


# Generated at 2022-06-24 04:11:52.599570
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class fake_request:
        def __init__(self):
            self.response = "fake_response"

    class fake_app:
        def __init__(self):
            self.middleware_mixin = MiddlewareMixin()

    def fake_middleware(request):
        return "fake_middleware"

    fake_app.middleware_mixin.middleware(fake_middleware)

    fake_app.middleware_mixin._apply_middleware(fake_app.middleware_mixin._future_middleware[0])
    fake_app.middleware_mixin._future_middleware[0].middleware(fake_request)
    assert fake_request.response == "fake_middleware"

# Generated at 2022-06-24 04:11:54.773141
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []


# Generated at 2022-06-24 04:11:57.683552
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    mid_mixin = MiddlewareMixin()
    mid_mixin.on_response('response')

# Generated at 2022-06-24 04:12:03.816556
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.futures import FutureMiddleware
    import sanic

    app = sanic.Sanic()
    app.on_request(lambda request, response: True)
    assert len(app._future_middleware) == 1
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert isinstance(app._future_middleware[0].middleware, type(lambda: None))
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-24 04:12:12.468589
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.request import Request
    from sanic.models.futures import FutureMiddleware

    class MockMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            MiddlewareMixin.__init__(self, *args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            return

    app = Sanic("test_sanic_app")
    app_middleware_mixin = MockMiddlewareMixin()
    assert len(app_middleware_mixin._future_middleware) == 0
    def func(request: Request):
        return text("OK")

    func_wrapper = app_middleware_mixin.middleware(func)


# Generated at 2022-06-24 04:12:15.159842
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    assert m.on_request(m)


# Generated at 2022-06-24 04:12:19.931333
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin = MiddlewareMixin()
    assert mixin._future_middleware is None
    # Expected to raise error when calling constructed class MiddlewareMixin
    try:
        mixin._apply_middleware(None)
    except NotImplementedError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 04:12:22.580668
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert True == True, "middleware is working"

# Generated at 2022-06-24 04:12:33.731593
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from unittest import TestCase
    from unittest.mock import Mock
    from unittest.mock import MagicMock

    class MiddlewareMixinTest(TestCase):
        def test_on_response(self):
            mock_middleware = MagicMock()
            # Mock parameters and return value of method on_response
            mock_ret = MagicMock()
            mock_ret.attach_to = "response"
            with patch(
                "sanic.models.middleware.MiddlewareMixin.middleware",
                return_value=mock_ret,
            ):
                instance = MiddlewareMixin()
                request = None
                # Call method on_response
                ret = instance.on_response(mock_middleware)
                # Check return value
                self.assertEqual(ret, mock_ret)


# Generated at 2022-06-24 04:12:40.874296
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic, response
    app = Sanic(__name__)

    @app.route("/")
    def handler(request):
        return response.json({"test": True})

    @app.middleware("response")
    def process_response(request, response):
        response.headers["XX-Test"] = "Test"

    request, response = app.test_client.get("/")

    assert response.headers.get("XX-Test") == "Test"

# Generated at 2022-06-24 04:12:43.937697
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    assert isinstance(mm, MiddlewareMixin)
    mml = list(mm._future_middleware)
    assert len(mml) == 0


# Generated at 2022-06-24 04:12:49.096853
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    print('Test MiddlewareMixin:')
    print('Called middleware method of MiddlewareMixin')
    try:
        middleware_mixin = MiddlewareMixin()
        middleware_mixin.middleware(middleware_or_request=None)
        print('Passed\n')
    except:
        print('Failed\n')


# Generated at 2022-06-24 04:12:52.426503
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = MiddlewareMixin()
    @app.on_request()
    def f(request):
        print('f')
        pass
    assert app._future_middleware[0]._middleware_type == 'request'

# Generated at 2022-06-24 04:13:03.047794
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class SimpleMiddleware:
        def __init__(self):
            self.ran = False

        async def handler(self, request):
            self.ran = True

    class MyMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            middleware.middleware(
                "test", SimpleMiddleware().handler, attach_to="request"
            )

    @MyMiddlewareMixin.middleware("test")
    async def request_middleware(request):
        pass

    @MyMiddlewareMixin.on_response("test")
    async def response_middleware(request, response):
        pass

    middleware_mixin = MyMiddlewareMixin()
    middleware_mixin.middleware("test")
    middleware_mixin.on_request("test")
    middleware

# Generated at 2022-06-24 04:13:05.722392
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    print("test_MiddlewareMixin_on_response")

    from sanic.server import HttpProtocol

    a = HttpProtocol()
    # a.on_response(None)
    print(a._future_middleware)

# Generated at 2022-06-24 04:13:14.711621
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic import BluePrint
    from sanic import response

    app = Sanic()
    class TestMid(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_mid = TestMid()

    # test middleware
    @test_mid.middleware
    async def test_middleware(request):
        pass

    # test on_request
    @test_mid.on_request
    async def test_on_request(request):
        pass

    # test_on_response
    @test_mid.on_response
    async def test_on_response(request, response):
        return response

    # test middleware()
    @test_mid.middleware()
    async def test_middleware1(request):
        pass

# Generated at 2022-06-24 04:13:20.896222
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import attach_to
    from sanic.models.futures import get_method

    class TestFutureMiddleware(FutureMiddleware):
        def __call__(self, request, *args, **kwargs):
            pass

    def test_middleware(request, *args, **kwargs):
        pass

    app = Sanic("test_MiddlewareMixin_on_request")
    result = app.on_request(test_middleware)
    assert isinstance(result, partial)
    app.on_request(test_middleware)
    assert len(app._future_middleware) == 1
    fm = app._future_middleware[0]

# Generated at 2022-06-24 04:13:26.807115
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware

    app = Sanic(__name__)
    assert app._future_middleware == []
    app.on_request(print)
    app.on_request(print)
    assert len(app._future_middleware) == 2
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert isinstance(app._future_middleware[1], FutureMiddleware)


# Generated at 2022-06-24 04:13:31.261933
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Test(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            MiddlewareMixin.__init__(self, *args, **kwargs)
    test = Test()
    assert isinstance(test._future_middleware, list), \
        "Type of _future_middleware should be list."
    
    

# Generated at 2022-06-24 04:13:33.171284
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    test_instance = MiddlewareMixin()
    assert test_instance._future_middleware == []


# Generated at 2022-06-24 04:13:34.677011
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert callable(MiddlewareMixin().on_response())


# Generated at 2022-06-24 04:13:45.012623
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    class Server(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    server = Server()
    assert server._future_middleware == []

    @server.middleware
    async def sample_mw(request):
        return True

    assert server._future_middleware != []
    assert server._future_middleware[0].middleware == sample_mw
    assert server._future_middleware[0].attach_to == 'request'

    @server.middleware('response')
    async def sample_mw2(request):
        return False


# Generated at 2022-06-24 04:13:48.093723
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    @Sanic.middleware
    class CustomMiddleware:
        def request(request):
            pass

    assert len(Sanic._future_middleware) == 1


# Generated at 2022-06-24 04:13:56.338888
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import logging
    import sys
    from sanic.log import logger
    from sanic.request import Request
    def before_request(request: Request):
        logger.debug("Logging before request")
    def after_request(request, response):
        logger.debug("Logging after request")

    m = MiddlewareMixin()
    m.on_request(before_request)
    m.on_response(after_request)

    #assert(hasattr(logger, "debug"))
    #assert(logger.debug("Logging after request") == None)
    #assert(logger.debug("Logging before request") == None)

# Generated at 2022-06-24 04:13:58.926321
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    mixin = MiddlewareMixin()
    app_request = mixin.on_request(middleware='on_request')
    result = app_request()
    assert result == 'on_request'


# Generated at 2022-06-24 04:14:00.638480
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    response = MiddlewareMixin()
    assert response.on_response() == partial(response.middleware, attach_to='response')

# Generated at 2022-06-24 04:14:10.674540
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import unittest

    from sanic.app import Sanic
    from sanic.constants import HTTP_METHODS
    from sanic.log import error_logger

    app = Sanic()

    @app.middleware
    async def test_middleware(request):
        request["test"] = "test"
        return request

    @app.middleware("request")
    async def test_middleware2(request):
        request["test2"] = "test"
        return request

    @app.middleware("response")
    async def test_middleware3(request, response):
        response.text += "test"
        return response

    async def handler(request):
        assert request["test"] == "test"
        assert request["test2"] == "test"
        return text("test")


# Generated at 2022-06-24 04:14:20.280111
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import unittest2 as unittest
    #from unittest.mock import patch, MagicMock
    from unittest import mock
    import sanic
    from sanic import Sanic

    # mock the return value of method 'middleware' in class Sanic
    mock_middleware = mock.MagicMock()
    mock_middleware.return_value = 'on_response'

    # mock the return value of method 'middleware' in class Sanic
    mock_partial = mock.MagicMock()
    mock_partial.return_value = 'on_response'

    # mock the return value of method 'partial' in module 'functools'
    with mock.patch('functools.partial', mock_partial):
        with mock.patch.object(Sanic, 'middleware', mock_middleware):
            s = san

# Generated at 2022-06-24 04:14:21.941031
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mw = MiddlewareMixin()
    assert mw._future_middleware == []

# Generated at 2022-06-24 04:14:24.641325
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin = MiddlewareMixin()
    assert isinstance(mixin, MiddlewareMixin)
    assert isinstance(mixin._future_middleware, List)

# Generated at 2022-06-24 04:14:36.553669
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Input
    class test1(MiddlewareMixin):
        def __init__(self):
            super().__init__()

    class test2(MiddlewareMixin):
        def __init__(self):
            super().__init__()

    # Output
    class test3(MiddlewareMixin):
        def __init__(self):
            super().__init__()

    class test4(MiddlewareMixin):
        def __init__(self):
            super().__init__()

    @test1.on_request
    def tmp(request):
        print('test1 on request')
        return request
    assert len(test1._future_middleware) == 1

    @test2.on_request()
    def tmp2(request):
        print('test2 on request')
        return request

# Generated at 2022-06-24 04:14:40.031529
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    f = FutureMiddleware(my_on_response, "response")
    print(f)
    assert (
        f == FutureMiddleware(my_on_response, "response")
    )


# Generated at 2022-06-24 04:14:42.036445
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class A():
        def __init__(self):
            self.x = 3

    a = A()
    m = MiddlewareMixin()
    return a.x


# Generated at 2022-06-24 04:14:44.058709
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    method = MiddlewareMixin()
    assert method.middleware(object) == object

# Generated at 2022-06-24 04:14:45.308891
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin._future_middleware == []

# Generated at 2022-06-24 04:14:48.899776
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import json

    url = "http://127.0.0.1:8000/"

    app = Sanic()

    @app.on_request
    def request_middleware(request):
        request["token"] = "coolbeans"
        return None

    @app.route("/")
    def handler(request):
        return json(request.token)

    _, response = app.test_client.get(url)
    assert response.text == "coolbeans"


# Generated at 2022-06-24 04:14:59.491214
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Test:
        def __init__(self):
            self.on_response_called = False
            self.on_response_variable = 0
        def on_response(self, middleware):
            def custom_middleware(request):
                self.on_response_called = True
                return request

            return custom_middleware

    # check whether the on_response_called is True after the middleware is called
    a = Test()
    a.on_response()(None)
    assert a.on_response_called == True

    # check whether the variable is changed after the middleware is called
    a = Test()
    a.on_response_variable = 1
    a.on_response()(None)
    assert a.on_response_variable == 1


# Generated at 2022-06-24 04:15:01.505427
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mMixin = MiddlewareMixin()
    assert isinstance(mMixin, MiddlewareMixin)



# Generated at 2022-06-24 04:15:11.359394
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    a = A()
    # test ok
    def x():
        pass
    a.middleware(x, "request")
    a.middleware("request")
    a.on_request()
    a.on_response()
    
    @a.middleware("request")
    def x():
        pass
    @a.on_request()
    def x():
        pass
    
    
    # test fail
    #a.middleware(x)
    #a.middleware(5)
    #a.middleware(None)

# Generated at 2022-06-24 04:15:19.919389
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_on_response')
    def test_middleware(request, response):
        # modifies the request
        request['test'] = True
        # returns the request unmodified
        return response
    app.on_response(test_middleware)
    @app.route('/test_on_response', methods=['GET'])
    def handler(request):
        return text('OK')
    request, response = app.test_client.get('/test_on_response')
    assert response.status == 200
    assert request['test'] is True


# Generated at 2022-06-24 04:15:21.739524
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    sa = MiddlewareMixin()
    assert not sa._future_middleware


# Generated at 2022-06-24 04:15:26.430297
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from types import FunctionType

    app = Sanic('test_MiddlewareMixin')
    assert isinstance(app.middleware, FunctionType)
    assert isinstance(app.on_request, FunctionType)
    assert isinstance(app.on_response, FunctionType)


# Generated at 2022-06-24 04:15:33.383669
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    req = Request()
    res = Response()
    _m = MiddlewareMixin()
    assert _m.on_request()(_m.on_response()(lambda x: True)) == _m.on_response()(lambda x: True)
    assert _m.on_request()(lambda x: True) == _m.middleware(lambda x: True, attach_to="request")
    assert isinstance(_m.on_request()(lambda x: True)(req, res), bool)

# Generated at 2022-06-24 04:15:45.187449
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class AnyObject:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    AnyObject.__bases__ += (MiddlewareMixin,)
    obj = AnyObject()
    assert 0 == len(obj._future_middleware)
    @obj.on_request
    def middleware_1(request):
        pass

    assert 1 == len(obj._future_middleware)
    assert isinstance(
        obj._future_middleware[0],
        FutureMiddleware
    )
    assert obj._future_middleware[0].middleware is middleware_1
    assert "request" == obj._future_middleware[0].attach_to_name

# Generated at 2022-06-24 04:15:50.484164
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    from sanic.models import SanicPlugins

    _sp = SanicPlugins()
    _middleware = MiddlewareMixin(_sp)
    assert _middleware._future_middleware == []

    # test method
    @_middleware.middleware
    async def add_global_stuff(request):
        return request

    assert add_global_stuff.middleware == True