

# Generated at 2022-06-24 04:05:49.291369
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic("test_app")
    app.on_response(lambda request, response: 'middleware')

# Generated at 2022-06-24 04:05:52.907995
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MiddlewareMixinForTest(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    MiddlewareMixinForTest().on_request(middleware=lambda: None)

# Generated at 2022-06-24 04:05:54.395219
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    x = MiddlewareMixin()
    assert x._future_middleware == []

# Generated at 2022-06-24 04:06:00.990849
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    
    from sanic.models.middleware import MiddlewareMixin
    from sanic.models.futures import FutureRequestMiddleware

    class DummyMiddleware(MiddlewareMixin):
        def __init__(self):
            super().__init__()
        
        def _apply_middleware(self, middleware):
            assert isinstance(middleware, FutureRequestMiddleware)

    dummy = DummyMiddleware()

    def dummy_func(response):
        pass

    dummy.on_request(dummy_func)


# Generated at 2022-06-24 04:06:02.914360
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    print('here')
    assert MiddlewareMixin.on_response is not None

# Generated at 2022-06-24 04:06:08.303064
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    """
    Unit test for method on_response of class MiddlewareMixin
    """
    from sanic.app import Sanic
    app = Sanic(__name__)

    # test with default parameter
    assert app.on_response() is not None

    # test with argument
    assert app.on_response('request') is not None

    # test with callable argument
    assert app.on_response(on_response) is not None



# Generated at 2022-06-24 04:06:12.685367
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic("test_MiddlewareMixin_on_response")
    @app.on_response # noqa
    async def test_on_response(request, response):
        response = text("Response text")

    assert app.listeners["response"][0]["func"] == test_on_response


# Generated at 2022-06-24 04:06:19.961577
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """
    - Test setup
        - create a class that inherite from MiddlewareMixin
        - create a simple middleware
    - Test steps
        - use middleware method in the class MiddlewareMixin
    - Expected results
        - cas succeed
    """
    def test_method():
        pass
    t = MiddlewareMixin()
    t.middleware(test_method)
    t.on_request(test_method)
    t.on_response(test_method)

# Generated at 2022-06-24 04:06:27.843754
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic(__name__)
    assert isinstance(app,MiddlewareMixin)
    @app.on_response
    def test_response(request,response):
        pass
    on_response = app.listeners["response"]
    assert isinstance(on_response,list) and len(on_response)==1 and isinstance(on_response[0],FutureMiddleware)

# Generated at 2022-06-24 04:06:35.751882
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Define class to help testing the method on_request
    import types
    class Test_Class_on_request(MiddlewareMixin):
        def __init__(self):
            self._future_middleware: List[FutureMiddleware] = []
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa
    # Define a function that will be used as middleware
    def my_middleware(request,response):
        # print(middleware_type)
        print("Hello from my_middleware!")
    # Call the function on_request
    test_class_on_request = Test_Class_on_request()
    test_class_on_request.on_request(my_middleware)

# Generated at 2022-06-24 04:06:39.353444
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin().on_request
    assert MiddlewareMixin().on_request("request")


# Generated at 2022-06-24 04:06:45.086418
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.protocols.http import HttpProtocol
    from sanic.server import HttpProtocol as server

    class FutureMiddleware:
        def __init__(self, middleware, attach_to):
            pass
    # __init__(self, *args, **kwargs) -> None:
    middleware = MiddlewareMixin()
    assert(middleware!=None)



# Generated at 2022-06-24 04:06:53.495753
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MiddlewareMixin_Test(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(MiddlewareMixin_Test, self).__init__(*args, **kwargs)
            self.kwargs = kwargs
            self._future_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            return middleware.attach_to

    # case1: callable(middleware)
    class Middleware:
        pass
    middleware_test = Middleware()
    app_test = MiddlewareMixin_Test()
    assert app_test.on_request(middleware_test) is 'request'
    assert app_test._future_middleware[0].middleware == middleware_test
    assert app_test._future_middleware

# Generated at 2022-06-24 04:07:01.393927
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestApp:
        pass
    test_app = TestApp()
    MiddlewareMixin.__init__(test_app)
    @test_app.middleware
    def test_middleware(request):
        pass
    assert len(test_app._future_middleware) == 1
    assert test_app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-24 04:07:03.562548
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    assert mm._future_middleware == []

assert test_MiddlewareMixin() == None


# Generated at 2022-06-24 04:07:11.288750
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    def middleware(request):
        return request

    def middleware2(request):
        return request

    async def handler(request):
        return HTTPResponse()

    app = Sanic()
    app.on_request(middleware)
    app.on_request(middleware2)
    app.add_route(handler, "/")
    _, _, response = app.test_client.get("/")
    assert response.status == 200


# Generated at 2022-06-24 04:07:13.724237
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    app = Sanic('test_app')

    def middleware(request):
        return

    app.on_request(middleware)

    assert app._future_middleware != []


# Generated at 2022-06-24 04:07:21.040752
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    # Test for an instance of Sanic class
    app = Sanic('sanic-app')
    @app.middleware('request')
    def test_middleware(request):
        return request

   # Test for an instance of Sanic class
    @app.middleware
    def test_middleware_with_default(request):
        return request

    # Test for an instance of Sanic class
    @app.on_response
    def test_on_response(request, response):
        return response

    # Test for an instance of Sanic class
    @app.on_request
    def test_on_request(request):
        return request

    # Test for an instance of Sanic class

# Generated at 2022-06-24 04:07:22.002563
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    value = MiddlewareMixin()
    assert(isinstance(value, MiddlewareMixin))

# Generated at 2022-06-24 04:07:26.689641
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.response import HTTPResponse

    app = Sanic("test_MiddlewareMixin")   
    @app.middleware()
    def test_middleware(request):
        return HTTPResponse()
    assert app._future_middleware[0].middleware == test_middleware



# Generated at 2022-06-24 04:07:35.739229
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.exceptions import NotFound
    from sanic.models.middleware import Middleware
    from sanic.models.exceptions import MethodNotFound

    class TestMiddleware(Middleware):
        def resolve(self, request, get_response):
            return await get_response(request)

    test_middleware = TestMiddleware()

    class TestApp:
        def __init__(self):
            self.middleware = MiddlewareMixin()
            self.middleware.middleware(test_middleware, attach_to="request")
            
        def route(self, uri, methods=['GET']):
            def decorator(handler):
                pass
            return decorator

        def add_route(self, handler, uri, methods=['GET']):
            pass

        def exception(self, *args):
            return

# Generated at 2022-06-24 04:07:46.092201
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin = MiddlewareMixin()
    @middleware_mixin.on_request()
    async def foo(request):
        return True

    from sanic.request import Request
    from sanic.response import HTTPResponse
    request = Request.from_dict({
        'headers': [],
        'version': [1, 1],
        'method': 'GET',
        'uri': 'http://192.168.1.100:8888/',
        'body': b'',
        'parsed_body': {},
        'args': [],
        '_app': middleware_mixin,
        '_cookies': {},
        '_task': None
    })


# Generated at 2022-06-24 04:07:50.616879
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()

    def middleware1(request, response):
        pass

    def middleware2(request, response):
        pass

    app.middleware(middleware1)
    app.middleware(middleware2)
    assert app._future_middleware[0].middleware is middleware1
    assert app._future_middleware[1].middleware is middleware2
    assert len(app._future_middleware) == 2


# Generated at 2022-06-24 04:07:57.716863
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    # Define a mock app
    class MyApp(Sanic):
        def handler(self, request):
            return HTTPResponse("OK")

    # Define a mock middleware
    async def middleware(request):
        return request

    app = MyApp()
    app.add_route(app.handler, "/")
    app.on_request(middleware)

    # A request to retrieve the route handler
    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.text == "OK"

# Generated at 2022-06-24 04:08:06.321905
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # make a dummy class
    class X(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
    @X.on_response("response")
    def f():
#        pass
        return "hello"
    assert f("world") == "hello"
    assert f("world") == "hello"


# Generated at 2022-06-24 04:08:13.252928
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MyMiddleWareMixin(MiddlewareMixin):
        def _apply_middleware(self, middlware):
            pass

    class MyApplication:
        _middleware_mixin = MyMiddleWareMixin()

        def __init__(self):
            self.middleware = self._middleware_mixin.middleware

    app = MyApplication()

    @app.middleware
    async def middleware(request):
        pass
    assert len(app._middleware_mixin._future_middleware) == 1
    assert app._middleware_mixin._future_middleware[0].attach_to == "request"



# Generated at 2022-06-24 04:08:19.046795
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic import response
    app = Sanic()
    @app.middleware
    def mw1(request):
        return response.text("1")
    @app.on_request
    def mw2(request):
        return response.text("2")
    @app.middleware("request")
    def mw3(request):
        return response.text("3")
    @app.on_request()
    def mw4(request):
        return response.text("4")


# Generated at 2022-06-24 04:08:20.351226
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """
    case1:
    """
    # TODO
    pass


# Generated at 2022-06-24 04:08:22.548301
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # setup
    middlewareMixin = MiddlewareMixin()
    # assert
    assert middlewareMixin._future_middleware == []



# Generated at 2022-06-24 04:08:31.005077
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class ClassWithMiddleware(MiddlewareMixin):

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    @ClassWithMiddleware.middleware("request")
    async def my_middleware(
            request: Request,
            _: Response
    ):  # pylint: disable=W0613
        pass

    # pylint: disable=E1101
    assert len(ClassWithMiddleware._future_middleware) == 1
    assert ClassWithMiddleware._future_middleware[0].middleware == my_middleware
    assert ClassWithMiddleware._future_middleware[0].attach_to == "request"



# Generated at 2022-06-24 04:08:35.364914
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic

    app = Sanic('test_Sanic_app')
    assert app._future_middleware == []
    assert app._future_handlers == []

# Generated at 2022-06-24 04:08:37.312305
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    assert mm._future_middleware == []
    

# Generated at 2022-06-24 04:08:40.003615
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Create a new MiddlewareMixin instance
    mm = MiddlewareMixin()

    # Run function on_request
    mm.on_request(middleware=None)

# Generated at 2022-06-24 04:08:41.411740
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response(middleware=None)()

# Generated at 2022-06-24 04:08:52.441638
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import pytest
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.testing import SanicTestClient
    from sanic.testing import create_server

    app = Sanic("test_MiddlewareMixin_middleware_app")

    @app.middleware("request")
    async def foo(request):
        request["test"] = True

    @app.middleware("response")
    async def bar(request, response):
        response.text = "test"

    @app.route("/")
    async def handler(request):
        return text("OK")


# Generated at 2022-06-24 04:09:03.135197
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.models.middleware import MiddlewareMixin
    from sanic.response import text
    from unittest import TestCase
    from unittest.mock import MagicMock
    class DummyMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass

    dummy_middleware_mixin = DummyMiddlewareMixin()
    dummy_middleware_mixin.middleware = MagicMock()
    def dummy_handler(request):
        return text("test")
    dummy_middleware_mixin.handler = dummy_handler
    dummy_middleware_mixin.on_response(None)
    dummy_middleware_mixin.middleware.assert_called_once_with(None, 'response')
    return


# Generated at 2022-06-24 04:09:04.886155
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin._future_middleware == []

# Generated at 2022-06-24 04:09:07.958105
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert isinstance(app, MiddlewareMixin)
    assert app._future_middlewa

# Generated at 2022-06-24 04:09:08.779927
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert callable(MiddlewareMixin().on_response())

# Generated at 2022-06-24 04:09:10.663177
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestClass(MiddlewareMixin):
        pass
    test_app = TestClass()
    assert test_app._future_middleware == []

# Generated at 2022-06-24 04:09:15.684439
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class app_middleware(MiddlewareMixin):
        def __init__(self):
            super().__init__()
        def _apply_middleware(self, middleware: FutureMiddleware):
            MiddlewareMixin._future_middleware.append(middleware)
    app = app_middleware()
    app.middleware(lambda x: x)
    assert len(app._future_middleware) == 1

# Generated at 2022-06-24 04:09:17.778841
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert MiddlewareMixin.middleware == MiddlewareMixin.middleware


# Generated at 2022-06-24 04:09:18.324696
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass

# Generated at 2022-06-24 04:09:19.084777
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass


# Generated at 2022-06-24 04:09:22.386197
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            assert self._future_middleware == []
    TestClass()


# Generated at 2022-06-24 04:09:23.941146
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Test(MiddlewareMixin):
        def __init__(self):
            super(Test, self).__init__()

    test = Test()

# Generated at 2022-06-24 04:09:26.419213
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    assert m.on_request() == partial(m.middleware, attach_to="request")

# Generated at 2022-06-24 04:09:32.548344
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic()

    @app.on_response
    def log_response(request, response):
        print(response.text)

    @app.route("/")
    async def handler(request):
        return Sanic.response.text("Yeah!")

    request, response = app.test_client.get("/")
    log_response(request, response)


# Generated at 2022-06-24 04:09:34.194940
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []

# Generated at 2022-06-24 04:09:39.137762
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddlewareMixinTest(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(MiddlewareMixinTest, self).__init__(*args, **kwargs)

    test_instance = MiddlewareMixinTest()

    assert test_instance._future_middleware == []

# Generated at 2022-06-24 04:09:47.730114
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import json, text
    from sanic_plugin.plugin import Plugin
    from sanic_plugin.utils.middleware import MiddlewareMixin
    from sanic_plugin.utils.middleware import showRequestInfoMiddleware


    class MyPlugin(Plugin, MiddlewareMixin):
        def __init__(self, app : Sanic, *args, **kwargs) -> None:
            Plugin.__init__(self, app, *args, **kwargs)
            MiddlewareMixin.__init__(self)

            self.on_request(showRequestInfoMiddleware)
            self.on_response(showRequestInfoMiddleware)

            self.route('/', methods=['GET', 'POST', 'OPTIONS'])(self.handler)


# Generated at 2022-06-24 04:09:56.639609
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(TestMiddlewareMixin,self).__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    my_test = TestMiddlewareMixin()
    @my_test.middleware
    def execute_middleware():
        return "A"
    assert execute_middleware() == "A"


# Generated at 2022-06-24 04:10:07.533697
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic, Blueprint
    from sanic.response import text

    def madware(request):
        return request

    app = Sanic("sanic test")
    bp = Blueprint("blue")

    @app.middleware("request")
    def request_middleware(request):
        return request

    @bp.middleware("request")
    def request_middleware(request):
        return request

    @bp.middleware("response")
    def response_middleware(request, response):
        return request, response

    @bp.middleware("middle")
    def middle_middleware(request, response):
        return request, response

    @bp.middleware
    def argless_middleware(request, response):
        return request, response


# Generated at 2022-06-24 04:10:16.137871
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json

    async def middleware_factory(request):
        return lambda r: json({'middleware': True})

    app = Sanic()

    @app.middleware(middleware_factory)
    @app.route('/')
    async def handler(request):
        return json({'handled': True})

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'middleware': True}

    # Unit test for method on_request of class MiddlewareMixin

# Generated at 2022-06-24 04:10:24.811161
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    attach_to = 'request'
    
    def middleware(request):
        request['blue'] = 'green'
        return request

    middleware_or_request=attach_to

    app.middleware(middleware_or_request)(middleware)

    print("app.middleware :",app.middleware)
    print("app._future_middleware :",app._future_middleware)
    # <bound method MiddlewareMixin.middleware of <sanic.app.Sanic object at 0x105d3f8d0>>
    # [<sanic.models.futures.FutureMiddleware object at 0x105d3f8d0>]

    # SanicObject.middleware(middleware_or

# Generated at 2022-06-24 04:10:35.341811
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from .mock_models import MockMiddlewareMixin
    from .mock_models import MockRequest
    from .mock_models import MockResponse

    app = MockMiddlewareMixin()

    class App(object):

        def __init__(self):
            self.response = None

        def on_response(self, req, res):
            self.response = res

    a = App()

    @app.on_response(a.on_response)
    def handler(req):
        return MockResponse()

    handler(MockRequest())

    assert a.response is not None
    assert type(a.response) is MockResponse
    assert a.response.status == 200

# Generated at 2022-06-24 04:10:44.773768
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.futures import FutureMiddleware
    from sanic.models.implement import Sanic

    app = Sanic("test_app")
    assert len(app._future_middleware) == 0

    # 1. Call as @app.on_request()
    @app.on_request()
    def middleware_1():
        pass
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].future is None
    assert isinstance(app._future_middleware[0], FutureMiddleware)


    # 2. Call as @app.on_request(middleware)
    middleware_2 = lambda request: None
    app.on_request(middleware=middleware_2)


# Generated at 2022-06-24 04:10:48.966259
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    
    app = Sanic("test_MiddlewareMixin")
    @app.on_response()
    async def response_middleware1(request, response):
        pass
    assert app.state.middleware["response"][0].middleware is response_middleware1
    
    @app.on_response
    async def response_middleware2(request, response):
        pass
    assert app.state.middleware["response"][1].middleware is response_middleware2


# Generated at 2022-06-24 04:10:53.571313
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.middleware import MiddlewareMixin

    class Mixin(MiddlewareMixin):
        pass

    mixin = Mixin()
    assert mixin.on_request() == partial(mixin.middleware, attach_to="request")

    def on_request_handler(request, handler):
        return True

    assert (
        mixin.on_request(on_request_handler)
        == mixin.middleware(on_request_handler, "request")
    )



# Generated at 2022-06-24 04:10:56.980108
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    def test_MiddlewareMixin_on_request_middleware(request):
        pass
    app = MiddlewareMixin()
    app.on_request(test_MiddlewareMixin_on_request_middleware)
    assert type(app._future_middleware[0]) == FutureMiddleware


# Generated at 2022-06-24 04:10:59.267400
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    mm = MiddlewareMixin()
    mm.on_response('response')


if __name__ == "__main__":
    test_MiddlewareMixin_on_response()

# Generated at 2022-06-24 04:11:05.961074
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.models.futures import MiddlewareMixin
    import io

    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, future_middleware: FutureMiddleware):
            pass

    g = io.BytesIO(b"a")
    m = TestMiddlewareMixin()
    def test_inner(request):
        g.read(-1)
        return request

    m.on_response(test_inner)("request")
    assert g.read(-1) == b''

# Generated at 2022-06-24 04:11:08.648463
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

# Generated at 2022-06-24 04:11:09.448128
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass


# Generated at 2022-06-24 04:11:12.621440
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Test:
        def __init__(self):
            self.x = "init"
        def on_request(self, req):
            self.x = "on_request"
    t = Test()
    t.on_request()
    assert t.x == "on_request"


# Generated at 2022-06-24 04:11:13.125788
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert True

# Generated at 2022-06-24 04:11:16.469422
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    @MiddlewareMixin.middleware('response')
    async def expected(request):
        return response
    assert len(MiddlewareMixin._response_middleware) > 0


# Generated at 2022-06-24 04:11:27.434108
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test_MiddleWareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []
        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)

    test_MiddleWareMixin = Test_MiddleWareMixin()
    assert len(test_MiddleWareMixin._future_middleware) == 0
    @test_MiddleWareMixin.middleware
    def on_request_middleware(request):
        return 1
    assert len(test_MiddleWareMixin._future_middleware) == 1
    middleware = test_MiddleWareMixin._future_middleware[0]
   

# Generated at 2022-06-24 04:11:34.136844
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from unittest.mock import Mock
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware

    mock_future_middleware = Mock(FutureMiddleware)

    app = Sanic()

    # Call with 2 parameters
    app.middleware = MiddlewareMixin()
    app.middleware._apply_middleware = Mock()

    assert app.middleware._future_middleware == []
    app.middleware(mock_future_middleware)
    assert app.middleware._future_middleware == [mock_future_middleware]

    # Call with the 2nd parameter set to False
    app.middleware = MiddlewareMixin()
    app.middleware._apply_middleware = Mock()

    assert app.middleware._future_middleware == []

# Generated at 2022-06-24 04:11:39.409095
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic()

    @app.middleware
    async def middleware_function(request):
        request['middleware'] = True
        return request

    @app.route('/')
    async def handler(request):
        return json({'test': request.get('middleware', False)})

    request, response = app.test_client.get('/')

    assert response.json == {'test': True}


# Generated at 2022-06-24 04:11:50.112318
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json

    app = Sanic('test_MiddlewareMixin_middleware')

    request_count = 0
    response_count = 0

    @app.middleware('request')
    async def request_func(request):
        nonlocal request_count
        request_count += 1
        return request

    @app.middleware('response')
    async def response_func(request, response):
        nonlocal response_count
        response_count += 1
        return response

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert request_count == 1
    assert response_count == 1


# Generated at 2022-06-24 04:11:58.954203
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.exceptions import NotFound
    from sanic.response import json
    from sanic.server import HttpProtocol
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol

    # Set MiddlewareMixin.on_request
    @MiddlewareMixin.on_request
    async def process_request(request):
        return await response

    class TestView(HTTPMethodView):
        async def get(self, request):
            return text("OK")

    app = Sanic("test_on_request")
    app.add_route(TestView.as_view(), "/")
    request, response = app.test_client.get("/")
    assert response.status == 404



# Generated at 2022-06-24 04:12:01.322043
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin(None)._future_middleware == []


# Generated at 2022-06-24 04:12:07.100382
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Mock class for testing
    class MockMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    # Instantiate mock class
    middleware_mixin = MockMiddlewareMixin()
    # Mock middleware function
    def mock_middleware(*args, **kwargs):
        pass
    # Call on_response
    middleware_mixin.on_response(middleware=mock_middleware)

# Generated at 2022-06-24 04:12:10.320338
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    request = DummyRequest()
    response = DummyResponse()
    @MiddlewareMixin.on_response()
    async def test_middleware_response(request, response=None):
        assert request == request
        assert response == response
        return response

    test_middleware_response(request, response)

# Generated at 2022-06-24 04:12:12.125285
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    mm = MiddlewareMixin()
    assert mm.on_request is partial(mm.middleware, attach_to="request")


# Generated at 2022-06-24 04:12:23.423534
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import unittest
    from unittest import mock
    from sanic.models.futures import FutureMiddleware

    # test

    class MiddlewareMixinTest(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = [
                FutureMiddleware("on_request"),
                FutureMiddleware("on_response"),
            ]

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = MiddlewareMixinTest(on_request=None, on_response=None)
    assert len(app._future_middleware) == 2
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app

# Generated at 2022-06-24 04:12:24.364882
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert False

# Generated at 2022-06-24 04:12:31.153084
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class DummyApp():
        def __init__(self):
            self._future_middleware = []

        def _apply_middleware(self, middleware):
            self._future_middleware.append(middleware)

            # Make sure that on_response is called
            assert middleware._attach_to == 'response'

    dummy_app = DummyApp()
    dummy_app.on_response()
    dummy_app.on_response(lambda s,f,r: None)

# Generated at 2022-06-24 04:12:36.401296
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic

    app = Sanic("test_MiddlewareMixin")
    assert isinstance(app, MiddlewareMixin)

    @app.middleware('request')
    async def middleware(request):
        pass

    assert app._future_middleware == [
        FutureMiddleware(middleware=middleware, attach_to='request')
    ]


# Generated at 2022-06-24 04:12:39.600398
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    f = MiddlewareMixin()
    f.on_response(lambda x: x*2)
    assert f._future_middleware[0].middleware(3) == 6

# Generated at 2022-06-24 04:12:48.159396
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    
    app = Sanic()
    assert app._future_middleware == []
    # when middleware is a callable object
    @app.middleware('request')
    def middleware_test(request):
        pass
    assert len(app._future_middleware) == 1
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].middleware == middleware_test
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[0].apply is True
    # when middleware is None
    assert app.middleware(None, 'response') == partial(app.middleware, attach_to='response')

# Generated at 2022-06-24 04:12:56.088862
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic, Notification

    app = Sanic('test')
    # request middleware
    @app.on_request
    def request1(request):
        request["request1"] = True
    assert app.is_request(app._future_middleware[-1][0])

    # response middleware
    @app.on_response
    def response1(request, response):
        response["response1"] = True
    assert not app.is_request(app._future_middleware[-1][0])



# Generated at 2022-06-24 04:13:02.580195
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestObj(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    obj = TestObj()
    # Call method on_request without arg middleware
    m1 = obj.on_request()
    assert m1.keywords['attach_to'] == "request"
    # Call method on_request with arg middleware
    m2 = obj.on_request(middleware=None)
    assert m2.keywords['attach_to'] == "request"


# Generated at 2022-06-24 04:13:09.599233
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    # Apply middleware on request
    app = Sanic(__name__)

    @app.middleware('request')
    async def handle_request(request):
        request['foo'] = 'bar'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert request['foo'] == 'bar'

    # Apply middleware on response
    app = Sanic(__name__)

    @app.middleware('response')
    async def handle_response(request, response):
        response.headers['foo'] = 'bar'

    @app.route('/')
    async def handler(request):
        return

# Generated at 2022-06-24 04:13:18.530039
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    unit = MiddlewareMixin()

    @unit.middleware(attach_to="test")
    def test_middleware(request):
        pass

    assert hasattr(test_middleware, "__middleware_name__")
    assert hasattr(test_middleware, "__middleware_version__")
    assert hasattr(test_middleware, "__middleware_type__")
    assert test_middleware.__middleware_name__ == "test_middleware"
    assert test_middleware.__middleware_version__ == "0.0.1"
    assert test_middleware.__middleware_type__ == "test"

    # Unit test for method on_request of class MiddlewareMixin
    def test_MiddlewareMixin_on_request():
        unit = MiddlewareMixin()


# Generated at 2022-06-24 04:13:28.065684
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    class MiddlewareMixin_on_request(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self.sanic = None
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware):
            self.sanic.request_middleware.append(middleware)

    app = Sanic()
    app.sanic = app

    mixin = MiddlewareMixin_on_request()

    @mixin.on_request()
    def middleware(request):
        pass

    assert len(mixin._future_middleware) == 1

    assert mixin._future_middleware[0].middleware == middleware
    assert mixin._future_middleware[0].attach_to == "request"

# Generated at 2022-06-24 04:13:28.999288
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin.on_request

# Generated at 2022-06-24 04:13:33.408404
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    try:
        class TestMiddlewareMixin(MiddlewareMixin):
            def _apply_middleware(self, middleware: FutureMiddleware):
                pass
        test = TestMiddlewareMixin()
        assert test._future_middleware == []
        test.on_request(middleware=lambda x: x.path)
        assert test._future_middleware != []
    except:
        assert False

# Generated at 2022-06-24 04:13:44.115325
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    import sanic
    sanic_instance = Sanic("sanic")
    assert sanic_instance.middleware == MiddlewareMixin.middleware
    assert sanic_instance.on_request == MiddlewareMixin.on_request
    assert sanic_instance.on_response == MiddlewareMixin.on_response
    def test_middleware(request):
        pass
    sanic_instance.middleware(test_middleware)
    assert sanic_instance._future_middleware[0].middleware == test_middleware
    assert sanic_instance._future_middleware[0].attach_to == "request"
    sanic_instance.on_request(test_middleware)
    assert sanic_instance._future_middleware[1].middleware == test_middleware
    assert san

# Generated at 2022-06-24 04:13:49.293270
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.exceptions import RequestTimeout

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def check_if_timeout(request):
        print('Checking if request is timedout')

    request, response = app.test_client.get('/')
    assert response.status == 599

# Generated at 2022-06-24 04:13:53.641139
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    class _TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware = _TestMiddlewareMixin()
    middleware_func = lambda request, response: None
    test_middleware.middleware(middleware_func)
    test_middleware.middleware(middleware_func, "response")

# Generated at 2022-06-24 04:13:59.951369
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Arrange
    test_object = MiddlewareMixin()
    # Act
    test_result = test_object.on_request()
    # Assert
    assert callable(test_result)
    assert test_result.args == (None,)
    assert repr(test_result) == "partial(<function MiddlewareMixin.middleware at 0x7fe0b8060d08>, attach_to='request')"  # noqa


# Generated at 2022-06-24 04:14:00.911042
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-24 04:14:03.182291
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    test = MiddlewareMixin()

    def m(request, response):
        return response

    print(test.on_response(m))
    assert test.on_response(m) is not None

# Generated at 2022-06-24 04:14:08.625129
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Given
    class Request:
        pass
    
    class Response:
        pass

    def middleware(request: Request) -> Response:
        return Response()

    # When
    middleware_mixin = MiddlewareMixin()

    # Then
    assert callable(middleware_mixin.on_response(middleware))

# Generated at 2022-06-24 04:14:12.417674
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    def req_func(request):
        return request

    app = Sanic(__name__)
    app.on_request(req_func)

    assert req_func in app.request_middleware



# Generated at 2022-06-24 04:14:17.284670
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic

    app = Sanic("test_MidlewareMixin_on_response")

    @app.middleware('response')
    def my_middleware(request):
        pass

    assert callable(my_middleware)
    assert my_middleware.__name__ == "my_middleware"
    assert my_middleware.__module__ == "__main__"

# Generated at 2022-06-24 04:14:28.202710
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic_restful.mixin import MiddlewareMixin

    app = Sanic("test_MiddlewareMixin_on_response")
    app.__class__.on_request = MiddlewareMixin.on_request
    app.__class__.on_response = MiddlewareMixin.on_response

    @app.route("/")
    async def handler(request):
        return json({"test": True})

    @app.on_response
    async def on_response(request, response):
        response.headers["test"] = "true"

    request, response = app.test_client.get("/")
    assert response.status == 200
    assert response.headers.get("test") == "true"

# Generated at 2022-06-24 04:14:38.030123
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # We create a middleware mixin with a given attribute.
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, _future_middleware, *args, **kwargs) -> None:
            self._future_middleware = _future_middleware
    
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    
    my_middleware = FutureMiddleware(lambda x: None, 'request')
    my_middleware_mixin = TestMiddlewareMixin([my_middleware])
    
    # We test the method on_request without a parameter.
    result = my_middleware_mixin.on_request()
    
    # Check if the result is a partial
    assert isinstance(result, partial)
    
    # Check if the result is a partial of

# Generated at 2022-06-24 04:14:38.728377
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    ...

# Generated at 2022-06-24 04:14:47.485024
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    class TestRequest:
        def __init__(self, uri, request_handler):
            self._uri = uri
            self._request_handler = request_handler

    class TestResponse:
        def __init__(self, url, response_handler):
            self._url = url
            self._response_handler = response_handler

    #test_normal
    test_obj = TestMiddlewareMixin()
    test_req = TestRequest("", "")
    test_res = TestResponse("", "")
    def test_request_handler(req):
        assert(req == test_req)

# Generated at 2022-06-24 04:14:57.323422
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import asyncio
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    obj = MiddlewareMixin()

    @app.middleware('request')
    async def request(request):
        pass

    @app.middleware('response')
    async def response(request, response):
        pass

    assert len(obj._future_middleware) == 0
    obj._apply_middleware(FutureMiddleware(request, 'request'))
    assert len(obj._future_middleware) == 1
    obj._apply_middleware(FutureMiddleware(response, 'response'))
    assert len(obj._future_middleware) == 2


# Generated at 2022-06-24 04:14:59.935759
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class test(MiddlewareMixin):
        def __init__(self):
            super().__init__()
    t = test()
    assert t._future_middleware == []

# Generated at 2022-06-24 04:15:02.727500
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')
    app.on_request(middleware='request')
    app.on_response(middleware='response')
    #app.middleware('request')
    #app.middleware('response')

# Generated at 2022-06-24 04:15:06.864412
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m = MiddlewareMixin()
    @m.middleware
    async def test(request):
        return request
    assert len(m._future_middleware) == 1
    assert m._future_middleware[0].middleware == test

# Generated at 2022-06-24 04:15:12.666617
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class FakeApp(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

    fake_app = FakeApp()
    assert (
        fake_app.on_request(middleware=partial(lambda x: x, attach_to="request"))
        == fake_app._future_middleware[0]
    )


# Generated at 2022-06-24 04:15:13.565662
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    m = MiddlewareMixin()
    m.on_response()

# Generated at 2022-06-24 04:15:22.119532
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import inspect
    # Initialize the class
    middlewareMixin = MiddlewareMixin()
    # Call the method on_response without parameter
    result = middlewareMixin.on_response()
    # Verify the result
    assert callable(result)
    assert "partial" in (inspect.getsource(result.__class__))
    # Call the method on_response with parameter
    def myFunction():
        return 'Function called'
    result = middlewareMixin.on_response(myFunction)
    assert callable(result)
    assert "Function called" == result()



# Generated at 2022-06-24 04:15:26.091697
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m = MiddlewareMixin()
    assert(m._future_middleware == [])
    @m.middleware
    def mid1(req):
        pass
    assert(m._future_middleware != [])
    m.middleware(mid1)


# Generated at 2022-06-24 04:15:26.594558
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-24 04:15:32.729378
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class test_class(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self._future_middleware = []
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    assert not test_class()._future_middleware
    assert test_class()._apply_middleware() == NotImplementedError

# Generated at 2022-06-24 04:15:42.727027
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic("test_MiddlewareMixin")
    @app.on_response
    def test_on_response(request, response):
        if not hasattr(test_on_response, "i"):
            test_on_response.i = 0
        test_on_response.i += 1
    @app.route("/")
    def handler(request):
        return request.app.name

    request, response = app.test_client.get("/")
    assert response.status == 200
    assert test_on_response.i == 1


# Generated at 2022-06-24 04:15:48.575133
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddleware(MiddlewareMixin):
        async def __call__(self, request):
            return request

    t = TestMiddleware()
    assert t.on_request().func is t.middleware
    assert t.on_request().keywords == {'attach_to': 'request'}
    assert t.on_request('response').keywords == {'attach_to': 'response'}
    t.on_request(lambda: 1)(2)

