

# Generated at 2022-06-24 04:06:06.058052
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MockApp:
        def __init__(self, *args, **kwargs):
            self._future_middleware = []

    # Mock Middleware request
    def mock_request(*args, **kwargs):
        print('mock_request')
        # call middle ware request
        self.middleware = self._future_middleware[0](*args, **kwargs)

    # Mock Middleware response
    def mock_response(*args, **kwargs):
        print('mock_response')
        # call middle ware response
        self.middleware = self._future_middleware[1](*args, **kwargs)

    # Mock Middleware request
    def mock_request1(*args, **kwargs):
        print('mock_request1')
        # call middle ware request
        self.middleware_request = self._future

# Generated at 2022-06-24 04:06:10.353067
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test = TestClass()
    test.middleware("request")
    test.middleware("response")
    test.on_request()
    test.on_response()


# Generated at 2022-06-24 04:06:11.922214
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """
    Unit test for method middleware of class MiddlewareMixin
    """
    pass

# Generated at 2022-06-24 04:06:12.988539
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert callable(MiddlewareMixin().on_request)


# Generated at 2022-06-24 04:06:19.605863
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    b = MiddlewareMixin()
    c = b.on_request(1)
    c = b.middleware(1)
    c = b.on_response(2)
    c = b.middleware(2, "response")
    c = b.middleware(3, "request")
    c = b.on_request(3)
    c = b.middleware(4)
    c = b.on_request(4)
    return True

# Generated at 2022-06-24 04:06:22.184446
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    app = MiddlewareMixin()
    assert app.on_response(middleware = None) == partial(app.middleware, attach_to="response")


# Generated at 2022-06-24 04:06:26.149558
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin().on_request("request")("middleware") == partial(MiddlewareMixin().middleware, attach_to="request")
    assert MiddlewareMixin().on_request("middleware")("request") == MiddlewareMixin().middleware("middleware", "request")


# Generated at 2022-06-24 04:06:34.398559
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware = [
        {'name': 'middleware1', 'attach_to': 'request'},
        {'name': 'middleware2', 'attach_to': 'request'},
        {'name': 'middleware3', 'attach_to': 'request'},
        {'name': 'middleware4', 'attach_to': 'request'},
    ]
    middleware[3]['attach_to'] = 'response'
    middleware[3]['name'] = 'middleware5'
    middleware[3]['name'] = 'middleware6'
    middleware[3]['name'] = 'middleware7'
    middleware[3]['name'] = 'middleware8'
    middleware[3]['name'] = 'middleware9'

# Generated at 2022-06-24 04:06:45.477645
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class test_class(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    class counter_class:
        def __init__(self):
            self.counter: int = 0

        def __call__(self):
            self.counter += 1

    m = test_class()
    c = counter_class()

    m.middleware(c, "request")(c)
    assert m._future_middleware[0] == FutureMiddleware(c, "request")
    assert m._future_middleware[0].middleware == c
    assert m._future_middleware[0].attach_to == "request"
   

# Generated at 2022-06-24 04:06:48.421096
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Given
    class MockMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    # When
    mixin = MockMiddlewareMixin()

    # Then
    assert mixin.middleware
    assert mixin.middleware.__qualname__ == 'MiddlewareMixin.middleware'

# Generated at 2022-06-24 04:06:49.160960
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass


# Generated at 2022-06-24 04:06:55.893660
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    assert len(app._future_middleware) == 0

    @app.middleware
    def attach_to_request(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware is attach_to_request
    assert app._future_middleware[0].attach_to == "request"

    @app.middleware('request')
    def request_middleware(request):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware is request_middleware
    assert app._future_middleware[1].attach_to == "request"


# Generated at 2022-06-24 04:06:56.494827
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass


# Generated at 2022-06-24 04:07:03.385542
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.views import HTTPMethodView
    class SimpleView(HTTPMethodView):
        def get(self, request):
            return "It works"
        def post(self, request):
            pass
    async def handler(request):
        return "It works"
    app = Sanic('test_MiddlewareMixin_on_request')
    app.add_route(SimpleView.as_view(), '/')
    app.add_route(handler, '/test_handler')
    middleware = lambda x: print(x)
    assert app.on_request(middleware) is not None
    assert app._future_middleware is not None
    assert app._future_middleware[0].middleware == middleware


# Generated at 2022-06-24 04:07:12.210290
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MyMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    middleware_mixin = MyMiddlewareMixin()
    assert isinstance(middleware_mixin, MyMiddlewareMixin)

    middleware_mixin.middleware(middleware_or_request = middleware)
    middleware_mixin.on_request(middleware = middleware)
    middleware_mixin.on_response(middleware = middleware)

# Generated at 2022-06-24 04:07:22.688263
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    def middleware1(request):
        return HTTPResponse(body="middleware1")

    def middleware2(request):
        return HTTPResponse(body="middleware2")

    async def handler(request):
        return HTTPResponse(body="handler")

    app = Sanic("MiddlewareMixin.middleware")
    app.middleware(middleware1)
    app.middleware(middleware2, "request")
    app.add_route(handler, uri="/", methods=["GET"])

    _, response = app.test_client.get("/")
    assert response.body == b"middleware2"

# Generated at 2022-06-24 04:07:26.718352
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    async def my_middleware(request):
        print("middleware before request")
        response = await handler(request)
        print("middleware after response")
        return response
    @app.route('/')
    async def handler(request):
        return response.text('Awesome!')
    app.middleware(my_middleware)


# Generated at 2022-06-24 04:07:35.306274
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.response import json

    @sanic.middleware("response")
    async def response_middleware(request, response):
        # print("I am a response middleware")
        assert(isinstance(request, sanic.request.Request))
        assert(isinstance(response, sanic.response.HTTPResponse))
        response.text = "I am a response middleware"
        return response

    app = sanic.Sanic()
    app.on_response(response_middleware)

    @app.route("/")
    async def handler(request):
        return json({"test": True})

    request, response = app.test_client.get('/')
    assert response.text == "I am a response middleware"

# Generated at 2022-06-24 04:07:45.684651
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()

    # The called function is without parameters
    @app.middleware
    async def add_middleware(request):
        return request

    middleware_len = len(app._future_middleware)
    # Calling the function again will not increase the length
    @app.middleware
    async def add_middleware2(request):
        return request
    assert middleware_len == len(app._future_middleware)

    # The called function is with parameter
    @app.middleware('request')
    async def add_middleware_r(request):
        return request

    @app.middleware('response')
    async def add_middleware_s(request, response):
        return response

    assert isinstance(app.on_request, partial)

# Generated at 2022-06-24 04:07:46.421228
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    MiddlewareMixin()


# Generated at 2022-06-24 04:07:50.668337
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(*args, **kwargs):
            super(TestMiddlewareMixin, args[0]).__init__()
    tmm = TestMiddlewareMixin()
    def test_function(request, response):
        return response
    tmm.on_response(test_function)

# Generated at 2022-06-24 04:07:51.185989
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert True

# Generated at 2022-06-24 04:07:53.461017
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    app = MiddlewareMixin()
    assert app._future_middleware == []

if __name__ == "__main__":
    test_MiddlewareMixin()

# Generated at 2022-06-24 04:08:01.039912
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """
    test_MiddlewareMixin_middleware()

    This function aims to test the function middleware of the class
    MiddlewareMixin.

    :return: None
    """

    from sanic.request import Request

    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware():
            pass

    # test for decorator
    @TestMiddlewareMixin().on_request
    async def request_middleware_decorator(request):
        pass

    assert isinstance(request_middleware_decorator, type(Request))

    # test for partial

# Generated at 2022-06-24 04:08:08.318684
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from os import path
    from . import Sanic

    app = Sanic("test_MiddlewareMixin_on_request")

    source_dir = path.dirname(__file__)

    @app.middleware("request")
    async def request_middleware(request):
        request["middleware"] = "this is a test"
        assert request["middleware"] == "this is a test"

    try:
        @app.middleware("test_MiddlewareMixin_on_request")
        def response_middleware(request):
            return

        assert True
    except TypeError:
        assert False
    except AssertionError:
        assert False

    async def handler(request):
        return text("OK")


# Generated at 2022-06-24 04:08:18.901528
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import CompositionView

    @CompositionView.middleware(CompositionView)  # noqa
    async def composition_view_middleware(request: Request):
        return None

    app = Sanic()

    @app.middleware(CompositionView)  # noqa
    async def composition_view_middleware(request: Request):
        return None

    @app.middleware  # noqa
    async def global_middleware(request: Request):
        return None

    @app.on_response  # noqa
    async def global_middleware_response(request: Request, response: HTTPResponse):
        return response


# Generated at 2022-06-24 04:08:20.281996
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    instance = MiddlewareMixin()
    instance.on_response()

# Generated at 2022-06-24 04:08:24.370037
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class DummyClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    dummy_class_obj = DummyClass()
    assert dummy_class_obj._future_middleware == []

# Generated at 2022-06-24 04:08:31.288244
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.request import Request
    from sanic.response import HTTPResponse
    m = MiddlewareMixin()
    assert isinstance(m, MiddlewareMixin)
    # Test decoration of middleware
    @m.middleware
    async def func1(request: Request) -> HTTPResponse:
        raise NotImplementedError
    assert isinstance(m._future_middleware[0].middleware, type(func1))

if __name__ == "__main__":
    test_MiddlewareMixin()

# Generated at 2022-06-24 04:08:40.580949
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware
    app = Sanic()
    # Case 1: decorate function
    @app.middleware
    def request(request):
        pass
    # Case 2: decorate class
    @app.middleware
    class Request:
        def __init__(self, request):
            pass
    # Case 3: callable is not the type of class or callable object
    try:
        app.middleware(Request)
    except TypeError:
        pass
    # Case 4: attach_to is not either "request" or "response"
    @app.middleware("middleware")
    def request(request):
        pass
    assert isinstance( app.middleware._future_middleware[0], FutureMiddleware )

# Generated at 2022-06-24 04:08:48.103421
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic import response
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.middleware('response')
    def print_on_response(request, response):
        print('Response:', response)
    @app.route('/')
    async def test(request):
        return response.text('OK')
    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-24 04:08:53.644113
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic("sanic-server")

    def request_middleware(request):
        return request

    app.on_request(request_middleware)

    assert len(app._future_middleware) == 0

    assert len(app._middleware) == 1

    assert app._middleware[0].attach_to == "request"
    assert app._middleware[0].middleware == request_middleware

# Generated at 2022-06-24 04:09:03.241914
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_on_response_middleware')
    @app.middleware
    def request_middleware(request) :
        foo = None
        return foo
    @app.middleware('request')
    def request_middleware_2(request) :
        foo = None
        return foo
    @app.on_request
    def request_middleware_3(request) :
        foo = None
        return foo
    @app.on_response
    def response_middleware(request, response) :
        foo = None
        return foo
    @app.response('request')
    def response_middleware_2(request, response) :
        foo = None
        return foo

    assert len(app._future_middleware) == 2

# Generated at 2022-06-24 04:09:07.786882
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic

    app = Sanic()

    @app.on_response
    def callback(request, response):
        pass

    assert isinstance(app._future_middleware, list)
    assert isinstance(app._future_middleware[0].middleware, type(callback))

# Generated at 2022-06-24 04:09:15.178670
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class test1:
        def on_response(self, request, response):
            pass
    class Test(MiddlewareMixin):
        def __init__(self):
            self.resp = None
        def _apply_middleware(self, middleware: FutureMiddleware):
            self.resp = middleware
    t = Test()
    res = t.on_response(test1().on_response)
    assert res == t.on_response(test1().on_response)
    assert t.resp.middleware == test1.on_response
    assert t.resp.attach_to == "response"


# Generated at 2022-06-24 04:09:19.256611
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.asgi import SanicASGIApp
    app = SanicASGIApp(None)
    app.on_response(None)
    app.on_response(int)


# Generated at 2022-06-24 04:09:28.314359
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic_pytest_parametrize import parametrize

    from test.data.middleware import (
        basic_middleware,
        middleware_async,
        middleware_both,
        middleware_both_async,
        middleware_exception,
        middleware_exception_async,
        middleware_none_async,
    )

    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware) -> None:
            pass


# Generated at 2022-06-24 04:09:29.733221
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []

# Generated at 2022-06-24 04:09:41.252529
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import asynctest
    from asynctest import CoroutineMock
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware

    app = Sanic()
    middleware1 = CoroutineMock()
    middleware2 = CoroutineMock()
    future_middleware1 = FutureMiddleware(middleware1, attach_to="request")
    future_middleware2 = FutureMiddleware(middleware2, attach_to="response")


# Generated at 2022-06-24 04:09:42.639834
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []

# Generated at 2022-06-24 04:09:45.468749
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    request = Request()
    middleware_request = MiddlewareMixin()
    assert isinstance(middleware_request.on_request, partial)


# Generated at 2022-06-24 04:09:54.168497
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    app = Sanic()
    assert app.request_middleware == []

    @app.middleware
    async def middleware_a(request):
        return HTTPResponse('Success')

    @app.middleware('request')
    async def middleware_b(request):
        return HTTPResponse('Success')

    @app.on_request
    async def middleware_c(request):
        return HTTPResponse('Success')

    @app.on_request()
    async def middleware_d(request):
        return HTTPResponse('Success')

    @app.on_request(attach_to='response')
    async def middleware_e(request):
        return HT

# Generated at 2022-06-24 04:09:59.975178
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.middleware import MiddlewareMixin

    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass
    
    test = TestMiddlewareMixin()
    assert test._future_middleware == []

    @test.middleware()
    def middelware(request):
        pass
    
    assert test._future_middleware != []
    assert test._future_middleware[0].middleware == middelware
    assert test._future_middleware[0].attach_to == "request"


# Generated at 2022-06-24 04:10:00.559014
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass

# Generated at 2022-06-24 04:10:01.889998
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []


# Generated at 2022-06-24 04:10:04.272822
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    app = MiddlewareMixin()
    assert app.on_response() == partial(app.middleware, attach_to="response")



# Generated at 2022-06-24 04:10:05.706478
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    assert mm._future_middleware is not None

# Generated at 2022-06-24 04:10:07.892204
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    def on_request(request):
        pass

    assert on_request is not None

# Generated at 2022-06-24 04:10:11.002912
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestClass(MiddlewareMixin):
        def __init__(self):
            super().__init__()
    assert TestClass()._future_middleware == []

# Generated at 2022-06-24 04:10:17.011336
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic(__name__)
    @app.middleware
    def handler(request):
        print(request)
    @app.on_response
    def handler(request, response):
        print(response)
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[1].attach_to == "response"


# Generated at 2022-06-24 04:10:18.819008
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin._future_middleware == []


# Generated at 2022-06-24 04:10:26.780955
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import unittest
    from sanic.blueprints import Blueprint
    from unittest.mock import MagicMock

    class App(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = App()
    @app.on_request
    def test_wrapped(request):
        return True
    @app.on_request()
    def test_nonwrapped(request):
        return True

    assert test_wrapped._middleware_attach_to == "request"
    assert test_nonwrapped._middleware_attach_to == "request"

    # Testing that register_middleware was called by
    # checking that it was registered
    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware is test_

# Generated at 2022-06-24 04:10:37.432612
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.response import HTTPResponse

    async def example_middleware(request):
        return HTTPResponse(text="Example middleware")


    app = Sanic()

    #test for @middleware
    @app.middleware
    async def middleware(request):
        return HTTPResponse(text="Example middleware")

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == "Example middleware"

    # test for @middleware('request')
    @app.middleware('request')
    async def middleware_request(request):
        return HT

# Generated at 2022-06-24 04:10:45.901156
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class FakeApplication_on_request(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(self, *args, **kwargs)
            self._future_middleware = []
            self._apply_middleware = lambda x: x

        def get(self, request):
            return request

    application = FakeApplication_on_request()
    @application.on_request()
    def request_middleware(request):
        request["from_middleware"] = "test_MiddlewareMixin_on_request"
        return request

    request = application.get(None)
    assert "from_middleware" in request


# Generated at 2022-06-24 04:10:48.729015
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    assert TestMiddlewareMixin()


# Generated at 2022-06-24 04:10:50.808461
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    test = MiddlewareMixin()

    def test_mw(request):
        return request

    assert middleware_mixin._apply_middleware( test_mw(None)) is None

# Generated at 2022-06-24 04:10:57.035138
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    def simple_middleware(request):
        pass

    app = Sanic('test_MiddlewareMixin_middleware')
    app.middleware(simple_middleware, attach_to="request")
    assert app._future_middleware[0].middleware == simple_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-24 04:10:57.990929
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []

# Generated at 2022-06-24 04:10:59.066572
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response

# Generated at 2022-06-24 04:11:07.542213
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Server:
        def __init__(self):
            self.middleware_registrations = []
        def middleware(self, middleware, attach_to=None):
            self.middleware_registrations.append("middleware")
            return middleware
        
    server = Server()
    mixin = MiddlewareMixin()
    mixin.middleware = server.middleware
    mixin.on_request(lambda request: request)
    assert len(server.middleware_registrations) == 1
    assert server.middleware_registrations[0] == "middleware"


# Generated at 2022-06-24 04:11:08.309547
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-24 04:11:11.144014
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    app = Sanic()
    app.middleware(None)
    app.on_response(None)
    app.on_request(None)
    assert app.middleware
    assert app.on_response
    assert app.on_request

# Generated at 2022-06-24 04:11:13.088228
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import sanic
    app = sanic.Sanic()
    assert app.on_request().func.__name__ == 'register_middleware'



# Generated at 2022-06-24 04:11:20.823585
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic()

    @app.on_request
    def on_request_middleware_handler(request):
        return request

    assert len(app._future_middleware) == 1
    assert isinstance(app._future_middleware, list)
    assert app._future_middleware[0].middleware is on_request_middleware_handler
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-24 04:11:23.194332
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    m = MiddlewareMixin()
    def middleware():
        return 'Hello'
    assert m.on_response(middleware) == 'Hello'

# Generated at 2022-06-24 04:11:29.034444
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Construct MiddlewareMixin object
    middleware_mixin = MiddlewareMixin()

    # Apply middleware_request
    request_1 = lambda request: 1
    middleware_mixin.middleware(request_1)

    # Apply middleware_response
    response_2 = lambda request, response: 2
    middleware_mixin.middleware(response_2)

    # Test apply request and response
    assert middleware_mixin._future_middleware[0].middleware(None) == 1
    assert middleware_mixin._future_middleware[1].middleware(
        None, None
    ) == 2


# Generated at 2022-06-24 04:11:37.011023
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()

    assert(len(test_middleware_mixin._future_middleware) == 0)

    test_middleware_mixin.on_request(lambda x: x)(lambda x: x)

    assert(len(test_middleware_mixin._future_middleware) == 1)
    assert(test_middleware_mixin._future_middleware[0]._attach_to == 'request')


# Generated at 2022-06-24 04:11:38.308455
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    m = MiddlewareMixin()
    m.on_response(lambda x: x)

# Generated at 2022-06-24 04:11:41.844946
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    a = MiddlewareMixin()
    assert a._future_middleware == []


# Generated at 2022-06-24 04:11:46.009714
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class A(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
    a = A()
    assert a._future_middleware == []

# Generated at 2022-06-24 04:11:55.682237
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import pytest
    from types import FunctionType
    from sanic import Sanic
    from pytest_mock import mocker
    
    

    app = Sanic("test_MiddlewareMixin_middleware")
    
    
    
    

    fun = lambda x: x**2
    app.middleware(fun)
    assert isinstance(app.middleware, FunctionType)
    assert isinstance(app._future_middleware[0], mocker.Mock)
    assert mocker.call(fun, "request") in app._future_middleware[0].mock_calls
    assert mocker.call(app._apply_middleware, app._future_middleware[0]) in app.mock_calls
    
    
    
    

    fun = lambda x: x**2

# Generated at 2022-06-24 04:11:59.666147
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Example(MiddlewareMixin):
        pass

    ex = Example()
    assert isinstance(ex, MiddlewareMixin)
    assert ex._future_middleware == []


# Generated at 2022-06-24 04:12:08.680293
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse, text
    from sanic.models.futures import FutureMiddleware

    app = Sanic(__name__)

    @app.middleware('response')
    async def hello_after(request, response):
        response.text = "Hello after {}!".format(response.text)
        return response

    @app.get('/')
    async def handler(request):
        return text('Hello world!')

    async def fetch_call(method, url):
        req, res = await app.http.request(method, url, version=1.1)
        return req, res


# Generated at 2022-06-24 04:12:12.695704
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    print("Testing on_request")
    test_obj = MiddlewareMixin()
    future_middleware = test_obj.on_request(middleware=None)
    assert callable(future_middleware)

    future_middleware = test_obj.on_request(middleware=test_MiddlewareMixin)
    assert callable(future_middleware)


# Generated at 2022-06-24 04:12:13.841151
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    MiddlewareMixin()

# Generated at 2022-06-24 04:12:21.104088
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()

    def test_middleware(request):
        if request.app.route == 'test':
            print('middleware for test')
        else:
            print('middleware for other route')

    app.middleware(test_middleware)

    app_middleware = app._future_middleware
    assert app_middleware[0].middleware == test_middleware
    assert app_middleware[0].attach_to == 'request'


# Generated at 2022-06-24 04:12:22.061424
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert MiddlewareMixin().middleware is not None

# Generated at 2022-06-24 04:12:24.365366
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class A(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)



# Generated at 2022-06-24 04:12:25.595939
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    _instance = MiddlewareMixin()
    assert _instance  # should not raise an exception

# Generated at 2022-06-24 04:12:31.427588
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Create a dummy class.
    class Dummy(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    # Parameter middleware_or_request is a callable, and attach_to is request.
    dummy = Dummy()
    @middleware(attach_to = 'request')
    def t0():
        pass
    dummy.middleware(t0)
    assert len(dummy._future_middleware) == 1
    assert dummy._future_middleware[0].attach_to == 'request'
    assert dummy._future_middleware[0].middleware == t0
    # Parameter middleware_or_request is a callable, and attach_to is response.
    dummy = Dummy()

# Generated at 2022-06-24 04:12:33.287400
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewareMixin = MiddlewareMixin()
    assert middlewareMixin._future_middleware


# Generated at 2022-06-24 04:12:39.166070
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    async def f(request):
        return request

    class sanic_app:
        def __init__(self):
            self._future_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError

    app = sanic_app()
    func = app.on_request(f)
    assert func == f

# Generated at 2022-06-24 04:12:46.477430
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.testing import SanicTestClient
    from sanic import Sanic
    import pytest

    app=Sanic(__name__)

    @app.route('/asd', methods={'GET','POST','DELETE','PUR','PUT','PATCH','HEAD','OPTIONS','TRACE','CONNECT'})
    def asd(request):
        return request.json

    @app.on_response
    def response(request, response):
        response.text = 'response'

    client = SanicTestClient(app, port=8003)

    result = client.get('/a')
    assert result.status==200
    assert result.text=='response'


# Generated at 2022-06-24 04:12:48.444884
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    @MiddlewareMixin.middleware()
    async def method(request):
        ...



# Generated at 2022-06-24 04:12:49.937283
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []

# Generated at 2022-06-24 04:12:52.428225
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    x = MiddlewareMixin()
    app = Flask(__name__)
    app.on_response(middleware = x)

# Generated at 2022-06-24 04:13:03.116257
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    async def async_middleware(request):
        return request

    def middleware(request):
        return request

    # Test if all parse correctly and attach to right middleware list
    app = Sanic(__name__)


    # Test async wrapped middleware
    @app.middleware
    async def async_wrapped_middleware(request):
        assert type(request) is Request
        return request

    # Test async middleware
    app.register_middleware(async_middleware, attach_to="request")
    app.register_middleware(async_middleware, attach_to="response")

    # Test sync wrapped middleware

# Generated at 2022-06-24 04:13:09.141934
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic("SanicFormation")

    def request_middleware(request):
        return request

    def response_middleware(request, response):
        return response

    app.middleware(request_middleware)
    app.middleware(response_middleware, attach_to='response')
    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[1].middleware == response_middleware
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].attach_to == 'response'


# Generated at 2022-06-24 04:13:15.727343
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():

    test_app = Sanic('test_app')

    @test_app.middleware('response')
    async def test_middleware(request, response):
        print('request: ', request)
        print('response: ', response)
        return response



if __name__ == '__main__':
    test_MiddlewareMixin_on_response()

# Generated at 2022-06-24 04:13:21.706875
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin._future_middleware == []
    response = middleware_mixin.middleware('request', 'response')
    assert isinstance(response, partial)
    response = response()
    assert response is None
    assert middleware_mixin._future_middleware[0].middleware == 'request'
    assert middleware_mixin._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-24 04:13:27.648573
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class FakeService(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    fakeService = FakeService()
    middleware = "middleware"
    assert fakeService.on_request(middleware) == fakeService.middleware(
        middleware, "request"
    )
    assert fakeService.on_request() == partial(
        fakeService.middleware, attach_to="request"
    )


# Generated at 2022-06-24 04:13:29.616325
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert hasattr(MiddlewareMixin, "__init__")
    assert callable(MiddlewareMixin.__init__)


# Generated at 2022-06-24 04:13:31.125378
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin._future_middleware == []

# Generated at 2022-06-24 04:13:38.121312
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.models.middlewares import MiddlewareMixin
    from sanic.models.futures import FutureMiddleware

    class TestMiddleware(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            return None

 
    # Test no middleware
    test_app = TestMiddleware()
    assert len(test_app._future_middleware) == 0

    # Test with middleware
    def test_middleware(request):
        return None

    test_app = TestMiddleware()
    test_app.on_request(test_middleware())
    assert len(test_app._future_middleware) == 1
    middleware = test_app._future_middleware[0]
    assert middleware.middleware == test_middleware


# Generated at 2022-06-24 04:13:42.582425
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class MyClass(MiddlewareMixin):
        def _apply_middleware(self, _):
            pass
    middleware1 = MyClass()
    @middleware1.on_response()
    def call_middleware():
        pass
    assert middleware1._future_middleware[0].attach_to == "response"

# Generated at 2022-06-24 04:13:47.946340
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Test:
        def __init__(self):
            self._future_middleware = []
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    mixin = MiddlewareMixin()
    t = Test()
    t.on_response = mixin.on_response
    t.on_response = mixin.on_response()

# Generated at 2022-06-24 04:13:52.280574
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class app(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    a = app()
    print(a)

if __name__ == "__main__":
    test_MiddlewareMixin()

# Generated at 2022-06-24 04:13:53.733243
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    app = Sanic()
    assert isinstance(app, MiddlewareMixin)

# Generated at 2022-06-24 04:13:59.219458
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    middleware_mixin = TestMiddlewareMixin()
    assert not middleware_mixin._future_middleware


# Generated at 2022-06-24 04:14:05.446288
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from unittest.mock import patch
    from sanic.server import HttpProtocol, HttpRequestParser
    from sanic.blueprints import Blueprint
    from sanic.request import Request

    request = Request("GET", "/")
    request.app = MiddlewareMixin()
    with patch.object(HttpProtocol, "__init__") as mock_init:
        mock_init.return_value = None
        HttpProtocol(request)
        mock_init.assert_called_with(request)
        assert request.app._future_middleware == []


# Generated at 2022-06-24 04:14:16.158817
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    from sanic.views import HTTPMethodView
    from sanic.response import json

    app = Sanic()
    app.config.LOAD_MODEL = True

    @app.middleware('request')
    async def model_middleware(request):
        print('>>> Model middleware')

    # model_middleware()  # Error: MiddlewareMixin() missing 1 required positional argument: 'self'

    @app.middleware('request')
    async def request_middleware(request):
        print('>>> Request middleware')

    @app.middleware('response')
    async def response_middleware(request, response):
        print('>>> Response middleware')

    @app.route('/')
    async def index(request):
        return json({'hello': 'world'})


# Generated at 2022-06-24 04:14:18.569766
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert callable(MiddlewareMixin.on_request(MiddlewareMixin))


# Generated at 2022-06-24 04:14:29.138592
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    assert m.on_request(middleware=None)() == m.middleware(
        middleware_or_request=None, attach_to="request"
    )
    assert m.on_request(middleware=2)(2) == m.middleware(
        middleware_or_request=2, attach_to="request"
    )
    assert m.on_request(middleware=False)(
        False
    ) == m.middleware(middleware_or_request=False, attach_to="request")
    assert m.on_request(middleware=True)(True) == m.middleware(
        middleware_or_request=True, attach_to="request"
    )

# Generated at 2022-06-24 04:14:30.313031
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Test:
        __init__ = MiddlewareMixin.__init__
        on_request = MiddlewareMixin.on_request
    Test()

# Generated at 2022-06-24 04:14:36.419752
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test:
        def __init__(self):
            super().__init__()
            self._future_middleware = []
        
        def _apply_middleware(self, middleware):
            return

    m = Test()
    m.middleware(lambda x: x)
    assert m._future_middleware[0].name() == "lambda"


# Generated at 2022-06-24 04:14:40.366086
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic(__name__)

    @app.on_request
    def request(request):
        pass

    assert(app._request_middleware[0].handle == request)


# Generated at 2022-06-24 04:14:47.723716
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.request import Request
    import functools
    import time
    import socket
    import sys
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    if str(sys.version[0]) == '2':
        try:
            from urllib.parse import urlparse
        except ImportError:
            from urlparse import urlparse
    else:
        from urllib.parse import urlparse
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    app = Sanic("test_MiddlewareMixin_on_request")
    
    
    
    
    

# Generated at 2022-06-24 04:14:56.828244
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class SomeMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            MiddlewareMixin.__init__(self, *args, **kwargs)

        def _apply_middleware(self, middleware):
            pass

    @SomeMiddlewareMixin.middleware
    def foo_middleware(request):
        pass

    @SomeMiddlewareMixin.on_request
    def foo_request_middleware(request):
        pass

    @SomeMiddlewareMixin.on_response
    def foo_response_middleware(request, response):
        pass



# Generated at 2022-06-24 04:14:57.982492
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []

# Generated at 2022-06-24 04:15:02.500833
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareInstance(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
                pass
    middleware_mixin = MiddlewareInstance()
    def test_middleware(request):
        pass
    assert callable(middleware_mixin.middleware(test_middleware))


# Generated at 2022-06-24 04:15:04.960845
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware = MiddlewareMixin()

    import asyncio
    @middleware.on_response
    async def handler(request):
        return request

    assert handler



# Generated at 2022-06-24 04:15:07.479843
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """Unit test for method middleware"""
    # TODO: Use a Mockup of class MiddlewareMixin and an instance of it
    # to test if the method middleware works like expected
    pass

# Generated at 2022-06-24 04:15:13.264338
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = MiddlewareMixin()

    # The following call has no effect, since the middleware hasn't been
    # applied.
    app.middleware(lambda request: request, attach_to="request", apply=False)
    assert len(app._future_middleware) == 1

    assert isinstance(app.middleware, partial)

    # The following call has no effect, since the middleware hasn't been
    # applied.
    app.middleware(lambda request: request, attach_to="response", apply=False)
    assert len(app._future_middleware) == 2

    assert isinstance(app.middleware, partial)

    # The following call has no effect, since the middleware hasn't been
    # applied.
    app.middleware(lambda request: request, attach_to="request", apply=False)

# Generated at 2022-06-24 04:15:21.556582
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class FakeMiddleware1:
        def __init__(self,request):
            self.request = request
    
    class FakeMiddleware2:
        def __init__(self,request):
            self.request = request
    
    class FakeMiddleware3:
        def __init__(self,request):
            self.request = request

    class FakeApp(MiddlewareMixin):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)

        def _apply_middleware(self, middleware):
            self._future_middleware.append(middleware)

    # Test case 1
    fake_app = FakeApp()
    fake_app.on_request(fake_app)

# Generated at 2022-06-24 04:15:25.471675
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    def test_middleware_function(request):
        return request
    app.middleware(test_middleware_function)
    #assert app._future_middleware[0].middleware == test_middleware_function
    assert isinstance(app._future_middleware[0], FutureMiddleware)


# Generated at 2022-06-24 04:15:32.022340
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic(__name__)
    obj = MiddlewareMixin(app)
    @obj.on_request()
    def test(request):
        pass
    assert len(obj._future_middleware) == 1
    assert obj._future_middleware[0].attach_to == "request"


# Generated at 2022-06-24 04:15:32.820667
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert True

# Generated at 2022-06-24 04:15:34.280565
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
  a = MiddlewareMixin()
  assert a


# Generated at 2022-06-24 04:15:43.937763
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # args = argv[1:]
    # print(f"choose {args[0]}")
    # if args[0] == "on_request":
    #     MiddlewareMixin.on_request(lambda x: x)
    # elif args[0] == "on_response":
    #     MiddlewareMixin.on_response(lambda x: x)
    # else:
    #     raise Exception(f"{args[0]} not supported")
    MiddlewareMixin.on_response(lambda x: x)
    pass


test_MiddlewareMixin_on_response()

# Generated at 2022-06-24 04:15:47.210232
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class FakeMiddlewareMixin(MiddlewareMixin):
        pass

    mixin = FakeMiddlewareMixin()
    print(mixin._future_middleware)
    assert mixin._future_middleware == []


# Generated at 2022-06-24 04:15:50.908921
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic(__name__)  # type: ignore

    @app.middleware('response')
    async def process_response(request, response):
        pass

    assert isinstance(app._future_middleware[0], FutureMiddleware)

# Generated at 2022-06-24 04:15:55.337502
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class test_class(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            MiddlewareMixin.__init__(self, *args, **kwargs)

    test_class_instance = test_class()
    test_class_instance.middleware(lambda x: x)(5)
    test_class_instance.on_request(lambda x: x)(5)
    return True
