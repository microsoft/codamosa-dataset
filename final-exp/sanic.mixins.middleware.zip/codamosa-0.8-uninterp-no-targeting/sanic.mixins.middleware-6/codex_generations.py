

# Generated at 2022-06-21 23:09:27.129731
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args,**kwargs)
            print("TestMiddlewareMixin is here")
            #self._future_middleware: List[FutureMiddleware] = []

    test = TestMiddlewareMixin()
    print(test._future_middleware)



# Generated at 2022-06-21 23:09:28.807477
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    a = MiddlewareMixin()
    assert a._future_middleware == []


# Generated at 2022-06-21 23:09:32.367040
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    base = MiddlewareMixin()
    assert base._future_middleware == []


# Generated at 2022-06-21 23:09:38.978400
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_middleware')
    # Test can be only done with function :
    # @app.middleware
    @app.middleware('request')
    async def test_middleware(request):
        return True
    assert test_middleware(None) == True

# Generated at 2022-06-21 23:09:47.127518
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestClass:
        def _apply_middleware(self, middleware: FutureMiddleware):
            return
        def __init__(self, *args, **kwargs):
            self._future_middleware = []
    testclass = TestClass()
    testclass.middleware(None, "test_on_response", False)
    testclass.middleware(None, "test_on_request", False)


# Generated at 2022-06-21 23:10:00.857593
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.log import logger
    from sanic.exceptions import ServerError
    from sanic.exceptions import SanicException
    from sanic.server import HttpProtocol
    from sanic.views import CompositionView
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    class Middleware(MiddlewareMixin):
        async def __call__(
        self, request, handler, *args, **kwargs
        ):
            request["middleware_called"] = True
            return await handler(request, *args, **kwargs)


# Generated at 2022-06-21 23:10:10.241749
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.server import serve
    app = Sanic("test_MiddlewareMixin_on_request")
    @app.route("/middleware")
    async def handler(request):
        return text("I'm middleware")
    @app.on_request
    def request_handler(request):
        pass
    _, test_client = serve(app)
    request, response = test_client.get(
        "/middleware", headers={"Host": "127.0.0.1"}
    )
    assert response.status == 200
    assert response.text == "I'm middleware"


# Generated at 2022-06-21 23:10:13.907829
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    sanic=Sanic('test_sanic')
    component=MiddlewareMixin()
    component.on_request(sanic)
    

# Generated at 2022-06-21 23:10:17.672959
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic(__name__)
    app.middleware
    assert callable(app.middleware)
    # test for method on_request
    app.on_request
    assert callable(app.on_request)
    # test for method on_response
    app.on_response
    assert callable(app.on_response)

# Generated at 2022-06-21 23:10:20.202272
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            pass

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    @TestMiddlewareMixin().on_response()
    def f():
        pass

    assert callable(f)

# Generated at 2022-06-21 23:10:34.710142
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    app = Sanic(__name__)
    async def handler(request):
        return HTTPResponse("OK")
    async def middleware1(request):
        return await handler(request)
    async def middleware2(request):
        return await middleware1(request)

    @app.middleware("request")
    async def request_middleware(request: Request):
        """Middleware1."""
        return await middleware2(request)

    @app.middleware("response")
    async def response_middleware(request: Request, response: HTTPResponse):
        """Middleware2."""
        return response


# Generated at 2022-06-21 23:10:37.146179
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewareMixin = MiddlewareMixin()
    assert middlewareMixin._future_middleware == []

# Generated at 2022-06-21 23:10:45.283542
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.response import text

    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            print("_apply_middleware")
            self.middleware_check_enable = True

    # test for method on_request
    async def test_on_request():
        app = Sanic("test_MiddlewareMixin_middleware")
        assert len(app._future_middleware) == 0

        @app.on_request
        def test_on_request_001(request):
            print("test_on_request_001")
            assert app.middleware_check_enable
            r = json({"test": "test_on_request_001"})
            return r

        request, response

# Generated at 2022-06-21 23:10:49.557495
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddlewareMixin_test(MiddlewareMixin):
        def _apply_middleware(self, future_middleware):
            pass

    tmp = MiddlewareMixin_test()
    assert tmp._future_middleware==[]

# Generated at 2022-06-21 23:11:01.777555
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.response import json

    app = Sanic("MiddlewareMixin_on_response")
    bp = Blueprint("bp", url_prefix="/bp")

    @app.on_response
    def bp_on_response(request, response):
        response.headers["X-On-Response"] = "1"

    @bp.on_response
    def bp_on_response(request, response):
        response.headers["X-On-Response-BP"] = "1"

    @app.post("/")
    async def handler(request):
        return json({"test": 1})

    request, response = app.test_client.post(
        "/", data=app.json_dumps({"test": 1})
    )

# Generated at 2022-06-21 23:11:02.760982
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert True

# Generated at 2022-06-21 23:11:05.296131
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    assert mm._future_middleware == []


# Generated at 2022-06-21 23:11:08.026408
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin._future_middleware == []



# Generated at 2022-06-21 23:11:14.564734
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    try:
        from sanic.app import Sanic
        from sanic.websocket import WebSocketProtocol
        from sanic.server import HttpProtocol
        from sanic.response import BaseHTTPResponse
        from sanic.views import HTTPMethodView
        from sanic.blueprints import Blueprint
        from sanic.request import Request
        from sanic.exceptions import SanicException
    except ImportError:
        print("[Error] Can't find Sanic")
        return
    print("[Testing] MiddlewareMixin")

    app = Sanic()

    middleware = MiddlewareMixin()

    if middleware._future_middleware != []:
        print("[Error] MiddlewareMixin Init Error")


# Generated at 2022-06-21 23:11:19.585179
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic()

    @app.middleware
    async def test_middleware(request):
        pass

    assert len(app.middleware_stack) == 1


# Generated at 2022-06-21 23:11:31.261179
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.server import HttpProtocol, WebSocketProtocol
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')
    app.list_middleware = []


    class TestHttpProtocol(HttpProtocol):
        def __init__(self):
            pass

    TestHttpProtocol.request_middleware = app.middleware
    TestHttpProtocol.response_middleware = app.middleware

    @app.middleware('request')
    async def print_on_request(request):
        pass

    @app.middleware('response')
    async def print_on_response(request, response):
        pass

    assert len(app.list_middleware) == 2
    assert app.list_middleware[0].middleware == print_on_request

# Generated at 2022-06-21 23:11:39.454253
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    class DummyMiddleware():
        pass
    dummy_middleware = DummyMiddleware()
    assert len(Sanic._future_middleware) == 0
    app = Sanic()
    app.middleware(dummy_middleware, attach_to="request", apply=False)
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == dummy_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-21 23:11:51.062164
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.router import Router
    from sanic.views import HTTPMethodView

    def middleware(request):
        pass

    def attach_to(request):
        pass

    def apply(request):
        pass

    app = Sanic(__name__)
    app.config.REQUEST_MAX_SIZE = 10 << 20
    blueprint = Blueprint("name", url_prefix="/prefix")
    http_method_view = HTTPMethodView()
    router = Router()

    assert app.middleware(middleware)
    assert blueprint.middleware(middleware)
    assert http_method_view.middleware(middleware)
    assert router.middleware(middleware)


# Generated at 2022-06-21 23:12:01.148387
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from .test_object import test_object
    from .test_object import test_middleware2
    from .test_object import test_middleware3
    from .test_object import test_middleware4
    from .test_object import test_middleware5
    from .test_object import test_middleware6
    from .test_object import test_middleware7
    from .test_object import test_middleware8

    assert test_object.middleware(
        test_middleware2
    ).__self__._future_middleware[0].middleware == test_middleware2
    assert test_object.middleware(test_middleware2, "request").__self__._future_middleware[
        0
    ].middleware == test_middleware2

# Generated at 2022-06-21 23:12:10.724191
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    new_REQUEST_TIMEOUT = 100
    new_RESPONSE_TIMEOUT = 101
    new_KEEP_ALIVE = False
    new_REQUEST_MAX_SIZE = 102
    new_RESPONSE_MAX_SIZE = 103
    new_REQUEST_BUFFER_QUEUE_SIZE = 104
    new_RESPONSE_BUFFER_QUEUE_SIZE = 105
    new_REQUEST_TIMEOUT = 106
    new_ROOT_PATH = "/"
    new_URL_PREFIX = "/"
    new_DEBUG = False
    new_ERROR_HANDLER = None
    new_EXCEPTION_HANDLER = None
    new_REQUEST_HANDLER = None
    new_RESPONSE_HANDLER = None
    new_NOT_FOUND_HANDLER

# Generated at 2022-06-21 23:12:14.306147
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from application import Application
    app = Application(name="my_app")
    app.on_request(lambda request: request)
    results = app._future_middleware[0].middleware(
        {"request_key": "request_value"}
    )
    assert "request_key" in results

# Generated at 2022-06-21 23:12:21.067631
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    """
    This is a testing unit for the on_request method of the MiddlewareMixin class. 
    """
    print("\n\n === Testing MiddlewareMixin.on_request === \n")

    # create an instance of the MiddlewareMixin class
    middlewareMixin = MiddlewareMixin()

    # get the on_request partial object
    on_request = middlewareMixin.on_request()

    # create a function and decorate it as a @middleware('request')
    @on_request
    def myMiddleware(request):
        print("myMiddleware() is being called...")
        return None

    # call the function myMiddleware and list the middleware 
    myMiddleware(None)
    print(middlewareMixin._future_middleware)    


# Generated at 2022-06-21 23:12:22.401096
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response(MiddlewareMixin, 'response')

# Generated at 2022-06-21 23:12:22.993831
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert 1 == 1

# Generated at 2022-06-21 23:12:27.254920
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class A:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
    a = A()
    middleware = None
    assert a.on_response(middleware) == partial(a.middleware, attach_to="response")

# Generated at 2022-06-21 23:12:35.842577
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Test(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    assert Test()._future_middleware == []


# Generated at 2022-06-21 23:12:47.545676
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic    # noqa
    from sanic.response import json # noqa

    def filter_request(request):
        return json({
            "status": "OK",
            "status_code": "200",
            "request_id": request.context.request_id
        })

    app = Sanic()

    @app.middleware('request')
    async def request_id(request):
        request.context.request_id = 1

    @app.on_request
    def on_request(request):
        return filter_request(request)

    request, response = app.test_client.get('/')
    assert response.json == {
        "status": "OK",
        "status_code": "200",
        "request_id": 1
    }


# Generated at 2022-06-21 23:12:54.023561
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    try:
        class test(MiddlewareMixin):
            def __init__(self, *args, **kwargs) -> None:
                super(test, self).__init__(*args, **kwargs)

            def _apply_middleware(self, middleware: FutureMiddleware):
                raise NotImplementedError  # noqa
        app = test()
        app.on_request(middleware=None)
    except Exception as exc:
        print(exc.__class__.__name__)
        assert False
    else:
        assert True


# Generated at 2022-06-21 23:12:56.093451
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    a = MiddlewareMixin()
    assert a._future_middleware == []


# Generated at 2022-06-21 23:12:57.425285
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    try:
        MiddlewareMixin()
    except Exception as e:
        raise e

# Generated at 2022-06-21 23:12:59.349349
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert (
        MiddlewareMixin.on_response().__name__
        == "register_middleware"
    )
    
    

# Generated at 2022-06-21 23:13:00.669473
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin is not None

# Generated at 2022-06-21 23:13:02.757427
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Cls(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
    assert Cls()._future_middleware == []

# Generated at 2022-06-21 23:13:03.447856
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert True

# Generated at 2022-06-21 23:13:12.870146
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text
    from sanic.testing import SanicTestClient
    from sanic.exceptions import NotFound

    sanic_app = Sanic('test_middleware')

    @sanic_app.on_response
    def on_response(request, response):
        response.headers["middleware"] = "testing"
        return response

    @sanic_app.route('/')
    async def handler(request):
        return text('OK')

    request, response = SanicTestClient(sanic_app).get('/')
    assert response.status == 200
    assert response.json["middleware"] == "testing"

    @sanic_app.on_response('request')
    def on_request(request):
        request.headers["middleware"] = "testing"


# Generated at 2022-06-21 23:13:23.882646
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class App(MiddlewareMixin):
        pass

    app = App

    assert app._future_middleware == []

# Generated at 2022-06-21 23:13:25.556633
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    def middleware(): pass
    r = MiddlewareMixin()
    r.on_response(middleware)
    assert r._future_middleware
    assert r._future_middleware[0]._middleware is middleware
    assert r._future_middleware[0]._attach_to == "response"


# Generated at 2022-06-21 23:13:28.087993
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []




# Generated at 2022-06-21 23:13:35.153623
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test(MiddlewareMixin):
        def on_request(self):
            pass
        def on_response(self):
            pass
        def _apply_middleware(self):
            pass

    test = Test()
    test.middleware(attach_to='request')
    test.on_request()
    test.on_response()

# Generated at 2022-06-21 23:13:45.345480
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # TypeDefs
    from sanic.types import RequestParameters
    from sanic.request import Request

    # Globals
    _middleware_instance = MiddlewareMixin()
    
    # Locals
    middleware = lambda _: None
    request = Request('GET', '/', {}, {'key': 'value'}, None, None, None, None,
            False, None)

    # Execute
    @_middleware_instance.middleware
    async def _middleware_func(request):
        pass

    # Verify
    assert len(_middleware_instance._future_middleware) == 1
    assert _middleware_instance._future_middleware[0].middleware == middleware    
    
    # Execute
    @_middleware_instance.on_request
    async def _request_func(request):
        pass

# Generated at 2022-06-21 23:13:46.198889
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

# Generated at 2022-06-21 23:13:46.637047
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-21 23:13:52.331683
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class MockMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware):
            MiddlewareMixin._apply_middleware(self, middleware)

    #Test for callable middleware
    result = MiddlewareMixin()
    result.on_response(0)
    assert result._future_middleware[0].at == "response"

    #Test for a normal function
    assert result.on_response()(0).at == "response"

# Generated at 2022-06-21 23:14:03.050663
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Test the function middleware of class MiddlewareMixin
    class Test_Middleware_Mixin(MiddlewareMixin):
        # Test class for method middleware of class MiddlewareMixin
        def _apply_middleware(self, middleware):
            print(middleware)

    @Test_Middleware_Mixin.middleware
    def middleware1():
        print('Middleware 1')

    @Test_Middleware_Mixin.middleware('response')
    def middleware2():
        print('Middleware 2')

    @Test_Middleware_Mixin.on_request
    def middleware3():
        print('Middleware 3')

    @Test_Middleware_Mixin.on_response
    def middleware4():
        print('Middleware 4')

    Test_Middleware_Mixin.middleware(middleware1)

# Generated at 2022-06-21 23:14:03.605734
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert(True)


# Generated at 2022-06-21 23:14:32.765344
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    import asyncio
    from types import coroutine

    # class Coroutine:
    #     def __await__(self):
    #         yield 42

    # # @asyncio.coroutine
    # def coroutine(result):
    #     yield result

    # @asyncio.coroutine
    # def return_after_hello_world(request):
    #     yield 'hello world'
    #     return request

    @asyncio.coroutine
    def get_name(request):
        return request
    get_name.name = 'get_name'

    app = Sanic('test_MiddlewareMixin')


# Generated at 2022-06-21 23:14:42.873670
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.handlers import RequestHandler
    from sanic.views import HTTPMethodView

    app = Sanic()
    # middleware is a method of Sanic
    assert hasattr(app, 'middleware')
    # This is an assignment with typehint
    middleware_func: (lambda:None) = app.middleware
    middleware_func('response', lambda request_handler, request, response: None)
    # _future_middleware is a field of Sanic
    assert hasattr(app, '_future_middleware')
    # _future_middleware is a list
    assert isinstance(app._future_middleware, list)
    # _middleware is a method of Sanic
    assert hasattr(app, '_apply_middleware')
    # _middle

# Generated at 2022-06-21 23:14:44.549128
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic

    app = Sanic()
    assert isinstance(app._future_middleware, list)
    assert len(app._future_middleware) == 0


# Generated at 2022-06-21 23:14:46.407784
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    obj = MiddlewareMixin()
    assert obj._future_middleware == []

# Generated at 2022-06-21 23:14:50.572208
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class MiddlewareMixin1(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(MiddlewareMixin1, self).__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    MM1 = MiddlewareMixin1()
    MM1.on_response()


# Generated at 2022-06-21 23:14:53.161782
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    mi = MiddlewareMixin()
    assert mi.on_response().keywords == {'attach_to': 'response'}

# Generated at 2022-06-21 23:14:58.790405
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    backend = MagicMock()
    app = MagicMock(spec=MiddlewareMixin)
    app.on_request = MagicMock()
    app.middleware.__wrapped__(backend)(app)
    app.on_request.assert_called_once()

    backend.assert_called_once()
    backend.assert_called_once_with(app)

# Generated at 2022-06-21 23:15:09.590230
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    # Unit test for method middleware of class Sanic
    """Tests if the correct arguments to the middleware
     decorator function are received correctly.

    Arguments:
    middleware_or_request (function): attach_to value.
    attach_to (str): decorator function.
    apply (bool): Decorator flag.

    """
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.middleware('request')
    async def request_method(request):  # type: ignore
        return text('hello')

    @app.middleware('response')
    async def response_method(request, response):  # type: ignore
        return text('hello')


# Generated at 2022-06-21 23:15:13.894343
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware is not None
    assert m.middleware is not None
    assert m.on_request is not None
    assert m.on_response is not None

# Generated at 2022-06-21 23:15:21.727712
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware
    import asyncio
    async def test_middleware_request(request):
        # request.app is a Sanic instance
        assert isinstance(request.app, Sanic)
        # request is a Request instance
        assert isinstance(request, Request)
        return text("OK")

    async def test_middleware_request2(request):
        assert isinstance(request.app, Sanic)
        assert isinstance(request, Request)
        return text("OK")

    app = Sanic("test_middleware")
    app.add_route(test_middleware_request, "/test1")
    app.add_route(test_middleware_request2, "/test2")

    app.middleware

# Generated at 2022-06-21 23:16:06.202059
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json

    app = Sanic("MiddlewareMixin")

    @app.middleware('request')
    async def print_on_request(request):
        print("I run on request")

    @app.middleware('response')
    async def print_on_response(request, response):
        print("I run on response")

    @app.route("/")
    async def test(request):
        return json({"hello": "world"})

    app.run(debug=True, host='127.0.0.1', port=8000)

# Generated at 2022-06-21 23:16:16.493473
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass


    @TestMiddlewareMixin.middleware
    async def my_middleware_in_outer():
        pass

    tmm = TestMiddlewareMixin()
    assert len(tmm._future_middleware) == 1
    assert tmm._future_middleware[0].middleware == my_middleware_in_outer

    tmm = TestMiddlewareMixin()
    @tmm.middleware
    async def my_middleware_in_inner():
        pass

    assert len(tmm._future_middleware) == 1
    assert tmm._future_middleware[0].middleware == my_middleware_in_inner

# Generated at 2022-06-21 23:16:22.591773
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic('test')

    async def handler(request):
        return text('OK')

    app.add_route(handler, '/')

    async def on_request(request):
        return

    async def on_response(request, response):
        return

    app.on_request(on_request)
    app.on_response(on_response)

    _, response = app.test_client.get('/')
    assert response.status == 200

# Generated at 2022-06-21 23:16:27.080617
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic('test_MiddlewareMixin_on_response')
    data = {'key': 'value'}
    @app.on_response
    def process(request, response):
        assert json(data) == response
        assert request == 'request'

    # Run on_response
    response = app.on_request('request')(json(data))

    # Check on_response
    assert json(data) == response
    assert request == 'request'

# Generated at 2022-06-21 23:16:31.587910
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():    
    class TestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.test = 0
            
    test = TestClass()
    assert test.test == 0

# Generated at 2022-06-21 23:16:34.966329
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class A(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    a = A()
    assert a._future_middleware == []

# Generated at 2022-06-21 23:16:37.397193
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    test = MiddlewareMixin()
    assert isinstance(test, MiddlewareMixin)
    assert isinstance(test._future_middleware, list)



# Generated at 2022-06-21 23:16:44.975482
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    from unittest import mock
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware

    app = Sanic()

    middleware_1 = mock.MagicMock(return_value=lambda *args, **kwargs: None)
    middleware_2 = mock.MagicMock(return_value=lambda *args, **kwargs: None)

    request_1 = FutureMiddleware(middleware_1, "request")
    request_2 = FutureMiddleware(middleware_2, "request")

    response_1 = FutureMiddleware(middleware_1, "response")
    response_2 = FutureMiddleware(middleware_2, "response")

    # Test: no apply
    app.middleware(middleware_1)
    assert app._future_middleware == [request_1]
   

# Generated at 2022-06-21 23:16:47.565909
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m = MiddlewareMixin()
    assert m.middleware(middleware_or_request = "test")(middleware= "test") == "test"

# Generated at 2022-06-21 23:16:52.030514
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    app = Sanic()
    app.on_request(func_a)

    # tests
    assert app._future_middleware[0].middleware == func_a
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].middleware_name == func_a.__name__


# Generated at 2022-06-21 23:18:04.049884
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic()

    @app.on_response()
    async def print_response(request, response):
        print(request)
        print(response)

    # Check response
    assert print_response(1, 2) == None



# Generated at 2022-06-21 23:18:12.635076
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class MiddlewareMixin_test:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
    test = MiddlewareMixin_test()
    @test.on_response
    def middleware(request):
        print(request)

    assert test._future_middleware[0].attach_to == 'response'
    
    
    


# Generated at 2022-06-21 23:18:16.356774
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddleware(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass
    test = TestMiddleware()

    assert test._future_middleware == []

# Generated at 2022-06-21 23:18:25.151506
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    mixin = MiddlewareMixin
    middleware_or_request=None
    attach_to = 'response'
    apply = True
    mixin.middleware = mock.Mock()
    mixin.on_response(middleware_or_request)

    mixin.middleware.assert_called_with(partial(mixin.middleware, attach_to='response'),attach_to=attach_to)
    # assert (mixin.middleware.attach_to==attach_to)
    # assert(mixin.middleware.apply==apply)


# Generated at 2022-06-21 23:18:30.510289
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    print("\n=====Test on_request of class MiddlewareMixin=====")
    # Test on_request
    assert isinstance(MiddlewareMixin().on_request(), partial)


# Generated at 2022-06-21 23:18:34.907534
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.models.futures import FutureMiddleware

    class TestMiddlewareMixin():
        def __init__(self):
            self._future_middleware = []

    test_middleware_mixin = TestMiddlewareMixin()

    test_middleware_mixin._future_middleware = []
    test_middleware_mixin._apply_middleware = False

# Generated at 2022-06-21 23:18:40.731741
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.futures import FutureMiddleware
    from sanic.server import HttpProtocol

    @MiddlewareMixin.on_request()
    def middleware(request):
        '''middleware for request'''
        print('middleware for request')

    assert isinstance(MiddlewareMixin.middleware, partial)
    _future_middleware = MiddlewareMixin._future_middleware
    assert isinstance(_future_middleware[0], FutureMiddleware)
    assert _future_middleware[0].middleware == middleware
    assert _future_middleware[0].attach_to == 'request'
    assert MiddlewareMixin._apply_middleware == HttpProtocol.apply_middleware
    assert MiddlewareMixin.on_request == MiddlewareMixin.middleware


# Generated at 2022-06-21 23:18:47.153780
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    from sanic.request import Request

    app = TestMiddlewareMixin()

    @app.middleware
    async def test(request: Request):
        return request

    @app.middleware('response')
    async def test2(request: Request, response):
        return response

    @app.on_request
    async def test3(request: Request):
        return request

    @app.on_response
    async def test4(request: Request, response):
        return response

    assert len(app._future_middleware) == 4
    assert app._future_middleware[0].middleware == test
    assert app._future_middleware[1].middleware == test2

# Generated at 2022-06-21 23:18:55.343625
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    @sanic.response.json
    async def a(request):
        return {"name": "a"}

    app = sanic.Sanic("a", strict_slashes=True)
    app.add_route(a, "/")

    @app.on_request
    async def test_on_request(request):
        return sanic.response.text("test")

    assert app.middleware[0].attach_to == "request"

    request, response = app.test_client.get("/")
    assert response.status == 200
    assert response.text == "test"


# Generated at 2022-06-21 23:18:56.018969
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert 1 == 1