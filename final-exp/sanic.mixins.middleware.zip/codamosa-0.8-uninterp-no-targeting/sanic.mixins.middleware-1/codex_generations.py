

# Generated at 2022-06-21 23:09:14.909560
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    app = MiddlewareMixin()
    assert app._future_middleware == []


# Generated at 2022-06-21 23:09:21.115575
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.request import Request, RequestParameters
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic import Blueprint
    from sanic.exceptions import NotFound, InvalidUsage, ServerError
    from sanic.views import HTTPMethodView
    import sanic
    from jinja2 import Template
    import os
    import sys
    import json
    import asyncio
    import logging
    import inspect

    app = Sanic()

    ret = app.middleware
    assert callable(ret) == True

    ret = app.middleware('request')
    assert callable(ret) == True

    ret = app.middleware('response')
    assert callable(ret) == True

    ret = app.on

# Generated at 2022-06-21 23:09:26.748476
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class FooMiddlewareMixin:
        future_middleware = []

    class BarMiddleware(FooMiddlewareMixin, MiddlewareMixin):
        pass

    bar = BarMiddleware()
    m = bar.on_request()
    assert m.__name__ == 'm'
    bar.on_request(m)
    assert len(bar.future_middleware) == 1



# Generated at 2022-06-21 23:09:30.524556
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    a = MiddlewareMixin()
    b = Sanic()
    assert a.middleware(middleware_or_request=b, apply=False) == b
    assert a.on_request(middleware=b) == b
    assert a.on_response(middleware=b) == b

# Generated at 2022-06-21 23:09:35.322034
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    import sanic.app

    a = sanic.app.Sanic()

    assert isinstance(a._future_middleware, list)


# Generated at 2022-06-21 23:09:42.161557
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestClass(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    
    @TestClass.middleware
    async def middleware1(request):
        pass

    @TestClass.middleware
    async def middleware2(request):
        pass

    @TestClass.middleware('request')
    async def middleware3(request):
        pass

    @TestClass.middleware('response')
    async def middleware4(request, response):
        pass

    assert all(future_middleware.middleware for future_middleware in TestClass._future_middleware)
    assert isinstance(TestClass._future_middleware[0].middleware, partial)
    assert isinstance(TestClass._future_middleware[1].middleware, partial)

# Generated at 2022-06-21 23:09:47.949066
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestClass(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass
    obj = TestClass()
    assert isinstance(obj, TestClass)
    assert isinstance(obj, MiddlewareMixin)
    obj.on_request()
    assert True


# Generated at 2022-06-21 23:09:56.774638
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class _MiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    middlewaremixin = _MiddlewareMixin()
    m = middlewaremixin.middleware
    assert isinstance(m(lambda: None), types.FunctionType)
    assert isinstance(m("request")(lambda: None), types.FunctionType)

# Generated at 2022-06-21 23:10:05.689514
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class FakeMiddleware:
        def __init__(self, *args, **kwargs) -> None:
            pass

        def middleware(self, *args, **kwargs) -> bool:
            return True

    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    obj = TestMiddlewareMixin()
    mock_func = MagicMock()
    mock_func.return_value = True
    assert obj.on_response(middleware=mock_func) == mock_func
    assert obj.on_response(middleware=FakeMiddleware)() is True


# Generated at 2022-06-21 23:10:11.966304
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from base import Base

    class _MiddlewareMixin(MiddlewareMixin, Base):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    server = _MiddlewareMixin()
    # Check if the `middleware` method of the class
    # `_MiddlewareMixin` instantiated from the class `MiddlewareMixin`
    # can return a method without any error.
    assert(callable(server.middleware))

# Generated at 2022-06-21 23:10:18.580326
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    my_sanic = Sanic(__name__)

    @my_sanic.on_response
    def custom_response_middlware(request, response):
        pass


# Generated at 2022-06-21 23:10:24.279015
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic("test_on_response_app")
    # call on_response method of MiddlewareMixin
    app.on_response(middleware=None)


# Generated at 2022-06-21 23:10:28.522471
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic(__file__)

    async def middleware(request):
        return request

    app.middleware(middleware)

    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == "request"

# Generated at 2022-06-21 23:10:35.351469
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class App(MiddlewareMixin):
        def __init__(self):
            super(App, self).__init__()
            self._future_middleware = [object]
            self._apply_middleware = lambda x: None

    app = App()
    app.on_response()

# Generated at 2022-06-21 23:10:44.616864
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # This method is used to test the method on_response in the class
    # MiddlewareMixin
    # given
    class InvokeMiddleware(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.mock_middleware = Mock()

        def _apply_middleware(self, middleware):
            if middleware.attach_to == "request":
                self.mock_middleware(middleware)

    # when
    invoke_middleware = InvokeMiddleware()
    invoke_middleware.on_response()

    # then
    assert invoke_middleware._future_middleware[0].attach_to == "response"
    invoke_middleware.mock_middleware.assert_not_called()


# Unit test

# Generated at 2022-06-21 23:10:51.747846
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    def middleware():
        pass

    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass
    middleware_mixin = TestMiddlewareMixin()
    middleware_mixin.on_response(middleware)
    assert middleware_mixin._future_middleware[0].middleware == middleware # noqa
    assert middleware_mixin._future_middleware[0].attach_to == "response" # noqa

# Generated at 2022-06-21 23:10:52.617078
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()

# Generated at 2022-06-21 23:10:56.580023
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    assert isinstance(mm, MiddlewareMixin)
    assert isinstance(mm._future_middleware, list)

# Tests for middleware method of class MiddlewareMixin

# Generated at 2022-06-21 23:11:03.451953
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic()
    class Middleware(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(MiddlewareMixin, self).__init__(*args, **kwargs)
            self.middleware = []
        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware.append(middleware)
    try:
        Middleware().on_response(None)
        assert False
    except TypeError:
        assert True
    def test_on_response(request):
        pass
    response = Middleware().on_response(test_on_response)
    assert response.__name__ == 'test_on_response'
    response(app)
    assert len(app.middleware) == 1
    assert callable

# Generated at 2022-06-21 23:11:07.827447
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    obj = MiddlewareMixin()
    f = lambda req: 0
    assert obj.on_request(f)(req=None) == obj.middleware(f, 'request')(req=None)


# Generated at 2022-06-21 23:11:11.554741
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert False, "Not implemented"

# Generated at 2022-06-21 23:11:14.492775
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin = MiddlewareMixin()
    assert mixin._future_middleware == []


# Generated at 2022-06-21 23:11:22.702910
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)

    mm = TestMiddlewareMixin()
    mm.middleware('request', apply=False)
    mm.on_request()(None, apply=False)
    assert len(mm._future_middleware) == 2

# Generated at 2022-06-21 23:11:26.240911
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()

    @app.middleware
    async def resp_middleware(request, response):
        pass

    assert len(app._future_middleware) > 0

# Generated at 2022-06-21 23:11:31.652958
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    mmix = MiddlewareMixin()
    @mmix.on_response()
    def mw_fn(request):
        pass
    assert mw_fn.__name__ == "mw_fn"
    assert mw_fn.__doc__ == None

    mmix2 = MiddlewareMixin()
    @mmix2.on_response
    def mw_fn2(request):
        pass
    assert mw_fn2.__name__ == "mw_fn2"
    assert mw_fn2.__doc__ == None

# Generated at 2022-06-21 23:11:36.613933
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Testing(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    testing = Testing()
    assert testing._future_middleware == []

# Generated at 2022-06-21 23:11:41.392141
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Test the function with default parameter
    app = sanic.Sanic('test_MiddlewareMixin_middleware')
    @app.middleware
    def mw1(request):
        print ('mw1')
    assert str(app._future_middleware[0].middleware) == "<function mw1 at 0x0000022DACCE9EA0>"
    app._apply_middleware(app._future_middleware[0])
    sanic.exceptions.abort(404)


# Generated at 2022-06-21 23:11:51.476994
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic()

    @app.middleware
    def my_middleware(request):
        pass

    app_middleware = app.middleware
    app_on_request = app.on_request
    app_on_response = app.on_response
    app_future_middleware = app._future_middleware

    class MiddlewareMixinTester(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test = MiddlewareMixinTester()
    test_middleware = test.middleware
    test_on_request = test.on_request
    test_on_response = test.on_response
    test_future_middleware = test._future_middleware

    test_middleware(lambda req: req)

# Generated at 2022-06-21 23:11:54.544541
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    def middleware(request):
        return 'middleware'
    mm = MiddlewareMixin()
    mm.on_request(middleware)
    # no assert...
    # TODO: make assert by checking self._future_middleware



# Generated at 2022-06-21 23:11:57.247017
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    request = 'request'
    @MiddlewareMixin.on_response(request)
    def middleware_or_request(request):
        return request

    # The instance of class MiddlewareMixin should be returned as None
    assert middleware_or_request is None

# Generated at 2022-06-21 23:12:05.196659
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    class Sanic():
        pass

    obj = MiddlewareMixin()

    @obj.middleware()
    async def bar(request):
        print('bar')
        
    assert isinstance(bar, types.FunctionType)
    
    

# Generated at 2022-06-21 23:12:12.008484
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    class MyMiddlewareMixin(MiddlewareMixin):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.app = self

        def _apply_middleware(self, middleware):
            pass
    
    m = MyMiddlewareMixin()
    m.on_request(middleware=1)
    expected_result = [1]

    for i in m._future_middleware:
        assert (isinstance(i, FutureMiddleware))
        assert (i.attach_to == 'request')



# Generated at 2022-06-21 23:12:14.869802
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    def func():
        pass
    instance = MiddlewareMixin()
    instance.on_request(func)
    instance.on_response(func)
    instance.middleware(func)
    instance.middleware('request', func)
    instance.middleware('response', func)
    assert instance._future_middleware
    assert len(instance._future_middleware) == 4

test_MiddlewareMixin()

# Generated at 2022-06-21 23:12:23.976371
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic import response

    app = Sanic("test_MiddlewareMixin_on_response")

    @app.middleware
    def second_request_middleware(request):
        request["second"] = True

    @app.middleware
    def second_response_middleware(request, response):
        response["second"] = True

    @app.middleware("request")
    def first_request_middleware(request):
        request["first"] = True

    @app.middleware("response")
    def first_response_middleware(request, response):
        response["first"] = True

    @app.post("/")
    async def handler(request):
        return response.json(request.json)

    @app.get("/reverse")
    async def handler(request):
        messages

# Generated at 2022-06-21 23:12:33.240255
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic(__name__)

    # Middleware should be callable
    with pytest.raises(TypeError) as excinfo:
        app.middleware(None)
    assert "Middleware must be callable" in str(excinfo.value)

    # Middleware attach_to name must be in ('request', 'response')
    with pytest.raises(ValueError) as excinfo:
        app.middleware(None, attach_to="invalid")
    assert "attach_to must be one of" in str(excinfo.value)

    # Middleware should be callable when using `on_request` or `on_response`
    with pytest.warns(DeprecationWarning):
        with pytest.raises(TypeError) as excinfo:
            app.on_

# Generated at 2022-06-21 23:12:42.589435
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic, response
    
    app = Sanic('test_MiddlewareMixin')

    @app.middleware('request')
    def request_middleware(request):
        request['foo'] = 'bar'

    @app.middleware('response')
    def response_middleware(request, response):
        response.headers['bar'] = 'foo'

    @app.route('/')
    def handler(request):
        return response.text('OK')

    request, response = app.test_client.get('/')

    assert request.get('foo') == 'bar'
    assert response.headers.get('bar') == 'foo'
    assert response.text == 'OK'


# Generated at 2022-06-21 23:12:53.455984
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MyMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            self.list1 = []
            self.list2 = []

        def _apply_middleware(self, future_middleware):
            if future_middleware.attach_to == "request":
                self.list1.append(future_middleware)
            if future_middleware.attach_to == "response":
                self.list2.append(future_middleware)

    test_obj = MyMiddlewareMixin()
    print(test_obj._future_middleware)
    print(test_obj.list1)
    print(test_obj.list2)

    @test_obj.middleware("request")
    async def test_middleware1(request):
        pass

    print(test_obj._future_middleware)

# Generated at 2022-06-21 23:12:55.759000
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewareMixin = MiddlewareMixin()
    assert type(middlewareMixin._future_middleware) == list

# Generated at 2022-06-21 23:13:00.297241
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import json

    async def my_response_middleware(request, response):
        return json({"foo": "bar"})

    app = Sanic("test_MiddlewareMixin_on_response")
    app.on_response(my_response_middleware)

    return True


# Generated at 2022-06-21 23:13:05.224150
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import SanicException
    from sanic.log import log
    from sanic.request import Request, StreamBuffer
    from sanic.response import HTTPResponse, text, web_file
    from sanic.routing import Router, RouteExists
    from sanic.server import Trigger, HttpProtocol, is_ip
    from sanic.utils import (
        sanic_endpoint_test,
        sanic_app_class,
        LOGGING_CONFIG_DEFAULTS,
    )

    from sanic.response import json as json_response

    from sanic.models.request import RequestParameters
    from sanic.models.response import HTTPResponseInterface

# Generated at 2022-06-21 23:13:14.663115
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

# Generated at 2022-06-21 23:13:19.329450
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():

    # Unit test when middleware is not none
    middleware_mixin_test = MiddlewareMixin(None)
    assert middleware_mixin_test._future_middleware == []

    # Unit test when middleware is none
    middleware_mixin_test = MiddlewareMixin()
    assert middleware_mixin_test._future_middleware == []


# Generated at 2022-06-21 23:13:21.893533
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    with pytest.raises(NotImplementedError):
        MiddlewareMixin()._apply_middleware(None)

# Generated at 2022-06-21 23:13:29.699838
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_on_request')

    @app.middleware
    async def handler(*args, **kwargs):
        print('ok')

    @app.route('/')
    async def handler(request):
        return text('ok')

    request, response = app.test_client.get('/')

    assert response.text == 'ok'


# Generated at 2022-06-21 23:13:35.664589
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Arrange
    class App:
        def __init__(self, *args, **kwargs):
            print('test')
    app = App()
    # Act
    result = app.on_response()
    # Assert
    assert result 


# Generated at 2022-06-21 23:13:39.925787
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    m.middleware = lambda *args, **kwargs: None
    
    def test_middleware():
        pass

    m.on_request(m.on_request())

# Generated at 2022-06-21 23:13:51.473729
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    output = MiddlewareMixin(1)

    # Test the exception
    try:
        output._apply_middleware(None)
    except NotImplementedError:
        pass

    # Test the function
    def test_func(request):
        return 1

    func = output.middleware(test_func)
    assert callable(func)
    assert func.func == test_func

    # Test the function for param "request"
    func = output.middleware(test_func, attach_to="request")
    assert callable(func)
    assert func.func == test_func

    # Test the function for param "response"
    func = output.middleware(test_func, attach_to="response")
    assert callable(func)
    assert func.func == test_func

    # Test the function for param "unknown

# Generated at 2022-06-21 23:13:55.273055
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    instance = MiddlewareMixin()
    assert hasattr(instance, '_future_middleware')
    assert hasattr(instance, '_apply_middleware')


# Generated at 2022-06-21 23:14:02.506930
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # arrange
    from unittest.mock import Mock
    import asyncio
    async def handler(request, callback):
        response = await callback(request)
        return response
    callback = Mock()
    request = Mock()
    response = Mock()
    callback.return_value = response
    # act
    future = asyncio.ensure_future(handler(request, callback))
    asyncio.get_event_loop().run_until_complete(future)
    result = future.result()
    # assert
    assert result is response

# Generated at 2022-06-21 23:14:05.657438
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class MiddlewareMixin_test(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    @MiddlewareMixin_test().on_response()
    def func_without_params():
        return 0

    assert func_without_params() == 0

    @MiddlewareMixin_test().on_response(lambda x: x)
    def func_with_params(x: int):
        return x

    assert func_with_params(0) == 0

