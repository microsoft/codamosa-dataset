

# Generated at 2022-06-21 23:09:19.454426
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin = MiddlewareMixin()

    def middleware(request):
        return request

    assert callable(middleware_mixin.on_response(middleware))



# Generated at 2022-06-21 23:09:28.532900
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class ClassForTest(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.middleware = {}
    
    def test_middleware_method(request, response):
        return None, response

    class_for_test = ClassForTest()
    class_for_test.on_request(test_middleware_method)
    assert class_for_test.middleware ==  {'request': test_middleware_method}



# Generated at 2022-06-21 23:09:32.367598
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    """
    TODO: bug: cannot be tested
    """
    pass


# Generated at 2022-06-21 23:09:35.746378
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
  b = MiddlewareMixin()
  assert len(b._future_middleware) == 0

# Generated at 2022-06-21 23:09:37.966460
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    
    @Sanic.middleware('request')
    async def logger(request):
        pass
    
    @Sanic.on_request
    async def logger(request):
        pass

# Generated at 2022-06-21 23:09:41.800413
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    @MiddlewareMixin.on_response
    def on_response(request, response):
        return request, response

    assert on_response



# Generated at 2022-06-21 23:09:49.138663
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    arg = partial(print, 1)
    arg2 = partial(print, 2)
    mm = MiddlewareMixin()
    mm.middleware = MagicMock()
    mm.on_request(arg)
    mm.middleware.assert_called_with(arg, attach_to="request")

    mm.on_request().__call__(arg2)
    mm.middleware.assert_called_with(arg2, attach_to="request")
    

# Generated at 2022-06-21 23:09:58.836753
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic

    app = Sanic()

    @app.middleware
    def before_request(request):
        pass

    @app.middleware('response')
    def after_request(request, response):
        pass

    @app.middleware
    async def async_before_request(request):
        pass

    @app.middleware('response')
    async def async_after_request(request, response):
        pass

    assert len(app._future_middleware) == 4

# Generated at 2022-06-21 23:10:05.691797
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic(name='sanic_test')
    @app.middleware
    async def method(a):
        return a
    assert method == app.on_request()
    assert method == app.on_request(method)


# Generated at 2022-06-21 23:10:06.192799
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    return

# Generated at 2022-06-21 23:10:19.714946
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    app = App()
    f = app.on_response(middleware=None)
    assert f.__name__ == 'on_response'
    assert f(None) == None
    assert f.__doc__ == 'Decorate and register middleware to be called before a request.\n        Can either be called as *@app.middleware* or\n        *@app.middleware(\'request\')*\n\n        `See user guide re: middleware\n        <https://sanicframework.org/guide/basics/middleware.html>`__\n\n        :param: middleware_or_request: Optional parameter to use for\n            identifying which type of middleware is being registered.\n'
    assert f.__defaults__ == (None,)
    assert f.__kwdefaults__ == {}
    assert f

# Generated at 2022-06-21 23:10:20.101504
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    pass

# Generated at 2022-06-21 23:10:31.097753
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MockMiddlewareMixin(MiddlewareMixin):
        @property
        def future_middleware(self):
            return self._future_middleware
    
    assert len(MockMiddlewareMixin().future_middleware) == 0
    assert len(MockMiddlewareMixin(middleware1='a').future_middleware) == 0
    assert len(MockMiddlewareMixin(middleware1='a', middleware2='b').future_middleware) == 0
    assert len(MockMiddlewareMixin(middleware1='a', middleware2='b', middleware3='c').future_middleware) == 0
    assert len(MockMiddlewareMixin(middleware1='a', middleware2='b', middleware3='c', middleware4='d').future_middleware) == 0

# Generated at 2022-06-21 23:10:32.704992
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass


# Generated at 2022-06-21 23:10:34.676115
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin_instance = MiddlewareMixin()
    assert middleware_mixin_instance._future_middleware == []


# Generated at 2022-06-21 23:10:44.417179
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic(__name__)

    def request_middleware(request):
        pass

    def response_middleware(request, response):
        pass

    assert len(app._future_middleware) == 0

    app.on_request(request_middleware)
    assert len(app._future_middleware) == 1
    assert (
        app._future_middleware[0].middleware
        == request_middleware
    )
    assert app._future_middleware[0].attach_to == "request"

    app.on_response(response_middleware)
    assert len(app._future_middleware) == 2
    assert (
        app._future_middleware[1].middleware
        == response_middleware
    )

# Generated at 2022-06-21 23:10:47.548746
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    tmp = MiddlewareMixin()
    assert tmp is not None
    assert callable(tmp.middleware)


# Generated at 2022-06-21 23:10:57.136193
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.testing import HOST, PORT

    app = Sanic("test_MiddlewareMixin")

    @app.middleware
    async def add_sum(request):
        request["sum"] = 1 + 2

    assert len(app._future_middleware) == 1

    @app.middleware("request")
    async def add_request(request):
        request["foo"] = "bar"

    assert len(app._future_middleware) == 2

    @app.middleware("response")
    async def add_response(request, response):
        response.headers["foo"] = "bar"

    assert len(app._future_middleware) == 3

    app.add_route(lambda x: x, "/")


# Generated at 2022-06-21 23:11:02.120660
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware = "foo"

    class MockMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    m = MockMiddlewareMixin()

    # Test with callable argument
    m.on_response(middleware)
    assert m._future_middleware
    assert m._future_middleware[0].middleware == middleware
    assert m._future_middleware[0].attach_to == "response"

    # Test without callabl argument
    m.on_response()
    assert len(m._future_middleware) == 1
    assert m.on_response()
    assert len(m._future_middleware) == 1



# Generated at 2022-06-21 23:11:11.178742
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert not hasattr(MiddlewareMixin, "on_request")
    MiddlewareMixin.on_request = on_request
    middleware_mixin = MiddlewareMixin()
    middleware = middleware_mixin.on_request()
    assert middleware_mixin.on_request(middleware) == middleware
    assert middleware_mixin.on_request(middleware_mixin) == middleware_mixin
    assert hasattr(MiddlewareMixin, "on_request")
    delattr(MiddlewareMixin, "on_request")


# Generated at 2022-06-21 23:11:21.927421
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.sanic import Sanic as _Sanic

    class Sanic(_Sanic):
        def __init__(self, *args, **kwargs):
            self._future_middleware = []
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError

    app = Sanic(__name__)

    @app.on_request()
    def middleware(request):
        return request

    app.middleware(middleware)

    assert len(app._future_middleware) == 1


# Generated at 2022-06-21 23:11:31.356960
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test_MiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super(Test_MiddlewareMixin, self).__init__()
            # Mock the Coroutine
            self._apply_middleware = CoroutineMock()

    test_obj = Test_MiddlewareMixin()

    # Call the function without passing any parameter
    test_obj.middleware()
    assert call(None, "request") in test_obj._apply_middleware.call_args_list

    # Call the function by passing the attach_to param "response"
    test_obj.middleware("response")
    assert call(None, "response") in test_obj._apply_middleware.call_args_list

    # Call the function by passing the attach_to param "request"
    test_obj.middleware("request")
   

# Generated at 2022-06-21 23:11:41.391723
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.base import Base

    # Test on_request function callable
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test = TestMiddlewareMixin()

    @test.on_request
    def test_middleware_on_request(request):
        pass

    assert test._future_middleware[0].attach_to == "request"
    assert test._future_middleware[0].middleware == test_middleware_on_request

    # Test on_request function not callable
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test = TestMiddlewareMixin()


# Generated at 2022-06-21 23:11:47.709880
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic(__name__)
    @app.middleware
    async def request_middleware(a, b):
        return a + b

    assert request_middleware(1, 2) == 3
    print("test_MiddlewareMixin_on_request() PASS")


# Generated at 2022-06-21 23:11:55.716656
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import unittest
    class MiddlewareMixinTest(unittest.TestCase, MiddlewareMixin):
        def test_MiddlewareMixin_on_response(self):
            @self.on_response
            def foo(request, response):
                response.foo = 1
            self.assertEqual(self._future_middleware[0].attach_to, "response")

# Generated at 2022-06-21 23:11:58.850178
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic("test_app")
    @app.on_request
    def handle_request(request):
        return request
    assert callable(handle_request)


# Generated at 2022-06-21 23:11:59.584093
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert True

# Generated at 2022-06-21 23:12:09.785297
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic import response
    from sanic.server import HttpProtocol
    from sanic.request import Request
    from sanic.blueprints import Blueprint
    from sanic.router import Router
    from sanic.log import logger
    from sanic.response import HTTPResponse
    from sanic.views import CompositionView
    from sanic_openapi import doc

    class App(MiddlewareMixin, Sanic):
        def __init__(self, name=None):
            pass

    app = App()

    async def my_response_middleware(request, response):
        return response

    app.on_response(my_response_middleware)

# Generated at 2022-06-21 23:12:17.992504
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.models.middlewares import FutureMiddleware

    app = Sanic()

    class TestMiddleware:
        pass

    middleware_list = []

    def _apply_middleware(middleware):
        nonlocal middleware_list
        middleware_list.append(middleware)

    def _middleware(middleware_or_request, attach_to="request", apply=True):
        nonlocal middleware_list

        nonlocal apply

        future_middleware = FutureMiddleware(middleware_or_request, attach_to)
        middleware_list.append(future_middleware)
        if apply:
            _apply_middleware(future_middleware)
        return middleware_or_request

    MiddlewareMixin._middleware = _middleware
    MiddlewareMix

# Generated at 2022-06-21 23:12:27.862756
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    request_flag = []
    response_flag = []

    @app.middleware('response')
    async def response_middleware(request, response):
        response_flag.append('ok')

    @app.middleware('request')
    async def request_middleware(request):
        request_flag.append('ok')

    @app.route("/")
    async def test(request):
        return text("test")

    request, response = app.test_client.get("/")
    assert len(request_flag) == 1
    assert request_flag[0] == 'ok'
    assert len(response_flag) == 1

# Generated at 2022-06-21 23:12:37.031282
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class App(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    app = App()
    assert app._future_middleware == []

# Generated at 2022-06-21 23:12:48.768507
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import ServerError
    from sanic import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic import Sanic
    from sanic.response import text
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import ServerError
    from sanic import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic import Sanic
    from sanic.response import text
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import ServerError
    from sanic import Blueprint
    from sanic.request import Request
    from sanic.response import HT

# Generated at 2022-06-21 23:12:56.074676
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.testing import HOST, PORT

    app = Sanic("test_MiddlewareMixin_App")

    @app.middleware("request")
    async def handler(request):
        return json({"a": "b"})

    @app.route("/")
    async def handler(request):
        return json({"a": "b"})

    request, response = app.test_client.get("/")
    assert response.status == 200
    assert response.json == {"a": "b"}
    assert app._future_middleware[0].name == "handler"


# Generated at 2022-06-21 23:13:04.290994
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class ClassMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(ClassMiddlewareMixin, self).__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        # Apply this middleware only to the / prefix URL.
        def _apply_middleware(self, middleware: FutureMiddleware):
            if middleware.attach_to == 'request':
                self.router.get('/', middleware.middleware)

    # Create this particular class of middleware.
    class_middleware_mixin = ClassMiddlewareMixin()

    # Assert that there is no attached middleware.
    assert len(class_middleware_mixin._future_middleware) == 0

    # Define an

# Generated at 2022-06-21 23:13:06.802059
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class App(MiddlewareMixin):
        pass

    app = App()
    assert isinstance(app, App)


# Generated at 2022-06-21 23:13:11.422827
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.request import Request

    class TestMiddleware:
        async def __call__(self, request: Request):
            pass

    class TestApp(MiddlewareMixin, Sanic):
        pass

    app = TestApp()
    app.middleware(TestMiddleware)
    assert len(app._future_middleware) == 1

# Generated at 2022-06-21 23:13:20.489594
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    mixin = MiddlewareMixin()
    def my_middleware(request):
        return request

    on_request_partial = mixin.on_request()
    assert on_request_partial.__name__ == "register_middleware"
    assert on_request_partial.keywords["attach_to"] == "request"

    on_request_partial(my_middleware)
    assert len(mixin._future_middleware) == 1

    assert mixin.on_request(my_middleware).__name__ == "my_middleware"
    assert len(mixin._future_middleware) == 2


# Generated at 2022-06-21 23:13:26.664077
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Mixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware):
            pass

    assert Mixin()._future_middleware == []

# Generated at 2022-06-21 23:13:31.314891
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.blueprint import Blueprint

    app = Sanic("Sanic")
    bp = Blueprint("bp")

    @app.middleware("request")
    def request_middleware(request):
        pass

    @bp.middleware("response")
    def response_middleware(request, response):
        pass

    assert len(app.middleware._future_middleware) == 1
    assert len(bp.middleware._future_middleware) == 1

# Generated at 2022-06-21 23:13:33.921012
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    with pytest.raises(NotImplementedError):
        MiddlewareMixin("test")

# Generated at 2022-06-21 23:13:51.230556
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.exceptions import SanicException
    from sanic.request import RequestParameters
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.models import Model

    # Create MiddlewareMixin for unit test
    mm: MiddlewareMixin = MiddlewareMixin()

    # Create the function decorators of method middleware
    middleware = mm.middleware
    on_request = mm.on_request
    on_response = mm.on_response

    # Create test request data

# Generated at 2022-06-21 23:13:55.202340
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class A(MiddlewareMixin):
        pass
    a = A()
    @a.on_request
    def test_middleware(request):
        pass


# Generated at 2022-06-21 23:13:59.215832
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddlewareMixinTestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    MiddlewareMixinTestClass()

# Generated at 2022-06-21 23:14:11.549942
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic, BaseModel
    from sanic.exceptions import SanicException
    from sanic.response import HTTPResponse

    class A(Sanic):
        class B(MiddlewareMixin, BaseModel):
            pass

        b = B()

        @b.on_response
        async def test_on_request(request):
            return HTTPResponse(b'{}', status=200)
    
    a = A()

    assert isinstance(a.b, A.B)
    assert a.b._future_middleware == []

    assert callable(a.b.on_request())
    assert callable(a.b.on_response())

    try:
        a.b.on_request()()
    except SanicException:
        assert True

# Generated at 2022-06-21 23:14:21.909114
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Check on_response method with callable 'middleware' parameter
    middleware_mixin = MiddlewareMixin()
    assert callable(middleware_mixin.on_response)
    assert callable(middleware_mixin.on_response(middleware_mixin))
    assert middleware_mixin.on_response(middleware_mixin) == middleware_mixin.middleware(middleware_mixin, "response")
    # Check on_response method without callable 'middleware' parameter
    assert callable(middleware_mixin.on_response())
    assert middleware_mixin.on_response()(middleware_mixin) == middleware_mixin.middleware(middleware_mixin, "response")


# Generated at 2022-06-21 23:14:27.964054
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    @app.middleware
    async def middleware1(request):
        pass
    @app.middleware('request')
    async def middleware2(request):
        pass
    @app.middleware('response')
    async def middleware3(request, response):
        pass
    @app.on_request
    async def middleware4(request):
        pass
    @app.on_response
    async def middleware5(request, response):
        pass

    assert len(app._future_middleware) == 5
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].attach_to == 'request'
    assert app._future_middleware[2].attach_to == 'response'

# Generated at 2022-06-21 23:14:29.731936
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert isinstance(m, MiddlewareMixin)
    assert m._future_middleware == []


# Generated at 2022-06-21 23:14:40.329954
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import pytest
    from sanic.utils import SanicException
    from sanic.app import Sanic

    app = Sanic(__name__)

    @app.middleware('request')
    async def _request_middleware(request):
        return request

    @app.middleware('response')
    async def _response_middleware(request, response):
        return response

    @app.route('/')
    async def index(request):
        return response.text('index')

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.text == 'index'


# Generated at 2022-06-21 23:14:42.353910
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()

# Generated at 2022-06-21 23:14:47.526678
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic()

    @app.middleware('request')
    async def request_middleware(request):
        raise NotImplementedError

    request_middleware()
    app.on_request(request_middleware)



# Generated at 2022-06-21 23:15:06.286464
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    print()
    from sanic import Sanic
    import asyncio
    from sanic.models.futures import FutureMiddleware

    app = Sanic()
    app.on_request(lambda request: asyncio.sleep(1))
    # print(app._future_middleware)
    # print(type(app._future_middleware[0]))
    # print(app._future_middleware[0].type)




# Generated at 2022-06-21 23:15:08.268897
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin = MiddlewareMixin()
    @middleware_mixin.on_response
    def test_response(request, response):
        pass

# Generated at 2022-06-21 23:15:09.080073
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    pass

# Generated at 2022-06-21 23:15:20.009770
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    import pytest
    mock_app = Sanic("test_MiddlewareMixin")

    mock_app_state = mock_app.__dict__
    # Test 1: default constructor
    test_MiddlewareMixin_instance = MiddlewareMixin()
    test_MiddlewareMixin_state = test_MiddlewareMixin_instance.__dict__

    assert test_MiddlewareMixin_state=={'_future_middleware': []}

    # Test 2: non-default argument is given
    # mock_app_2 = Sanic("MiddlewareMixin_2")
    # test_MiddlewareMixin_instance_2 = MiddlewareMixin(app=mock_app_2)
    # test_MiddlewareMixin_state_2 = test_MiddlewareMixin_instance_2.__

# Generated at 2022-06-21 23:15:27.251977
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Arrange
    middleware1 = "middleware1"
    middleware2 = "middleware2"
    # Act
    test_mixin = MiddlewareMixin(middleware1, middleware2)
    # Assert
    assert len(test_mixin._future_middleware) == 2
    assert test_mixin._future_middleware[0] == middleware1
    assert test_mixin._future_middleware[1] == middleware2


# Generated at 2022-06-21 23:15:29.578733
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.views import CompositionView

    app = Sanic("test_MiddlewareMixin_on_response")
    cv = CompositionView()
    middleware = MiddlewareMixin()
    assert "middleware" in middleware.on_response()



# Generated at 2022-06-21 23:15:34.145057
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Temp():
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

    assert Temp()


# Generated at 2022-06-21 23:15:37.274429
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    a = A()
    a.on_request(1)
    a.on_response(2)
    a.middleware(3)
    assert len(a._future_middleware) == 3

# Generated at 2022-06-21 23:15:44.540528
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic()

    # middleware is None
    assert callable(app.on_request)
    # middleware is callable
    assert callable(app.on_request(lambda req: req))
    # middleware is not callable
    assert callable(app.on_request(None))



# Generated at 2022-06-21 23:15:48.370695
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m=MiddlewareMixin()
    assert m._future_middleware == []
    m.middleware(lambda x:x)
    assert len(m._future_middleware) == 1

# Generated at 2022-06-21 23:16:17.636587
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin = MiddlewareMixin()
    list(mixin._future_middleware)

    if mixin._future_middleware == []:
        print('PASS!')
    else:
        print('FAIL!') 

test_MiddlewareMixin()

# Generated at 2022-06-21 23:16:19.250373
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from . import Mock
    mm = MiddlewareMixin()
    mm2 = MiddlewareMixin()
    mm.middleware(mm2)
    assert (True is False)


# Generated at 2022-06-21 23:16:26.696524
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
  
  # mock sanic.app.Sanic
  class _Sanic:
    pass
    
  # mock class
  class _Middleware:
    pass
    
  # mock object
  _middleware = _Middleware()
  
  # create instance under test
  _middleware_mixin = MiddlewareMixin()
  # apply mocks
  _middleware_mixin._future_middleware = []
  _middleware_mixin._apply_middleware = lambda x: None
  _middleware_mixin.middleware = lambda x, attach_to, apply: x
  
  # test @middleware
  assert _middleware_mixin.on_response(_middleware) == _middleware
  assert _middleware_mixin._future_middleware[-1].middleware == _middleware
  assert _middle

# Generated at 2022-06-21 23:16:33.081984
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    class Sanic_test(Sanic):
        def __init__(self):
            super().__init__("test_on_request")

    app = Sanic_test()

    @app.on_request
    async def func_on_request():
        return None

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == func_on_request

# Generated at 2022-06-21 23:16:41.172110
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.futures import FutureMiddleware
    class TestApp(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    # unit test starts here
    @TestApp().on_request
    def test_middleware(req):
        pass
    test_app = TestApp()
    middleware = test_app._future_middleware[0]
    assert middleware.middleware == test_middleware
    assert middleware.attach_to == 'request'


# Generated at 2022-06-21 23:16:47.127036
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import json
    app = Sanic(__name__)

    # Ensure it correctly receives its parameters
    @app.on_response()
    async def on_response(request, response):
        return response

    @app.route("/")
    async def handler(request):
        return json({"test": True})

    request, response = app.test_client.get("/")
    assert response.status == 200

# Generated at 2022-06-21 23:16:52.205251
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    @MiddlewareMixin.middleware
    def request_middleware(request):
        pass

    @MiddlewareMixin.on_response
    def response_middleware(request, response):
        pass

    middleware_mixin = MiddlewareMixin()
    assert len(middleware_mixin._future_middleware) == 2

# Generated at 2022-06-21 23:17:01.208193
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A(MiddlewareMixin):pass
    a = A()
    def mid1(request): pass
    def mid2(request, response): pass
    def mid3(request): pass
    def mid4(request,response): pass
    a.middleware(mid1)
    a.middleware(mid2,'response')
    a.middleware(mid3,'request')
    a.middleware(mid4)
    assert a._future_middleware[0].middleware == mid1
    assert a._future_middleware[1].middleware == mid2
    assert a._future_middleware[1].when == 'response'
    assert a._future_middleware[2].middleware == mid3
    assert a._future_middleware[2].when == 'request'
    assert a._future_middleware[3].middleware

# Generated at 2022-06-21 23:17:06.184131
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    try:
        m = MiddlewareMixin()
        assert isinstance(m, MiddlewareMixin)
    except Exception as e:
        print('Exception:', e)
        assert False

    try:
        m = MiddlewareMixin(1,2,a = 3)
        assert isinstance(m, MiddlewareMixin)
    except Exception as e:
        print('Exception:', e)
        assert False

# Generated at 2022-06-21 23:17:15.543654
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic()
    test_dict = {}

    @app.on_response
    def test_middleware(request, response):
        test_dict['test'] = "passed on_response"

    @app.route('/')
    async def test_route(request):
        test_dict['test'] = "passed on_request"
        return sanic.response.text("test")

    client = app.test_client
    request, response = client.get('/')

    assert test_dict['test'] == "passed on_response"


# Generated at 2022-06-21 23:18:08.393669
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    # Sanic is a subclass of MiddlewareMixin
    # so test will start with Sanic's __init__()
    s = Sanic('test')

    # Verify that __init__() in MiddlewareMixin has been called
    assert s._future_middleware == []

# Generated at 2022-06-21 23:18:11.038427
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert isinstance(MiddlewareMixin.__init__, collections.Callable)



# Generated at 2022-06-21 23:18:12.453377
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    pass

# Generated at 2022-06-21 23:18:19.384485
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    app = Sanic("test_app")

    @app.on_request
    def process_request(request):
        return request

    assert len(app._future_middleware) == 1
    assert (
        app._future_middleware[0].middleware_func is process_request
    )


# Generated at 2022-06-21 23:18:26.825814
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text

    # Case 1, normal function
    app = Sanic(__name__)

    @app.on_request
    def _1(request):
        pass

    @app.route("/")
    def _2(request):
        return text("OK")

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.text == "OK"
    assert response.headers.get("content-type") == "text/plain"

    # Case 2, async function
    app = Sanic(__name__)

    @app.on_request
    async def _1(request):
        pass

    @app.route("/")
    def _2(request):
        return text("OK")

    request

# Generated at 2022-06-21 23:18:36.444735
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Test(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware):
            return middleware

    test = Test()
    middleware = test.middleware(attach_to='request')
    middleware_result = middleware(middleware=1)

    assert middleware_result == 1

    on_request_middleware = test.on_request(middleware=2)
    on_request_middleware_result = on_request_middleware()

    assert on_request_middleware_result == 2

    on_response_middleware = test.on_response(middleware=3)
    on_response_middleware_result = on_response_middleware()

    assert on_response

# Generated at 2022-06-21 23:18:46.117306
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.log import logger
    import asyncio
    try:
        # py27
        import mock
    except ImportError:
        # py35
        from unittest import mock

    app = Sanic(__name__)

    @app.middleware
    async def handler(request):
        return request

    @app.middleware('request')
    def handler2(request):
        pass

    assert len(app._future_middleware) == 2

    @app.middleware(apply=False)
    async def handler3(request):
        return request

    assert len(app._future_middleware) == 3

    # Check if the middleware is applied in order.
    logger.level = 'ERROR'
    loop = asyncio.new_event_loop()

# Generated at 2022-06-21 23:18:55.125025
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    import pytest
    app = Sanic('test_MiddlewareMixin_middleware')
    assert isinstance(app, MiddlewareMixin)
    assert app._future_middleware == []

    @app.middleware
    async def test_middleware(request):
        return

    @app.on_request
    async def test_middleware(request):
        return

    @app.on_response
    async def test_middleware(request):
        return

    with pytest.raises(NotImplementedError):
        app._apply_middleware(app._future_middleware[0])

# Generated at 2022-06-21 23:19:00.445767
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic(__name__)

    @app.middleware
    async def mw(request):
        pass

    assert len(app._future_middleware) == 1


# Generated at 2022-06-21 23:19:06.159387
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.middlewares import MiddlewareMixin
    from sanic.models.futures import FutureMiddleware
    middleware_mixin = MiddlewareMixin()
    middleware = lambda req, res: None
    future_middleware = FutureMiddleware(middleware=middleware, attach_to="request")
    middleware_mixin._future_middleware = [future_middleware]
    middleware_mixin._apply_middleware = lambda fm: middleware_mixin.middleware(fm)
    assert (middleware_mixin._future_middleware[0].middleware == middleware)
    assert (middleware_mixin._future_middleware[0].attach_to == "request")
