

# Generated at 2022-06-21 23:09:27.685743
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin.on_request(MiddlewareMixin) == partial(MiddlewareMixin.middleware, attach_to='request')
    assert MiddlewareMixin.on_request(MiddlewareMixin, middleware='middleware') == MiddlewareMixin.middleware('middleware', attach_to='request')

# Generated at 2022-06-21 23:09:40.025777
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.testing import HOST, PORT

    app = Sanic()

    @app.on_request
    def on_request(request):
        assert "on_request"

    @app.on_response
    def on_response(request, response):
        assert "on_request"

    @app.route("/")
    async def handler(request):
        return "Hello"

    @app.websocket("/websocket")
    async def feed(request, ws):
        while True:
            data = "Hello"
            print("Sending", data)
            await ws.send(data)

            data = await ws.recv()
            print("Received", data)

    protocol = Web

# Generated at 2022-06-21 23:09:47.390388
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Tests the on_response method of the class MiddlewareMixin
    # This method shall not be tested in detail
    # In case of errors, please check the class MiddlewareMixin

    # Please note that this method is tested using a pytest
    # fixture, i.e. the method is tested in context with the fixture test_app

    # The method under test shall raise no exceptions
    # Thus, the test shall be successful, if the test is finished
    # without exceptions
    pass

# Generated at 2022-06-21 23:09:57.328277
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
  from sanic.app import Sanic

  class TestSanic(MiddlewareMixin, Sanic):
    pass

  app = TestSanic()
  
  # Unit test for method on_request of class MiddlewareMixin
  def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    class TestSanic(MiddlewareMixin, Sanic):
      pass

    app = TestSanic()

# Generated at 2022-06-21 23:10:09.563377
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.testing import EmptySanicTestClient as TestClient
    from sanic import Sanic

    @MiddlewareMixin.middleware
    def middleware(request):
        request["a"] = "b"

    app = Sanic()

    @app.route("/")
    @MiddlewareMixin.middleware
    async def handler(request):
        msg = request["a"]
        return text(msg)

    client = TestClient(app)
    response = client.get("/")
    assert response.status == 200
    assert response.text == "b"

# Generated at 2022-06-21 23:10:16.144371
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TempMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
    temp_mixin = TempMixin()
    @temp_mixin.on_request
    def middleware1():
        pass
    assert isinstance(temp_mixin._future_middleware[0].middleware, type(middleware1))
    assert temp_mixin._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-21 23:10:18.373750
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin._future_middleware == [] and len(middleware_mixin._future_middleware) == 0


# Generated at 2022-06-21 23:10:21.254037
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    instance = MiddlewareMixin()
    assert instance.on_request


# Generated at 2022-06-21 23:10:23.112117
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class A:
        def __init__(self):
            self._future_middleware = []
    
    mm = MiddlewareMixin()

    print(mm.on_response)
    print(mm.on_response())
    mm.on_response(A)



# Generated at 2022-06-21 23:10:23.707797
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-21 23:10:30.715056
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware

    app = Sanic()

    assert app._future_middleware == []

    @app.on_request
    def middleware_test(request):
        pass

    assert isinstance(app._future_middleware[0], FutureMiddleware)

    assert app._future_middleware[0].middleware == middleware_test
    assert app._future_middleware[0].attach_to == "request"



# Generated at 2022-06-21 23:10:39.433021
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    args = (1,2);
    kwargs = {'a':3,'b':4}
    mixin = MiddlewareMixin(*args, **kwargs)
    MiddlewareMixin._future_middleware = []
    assert len(MiddlewareMixin._future_middleware) == 0
    mixin.on_request()(lambda *a, **k:None)(*args, **kwargs)
    assert len(MiddlewareMixin._future_middleware) == 1
    return


# Generated at 2022-06-21 23:10:42.028583
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response.__name__ == 'on_response'

# Generated at 2022-06-21 23:10:42.837643
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert True

# Generated at 2022-06-21 23:10:53.524802
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():

    future_middleware1 = FutureMiddleware("middleware1", "request")
    future_middleware2 = FutureMiddleware("middleware2", "request")
    future_middleware3 = FutureMiddleware("middleware3", "response")
    future_middleware4 = FutureMiddleware("middleware3", "response")
    future_middleware5 = FutureMiddleware("middleware3", "response")
    future_middleware6 = FutureMiddleware("middleware3", "response")
    future_middleware7 = FutureMiddleware("middleware4", "response")


# Generated at 2022-06-21 23:11:00.561885
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.models.middleware import MiddlewareMixin
    from sanic.models.futures import FutureMiddleware

    app = Sanic()

    @app.middleware
    def example_request_middleware(request):
        request['request_middleware'] = True

    @app.middleware('response')
    def example_response_middleware(request, response):
        response['response_middleware'] = True

    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == example_request_middleware
    assert app._future_middleware[0].attach_to == 'request'
    assert app._future_middleware[1].middleware == example_response_middleware
    assert app._future_middleware[1].attach_to

# Generated at 2022-06-21 23:11:09.764859
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()

    async def request_middleware(request):
        pass

    async def response_middleware(request, response):
        pass

    app.middleware(request_middleware)
    app.middleware(response_middleware, "response")

    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[1].middleware == response_middleware

# Generated at 2022-06-21 23:11:22.402051
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.views import HTTPMethodView

    app = Sanic("test_MiddlewareMixin_on_request")

    class MyView(HTTPMethodView):
        def __init__(self):
            self.called = False

        def get(self, request):
            self.called = True

    my_view = MyView.as_view()

    @app.get("/")
    async def handler(request):
        return response.json({"test": True})

    @app.on_request
    async def on_request(request):
        return response.json({"test": True})

    request, response = app.test_client.get("/")
    assert response.json == {"test": True}
    assert on_request.called is True    



# Generated at 2022-06-21 23:11:28.770024
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    app = Sanic(__name__)

    class MyMiddleware:
        def __init__(self, request=None):
            pass

    app.on_request(MyMiddleware)

    assert app._future_middleware[0].middleware_func == MyMiddleware
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].middleware_name == "MyMiddleware"

# Generated at 2022-06-21 23:11:40.773658
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    test_arg1 = []
    test_arg2 = []
    test_arg3 = []
    test_arg4 = []
    test_arg5 = []
    test_arg6 = []
    test_arg7 = []
    test_arg8 = []
    test_arg9 = []
    test_arg10 = []
    test_arg11 = []
    test_arg12 = []
    test_arg13 = []
    test_arg14 = []
    test_arg15 = []
    test_arg16 = []
    test_arg17 = []
    test_arg18 = []
    test_arg19 = []
    test_arg20 = []
    test_arg21 = []
    test_arg22 = []
    test_arg23 = []
    test_arg24 = []
    test_arg25 = []

# Generated at 2022-06-21 23:11:45.333993
# Unit test for method on_request of class MiddlewareMixin

# Generated at 2022-06-21 23:11:47.981482
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewareMixin = MiddlewareMixin()
    assert middlewareMixin._future_middleware == []   # FutureMiddleware are added to this list

# Generated at 2022-06-21 23:11:58.917138
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class cls(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            assert 1 == 1

    a = cls()
    b = a.middleware(on_request=1)
    assert b == 1
    b = a.middleware(on_response=2)
    assert b == 2
    b = a.middleware(3)
    assert b == 3
    b = a.on_request(on_request=4)
    assert b == 4
    b = a.on_response(on_response=5)
    assert b == 5



# Generated at 2022-06-21 23:12:10.122778
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from Sanic import Sanic
    app = Sanic()

    # Test case: call on_request as method
    @app.on_request()
    def test_middleware1(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware() == test_middleware1
    assert app._future_middleware[0].attach_to == 'request'

    # Test case: call on_request as decorator
    @app.on_request
    def test_middleware2(request):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware() == test_middleware2
    assert app._future_middleware[1].attach_to == 'request'

# Generated at 2022-06-21 23:12:11.040987
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-21 23:12:15.613611
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Setup
    from sanic.app import Sanic
    app = Sanic()

    # Exercise
    middleware = app.on_response()

    # Verify
    assert middleware.__name__ == 'on_response'
    assert middleware.__closure__[1].cell_contents == 'response'
    assert middleware.__closure__[0].cell_contents == app


# Generated at 2022-06-21 23:12:20.451325
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.helpers import get_function_name_or_class_name

    assert MiddlewareMixin.on_request is not Sanic.on_request
    assert get_function_name_or_class_name(MiddlewareMixin.on_request) == 'on_request'
    assert get_function_name_or_class_name(Sanic.on_request) is None


# Generated at 2022-06-21 23:12:27.061690
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Main(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    main_test = Main()

    # define a middleware
    def middleware(request):
        pass

    # register the middleware
    main_test.middleware(middleware, attach_to="request")

    # check whether the registered middleware is correct
    assert main_test._future_middleware[0] == FutureMiddleware(middleware, "request")


# Generated at 2022-06-21 23:12:29.787504
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class AppTest(MiddlewareMixin):
        pass
    app = AppTest()
    assert len(app._future_middleware) == 0

# Inject middleware on the instance of a class

# Generated at 2022-06-21 23:12:30.585969
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass

# Generated at 2022-06-21 23:12:37.740276
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()

# Generated at 2022-06-21 23:12:39.495146
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []


# Generated at 2022-06-21 23:12:51.142797
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestObject(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_obj = TestObject()
    assert test_obj._future_middleware == []

    @test_obj.middleware('request', apply=False)
    def middleware(request):
        return request
    assert test_obj._future_middleware == [FutureMiddleware(middleware, attach_to='request')]

    @test_obj.middleware(apply=False)
    def middleware(request):
        return request

# Generated at 2022-06-21 23:13:02.499575
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.response import text
    from sanic import Sanic
    app = Sanic()

    async def custom_middleware(request):
        return text("This is a middleware")

    assert app._future_middleware == []
    # Calling app.middleware(custom_middleware) will add
    # the custom_middleware to the future middleware list
    app.middleware(custom_middleware)
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == custom_middleware
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].app == app

    # Call app.middleware with a custom attach_to
    app.middleware(custom_middleware, attach_to="response")
   

# Generated at 2022-06-21 23:13:04.642123
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin = MiddlewareMixin()
    assert mixin._future_middleware == []


# Generated at 2022-06-21 23:13:08.447138
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    P = MiddlewareMixin()
    assert isinstance(P, MiddlewareMixin) and isinstance(P, object)
    assert P._future_middleware == []

test_MiddlewareMixin()


# Generated at 2022-06-21 23:13:15.643198
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Server(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    @Server.on_request
    async def wrt (request):
        pass

    assert len(Server._future_middleware) == 1
    assert Server._future_middleware[0].middleware == wrt

# Generated at 2022-06-21 23:13:20.076153
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = MiddlewareMixin()
    @app.on_request()
    def on_request(request):
        return "execute before response"
    assert app._future_middleware[0].to_execute == "execute before response"
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-21 23:13:24.355281
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    @MiddlewareMixin.on_request()
    def on_request(request):
        return request

    assert on_request is on_request



# Generated at 2022-06-21 23:13:28.045106
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic

    sanic = Sanic("TestMiddlewareMixin")
    assert sanic._future_middleware == []


# Generated at 2022-06-21 23:13:50.998054
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    assert m.on_request is not None
    assert m.on_request() is not None
    assert m.on_request() is not None
    assert m.on_request(1) is not None
    assert m.on_request(lambda: True) is not None
    assert m.on_request(callable=1) is not None
    assert m.on_request('request') is not None
    assert m.on_request('response') is not None
    assert m.on_request('request', 'response') is not None
    assert m.on_request()('response') is not None
    assert m.on_request('request')(lambda: True) is not None


# Generated at 2022-06-21 23:14:02.753955
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import sys
    import os
    import pytest
    curPath = os.path.abspath(os.path.dirname(__file__))
    rootPath = os.path.split(curPath)[0]
    sys.path.append(rootPath)

    from src.core.Request import Request
    from src.core.Response import Response
    from src.core.Application import Application
    from src.core.AppBundle import AppBundle

    from src.core.Message import Message
    from src.core.Executor import Executor
    from src.core.Config import Config

    from src.middleware.MiddlewareMixin import MiddlewareMixin
    from src.middleware.Middleware import Middleware

    from src.core.Log import Log

    def on_request_handler():
        print("on_request_handler")


# Generated at 2022-06-21 23:14:07.930014
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    from sanic.views import HTTPMethodView

    app = Sanic("test_MiddlewareMixin_middleware")

    def middleware(request):
        request["middleware"] = True
        return request

    @app.middleware(middleware)
    @app.route("/0")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/0")
    assert request["middleware"]

    class MyView(HTTPMethodView):
        @app.middleware("request")
        async def get(self, request):
            return text("OK")

    request, response = app.test_client.get("/1")
    assert request["middleware"]

# Generated at 2022-06-21 23:14:16.033412
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class FakeMiddleware(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    mw = FakeMiddleware()
    assert mw.on_response()(lambda x: x) in mw._future_middleware


# Generated at 2022-06-21 23:14:19.757806
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class A(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    a = A()
    assert len(a._future_middleware) == 0

    return a

# Generated at 2022-06-21 23:14:21.587036
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware is not None

# Generated at 2022-06-21 23:14:27.329418
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    test_mixin = MiddlewareMixin()
    # 'MiddlewareMixin' object has no attribute '_future_middleware'
    assert hasattr(test_mixin, '_future_middleware')
    # test if it is the right type
    assert isinstance(test_mixin._future_middleware, list)

# Generated at 2022-06-21 23:14:29.695263
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middle = MiddlewareMixin()
    assert (middle._future_middleware == [])
    assert (callable(middle._apply_middleware) == False)


# Generated at 2022-06-21 23:14:40.906572
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Mock(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.mw_func = None
            self.mw_place = None

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.mw_func = middleware.middleware
            self.mw_place = middleware.attach_to

    m = Mock()

    def mw_func():
        pass

    m.on_request(mw_func)()

    assert m.mw_func is mw_func
    assert m.mw_place == "request"



# Generated at 2022-06-21 23:14:51.189214
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    m = TestMiddlewareMixin()

    @m.middleware
    def on_request(request):
        return "some response"
    assert m._future_middleware[0].middleware == on_request
    assert m._future_middleware[0].attach_to == "request"
    assert m._future_middleware[0].middleware(None) == "some response"

    @m.middleware('response')
    def on_response(request, response):
        return "some response"
    assert m._future_middleware[1].middleware == on_response
    assert m._future_middleware[1].attach_to == "response"
    assert m._future_middle

# Generated at 2022-06-21 23:15:19.135459
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    testMiddlewareMixin = MiddlewareMixin()
    assert testMiddlewareMixin is not None

# Generated at 2022-06-21 23:15:20.891302
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass



# Generated at 2022-06-21 23:15:29.591555
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.models.futures import FutureMiddleware
    from sanic.response import json
    from sanic.request import Request

    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass

    t = TestMiddlewareMixin()
    @t.on_response
    def func1(request, response):
        response.body = '{"middleware":"response"}'

    @t.on_response
    def func2():
        pass

    assert isinstance(t._future_middleware[0], FutureMiddleware)
    assert t._future_middleware[0].middleware == func1
    assert t._future_middleware[0].attach_to == 'response'

    assert isinstance(t._future_middleware[1], FutureMiddleware)

# Generated at 2022-06-21 23:15:35.256834
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware("request")
    async def request_middleware(request: Request):
        return HTTPResponse("Hello", status=200)

    @app.middleware("response")
    async def response_middleware(request: Request, response: HTTPResponse):
        response = HTTPResponse("Hello", status=200)

    @app.middleware  # noqa
    async def default_middleware(request: Request):
        return HTTPResponse("Hello", status=200)


# Generated at 2022-06-21 23:15:46.641644
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic("test_MiddlewareMixin_middleware")

    # Testing calls with 'request' argument
    @app.middleware
    def test_middleware1(request):
        pass

    assert len(app._future_middleware) == 1

    @app.middleware("request")
    def test_middleware2(request):
        pass

    assert len(app._future_middleware) == 2

    @app.middleware("response")
    def test_middleware3(request, response):
        pass

    assert len(app._future_middleware) == 3

    # Testing calls without 'request' argument
    @app.middleware
    def test_middleware4():
        pass

    assert len(app._future_middleware) == 4


# Generated at 2022-06-21 23:15:47.454523
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert True

# Generated at 2022-06-21 23:15:52.711006
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    app = Sanic(__name__)
    app.middleware(middleware)
    assert app._future_middleware == [FutureMiddleware(middleware, "request")]


# Generated at 2022-06-21 23:15:54.848465
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.application import Sanic

    app = Sanic()
    assert app._future_middleware == []

# Generated at 2022-06-21 23:15:56.260935
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-21 23:16:08.019463
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from dataclasses import dataclass
    from sanic.models.futures import FutureMiddleware
    import sanic
    @dataclass
    class MiddlewareMixinTest(MiddlewareMixin):
        _future_middleware: List[FutureMiddleware] = []
        _apply_middleware: object = object()

    def dummy_middleware_func(request):
        return request

    dummy_middleware = dummy_middleware_func
    mmt = MiddlewareMixinTest()

    middleware_return = mmt.middleware(middleware_or_request=dummy_middleware, attach_to="request", apply=True)
    assert middleware_return == dummy_middleware_func
    assert mmt._future_middleware == [FutureMiddleware(attach_to="request", middleware=middleware_return)]
   

# Generated at 2022-06-21 23:17:10.636799
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
  '''
  This test case is to test whether on_request method works well
  '''
  middlewareMixin = MiddlewareMixin()
  middlewareMixin.on_request(middleware)


# Generated at 2022-06-21 23:17:14.194496
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = Sanic('test', load_env='test')
    assert app.on_request() == partial(app.middleware, attach_to='request')


# Generated at 2022-06-21 23:17:19.685842
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewaremixin = MiddlewareMixin()
    assert middlewaremixin._future_middleware == []
    #assert middlewaremixin.middleware("something") == None
    #assert middlewaremixin.on_request("something") == None
    #assert middlewaremixin.on_response("something") == None

# Generated at 2022-06-21 23:17:24.540497
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    class TestMiddleware1:
        def __init__(self, request):
            pass

    class TestMiddleware2:
        def __init__(self, response):
            pass

    # Test case 1
    test_obj1 = TestClass()
    test_obj1.on_response(TestMiddleware1)
    assert isinstance(
        test_obj1._future_middleware[0].middleware, TestMiddleware1
    )
    assert test_obj1._future_middleware

# Generated at 2022-06-21 23:17:33.986286
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MixinTest(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__()

        def _apply_middleware(self, middleware):
            pass

    app = MixinTest()

    @app.middleware('request')
    def test_request_middleware(request):
        pass

    @app.middleware('response')
    def test_response_middleware(request, response):
        pass

    assert len(app._future_middleware) == 2

# Generated at 2022-06-21 23:17:44.116728
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.server import SanicServer

    async def middleware_factory(*args, **kwargs):
        """
        Just return a no op function
        """

        return lambda x: x

    sanic = MiddlewareMixin()

    sanic.middleware(middleware_factory)

    assert len(sanic._future_middleware) == 2

    # Test the partial function
    sanic.middleware(attach_to="request")(middleware_factory)
    assert len(sanic._future_middleware) == 3

    # Replace with our dummy server
    sanic.server = SanicServer()

    sanic.middleware(middleware_factory)
    assert len(sanic._future_middleware) == 4


# Generated at 2022-06-21 23:17:49.101891
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin')
    assert app._future_middleware == []
    assert isinstance(app, MiddlewareMixin)

# Generated at 2022-06-21 23:17:55.324282
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    # constructor test
    testMiddlewareMixin = TestMiddlewareMixin()
    assert testMiddlewareMixin._future_middleware == []


# Generated at 2022-06-21 23:18:00.169955
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    fn = lambda x: x
    m.on_request(fn)
    assert len(m._future_middleware) == 1
    assert m._future_middleware[0].middleware == fn



# Generated at 2022-06-21 23:18:06.892673
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.testing import HOST, PORT
    app = Sanic(__name__)
    @app.middleware('request')
    async def middleware_1(request):
        request['mw_1'] = 'middleware'

    @app.middleware('response')
    async def middleware_2(request, response):
        response.headers['mw_2'] = 'middleware'

    @app.middleware('request')
    async def middleware_3(request):
        request['mw_3'] = 'middleware'

    @app.middleware('response')
    async def middleware_4(request, response):
        response.headers['mw_4'] = 'middleware'
