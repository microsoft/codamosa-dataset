

# Generated at 2022-06-21 23:09:17.840582
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MyApp(MiddlewareMixin):
        pass
    app = MyApp()
    assert app._future_middleware==[]
    def mw_test(request, response):
        pass
    register_middleware=app.middleware(mw_test)
    assert app._future_middleware!=[]

# Generated at 2022-06-21 23:09:18.849279
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass


# Generated at 2022-06-21 23:09:22.260850
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()
    assert MiddlewareMixin(1)
    # assert MiddlewareMixin(*[])
    # assert MiddlewareMixin(**{})
    assert hasattr(MiddlewareMixin(), "_future_middleware")

# Generated at 2022-06-21 23:09:28.395053
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.model.sanic import Sanic
    app = Sanic("test_MiddlewareMixin_on_request")

    @app.on_request
    def my_middleware(request, response):
        pass

    # Test if on_request reflect arguments' order of middleware method
    assert app._future_middleware[0].attach_to == "request"

# Generated at 2022-06-21 23:09:37.826818
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()
    assert len(app._future_middleware) == 0

    @app.middleware
    def print_on_request(request):
        pass

    assert len(app._future_middleware) == 1

    @app.middleware('response')
    def print_on_request(request):
        pass

    assert len(app._future_middleware) == 2



# Generated at 2022-06-21 23:09:40.607485
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class EmptyClass(MiddlewareMixin):
        pass
    EmptyClass()

# Generated at 2022-06-21 23:09:47.127297
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    # This is the middleware function

    async def hello(request):
        return response.text("hello")
    # Call the app.middleware() decorator.
    app.middleware(hello)
    assert app._future_middleware[0].middleware == hello
    assert app._future_middleware[0].attach_to == 'request'

# Generated at 2022-06-21 23:09:58.332457
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    r = MiddlewareMixin()

    @r.middleware('response')
    def middleware_middleware(request):
        print(request)
    middleware_middleware()

    @r.on_response()
    def on_response_middleware(request):
        print(request)
    on_response_middleware()

    @r.on_request()
    def on_request_middleware(request):
        print(request)
    on_request_middleware()


# Generated at 2022-06-21 23:10:07.850184
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestClass(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass

    test_class: TestClass = TestClass()
    test_class.middleware(object())
    assert len(test_class._future_middleware) == 1
    test_class.middleware(object())
    assert len(test_class._future_middleware) == 2



# Generated at 2022-06-21 23:10:16.311550
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Test with callable
    def middleware_request(request):
        pass

    mm = MiddlewareMixin()
    new = mm.on_request(middleware=middleware_request)
    assert new == middleware_request

    # Test with partial
    new = mm.on_request(middleware=None)
    assert new.func == mm.middleware
    assert new.keywords['attach_to'] == 'request'

# Generated at 2022-06-21 23:10:25.695975
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    a = MiddlewareMixin()
    # These lines will raise if it is not a function
    response = a.on_response(middleware=None)
    b = response(None)
    b(None, None)  # Will raise if it is not a function
    return True


# Generated at 2022-06-21 23:10:28.592511
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mw_mixin = MiddlewareMixin()
    future_middleware = mw_mixin._future_middleware
    assert future_middleware == []

# Generated at 2022-06-21 23:10:37.501232
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class tester(MiddlewareMixin):
        def __init__(self, *args, **kwargs):

            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware = middleware

    tester.middleware('test')
    assert tester.middleware.__name__ == 'test'


# Generated at 2022-06-21 23:10:40.158587
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # create an object of MiddlewareMixin
    mw = MiddlewareMixin()

    # check _future_middleware of object mw
    assert mw._future_middleware == []


# Generated at 2022-06-21 23:10:43.672204
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic

    app = Sanic()
    assert isinstance(app, MiddlewareMixin)


# Generated at 2022-06-21 23:10:46.833046
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    MiddlewareMixin_instance = MiddlewareMixin()
    assert isinstance(MiddlewareMixin_instance, MiddlewareMixin)


# Generated at 2022-06-21 23:10:51.448947
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic()
    @app.middleware
    async def on_response(request, response):
        response.text = "Connection Lost"
    app.run(host="0.0.0.0", port=8000)

# Generated at 2022-06-21 23:10:51.969424
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert True

# Generated at 2022-06-21 23:10:55.990294
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic

    app = Sanic(__name__)

    @app.on_response
    def on_response(request, response):
        if response.status == 404:
            response.text = "custom output"

    request, response = app.test_client.get("/")
    assert response.status == 404
    assert response.text == "custom output"

# Generated at 2022-06-21 23:10:58.340600
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    for m in MiddlewareMixin:
        assert m.on_response('response')



# Generated at 2022-06-21 23:11:11.247705
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware): pass

    test_mixin = TestMiddlewareMixin()
    middleware = test_mixin.on_request()
    # TODO: find out what's the correct way of getting the return value in a test. 
    #   currently trying to get it by calling middleware, but it doesn't seem to be the right way
    middleware()

# Generated at 2022-06-21 23:11:22.462071
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import sanic
    from sanic.models.futures import FutureMiddleware

    class App(MiddlewareMixin):
        def __init__(self):
            super(App, self).__init__()
            self.middleware_queue = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware_queue.append(middleware)

    async def test_middleware(request):
        return sanic.response.text('OK')

    app = App()
    app.on_request(test_middleware)
    assert app.middleware_queue[-1].middleware == test_middleware
    assert app.middleware_queue[-1].attach_to == 'request'


# Generated at 2022-06-21 23:11:29.950120
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Test:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

    class App(Test, MiddlewareMixin):
        pass

    app = App()

    # on_request is decorator function
    @app.on_request
    def foo():
        pass

    assert len(app._future_middleware) == 1

    # on_request, middleware is not callable
    @app.on_request
    def bar():
        pass

    assert len(app._future_middleware) == 2

# Generated at 2022-06-21 23:11:36.899620
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    import unittest

    class MiddlewareMixinTestCase(unittest.TestCase):
        def test_mixin_instantiation_default_parameters(self):
            from sanic import Sanic

            app = Sanic('test_mixin_instantiation_default_parameters')
            self.assertIsInstance(app, MiddlewareMixin)

# Generated at 2022-06-21 23:11:39.048083
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert isinstance(m._future_middleware, List)
    assert len(m._future_middleware) == 0


# Generated at 2022-06-21 23:11:50.921897
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
	from sanic.models.middleware import MiddlewareMixin
	from sanic.models.futures import FutureMiddleware
	# create the class
	middleware_mixin = MiddlewareMixin()
	# call the method
	result = middleware_mixin.on_request()
	# check the type of the result
	assert isinstance(result, types.FunctionType)
	# check the number of arguments
	assert len(inspect.signature(result).parameters) == 1
	# check the number of the future_middleware
	assert len(middleware_mixin._future_middleware) == 0
	# call the function
	result = result(middleware = lambda : 1)
	# check the type of the result
	assert isinstance(result, types.FunctionType)
	# check the number of the future_middleware

# Generated at 2022-06-21 23:11:54.403365
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            assert middleware
    tmm = TestMiddlewareMixin()
    def middleware(request):
        assert request
    tmm.on_response(middleware)

# Generated at 2022-06-21 23:11:55.427592
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()._future_middleware == []


# Generated at 2022-06-21 23:11:56.992290
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
	mixin = MiddlewareMixin(1,2,3,4,5)
	assert mixin._future_middleware == []


# Generated at 2022-06-21 23:11:58.330526
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    assert mm._future_middleware == []


# Generated at 2022-06-21 23:12:16.484165
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from unittest.mock import Mock
    from sanic.router import ROUTES
    from sanic.request import Request
    from sanic.response import HTTPResponse

    ROUTES.clear()

    class AddHeaderMiddleware:
        async def response(self, request, response):
            response.headers["added-by-middleware"] = "yup"
            return response

    class Request(Request):
        def __init__(self):
            super().__init__(url_bytes=b"/", headers={}, version="1.1", method="GET")

    class MiddlewareMixinTester(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, future_middleware):
            self.applied = True


# Generated at 2022-06-21 23:12:18.202099
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    try:
        MiddlewareMixin()
        assert True
    except:
        assert False, "MiddlewareMixin should be initialized successfully"

# Generated at 2022-06-21 23:12:19.172723
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert callable(MiddlewareMixin.on_request())


# Generated at 2022-06-21 23:12:23.951257
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class App:
        pass
    app = App()
    app.middleware = MiddlewareMixin.middleware

    @app.middleware()
    def mw(request):
        print('mw')

    assert len(app._future_middleware) == 0

    @app.on_response()
    def mw_response(request, response):
        print('mw_response')

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == mw_response
    assert app._future_middleware[0].attach_to == 'response'

    @app.on_response
    def mw_response_2(request, response):
        print('mw_response_2')

    assert len(app._future_middleware) == 2
    assert app._future

# Generated at 2022-06-21 23:12:33.135569
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    # TODO: find a better way to test private attribute
    # @pytest.mark.parametrize("private_attr", ["_future_middleware"])
    # def test_private_attr(private_attr):
    #     assert getattr(MiddlewareMixin(), private_attr) == []

    # TODO: find a way to test abstract method _apply_middleware()
    # @pytest.mark.parametrize(
    #     "middleware", ['middleware', 'middleware_or_request']
    # )
    # def test_apply_middleware(middleware):
    #     with pytest.raises(NotImplementedError):
    #         MiddlewareMixin().apply_middleware(middleware)

   

# Generated at 2022-06-21 23:12:34.120038
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-21 23:12:36.131891
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():    
    assert MiddlewareMixin.on_request(MiddlewareMixin, None) == None


# Generated at 2022-06-21 23:12:37.886980
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    tmp = MiddlewareMixin()
    assert tmp._future_middleware == []


# Generated at 2022-06-21 23:12:40.058642
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    mw = MiddlewareMixin()
    @mw.on_response()
    def on_response(request, response):
        pass

# Generated at 2022-06-21 23:12:45.280095
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixinClass(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            self._future_middleware.append(middleware)

    @TestMiddlewareMixinClass.on_request
    def test_middleware(request):
        print('d')
        

# Generated at 2022-06-21 23:13:10.734996
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    assert TestMiddlewareMixin(1, 2, 3)


# Generated at 2022-06-21 23:13:12.084665
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass

# Generated at 2022-06-21 23:13:20.627799
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class DummyClass(MiddlewareMixin):
        def __init__(self, **kwargs):
            self.kwargs = kwargs
            super().__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    dummy_instance = DummyClass(key='value')
    assert dummy_instance.kwargs == {'key':'value'}
    assert hasattr(dummy_instance, '_future_middleware')
    assert len(dummy_instance._future_middleware) == 0

#TODO: Unit tests for the rest of the class.

# Generated at 2022-06-21 23:13:24.430229
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    print('Test MiddlewareMixin on_request: ')
    middleware_mixin = MiddlewareMixin()


# Generated at 2022-06-21 23:13:26.442013
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    app = MiddlewareMixin()
    assert app._future_middleware == []

# Generated at 2022-06-21 23:13:30.398599
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class T(MiddlewareMixin):
        def __init__(self):
            super().__init__()
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    @T.on_request()
    def request_middleware(request):
        pass

    assert T()._future_middleware[0]._middleware == request_middleware
    assert T()._future_middleware[0]._attach_to == "request"


# Generated at 2022-06-21 23:13:40.468563
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.models.middleware import MiddlewareMixin

    class MyClass(MiddlewareMixin):
        # @middleware not defined
        def f1(self):
            self.middleware("request")()

        def f2(self):
            self.middleware("response")()

    # on_request is not defined
    with pytest.raises(NotImplementedError):
        MyClass().f1

    # on_response is not defined
    with pytest.raises(NotImplementedError):
        MyClass().f2

# Generated at 2022-06-21 23:13:48.929350
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    @MiddlewareMixin.on_response(attach_to="response")
    def on_response(request, response):
        return response

    @MiddlewareMixin.on_response()
    def on_response(request, response):
        return response

    @MiddlewareMixin.on_response
    def on_response(request, response):
        return response

test_MiddlewareMixin_on_response()


# Generated at 2022-06-21 23:13:54.921647
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert isinstance(middleware_mixin, MiddlewareMixin) == True
    assert isinstance(middleware_mixin, object) == True
    assert middleware_mixin._future_middleware == []


# Generated at 2022-06-21 23:13:58.756946
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestClass(MiddlewareMixin):
        pass

    test_class = TestClass()

    assert test_class.on_request(middleware=None) is not None


# Generated at 2022-06-21 23:14:45.108989
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Server(MiddlewareMixin):
        pass

    server = Server()
    @server.on_response()
    def resp(request, response):
        print('ok')
    assert (server._future_middleware[0].middleware == resp)



# Generated at 2022-06-21 23:14:52.370132
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware_1(request):
        request['middleware1'] = 'request_middleware_1'

    @app.middleware('request')
    async def request_middleware_2(request):
        request['middleware1'] = 'request_middleware_2'

    @app.middleware('response')
    async def response_middleware_1(request, response):
        response['middleware1'] = 'response_middleware_1'
        return response

    @app.middleware('response')
    async def response_middleware_2(request, response):
        response['middleware1'] = 'response_middleware_2'
        return response


# Generated at 2022-06-21 23:15:01.473471
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # test case 1
    # NotImplementedError: _apply_middleware
    middleware_mixin = MiddlewareMixin()
    with pytest.raises(NotImplementedError):
        middleware_mixin.middleware()
    # test case 2
    # TypeError: middleware() missing 1 required positional argument: 'middleware_or_request'
    with pytest.raises(TypeError):
        middleware_mixin.middleware(1)
    # test case 3
    # TypeError: middleware() got an unexpected keyword argument 'middleware_or_request'
    with pytest.raises(TypeError):
        middleware_mixin.middleware(middleware_or_request=1)
    # test case 4
    # TypeError: middleware() missing 1 required positional argument: 'attach_to'


# Generated at 2022-06-21 23:15:03.016218
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert False


# Generated at 2022-06-21 23:15:10.913741
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            MiddlewareMixin.__init__(self)
            self._future_middleware = []

        def _apply_middleware(self, middleware):
            pass
            # print('apply middleware')

    # case 1
    testMiddlewareMixin = TestMiddlewareMixin()

# Generated at 2022-06-21 23:15:14.033439
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin.on_response(middleware="middleware")

# Generated at 2022-06-21 23:15:16.571293
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin = MiddlewareMixin()
    assert mixin._future_middleware == []


# Generated at 2022-06-21 23:15:21.028149
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class testMiddleware(MiddlewareMixin):
        def on_request(self):
            print("at_request is working!")

    t = testMiddleware()
    t.middleware(t.on_request)

# Generated at 2022-06-21 23:15:25.878747
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic()

    class TestMiddleware:
        def __init__(self, request):
            self.request = request

        async def __call__(self, request):
            return request

    @app.middleware
    def test_middleware(request):
        return request

    @app.middleware('response')
    async def test_response_middleware(request):
        return request

    assert app.middleware_instance is True
    assert app.middlewares == [TestMiddleware, TestMiddleware]

# Generated at 2022-06-21 23:15:27.819385
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    MiddlewareMixin.on_response(MiddlewareMixin)

# Generated at 2022-06-21 23:17:01.110570
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # given
    app = Sanic()

    # when
    @app.on_request
    def add_user(request):
        request.user = 'user'

    # then
    request, response = app.test_client.get('/')
    assert response.status == 200
    assert request.user == 'user'



# Generated at 2022-06-21 23:17:04.360554
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewareMixin = MiddlewareMixin()
    assert str(middlewareMixin) == '<sanic.models.MiddlewareMixin object at 0x000001CCB06F7790>'
    assert middlewareMixin._future_middleware == []


# Generated at 2022-06-21 23:17:15.879737
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.log import log
    from sanic.response import json

    # Define a test class that derives from Sanic, and uses MiddlewareMixin
    class TestClass(Sanic, MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            Sanic.__init__(self, *args, **kwargs)
            MiddlewareMixin.__init__(self, *args, **kwargs)

    # Create the test object
    app = TestClass()

    # Define the middleware function
    @app.on_response
    def test_middleware(request, response):
        response.body += b'<html><body>Hello, World!</body></html>'
        return response

    # Define the test function

# Generated at 2022-06-21 23:17:25.692470
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from unittest import mock, TestCase
    from sanic.models.futures import FutureMiddleware

    class TargetClass(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_case = TestCase()
    obj = TargetClass()

    # apply==True
    @obj.middleware(attach_to='request')
    def middleware1(request):
        return request

    test_case.assertIsInstance(obj._future_middleware[0], FutureMiddleware)
    test_case.assertEqual(obj._future_middleware[0].middleware, middleware1)
    test_case.assertEqual(obj._future_middleware[0].attach_to, 'request')

# Generated at 2022-06-21 23:17:29.285129
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_test = MiddlewareMixin(["test_middleware"])
    assert middleware_test._future_middleware == []


# Generated at 2022-06-21 23:17:38.811482
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # See re: testing Sanic source
    # https://github.com/huge-success/sanic/issues/1374
    class MyMiddleware(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, future_middleware: FutureMiddleware):
            print(future_middleware)

    def first(request):
        print(f"first: {request}")

    def second(request):
        print(f"second: {request}")

    app = MyMiddleware()
    app.on_request(first)
    app.on_request(second)
    # expected:
    # {'middleware':

# Generated at 2022-06-21 23:17:39.702648
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass

# Generated at 2022-06-21 23:17:43.472503
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin')
    assert isinstance(app, MiddlewareMixin)

# Generated at 2022-06-21 23:17:47.864052
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m = MiddlewareMixin()
    assert m
    f = m.middleware
    assert f
    f(partial(print, "test"))


# Generated at 2022-06-21 23:17:53.887485
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
	mymixin = MiddlewareMixin()
	@mymixin.middleware
	def mymiddleware(request):
		print('request recieved')
		return None
		
	@mymixin.middleware
	def mymiddleware(request):
		print('response sent')
		return None

		