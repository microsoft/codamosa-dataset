

# Generated at 2022-06-21 23:09:24.074512
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    """Testing method middleware of class MiddlewareMixin"""

    # Arrange
    from sanic import Sanic

    app = Sanic()

    # Act
    # Assert
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None


# Generated at 2022-06-21 23:09:32.576242
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    path = '/test/test_on_request'
    async def test_on_request(request):
        return json({"test":"test_on_request"})

    from sanic import Sanic
    app = Sanic('test_on_request')
    app.add_route(test_on_request, path, methods=['GET', 'POST'])
    app.on_request(lambda request: request)
    request, response = app.test_client.get(path)
    assert response.json == {"test":"test_on_request"}

    request, response = app.test_client.post(path)
    assert response.json == {"test":"test_on_request"}


# Generated at 2022-06-21 23:09:38.435217
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A:
        def __init__(self, *args, **kwargs):
            self._future_middleware = []
            self.a = args
            self.kwargs = kwargs

    A.__bases__ = (MiddlewareMixin,)

    a = A()

    m = a.middleware("q")
    m(1,2,3)
    m("w", "e")
    m("e")

    assert a._future_middleware == [
        FutureMiddleware(1, "q"),
        FutureMiddleware("w", "q"),
        FutureMiddleware("e", "q")
    ]


# Generated at 2022-06-21 23:09:44.173601
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    @Sanic.middleware
    def middleware(request):
        print(request)
        return request

    assert callable(middleware) == True
    print(middleware)


# Generated at 2022-06-21 23:09:47.516782
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from unittest import mock
    from unittest.mock import MagicMock

    middleware_mixin = MiddlewareMixin()
    wrapped_middleware = middleware_mixin.on_request(MagicMock())

    assert wrap

# Generated at 2022-06-21 23:09:53.046464
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class _MiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            return middleware

    _MiddlewareMixin().middleware(lambda: None)

# Generated at 2022-06-21 23:10:00.261817
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic("test_MiddlewareMixin_on_response")
    async def handler(request):
        return text("OK")

    @app.middleware
    async def print_on_request(request):
        print("before request")

    @app.middleware('request')
    async def print_on_request(request):
        print("before request")

    @app.on_response
    async def print_on_response(request, response):
        print("after response")

    @app.on_response('request')
    async def print_on_response(request, response):
        print("after response")

    app.add_route(handler, '/')

    return app


# Generated at 2022-06-21 23:10:03.019832
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
  app = MiddlewareMixin()
  @app.middleware('startup')
  def sample_middleware(request):
    return request
  @app.on_response('shutdown')
  def sample_middleware(request):
    return request
  @app.middleware('request')
  def sample_middleware(request):
    return request
  @app.middleware('websocket')
  def sample_middleware(request):
    return request


# Generated at 2022-06-21 23:10:05.144158
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # TODO: Finish this unit test
    assert False


# Generated at 2022-06-21 23:10:08.810660
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class App(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    app = App()
    app.on_response(lambda x: x)

# Generated at 2022-06-21 23:10:13.561737
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    app = MiddlewareMixin()
    assert isinstance(app, MiddlewareMixin)
    assert app._future_middleware == []


# Generated at 2022-06-21 23:10:18.518188
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixinClass(MiddlewareMixin):
        def __init__(self):
            super(TestMiddlewareMixinClass, self).__init__()

    assert TestMiddlewareMixinClass().on_request() == partial(TestMiddlewareMixinClass().middleware, attach_to='request')


# Generated at 2022-06-21 23:10:29.251378
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    from sanic.models.middleware import MiddlewareMixin
    from sanic.models.futures import FutureMiddleware

    class Middleware(MiddlewareMixin):
        pass

    middleware = Middleware()

    @middleware.on_request
    def test(request):
        return request

    assert isinstance(middleware._future_middleware[0], FutureMiddleware)
    assert middleware._future_middleware[0]._attach_to == 'request'
    assert callable(middleware._future_middleware[0]._middleware)



# Generated at 2022-06-21 23:10:32.235527
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    a = MiddlewareMixin
    assert a == MiddlewareMixin


# Generated at 2022-06-21 23:10:40.674985
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()

    test_MiddlewareMixin = TestMiddlewareMixin()

    # test with parameter middleware
    @test_MiddlewareMixin.middleware
    async def test_middleware(request):
        pass

    expected = "test_middleware"

    actual = test_MiddlewareMixin._future_middleware[0].middleware.__name__

    assert expected == actual
    assert len(test_MiddlewareMixin._future_middleware) == 1



# Generated at 2022-06-21 23:10:46.832950
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = Sanic("MiddlewareMixin")
    @app.on_request
    def on_request(request):
        on_request.called = True
    request = Request("", app)
    app._run_request_middleware(request)
    assert on_request.called == True


# Generated at 2022-06-21 23:10:51.940147
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.blueprints import Blueprint
    from sanic.router import Router

    blueprint = Blueprint("test_blueprint", url_prefix="/test_blueprint")
    router = Router([])
    router.register(blueprint)
    router._apply_all_middleware()
    assert blueprint.middleware_stack[0].middleware == router.middleware_stack[0].middleware

# Generated at 2022-06-21 23:10:59.578064
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class BaseApp:
        def __init__(self):
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

        def middleware(self, middleware_or_request, attach_to="request"):
            def register_middleware(middleware, attach_to="request"):
                future_middleware = FutureMiddleware(middleware, attach_to)
                self._future_middleware.append(future_middleware)
                self._apply_middleware(future_middleware)
                return middleware

            if callable(middleware_or_request):
                return register_middleware(
                    middleware_or_request, attach_to=attach_to
                )

# Generated at 2022-06-21 23:11:01.944905
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    Sanic.on_request(Sanic, None)


# Generated at 2022-06-21 23:11:09.567323
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_on_response')
    # a.on_response(c)
    def c(request, response):
        pass
    app.on_response(c)
    # a.on_response()(c)
    @app.on_response()
    def d(request, response):
        pass


# Generated at 2022-06-21 23:11:22.100008
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic

    app = Sanic('test')

    # create
    @app.on_response
    def handler(request, response):
        pass

    assert len(app._future_middleware) == 1

    # update
    @app.on_response
    def handler(request, response):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == handler

    # delete
    app._future_middleware = []

    assert len(app._future_middleware) == 0

# Generated at 2022-06-21 23:11:29.648710
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic(__name__)

    app.on_response(lambda request, response: print(request), attach_to="response")
    # app.on_response(middleware_or_request = lambda request, response: print(request))

    @app.route("/")
    async def test(request):
        @app.on_response
        def on_response_decorator(request, response):
            print("middleware")

        return json({"test": True})

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.json == {"test": True}

    assert response.body == b"{\"test\": true}"



# Generated at 2022-06-21 23:11:39.161567
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    import os
    import random
    import string

    letters = string.ascii_lowercase
    dir_name = ''.join(random.choice(letters) for i in range(10))
    dir_name = '/tmp/' + dir_name
    try:
        os.mkdir(dir_name)
    except FileExistsError:
        pass

    from sanic import Sanic
    app = Sanic(__name__, root_path=dir_name)
    assert isinstance(app, Sanic)
    assert isinstance(app, MiddlewareMixin)

# Generated at 2022-06-21 23:11:50.949091
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.exceptions import SanicException

    @MiddlewareMixin.on_request
    def example_middleware(request):
        pass

    class Example(Sanic):
        __slots__ = ["middleware"]

        def __init__(self, *args, **kwargs):
            super(Example, self).__init__(*args, **kwargs)
            self.middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            super(Example, self)._apply_middleware(middleware)
            self.middleware.append(middleware)

    example = Example()
    example.middleware
    example.add_route(example_middleware, "/example")

    assert len(example.middleware) == 1

# Generated at 2022-06-21 23:11:53.028977
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class test_MiddlewareMixin(MiddlewareMixin):
        pass

    test = test_MiddlewareMixin()
    assert test._future_middleware == []

# Generated at 2022-06-21 23:12:01.482878
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.response import text
    from sanic.request import Request
    from sanic.router import Router
    app = Sanic()

    @app.route('/')
    async def test(request):
        return text('Test')

    @app.middleware
    async def handler_middleware(request):
        request.foo = 'bar'

    @app.middleware('request')
    async def main_middleware(request):
        request.foo = 'bar'

    request_object = Request('POST', '/', data={}, headers={})
    router = Router(app)
    request_handler = router.get(request_object)
    rv = request_handler.run_middleware(
        request_object,
        app.request_middleware)
    response = request_handler

# Generated at 2022-06-21 23:12:06.959195
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class test:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    a = MiddlewareMixin()
    a.on_request()
    a.on_request(test)



# Generated at 2022-06-21 23:12:10.374482
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    MiddlewareMixin_test_obj = MiddlewareMixin(None, None)
    assert MiddlewareMixin_test_obj.on_response(None) == partial(MiddlewareMixin_test_obj.middleware, attach_to="response")


# Generated at 2022-06-21 23:12:18.421089
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.response import json
    from sanic.views import HTTPMethodView
    from sanic.views import CompositionView

    class ExampleHTTPMethodView(MiddlewareMixin, HTTPMethodView):
        pass

    class ExampleCompositionView(CompositionView, MiddlewareMixin):
        pass

    @ExampleHTTPMethodView.on_request
    def middleware_example_method_1(request):
        return request

    @ExampleCompositionView.on_request
    def middleware_example_method_2(request):
        return request

    example_view_method = ExampleHTTPMethodView.as_view(
        ["HEAD", "GET"], "/example/url"
    )

# Generated at 2022-06-21 23:12:28.277398
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.response import text

    # Definition of the method of the class
    assert hasattr(MiddlewareMixin, "_apply_middleware")
    assert callable(MiddlewareMixin._apply_middleware)

    # Definition of the method of the class
    assert hasattr(MiddlewareMixin, "middleware")
    assert callable(MiddlewareMixin.middleware)

    # Definition of the method of the class
    assert hasattr(MiddlewareMixin, "on_request")
    assert callable(MiddlewareMixin.on_request)

    # Definition of the method of the class
    assert hasattr(MiddlewareMixin, "on_response")
    assert callable(MiddlewareMixin.on_response)

    # Definition of a class MiddlewareMixin 
    assert issub

# Generated at 2022-06-21 23:12:46.295037
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.models import Server
    from sanic.request import Request
    from sanic.response import BaseHTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import ServerError
    from sanic.response import json

    app = Sanic("MiddlewareMixin-on_request")

    def request_middleware(request):
        return json({"request": True})

    app.on_request(request_middleware)

    @app.route("/")
    async def route(request):
        return json({"request": False})

    app.request_middleware.append(request_middleware)

    request, response = app.test_client.get("/")

    # Check the status code is 200

# Generated at 2022-06-21 23:12:52.745395
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic(__name__)

    @app.route("/")
    async def handler(request):
        return json({"hello": "world"})

    @app.middleware("request")
    async def request_middleware(request):
        print("I am in the request middleware")

    @app.middleware("response")
    async def request_middleware(request, response):
        print("I am in the response middleware")



# Generated at 2022-06-21 23:12:55.857137
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin() is not None
    class A(MiddlewareMixin):
        pass

    assert A() is not None

# Generated at 2022-06-21 23:12:56.429468
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert True

# Generated at 2022-06-21 23:13:04.502642
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # given
    class Server(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    server = Server()

    # when
    @server.middleware
    async def handle_request(request):
        pass

    @server.middleware
    async def handle_response(request, response):
        pass

    @server.middleware('response')
    async def handle_response(request, response):
        pass

    @server.on_request
    async def handle_request(request):
        pass

    @server.on_response
    async def handle_response(request, response):
        pass

    # then
    assert len(server._future_middleware) == 4
    assert server._future_middleware[0].middleware == handle_request
    assert server._future_middle

# Generated at 2022-06-21 23:13:12.759860
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    """
    Function to test the on_response method of class MiddlewareMixin
    """

    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self.middleware = []
            return super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware.append(middleware)

    @TestMiddlewareMixin.on_response()
    def test_on_response():
        return

    TestMiddlewareMixin = TestMiddlewareMixin()
    assert TestMiddlewareMixin.middleware[0].name == "test_on_response"


# Generated at 2022-06-21 23:13:21.936902
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    class CustomMiddlewareMixin(MiddlewareMixin):
        async def _apply_middleware(self, middleware):
            self._middleware = middleware

        def set_middleware(self, middleware):
            self._middleware = middleware

    app = Sanic('test_MiddlewareMixin_on_response')
    app.config.MIDDLEWARE_CLASSES = [
        CustomMiddlewareMixin,
    ]

    # Run the app setup
    app._run_setup_middleware()

    @app.middleware("response")
    async def print_on_response(request, response):
        response.text += "I'm a response middleware\n"


# Generated at 2022-06-21 23:13:32.235145
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.middleware_excuted = False
        
        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware_excuted = True
            assert middleware.middleware == m1

    tmm = TestMiddlewareMixin()

    # Call m1 as a way to test that the middleware mixin is working.
    # If this test fails, it is due to the decorator being a no-op.
    # See also: https://stackoverflow.com/questions/52806690/
    #           how-to-unit-test-a-decorator-without-calling-the-decor

# Generated at 2022-06-21 23:13:33.633773
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-21 23:13:41.044305
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestClass(MiddlewareMixin):
        pass

    test_class = TestClass()
    result = test_class.on_request(middleware = "test")
    assert(result == partial(test_class.middleware, attach_to="request"))
    result = test_class.on_request(middleware = lambda test: test)
    assert(result == test_class.middleware(lambda test: test, "request"))


# Generated at 2022-06-21 23:13:55.630866
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    new_middleware = MiddlewareMixin([])
    assert new_middleware._future_middleware == []

# Generated at 2022-06-21 23:14:00.041632
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Arrange
    MIXIN_CLASS = MiddlewareMixin

    @MIXIN_CLASS.on_response()
    def mw(resp):
        return resp

    # Act
    mixin_class_instance = MIXIN_CLASS()

    # Assert

# Generated at 2022-06-21 23:14:11.768273
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        request.app = "app"

    @app.route('/middleware')
    async def handler(request):
        return request.app
    
    request, response = app.test_client.get('/middleware')
    assert response.text == 'app'

    @app.middleware('response')
    async def response_middleware(request, response):
        response.headers['test'] = 'test'

    request, response = app.test_client.get('/middleware')
    assert response.headers.get('test') == 'test'

    # Not Implemented Error

# Generated at 2022-06-21 23:14:19.902960
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestClass(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self._future_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    mw = TestClass()
    assert len(mw._future_middleware) == 0
    mw.on_response(lambda x: x)
    assert len(mw._future_middleware) == 1



# Generated at 2022-06-21 23:14:31.006925
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixin_test(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)

    m = MiddlewareMixin_test()
    m.middleware(None)  # test middleware without parameters
    m.middleware(None, "request")  # test middleware with attach_to parameter
    m.middleware(None, "response")
    m.middleware(None, attach_to="request")
    m.middleware(None, attach_to="response")

    # test middleware without parameters

# Generated at 2022-06-21 23:14:33.848935
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic

    assert not Sanic(__name__)._future_middleware

# Generated at 2022-06-21 23:14:35.238978
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert False


# Generated at 2022-06-21 23:14:38.603039
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin = MiddlewareMixin()
    mixin._future_middleware = '123321'
    assert mixin._future_middleware == '123321'

# Generated at 2022-06-21 23:14:42.637513
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
	B = MiddlewareMixin
	b1 = B()
	#print(b1)
	assert b1._future_middleware == []


# Generated at 2022-06-21 23:14:46.129037
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic("sanic-server")
    assert len(app._future_middleware) == 0

    def middleware_before_request(request):
        pass

    app.middleware(middleware_before_request)
    assert len(app._future_middleware) == 1
    ret = app._future_middleware[0]
    assert ret.middleware == middleware_before_request
    assert ret.attach_to == "request"



# Generated at 2022-06-21 23:15:24.544030
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    @Sanic.middleware('request')
    async def f1(request):
        pass
    assert Sanic._future_middleware[0].middleware == f1
    assert Sanic._future_middleware[0].attach_to == 'request'
    assert Sanic._future_middleware[0].__repr__() == '<FutureMiddleware attach_to=request>'


# Generated at 2022-06-21 23:15:25.884334
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    print(MiddlewareMixin()._future_middleware)

# Generated at 2022-06-21 23:15:31.465909
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def middleware(request):
        request['processed'] = True

    request, response = app.test_client.get('/')
    assert request['processed']

# Generated at 2022-06-21 23:15:38.661097
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.models.middleware import MiddlewareDataclass

    class TestMiddleware(MiddlewareDataclass):
        def resolve_future(self, request):
            return request

        def resolve_future_error(self, request):
            return request

    assert hasattr(MiddlewareMixin, '__init__') \
            and callable(MiddlewareMixin.__init__)
    assert hasattr(MiddlewareMixin, 'middleware') \
            and callable(MiddlewareMixin.middleware)
    assert hasattr(MiddlewareMixin, 'on_request') \
            and callable(MiddlewareMixin.on_request)
    assert hasattr(MiddlewareMixin, 'on_response') \
            and callable(MiddlewareMixin.on_response)

    test

# Generated at 2022-06-21 23:15:46.514873
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    import pytest

    try:
        @app.on_request
        def test(req):
            ...
    except:
        pytest.fail('The function on_request() failed.')

    # request is valid
    try:
        @app.on_request('request')
        def test(req):
            ...
    except:
        pytest.fail('The function on_request(req) failed.')

    # request is not valid
    with pytest.raises(TypeError):
        @app.on_request('resp')
        def test(req):
            ...


# Generated at 2022-06-21 23:15:49.452220
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    app = MiddlewareMixin()
    assert isinstance(app._future_middleware, List)

# Generated at 2022-06-21 23:15:52.505279
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    obj = MiddlewareMixin()
    assert obj 
    assert isinstance(obj, MiddlewareMixin)


# Generated at 2022-06-21 23:15:53.340379
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    pass

# Generated at 2022-06-21 23:15:57.806254
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic("test_on_response")

    @app.middleware
    async def print_on_response(request):
        print("before response")

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.text == "OK"
    assert len(app._middleware) == 1

# Generated at 2022-06-21 23:16:00.511999
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response(None) is not None