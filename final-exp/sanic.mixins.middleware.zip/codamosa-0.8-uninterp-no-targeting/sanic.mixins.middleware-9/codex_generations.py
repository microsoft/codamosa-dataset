

# Generated at 2022-06-21 23:09:17.433664
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert True

# Generated at 2022-06-21 23:09:21.546734
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    def mock_middleware(request):
        pass

    @MiddlewareMixin.on_request(mock_middleware)
    class TestClass:
        pass
    
    assert TestClass()._future_middleware == [FutureMiddleware(mock_middleware, 'request')]


# Generated at 2022-06-21 23:09:24.160610
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class A(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    a = A()
    assert isinstance(a, A)

# Generated at 2022-06-21 23:09:33.656184
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            self._future_middleware = []
            self._apply_middleware = 0

    class TestMiddleware():
        def __init__(self, age: int = 0):
            self.age = age

    tMM = TestMiddlewareMixin()
    tM = TestMiddleware()
    tMM.middleware(tM)
    assert(len(tMM._future_middleware) == 1)
    assert(tMM._future_middleware[0].middleware == tM)
    assert(tMM._future_middleware[0].attach_to == "request")
    tMM._apply_middleware = 1
    tMM.middleware(tM, 'response')

# Generated at 2022-06-21 23:09:37.936873
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class App(MiddlewareMixin, object):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    m = App()
    assert m.on_response is not None

# Generated at 2022-06-21 23:09:39.486067
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass

# Generated at 2022-06-21 23:09:41.530172
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert callable(MiddlewareMixin().on_response())

# Generated at 2022-06-21 23:09:49.740837
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic("test_MiddlewareMixin_on_request")
    called = [0]

    @app.on_request
    def request_handler(request):
        called[0] = called[0] + 1

    @app.route("/")
    def handler(request):
        return json({"success": True})

    _, response = app.test_client.get("/")
    assert response.status == 200
    assert called[0] == 1


# Generated at 2022-06-21 23:09:58.412554
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # MiddlewareMixin.middleware test
    from sanic import Sanic
    app = Sanic()
    middleware = app.middleware
    assert middleware != None
    middleware_or_request = app.middleware('request')
    assert middleware_or_request != None
    attach_to = 'request'
    apply = True
    assert attach_to == 'request'
    assert apply == True



# Generated at 2022-06-21 23:10:04.600904
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    mixin = MiddlewareMixin()
    @mixin.on_response()
    def response():
        pass
    assert mixin._future_middleware[0].attach_to=='response'

# Generated at 2022-06-21 23:10:19.566890
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    import pytest
    import sanic
    from sanic.exceptions import NotFound
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.utils import sanic_endpoint_test

    class App(MiddlewareMixin):
        def __init__(self):
            self.route_list = {}

        def route(self, uri, methods=frozenset({"GET"})):
            def decorator(handler):
                self.route_list[uri] = handler

            return decorator

        def error_handler(self, request, exception):
            raise NotFound("Not Found")

        async def on_request(self, request):
            return HTTPResponse(text="pass")

        async def on_response(self, request, response):
            return HTTPR

# Generated at 2022-06-21 23:10:24.033156
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # In a unit test, we are not able to test if method _apply_middleware is called by function middleware. 
    # However, we can test if the method middleware is able to append the injected middleware to instance attribute _future_middleware.
    # The following are the steps involved in this test:
    # 1. Instantiate a new object of class MiddlewareMixin
    # 2. Call method middleware and inject a new object of class FutureMiddleware.
    test_middleware = MiddlewareMixin()
    test_middleware.middleware(FutureMiddleware("",""))
    assert(isinstance(test_middleware._future_middleware[0], FutureMiddleware))

# Race Condition for method middleware of class MiddlewareMixin
# The following race condition was noted by running the middleware unit test method in the following way:
# python -m

# Generated at 2022-06-21 23:10:32.446066
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    """
    Unit test for method on_response of class MiddlewareMixin
    """
    # TODO: pass a proper request as first parameter
    # TODO: pass a proper response as second parameter
    # TODO: pass a proper request, response and sanic_app as third parameter
    # in a non mocked way
    # TODO: pass a proper request, response, sanic_app and error as fourth
    # parameter in a non mocked way
    # TODO: pass a proper request, response, sanic_app, error and remove_from_queue
    # as fifth parameter in a non mocked way
    pass


# Generated at 2022-06-21 23:10:39.375072
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    middleware_test = MiddlewareMixin()
    assert callable(middleware_test.middleware),\
            "middleware method is not callable"
    assert callable(middleware_test.on_request()),\
            "on_request method is not callable"
    assert callable(middleware_test.on_response()),\
            "on_response method is not callable"

# Generated at 2022-06-21 23:10:43.169424
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    a = MiddlewareMixin()
    result = a.on_request(middleware=None)
    assert result is not None


# Generated at 2022-06-21 23:10:53.657567
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    """ Test on_response method of class Sanic"""
    from unittest import TestCase
    from sanic import Sanic
    import asyncio as aio

    app = Sanic()


    # Create a middleware
    @app.middleware('response')
    async def my_middleware(request, response):
        response.headers['X-XSS-Protection'] = '1'
        return response

    # Create a route to generate event
    @app.route('/test')
    async def my_test(request):
        return html('<html><head><title>test</title></head><body><p>test</p></body></html>')

    # Create a client and a server
    client = app.test_client

    # Client makes a request to the server
    request, _ = client.get('/test')



# Generated at 2022-06-21 23:10:54.920809
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin._future_middleware == []

# Generated at 2022-06-21 23:11:00.731341
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # First test without parameter
    assert MiddlewareMixin().on_request() == partial(
        MiddlewareMixin().middleware, attach_to="request"
    )
    # Then with parameter
    assert MiddlewareMixin().on_request(
        middleware=lambda: True
    ) == MiddlewareMixin().middleware(middleware=lambda: True, attach_to="request")
    
    

# Generated at 2022-06-21 23:11:05.733836
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    @MiddlewareMixin.on_request
    async def test_middleware_on_request(request, handler):
        return (await handler(request))
    
    return (test_middleware_on_request)


# Generated at 2022-06-21 23:11:13.952540
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import ServerError
    from sanic.handlers import ErrorHandler

    def func(self):
        pass

    app = Sanic("test_MiddlewareMixin_middleware")
    # Case: attach_to = "request"
    app.middleware(func)
    assert app._future_middleware[0].middleware == func
    assert app._future_middleware[0].attach_to == "request"

    def request_func(func):
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        return wrapper

    app.middleware(request_func, "request")
    assert app._future_middleware[1].middleware == request

# Generated at 2022-06-21 23:11:22.673530
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    attached_to = 'request'
    middleware_type = int
    app = MiddlewareMixin()
    @app.middleware(attach_to)
    def dummy_middleware(request):
        return middleware_type

    assert dummy_middleware(middleware_type) == middleware_type
    middleware = app._future_middleware[0]
    assert middleware.attach_to == attached_to
    assert middleware.middleware(middleware_type) == middleware_type


# Generated at 2022-06-21 23:11:25.848380
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    sanic_obj = Sanic()
    sanic_obj.on_response(middleware=None)


# Generated at 2022-06-21 23:11:28.926473
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class DummyClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            assert self._future_middleware == []
    DummyClass()

# Generated at 2022-06-21 23:11:38.020385
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import sys, os
    sys.path.append(os.getcwd())
    from sanic.app import Sanic
    @Sanic.middleware
    def example_middleware(request):
        return "test_example_middleware"
    a = Sanic()
    assert a.on_response(example_middleware) == "test_example_middleware"

if __name__ == '__main__':
    test_MiddlewareMixin_on_response()

# Generated at 2022-06-21 23:11:41.426982
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    try:
        a=MiddlewareMixin()
        assert a
    except:
        assert False

# Generated at 2022-06-21 23:11:42.511559
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []


# Generated at 2022-06-21 23:11:50.958889
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Create class for test
    class AMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.func_list = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.func_list.append(middleware)

    # Test first parameter is callable
    amiddlewaremixin = AMiddlewareMixin()

    @amiddlewaremixin.on_response
    def a_middleware(request, response):
        pass

    def a_middleware2(request, response):
        pass

    amiddlewaremixin.on_response(a_middleware2)

    assert amiddlewaremixin._future_middleware[0].middleware == a_middleware
   

# Generated at 2022-06-21 23:11:52.316588
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from .utils import Sanic
    app = Sanic('test_MiddlewareMixin')
    assert app._future_middleware == []

# Generated at 2022-06-21 23:11:54.934829
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()

    assert isinstance(mm, MiddlewareMixin)


# Generated at 2022-06-21 23:12:02.231248
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    obj = MiddlewareMixin()

    assert isinstance(obj._future_middleware, list)

    from pytest import raises
    with raises(NotImplementedError):
        obj._apply_middleware(None)

    with raises(TypeError):
        obj.middleware(None)

    # Check with one argument, i.e. without attach_to
    middleware_function = lambda: None
    assert obj.middleware(middleware_function) is middleware_function
    assertobj.middleware.keywords == {"attach_to": "request"}
    assert obj._future_middleware[-1].handler is middleware_function
    assert obj._future_middleware[-1].attach_to == "request"

    # Check with two arguments, i.e. with attach_to

# Generated at 2022-06-21 23:12:13.554585
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic("test_MiddlewareMixin_middleware")
    @app.middleware('request')
    async def test(request):
        pass
    app.__init__("test_MiddlewareMixin_middleware")
    assert app.__init__.__code__.co_argcount == 1
    assert app._future_middleware == []
    assert app.on_request.__code__.co_argcount == 2
    assert app.on_response.__code__.co_argcount == 2
    assert app._apply_middleware.__code__.co_argcount == 2
    assert app._apply_middleware.__code__.co_consts[0] == NotImplementedError


# Generated at 2022-06-21 23:12:16.016861
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class A(MiddlewareMixin):
        pass
    a = A()
    assert a.on_request(middleware=None) == partial(a.middleware, attach_to="request")



# Generated at 2022-06-21 23:12:17.326074
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    MiddlewareMixin()
    print('test_MiddlewareMixin_on_response')


# Generated at 2022-06-21 23:12:22.913557
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    # Test for the callable of callable
    middleware = lambda request, response: response

    app = App()
    result = app.middleware(middleware, apply=False)
    assert result == middleware
    assert app._future_middleware[-1].middleware == middleware
    assert app._future_middleware[-1].attach_to == "request"

    # Test for the callable of string
    app = App()
    result = app.middleware("response", apply=False)
    assert callable(result)

# Generated at 2022-06-21 23:12:24.939545
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    app = MiddlewareMixin()
    assert app is not None


# Generated at 2022-06-21 23:12:30.492780
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.app import BaseSanicAPI

    app = Sanic()

    def request_middleware(request):
        request['test'] = True

    app.on_request(request_middleware)

    assert isinstance(app, BaseSanicAPI)
    assert isinstance(app._future_middleware, list)
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-21 23:12:36.364704
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()    
    def middleware_test():
        return None
    register_middleware = app.on_request(middleware_test)
    assert app._future_middleware[0].middleware == middleware_test


# Generated at 2022-06-21 23:12:42.725056
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from .middleware_mixin import MiddlewareMixin
    from .blueprint import Blueprint

    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

    blueprint = Blueprint('test')
    blueprint.on_response(lambda request, response: response)

    assert blueprint._future_middleware[0].attach_to == 'response'



# Generated at 2022-06-21 23:12:49.045381
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.response import HTTPResponse
    assert issubclass(MiddlewareMixin,object)
    assert issubclass(MiddlewareMixin_test,MiddlewareMixin)
    assert isinstance(MiddlewareMixin_test(),MiddlewareMixin_test)
    assert isinstance(MiddlewareMixin_test().on_response(HTTPResponse),partial)



# Generated at 2022-06-21 23:12:58.143816
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.handlers import ErrorHandler

    middleware_mixin = MiddlewareMixin()

    # Testing apply middleware
    def sample_middleware(request, response):
        pass

    middleware_mixin._future_middleware = []
    middleware_mixin.middleware(sample_middleware)
    assert middleware_mixin._future_middleware[0].middleware == sample_middleware

    # Testing apply middleware attach_to
    middleware_mixin._future_middleware = []
    middleware_mixin.middleware(sample_middleware, attach_to="request")
    assert middleware_mixin._future_middleware[0].attach_to == "request"

    # Testing on_request
    middleware_mixin._future_middleware = []


# Generated at 2022-06-21 23:13:05.122156
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert callable(MiddlewareMixin.on_request)


# Generated at 2022-06-21 23:13:08.160648
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic

    app = Sanic("app name")
    assert [] == app._future_middleware



# Generated at 2022-06-21 23:13:13.131657
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin')

    @app.middleware
    async def handler():
        return True

    assert app.on_request(handler)() == True

# Generated at 2022-06-21 23:13:18.519506
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic('test_on_request')
    @app.on_request
    async def handler(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == handler


# Generated at 2022-06-21 23:13:28.784603
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_on_request')

    @app.route('/')
    async def test(request, app):
        return text('OK')

    async def request_middleware(request):
        request['test'] = True

    async def response_middleware(request, response):
        response.text = 'FAIL'

    app.on_request(request_middleware)
    app.on_response(response_middleware)



# Generated at 2022-06-21 23:13:34.209111
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Instantiate an object of class MiddlewareMixin
    ut_object = MiddlewareMixin()
    # Check the return type of function on_request
    assert isinstance(ut_object.on_request, partial)


# Generated at 2022-06-21 23:13:35.590515
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert True


# Generated at 2022-06-21 23:13:44.908568
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    m = MiddlewareMixin()
    
    assert m._future_middleware == []
    
    @m.on_response
    def middleware(request):
        pass

    assert m._future_middleware[0]._attach_to == 'response'
    assert isinstance(m._future_middleware[0]._middleware, partial)
    assert m._future_middleware[0]._middleware.args == ()
    assert m._future_middleware[0]._middleware.keywords == {}
    assert m._future_middleware[0]._middleware.func is middleware
    
if __name__ == '__main__':
    test_MiddlewareMixin_on_response()

# Generated at 2022-06-21 23:13:46.344503
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass


# Generated at 2022-06-21 23:13:51.565788
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.response import text

    # Define on_request middleware
    @Sanic.middleware('request')
    async def requestHandler(request):
        print('Do something at start of request')

    @Sanic.middleware('response')
    async def responseHandler(request, response):
        print('Do something at end of request')

    # Create Sanic instance
    app = Sanic()

    # Bind on_request middleware
    app.on_request(requestHandler)

    # Bind on_response middleware
    app.on_response(responseHandler)

    # Bind router
    @app.route('/')
    async def handler(request):
        return text('Hello, World!')

    # Test request
    app.test_client.get('/')

# Generated at 2022-06-21 23:14:08.153282
# Unit test for constructor of class MiddlewareMixin

# Generated at 2022-06-21 23:14:21.029486
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.log import log
    from asyncio import Future
    import logging

    app = Sanic('test_MiddlewareMixin_middleware')
    app.debug = True

    class TestMiddleware(logging.Handler):
        def __init__(self, app, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.app = app

        def emit(self, record):
            pass

        def response(self, request, response):
            pass

        def request(self, request):
            pass

    # Test @app.middleware('response')
    mw_response = TestMiddleware(app, level=logging.DEBUG)
    app.middleware('response')(mw_response)


# Generated at 2022-06-21 23:14:23.439748
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__()

    mixin = TestMiddlewareMixin()
    assert mixin._future_middleware == []


# Generated at 2022-06-21 23:14:30.485369
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            assert middleware._attach_to == "response"
            return None

    testMiddlewareMixin = TestMiddlewareMixin()

    @testMiddlewareMixin.on_response
    def on_response_middleware(request):
        return request

    @testMiddlewareMixin.on_response
    def on_response_middleware_no_param():
        return None


# Generated at 2022-06-21 23:14:37.428395
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    tmm: TestMiddlewareMixin = TestMiddlewareMixin()
    assert tmm
    assert tmm._future_middleware is not None
    assert tmm._future_middleware == []


# Generated at 2022-06-21 23:14:40.942146
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    
    app = Sanic()
    app.middleware(middleware_or_request='asd')
    assert app._future_middleware == [FutureMiddleware(middleware_or_request='asd', attach_to='asd')]



# Generated at 2022-06-21 23:14:41.451489
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    MiddlewareMixin()

# Generated at 2022-06-21 23:14:46.977384
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.middleware
    def a():
        pass
    @app.on_request
    def b():
        pass
    @app.middleware('request')
    def c():
        pass
    @app.on_request('request')
    def d():
        pass
    @app.middleware('response')
    def e():
        pass
    @app.on_request('response')
    def f():
        pass
    @app.middleware('b')
    def g():
        pass
    @app.on_request('b')
    def h():
        pass
    @app.middleware('b')
    def i():
        pass

# Generated at 2022-06-21 23:14:50.043619
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Arrange
    from unittest.mock import Mock

    AppClassMock = Mock()
    middleware_mixin = MiddlewareMixin(AppClassMock)

    # Act
    assert isinstance(middleware_mixin._future_middleware, list)

    # Assert


# Generated at 2022-06-21 23:14:50.898423
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response




# Generated at 2022-06-21 23:15:21.399942
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Create Instance
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    class MiddlewareMixinFake(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    fake_obj = MiddlewareMixinFake()
    # MiddlewareMixin.middleware(middleware_or_request, attach_to='request', apply=True)
    assert fake_obj.middleware is not None
    # MiddlewareMixin.on_request(middleware=None)
    assert fake_obj.on_request is not None
    # MiddlewareMixin.on_response(middleware=None)
    assert fake_obj.on_response is not None


# Generated at 2022-06-21 23:15:24.404257
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    app = Sanic("test_MiddlewareMixin")
    assert app._future_middleware == []


# Generated at 2022-06-21 23:15:30.161313
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Test:
        def __init__(self):
            self._future_middleware: List[FutureMiddleware] = []
    test = Test()
    test.middleware = MiddlewareMixin.middleware
    test.on_request = MiddlewareMixin.on_request
    @test.on_request
    async def add_one(request):
        request.args['one'] = 1



# Generated at 2022-06-21 23:15:38.309045
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    from sanic.models import FutureMiddleware
    app = Sanic()
    @app.middleware('response')
    async def handler(request, response):
        pass
    @app.middleware
    async def handler2(request):
        pass
    @app.on_response()
    async def handler3(request, response):
        pass
    @app.on_request()
    async def handler4(request):
        pass
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert isinstance(app._future_middleware[1], FutureMiddleware)
    assert isinstance(app._future_middleware[2], FutureMiddleware)
    assert isinstance(app._future_middleware[3], FutureMiddleware)

# Generated at 2022-06-21 23:15:44.788727
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    b = MiddlewareMixin()
    assert callable(b.on_response())
    assert callable(b.on_response(5))
    assert partial(b.middleware, attach_to="response") == b.on_response()
    assert partial(b.middleware, attach_to="response") == b.on_response(5)



# Generated at 2022-06-21 23:15:50.682059
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    app = Sanic('test_MiddlewareMixin_middleware')



# Generated at 2022-06-21 23:15:56.710009
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic()

    @app.on_request
    def before_request(request):
        assert 1 == 1

    @app.route("/")
    async def handler(request):
        return json({"1": 1})

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.json == {"1": 1}


# Generated at 2022-06-21 23:16:07.228264
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.exceptions import ServerError
    from sanic_restful import Api
    from sanic_restful.views import Resource

    app = Sanic(__name__)
    api = Api(app)

    def custom_middleware(request):
        raise ServerError("oops")

    app.on_request(custom_middleware)

    assert len(api.app._future_middleware) == 1
    assert api.app._future_middleware[0].attach_to == "request"
    assert api.app._future_middleware[0].middleware == custom_middleware



# Generated at 2022-06-21 23:16:18.061360
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class User:
        def __init__(self, *args, **kwargs):
            if not callable(args[0]):
                raise ValueError
            self.middleware = args[0]
            self.attach_to = "request"

        def __call__(self, *args, **kwargs):
            return self.middleware(*args, **kwargs)

    class MiddlewareMixinTest:
        def __init__(self, *args, **kwargs):
            self._future_middleware = []

        def _apply_middleware(self, middleware):
            return self._future_middleware.append(middleware)

        def on_request(self, middleware=None):
            if callable(middleware):
                return self.middleware(middleware, "request")

# Generated at 2022-06-21 23:16:18.968173
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    MiddlewareMixin()


# Generated at 2022-06-21 23:17:12.108733
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert True

# Generated at 2022-06-21 23:17:19.202063
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddlewareMixinTest(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware):
            pass
    # Test constructor
    test_app = MiddlewareMixinTest()
    assert test_app._future_middleware == []


# Left out the test for the method:
#     def _apply_middleware(self, middleware: FutureMiddleware):
# because the method is not in the class MiddlewareMixin.
# To test _apply_middleware, a new class has to be created that inherits from
# class MiddlewareMixin and implements the abstract method _apply_middleware.



# Generated at 2022-06-21 23:17:20.843269
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    @MiddlewareMixin.on_request
    def middleware_for_request(request):
        return request.app

    app = MiddlewareMixin()
    assert app == middleware_for_request(app)


# Generated at 2022-06-21 23:17:21.428638
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert True is True

# Generated at 2022-06-21 23:17:29.965166
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic 
    class Api(Sanic):
        pass
    app = Api()
    assert app._future_middleware == []
    assert app._apply_middleware("middleware") == NotImplementedError
    @app.middleware("request")
    def request_handler(request):
        return request
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert callable(app.on_request)
    @app.on_request
    def new_request_handler(request):
        return request
    assert isinstance(app._future_middleware[1], FutureMiddleware)
    assert callable(app.on_response)
    @app.on_response
    def response_handler(request, response):
        return response

# Generated at 2022-06-21 23:17:31.129507
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

# Generated at 2022-06-21 23:17:33.293693
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    client = MiddlewareMixin()

    assert isinstance(client._future_middleware, list)

# Generated at 2022-06-21 23:17:44.571564
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Mixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def middleware(self, middleware_or_request, attach_to="request", apply=True):
            return super().middleware(middleware_or_request, attach_to, apply)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    mixin = Mixin()
    # SUT
    @mixin.middleware
    def req_middleware(request):
        return request

    @mixin.middleware
    def res_middleware(request, response):
        return response

    # check type and attributes
    assert(isinstance(mixin._future_middleware, list))

# Generated at 2022-06-21 23:17:45.461235
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-21 23:17:48.155319
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []