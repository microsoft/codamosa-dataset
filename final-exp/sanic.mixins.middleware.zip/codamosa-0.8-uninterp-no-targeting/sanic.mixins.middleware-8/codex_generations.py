

# Generated at 2022-06-21 23:09:21.013643
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    @MiddlewareMixin.on_response
    def test():
        return "pass"
    assert test() == "pass"


# Generated at 2022-06-21 23:09:31.017341
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware
    from sanic.models.middlewares import PAYLOAD_ATTRS, RESPONSE_ATTRS
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol

    @MiddlewareMixin.on_request()
    def inbound_middleware_func(request):
        return request

    @MiddlewareMixin.on_request()
    def inbound_middleware_func2(request):
        return request

    @MiddlewareMixin.on_request()
    def inbound_middleware_func3(request):
        return request


# Generated at 2022-06-21 23:09:41.133534
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.views import HTTPMethodView
    from sanic.response import json
    from sanic.exceptions import NotFound
    import pytest
    
    app = Sanic(__name__)
    @app.on_response
    async def custom_middleware(request, response):
        return response
    
    #Create a test case
    class GetUserView(HTTPMethodView):
        async def get(self, request, user_id):
            return json({"user_id": user_id})
        
    async def test_middleware_result(app):
        request, response = app.test_client.get('/user/42')
        assert response.json == {'user_id': 42}
    

# Generated at 2022-06-21 23:09:47.985933
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestObj(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, middleware):
            pass

    @TestObj().on_request()
    def custom_on_request(req):
        return req

    assert custom_on_request.__name__ == "custom_on_request"


# Generated at 2022-06-21 23:10:00.856217
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    mixin = TestMiddlewareMixin()
    # Call this middleware with attach_to='request'
    @mixin.middleware()
    async def test_middleware():
        pass

    assert mixin._future_middleware[0].middleware == test_middleware
    assert mixin._future_middleware[0].attach_to == 'request'

    # Call this middleware with attach_to='response'
    @mixin.middleware('response')
    async def test_middleware_response():
        pass

    assert mixin._future_middleware[1].middleware == test_middleware_response

# Generated at 2022-06-21 23:10:11.774297
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from async_server import AsyncServer
    from sanic.response import text, json
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic("middleware_app")

    @app.middleware
    async def header_middleware(request):
        print("Request header:", request.headers)

    @app.middleware("request")
    async def before_request(request):
        print("Request:", request)

    @app.middleware("response")
    async def after_request(request, response):
        print("Response:", response)


# Generated at 2022-06-21 23:10:18.301392
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import sanic
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(TestMiddlewareMixin, self).__init__(*args, **kwargs)

        def _apply_middleware(self, middleware):
            pass
    app = sanic.Sanic()
    middleware_mixin = TestMiddlewareMixin(app)
    middleware_mixin.on_response(middleware_mixin)



# Generated at 2022-06-21 23:10:21.785968
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    tester = MiddlewareMixin()
    assert tester._future_middleware == []


# Generated at 2022-06-21 23:10:25.444929
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixinTest(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    middleware_mixin_test = MiddlewareMixinTest()
    # Case 1
    @middleware_mixin_test.on_request(middleware=None)
    def middleware_test_case1():
        pass
    assert len(middleware_mixin_test._future_middleware) == 1
    assert middleware_mixin_test._future_middleware[0].middleware == middleware_test_case1
    assert middleware_mixin_test._future_middleware[0].attach_to == "request"

    # Case 2
    @middleware_mixin_test.on_request("response")
    def middleware_test_case2():
        pass


# Generated at 2022-06-21 23:10:28.358689
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = MiddlewareMixin()
    def aaa(request):
        return response.text('aaa')

    bbb = app.on_request(aaa)
    assert(callable(bbb))
    assert(bbb('request') == 'aaa')


# Generated at 2022-06-21 23:10:32.865836
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    class _MiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            self._future_middleware: List[FutureMiddleware] = []
            
    _MiddlewareMixin()  # noqa
    print("Test method MiddlewareMixin_on_request() is passed")

# Generated at 2022-06-21 23:10:33.751468
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response(MiddlewareMixin) != None


# Generated at 2022-06-21 23:10:39.960221
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic(__name__)

    @app.middleware('request')
    async def print_on_request(request):
        pass

    assert print_on_request == app.on_request()

    @app.middleware('response')
    async def print_on_request(request, response):
        pass

    assert print_on_request == app.on_response()


# Generated at 2022-06-21 23:10:47.120092
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic import response

    app = Sanic('test')
    @app.on_request
    async def middleware(request):
        return response.text('pass')

    request, response = app.test_client.get('/')
    assert response.text == 'pass'


# Generated at 2022-06-21 23:10:49.238327
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import sanic
    app = sanic.Sanic()
    assert callable(app.on_request)

# Generated at 2022-06-21 23:10:52.159546
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic('test')

    @app.on_response
    def handler(request, response):
        return response

    assert True

# Generated at 2022-06-21 23:10:59.755242
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    @sanic.response.json
    async def handler(request):
        return {"test": True}

    app = sanic.Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    def test_middleware(request):
        raise NotImplementedError  # noqa

    app.add_route(handler, "/test")
    _, response = app.test_client.get("/test")
    assert response.status == 200

    @app.middleware("request")
    def test_middleware(request):
        raise NotImplementedError  # noqa

    app.add_route(handler, "/test")
    _, response = app.test_client.get("/test")
    assert response.status == 200


# Generated at 2022-06-21 23:11:04.072304
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic(__name__)

    @app.on_request
    def print_hello():
        print('hello')


test_MiddlewareMixin_on_request()

# Generated at 2022-06-21 23:11:05.439185
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    [1,2,3]

# Generated at 2022-06-21 23:11:13.864987
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.views import HTTPMethodView
    from sanic.response import json
    from sanic.models.views import apply_middleware

    app = Sanic('test_MiddlewareMixin_on_response')

    class MyView(HTTPMethodView):
        async def get(self):
            return json({'text': 'abc'})

    @app.middleware('response')
    async def handle_response(request, response):
        response.text = response.text + "def"

    app.add_route(MyView.as_view(), '/')
    apply_middleware(app, app._future_middleware)

    request, response = app.test_client.get('/')

    assert response.text == 'abcdef'


# Generated at 2022-06-21 23:11:19.902415
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    output = MiddlewareMixin()
    assert output._future_middleware == []

# Generated at 2022-06-21 23:11:26.680042
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MiddlewareMixinSubClass(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware = middleware
    sub = MiddlewareMixinSubClass()
    middleware = sub.on_request()
    assert middleware.func.__name__ == "register_middleware"
    assert middleware.keywords["attach_to"] == "request"

# Generated at 2022-06-21 23:11:28.999093
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic()
    app.on_request(lambda x: x)
    assert len(app._future_middleware) == 1


# Generated at 2022-06-21 23:11:32.912598
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    my_sanic = Sanic(__name__)
    assert my_sanic.on_request()



# Generated at 2022-06-21 23:11:35.460350
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    test1 = MiddlewareMixin()
    assert isinstance(test1, MiddlewareMixin)

# Generated at 2022-06-21 23:11:38.719682
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.models.futures import FutureMiddleware
    #test if list of middleware is initialized
    object_test = MiddlewareMixin()
    assert object_test._future_middleware == []


    # test function register_middleware appends future_middleware to _future_middleware
    middleware_test = FutureMiddleware("middleware", "attach_to")
    object_test.register_middleware(middleware_test)
    assert object_test._future_middleware == [middleware_test]

# Generated at 2022-06-21 23:11:44.465611
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.response import HTTPResponse
    app = MiddlewareMixin()
    @app.on_response
    def on_response(request, response):
        return HTTPResponse("success", status=200)
    return app

# Generated at 2022-06-21 23:11:52.377870
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    import pytest
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware
    # MiddlewareMixin()
    middleware_mixin = MiddlewareMixin()
    test_future_middleware = [FutureMiddleware(lambda x : x, 'response')]
    assert middleware_mixin._future_middleware == []
    assert middleware_mixin._apply_middleware == NotImplemented
    # MiddlewareMixin(test_future_middleware)
    middleware_mixin = MiddlewareMixin(test_future_middleware)
    assert middleware_mixin._future_middleware == test_future_middleware
    # MiddlewareMixin(FutureMiddleware)
    middleware_mixin2 = MiddlewareMixin(FutureMiddleware)
    assert middleware_mixin

# Generated at 2022-06-21 23:12:01.558834
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic(__name__)

    # test on_request
    @app.middleware
    def middleware(request):
        app.instance.middleware_run = True

    @app.route("/")
    def handler(request):
        return text("OK")

    client = app.test_client
    request, response = client.get("/")
    assert response.status == 200
    assert app.instance.middleware_run
    app.instance.middleware_run = False

    # test on_response

    @app.middleware("response")
    def middleware2(request, response):
        app.instance.middleware_run = True

    @app.route("/")
    def handler(request):
        return text("OK")

    client = app.test

# Generated at 2022-06-21 23:12:10.742147
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import unittest
    from unittest.mock import MagicMock

    from sanic.models.futures import FutureModel
    from sanic.models.futures import FutureMiddleware

    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

    class TestFutureModel(FutureModel):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

    class TestMiddleware:
        def __init__(self, app, args):
            pass

    class TestMiddlewareApp:
        def __init__(self, **kwargs):
            self.test_future_model = TestFuture

# Generated at 2022-06-21 23:12:27.710739
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Request:
        def __init__(self):
            self.info = Dummy()

    class Hooks:
        def __init__(self):
            self.request = []
            self.response = []

    class App(MiddlewareMixin):
        def __init__(self):
            self.dummy = Hooks()

        @staticmethod
        def middleware(middleware, attach_to):
            return middleware

    app = App()

    @app.on_request
    def middleware1(request):
        app.dummy.request.append(1)

    @app.on_request
    def middleware2(request):
        app.dummy.request.append(2)


# Generated at 2022-06-21 23:12:31.146548
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestClass:
        def __init__(self):
            pass

    my_class = TestClass()
    the_partial = my_class.on_request()
    on_request_wrapper = the_partial(None)

# Generated at 2022-06-21 23:12:36.272947
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            middleware.apply(None)

    obj = TestMiddlewareMixin()
    obj.on_request()

# Generated at 2022-06-21 23:12:37.649187
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin.on_request('request') == 'request'

# Generated at 2022-06-21 23:12:49.375372
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    print("Test MiddlewareMixin.middleware")
    
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    
    def decorate_middleware():
        return None
    
    test_middleware_mixin = TestMiddlewareMixin()
    # Decorate
    @test_middleware_mixin.middleware
    def decorate_middleware():
        return None
    # Register middleware
    test_middleware_mixin.middleware(decorate_middleware)
    # Run tests
    assert(callable(decorate_middleware))
    assert(len(test_middleware_mixin._future_middleware) == 1)

# Generated at 2022-06-21 23:12:51.102277
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    assert mm._future_middleware == []


# Generated at 2022-06-21 23:12:57.145156
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    class test(MiddlewareMixin):pass
    app=Sanic("test")
    test(app)
    @app.middleware
    def middleware(request):pass
    assert len(app._middleware)==1



# Generated at 2022-06-21 23:13:02.353383
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    def test_middleware_1():
        print("test_middleware_1")

    def test_middleware_2():
        print("test_middleware_2")

    class TestClass(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            print(middleware)

    a = TestClass()
    a.middleware(test_middleware_1)
    a.middleware(test_middleware_2)



# Generated at 2022-06-21 23:13:04.541485
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    mm=MiddlewareMixin()
    assert mm._future_middleware == []


# Generated at 2022-06-21 23:13:05.931182
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert isinstance(MiddlewareMixin.on_response, types.MethodType)

# Generated at 2022-06-21 23:13:35.298997
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert MiddlewareMixin.middleware.__doc__
    assert MiddlewareMixin.on_request.__doc__
    assert MiddlewareMixin.on_response.__doc__

# Generated at 2022-06-21 23:13:42.888262
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.sanic import Sanic
    app = Sanic("middleware_mixin")
    assert isinstance(app, Sanic)
    assert app.__class__.__name__ == "Sanic"
    assert 'middleware_mixin' == app.name
    assert callable(app.middleware)
    assert callable(app.on_request)
    assert callable(app.on_response)
    assert isinstance(app._future_middleware, List)


# Generated at 2022-06-21 23:13:52.312531
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin._future_middleware == []

    # Test for method middleware
    def middleware_decorator_test_response(request):
        return request
    
    def middleware_decorator_test_request(request):
        return request
    
    middleware_decorator = middleware_mixin.middleware(
        middleware_decorator_test_request, attach_to="request", apply=True
    )
    assert isinstance(middleware_decorator, partial)

    middleware_decorator_response = middleware_mixin.middleware(
        middleware_decorator_test_response, attach_to="response", apply=True
    )
    assert isinstance(middleware_decorator_response, partial)

# Generated at 2022-06-21 23:13:55.487005
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert isinstance(m, MiddlewareMixin)
    assert isinstance(m._future_middleware, List)

# Generated at 2022-06-21 23:14:02.093057
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    a = MiddlewareMixin
    a.on_request(middleware=None)
    a.on_request(middleware=2)
    a.on_request(middleware=lambda x: print(x))
    a.on_request(middleware=lambda y: print(y))
    a.on_request(middleware=lambda z: print(z))
    a.on_request(middleware=None)
    return 'OK'


# Generated at 2022-06-21 23:14:11.177051
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text
    def hello(request):
        return text('Hello!')

    app = Sanic('test_on_response')
    app.add_route(hello, '/')

    @app.on_response
    def when_done(request, response):
        response.headers['x-hello'] = 'world'

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.headers['x-hello'] == 'world'

    # Unit test for method on_request of class MiddlewareMixin

# Generated at 2022-06-21 23:14:21.217581
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    app = Sanic('test_MiddlewareMixin_on_request')
    assert not hasattr(app, "on_request")
    assert not hasattr(app, "on_response")

    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass

    TestMiddlewareMixin(app)

    assert hasattr(app, "on_request")
    assert hasattr(app, "on_response")

    assert app.on_request.__name__ == "on_request"
    assert app.on_response.__name__ == "on_response"


# Generated at 2022-06-21 23:14:22.397345
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m is not None
    assert isinstance(m._future_middleware, list)

# Generated at 2022-06-21 23:14:26.140536
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class test_MiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            pass
        def _apply_middleware(self, middleware):
            pass

    test = test_MiddlewareMixin()
    assert(test._future_middleware == [])

    @test.middleware
    async def test_middleware(request):
        pass

    assert(len(test._future_middleware) == 1)


# Generated at 2022-06-21 23:14:29.658344
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Test:
        _future_middleware: List[FutureMiddleware] = []

    inst = MiddlewareMixin()
    assert callable(inst.on_response())
    assert callable(inst.on_response(lambda x: x))

# Generated at 2022-06-21 23:15:09.241358
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    #Test Class Loading
    assert callable(MiddlewareMixin)
    assert callable(MiddlewareMixin())
    assert callable(MiddlewareMixin.__init__)
    assert callable(MiddlewareMixin._apply_middleware)
    assert callable(MiddlewareMixin.middleware)
    assert callable(MiddlewareMixin.on_request)
    assert callable(MiddlewareMixin.on_response)

    #Test function with no parameters
    assert MiddlewareMixin.on_request()

    def test_middleware(request):
        return request
    assert MiddlewareMixin.on_request(test_middleware)

    mixin = MiddlewareMixin()
    assert callable(mixin.on_request())
    assert mixin.on_request(test_middleware)


# Generated at 2022-06-21 23:15:11.799490
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App(MiddlewareMixin):
        ...

    _ = App()
    f = _.middleware

# Generated at 2022-06-21 23:15:18.140785
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    @TestMiddlewareMixin.on_response()
    def test(request):
        return request

    t = TestMiddlewareMixin()
    assert len(t._future_middleware) == 1



# Generated at 2022-06-21 23:15:22.054745
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Test(MiddlewareMixin):
        pass

    test = Test()
    assert isinstance(test, Test)
    assert test._future_middleware  == []


# Generated at 2022-06-21 23:15:32.201563
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    '''
    Test the method to set a middleware in the core.
    '''
    from sanic.app import Sanic
    from sanic_openapi import doc
    from sanic_openapi import swagger_blueprint
    from sanic_openapi import openapi_blueprint

    from .fixtures import fooMiddleware

    app = Sanic(__name__)
    app.blueprint(swagger_blueprint)
    app.blueprint(openapi_blueprint)

    @app.middleware('response')
    async def reorder_key(request, response):
        if response.status == 404:
            response = fooMiddleware().execute(request, response)
        return response


# Generated at 2022-06-21 23:15:35.292933
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    test_Middleware = MiddlewareMixin()
    assert callable(test_Middleware.on_request())
    assert callable(test_Middleware.on_response())

# Generated at 2022-06-21 23:15:46.659554
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic('sanic_middleware_mixin')
    bp = Blueprint('sanic')

    @app.middleware
    async def middleware_for_request(request):
        request.test = True

    @bp.middleware
    async def middleware_for_request(request):
        request.test = True

    assert app.list_routes() == []
    assert app.list_blueprints() == []
    assert bp.list_routes() == []
    assert bp.list_blueprints() == []
    assert app._future_middleware == []
    assert bp._future_middleware == []

    @app.get('/')
    async def handler(request):
        assert request.test == True

# Generated at 2022-06-21 23:15:57.446365
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    from sanic.exceptions import SanicException
    assert isinstance(Sanic('test').middleware(None), partial)
    assert isinstance(Sanic('test').middleware(), partial)
    assert isinstance(Sanic('test').middleware(lambda *args, **kwargs: None), partial)
    assert isinstance(Sanic('test').on_request(), partial)
    assert isinstance(Sanic('test').on_response(), partial)
    assert isinstance(Sanic('test').on_request(lambda *args, **kwargs: None), partial)
    assert isinstance(Sanic('test').on_response(lambda *args, **kwargs: None), partial)
    assert isinstance(Sanic('test').middleware(attach_to="request"), partial)


# Generated at 2022-06-21 23:16:02.478000
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin(None, None)
    middleware_mixin._future_middleware
    middleware_mixin._apply_middleware(None)




# Generated at 2022-06-21 23:16:09.278963
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class FutureMiddlewareMock:
        def __init__(self, middleware, attach_to):
            self.caller = middleware
            self.name = attach_to

        def __call__(self, request, callback):
            return self.caller(request)

    def dummy_middleware(request):
        return request

    class MiddlewareMixinMock(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self._future_middleware = []

        def _apply_middleware(self, middleware):
            middleware.__call__()

    mi = MiddlewareMixinMock()
    assert not mi._future_middleware
    assert mi.middleware(dummy_middleware, 'request')
    assert mi._future_middleware

# Generated at 2022-06-21 23:17:20.033227
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    def middleware(req,resp):
        pass
    assert MiddlewareMixin.on_response(middleware) == MiddlewareMixin.middleware(middleware, 'response')
    assert MiddlewareMixin.on_response() == MiddlewareMixin.middleware(attach_to='response')

# Generated at 2022-06-21 23:17:24.402012
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestSanic(MiddlewareMixin):
        def __init__(self):
            self._future_middleware = []
    app = TestSanic()
    @app.on_request
    def on_request_test(request):
        pass
    assert len(app._future_middleware) == 1


# Generated at 2022-06-21 23:17:35.116378
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddlewareMixinTest(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    mw = MiddlewareMixinTest()
    assert mw._future_middleware == []

    def test_mw1(request):
        pass

    def test_mw2(request, response):
        pass

    # Test middleware function
    mw.middleware(test_mw1)
    assert len(mw._future_middleware) == 1
    assert mw._future_middleware[0]._middleware == test_mw1
    assert mw._future_middleware[0]._attach_to == 'request'
    mw.middleware(test_mw2, attach_to='response')
    assert len

# Generated at 2022-06-21 23:17:42.554335
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    def test_func():
        pass
    a = MiddlewareMixin()
    # test if not called with callable
    assert isinstance(a.on_response(), partial)
    # test if called with a callable
    assert a.on_response(test_func) == test_func


# Generated at 2022-06-21 23:17:50.140584
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    mixin = MiddlewareMixin()
    middleware = mixin.middleware(None)

    # type of middleware is function
    assert callable(middleware)
    # middleware has 1 positional parameter
    assert inspect.signature(middleware).parameters.__len__() == 1
    # print(middleware(None))
    assert middleware(None) is None



# Generated at 2022-06-21 23:17:54.177957
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    def test_middleware_response(request, response):
        return response

    a = MiddlewareMixin()
    response = a.on_response(test_middleware_response)()
    assert response == a



# Generated at 2022-06-21 23:18:03.682674
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import sanic.app

    app = sanic.app.Sanic("test")

    @app.middleware('response')
    async def handler_response(request):
        return request

    assert app._future_middleware[0].handler is handler_response

    @app.middleware
    async def handler_response_2(request):
        return request

    assert app._future_middleware[1].handler is handler_response_2

    @app.middleware("request")
    async def handler_request(request):
        return request

    assert app._future_middleware[2].handler is handler_request

# Generated at 2022-06-21 23:18:07.731587
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic()

    @app.middleware('response')
    async def handler(request):
        return request

    assert len(app._future_middleware) == 1

# Generated at 2022-06-21 23:18:16.203811
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = App()

    @app.middleware
    def middleware(request):
        return request

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].middleware is middleware

    @app.middleware("response")
    def middleware(request, response):
        return response

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].attach_to == "response"
    assert app._future_middleware[1].middleware is middleware


# Generated at 2022-06-21 23:18:22.949338
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin_middleware(MiddlewareMixin):
        pass
    obj = TestMiddlewareMixin_middleware()
    # middleware is a method
    assert callable(obj.middleware)
    # __init__ execute without error
    assert obj

