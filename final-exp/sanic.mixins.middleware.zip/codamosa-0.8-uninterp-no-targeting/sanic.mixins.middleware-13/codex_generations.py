

# Generated at 2022-06-21 23:09:18.146219
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    x = MiddlewareMixin()
    x._apply_middleware(None)
    assert x._future_middleware == []

# Generated at 2022-06-21 23:09:23.538617
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class App(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    app = App()
    @app.on_request()
    def middleware(request):
        pass
    assert app._future_middleware[0].handler is middleware
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-21 23:09:30.740740
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class ClassForMiddlewareMixin:
        def __init__(self, *args, **kwargs):
            self._future_middleware = []
            self._apply_middleware = lambda x: x # noqa

    classed = ClassForMiddlewareMixin()
    classed.on_response = MiddlewareMixin.on_response
    assert classed.on_response is not None
    try:
        classed.on_response(12)
    except Exception as e:
        assert type(e) == TypeError and "invalid type" in str(e)



# Generated at 2022-06-21 23:09:33.149554
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert __name__ == 'sanic.models.mixins.middleware'

# Generated at 2022-06-21 23:09:36.157612
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class _MockMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    mmm = _MockMiddlewareMixin()

# Generated at 2022-06-21 23:09:37.245875
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert callable(MiddlewareMixin.on_request)


# Generated at 2022-06-21 23:09:42.607915
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.middleware import Middleware
    from sanic.response import json
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from unittest.mock import MagicMock
    from sanic.websocket import WebSocketCommonProtocol

    app = MiddlewareMixin()
    middleware1 = MagicMock(Middleware)
    middleware2 = MagicMock(Middleware)
    middleware3 = MagicMock(Middleware)
    middleware4 = MagicMock(Middleware)

    app.middleware(middleware1,'response')
    app.middleware(middleware2,'request')
    app.middleware(middleware3)
    app.middleware(middleware4,'response')


# Generated at 2022-06-21 23:09:49.231379
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic("middleware_test")


    @app.middleware("request")
    async def request_middleware(request):
        return await request

    @app.middleware("response")
    async def response_middleware(request, response):
        return response

    @app.route("/")
    async def handler(request):
        return response.text("OK")

    app.run()

# Generated at 2022-06-21 23:09:58.530202
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            print("_apply_middleware")

    middleware_mixin = MiddlewareMixin()
    app = middleware_mixin.on_response()
    app("middleware")


# Generated at 2022-06-21 23:10:11.484020
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import json
    import asyncio

    class ServerMiddlewareMixin(MiddlewareMixin):
        pass
    app = Sanic(__name__)
    app.__class__ = ServerMiddlewareMixin
    app.__class__.__init__(app)

    @app.middleware('response')
    async def halt_all_responses(request):
        if request.uri == '/halt_all_responses':
            return json({'message': 'halting all responses'}, status=401)
    @app.middleware('request')
    async def halt_all_requests(request):
        if request.uri == '/halt_all_requests':
            return json({'message': 'halting all requests'}, status=401)


# Generated at 2022-06-21 23:10:18.119907
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    object = MiddlewareMixin()
    object.on_request()
    assert type(object.on_request()) == partial
    assert type(object.on_request(lambda request: "hello")) == types.FunctionType


# Generated at 2022-06-21 23:10:29.889198
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestClass:
        def __init__(self):
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    # without parameter
    test = TestClass()
    func = test.on_response()
    assert isinstance(func, partial)
    assert func.func == test.middleware
    assert func.keywords.get("attach_to") == "response"
    # with parameter
    test = TestClass()
    func = test.on_response(lambda x: x)
    assert callable(func)
    res = func("a")
    assert res == "a"

# Generated at 2022-06-21 23:10:41.054624
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MyMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)
    
    my_middleware_mixin = MyMiddlewareMixin()

    def my_middleware(request):
        return True

    # Test decorate and register middleware to be called when request is 'request', and set apply = True 
    my_middleware_mixin.middleware(my_middleware, apply=True)
    assert len(my_middleware_mixin._future_middleware) == 1
    assert my_middleware_mixin._future_middleware[0]._middleware == my_middle

# Generated at 2022-06-21 23:10:42.470140
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass


# Generated at 2022-06-21 23:10:46.273268
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class ClazzTest(MiddlewareMixin):
        pass
    clazz_test = ClazzTest()
    assert clazz_test._future_middleware == []

# Generated at 2022-06-21 23:10:54.053856
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    class A(MiddlewareMixin):
        async def middleware_test(self):
            pass
        async def middleware_test2(self):
            pass
    a = A()
    a.middleware(None)
    a.middleware(a.middleware_test)
    a.middleware(a.middleware_test2)
    a._future_middleware[1].middleware = a.middleware_test
    a._future_middleware[2].middleware = a.middleware_test2
    a._future_middleware[1].attach_to = "request"
    a._future_middleware[2].attach_to = "response"


# Generated at 2022-06-21 23:11:01.595332
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.futures import Future
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import FutureMiddlewareType
    from sanic.models.futures import FutureType
    from sanic.request import Request

    class DummyClass(MiddlewareMixin):

        def _apply_middleware(self, future_middleware: FutureMiddleware):
            pass

    dummy_class = DummyClass()
    request_middleware = Future(FutureType.REQUEST, lambda a: a + 1)
    response_middleware = Future(FutureType.RESPONSE, lambda a: a - 1)

    @dummy_class.on_request
    def function_middleware(request, *args, **kwargs):
        pass


# Generated at 2022-06-21 23:11:06.637275
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic()

    @app.on_response
    def on_response(request, response):
        pass

    assert len(app._future_middleware) == 1


# Generated at 2022-06-21 23:11:13.599541
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():

    from sanic import Sanic

    app = Sanic()

    @app.on_response
    def on_response_middleware(request, response):
        pass

    assert app.is_request_stream is False
    assert app.request_class is None
    assert app.error_handler is None
    assert app.before_server_start is None
    assert app.before_server_stop is None
    assert app.after_server_stop is None
    assert app.response_class is None
    assert app.exception_handler is None
    assert app.middleware is not None
    assert app.on_request is not None
    assert app.on_response is not None
    assert app.listeners is not None
    assert app.route is not None
    assert app.add_task is not None

# Generated at 2022-06-21 23:11:20.355988
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    mm = MiddlewareMixin()
    # Create an example middleware
    def example_request_middleware(request):
        return request

    assert isinstance(mm.on_request(example_request_middleware), Callable)
    assert mm.on_request(example_request_middleware).__name__ == "example_request_middleware"


# Generated at 2022-06-21 23:11:31.882067
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from functools import partial

    class App(MiddlewareMixin):
        _future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)

    app = App()

    @app.on_request
    def test_func(request):
        return request

    assert app._future_middleware[0].middleware == test_func
    assert app._future_middleware[0].attach_to == "request"

    @app.on_request()
    def test_func(request):
        return request

    assert app._future_middleware[1].middleware == test_func
    assert app._future_middleware[1].attach_to == "request"


# Generated at 2022-06-21 23:11:33.904050
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin = MiddlewareMixin()
    assert mixin._future_middleware == []

# Generated at 2022-06-21 23:11:36.467032
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    obj = MiddlewareMixin()
    assert obj._future_middleware == []


# Generated at 2022-06-21 23:11:40.974881
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic(__name__)

    app.middleware(1,apply=True)
    assert app._future_middleware == []

    app.middleware(attach_to="request")(lambda x, y, z: None)
    list1 = [FutureMiddleware(lambda x, y, z: None, attach_to='request')]
    assert app._future_middleware == list1



# Generated at 2022-06-21 23:11:43.473422
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    _app = Sanic()
    _app.middleware("anything")

# Generated at 2022-06-21 23:11:44.255777
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-21 23:11:50.633674
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.futures import FutureMiddleware
    from sanic.utils import sanic_endpoint_test
    from sanic.app import Sanic

    class _MiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.middleware_called = False
        
        def _apply_middleware(self, middleware: FutureMiddleware):
            self.midd

# Generated at 2022-06-21 23:11:59.485498
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class test_to_test(MiddlewareMixin):
        def __init__(self):
            self.middleware_res = []
            super().__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware_res.append(middleware)
            return

    test_obj = test_to_test()

    @test_obj.on_response("response")
    def on_response_func():
        return

    assert test_obj.middleware_res[0].attach_to == "response"
    return

# Generated at 2022-06-21 23:12:04.020580
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from unittest.mock import Mock
    app = Mock()
    app.middleware = MiddlewareMixin.middleware
    # call function
    MiddlewareMixin.on_response(app, "response")

# Generated at 2022-06-21 23:12:09.338586
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    # Case 1: Call method on_request with middleware
    middleware = 'on_request'
    model = MiddlewareMixin()
    model.on_request(middleware)
    assert model._future_middleware == [
        FutureMiddleware(middleware, 'request')]

    # Case 2: Call method on_request without middleware
    model = MiddlewareMixin()
    model.on_request()
    assert model._future_middleware == []



# Generated at 2022-06-21 23:12:20.794323
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic("test_app", load_env="SANIC_", log_config=False)
    assert app.on_response == app.middleware('response')
    app.on_response(lambda request, response: response)
    assert hasattr(app, '_future_middleware')
    assert isinstance(app._future_middleware, list)
    assert len(app._future_middleware) == 1
    middleware = app._future_middleware[0]

# Generated at 2022-06-21 23:12:29.952181
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.response import json
    from sanic.server import HttpProtocol
    from sanic import Sanic

    app = Sanic(__name__)

    @app.route("/")
    async def handler(request):
        return json({"test": True})

    @app.on_response
    def response_function(request, response):
        if response.body:
            # This has to be bytes. So be careful who handles this.
            response.body += b" appended"


# Generated at 2022-06-21 23:12:35.091422
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import sys
    import os
    import subprocess
    import logging
    import signal
    import unittest
    import requests

    SERVER_ADDRESS = "http://localhost:8000"

    # Creates a sanic server
    PORT = 8000
    app = Sanic("sanic-middleware")

    # Creating a handler for the root url
    @app.get("/")
    async def test(request):
        return response.json({"test":"success"})

    def get_request():
        # Get method is called
        r = requests.get(SERVER_ADDRESS)

        # Validate if the get method returned valid data
        return r.json() ==  {"test":"success"}

    # Driver Code

# Generated at 2022-06-21 23:12:46.785023
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.server import HttpProtocol
    from sanic.views import HTTPMethodView
    from sanic.server import HttpProtocol
    from sanic.response import json

    #  create a app, the _apply_middleware() of the app is not implemented
    class App(MiddlewareMixin):
        pass
    app = App()

    # create a view
    @app.route('/test')
    class TestView(HTTPMethodView):
        @app.on_request()
        def middleware_test_request(self, request):
            return request
        @app.on_response()
        def middleware_test_response(self, request, response):
            return response


# Generated at 2022-06-21 23:12:54.058140
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app=Sanic('test_MiddlewareMixin_middleware')
    test_attach_to = []
    @app.middleware
    async def attach_to(request):
    	test_attach_to.append(request)
    assert test_attach_to == []
    @app.route('/test_MiddlewareMixin_middleware')
    async def handler(request):
    	return text('OK')
    request, response = app.test_client.get('/test_MiddlewareMixin_middleware')
    assert response.text == 'OK'
    assert test_attach_to != []


# Generated at 2022-06-21 23:12:58.413157
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    test_app = Sanic("test_MiddlewareMixin_on_response")
    @test_app.on_response
    def my_middleware(request, response):
        print("called")
    assert test_app.middleware[0]._middleware is my_middleware

# Generated at 2022-06-21 23:13:00.019380
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # TODO: try to have a unit test for this one
    return True


# Generated at 2022-06-21 23:13:06.520188
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import unittest

    from unittest.mock import call, Mock, patch

    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware

    # Mock class
    class T:
        @staticmethod
        def middleware(*args, **kwargs):
            return Mock()

    # Config
    test_object = T()
    test_func = Mock()

    # Begin
    with patch.object(
        T,
        "middleware",
        wraps=test_object.middleware,
        autospec=True,
        return_value=test_func,
    ) as mocked_middleware:
        mocked_middleware.side_effect = test_object.middleware
        # Call
        res = test_object.on_request(middleware=test_func)
        # Check

# Generated at 2022-06-21 23:13:07.711406
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # assert
    pass

# Generated at 2022-06-21 23:13:09.899711
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response.__code__.co_argcount == 1

# Generated at 2022-06-21 23:13:32.977503
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import sanic
    app = sanic.Sanic()

    @app.middleware
    async def handler(request):
        return True

    print(app.router.middlewares)


# Generated at 2022-06-21 23:13:44.615039
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    assert app._future_middleware == []
    app.middleware(middleware_or_request=None, attach_to="request")
    assert len(app._future_middleware) == 1
    app._apply_middleware = None
    app.middleware(middleware_or_request=None, attach_to="response", apply=False)
    assert len(app._future_middleware) == 2
    app._apply_middleware = None
    app.on_request()
    assert len(app._future_middleware) == 3
    app._apply_middleware = None
    app.on_response()
    assert len(app._future_middleware) == 4

# Generated at 2022-06-21 23:13:50.746802
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    import pytest

    app = Sanic()

    @app.on_response
    def foo_response(request, response):
        print('before response')

    assert hasattr(app, "_future_middleware")
    assert len(app._future_middleware) == 1
    assert callable(app._future_middleware[0].middleware)
    assert app._future_middleware[0].attach_to == 'response'

# Generated at 2022-06-21 23:13:58.208839
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.sanic import Sanic
    app = Sanic("test_MiddlewareMixin_on_response")
    mw = app.on_response(lambda x, y: True)
    assert mw.__name__ == "<lambda>"
    mw = app.on_response(mw)
    assert mw.__name__ == "<lambda>"

# Generated at 2022-06-21 23:14:00.645021
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestClass(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_instance = TestClass()
    test_instance.on_request(middleware)

# Generated at 2022-06-21 23:14:10.055042
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Test for method middleware of class MiddlewareMixin
    # Input:
    #   - middleware: function
    # Expect: middleware_or_request is a function

    assert callable(middleware_or_request)

    # Test for method middleware of class MiddlewareMixin
    # Input:
    #   - attach_to: request_type
    # Expect: register_middleware returns a middleware

    assert callable(register_middleware)
    assert attach_to == "request" or attach_to == "response"



# Generated at 2022-06-21 23:14:18.839450
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    @app.on_request
    def on_request(req):
        return req
    assert app._future_middleware[0]._middleware == on_request
    assert app._future_middleware[0]._attach_to == "request"
    assert app._future_middleware[0]._future._func_ref == on_request


# Generated at 2022-06-21 23:14:27.762721
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic()

    @app.on_response
    def test(request, response):
        pass

    assert isinstance(test, partial)

    def test2(request, response):
        pass

    app.on_response(test2)

    assert app._future_middleware[-1].middleware == test2

    @app.middleware('response')
    def test3(request, response):
        pass

    assert app._future_middleware[-1].middleware == test3

# Generated at 2022-06-21 23:14:32.413579
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()
    assert len(app._future_middleware) == 0
    # user_middleware = app.middleware
    # user_middleware = app.middleware('request') 
    @app.middleware
    async def method_middleware1(request,response): 
        print('test_MiddlewareMixin_middleware')
    assert len(app._future_middleware) == 1
    assert callable(app._future_middleware[0].middleware)


# Generated at 2022-06-21 23:14:39.917707
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class App(MiddlewareMixin):
        def _apply_middleware(self, future_middleware):
            pass

    app = App()

    @app.on_response()
    async def simple_middleware(request):
        pass

    assert len(app._future_middleware) == 1
    middleware = app._future_middleware[0]
    assert middleware.attach_to == 'response'
    assert middleware.handler == simple_middleware



# Generated at 2022-06-21 23:15:00.436046
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class test_class_middleware:
        def on_response(self, middleware=None):
            if callable(middleware):
                return self.middleware(middleware, "response")
            else:
                return partial(self.middleware, attach_to="response")
    test_obj = test_class_middleware()
    test_obj.on_response()

# Generated at 2022-06-21 23:15:08.705472
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic(__name__)

    @app.on_request
    def function_to_test_on_request(request):
        return

    assert isinstance(app._future_middleware, list)
    assert len(app._future_middleware) == 1
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].func == function_to_test_on_request
    assert app._future_middleware[0].attach_to == "request"


# Generated at 2022-06-21 23:15:11.215994
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    dd=MiddlewareMixin()
    assert callable(dd.on_request())


# Generated at 2022-06-21 23:15:18.394414
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(TestClass, self).__init__(*args, **kwargs)

    class TestMiddleware:
        @staticmethod
        def test():
            return True

    test_obj = TestClass()
    test_obj.middleware(TestMiddleware.test)

    assert test_obj._future_middleware[0].func() == True

# Generated at 2022-06-21 23:15:25.163739
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestClass1(MiddlewareMixin):
        pass
    @TestClass1.middleware
    async def middleware(request):
        print(request)
    mw = TestClass1()._future_middleware
    assert len(mw) == 1
    assert mw[0].attach_to == "request"


# Generated at 2022-06-21 23:15:36.282912
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.futures import FutureMiddleware
    from sanic.models.futures import Future
    from sanic.models.request import Request

    class TestMiddlewareMixin(MiddlewareMixin):
        pass

    request = Request('get', 'http://127.0.0.1:8000/', '', '', False, False)
    middleware = FutureMiddleware(TestMiddlewareMixin.on_request, 'request')
    TestMiddlewareMixin._future_middleware.append(middleware)

    def test_on_request_middleware():
        class TestMiddlewareMixin(MiddlewareMixin):
            pass

        request = Request('get', 'http://127.0.0.1:8000/', '', '', False, False)

        def on_request_middleware(request):
            return

# Generated at 2022-06-21 23:15:43.894652
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError
    a = A()
    a.middleware(lambda *args, **kwargs: args)
    a.on_request(lambda *args, **kwargs: args)
    a.on_response(lambda *args, **kwargs: args)

# Generated at 2022-06-21 23:15:45.701334
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Test(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    test = Test()
    assert test.on_response()

# Generated at 2022-06-21 23:15:47.030283
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # TODO
    pass



# Generated at 2022-06-21 23:15:53.987949
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Foo(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    foo = Foo()
    @foo.on_request()
    def foo_request(request):
        pass
    assert foo._future_middleware == [FutureMiddleware(foo_request, 'request')]



# Generated at 2022-06-21 23:16:37.111231
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    # app.__class__.__name__
    on_response = MiddlewareMixin.on_response
    assert on_response(app) == partial(MiddlewareMixin.middleware, app, attach_to="response")
    # assert on_response(app)(test_func) == test_func



# Generated at 2022-06-21 23:16:44.760694
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    class Mixin:
        def __init__(self):
            self.middlewares = []

        def _apply_middleware(self, middleware):
            self.middlewares.append(middleware)

    class App(Mixin, MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self.middlewares = []

        def __call__(self, *args, **kwargs):
            return super().__call__(*args, **kwargs)

    app = App()

    @app.middleware
    async def test1(request):
        return

    @app.middleware('response')
    async def test2(request, response):
        return

    @app.on_request
    async def test3(request):
        return

   

# Generated at 2022-06-21 23:16:52.963460
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # GIVEN
    class MockMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    # WHEN
    middleware_mixin = MockMiddlewareMixin()
    middleware = lambda: None
    response_middleware = middleware_mixin.on_response(middleware)
    # THEN
    middleware_mixin._future_middleware[0].attach_to == 'response'
    middleware_mixin._future_middleware[0].middleware == middleware

# Generated at 2022-06-21 23:16:55.843479
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    # The class Sanic is tested
    app = Sanic(__name__)

    # Unit test for Sanic class which has method on_request
    app.on_request(lambda: 0)


# Generated at 2022-06-21 23:16:58.477627
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    @MiddlewareMixin.on_response()
    def middleware(request):
        pass

    assert callable(middleware) is True

# Generated at 2022-06-21 23:17:02.968300
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic()
    @app.middleware
    def auth(request):
        return request.authorization

    @app.route('/')
    async def handler(request):
        return json({'test': True})
    request, _ = app.test_client.get('/')
    assert request.authorization is None


# Generated at 2022-06-21 23:17:05.786356
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    app = Sanic("MiddlewareMixin_on_request")

    assert app.on_request()("response") == partial(
        app.middleware, attach_to="request"
    )("response")

# Generated at 2022-06-21 23:17:11.478585
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Test:
        def __init__(self):
            self._future_middleware = []

        @MiddlewareMixin.on_request
        def test(self, request):
            return request

    test_obj = Test()
    assert isinstance(test_obj, Test)


# Generated at 2022-06-21 23:17:18.739137
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import text

    from typing import Callable

    def test_middleware(request):
        nonlocal mid_var
        mid_var = "1"

    async def test_handler(request):
        nonlocal mid_var
        if mid_var == "1":
            return text("success")

    app = Sanic()

    test_middleware = app.middleware(test_middleware)
    assert isinstance(test_middleware, Callable)

    mid_var = "0"
    app.add_route(test_handler, "/test_route")

    _, response = app.test_client.get("/test_route")
    asse

# Generated at 2022-06-21 23:17:26.612651
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import sys
    import os
    import pytest
    CurrDir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))).replace("\\", "/")
    sys.path.append(CurrDir)
    from sanic import Sanic
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import InvalidUsage
    from sanic.blueprints import Blueprint
    from sanic.constants import HTTP_METHODS

    from sanic.models.futures import FutureMiddleware
    from sanic.models.utils import error_handler
    from sanic.models.utils import _is_generator_

# Generated at 2022-06-21 23:18:56.728191
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.futures import FutureMiddleware
    from unittest.mock import patch

    class UnitTest(MiddlewareMixin):
        pass

    # Case - 1
    # Test for successful registration of middleware
    ut = UnitTest()
    @ut.middleware
    def middleware(request):
        pass
    assert isinstance(ut._future_middleware[0], FutureMiddleware)
    assert ut._future_middleware[0].middleware == middleware
    assert ut._future_middleware[0].attach_to == "request"

    # Case - 2
    # Test for successful registration of middleware
    ut = UnitTest()
    @ut.middleware('response')
    def middleware(request):
        pass
    assert isinstance(ut._future_middleware[0], FutureMiddleware)


# Generated at 2022-06-21 23:19:04.587965
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        def get(self, request):
            return text("OK!")

    app = Sanic("test_MiddlewareMixin_on_request")
    app.add_route(MyView.as_view(), '/')

    @app.on_request
    def custom_middleware(request):
        pass

    request, response = app.test_client.get('/')

    assert response.status == 200


# Generated at 2022-06-21 23:19:06.236187
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass
    # TODO

# Generated at 2022-06-21 23:19:15.446643
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert issubclass(MiddlewareMixin, object)
    assert MiddlewareMixin.__base__ == object

    obj = MiddlewareMixin()
    assert isinstance(obj, MiddlewareMixin)

    assert isinstance(obj._future_middleware, list)
    assert isinstance(obj._apply_middleware, collections.abc.Callable)
    assert isinstance(obj.middleware, collections.abc.Callable)
    assert isinstance(obj.on_request, collections.abc.Callable)
    assert isinstance(obj.on_response, collections.abc.Callable)

