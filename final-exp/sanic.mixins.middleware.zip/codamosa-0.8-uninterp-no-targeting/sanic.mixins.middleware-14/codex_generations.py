

# Generated at 2022-06-21 23:09:23.200337
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    with pytest.raises(NotImplementedError):
        m = MiddlewareMixin()
        m._apply_middleware()

# Generated at 2022-06-21 23:09:27.637809
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.sanic import Sanic
    from middleware import RequestMiddleware
    import sys; sys.argv = ['', 'test']
    app = Sanic(__name__)
    app.middleware(RequestMiddleware)
    assert app.is_request_stream



# Generated at 2022-06-21 23:09:39.999672
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.middleware import ErrorMiddleware
    from sanic.exceptions import NotFound, ServerError, URLBuildError
    from sanic import response

    app = Sanic("test_MiddlewareMixin")
    error_middleware = ErrorMiddleware()

    @app.middleware
    def m_middleware(request):
        return response.text('OK')

    # test
    assert [
        (m.middleware, m.attach_to)
        for m in app._future_middleware
    ] == [(error_middleware, 'request'), (m_middleware, 'request')]

# Generated at 2022-06-21 23:09:47.127700
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Server(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    def update_response():
        pass
    app = Server()
    app_middleware = app.on_response(update_response)
    assert (app_middleware.__name__ == update_response.__name__)

if __name__ == "__main__":
    test_MiddlewareMixin_on_response()

# Generated at 2022-06-21 23:10:00.857058
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    c = MiddlewareMixin()

    @app.middleware('request')
    def request_middleware(request):
        return request

    @app.middleware('response')
    def request_middleware(request):
        return request

    c._future_middleware = app.middleware

    assert isinstance(app._future_middleware, list)
    assert len(app._future_middleware) == 2
    assert isinstance(app._future_middleware[0], FutureMiddleware)
    assert app._future_middleware[0].attach_to == 'request'
    assert isinstance(app._future_middleware[1], FutureMiddleware)
    assert app._future_middleware[1].attach_to == 'response'

# Generated at 2022-06-21 23:10:03.074854
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    print ("Unit test for constructor of class MiddlewareMixin")
    middlewares = MiddlewareMixin()
    assert middlewares._future_middleware == []
    print ("Test passed")


# Generated at 2022-06-21 23:10:06.321110
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    @MiddlewareMixin.on_response
    def test_middleware(request, response):
        pass
    assert callable(test_middleware)

# Generated at 2022-06-21 23:10:15.834557
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Given
    class FakeClass(MiddlewareMixin):
        def __init__(self):
            self.attach_to = ""
            self.middleware = ""

        def _apply_middleware(self, middleware):
            self.attach_to = middleware.attach_to
            self.middleware = middleware.middleware

    # Given
    def request_middleware(request):
        pass

    def response_middleware(request, response):
        pass

    # When
    mixin = FakeClass()
    mixin.on_request(request_middleware)()
    mixin.on_response(response_middleware)()

    # Then
    assert mixin.attach_to == "response"
    assert mixin.middleware == response_middleware

# Generated at 2022-06-21 23:10:17.752209
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    try:
        MiddlewareMixin().middleware()
    except NotImplementedError as err:
        assert 'object has no attribute' in str(err)


# Generated at 2022-06-21 23:10:18.514749
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass



# Generated at 2022-06-21 23:10:26.967479
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware
    app = Sanic('test_MiddlewareMixin_middleware')
    with pytest.raises(NotImplementedError):
        app._apply_middleware(FutureMiddleware(None, 'request'))
    app.middleware()

# Generated at 2022-06-21 23:10:35.956352
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    #1
    MiddlewareMixin.on_request(middleware=None) # noqa
    #2
    class MiddlewareMixin:
        def on_request(self, middleware=None):
            if callable(middleware):
                return self.middleware(middleware, "request")
            else:
                return partial(self.middleware, attach_to="request")

    MiddlewareMixin = MiddlewareMixin()
    MiddlewareMixin.on_request(middleware=None) # noqa

    #3
    class MiddlewareMixin:
        def on_request(self, middleware=None):
            if callable(middleware):
                return self.middleware(middleware, "request")
            else:
                return partial(self.middleware, attach_to="request")


# Generated at 2022-06-21 23:10:38.387411
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin._future_middleware == []

# Generated at 2022-06-21 23:10:45.126526
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import json
    from sanic.views import HTTPMethodView
    from sanic.response import json as res_json

    class Resource(HTTPMethodView):
        def get(self, request):
            return res_json({"message": "OK"})

    class AppMock(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = AppMock()
    res = app.on_response(middleware=Resource.as_view())
    # This is the callable
    assert res.__name__ == "dispatch_request"
    assert res.__name__ != "get"



# Generated at 2022-06-21 23:10:54.279774
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import instamatic
    from types import FunctionType
    
    mm = instamatic.app.MiddlewareMixin()
    on_response = mm.on_response
    assert type(on_response) is FunctionType
    assert on_response.__name__ == 'on_response'
    assert on_response.__doc__ == mm.middleware.__doc__
    assert on_response.__defaults__ == ('request',)
    
    
    
    # test with simple middleware
    @on_response
    def test_middleware(request, response):
        return (request, response)
    
    test_middleware_fut_middle = instamatic.app.FutureMiddleware(test_middleware, "response")
    assert test_middleware_fut_middle in mm._future_middleware
     
    


# Generated at 2022-06-21 23:10:58.311398
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock
    print("test MiddlewareMixin_on_response")
    instance = MagicMock(spec=MiddlewareMixin)
    callable_obj = MagicMock()
    instance.on_response(callable_obj)
    instance.middleware.assert_called_once_with(callable_obj, "response")

# Generated at 2022-06-21 23:10:59.506792
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response()

# Generated at 2022-06-21 23:11:01.877750
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    obj = MiddlewareMixin()
    assert obj
    assert obj._future_middleware


# Generated at 2022-06-21 23:11:12.729620
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.request import Request
    from sanic.response import HTTPResponse

    @asyncio.coroutine
    def middleware(request: Request) -> HTTPResponse:
        return HTTPResponse(text="Middleware executed")

    @asyncio.coroutine
    def handler(request: Request) -> HTTPResponse:
        return HTTPResponse(text="Request handler executed")

    class DummyMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            self.request = None
            self.response = None
            super().__init__()

        def _apply_middleware(self, middleware:FutureMiddleware):
            self.response = middleware(self.request)
            return self.response

    # case 1: attach_to == "request"


# Generated at 2022-06-21 23:11:23.320497
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from unittest import TestCase, mock
    from sanic.blueprints import Blueprint

    class MockMiddleware(MiddlewareMixin):
        def __getattr__(self, item):
            return mock.Mock()

        def on_request(self, request):
            return mock.Mock()

    bp = Blueprint(__name__)
    middleware = MockMiddleware()

    @bp.middleware(middleware.on_response)
    def response(request, response):
        return mock.Mock()
        # assert_test(request, response)

    # assert response(mock.Mock()) == None

    # assert not isinstance(response, mock.Mock)
    # assert response is response_handler

    # assert middleware.middleware.call_count == 1
    # assert middleware.middleware.called_

# Generated at 2022-06-21 23:11:34.047803
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.response import HTTPResponse
    app = Sanic()
    assert isinstance(app._future_middleware, list)


# Generated at 2022-06-21 23:11:38.180491
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    _MiddlewareMixin = MiddlewareMixin()
    @_MiddlewareMixin.middleware('request')
    def my_middleware(request):
        pass
    _MiddlewareMixin.middleware('request', my_middleware)



# Generated at 2022-06-21 23:11:40.346633
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass


# Generated at 2022-06-21 23:11:47.486906
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic()

    @app.middleware('request')
    async def request_middleware(request):
        request['middleware'] = 'this is a middleware'

    request, response = app.test_client.get('/')

    assert request['middleware'] == 'this is a middleware'


# Generated at 2022-06-21 23:11:55.217279
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Application
    app = Application()
    app.middleware(lambda x,y: x+1, attach_to="a")
    assert len(app._future_middleware) == 1
    assert app.middleware.__name__ == 'register_middleware'
    assert app.middleware.__doc__ == 'Decorate and register middleware to be called before a request.\n        Can either be called as *@app.middleware* or\n        *@app.middleware(\'request\')*\n\n        See user guide re: middleware\n        <https://sanicframework.org/guide/basics/middleware.html>__\n\n        :param: middleware_or_request: Optional parameter to use for\n            identifying which type of middleware is being registered.\n        '
   

# Generated at 2022-06-21 23:11:59.693448
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
        m1 = MiddlewareMixin()
        assert m1.on_response().__closure__[0].cell_contents == "response"
        m2 = MiddlewareMixin()
        m2.on_response(lambda: None)
        assert m2._future_middleware[0].type == "response"
        assert m2._future_middleware[0].middleware() == None
        m3 = MiddlewareMixin()
        assert m3.on_respo

# Generated at 2022-06-21 23:12:05.713335
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():   
    from sanic import Sanic
    app = Sanic(__name__)
    @app.middleware
    async def print_on_response(request):
        print("on response")
    assert print_on_response == app.on_response(print_on_response)

# Generated at 2022-06-21 23:12:07.242816
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    app = Sanic('name')
    print(app)


# Generated at 2022-06-21 23:12:16.016953
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app=Sanic('test')
    mm=MiddlewareMixin()
    mm_middleware = mm.middleware(middleware_or_request=None)
    
    @app.middleware(middleware_or_request='request')
    @mm.middleware(middleware_or_request='request')
    def test(request):
        return
    @app.middleware(middleware_or_request='response')
    @mm.middleware(middleware_or_request='response')
    def test(response):
        return
    @app.on_request()
    @mm.on_request()
    def test(request):
        return
    @app.on_response()
    @mm.on_response()
    def test(response):
        return 
    return

#

# Generated at 2022-06-21 23:12:16.737341
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    def test1():
        pass
    test1()

# Generated at 2022-06-21 23:12:25.277621
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    emty_list = []
    A = MiddlewareMixin()
    assert A._future_middleware == emty_list

# Generated at 2022-06-21 23:12:32.141652
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class MiddlewareMixinTest(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_middleware = []

        def _apply_middleware(self, middleware):
            pass

        def on_request(self, middleware=None):
            pass

    # Test1 on_response without argument
    test_obj = MiddlewareMixinTest(None)
    assert callable(test_obj.on_response())

    # Test2 on_response with argument
    def test_func(request):
        pass
    test_obj.on_response(test_func)
    assert test_obj._future_middleware[-1].function == test_func

# Generated at 2022-06-21 23:12:43.579903
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import HTTPResponse

    def request_middleware_useful(request):
        return HTTPResponse("response from request_middleware_useful")

    my_middleware = MiddlewareMixin()
    my_middleware.on_request(request_middleware_useful)
    assert len(my_middleware._future_middleware) == 1
    assert my_middleware._future_middleware[0].middleware == request_middleware_useful
    assert my_middleware._future_middleware[0].attach_to == "request"

    def request_middleware_no_useful(request):
        return HTTPResponse("response from request_middleware_no_useful")


# Generated at 2022-06-21 23:12:46.949893
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic

    app = Sanic('test')
    assert isinstance(app, MiddlewareMixin)

# Generated at 2022-06-21 23:12:48.725494
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin().on_response() == \
        MiddlewareMixin().middleware(attach_to="response")

# Generated at 2022-06-21 23:12:50.407871
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    async def handle_response(request, response):
        print("Hello, world!")
    assert app.middleware
    return True

# Generated at 2022-06-21 23:12:56.691631
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    import unittest

    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    class TestCase(unittest.TestCase):
        def test_middleware(self):
            test_instance = TestMiddlewareMixin()
            @test_instance.on_request()
            def middleware():
                pass

            self.assertEqual(len(test_instance._future_middleware), 1)
            self.assertEqual(test_instance._future_middleware[0].middleware, middleware)

    unittest.main()

# Generated at 2022-06-21 23:13:00.454236
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.application import Application

    """
    Initialize the middlewareMixin class and assert
    the values of _future_middleware is []
    """
    app = Application(__name__)
    assert app._future_middleware == []
    print("test_MiddlewareMixin test passed.")

# Generated at 2022-06-21 23:13:04.102729
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.server import Sanic
    a = Sanic("test_sanic")
    assert a._future_middleware == []

    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    a = TestMiddlewareMixin("test_mixin")
    assert a._future_middleware == []

# Generated at 2022-06-21 23:13:13.206012
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    """Unit tests for method on_response of class MiddlewareMixin."""
    class A(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass
    import pytest
    from functools import partial
    a = A()
    with pytest.raises(NotImplementedError):
        a.on_response()
    with pytest.raises(NotImplementedError):
        a.on_response(None)
    with pytest.raises(NotImplementedError):
        a.on_response(True)
    with pytest.raises(NotImplementedError):
        a.on_response(1)
    with pytest.raises(NotImplementedError):
        a.on_response(1.0)

# Generated at 2022-06-21 23:13:34.281506
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin(1, 2, 3)
    assert m is not None

# Generated at 2022-06-21 23:13:41.044290
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    assert app.__class__.middleware is MiddlewareMixin.middleware
    assert app.__class__.on_request is MiddlewareMixin.on_request
    assert app.__class__.on_response is MiddlewareMixin.on_response
    assert app._future_middleware == []
    assert app._apply_middleware is None

# Generated at 2022-06-21 23:13:47.247554
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Middleware:
        pass

    class Mixin(MiddlewareMixin):
        pass

    m = Middleware()
    mixin = Mixin()

    assert mixin._future_middleware == []
    mixin.middleware(m)
    assert mixin._future_middleware != []

# Generated at 2022-06-21 23:13:50.334159
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin_object = MiddlewareMixin()
    assert middleware_mixin_object._future_middleware == []
    assert middleware_mixin_object._apply_middleware is False
    # assert middleware_mixin_object is None

# Generated at 2022-06-21 23:13:55.847048
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    test_middleware_mixin = MiddlewareMixin()
    @test_middleware_mixin.on_response
    def test_middleware():
        print("Test Middleware Mixin")
    test_middleware()


# Generated at 2022-06-21 23:14:04.166287
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    from sanic.models.futures import FutureMiddleware

    app = Sanic("test_MiddlewareMixin_middleware")

    # Create a test middleware to modify the response
    async def middleware(request):
        request.ctx.update({"test": "value"})
        response = text("Not so fast")
        return response

    # Register the middleware
    app.middleware(middleware)

    # Check that the middleware was added to the list
    assert len(app.middleware._future_middleware) == 1

    # Check that the middleware is a FutureMiddleware instance
    assert isinstance(app.middleware._future_middleware[0], FutureMiddleware)

    # Check that the middleware was applied

# Generated at 2022-06-21 23:14:05.342709
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Mixin(MiddlewareMixin):
        pass
    assert MiddlewareMixin._future_middleware == []
    assert Mixin._future_middleware == []


# Generated at 2022-06-21 23:14:10.245246
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    app = Sanic()

    app.__class__.__bases__ = (MiddlewareMixin,) + app.__class__.__bases__

    assert app._future_middleware == []

# Test for class MiddlewareMixin method middleware()

# Generated at 2022-06-21 23:14:11.945994
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-21 23:14:22.568361
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class MiddlewareMixin_on_response_Test(MiddlewareMixin):
        def __init__(self):
            self._future_middleware = []
    middleware_mixin_on_response_test = MiddlewareMixin_on_response_Test()
    def middleware(middleware=None):
        if callable(middleware):
            return middleware_mixin_on_response_test.middleware(middleware, "response")
        else:
            return partial(
                middleware_mixin_on_response_test.middleware, attach_to="response"
            )

# Generated at 2022-06-21 23:14:48.087523
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin = MiddlewareMixin()
    assert mixin._future_middleware == []

# Generated at 2022-06-21 23:14:49.438076
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()

# Generated at 2022-06-21 23:15:00.762451
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.exceptions import (
        RequestTimeout,
        PayloadTooLarge,
        RequestURITooLarge,
        ContentTypeError,
        ServerError,
        URLRequired,
        TooManyRedirects,
        MissingSchema,
        InvalidSchema,
        InvalidURL,
    )
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketProtocol

    from sanic.models.futures import FutureMiddleware

    app = Sanic("sanic-test")
    assert isinstance(app, MiddlewareMixin)

    def middleware_fn_request(request: Request):
        return


# Generated at 2022-06-21 23:15:02.166692
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass



# Generated at 2022-06-21 23:15:05.298180
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestClass(MiddlewareMixin):
        pass
    x_test = TestClass()
    assert x_test._future_middleware == []

# Generated at 2022-06-21 23:15:12.659624
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestClass(MiddlewareMixin):
        def __init__(self):
            super(MiddlewareMixin, self).__init__()
            self._future_middleware = []

    def fake_middleware(request):
        return request + 2

    t = TestClass()

    def fake_apply_middleware(future_middleware):
        return future_middleware

    t._apply_middleware = fake_apply_middleware
    t.middleware(fake_middleware)
    assert t._future_middleware[0].middleware == fake_middleware
    assert t._future_middleware[0].attach_to == "request"
    assert t._future_middleware[0].applied is True

    t._future_middleware = []

# Generated at 2022-06-21 23:15:18.533398
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    import pytest

    with pytest.raises(Exception):
        MiddlewareMixin()
    m = MiddlewareMixin()
    assert len(m._future_middleware) == 0
    with pytest.raises(NotImplementedError):
        m._apply_middleware(None)
    with pytest.raises(Exception):
        m.middleware(None)


# Generated at 2022-06-21 23:15:21.985465
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert(isinstance(MiddlewareMixin().on_response(), partial))
    assert(MiddlewareMixin().on_response(lambda: None) is not None)

# Generated at 2022-06-21 23:15:28.157052
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    import asyncio
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.route('/')
    async def handler(request):
        return response.text('OK')
    @app.on_response
    def response_middleware(request, response):
        response.headers["test-middleware"] = "true"
    request, response = app.test_client.get('/')
    assert response.headers["test-middleware"] == "true"

# Generated at 2022-06-21 23:15:28.780886
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()

# Generated at 2022-06-21 23:15:54.390611
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    instance = MiddlewareMixin()
    assert isinstance(instance, MiddlewareMixin)
    assert instance._future_middleware == []

# Unit test that an error will be raised when trying to call _apply_middleware

# Generated at 2022-06-21 23:15:55.960469
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    result = app.middleware()
    assert result is not None



# Generated at 2022-06-21 23:15:57.305886
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # TODO
    pass

# Generated at 2022-06-21 23:16:00.145361
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    http_server = HTTPServer()
    assert callable(http_server.on_response())

# Generated at 2022-06-21 23:16:04.743731
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic(__name__)
    @app.on_response('sdfsdfsdfsdf')
    async def test_response(request, response):
        pass

# Generated at 2022-06-21 23:16:07.879859
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
  middlewareMixin = MiddlewareMixin()
  assert middlewareMixin._future_middleware == [], "must be []"

# Generated at 2022-06-21 23:16:12.108780
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.response import json

    app = Sanic('test_MiddlewareMixin_on_request')

    @app.on_request()
    def process_request(request):
        print('Request')
    @app.route('/')
    async def index(request):
        return json({'hello': 'world'})


# Generated at 2022-06-21 23:16:22.715480
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestingMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)

    mm = TestingMiddlewareMixin()

    @mm.on_response()
    def response_middleware(request):
        return request

    assert len(mm._future_middleware) == 0
    mm.middleware(None)
    assert len(mm._future_middleware) == 1
    assert mm._future_middleware[0].middleware == response_middleware
    assert mm._future_middleware[0].attach_to == "response"


# Generated at 2022-06-21 23:16:23.778260
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []

# Generated at 2022-06-21 23:16:33.616930
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class FakeSanic(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    app = FakeSanic()
    app2 = FakeSanic()
    def fake_middleware(request):
        pass
    app.on_response(fake_middleware)
    assert len(app._future_middleware) == 1
    # Verify that the partial function has been created successfully.
    # The following is the original code snippet in the source file.
    # app2.on_response(fake_middleware)
    app2.on_response(attach_to="response")(fake_middleware)
    assert len(app2._future_middleware) == 1



# Generated at 2022-06-21 23:17:20.703919
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.exceptions import SanicException

    def customMiddleware(request):
        return request

    app = Sanic('test_on_request')
    try:
        app.on_request()
        assert False
    except SanicException:
        assert True

    try:
        app.on_request(customMiddleware, 'dfds')
        assert False
    except SanicException:
        assert True

    app.on_request(customMiddleware)



# Generated at 2022-06-21 23:17:25.183595
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin1(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            return middleware

    testapp1 = TestMiddlewareMixin1()
    def middleware(self):
        return 1

    assert testapp1.middleware == MiddlewareMixin.middleware

    testapp1_middleware = testapp1.middleware(middleware)
    assert testapp1_middleware == middleware

    testapp1_middleware = testapp1.middleware(middleware, attach_to="request")
    assert testapp1_middleware == middleware

# Generated at 2022-06-21 23:17:34.266433
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.models.middleware import MiddlewareMixin
    from sanic.models.futures import FutureMiddleware

    app = Sanic()

    assert app._future_middleware == []
    assert app.on_request() != None
    assert app.on_request()(lambda request: None) == None
    assert isinstance(app._future_middleware[-1], FutureMiddleware)
    assert app._future_middleware[-1].middleware == app.on_request()(lambda request: None)

# Generated at 2022-06-21 23:17:44.225812
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.futures import FutureMiddleware
    from sanic.views.static import serve_file
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    
    class Test_middleware:
        def test_register_middleware(self):
            test = TestMiddlewareMixin()
            middleware = serve_file
            attach_to = "request"

            test.middleware(middleware, attach_to=attach_to)
            assert test._future_middleware[-1] == FutureMiddleware(middleware, attach_to)
        
        def test_register_middleware_without_attach_to(self):
            test = TestMiddlewareMixin()
            middleware = serve_file

# Generated at 2022-06-21 23:17:55.516722
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic()

    @app.middleware('request')
    def handler(request):
        pass

    assert "request" in app._future_middleware

    # Same way as decorator is called.
    @app.on_request
    def handler1(request):
        pass

    assert "request" in app._future_middleware

    # Same way as decorator is called.
    @app.on_request()
    def handler2(request):
        pass

    assert "request" in app._future_middleware

    # Same way as decorator is called.
    app.on_request(handler3)

    assert "request" in app._future_middleware


# Generated at 2022-06-21 23:17:57.967590
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    test = MiddlewareMixin()
    assert test._future_middleware == []


# Generated at 2022-06-21 23:18:02.883924
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.middleware import MiddlewareMixin
    m = MiddlewareMixin()
    # Check that middleware is a function in Main class of file "sanic/app.py"
    assert callable(MiddlewareMixin.middleware)


# Generated at 2022-06-21 23:18:08.526406
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic

    app = Sanic()
    def test():
        return "This is a test"

    app.on_response(test)
    assert app._future_middleware[0].function == test
    assert app._future_middleware[0].attach_to == "response"

# Generated at 2022-06-21 23:18:16.921999
# Unit test for method on_response of class MiddlewareMixin

# Generated at 2022-06-21 23:18:19.125693
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass
