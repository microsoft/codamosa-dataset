

# Generated at 2022-06-21 23:09:26.413734
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    a = A()
    @a.middleware
    def one():
        pass
    assert isinstance(a._future_middleware[0], FutureMiddleware)
    assert a._future_middleware[0].middleware is one
    assert a._future_middleware[0].attach_to == "request"

# Generated at 2022-06-21 23:09:32.373444
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class a:
        def __init__(self):
            self._future_middleware = []
        def middleware(self, middleware_or_request, attach_to="request", apply=True):
            def register_middleware(middleware, attach_to="request"):
                future_middleware = FutureMiddleware(middleware, attach_to)
                self._future_middleware.append(future_middleware)
                if apply:
                    self._apply_middleware(future_middleware)
                return middleware
            if callable(middleware_or_request):
                return register_middleware(middleware_or_request, attach_to=attach_to)
            else:
                return partial(register_middleware, attach_to=middleware_or_request)

# Generated at 2022-06-21 23:09:34.956430
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass

# Generated at 2022-06-21 23:09:38.660671
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic()
    x = app.middleware(middleware_or_request='request')
    y = x(middleware='middleware')
    assert isinstance(y, MiddlewareMixin)


# Generated at 2022-06-21 23:09:45.296103
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic('test_MiddlewareMixin_on_response')


# Generated at 2022-06-21 23:09:48.302865
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic("sanic-cookies-test")

    @app.on_request
    def method_to_call(request):
        return True

    assert method_to_call == app._future_middleware[0].middleware



# Generated at 2022-06-21 23:10:01.005364
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware
    from utils.constant import UNIT_TEST_CONFIG
    from utils.middleware.utility import get_middleware_from_request

    @Sanic.middleware
    def middleware_1(request):
        request['middleware_1'] = True
        return request

    @Sanic.middleware
    def middleware_2(request):
        request['middleware_2'] = True
        return request

    @Sanic.middleware
    def middleware_3(request):
        request['middleware_3'] = True
        return request

    # test default constructor
    application = Sanic(__name__)
    assert application._future_middleware == []

    # test add middleware in default way
    application

# Generated at 2022-06-21 23:10:11.859670
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    mwm = TestMiddlewareMixin()
    # call middleware without args
    m1 = mwm.middleware()
    # assert that m1 is a <function TestMiddlewareMixin.middleware.<locals>.register_middleware> # noqa
    assert m1.__name__ == 'register_middleware'
    assert m1.__qualname__ == 'TestMiddlewareMixin.middleware.<locals>.register_middleware' # noqa
    # assert that the returned partial function is a partial of <function TestMiddlewareMixin.middleware> # noqa
    assert m1.func.__name__ == 'middleware'

# Generated at 2022-06-21 23:10:19.831882
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.middleware
    def test_on_request(request):
        assert isinstance(request, Request)
        return request

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0]
    assert app._future_middleware[0].name == 'test_on_request'
    assert callable(app._future_middleware[0].middleware)
    assert app._future_middleware[0].attach_to == 'request'



# Generated at 2022-06-21 23:10:25.469747
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class ClassA(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    classA = ClassA()

    assert len(classA._future_middleware) == 0

# Generated at 2022-06-21 23:10:35.395938
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class FakeMiddlewareMixin():
        def __init__(self):
            self.middleware_called = False
        def middleware(self, middleware_or_request, attach_to):
            self.middleware_called = True
            self.middleware_or_request = middleware_or_request
            self.attach_to = attach_to
    f = FakeMiddlewareMixin()
    f.on_request(middleware=lambda x:x + 1)
    assert f.middleware_called
    assert f.middleware_or_request(1) == 2
    assert f.attach_to == "request"

# Generated at 2022-06-21 23:10:40.811170
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic("test_MiddlewareMixin_on_request")

    # Unit test 1: Test the return value of on_request
    @app.on_request  # noqa
    def test_on_request(request):
        pass

    # Unit test 2: Test the return value of on_request
    @app.on_request  # noqa
    async def test_on_request_async(request):
        pass



# Generated at 2022-06-21 23:10:45.244464
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    m = MiddlewareMixin()

    assert m.on_response()(str) == m.middleware(str, "response")
    assert m.on_response(str) == m.middleware(str, "response")

# Generated at 2022-06-21 23:10:52.243452
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    
    def middleware_request(request):
        request.cbp_middleware_request = True

    def middleware_response(request, response):
        response.cbp_middleware_response = True    

    app = Sanic(__name__)

    app.on_request(middleware_request)
    app.on_response(middleware_response)

    assert app.on_request == app.middleware
    assert app.on_response == app.middleware

# Generated at 2022-06-21 23:10:56.839950
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class A(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    a = A()
    assert isinstance(a._future_middleware, list)
    assert len(a._future_middleware) == 0


# Generated at 2022-06-21 23:10:57.602187
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


# Generated at 2022-06-21 23:10:58.586333
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []

# Generated at 2022-06-21 23:11:01.046035
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Test1: test with one parameter
    @app.on_response
    def middleware(request):
        return "request"

    # Test2: test with two parameters
    @app.on_response()
    def middleware1(request, response):
        return "request"


# Generated at 2022-06-21 23:11:10.670808
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    def middleware_assertion(*args, **kwargs):
        assert len(args) == 1
        assert args[0] == FutureMiddleware
        assert len(kwargs) == 2
        assert kwargs['attach_to'] == 'test_value'
        assert kwargs['apply'] == True

    mm = MiddlewareMixin()
    mm._apply_middleware = middleware_assertion
    mm.middleware(MiddlewareMixin, attach_to='test_value')
    mm.on_request(MiddlewareMixin)
    mm.on_response(MiddlewareMixin)

# Generated at 2022-06-21 23:11:14.636150
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Assert that value of _future_middleware is empty
    mix = MiddlewareMixin()
    assert mix._future_middleware == []


# Generated at 2022-06-21 23:11:28.068283
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self.called = False

        def _apply_middleware(self, middleware: FutureMiddleware):
            if middleware.name == "on_request":
                self.called = True

    test = TestMiddlewareMixin()
    test.middleware("on_request", apply=False)
    assert test._future_middleware
    assert not test.called
    test.on_request()
    assert test.called


# Generated at 2022-06-21 23:11:29.282864
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    a = MiddlewareMixin()

# Generated at 2022-06-21 23:11:40.974860
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class FutureMiddleware(MiddlewareMixin):
        def __init__(self):
            super(FutureMiddleware, self).__init__()
            self.is_middleware_called = False
            self.request_middleware_called = False
            self.response_middleware_called = False
        def _apply_middleware(self, future_middleware: FutureMiddleware):
            self.is_middleware_called = True
            if future_middleware.attach_to == 'request':
                self.request_middleware_called = True
            elif future_middleware.attach_to == 'response':
                self.response_middleware_called = True
        def middleware(self):
            super(MiddlewareMixin, self).middleware('request')
            super(MiddlewareMixin, self).middleware('response')
           

# Generated at 2022-06-21 23:11:47.482786
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Testi:
        @staticmethod
        def mdd(self, request, response):
            return response

    mdd = Testi()
    mm = MiddlewareMixin()
    mm.on_response(mdd)
    assert mm._future_middleware == [
        FutureMiddleware(middleware=mdd, attach_to="response")
    ]

# Generated at 2022-06-21 23:11:49.474675
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    app = Sanic()
    assert isinstance(app._future_middleware, list)


# Generated at 2022-06-21 23:12:00.900158
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Arrange
    class ExpectedClass:
        def __init__(self, 
                     *args, 
                     **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa


# Generated at 2022-06-21 23:12:09.923414
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MockMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    # when middleware_or_request is a request object
    mock = MockMiddlewareMixin()
    mock.middleware(request='request')
    # when middleware_or_request is a middleware object
    mock = MockMiddlewareMixin()
    mock.middleware(middleware='middleware')


# Generated at 2022-06-21 23:12:11.872737
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Test_Object(MiddlewareMixin):
        pass
    test_object = Test_Object()
    test_object.on_response()

# Generated at 2022-06-21 23:12:13.028195
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    m = MiddlewareMixin()
    res = m.on_response(middleware="test")
    assert res() == 'test'

# Generated at 2022-06-21 23:12:18.839753
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic('test')

    @app.middleware('request')
    async def process_request(request):
        pass

    assert app._future_middleware[0].middleware is process_request
    assert app._future_middleware[0].attach_to is 'request'

    @app.middleware('response')
    async def process_response(request, response):
        pass

    assert app._future_middleware[1].middleware is process_response
    assert app._future_middleware[1].attach_to is 'response'



# Generated at 2022-06-21 23:12:38.584612
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Foo:
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            assert self._future_middleware == []
    class Bar(MiddlewareMixin, Foo):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            assert self._future_middleware == []
    class Baz(Foo, MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            assert self._future_middleware == []


# Generated at 2022-06-21 23:12:40.306166
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mix = MiddlewareMixin()
    assert mix._future_middleware == []


# Generated at 2022-06-21 23:12:44.924529
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import unittest
    import unittest.mock as mock
    from sanic.models.interface.bases import MiddlewareMixin as MiddlewareMixin_
    from sanic.models.futures import FutureMiddleware
    from typeguard import typechecked

    @typechecked
    def __init__(self, *args, **kwargs):
        return MiddlewareMixin_.__init__(self, *args, **kwargs)

    MiddlewareMixin.__init__ = __init__
    m_MiddlewareMixin = mock.Mock(spec=MiddlewareMixin)
    m_MiddlewareMixin._future_middleware = []


# Generated at 2022-06-21 23:12:50.536169
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic()

    @app.middleware
    async def test_func(request):
        return request

    middleware = app._future_middleware[0]

    a = middleware.middleware == test_func
    b = middleware.attach_to == 'request'

    assert a and b


# Generated at 2022-06-21 23:13:02.463396
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MyMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            self.middleware_stack = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware_stack.append(middleware)

    mm = MyMiddlewareMixin()

    def mw(request):
        pass

    mm.on_request(mw)

    assert len(mm._future_middleware) == 1
    assert mm._future_middleware[0].handler is mw
    assert mm._future_middleware[0].attach_to == "request"

    mm.on_request()(mw)

    assert len(mm._future_middleware) == 2
    assert mm._future_middleware[1].handler is mw

# Generated at 2022-06-21 23:13:04.973183
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            MiddlewareMixin.__init__(self, *args, **kwargs)

        def _apply_middleware(self, middleware):
            return

    test_middleware_mixin = TestMiddlewareMixin()
    assert test_middleware_mixin._future_middleware == []


# Generated at 2022-06-21 23:13:13.593112
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class M(MiddlewareMixin):
        def __init__(self):
            self.request_funcs = []
            self.response_funcs = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            if middleware.attach_to == 'request':
                self.request_funcs.append(middleware.middleware)
            elif middleware.attach_to == 'response':
                self.response_funcs.append(middleware.middleware)

    def request_middleware(request):
        return request
        
    def response_middleware(request, response):
        return response

    m = M()
    m.middleware(request_middleware)
    m.middleware('response')(response_middleware)
    assert m.request_funcs[0] == request_middleware

# Generated at 2022-06-21 23:13:21.061844
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic(__name__)

    @app.middleware
    def request_middleware(request):
        pass

    @app.middleware('response')
    def response_middleware(request, response):
        pass

    @app.on_request
    def on_request(request):
        pass

    @app.on_response
    def on_response(request, response):
        pass

    fm: FutureMiddleware
    for fm in app._future_middleware[1:]:
        assert fm.attach_to == 'request'
    for fm in app._future_middleware[1:]:
        assert fm.attach_to == 'response'

# Generated at 2022-06-21 23:13:24.798624
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    obj = MiddlewareMixin()
    #...
    #TODO: write unit test code
    #...



# Generated at 2022-06-21 23:13:28.895574
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class EmptyClass:
        pass

    instance = EmptyClass()
    instance.middleware = MiddlewareMixin._middleware
    result = instance.on_request(lambda x: x)
    assert result is not None
