

# Generated at 2022-06-21 23:09:22.026567
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

# Generated at 2022-06-21 23:09:31.245555
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # create a class MyMiddleware
    class MyMiddleware:
        def __init__(self):
            pass
        def method_on_request(self):
            pass
    # create an instance of class MiddlewareMixin
    obj = MiddlewareMixin()
    # register a request middleware
    assert obj.on_request(middleware = MyMiddleware.method_on_request)() == MyMiddleware.method_on_request()
    # register a response middleware
    assert obj.on_response(middleware = MyMiddleware.method_on_request)() == MyMiddleware.method_on_request()
    # register a generic middleware
    assert obj.middleware(middleware = MyMiddleware.method_on_request)() == MyMiddleware.method_on_request()
    
    
# Test for the method middleware

# Generated at 2022-06-21 23:09:33.531502
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    app = MiddlewareMixin()
    def middleware(request):
        print('This is my first test middleware!')
        return request
    app.on_request(middleware)

# Generated at 2022-06-21 23:09:37.787303
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddlewareClass(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError

    MiddlewareClass()

# Generated at 2022-06-21 23:09:50.133029
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import inspect
    from unittest.mock import patch

    with patch.object(
        MiddlewareMixin, "middleware", return_value="middleware"
    ) as mock_middleware:
        # without params
        result = MiddlewareMixin().on_response()
        assert result is None
        assert mock_middleware.call_count == 1
        args, kwargs = mock_middleware.call_args
        assert args == ()
        assert kwargs == {}

        # with params
        result = MiddlewareMixin().on_response("middleware")
        assert result == "middleware"
        assert mock_middleware.call_count == 2
        args, kwargs = mock_middleware.call_args
        assert args == ("middleware",)
        assert kwargs == {"attach_to": "response"}

# Generated at 2022-06-21 23:10:01.250324
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response.__name__ == "on_response"
    assert MiddlewareMixin.on_response.__doc__ == "Register middleware to run after the response is created, but before it is returned to the client. For decorating a function that handles the request, use a regular function decorator instead of this method.\n\n    Usage::\n\n        @app.on_response\n        async def halt_request(request, response):\n            halt_request_if_needed(request, response)\n    "
    assert MiddlewareMixin.on_response.__annotations__ == {}
    assert MiddlewareMixin.on_response.__dict__ == {}
    assert MiddlewareMixin.on_response.__kwdefaults__ == None


# Generated at 2022-06-21 23:10:01.698972
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert True

# Generated at 2022-06-21 23:10:02.581506
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert True

# Generated at 2022-06-21 23:10:12.549806
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MockMiddlewareMixin():
        @staticmethod
        def middleware(middleware, attach_to):
            print(middleware)
            print(attach_to)
            return middleware

    mw_mixin_obj = MockMiddlewareMixin()

    @mw_mixin_obj.on_request
    def mw_func():
        pass

    mw_mixin_obj.middleware = MockMiddlewareMixin.middleware

    mw_mixin_obj.middleware = Mock(return_value = 42)
    out = mw_func()
    assert mw_mixin_obj.middleware.call_count == 1
    assert mw_mixin_obj.middleware.call_args[0][0] is mw_func
    assert mw_mixin_obj.middleware.call

# Generated at 2022-06-21 23:10:17.842602
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Test(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            nonlocal applymiddlewarecalled
            nonlocal middlewarecalled
            applymiddlewarecalled = True
            middlewarecalled = middleware

    def test_middleware():
        nonlocal middlewarecalled
        nonlocal applymiddlewarecalled
        assert applymiddlewarecalled
        assert middlewarecalled

    test = Test()
    applymiddlewarecalled = False
    middlewarecalled = None
    test.on_request(test_middleware)()


# Generated at 2022-06-21 23:10:30.923081
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic

    app = Sanic("test_MiddlewareMixin_on_response")

    @app.middleware
    async def print_on_request(request):
        print("I am a request middleware")

    @app.middleware("response")
    async def print_on_response(request, response):
        print("I am a response middleware")

    @app.route("/")
    async def handler(request):
        return response.text("I am a handler")

    request, response = app.test_client.get("/")
    assert response.text == "I am a handler"

    request, response = app.test_client.get("/")
    assert response.text == "I am a handler"

    request, response = app.test_client.get("/")
    assert response.text

# Generated at 2022-06-21 23:10:31.632110
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass


# Generated at 2022-06-21 23:10:38.469721
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class MiddlewareMixinTest(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            return middleware
    obj = MiddlewareMixinTest()
    # Test case1
    def fun1():
        return True
    obj.on_response(fun1)
    assert hasattr(fun1,'sanic_middleware') == True
    assert fun1.sanic_middleware == 'response'
    assert obj._future_middleware[0].middleware == fun1
    assert obj._future_middleware[0].attach_to == 'response'
    # Test case2
    def fun2():
        return False
    test_fun2 = obj.on_response(fun2)
    assert hasattr(fun2,'sanic_middleware') == False
    assert obj._future_middleware

# Generated at 2022-06-21 23:10:43.475972
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic

    app = Sanic('test_MiddlewareMixin_on_response')

    @app.on_response
    def handler1(request, response):
        print('Finish a request, after it is handled by the server.')

    @app.on_response
    def handler2(request, response):
        print('Finish a request, after it is handled by the server.')


# Generated at 2022-06-21 23:10:51.242124
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    m = MiddlewareMixin()
    assert isinstance(m, MiddlewareMixin)

    @m.on_response
    async def print_response(request, response):
        print(request.url)

    assert isinstance(m, MiddlewareMixin)
    assert m._future_middleware[0].middleware == print_response
    assert m._future_middleware[0].attach_to == "response"


# Generated at 2022-06-21 23:10:57.707399
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.server import HttpProtocol
    class MyMiddlewareMixin(MiddlewareMixin):
        self._app = MyMiddlewareMixin()
        self.foo = self.bar = ""
        self.testreq = 1
        def _apply_middleware(self, middleware):
            assert middleware, "middleware is empty"
    # initialize middleware
    s = HttpProtocol(MyMiddlewareMixin())
    assert s.middleware_stack, "middleware_stack is empty"
    assert s.middleware_stack.__name__ == "middleware_stack", "name is wrong"


# Generated at 2022-06-21 23:11:06.340703
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    '''
    If call as @middleware and attach_to is 'request' or 'response'.
    '''
    @app.middleware
    def middleware_fun():
        pass
    assert middleware_fun in app._future_middleware
    assert app._future_middleware[-1].attach_to == 'request'
    @app.middleware('response')
    def middleware_fun_response():
        pass
    assert middleware_fun_response in app._future_middleware
    assert app._future_middleware[-1].attach_to == 'response'


# Generated at 2022-06-21 23:11:11.922646
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    with pytest.raises(NotImplementedError):
        TestMiddlewareMixin().middleware(FutureMiddleware(callable, "request"))


# Generated at 2022-06-21 23:11:16.979462
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class FakeApp(MiddlewareMixin):
        def __init__(self):
            super().__init__()

    app = FakeApp()
    assert(callable(app.on_request()))



# Generated at 2022-06-21 23:11:20.688667
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_on_request")

    @app.on_request
    def test(request):
        pass
    assert app._future_middleware[0].middleware == test

# Generated at 2022-06-21 23:11:27.056289
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    assert app._future_middleware == []
    app.on_request(middleware=lambda x: x)
    assert len(app._future_middleware) == 1


# Generated at 2022-06-21 23:11:35.262655
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    app = MiddlewareMixin
    try:
        logger.info('Step 1: Create an instance of class MiddlewareMixin')
        app = MiddlewareMixin()
        logger.info('Step 1: Create an instance of class MiddlewareMixin successfully')
    except Exception as e:
        logger.error('Step 1: Create an instance of class MiddlewareMixin failed')
        logger.error(str(e))
        assert 0, 'Step 1: Create an instance of class MiddlewareMixin failed'

# Generated at 2022-06-21 23:11:39.954791
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.blueprints import Blueprint
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import NotFound

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    def request_middleware1(request):
        pass

    @app.middleware
    def request_middleware2(request):
        pass

    @app.middleware('request')
    async def request_middleware3(request):
        pass

    @app.middleware
    async def request_middleware4(request):
        pass


# Generated at 2022-06-21 23:11:50.051070
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    # Unit tests for method on_response of class MiddlewareMixin
    def test_MiddlewareMixin_on_response_is_function():
        assert callable(TestMiddlewareMixin.on_response)

    def test_MiddlewareMixin_on_response_call():
        assert isinstance(
            TestMiddlewareMixin.on_response(lambda: None), partial
        )

    test_MiddlewareMixin_on_response_is_function()
    test_MiddlewareMixin_on_response_call()



# Generated at 2022-06-21 23:11:59.138451
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test_MiddlewareMixin_on_request')
    mock_future_middleware = FutureMiddleware(None, "request")
    app._future_middleware = [mock_future_middleware]
    app.on_request()

    # Assert the last item in _future_middleware is the middleware that we
    # wanted to register
    assert mock_future_middleware == app._future_middleware[-1]

# Generated at 2022-06-21 23:12:10.204505
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    _pass = True
    test_params = [
        (None, "request", True),
        (None, "response", True)
    ]
    test_results = [
        ("partial", "partial"),
        ("partial", "partial")
    ]
    test_ids = [
        ("With_params_and_attach_to", "Without_params_and_attach_to"),
        ("With_params_and_attach_to", "Without_params_and_attach_to")
    ]
    ut = MiddlewareMixin()
    for i, param in enumerate(test_params):
        res = ut.middleware(*param)
        if not isinstance(res, type(test_results[i])):
            _pass = False
            print(f"Test {test_ids[i]} failed")

# Generated at 2022-06-21 23:12:11.827609
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mix = MiddlewareMixin()
    assert isinstance(mix._future_middleware, list)

# Generated at 2022-06-21 23:12:13.058460
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    print('In test_MiddlewareMixin()')

# Generated at 2022-06-21 23:12:14.113653
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewareMixin = MiddlewareMixin()

    assert middlewareMixin._future_middleware == []



# Generated at 2022-06-21 23:12:20.285738
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.exceptions import NotFound
    import unittest

    class RequestMock:

        def __init__(self):
            self.args = dict()
            self.headers = dict()
            self.json = dict()

    @Sanic.middleware
    async def request_log(request):
        print('Request Log: {}'.format(request))

    @Sanic.middleware('request')
    async def request_log_2(request):
        pri

# Generated at 2022-06-21 23:12:30.539151
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    @MiddlewareMixin.on_response()
    def send_response(request, response):
        pass

# Generated at 2022-06-21 23:12:42.589116
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.views import HTTPMethodView
    from sanic.response import text

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def process_request(request):
        return text('OK')

    @app.route('/test1')
    async def handler1(request):
        return text('OK')

    @app.route('/test2')
    class Handler2(HTTPMethodView):
        async def get(self, request):
            return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

    request, response = app.test_client.get('/test1')
    assert response.text == 'OK'


# Generated at 2022-06-21 23:12:47.397321
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class App(MiddlewareMixin):
        pass
    @App.on_request()
    def handler(request):
        pass
    assert App._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-21 23:12:49.144971
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    instance = MiddlewareMixin()
    assert type(instance._future_middleware) == List


# Generated at 2022-06-21 23:12:50.536018
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class App(MiddlewareMixin):
        pass
    
    App()

# Generated at 2022-06-21 23:13:01.260862
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestClass:
        def __init__(self, *args, **kwargs):
            self._future_middleware: List[FutureMiddleware] = []

    # test raise not implemented error
    obj = TestClass()
    try:
        obj._apply_middleware(None)
    except NotImplementedError:
        assert True
    else:
        assert False

    # test if callable
    obj = MiddlewareMixin()
    f = obj.on_request(lambda: 1)
    assert isfunction(f)

    # test else
    obj = MiddlewareMixin()
    f = obj.on_request()
    assert isfunction(f)

# Generated at 2022-06-21 23:13:07.762063
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddleware:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    testMiddleware = TestMiddleware()
    assert(testMiddleware._future_middleware == [])

# Generated at 2022-06-21 23:13:16.275108
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin = MiddlewareMixin()
    response_middleware = middleware_mixin.on_response(middleware=None)
    assert callable(response_middleware)
    assert response_middleware.keywords == {'attach_to': 'response'}
    assert response_middleware.args == ()
    assert response_middleware.func == middleware_mixin.middleware

# Generated at 2022-06-21 23:13:21.474716
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import SanicException
    app = Sanic('test_MiddlewareMixin')
    app.error_handler.add(SanicException, lambda request, exception: text(exception.status_code))
    app.middleware('request')(lambda request: 'response')

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'response'



# Generated at 2022-06-21 23:13:31.748477
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    from sanic.exceptions import InvalidUsage

    app = Sanic()
    assert isinstance(app, MiddlewareMixin), "Fail unite test for class Sanic."
    assert isinstance(app, MiddlewareMixin), "Fail unite test for class Sanic."

# Generated at 2022-06-21 23:13:42.661934
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def process_request(request):
        return text('request processed')

    @app.route('/')
    async def handler(request):
        return text('request handled')

    request, response = app.test_client.get('/')
    assert response.text == "request processed"

# Generated at 2022-06-21 23:13:46.520652
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    try:
        class TestMiddlewareMixin(MiddlewareMixin):
            def __init__(self):
                super().__init__()
        assert True
    except:
        assert True

# Generated at 2022-06-21 23:13:50.997701
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware_mixin = MiddlewareMixin()

    @middleware_mixin.on_request()
    def msg_print():
        print("on_request method")
    
    assert str(msg_print) == '<bound method msg_print of <__main__.MiddlewareMixin object at 0x7f2d4a039090>>'


# Generated at 2022-06-21 23:13:55.703276
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MockServer(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass
    app = MockServer()
    assert app._future_middleware == []


# Generated at 2022-06-21 23:13:59.781493
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    sanic = MiddlewareMixin()
    assert sanic._future_middleware == []
    # _apply_middleware
    with pytest.raises(NotImplementedError):
        sanic._apply_middleware(FutureMiddleware(None, None))

# Generated at 2022-06-21 23:14:01.206993
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()

# Generated at 2022-06-21 23:14:02.981140
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    obj = MiddlewareMixin()
    with pytest.raises(NotImplementedError):
        obj.on_response(middleware=None)

# Generated at 2022-06-21 23:14:06.860943
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin')

    assert isinstance(app, MiddlewareMixin)
    assert app.__class__.__name__ == 'Sanic'
    assert app._future_middleware == []
    assert app._middleware is not None
    assert app.config == {'REQUEST_MAX_SIZE': 100000000, 'REQUEST_TIMEOUT': 60, 'RESPONSE_TIMEOUT': 60, 'KEEP_ALIVE': True, 'KEEP_ALIVE_TIMEOUT': 5, 'REQUEST_MAX_MEMORY_SIZE': 0}

# Generated at 2022-06-21 23:14:08.268355
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # No errors
    MiddlewareMixin()

# Generated at 2022-06-21 23:14:12.172433
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    def test_middleware(request):
        return

    app = Sanic("sanic-opentelemetry_tests")
    app.on_response(test_middleware)

    middleware_chain = [(test_middleware, "response")]
    assert app._request_middleware == []
    assert app._response_middleware == middleware_chain



# Generated at 2022-06-21 23:14:22.921826
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.models import MiddlewareMixin
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin._future_middleware == []



# Generated at 2022-06-21 23:14:23.776742
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    objects = MiddlewareMixin()
    assert objects is not None

# Generated at 2022-06-21 23:14:32.413614
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic()
    app.__class__ = type(
        app.__class__.__name__, (app.__class__, MiddlewareMixin), {}
    )

    def middleware_request1(request):
        pass

    def middleware_request2(request):
        pass

    def middleware_response1(request, response):
        pass

    app.middleware(middleware_request1)
    app.middleware(middleware_request2)
    app.middleware(middleware_response1)

    assert middleware_request1 in app._future_middleware
    assert middleware_request2 in app._future_middleware
    assert middleware_response1 in app._future_middleware


# Generated at 2022-06-21 23:14:37.315575
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.futures import FutureMiddleware
    from sanic.models.context import RequestContext
    from sanic.models.request import Request
    from sanic.models.response import HTTPResponse
    class MockMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super(MockMiddlewareMixin, self).__init__()
            self._future_middleware = []
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    mock = MockMiddlewareMixin()
    # test 1
    request_handler_1 = mock.middleware
    assert isinstance(request_handler_1, partial)
    # test 2
    response_handler_1 = mock.on_response
    assert isinstance(response_handler_1, partial)
    #

# Generated at 2022-06-21 23:14:40.032179
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    middleware = MiddlewareMixin()
    assert middleware
    @middleware.on_request()
    def on_request(request):
        return request
    assert on_request


# Generated at 2022-06-21 23:14:48.700354
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text

    def middleware(request):
        request["retest"] = "I am on response"

    app = Sanic("test_MiddlewareMixin_on_response")

    @app.route("/")
    async def handler(request):
        return text("OK")

    app.middleware(middleware)

    _, response = app.test_client.get("/")
    assert response.text == 'OK'



# Generated at 2022-06-21 23:15:00.466284
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic  # noqa
    from sanic.models import FutureMiddleware
    from sanic.models import MiddlewareMixin

    class MiddlewareMixinTest(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(MiddlewareMixinTest, self).__init__(*args, **kwargs)
            self._future_middleware = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError

    @MiddlewareMixinTest.on_request
    async def request_middleware(request):
        request["result"] = "OK"

    middleware_test = MiddlewareMixinTest()
    assert len(middleware_test._future_middleware) == 0


# Generated at 2022-06-21 23:15:08.961572
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')

    @app.get('/test_MiddlewareMixin_on_response')
    async def test_on_response(request):
        return response.text('OK')

    @app.middleware('response')
    def process_response(request, response):
        response.headers['name'] = 'value'

    request, response = app.test_client.get('/test_MiddlewareMixin_on_response')
    assert response.status == 200
    assert response.headers['name'] == 'value'

# Generated at 2022-06-21 23:15:09.736548
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert True

# Generated at 2022-06-21 23:15:15.152532
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class A(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(A, self).__init__(*args, **kwargs)

    a = A("a", "bc")
    assert a._future_middleware == []



# Generated at 2022-06-21 23:15:35.434675
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    app = MiddlewareMixin()

    assert 1 == len(app._future_middleware)

# Generated at 2022-06-21 23:15:42.295595
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class ModelClass:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
            pass
    
    dataInfo = MiddlewareMixin()
    assert type(dataInfo) == MiddlewareMixin


# Generated at 2022-06-21 23:15:46.674253
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.models.middlewares import MiddlewareMixin

    middleware_mixin = MiddlewareMixin()

    assert isinstance(middleware_mixin, MiddlewareMixin)
    assert isinstance(middleware_mixin, Sanic)
    assert issubclass(MiddlewareMixin, Sanic)

    assert isinstance(middleware_mixin._future_middleware, List)

    assert middleware_mixin._future_middleware == []

# Black box unit test for method MiddlewareMixin._apply_middleware()

# Generated at 2022-06-21 23:15:57.446150
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol

    app = Sanic(__name__)

    @app.middleware
    async def handler(request):
        request.parsed_json = {"foo": "bar"}

    raw_request, _ = make_raw_request(
        "GET", "/", headers={"host": "localhost:8000", "content-type": "application/json"}, body=b'{"foo": "bar"}'
    )

    assert raw_request

    handler = app.request_middleware[-1].handler
    assert handler
    request = Request(raw_request, SocketStream(raw_request._sock), WebSocketProtocol(None, None))
    response = await handler(request)

# Generated at 2022-06-21 23:16:07.496242
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class Registrable(MiddlewareMixin):
        def __init__(self) -> None:
            super().__init__()

        def _apply_middleware(self, middleware):
            pass

    registrable = Registrable()
    registrable.middleware(lambda r: r)
    registrable.middleware(lambda r: r, 'request')
    registrable.middleware(lambda r: r, 'response')
    registrable.middleware(lambda r: r, apply=False)

    registrable.on_request(lambda r: r)
    registrable.on_response(lambda r: r)

# Generated at 2022-06-21 23:16:08.138568
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert False

# Generated at 2022-06-21 23:16:16.533587
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m1 = MiddlewareMixin()
    m2 = MiddlewareMixin()
    #
    def on_request(request):
        print(request)
    #
    def on_request1(request):
        print('on_request1')
    #
    m1.on_request(on_request)
    m2.on_request()
    m1._future_middleware
    m2._future_middleware
    print(m1._future_middleware)
    print(m2._future_middleware)

if __name__ == "__main__":
    test_MiddlewareMixin_on_request()

# Generated at 2022-06-21 23:16:19.008666
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()


if __name__ == '__main__':
    test_MiddlewareMixin()

# Generated at 2022-06-21 23:16:20.974860
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewareMixin = MiddlewareMixin()
    assert middlewareMixin._future_middleware == []
    
test_MiddlewareMixin()

# Generated at 2022-06-21 23:16:24.189890
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    MiddlewareMixin.__new__ = object.__new__
    MiddlewareMixin.__init__ = object.__init__
    a = MiddlewareMixin()
    b = a.on_response()
    result = b
    assert result == partial(a.middleware, attach_to="response")

# Generated at 2022-06-21 23:17:11.615077
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Student:
        def __init__(self, *args, **kwargs):
            self._future_middleware: List[FutureMiddleware] = []
    s = Student()


# Generated at 2022-06-21 23:17:17.793398
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic()

    @app.middleware
    async def print_on_request(request):
        print('in request middleware')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('in response middleware')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    request, response = app.test_client.get('/')
    assert response.status == 200

# Generated at 2022-06-21 23:17:23.591460
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # given
    def _middleware1(): pass
    def _middleware2(): pass
    _mixin = MiddlewareMixin()
    # when
    _cr1 = _mixin.on_response(_middleware1)
    _cr2 = _mixin.on_response(_middleware2)
    # then
    assert _cr1
    assert _cr2


# Generated at 2022-06-21 23:17:30.059088
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Arrange
    @MiddlewareMixin.on_request
    def test_middleware(request):
        return request

    # Act
    @MiddlewareMixin.on_request
    def test_middleware(request):
        return request

    # Assert



# Generated at 2022-06-21 23:17:38.951887
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from unittest.mock import Mock
    s = Sanic(name="test_server")

    @s.middleware
    def test_mw_mid(request, response):
        pass

    @s.on_request
    def test_mw(request):
        pass

    assert len(s._future_middleware) == 2

    s.blueprint(Mock())
    assert len(s._future_middleware) == 2

    s._apply_middleware(Mock())
    assert len(s._future_middleware) == 2

    # MiddlewareMixin.on_request
    assert test_mw in s._future_middleware[-1]
    assert test_mw_mid in s._future_middleware[-2]
    
    
# Unit test

# Generated at 2022-06-21 23:17:46.319168
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic(__name__)

    @app.middleware
    async def before_request(request):
        pass

    @app.on_response
    async def before_request(request, response):
        pass

    assert len(app._middleware) == 2
    assert len(app._future_middleware) == 2

    @app.middleware('request')
    async def before_request(request):
        pass

    @app.on_response('response')
    async def before_request(request, response):
        pass

    assert len(app._middleware) == 4
    assert len(app._future_middleware) == 4



# Generated at 2022-06-21 23:17:55.455581
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('sanic')
    class Test_MiddlewareMixin_on_response(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    app.__class__ = Test_MiddlewareMixin_on_response
    def mock_middleware(request):
        return None
    app.on_response(mock_middleware)
    assert len(app._future_middleware) == 1
    assert isinstance(app._future_middleware[0], FutureMiddleware)

# Generated at 2022-06-21 23:18:02.398240
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic()
    result = app.on_response()
    assert not callable(result)
    result = app.on_response(middleware=lambda : logging.info())
    assert callable(result)
    result = app.on_response('request')
    assert callable(result)



# Generated at 2022-06-21 23:18:07.402960
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A(MiddlewareMixin):
        pass
    class B(A):
        pass

    middleware = lambda request, response: print('hello')

    b = B()
    assert len(b._future_middleware) == 0

    b.middleware(middleware)
    assert len(b._future_middleware) == 1

    b.middleware(middleware, 'response')
    assert len(b._future_middleware) == 2

    b.middleware(middleware, 'request')
    assert len(b._future_middleware) == 3

    a = A()
    assert len(a._future_middleware) == 0
    a.middleware(middleware)
    assert len(a._future_middleware) == 1



# Generated at 2022-06-21 23:18:09.790861
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    MiddlewareMixin.middleware("MiddlewareMixin", attach_to="MiddlewareMixin", apply=False)