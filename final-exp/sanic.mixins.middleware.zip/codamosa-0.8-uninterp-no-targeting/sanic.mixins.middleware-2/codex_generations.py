

# Generated at 2022-06-21 23:09:19.181417
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic, response

    app = Sanic('test_MiddlewareMixin_on_request')

    @app.middleware('request')
    async def test_on_request(request):
        return response.text('request!')

    request, response = app.test_client.get('/')
    assert response.status == 201
    assert response.text == 'request!'


# Generated at 2022-06-21 23:09:22.951807
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    t = TestMiddlewareMixin()
    assert t._future_middleware == []

# Generated at 2022-06-21 23:09:27.823438
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
    
    @App.middleware
    def middleware(request):
        pass
    assert len(App._future_middleware) == 1

# Generated at 2022-06-21 23:09:37.827702
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    def g(*args, **kwargs):
        pass
    m = MiddlewareMixin()
    m.on_response()
    m.on_response(g)
    try:
        m.on_response(10)
        assert False
    except Exception:
        pass
    q = MiddlewareMixin()
    q.middleware(g)
    q.on_response(g)


# Generated at 2022-06-21 23:09:48.980810
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.bool = False

        def _apply_middleware(self, _):
            self.bool = True

    test = TestMiddlewareMixin()
    @test.on_request()
    def f():
        pass
    assert test.bool
    assert len(test._future_middleware) == 1
    assert test._future_middleware[0].middleware == f
    assert test._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-21 23:10:00.251440
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    app = Sanic("on_response")
    testvar = 0
    @app.on_response
    def increment(request, response):  # type: ignore
        global testvar
        testvar += 1

    testvar2 = 0
    @app.on_response("response")
    def increment2(request, response):  # type: ignore
        global testvar2
        testvar2 += 1

    @app.route("/")
    async def handler(request):
        return text("success")

    request, response = app.test_client.get("/")

    assert response.text == "success"
    assert testvar == 1
    assert testvar2 == 1

# Generated at 2022-06-21 23:10:11.700855
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.models import MiddlewareMixin

    class O:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa


# Generated at 2022-06-21 23:10:15.632824
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    app = MiddlewareMixin()
    result = app.on_response(middleware='middleware')
    assert result == partial(app.middleware, attach_to='response')


# Generated at 2022-06-21 23:10:21.733491
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic import response
    from unittest.mock import Mock
    # Mock a class of Sanic
    app = Sanic(__name__)
    # Create a decorator for request which is in this case a function.
    def on_request_function(request):
        return request
    
    # Check if it returns a function
    assert app.on_request() == app.on_request
    # Call the method on_request
    app.on_request(on_request_function)
    # Check if the method on_request is called on the returned function.
    assert app.on_request(on_request_function)==on_request_function
    # Set a request handler
    @app.route("/")
    def handler(request):
        return response.text("OK")


# Generated at 2022-06-21 23:10:31.443128
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.router import RouteExists

    app = Sanic('test_sanic_MiddlewareMixin_middleware')
    bp = Blueprint('test_sanic_MiddlewareMixin_middleware_blueprint')


# Generated at 2022-06-21 23:10:38.971250
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.response import json

    @MiddlewareMixin.on_request
    def request_middleware(request):
        return True

    @MiddlewareMixin.on_response
    def response_middleware(request, response):
        return True

    app = Sanic()

    @app.route("/")
    async def test(request):
        return json(request.__dict__)

    test_client = app.test_client
    request, response = test_client.get("/")
    assert response.json.get("middleware") is None

    app.middleware(None)

    request, response = test_client.get("/")
    assert response.json.get("middleware") is True

    app.middleware(None)

    request, response = test_client.get

# Generated at 2022-06-21 23:10:47.548597
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Test(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    @Test().on_response()
    async def update_attribute(request, response):
        # type: (Request, Response) -> None
        response.foo = "bar"

    assert update_attribute.__name__ == "update_attribute"

# Generated at 2022-06-21 23:10:51.764415
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    app = Sanic()

    def on_request(request):
        pass

    request = app.on_request(on_request)
    assert request.__name__ == 'on_request'



# Generated at 2022-06-21 23:10:59.513616
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():

    from sanic.app import Sanic
    from sanic.testing import SanicTestClient

    class TestMiddleware(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        async def _apply_middleware(self, middleware: FutureMiddleware):
            pass

        def middleware(
                self, middleware_or_request, attach_to="request", apply=True):
            pass

    app = Sanic('test_MiddlewareMixin_on_response')
    test_client = SanicTestClient(app, raise_sanic_exceptions=True)

    @app.middleware
    async def middleware_request(request):
        pass

   

# Generated at 2022-06-21 23:11:09.764946
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic('test_on_request')

    async def first_request(request):
        return 'first'

    async def second_request(request):
        return 'second'

    @app.listener('before_server_start')
    async def save_request(app, loop):
        app.middleware_value = app.request('/')

    app.on_request(first_request)
    app.on_request(second_request)

    assert app.middleware_value == 'second'


# Generated at 2022-06-21 23:11:22.402941
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import HTTPResponse, text
    from sanic.response import json
    from unittest.mock import MagicMock
    @Sanic.middleware
    def log_milliseconds(request, response):
        return text('log_milliseconds')

    app = Sanic('test_on_response')

    @app.route('/')
    async def handler(request):
        return text('OK')

    @app.listener('before_server_start')
    async def before_server_start(app, loop):
        return text('before_server_start')

    @app.listener('after_server_start')
    async def after_server_start(app, loop):
        return text('after_server_start')


# Generated at 2022-06-21 23:11:23.177094
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # TODO: Add test
    assert True

# Generated at 2022-06-21 23:11:27.566581
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MyClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    myclass = MyClass()

    assert isinstance(myclass, MiddlewareMixin)


# Generated at 2022-06-21 23:11:35.892228
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic(__name__)

    @app.on_response
    def handler_response(request, response):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].attach_to == "response"
    assert app._future_middleware[0].middleware == handler_response



# Generated at 2022-06-21 23:11:38.219334
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    def middleware_test(middleware):
        return middleware

    assert MiddlewareMixin.on_request(middleware_test)



# Generated at 2022-06-21 23:11:44.111247
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin = MiddlewareMixin()
    assert mixin
    assert isinstance(mixin._future_middleware, list)

# Generated at 2022-06-21 23:11:46.715620
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin = MiddlewareMixin()
    assert isinstance(mixin, MiddlewareMixin)
    assert mixin._future_middleware == []


# Generated at 2022-06-21 23:11:54.972920
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import unittest
    from sanic import Sanic
    from sanic.response import json
    from unittest import mock

    import asynctest

    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = Sanic()
    middlewareMixin = TestMiddlewareMixin()

    @middlewareMixin.on_response()
    def test_response_middleware(request, response):
        return response

    @app.route("/")
    def test_endpoint(request):
        return json({"test": True})


# Generated at 2022-06-21 23:12:04.350063
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(App, self).__init__(*args, **kwargs)
            self.is_init = True

        def _apply_middleware(self, middleware: FutureMiddleware):
            nonlocal is_apply_middleware
            is_apply_middleware = True

    app = App()
    assert app.is_init
    assert app._future_middleware == []
    assert app.on_request(middleware_or_request=lambda: None) == app.on_request(lambda: None)
    assert app.on_response(middleware_or_request=lambda: None) == app.on_response(lambda: None)

# Generated at 2022-06-21 23:12:11.481313
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.request import Request

    class FakeMiddleware:
        called = False

        @staticmethod
        def preprocess_request(request):
            request.test = True
            FakeMiddleware.called = True

    app = Sanic(__name__)
    app.on_request(FakeMiddleware)

    @app.route("/")
    def handler(request: Request):
        assert request.test is True
        return request.args

    _, response = app.test_client.get("/?test=true")
    assert response.status == 200
    assert FakeMiddleware.called is True


# Generated at 2022-06-21 23:12:19.201222
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic(__name__)

    @app.middleware  # noqa
    async def test_middleware_one(request):
        request["user_agent"] = "sanic"

    @app.middleware('request')
    async def test_middleware_two(request):
        request["user_agent"] = "sanic"

    @app.middleware('response')
    async def test_middleware_three(request, response):
        request["user_agent"] = "sanic"

    @app.get("/")
    def handler(request):
        return text("OK")

    client = app.test_client
    request, response = client.get("/")
    assert response.status == 200

# Generated at 2022-06-21 23:12:28.713226
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    print('Test: test_MiddlewareMixin_on_request...\n')

    class MiddlewareMixin_on_request(MiddlewareMixin):
        def __init__(self):
            MiddlewareMixin.__init__(self)

    t = MiddlewareMixin_on_request()
    times = 0
    def test_MiddlewareMixin_on_request_middleware():
        nonlocal times
        times += 1

    t.on_request(test_MiddlewareMixin_on_request_middleware)
    t.on_request(test_MiddlewareMixin_on_request_middleware)
    t.on_request(test_MiddlewareMixin_on_request_middleware)
    t.on_request(test_MiddlewareMixin_on_request_middleware)

# Generated at 2022-06-21 23:12:36.408721
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.models.middleware import Middleware

    app_ = Sanic()
    assert isinstance(app_, MiddlewareMixin)

    @app_.middleware
    async def method_middleware(request):
        pass
    assert len(app_._future_middleware) == 1
    assert callable(app_._future_middleware[0].middleware)



# Generated at 2022-06-21 23:12:38.538513
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    #arrange
    test_obj = MiddlewareMixin()

    #act
    test_obj.on_request()

    #assert

# Generated at 2022-06-21 23:12:48.442166
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    def test_future_middleware():
        pass
    class MiddlewareMixinTest:
        pass
    MiddlewareMixinTest.middleware = MiddlewareMixin.middleware
    MiddlewareMixinTest._apply_middleware = MiddlewareMixin._apply_middleware
    MiddlewareMixinTest._future_middleware = []

    middleware_mixin_test = MiddlewareMixinTest()
    middleware_mixin_test.middleware(attach_to="request")
    middleware_mixin_test.middleware(attach_to="response")
    middleware_mixin_test.middleware(test_future_middleware)


# Generated at 2022-06-21 23:13:01.604074
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    app = Sanic("test_request")

    async def handler(request):
        return text("OK")

    async def request_middleware(request):
        assert request.path == "/"

    async def response_middleware(request, response):
        pass

    app.add_route(handler, "/")
    app.on_request(request_middleware)
    app.on_response(response_middleware)
    _, response = app.test_client.get("/")
    assert response.status == 200



# Generated at 2022-06-21 23:13:05.509117
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.server import Sanic
    app = Sanic()
    app.on_request(middleware)
    assert app._future_middleware[-1] == FutureMiddleware(middleware, 'request')

# Generated at 2022-06-21 23:13:08.544127
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware = MiddlewareMixin()
    assert middleware._future_middleware == []
    assert middleware == MiddlewareMixin


# Generated at 2022-06-21 23:13:19.148522
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class FakeMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    f = FakeMiddlewareMixin()

    @f.on_response
    async def test(request, response):
        pass

    assert f._future_middleware[0].middleware == test
    assert f._future_middleware[0].attach_to == 'response'

# Generated at 2022-06-21 23:13:26.367195
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class UniversalApp:
        pass
    UniversalApp.on_request = MiddlewareMixin.on_request
    app = UniversalApp()
    k=0
    @app.on_request()
    def request_handler():
        nonlocal k
        k = 1
    request_handler()
    assert k==1


# Generated at 2022-06-21 23:13:29.857943
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    def middleware():
        pass

    instance = MiddlewareMixin()

    assert(partial(instance.middleware, attach_to="response") == instance.on_response())

    assert(instance.middleware(middleware, "response") == instance.on_response(middleware))

# Generated at 2022-06-21 23:13:40.795958
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    app = Sanic()


    @app.on_request
    def custom_middleware(request, response):
        assert user_defined_variable == "I am a user defined variable"

    @app.middleware("response")
    def another_middleware(request, response):
        assert user_defined_variable == "I am a user defined variable"

    @app.middleware
    def middleware(request, response):
        assert user_defined_variable == "I am a user defined variable"

    user_defined_variable = "I am a user defined variable"



# Generated at 2022-06-21 23:13:43.222096
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Object of class MiddlewareMixin
    test_case = MiddlewareMixin()
    # Call the method on_request
    test_case.on_request()

# Generated at 2022-06-21 23:13:45.318902
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert callable(MiddlewareMixin.on_response)


# Generated at 2022-06-21 23:13:52.441677
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    class MyMiddleware:
        def __init__(self):
            pass
        async def setup(self, request):
            pass
        async def handle_request(self, request):
            pass
        async def handle_response(self, request, response):
            pass
    MyMiddleware = MyMiddleware()
    app = Sanic()
    app.on_request(MyMiddleware)
    assert(app._future_middleware[0].middleware_or_request == MyMiddleware)
    assert(app._future_middleware[0].attach_to == "request")
    assert(len(app._future_middleware) == 1)


# Generated at 2022-06-21 23:14:12.172239
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.testing import SanicTestClient

    app = Sanic("test_MiddlewareMixin_on_request")
    request_log = [0]

    @app.on_request
    def request_handler(request):
        request_log[0] += 1

    client = SanicTestClient(app)
    _, _ = client.get("/")
    assert request_log[0] == 1
    _, _ = client.get("/")
    assert request_log[0] == 2



# Generated at 2022-06-21 23:14:14.152769
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert callable(MiddlewareMixin.on_response)



# Generated at 2022-06-21 23:14:19.324110
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Test:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

    assert isinstance(Test(), MiddlewareMixin), 'Test class is not a subclass of MiddlewareMixin'

# Generated at 2022-06-21 23:14:22.684837
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    m = MiddlewareMixin()
    a = m.on_response()
    assert repr(a) == "<function MiddlewareMixin.middleware at 0x10d962d90>"

# Generated at 2022-06-21 23:14:28.359786
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddlewareMixinTest(MiddlewareMixin):
        def __init__(self):
            self._future_middleware = []

    with pytest.raises(NotImplementedError):
        mixer = MiddlewareMixinTest()
        mixer._apply_middleware(None)

# Generated at 2022-06-21 23:14:30.692320
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    mm = MiddlewareMixin()
    # TODO: Test the method


# Generated at 2022-06-21 23:14:39.763275
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic("test_MiddlewareMixin_on_response")

    flag = False
    @app.route("/")
    async def test(request):
        flag = True
        return response.text("")

    @app.on_response("response")
    def test_on_response(request, response):
        response.text("")

    request, response = app.test_client.get("/")
    assert response.text == ""
    assert flag == True


# Generated at 2022-06-21 23:14:43.528124
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()._future_middleware == []

if __name__ == '__main__':
    test_MiddlewareMixin()

# Generated at 2022-06-21 23:14:47.042042
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class dummy(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    @dummy.on_response()
    def func_middleware():
        pass

    assert isinstance(dummy._future_middleware[0], FutureMiddleware)
    assert dummy._future_middleware[0]._middleware == func_middleware
    assert dummy._future_middleware[0]._attach_to == "response"

# Generated at 2022-06-21 23:14:59.164247
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from . import Sanic
    from .response import HTTPResponse
    from .request import Request
    from .utils import STATUS_CODES
    from .constants import HTTP_METHODS
    from .router import Router, Rule
    import unittest
    import os
    import sys
    import json
    import logging
    import asyncio

    async def f(request, other, *args, **kwargs):
        return request.json["test"]

    class AServer(Sanic):
        def __init__(self, *args, **kwargs):
            self.middleware_test = []
            super().__init__(*args, **kwargs)


# Generated at 2022-06-21 23:15:30.032199
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    mixin = MiddlewareMixin()
    assert mixin.on_request() == partial(mixin.middleware, attach_to='request')


# Generated at 2022-06-21 23:15:36.932693
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(TestMiddlewareMixin, self).__init__(*args, **kwargs)
            self._future_middleware = None

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    test_middleware_mixin = TestMiddlewareMixin()
    assert test_middleware_mixin._future_middleware == []


# Generated at 2022-06-21 23:15:39.354705
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin.on_request == MiddlewareMixin.middleware

# Generated at 2022-06-21 23:15:45.195330
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Simple test for function middleware
    MM = MiddlewareMixin()
    MM.middleware(middleware_or_request=None, attach_to=None, apply=None)
    # Simple test for function on_request
    MM.on_request(middleware=None)
    # Simple test for function on_response
    MM.on_response(middleware=None)

# Generated at 2022-06-21 23:15:53.407403
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.models.futures import FutureMiddleware
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            pass
    test_middlewaremixin = TestMiddlewareMixin()
    assert test_middlewaremixin._future_middleware == []
    assert test_middlewaremixin._future_middleware == []



# Generated at 2022-06-21 23:15:58.442946
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic import response
    from sanic.models.futures import FutureMiddleware
    from functools import partial

    app = Sanic()
    async def handler(request):
        return response.text('OK')

    @app.on_response
    def on_response(request, response):
        response.text = 'OK'

    async def test_MiddlewareMixin_on_response():
        request, response = app.test_client.get('/')
        exp_response = 'OK'
        assert response.text == exp_response
        assert request.app == app

# Generated at 2022-06-21 23:16:01.754265
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():

    from sanic.models.middleware import MiddlewareMixin

    class test_class(MiddlewareMixin):
        pass
        
    test_class_obj = test_class()

    assert test_class_obj.on_response() == test_class.on_response(test_class_obj)


# Generated at 2022-06-21 23:16:07.311745
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class _Application:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware = []

            self._apply_middleware = lambda middleware: None

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa
    application = _Application()
    application.on_request('request')


# Generated at 2022-06-21 23:16:18.099851
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():

    # Create a class for testing
    class MiddlewareMixinTestClass(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            return middleware

    # Create a test instance
    mw = MiddlewareMixinTestClass()

    # Check that the function returns a function
    assert callable(mw.on_request())

    # Create a test function and register it
    def test_function():
        pass
    mw.on_request(test_function)

    # Check that a FutureMiddleware instance has been added to the property _future_middleware
    assert len(mw._future_middleware) == 1
    assert isinstance(mw._future_middleware[0], FutureMiddleware)
    assert mw._future_middleware[0].attach_to == 'request'

# Generated at 2022-06-21 23:16:19.985854
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from project.middlewares.middlewares import MiddlewareMixin
    mix = MiddlewareMixin()
    assert mix._future_middleware == []

# Generated at 2022-06-21 23:17:29.459432
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddlewareMixin_Test(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(MiddlewareMixin_Test, self).__init__(*args, **kwargs)
    
    MiddlewareMixin_Test()

# Generated at 2022-06-21 23:17:31.299179
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass


# Generated at 2022-06-21 23:17:35.689414
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    m = MiddlewareMixin()
    assert m._future_middleware == []
    m.middleware('response')(lambda a, b, c=None: a)
    assert m._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-21 23:17:40.241319
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    app = MiddlewareMixin()
    an_app = app.on_response()

    app.middleware(an_app, "response")


# Generated at 2022-06-21 23:17:44.696110
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic("test_middleware")
    @app.middleware("request")
    async def work(request):
        return request
    assert app.middleware._future_middleware[-1]._middleware == work
    assert app.middleware._future_middleware[-1]._attach_to == "request"

# Generated at 2022-06-21 23:17:46.689291
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()._future_middleware == []

# Generated at 2022-06-21 23:17:47.513071
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
  assert True

# Generated at 2022-06-21 23:17:51.203698
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    # should return no error
    app = Sanic()
    app.on_request(lambda x: x)


# Generated at 2022-06-21 23:17:58.873508
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from unittest import TestCase, mock
    from sanic.sanic import Sanic

    class TestMiddlewareMixin(MiddlewareMixin, Sanic):
        def __init__(self, *args, **kwargs):
            MiddlewareMixin.__init__(self, *args, **kwargs)
            Sanic.__init__(self, *args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    # test if the default parameter_value returns
    # the same as the parameter_value passed as argument
    app = TestMiddlewareMixin()
    assert app.on_request() == TestMiddlewareMixin.on_request
    assert app.on_request()(middleware=mock.MagicMock()) == mock.MagicMock()



# Generated at 2022-06-21 23:18:01.950346
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic('test')

    @app.route('/')
    async def handler(request):
        return json({'test': True})

    @app.on_response
    def on_response(request, response):
        return json({'test': True}, 200)

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': True}
