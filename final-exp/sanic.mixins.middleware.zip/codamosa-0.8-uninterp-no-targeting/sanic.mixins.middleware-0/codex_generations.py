

# Generated at 2022-06-21 23:09:24.160627
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, future_middleware):
            pass

    m = TestMiddlewareMixin()

    @m.on_response
    def a_middleware(request, response):
        return response

    from types import FunctionType

    assert type(m.middleware) == FunctionType
    assert type(m.on_request) == FunctionType
    assert type(m.on_response) == FunctionType

    assert len(m._future_middleware) == 1
    assert m._future_middleware[0].middleware == a_middleware

# Generated at 2022-06-21 23:09:33.656667
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    import unittest
    import sanic
    class test2(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    class test(sanic.Sanic):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    class UnitTest(unittest.TestCase):
        def test_method_on_response(self):
            app = test

# Generated at 2022-06-21 23:09:36.667675
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Arrange
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    # Act
    @app.middleware
    async def middleware_to_register(request):
        pass

    # Assert
    assert len(app._future_middleware) == 1

# Generated at 2022-06-21 23:09:41.034721
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    testMiddlewareMixin = TestMiddlewareMixin()

    @testMiddlewareMixin.middleware('response')
    async def middleware_function(request, response):
        return response

    assert middleware_function != None
    assert testMiddlewareMixin._future_middleware != None
    assert testMiddlewareMixin._future_middleware[0].middleware == middleware_function
    assert testMiddlewareMixin._future_middleware[0].attach_to == 'response'


# Generated at 2022-06-21 23:09:50.717992
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic;
    app = Sanic("test_MiddlewareMixin_on_response");
    @app.middleware
    async def test_middleware(request):
        return await test_on_request(request);

    def test_on_request(request):
    	return request;

    request = {
        "test" : "test_request"
    };
    result = app.on_request(test_on_request)(request);
    assert result == {
        "test" : "test_request"
    };

    result = app.on_response(test_middleware)(request);
    assert result == {
        "test" : "test_request"
    };


# Generated at 2022-06-21 23:09:58.210488
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic_opentracing import SanicTracing


    app = Sanic()
    tracing = SanicTracing(app)

    @tracing.on_request()
    def func(request):
        return json({'test': True})

    assert isinstance(func, partial)



# Generated at 2022-06-21 23:10:10.146623
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class MyMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    mm = MyMiddlewareMixin()

    @mm.on_response
    def foo(request):
        return request

    @mm.on_response
    def bar(request):
        return request

    assert len(mm._future_middleware) == 2



# Generated at 2022-06-21 23:10:10.992705
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert 1

# Generated at 2022-06-21 23:10:15.076091
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic('test')

# Generated at 2022-06-21 23:10:15.571423
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    MiddlewareMixin()

# Generated at 2022-06-21 23:10:30.883330
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MixinObject:
        def __init__(self):
            self._future_middleware = []
            self.__name__ = 'middleware'

    mixin = MiddlewareMixin()
    mixin_object = MixinObject()

    @mixin_object.__class__.middleware
    def first_middleware(request):
        pass

    assert len(mixin_object._future_middleware) == 1
    assert mixin_object._future_middleware[0].middleware_func == first_middleware
    assert mixin_object._future_middleware[0].attach_to == 'request'

    @mixin_object.__class__.middleware
    def second_middleware(request):
        pass

    assert len(mixin_object._future_middleware) == 2
    assert mixin_object

# Generated at 2022-06-21 23:10:34.519735
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from unittest.mock import Mock

    app = None
    assert app.on_response(mock_func) == mock_func
    assert app.on_response() == mock_func


# Generated at 2022-06-21 23:10:41.661739
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.request import Request

    app = Sanic('test_MiddlewareMixin_on_request')

    @app.middleware
    async def print_on_request(request):
        """ Print request uri """
        print(request.url)

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')



# Generated at 2022-06-21 23:10:44.280767
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    m = MiddlewareMixin()
    assert m.middleware == m.on_request


# Generated at 2022-06-21 23:10:53.993707
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestClass:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    # Add on_request method to TestClass
    MiddlewareMixin.__init__(TestClass, *args, **kwargs)
    MiddlewareMixin.on_request(TestClass, *args, **kwargs)
    MiddlewareMixin._apply_middleware(TestClass, *args, **kwargs)
    MiddlewareMixin._future_middleware(TestClass, *args, **kwargs)

    # Initialize TestClass
    test = TestClass()

    # Test on_request method
    assert test.on_request


# Generated at 2022-06-21 23:10:57.882251
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    with pytest.raises(NotImplementedError):
        m = MiddlewareMixin(1,2,3,4)
        assert m._future_middleware == []



# Generated at 2022-06-21 23:11:02.854886
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class M:
        def __init__(self, *args, **kwargs):
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

        def middleware(
            self, middleware_or_request, attach_to="request", apply=True
        ):
            def register_middleware(middleware, attach_to="request"):
                nonlocal apply

                future_middleware = FutureMiddleware(middleware, attach_to)
                self._future_middleware.append(future_middleware)
                if apply:
                    self._apply_middleware(future_middleware)
                return middleware


# Generated at 2022-06-21 23:11:10.036158
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic("test_MiddlewareMixin_on_request")

    @app.on_request
    def process_request(request):
        return None

    assert app._future_middleware != []
    assert app._future_middleware[0].attach_to == "request"
    assert app._future_middleware[0].middleware == process_request


# Generated at 2022-06-21 23:11:20.581554
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class ClassTest(MiddlewareMixin):
        def __init__(self):
            self._str = ""
        def first(request, response):
            self._str += "A"
        def second(request, response):
            self._str += "B"
    class_test = ClassTest()
    class_test._apply_middleware = lambda middleware: None
    class_test.on_request(class_test.first)
    class_test.on_request(class_test.second)
    assert class_test._str == "AB"


# Generated at 2022-06-21 23:11:23.619988
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_on_request')

    @app.on_request
    def request_handler(request):
        return request
    
    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'OK'


# Generated at 2022-06-21 23:11:40.860717
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.exceptions import InvalidUsage

    def middleware_before1(request: Request, handling=False):
        return request

    def middleware_before2(request: Request, handling=False):
        return request

    def middleware_after1(request: Request, response: HTTPResponse, handling=True):
        return response

    def middleware_after2(request: Request, response: HTTPResponse, handling=True):
        return response

    class MyView(HTTPMethodView):
        def get(self, request):
            return text("I am view")


# Generated at 2022-06-21 23:11:51.315180
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            self.list = []
            self.future_middleware = []
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.list.append(middleware)

    a = TestMiddlewareMixin()
    @a.middleware
    @a.middleware
    def f():
        print ('a')

    @a.middleware
    def g():
        print ('b')

    @a.middleware('response')
    def h():
        print ('c')

    assert len(a._future_middleware) == 3
    assert a._future_middleware[0]._attach_to == 'request'
   

# Generated at 2022-06-21 23:11:52.964270
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    obj = MiddlewareMixin()
    obj.on_response(middleware=None)

    pass

# Generated at 2022-06-21 23:11:56.211422
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin')
    assert hasattr(app, 'on_response')

# Generated at 2022-06-21 23:11:57.910879
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    with pytest.raises(NotImplementedError):
        MiddlewareMixin()._apply_middleware(None)



# Generated at 2022-06-21 23:12:00.596627
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mix = MiddlewareMixin(middleware)
    assert mix._future_middleware == []


# Generated at 2022-06-21 23:12:08.475427
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, middleware):
            pass

    inst = TestMiddlewareMixin()
    assert isinstance(inst, MiddlewareMixin)
    assert isinstance(inst, TestMiddlewareMixin)
    assert isinstance(inst._future_middleware, list)


# Generated at 2022-06-21 23:12:14.595505
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Set up
    class TestClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    def middleware_func(request):
        pass

    # Exercise
    middleware = TestClass().on_response(middleware_func)

    # Verify
    assert middleware == middleware_func

    # Clean up - none necessary


# Generated at 2022-06-21 23:12:16.297339
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    assert m.on_request == partial(m.middleware, attach_to="request")

# Generated at 2022-06-21 23:12:22.565678
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic()
    assert isinstance(app.on_request, partial)
    assert app.on_request.func is app.middleware
    assert app.on_request.keywords == {"attach_to": "request"}
    assert app.on_request.args == ()

    request_middleware = lambda x: x
    on_request = app.on_request(request_middleware)
    assert callable(on_request)
# END of Unit tests for MiddlwareMixin

# Generated at 2022-06-21 23:12:27.334956
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    a = MiddlewareMixin()
    a.on_response(lambda x: x)

# Generated at 2022-06-21 23:12:33.418463
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic(__name__)

    def mw():
        pass

    assert app.middleware == []
    assert app.on_request == app.middleware('request')
    assert app.on_response == app.middleware('response')

    # call @app.middleware
    app.middleware(mw)
    assert len(app.middleware) == 1 and isinstance(
        app.middleware[0].middleware, type(mw)
    )

    # call @app.middleware('request')
    app.middleware('request')(mw)
    assert len(app.middleware) == 2 and isinstance(
        app.middleware[1].middleware, type(mw)
    )

    # call @app.middleware('response')
    app

# Generated at 2022-06-21 23:12:34.416615
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin().on_response

# Generated at 2022-06-21 23:12:41.802468
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Test on_request
    a = MiddlewareMixin()
    b = a.on_request()
    assert callable(b)
    c = b("test")
    assert c == "test"
    assert a._future_middleware[0].middleware == "test"
    assert a._future_middleware[0].attach_to == "request"

    # Test on_response
    a.on_response("test")
    assert a._future_middleware[1].middleware == "test"
    assert a._future_middleware[1].attach_to == "response"

# Generated at 2022-06-21 23:12:45.185669
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.models.middlewares import Middleware
    
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)
        
    m = TestMiddlewareMixin()
    assert len(m._future_middleware) == 0
    m.middleware(Middleware, attach_to="request")
    assert len(m._future_middleware) == 1
    m.middleware(Middleware, attach_to="response")
    assert len(m._future_middleware) == 2


# Generated at 2022-06-21 23:12:55.313799
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_on_request')

    assert isinstance(app.on_response(), partial)

    @app.on_response
    def test_on_request(request, response):
        pass

    assert isinstance(app.on_response(), partial)

    assert not app._future_middleware

    app.go_fast(workers=1)

    @app.on_response
    def test_on_request2(request, response):
        pass

    assert isinstance(app.on_response(), partial)

    assert not app._future_middleware

    app.go_fast(workers=1)

    @app.on_response()
    def test_on_request3(request, response):
        pass

    assert isinstance(app.on_response(), partial)

   

# Generated at 2022-06-21 23:13:02.737686
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class App(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self.called_middleware = []
            self.called_request_middleware = []

        def _apply_middleware(self, middleware):
            self.called_middleware.append(middleware)

        def _apply_request_middleware(self, middleware):
            self.called_request_middleware.append(middleware)

    app = App()
    @app.on_request()
    def f(request):
        return request

    @app.on_response()
    def f(request, response):
        return response
    return app



# Generated at 2022-06-21 23:13:12.492896
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test = TestMiddlewareMixin()

    # test input type of middleware_or_request: middleware
    @test.middleware
    def a():
        pass

    assert test._future_middleware[0].middleware == a
    assert test._future_middleware[0].attach_to == "request"
    assert test._future_middleware[0].args == ()
    assert test._future_middleware[0].kwargs == {}

    # test input type of middleware_or_request: partial
    @test.middleware('response')
    def b():
        pass

    assert test._future_middleware[1].middleware == b
    assert test._future_middleware

# Generated at 2022-06-21 23:13:13.992189
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
  assert 1 == 2, "Not implemented"

# Generated at 2022-06-21 23:13:20.112921
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Test 1, the function middleware
    assert MiddlewareMixin(middleware = callable)
    # Test 2, the function middleware
    assert MiddlewareMixin(middleware = "request")
    # Test 3, the function middleware
    assert MiddlewareMixin(middleware = callable, attach_to = "request")
    # Test 4, the function middleware
    assert MiddlewareMixin(middleware = callable, attach_to = "response")

# Generated at 2022-06-21 23:13:26.441923
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    assert MiddlewareMixin.on_response() == partial(MiddlewareMixin.middleware, attach_to="response")



# Generated at 2022-06-21 23:13:34.595862
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    """
    This unit test is for method on_response of class MiddlewareMixin
    """
    # Arrange
    import unittest
    from unittest import mock
    from unittest.mock import mock_open
    import sanic
    from sanic.exceptions import ServerError
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from unittest.mock import MagicMock
    import json

    def before_request(request):
        return request

    def after_request(request, response):
        return response

    class TestMiddlewareMixin(unittest.TestCase):
        def setUp(self):
            self.app = sanic.Sanic('TestMiddlewareMixin')

# Generated at 2022-06-21 23:13:45.175199
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import pytest
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    class TestClass(MiddlewareMixin):
        pass

    tc = TestClass()

    def test_middleware_1(request):
        test_middleware_1.called = True

    tc.on_request(test_middleware_1)
    assert test_middleware_1.called is True

    def test_middleware_2(request):
        test_middleware_2.called = True

    tc.on_response(test_middleware_2)
    assert test_middleware_2.called is True

    @tc.on_request()
    def test_middleware_3(request):
        test_middleware_3.called = True


# Generated at 2022-06-21 23:13:50.745633
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    test_middleware_mixin = TestMiddlewareMixin()

    @test_middleware_mixin.on_request()
    def test_middleware(request):
        pass

    print(test_middleware_mixin._future_middleware[0])

# Generated at 2022-06-21 23:14:02.755009
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Test:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        @on_response
        def on_response(self, request, response):
            pass

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa


# Generated at 2022-06-21 23:14:05.365822
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    def f():
        pass
    assert f == MiddlewareMixin().on_response(f)


# Generated at 2022-06-21 23:14:07.238790
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class M(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    m = M()
    assert m._future_middleware == []

# Generated at 2022-06-21 23:14:08.062144
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    pass

# Generated at 2022-06-21 23:14:12.091337
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic('test_on_response_of_MiddlewareMixin')
    @app.on_response()
    def process_response(request, response):
        response.body += 'bar'

    @app.route('/')
    async def handler(request):
        return response.text('foo')
    do_request(app, 'GET', '/')

# Generated at 2022-06-21 23:14:22.681296
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixin_test(MiddlewareMixin):
        
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()
            self._future_middleware: List[FutureMiddleware] = []
        
        def _apply_middleware(self, middleware: FutureMiddleware):
            if middleware._attach_to == 'request':
                print('request')
            elif middleware._attach_to == 'response':
                print('response')
            else:
                print('None')
        
    MiddlewareMixin_test = MiddlewareMixin_test()
    @MiddlewareMixin_test.on_request()
    def middleware_on_request():
        print('a')
    middleware_on_request()
    

# Generated at 2022-06-21 23:14:33.562845
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Test_MiddlewareMixin(MiddlewareMixin):
        pass
    obj = Test_MiddlewareMixin()
    assert obj._future_middleware == []


# Generated at 2022-06-21 23:14:36.753153
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin = MiddlewareMixin()
    assert mixin is not None
    
    assert mixin._future_middleware == []
    

# Generated at 2022-06-21 23:14:44.322570
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MockSanic:
        def __init__(self, *args, **kwargs):
            self._future_middleware = []

        def _apply_middleware(self, middleware):
            self._future_middleware.append(middleware)

    mock_sanic = MockSanic()
    mixin = MiddlewareMixin()
    mixin._apply_middleware = mock_sanic._apply_middleware
    mixin._future_middleware = mock_sanic._future_middleware
    mixin.middleware(lambda x: x)
    assert len(mixin._future_middleware) == 1

# Generated at 2022-06-21 23:14:47.925713
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MiddMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(MiddMixin, self).__init__(*args, **kwargs)
            self.middleware(self.on_request, apply=False)
        def on_request(self, request):
            return request
    class Test:
        def __init__(self, request):
            self.request = request
    request = Test(request)
    result = MiddMixin(request)
    assert result.request == request



# Generated at 2022-06-21 23:14:49.301045
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    pass # test passed



# Generated at 2022-06-21 23:14:51.512671
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert callable(MiddlewareMixin.middleware)

# Generated at 2022-06-21 23:15:01.173538
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Test 1
    @app.on_request
    async def middleware1(request):
        return request
    @app.on_request
    async def middleware2(request):
        return request

    len_middleware = len(app._future_middleware)
    assert app.middleware(middleware1, attach_to='request') == middleware1
    assert len(app._future_middleware) == len_middleware + 1

    # Test 2
    @app.on_request()
    async def middleware1(request):
        return request
    @app.on_request()
    async def middleware2(request):
        return request

    len_middleware = len(app._future_middleware)
    assert app.middleware(middleware1, attach_to='request') == middleware1

# Generated at 2022-06-21 23:15:03.784995
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mid=MiddlewareMixin()
    assert mid._future_middleware==[]


# Generated at 2022-06-21 23:15:09.711732
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_on_request')

    @app.middleware
    async def test_on_request(request):
        assert 'middleware' == request

    assert '/' not in app._middleware

    @app.route('/')
    def handler(request):
        assert 'request' == request

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert b'' == response.body



# Generated at 2022-06-21 23:15:20.271135
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.response import json, text

    app = Sanic("test_MiddlewareMixin_middleware")

    @app.middleware
    async def valid_middleware(request):
        assert "method" in request.scope
        assert "type" in request.scope
        response = json({"valid": True})
        return response

    @app.route("/")
    async def index(request):
        response = json({"valid": True})
        return response

    _, response = app.test_client.get("/")
    assert response.json == {"valid": True}

    @app.middleware("response")
    async def process_response(request, response):
        assert response.text == '{"valid": true}'
        return text("OK")


# Generated at 2022-06-21 23:15:35.539402
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.server import Sanic
    app = Sanic()
    assert "MiddlewareMixin" in repr(type(app))


# Generated at 2022-06-21 23:15:44.756936
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    app = Sanic("sanic-server")

    @app.middleware("request")
    async def print_on_request(request):
        print("I am a request middleware")

    @app.middleware("response")
    async def print_on_response(request, response):
        print("I am a response middleware")

    assert len(app.middleware_request) == 1
    assert len(app.middleware_response) == 1

# Generated at 2022-06-21 23:15:50.125270
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    test_MiddlewareMixin = MiddlewareMixin()
    assert len(test_MiddlewareMixin._future_middleware) == 0
    assert callable(test_MiddlewareMixin._apply_middleware)


# Generated at 2022-06-21 23:15:51.527601
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    pass


# Generated at 2022-06-21 23:15:54.811389
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Test initialise MiddlewareMixin
    temp_middleware = MiddlewareMixin()
    assert temp_middleware._future_middleware == []
   

# Generated at 2022-06-21 23:16:06.698010
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Arrange
    class TestC(MiddlewareMixin):
        def __init__(self):
            super().__init__()
            self._apply_middleware = lambda middleware: None

    expected_srv = TestC()
    def my_middleware(request):
        pass
    # Act
    actual_srv = expected_srv.on_response(my_middleware)

    # Assert
    assert actual_srv == my_middleware
    assert expected_srv._future_middleware[0].middleware == my_middleware
    assert expected_srv._future_middleware[0].attach_to == "response"


# Generated at 2022-06-21 23:16:11.990044
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')
    @app.on_response()
    async def test_on_response(request, response):
        pass
    @app.on_request()
    async def test_on_request(request):
        pass
    print(app._future_middleware)
    assert len(app._future_middleware) == 2



# Generated at 2022-06-21 23:16:17.920218
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Declare and initialize an instance of class MiddlewareMixin
    middlewareMixin_obj = MiddlewareMixin()
    # Execution of on_request method
    response = middlewareMixin_obj.on_request()
    # Assertion of function on_request
    assert callable(response) and response is not None


# Generated at 2022-06-21 23:16:20.169886
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic('test')

    assert app.on_request.__name__ == 'on_request'


# Generated at 2022-06-21 23:16:23.241499
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class UnitTest(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__()
    
    instance = UnitTest()
    assert isinstance(instance, UnitTest)
    assert instance._future_middleware == []


# Generated at 2022-06-21 23:16:57.807324
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound

    app = Sanic(__name__)

    @app.middleware
    def return_404(request):
        raise NotFound("It's gone!")


    @app.route("/")
    def handler(request):
        return text("I completed")


    request, response = app.test_client.get("/")
    assert response.status == 404



# Generated at 2022-06-21 23:16:58.326571
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass

# Generated at 2022-06-21 23:17:07.310726
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    auth = False
    class app(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            # JT: Here, we simulate the execution of on_request by initializing
            # some attributes into the object.
            self.on_request(
                lambda request: None
            )
            self.on_request(
                lambda request: None
            )
        def _apply_middleware(self, middleware: FutureMiddleware):
            if isinstance(middleware, FutureMiddleware):
                auth = True

    application = app()
    assert application.on_request() == partial(application.middleware, attach_to='request')
    assert application.on_request(lambda request: None) == None
    assert auth

# Generated at 2022-06-21 23:17:10.841152
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    m = MiddlewareMixin()
    assert m.on_request() is not None
    assert m.on_request()('test') is not None


# Generated at 2022-06-21 23:17:13.892905
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    with pytest.raises(NotImplementedError):
        MiddlewareMixin()._apply_middleware(None)



# Generated at 2022-06-21 23:17:20.181815
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic()

    # Case 1: call function middleware
    def middleware_1(request):
        return request

    def middleware_2(request):
        return request

    app.middleware(middleware_1)
    app.middleware(middleware_2)

    assert app._future_middleware[0].middleware == middleware_1
    assert app._future_middleware[1].middleware == middleware_2

    # Case 2: call function middleware with attach_to
    app.middleware(middleware_1, 'request')
    app.middleware(middleware_2, 'response')

    assert app._future_middleware[2].attach_to == 'request'
    assert app._future_middleware[3].attach_to == 'response'



# Generated at 2022-06-21 23:17:20.926882
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    response = on_request()
    assert not response


# Generated at 2022-06-21 23:17:26.231601
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    test = MiddlewareMixin()

    result = test.middleware(middleware_or_request="request")
    assert result == "<function MiddlewareMixin.middleware.<locals>.register_middleware at 0x000001D94B7C9378>"

    def sample_middleware(request):
        return request

    sample_middleware_result = sample_middleware("request")
    assert sample_middleware_result == "request"

# Generated at 2022-06-21 23:17:27.165743
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    pass

# Generated at 2022-06-21 23:17:35.170364
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic(__name__)

    #  Example use on_response with default param
    @app.on_response()
    def on_response(request, response):
        print(request)
        print(response)

    # Exaple use on_response without param
    @app.on_response
    def on_response1(request, response):
        print(request)
        print(response)

    assert len(app._future_middleware) == 2

    # Exaple use on_response with custom callable
    def on_response2(request, response):
        print(request)
        print(response)
    app.on_response(on_response2)

    assert len(app._future_middleware) == 3


# Generated at 2022-06-21 23:18:36.398966
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    mwm = MiddlewareMixin()



# Generated at 2022-06-21 23:18:40.140388
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mixin = MiddlewareMixin()
    assert mixin._future_middleware == []

if __name__ == "__main__":
    test_MiddlewareMixin()

# Generated at 2022-06-21 23:18:47.012351
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import unittest

    class MockMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, future_middleware):
            self._future_middleware.append(future_middleware)

    class TestMiddlewareMixin(unittest.TestCase):
        def test_middleware_with_parameters(self):
            mockMiddlewareMixin = MockMiddlewareMixin()
            self.assertListEqual(mockMiddlewareMixin._future_middleware, [])

            # test MiddlewareMixin._future_middleware with function
            mockMiddlewareMixin.middleware(lambda: None)
            self.assertEqual(len(mockMiddlewareMixin._future_middleware), 1)

# Generated at 2022-06-21 23:18:54.525648
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Arrange
    from sanic import Sanic

    app = Sanic("test_MiddlewareMixin_middleware")

    async def middleware(request):
        pass
    app.middleware(middleware)
    # Assert
    assert len(app._future_middleware) == 1
    # Assert
    for future_middleware in app._future_middleware:
        assert future_middleware.middleware == middleware
        assert future_middleware.attach_to == "request"


# Generated at 2022-06-21 23:19:00.897421
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Achieves 100% line coverage but not complete branch coverage
    mock_args = object()
    mock_kwargs = dict()
    middleware_mixin = MiddlewareMixin(mock_args, **mock_kwargs)
    assert middleware_mixin._future_middleware == []


# Generated at 2022-06-21 23:19:02.881804
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass


if __name__ == '__main__':
    test_MiddlewareMixin_middleware()

# Generated at 2022-06-21 23:19:07.209238
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    app = create_app()
    assert app.on_response().__name__ == 'register_middleware'


# Generated at 2022-06-21 23:19:14.913342
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class MiddlewareMixinTest:
        def __init__(self, *args, **kwargs):
            self._future_middleware = []

        def _apply_middleware(self, middleware):
            raise NotImplementedError

    def middleware_test(request):
        pass

    MiddlewareMixinTest = MiddlewareMixin(MiddlewareMixinTest)
    x = MiddlewareMixinTest()
    x.on_response(middleware_test)