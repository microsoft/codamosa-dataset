

# Generated at 2022-06-21 23:09:23.678440
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    mm = MiddlewareMixin(object)
    assert not mm.middleware([], "request", True)

# Generated at 2022-06-21 23:09:26.949260
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    test_middleware_mixin = MiddlewareMixin()
    test_middleware = test_middleware_mixin.middleware(None)
    assert test_middleware == NotImplemented


# Generated at 2022-06-21 23:09:35.589443
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Create a new class derived from the MiddlewareMixin
    class MyClass(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(MyClass, self).__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    # Create and instance of `MyClass`
    MyClassInstance = MyClass()
    # Define a middleware.
    def middleware(request):
        pass
    # Register the middleware to the `on_request` method.
    MyClassInstance.on_request(middleware)
    # Check if the middleware is registered.
    assert callable(MyClassInstance._future_middleware[0])
    assert isinstance(MyClassInstance._future_middleware[0], FutureMiddleware)



# Generated at 2022-06-21 23:09:42.230922
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    import pytest
    from sanic import Sanic
    from sanic.models.futures import FutureMiddleware
    m_app = Sanic()
    assert isinstance(m_app, MiddlewareMixin)
    assert m_app._future_middleware == []
    # Here we test that function without any parameters
    with pytest.raises(NotImplementedError):
        m_app._apply_middleware(FutureMiddleware(None, 'request'))
    # Here we test that function with one parameter
    with pytest.raises(NotImplementedError):
        m_app._apply_middleware(FutureMiddleware(None, 'request'))
    # We test the function with two parameters

# Generated at 2022-06-21 23:09:52.198026
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class T(MiddlewareMixin):
        _apply_middleware = None

    t = T()
    with pytest.raises(NotImplementedError):
        t._apply_middleware = None
        t.middleware(lambda: None)()

    t._apply_middleware = lambda middleware: middleware.run()

    @t.middleware
    def _middleware():
        pass

    t._middleware()

    with pytest.raises(Exception):
        t.middleware(attach_to="wrong")(lambda: None)()

    with pytest.raises(Exception):
        t.middleware(attach_to="request")(lambda: None)()

    t._future_middleware = []


# Generated at 2022-06-21 23:10:01.899886
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import json
    from unittest import TestCase
    from unittest.mock import create_autospec

    app = Sanic("test_get_middleware")

    class Test(TestCase):
        def __init__(self, app, methodName):
            super().__init__(methodName)
            self.app = app

        def test_on_response(self):
            mw = create_autospec(self.process_response)
            self.app.on_response(mw)

            @self.app.get("/")
            async def handler(request):
                return json({"test": True})

            request, response = app.test_client.get(self.app.url_for("handler"))

# Generated at 2022-06-21 23:10:10.596010
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import json, HTTPResponse

    app = Sanic()

    @app.middleware('request')
    def request_middleware(request):
        pass

    @app.middleware('response')
    def response_middleware(request, response):
        pass

    @app.get('/')
    def handler(request):
        return json({'test': 'pass'})

    request, response = app.test_client.get('/')
    assert response.json == {'test': 'pass'}

    request, response = app.test_client.get('/')
    assert response.json == {'test': 'pass'}

    @app.on_response('request')
    def request_middleware(request, response):
        pass


# Generated at 2022-06-21 23:10:18.935813
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class FakeApp:
        def _apply_middleware(self, middleware):
            # This is a middleware method added to class FakeApp.
            # The middleware method is added successfully, if the code path
            # can reach here. In other words, the test case is passed, if no
            # exception is raised.
            pass

    app = MiddlewareMixin()
    app.__class__ = FakeApp

    @app.middleware
    def fake_middleware():
        print("fake_middleware()")

    fake_middleware()

# Generated at 2022-06-21 23:10:30.922484
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class App(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            MiddlewareMixin.__init__(self, *args, **kwargs)
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    app = App()

    middleware_1 = (lambda _, __: None)
    middleware_2 = (lambda _, __, ___: None)
    middleware_3 = (lambda _, __: None)
    middleware_4 = (lambda _, __, ___: None)

    # test default params
    app.middleware(middleware_1)
    app.middleware(middleware_2)
    assert len(app._future_middleware) == 2
    assert app._future_middleware[0].middleware == middleware_1

# Generated at 2022-06-21 23:10:32.584872
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    async def response_func(request, response):
        return response
    assert True


# Generated at 2022-06-21 23:10:43.223421
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    app = Sanic()

    @app.on_request
    def before_request_test(request):
        request.test = True

    class ServerTest(SanicTestClient):
        def __init__(
            self, app, uri="http://test"  # pylint: disable=E1003
        ):
            SanicTestClient.__init__(self, app, uri=uri)

        async def test_middleware(self):
            request, response = await self.get("/")
            self.assertIsNotNone(request.test)

    test_client = ServerTest(app)
    test_client.test_middleware()


# Generated at 2022-06-21 23:10:49.443519
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # Assert exception is raised when middleware is None
    mixin = MiddlewareMixin()
    with pytest.raises(TypeError):
        mixin.on_response()

    # Assert callable is returned when middleware is not None
    assert callable(mixin.on_response(lambda: None))

# Generated at 2022-06-21 23:10:58.118279
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    # Create instance of class Sanic
    app = Sanic("sanic-application")

    # Test method middleware of class Sanic
    # Create a function named "middleware"
    def middleware(request):
        print("middleware")

    # Register a middleware to be called before a request
    app.middleware(middleware)
    # Check value of instance variable _future_middleware
    assert len(app._future_middleware) == 1

    # Test method middleware of class Sanic
    # Register a middleware to be called before a request
    app.middleware(middleware, "response")
    # Check value of instance variable _future_middleware
    assert len(app._future_middleware) == 2

    # Test method middleware of class Sanic
    # Register a middleware

# Generated at 2022-06-21 23:10:58.717926
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()._future_middleware == []

# Generated at 2022-06-21 23:11:10.932638
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.exceptions import NotFound, ServerError  # type: ignore
    from sanic.response import text  # type: ignore
    from sanic.request import Request

    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_middleware(
            self, middleware: FutureMiddleware  # type: ignore
        ):
            pass

    app = TestMiddlewareMixin()

    @app.on_request
    def on_request(request):
        return request

    @app.on_response
    def on_response(request, response):
        return response

    @app.exception(NotFound)
    def ignore_404s(request, exception):
        return text

# Generated at 2022-06-21 23:11:18.254692
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    obj = MiddlewareMixin()
    def test_middleware(request):
        return request
    assert obj.on_request(test_middleware) == obj.on_request()(test_middleware)
    obj.on_request(test_middleware)
    assert obj.on_request()(test_middleware)


# Generated at 2022-06-21 23:11:23.630752
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Request:
        pass

    class Response:
        pass

    class Sanic:
        # Create empty objects 
        middleware = MiddlewareMixin()
        request = Request()
        response = Response()
        # Create a closure to be used as middleware
        def my_middleware(self, request, response):
            print(self, request, response)
            return True

    # Test on_request method
    Sanic.middleware.on_response(Sanic.my_middleware)(Sanic, Sanic.request, Sanic.response)



# Generated at 2022-06-21 23:11:28.525855
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(TestMixin, self).__init__(*args, **kwargs)
    m = TestMixin()
    assert isinstance(m._future_middleware, list)



# Generated at 2022-06-21 23:11:34.767380
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    test_middleware = TestMiddlewareMixin()
    # call on_response
    test_middleware.on_response()

# Generated at 2022-06-21 23:11:39.453383
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic

    app = Sanic(__name__)

    @app.on_request
    def on_request_handler(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0]._attach_to == 'request'



# Generated at 2022-06-21 23:11:50.122876
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    from sanic.response import HTTPResponse

    async def handler(request):
        return HTTPResponse("OK")

    async def handler_2(request):
        return HTTPResponse("OK")


    def response_middleware(request, response):
        return response


    def response_middleware_2(request, response):
        return response


    app = Sanic('test_MiddlewareMixin_on_response')

    app.on_response(response_middleware)
    app.on_response(response_middleware_2)(handler)

    assert True

# Generated at 2022-06-21 23:12:00.521159
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    def middleware_func(request):
        request.app.test_value = True

    app.middleware(middleware_func)
    assert app.test_value == True

    # Test on_request
    def middleware_func(request):
        request.app.test_value2 = True

    app.on_request(middleware_func)
    assert app.test_value2 == True

    # Test on_response
    def middleware_func(request, response):
        request.app.test_value3 = True

    app.on_response(middleware_func)
    assert app.test_value3 == True

# Generated at 2022-06-21 23:12:06.995514
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.request import Request

    @MiddlewareMixin.on_request
    def func(request: Request):
        return request
    app = Sanic("test_middleware_on")
    app.middleware(func)
    app.get("/test")(func).result()

# Generated at 2022-06-21 23:12:12.511725
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.models.middleware import MiddlewareMixin
    class A(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []
            self.middleware(middleware_or_request, attach_to="request")
    test=A(1,2,3,4,5)
    assert test.middleware()==partial(test.middleware, attach_to="response")

# Generated at 2022-06-21 23:12:13.822554
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from .interface import MiddlewareMixin
    m = MiddlewareMixin()
    assert m.on_request is m.middleware

# Generated at 2022-06-21 23:12:20.749571
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = Sanic('test')

    # test_on_request_correctly_decorates_function
    def _decorated_function():
        pass
    app.on_request(_decorated_function)
    assert app.middleware._middleware_stack == [
        FutureMiddleware(_decorated_function, attach_to='request')]

    # test_on_request_correctly_decorates_partial
    def _decorated_function():
        pass
    app.on_request(_decorated_function)
    assert app.middleware._middleware_stack == [
        FutureMiddleware(_decorated_function, attach_to='request')]
    app.on_request()(_decorated_function)

# Generated at 2022-06-21 23:12:21.845738
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mid_mix = MiddlewareMixin()

# Generated at 2022-06-21 23:12:22.730810
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    pass



# Generated at 2022-06-21 23:12:31.157139
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from unittest.mock import MagicMock, call
    from sanic import Sanic

    # Checks that the function middleware, of Sanic object, is called with correct
    # arguments.
    app = Sanic()
    app.middleware = MagicMock()
    app.on_response(lambda f: 'do something')
    app.middleware.assert_called_once_with(lambda f: 'do something', 
        attach_to='response')

    # Checks that the function middleware, of Sanic object, is called with correct
    # arguments without specifying attach_to parameter.
    app = Sanic()
    app.middleware = MagicMock()
    app.on_response()(lambda f: 'do something')

# Generated at 2022-06-21 23:12:38.538732
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # arrange
    from sanic import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    # act
    @app.middleware
    async def print_request(request):
        print(request)

    # assert
    assert app._future_middleware[0].middleware.__name__ == 'print_request'
    assert app._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-21 23:12:52.081240
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic
    from sanic.response import html, json
    app = Sanic(__name__)

    @app.middleware
    async def print_on_request(request):
        print("I print when a request is received by the server")

    @app.route("/")
    def handler(request):
        return html("I am a Sanic application!")

    request, response = app.test_client.get('/')
    m = MiddlewareMixin()


if __name__ == "__main__":
    test_MiddlewareMixin()

# Generated at 2022-06-21 23:12:56.899950
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestSubclass(MiddlewareMixin):
        pass

    test_subclass = TestSubclass()
    assert isinstance(test_subclass, MiddlewareMixin)

    assert test_subclass._future_middleware == []


# Generated at 2022-06-21 23:13:04.794942
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # create a test instance
    from sanic.app import Sanic
    middleware_mixin_test_case = Sanic()

    # define test middlewares
    middleware_test_1 = lambda request: request
    middleware_test_2 = lambda request: None

    # register middlewares
    middleware_mixin_test_case.middleware(middleware_test_1, attach_to='request')
    middleware_mixin_test_case.middleware(middleware_test_2, attach_to='response')

    # test for the result of method middleware object
    assert middleware_mixin_test_case._future_middleware[0].middleware == middleware_test_1
    assert middleware_mixin_test_case._future_middleware[0].attach_to == 'request'

# Generated at 2022-06-21 23:13:13.154443
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.route("/")
    def handler(request):
        return HTTPResponse("OK")
    
    @app.listener("before_server_start")
    async def before_server_start_(app: Sanic, loop):
        from types import FunctionType
        _on_request = app.on_request(middleware=FunctionType)
        print(type(_on_request))

    app.run(host="0.0.0.0", port=8000, debug=True, access_log=False)


# Generated at 2022-06-21 23:13:16.371085
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    temp_class = MiddlewareMixin()
    print(temp_class.on_request)

if __name__ == "__main__":
    test_MiddlewareMixin_on_request()

# Generated at 2022-06-21 23:13:18.956803
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    assert bool(Sanic(__name__).on_request(middleware=lambda x: x))


# Generated at 2022-06-21 23:13:24.948175
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    async def func():
        assert 1 == 1
    mm = MiddlewareMixin()
    mm.middleware(func)
    mm.on_request(func)
    mm.on_response(func)

if __name__ == "__main__":
    test_MiddlewareMixin()

# Generated at 2022-06-21 23:13:29.763424
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestClass(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa

    a = TestClass()
    assert a._future_middleware == []
    assert a._apply_middleware(None) is None

# test callable()

# Generated at 2022-06-21 23:13:41.375392
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MockApp:
        pass

    m_mock_app = MockApp()
    m_mock_app.middleware = lambda x, y: f"Middleware has been attached at {y}"
    
    m_middleware_mixin = MiddlewareMixin()
    m_middleware_mixin.middleware = m_mock_app.middleware
    m_middleware_mixin.on_request = m_middleware_mixin.on_request
    result = m_middleware_mixin.on_request()
    assert result == "Middleware has been attached at request"

test_MiddlewareMixin_on_request()


# Generated at 2022-06-21 23:13:45.218526
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class UnitTestMiddlewareMixin(MiddlewareMixin):
        ...

    # Constructor
    test_mixin = UnitTestMiddlewareMixin()
    assert test_mixin

# Generated at 2022-06-21 23:14:02.681853
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic, SanicPlugins, SanicPluginsInit
    from sanic.plugins.sanic_plugins import SanicPluginsMixin
    from sanic.request import Request
    from sanic.response import HTTPResponse
    import asyncio

    class MyApp(MiddlewareMixin, SanicPluginsMixin, Sanic):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            self._middleware.append(middleware)

    async def mrw(request):
        return HTTPResponse(text="Ok")

    async def test(request: Request):
        return HTT

# Generated at 2022-06-21 23:14:12.758687
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.models.middleware import Middleware
    from sanic.models.futures import FutureMiddleware
    from sanic.models.handler import RequestHandler
    from sanic.models.handler import RequestRouter

    def request_handler(request, response):
        return json({"test": True})

    # Create instance of Sanic app and configure
    app = Sanic(__name__, load_env=False)
    app.config.KEEP_ALIVE = False

    # Create request handler
    request_handler = RequestHandler(
        request_handler, [Middleware()], None, "GET", "/"
    )

    # Create request router
    request_router = RequestRouter()
    request_router.add(request_handler)

# Generated at 2022-06-21 23:14:19.171385
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    mixin = MiddlewareMixin()
    mixin.middleware(FutureMiddleware(lambda x: x, 'request'))
    # print(mixin._future_middleware)
    assert mixin._future_middleware[0].attach_to == 'request'

# Generated at 2022-06-21 23:14:20.999447
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin.on_request(MiddlewareMixin) != None

# Generated at 2022-06-21 23:14:26.686024
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            MiddlewareMixin.__init__(self, *args, **kwargs)
    middleware = TestMiddlewareMixin()
    assert middleware._future_middleware == []

# Generated at 2022-06-21 23:14:32.645257
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware

    app = Sanic('test')

    mw_a = FutureMiddleware(None, None)
    mw_b = FutureMiddleware(None, None)

    app.middleware(mw_a, 'request', apply=False)
    app.middleware(mw_b, 'response', apply=False)

    # Check for appropriate initializer
    assert app._future_middleware == [mw_a, mw_b]

    # Check for appropriate middleware method
    assert app.middleware == MiddlewareMixin.middleware

# Generated at 2022-06-21 23:14:38.481562
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class App(MiddlewareMixin):
        def __init__(self):
            super().__init__()
        def _apply_middleware(self, middleware):
            pass
    app = App()
    assert app._future_middleware == []
    assert app._apply_middleware == None

# Generated at 2022-06-21 23:14:44.119289
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    middleware_mixin = MiddlewareMixin()
    def middleware(request, response): return response
    assert callable(middleware_mixin.on_response(middleware))
    assert callable(middleware_mixin.on_response())


# Generated at 2022-06-21 23:14:48.486157
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    mm = MiddlewareMixin()
    mm1 = mm.on_response()
    assert str(mm1) == '<function MiddlewareMixin.on_response.<locals>.register_middleware at 0x7f9d9e7a0f28>'
    

# Generated at 2022-06-21 23:15:00.373399
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    try:
        import pytest
    except:
        print("Pytest hasn't been installed. Something goes wrong.")
        exit(1)
    from sanic import Sanic
    from sanic.response import json
    from sanic.models.futures import FutureMiddleware

    def handler(request):
        return json({"hello": "world"})

    def middleware(request):
        return request

    app = Sanic()

    app.add_route(handler, "/")

    @app.on_response
    def response_middleware(request, response):
        return response

    request, response = app.test_client.get("/")
    assert response.status == 200
    assert response.json == {"hello": "world"}
    assert len(app._future_middleware) == 1

# Generated at 2022-06-21 23:15:14.176020
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewareMixin = MiddlewareMixin()
    print(middlewareMixin)


# Generated at 2022-06-21 23:15:18.177018
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = MockMiddlewareMixin()
    @app.middleware
    def test_on_request_mwd(req):
        return req
    assert test_on_request_mwd in app._future_middleware
    assert app._apply_middleware_called == True


# Generated at 2022-06-21 23:15:28.756980
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic.models.base import BaseModel
    from sanic.models.route import RouteModel

    # MiddlewareMixin.__init__ has only one parameter "*args"
    # middleware_mixin_constructor_with_0_parameters = MiddlewareMixin()
    # middleware_mixin_constructor_with_0_parameters
    # AssertionError: MiddlewareMixin() takes 0 positional arguments but 1 was given

    # MiddlewareMixin.__init__ has only one parameter "*args"
    # middleware_mixin_constructor_with_1_parameter = MiddlewareMixin(1)
    # middleware_mixin_constructor_with_1_parameter
    # AssertionError: MiddlewareMixin() takes 0 positional arguments but 1 was given
    #


# Generated at 2022-06-21 23:15:33.213300
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixin_test(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            self.middleware = middleware

    MiddlewareMixin_test()



# Generated at 2022-06-21 23:15:36.046169
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic

    app = Sanic()

    assert isinstance(app._middleware, MiddlewareMixin)
    assert app._middleware._future_middleware == []


# Generated at 2022-06-21 23:15:44.694102
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(self, *args, **kwargs)
            self._future_middleware=[]

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    mixin = TestMiddlewareMixin()
    assert mixin._future_middleware==[]


# Generated at 2022-06-21 23:15:56.825779
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware(): 
    
    #Test Arguments:
    middleware_or_request = 'request'
    attach_to='request'
    apply=True
    
    #Case13: Attach an request event to the middleware
    closure_callable = MiddlewareMixin.middleware(middleware_or_request, attach_to, apply)
    closure_callable(1)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
if __name__ == "__main__":
    test_MiddlewareMixin_middleware()

# Generated at 2022-06-21 23:15:59.650872
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert (MiddlewareMixin.on_request)

# Generated at 2022-06-21 23:16:08.651253
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
            from sanic import Sanic
            from sanic.response import json
            from sanic.views import HTTPMethodView

            app = Sanic('test_MiddlewareMixin_on_request')

            class SimpleView(HTTPMethodView):
                def get(self, request):
                    return json({'hello': 'world'})

            def middleware1(request):
                request['middleware'] = 'This is middleware1'
                return request

            def middleware2(request):
                request['middleware'] = 'This is middleware2'
                return request

            @app.on_request(middleware1)
            @app.on_request(middleware2)
            def middleware(request):
                request['middleware'] = 'This is middleware'
                return request


# Generated at 2022-06-21 23:16:19.294340
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    def middleware_test(request):
        pass

    assert app.is_request_stream is False
    assert len(app.middleware_stack) == 0
    assert len(app._future_middleware) == 0

    # Test @app.middleware
    app.middleware(middleware_test)
    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == middleware_test
    assert app._future_middleware[0].attach_to == "request"

    # Test @app.middleware('request')
    app.middleware('request')(middleware_test)
    assert len(app._future_middleware) == 2


# Generated at 2022-06-21 23:16:46.244227
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    obj = MiddlewareMixin()
    assert len(obj._future_middleware) == 0


# Generated at 2022-06-21 23:16:55.104840
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic, response
    from sanic.response import BaseHTTPResponse
    from sanic.models.futures import FutureMiddleware
    from Web.App.middleware import MiddlewareMixin

    app = Sanic('test_app')
    MiddlewareMixin(app)

    @app.middleware
    async def print_on_request(request):
        assert request

    @app.middleware('response')
    async def print_on_response(request, response):
        assert request
        assert isinstance(response, BaseHTTPResponse)

    @app.route('/')
    async def handler(request):
        return response.json({"hello": "world"})

    request, response = app.test_client.get('/')
    # If a request is made, the test will fail


# Generated at 2022-06-21 23:16:58.038424
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        pass

    tmm = TestMiddlewareMixin()
    assert tmm._future_middleware == []



# Generated at 2022-06-21 23:17:01.711007
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    app = Sanic("test_on_request")

    @app.middleware("request")
    async def async_on_request(request):
        request["a"] = 4

    request, response = app.test_client.get("/")
    assert request["a"] == 4



# Generated at 2022-06-21 23:17:08.236555
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic

    app = Sanic(__name__)
    @app.on_response
    def response_middleware(response):
        response.headers["x-middleware"] = "true"

    request, response = app.test_client.get(
        "/", headers={"x-test": "true"}
    )
    assert response.headers["x-middleware"] == "true"
    assert response.headers["x-test"] == "true"


# Generated at 2022-06-21 23:17:11.839159
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class MyClass(MiddlewareMixin):
        pass
    assert MyClass.on_request(None) == partial(MyClass.middleware, attach_to="request")


# Generated at 2022-06-21 23:17:15.911319
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic

    app = Sanic()

    @app.middleware
    def request_middleware(request):
        return request

    @app.on_response
    def response_middleware(request, response):
        return response

    assert len(app._future_middleware) == 2

# Generated at 2022-06-21 23:17:25.516343
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import json
    @app.middleware('response')
    def cors_headers(request, response):
        """Add CORS headers to each response."""
        response.headers['Access-Control-Allow-Origin'] = '*'
        response.headers['Access-Control-Allow-Headers'] = (
            'Authorization, Content-Type'
        )
        response.headers['Access-Control-Allow-Methods'] = (
            'OPTIONS, HEAD, GET, POST, PUT, PATCH, DELETE'
        )

    @app.route('/')
    async def index(request):
        return json({'hello': 'world'})

    app.run(host='0.0.0.0', port=8000)

# Generated at 2022-06-21 23:17:31.404220
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class A:
        def on_request(self, request):
            return request
    obj = A()
    assert callable(obj.on_request())
    assert obj.on_request()('request') == 'request'


# Generated at 2022-06-21 23:17:33.976228
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    # MiddlewareMixin.on_response(middleware=None)
    assert callable(MiddlewareMixin.on_response)