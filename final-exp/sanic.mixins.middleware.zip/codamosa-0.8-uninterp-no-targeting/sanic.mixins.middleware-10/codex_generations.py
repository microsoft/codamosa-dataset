

# Generated at 2022-06-21 23:09:19.042310
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Instance of class
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin._future_middleware == []


# Generated at 2022-06-21 23:09:25.443384
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic

    app = Sanic('test_MiddlewareMixin_middleware')
    assert app._future_middleware == []

    @app.middleware('request')
    async def request_middleware(request):
        assert request is None

    assert app._future_middleware != []
    assert app._future_middleware[0].middleware == request_middleware
    assert app._future_middleware[0].attach_to == 'request'

# Generated at 2022-06-21 23:09:31.854478
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class A():
        def __init__(self, *args, **kwargs):
            self._future_middleware: List[FutureMiddleware] = []
        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa
    a = A()
    a.on_response(middleware)


# Generated at 2022-06-21 23:09:39.415588
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic

    app = Sanic()

    @app.middleware
    async def before(request):
        print("before request")

    @app.on_request
    async def before1(request):
        print("before1 request")

    @app.middleware('response')
    async def after(request, response):
        print("after request")

    @app.on_response
    async def after2(request, response):
        print("after2 request")



# Generated at 2022-06-21 23:09:48.689836
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import text
    app = Sanic()

    @app.on_request
    def request_middleware(request):
        return text('Middleware Works')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'Middleware Works'



# Generated at 2022-06-21 23:09:52.006188
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin.on_request(MiddlewareMixin, middleware=None) == None


# Generated at 2022-06-21 23:10:01.852730
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # step 1. Create an instance of class MiddlewareMixin
    a = MiddlewareMixin()
    print("\n---step 1: a = MiddlewareMixin()---")
    print("type(a) = ", type(a))
    print("a = ", a)
    
    # step 2. Create instances of class FutureMiddleware
    b = FutureMiddleware(FutureMiddleware, 'response')
    print("\n---step 2: b = FutureMiddleware(FutureMiddleware, 'response')---")
    print("type(b) = ", type(b))
    print("b = ", b)
    print("isinstance(b, FutureMiddleware) = ", isinstance(b, FutureMiddleware))
    
    c = FutureMiddleware(FutureMiddleware, 'request')

# Generated at 2022-06-21 23:10:12.928196
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
  from sanic.models.futures import FutureMiddleware

  # test 1
  class Test1(MiddlewareMixin):
    def _apply_middleware(self, middleware: FutureMiddleware):
      pass
    
  def func1():
    pass

  partial_func = Test1().on_request(func1)
  assert partial_func.args == ()
  assert partial_func.keywords == {"attach_to": "request"}
  # test 2
  class Test2(MiddlewareMixin):
    def _apply_middleware(self, middleware: FutureMiddleware):
      pass

  partial_func = Test2().on_request()
  
  assert partial_func.args == ()
  assert partial_func.keywords == {"attach_to": "request"}


# Generated at 2022-06-21 23:10:17.051456
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class TestMiddlewareMixin(MiddlewareMixin):
        pass
    test = TestMiddlewareMixin()
    assert test._future_middleware is not None, "test_MiddlewareMixin passed"

# Generated at 2022-06-21 23:10:22.641629
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class TempMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            return middleware
    # No middleware
    tm = TempMixin()
    assert len(tm._future_middleware) == 0
    # Apply middleware
    def mw():
        pass
    tm.middleware(mw)
    assert len(tm._future_middleware) == 1
    assert tm._future_middleware[0].middleware == mw
    assert tm._future_middleware[0].attach_to == "request"
    # Partially apply middleware
    mwp = tm.middleware('response')
    mwp()
    assert len(tm._future_middleware) == 2

# Generated at 2022-06-21 23:10:26.500854
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mm = MiddlewareMixin()
    assert mm._future_middleware == []


# Generated at 2022-06-21 23:10:29.441060
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class Test(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            assert middleware.attach_to == 'r'

    test = Test()
    @test.on_response('r')
    def middleware1():
        pass


# Generated at 2022-06-21 23:10:38.961911
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    with patch.object(MiddlewareMixin, "middleware") as mock_middleware:
        class TestMiddlewareMixin(MiddlewareMixin):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
        instance = TestMiddlewareMixin()
        instance.on_request(middleware=None)
        mock_middleware.assert_called_once_with(attach_to="request")


# Generated at 2022-06-21 23:10:48.902217
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddlewareMixinTest(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            super(MiddlewareMixinTest, self).__init__(*args, **kwargs)

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    mm = MiddlewareMixinTest()
    
    # test basic attributes of class MiddlewareMixin
    assert mm._future_middleware is not None


# Generated at 2022-06-21 23:10:57.812082
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    print ('#### Test in MiddlewareMixin_middleware_test.py ####')

    class ClassUsedForTesting:
        def __init__(self):
            self._future_middleware = []

    class TestMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            MiddlewareMixin.__init__(self)

    class TestMiddlewareMixinWithoutInit(MiddlewareMixin):
        pass

    class ClassUsedForTestingMiddleware(ClassUsedForTesting):
        def __init__(self):
            ClassUsedForTesting.__init__(self)

        def _apply_middleware(self, middleware):
            print (middleware)
            #self._future_middleware.append(middleware)

    # Test the case where middleware is a function

# Generated at 2022-06-21 23:11:03.624728
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Test case data
    on_request_param1 = None
    on_request_param2 = "request"
    on_request_return1 = None
    on_request_return2 = "request"

    # Perform the test
    from sanic.log import logger

    logger.info("Start test_MiddlewareMixin_on_request")
    middlewareMixin = MiddlewareMixin()
    middlewareMixin.on_request()
    middlewareMixin.on_request(on_request_param1)
    assert isinstance(middlewareMixin.on_request(on_request_param2), type(
        on_request_return2)), "Return value from on_request incorrect"
    logger.info("End test_MiddlewareMixin_on_request")


# Generated at 2022-06-21 23:11:08.182226
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middleware_mixin = MiddlewareMixin()
    assert middleware_mixin._future_middleware == []

if __name__ == "__main__":
    test_MiddlewareMixin()

# Generated at 2022-06-21 23:11:13.585329
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # Arrange
    register_middleware = MagicMock()

    class Middleware:
        def __init__(self, *args, **kwargs):
            self._future_middleware = []
            self._apply_middleware = register_middleware

    # Act
    mixin = Middleware()
    mixin.middleware('request')(MagicMock())
    middleware = mixin._future_middleware[0].middleware

    # Assert
    assert middleware is not None
    register_middleware.assert_called_with(
        mixin._future_middleware[0]
    )

# Generated at 2022-06-21 23:11:19.703300
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class MiddlewareMixinTester(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    m = MiddlewareMixinTester()
    assert m._future_middleware == []


# Generated at 2022-06-21 23:11:28.754106
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():

    import unittest
    from unittest.mock import Mock

    class TestMiddlewareMixin(MiddlewareMixin):

        def __init__(self, *args, **kwargs):
            super(TestMiddlewareMixin, self).__init__(*args, **kwargs)
            self._apply_middleware = Mock()

    app = TestMiddlewareMixin()
    assert app._apply_middleware.call_count == 0

    @app.on_response
    async def on_response(request, response):
        pass
    assert app._apply_middleware.call_count == 1

    @app.middleware("response")
    async def on_response(request, response):
        pass
    assert app._apply_middleware.call_count == 2

# Generated at 2022-06-21 23:11:36.110237
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    MiddlewareMixin._on_request = lambda self, middleware: middleware

    test_instance = MiddlewareMixin()

    assert test_instance.on_request(lambda x: x)() == "called"

# Generated at 2022-06-21 23:11:39.272807
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    assert callable(MiddlewareMixin.middleware)
    # assert callable(MiddlewareMixin.on_request)
    # assert callable(MiddlewareMixin.on_response)
    assert callable(MiddlewareMixin._apply_middleware)

# Generated at 2022-06-21 23:11:51.052262
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MyMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(self, *args, **kwargs)
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    import unittest

    class TestMiddlewareMixin(unittest.TestCase):
        def test_middle_without_middleware(self):
            middleware_mixin = MyMiddlewareMixin()
            self.assertEqual([], middleware_mixin._future_middleware)

        def test_middle_with_middleware(self):
            middleware_mixin = MyMiddlewareMixin()

# Generated at 2022-06-21 23:11:56.841356
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.sanic import Sanic
    from sanic.response import json

    app = Sanic()

    @app.middleware
    async def handler_middleware(request):
        request["foo"] = "bar"

    @app.middleware('request')
    async def handler_request(request):
        request["foo"] = "foo"

    @app.route("/")
    async def handler(request):
        return json({})

    request, response = app.test_client.get('/')

    assert request.get('foo') == "foo"

# Generated at 2022-06-21 23:11:57.911444
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert MiddlewareMixin().on_request()('request') == 'request'

# Generated at 2022-06-21 23:12:00.595431
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # AssertionError: Middleware returned 'ValueError' object when applied on ''
    assert True



# Generated at 2022-06-21 23:12:02.496616
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # code...
    pass



# Generated at 2022-06-21 23:12:08.327845
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_on_response')
    @app.on_response
    def handler(request, response):
        response.body = b"abc"

    @app.route("/")
    async def handler1(request):
        return response

    request, response = app.test_client.get('/')
    assert response.body == b"abc"


# Generated at 2022-06-21 23:12:14.140798
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class testClassMiddlewareMixin(MiddlewareMixin):
        def __init__(self, *args, **kwargs):
            self._future_middleware: List[FutureMiddleware] = []
            self.test = None

        def _apply_middleware(self, middleware: FutureMiddleware):
            self.test = middleware

    testClass = testClassMiddlewareMixin()
    testClass.on_response()
    assert testClass.test == FutureMiddleware(None, 'response')



# Generated at 2022-06-21 23:12:14.749069
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    mmix = MiddlewareMixin()
    assert mmix

# Generated at 2022-06-21 23:12:26.201565
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    app = Sanic('test_MiddlewareMixin_on_request')
    @app.on_request
    async def middleware(request):
        pass
    
    # Check _future_middleware list
    assert app._future_middleware[-1].middleware == middleware
    assert app._future_middleware[-1].attach_to == 'request'
    assert app._future_middleware[-1].args == ()
    assert app._future_middleware[-1].kwargs == {}
    assert app._future_middleware[-1].run == True
    assert app._future_middleware[-1].enabled == True



# Generated at 2022-06-21 23:12:26.611881
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    MiddlewareMixin()

# Generated at 2022-06-21 23:12:34.947995
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic.app import Sanic
    from sanic.models.middleware import FutureMiddleware

    app = Sanic()

    assert isinstance(
        app.on_request(), partial
    )  # noqa: E721

    assert isinstance(
        app.on_request(callable)(), FutureMiddleware
    )  # noqa: E721

    assert app.on_request(callable)().middleware is callable

    assert app.on_request(callable)().attach_to is "request"



# Generated at 2022-06-21 23:12:35.450869
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    pass


# Generated at 2022-06-21 23:12:46.739483
# Unit test for constructor of class MiddlewareMixin

# Generated at 2022-06-21 23:12:48.539136
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    from sanic import Sanic

    app = MiddlewareMixin()

    assert app is not None


# Generated at 2022-06-21 23:12:52.273203
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class MiddlewareMixinTest(MiddlewareMixin):
        def _apply_middleware(self, middleware):
            pass

    test = MiddlewareMixinTest()
    assert test.middleware(None) == test.middleware
    assert test.middleware(None, "request") == test.middleware

# Generated at 2022-06-21 23:13:02.637679
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text
    from sanic.request import Request

    # Case 1: When middleware is None
    def test_case_1():
        app = Sanic()
        response = text("test_case_1")

        @app.route('/test_case_1')
        def test_case_1(request: Request):
            return text("test_case_1")

        @app.on_response()
        def on_response1(request: Request, response):
            return text("test_case_1")

        request, response = app.test_client.get('/test_case_1')
        assert "test_case_1" in response.text

    test_case_1()

    # Case 2: when middleware is callable

# Generated at 2022-06-21 23:13:12.496453
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class Test:
        def __init__(self, *args, **kwargs) -> None:
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            raise NotImplementedError  # noqa


# Generated at 2022-06-21 23:13:15.142938
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewareMixin = MiddlewareMixin()
    assert middlewareMixin._future_middleware == []


# Generated at 2022-06-21 23:13:26.290689
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from .test_models import Sanic
    app = Sanic("test_MiddlewareMixin_on_request")
    @app.on_request
    def handler(request):
        pass
    assert len(app._future_middleware) == 1
    future_middleware = app._future_middleware[0]

# Generated at 2022-06-21 23:13:34.276435
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic import Sanic

    app = Sanic("test_MiddlewareMixin")

    @app.middleware  # noqa
    def middleware(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].middleware == middleware
    assert app._future_middleware[0].attach_to == "request"

    @app.middleware("response")  # noqa
    def other_middleware(request, response):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].middleware == other_middleware
    assert app._future_middleware[1].attach_to == "response"


# Generated at 2022-06-21 23:13:40.121120
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    testMixin = TestMiddlewareMixin()
    assert isinstance(testMixin.on_request(lambda request: request), partial)



# Generated at 2022-06-21 23:13:48.731800
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestClass(MiddlewareMixin):
        pass
    test_MiddlewareMixin = TestClass()
    @test_MiddlewareMixin.on_request()
    def test_func(request):
        pass
    assert test_MiddlewareMixin._future_middleware[0].middleware is test_func
    assert test_MiddlewareMixin._future_middleware[0].attach_to == "request"


# Generated at 2022-06-21 23:13:59.454306
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    # Arrange
    class MyMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            self._future_middleware: List[FutureMiddleware] = []
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    obj = MyMiddlewareMixin()

    # Act
    result = obj.on_request()

    # Assert
    assert callable(result) is True
    assert result.args == ()
    assert result.keywords == {'attach_to': 'request'}


# Generated at 2022-06-21 23:14:03.650211
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    m = MiddlewareMixin()
    assert m._future_middleware == []

if __name__ == "__main__":
    test_MiddlewareMixin()

# Generated at 2022-06-21 23:14:13.093101
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class A:
        def __init__(self,*args,**kwargs):
            self._future_middleware: List[FutureMiddleware] = []

        def _apply_middleware(self, middleware: FutureMiddleware):
            return middleware
        
        def middleware(
            self, middleware_or_request, attach_to="request", apply=True
        ):
            def register_middleware(middleware, attach_to="request"):
                nonlocal apply
                future_middleware = FutureMiddleware(middleware, attach_to)
                self._future_middleware.append(future_middleware)
                if apply:
                    self._apply_middleware(future_middleware)
                return middleware

# Generated at 2022-06-21 23:14:17.913709
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    #arrange
    mixin = MiddlewareMixin()
    #act
    future_middleware = mixin._future_middleware
    #assert
    assert future_middleware is not None
    assert isinstance(future_middleware, list)

# Generated at 2022-06-21 23:14:21.185267
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class FakeMiddlewareMixin(MiddlewareMixin):
        def __init__(self):
            super().__init__()

        def _apply_middleware(self, middleware: FutureMiddleware):
            print(middleware)
            pass

    pass



# Generated at 2022-06-21 23:14:24.755845
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    class Server(MiddlewareMixin):
        def __init__(self):
            super().__init__()

    server = Server()
    m_1 = lambda request: None
    m_2 = lambda request: None
    server.middleware(m_1)
    server.middleware(m_2)
    assert server._future_middleware == [
            FutureMiddleware(m_1, 'request'),
            FutureMiddleware(m_2, 'request')
        ]

# Generated at 2022-06-21 23:14:36.244659
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    class TestClass(MiddlewareMixin):
        pass
    @TestClass.on_request()
    def middleware():
        pass
    assert TestClass()._future_middleware[0].attach_to == 'request'


# Generated at 2022-06-21 23:14:40.658279
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    app = Sanic('test')
    test_MiddlewareMixin = MiddlewareMixin(app)
    assert isinstance(test_MiddlewareMixin.on_request(None), partial)
    assert isinstance(test_MiddlewareMixin.on_request(None), partial)


# Generated at 2022-06-21 23:14:48.491926
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic_openapi.docs import Documentation
    from sanic.app import Sanic
    from sanic.models.futures import FutureMiddleware

    app = Sanic()

    assert len(app._future_middleware) == 0

    @app.on_response
    def on_response(request, response):
        pass

    assert isinstance(app._future_middleware[0], FutureMiddleware)



# Generated at 2022-06-21 23:14:51.812762
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    mmix = MiddlewareMixin()
    mmix.on_response(None)


# Generated at 2022-06-21 23:14:54.976557
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Iniialize a class MiddlewareMixin
    mx = MiddlewareMixin()
    assert mx._future_middleware == []

# Generated at 2022-06-21 23:14:58.821558
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic()
    app._future_middleware = []
    app._apply_middleware = None
    result = app.middleware(
        'request'
        )
    assert callable(result)


# Generated at 2022-06-21 23:15:09.614202
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.sanic import Sanic
    from sanic.response import text
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage
    from sanic.response import HTTPResponse
    from asyncio import Queue
    import asyncio
    import pytest

    app = Sanic("test_MiddlewareMixin_on_response")
    queue = Queue()

    @app.route("/")
    def handler(request):
        return text("OK")

    @app.middleware("response")
    async def response_handler(request, response):
        queue.put_nowait(response)
        return response

    request, response = app.test_client.get("/")
    assert 200 == response.status
    assert "OK" == response.text

# Generated at 2022-06-21 23:15:17.923103
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.request import Request
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware('request')
    async def request_middleware(request):
        assert isinstance(request, Request)

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'


# Generated at 2022-06-21 23:15:27.639921
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic import Sanic
    from sanic.response import text

    # on_response is a method of class MiddlewareMixin
    # Sanic is a subclass of MiddlewareMixin
    app = Sanic('test_MiddlewareMixin_on_response')

    @app.middleware('response')
    async def add_header(request, response):
        response.headers['X-Test'] = '1'

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.headers['X-Test'] == '1'


# Generated at 2022-06-21 23:15:36.137914
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic(__name__)

    @app.middleware('request')
    async def request_middleware(request):
        print('In Request Middleware')

    @app.route('/')
    def handler(request):
        return text('OK')

    @app.on_response('response')
    async def response_handler(request, response):
        print('On Response Handler')

    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-21 23:15:55.955007
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert hasattr(MiddlewareMixin, '_future_middleware') == True
    assert hasattr(MiddlewareMixin, '_apply_middleware') == True
    assert hasattr(MiddlewareMixin, 'middleware') == True
    assert hasattr(MiddlewareMixin, 'on_request') == True
    assert hasattr(MiddlewareMixin, 'on_response') == True


# Generated at 2022-06-21 23:16:07.932433
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.exceptions import NotFound
    from sanic.response import json
    from sanic.request import Request

    mm = MiddlewareMixin()

    @mm.on_response
    def response_handler(request, response):
        return json({"test": 1})

    @mm.on_request
    def request_handler(request):
        return request

    @mm.middleware
    def middleware_handler(response):
        raise NotFound(message="Not found")

    assert mm._apply_middleware(mm._future_middleware[0]) is None

    request = Request("GET", "/test")
    response = mm._future_middleware[0]._call_middleware(request)
    assert response == {"test": 1}

    response = mm._future_middleware[1]._call_middleware(request)

# Generated at 2022-06-21 23:16:14.443531
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    obj = MiddlewareMixin()
    # Case when middleware is not callable
    middleware = 'request'
    result = obj.on_response(middleware)
    assert result == partial(obj.middleware, attach_to='request')
    # Case when middleware is callable
    middleware = 'response'
    result = obj.on_response(middleware)
    assert result == obj.middleware(middleware, attach_to='response')


# Generated at 2022-06-21 23:16:23.601416
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    app = Sanic('test_MiddlewareMixin_middleware')

    @app.middleware
    async def middleware1(request):
        pass

    assert len(app._future_middleware) == 1
    assert app._future_middleware[0].handler is middleware1
    assert app._future_middleware[0].attach_to == 'request'

    @app.middleware('request')
    async def middleware2(request):
        pass

    assert len(app._future_middleware) == 2
    assert app._future_middleware[1].handler is middleware2
    assert app._future_middleware[1].attach_to == 'request'

    @app.middleware('response')
    async def middleware3(request, response):
        pass


# Generated at 2022-06-21 23:16:28.825369
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    class SimpleMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass
    my_middleware = SimpleMiddlewareMixin()
    my_middleware.middleware(middleware = lambda a: a, attach_to = "request")
    assert my_middleware._future_middleware[0].middleware


# Generated at 2022-06-21 23:16:33.537647
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    middlewareMixin = MiddlewareMixin()
    try:
        middlewareMixin._apply_middleware(None)
    except NotImplementedError:
        pass
        #print("Not Implemented Error for _apply_middleware")
    else:
        raise AssertionError("_apply_middleware not implemented")

# Generated at 2022-06-21 23:16:37.677212
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    """
    Constructor of class MiddlewareMixin doesn't need parameter, because it has default value.
    So we don't need to write the test.
    """
    m1 = MiddlewareMixin()

"""
Unit tests for on_request and on_response.
"""


# Generated at 2022-06-21 23:16:38.518738
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert isinstance(MiddlewareMixin(), object)

# Generated at 2022-06-21 23:16:45.532374
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    class TestApp(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            self._future_middleware.append(middleware)

    app = TestApp()
    # Callable
    @app.on_response
    def nop():
        pass
    assert callable(nop)
    assert nop.__name__ == "nop"
    assert app._future_middleware[0]._attach_to == "response"
    assert app._future_middleware[0]._middleware == nop

    app = TestApp()
    # Partial
    @app.on_response()
    def nop():
        pass
    assert callable(nop)
    assert nop.__name__ == "nop"
    assert app._fu

# Generated at 2022-06-21 23:16:46.393241
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    assert MiddlewareMixin()._future_middleware == []

# Generated at 2022-06-21 23:17:33.560129
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.log import error_logger

    error_logger.warning = lambda s: s

    class Parent:
        pass

    class A(MiddlewareMixin):
        pass

    a = A()
    a.on_response(Parent)

    assert isinstance(a._future_middleware[0]._middleware, Parent)
    assert a._future_middleware[0]._attach_to == "response"



# Generated at 2022-06-21 23:17:36.038874
# Unit test for method on_request of class MiddlewareMixin
def test_MiddlewareMixin_on_request():
    assert False # TODO: implement your test here


# Generated at 2022-06-21 23:17:39.217978
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
	app = MiddlewareMixin()
	app.middleware(1, 2, False)



# Generated at 2022-06-21 23:17:46.747148
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    '''
    Test method middleware of class MiddlewareMixin
    '''
    class TestMiddlewareMixin(MiddlewareMixin):
        def _apply_middleware(self, middleware: FutureMiddleware):
            return middleware
    
    # Test positive case
    test_middleware_mixin = TestMiddlewareMixin()
    @test_middleware_mixin.middleware()
    def my_middleware(request):
        return request
    assert len(test_middleware_mixin._future_middleware) > 0
    assert test_middleware_mixin._future_middleware[0].middleware == my_middleware and test_middleware_mixin._future_middleware[0].attach_to == 'request'

    test_middleware_mixin = TestMiddlewareMixin()

# Generated at 2022-06-21 23:17:57.595148
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    from sanic.app import Sanic
    from sanic.exceptions import NotFound
    from sanic.response import text

    async def middleware(request):
        if request.path == '/test':
            raise NotFound("Not Found")
        else:
            return text("")

    # Build app
    app = Sanic("MiddlewareMixin_middleware")

    # Register middleware
    app.middleware(middleware)
    app.middleware(middleware, "response")

    assert len(app._future_middleware) == 2

    # Normal request, no error
    request, response = app.test_client.get("/")
    assert response.status == 200
    assert response.text == ""

    # Error request and error response

# Generated at 2022-06-21 23:18:06.213197
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    listA = []
    def decoratorA(func):
        def wrapped():
            listA.append(1)
            func()
        return wrapped
    class ClassA(MiddlewareMixin):
        pass
    classA = ClassA()
    @classA.middleware
    def functionA():
        listA.append(2)
    functionA()
    listA.append(3)
    assert listA == [1, 2, 3], 'test_MiddlewareMixin_middleware1 failed!'
    listA = []
    @classA.on_request()
    def functionA():
        listA.append(2)
    functionA()
    listA.append(3)
    assert listA == [1, 2, 3], 'test_MiddlewareMixin_middleware2 failed!'
    listA = []


# Generated at 2022-06-21 23:18:14.238559
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    from sanic.server import HttpProtocol
    from sanic.response import HTTPResponse

    async def test_middleware(request, call_next):
        return await call_next()

    handler = MiddlewareMixin()
    handler.on_response(test_middleware)
    assert len(handler._future_middleware) == 1
    assert handler._future_middleware[0].name == "test_middleware"
    assert handler._future_middleware[0].attach_to == "response"



# Generated at 2022-06-21 23:18:25.633770
# Unit test for method middleware of class MiddlewareMixin
def test_MiddlewareMixin_middleware():
    # class used to test
    class MiddlewareMixinTest(MiddlewareMixin):
        def __init__(self):
            super().__init__()
        def _apply_middleware(self, middleware: FutureMiddleware):
            pass

    # test case 1: when middleware is a function
    # function to be passed to middleware
    def middleware_test(request, hahah=None):
        pass

    middleware_mixin_instance = MiddlewareMixinTest()
    middleware_mixin_instance.middleware(middleware_test)

    assert len(middleware_mixin_instance._future_middleware) == 1
    assert middleware_mixin_instance._future_middleware[0].attach_to == "request"
    assert middleware_mixin_instance._future_middleware[0].middleware

# Generated at 2022-06-21 23:18:28.846039
# Unit test for method on_response of class MiddlewareMixin
def test_MiddlewareMixin_on_response():
    foo = MiddlewareMixin()
    x = foo.on_response(middleware=None)



# Generated at 2022-06-21 23:18:33.032187
# Unit test for constructor of class MiddlewareMixin
def test_MiddlewareMixin():
    # Confirm that MiddlewareMixin class can be constructed
    try:
        mixin = MiddlewareMixin()
        assert mixin is not None
    except Exception as ex:
        assert False, "constructor of class MiddlewareMixin threw exception: " + str(ex)
