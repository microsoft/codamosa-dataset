

# Generated at 2022-06-26 00:05:50.666310
# Unit test for method concat of class Min
def test_Min_concat():
    int_0 = 2357
    int_1 = 2760
    min_0 = Min(int_0)
    min_1 = Min(int_1)
    res = min_0.concat(min_1)
    assert res.value == int_0


# Generated at 2022-06-26 00:05:59.956020
# Unit test for method concat of class Map
def test_Map_concat():
    # set up
    # Test 1
    map_1_1 = Map({'a': Sum(3), 'b': All(True)})
    map_1_2 = Map({'a': Sum(4), 'b': All(False)})
    expected_result_1 = Map({'a': Sum(7), 'b': All(False)})
    # Test 2
    map_2_1 = Map({'a': Sum(3), 'b': All(True), 'c': Sum(1), 'd': All(False)})
    map_2_2 = Map({'a': Sum(4), 'b': All(False)})
    expected_result_2 = Map({'a': Sum(7), 'b': All(False), 'c': Sum(1), 'd': All(False)})
    # Test 3
   

# Generated at 2022-06-26 00:06:02.631511
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(7)
    b = Min(4)
    assert str(a) == 'Min[value=7]'
    assert str(b) == 'Min[value=4]'
    assert a.concat(b).value == min([a.value, b.value])


# Generated at 2022-06-26 00:06:06.605944
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map({1: First(1), 2: First(2)})
    map2 = Map({1: First(3), 2: First(4)})
    map3 = Map({1: First(5), 2: First(6)})
    map1.concat(map2)
    map1.concat(map3)

# Generated at 2022-06-26 00:06:11.248007
# Unit test for method concat of class Min
def test_Min_concat():
    int_0 = 12
    int_1 = 10
    min_0 = Min(int_0)
    min_1 = Min(int_1)
    actual_0 = min_0.concat(min_1)
    assert isinstance(actual_0, Min)
    assert actual_0.value == 10


# Generated at 2022-06-26 00:06:20.795306
# Unit test for method concat of class Map
def test_Map_concat():
    # test that Map concat return Map
    map1 = Map({
        'foo': Max(1),
        'bar': Max(2),
    })
    map2 = Map({
        'foo': Max(3),
        'bar': Max(4),
    })
    assert isinstance(
        map1.concat(map2),
        Map
    )
    # test that Map concat return Map with all values
    map3 = Map({
        'foo': Max(1),
        'bar': Max(2),
        'baz': Max(3)
    })
    assert map3.concat(map2) == Map({
        'foo': Max(3),
        'bar': Max(4),
        'baz': Max(3)
    })



# Generated at 2022-06-26 00:06:31.217345
# Unit test for method concat of class Min
def test_Min_concat():
    int_0 = 2
    int_1 = 2
    min_0 = Min(int_0)
    min_1 = Min(int_1)
    assert min_0.concat(min_1) == Min(2)
    assert min_0.concat(min_1).concat(min_1) == Min(2)
    int_0 = 2
    int_1 = 1
    min_0 = Min(int_0)
    min_1 = Min(int_1)
    assert min_0.concat(min_1) == Min(1)
    assert min_0.concat(min_1).concat(min_1) == Min(1)


# Generated at 2022-06-26 00:06:39.246869
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = 0
    Min_0 = Min(int_0)
    Max_0 = Max(int_0)

    # max_0 = Max_0.concat(Min_0)
    assert Max_0.concat(Min_0) == Max(0)
    assert Min_0.concat(Max_0) == Min(0)

    Max_1 = Max(1)
    Min_1 = Min(1)

    assert Max_1.concat(Min_1) == Max(1)
    assert Min_1.concat(Max_1) == Min(1)

if __name__ == '__main__':
    test_Max_concat()

# Generated at 2022-06-26 00:06:45.178311
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(1)
    b = Min(2)
    c = Min(3)

    assert(Min(1).concat(Min(2)) == Min(1))
    assert(Min(2).concat(Min(1)) == Min(1))
    assert(Min(3).concat(Min(2)) == Min(2))
    assert(Min(2).concat(Min(2)) == Min(2))


# Generated at 2022-06-26 00:06:53.439385
# Unit test for method concat of class Map
def test_Map_concat():
    reduce_0 = lambda x, y: x.concat(y).value
    Map_0 = Map({'a': All(True), 'b': All(False)})
    Map_1 = Map({'a': All(False), 'b': All(True)})
    Map_2 = Map_0.concat(Map_1)
    Map_3 = reduce_0(Map_0, Map_1)
    Map_3_result = Map({'a': All(False), 'b': All(False)})
    assert Map_2 == Map_3_result
    assert Map_3 == Map_3_result


# Generated at 2022-06-26 00:06:58.201223
# Unit test for constructor of class Max
def test_Max():
    m = Max(3)
    assert m.value == 3
    assert m.neutral_element == -float("inf")


# Generated at 2022-06-26 00:07:01.908447
# Unit test for constructor of class Map
def test_Map():
    map = Map({'a': First([1, 2, 3]), 'b': Last([4, 5, 6])})
    assert map.value['a'].value[0] == 1
    assert map.value['b'].value[-1] == 6


# Generated at 2022-06-26 00:07:06.758729
# Unit test for constructor of class Max
def test_Max():
    int_0 = 2357
    max_0 = Max(int_0)
    int_1 = max_0.value
    assert int_1 == int_0
    int_0 = 1
    int_1 = 0
    max_0 = Max(int_0)
    max_2 = max_0.concat(max_0)
    int_3 = max_0.value

# Generated at 2022-06-26 00:07:07.497175
# Unit test for constructor of class Min
def test_Min():
    obj_Min = Min(11)
    assert obj_Min.value == 11


# Generated at 2022-06-26 00:07:09.527873
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    int_0 = 2357
    sum_0 = Sum(int_0)
    assert str(sum_0) == 'Sum[value=2357]'


# Generated at 2022-06-26 00:07:13.280877
# Unit test for method concat of class Sum
def test_Sum_concat():
    int_0 = 2357
    int_1 = -2357
    int_2 = 0
    sum_0 = Sum(int_0)
    sum_1 = Sum(int_1)
    sum_2 = Sum(int_2)
    sum_0_concated_with_sum_1 = sum_0.concat(sum_1)
    assert sum_0_concated_with_sum_1 == sum_2


# Generated at 2022-06-26 00:07:15.498248
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert First(1).fold(lambda n: n+2) == 3
    assert (Last(1).fold(lambda n: n+2)) == 3


# Generated at 2022-06-26 00:07:20.098060
# Unit test for method __str__ of class Map
def test_Map___str__():
    int_0 = -87294
    map_0 = Map({int_0: int_0})
    str_0 = str(map_0)


# Generated at 2022-06-26 00:07:24.624976
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = 2357
    int_1 = 3
    int_2 = 560

    max_0 = Max(int_0)
    max_1 = Max(int_1)
    max_2 = Max(int_2)

    assert (max_1.concat(max_2).concat(max_0)) == Max(560)


# Generated at 2022-06-26 00:07:28.812218
# Unit test for constructor of class One
def test_One():
    """
    Test case for One class constructor.
    """
    int_0 = 1234
    one_0 = One(int_0)
    one_1 = One(None)
    assert one_0.value == int_0
    assert one_1.value == False


# Generated at 2022-06-26 00:07:39.696905
# Unit test for method concat of class Min
def test_Min_concat():
    int_0 = 2357
    int_1 = 1234
    int_2 = 2845
    int_3 = 1265
    int_4 = 2145
    int_5 = 2265
    int_6 = 2155
    min_0 = Min(int_0)
    min_1 = Min(int_1)
    min_2 = Min(int_2)
    min_3 = Min(int_3)
    min_4 = Min(int_4)
    min_5 = Min(int_5)
    min_6 = Min(int_6)
    min_7 = min_3.concat(min_0)
    min_8 = min_6.concat(min_2)
    min_9 = min_0.concat(min_6)
    min_10 = min_1

# Generated at 2022-06-26 00:07:42.163669
# Unit test for method concat of class First
def test_First_concat():
    semantic_0 = First('first')
    semantic_1 = semantic_0.concat(First('second'))
    assert semantic_1 == First('first')


# Generated at 2022-06-26 00:07:44.216444
# Unit test for constructor of class Last
def test_Last():
    int_0 = 2357
    last_0 = Last(int_0)
    assert last_0.value == int_0


# Generated at 2022-06-26 00:07:45.907030
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(0) == Sum(0)
    assert Sum(1) == Sum(1)


# Generated at 2022-06-26 00:07:47.215496
# Unit test for constructor of class One
def test_One():
    int_0 = 2357
    one_0 = One(int_0)


# Generated at 2022-06-26 00:07:51.343473
# Unit test for method __str__ of class Last
def test_Last___str__():
    int_0 = -2844
    last_0 = Last(int_0)
    assert last_0.__str__() == 'Last[value=-2844]'



# Generated at 2022-06-26 00:07:57.280683
# Unit test for constructor of class All
def test_All():
    assert All(0) == All(0)
    assert All(0) != All(1)
    assert All(0).value == 0
    assert All(1).value == 1


# Generated at 2022-06-26 00:08:01.590820
# Unit test for method concat of class Sum
def test_Sum_concat():
    int_0 = 1
    int_1 = 1
    sum_0 = Sum(int_0)
    sum_1 = Sum(int_1)
    sum_2 = sum_0.concat(sum_1)
    assert sum_2 == Sum(int_0 + int_1)



# Generated at 2022-06-26 00:08:05.880966
# Unit test for method __str__ of class Map
def test_Map___str__():
    int_0 = 2357
    map_0 = Map({int_0: Map({int_0: Map({int_0: Map({})})})})
    assert map_0.__str__() == 'Map[value={2357: Map[value={2357: Map[value={2357: Map[value={}]}]}]}]'


# Generated at 2022-06-26 00:08:07.066861
# Unit test for constructor of class Last
def test_Last():
    last = Last('foo')
    assert last.value == 'foo'



# Generated at 2022-06-26 00:08:13.217139
# Unit test for method concat of class Last
def test_Last_concat():
    int_0 = 2357
    last_0 = Last(int_0)

    int_1 = -1790
    last_1 = Last(int_1)

    last_1.concat(last_0)

    pass


# Generated at 2022-06-26 00:08:22.652972
# Unit test for constructor of class First
def test_First():
    int_0 = 2357
    first_0 = First(int_0)
    msg = "Expected {}, but got {}".format(True, type(first_0) == First)
    assert type(first_0) == First, msg

    string_0 = "QWERTY"
    first_1 = First(string_0)
    msg = "Expected {}, but got {}".format(True, type(first_1) == First)
    assert type(first_1) == First, msg

    float_0 = float("inf")
    first_2 = First(float_0)
    msg = "Expected {}, but got {}".format(True, type(first_2) == First)
    assert type(first_2) == First, msg

    list_0 = []

# Generated at 2022-06-26 00:08:26.598339
# Unit test for constructor of class Map
def test_Map():
    int_0 = 2357
    map_0 = Map({'a': First(int_0), 'b': All(int_0), 'c': Last(int_0)})
    assert (map_0 == Map({'a': First(int_0), 'b': All(int_0), 'c': Last(int_0)}))



# Generated at 2022-06-26 00:08:30.461079
# Unit test for method concat of class One
def test_One_concat():

    int_0 = 2357
    int_1 = 2358
    one_0 = One(int_0)
    one_1 = One(int_1)

    one_2 = one_0.concat(one_1)
    assert_that(one_2.value).is_equal_to(True)
    one_3 = one_1.concat(one_0)
    assert_that(one_3.value).is_equal_to(True)



# Generated at 2022-06-26 00:08:32.403136
# Unit test for constructor of class One
def test_One():
    int_0 = 2357
    one_0 = One(int_0)
    assert one_0.value == int_0


# Generated at 2022-06-26 00:08:35.032807
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert Last(2).__str__() == 'Last[value=2]'


# Generated at 2022-06-26 00:08:38.650207
# Unit test for method concat of class First
def test_First_concat():
    int_0 = 50
    int_1 = 3
    first_0 = First(int_0)
    first_1 = First(int_1)
    first_2 = first_0.concat(first_1)
    assert first_0 == first_2


# Generated at 2022-06-26 00:08:41.181820
# Unit test for method __str__ of class All
def test_All___str__():
    int_0 = 2357
    all_0 = All(int_0)
    expected_value = 'All[value=2357]'
    assert str(all_0) == expected_value



# Generated at 2022-06-26 00:08:44.217691
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': First(1), 'b': First(2)})) == "Map[value={'a': Fist[value=1], 'b': Fist[value=2]}]"


# Generated at 2022-06-26 00:08:51.737141
# Unit test for constructor of class Sum
def test_Sum():
    int_0 = 12
    int_1 = 34
    int_2 = 56
    int_3 = 78
    sum_0 = Sum(int_0)
    sum_1 = Sum(int_1)
    sum_2 = Sum(int_2)
    sum_3 = Sum(int_3)
    assert int_0 == sum_0.value
    assert int_1 == sum_1.value
    assert int_2 == sum_2.value
    assert int_3 == sum_3.value
    assert sum_0.neutral().value == 0
    assert sum_1.neutral().value == 0
    assert sum_2.neutral().value == 0
    assert sum_3.neutral().value == 0


# Generated at 2022-06-26 00:08:58.595904
# Unit test for method __str__ of class Map
def test_Map___str__():
    obj = Map({"a": Sum(1), "b": All(True)})
    method_return_val = obj.__str__()
    str_return_val = "Map[value={'a': Sum[value=1], 'b': All[value=True]}]"
    assert method_return_val == str_return_val



# Generated at 2022-06-26 00:09:03.219501
# Unit test for method concat of class Min
def test_Min_concat():
    int_0 = 2357
    int_1 = 1234
    min_0 = Min(int_0)
    min_1 = Min(int_1)

    min_2 = min_0.concat(min_1)

    assert min_2.value == int_1, "Min.concat should return new Min with value of min_1"


# Generated at 2022-06-26 00:09:05.759194
# Unit test for method __str__ of class Map
def test_Map___str__():
    map_0 = {'key': 'value'}
    map_1 = Map(map_0)

    assert str(map_1) == "Map[value={'key': 'value'}]"


# Generated at 2022-06-26 00:09:09.797123
# Unit test for constructor of class Sum
def test_Sum():
    int_0 = 9
    sum_0 = Sum(int_0)
    assert sum_0==Sum(int_0)
    assert sum_0.value==int_0
    assert sum_0.fold(lambda x: x) == int_0
    assert sum_0.fold(lambda x: x) == 9


# Generated at 2022-06-26 00:09:17.067578
# Unit test for method __str__ of class Map
def test_Map___str__():
    all_0 = All(True)
    all_1 = All(False)
    assert str(all_0) == "All[value=True]"
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"
    assert str(All.neutral().concat(All.neutral())) == "All[value=True]"
    assert all_0 == All(True)
    assert all_0 != All(False)
    assert not all_0 != All(True)
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(True)) == All(False)



# Generated at 2022-06-26 00:09:19.335424
# Unit test for constructor of class Semigroup
def test_Semigroup():
    int_0 = 2357
    all_0 = All(int_0)

    # Case 0:
    assert all_0.value == int_0



# Generated at 2022-06-26 00:09:23.666825
# Unit test for method concat of class First
def test_First_concat():
    int_0 = 2357
    map_0 = First(int_0)
    int_1 = -260
    first_0 = First(int_1)
    first_1 = map_0.concat(first_0)
    result_property_0 = first_1.fold()
    assert  (result_property_0 == int_0)


# Generated at 2022-06-26 00:09:32.995130
# Unit test for constructor of class Sum
def test_Sum():
    int_0 = 2357
    int_1 = -2357
    int_2 = 0
    sum_int_0 = Sum(int_0)
    sum_int_1 = Sum(int_1)
    sum_int_2 = Sum(int_2)
    assert sum_int_0.concat(sum_int_1).value == 0

    float_0 = -2357.0
    float_1 = 2357.2357
    float_2 = -0.0
    sum_float_0 = Sum(float_0)
    sum_float_1 = Sum(float_1)
    sum_float_2 = Sum(float_2)
    assert sum_float_0.concat(sum_float_1).value == 2357.2357


# Generated at 2022-06-26 00:09:34.501791
# Unit test for constructor of class Semigroup
def test_Semigroup():
    str_0 = "qwerty"
    assert Semigroup(str_0).value == str_0


# Generated at 2022-06-26 00:09:36.671785
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert Max(0).__str__() == "Max[value=0]"
    assert Max(1).__str__() == "Max[value=1]"


# Generated at 2022-06-26 00:09:47.367916
# Unit test for constructor of class Semigroup
def test_Semigroup():
    int_0 = 2357
    str_0 = "The quick brown fox jumps over the lazy dog"
    float_0 = 7.8987
    one_0 = One(True)
    all_0 = All(int_0)
    one_1 = One(False)
    first_0 = First(str_0)
    last_0 = Last(float_0)
    sum_0 = Sum(5)
    sum_1 = Sum(6)
    sum_2 = sum_0.concat(sum_1)
    map_0 = Map({'key_0': sum_0, 'key_1': sum_1})
    map_1 = Map({'key_0': sum_2, 'key_1': sum_1})
    map_2 = map_0.concat(map_1)
    map

# Generated at 2022-06-26 00:09:50.056983
# Unit test for constructor of class First
def test_First():
    """
    >>> test_First()
    'First[value=2]'
    """
    int_0 = 2
    first_0 = First(int_0)
    return str(first_0)


# Generated at 2022-06-26 00:09:53.529637
# Unit test for method concat of class Sum
def test_Sum_concat():
    int_1 = 1

    # Test add 2 int value
    sum_0 = Sum(int_1)
    sum_1 = Sum(0)
    sum_res = sum_0.concat(sum_1)
    assert sum_res == Sum(1)



# Generated at 2022-06-26 00:09:56.832678
# Unit test for method __str__ of class Map
def test_Map___str__():
    int_0 = 14
    map_0 = Map({'key': First(int_0)})
    print('map_0.__str__() = ' + str(map_0.__str__()))



# Generated at 2022-06-26 00:10:03.541256
# Unit test for method concat of class One
def test_One_concat():
    int_0 = 2357
    one_0 = One(int_0)
    int_1 = 9262
    one_1 = One(int_1)
    one_2 = one_0.concat(one_1)
    assert one_2.value == one_0.value or one_2.value == one_1.value
    int_2 = 1891
    one_3 = one_1.concat(One(int_2))
    assert one_3.value == one_1.value or one_3.value == int_2
    int_3 = 3175
    one_4 = one_3.concat(One(int_3))
    assert one_4.value == one_3.value or one_4.value == int_3
    str_0 = "bTEZWD"
    one

# Generated at 2022-06-26 00:10:06.494632
# Unit test for constructor of class Semigroup
def test_Semigroup():
    int_0 = 2357
    assert Semigroup(int_0).value == int_0

    str_0 = "2357"
    assert Semigroup(str_0).value == str_0


# Generated at 2022-06-26 00:10:08.013558
# Unit test for method __str__ of class Min
def test_Min___str__():
    actual = str(Min(1))
    assert actual == 'Min[value=1]'



# Generated at 2022-06-26 00:10:10.027522
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    int_0 = 2357
    sum_0 = Sum(int_0)
    str_0 = str(sum_0)


# Generated at 2022-06-26 00:10:16.609081
# Unit test for method concat of class Map
def test_Map_concat():
    test_case_0()
    map_0 = Map({'key_1': All(1), 'key_2': All(2)})
    map_1 = Map({'key_1': All(3), 'key_2': All(4)})
    map_2 = map_0.concat(map_1)
    assert map_2.value['key_1'].value == 1 and map_2.value['key_2'].value == 2


# Generated at 2022-06-26 00:10:18.179548
# Unit test for constructor of class Semigroup
def test_Semigroup():
    int_0 = 2357
    all_0 = All(int_0)
    test_case_0()



# Generated at 2022-06-26 00:10:23.627756
# Unit test for constructor of class First
def test_First():
    int_0 = 2357
    first_0 = First(int_0)
    # expected_0: instance that represents unit test passed
    expected_0 = First(2357)
    # actual_0: instance that represents actual result from function being tested
    actual_0 = first_0
    # Test if 2 instances are equal
    assert actual_0 == expected_0


# Generated at 2022-06-26 00:10:26.774044
# Unit test for method __str__ of class One
def test_One___str__():
    value = False
    semigroup = First(value)
    actual = str(semigroup)
    expected = 'One[value={}]'.format(value)
    assert_equal(expected, actual)


# Generated at 2022-06-26 00:10:29.409444
# Unit test for method __str__ of class First
def test_First___str__():
    int_0 = -1570
    first_0 = First(int_0)
    assert first_0.__str__() == "Fist[value=-1570]"


# Generated at 2022-06-26 00:10:38.956050
# Unit test for method concat of class Min
def test_Min_concat():
        class_Min_concat_test_0 = Min(3)
        class_Min_concat_test_1 = Min(7)
        class_Min_concat_test_2 = Min(-5)
        class_Min_concat_test_3 = Min(3)
        class_Min_concat_test_4 = Min(-5)
        assert Min.neutral().concat(class_Min_concat_test_0).value == 3
        assert Min.neutral().concat(class_Min_concat_test_1).value == 7
        assert Min.neutral().concat(class_Min_concat_test_2).value == -5
        assert class_Min_concat_test_3.concat(class_Min_concat_test_4).value == -5



# Generated at 2022-06-26 00:10:40.984039
# Unit test for constructor of class Min
def test_Min():
    int_0 = 2357
    min_0 = Min(int_0)
    assert min_0.value == int_0
    
# Unit tests for methods of class Min

# Generated at 2022-06-26 00:10:45.375724
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    expected_0 = "Sum[value=3]"
    sum_0 = Sum(3)
    actual_0 = str(sum_0)
    assert actual_0 == expected_0, "Expected {0}, but got {1}".format(expected_0, actual_0)


# Generated at 2022-06-26 00:10:49.885663
# Unit test for method __str__ of class Map
def test_Map___str__():
    map_0 = {'acb': One(True), 'bca': All(False)}
    map_1 = Map(map_0)
    
    expected = 'Map[value={\'acb\': One[value=True], \'bca\': All[value=False]}]'
    actual = str(map_1)
    
    assert expected == actual

# Generated at 2022-06-26 00:10:54.496869
# Unit test for method __str__ of class First
def test_First___str__():
    int_0 = 2357
    first_0 = First(int_0)
    first_1 = First(int_0)
    str_0 = str(first_0)
    first_0 = first_1


# Generated at 2022-06-26 00:10:59.690490
# Unit test for method concat of class Last
def test_Last_concat():
    last_0 = Last('abc')
    last_1 = Last('xyz')
    result = last_0.concat(last_1)
    assert (type(result) == Last, 'Expected type should be "Last"')
    assert (result == last_1, 'Expected result should be "last_1"')



# Generated at 2022-06-26 00:11:02.716976
# Unit test for constructor of class Sum
def test_Sum():
    int_1 = 4567
    sum_0 = Sum(int_1)
    assert(sum_0.value) == int_1
    assert(sum_0.neutral_element) == 0

# Test to concat two Sum instances

# Generated at 2022-06-26 00:11:09.012292
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = 861
    max_0 = Max(int_0)
    int_1 = 2788
    max_1 = Max(int_1)
    max_0.concat(max_1)


# Generated at 2022-06-26 00:11:19.618635
# Unit test for method concat of class Map
def test_Map_concat():
    int_0 = 2357
    list_0 = [int_0, int_0, int_0]
    map_0 = Map(
        {
            'key_0': Sum(list_0[0]),
            'key_1': Sum(list_0[1]),
            'key_2': Sum(list_0[2]),
        }
    )
    map_1 = Map(
        {
            'key_0': Sum(list_0[0]),
            'key_1': Sum(list_0[1]),
            'key_2': Sum(list_0[2]),
        }
    )
    map_2 = map_0.concat(map_1)
    assert map_2.value[
        'key_0'
    ].value == list_0[0] * 2 and map_

# Generated at 2022-06-26 00:11:22.579409
# Unit test for method __str__ of class One
def test_One___str__():
    int_0 = 2
    one_0 = One(int_0)
    assert str(one_0) == 'One[value={}]'.format(int_0)


# Generated at 2022-06-26 00:11:24.377845
# Unit test for method concat of class Min
def test_Min_concat():
    int_0 = 0
    int_1 = 1
    min_0 = Min(int_0)
    min_1 = Min(int_1)
    min_2 = min_0.concat(min_1)



# Generated at 2022-06-26 00:11:26.286615
# Unit test for method __str__ of class Max
def test_Max___str__():
    int_0 = 2
    max_0 = Max(int_0)
    str_0 = max_0.__str__()
    assert str_0 == 'Max[value=2]'


# Generated at 2022-06-26 00:11:29.455474
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    int_0 = 2357
    all_0 = All(int_0)
    result = all_0.fold(lambda x: x)
    assert result == all_0.value



# Generated at 2022-06-26 00:11:30.330792
# Unit test for constructor of class Max
def test_Max():
    assert Max(4).value == 4


# Generated at 2022-06-26 00:11:31.154110
# Unit test for constructor of class First
def test_First():
    First(0)


# Generated at 2022-06-26 00:11:40.919904
# Unit test for constructor of class Min
def test_Min():
    int_0 = 2357
    min_0 = Min(int_0)
    min_1 = Min(0)
    min_2 = Min(1)
    min_3 = Min(0)
    min_4 = Min(1)
    min_5 = Min(0)
    min_6 = Min(1)
    min_7 = Min(0)
    min_8 = Min(1)
    min_9 = Min(0)
    min_10 = Min(1)
    min_11 = Min(0)
    min_12 = Min(1)
    min_13 = Min(0)
    min_14 = Min(1)
    min_15 = Min(0)
    min_16 = Min(1)
    min_17 = Min(0)
    min_18 = Min(1)

# Generated at 2022-06-26 00:11:42.601835
# Unit test for constructor of class First
def test_First():
    int_0 = 2357
    first_0 = First(int_0)
    assert first_0.value == 2357


# Generated at 2022-06-26 00:11:49.259297
# Unit test for method concat of class First
def test_First_concat():
    """
    testing method concat for class First
    """
    int_0 = 2357
    first_0 = First(int_0)
    int_1 = 7352
    first_1 = First(int_1)

    result = first_0.concat(first_1)
    assert(result.value == int_0)


# Generated at 2022-06-26 00:11:53.923965
# Unit test for method __str__ of class Min
def test_Min___str__():
    int_0 = 3000
    min_0 = Min(int_0)
    min_1 = Min(int_0)
    result = min_0.__str__()
    assert result == 'Min[value=3000]'
    result = min_1.__str__()
    assert result == 'Min[value=3000]'


# Generated at 2022-06-26 00:12:04.936104
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    int_0 = 2357
    int_1 = 2861
    int_2 = 2761
    int_3 = 2260
    int_4 = 2358
    int_5 = 2359
    int_6 = 2459
    int_7 = 2160
    int_8 = 2160
    int_list_0 = [int_0, int_1, int_2, int_3, int_4, int_5, int_6, int_7, int_8]
    sum_0 = Sum(int_list_0[0]).fold(lambda s: sum(s))
    sum_1 = Sum(int_list_0[1]).fold(lambda s: sum(s))
    sum_2 = Sum(int_list_0[2]).fold(lambda s: sum(s))

# Generated at 2022-06-26 00:12:10.029783
# Unit test for method __str__ of class One
def test_One___str__():
    one_0 = One(25)
    one_1 = One(643)
    assert one_0.__str__() == "One[value=25]"
    assert one_1.__str__() == "One[value=643]"

# Generated at 2022-06-26 00:12:12.551011
# Unit test for constructor of class First
def test_First():
    first_0 = First(1)
    first_1 = First(2)
    assert first_0.concat(first_1) == First(1)
    assert first_1.concat(first_0) == First(2)


# Generated at 2022-06-26 00:12:17.607995
# Unit test for constructor of class Min
def test_Min():
    int_0 = 2357
    min_0 = Min(int_0)
    min_1 = Min(int_0)
    min_0.concat(min_1)
    min_0_key = min(int_0)
    min_0_value = min(int_0)
    assert min_0.value == min_0_value

# Generated at 2022-06-26 00:12:19.146544
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    a = All(True)
    b = All(True)
    assert a == b



# Generated at 2022-06-26 00:12:21.977806
# Unit test for method __str__ of class Last
def test_Last___str__():
    int_0 = 4200
    obj_0 = Last(int_0)
    assert isinstance(obj_0.__str__(), str)
    assert obj_0.__str__() == "Last[value=4200]"


# Generated at 2022-06-26 00:12:26.730492
# Unit test for method concat of class First
def test_First_concat():
    value_0 = 2357
    f0 = First(value_0)

    value_1 = 1234
    f1 = First(value_1)

    result_f0 = f0.concat(f1)
    assert isinstance(result_f0, First)
    assert result_f0.value == value_0



# Generated at 2022-06-26 00:12:28.915217
# Unit test for method __str__ of class Last
def test_Last___str__():
    int_0 = 2483
    last_0 = Last(int_0)
    assert str(last_0) == 'Last[value=2483]'


# Generated at 2022-06-26 00:12:35.101039
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({"foo": Sum(23), "bar": Sum(42)})) == 'Map[value={"foo": Sum[value=23], "bar": Sum[value=42]}]'


# Generated at 2022-06-26 00:12:39.532563
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    int_0 = 2357
    all_0 = All(int_0)
    t_0 = all_0.fold(lambda x: x * x * x * x * x * x * x * x * x * x * x * x * x * x * x * x * x * x * x * x * x * x * x * x * x * x * x)
    assert t_0 == int_0 ** 30


# Generated at 2022-06-26 00:12:50.145236
# Unit test for method concat of class First
def test_First_concat():
    print("Method concat of class First:")
    test_case_0()
    int_1 = 13
    str_1 = "string"
    int_2 = 5
    str_2 = "another string"
    first_1 = First(int_1)
    concat_1 = first_1.concat(First(str_1))
    assert concat_1.value == int_1, "Value: " + str(concat_1.value)
    print("\tThe value " + str(concat_1.value) + " has been assigned correctly")
    first_2 = First(str_1)
    concat_2 = first_2.concat(First(str_2))
    assert concat_2.value == str_1, "Value: " + str(concat_2.value)


# Generated at 2022-06-26 00:12:54.611004
# Unit test for method concat of class Map
def test_Map_concat():
    this = Map({'first': Sum(1), 'second': Sum(2)})
    other = Map({'first': Sum(10), 'second': Sum(20)})
    new_m = Map({'first': Sum(11), 'second': Sum(22)})

    assert this.concat(other) == new_m


# Generated at 2022-06-26 00:12:55.829065
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-26 00:13:03.932688
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) == Semigroup(1.0)
    assert Semigroup(1) == Semigroup('1')
    assert Semigroup('1') == Semigroup('1')
    assert Semigroup('1') == Semigroup(1)
    assert Semigroup(1.1) == Semigroup('1.1')
    assert Semigroup(1.0) == Semigroup('1')
    assert Semigroup(1) == Semigroup(True)
    assert Semigroup(False) == Semigroup(True)
    assert Semigroup(True) == Semigroup(1)
    assert Semigroup('True') == Semigroup(False)
    assert Semigroup('False') == Semigroup('True')
    assert Semigroup((1,)) == Semigroup((1,))

# Generated at 2022-06-26 00:13:05.543537
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"


# Generated at 2022-06-26 00:13:15.640274
# Unit test for method concat of class One
def test_One_concat():
    # Given
    str_0 = 'I'
    str_1 = 'am'
    str_2 = 'truly'
    str_3 = 'only'
    str_4 = 'sometimes'
    str_5 = 'falsy'

    one_0 = One(str_0)
    one_1 = One(str_1)
    one_2 = One(str_2)
    one_3 = One(str_3)
    one_4 = One(str_4)
    one_5 = One(str_5)

    # When
    actual_0 = one_2.concat(one_4)

    # Then
    expected_0 = One(str_2)
    expected_1 = One(str_4)

    assert actual_0 == expected_0
    assert actual_0 != expected

# Generated at 2022-06-26 00:13:17.557452
# Unit test for constructor of class Map
def test_Map():
    m_0 = Map({1: '2'})
    m_0.value == {1: '2'}


# Generated at 2022-06-26 00:13:18.968117
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(4).value == 4
    assert Sum(2).value == 2



# Generated at 2022-06-26 00:13:30.003076
# Unit test for method concat of class One
def test_One_concat():
    int_0 = 848
    int_1 = -1
    one_0 = One(int_0)
    one_1 = one_0.concat(One(int_1))
    assert one_1.value == int_0 or one_1.value == int_1


# Generated at 2022-06-26 00:13:31.855586
# Unit test for method __str__ of class First
def test_First___str__():
    int_0 = 1836
    first_0 = First(int_0)
    print(first_0)


# Generated at 2022-06-26 00:13:34.464455
# Unit test for method concat of class Last
def test_Last_concat():
    value = 423
    last = Last(value)

    value_2 = 789
    last_2 = Last(value_2)

    assert last.concat(last_2) == Last(value_2)



# Generated at 2022-06-26 00:13:36.503862
# Unit test for method concat of class First
def test_First_concat():
    f_0 = First(23)
    f_1 = First(42)
    f_result = f_0.concat(f_1)
    assert f_result == First(23)


# Generated at 2022-06-26 00:13:39.231366
# Unit test for constructor of class First
def test_First():
    int_0 = 2357
    first_0 = First(int_0)
    assert first_0.value == int_0



# Generated at 2022-06-26 00:13:43.821025
# Unit test for method __str__ of class Last
def test_Last___str__():
    int_0 = 728
    last_0 = Last(int_0)

    assert str(last_0) == 'Last[value=728]'


# Generated at 2022-06-26 00:13:49.611751
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    int_0 = 2357
    all_1 = All(int_0)
    all_2 = All(int_0)
    all_3 = All(int_0)

    assert(all_1 == all_2)

    all_1.concat(all_2)
    all_2.concat(all_3)

    assert (all_1 == all_2)


# Generated at 2022-06-26 00:13:52.262930
# Unit test for method __str__ of class One
def test_One___str__():
    int_0 = 4569
    all_0 = One(int_0)
    string_0 = 'One[value={}]'.format(int_0)
    assert all_0.__str__() == string_0


# Generated at 2022-06-26 00:13:59.424687
# Unit test for method concat of class One
def test_One_concat():
    one_0 = One(False)
    one_1 = one_0.concat(one_0)
    assert one_1.value == False, "Assertion failed"

    one_2 = One(True)
    one_3 = one_0.concat(one_2)
    assert one_3.value == True, "Assertion failed"

    one_4 = One(True)
    one_5 = one_2.concat(one_4)
    assert one_5.value == True, "Assertion failed"


# Generated at 2022-06-26 00:14:07.908876
# Unit test for method concat of class All
def test_All_concat():
    all_0 = All(True)
    all_1 = All(False)
    all_2 = All(True)

    result = all_0.concat(all_1)
    assert result.value == False, 'all_0.concat(all_1) result is {}'.format(result)
    assert all_0 != result, 'all_0 == result'

    result = all_0.concat(all_2)
    assert result.value == True, 'all_0.concat(all_2) result is {}'.format(result)
    assert all_0 != result, 'all_0 == result'

    result = all_1.concat(all_0)
    assert result.value == False, 'all_1.concat(all_0) result is {}'.format(result)
    assert all_1

# Generated at 2022-06-26 00:14:18.426399
# Unit test for constructor of class Last
def test_Last():
    # Test 1
    int_0 = 2357
    last_0 = Last(int_0)
    assert last_0.value == 2357


# Generated at 2022-06-26 00:14:19.795145
# Unit test for method concat of class Last
def test_Last_concat():
    last = Last(2)
    assert last.concat(Last(3)) == Last(3)



# Generated at 2022-06-26 00:14:32.205896
# Unit test for method concat of class Map
def test_Map_concat():
    int_1 = 2357
    map_dict = {'a': Sum(int_1), 'b': All(int_1), 'c': First(int_1)}
    map_1 = Map(map_dict)

    int_2 = 12356
    map_dict = {'a': Sum(int_2), 'b': All(int_2), 'c': First(int_2)}
    map_2 = Map(map_dict)

    assert map_1.concat(map_2).value['a'].value == 35813
    assert map_1.concat(map_2).value['b'].value == True
    assert map_1.concat(map_2).value['c'].value == 2357
    assert map_1.concat(map_2).value['d'].value == 0



# Generated at 2022-06-26 00:14:33.532920
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False


# Generated at 2022-06-26 00:14:36.227839
# Unit test for constructor of class One
def test_One():
    int_0 = 2357
    one_0 = One(int_0)
    str_0 = "c"
    one_2 = one_0.concat(One(str_0))
    if isinstance(one_2, One):
        print(True)



# Generated at 2022-06-26 00:14:38.023761
# Unit test for method __str__ of class All
def test_All___str__():
    assert All(True).__str__() == 'All[value=True]'
    assert All(False).__str__() == 'All[value=False]'


# Generated at 2022-06-26 00:14:40.116799
# Unit test for method concat of class First
def test_First_concat():
    int_0 = 2357
    int_1 = 935
    first_0 = First(int_0)
    first_1 = First(int_1)
    first_0.concat(first_1)


# Generated at 2022-06-26 00:14:43.121410
# Unit test for constructor of class All
def test_All():
    assert All(True).fold(bool) == True
    assert All(False).fold(bool) == False


# Generated at 2022-06-26 00:14:53.437417
# Unit test for method concat of class First
def test_First_concat():
    # Test case 1
    int_0 = 2357
    first_0 = First(int_0)
    int_1 = 3486
    first_1 = First(int_1)
    first_2 = first_0.concat(first_1)
    assert int_0 == first_2.value
    # Test case 2
    float_0 = 3.0648965185E9
    first_3 = First(float_0)
    first_4 = first_2.concat(first_2)
    assert int_0 == first_4.value
    # Test case 3
    str_0 = 'jk$H#z_Xl?{l'
    first_5 = First(str_0)
    first_6 = first_3.concat(first_5)
    assert float_0 == first

# Generated at 2022-06-26 00:14:54.451321
# Unit test for constructor of class Map
def test_Map():
    int_0 = 2357
    map_0 = Map({0: int_0})


# Generated at 2022-06-26 00:15:07.939291
# Unit test for constructor of class One
def test_One():
    int_0 = 17
    one_0 = One(int_0)
    one_1 = One(int_0)
    one_2 = One(int_0)
    one_3 = One(int_0)
    one_4 = One(int_0)
    one_5 = One(int_0)
    one_6 = One(int_0)
    one_7 = One(int_0)
    one_8 = One(int_0)


# Generated at 2022-06-26 00:15:09.468296
# Unit test for constructor of class First
def test_First():
    first_0 = First(4)
    print(first_0)
# Result is First with value 4


# Generated at 2022-06-26 00:15:10.787997
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(11).fold(lambda x: x * 2) == 22



# Generated at 2022-06-26 00:15:18.736858
# Unit test for method concat of class First
def test_First_concat():
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4

    first_0 = First(int_0)
    first_1 = First(int_1)
    first_2 = First(int_2)
    first_3 = First(int_3)
    first_4 = First(int_4)

    first_3.concat(first_4)
    first_3.concat(first_2)
    first_3.concat(first_3)
    first_3.concat(first_1)
    first_3.concat(first_0)


# Generated at 2022-06-26 00:15:21.025469
# Unit test for method __str__ of class First
def test_First___str__():
    int_0 = 2357
    first_0 = First(int_0)
    str_0 = str(first_0)
    assert str_0 == 'Fist[value=2357]'


# Generated at 2022-06-26 00:15:22.550799
# Unit test for method __str__ of class All
def test_All___str__():
    result = All(False)
    assert_true(result.__str__() == 'All[value=False]')


# Generated at 2022-06-26 00:15:26.029011
# Unit test for method concat of class Sum
def test_Sum_concat():
    int_0 = 2357
    sum_0 = Sum(int_0)
    int_1 = 7654
    sum_1 = Sum(int_1)
    sum_2 = sum_0.concat(sum_1)
    assert isinstance(sum_2, Sum)
    assert sum_2.value == int_0 + int_1


# Generated at 2022-06-26 00:15:27.956891
# Unit test for method __str__ of class One
def test_One___str__():
    int_0 = 2357
    one_0 = One(int_0)
    assert one_0.__str__() == 'One[value=2357]'


# Generated at 2022-06-26 00:15:31.771805
# Unit test for method __str__ of class Map
def test_Map___str__():
    """
    Test if method __str__ of class Map is working correctly.
    """
    int_0 = 2357
    map_0 = Map({'0': int_0})

    assert str(map_0) == 'Map[value={\'0\': Sum[value=2357]}]'

test_Map___str__()


# Generated at 2022-06-26 00:15:35.041122
# Unit test for method concat of class Last
def test_Last_concat():
    last_0 = Last(None)
    last_1 = Last('x')
    last_2 = last_0.concat(last_1)
    assert last_2.value == 'x', "expected 'x' but got {last_2.value}".format(last_2=last_2)
