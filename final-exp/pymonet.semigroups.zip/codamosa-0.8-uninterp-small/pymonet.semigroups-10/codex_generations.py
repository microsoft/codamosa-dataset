

# Generated at 2022-06-26 00:05:56.374041
# Unit test for method concat of class Max
def test_Max_concat():
    float_0 = -3206.62
    Max_0 = Max(float_0)
    float_1 = -8401.39
    Max_1 = Max(float_1)
    assert Max_0.concat(Max_1).value == float_0

    float_0 = 5143.3
    Max_0 = Max(float_0)
    float_1 = -2.72
    Max_1 = Max(float_1)
    assert Max_0.concat(Max_1).value == float_0

    float_0 = 9690.85
    Max_0 = Max(float_0)
    float_1 = 6367.26
    Max_1 = Max(float_1)
    assert Max_0.concat(Max_1).value == float_0

    float_0 = 6
   

# Generated at 2022-06-26 00:06:00.538633
# Unit test for method concat of class Min
def test_Min_concat():
    float_0 = -3206.62
    min_0 = Min(float_0)
    float_1 = -3206.62
    float_2 = -3206.62
    min_1 = Min(float_1)
    min_2 = min_0.concat(min_1)
    assert_true(min_2.value == float_2)

# Generated at 2022-06-26 00:06:06.614392
# Unit test for method concat of class Map
def test_Map_concat():
    float_0 = -3206.62
    map_0 = Map(float_0)
    max_0 = Max(float_0)
    map_0 = map_0.concat(map_0)
    assert map_0 == Map(float_0)
    map_0 = map_0.concat(map_0)
    assert map_0 == Map(float_0)
    map_0 = map_0.concat(map_0)
    assert map_0 == Map(float_0)
    map_0 = map_0.concat(map_0)
    assert map_0 == Map(float_0)
    map_0 = map_0.concat(map_0)
    assert map_0 == Map(float_0)

# Generated at 2022-06-26 00:06:17.494957
# Unit test for method concat of class Max
def test_Max_concat():
    float_0 = 4.789615318470897
    Max_0 = Max(float_0)
    float_1 = 0.6687456451129152
    Max_1 = Max(float_1)
    float_2 = -0.7988130193933331
    Max_2 = Max(float_2)
    float_3 = -0.5533616704975943
    Max_3 = Max(float_3)
    float_4 = -20.538490126947646
    Max_4 = Max(float_4)
    float_5 = 33.96307401472559
    Max_5 = Max(float_5)
    float_6 = -15.082470892712076
    Max_6 = Max(float_6)

# Generated at 2022-06-26 00:06:24.115448
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1) == Max(1).concat(Max(1).neutral())
    assert Max(5) == Max(1).concat(Max(5))
    assert Max(5) == Max(5).concat(Max(1))
    assert Max(-1) == Max(-1).concat(Max(-1).neutral())
    assert Max(-1) == Max(-1).concat(Max(-5))
    assert Max(-1) == Max(-5).concat(Max(-1))
    assert Max(1) == Max(1).concat(Max(0))
    assert Max(1) == Max(0).concat(Max(1))
    assert Max(0) == Max(0).concat(Max(0))
    assert Max(1) == Max(1).concat(Max(-1))

# Generated at 2022-06-26 00:06:33.994575
# Unit test for method concat of class Max
def test_Max_concat():
    float_1 = -1243.9
    float_2 = -1310.48
    float_3 = -3993.5
    float_4 = 4910.15
    float_5 = 4866.67
    int_1 = 4488
    int_2 = -3987
    int_3 = -4369
    int_4 = -4339
    int_5 = 4682
    map_1 = Map(float_1)
    map_2 = Map(float_2)
    map_3 = Map(float_3)
    map_4 = Map(float_4)
    map_5 = Map(float_5)
    map_6 = Map(int_1)
    map_7 = Map(int_2)
    map_8 = Map(int_3)

# Generated at 2022-06-26 00:06:43.960171
# Unit test for method concat of class Max
def test_Max_concat():
    float_0 = -3206.62
    assert Max(-17.580159542702085).concat(Max(float_0)) == Max(float_0)
    float_1 = -0.0
    assert Max(1.5e-323).concat(Max(float_1)) == Max(float_1)
    assert Max(2.0291501900453085).concat(Max(float_0)) == Max(float_0)
    assert Max(-24748.674867600607).concat(Max(-0.0)) == Max(-0.0)
    assert Max(0.0).concat(Max(-17.580159542702085)) == Max(-17.580159542702085)

# Generated at 2022-06-26 00:06:47.547411
# Unit test for method concat of class Min
def test_Min_concat():
    float_0 = 0.00
    Min_0 = Min(float_0)
    float_1 = -98.94
    Min_1 = Min(float_1)
    Min_2 = Min_0.concat(Min_1)
    print(Min_2)


# Generated at 2022-06-26 00:06:58.436429
# Unit test for method concat of class Map
def test_Map_concat():
    # positive test case
    map_0 = Map({0: Sum(int_0)})
    map_1 = Map({0: Sum(int_1)})
    map_2 = map_0.concat(map_1)
    assert map_2.value[0].value == (int_0 + int_1)

    # positive test case
    map_0 = Map({})
    map_1 = Map({0: Sum(int_1)})
    map_2 = map_0.concat(map_1)
    assert map_2.value[0].value == (int_1)

    # positive test case
    map_0 = Map({0: Sum(int_0)})
    map_1 = Map({})
    map_2 = map_0.concat(map_1)
    assert map_

# Generated at 2022-06-26 00:07:02.844706
# Unit test for method concat of class Max
def test_Max_concat():
    float_0 = -3206.62
    max_0 = Max(float_0)
    float_1 = -3206.62
    max_1 = Max(float_1)
    max_2 = max_0.concat(max_1)
    assert max_2 == Max(-3206.62)


# Generated at 2022-06-26 00:07:08.845079
# Unit test for constructor of class Max
def test_Max():
  max_0 = Max(0)
  assert max_0.value == 0
  max_1 = Max(5)
  assert max_1.value == 5
  max_2 = Max(-3.8)
  assert max_2.value == -3.8


# Generated at 2022-06-26 00:07:10.434189
# Unit test for constructor of class First
def test_First():
    a = First(2)
    assert a == First(2)
    b = First(3)
    c = Last(1)
    assert a.concat(b) == First(2)
    assert a.concat(c) == Last(1)


# Generated at 2022-06-26 00:07:11.866851
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    float_0 = -3206.62
    sum_t = Sum(float_0)
    assert sum_t.__str__() == 'Sum[value=-3206.62]', 'Method Sum.__str__ failed'


# Generated at 2022-06-26 00:07:13.555766
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(5).concat(Sum(6)) == Sum(11)



# Generated at 2022-06-26 00:07:15.894997
# Unit test for method __str__ of class One
def test_One___str__():
    float_0 = 3.0849
    one_0 = One(float_0)
    assert str(one_0) == 'One[value=3.0849]'


# Generated at 2022-06-26 00:07:23.202973
# Unit test for constructor of class Min
def test_Min():
    float_0 = -3206.62
    obj = Min(float_0)
    assert isinstance(obj, Min)



# Generated at 2022-06-26 00:07:25.651971
# Unit test for constructor of class Semigroup
def test_Semigroup():
    float_0 = -3206.62
    map_0 = Map(float_0)
    assert map_0.value == float_0, "Wrong Object Map"


# Generated at 2022-06-26 00:07:31.130749
# Unit test for method concat of class Max
def test_Max_concat():
    float_1 = -3206.62
    float_2 = -1465.17
    max_1 = Max(float_1)
    max_2 = Max(float_2)
    max_3 = max_1.concat(max_2)

    assert_true(max_3.value == -1465.17, 'Assertion error: concat')


# Generated at 2022-06-26 00:07:35.200286
# Unit test for method __str__ of class First
def test_First___str__():
    float_0 = -3206.62
    first_0 = First(float_0)
    str_0 = 'Fist[value=-3206.62]'
    assert str_0 == first_0.__str__()



# Generated at 2022-06-26 00:07:37.236047
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True) != All(False)


# Generated at 2022-06-26 00:07:44.216712
# Unit test for constructor of class Semigroup
def test_Semigroup():
    for i in range(100):
        int_0 = rnd_int16()
        float_0 = rnd_float64()
        str_0 = rnd_str()
        semigroup_0 = Semigroup(int_0)
        semigroup_0 = Semigroup(float_0)
        semigroup_0 = Semigroup(str_0)

# Generated at 2022-06-26 00:07:55.214431
# Unit test for method concat of class Map
def test_Map_concat():
    float_0 = -3206.62
    map_0 = Map(float_0)
    map_1 = Map({map_0: Last(map_0.value)})
    map_2 = Map({map_1: Last(map_1.value)})
    map_3 = Map({map_2: Last(map_2.value)})
    map_4 = Map({map_3: Last(map_3.value)})
    map_5 = Map({map_4: Last(map_4.value)})
    map_6 = Map({map_5: Last(map_5.value)})
    map_7 = Map({map_6: Last(map_6.value)})
    map_8 = Map({map_7: Last(map_7.value)})

# Generated at 2022-06-26 00:07:58.257286
# Unit test for constructor of class First
def test_First():
    def test_case_0():
        string_0 = "abc"
        first = First(string_0)

    test_case_0()



# Generated at 2022-06-26 00:07:59.756720
# Unit test for constructor of class Min
def test_Min():
    assert type(Min(2.2)) == Min



# Generated at 2022-06-26 00:08:02.460593
# Unit test for method __str__ of class One
def test_One___str__():
    float_0 = -3206.62
    one_0 = One(float_0)
    assert str(one_0) == 'One[value=-3206.62]'



# Generated at 2022-06-26 00:08:11.634915
# Unit test for method __str__ of class All
def test_All___str__():
    float_0 = -3206.62
    all_0 = All(float_0)
    str_0 = all_0.__str__()
    assert str_0 == "All[value=-3206.62]"
    float_0 = -1934.05
    all_0 = All(float_0)
    str_0 = all_0.__str__()
    assert str_0 == "All[value=-1934.05]"
    float_0 = -6228.66
    all_0 = All(float_0)
    str_0 = all_0.__str__()
    assert str_0 == "All[value=-6228.66]"
    float_0 = -2865.7
    all_0 = All(float_0)
    str_0 = all_0.__str__()


# Generated at 2022-06-26 00:08:15.921842
# Unit test for method concat of class Min
def test_Min_concat():
    semigroup_0 = Min(677)
    float_0 = 10.0
    semigroup_1 = Min(float_0)
    float_1 = float_0
    assert float_1 == float_1
    semigroup_0.concat(semigroup_1)


# Generated at 2022-06-26 00:08:17.649958
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True
    assert One(False).value == False


# Generated at 2022-06-26 00:08:19.670095
# Unit test for constructor of class Sum
def test_Sum():
    float_0 = -3206.62
    sum_0 = Sum(float_0)



# Generated at 2022-06-26 00:08:21.902758
# Unit test for method concat of class One
def test_One_concat():
    unit_test_case_0()
    unit_test_case_1()
    unit_test_case_2()
    unit_test_case_3()


# Generated at 2022-06-26 00:08:28.630665
# Unit test for method __str__ of class All
def test_All___str__():
    float_0 = -213.0
    bool_0 = bool(float_0)
    bool_1 = bool(bool_0)
    bool_2 = bool(bool_0)
    all_0 = All(bool_2)
    str_0 = str(all_0)
    assert str_0 == 'All[value=False]'

# Generated at 2022-06-26 00:08:38.985851
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    float_0 = 4.813450974942571
    list_0 = [float_0, 0.98254579582985, float_0]
    value_0 = Sum.fold(list_0)
    assert value_0 == Sum(Sum(Sum.neutral_element).concat(Sum(float_0)).concat(Sum(0.98254579582985))).concat(
        Sum(float_0))

    float_0 = -0.22635013734161704
    dict_0 = {'2UCaA': All(True), 'x?': First(float_0), '}E{': float_0, 'i': Min(float_0)}
    value_0 = All.fold(dict_0)
    assert value_0 == All(All.neutral_element).concat

# Generated at 2022-06-26 00:08:41.142028
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    float_0 = float("NaN")
    sum_0 = Sum(float_0)
    assert sum_0.__str__() == "Sum[value=nan]"


# Generated at 2022-06-26 00:08:50.120321
# Unit test for constructor of class One
def test_One():
    string_0 = 'S8~'
    float_0 = 476.47
    float_1 = -471.71
    float_2 = -82.69
    float_3 = -972.34
    string_1 = '$\nFk^'
    string_2 = 'aHn3'
    string_3 = '7dZ_I'
    float_4 = 0.0
    float_5 = 875.38
    float_6 = -53.27
    float_7 = 467.46
    float_8 = -949.82
    float_9 = -918.45
    float_10 = -624.86
    float_11 = 356.21
    float_12 = -948.68
    float_13 = 703.3
    float_14 = -337

# Generated at 2022-06-26 00:08:56.406241
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    float_0 = 1.3576314592388946
    float_1 = 9549.966604527198
    float_2 = -3815.8284636989975

    Sum_0 = Sum(float_0)
    Sum_1 = Sum(float_1)
    Sum_2 = Sum(float_2)

    Sum_0.concat(Sum_1)
    Sum_2.concat(Sum_1)
    Sum_2 == Sum_1

# Generated at 2022-06-26 00:09:00.735086
# Unit test for method concat of class All
def test_All_concat():
    bool_0 = All(True)
    bool_1 = All(False)
    bool_2 = bool_0.concat(bool_1)
    bool_3 = bool_1.concat(bool_0)
    assert bool_2 == All(False)
    assert bool_3 == All(False)


# Generated at 2022-06-26 00:09:01.934242
# Unit test for constructor of class Map
def test_Map():
    assert Map(5).value == 5


# Generated at 2022-06-26 00:09:10.590679
# Unit test for method concat of class First
def test_First_concat():
    first_0 = First(True)
    first_1 = last(first_0)
    str_0 = 'First[value=True]'
    bool_0 = str_0 == str(first_1)
    bool_1 = bool_0
    if not bool_1:
        return False
    first_2 = First(False)
    first_3 = last(first_2)
    bool_2 = bool_1
    str_1 = 'First[value=False]'
    bool_3 = str_1 == str(first_3)
    bool_4 = bool_3
    if not bool_4:
        return False
    first_4 = First(False)
    first_5 = Last(True)
    first_6 = first_4.concat(first_5)

# Generated at 2022-06-26 00:09:11.808841
# Unit test for method __str__ of class All
def test_All___str__():
    assert All(True).__str__() == 'All[value=True]'


# Generated at 2022-06-26 00:09:20.514894
# Unit test for method concat of class First
def test_First_concat():
    # Test case 0
    semigroup_0 = First(10.378005632129816)
    semigroup_1 = First(8.438010772180148)
    semigroup_0.concat(semigroup_1)

    # Test case 1
    semigroup_2 = First(22.551035)
    semigroup_3 = First(6.688047128507804)
    semigroup_2.concat(semigroup_3)

    # Test case 2
    semigroup_4 = First(None)
    semigroup_5 = First(12.256658496866792)
    semigroup_4.concat(semigroup_5)

    # Test case 3
    semigroup_6 = First(None)
    semigroup_7 = First(None)
    semigroup_6.con

# Generated at 2022-06-26 00:09:32.768171
# Unit test for constructor of class Semigroup
def test_Semigroup():
    all_0 = All(True)
    assert str(all_0) == 'All[value=True]'
    assert all_0.fold(bool) == True

    all_1 = All(False)
    assert all_1.concat(all_0) == All.neutral()
    assert all_1.fold(bool) == False

    _min = Min(2)
    _max = Max(3)
    assert _min.concat(_max) == _max

    _map = Map({'a': _max})
    assert _map.concat(_map) == Map({'a': _max.concat(_max)})

    first_0 = First(True)
    first_1 = First(False)
    assert first_0.concat(first_1) == first_1

# Generated at 2022-06-26 00:09:35.266484
# Unit test for method concat of class First
def test_First_concat():
    value_a = First(1)
    value_b = First(2)
    value = value_a.concat(value_b)
    expect(value).to_equal(First(1))


# Generated at 2022-06-26 00:09:44.754480
# Unit test for constructor of class First
def test_First():
    float_1 = 1769.70
    float_2 = float("nan")
    float_3 = float("infinity")
    float_4 = float("infinity")
    float_5 = float("-infinity")
    float_6 = float("-infinity")

    # Semigroup<First<float>>
    semigroup_0 = First(float_1)

    # Semigroup<First<float>>
    semigroup_1 = First(float_2)

    # Semigroup<First<float>>
    semigroup_2 = First(float_3)

    # Semigroup<First<float>>
    semigroup_3 = First(float_4)

    # Semigroup<First<float>>
    semigroup_4 = First(float_5)

    # Semigroup<First<float>>

# Generated at 2022-06-26 00:09:49.687201
# Unit test for constructor of class Sum
def test_Sum():
    float_0 = -3206.62
    sum_0 = Sum(float_0)
    float_1 = sum_0.value
    float_2 = float_1 + float_0
    sum_1 = Sum(float_2)
    sum_2 = sum_1.concat(sum_0)
    float_3 = sum_2.value

    assert(float_3 == float_1)


# Generated at 2022-06-26 00:09:52.479489
# Unit test for constructor of class Min
def test_Min():
    min_0 = Min(float("inf"))

    assert min_0.value is float("inf")

    min_0_0 = Min(-float("inf"))

    assert min_0_0.value is -float("inf")



# Generated at 2022-06-26 00:09:55.955355
# Unit test for constructor of class Last
def test_Last():
    test_case_0()
    test_concat_0()
    test_fold_0()
    test_neutral_0()

# Function to test the method concat of class Last

# Generated at 2022-06-26 00:09:57.264883
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    int_0 = -2147483647
    sum_0 = Sum(int_0)
    assert str(sum_0) == "Sum[value=-2147483647]"


# Generated at 2022-06-26 00:10:00.008815
# Unit test for method concat of class All
def test_All_concat():
    for i in range(100):
        # Test that when we concat 2 All values, it will always return All(True)
        all_true = All(True)
        all_true_concat = all_true.concat(all_true)
        assert(all_true_concat.value == True)
    return 'All concat passed.'


# Generated at 2022-06-26 00:10:01.925924
# Unit test for constructor of class Min
def test_Min():
    min_0 = Min(0.0)
    assert str(min_0) == "Min[value=0.0]"

# Generated at 2022-06-26 00:10:05.788828
# Unit test for method __str__ of class Map
def test_Map___str__():
    float_0 = -9864.9
    map_0 = Map({float_0: float_0})
    # Start of user code test__str__0
    assert str(map_0) == "Map[value={-9864.9: -9864.9}]"
    # End of user code test__str__0


# Generated at 2022-06-26 00:10:18.831857
# Unit test for method __str__ of class All
def test_All___str__():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()
    bool_23 = bool()
    bool_24 = bool()

# Generated at 2022-06-26 00:10:21.818486
# Unit test for method __str__ of class Map
def test_Map___str__():
    float_0 = -11.0
    map_0 = Map(float_0)
    str_expected = ("Map[value={}]".format(float_0))
    str_actual = str(map_0)
    assert str_expected == str_actual



# Generated at 2022-06-26 00:10:23.687634
# Unit test for constructor of class Map
def test_Map():
    print('>Test for Map')
    map_0 = Map(1)
    map_1 = Map(2)
    map_2 = Map({1: 'abc'})

    print(map_0)
    print(map_1)
    print(map_2)


# Generated at 2022-06-26 00:10:26.774024
# Unit test for method __str__ of class One
def test_One___str__():
    float_0 = -2624.80
    one_0 = One(float_0)
    assert one_0.__str__() == "One[value=-2624.8]"



# Generated at 2022-06-26 00:10:30.072513
# Unit test for method concat of class Last
def test_Last_concat():
    first_0 = First(24.2544)
    first_1 = First(27.6402)
    first_2 = first_0.concat(first_1)
    assert first_2.value == 24.2544


# Generated at 2022-06-26 00:10:34.468832
# Unit test for method __str__ of class Min
def test_Min___str__():
    float_0 = -3206.62
    float_1 = float_0
    min_0 = Min(float_0)
    min_1 = Min(float_1)
    min_2 = min_0.concat(min_1)
    assert str(min_2) == "Min[value=-3206.62]"



# Generated at 2022-06-26 00:10:36.223409
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)


# Generated at 2022-06-26 00:10:38.320801
# Unit test for constructor of class Map
def test_Map():
    float_0 = -3206.62
    map_0 = Map(float_0)
    return map_0.value


# Generated at 2022-06-26 00:10:44.619973
# Unit test for method concat of class Map
def test_Map_concat():
    float_0 = -3206.62
    float_1 = -0.69663
    float_2 = -9895.18
    float_3 = 2.9904
    float_4 = -2888.27
    float_5 = -5383.33
    float_6 = -5383.33
    float_7 = -3266.5
    int_0 = -100
    int_1 = -100
    int_2 = -100
    int_3 = -100
    int_4 = -100
    int_5 = -100
    int_6 = -100
    int_7 = -100
    map_0 = Map(float_0)
    map_1 = Map(float_1)
    map_2 = Map(float_2)
    map_3 = Map(float_3)


# Generated at 2022-06-26 00:10:55.748200
# Unit test for constructor of class Semigroup
def test_Semigroup():
    try:
        float_0 = Sum(-3206.62)
        assert float_0.value == -3206.62
        float_1 = Sum(-3206.62)
        float_2 = float_0.concat(float_1)
        assert float_2.value == -6413.24
        float_3 = Semigroup.neutral(float_0)
        float_4 = float_2.fold(float_3)
        assert float_4.value == -6413.24
        float_5 = float_0.fold(float_4)
        assert float_5.value == -6413.24
        float_6 = float_1.fold(float_3)
        assert float_6.value == -3206.62
    except Exception:
        raise Exception


# Generated at 2022-06-26 00:11:02.301082
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)


# Generated at 2022-06-26 00:11:10.808737
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    neutral_value_of_semigroup_0 = Semigroup.neutral_element
    neutral_value_of_semigroup_1 = Semigroup.neutral_element
    neutral_value_of_semigroup_2 = Semigroup.neutral_element
    neutral_value_of_semigroup_3 = Semigroup.neutral_element
    neutral_value_of_semigroup_4 = Semigroup.neutral_element
    neutral_value_of_semigroup_5 = Semigroup.neutral_element
    neutral_value_of_semigroup_6 = Semigroup.neutral_element
    neutral_value_of_semigroup_7 = Semigroup.neutral_element
    neutral_value_of_semigroup_8 = Semigroup.neutral_element
    neutral_value_of_semigroup_9 = Semigroup.neutral_element
    neutral_value_of_semigroup

# Generated at 2022-06-26 00:11:21.333050
# Unit test for method concat of class Sum
def test_Sum_concat():
    float_0 = 0.0
    float_1 = -3.0
    float_2 = 4.17
    float_3 = -0.0
    float_4 = -3.0
    float_5 = -9.0
    float_6 = 3.0
    float_7 = 0.0
    float_8 = -4.17
    float_9 = 0.0
    sum_0 = Sum(float_0)
    sum_1 = Sum(float_1)
    sum_2 = Sum(float_2)
    sum_3 = Sum(float_3)
    sum_4 = Sum(float_4)
    sum_5 = Sum(float_5)
    sum_6 = Sum(float_6)
    sum_7 = Sum(float_7)

# Generated at 2022-06-26 00:11:23.882936
# Unit test for method concat of class Min
def test_Min_concat():
    float_0 = -3206.62
    min_0 = Min(float_0)
    assert min_0.concat(min_0).value == -3206.62


# Generated at 2022-06-26 00:11:25.760161
# Unit test for constructor of class All
def test_All():
    all_0 = All(True)
    all_1 = All(False)

    assert all_0 == All(True)
    assert all_1 == All(False)


# Generated at 2022-06-26 00:11:30.436609
# Unit test for constructor of class Semigroup
def test_Semigroup():
    print("")
    
    float_0 = -3206.62
    map_0 = Map(float_0)
    
    print("<---- test_Semigroup ---->\n")

    float_0 = -3206.62
    map_0 = Map(float_0)
    
    print("<---- test_Semigroup ---->\n")



# Generated at 2022-06-26 00:11:32.474816
# Unit test for method __str__ of class Map
def test_Map___str__():
    float_0 = -390.00
    map_0 = Map(float_0)
    assert str(map_0) == 'Map[value=-390.0]'


# Generated at 2022-06-26 00:11:34.875174
# Unit test for method __str__ of class Map
def test_Map___str__():
    float_0 = -3206.62
    map_0 = Map(float_0)
    assert str(map_0) == "Map[value=-3206.62]"


# Generated at 2022-06-26 00:11:39.769188
# Unit test for method concat of class Map
def test_Map_concat():
    float_0 = -3206.62
    map_0 = Map(float_0)
    assert map_0.value == float_0
    
if __name__ == '__main__':
    test_case_0()
    test_Map_concat()

# Generated at 2022-06-26 00:11:43.374572
# Unit test for method __str__ of class Last
def test_Last___str__():
    print('test __str__ for class First')
    for i in range(int(1e3)):
        obj = Last(int(random() * 1e10))
        #  visual
        print(obj)
        #  functional
        assert str(obj) == 'Last[value={}]'.format(obj.value)


# Generated at 2022-06-26 00:11:56.711783
# Unit test for method concat of class Map
def test_Map_concat():
    float_0 = -3141.34 
    map_0 = Map(float_0)
    float_1 = -6640.67 
    map_1 = Map(float_1)
    map_2 = map_0.concat(map_1)
    float_2 = 393.47 
    map_3 = Map(float_2)
    map_4 = map_2.concat(map_3)
    float_3 = -3455.7 
    map_5 = Map(float_3)
    map_6 = map_4.concat(map_5)
    boolean_0 = map_6.__eq__(map_6)
    assert boolean_0
    int_0 = map_6.value
    assert int_0 == -6640.67


# Generated at 2022-06-26 00:11:59.997245
# Unit test for method __str__ of class All
def test_All___str__():
    bool_0 = True
    all_0 = All(bool_0)
    assert all_0.__str__() == 'All[value=True]'



# Generated at 2022-06-26 00:12:01.904776
# Unit test for constructor of class Min
def test_Min():
    min_0 = Min(0)
    min_1 = Min(min_0)
    min_2 = Min(min_1)

# Generated at 2022-06-26 00:12:04.901599
# Unit test for method __str__ of class Min
def test_Min___str__():
    float_0 = -482.9791
    min_0 = Min(float_0)
    str_0 = 'Min[value=-482.9791]'
    assert str(min_0) == str_0


# Generated at 2022-06-26 00:12:08.473546
# Unit test for constructor of class Min
def test_Min():
    float_0 = -3206.62
    min_0 = Min(float_0)


# Generated at 2022-06-26 00:12:14.127491
# Unit test for method concat of class Last
def test_Last_concat():
    struct_0 = Last(0)
    struct_1 = Last(1)
    struct_2 = struct_0.concat(struct_1)
    assert struct_2.value == 1


# Generated at 2022-06-26 00:12:20.961633
# Unit test for constructor of class First
def test_First():
    first_0 = First(4160)
    assert (first_0.value == 4160)

    first_1 = First(589)
    assert (first_1.value == 589)

    first_2 = First(-7234)
    assert (first_2.value == -7234)

    first_3 = First(9571)
    assert (first_3.value == 9571)

    first_4 = First(-7409)
    assert (first_4.value == -7409)

    first_5 = First(8765)
    assert (first_5.value == 8765)



# Generated at 2022-06-26 00:12:30.235368
# Unit test for method __str__ of class Map
def test_Map___str__():
    float_0 = -3206.62
    map_0 = Map(float_0)
    str_0 = map_0.__str__()
    float_1 = float("inf")
    float_2 = float("inf")
    list_0 = [float_1, float_2]
    map_1 = Map(list_0)
    str_1 = map_1.__str__()
    float_3 = float("inf")
    float_4 = float("inf")
    list_1 = [float_3, float_4]
    map_2 = Map(list_1)
    str_2 = map_2.__str__()
    float_5 = float("inf")
    float_6 = float("inf")
    list_2 = [float_5, float_6]

# Generated at 2022-06-26 00:12:32.300299
# Unit test for method concat of class First
def test_First_concat():
    assert First("foo").concat(Last("bar")) == First("foo")
    assert First(1).concat(First(2)) == First(1)


# Generated at 2022-06-26 00:12:33.792529
# Unit test for constructor of class Map
def test_Map():
    test_case_0()


# Generated at 2022-06-26 00:12:55.311414
# Unit test for constructor of class Map
def test_Map():
    print("\nUnit test for constructor of class Map...")
    float_0 = -3206.62
    map_0 = Map(float_0)
    print("Instance of Map has been created: {}".format(map_0))
    int_0 = -4426
    map_1 = Map(int_0)
    print("Instance of Map has been created: {}".format(map_1))
    float_1 = 99126.6
    map_2 = Map(float_1)
    print("Instance of Map has been created: {}".format(map_2))
    int_1 = -7054
    map_3 = Map(int_1)
    print("Instance of Map has been created: {}".format(map_3))
    print("\tDone!")


# Generated at 2022-06-26 00:13:03.512695
# Unit test for method concat of class Sum
def test_Sum_concat():
    # Case 0
    float_0 = -3206.62
    sum_0 = Sum(float_0)
    float_1 = -445.8
    sum_1 = Sum(float_1)
    sum_2 = sum_1.concat(sum_0)
    # Assertion
    assert sum_2.value == sum_0.value + sum_1.value

    # Case 1
    list_0 = [59, 3, 84, 63, 28, -75, -63, -76, -71, 53, -91, -64, -42, 81, -45, -12, -66, -41, 7, -38]
    sum_3 = Sum(list_0[0])

# Generated at 2022-06-26 00:13:07.276961
# Unit test for method __str__ of class First
def test_First___str__():
    float_0 = -3206.62
    first_0 = First(float_0)
    str_0 = first_0.__str__()
    assert str_0 == 'Fist[value=None]', 'Expected ' + 'Fist[value=None]' + ', but got ' + str_0


# Generated at 2022-06-26 00:13:15.423384
# Unit test for method concat of class Map
def test_Map_concat():
    float_0 = -3206.62
    list_0 = [float_0, float_0]
    map_0 = Map({float_0: list_0})
    string_0 = '<&",],T{T3`bx#'
    dict_0 = {string_0: map_0}
    map_1 = Map(dict_0)
    string_1 = 'eq4!Am7D:1'
    map_2 = Map({string_1: map_1})
    map_3 = map_2.concat(map_2)

    assert isinstance(map_3.value, dict)


# Generated at 2022-06-26 00:13:19.661641
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    float_0 = -3206.62
    semigroup_0 = Sum(float_0)

    Sum.neutral()

    float_1 = -3206.62
    Sum_0 = Sum(float_1)

    Sum_0.concat(semigroup_0)

    # Test instance not has attribute concat
    semigroup_0.concat(semigroup_0)

# Generated at 2022-06-26 00:13:21.269226
# Unit test for method __str__ of class First
def test_First___str__():
    float_0 = -3206.62
    assert str(First(float_0)) == 'Fist[value=-3206.62]'


# Generated at 2022-06-26 00:13:26.170786
# Unit test for constructor of class Sum
def test_Sum():
    float_0 = float(42.254)
    float_1 = float(34.254)
    float_2 = float(39.254)
    float_3 = float(-55.254)
    float_4 = float(-57.254)
    float_5 = float(-27.254)
    float_6 = float(-82.254)
    float_7 = float(14.254)
    float_8 = float(20.254)
    float_9 = float(0.254)
    float_10 = float(25.254)
    float_11 = float(13.254)
    float_12 = float(1.254)
    float_13 = float(5.254)
    float_14 = float(19.254)
    float_15 = float(4.254)

# Generated at 2022-06-26 00:13:28.553689
# Unit test for method concat of class Last
def test_Last_concat():
    last_0 = Last(11.4)
    last_1 = Last(57.9)
    last_2 = last_0.concat(last_1)
    assert last_2.value == 57.9



# Generated at 2022-06-26 00:13:36.098773
# Unit test for method concat of class One
def test_One_concat():
    one_1 = One(True)
    one_2 = One(False)
    one_3 = One(False)
    one_4 = One(False)
    one_5 = One(True)
    one_6 = One(False)
    one_7 = One(True)
    one_8 = One(True)
    one_9 = One(True)
    one_10 = One(False)
    one_11 = One(False)
    one_12 = One(True)
    one_13 = One(True)
    one_14 = One(False)
    one_15 = One(False)
    one_16 = One(False)
    one_17 = One(True)
    one_18 = One(False)
    one_19 = One(False)
    one_20 = One(True)

# Generated at 2022-06-26 00:13:43.458625
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max.neutral().concat(Max(-7.25)) == Max(-7.25)
    assert Max(44.2).concat(Max.neutral()) == Max(44.2)
    assert Max(8.88).concat(Max(33.42)) == Max(33.42)
    assert Max(42.36).concat(Max(83.17)) == Max(83.17)
    assert Max(60.34).concat(Max(-2.47)) == Max(60.34)
    assert Max(54.25).concat(Max(6.34)) == Max(54.25)
    assert Max(40.94).concat(Max(-35.66)) == Max(40.94)
    assert Max(28.89).concat(Max(7.71)) == Max(28.89)
    assert Max

# Generated at 2022-06-26 00:14:02.596702
# Unit test for method concat of class One
def test_One_concat():
    float_0 = -3206.62
    one_0 = One(float_0)
    bool_0 = one_0.concat(one_0)
    bool_0.neutral()
    assert bool_0 == False


# Generated at 2022-06-26 00:14:09.126468
# Unit test for method concat of class Map
def test_Map_concat():
    float_0 = -3206.62
    map_0 = Map({'r': First(float_0), 'x': First(float_0)})
    float_1 = 4463.93
    map_1 = Map({'r': First(float_1), 'x': First(float_1)})
    map_expected = Map({'r': First(float_0), 'x': First(float_0)})
    map_1 = map_0.concat(map_1)
    # self.assertTrue(map_1.equals(map_expected))

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 00:14:20.751586
# Unit test for method concat of class Min
def test_Min_concat():
    # case 0
    float_0 = -3206.62
    min_0 = Min(float_0)
    float_1 = -3206.62
    min_1 = Min(float_1)
    min_2 = Min.neutral()
    assert min_0.concat(min_1).value == -3206.62
    float_2 = float("inf")
    min_3 = Min(float_2)
    float_3 = -3206.62
    min_4 = Min(float_3)
    assert min_3.concat(min_4).value == -3206.62
    float_4 = 0.0
    min_5 = Min(float_4)
    float_5 = -3206.62
    min_6 = Min(float_5)
    assert min_5.con

# Generated at 2022-06-26 00:14:33.220332
# Unit test for method concat of class One
def test_One_concat():
    bool_0 = False
    int_0 = 10
    int_1 = 8
    bool_1 = True
    bool_2 = True
    bool_3 = False
    bool_4 = True
    bool_5 = False
    bool_6 = True
    bool_7 = False
    bool_8 = True
    bool_9 = False
    bool_10 = False
    bool_11 = True
    bool_12 = False
    bool_13 = False
    bool_14 = False
    bool_15 = False
    bool_16 = False
    bool_17 = False
    bool_18 = True
    bool_19 = True
    bool_20 = True
    bool_21 = False
    bool_22 = True
    bool_23 = True
    bool_24 = True
    bool_25 = True
    bool_

# Generated at 2022-06-26 00:14:35.931699
# Unit test for method __str__ of class First
def test_First___str__():
    float_0 = -3206.62
    first_0 = First(float_0) #TODO: rename variable to proper name
    str_0 = str(first_0)
    assert str_0 == 'Fist[value=-3206.62]'


# Generated at 2022-06-26 00:14:37.722163
# Unit test for method __str__ of class Max
def test_Max___str__():
    float_0 = 0.03235048496067919
    max_0 = Max(float_0)
    str_0 = str(max_0)



# Generated at 2022-06-26 00:14:40.515694
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    float_0 = -3206.62
    map_0 = Map(float_0)
    map_1 = Last(-3.0)
    expected_result = 'comparing two semigroups of different types'
    result = map_0.__eq__(map_1)
    assert result == expected_result



# Generated at 2022-06-26 00:14:50.572528
# Unit test for constructor of class Last
def test_Last():
    int_0 = 500
    bool_0 = bool(int_0)
    bool_1 = bool_0
    bool_2 = bool_0
    list_0 = []
    list_0.append(bool_1)
    list_0.append(bool_2)
    list_0.append(bool_2)
    last_0 = Last(int_0)
    last_1 = Last(list_0)
    assert last_1.value[0] == True
    assert last_0.value == int_0
    assert last_1.value[1] == True
    assert last_1.value[2] == True


# Generated at 2022-06-26 00:14:52.117011
# Unit test for constructor of class Last
def test_Last():
    assert Last(5) == Last(5)
    assert not (Last(5) == Last(6))


# Generated at 2022-06-26 00:14:53.678920
# Unit test for method __str__ of class Min
def test_Min___str__():
    float_0 = -3206.62
    min_0 = Min(float_0)


# Generated at 2022-06-26 00:15:14.620761
# Unit test for method concat of class Last
def test_Last_concat():
    list_0 = ["b", len("b")]
    list_1 = [re.match(r'^[0-9]+$', None), re.match(r'^[0-9]+$', None)]
    attribute_0 = Last(list_0)
    attribute_1 = Last(list_1)
    attribute_2 = attribute_0.concat(attribute_1)
    attribute_2.value = list_0


# Generated at 2022-06-26 00:15:18.021614
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_0 = Sum(5)
    sum_1 = Sum(2)
    sum_2 = sum_0.concat(sum_1)
    print(sum_0)
    print(sum_1)
    print(sum_2)



# Generated at 2022-06-26 00:15:19.187389
# Unit test for method concat of class First
def test_First_concat():
    float_0 = -3206.62
    first_0 = First(float_0)
    assert first_0.concat(first_0) == First(float_0)


# Generated at 2022-06-26 00:15:21.659565
# Unit test for constructor of class Sum
def test_Sum():
  assert Sum.neutral_element == 0

  # float_0 = -3206.62
  assert float_0 == Sum.neutral_element

  map_0 = Map(float_0)
  Sum.__init__(map_0)


# Generated at 2022-06-26 00:15:22.910249
# Unit test for constructor of class All
def test_All():
    all_0 = All(True)
    all_1 = All(False)


# Generated at 2022-06-26 00:15:26.859978
# Unit test for method __str__ of class Last
def test_Last___str__():
    float_0 = -3206.62
    last_0 = Last(float_0)
    # assert last_0.__str__() == 'Last[value=3-3206.62]'
    # assert len(last_0.__str__()) == 17
    assert last_0.__str__() == 'Last[value=-3206.62]'
    assert len(last_0.__str__()) == 18


# Generated at 2022-06-26 00:15:34.902719
# Unit test for constructor of class All
def test_All():
    val_0 = True
    all_0 = All(val_0)
    val_1 = False
    all_1 = All(val_1)
    val_2 = False
    all_2 = All(val_2)
    val_3 = True
    all_3 = All(val_3)
    val_4 = False
    all_4 = All(val_4)
    val_5 = False
    all_5 = All(val_5)

    val_6 = False
    all_6 = All(val_6)

    val_7 = True
    all_7 = All(val_7)

    val_8 = True
    all_8 = All(val_8)

    val_9 = True
    all_9 = All(val_9)

    val_10 = False
    all

# Generated at 2022-06-26 00:15:36.160909
# Unit test for method __str__ of class All
def test_All___str__():
    subject = All(123)
    assert str(subject) == 'All[value=123]'



# Generated at 2022-06-26 00:15:38.371919
# Unit test for method __str__ of class Min
def test_Min___str__():
    float_0 = -3206.62
    min_0 = Min(float_0)
    string_0 = 'Min[value=-3206.62]'
    assert(str(min_0) == string_0)


# Generated at 2022-06-26 00:15:40.486685
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    float_0 = -2294.45
    sum_0 = Sum(float_0)
    semigroup_0 = sum_0
    assert str(semigroup_0) == 'Sum[value=-2294.45]'
