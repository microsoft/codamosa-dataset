

# Generated at 2022-06-26 00:05:45.089457
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)).value == 2


# Generated at 2022-06-26 00:05:47.776684
# Unit test for method concat of class Min
def test_Min_concat():
    min_1 = Min(2141579276)
    min_2 = Min(814240413)
    min_3 = min_1.concat(min_2)
    assert min_3.value == 814240413




# Generated at 2022-06-26 00:05:50.816053
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(3)).value == 2
    assert Min(3).concat(Min(2)).value == 2
    assert Min(3).concat(Min(3)).value == 3



# Generated at 2022-06-26 00:05:53.368504
# Unit test for method concat of class Max
def test_Max_concat():
    pass
    # assert var_0 == "IZC5\x0c[%\x0cA<;/]}^M[S%\\"


# Generated at 2022-06-26 00:06:02.121294
# Unit test for method concat of class Min
def test_Min_concat():
    '''
    :return: Unit tests result
    :rtype: bool
    '''
    value_1 = Min(2)
    Min_concat_1 = value_1.concat(Min(1))
    expected_1 = Min(1)

    value_2 = Min(1)
    Min_concat_2 = value_2.concat(Min(2))
    expected_2 = Min(1)

    value_3 = Min(-1)
    Min_concat_3 = value_3.concat(Min(-2))
    expected_3 = Min(-2)

    value_4 = Min(-2)
    Min_concat_4 = value_4.concat(Min(-1))
    expected_4 = Min(-2)


# Generated at 2022-06-26 00:06:05.115105
# Unit test for method concat of class Min
def test_Min_concat():
    int_0 = Min(2).concat(Min(2))
    float_0 = Min(3.0).concat(Min(2.0))
    assert (int_0.value == 2)
    assert (float_0.value == 2.0)


# Generated at 2022-06-26 00:06:10.302844
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min(89.0)
    min_1 = Min(98.0)
    min_2 = Min(99.0)
    min_3 = min_1.concat(min_2)
    assert min_3.value == 99.0
    min_4 = min_0.concat(min_3)
    assert min_4.value == 89.0


# Generated at 2022-06-26 00:06:13.692632
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min(10)
    min_0.concat(5)
    print(min_0.concat(5))
    assert min_0.value == 5

# Generated at 2022-06-26 00:06:23.364801
# Unit test for method concat of class Max
def test_Max_concat():
    # Test case 1
    int_0 = 6029
    int_1 = 7159
    max_0 = Max(int_0)
    max_1 = max_0.concat(int_1)
    assert max_1.value == 7159
    # Test case 2
    int_2 = -924
    int_3 = -4028
    max_2 = Max(int_2)
    max_3 = max_2.concat(int_3)
    assert max_3.value == -924
    # Test case 3
    int_4 = -924
    int_5 = -4028
    max_4 = Max(int_4)
    max_5 = max_4.concat(int_5)
    assert max_5.value == -924



# Generated at 2022-06-26 00:06:33.422773
# Unit test for method concat of class Min
def test_Min_concat():
    """
    Check method concat of Min class
    """
    # Test case #0
    str_0 = 'IZC5\x0c[%\x0cA<;/]}^M[S%\\'
    str_1 = 'IZC5\x0c[%\x0cA<;/]}^M[S%\\'
    last_0 = Last(str_0)
    last_1 = Last(str_1)
    var_0 = last_0.concat(last_1)
    assert var_0.value == str_0

    # Test case #1
    str_2 = 'IZC\x0cA<;/]}^M[S%\\'
    str_3 = 'IZC\x0cA<;/]}^M[S%\\'
    last_

# Generated at 2022-06-26 00:06:38.242006
# Unit test for method concat of class Max
def test_Max_concat():
    obj_0 = Max(0)
    obj_1 = Max(5)
    result_0 = obj_0.concat(obj_1)
    assert result_0 == 5


# Generated at 2022-06-26 00:06:43.378914
# Unit test for method concat of class Max
def test_Max_concat():
    sum_0 = Sum(2)
    sum_1 = Sum(1)
    last_0 = Last(sum_0)
    last_1 = Last(sum_1)
    max_0 = Max(sum_0)
    max_1 = Max(sum_1)
    max_0.concat(Last(max_1))


# Generated at 2022-06-26 00:06:45.047575
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)


# Generated at 2022-06-26 00:06:47.913657
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(6).concat(8) == 8
    assert Max(7).concat(5) == 7
    assert Max(9).concat(9) == 9
    assert Max(4).concat(4) == 4


# Generated at 2022-06-26 00:06:51.772882
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max("asd").concat("bcd") == Max("bcd")
    assert Max("bcd").concat("asd") == Max("bcd")
    assert Max("").concat("") == Max("")


# Generated at 2022-06-26 00:06:56.579675
# Unit test for method concat of class Max
def test_Max_concat():
    float_0 = float("NaN")
    max_instance_0 = Max(float_0)
    max_instance_1 = Max(float_0)
    max_instance_2 = max_instance_0.concat(max_instance_1)
    assert max_instance_2 == Max(float_0)


# Generated at 2022-06-26 00:07:00.703387
# Unit test for method concat of class Max
def test_Max_concat():
    str_0 = 'izc5\x0c[%\x0cA<;/]}^M[S%\\'
    max_0 = Max(str_0)
    var_0 = max_0.concat(str_0)


# Generated at 2022-06-26 00:07:02.614157
# Unit test for method concat of class Max
def test_Max_concat():
    max_0 = Max(10)
    max_1 = Max(10)
    max_0.concat(max_1)


# Generated at 2022-06-26 00:07:10.982523
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(-2).concat(Max(-1)) == Max(-1)
    assert Max(1).concat(Max(0)) == Max(1)
    assert Max(0).concat(Max(3)) == Max(3)
    assert Max(3).concat(Max(-1)) == Max(3)
    assert Max(-2).concat(Max(1)) == Max(1)
    assert Max(-1).concat(Max(0)) == Max(0)
    assert Max(1).concat(Max(3)) == Max(3)
    assert Max(0).concat(Max(-1)) == Max(0)
    assert Max(3).concat(Max(-2)) == Max(3)
    assert Max(1).concat(Max(-2)) == Max(1)

# Generated at 2022-06-26 00:07:23.260715
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(33).concat(Max(21)) == Max(33)
    assert Max(34).concat(Max(28)) == Max(34)
    assert Max(35).concat(Max(15)) == Max(35)
    assert Max(36).concat(Max(26)) == Max(36)
    assert Max(37).concat(Max(27)) == Max(37)
    assert Max(38).concat(Max(21)) == Max(38)
    assert Max(39).concat(Max(18)) == Max(39)
    assert Max(30).concat(Max(19)) == Max(30)
    assert Max(31).concat(Max(13)) == Max(31)
    assert Max(32).concat(Max(17)) == Max(32)

# Generated at 2022-06-26 00:07:29.389039
# Unit test for method concat of class Max
def test_Max_concat():
    max_0 = Max(0)
    max_1 = max_0.concat(0)
    assert max_1.value == 0



# Generated at 2022-06-26 00:07:36.176776
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min(83)
    min_1 = min_0.concat(Min(9))

    assert min_0.value == min_1.value



# Generated at 2022-06-26 00:07:39.822607
# Unit test for constructor of class Last
def test_Last():
    last = Last(8)
    # Assert type of returned object
    assert isinstance(last, Last)
    # Assert if returned object is empty
    assert last.value == 8
    # Assert type of returned value
    assert isinstance(last.value, int)



# Generated at 2022-06-26 00:07:49.064529
# Unit test for constructor of class Semigroup
def test_Semigroup():
    str_0 = 'IZC5\x0c[%\x0cA<;/]}^M[S%\\'
    str_1 = 'IZC5\x0c[%\x0cA<;/]}^M[S%\\'
    last_0 = Last(str_0)
    first_0 = First(str_1)
    max_0 = Max(str_0)
    min_0 = Min(str_1)
    map_0 = Map(
        {
            "zzz": last_0,
            "xxx:": last_0,
            "zzxxz:": last_0,
            "zzzzzzz": last_0,
            "xxxxxx:": last_0
        }
    )
    one_0 = One(str_1)
    one_1

# Generated at 2022-06-26 00:07:59.464024
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert str_0 == Semigroup.fold()
    assert int_0 == Semigroup.fold()
    assert last_0 == Semigroup.fold()
    assert str_2 == Semigroup.fold()
    assert max_0 == Semigroup.fold()
    assert min_2 == Semigroup.fold()
    assert map_0 == Semigroup.fold()


# Generated at 2022-06-26 00:08:01.131567
# Unit test for constructor of class Max
def test_Max():
    assert Max(2) == Max(2)
    assert Max(2) != Max(3)


# Generated at 2022-06-26 00:08:02.996281
# Unit test for constructor of class One
def test_One():
    instance = One(1)
    assert isinstance(instance, One), f'Expected {One}, but got {type(instance)}'


# Generated at 2022-06-26 00:08:06.580512
# Unit test for method concat of class Max
def test_Max_concat():
    # Test function Max
    var_4 = Max(42)
    assert var_4.concat(2) == var_4
    assert var_4.concat(53) == var_4
    assert var_4.concat(21) != var_4
    assert var_4.concat(22) != var_4



# Generated at 2022-06-26 00:08:10.664954
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():

    def check_fold_case_0(var_0):
        assert var_0 == 'IZC5\x0c[%\x0cA<;/]}^M[S%\\'

    # test case for Semigroup fold method
    check_fold_case_0(test_case_0())


# Generated at 2022-06-26 00:08:15.053446
# Unit test for constructor of class Map
def test_Map():
    try:
        var_0 = {'a':1, 'b':2}
        var_1 = Map(var_0)
        assert(var_1.value == {'a':1, 'b':2})
    except:
        assert False


# Generated at 2022-06-26 00:08:23.941442
# Unit test for method __str__ of class All
def test_All___str__():
    str_0 = 'IZC5\x0c[%\x0cA<;/]}^M[S%\\'
    all_0 = All(str_0)


# Generated at 2022-06-26 00:08:26.871095
# Unit test for method __str__ of class Last
def test_Last___str__():
    str_0 = 'IZC5\x0c[%\x0cA<;/]}^M[S%\\'
    last_0 = Last(str_0)
    str_1 = last_0.__str__()


# Generated at 2022-06-26 00:08:32.402347
# Unit test for method __str__ of class Map
def test_Map___str__():
    str_0 = 'IZC5\x0c[%\x0cA<;/]}^M[S%\\'
    last_0 = Last(str_0)
    map_0 = Map({str_0: last_0})

    assert str(map_0) == 'Map[value={IZC5\x0c[%\x0cA<;/]}^M[S%\\: Last[value=IZC5\x0c[%\x0cA<;/]}^M[S%\\]]'


# Generated at 2022-06-26 00:08:33.715635
# Unit test for constructor of class Max
def test_Max():
    var = Max(0)
    assert var.value == 0


# Generated at 2022-06-26 00:08:37.316840
# Unit test for method concat of class First
def test_First_concat():
    value = 'First[value=test]'
    other_value = 'First[value=test_new]'
    First(value).concat(First(other_value))


# Generated at 2022-06-26 00:08:41.830896
# Unit test for method concat of class Map
def test_Map_concat():
    map_0 = Map({'a': Sum(0), 'b': Sum(1)})
    map_1 = Map({'a': Sum(2), 'b': Sum(3)})
    map_2 = map_0.concat(map_1)
    map_3 = map_2
    map_4 = map_3.fold(str)
    assert map_4 is not None


# Generated at 2022-06-26 00:08:44.218170
# Unit test for method __str__ of class All
def test_All___str__():
    first_1 = All('truly value')
    assert first_1.__str__() == 'All[value=truly value]'


# Generated at 2022-06-26 00:08:46.091800
# Unit test for method __str__ of class Min
def test_Min___str__():
    min_0 = Min(1.38)
    assert min_0.__str__() == 'Min[value=1.38]'


# Generated at 2022-06-26 00:08:49.301681
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First('IZC5\x0c[%\x0cA<;/]}^M[S%\\')) == 'Fist[value=IZC5\x0c[%\x0cA<;/]}^M[S%\\]'


# Generated at 2022-06-26 00:08:53.827130
# Unit test for method __str__ of class Last
def test_Last___str__():
    str_0 = '\u0001\u0003\u0003\u0003\u0001\u0003\u0000'
    last_0 = Last(str_0)
    str_1 = str(last_0)
    assert str_1 == 'Last[value=\u0001\u0003\u0003\u0003\u0001\u0003\u0000]', 'Unittest: Method __str__'



# Generated at 2022-06-26 00:09:08.332156
# Unit test for constructor of class Sum
def test_Sum():
    sum_0 = Sum(12)
    assert isinstance(sum_0.value, int)
    assert sum_0.value == 12


# Generated at 2022-06-26 00:09:11.358146
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    var = -2994682030
    int_0 = Sum(var)
    var_0 = int_0.__eq__(var)
    assert var_0 == True, '__eq__ in class Semigroup returns unexpected value.'



# Generated at 2022-06-26 00:09:12.918933
# Unit test for method __str__ of class One
def test_One___str__():
    result = str(One('+137'))
    assert 'One[value=+137]' == result


# Generated at 2022-06-26 00:09:14.699140
# Unit test for method __str__ of class Max
def test_Max___str__():
    max_0 = Max(8)
    assert(str(max_0) == 'Max[value=8]')


# Generated at 2022-06-26 00:09:20.796397
# Unit test for method __str__ of class One
def test_One___str__():
    str_0 = 'IZC5\x0c[%\x0cA<;/]}^M[S%\\'
    last_0 = Last(str_0)
    assert last_0.__str__() == 'Last[value=IZC5\x0c[%\x0cA<;/]}^M[S%\\]'
    return

if __name__ == "__main__":  # pragma: no cover
    # execute only if run as a script
    test_case_0()
    test_One___str__()

# Generated at 2022-06-26 00:09:22.281078
# Unit test for method __str__ of class All
def test_All___str__():
    assert All(True).__str__() == u'All[value=True]'


# Generated at 2022-06-26 00:09:28.125739
# Unit test for method __str__ of class First
def test_First___str__():
    str_0 = 'v\x1b1[$\n#\t\x1b1%\x12#?\x1b~\x1b\\]_'
    first_0 = First(str_0)
    var_1 = 'Fist[value=v\x1b1[$\n#\t\x1b1%\x12#?\x1b~\x1b\\]_]'
    var_0 = first_0.__str__()
    assert var_1 == var_0



# Generated at 2022-06-26 00:09:31.573520
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    str_0 = 'IZC5\x0c[%\x0cA<;/]}^M[S%\\'
    last_0 = Last(str_0)
    var_0 = last_0.fold(print)


# Generated at 2022-06-26 00:09:35.109305
# Unit test for method concat of class Max
def test_Max_concat():
    var_0 = Max(4).concat(4)
    assert var_0 is not None and var_0.value == 4
    var_0 = Max(4).concat(2)
    assert var_0 is not None and var_0.value == 4


# Generated at 2022-06-26 00:09:36.951409
# Unit test for method __str__ of class All
def test_All___str__():
    var_0 = All(0)
    assert var_0.__str__() == 'All[value=0]'


# Generated at 2022-06-26 00:10:12.170935
# Unit test for method __str__ of class Last

# Generated at 2022-06-26 00:10:20.918845
# Unit test for method __str__ of class All
def test_All___str__():
    int_0 = 0
    int_1 = 1
    int_2 = 2
    bool_0 = True
    bool_1 = False
    int_3 = 3
    str_0 = 'All[value={}]'
    all_0 = All(bool_1)
    var_0 = all_0.concat(bool_1)
    var_1 = var_0.concat(bool_1)
    var_2 = var_1.concat(bool_0)
    var_3 = var_2.concat(bool_0)

    # Test with Last
    var_4 = var_3.concat(bool_0)
    var_5 = var_4.concat(bool_1)

    # Test with First
    var_6 = var_5.concat(bool_0)
   

# Generated at 2022-06-26 00:10:22.627004
# Unit test for constructor of class Last
def test_Last():
    last = Last('str')
    assert(last.__str__() == 'Last[value=str]')


# Generated at 2022-06-26 00:10:24.247736
# Unit test for method concat of class All
def test_All_concat():
    test_case_0()



# Generated at 2022-06-26 00:10:33.806383
# Unit test for method concat of class One
def test_One_concat():
    # Contants definition
    int_0 = -34
    int_1 = -1
    int_2 = 1
    int_3 = 30
    map_0 = {
        'a': Map({
            'a': All(True),
            'b': All(True)
        }),
        'b': Map({
            'a': All(True),
            'b': All(True)
        })
    }
    map_1 = {
        'a': Map({
            'a': All(True),
            'b': All(True)
        }),
        'b': Map({
            'a': All(True),
            'b': All(True)
        }),
        'c': Map({
            'a': All(True),
            'b': All(True)
        })
    }


# Generated at 2022-06-26 00:10:38.201774
# Unit test for method __str__ of class Last
def test_Last___str__():
    str_0 = 'Q\x01}T\x07\x0fB_\x05\x07\x01s~\x0f\x03\x01{'
    last_0 = Last(str_0)
    last_0.__str__()


# Generated at 2022-06-26 00:10:44.590983
# Unit test for method concat of class One
def test_One_concat():
    # Create an instance of class One
    value_0 = One('true')
    expected_0 = value_0.fold(lambda _: True)
    value_1 = One('false')
    expected_1 = value_1.fold(lambda _: True)
    value_2 = One(None)
    expected_2 = value_2.fold(lambda _: False)
    actual_0 = value_0.concat(value_1)
    assert actual_0.value == expected_0, 'actual: {} expected: {}'.format(actual_0.value, expected_0)
    actual_1 = value_1.concat(value_2)
    assert actual_1.value == expected_1, 'actual: {} expected: {}'.format(actual_1.value, expected_1)

# Generated at 2022-06-26 00:10:46.976210
# Unit test for method __str__ of class First
def test_First___str__():
    fst = First(1)
    assert str(fst) == 'Fist[value=1]'



# Generated at 2022-06-26 00:10:48.448058
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(True).__str__() == 'One[value=True]'


# Generated at 2022-06-26 00:10:50.316688
# Unit test for method __str__ of class One
def test_One___str__():
    one_0 = One(0)
    assert one_0.__str__() == 'One[value=0]'



# Generated at 2022-06-26 00:11:45.311582
# Unit test for constructor of class Semigroup
def test_Semigroup():
    semigroup = Semigroup(5)
    assert semigroup.value == 5
    assert semigroup.neutral() == Semigroup(semigroup.neutral_element)


# Generated at 2022-06-26 00:11:47.256475
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum_0 = Sum(43.66)
    assert sum_0.__str__() == 'Sum[value=43.66]'


# Generated at 2022-06-26 00:11:48.369315
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(8)) == 'Min[value=8]'

# Generated at 2022-06-26 00:11:55.198406
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    test_case_0()
    str_0 = 'IZC5\x0c[%\x0cA<;/]}^M[S%\\'
    last_0 = Last(str_0)
    var_0 = [1, 2, 3]
    var_0.append(var_0)
    var_0.append(var_0)
    var_0.append(var_0)
    int_0 = var_0[0].fold(var_0[0])
    last_0.fold((var_0[0]))
    var_0[0].fold((var_0[0]))



# Generated at 2022-06-26 00:12:01.500359
# Unit test for method concat of class Max
def test_Max_concat():
    str_0 = 'GZ\x003\x05\x1e\x1a\x03\x050A_\n\x1c\x1f\\\x1e'
    max_0 = Max(str_0)
    max_1 = max_0.concat(str_0)
    assert max_1.value == str_0, 'AssertionError'


# Generated at 2022-06-26 00:12:04.864755
# Unit test for constructor of class One
def test_One():
    one_0 = One(True)
    assert one_0.value == True
    var = ''.join([chr(i) for i in range(32, 127)])
    one_1 = One(var)
    assert one_1.value == var


# Generated at 2022-06-26 00:12:06.026905
# Unit test for method __str__ of class One
def test_One___str__():
    pass


# Generated at 2022-06-26 00:12:11.109385
# Unit test for constructor of class Last
def test_Last():
    assert str(Last('IZC5\x0c[%\x0cA<;/]}^M[S%\\')) == 'Last[value=IZC5\x0c[%\x0cA<;/]}^M[S%\\]'


# Generated at 2022-06-26 00:12:21.037507
# Unit test for method concat of class Max
def test_Max_concat():
    num_0 = 0.96
    max_0 = Max(num_0)
    max_1 = max_0.concat(Max(num_0))
    assert max_1.value == num_0
    num_0 = 0.96
    max_0 = Max(num_0)
    max_1 = max_0.concat(Max(num_0))
    assert max_1.value == num_0
    num_0 = 0.96
    max_0 = Max(num_0)
    max_1 = max_0.concat(Max(num_0))
    assert max_1.value == num_0
    num_0 = 0.96
    max_0 = Max(num_0)
    max_1 = max_0.concat(Max(num_0))
    assert max

# Generated at 2022-06-26 00:12:26.732167
# Unit test for method __str__ of class All
def test_All___str__():
    str_0 = '`6-p^\x1c\x1b\x1e.\x0f\x1c9\x01\x1c\x1a\x1e0\x1b\x1c'
    all_0 = All(str_0)
    var_0 = all_0.__str__()
    var_1 = all_0.concat(all_0)


# Generated at 2022-06-26 00:14:30.205238
# Unit test for constructor of class Map
def test_Map():
    with pytest.raises(TypeError):
        Map('Test')
        Map(Any)
    Map({
        'First': First(1),
        'Last': Last(2),
        'Max': Max(3),
        'Min': Min(4),
        'All': All(5),
        'One': One(6),
        'Sum': Sum(7),
    })



# Generated at 2022-06-26 00:14:38.288643
# Unit test for method concat of class All
def test_All_concat():
    # Case 0
    str_0 = 'WYQ8^\x0c+\x0c^/WO)8M\x0c{;\x0c'
    all_0 = All(str_0)
    var_0 = all_0.concat(True)
    assert var_0.value == True, 'Expected var_0 to be True but was {}'.format(var_0.value)

    # Case 1
    str_0 = '.+\x0c\x0c^\x0c}R9\x0cM7O\x0c{;\x0c'
    all_0 = All(str_0)
    var_0 = all_0.concat(False)

# Generated at 2022-06-26 00:14:41.967186
# Unit test for method concat of class First
def test_First_concat():
    str_0 = 'IZC5\x0c[%\x0cA<;/]}^M[S%\\'
    last_0 = First('_E=.F^1*}]E_]3P' + ']B' + '&*X' + 'Q+)R' + str_0)
    var_0 = last_0.concat('K@FF^&{N|N' + 'C' + 'W8' + '#<' + '4')


# Generated at 2022-06-26 00:14:52.815004
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    :description: Test concat method of Sum class
    :return: None
    """
    # Tests that Sum behaves correctly when concatenating two Sums
    int_0 = Sum(5)
    int_1 = Sum(7)
    int_2 = int_0.concat(int_1)
    assert int_2.value == 12, \
        "Sum.concat should return a new Sum with the combined values of the two Sums"

    # Tests that Sum behaves correctly when concatenating a Sum and an Appendable
    int_0 = Sum(5)
    int_3 = int_0.concat(12)
    assert int_3.value == 17, \
        "Sum.concat should return a new Sum with the combined values of the Sum and the Appendable"

    # Tests that Sum behaves correctly when

# Generated at 2022-06-26 00:14:54.629260
# Unit test for method __str__ of class Max
def test_Max___str__():
    max_arg_0 = Max(999)
    assert str(max_arg_0) == 'Max[value=999]'


# Generated at 2022-06-26 00:14:57.556743
# Unit test for method concat of class Last
def test_Last_concat():
    str_0 = 'IZC5\x0c[%\x0cA<;/]}^M[S%\\'
    last_0 = Last(str_0)
    var_0 = last_0.concat(str_0)
    assert var_0.value == str_0


# Generated at 2022-06-26 00:14:58.665064
# Unit test for method __str__ of class Max
def test_Max___str__():
    value = 20
    max_instance = Max(value)
    assert max_instance.__str__() == 'Max[value=20]'


# Generated at 2022-06-26 00:14:59.420231
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-26 00:15:00.477152
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-26 00:15:01.802901
# Unit test for method concat of class Sum
def test_Sum_concat():
    a = Sum(2)
    b = Sum(3)
    c = a.concat(b)

    assert c == Sum(5)

