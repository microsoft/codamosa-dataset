

# Generated at 2022-06-26 00:05:56.795520
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = -2029
    max_0 = Max(int_0)
    int_1 = -2721
    max_1 = Max(int_1)
    max_2 = max_0.concat(max_1)
    assert max_0.value == int_0
    assert max_1.value == int_1
    assert max_2.value == int_0


# Generated at 2022-06-26 00:06:00.617464
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = -2029
    max_0 = Max(int_0)
    int_1 = -939
    max_1 = Max(int_1)
    max_0.concat(max_1)
    actual = max_0
    expected = Max(-939)
    assert actual == expected


# Generated at 2022-06-26 00:06:05.985742
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = -2029
    int_1 = -2029
    int_2 = 6206
    int_3 = 6206
    max_0 = Max(int_0)
    max_1 = Max(int_1)
    max_2 = Max(int_2)
    max_3 = Max(int_3)
    exp_0 = max_0.concat(max_1)
    exp_1 = max_2.concat(max_3)
    res_0 = Max(-2029)
    res_1 = Max(6206)
    assert exp_0 == res_0
    assert exp_1 == res_1


# Generated at 2022-06-26 00:06:10.428785
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = -2029
    int_1 = 1463
    max_0 = Max(int_0)
    max_1 = Max(int_1)
    max_2 = max_0.concat(max_1)
    assert max_2 == max_1


# Generated at 2022-06-26 00:06:19.982457
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = -2029
    int_1 = -823
    int_2 = -1205
    max_0 = Max(int_0)
    max_1 = Max(int_1)
    max_2 = Max(int_2)
    max_0 = max_0.concat(max_1)
    max_1 = max_1.concat(max_0)
    max_0 = max_0.concat(max_1)
    max_1 = max_1.concat(max_2)
    max_2 = max_2.concat(max_1)
    max_1 = max_1.concat(max_2)
    assert -2029 == max_1.value


# Generated at 2022-06-26 00:06:29.285013
# Unit test for method concat of class Map
def test_Map_concat():
    # Expected to return:
    # instanceOf: Map[value={'4': Last[value=4], '5': Last[value=5], '6': Last[value=7], '7': Last[value=6]}]
    # But returned:
    # instanceOf: Map[value={'5': Last[value=5], '4': Last[value=4], '6': Last[value=7]}]
    m0 = Map({'4': First(4), '5': First(5)})
    m1 = Map({'5': First(5), '6': First(7), '7': First(6)})
    m0.concat(m1)


# Generated at 2022-06-26 00:06:32.523983
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = 1
    int_1 = -1
    max_0 = Max(int_1)
    max_1 = Max(int_0)
    assert max_0.concat(max_1) == Max(1)


# Generated at 2022-06-26 00:06:37.910495
# Unit test for method concat of class Map
def test_Map_concat():
    dict_0 = {"a": Sum(1), "b": First(2)}
    dict_1 = {"a": Sum(3), "b": Last(4)}
    map_0 = Map(dict_0)
    map_1 = Map(dict_1)
    map_2 = map_0.concat(map_1)

    assert map_2.value == {'a': Sum(4), 'b': Last(4)}



# Generated at 2022-06-26 00:06:39.376265
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(4)).fold(identity) == 4
    assert Max(4).concat(Max(1)).fold(identity) == 4


# Generated at 2022-06-26 00:06:43.100487
# Unit test for method concat of class Max
def test_Max_concat():
    max_0 = Max(6.917)
    max_1 = Max(2.365)
    max_2 = max_1.concat(max_0)
    assert max_2 == Max(6.917)


# Generated at 2022-06-26 00:06:45.433692
# Unit test for constructor of class First
def test_First():
    assert First(5).value == 5


# Generated at 2022-06-26 00:06:48.725189
# Unit test for constructor of class Semigroup
def test_Semigroup():
    int_0 = -2029
    one_0 = One(int_0)
    int_1 = -384
    one_1 = One(int_1)

# Generated at 2022-06-26 00:06:53.571141
# Unit test for constructor of class Map
def test_Map():
    int_0 = 2
    map_0 = Map({int_0: All(int_0)})

    assert map_0.value[int_0] == All(int_0)
    assert map_0.concat(map_0).value[int_0] == All(int_0)


# Generated at 2022-06-26 00:06:55.445106
# Unit test for constructor of class Map
def test_Map():
    """
    For this test we expect to get a error.
    """
    m = Map(1)


# Generated at 2022-06-26 00:07:01.393721
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Sum(1).value == 1
    assert All(True).value == True
    assert One(True).value == True
    assert First("1").value == "1"
    assert Last("2").value == "2"
    assert Max(1.1).value == 1.1
    assert Min(5).value == 5
    assert Map({"a": Sum(1)}).value["a"] == Sum(1)

# Generated at 2022-06-26 00:07:04.413474
# Unit test for method __str__ of class First
def test_First___str__():
    int_0 = 16823
    first_0 = First(int_0)
    str_0 = str(first_0)
    assert 'First[value={}]'.format(int_0) == str_0


# Generated at 2022-06-26 00:07:06.069420
# Unit test for method __str__ of class Map
def test_Map___str__():
    map_0 = Map({})
    assert str(map_0) == 'Map[value={}]'



# Generated at 2022-06-26 00:07:13.125249
# Unit test for method concat of class First
def test_First_concat():
    int_0 = 958
    first_0 = First(int_0)
    int_1 = -1415
    first_1 = First(int_1)
    assert first_0.concat(first_1).value == int_0
    int_2 = -827
    first_2 = First(int_2)
    int_3 = -719
    first_3 = First(int_3)
    assert first_2.concat(first_3).value == int_2
    int_4 = -21
    first_4 = First(int_4)
    int_5 = -25
    first_5 = First(int_5)
    assert first_4.concat(first_5).value == int_4
    int_6 = -182
    first_6 = First(int_6)

# Generated at 2022-06-26 00:07:24.501782
# Unit test for method concat of class Max
def test_Max_concat():
    expected_max_0 = Max(543)

    assert expected_max_0.concat(Max(543)) == Max(543)
    assert expected_max_0.concat(Max(2)) == Max(543)
    assert expected_max_0.concat(Max(-543)) == Max(543)

    expected_max_1 = Max(2)

    assert expected_max_1.concat(Max(2)) == Max(2)
    assert expected_max_1.concat(Max(543)) == Max(543)
    assert expected_max_1.concat(Max(-543)) == Max(2)

    expected_max_2 = Max(-543)

    assert expected_max_2.concat(Max(-543)) == Max(-543)
    assert expected_

# Generated at 2022-06-26 00:07:32.143753
# Unit test for method concat of class Last
def test_Last_concat():
    int_0 = -2029
    one_0 = One(int_0)
    int_3 = -2029
    one_1 = One(int_3)
    last_0 = Last(one_1)
    int_5 = -2029
    one_2 = One(int_5)
    last_1 = Last(one_2)
    one_3 = one_0.concat(one_2)
    last_1.concat(last_0)
    assert last_1.concat(last_0) == Last(one_3)


# Generated at 2022-06-26 00:07:36.489244
# Unit test for method __str__ of class One
def test_One___str__():
    int_0 = -1913
    one_0 = One(int_0)
    str_0 = one_0.__str__()
    assert str_0 == 'One[value=-1913]'


# Generated at 2022-06-26 00:07:45.256183
# Unit test for method concat of class One
def test_One_concat():

    int_0 = -2029
    one_0 = One(int_0)
    str_0 = 'V{_?N'
    one_1 = One(str_0)
    one_0.concat(one_1)
    one_0.value = -2029
    one_1.value = 'V{_?N'
    one_0.concat(one_1)
    # var.concat(var)
    one_0.concat(one_0)
    int_1 = -2029
    one_2 = One(int_1)
    one_0.concat(one_2)
    # var.concat(var)
    one_2.concat(one_2)


# Generated at 2022-06-26 00:07:48.988404
# Unit test for method __str__ of class Map
def test_Map___str__():
    int_0 = -475332556
    map_0 = Map({int_0: Min(int_0)})
    str_0 = "Map[value={-475332556: Min[value=-475332556]}]"
    assert str(map_0) == str_0


# Generated at 2022-06-26 00:07:56.799582
# Unit test for constructor of class Max
def test_Max():
    int_0 = -2029
    int_1 = -2029
    max_0 = Max(int_0)
    assert max_0.value == int_1


# Generated at 2022-06-26 00:07:59.292166
# Unit test for constructor of class Semigroup
def test_Semigroup():
    result = Semigroup(45)
    assert 45 == result.value
    print('Success: test_Semigroup')



# Generated at 2022-06-26 00:08:02.335898
# Unit test for method __str__ of class First
def test_First___str__():
    int_0 = -2029
    one_0 = First(int_0)
    str_0 = str(one_0)
    assert str_0 == 'Fist[value={}]'.format(int_0)


# Generated at 2022-06-26 00:08:11.577127
# Unit test for method concat of class One
def test_One_concat():
    int_0 = -2029
    one_0 = One(int_0)

    int_1 = 81
    one_1 = One(int_1)

    one_2 = One(False)

    one_3 = One(True)

    int_4 = -2029
    one_4 = One(int_4)

    int_5 = 81
    one_5 = One(int_5)

    one_6 = One(False)

    one_7 = One(False)

    int_8 = -2029
    one_8 = One(int_8)

    int_9 = 81
    one_9 = One(int_9)

    one_10 = One(True)

    one_11 = One(False)

    int_12 = -2029

# Generated at 2022-06-26 00:08:21.555804
# Unit test for method __str__ of class Map
def test_Map___str__():
    int_0 = 6969
    int_1 = -2
    int_2 = -92
    int_3 = -209
    int_4 = -918
    int_5 = -3
    int_6 = -45
    int_7 = 8
    int_8 = -9
    int_9 = -4
    int_10 = -2
    int_11 = -99
    int_12 = -9
    int_13 = -70
    int_14 = 8
    map_0 = Map({int_12: Min(int_9), int_3: Sum(int_3), int_14: Max(int_1)})
    map_1 = Map({int_7: Min(int_2), int_10: Sum(int_7), int_11: Max(int_3)})
    map

# Generated at 2022-06-26 00:08:26.825528
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert First(123).fold(lambda value: value) == 123
    assert Last(123).fold(lambda value: value) == 123
    assert Sum(123).fold(lambda value: value) == 123
    assert Min(123).fold(lambda value: value) == 123
    assert Max(123).fold(lambda value: value) == 123
    assert All(123).fold(lambda value: value) == 123
    assert One(123).fold(lambda value: value) == 123



# Generated at 2022-06-26 00:08:36.519903
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = -2029
    max_0 = Max(int_0)
    int_1 = -2029
    max_1 = Max(int_1)
    max_2 = max_0.concat(max_1)
    assert (max_2.value == max_0.value), "AssertionError"
    int_2 = -2029
    max_3 = Max(int_2)
    max_4 = max_2.concat(max_3)
    assert (max_4.value == max_2.value), "AssertionError"

# Generated at 2022-06-26 00:08:40.621388
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'


# Generated at 2022-06-26 00:08:43.526256
# Unit test for method __str__ of class All
def test_All___str__():
    int_0 = 1214
    all_0 = All(int_0)
    exp_0 = 'All[value=1214]'
    assert all_0.__str__() == exp_0


# Generated at 2022-06-26 00:08:51.803740
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    one_0 = One(int_0)
    one_1 = One(int_1)
    one_2 = one_0.concat(one_1)
    one_3 = one_2.concat(one_2)
    one_4 = one_3.concat(one_3)
    one_5 = one_4.concat(one_4)
    one_6 = one_5.concat(one_5)
    one_7 = one_6.concat(one_6)
    one_8 = one_7.concat(one_7)
    one_9 = one_8.concat(one_8)
    one_10 = one_9.concat(one_9)
    one_11 = one_10.concat(one_10)

# Generated at 2022-06-26 00:08:53.730527
# Unit test for constructor of class Map
def test_Map():
    int_0 = -30
    map_0 = Map({0: int_0})


# Generated at 2022-06-26 00:08:55.137048
# Unit test for constructor of class All
def test_All():
    testAll = All(True)
    assert testAll.value == True


# Generated at 2022-06-26 00:08:58.548503
# Unit test for method concat of class All
def test_All_concat():
    int_0 = -2029
    one_0 = One(int_0)
    int_1 = -2029
    one_1 = One(int_1)


# Generated at 2022-06-26 00:09:01.472088
# Unit test for method __str__ of class Min
def test_Min___str__():
    int_0 = 628
    min_0 = Min(int_0)
    str_0 = str(min_0)
    assert str_0 == "Min[value=628]"


# Generated at 2022-06-26 00:09:02.357402
# Unit test for constructor of class Last
def test_Last():
    one_0 = Last(1)


# Generated at 2022-06-26 00:09:05.907537
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = -2029
    max_0 = Max(int_0)
    int_1 = 2029
    max_1 = Max(int_1)
    max_result = max_0.concat(max_1)
    assert max_result.value == 2029


# Generated at 2022-06-26 00:09:08.105098
# Unit test for constructor of class All
def test_All():
    int_0 = -2029
    one_0 = All(int_0)
    assert str(one_0) == 'All[value=True]'


# Generated at 2022-06-26 00:09:12.833840
# Unit test for constructor of class Last
def test_Last():
    int_0 = -741
    # 0 % 2 = 0
    assert Last(int_0).value == int_0


# Generated at 2022-06-26 00:09:14.304317
# Unit test for method concat of class Last
def test_Last_concat():

    assert Last(1).concat(Last(2)) == Last(2)



# Generated at 2022-06-26 00:09:15.761092
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    b = All(True)
    assert isinstance(b.fold(), bool)


# Generated at 2022-06-26 00:09:18.438801
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    int_0 = 1866
    sum_0 = Sum(int_0)
    assert sum_0.__str__() == 'Sum[value={}]'.format(int_0)


# Generated at 2022-06-26 00:09:20.147925
# Unit test for constructor of class All
def test_All():
    test1 = All(True)
    assert test1 == All(True)


# Generated at 2022-06-26 00:09:24.995012
# Unit test for method concat of class Sum
def test_Sum_concat():
    print('\n\nUnit test for method concat of class Sum:')
    int_0 = -2029
    sum_0 = Sum(int_0)
    int_1 = -880
    sum_1 = Sum(int_1)
    s_0 = sum_1.concat(sum_0)
    print('Expected: Sum[value=-2909]')
    print('Actual:', s_0)



# Generated at 2022-06-26 00:09:28.125989
# Unit test for constructor of class Sum
def test_Sum():
    # Test cases
    int_0 = -2029
    sum_0 = Sum(int_0)
    assert sum_0.value == int_0
    assert str(sum_0) == 'Sum[value={}]'.format(int_0)



# Generated at 2022-06-26 00:09:32.602789
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    print('test_Sum___str__')
    int_0 = -2029
    Sum_0 = Sum(int_0)
    str_0 = 'Sum[value={}]'.format(int_0)
    assert(str(Sum_0) == str_0)


# Generated at 2022-06-26 00:09:36.083755
# Unit test for method concat of class Last
def test_Last_concat():
    last_0 = Last("last0")
    last_1 = Last("last1")
    last_2 = last_0.concat(last_1)
    str_1 = last_2.value
    assert str_1 == "last1", "Expected last1, but got " + str_1


# Generated at 2022-06-26 00:09:39.183483
# Unit test for constructor of class Min
def test_Min():
    int_0 = 10
    int_1 = -10
    min = Min(int_0)
    min = min.concat(Min(int_1))
    assert min.value == int_1

test_Min()


# Generated at 2022-06-26 00:09:45.342313
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    int_0 = -2029
    one_0 = One(int_0)
    semigroup_0 = one_0
    assert semigroup_0 == semigroup_0



# Generated at 2022-06-26 00:09:47.773642
# Unit test for method concat of class Last
def test_Last_concat():
    last_0 = Last(2)
    last_1 = Last(1)
    last_2 = last_0.concat(last_1)
    assert last_2.value == 1


# Generated at 2022-06-26 00:09:50.780174
# Unit test for method __str__ of class Max
def test_Max___str__():
    int_0 = -2029
    max_0 = Max(int_0)
    str_0 = max_0.__str__()
    assert (str_0 == 'Max[value=-2029]')


# Generated at 2022-06-26 00:09:55.877715
# Unit test for method concat of class Min
def test_Min_concat():
    m1 = Min(1)
    assert m1.concat(Min(2)).value == 1
    assert m1.concat(Min(1)).value == 1
    assert m1.concat(Min(0)).value == 0
    assert m1.concat(Min(-1)).value == -1
    assert m1.concat(Min(-2)).value == -2


# Generated at 2022-06-26 00:09:58.190779
# Unit test for constructor of class Map
def test_Map():
    try:
        int_0 = 4
        int_1 = 4
        map_0 = Map({int_0 : int_1})
    except NameError as e:
        print (e)


# Generated at 2022-06-26 00:10:00.538604
# Unit test for constructor of class Map
def test_Map():
    dict_1 = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    map_1 = Map(dict_1)
    assert map_1 == Map(dict_1)


# Generated at 2022-06-26 00:10:02.948768
# Unit test for method __str__ of class Min
def test_Min___str__():
    int_0 = -1879407992
    min_0 = Min(int_0)
    assert min_0.__str__() == "Min[value={}]".format(int_0)


# Generated at 2022-06-26 00:10:07.524732
# Unit test for method __str__ of class Min
def test_Min___str__():
    try:
        int_0 = -2029
        min_0 = Min(int_0)
        # Execute
        str_0 = min_0.__str__()
        str_1 = 'Min[value=%d]' % int_0
        # Asserts
        assert str_0 == str_1
    except Exception as e:
        raise e


# Generated at 2022-06-26 00:10:10.987139
# Unit test for method concat of class First
def test_First_concat():
    first_0 = First("hi")
    first_1 = First("there!")
    any_0 = first_0.concat(first_1)
    assert any_0 == first_0


# Generated at 2022-06-26 00:10:12.411003
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(9)) == 'Max[value=9]'



# Generated at 2022-06-26 00:10:17.054274
# Unit test for constructor of class Min
def test_Min():
    int_0 = -2029
    one_0 = First(int_0)



# Generated at 2022-06-26 00:10:21.443420
# Unit test for constructor of class One
def test_One():
    # Set up test case
    int_0 = 2
    one_0 = One(int_0)

    # Test 1: First value
    assert one_0.value == int_0

    # Set up test case
    int_1 = 5
    one_1 = One(int_1)

    # Test 2: Second value
    assert one_1.value == int_1


# Generated at 2022-06-26 00:10:24.485295
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(32417)) == 'Fist[value=32417]'
    assert str(First(26)) == 'Fist[value=26]'
    assert str(First(2712)) == 'Fist[value=2712]'
    assert str(First(88)) == 'Fist[value=88]'
    assert str(First(-1473)) == 'Fist[value=-1473]'
    assert str(First(-1533)) == 'Fist[value=-1533]'
    assert str(First(-7)) == 'Fist[value=-7]'


# Generated at 2022-06-26 00:10:29.781974
# Unit test for method concat of class Max
def test_Max_concat():
    # Test case 0
    max_0 = Max(1)
    max_1 = Max(2)
    max_0_result = max_0.concat(max_1)
    max_1_result = max_1.concat(max_0)
    assert_equal(max_0_result.value, 2)
    assert_equal(max_1_result.value, 2)

# Generated at 2022-06-26 00:10:33.450969
# Unit test for method concat of class Last
def test_Last_concat():
    obj1=Last(10)
    obj2=Last(20)
    obj3=Last(30)
    obj4=Last(40)
    obj1.concat(obj2)
    obj2.concat(obj3)
    obj3.concat(obj4)
    


# Generated at 2022-06-26 00:10:34.000478
# Unit test for constructor of class Semigroup
def test_Semigroup():
    pass


# Generated at 2022-06-26 00:10:37.683911
# Unit test for method __str__ of class One
def test_One___str__():
    int_1 = -11
    one_1 = One(int_1)
    result = one_1.__str__()
    expected = 'One[value=-11]'
    assert (expected == result)



# Generated at 2022-06-26 00:10:39.133914
# Unit test for constructor of class First
def test_First():
    first_0 = First(True)
    assert first_0.value == True


# Generated at 2022-06-26 00:10:42.424388
# Unit test for constructor of class Min
def test_Min():
    min1 = Min(-2029)
    min2 = Min(-400)
    min3 = Min(40)
    min4 = Min(500)

    # assert statements
    assert min1.value == -2029
    assert min2.value == -400
    assert min3.value == 40
    assert min4.value == 500


# Generated at 2022-06-26 00:10:43.158469
# Unit test for method __str__ of class First

# Generated at 2022-06-26 00:10:47.911743
# Unit test for constructor of class Max
def test_Max():
    int_0 = 244
    max_0 = Max(int_0)
    assert max_0.value == 244

# Generated at 2022-06-26 00:10:50.076690
# Unit test for method __str__ of class Min
def test_Min___str__():
    int_0 = -3
    min_0 = Min(int_0)
    assert str(min_0) == 'Min[value=-3]'


# Generated at 2022-06-26 00:10:54.307219
# Unit test for method __str__ of class Map
def test_Map___str__():
    int_0 = -2029
    one_0 = One(int_0)
    # test
    assert str(one_0) == 'One[value=-2029]'



# Generated at 2022-06-26 00:11:04.108628
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = -44569
    max_0 = Max(int_0)
    int_1 = -44556
    max_1 = Max(int_1)
    max_2 = max_0.concat(max_1)
    assert max_2.value == -44556

    int_2 = -44556
    max_3 = Max(int_2)
    max_4 = max_2.concat(max_3)
    assert max_4.value == -44556

    int_3 = -2559
    max_5 = Max(int_3)
    max_6 = max_4.concat(max_5)
    assert max_6.value == -2559

    max_7 = max_6.concat(max_5)
    assert max_7.value == -2559

# Generated at 2022-06-26 00:11:12.703633
# Unit test for constructor of class All
def test_All():
    print("<===Testing All===>")
    print("\n<===Testing Constructor===>")
    print("Test Case 0:")
    test_case_0()
    print("Test Case 1:")
    int_1 = 5
    one_1 = One(int_1)
    print("Test Case 2:")
    input_2 = True
    one_2 = One(input_2)
    print("Test Case 3:")
    input_3 = False
    one_3 = One(input_3)
    print("Test Case 4:")
    input_4 = "ab"
    one_4 = One(input_4)
    print("Test Case 5:")
    input_5 = " "
    one_5 = One(input_5)
    print("\n<===Test Finish===>")



# Generated at 2022-06-26 00:11:14.452712
# Unit test for constructor of class Min
def test_Min():
    int_0 = -2029
    max_0 = Max(int_0)


# Generated at 2022-06-26 00:11:19.770169
# Unit test for method concat of class Last
def test_Last_concat():
    int_0 = -2029
    int_1 = -6
    last_0 = Last(int_0)
    last_1 = Last(int_1)
    last_2 = last_0.concat(last_1)
    assert last_2.value == int_1


# Generated at 2022-06-26 00:11:27.550720
# Unit test for method concat of class Min

# Generated at 2022-06-26 00:11:38.240424
# Unit test for method __str__ of class Max
def test_Max___str__():
    int_0 = -2029
    max_0 = Max(int_0)
    str_0 = 'Max[value=-2029]'
    str_0 = str_0.replace(' ', '')
    str_0 = str_0.replace('\t', '')
    str_0 = str_0.replace('\n', '')
    str_0_actual = str(max_0).replace(' ', '')
    str_0_actual = str_0_actual.replace('\t', '')
    str_0_actual = str_0_actual.replace('\n', '')
    assert str_0_actual == str_0, 'AssertionError'
    str_1 = 'Max[value=0]'
    str_1 = str_1.replace(' ', '')
    str_1 = str_

# Generated at 2022-06-26 00:11:45.809168
# Unit test for method concat of class Last
def test_Last_concat():
    int_0 = -2029
    one_0 = Last(int_0)
    one_1 = Last(int_0)
    one_0.concat(one_1)
    assert one_0 == Last(int_0)



# Generated at 2022-06-26 00:11:59.552360
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    int_0 = -2029
    one_0 = One(int_0)
    str_0 = ' '
    One.neutral(str_0)
    one_0.fold(str_0)
    int_1 = -2029
    One(int_1)
    one_0


# Generated at 2022-06-26 00:12:01.540766
# Unit test for constructor of class Last
def test_Last():
    int_0 = -2029
    last_0 = Last(int_0)
    assert last_0.value == -2029


# Generated at 2022-06-26 00:12:08.571237
# Unit test for method concat of class One
def test_One_concat():
    int_0 = int('-1')
    float_0 = float('-1.0')
    one_0 = One(int_0)
    one_1 = One(float_0)
    one_2 = one_0.concat(one_1)
    assert one_0.value == int_0
    assert one_1.value == float_0
    assert one_2.value == float_0



# Generated at 2022-06-26 00:12:20.509367
# Unit test for method concat of class Last
def test_Last_concat():
    """
    :return: {void}
    :raises: {AssertionError}
    """
    int_0 = -2029
    one_0 = One(int_0)
    str_0 = 'a'
    last_0 = Last(str_0)
    str_1 = 'd'
    one_1 = One(str_1)
    str_2 = 'Last.concat(One) did not return the expected value'
    assert last_0.concat(one_1) == one_0, str_2
    str_1 = 'a'
    last_0 = Last(str_1)
    str_2 = 'Last.concat(First) did not return the expected value'
    assert last_0.concat(one_0) == one_1, str_2
    str_

# Generated at 2022-06-26 00:12:23.241772
# Unit test for method __str__ of class One
def test_One___str__():
    int_0 = One(42)
    str_0 = str(int_0)
    map_0 = Map({int_0: First('hey')})
    str_1 = str(map_0)


# Generated at 2022-06-26 00:12:24.382039
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(0)) == 'Fist[value=0]'


# Generated at 2022-06-26 00:12:26.656625
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)



# Generated at 2022-06-26 00:12:28.083085
# Unit test for constructor of class First
def test_First():
    int_1 = -4278
    first_0 = First(int_1)


# Generated at 2022-06-26 00:12:30.000664
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)



# Generated at 2022-06-26 00:12:37.229654
# Unit test for method concat of class One
def test_One_concat():
    int_0 = -2029
    int_1 = -2079
    one_0 = One(int_0)
    one_1 = One(int_1)
    one_2 = one_0.concat(one_1)
    int_2 = one_2.value
    int_3 = 0
    if (int_0 == 0):
        int_3 = int_1
    else:
        if (int_1 == 0):
            int_3 = int_0
        else:
            int_3 = int_0
    if (int_3 != int_2):
        return False

    return True


# Generated at 2022-06-26 00:12:58.055047
# Unit test for method concat of class Max
def test_Max_concat():
    float_0 = float("inf")
    float_1 = float("inf")
    float_2 = float(float_1)
    float_3 = float(float_2)
    float_4 = float(float_3)
    float_5 = float(float_4)
    float_6 = float(float_5)
    float_7 = float(float_6)
    float_8 = float(float_7)
    float_9 = float(float_8)
    float_10 = float(float_9)
    float_11 = float(float_10)
    float_12 = float(float_11)
    float_13 = float(float_12)
    float_14 = float(float_13)
    float_15 = float(float_14)
    float_16 = float(float_15)

# Generated at 2022-06-26 00:13:00.784607
# Unit test for constructor of class One
def test_One():
    print()
    print("test_One")
    int_0 = -2029
    one_0 = One(int_0)
    assert one_0.value == int_0, '_concat = %s' % (one_0)



# Generated at 2022-06-26 00:13:03.858471
# Unit test for method concat of class Sum
def test_Sum_concat():
    int_0 = Sum(1)
    int_1 = Sum(2)
    assert int_0.concat(int_1) == Sum(3)
    assert int_0.concat(int_1.concat(int_1)) == Sum(4)



# Generated at 2022-06-26 00:13:06.246371
# Unit test for method concat of class First
def test_First_concat():
    first_0 = First(0)
    first_1 = First(1)
    result = first_0.concat(first_1)
    assert First(0) == result


# Generated at 2022-06-26 00:13:15.189166
# Unit test for method __str__ of class Max
def test_Max___str__():
    arg0 = -6904
    arg1 = -2029
    obj0 = Max(arg0)
    obj1 = Max(arg1)
    obj1.value = arg0
    obj2 = Max(arg0)
    obj2.value = arg1
    strcomp0 = "Max[value=%d]"
    strcomp1 = "Max[value=%d]"
    str0 = obj0.__str__()
    str1 = obj1.__str__()
    str2 = obj2.__str__()
    assert str0 == strcomp0 % arg0
    assert str1 == strcomp1 % arg1
    assert str2 == strcomp0 % arg1


# Generated at 2022-06-26 00:13:17.742620
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    int_0 = -2029
    one_0 = One(int_0)
    semigroup_0 = Semigroup(int_0)
    assert semigroup_0 == one_0


# Generated at 2022-06-26 00:13:18.566642
# Unit test for constructor of class Sum
def test_Sum():
    sum_0 = Sum(1)


# Generated at 2022-06-26 00:13:21.572472
# Unit test for method __str__ of class First
def test_First___str__():
    value_0: int = aslkdjsakldj
    expected_0: str = 'First[value={}]'.format(value_0)
    first_0 = First(value_0)
    actual_0: str = first_0.__str__()


# Generated at 2022-06-26 00:13:29.382654
# Unit test for constructor of class Map
def test_Map():
    int_0 = -2029
    one_0 = One(int_0)
    int_1 = -28
    one_1 = One(int_1)
    int_2 = -32
    one_2 = One(int_2)
    int_3 = -21
    one_3 = One(int_3)
    int_4 = 20
    one_4 = One(int_4)
    int_5 = -17
    one_5 = One(int_5)
    map_0 = Map({'0': one_0, '1': one_1, '2': one_2, '3': one_3, '4': one_4, '5': one_5})
    int_6 = -23
    one_6 = One(int_6)
    int_7 = -24
   

# Generated at 2022-06-26 00:13:31.856613
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    int_0 = 1
    sum_0 = Sum(int_0)
    assert str(sum_0) == 'Sum[value={}]'.format(int_0)


# Generated at 2022-06-26 00:14:10.520259
# Unit test for method concat of class One
def test_One_concat():
    int_0 = 0
    one_0 = One(int_0)
    int_1 = -1847
    one_1 = One(int_1)
    one_result = one_0.concat(one_1)
    assert(int_0 == one_result.value)

    # test
    test_case_0()

    # Example
    int_0 = 0
    one_0 = One(int_0)
    int_1 = -1847
    one_1 = One(int_1)
    one_result = one_0.concat(one_1)
    assert(int_0 == one_result.value)
    int_0 = 2
    one_0 = One(int_0)
    int_1 = -2029
    one_1 = One(int_1)
   

# Generated at 2022-06-26 00:14:13.508781
# Unit test for constructor of class All
def test_All():
    int_0 = -2029
    all_0 = All(int_0)
    assert all_0.value == int_0


# Generated at 2022-06-26 00:14:18.254651
# Unit test for constructor of class Min
def test_Min():
    int_0 = -2029
    Min_0 = Min(int_0)
    str_0 = Min_0.__str__()
    if (str_0 != "Min[value=-2029]"):
        raise ValueError("")


# Generated at 2022-06-26 00:14:19.615859
# Unit test for constructor of class One
def test_One():
    int_0 = -2029
    one_0 = One(int_0)


# Generated at 2022-06-26 00:14:21.237881
# Unit test for constructor of class Map
def test_Map():
    test_map = Map({
        "key0": Sum(100),
        "key1": All(True)
    })


# Generated at 2022-06-26 00:14:33.727835
# Unit test for method concat of class Map
def test_Map_concat():
    int_0 = -2029
    one_0 = One(int_0)
    int_1 = -2029
    one_1 = One(int_1)

    # Substitution site.
    map_concat_0 = {'0': one_0, '1': one_1}
    int_2 = -2029
    one_2 = One(int_2)
    int_3 = -2029
    one_3 = One(int_3)

    # call to concat
    map_0 = Map(map_concat_0)
    map_1 = Map({'0': one_2, '1': one_3})
    map_concat_0_out = map_0.concat(map_1)


# Generated at 2022-06-26 00:14:36.160825
# Unit test for constructor of class Min
def test_Min():
    int_0 = -2029
    min_0 = Min(int_0)
    assert min_0.__eq__(Min(min_0.value))
    assert min_0.value == int_0

# Generated at 2022-06-26 00:14:39.888626
# Unit test for method concat of class All
def test_All_concat():
    """Check the results of method concat of class All"""
    #
    int_0 = -2029
    one_0 = All(int_0)
    #
    int_1 = 8165
    one_1 = All(int_1)
    #
    int_res = int_1
    one_res = one_0.concat(one_1)
    #
    assert one_res.value == int_res


# Generated at 2022-06-26 00:14:45.398578
# Unit test for method concat of class One
def test_One_concat():
    int_0 = -2029
    one_0 = One(int_0)
    int_1 = -1865
    one_1 = One(int_1)
    one_2 = one_1.concat(one_0)
    assert(str(one_2) == "One[value=-2029]")


# Generated at 2022-06-26 00:14:49.695053
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    int_0 = -2029
    sum_0 = Sum(int_0)

    result_str = str(sum_0)

    assert result_str == 'Sum[value={}]'.format(int_0)

