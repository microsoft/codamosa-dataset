

# Generated at 2022-06-26 00:05:49.680767
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(10).concat(Max(9)).value == 10



# Generated at 2022-06-26 00:05:53.285427
# Unit test for method concat of class Max
def test_Max_concat():
    
    # Given
    Max_0 = Max(1)
    Max_1 = Max(2)
    # When
    Max_2 = Max_0.concat(Max_1)
    # Then
    assert(Max_2.value == 2)


# Generated at 2022-06-26 00:05:58.552926
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(12).concat(Max(14)) == Max(14)
    assert Max(0).concat(Max(-1)) == Max(0)
    assert Max(-12).concat(Max(-29)) == Max(-12)
    assert Max(-12).concat(Max(-14)) == Max(-12)
    assert Max(-12.5).concat(Max(-14)) == Max(-12.5)


# Generated at 2022-06-26 00:06:04.450145
# Unit test for method concat of class Min
def test_Min_concat():
    min0 = Min(10)
    min1 = Min(20)
    min2 = Min(5)
    min3 = Min(100)
    min4 = Min(80)
    min5 = Min(10)
    assert min0.concat(min1) == Min(10)
    assert min0.concat(min2) == Min(5)
    assert min2.concat(min1) == Min(5)
    assert min4.concat(min3) == Min(80)
    assert min4.concat(min5) == Min(10)
    assert min5.concat(min4) == Min(10)
    assert min5.concat(min5) == Min(10)




# Generated at 2022-06-26 00:06:06.303959
# Unit test for method concat of class Max
def test_Max_concat():
    assert(Max(1).concat(Max(3)) == Max(3))


# Generated at 2022-06-26 00:06:09.185496
# Unit test for method concat of class Map
def test_Map_concat():
    list_0 = []
    map_0 = Map(list_0)
    map_0_0 = Map(list_0)
    map_0.concat(map_0_0)


# Generated at 2022-06-26 00:06:15.045757
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min(10)
    min_1 = Min(20)
    min_2 = min_0.concat(min_1)
    assert isinstance(min_2, Min)
    assert min_1.value == 20
    assert min_2.value == 10


# Generated at 2022-06-26 00:06:17.882574
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(1).concat(Max(-1)) == Max(1)


# Generated at 2022-06-26 00:06:21.119720
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(float("inf")) == Min(1).concat(Min(2))
    assert Min(float("inf")) == Min(float("inf")).concat(Min(2))
    assert Min(float("inf")) == Min(float("inf")).concat(Min(float("inf")))


# Generated at 2022-06-26 00:06:27.067710
# Unit test for method concat of class Map
def test_Map_concat():
    obj0 = {"val": Sum(3)}
    obj1 = {"val": Sum(4)}
    map0 = Map(obj0)
    map1 = Map(obj1)
    result = map0.concat(map1)
    assert result.value == {"val": Sum(7)}, f"{result.value}"


# Generated at 2022-06-26 00:06:31.257281
# Unit test for method __str__ of class Last
def test_Last___str__():
    last_0 = Last(sum([20]))
    str_0 = str(last_0)
    assert str_0 == 'Last[value=20]'



# Generated at 2022-06-26 00:06:40.586639
# Unit test for method __str__ of class Min
def test_Min___str__():
    min_0 = Min(4)
    min_0_str = 'Min[value=4]'
    assert str(min_0) == min_0_str

if __name__ == '__main__':
    # Unit test for method __str__ of class Sum
    test_Sum___str__()

    # Unit test for method __str__ of class All
    test_All___str__()
    test_case_0()

    # Unit test for method __str__ of class One
    test_One___str__()

    # Unit test for method __str__ of class First
    test_First___str__()

    # Unit test for method __str__ of class Last
    test_Last___str__()

    # Unit test for method __str__ of class Map
    test_Map___str__()

    # Unit test for method __

# Generated at 2022-06-26 00:06:42.583927
# Unit test for constructor of class First
def test_First():
    assert First(0) == First(First(0))


# Generated at 2022-06-26 00:06:44.338726
# Unit test for method __str__ of class First
def test_First___str__():
    first = First(4)
    assert str(first) == "Fist[value=4]"



# Generated at 2022-06-26 00:06:46.629140
# Unit test for method __str__ of class Max
def test_Max___str__():
    try:
        obj = Max(0)
        str_ = str(obj)
    except Exception as e:
        return False
    else:
        return True

# Generated at 2022-06-26 00:06:51.774314
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    Test for method concat
    """
    sum_0 = Sum(1)
    sum_1 = Sum(2)
    print(sum_1)
    print(sum_0)
    print(sum_0.concat(sum_1))
    assert sum_0.concat(sum_1) == Sum(3)


# Generated at 2022-06-26 00:06:54.091484
# Unit test for constructor of class First
def test_First():
    # Test constructor
    value = [1,2,3]
    first = First(value)
    assert first.value == value


# Generated at 2022-06-26 00:07:01.362736
# Unit test for method concat of class Sum
def test_Sum_concat():
    list_0 = [1, 2, 3, 4]
    list_1 = [5, 6, 7, 8]
    list_2 = [9, 10, 11, 12]

    sum_0 = Sum(list_0)
    sum_1 = Sum(list_1)
    sum_2 = Sum(list_2)

    assert sum_0.concat(sum_1).concat(sum_2).value == sum_0.concat(sum_1.concat(sum_2)).value


# Generated at 2022-06-26 00:07:06.931559
# Unit test for method concat of class One
def test_One_concat():
    ones = [One(False), One(False), One(False), One(False)]
    monoid_0 = reduce(lambda x, y: x.concat(y), ones)
    assert monoid_0 == ones[0]
    ones = [One(False), One(False), One(False), One(True)]
    monoid_0 = reduce(lambda x, y: x.concat(y), ones)
    assert monoid_0 == ones[3]


# Generated at 2022-06-26 00:07:09.602839
# Unit test for constructor of class Last
def test_Last():
    """
    The function test_Last() is used to unit test the constructor of
    class Last.

    :return: True if the test passes.
    :rtype: bool
    """
    assert Last([]) is not None



# Generated at 2022-06-26 00:07:12.919146
# Unit test for constructor of class Min
def test_Min():
    assert str(Min(2)) == "Min[value=2]"


# Generated at 2022-06-26 00:07:16.316813
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First('hello')) == 'Fist[value=hello]'
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First(None)) == 'Fist[value=None]'


# Generated at 2022-06-26 00:07:24.720384
# Unit test for constructor of class One
def test_One():
    one_0 = One(False)
    one_2 = One(True)
    one_3 = One(1)
    assert one_0 == One.neutral()
    assert one_2 != one_0
    assert one_3 != one_0


# Generated at 2022-06-26 00:07:26.057756
# Unit test for constructor of class Last
def test_Last():
    l = Last(1)
    assert l.value == 1



# Generated at 2022-06-26 00:07:29.474804
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == "Max[value=1]"
    assert str(Max(2)) == "Max[value=2]"
    assert str(Max(3)) == "Max[value=3]"


# Generated at 2022-06-26 00:07:34.291502
# Unit test for constructor of class Max
def test_Max():
    assert Max(5).value == 5


# Generated at 2022-06-26 00:07:36.395080
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(5).concat(Min(2)) == Min(2)


# Generated at 2022-06-26 00:07:41.146279
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({'a': Sum(1), 'b': Sum(2)})
    m2 = Map({'a': Sum(10), 'b': Sum(20)})
    assert (m1.concat(m2).value['a'].value == 11)
    assert (m1.concat(m2).value['b'].value == 22)


# Generated at 2022-06-26 00:07:42.822048
# Unit test for constructor of class Max
def test_Max():
    list_test = [1,2,3]
    max_test = Max(list_test)


# Generated at 2022-06-26 00:07:47.803198
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum0 = Sum(0)
    sum1 = Sum(1)
    sum2 = Sum(2)
    sum5 = Sum(5)
    assert sum0.concat(sum1).value == 1
    assert sum1.concat(sum2).value == 3
    assert sum1.concat(sum5).value == 6

#  Unit test for method concat of class All

# Generated at 2022-06-26 00:07:53.277807
# Unit test for constructor of class Min
def test_Min():
    assert Min(3) == Min(3)
    assert Min(3).value == 3
    assert Min(3).fold(lambda x: x) == 3

# Test for concat of class Min

# Generated at 2022-06-26 00:07:54.517940
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-26 00:08:04.883863
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    Test Sum class method concat
    """

    # Test case 1
    list_1 = [1, 2, 3, 4]
    sum_1 = Sum(list_1)

    list_2 = [2, 3, 4, 5]
    sum_2 = Sum(list_2)

    assert(sum_1.concat(sum_2).value == 20)

    # Test case 2
    list_1 = [1, 2]
    sum_1 = Sum(list_1)

    list_2 = [2, 3]
    sum_2 = Sum(list_2)

    assert(sum_1.concat(sum_2).value == 9)

    # Test case 3
    list_1 = []
    sum_1 = Sum(list_1)

    list_2 = [2, 3]

# Generated at 2022-06-26 00:08:12.551293
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    sum_0 = Sum(10)
    assert sum_0.fold(lambda x: x * 3) == 30
    assert sum_0.fold(lambda x: x - 2) == 8
    assert sum_0.fold(lambda x: x + 5) == 15
    assert First(10).fold(lambda x: x + 2) == 12
    assert Last(10).fold(lambda x: x - 2) == 8
    assert All(True).fold(lambda x: x and True) == True
    assert One(False).fold(lambda x: x or False) == False
    assert Max(10).fold(lambda x: x + 2) == 12
    assert Min(10).fold(lambda x: x - 2) == 8


# Generated at 2022-06-26 00:08:14.075021
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).fold(lambda x: x) == 1


# Generated at 2022-06-26 00:08:17.896936
# Unit test for method concat of class Sum
def test_Sum_concat():

    sum1: Sum = Sum(1)
    sum2: Sum = Sum(2)

    # Assert that sum1.concat(sum2) == Sum(3)
    assert sum1.concat(sum2) == Sum(3), "Sum is not concating correctly"



# Generated at 2022-06-26 00:08:26.910112
# Unit test for method __str__ of class One
def test_One___str__():
    # Test case 0
    list_0 = [4, 4, 5, 3, 3]
    one_0 = One(list_0)
    assert str(one_0) == "One[value=[4, 4, 5, 3, 3]]", str(one_0)
    # Test case 1
    list_0 = [False, 7, 2, '*x']
    one_0 = One(list_0)
    assert str(one_0) == "One[value=[False, 7, 2, '*x']]", str(one_0)
    # Test case 2
    list_0 = []
    one_0 = One(list_0)
    assert str(one_0) == "One[value=[]]", str(one_0)
    # Test case 3
    list_0 = []
    one_

# Generated at 2022-06-26 00:08:31.424347
# Unit test for method concat of class First
def test_First_concat():
    assert First('E').concat(First('A')).value == 'A'
    assert First(None).concat(First('A')).value == None
    assert First('A').concat(First(None)).value == 'A'
    assert First(None).concat(First(None)).value == None
    assert First('E').concat(First('A')).concat(First('X')).value == 'A'


# Generated at 2022-06-26 00:08:33.109488
# Unit test for constructor of class Semigroup
def test_Semigroup():
    unittest.main(argv=[''], verbosity=2, exit=False)


# Generated at 2022-06-26 00:08:36.739083
# Unit test for method concat of class First
def test_First_concat():
    first_A = First("A")
    first_B = First("B")
    assert first_A.concat(first_B).value == "A"



# Generated at 2022-06-26 00:08:42.173131
# Unit test for constructor of class Semigroup
def test_Semigroup():
    #assert Sum(0) == Semigroup in Sum
    assert Sum(0) == Sum(0)
    assert Sum(0).value == 0
    assert Semigroup(0) == Sum(0)



# Generated at 2022-06-26 00:08:44.128002
# Unit test for constructor of class Min
def test_Min():
    assert Min(1).__class__ == Min
    assert Min(1).value == 1


# Generated at 2022-06-26 00:08:47.009391
# Unit test for method __str__ of class Min
def test_Min___str__():
    list_0 = []
    sum_0 = Sum(list_0)
    min_0 = Min(sum_0.value)
    assert str(min_0) == str(Min(list_0))


# Generated at 2022-06-26 00:08:48.264185
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)).value == 3


# Generated at 2022-06-26 00:08:49.142212
# Unit test for constructor of class Last
def test_Last():
    last_0 = Last(10)
    assert last_0 != Last(11)


# Generated at 2022-06-26 00:08:51.879766
# Unit test for constructor of class Last
def test_Last():
    print("Unit test for class Last")
    try:
        test_case_0()
        print("Test 0: OK")
    except AssertionError as e:
        print("Test 0: FAIL")
        print(e)
    print ("Test of class Last is done")

test_Last()

# Generated at 2022-06-26 00:08:55.040624
# Unit test for method __str__ of class Last
def test_Last___str__():
    list_0 = {'abc', 'abc', 'abc'}
    value_0 = str(Last(list_0))
    assert value_0 == 'Last[value={abc}]'


# Generated at 2022-06-26 00:09:03.250976
# Unit test for method concat of class Map
def test_Map_concat():
    # type: () -> None
    dict_0 = {'first': Sum(0),'second': Sum(1)}
    map_0 = Map(dict_0)
    dict_1 = {'first': Sum(0),'second': Sum(1)}
    map_1 = Map(dict_1)
    map_2 = map_0.concat(map_1)
    test_0 = map_2.value['first'].value == 0
    test_1 = map_2.value['second'].value == 2
    assert all([test_0, test_1])


# Generated at 2022-06-26 00:09:05.791181
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1
    assert First(2).value == 2
    assert First("1").value == "1"
    print("Unit test for constructor of class First - PASS")


# Generated at 2022-06-26 00:09:08.562583
# Unit test for constructor of class Map
def test_Map():
    Map_0 = Map({1:Sum(1), 2:Sum(2)})
    assert(Map_0.fold(lambda x:x) == {1:Sum(1), 2:Sum(2)})


# Generated at 2022-06-26 00:09:16.107015
# Unit test for constructor of class Semigroup
def test_Semigroup():
    list_0 = []
    sum_0 = Sum(list_0)
    assert sum_0.value is list_0



# Generated at 2022-06-26 00:09:24.912803
# Unit test for method concat of class Map
def test_Map_concat():
    """
    Test concat method of class Map
    """
    # assertions
    assert Map({}).concat(Map({})) == Map({})
    assert Map({'key_0': First(1)}).concat(Map({'key_0': First(2)})) == Map({'key_0': First(1)})
    assert Map({'key_0': Last(1)}).concat(Map({'key_0': Last(2)})) == Map({'key_0': Last(2)})
    assert Map({'key_0': Sum(0)}).concat(Map({'key_0': Sum(0)})) == Map({'key_0': Sum(0)})

# Generated at 2022-06-26 00:09:27.720627
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)
    assert Min(2) == Min(2)
    assert Min(1) != Min(2)
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-26 00:09:30.449136
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    list_0 = []
    sum_0 = Sum(list_0)
    result = str(sum_0)
    assert result == 'Sum[value=0]'


# Generated at 2022-06-26 00:09:32.371124
# Unit test for constructor of class Last
def test_Last():
    last_0 = Last(0)
    assert last_0.value == 0


# Generated at 2022-06-26 00:09:33.628246
# Unit test for constructor of class First
def test_First():
    assert First(1).fold(lambda x: x) == 1

# Generated at 2022-06-26 00:09:36.422792
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({"hello": Sum(3), "olleh": Sum(4)})) == "Map[value={'hello': Sum[value=3], 'olleh': Sum[value=4]}]"


# Generated at 2022-06-26 00:09:39.183045
# Unit test for method concat of class Max
def test_Max_concat():
    max_0 = Max(87)
    max_1 = Max(81)
    max_2 = max_0.concat(max_1)
    assert max_2.value == 87


# Generated at 2022-06-26 00:09:41.914635
# Unit test for method __str__ of class Last
def test_Last___str__():
    list_0 = []
    last_0 = Last(list_0)
    # assert last_0.__str__() == 'Last[value=<class \'list\'>]'
    print(last_0.__str__())


# Generated at 2022-06-26 00:09:44.671075
# Unit test for method __str__ of class One
def test_One___str__():
    one_0 = One(True)
    assert one_0.__str__() == 'One[value=True]'


# Generated at 2022-06-26 00:09:57.400789
# Unit test for method __str__ of class All
def test_All___str__():
    all_0 = All(True)
    all_1 = All(False)
    all_0_sum = all_0.__str__()
    all_1_sum = all_1.__str__()
    if all_0_sum != 'All[value=True]':
        print("All___str__: failed")
    elif all_1_sum != 'All[value=False]':
        print("All___str__: failed")
    else:
        print("All___str__: passed")


# Generated at 2022-06-26 00:09:58.897631
# Unit test for method __str__ of class Min
def test_Min___str__():
    neutral = Min.neutral()
    Min_str = str(Min(1))
    assert(Min_str == 'Min[value=1]')



# Generated at 2022-06-26 00:10:00.416939
# Unit test for method __str__ of class One
def test_One___str__():
    _one = One("one")
    _str = str(_one)
    assert _str == 'One[value=one]'


# Generated at 2022-06-26 00:10:02.789187
# Unit test for method __str__ of class First
def test_First___str__():
    list_0 = []
    obj_0 = First(list_0)
    assert obj_0.__str__() == "Fist[value=[]]", "__str__ method is wrong"


# Generated at 2022-06-26 00:10:04.883395
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(0).value == 0
    assert Sum(1).value == 1
    assert Sum(-1).value == -1
    assert Sum(10000).value == 10000


# Generated at 2022-06-26 00:10:06.574770
# Unit test for constructor of class Semigroup
def test_Semigroup():
    test_case_0()
    assert True


# Generated at 2022-06-26 00:10:08.429737
# Unit test for constructor of class Max
def test_Max():
    """
     Test Max class constructor
     """
    test_Max = Max(64)
    assert(test_Max.value == 64)

# Generated at 2022-06-26 00:10:12.604313
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(10)) == Max(10)
    assert Max(10).concat(Max(5)) == Max(10)
    assert Max(5).concat(Max(5)) == Max(5)


# Generated at 2022-06-26 00:10:13.946227
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(10)) == "Max[value=10]"



# Generated at 2022-06-26 00:10:15.276458
# Unit test for constructor of class Max
def test_Max():
    assert type(Max(1)) is Max


# Generated at 2022-06-26 00:10:22.373287
# Unit test for method __str__ of class All
def test_All___str__():
    assert All(False).__str__() == "All[value=False]" 


# Generated at 2022-06-26 00:10:23.214132
# Unit test for constructor of class Min
def test_Min():
    min_0 = Min(0)



# Generated at 2022-06-26 00:10:25.117345
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(0)) == "Min[value=0]"

# Generated at 2022-06-26 00:10:32.179907
# Unit test for constructor of class Semigroup
def test_Semigroup():
    list_0 = [1, 2, 1, 10, 2, 4, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    sum_0 = Sum(list_0)

    # Test folded function
    assert sum_0.fold(sum) == sum_0.value

    # Test neutral element
    assert sum_0.fold(Sum.neutral) == Sum.neutral_element



# Generated at 2022-06-26 00:10:34.985945
# Unit test for method __str__ of class First
def test_First___str__():
    list_0 = []
    fist_0 = First(list_0)
    assert str(fist_0) == "Fist[value=[]]"



# Generated at 2022-06-26 00:10:37.921926
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    print("\n- test_Semigroup_fold")
    sum_0 = Sum(10)
    assert sum_0.fold(str) == "10"
    print(">> OK")


# Generated at 2022-06-26 00:10:39.669774
# Unit test for constructor of class All
def test_All():
    list_0 = [True, True, True]
    all_0 = All(list_0)

    assert all_0 is not None


# Generated at 2022-06-26 00:10:47.660031
# Unit test for method __str__ of class Last
def test_Last___str__():
    list_0 = [5,8,3,5,5,7,5,6,5,6,5,1,5,7,5,1,5,8,5,6,5,7,5,6,5,8,5,6,5]
    list_1 = iter(list_0)
    sum_0 = Last(0)
    for i_0 in range(0, 27):
        sum_0 = sum_0.concat(Last(next(list_1)))
    assert str(sum_0) == "[value=5]"


# Generated at 2022-06-26 00:10:49.847004
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_0 = Sum(0)
    sum_1 = Sum(1)
    assert sum_0.concat(sum_1) == Sum(1)


# Generated at 2022-06-26 00:10:55.506829
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)
    assert Sum([1, 2]).concat(Sum([3, 4])) == Sum([1, 2, 3, 4])


# Generated at 2022-06-26 00:11:04.171018
# Unit test for constructor of class Max
def test_Max():
    max_0 = Max(0)
    if not max_0.concat(max_0):
        raise TypeError('Max.__init__() test failed')
    else:
        return True


# Generated at 2022-06-26 00:11:07.026532
# Unit test for method __str__ of class All
def test_All___str__():
    all_0 = All(False)
    s_0 = str(all_0)
    assert s_0 == 'All[value=False]', "Expected: All[value=False] Received: %s" % s_0


# Generated at 2022-06-26 00:11:11.467025
# Unit test for method __str__ of class Last
def test_Last___str__():
    value = None
    last_0 = Last(value)
    last_0_str = str(last_0)
    value = ""
    last_1 = Last(value)
    last_1_str = str(last_1)
    value = 1
    last_2 = Last(value)
    last_2_str = str(last_2)


# Generated at 2022-06-26 00:11:13.498349
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    sum_0 = Sum(0)
    sum_1 = sum_0.fold(lambda x: x + 1)
    return sum_1.value == 1


# Generated at 2022-06-26 00:11:17.840229
# Unit test for constructor of class One
def test_One():
    one1 = One(True)
    assert(one1.value == True)
    one2 = One(False)
    assert(one2.value == False)


# Generated at 2022-06-26 00:11:19.656863
# Unit test for constructor of class Map
def test_Map():
    list_0 = []
    map_0 = Map(list_0)
    assert isinstance(map_0, Map)


# Generated at 2022-06-26 00:11:22.489956
# Unit test for constructor of class Last
def test_Last():
    a = Last(0)
    assert a.value == 0
    assert a.concat(Last(1)) == Last(1)
    assert a.concat(Last(2)) == Last(2)


# Generated at 2022-06-26 00:11:24.075020
# Unit test for method __str__ of class All
def test_All___str__():
    a = All(True)
    assert str(a) == 'All[value=True]'


# Generated at 2022-06-26 00:11:29.792349
# Unit test for method concat of class Sum
def test_Sum_concat():
    list_0 = [9, -1, 9, 6, -5, -2, -5, -2, 9, -5, -4]
    list_1 = [4, -7, -10, -10, -8, -1, 9, -4, 8, -10, -9]
    list_2 = [6, -4, -7, -2, -2, 2, -3, 2, -9, 1, -3]

    sum_0 = Sum(list_0)
    sum_1 = Sum(list_1)
    sum_2 = Sum(list_2)

    sum_3 = sum_0.concat(sum_1)
    sum_4 = sum_1.concat(sum_2)
    sum_5 = sum_2.concat(sum_0)

    assert sum

# Generated at 2022-06-26 00:11:31.879009
# Unit test for constructor of class All
def test_All():
    x = All(False)
    assert x.value == False
    assert isinstance(x, All)
    assert x.__class__ == All


# Generated at 2022-06-26 00:11:43.308603
# Unit test for constructor of class One
def test_One():
    one_init = One(False)
    assert one_init.value is False


# Generated at 2022-06-26 00:11:46.625263
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    list_0 = [1,2,3]
    sum_0 = Sum(list_0)
    assert sum_0.fold(lambda x: x) == list_0



# Generated at 2022-06-26 00:11:47.766823
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-26 00:11:50.947895
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    # assert Semigroup(2)['test'] == 2
    assert Semigroup(1)['test'] == 1


# Generated at 2022-06-26 00:11:56.006550
# Unit test for method concat of class Max
def test_Max_concat():
    max_0 = Max(2).concat(Max(3))
    max_1 = Max(4).concat(Max(4))
    max_2 = Max(4).concat(Max(1))
    max_3 = Max(3.3).concat(Max(3.3333))
    max_4 = Max(3.3).concat(Max(3))

    assert max_0.value == 3
    assert max_1.value == 4
    assert max_2.value == 4
    assert max_3.value == 3.3333
    assert max_4.value == 3.3


# Generated at 2022-06-26 00:12:06.399942
# Unit test for method __str__ of class One
def test_One___str__():
    one_0 = One(False)
    one_1 = One(True)
    one_2 = One(False)
    one_3 = One(False)
    one_4 = One(True)
    one_5 = One(True)
    one_6 = One(False)
    one_7 = One(False)
    one_8 = One(True)
    one_9 = One(False)
    one_10 = One(True)
    one_11 = one_5.concat(one_4)
    one_12 = one_11.concat(one_9)
    one_13 = one_12.concat(one_6)
    one_14 = one_13.concat(one_2)
    assert isinstance(one_14, One)

# Generated at 2022-06-26 00:12:09.862426
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(7).concat(Max(8)) == Max(8)


# Generated at 2022-06-26 00:12:11.080669
# Unit test for constructor of class All
def test_All():
    assert All.neutral() == All(True)


# Generated at 2022-06-26 00:12:15.571407
# Unit test for method concat of class Last
def test_Last_concat():
    last_0 = Last(object())
    last_1 = Last(object())
    last_2 = last_0.concat(last_1)
    assert isinstance(last_2, Last)
    assert last_2.value is last_1.value



# Generated at 2022-06-26 00:12:16.598183
# Unit test for constructor of class One
def test_One():
    assert One(1).value == 1


# Generated at 2022-06-26 00:12:26.811324
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    list_0 = [1, 2, 3]
    sum_0 = Sum(list_0)
    assert sum_0.__str__() == "Sum[value=[1, 2, 3]]"
    assert type(sum_0.__str__()) == str


# Generated at 2022-06-26 00:12:29.279880
# Unit test for constructor of class Last
def test_Last():
    instance_Last = Last(1)
    print("instance_Last is " + str(instance_Last))
    assert str(instance_Last) == "Last[value=1]"


# Generated at 2022-06-26 00:12:30.622759
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last('value')) == 'Last[value=value]'


# Generated at 2022-06-26 00:12:35.916545
# Unit test for method concat of class Max
def test_Max_concat():
    import math
    sum_max_1 = Max(4).concat(Max(6))
    assert sum_max_1.value == 6
    sum_max_2 = Max(math.inf).concat(Max(6))
    assert sum_max_2.value == math.inf
    sum_max_3 = Max(-math.inf).concat(Max(6))
    assert sum_max_3.value == 6



# Generated at 2022-06-26 00:12:37.151616
# Unit test for constructor of class One
def test_One():
    valueDict = dict()
    One(valueDict)
    

# Generated at 2022-06-26 00:12:38.820992
# Unit test for constructor of class Min
def test_Min():
    min = Min(1)
    assert min.value == 1 and min.neutral_element == float("inf")



# Generated at 2022-06-26 00:12:42.219757
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]', 'Last.__str__() not equals to expected value'



# Generated at 2022-06-26 00:12:43.713210
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)


# Generated at 2022-06-26 00:12:45.023611
# Unit test for constructor of class First
def test_First():
    res = First("a")
    assert res.value == "a"


# Generated at 2022-06-26 00:12:49.717388
# Unit test for method concat of class Max
def test_Max_concat():
    max_0 = Max(0)
    max_1 = Max(1)
    assert max_0.concat(max_1).value == 1
    assert max_1.concat(max_1).value == 1
    assert max_0.concat(max_0).value == 0


if __name__ == '__main__':
    test_case_0()
    test_Max_concat()

# Generated at 2022-06-26 00:12:59.856307
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum0 = Sum(1)
    sum1 = Sum(2)
    assert sum0.concat(sum1) == Sum(3)
    assert sum1.concat(sum0) == Sum(3)
    assert sum0 == Sum(1)
    assert sum1 == Sum(2)


# Generated at 2022-06-26 00:13:02.181875
# Unit test for method concat of class First
def test_First_concat():
    First_0 = First(1)
    First_1 = First(2)
    First_2 = First_0.concat(First_1)
    assert First_2.value == 1


# Generated at 2022-06-26 00:13:08.726456
# Unit test for constructor of class One
def test_One():
    list_0 = []
    one_0 = One(list_0)
    list_1 = [False]
    one_1 = One(list_1)
    list_2 = [False, True]
    one_2 = One(list_2)
    list_3 = [False, True, True]
    one_3 = One(list_3)
    assert one_0.value is False
    assert one_1.value is False
    assert one_2.value is True
    assert one_3.value is True

# Generated at 2022-06-26 00:13:10.514458
# Unit test for constructor of class Last
def test_Last():
    # Create variable to test class Last constructor
    value = Last(2)
    # check if variable has value
    assert (value != None)


# Generated at 2022-06-26 00:13:15.959027
# Unit test for constructor of class Min
def test_Min():
    # Instance by init
    min_1 = Min(5)
    min_2 = Min(2)
    min_3 = min_1.concat(min_2)
    assert min_3.value == 2

    # Instance by class method
    min_4 = Min.neutral()
    min_5 = min_4.concat(min_3)
    assert min_5.value == 2


# Generated at 2022-06-26 00:13:22.851625
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    list_0 = []
    sum_0 = Sum(list_0)
    assert sum_0.fold(lambda x: x * 2) == 0

    list_0 = [1, 2, 3, 4]
    sum_0 = Sum(list_0)
    assert sum_0.fold(lambda x: x * 2) == 20

    list_0 = {'a': Sum(1), 'b': Sum(2), 'c': Sum(3), 'd': Sum(4)}
    sum_0 = Map(list_0)
    assert sum_0.fold(lambda x: x * 2) == {
        'a': 2, 'b': 4, 'c': 6, 'd': 8
    }


# Generated at 2022-06-26 00:13:24.326131
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1).value == 1
    assert Sum(1) != Sum(2)


# Generated at 2022-06-26 00:13:26.878506
# Unit test for method __str__ of class Last
def test_Last___str__():
    last_0 = Last(3)
    assert str(last_0) == 'Last[value=3]'


# Generated at 2022-06-26 00:13:30.985942
# Unit test for method __str__ of class Map
def test_Map___str__():
    list_0 = [{'key': 0}, {'key': 1}, {'key': 2}, {'key': 3}]
    map_0 = Map(list_0)
    str_0 = map_0.__str__()
    assert str_0 == 'Map[value=[{\'key\': 0}, {\'key\': 1}, {\'key\': 2}, {\'key\': 3}]]'


# Generated at 2022-06-26 00:13:39.683941
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(None)) == Last(None)
    assert Last(None).concat(Last(1)) == Last(1)
    assert Last(None).concat(Last(None)) == Last(None)
    assert Last(True).concat(Last(False)) == Last(False)
    assert Last(True).concat(Last(True)) == Last(True)
    assert Last(False).concat(Last(True)) == Last(True)
    assert Last(False).concat(Last(False)) == Last(False)
    assert Last([]).concat(Last([])) == Last([])
    assert Last([1]).concat(Last([2])) == Last([2])

# Generated at 2022-06-26 00:13:50.102692
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert Sum(10).__str__() == 'Sum[value=10]'
    assert Sum(-10).__str__() == 'Sum[value=-10]'


# Generated at 2022-06-26 00:13:50.837515
# Unit test for constructor of class Last
def test_Last():
    class_instance = Last(1)
    assert isinstance(class_instance, Last)


# Generated at 2022-06-26 00:13:51.862454
# Unit test for method __str__ of class First
def test_First___str__():
    print('Test: First.__str__')
    expected = 'Fist[value=5]'
    result = First(5).__str__()
    assert result == expected



# Generated at 2022-06-26 00:13:52.829631
# Unit test for constructor of class Map
def test_Map():
    result = Map(None)
    assert result is not None



# Generated at 2022-06-26 00:13:59.511962
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert First(1) == First(1)
    assert Last(0) == Last(0)
    assert Map({1: Sum(1), 2: First(1)}) == Map({1: Sum(1), 2: First(1)})
    assert Sum(4) == Sum(4)
    assert All(1) == All(1)
    assert One(0) == One(0)
    assert Min(2) == Min(2)
    assert Max(1) == Max(1)


# Generated at 2022-06-26 00:14:01.029216
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-26 00:14:02.309814
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)).value == 2


# Generated at 2022-06-26 00:14:06.882184
# Unit test for method __str__ of class First
def test_First___str__():
    input_list_value = ['1', '2', '3']
    input_semigroup_value = ['4', '5', '6']
    f = First(input_list_value)
    expected_first = 'Fist[value=1]'
    actual_first = f.__str__()
    assert expected_first == actual_first, 'Expected {} and got {}'.format(
        expected_first, actual_first
    )


# Generated at 2022-06-26 00:14:11.319071
# Unit test for method concat of class One
def test_One_concat():
    one_0 = One(None)
    assert one_0.concat(One(False)).value == one_0.value
    assert one_0.concat(One(None)).value == one_0.value
    assert one_0.concat(One(True)).value != one_0.value
    assert one_0.concat(One(object())).value != one_0.value


# Generated at 2022-06-26 00:14:16.137409
# Unit test for constructor of class Max
def test_Max():
    m = Max(10)
    m2 = Max(5)
    m3 = Max(20)
    assert m.value == 10
    assert m2.value == 5
    assert m3.value == 20


# Generated at 2022-06-26 00:14:27.104767
# Unit test for constructor of class Map
def test_Map():
    # Given

    map_0 = Map({"one": Sum(1), "two": Sum(2), "three": Sum(3)})

    # When
    map_0_str = str(map_0)

    # Then
    assert map_0_str == "Map[value={'one': Sum[value=1], 'two': Sum[value=2], 'three': Sum[value=3]}]"



# Generated at 2022-06-26 00:14:29.015239
# Unit test for method __str__ of class One
def test_One___str__():
    obj = One(True)
    actual = str(obj)
    expected = 'One[value=True]'
    assert actual == expected


# Generated at 2022-06-26 00:14:33.566957
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    :returns: nothing
    :rtype: None
    """
    print("\n*** Testing for method fold of class Semigroup ***")
    sum_0 = Sum(15)
    print("The result of fold should be 15")
    print("The result of fold is: {}".format(sum_0.fold(lambda x: x)))


# Generated at 2022-06-26 00:14:34.657286
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == "Last[value=1]"



# Generated at 2022-06-26 00:14:35.996627
# Unit test for method __str__ of class All
def test_All___str__():
    all_0 = All(True)
    assert str(all_0) == str(All(True))


# Generated at 2022-06-26 00:14:41.846841
# Unit test for method __str__ of class Last
def test_Last___str__():
    """
    Unit test for method __str__ of class Last
    """
    last_0 = Last([])
    str_0 = str(last_0)
    last_0 = Last([])
    str_1 = str(last_0)
    last_0 = Last([])
    str_2 = str(last_0)
    last_0 = Last([])
    str_3 = str(last_0)
    last_0 = Last([])
    str_4 = str(last_0)
    last_0 = Last([])
    str_5 = str(last_0)
    last_0 = Last([])
    str_6 = str(last_0)
    last_0 = Last([])
    str_7 = str(last_0)
    last_0 = Last([])
    str_8

# Generated at 2022-06-26 00:14:46.938933
# Unit test for method concat of class All
def test_All_concat():
    assert All(1).concat(All(1)) == All(True)
    assert All(1).concat(All(0)) == All(False)
    assert All(0).concat(All(0)) == All(False)
    with pytest.raises(TypeError):
        All(1).concat(All(""))
    with pytest.raises(TypeError):
        All("").concat(All(1))


# Generated at 2022-06-26 00:14:52.328602
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    print(Sum([1, 2, 3, 4, 5]).fold(sum))
    print(Max([1, 2, 3, 4, 5]).fold(max))
    print(Min([1, 2, 3, 4, 5]).fold(min))



# Generated at 2022-06-26 00:14:55.153671
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    obj = Sum(1)
    expected = 3
    actual = obj.fold(lambda value: value + 2)
    assert actual == expected, "expected {0} to equal {1}".format(actual, expected)


# Generated at 2022-06-26 00:14:59.190876
# Unit test for method __str__ of class Min
def test_Min___str__():
    # Test for method __str__
    """
    :returns: string representation of the object.
    """
    list_0 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    min_0 = Min(list_0)
    str_0 = repr(min_0)
    assert str_0 == 'Min[value=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]'



# Generated at 2022-06-26 00:15:18.393006
# Unit test for method __str__ of class First
def test_First___str__():
    first_0 = First('value')
    assert callable(first_0.__str__)
    assert isinstance(first_0.__str__(), str)
    assert first_0.__str__() == "Fist[value=value]"


# Generated at 2022-06-26 00:15:22.046998
# Unit test for constructor of class Sum
def test_Sum():
    obj_1 = Sum(3)
    obj_2 = Sum(3)
    obj_3 = Sum(4)
    assert obj_1 == obj_2, "test 1 failed"
    assert obj_1 != obj_3, "test 2 failed"
    assert str(obj_1) == "Sum[value=3]", "test 3 failed"



# Generated at 2022-06-26 00:15:25.543975
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One("c")) == "One[value=c]"
    assert str(One(2)) == "One[value=2]"
    assert str(One(True)) == "One[value=True]"
    assert str(One(False)) == "One[value=False]"
    assert str(One(None)) == "One[value=None]"


# Generated at 2022-06-26 00:15:30.585241
# Unit test for method concat of class First
def test_First_concat():

    v0 = First(3).concat(First(4)).value
    assert v0 == 3

    v1 = First(4).concat(First(3)).value
    assert v1 == 4

    v2 = First(4).concat(First(5)).value
    assert v2 == 4

    v3 = First(5).concat(First(4)).value
    assert v3 == 5

    v4 = First(5).concat(First(5)).value
    assert v4 == 5



# Generated at 2022-06-26 00:15:32.116550
# Unit test for constructor of class Min
def test_Min():
    min = Min(1)
    assert min.value == 1, "min value should be 1"

# Generated at 2022-06-26 00:15:35.308284
# Unit test for method __str__ of class All
def test_All___str__():
    list_0 = [True, False]
    all_obj = All(list_0[0])
    assert str(all_obj) == 'All[value=True]'
    all_obj = All(list_0[1])
    assert str(all_obj) == 'All[value=False]'


# Generated at 2022-06-26 00:15:37.345161
# Unit test for method __str__ of class First
def test_First___str__():
    assert First(AnyType()).__str__() == "Fist[value=AnyType()]"

    assert First(99).__str__() == "Fist[value=99]"


# Generated at 2022-06-26 00:15:38.307565
# Unit test for constructor of class Max
def test_Max():
    a = Max(2)
    assert a.value == 2


# Generated at 2022-06-26 00:15:42.069625
# Unit test for constructor of class Max
def test_Max():
    assert str(Max(1)) == "Max[value=1]"
    assert str(Max(1.1)) == "Max[value=1.1]"
    assert str(Max("string")) == "Max[value=string]"
    assert str(Max([1])) == "Max[value=[1]]"
    assert str(Max({1: 1})) == "Max[value={1: 1}]"
    assert str(Max(None)) == "Max[value=None]"



# Generated at 2022-06-26 00:15:44.291709
# Unit test for method concat of class Last
def test_Last_concat():
    last_0 = Last("a")
    last_1 = last_0.concat(Last("b"))
    assert last_1 == Last("b")
