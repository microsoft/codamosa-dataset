

# Generated at 2022-06-26 00:05:50.003493
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).value == 1
    assert Min(2).concat(Min(1)).value == 1


# Generated at 2022-06-26 00:05:52.563427
# Unit test for method concat of class Max
def test_Max_concat():
    concat_0 = Max(max(0.0, 0.0))
    concat_1 = Max(0)
    concat_2 = Max(0)


# Generated at 2022-06-26 00:05:56.837611
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(10).concat(Max(5)) == Max(10)
    assert Max(5).concat(Max(10)) == Max(10)
    for _ in range(10):
        i = random.randint(0, 100)
        assert Max(i).concat(Max(i)) == Max(i)




# Generated at 2022-06-26 00:05:59.699300
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min(0)
    min_1 = Min(1)

    min_0_1 = min_0.concat(min_1)

    assert min_0_1.value == 0



# Generated at 2022-06-26 00:06:01.784619
# Unit test for method concat of class Max
def test_Max_concat():
    max_0 = Max(int(-293))
    max_1 = max_0.concat(int(-293))
    assert max_1 == Max(-293)


# Generated at 2022-06-26 00:06:07.149054
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min(35)
    min_1 = Min(50)
    min_0.concat(10)
    min_0.concat(-19)
    try:
        min_1.concat(min_0)
        raise Exception("Method concat of class Min did not return expected result")
    except DontCare:
        pass
    min_1.concat(-30)
    min_1.concat(min_0)
    min_0.concat(min_1)

# Generated at 2022-06-26 00:06:18.033650
# Unit test for method concat of class Max
def test_Max_concat():
  concat = Max.Min(255).concat()
  assert concat == Max(255)
  concat = Max.Min(64).concat()
  assert concat == Max(64)
  concat = Max.Min(128).concat()
  assert concat == Max(128)
  concat = Max.Min(1024).concat()
  assert concat == Max(1024)
  concat = Max.Min(512).concat()
  assert concat == Max(512)
  concat = Max.Min(2048).concat()
  assert concat == Max(2048)
  concat = Max.Min(192).concat()
  assert concat == Max(192)
  concat = Max.Min(8).concat()
  assert concat == Max(8)
  concat = Max

# Generated at 2022-06-26 00:06:22.270308
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({'a': Sum(1), 'b': Sum(2), 'c': Sum(3)})
    m2 = Map({'a': Sum(1), 'b': Sum(2), 'c': Sum(3)})
    m3 = m1.concat(m2)
    assert m3 == Map({'a': Sum(2), 'b': Sum(4), 'c': Sum(6)})



# Generated at 2022-06-26 00:06:30.041800
# Unit test for method concat of class Max
def test_Max_concat():
    max_2 = Max(2)
    max_3 = Max(3)
    max_0 = Max(0)
    max_0_ = max_2.concat(max_3)
    max_3_ = max_3.concat(max_2)
    max_2_ = max_2.concat(max_0)
    max_3__ = max_3.concat(max_0)
    assert(max_0_ == max_3_ == max_3 == Max(3))
    assert(max_2_ == max_3__ == max_2 == Max(2))


# Generated at 2022-06-26 00:06:34.150181
# Unit test for method concat of class Max
def test_Max_concat():
    bytes_0 = b'*a#<'
    bytes_1 = b'K\x1f\x95'
    int_0 = 2
    max_0 = Max(bytes_0)
    max_1 = Max(bytes_1)
    max_0.concat(max_1)


# Generated at 2022-06-26 00:06:44.380650
# Unit test for method __str__ of class First
def test_First___str__():
    value = {}
    first_0 = First(value)
    first_1 = First(value)
    str_0 = str(first_0)
    assert str_0.startswith('First[value={')
    assert str_0.endswith('}]')
    assert 'value' in str_0
    assert first_0.__str__() is str_0
    str_1 = str(first_1)
    assert str_1.startswith('First[value={')
    assert str_1.endswith('}]')
    assert 'value' in str_1
    assert first_1.__str__() is str_1



# Generated at 2022-06-26 00:06:47.634615
# Unit test for method concat of class Last
def test_Last_concat():
    last_0 = Last(b'-\x00d')
    last_1 = Last(b'\xe6\xc9\t\xeb')
    last_2 = last_0.concat(last_1)
    assert last_2 == last_1


# Generated at 2022-06-26 00:06:58.529444
# Unit test for method __str__ of class Max
def test_Max___str__():
    bytes_0 = b'*a#<'
    max_0 = Max(bytes_0)
    str_0 = max_0.__str__()
    assert str_0 == 'Max[value=b'*a#<']'
    bytes_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    max_1 = Max(bytes_1)
    str_1 = max_1.__str__()

# Generated at 2022-06-26 00:07:03.626256
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    bytes_0 = b'*a#<'
    max_0 = Max(bytes_0)
    bytes_1 = b'*a#<'
    max_1 = Max(bytes_1)
    bytes_2 = b'*a#<'
    max_2 = Max(bytes_2)
    assert max_0 == max_1 and max_0 == max_2


# Generated at 2022-06-26 00:07:05.229909
# Unit test for constructor of class All
def test_All():
    assert isinstance(All(False), All)
    assert isinstance(All(True), All)


# Generated at 2022-06-26 00:07:11.381077
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min('y')
    min_0.concat(Min('Sv'))
    min_1 = Min('Sv')
    min_1.concat(min_0)
    min_2 = Min('Sv')
    min_2.concat(min_0)
    min_3 = Min('Sv')
    min_3.concat(min_0)
    min_4 = Min('y')
    min_4.concat(Min('Sv'))
    min_5 = Min('Sv')
    min_5.concat(min_0)


# Generated at 2022-06-26 00:07:15.578243
# Unit test for method __str__ of class First
def test_First___str__():
    print('Running test for method __str__ of class First')
    print(First(8))
    print(First('a'))
    print(First({}))
    print(First(All(True)))
    print(First(All(False)))
    print(First(First('a')))
    print('Done.')


# Generated at 2022-06-26 00:07:18.339258
# Unit test for method __str__ of class Last
def test_Last___str__():
    pass


# Generated at 2022-06-26 00:07:23.305014
# Unit test for constructor of class Max
def test_Max():
    assert Max(5) == Max(5)
    assert Max('5') == Max('5')
    assert Max(5) != 6


# Generated at 2022-06-26 00:07:25.045657
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert Min(9.9).__str__() == 'Min[value=9.9]'


# Generated at 2022-06-26 00:07:35.328498
# Unit test for method concat of class First
def test_First_concat():
    assert (First(1) + First(2)) == First(1)
    assert (First(1) + First(None)) == First(1)
    assert (First(None) + First(2)) == First(None)
    assert (First(None) + First(None)) == First(None)
    assert (First(1) + First(2) + First(3)).fold(lambda x: x) == 1
    assert (First(1) + First(None) + First(3)).fold(lambda x: x) == 1
    assert (First(None) + First(2) + First(3)).fold(lambda x: x) == None
    assert (First(None) + First(None) + First(3)).fold(lambda x: x) == None


# Generated at 2022-06-26 00:07:37.727098
# Unit test for method concat of class First
def test_First_concat():
    first_0 = First(79)
    first_1 = First(83)
    first_0.concat(first_1)


# Generated at 2022-06-26 00:07:41.579003
# Unit test for constructor of class Map
def test_Map():
    map_0 = Map({'a': Sum(2) , 'b': Sum(0)})
    assert map_0.value == {'a': Sum(2) , 'b': Sum(0)}
    assert map_0.value == {'a': Sum(2), 'b': Sum(0)}



# Generated at 2022-06-26 00:07:45.813831
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(True).concat(All(1)) == All(True)
    assert All(True).concat(All('')) == All(False)


# Generated at 2022-06-26 00:07:48.170395
# Unit test for method concat of class Last
def test_Last_concat():
    last_0 = Last(20)
    last_1 = Last(54)

    assert last_0.concat(last_1).value == 54



# Generated at 2022-06-26 00:07:58.173955
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    # Test case 0
    kwargs_0 = {}
    kwargs_0['value'] = '\x1a!\x1c\x1b\x0f<\x11\x00\x1a\x05\x0f'
    semigroup_instance_0 = Semigroup(**kwargs_0)
    kwargs_1 = {'semigroup_instance_0': semigroup_instance_0}
    fn_0 = lambda x: (x * x)
    kwargs_2 = {'fn_0': fn_0}
    kwargs_1.update(kwargs_2)
    kwargs_2.update(kwargs_0)
    assert fn_0(kwargs_0['value']) == Semigroup.fold(**kwargs_1)
    # Test case 1

# Generated at 2022-06-26 00:08:05.145352
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    bytes_0 = b'FQY'
    bytes_1 = b'fhU!'
    min_0 = Min(bytes_0)
    min_1 = Min(bytes_1)
    max_0 = Max(bytes_0)
    max_1 = Max(bytes_1)
    assert max_0.__eq__(max_1)
    assert not max_1.__eq__(min_0)
    assert min_0.__eq__(max_0)
    assert not min_1.__eq__(min_0)


# Generated at 2022-06-26 00:08:13.060002
# Unit test for constructor of class Map
def test_Map():

    int_0 = 42
    bytes_0 = b'*a#<'
    bytes_1 = b'B'
    bytes_2 = b'_'
    bytes_3 = b'\x0e'
    float_0 = math.exp(2.0)
    float_1 = math.exp(1.0)
    float_2 = math.exp(0.0)
    float_3 = math.sqrt(9.0)
    tuple_0 = (bytes_3, bytes_3, bytes_2)
    tuple_1 = (int_0, float_1, float_1)
    list_0 = [float_0, float_0, int_0]
    list_1 = [bytes_1, float_2, float_2]

# Generated at 2022-06-26 00:08:22.570486
# Unit test for method __str__ of class Map
def test_Map___str__():
    bytes_0 = b'$e6\x00\x00\x00\x00\x00'
    dict_0 = dict()
    map_0 = Map(dict_0)

    bytes_1 = b',\x19X\x00\x00\x00\x00\x00'
    list_0 = list()
    map_0 = Map(list_0)

    bytes_2 = b'2\x1cC\x00\x00\x00\x00\x00'
    str_0 = 'hS'
    map_0 = Map(str_0)

    bytes_3 = b'$e6\x00\x00\x00\x00\x00'
    dict_0 = dict()
    map_1 = Map(dict_0)


# Generated at 2022-06-26 00:08:26.510690
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    bytes_0 = b'*a#<'
    max_0 = Max(bytes_0)

    bool_0 = bool(max_0.__eq__(max_0))
    bool_1 = bool(max_0 == max_0)

    assert bool_0 == bool_1
    assert bool_0 == True


# Generated at 2022-06-26 00:08:36.985927
# Unit test for method concat of class All
def test_All_concat():
    all_0 = All(True)
    all_1 = All(False)
    all_2 = All(True)
    all_3 = All(False)
    all_1_concat_all_0 = all_1.concat(all_0)
    all_2_concat_all_3 = all_2.concat(all_3)
    assert not all_1_concat_all_0
    assert not all_2_concat_all_3


# Generated at 2022-06-26 00:08:38.494918
# Unit test for constructor of class Last
def test_Last():
    last = Last(0)
    assert last.value == 0
    assert last == Last(0)



# Generated at 2022-06-26 00:08:42.759621
# Unit test for method concat of class Last
def test_Last_concat():
    last_0 = Last('')
    last_1 = Last('fba')
    last_2 = Last('e')
    last_3 = last_0.concat(last_1)
    last_4 = last_3.concat(last_2)


# Generated at 2022-06-26 00:08:46.092206
# Unit test for constructor of class Map
def test_Map():
    map_0 = Map({'a': 'b', 'a': 'c'})
    print(map_0.value)
    map_1 = Map({'abc': 'def', 'abc': 'ghi'})
    print(map_1.value)


# Generated at 2022-06-26 00:08:47.210607
# Unit test for constructor of class Map
def test_Map():
    m = Map({'a': Sum(1), 'b': Sum(2)})
    assert m.value['a'].value == 1
    assert m.value['b'].value == 2

# Generated at 2022-06-26 00:08:51.328617
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First(2) == First(2)
    assert Last(2) == Last(2)
    assert Map({'a': Sum(1)}) == Map({'a': Sum(1)})
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)


# Generated at 2022-06-26 00:08:52.853237
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)



# Generated at 2022-06-26 00:08:59.841667
# Unit test for method concat of class All
def test_All_concat():
    bytes_0 = b'h\xe3\x1d\xc8\xe0\x06\x0e\xde\xf8\x05\xa7\xb1\xd9\xcd\x90'
    all_0 = All(bytes_0)
    int_1 = 0
    all_1 = All(int_1)
    int_2 = all_0.concat(all_1)
    assert int_2 == 0


# Generated at 2022-06-26 00:09:01.386097
# Unit test for constructor of class Sum
def test_Sum():
    b = Sum(1)
    assert b.value == 1



# Generated at 2022-06-26 00:09:04.692833
# Unit test for constructor of class Max
def test_Max():
    """
    Test to check the constructor: Max
    """
    bytes_0 = b'*a#<'
    max_0 = Max(bytes_0)
    assert max_0.value == bytes_0
    assert type(max_0.value) == bytes


# Generated at 2022-06-26 00:09:14.856497
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    bytes_0 = b'*a#<'
    max_0 = Max(bytes_0)
    bytes_0 = b'*a#<'
    sum_0 = Sum(bytes_0)
    assert str(sum_0) == 'Sum[value=*a#<]'

# Generated at 2022-06-26 00:09:23.668153
# Unit test for method concat of class All
def test_All_concat():
    parameter_0 = All(False)
    assert parameter_0.concat(parameter_0).value == False
    parameter_1 = All(False)
    assert parameter_0.concat(parameter_1).value == False
    parameter_2 = All(True)
    assert parameter_2.concat(parameter_0).value == False
    parameter_3 = All(False)
    assert parameter_3.concat(parameter_2).value == False
    parameter_4 = All(True)
    assert parameter_4.concat(parameter_4).value == True
    parameter_5 = All(True)
    assert parameter_4.concat(parameter_5).value == True
    parameter_6 = All(False)
    assert parameter_6.concat(parameter_6).value == False
    parameter_

# Generated at 2022-06-26 00:09:33.075399
# Unit test for method concat of class Max
def test_Max_concat():
    """
    Unit test for method concat of class Max

    """

# Generated at 2022-06-26 00:09:35.891361
# Unit test for method __str__ of class First
def test_First___str__():
    bytes_0 = b'*a#<'
    first_0 = First(bytes_0)
    assert (str(first_0) == 'Fist[value=b\'*a#<\']')


# Generated at 2022-06-26 00:09:38.986635
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(10)) == 'Sum[value=10]'
    assert str(Sum(20)) == 'Sum[value=20]'
    assert str(Sum(-30)) == 'Sum[value=-30]'



# Generated at 2022-06-26 00:09:43.936598
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():

    obj_0 = Semigroup(b'*a#<')
    obj_1 = First(0)

    # obj_0 = obj_1
    assert obj_0 == obj_1, \
        'obj_0 = obj_1 does not match actual value {}'.format(obj_0 == obj_1)


test_Semigroup___eq__()



# Generated at 2022-06-26 00:09:45.776858
# Unit test for method __str__ of class All
def test_All___str__():
    all_0 = All(False)
    assert str(all_0) == 'All[value=False]'


# Generated at 2022-06-26 00:09:47.570978
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min(3)
    min_1 = Min(4)
    min_0.concat(min_1)


# Generated at 2022-06-26 00:09:50.579574
# Unit test for method concat of class Last
def test_Last_concat():
    exp_0 = Last(b'*a#<')
    res_0 = First(b'T\xb2\xcf').concat(Last(b'*a#<'))
    assert res_0 == exp_0


# Generated at 2022-06-26 00:09:53.039544
# Unit test for method __str__ of class Map
def test_Map___str__():
    map_0 = Map({})
    result = map_0.__str__()
    assert isinstance(result, str)
    assert result == 'Map[value={}]'


# Generated at 2022-06-26 00:10:08.388843
# Unit test for constructor of class Sum
def test_Sum():
    bytes_0 = b'*a#<'
    Sum_0 = Sum(bytes_0)
    assert Sum_0.value == bytes_0


# Generated at 2022-06-26 00:10:10.085758
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    i64_0 = Sum(5)
    assert  i64_0 == Sum(5)


# Generated at 2022-06-26 00:10:13.818732
# Unit test for method __str__ of class Map
def test_Map___str__():
    bytes_0 = b'*a#<'
    map_0 = Map(bytes_0)
    assert str(map_0) == 'Map[value={}]'.format(bytes_0)


# Generated at 2022-06-26 00:10:16.500818
# Unit test for method concat of class First
def test_First_concat():
    arg0 = First('a')
    arg1 = First('b')
    ret_val = arg0.concat(arg1)
    assert ret_val == First('a')


# Generated at 2022-06-26 00:10:20.651708
# Unit test for method __str__ of class Min
def test_Min___str__():
    min_0 = Min(b'#)!')
    # evaluates to 'Min[value=b\'#)!\']'
    statement_0 = str(min_0)
    assert statement_0 == 'Min[value=b\'#)!\']'


if __name__ == '__main__':
    test_case_0()
    test_Min___str__()

# Generated at 2022-06-26 00:10:30.414115
# Unit test for method concat of class Map
def test_Map_concat():
    # Test 1
    bytes_0 = b'jN\xd1\x1d\x83\x8b\xca\xca\xf4\x1a\x85\x9c\xb0\x1b'
    map_0 = Map({bytes_0: bytes_0})
    bytes_1 = b'\x91'
    map_1 = Map({bytes_1: bytes_1})
    map_2 = map_0.concat(map_1)
    assert b'\x91' in map_2.value
    
    # Test 2
    bytes_0 = b'r\x14\xc7\x8b\x7f\x1d\x7f\x8b\xc7\x14\x81\x1d'

# Generated at 2022-06-26 00:10:33.882369
# Unit test for method concat of class Min
def test_Min_concat():
    min_0_0 = Min(10)
    min_0_1 = Min(20)
    min_0_2 = min_0_0.concat(min_0_1)
    assert min_0_2.value == 10


# Generated at 2022-06-26 00:10:42.518475
# Unit test for constructor of class Last
def test_Last():

    # Checkpoints of constructor of class Last:
    # -----------------------------------------

    # Checkpoint 1: Checking if Last works as expected with a positive number
    assert Last(7).concat(Last(1)).concat(Last(3)).concat(Last(3)).concat(Last(2)).concat(Last(1)) == Last(1)

    # Checkpoint 2: Checking if Last works as expected with a negative number
    assert Last(-7).concat(Last(-1)).concat(Last(-3)).concat(Last(-3)).concat(Last(-2)).concat(Last(-1)) == Last(-1)

    # Checkpoint 3: Checking if Last works as expected with a positive float

# Generated at 2022-06-26 00:10:47.176185
# Unit test for constructor of class One
def test_One():
    # 1
    one_0 = One(True)
    assert one_0.value == True

    # 2
    one_1 = One(False)
    assert one_1.value == False

    # 3
    one_2 = One(True)
    assert one_2.value == True


# Generated at 2022-06-26 00:10:57.865649
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(7).concat(Max(5)) == Max(7)
    assert Max(5).concat(Max(7)) == Max(7)
    assert Max(5).concat(Max(5)) == Max(5)
    assert Max(5).concat(Max(5)) == Max(5)
    assert Max(5).concat(Max(6)) == Max(6)
    assert Max(6).concat(Max(5)) == Max(6)
    assert Max(5).concat(Max(6)) == Max(6)
    assert Max(6).concat(Max(5)) == Max(6)
    assert Max(5).concat(Max(6)) == Max(6)
    assert Max(6).concat(Max(5)) == Max(6)

# Generated at 2022-06-26 00:11:27.636263
# Unit test for method __str__ of class Map
def test_Map___str__():
    dict_0 = {}
    dict_0['one'] = Sum(1)
    dict_0['two'] = Sum(2)
    map_0 = Map(dict_0)
    res = map_0.__str__()
    assert res == "Map[value={'one': Sum[value=1], 'two': Sum[value=2]}]"



# Generated at 2022-06-26 00:11:29.797164
# Unit test for constructor of class Map
def test_Map():
    test_map = Map({'1': Sum(5)})

# Generated at 2022-06-26 00:11:32.783282
# Unit test for constructor of class Min
def test_Min():
    min_0 = Min('a')
    assert min_0.value == 'a'
    assert isinstance(min_0, Min)
    assert not isinstance(min_0, First)
    assert isinstance(min_0, Semigroup)


# Generated at 2022-06-26 00:11:42.162494
# Unit test for constructor of class Min
def test_Min():
    min_0 = Min(0)
    min_1 = Min(1)
    min_0_1 = Min(0).concat(min_1)
    min_2 = Min(2)
    min_3 = Min(3)
    min_2_3 = Min(2).concat(min_3)
    min_4 = Min(4)
    min_4_0 = Min(4).concat(min_0)
    min_5 = Min(5)
    min_5_2 = Min(5).concat(min_2)
    min_6 = Min(6)
    min_6_3 = Min(6).concat(min_3)
    min_7 = Min(7)
    min_7_5 = Min(7).concat(min_5)

# Generated at 2022-06-26 00:11:52.680403
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert isinstance(Sum.neutral().concat(Sum(1)), Sum)
    assert isinstance(Sum.neutral().concat(Sum('test')), Sum)
    assert Sum.neutral().concat(Sum(1)).value == 1
    assert Sum.neutral().concat(Sum('test')).value == 0
    assert Sum(1).concat(Sum('test')).value == 1
    assert Sum(1).concat(Sum(1)).value == 2
    assert Sum(1).concat(Sum(2)).value == 3
    assert Sum(1).concat(Sum(2.5)).value == 3.5
    assert Sum(1).concat(Sum(-2)).value == -1
    assert Sum(-1).concat(Sum(-1)).value == -2

# Generated at 2022-06-26 00:11:59.955131
# Unit test for method __str__ of class Last
def test_Last___str__():
    bytes_0 = b'\x1c\xbe\x14\r'
    last_0 = Last(bytes_0)
    assert last_0 == Last(bytes_0)
    assert last_0.concat(last_0).concat(last_0) == last_0.concat(last_0)


# Generated at 2022-06-26 00:12:03.434876
# Unit test for method __str__ of class Max
def test_Max___str__():
    bytes_0 = b'*a#<'
    max_0 = Max(bytes_0)
    str_0 = 'Max[value=42]'
    str_1 = max_0.__str__()
    assert str_0 == str_1


# Generated at 2022-06-26 00:12:08.621510
# Unit test for method concat of class Map
def test_Map_concat():
    value = {
        "name": Sum(1),
        "lastname": Sum(1),
        "age": Sum(1),
    }
    map1 = Map(value)
    assert map1.concat(map1).value["name"].value == 2


# Generated at 2022-06-26 00:12:11.544130
# Unit test for constructor of class Map
def test_Map():
    d = {1: First(1), 2: First(2), 3: First(3), 4: First(4)}
    assert Map({1: 1, 2: 2, 3: 3, 4: 4}) == Map(d)


# Generated at 2022-06-26 00:12:16.262525
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    bytes_0 = b'*a#<'
    sum_0 = Sum(bytes_0)
    # State assertion
    try:
        assert_equal('Sum[value=*a#<]', sum_0.__str__())
    except AssertionError as e:
        raise e


# Generated at 2022-06-26 00:13:13.849998
# Unit test for constructor of class One
def test_One():
    example = One(True)
    assert example == One(True)


# Generated at 2022-06-26 00:13:18.489858
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({'a': Sum(1), 'b': Sum(2), 'c': Sum(3)})
    m2 = Map({'a': Sum(4), 'b': Sum(5), 'c': Sum(6)})
    actual = m1.concat(m2).value
    expected = {'a': Sum(5), 'b': Sum(7), 'c': Sum(9)}
    assert actual == expected


# Generated at 2022-06-26 00:13:20.129920
# Unit test for method concat of class All
def test_All_concat():
    assert All(All(True).concat(All(False))).value == False



# Generated at 2022-06-26 00:13:21.958658
# Unit test for constructor of class One
def test_One():
    list_0 = [
            One(True)
    ]
    for value_0 in list_0:
        assert value_0.value == True
    value_1 = One.neut

# Generated at 2022-06-26 00:13:23.261523
# Unit test for constructor of class First
def test_First():
    f = First(1)
    assert f.value == 1


# Unit tests for instance method concat of class First

# Generated at 2022-06-26 00:13:28.656141
# Unit test for method concat of class Map
def test_Map_concat():
    map_0 = Map({key_1 : Semigroup(i) for i, key_1 in enumerate(range(10))})
    map_1 = Map({key_1 : Semigroup(i * i) for i, key_1 in enumerate(range(10))})
    map_2 = map_0.concat(map_1)
    assert map_2.value == {key_1 : Semigroup(i * i + i) for i, key_1 in enumerate(range(10))}

# Generated at 2022-06-26 00:13:34.663057
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    bytes_0 = b'*a#<'
    bytes_1 = b'*a#<'
    assert Sum(bytes_0) == Sum(bytes_1)
    bytes_2 = b'8d#'
    assert Sum(bytes_0) != Sum(bytes_2)
    bytes_3 = b'*a#<'
    bytes_4 = b'*a#<'
    assert First(bytes_3) == First(bytes_4)
    bytes_5 = b'8d#'
    assert First(bytes_3) != Last(bytes_5)



# Generated at 2022-06-26 00:13:35.664445
# Unit test for constructor of class Sum
def test_Sum():
    semigroup_0 = Sum(92)


# Generated at 2022-06-26 00:13:40.859756
# Unit test for method concat of class Map
def test_Map_concat():
    dict_0 = dict()
    dict_0[5] = (5,)
    dict_1 = dict()
    dict_1[5] = (5,)
    map_0 = Map(dict_0)
    map_1 = Map(dict_1)
    map_1.concat(map_0)
    map_0.concat(map_0)
    map_1.concat(map_1)


# Generated at 2022-06-26 00:13:51.633790
# Unit test for constructor of class Sum
def test_Sum():
    print(test_Sum.__doc__)
    # test constructor
    sum_0: Sum = Sum(0)
    assert sum_0.value == 0
    # test constructor raises exception
    try:
        Sum(0.0)
        assert False
    except TypeError:
        assert True
    # test constructor raises exception
    try:
        Sum(True)
        assert False
    except TypeError:
        assert True
    # test constructor raises exception
    try:
        Sum(False)
        assert False
    except TypeError:
        assert True
    # test constructor raises exception
    try:
        Sum('0')
        assert False
    except TypeError:
        assert True
    # test constructor raises exception
    try:
        Sum([0])
        assert False
    except TypeError:
        assert True
    # test