

# Generated at 2022-06-26 00:05:56.539603
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = -1738
    int_1 = -1738
    max_0 = Max(int_0)
    max_1 = Max(int_1)
    max_2 = max_0.concat(max_1)
    result = max_2.value
    assert result == int_0



# Generated at 2022-06-26 00:06:02.227780
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = 23
    int_1 = -14
    int_2 = -14
    int_3 = -1738
    int_4 = -14
    max_0 = Max(int_0)
    max_1 = Max(int_1)

    assert max_0.concat(max_1).value == 23
    assert Max(int_2).concat(Max(int_3)).value == -14
    assert Max(int_4).concat(Max(int_3)).value == -14



# Generated at 2022-06-26 00:06:03.260666
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)


# Generated at 2022-06-26 00:06:07.700922
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = -1738
    max_0 = Max(int_0)
    int_1 = -1738
    max_1 = Max(int_1)
    max_2 = max_0.concat(max_1)
    assert max_2.value == max(int_0, int_1)
# Test for method concat of class Last

# Generated at 2022-06-26 00:06:15.007190
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = 1738
    int_1 = -2288
    int_2 = -558
    max_0 = Max(int_0)
    max_1 = Max(int_1)
    max_2 = Max(int_2)
    max_concat_0 = max_0.concat(max_1)
    max_concat_1 = max_concat_0.concat(max_2)
    assert max_concat_1.value == int_0


# Generated at 2022-06-26 00:06:17.901246
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(3.1415).concat(Max(2.7182)).value == Max(3.1415).value


# Generated at 2022-06-26 00:06:20.004741
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = -1738
    max_0 = Max(int_0)

    int_60 = 1738
    max_60 = Max(int_60)

    max_0.concat(max_60)

    assert max_0 == Max(-1738)


# Generated at 2022-06-26 00:06:24.690402
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = -1738
    int_1 = -3883
    max_0 = Max(int_0)

    int_2 = -3745
    max_0_2 = max_0.concat(Max(int_2))

# Generated at 2022-06-26 00:06:26.884243
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(0).concat(Max(1)).fold(lambda x: x) == 1

test_Max_concat()


# Generated at 2022-06-26 00:06:33.637940
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = -1738
    first_0 = First(int_0)
    int_1 = -1738
    last_0 = Last(-1738)
    dict_0 = {}
    int_2 = -1738
    one_0 = One(int_2)
    last_1 = Last(last_0)
    list_0 = []
    max_0 = Max(list_0)
    max_1 = max_0.concat(last_0)
    return (max_1)


# Generated at 2022-06-26 00:06:36.213303
# Unit test for constructor of class First
def test_First():
    test_case_0()


# Generated at 2022-06-26 00:06:39.287626
# Unit test for constructor of class First
def test_First():
    int_1 = -1738
    first_1 = First(int_1)
    int_0 = -1738
    first_0 = First(int_0)
    print('assertFirst: ', first_1 == first_0)



# Generated at 2022-06-26 00:06:45.569987
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    int_0 = -1738
    first_0 = First(int_0)
    int_1 = -704
    first_1 = First(int_1)
    assert type(first_0) == First
    assert first_0.value == int_0
    assert type(first_1) == First
    assert first_1.value == int_1
    assert first_0 == first_0
    assert not first_0 == first_1


# Generated at 2022-06-26 00:06:48.198584
# Unit test for method concat of class Sum
def test_Sum_concat():
    int_0 = -1738
    sum_0 = Sum(int_0)
    int_1 = -2077
    sum_1 = Sum(int_1)
    sum_2 = sum_0.concat(sum_1)
    int_2 = -3815
    sum_3 = Sum(int_2)
    assert sum_2 == sum_3


# Generated at 2022-06-26 00:06:54.522307
# Unit test for method __str__ of class Last
def test_Last___str__():
    int_0 = -1738
    last_0 = Last(int_0)

# test 0.1
    str_0 = str(last_0)
    str_1 = 'Last[value=-1738]'
    assert str_0 == str_1

# test 0.2
    str_0 = str(last_0)
    str_1 = 'Last[value=0]'
    assert str_0 != str_1


# Generated at 2022-06-26 00:06:58.936784
# Unit test for method __str__ of class Map
def test_Map___str__():
    int_0 = -1738
    first_0 = First(int_0)
    last_0 = Last(first_0)
    map_0 = Map({'test': last_0})
    str_0 = map_0.__str__()
    assert str_0 is not None



# Generated at 2022-06-26 00:07:08.162931
# Unit test for constructor of class Semigroup
def test_Semigroup():
    int_0 = -1738
    sum_0 = Sum(int_0)
    assert sum_0.value == -1738
    bool_0 = False
    all_0 = All(bool_0)
    assert all_0.value == False
    bool_1 = False
    all_1 = All(bool_1)
    assert all_1.value == False
    bool_2 = False
    all_2 = All(bool_2)
    assert all_2.value == False
    bool_3 = True
    all_3 = All(bool_3)
    assert all_3.value == True
    bool_4 = True
    all_4 = All(bool_4)
    assert all_4.value == True
    bool_5 = True
    all_5 = All(bool_5)

# Generated at 2022-06-26 00:07:11.167594
# Unit test for constructor of class Map
def test_Map():
    # Test case 0 will create a map with 2 keys, test_key_0, test_key_1, and 2 values
    # each are a Sum[value=0]. The 2 Sum[value=0] objects were created to test that
    # the concat function for Map will properly merge the values
    int_0 = 0
    int_1 = 1
    str_0 = "test_key_0"
    str_1 = "test_key_1"

    test_map = Map({str_0: Sum(int_0), str_1: Sum(int_0)})


# Generated at 2022-06-26 00:07:19.469409
# Unit test for method concat of class Last
def test_Last_concat():
    int_0 = -1738
    first_0 = First(int_0)
    int_1 = -1738
    first_1 = First(int_1)
    int_2 = -1738
    last_2 = Last(int_2)
    last_result = first_0.concat(first_1)
    if not ((last_result == last_2)):
        raise Exception("Result: (%s) is not what is expected: (%s)" % (last_result, last_2))


# Generated at 2022-06-26 00:07:22.507058
# Unit test for constructor of class All
def test_All():
    assert bool(All(True) is True)


# Generated at 2022-06-26 00:07:26.328124
# Unit test for constructor of class First
def test_First():
    assert First(17).value == 17


# Generated at 2022-06-26 00:07:27.684480
# Unit test for method __str__ of class Last
def test_Last___str__():
    return Last(42).__str__()



# Generated at 2022-06-26 00:07:30.834940
# Unit test for method __str__ of class First
def test_First___str__():
    int_0 = -1738
    first_0 = First(int_0)

    assert "Fist[value=-1738]" == first_0.__str__()



# Generated at 2022-06-26 00:07:34.172531
# Unit test for method __str__ of class All
def test_All___str__():
    assert All.__str__(All(False)) == "All[value=False]"
    assert All.__str__(All(True)) == "All[value=True]"


# Generated at 2022-06-26 00:07:36.307352
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert Max(-1738).__str__() == 'Max[value=-1738]'


# Generated at 2022-06-26 00:07:39.607467
# Unit test for method concat of class First
def test_First_concat():
    int_0 = -1738
    first_0 = First(int_0)
    int_1 = 6873
    first_1 = First(int_1)
    first_1.concat(first_0)



# Generated at 2022-06-26 00:07:40.948273
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-26 00:07:42.651555
# Unit test for constructor of class Last
def test_Last():
    int_0 = -1738
    first_0 = First(int_0)



# Generated at 2022-06-26 00:07:46.473701
# Unit test for method __str__ of class First
def test_First___str__():
    int_0 = 2
    first_0 = First(int_0)
    result_0 = str(first_0)
    assert result_0 == 'Fist[value=2]', '__str__(first_0) returned ' + result_0 + ', expected Fist[value=2]'


# Generated at 2022-06-26 00:07:49.066203
# Unit test for method __str__ of class Map
def test_Map___str__():
    int_0 = 8176
    map_0 = Map({})
    str_0 = map_0.__str__()
    assert "Map[value={" in str_0


# Generated at 2022-06-26 00:07:56.903332
# Unit test for method concat of class Last
def test_Last_concat():
    last_0 = Last('0')
    last_1 = last_0.concat(Last('1'))
    assert last_1.value == '1'


# Generated at 2022-06-26 00:07:58.543953
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(-991) == One(-991)



# Generated at 2022-06-26 00:08:02.461090
# Unit test for method __str__ of class All
def test_All___str__():
    int_a = 607
    all_a = All(int_a)
    assert str(all_a) == 'All[value=607]'

    bool_b = False
    all_b = All(bool_b)

    assert str(all_b) == 'All[value=False]'


# Generated at 2022-06-26 00:08:05.714355
# Unit test for method __str__ of class Max
def test_Max___str__():
    expect_arg_0 = 'Max[value=1738]'
    expect_return = expect_arg_0
    actual_return = Max(1738).__str__()
    assert actual_return == expect_return, ('expected: {} got: ' + actual_return)


# Generated at 2022-06-26 00:08:08.334684
# Unit test for constructor of class Semigroup
def test_Semigroup():
    int_0 = -1738
    semigroup_0 = Semigroup(int_0)
    assert semigroup_0.value == int_0


# Generated at 2022-06-26 00:08:12.539823
# Unit test for method __str__ of class Max
def test_Max___str__():
    string_0 = "Max[value=42]"
    int_0 = 42
    max_0 = Max(int_0)
    assert(str(max_0) == string_0)


# Generated at 2022-06-26 00:08:15.832972
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    actual = test_case_0().fold(lambda value: value)
    expected = -1738
    assert actual == expected, \
        'Wrong value "{}" returned when, expecting "{}"'.format(actual, expected)


# Generated at 2022-06-26 00:08:17.897070
# Unit test for constructor of class First
def test_First():
    int_0 = -1738
    first_0 = First(int_0)
    print(first_0)


# Generated at 2022-06-26 00:08:26.910213
# Unit test for method concat of class One
def test_One_concat():
    # Test setup code
    bool_0 = bool(None)
    bool_1 = bool(None)
    bool_2 = bool(None)
    bool_3 = bool(None)
    bool_4 = bool(None)
    bool_5 = bool(None)
    bool_6 = bool(None)
    bool_7 = bool(None)
    bool_8 = bool(None)
    bool_9 = bool(None)
    bool_10 = bool(None)
    bool_11 = bool(None)

    # Test execution code
    if (not bool_6):
        if (not bool_7):
            bool_11 = One(bool_0).concat(One(bool_1)).value

# Generated at 2022-06-26 00:08:28.287013
# Unit test for constructor of class Sum
def test_Sum():
    int_0 = -1738
    sum_0 = Sum(int_0)

    assert int_0 == sum_0.value


# Generated at 2022-06-26 00:08:35.160570
# Unit test for method __str__ of class First
def test_First___str__():
    int_0 = -1738
    first_0 = First(int_0)
    str_0 = str(first_0)
    str_1 = 'Fist[value=-1738]'
    assert str_0 == str_1


# Generated at 2022-06-26 00:08:44.625465
# Unit test for constructor of class Min
def test_Min():
    int_0 = -5898
    min_0 = Min(int_0)
    assert min_0.value == int_0
    int_1 = -413
    min_1 = Min(int_1)
    assert min_1.value == int_1
    int_2 = 0
    min_2 = Min(int_2)
    assert min_2.value == int_2
    int_3 = 9157
    min_3 = Min(int_3)
    assert min_3.value == int_3
    int_4 = -5936
    min_4 = Min(int_4)
    assert min_4.value == int_4
    int_5 = -7191
    min_5 = Min(int_5)
    assert min_5.value == int_5

# Generated at 2022-06-26 00:08:47.188718
# Unit test for constructor of class Semigroup
def test_Semigroup():
    int_0 = -1738
    semigroup_0 = Semigroup(int_0)
    int_1 = semigroup_0.value
    assert int_1 == int_0



# Generated at 2022-06-26 00:08:51.442023
# Unit test for method concat of class One
def test_One_concat():
    # Asserts method concat against the definition of One.
    one = One
    a = one(True)
    b = one(False)
    assert a.concat(b) == one(True)
    assert b.concat(a) == one(True)
    assert a.concat(a) == one(True)
    assert b.concat(b) == one(False)


# Generated at 2022-06-26 00:08:53.687214
# Unit test for method concat of class Last
def test_Last_concat():
    last = Last("A")
    other = Last("B")
    assert_that(last.concat(other), is_(other))


# Generated at 2022-06-26 00:08:58.302394
# Unit test for method __str__ of class First
def test_First___str__():
    int_0 = -1738
    first_0 = First(int_0)
    str_ret_0 = str(first_0)
    str_ret_expected = 'Fist[value=-1738]'
    assert str_ret_0 == str_ret_expected


# Generated at 2022-06-26 00:09:02.275247
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert First(1).__eq__(First(1)) == True
    assert Sum(42).__eq__(Sum(-42)) == False
    assert NotImplemented == First(42).__eq__(Sum(-42))
    assert NotImplemented == Sum(42).__eq__(First(-42))


# Generated at 2022-06-26 00:09:08.408961
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    int_0 = 2427
    int_1 = -1052
    sum_0 = Sum(int_0)
    sum_1 = Sum(int_1)
    sum_2 = sum_0.concat(sum_1)
    result = sum_2.__str__()
    assert id(sum_0) == id(sum_1)
    assert id(sum_0) != id(sum_2)
    assert id(sum_1) != id(sum_2)
    assert result == 'Sum[value=1375]'


# Generated at 2022-06-26 00:09:15.378703
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    int_0 = -1738
    first_0 = First(int_0)
    first_1 = First(int_0)
    first_2 = First(int_0)
    first_1__eq__result = first_1.__eq__(first_2)
    first_2__eq__result = first_2.__eq__(first_0)
    first_0__eq__result = first_0.__eq__(first_1)
    assert first_1__eq__result == True
    assert first_2__eq__result == True
    assert first_0__eq__result == True


# Generated at 2022-06-26 00:09:17.606363
# Unit test for constructor of class First
def test_First():
    first = First(1)
    assert isinstance(first.value, int)
    assert first.value == 1
    first = First(1.0)
    assert isinstance(first.value, float)
    assert first.value == 1.0
    first = First("hello")
    assert isinstance(first.value, str)
    assert first.value == "hello"


# Generated at 2022-06-26 00:09:23.196949
# Unit test for method __str__ of class Last
def test_Last___str__():
    last_0 = Last(str())
    # Test method __str__ of class Last
    last_0__str__ = str(last_0)
    assert last_0__str__ == 'Last[value=]'


# Generated at 2022-06-26 00:09:32.644096
# Unit test for constructor of class Max
def test_Max():
    int_0 = -1738
    int_1 = -1739
    first_0 = Max(int_0)
    first_1 = Max(int_1)
    first_2 = first_1.concat(first_0)
    assert first_2.value != first_0.value
    assert first_2.value != first_1.value
    assert first_2.value == first_0.value
    assert first_2.value != first_1.value
    assert first_2.value == first_0.value
    assert first_2.value != int_0
    assert first_2.value != int_1
    assert first_2.value == int_0
    assert first_2.value != int_1
    assert first_2.value == int_0
    assert first_0.value != first_

# Generated at 2022-06-26 00:09:36.185869
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)).value is False
    assert All(False).concat(All(True)).value is False
    assert All(False).concat(All(False)).value is False
    assert All(True).concat(All(True)).value is True


# Generated at 2022-06-26 00:09:39.882382
# Unit test for method concat of class Sum
def test_Sum_concat():
    int_0 = -1738
    int_1 = -1554
    sum_0 = Sum(int_0)
    sum_1 = Sum(int_1)
    sum_2 = sum_0.concat(sum_1)
    assert sum_2.value == -3292


# Generated at 2022-06-26 00:09:41.992898
# Unit test for constructor of class Last
def test_Last():
    int_0 = -1738
    last_0 = Last(int_0)
    int_1 = -1738
    last_1 = Last(int_1)


# Generated at 2022-06-26 00:09:46.704664
# Unit test for method concat of class Sum
def test_Sum_concat():
    int_0 = -1123
    sum_0 = Sum(int_0)

    int_1 = -1123
    sum_1 = Sum(int_1)

    Sum_2 = sum_0.concat(sum_1)
    assert int_0 + int_1 == Sum_2.value


# Generated at 2022-06-26 00:09:48.210479
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert First.__str__(First(1)) == "Fist[value=1]"


# Generated at 2022-06-26 00:09:51.235807
# Unit test for constructor of class Sum
def test_Sum():
    # Create object of class Sum
    s = Sum(2)
    assert s.value == 2

    # Create object of class Sum with default value
    s_1 = Sum(0)
    assert s_1.value == 0



# Generated at 2022-06-26 00:09:54.088194
# Unit test for constructor of class Min
def test_Min():
    int_0 = -1738
    min_0 = Min(int_0)    # must invoke constructor of class Min
    assert min_0.value == -1738


# Generated at 2022-06-26 00:09:55.558068
# Unit test for constructor of class All
def test_All():
    assert All(True)
    assert All(False)


# Generated at 2022-06-26 00:10:00.711166
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    int_0 = -1738
    sum_0 = Sum(int_0)
    expected_0 = 'Sum[value=-1738]'
    assert (sum_0.__str__() == expected_0)


# Generated at 2022-06-26 00:10:02.514617
# Unit test for constructor of class Min
def test_Min():
    int_0 = -1738
    min_0 = Min(int_0)
    assert min_0.value == int_0


# Generated at 2022-06-26 00:10:12.701180
# Unit test for method concat of class Map
def test_Map_concat():
    int_0 = -1738
    str_0 = 'some random string'
    first_0 = First(int_0)
    last_0 = Last(str_0)
    map_0 = Map({'first_0': first_0, 'last_0': last_0})
    int_1 = -528616687
    str_1 = 'some random string'
    first_1 = First(int_1)
    last_1 = Last(str_1)
    map_1 = Map({'first_0': first_1, 'last_0': last_1})
    assert type(map_0.concat(map_1)) == Map
    assert map_0.concat(map_1).fold(lambda value: value['first_0'].value) == int_1
    assert map_0.con

# Generated at 2022-06-26 00:10:21.328582
# Unit test for method __str__ of class Max
def test_Max___str__():
    max_0 = Max(
        1
    )
    assert str(max_0) == 'Max[value=1]'
    int_0 = -251
    max_1 = Max(int_0)
    assert str(max_1) == 'Max[value=-251]'
    int_1 = -945
    max_2 = Max(int_1)
    assert str(max_2) == 'Max[value=-945]'
    int_2 = -177
    max_3 = Max(int_2)
    assert str(max_3) == 'Max[value=-177]'
    int_3 = 574
    max_4 = Max(int_3)
    assert str(max_4) == 'Max[value=574]'
    int_4 = 0
    max_5 = Max(int_4)

# Generated at 2022-06-26 00:10:23.065534
# Unit test for constructor of class Sum
def test_Sum():
    int_0 = -1738
    sum_0 = Sum(int_0)
    assert sum_0.value == int_0


# Generated at 2022-06-26 00:10:25.067928
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == "Max[value=1]"


# Generated at 2022-06-26 00:10:34.985629
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    Case 0
    """
    int_0 = -1738
    int_1 = -2453
    sum_0 = Sum(int_0)
    sum_1 = Sum(int_1)
    res_1 = sum_0.concat(sum_1)
    assert isinstance(res_1, Sum)

    """
    Case 1
    """
    int_0 = -2888
    int_1 = -1385
    sum_0 = Sum(int_0)
    sum_1 = Sum(int_1)
    res_1 = sum_0.concat(sum_1)
    assert isinstance(res_1, Sum)

    """
    Case 2
    """
    int_0 = -1746
    int_1 = 2945

# Generated at 2022-06-26 00:10:37.605378
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    int_0 = -1738
    sum_0 = Sum(int_0)
    assert str(sum_0) == "Sum[value=-1738]"


# Generated at 2022-06-26 00:10:40.895499
# Unit test for constructor of class Min
def test_Min():
    result1 = Min(10)
    result2 = Min(20)
    result3 = Min(30)
    result4 = Min(40)
    assert result1.value == 10
    assert result2.value == 20
    assert result3.value == 30
    assert result4.value == 40


# Generated at 2022-06-26 00:10:46.255699
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False
    assert All(True).concat(All(True)).value == True
    assert All(False).concat(All(False)).value == False
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False

# Generated at 2022-06-26 00:10:53.373304
# Unit test for method __str__ of class Last
def test_Last___str__():
    int_0 = -1738
    first_0 = First(int_0)

    ret = str(first_0)
    assert ret == 'Fist[value=-1738]'


# Generated at 2022-06-26 00:11:03.443712
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = -1738
    max_0 = Max(int_0)
    int_1 = -1738
    max_1 = Max(int_1)
    max_2 = max_0.concat(max_1)
    assert max_2.value == int_0
    int_2 = -8
    max_3 = Max(int_2)
    max_4 = max_2.concat(max_3)
    assert max_4.value == int_0
    int_3 = 1738
    max_5 = Max(int_3)
    max_6 = max_4.concat(max_5)
    assert max_6.value == int_3
    int_4 = 538
    max_7 = Max(int_4)
    max_8 = max_6.con

# Generated at 2022-06-26 00:11:04.547437
# Unit test for constructor of class Max
def test_Max():

   assert Max(int_0).__str__() == 'Max[value=-1738]'

# Generated at 2022-06-26 00:11:13.120234
# Unit test for method concat of class Map
def test_Map_concat():
    # Test case 0
    int_0 = -1738
    str_0 = 'hello world'
    dict_0 = {
        int_0: First(int_0),
        str_0: First(str_0)
    }
    map_0 = Map(dict_0)
    # Test case 1
    int_1 = -1738
    str_1 = 'hello world'
    dict_1 = {
        int_1: First(int_1),
        str_1: First(str_1)
    }
    map_1 = Map(dict_1)
    assert map_0.concat(map_1) == Map(dict_0)
    # Test case 2
    int_0 = -1738
    str_0 = 'hello world'

# Generated at 2022-06-26 00:11:15.674193
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    all_ = All(True)
    assert all_.fold(lambda x: x) == True

# Generated at 2022-06-26 00:11:19.885910
# Unit test for method concat of class All
def test_All_concat():
    # Test case 0
    int_0 = -1
    all_0 = All(int_0)
    int_1 = -1
    all_1 = All(int_1)
    all_2 = all_0.concat(all_1)
    assert all_2.value == True


# Generated at 2022-06-26 00:11:22.734694
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    int_0 = -1738
    semigroup_0 = Semigroup(int_0)
    semigroup_1 = Semigroup(int_0)
    assert semigroup_0 == semigroup_1


# Generated at 2022-06-26 00:11:24.600219
# Unit test for constructor of class First
def test_First():
    int_0 = -1738
    first_0 = First(int_0)
    assert first_0.value == int_0


# Generated at 2022-06-26 00:11:25.947417
# Unit test for constructor of class Map
def test_Map():
    Map_1 = Map({})
    assert isinstance(Map_1, Map)
    assert type(Map_1.value) == dict


# Generated at 2022-06-26 00:11:29.329908
# Unit test for method __str__ of class First
def test_First___str__():
    int_0 = -1738
    first_0 = First(int_0)
    actual = first_0.__str__()
    expected = 'Fist[value=-1738]'
    assert actual == expected


# Generated at 2022-06-26 00:11:42.149866
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)).concat(Max(3)) == Max(3)
    assert Max(2).concat(Max(3)).concat(Max(1)) == Max(3)
    assert Max(3).concat(Max(2)).concat(Max(1)) == Max(3)
    assert Max(1).concat(Max(2)).concat(Max(-5)) == Max(2)
    assert Max(1).concat(Max(18)).concat(Max(2)) == Max(18)
    assert Max(2).concat(Max(1)).concat(Max(18)) == Max(18)
    assert Max(18).concat(Max(1)).concat(Max(2)) == Max(18)

# Generated at 2022-06-26 00:11:43.790288
# Unit test for method __str__ of class First
def test_First___str__():
    int_1 = -1394
    first_1 = First(int_1)
    assert first_1.__str__() == 'Fist[value=-1394]'


# Generated at 2022-06-26 00:11:52.253249
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    int_0 = -958
    semigroup_0 = Semigroup(int_0)
    int_1 = -1331
    semigroup_1 = Semigroup(int_1)
    int_2 = -1738
    semigroup_2 = Semigroup(int_2)
    assert semigroup_0 == semigroup_0
    assert not semigroup_1 == semigroup_2
    assert not semigroup_0 == semigroup_2
    assert not semigroup_2 == semigroup_1
    assert not semigroup_1 == semigroup_0
    assert semigroup_2 == semigroup_2
    assert not semigroup_0 == semigroup_1


# Generated at 2022-06-26 00:11:57.698466
# Unit test for method __str__ of class One
def test_One___str__():
    Any = int
    int_0 = -1738
    one_0 = One(int_0)

    result = one_0.__str__()



# Generated at 2022-06-26 00:12:00.764612
# Unit test for constructor of class One
def test_One():
    int_0 = -1738
    one_0 = One(int_0)
    actual = one_0.value
    expected = int_0
    assert actual == expected


# Generated at 2022-06-26 00:12:04.124860
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    int_0 = -1738
    first_0 = First(int_0)
    first_1 = first_0.fold(lambda x: First(x))
    assert first_1 is not None
    assert first_1.value == -1738


# Generated at 2022-06-26 00:12:05.916653
# Unit test for constructor of class Semigroup
def test_Semigroup():
    first_0 = First(0)
    assert first_0.value == 0



# Generated at 2022-06-26 00:12:14.797214
# Unit test for method concat of class First
def test_First_concat():
    int_0 = -1738
    first_0 = First(int_0)
    int_1 = -1738
    first_1 = First(int_1)
    first_2 = first_0.concat(first_1)
    assert first_2.value == int_0

    int_0 = -1738
    first_0 = First(int_0)
    str_1 = '-1738'
    first_1 = First(str_1)
    first_2 = first_0.concat(first_1)
    assert first_2.value == int_0

    int_0 = -1738
    first_0 = First(int_0)
    bool_1 = False
    first_1 = First(bool_1)

# Generated at 2022-06-26 00:12:16.597866
# Unit test for method concat of class Last
def test_Last_concat():
    last_0 = test_case_0()
    last_0.concat(last_0)



# Generated at 2022-06-26 00:12:25.527701
# Unit test for method concat of class Max
def test_Max_concat():
    #Test 0
    int_0 = 64108
    max_0 = Max(int_0)
    int_1 = 91845
    max_1 = Max(int_1)
    semigroup_0 = max_0.concat(max_1)
    #Test 1
    int_2 = -34672
    max_2 = Max(int_2)
    int_3 = 55700
    max_3 = Max(int_3)
    semigroup_1 = max_2.concat(max_3)
    #Test 2
    int_4 = -1031
    max_4 = Max(int_4)
    int_5 = -37789
    max_5 = Max(int_5)
    semigroup_2 = max_4.concat(max_5)
    #Test 3


# Generated at 2022-06-26 00:12:33.635760
# Unit test for method concat of class One
def test_One_concat():
    # Test case: 0
    int_0 = -1738
    one_0 = One(int_0)
    int_1 = -1738
    one_1 = One(int_1)
    one_0.concat(one_1)
    int_2 = -1738
    one_2 = One(int_2)

# Test for method fold of class One

# Generated at 2022-06-26 00:12:40.937154
# Unit test for method concat of class First
def test_First_concat():
    int_0 = -1738
    first_0 = First(int_0)
    int_1 = 4352
    first_1 = First(int_1)
    assert(first_0.concat(first_1) == First(-1738))
    int_0 = -1738
    first_0 = First(int_0)
    int_1 = -1738
    first_1 = First(int_1)
    assert(first_0.concat(first_1) == First(-1738))
    int_0 = 4352
    first_0 = First(int_0)
    int_1 = -1738
    first_1 = First(int_1)
    assert(first_0.concat(first_1) == First(4352))
    int_0 = -1738
    first_

# Generated at 2022-06-26 00:12:44.936616
# Unit test for method concat of class Last
def test_Last_concat():
    last_1 = Last(15)
    last_2 = Last(28)
    last_3 = last_1.concat(last_2)
    assert last_3.value == 28


if __name__ == '__main__':
    test_Last_concat()

# Generated at 2022-06-26 00:12:47.543284
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(3).fold(lambda x: x) == 3
    assert Semigroup(3).fold(lambda x: x + 2) == 5


# Generated at 2022-06-26 00:12:56.307077
# Unit test for method concat of class Last
def test_Last_concat():
    int_0 = -1738
    last_0 = Last(int_0)
    int_1 = -6897
    last_1 = Last(int_1)
    last_2 = last_0.concat(last_1)
    assert last_2.value == int_1
    int_0 = 265
    last_0 = Last(int_0)
    int_1 = -1411
    last_1 = Last(int_1)
    last_2 = last_0.concat(last_1)
    assert last_2.value == int_1
    int_0 = 1567
    last_0 = Last(int_0)
    int_1 = -9678
    last_1 = Last(int_1)
    last_2 = last_0.concat(last_1)
   

# Generated at 2022-06-26 00:13:00.675369
# Unit test for constructor of class Sum
def test_Sum():
    int_0 = 10
    sum_0 = Sum(int_0)
    int_1 = 2
    sum_1 = Sum(int_1)
    bool_0 = sum_0.concat(sum_1)
    int_2 = 12
    sum_2 = Sum(int_2)
    bool_1 = bool_0 == sum_2
    assert bool_1


# Generated at 2022-06-26 00:13:03.142436
# Unit test for method __str__ of class One
def test_One___str__():
    int_0 = -1738
    one_0 = One(int_0)
    str_0 = "One[value=-1738]"
    assert one_0.__str__() == str_0


# Generated at 2022-06-26 00:13:07.527789
# Unit test for method concat of class Sum
def test_Sum_concat():

    int_0 = -1738
    int_1 = -1738
    Sum_0 = Sum(int_0)
    Sum_1 = Sum(int_1)
    Sum_2 = Sum_0.concat(Sum_1)

    assert Sum_2 == Sum(int_0 + int_1)
    assert Sum_2.value == int_0 + int_1



# Generated at 2022-06-26 00:13:11.451579
# Unit test for method concat of class One
def test_One_concat():
    int_0 = -1738
    int_1 = 7278

    one_0 = One(int_0)
    one_1 = One(int_1)
    one_2 = one_0.concat(one_1)

    assert one_2.value == False


# Generated at 2022-06-26 00:13:14.548639
# Unit test for constructor of class Sum
def test_Sum():
    int_1 = 1
    int_2 = 2
    sum_1 = Sum(int_1)
    sum_2 = Sum(int_2)


# Generated at 2022-06-26 00:13:25.864379
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': First(1), 'b': First(2)}) == Map({'a': First(1), 'b': First(2)})
    assert Map({'a': First(1), 'b': First(2)}).value['a'].value == 1


# Generated at 2022-06-26 00:13:27.454524
# Unit test for method __str__ of class All
def test_All___str__():
    bool_0 = All(True)
    str_0 = All(str)

    print(str_0)


# Generated at 2022-06-26 00:13:28.986759
# Unit test for method __str__ of class Min
def test_Min___str__():
    expected = 'Min[value=42]'
    actual = str(Min(42))
    assert (actual == expected)


# Generated at 2022-06-26 00:13:35.478688
# Unit test for constructor of class Sum
def test_Sum():
    print("Creating Sum object")
    int_0 = -1738
    sum_0 = Sum(int_0)

    assert(sum_0.value == int_0)

    int_1 = -1739
    sum_1 = Sum(int_1)
    sum_0.concat(sum_1) == sum_1

    int_2 = -1740
    sum_2 = Sum(int_2)
    sum_0.concat(sum_2) == sum_2

    int_3 = -1741
    sum_3 = Sum(int_3)
    sum_0.concat(sum_3) == sum_3


# Generated at 2022-06-26 00:13:41.204810
# Unit test for method concat of class Map
def test_Map_concat():
    dic_0 = {'foo': Sum(2), 'bar': Last(7)}
    dic_1 = {'foo': First(1), 'bar': Sum(8)}
    instance_0 = Map(dic_0)
    instance_1 = Map(dic_1)
    Map_concat_0 = instance_0.concat(instance_1)
    assert Map_concat_0.value == {'foo': Sum(3), 'bar': Sum(15)}


# Generated at 2022-06-26 00:13:42.830183
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(10).concat(Sum(10)) == Sum(20)
    assert Sum(20).concat(Sum(10)) == Sum(30)


# Generated at 2022-06-26 00:13:46.397157
# Unit test for method __str__ of class Max
def test_Max___str__():
    neutral_element = float("inf")
    value = int
    max = Max(value)
    assert max.__str__() == 'Max[value={}]'.format(value)



# Generated at 2022-06-26 00:13:51.930694
# Unit test for method __str__ of class One
def test_One___str__():
    string_0 = "One[value=True]"
    boolean_0 = True
    one_0 = One(boolean_0)
    string_1 = one_0.__str__()
    assert string_0 == string_1
    string_2 = "One[value=False]"
    boolean_1 = False
    one_1 = One(boolean_1)
    string_3 = one_1.__str__()
    assert string_2 == string_3

# Generated at 2022-06-26 00:13:55.851558
# Unit test for method __str__ of class Map
def test_Map___str__():
    int_0 = -449
    str_0 = 'Map[value={}]'
    str_1 = Map(int_0).__str__()
    assert str_1 == str_0.format(int_0)


# Generated at 2022-06-26 00:14:00.244690
# Unit test for method __str__ of class Min
def test_Min___str__():
    left_0 = Min(2)
    assert __str__(left_0) == 'Min[value=2]'


# Generated at 2022-06-26 00:14:13.797669
# Unit test for method __str__ of class All
def test_All___str__():
    all_0 = All(1)
    expected_value_0 = 'All[value=1]'
    actual_value_0 = all_0.__str__()
    assert actual_value_0 == expected_value_0


# Generated at 2022-06-26 00:14:19.648457
# Unit test for method concat of class First
def test_First_concat():
    int_0 = -1738
    int_1 = -804
    first_0 = First(int_0)
    first_1 = First(int_1)
    first_2 = first_0.concat(first_1)
    assert first_0 == First(int_0)
    assert first_1 == First(int_1)
    assert first_2 == First(int_0)


# Generated at 2022-06-26 00:14:21.765728
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True), "True == True"
    assert One(False) == One(False), "False == False"
    assert One(True) != One(False), "True != False"

# Generated at 2022-06-26 00:14:27.139817
# Unit test for constructor of class Last
def test_Last():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 00:14:30.139098
# Unit test for method __str__ of class First
def test_First___str__():
    int_0 = 5300
    first_0 = First(int_0)
    str_0 = 'Fist[value=5300]'
    str_1 = first_0.__str__()
    assert str_1 == str_0


# Generated at 2022-06-26 00:14:32.778170
# Unit test for constructor of class Max
def test_Max():
    int_0 = -1234
    max_0 = Max(int_0)
    assert max_0.value == int_0



# Generated at 2022-06-26 00:14:34.893920
# Unit test for method __str__ of class Last
def test_Last___str__():
    int_0 = 438
    last_0 = Last(int_0)
    str_0 = 'Last[value=438]'
    assert last_0.__str__() == str_0


# Generated at 2022-06-26 00:14:38.089677
# Unit test for method concat of class One
def test_One_concat():
    int_0 = -1738
    int_1 = 1672
    one_0 = One(int_0)
    one_1 = One(int_1)
    one_2 = one_0.concat(one_1)
    assertEqual(one_2.value, int_0 or int_1)


# Generated at 2022-06-26 00:14:40.930816
# Unit test for method __str__ of class One
def test_One___str__():
    one_0=One(False)
    assert str(one_0) == "One[value=False]"
    one_1=One(True)
    assert str(one_1) == "One[value=True]"
    one_2=One(0)
    assert str(one_2) == "One[value=0]"
    


# Generated at 2022-06-26 00:14:44.625489
# Unit test for constructor of class All
def test_All():
    # Test constructor of class All
    All(False)
    All(True)
    # Test for the correct type of All instance
    assert type(All(False)) is All
    assert type(All(True)) is All


# Generated at 2022-06-26 00:14:59.407828
# Unit test for method concat of class Min
def test_Min_concat():
    int_0 = -1738
    min_0 = Min(int_0)
    int_1 = -744
    min_1 = Min(int_1)
    assert min_0.concat(min_1) == Min(-744)

    int_0 = -1738
    min_0 = Min(int_0)
    int_1 = -1738
    min_1 = Min(int_1)
    assert min_0.concat(min_1) == Min(-1738)

    int_0 = -1738
    min_0 = Min(int_0)
    int_1 = -821
    min_1 = Min(int_1)
    assert min_0.concat(min_1) == Min(-1738)

    int_0 = -1738
    min_0

# Generated at 2022-06-26 00:15:00.293048
# Unit test for method concat of class Map
def test_Map_concat():
    # TODO: Remove this exception and implement the tests.
    raise Exception("Tests not implemented")


# Generated at 2022-06-26 00:15:01.397470
# Unit test for constructor of class Last
def test_Last():
    int_0 = -1738
    case_0 = Last(int_0)
    assert case_0


# Generated at 2022-06-26 00:15:02.354316
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(float("inf"))) == "Min[value=inf]"


# Generated at 2022-06-26 00:15:04.984476
# Unit test for method __str__ of class Max
def test_Max___str__():
    int_0 = -1166
    max_0 = Max(int_0)
    assert str(max_0) == 'Max[value={}]'.format(int_0)


# Generated at 2022-06-26 00:15:09.434479
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert "Map[value={'a': First[value=1],'b': First[value=2],'c': First[value=3],'d': First[value=4],'e': First[value=5]}]" == str(Map({'a': First(1), 'b': First(2), 'c': First(3), 'd': First(4), 'e': First(5)}))


# Generated at 2022-06-26 00:15:15.544263
# Unit test for method concat of class Max
def test_Max_concat():
    a = 1738
    b = -1738
    c = 913664
    d = -913664

    j_max = Max(a)
    k_max = Max(b)
    l_max = Max(c)
    m_max = Max(d)

    result1 = j_max.concat(k_max)
    result2 = l_max.concat(m_max)
    
    print(result1)
    print(result2)


# Generated at 2022-06-26 00:15:18.110233
# Unit test for constructor of class Sum
def test_Sum():
    int_0 = -1738
    int_1 = -1738
    sum_0 = Sum(int_0)
    assert sum_0.value == int_1


# Generated at 2022-06-26 00:15:20.127229
# Unit test for method __str__ of class All
def test_All___str__():
    int_0 = 1
    all_0 = All(int_0)
    assert all_0.__str__() == "All[value=1]"


# Generated at 2022-06-26 00:15:22.521739
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_10 = Sum(10)
    sum_20 = Sum(20)
    sum_30 = sum_10.concat(sum_20)
    assert sum_30.value == Sum(30).value


# Generated at 2022-06-26 00:15:33.098808
# Unit test for constructor of class One
def test_One():
    int_0 = -1738
    one_0 = One(int_0)
    assert One(True).value == True
    assert One(False).value == False
    assert one_0.value == int_0



# Generated at 2022-06-26 00:15:34.426074
# Unit test for method __str__ of class First
def test_First___str__():
    first_0 = First(0.6)
    str_0 = str(first_0)


# Generated at 2022-06-26 00:15:36.228465
# Unit test for method __str__ of class Last
def test_Last___str__():
    actual_result = Last(1).__str__()
    expected_result = 'Last[value=1]'
    assert actual_result == expected_result


# Generated at 2022-06-26 00:15:37.183861
# Unit test for constructor of class Min
def test_Min():
    assert Min(0) == Min(0)


# Generated at 2022-06-26 00:15:39.637608
# Unit test for method __str__ of class Max
def test_Max___str__():
    number_0 = -507
    max_0 = Max(number_0)
    __str__0 = max_0.__str__()
    assert (__str__0 == 'Max[value=' + str(number_0) + ']')


# Generated at 2022-06-26 00:15:46.058896
# Unit test for method concat of class All
def test_All_concat():
    bool_0 = True
    bool_1 = False
    all_0 = All(bool_0)
    all_1 = All(bool_1)
    assert all_0.concat(all_1) == All(bool_1)
    all_2 = All(bool_0)
    all_3 = All(bool_1)
    assert all_2.concat(all_3) == All(bool_1)
    all_4 = All(bool_0)
    all_5 = All(bool_1)
    assert all_4.concat(all_5) == All(bool_1)
    all_6 = All(bool_1)
    all_7 = All(bool_0)
    assert all_6.concat(all_7) == All(bool_0)