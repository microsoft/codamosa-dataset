

# Generated at 2022-06-26 00:05:58.171922
# Unit test for method concat of class Map
def test_Map_concat():
    map_0_0 = Map([])
    map_0_1 = Map([])
    map_0 = map_0_0.concat(map_0_1)
    map_1_0 = Map(['a', 'b'])
    map_1_1 = Map([])
    map_1 = map_1_0.concat(map_1_1)
    map_2_0 = Map(['a', 'b'])
    map_2_1 = Map(['a', 'b'])
    map_2 = map_2_0.concat(map_2_1)
    map_3_0 = Map([])
    map_3_1 = Map(['a', 'b'])
    map_3 = map_3_0.concat(map_3_1)
    pass


# Generated at 2022-06-26 00:06:00.658505
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min(int())
    min_1 = min_0.concat(Min((-1)))
    min_2 = min_1.concat(Min((-2)))


# Generated at 2022-06-26 00:06:02.189573
# Unit test for method concat of class Max
def test_Max_concat():
    max_0 = Max(0)
    max_1 = Max(max_0)
    max_2 = max_0.concat(max_1)


# Generated at 2022-06-26 00:06:11.421232
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = None
    min_1 = None
    min_2 = min(min_1, min_0)
    assert min_2 == min_1
    min_3 = None
    min_4 = min(min_3, min_3)
    assert min_4 == min_3
    min_5 = None
    min_6 = min(min_5, min_5)
    assert min_6 == min_5
    min_7 = None
    min_8 = min(min_7, min_7)
    assert min_8 == min_7
    min_9 = None
    min_10 = min(min_9, min_9)
    assert min_10 == min_9
    min_11 = None
    min_12 = min(min_11, min_11)
    assert min_

# Generated at 2022-06-26 00:06:16.875810
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min(0)
    min_1 = Min(1)
    min_2 = Min(2)

    min_0.concat(min_1)
    min_2.concat(min_0)
    min_2.concat(min_2)
    min_1.concat(min_1)


# Generated at 2022-06-26 00:06:21.625079
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min(0)
    min_1 = Min(1)
    min_2 = Min(2)
    str_0 = min_1.concat(min_2).__str__()
    str_1 = min_1.concat(min_0).__str__()
    str_2 = min_0.concat(min_2).__str__()

    assert str_0 == str_1 and str_0 == str_2


# Generated at 2022-06-26 00:06:25.106762
# Unit test for method concat of class Min
def test_Min_concat():
    Min_0 = Min(2)
    Min_1 = Min(Min_0.value)
    Min_2 = Min_0.concat(Min_1)


# Generated at 2022-06-26 00:06:29.556736
# Unit test for method concat of class Max
def test_Max_concat():
    max_0 = Max(Max.neutral_element)
    num_0 = max_0.concat(max_0)
    num_1 = num_0.value
    #assert(num_1 == 0), 'Expected 0, got ' + str(num_1)
    print("Max concat", num_1)


# Generated at 2022-06-26 00:06:34.025255
# Unit test for method concat of class Min
def test_Min_concat():
    assert True == Min(5).concat(Min(10)).__eq__(Min(5))
    assert True == Min(5).concat(Min(5)).__eq__(Min(5))
    assert True == Min(5).concat(Min(5)).concat(Min(6)).__eq__(Min(5))


# Generated at 2022-06-26 00:06:40.742558
# Unit test for method concat of class Max
def test_Max_concat():
    # create a Max instance from the value 1
    max_0 = Max(1)

    # create a Max instance from the value 2
    max_1 = Max(2)

    # create a Max instance from the value 1
    max_2 = Max(1)

    # concat max_0 with max_1, then concat the result with max_2
    res_0 = max_0.concat(max_1).concat(max_2)

    # assert that the value of res_0 is equal to 2
    assert 2 == res_0.value


# Generated at 2022-06-26 00:06:52.456817
# Unit test for method concat of class Map
def test_Map_concat():
    map_0 = Map({0: First(0), 1: First(1), 2: First(2), 3: First(3), 4: First(4)})
    assert map_0.concat(map_0) == Map({0: First(0), 1: First(1), 2: First(2), 3: First(3), 4: First(4)})
    map_1 = Map({0: Last(0), 1: Last(1), 2: Last(2), 3: Last(3), 4: Last(4)})
    assert map_1.concat(map_1) == Map({0: Last(0), 1: Last(1), 2: Last(2), 3: Last(3), 4: Last(4)})


# Generated at 2022-06-26 00:07:01.187042
# Unit test for method concat of class Map
def test_Map_concat():
    """
    If you have Map as Map({'a': Sum(1), 'b': Sum(2)})
    and second Map as Map({'a': Sum(3), 'b': Sum(4)})
    then imagine that you have Map as Map({'a': Sum(4), 'b': Sum(6)})
    """
    m_0 = Map({'a': Sum(1), 'b': Sum(2)})
    m_1 = Map({'a': Sum(3), 'b': Sum(4)})
    assert m_0.concat(m_1) == Map({'a': Sum(4), 'b': Sum(6)})



# Generated at 2022-06-26 00:07:06.770770
# Unit test for method concat of class Map
def test_Map_concat():
    list_0 = list()
    list_0.extend([Last(None), First("\u00d0"), Last("and"), Last("and")])
    list_0.append(Last("and"))
    list_0.extend([First("and"), First("and"), First("and"), First("and")])
    map_0 = Map({})
    for value_0 in list_0:
        map_0.concat(value_0)



# Generated at 2022-06-26 00:07:11.915007
# Unit test for method concat of class Map
def test_Map_concat():
    r_0 = Map({0: First(2), 1: First(1), 2: First(3)})
    r_1 = Map({0: First(5), 1: First(5), 2: First(5)})
    r_0_res = r_0.concat(r_1)
    assert r_0_res.value[0] == First(2)
    assert r_0_res.value[1] == First(1)
    assert r_0_res.value[2] == First(3)


# Generated at 2022-06-26 00:07:21.049484
# Unit test for method concat of class Map
def test_Map_concat():
    val_0 = Map({"a": Sum(1), "f": Sum(4), "g": Sum(7)})
    val_1 = Map({
        "b": Sum(2),
        "f": Sum(5),
        "s": Sum(88)
    })
    val_0.concat(val_1)
    assert val_0.value == {
        "a": Sum(1),
        "f": Sum(9),
        "g": Sum(7),
        "b": Sum(2),
        "s": Sum(88)
    }


# Generated at 2022-06-26 00:07:31.853311
# Unit test for method concat of class Map
def test_Map_concat():
    str_0 = 'Max concat'
    str_1 = 'Min concat'
    str_2 = 'Last concat'
    str_3 = 'First concat'
    str_4 = 'All concat'
    str_5 = 'Sum concat'
    str_6 = 'Map concat'
    str_7 = 'One concat'
    str_8 = 'None concat'
    str_9 = 'All concat'
    str_10 = 'All concat'
    str_11 = 'All concat'
    str_12 = 'Sum concat'
    str_13 = 'Sum concat'
    str_14 = 'One concat'
    str_15 = 'None concat'
    str_16 = 'All concat'
    str_17 = 'All concat'
   

# Generated at 2022-06-26 00:07:39.889771
# Unit test for method concat of class Map
def test_Map_concat():
    map_0 = Map({'a': Sum(0), 'b': Sum(0), 'c': Sum(0), 'd': Sum(0)})
    map_0 = map_0.concat(Map({'a': Sum(4), 'b': Sum(5), 'c': Sum(6), 'd': Sum(7)}))
    assert map_0 == Map({'a': Sum(4), 'b': Sum(5), 'c': Sum(6), 'd': Sum(7)})
    map_0 = map_0.concat(Map({'a': Sum(4), 'b': Sum(5), 'c': Sum(6), 'd': Sum(7)}))

# Generated at 2022-06-26 00:07:42.029136
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({0: First(0)}).concat(Map({0: First(1)})) == Map({0: First(0)})


# Generated at 2022-06-26 00:07:53.231534
# Unit test for method concat of class Map
def test_Map_concat():
    if  not (isinstance(Map({}).concat(Map({})), Map)):
        raise Exception("1")
    if  not (Map({}).concat(Map({})) == Map({})):
        raise Exception("2")
    if  not (Map({1: 'a'}).concat(Map({})) == Map({1: 'a'})):
        raise Exception("3")
    if  not (Map({}).concat(Map({1: 'a'})) == Map({1: 'a'})):
        raise Exception("4")

# Generated at 2022-06-26 00:07:55.972973
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({1: Sum(1), 2: Sum(2)}).concat(Map({1: Sum(1), 2: Sum(2)})) == Map({1: Sum(2), 2: Sum(4)})


# Generated at 2022-06-26 00:07:58.908947
# Unit test for method __str__ of class One
def test_One___str__():
    test_case_0()


# Generated at 2022-06-26 00:08:02.379966
# Unit test for constructor of class Min
def test_Min():
    num_0 = Min(1)
    assert num_0.value == 1
    num_1 = Min(5)
    assert num_1.value == 5
    assert num_1.concat(num_0) == Min(5)


# Generated at 2022-06-26 00:08:05.633577
# Unit test for constructor of class Max
def test_Max():
    Abc = Max(1)
    assert Abc.concat(Max(2)) == Max(2)
    assert Abc.concat(Max(0)) == Max(1)
    assert Abc.concat(Max(-1)) == Max(1)


# Generated at 2022-06-26 00:08:06.884746
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(0)) == 'Min[value=0]'


# Generated at 2022-06-26 00:08:09.717956
# Unit test for method concat of class All
def test_All_concat():
    All_0 = All(False)
    All_1 = All(True)
    r = All_0.concat(All_1)
    assert not r.value


# Generated at 2022-06-26 00:08:13.981775
# Unit test for method __str__ of class All
def test_All___str__():
    str_0 = str(All(False))
    assert str_0 == 'All[value=False]'
    str_1 = str(All(True))
    assert str_1 == 'All[value=True]'


# Generated at 2022-06-26 00:08:23.319180
# Unit test for constructor of class Max
def test_Max():
    a, b = [1, 2, 3, 2, 1]
    assert a > 1, 'a is greater than 1'
    assert b > 1, 'b is greater than 1'
    assert a == 2, 'a is equal to 2'
    assert b == 2, 'b is equal to 2'
    assert a != 3, 'a is not equal to 3'
    assert b != 3, 'b is not equal to 3'
    assert a >= 2, 'a is greater than or equal to 2'
    assert b >= 2, 'b is greater than or equal to 2'
    assert a <= 2, 'a is less than or equal to 2'
    assert b <= 2, 'b is less than or equal to 2'

    c, d = [1, 2, 3, 4, 5]

# Generated at 2022-06-26 00:08:25.242639
# Unit test for method __str__ of class First
def test_First___str__():
    str_0 = First(5).__str__()
    assert str_0 == 'Fist[value=5]'


# Generated at 2022-06-26 00:08:30.944811
# Unit test for method concat of class Map
def test_Map_concat():
    str_0 = 'Max concat'

    # Assert if concat in instance Map is working
    assert Map({
        'foo': Sum(1),
        'bar': Max(9),
        'baz': All(False),
        'qux': Min(14),
    }).concat(Map({
        'foo': Sum(2),
        'bar': Max(4),
        'baz': All(True),
        'qux': Min(13),
    })) == Map({
        'foo': Sum(3),
        'bar': Max(9),
        'baz': All(False),
        'qux': Min(13),
    }), str_0


# Generated at 2022-06-26 00:08:32.482275
# Unit test for constructor of class Min
def test_Min():
    min_0 = Min(2)
    assert min_0.value == 2


# Generated at 2022-06-26 00:08:38.904959
# Unit test for method __str__ of class Max
def test_Max___str__():
    str_0 = 'Max[value={}]'.format(1)
    str_1 = 'Max[value={}]'.format('a')

    assert str_0 == Max(1).__str__()
    assert str_1 == Max('a').__str__()


# Generated at 2022-06-26 00:08:42.748964
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    str_0 = 'Sum[value=0]Sum[value=0]'
    Sum_0 = Sum(0)
    Sum_1 = Sum(0)
    try:
        assert (Sum_0 == Sum_1)
    except AssertionError:
        print(str_0)


# Generated at 2022-06-26 00:08:46.760829
# Unit test for method concat of class One
def test_One_concat():
    one_0 = One(False)
    assert one_0.concat(one_0).value == False
    one_1 = One(True)
    assert one_1.concat(one_1).value == True
    one_2 = One(True)
    assert one_2.concat(one_2).value == True


# Generated at 2022-06-26 00:08:48.006374
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(2)) == 'Sum[value=2]'


# Generated at 2022-06-26 00:08:51.550611
# Unit test for method concat of class Sum
def test_Sum_concat():
    # Given
    str_0 = 'Max concat'

    value_0 = Sum(1)
    value_1 = Sum(2)

    # When
    result = value_0.concat(value_1)

    # Then
    assert result == Sum(3)
    assert result.value == 3


# Generated at 2022-06-26 00:08:54.602146
# Unit test for method concat of class Last
def test_Last_concat():
    str_0 = 'Last concat'
    assert Last(1).concat(Last(2)).value == 2
    assert Last(1).concat(Last(1)).value == 1


# Generated at 2022-06-26 00:08:57.324827
# Unit test for method __str__ of class Min
def test_Min___str__():
    str_0 = str(Min(0))
    assert str_0 == 'Min[value=0]'



# Generated at 2022-06-26 00:09:01.725140
# Unit test for method __str__ of class Min
def test_Min___str__():

    str_1 = str(Min(2))
    str_2 = 'Min[value=2]'
    str_3 = str_1
    # Test case for Min
    assert str_3 == str_2, "test_case_0: Expected <{}> but got <{}>".format(str_2, str_3)


# Generated at 2022-06-26 00:09:03.292033
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == "Sum[value=1]", "Not Equal"


# Generated at 2022-06-26 00:09:06.840198
# Unit test for method concat of class Sum
def test_Sum_concat():
    print('Test Case 1: {}'.format('Max concat'))

    assert Sum(1).concat(Sum(1)) == Sum(2)
    assert Sum(1).concat(Sum(5)) == Sum(6)


if __name__ == '__main__':
    test_Sum_concat()

# Generated at 2022-06-26 00:09:15.686059
# Unit test for method __str__ of class All
def test_All___str__():
    # Init
    str_0 = 'All[value={}]'.format(True)
    all_0 = All(True)

    # Execute
    result = all_0.__str__()

    # Assert
    assert result == str_0


# Generated at 2022-06-26 00:09:19.016378
# Unit test for constructor of class All
def test_All():
    assert All(True)
    assert All(False)
    assert not All(0)
    assert not All(None)
    assert not All('')
    assert All(1)
    assert All('a')
    assert All([1, 2, 3])



# Generated at 2022-06-26 00:09:21.675818
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)).value == True
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(False)).value == False


# Generated at 2022-06-26 00:09:22.832447
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    str_1 = 'Semigroup.__eq__'


# Generated at 2022-06-26 00:09:25.106953
# Unit test for method __str__ of class All
def test_All___str__():
    assert All(True).__str__() == 'All[value=True]'
    assert All(False).__str__() == 'All[value=False]'


# Generated at 2022-06-26 00:09:27.876404
# Unit test for method __str__ of class All
def test_All___str__():
    str_0 = str(All(True))
    assert str_0 == 'All[value=True]'

    str_1 = str(All(False))
    assert str_1 == 'All[value=False]'


# Generated at 2022-06-26 00:09:29.878843
# Unit test for constructor of class Min
def test_Min():
    min_0 = Min(1)
    assert min_0.value == 1



# Generated at 2022-06-26 00:09:35.523846
# Unit test for method __str__ of class All
def test_All___str__():
    str_0 = 'All[value=True]'
    assert str(All(True)) == str_0, 'Wrong __str__ result. Expected: {}, result: {}'.format(str_0, str(All(True)))
    str_1 = 'All[value=False]'
    assert str(All(False)) == str_1, 'Wrong __str__ result. Expected: {}, result: {}'.format(str_1, str(All(False)))


# Generated at 2022-06-26 00:09:37.352695
# Unit test for method concat of class First
def test_First_concat():
    if "First concat" != First("Hello").concat(First("First concat")):
        raise Exception("First concat")


# Generated at 2022-06-26 00:09:38.127187
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    sum_0 = Sum(5)
    print(sum_0.fold(str) == '5')


# Generated at 2022-06-26 00:09:46.588963
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    str_0 = 'Semigroup.__eq__'
    semigroup_0 = Sum(0)
    assert semigroup_0 == semigroup_0
    assert not semigroup_0 == All(False)


# Generated at 2022-06-26 00:09:48.093670
# Unit test for method __str__ of class All
def test_All___str__():
    assert(str(All(True)) == 'All[value=True]')


# Generated at 2022-06-26 00:09:49.475797
# Unit test for method __str__ of class One
def test_One___str__():
    assert repr(One(True)) == repr(One(True))


# Generated at 2022-06-26 00:09:50.986747
# Unit test for method concat of class First
def test_First_concat():
    result = First(1).concat(First(2))
    assert(result == First(1))

# Generated at 2022-06-26 00:09:54.771983
# Unit test for method concat of class Max
def test_Max_concat():
    instance_0 = Max(0)
    instance_1 = Max(1)

    assert type(instance_0.concat(instance_1)) is Max
    assert instance_0.concat(instance_1) == Max(1)


# Generated at 2022-06-26 00:09:56.905736
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(1)) == Sum(2)
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-26 00:09:58.093620
# Unit test for constructor of class Last
def test_Last():
    last = Last(0)
    assert last.value == 0
    last = Last()
    assert last.value is None


# Generated at 2022-06-26 00:09:59.921761
# Unit test for method __str__ of class Last
def test_Last___str__():
    str_0 = Last(1).__str__()
    print(str_0)
    assert str_0 == 'Last[value=1]'


# Generated at 2022-06-26 00:10:02.213363
# Unit test for constructor of class All
def test_All():
    str_0 = 'All[value=True]'
    semigroup_0 = All(True)
    assert str(semigroup_0) == str_0


# Generated at 2022-06-26 00:10:12.360688
# Unit test for constructor of class Min
def test_Min():

    # Create instance of class Min
    min = Min('value')

    # Create a variable of type Min
    min_0 = min

    # Create a variable of type Min
    min_1 = min

    # Create a variable of type Map
    map_0 = Map({'key': min_0})

    # Create a variable of type Map
    map_1 = Map({'key': min_1})

    # Create a variable of type Min
    min_2 = min

    # Create a variable of type Min
    min_3 = min

    # Create a variable of type Map
    map_2 = Map({'key': min_2})

    # Create a variable of type Map
    map_3 = Map({'key': min_3})

    # Create a variable of type First
    first = First('value')

    # Create a variable of

# Generated at 2022-06-26 00:10:29.203395
# Unit test for method concat of class All
def test_All_concat():
    """
    Function to test method concat of class All
    """

# Generated at 2022-06-26 00:10:33.109687
# Unit test for constructor of class First
def test_First():
    str_0 = 'First concat'
    int_0 = 1

    frist_0 = First(str_0)
    frist_1 = First(int_0)
    frist_2 = frist_0.concat(frist_1)

    assert frist_0 == frist_2


# Generated at 2022-06-26 00:10:36.099836
# Unit test for constructor of class Map
def test_Map():
    assert Map({'str': Sum()}) != Map({'str': Sum()})
    assert Map({'str': Sum()}).value == {'str': Sum()}


# Generated at 2022-06-26 00:10:37.879211
# Unit test for method __str__ of class First
def test_First___str__():
    str_0 = str(First())
    str_1 = str(First(1))
    pass


# Generated at 2022-06-26 00:10:39.933746
# Unit test for method __str__ of class Min
def test_Min___str__():
    str_0 = 'Max[value=inf]'
    str_1 = Min(1).__str__()
    assert str_1 == str_0


# Generated at 2022-06-26 00:10:48.979734
# Unit test for constructor of class Sum
def test_Sum():
    str_0 = 'Sum constr'
    test_0_in = 0
    test_0_out = Sum(test_0_in)
    assert test_0_out.value == test_0_in, str_0
    str_1 = 'Sum constr'
    test_1_in = -4
    test_1_out = Sum(test_1_in)
    assert test_1_out.value == test_1_in, str_1
    str_2 = 'Sum constr'
    test_2_in = 100
    test_2_out = Sum(test_2_in)
    assert test_2_out.value == test_2_in, str_2


# Generated at 2022-06-26 00:10:59.183522
# Unit test for method concat of class Max
def test_Max_concat():
    str_0 = 'Max concat'
    max_0 = Max(2.8584345659192477)
    max_1 = Max(1)
    max_2 = Max(2.8584345659192477)
    max_3 = Max(1)
    max_concat_0 = max_0.concat(max_1)
    max_concat_1 = max_2.concat(max_3)
    int_0 = max_concat_0.concat(max_concat_1)
    assert int_0 == max_concat_0.concat(max_concat_1)


# Generated at 2022-06-26 00:11:01.572639
# Unit test for constructor of class Min
def test_Min():
    expected = Min(10)
    input = Min(10)
    actual = input.concat(input)
    assert actual == expected, "Test failed"


# Generated at 2022-06-26 00:11:02.702725
# Unit test for constructor of class Last
def test_Last():
    Last_1 = Last(15)
    assert True



# Generated at 2022-06-26 00:11:04.619450
# Unit test for method __str__ of class Max
def test_Max___str__():
    str_0 = Max.__str__(Max(1))
    str_1 = str_0 == 'Max[value=1]'
    assert str_1 == True


# Generated at 2022-06-26 00:11:17.702514
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert type(Sum(1234)) == Sum


# Generated at 2022-06-26 00:11:25.633417
# Unit test for method concat of class Map
def test_Map_concat():
    Sum_0 = Sum(
        1
    )
    Map_0 = Map(
        {
            'b': Sum_0,
            'd': Sum_0
        }
    )
    Sum_1 = Sum(
        1
    )
    Map_1 = Map(
        {
            'a': Sum_1,
            'b': Sum_1
        }
    )
    Map_2 = Map_0.concat(Map_1)

    Sum_2 = Sum(
        1
    )

    assert Sum_2 == Map_2.value['b']
    assert Sum_2 == Map_2.value['d']
    assert Sum_2 == Map_2.value['a']


# Generated at 2022-06-26 00:11:27.178952
# Unit test for constructor of class Map
def test_Map():
    x = Map(1)
    y = Map(2)
    assert x.concat(y) == Map(3)


# Generated at 2022-06-26 00:11:30.241532
# Unit test for method __str__ of class First
def test_First___str__():
    # Fail: str_0 is not equal to 'First'
    str_0 = First(1).__str__()
    eq_(str_0, 'First')


# Generated at 2022-06-26 00:11:32.283434
# Unit test for method __str__ of class Map
def test_Map___str__():
    
    str_expected = 'Map[value=0]'
    str_actual = str(Map(0))
    assert str_expected == str_actual


# Generated at 2022-06-26 00:11:33.468845
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-26 00:11:34.623396
# Unit test for constructor of class First
def test_First():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-26 00:11:39.171036
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min(5)
    assert min_0.concat(5) == 5
    assert min_0.concat(-5) == -5
    assert min_0.concat(0) == 0


# Generated at 2022-06-26 00:11:44.566174
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last([]).concat(Last([1, 2, 3, 4, 5])) == Last([1, 2, 3, 4, 5])


# Generated at 2022-06-26 00:11:46.786710
# Unit test for constructor of class One
def test_One():
    test_case_0()
    print ('One class constructor test ..... ok')

#test_One()

test_case_0()

# Generated at 2022-06-26 00:12:12.936697
# Unit test for method __str__ of class All
def test_All___str__():
    test_case_0()



# Generated at 2022-06-26 00:12:14.497407
# Unit test for constructor of class Min
def test_Min():
    x = Min(1)
    assert x.value == 1


# Generated at 2022-06-26 00:12:16.221314
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(0).concat(Min(1)).concat(Min(2)) == Min(0)


# Generated at 2022-06-26 00:12:16.880028
# Unit test for constructor of class One
def test_One():
    assert One


# Generated at 2022-06-26 00:12:17.995190
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-26 00:12:21.265104
# Unit test for method concat of class First
def test_First_concat():
    """
    Test for First.concat method
    """

    str_0 = First('First value')
    str_1 = First('Second value')
    str_2 = str_0.concat(str_1)
    assert str_2 == First('First value')


# Generated at 2022-06-26 00:12:23.664778
# Unit test for method concat of class All
def test_All_concat():
    all_0 = All(False)
    all_1 = All(True)
    all_2 = all_0.concat(all_1)
    assert all_2 != False


# Generated at 2022-06-26 00:12:27.705050
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    print('Test for method fold of class Semigroup')
    semigroup = Sum(3)
    fn = lambda x: x + 3
    assert semigroup.fold(fn) == 6
    assert semigroup.fold(lambda x: x+5) == 8


# Generated at 2022-06-26 00:12:30.588460
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    str_0 = 'Neutral[value=Neutral]'
    sum_0 = Semigroup(str_0)
    sum_1 = Semigroup(str_0)
    assert sum_0 == sum_1


# Generated at 2022-06-26 00:12:31.731117
# Unit test for method __str__ of class Last
def test_Last___str__():
    str_0 = str(Last(49))


# Generated at 2022-06-26 00:12:59.476586
# Unit test for method __str__ of class One
def test_One___str__():
    one_0 = One(None)
    str_0 = one_0.__str__()
    assert str_0 == "One[value=None]"


# Generated at 2022-06-26 00:13:00.564105
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(0) == Sum(0)


# Generated at 2022-06-26 00:13:02.844569
# Unit test for method concat of class All
def test_All_concat():
    all_0 = All(None)
    all_1 = All(all_0.concat(All(None)))
    str_0 = all_1.__str__()


# Generated at 2022-06-26 00:13:04.883965
# Unit test for constructor of class Semigroup
def test_Semigroup():
    semigroup0 = Sum(1)
    semigroup0.value = 1
    assert semigroup0.value == 1
    assert isinstance(semigroup0, Sum)


# Generated at 2022-06-26 00:13:06.798747
# Unit test for method concat of class Max
def test_Max_concat():
    max_0 = Max(None)
    max_1 = Max(None)
    max_0.concat(max_1)


# Generated at 2022-06-26 00:13:09.247882
# Unit test for method __str__ of class Max
def test_Max___str__():
    max_0 = Max(0)
    str_0 = max_0.__str__()


# Generated at 2022-06-26 00:13:15.889816
# Unit test for method __str__ of class Max
def test_Max___str__():
    sum_0 = Sum([])
    sum_1 = Sum([-1, 0, 1])
    sum_2 = Sum([0])
    max_0 = Max(sum_0.value)
    max_1 = Max(sum_1.value)
    max_2 = Max(sum_2.value)

    str_0 = max_0.__str__()
    str_1 = max_1.__str__()
    str_2 = max_2.__str__()

    result = str_0 + str_1 + str_2


# Generated at 2022-06-26 00:13:17.445810
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(3).concat(Last(4)) == Last(4)



# Generated at 2022-06-26 00:13:19.415252
# Unit test for constructor of class Max
def test_Max():
    max_1 = Max(1)
    max_2 = Max(2)
    max_1.concat(max_2)


# Generated at 2022-06-26 00:13:25.211909
# Unit test for method __str__ of class One
def test_One___str__():
    all_0 = All(None)
    str_0 = all_0.__str__()
    all_1 = All(None)
    str_1 = all_1.__str__()
    all_2 = All(None)
    str_2 = all_2.__str__()
    list_0 = [all_0, all_1, all_2]
    sum_0 = Sum(list_0)
    str_3 = sum_0.__str__()
    all_3 = All(None)
    str_4 = all_3.__str__()
    all_4 = All(None)
    str_5 = all_4.__str__()
    all_5 = All(None)
    str_6 = all_5.__str__()

# Generated at 2022-06-26 00:14:30.448970
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    sum_0 = Sum(1)
    n = sum_0.fold(lambda x: x)
    if n == 1:
        print("Test of method fold of class Semigroup PASSED")
    else:
        print("Test of method fold of class Semigroup FAILED")

test_Semigroup_fold()


# Generated at 2022-06-26 00:14:33.634313
# Unit test for constructor of class Last
def test_Last():
    """
    This unit test is example of test case for Monoid class.
    """
    last_0 = Last(str)

    assert last_0.fold(str) == str

    return last_0



# Generated at 2022-06-26 00:14:37.420768
# Unit test for method __str__ of class First
def test_First___str__():
    first_0 = First(First)
    bool_0 = first_0.__eq__(first_0)
    str_0 = first_0.__str__()
    bool_1 = isinstance(first_0, Semigroup)
    bool_2 = isinstance(first_0, Semigroup)
    bool_3 = first_0.__eq__(first_0)


# Generated at 2022-06-26 00:14:42.300911
# Unit test for method concat of class All
def test_All_concat():
    # In the following two lines, we declare two variable all_0 and all_1 of type All which is a Semigroup
    # We also initialize them with some values
    all_0 = All(False)
    all_1 = All(True)

    # In the following line, we call the concat method on the variable all_0 which is of type All and pass in the
    # variable all_1 as a parameter. This should return a new variable which is a Semigroup and has the value True
    all_2 = all_0.concat(all_1)

    # In the following line, we print out the variable all_2 to ensure that it has the value True
    print(all_2)
    assert all_2.__eq__(All(True))



# Generated at 2022-06-26 00:14:47.194153
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    # Test 1
    sum_1 = Sum(1)
    list_1 = [sum_1, sum_1, sum_1]
    sum_1.__str__()
    sum_1.fold(list)

    # Test 2
    all_0 = All(False)
    list_0 = [all_0, all_0]
    all_0.__str__()
    all_0.fold(list)


# Generated at 2022-06-26 00:14:51.958887
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    min_0 = None
    list_0 = [Sum, Sum, Sum]
    sum_0 = Sum(list_0)
    str_0 = sum_0.__str__()


# Generated at 2022-06-26 00:14:52.979006
# Unit test for method concat of class All
def test_All_concat():
    all_0 = All(0)
    all_1 = all_0.concat(all_0)
    str_0 = all_1.__str__()


# Generated at 2022-06-26 00:14:54.494241
# Unit test for method __str__ of class Last
def test_Last___str__():
    min_0 = Last()
    str_0 = min_0.__str__()
    assert str_0 == "Last[value=None]"


# Generated at 2022-06-26 00:14:55.857077
# Unit test for method __str__ of class Min
def test_Min___str__():
    min_1 = Min(1)
    str_1 = min_1.__str__()


# Generated at 2022-06-26 00:14:56.595059
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    pass
