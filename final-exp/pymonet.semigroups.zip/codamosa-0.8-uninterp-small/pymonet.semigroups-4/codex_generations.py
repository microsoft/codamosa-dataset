

# Generated at 2022-06-26 00:05:53.327459
# Unit test for method concat of class Min
def test_Min_concat():
    """
    Do not edit this function.
    This function will automatically run when you call "natual.test"
    """

    int_0 = -4917
    int_1 = -2743
    min_0 = Min(int_0)
    min_1 = Min(int_1)
    min_2 = Min(-2948)
    result = min_0 \
        .concat(min_1) \
        .concat(min_2)
    assert result == min_0


# Generated at 2022-06-26 00:05:58.924135
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = 1615
    max_0 = Max(int_0)
    int_1 = -1615
    max_1 = Max(int_1)
    max_2 = max_0.concat(max_1)
    print(max_2)
    int_2 = 1615
    max_3 = Max(int_2)
    bool_0 = max_2 == max_3
    print(bool_0)

test_Max_concat()

# Generated at 2022-06-26 00:06:03.460272
# Unit test for method concat of class Map
def test_Map_concat():
    dict_0 = {
        "1": Sum(1),
        "2": Sum(2)
    }
    dict_1 = {
        "1": Sum(2),
        "2": Sum(3)
    }
    map_0 = Map(dict_0)
    map_1 = Map(dict_1)
    map_2 = map_0.concat(map_1)
    map_2_expected = Map({
        "1": Sum(3),
        "2": Sum(5)
    })
    test_passed = map_2 == map_2_expected
    assert test_passed

# Generated at 2022-06-26 00:06:06.502475
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(-1)) == Max(1)



# Generated at 2022-06-26 00:06:16.408614
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = -114
    max_0 = Max(int_0)
    max_1 = max_0.concat(Max(int_0))
    int_1 = 1547
    max_1 = max_0.concat(Max(int_1))
    int_2 = -1467
    max_1 = max_0.concat(Max(int_2))
    max_0 = max_0.concat(Max((-1467)))
    max_0 = max_0.concat(Max((int_2)))
    max_1 = max_1.concat(Max(int_0))
    max_0 = max_0.concat(Max((-137)))



# Generated at 2022-06-26 00:06:18.264827
# Unit test for method concat of class Min
def test_Min_concat():
    int_0 = 1770
    min_0 = Min.neutral().concat(Min(int_0))


# Generated at 2022-06-26 00:06:21.486438
# Unit test for method concat of class Min
def test_Min_concat():
    int_0 = 500
    min_0 = Min(int_0)
    int_1 = 500
    min_1 = Min(int_1)
    min_0.concat(min_1)



# Generated at 2022-06-26 00:06:32.366811
# Unit test for method concat of class Min
def test_Min_concat():
    int_0 = -1535
    int_1 = 51
    int_3 = -1695
    int_2 = 1658
    int_5 = 1544
    int_4 = -1108
    min_0 = Min(int_1)
    min_1 = Min(int_4)
    min_2 = min_1.concat(min_0)
    int_6 = int_3
    int_7 = int_2
    int_8 = int_4
    int_9 = int_1
    int_10 = int_5
    int_11 = int_0
    max_0 = Max(int_6)
    max_1 = Max(int_7)
    max_2 = max_1.concat(max_0)
    min_3 = Min(int_6)
   

# Generated at 2022-06-26 00:06:39.899716
# Unit test for method concat of class Min
def test_Min_concat():
    int_0 = -1615
    int_1 = 1615
    int_2 = -3030
    int_3 = 3030
    min_0 = Min(int_0)
    min_1 = Min(int_1)
    min_2 = Min(int_2)
    min_3 = Min(int_3)
    min_result_0 = min_0.concat(min_1)
    min_result_1 = min_2.concat(min_3)
    assert (min_result_0.value == -1615)
    assert (min_result_1.value == -3030)


# Generated at 2022-06-26 00:06:47.513714
# Unit test for method concat of class Map
def test_Map_concat():
    map_0 = Map({
        "a": Sum(1),
        "b": Sum(2),
        "c": Sum(3),
        "d": Sum(4)
    })
    map_1 = Map({
        "a": Sum(4),
        "b": Sum(2),
        "c": Sum(3),
        "d": Sum(5)
    })
    assert map_0.concat(map_1).value == {
        "a": Sum(5),
        "b": Sum(4),
        "c": Sum(6),
        "d": Sum(9)
    }

# Generated at 2022-06-26 00:06:54.692881
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    int_0 = 1615
    int_1 = -1942
    max_0 = Max(int_0)
    max_1 = Max(int_1)
    max_2 = Max(int_0)
    assert (max_0 == max_1) == False
    assert max_0 == max_2


# Generated at 2022-06-26 00:07:01.513366
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    int_0 = 1615
    max_0 = Max(int_0)
    int_1 = -2992
    max_1 = Max(int_1)
    bool_0 = max_1.__eq__(max_0)
    int_2 = -2992
    max_2 = Max(int_2)
    bool_1 = max_1.__eq__(max_2)
    assert(bool_0 == False)
    assert(bool_1 == True)


# Generated at 2022-06-26 00:07:03.151861
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    semigroup = Sum(1)
    assert str(semigroup) == 'Sum[value=1]'


# Generated at 2022-06-26 00:07:04.758302
# Unit test for method __str__ of class First
def test_First___str__():
    obj = First(None)
    assert obj.__str__() == 'Fist[value=None]'


# Generated at 2022-06-26 00:07:06.474994
# Unit test for method __str__ of class First
def test_First___str__():
    int_0 = 638
    first_0 = First(int_0)



# Generated at 2022-06-26 00:07:09.488908
# Unit test for method concat of class Last
def test_Last_concat():
    value_0 = Last(12)
    value_1 = Last(13)
    value_2 = value_0.concat(value_1)
    value_3 = 13
    value_4 = value_2.value
    assert value_3 == value_4



# Generated at 2022-06-26 00:07:11.610909
# Unit test for method __str__ of class First
def test_First___str__():
    int_0 = 161
    first_0 = First(int_0)
    str_0 = str(first_0)
    assert str_0 == 'Fist[value=161]'


# Generated at 2022-06-26 00:07:14.423685
# Unit test for method __str__ of class Last
def test_Last___str__():
    int_0 = -1781317363
    last_0 = Last(int_0)
    str_0 = last_0.__str__()
    assert type(str_0) is str



# Generated at 2022-06-26 00:07:18.771879
# Unit test for method __str__ of class One
def test_One___str__():
    int_0 = 5827
    one_0 = One(int_0)
    assert one_0.__str__() == 'One[value=5827]'



# Generated at 2022-06-26 00:07:26.441876
# Unit test for method concat of class Map
def test_Map_concat():
    int_0 = 1469
    any_0 = Map({})
    any_1 = Map(any_0.concat(any_0))
    str_0 = "fD{i#"
    str_1 = str_0[::-1]
    float_0 = float(str_1)
    float_1 = float(str_0)
    float_2 = float(str_1)

# Generated at 2022-06-26 00:07:32.390286
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)).value == True
    assert One(True).concat(One(True)).value == True
    assert One(False).concat(One(False)).value == False
    assert One(False).concat(One(True)).value == True


# Generated at 2022-06-26 00:07:35.855888
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)).value == 2
    assert Last(3).concat(Last(4)).value == 4


# Generated at 2022-06-26 00:07:42.120806
# Unit test for method concat of class Min
def test_Min_concat():
    int_0 = 1615
    min_0 = Min(int_0)

    int_1 = -1615
    min_1 = Min(int_1)

    stream_0 = Stream(min_1)

    min_0.add(min_1)

    min_0.map(lambda x: x)

    min_0.filter(lambda x: x)

    min_0.fold(lambda x: x)

    min_0.concat(min_1)


# Generated at 2022-06-26 00:07:47.804757
# Unit test for method __str__ of class Map
def test_Map___str__():
    with codecs.open("/home/npm/workspace/src/npm/fp-ts/test/map.d.ts.golden", "r", "utf-8") as file:
        test_case_0_true_value = file.read()
    test_case_0_calc_value = str(test_case_0().value)
    assert test_case_0_true_value == test_case_0_calc_value


# Generated at 2022-06-26 00:07:52.827085
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    int_0 = 1615
    max_0 = Max(int_0)
    assert str(max_0) == 'Max[value=1615]', 'Method Sum.__str__() returned unexpected result (1).'


# Generated at 2022-06-26 00:07:54.113685
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert repr(Map.neutral()) == 'Map[value={}]'



# Generated at 2022-06-26 00:07:56.343242
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(-1).concat(Min(-2)) == Min(-2)


# Generated at 2022-06-26 00:08:00.021814
# Unit test for method __str__ of class Map
def test_Map___str__():
    map_0 = Map({1: Sum(1)})
    map_0_res = map_0.__str__()
    assert map_0_res == 'Map[value={1: Sum[value=1]}]'


# Generated at 2022-06-26 00:08:01.345490
# Unit test for constructor of class First
def test_First():
    with pytest.raises(TypeError):
        First(1)

# Generated at 2022-06-26 00:08:10.739806
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({"a":Sum(1), "b":Sum(2), "c":Sum(3)})) == "Map[value={'a': Sum[value=1], 'b': Sum[value=2], 'c': Sum[value=3]}]"
    assert str(Map({"a":All(True), "b":All(False)})) == "Map[value={'a': All[value=True], 'b': All[value=False]}]"
    assert str(Map({"a":One(True), "b":One(False)})) == "Map[value={'a': One[value=True], 'b': One[value=False]}]"

# Generated at 2022-06-26 00:08:15.706607
# Unit test for constructor of class All
def test_All():
    all_true = All(True)
    assert all_true.value, 'All should have true value'

    all_false = All(False)
    assert not all_false.value, 'All should have false value, but found true'



# Generated at 2022-06-26 00:08:17.132322
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)


# Generated at 2022-06-26 00:08:18.789875
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    return str(Sum(0)) == "Sum[value=0]"


# Generated at 2022-06-26 00:08:27.337118
# Unit test for constructor of class Map
def test_Map():
    map_0 = Map({'key_0': Sum(int_0), 'key_1': Sum(int_1)})
    start_0 = TimeIt()
    for _ in range(100):
        map_1 = Map({'key_0': Sum(int_0), 'key_1': Sum(int_1)})
        map_2 = Map({'key_0': Sum(int_0), 'key_1': Sum(int_1)})
        map_3 = Map({'key_0': Sum(int_0), 'key_1': Sum(int_1)})
        map_4 = Map({'key_0': Sum(int_0), 'key_1': Sum(int_1)})
    end_0 = TimeIt()
    print("test_Map took : ", end_0 - start_0)

# Generated at 2022-06-26 00:08:37.327196
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = 1615
    max_0 = Max(int_0)
    int_1 = 1147
    max_1 = Max(int_1)
    max_2 = max_0.concat(max_1)
    assert 1615 == max_2.value
    int_2 = 1521
    max_3 = Max(int_2)
    max_4 = max_2.concat(max_3)
    assert 1615 == max_4.value
    int_3 = -1557
    max_5 = Max(int_3)
    max_6 = max_4.concat(max_5)
    assert 1615 == max_6.value
    int_4 = -252
    max_7 = Max(int_4)

# Generated at 2022-06-26 00:08:39.608663
# Unit test for constructor of class Sum
def test_Sum():
    value_1 = -2
    sum_1 = Sum(value_1)
    assert sum_1.value == value_1, "Sum constructor is failed"


# Generated at 2022-06-26 00:08:41.752308
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert 'Max[value={}]'.format(test_case_0.max_0.value) == test_Max___str__.__annotations__['return']


# Generated at 2022-06-26 00:08:44.475140
# Unit test for method concat of class Last
def test_Last_concat():
    assert isinstance(Last(0).concat(Last(1)), Last)
    assert Last(0).concat(Last(1)) == Last(1)



# Generated at 2022-06-26 00:08:48.705992
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    :return: void func
    """
    int_0 = 1615
    int_1 = -847
    sum_0 = Sum(int_0)
    sum_1 = Sum(int_1)
    print(sum_0, ' + ', sum_1, ' = ', sum_0.concat(sum_1))



# Generated at 2022-06-26 00:08:51.309555
# Unit test for method concat of class First
def test_First_concat():
    value_0 = 5
    first_0 = First(value_0)
    value_1 = 4
    first_1 = First(value_1)
    first_2 = first_0.concat(first_1)


# Generated at 2022-06-26 00:08:55.136942
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-26 00:08:59.585657
# Unit test for method concat of class Map
def test_Map_concat():
    str_0 = 'Map[value=a]'
    str_1 = 'Map[value=b]'
    Map_0 = Map(str_0)
    Map_1 = Map(str_1)
    Map_0.concat(Map_1)


# Generated at 2022-06-26 00:09:08.408569
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).concat(All(True)).concat(All(True)) == All(True)
    assert All(True).concat(All(True)).concat(All(True)).concat(All(False)) == All(False)
    assert All(True).concat(All(True)).concat(All(False)).concat(All(True)) == All(False)
    assert All(True).concat(All(False)).concat(All(True)).concat(All(True)) == All(False)
    assert All(False).concat(All(True)).concat(All(True)).concat(All(True)) == All(False)
    assert All(False).concat(All(True)).concat(All(True)).concat(All(False)) == All(False)
   

# Generated at 2022-06-26 00:09:10.551814
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min(20)
    assert min_0.concat(Min(10)).value == 10



# Generated at 2022-06-26 00:09:13.128451
# Unit test for constructor of class Map
def test_Map():
    str_0 = 'Map[value={}]'
    map_0 = Map({})
    assert str_0.format(map_0.value) == str(map_0)



# Generated at 2022-06-26 00:09:14.894080
# Unit test for method __str__ of class First
def test_First___str__():
    str_0 = 'Fist[value=5]'
    assert str(First(5)) == str_0



# Generated at 2022-06-26 00:09:16.392853
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(2).concat(Max(3)) == Max(3)


# Generated at 2022-06-26 00:09:24.874234
# Unit test for constructor of class Min
def test_Min():
    num_0 = Min(5)
    num_1 = Min(5)
    num_2 = Min(5)
    num_3 = Min(5)
    num_4 = Min(5)
    num_5 = Min(5)
    num_6 = Min(None)
    num_7 = Min(None)
    num_8 = Min(None)
    num_9 = Min(None)
    num_10 = Min(None)
    num_11 = Min(None)
    num_12 = Min(5)
    num_13 = Min(5)
    num_14 = Min(5)
    num_15 = Min(5)
    num_16 = Min(5)
    num_17 = Min(5)


# Generated at 2022-06-26 00:09:26.390968
# Unit test for constructor of class Sum
def test_Sum():
    obj = Sum(0)
    assert str(obj) == "Sum[value=0]"


# Generated at 2022-06-26 00:09:28.204068
# Unit test for constructor of class One
def test_One():
    expected = One(True).fold(lambda x:x)
    actual = True
    assert(expected == actual)


# Generated at 2022-06-26 00:09:36.585829
# Unit test for constructor of class Semigroup
def test_Semigroup():
    pass
    str_0 = 'Max[value=2]'
    str_1 = 'Max[value=1]'
    str_2 = 'Max[value=3]'
    obj_0 = Max(1)
    obj_1 = Max(2)
    obj_2 = Max(3)
    assert str_0 == str(obj_0)
    assert str_1 == str(obj_1)
    assert str_2 == str(obj_2)


# Generated at 2022-06-26 00:09:40.609873
# Unit test for method __str__ of class One
def test_One___str__():
    str_0 = One(One(One(One(False))).value).__str__()
    str_1 = One(One(One(One(One(True)))).value).__str__()
    assert ((str_0 == 'One[value=False]') and (str_1 == 'One[value=True]'))


# Generated at 2022-06-26 00:09:43.144622
# Unit test for method concat of class Max
def test_Max_concat():
    assert str(Max(1).concat(Max(2))) == 'Max[value={}]'.format(max(1, 2))


# Generated at 2022-06-26 00:09:45.814952
# Unit test for method __str__ of class First
def test_First___str__():
    str_0 = 'Fist[value={}]'

    f_0 = First({})
    s_0 = f_0.__str__()
    assert str_0 == s_0


# Generated at 2022-06-26 00:09:55.307276
# Unit test for constructor of class Last
def test_Last():
    assert Last(5).fold(str) == 'Last[value=5]'
    assert Last(5).concat(Last(6)).fold(str) == 'Last[value=6]'
    assert Last(5).concat(Last(6)).fold(str) == 'Last[value=6]'
    assert Last(5).concat(Last(6)).fold(str) == 'Last[value=6]'

    # example of Monoid laws for Last:

    x = Last(6)
    y = Last(6)
    assert x.concat(y).concat(Last(8)).fold(str) == x.concat(y.concat(Last(8))).fold(
        str)

    def identity_law(x):
        return x.concat(Last.neutral()).fold(str) == x.fold(str)

# Generated at 2022-06-26 00:09:58.581131
# Unit test for method concat of class Min
def test_Min_concat():
    obj_0 = Min(9.090432340721416)
    obj_1 = obj_0.concat(Min(3.7760277310771654))
    assert str(obj_1) == 'Min[value=3.7760277310771654]'



# Generated at 2022-06-26 00:09:59.874136
# Unit test for constructor of class Max
def test_Max():
    val = 0
    m = Max(val)
    assert m.value == val
    assert hasattr(m, 'concat')


# Generated at 2022-06-26 00:10:02.524683
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min(1.0)
    min_1 = Min(2.0)
    assert min_0.concat(min_1).value == 1.0


# Generated at 2022-06-26 00:10:03.384867
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    pass # TODO


# Generated at 2022-06-26 00:10:05.355782
# Unit test for constructor of class Sum
def test_Sum():
    test_case_0()

if __name__ == '__main__':
    # test_case_0()
    pass

# Generated at 2022-06-26 00:10:11.513092
# Unit test for method __str__ of class First
def test_First___str__():
    obj = First(1)
    is_equal = obj.__str__() == "Fist[value=1]"
    print(obj)
    assert is_equal


# Generated at 2022-06-26 00:10:15.450152
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = 1615
    int_1 = 1145
    semigroup_0 = Min(int_1)
    semigroup_1 = Max(int_0)
    actual_0 = semigroup_0.concat(semigroup_1)

    assert (actual_0.value == 1145)


# Generated at 2022-06-26 00:10:17.622686
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_0 = Sum(4)
    sum_1 = Sum(6)
    assert sum_0.concat(sum_1).value == 10


# Generated at 2022-06-26 00:10:26.897195
# Unit test for method concat of class Min
def test_Min_concat():
    int_0 = -511
    min_0 = Min(int_0)
    int_1 = 48
    min_1 = Min(int_1)
    int_2 = -839
    min_2 = Min(int_2)
    int_3 = -739
    min_3 = Min(int_3)
    int_4 = -29
    min_4 = Min(int_4)
    int_5 = -323
    min_5 = Min(int_5)
    min_6 = min_5.concat(min_1)
    min_7 = min_6.concat(min_4)
    int_8 = -847
    min_8 = Min(int_8)
    min_9 = min_3.concat(min_7)
    min_10 = min

# Generated at 2022-06-26 00:10:36.702610
# Unit test for method __str__ of class First
def test_First___str__():
    expected_str_0 = 'Fist[value=?]'
    result_str_0 = First(None).__str__()
    assert result_str_0 == expected_str_0
    expected_str_1 = 'Fist[value=?]'
    result_str_1 = First(None).__str__()
    assert result_str_1 == expected_str_1
    expected_str_2 = 'Fist[value=abc]'
    result_str_2 = First('abc').__str__()
    assert result_str_2 == expected_str_2
    expected_str_3 = 'Fist[value=abc]'
    result_str_3 = First('abc').__str__()
    assert result_str_3 == expected_str_3
    expected_str_4 = 'Fist[value=123]'

# Generated at 2022-06-26 00:10:39.058924
# Unit test for method __str__ of class All
def test_All___str__():
    int_0 = 1615
    all_0 = All(int_0)
    assert all_0.__str__() == 'All[value=1615]'


# Generated at 2022-06-26 00:10:39.857850
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True


# Generated at 2022-06-26 00:10:43.164225
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_0 = Sum(0)
    sum_1 = Sum(1)
    sum_2 = Sum(2)
    assert sum_0.concat(sum_1) == Sum(1)
    assert sum_1.concat(sum_2) == Sum(3)
    assert sum_2.concat(sum_1) == Sum(3)


# Generated at 2022-06-26 00:10:46.736050
# Unit test for method concat of class Sum
def test_Sum_concat():
    arg_0 = Sum(10)
    arg_1 = Sum(20)
    res_0 = arg_0.concat(arg_1)

    assert res_0 == Sum(30)



# Generated at 2022-06-26 00:10:50.192886
# Unit test for method __str__ of class One
def test_One___str__():
    str_0 = 'One[value=False]'
    One_0 = One(False)
    One_1 = One(True)
    str_1 = str(One_0)
    assert(One_1.__str__() == str_0)
    assert(str_1 == str_0)


# Generated at 2022-06-26 00:10:59.044770
# Unit test for method __str__ of class Max
def test_Max___str__():
    int_0 = 1615
    max_0 = Max(int_0)
    assert max_0.__str__() == 'Max[value=1615]'



# Generated at 2022-06-26 00:11:06.646981
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    int_0 = 925
    int_1 = 925
    int_2 = -233
    int_3 = 925
    int_4 = 925
    int_5 = 925
    int_6 = 925
    int_7 = 925
    assert Sum(int_0) == Sum(int_1)
    assert not (Sum(int_1) == Sum(int_2))
    assert Sum(int_3) == Sum(int_4)
    assert not (Sum(int_4) == Sum(int_5))
    assert Sum(int_6) == Sum(int_7)
    assert not (Sum(int_0) == Sum(int_6))
    assert All(int_0) == All(int_1)
    assert not (All(int_1) == All(int_2))

# Generated at 2022-06-26 00:11:10.491191
# Unit test for method __str__ of class Last
def test_Last___str__():
    int_0 = 1140
    last_0 = Last(int_0)
    actual = last_0.__str__()
    assert actual == 'Last[value=1140]', 'Got %s expected %s' % (actual, 'Last[value=1140]')


# Generated at 2022-06-26 00:11:12.551954
# Unit test for constructor of class First
def test_First():
    first_0 = First(1)
    first_1 = First(2)
    assert first_0.concat(first_1) == first_0


# Generated at 2022-06-26 00:11:18.905253
# Unit test for constructor of class Sum
def test_Sum():
    int_0 = 12
    sum_0 = Sum(int_0)
    assert sum_0.value == 12
    assert sum_0.value == 12
    assert sum_0.value == 12
    assert sum_0.value == 12
    assert sum_0.value == 12
    assert sum_0.value == 12
    assert sum_0.value == 12


# Generated at 2022-06-26 00:11:20.446157
# Unit test for constructor of class Last
def test_Last():
    string_0 = 'string_0'
    last_0 = Last(string_0)


# Generated at 2022-06-26 00:11:25.666597
# Unit test for method concat of class Last
def test_Last_concat():
    # Define test inputs
    first_value = -28
    second_value = 904
    # Create Last with first_value
    first_last = Last(first_value)
    # Create Last with second_value
    second_last = Last(second_value)
    # Use concat method of first_last
    result = first_last.concat(second_last)
    # Assert returns
    assert result == Last(second_value)


# Generated at 2022-06-26 00:11:30.319983
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = 1615
    max_0 = Max(int_0)
    int_1 = 1167
    max_1 = Max(int_1)
    max_0 = max_0.concat(max_1)
    int_2 = 1615
    max_2 = Max(int_2)
    assert max_0 == max_2


# Generated at 2022-06-26 00:11:32.660905
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map(dict())) == "Map[value={}]"
    assert str(Map(dict(foo='foo'))) == "Map[value={'foo': 'foo'}]"



# Generated at 2022-06-26 00:11:38.385694
# Unit test for method concat of class Max
def test_Max_concat():
    int_0 = 1615
    int_1 = 1011
    max_0 = Max(int_0)
    max_1 = Max(int_1)
    max_0_concat_max_1 = max_0.concat(max_1)

    assert int_0 == max_0_concat_max_1.value


# Generated at 2022-06-26 00:11:52.449971
# Unit test for method __str__ of class One
def test_One___str__():
    value = 73
    one = One(value)
    assert str(one) == "One[value=73]"


# Generated at 2022-06-26 00:11:58.814832
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(True).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-26 00:12:09.911499
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    int_0 = None
    list_1 = [int_0, 3]
    semantic_arity_0 = SemanticArity(list_1, 1)
    semantic_arity_1 = SemanticArity(list_1, 1)
    semantic_arity_2 = SemanticArity(list_1, 1)
    bool_0 = bool(int_0)
    bool_1 = bool(int_0)
    bool_2 = bool(int_0)
    bool_3 = bool(int_0)
    bool_4 = bool(int_0)
    bool_5 = bool(int_0)
    bool_6 = bool(int_0)
    bool_7 = bool(int_0)
    bool_8 = bool(int_0)
    bool_9 = bool(int_0)
    bool

# Generated at 2022-06-26 00:12:11.406474
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-26 00:12:13.381070
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(0)) == 'Fist[value=0]'



# Generated at 2022-06-26 00:12:17.691699
# Unit test for method concat of class Map
def test_Map_concat():
    map_0 = Map({
        "b": Sum(10),
        "a": Sum(1),
        "c": Sum(100)
    })

    map_1 = Map({
        "b": Sum(10),
        "a": Sum(2),
        "c": Sum(200)
    })


# Generated at 2022-06-26 00:12:21.538330
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(0) == Last(3).concat(Last(0))
    assert Last(0) == Last(0).concat(Last(3))
    assert Last(2) == Last(2).concat(Last(3))
    assert Last(3) == Last(3).concat(Last(2))


# Generated at 2022-06-26 00:12:25.609204
# Unit test for method concat of class One
def test_One_concat():
    int_0 = 1615
    one_0 = One(int_0)
    int_1 = 795
    one_1 = One(int_1)
    one_2 = one_0.concat(one_1)
    assert one_2.value == True


# Generated at 2022-06-26 00:12:26.801464
# Unit test for constructor of class Max
def test_Max():
    assert Max(42).value == 42


# Generated at 2022-06-26 00:12:27.891693
# Unit test for constructor of class Max
def test_Max():
    assert Max(100).value == 100
    assert Max(100)



# Generated at 2022-06-26 00:12:59.665695
# Unit test for constructor of class Sum
def test_Sum():

    # Test for addition of two integers
    int_0 = 1615
    int_1 = 75
    sum_0 = Sum(int_0)
    sum_1 = Sum(int_1)
    sum_2 = sum_0.concat(sum_1)
    assert sum_2.value == 1690

    # Test for addition of two floats
    float_0 = 5.526
    float_1 = 5.821
    sum_3 = Sum(float_0)
    sum_4 = Sum(float_1)
    sum_5 = sum_3.concat(sum_4)
    assert sum_5.value == 11.347

    # Test for addition of an integer and a float
    sum_6 = Sum(int_0)
    sum_7 = Sum(float_0)
    sum_8 = sum

# Generated at 2022-06-26 00:13:02.253302
# Unit test for constructor of class All
def test_All():
    with pytest.raises(TypeError):
        All(hidden=True)

    # Valid constructors
    All(True)
    All(1)
    All(0)
    All(False)
    All(None)


# Generated at 2022-06-26 00:13:03.525226
# Unit test for method __str__ of class One
def test_One___str__():
    # Test
    int_0 = 1615
    one_0 = One(int_0)
    assert str(one_0) == 'One[value=1615]'


# Generated at 2022-06-26 00:13:05.645105
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    int_0 = 1615
    max_0 = Max(int_0)
    boolean_0 = max_0.__eq__(max_0)
    assert boolean_0


# Generated at 2022-06-26 00:13:09.008323
# Unit test for constructor of class Map
def test_Map():
    m1 = Map({1: 1, 2: 4})
    assert m1.value[1].value == 1
    assert m1.value[2].value == 4

# Generated at 2022-06-26 00:13:11.596193
# Unit test for method concat of class Min
def test_Min_concat():
    int_0 = -2030
    int_1 = 1602
    min_0 = Min(int_0)
    min_1 = Min(int_1)
    min_2 = min_0.concat(min_1)


# Generated at 2022-06-26 00:13:14.984704
# Unit test for method __str__ of class All
def test_All___str__():
    int_0 = 612
    all_0 = All(int_0)
    s_0 = all_0.__str__()
    assert s_0 == 'All[value=612]'


# Generated at 2022-06-26 00:13:19.005520
# Unit test for method concat of class Map
def test_Map_concat():
    int_0 = 'b'
    map_0 = Map({'a': Sum(1615), 'b': Sum(2)})
    map_1 = map_0.concat(Sum(2))
    map_2 = Map({'b': Sum(4)})
    assert {int_0: map_1[int_0]} == map_2
    

# Generated at 2022-06-26 00:13:22.359292
# Unit test for method concat of class First
def test_First_concat():
    string_0 = "The answer is "
    string_1 = "42"
    string_2 = "The answer is 42"
    first_0 = First(string_0)
    first_1 = First(string_1)

    result = first_0.concat(first_1)

    assert result.value == string_2


# Generated at 2022-06-26 00:13:24.355035
# Unit test for method __str__ of class Max
def test_Max___str__():
    max_0 = Max(int_0)
    obj_0 = max_0.__str__()
    assert obj_0.__eq__('Max[value=1615]')


# Generated at 2022-06-26 00:14:27.491639
# Unit test for constructor of class Last
def test_Last():
    int_0 = 1615
    last_0 = Last(int_0)



# Generated at 2022-06-26 00:14:33.634326
# Unit test for constructor of class All
def test_All():
    bool_0 = True
    all_0 = All(bool_0)
    assert all_0.value == bool_0
    bool_1 = False
    all_1 = All(bool_1)
    assert all_1.value == bool_1
    bool_2 = True
    all_2 = All(bool_2)
    assert all_2.value == bool_2
    bool_2 = not bool_1
    all_2 = All(bool_2)
    assert all_2.value == bool_2


# Generated at 2022-06-26 00:14:36.899334
# Unit test for method concat of class Max
def test_Max_concat():
    int_1 = 1615
    int_2 = 73
    max_1 = Max(int_1)
    max_2 = Max(int_2)
    max_3 = max_1.concat(max_2)
    if max_3.value == 1615:
        return True
    return False


# Generated at 2022-06-26 00:14:37.885862
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1)}) is not None



# Generated at 2022-06-26 00:14:40.221579
# Unit test for method __str__ of class Min
def test_Min___str__():
    int_0 = 8473
    min_0 = Min(int_0)
    str_0 = min_0.__str__()
    if str_0 != "Min[value=8473]":
        print("test_Min___str__ FAILED")


# Generated at 2022-06-26 00:14:43.166614
# Unit test for method __str__ of class One
def test_One___str__():
    assert(str(One(1)) == "One[value=1]")



# Generated at 2022-06-26 00:14:44.096801
# Unit test for constructor of class Max
def test_Max():
    assert max_0.value == int_0



# Generated at 2022-06-26 00:14:50.738625
# Unit test for method concat of class Last
def test_Last_concat():
    string_0 = 'z'
    string_1 = 'b'
    last_last_0 = Last(string_0)
    last_last_1 = Last(string_1)
    last_last_0_concat_last_last_1 = last_last_0.concat(last_last_1)
    assert last_last_0_concat_last_last_1 == Last("b")

# Generated at 2022-06-26 00:14:57.626208
# Unit test for method concat of class Map
def test_Map_concat():
    dict_0 = dict()
    dict_0[0] = 0
    dict_1 = dict()
    dict_1[0] = 0
    dict_2 = dict()
    dict_2[0] = 0
    map_0 = Map(dict_0)
    map_1 = Map(dict_1)
    map_2 = Map(dict_2)
    map_2 = map_1.concat(map_2)
    if map_0.equals(map_2):
        map_0 = Map(dict_0)
        map_0 = map_0.concat(map_1)
    else:
        raise ValueError("Map.concat() method test failed")


# Generated at 2022-06-26 00:15:03.195989
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    int_0 = 1615
    float_0 = float('-inf')
    float_1 = float('inf')
    str_0 = 'Sum[value={}]'.format(int_0)
    bool_0 = True
    sum_0 = Sum(int_0)
    sum_1 = Sum(float_0)
    sum_2 = Sum(float_1)
    sum_3 = sum_0.concat(sum_1)
    sum_4 = sum_0.concat(sum_2)
    min_0 = Min(int_0)
    min_1 = Min(int_0+1)
    min_2 = min_0.concat(min_1)
    last_0 = Last(sum_0)
    last_1 = Last(sum_1)
    last_2 = last