

# Generated at 2022-06-26 00:05:52.378759
# Unit test for method concat of class Map
def test_Map_concat():
    map_0 = Map({'+': First('+'), '%': Last('%')})
    map_1 = Map({'b': First('b'), 'a': Last('a')})
    map_2 = map_0.concat(map_1)
    map_3 = Map({'b': First('b'), 'a': Last('a')})
    map_4 = map_3.concat(map_0)
    assert str(map_1) == str(map_3) == str(map_2) == str(map_4) == "Map[value={'a': Last[value=a], 'b': First[value=b]}]"

if __name__ == "__main__":
    test_case_0()
    test_Map_concat()

# Generated at 2022-06-26 00:05:57.669295
# Unit test for method concat of class Min
def test_Min_concat():
    semigroup_0 = Min(0.0)
    str_0 = semigroup_0.__str__()
    semigroup_1 = Min(0.0)
    str_1 = semigroup_1.__str__()
    semigroup_2 = semigroup_0.concat(semigroup_1)
    str_2 = semigroup_2.__str__()
    assert((str_2 == str_1))


# Generated at 2022-06-26 00:06:02.624419
# Unit test for method concat of class Max
def test_Max_concat():
    str_0 = '.\x14\x12\x16\x0bAW\x1b'
    max_0 = Max(str_0)
    str_1 = 'VK\n\x18\x1d#\x16\x13\x14'
    max_1 = Max(str_1)
    max_2 = max_0.concat(max_1)
    assert str_1 == max_2.value


# Generated at 2022-06-26 00:06:07.668998
# Unit test for method concat of class Min
def test_Min_concat():
    """
    Test concat
    """
    # Create input
    float_0 = float('inf')
    float_1 = float('inf')
    float_2 = float('nan')
    float_3 = float('nan')
    float_4 = float('inf')
    float_5 = float('inf')
    int_0 = -12
    int_1 = -12
    int_2 = -13
    int_3 = -12
    int_4 = -12
    int_5 = -12
    list_0 = [float_0, float_1, float_2]
    list_1 = [float_3, float_4, float_5]
    list_2 = [int_0, int_1, int_2]
    list_3 = [int_3, int_4, int_5]

# Generated at 2022-06-26 00:06:16.794978
# Unit test for method concat of class Min
def test_Min_concat():
    value_0 = '\x02\x01\x02\b\x01\x0f\x06'
    min_0 = Min(value_0)
    value_1 = '\x02\x01\x02\b\x01\x0f\x06'
    min_1 = Min(value_1)
    value_2 = '\x02\x01\x02\b\x01\x0f\x06'
    min_2 = Min(value_2)
    min_3 = min_0.concat(min_1)
    return min_2.concat(min_3)


# Generated at 2022-06-26 00:06:23.208349
# Unit test for method concat of class Map
def test_Map_concat():
    test_value = {'a': Sum(1), 'b': Sum(2)}
    test_value_2 = {'a': Sum(2), 'b': Sum(1), 'c': Sum(1)}
    test_case_Map_concat = Map(test_value).concat(Map(test_value_2))
    value_a = test_case_Map_concat.value['a'].value
    value_b = test_case_Map_concat.value['b'].value
    value_c = test_case_Map_concat.value['c'].value

    assert value_a == 3
    assert value_b == 3
    assert value_c == 1


# Generated at 2022-06-26 00:06:30.530971
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(0).concat(Max(1)) == Max(1)
    for i in range(100):
        num = random.randint(0, 100)
        assert Max(num).concat(Max(num + 1)) == Max(num + 1)
        assert Max(num + 1).concat(Max(num)) == Max(num + 1)
        assert Max(num + 1).concat(Max(num + 1)) == Max(num + 1)
    assert Max(0).concat(Max(-1)) == Max(0)


# Generated at 2022-06-26 00:06:35.309164
# Unit test for method concat of class Min
def test_Min_concat():
    value_0 = Min('m\x1bAg\x1a')
    value_1 = 'y\r\r'
    value_2 = Min(value_1)
    result_0 = value_0.concat(value_2)
    assert result_0.__str__() == 'Min[value=y\r\r]'


# Generated at 2022-06-26 00:06:37.818238
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(1)
    b = Min(2)
    result = a.concat(b)
    assert result.value == 1


# Generated at 2022-06-26 00:06:43.011801
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min(4)
    min_1 = Min(6)
    min_1.concat(min_0)
    min_2 = Min(6)
    min_3 = min_1.concat(min_2)
    min_3.__str__()
    min_4 = Min(4)
    min_4.__str__()


# Generated at 2022-06-26 00:06:47.007086
# Unit test for method __str__ of class Map
def test_Map___str__():
    map_0 = Map({'a': Sum(5), 'b': Sum(2)})
    assert 'Map[value={\'a\': Sum[value=5], \'b\': Sum[value=2]}]' == map_0.__str__()


# Generated at 2022-06-26 00:06:48.174036
# Unit test for method concat of class Last
def test_Last_concat():
    first = Last(1)
    last = Last(2)
    result = last.concat(first)
    assert result != last


# Generated at 2022-06-26 00:06:56.224381
# Unit test for constructor of class First
def test_First():
    expected_0 = First(1)
    actual_0 = First(1)

    expected_1 = First([1, 2, 3])
    actual_1 = First([1, 2, 3])

    expected_2 = First({1, 2, 3})
    actual_2 = First({1, 2, 3})

    expected_3 = First(None)
    actual_3 = First(None)

    assert expected_0 == actual_0
    assert expected_1 == actual_1
    assert expected_2 == actual_2
    assert expected_3 == actual_3


# Generated at 2022-06-26 00:06:59.610837
# Unit test for constructor of class Min
def test_Min():
    min_0 = Min(5)
    min_1 = Min(1)
    min_res = min_0.concat(min_1)
    assert min_res is not None
    assert min_res.value == 1

# Generated at 2022-06-26 00:07:00.903487
# Unit test for constructor of class Map
def test_Map():
    test_case_0()


# Generated at 2022-06-26 00:07:02.843714
# Unit test for constructor of class All
def test_All():
    sum_1 = Sum(2)
    all_1 = All(sum_1)
    assert all_1.value == True


# Generated at 2022-06-26 00:07:05.138666
# Unit test for method __str__ of class All
def test_All___str__():
    """
    :return: None
    """
    assert All(True).__str__() == 'All[value=True]'

# Unit tests for method concat of class All

# Generated at 2022-06-26 00:07:07.819406
# Unit test for constructor of class Map
def test_Map():
    map_1 = Map({'a': Sum(1), 'b': Sum(2)})
    assert map_1.value == {'a': Sum(1), 'b': Sum(2)}



# Generated at 2022-06-26 00:07:14.015514
# Unit test for method concat of class Map
def test_Map_concat():
    first = Map({
        'a': Sum(1),
        'b': Last(2),
        'c': First('3'),
        'd': Map({
            'd1': Min(2),
            'd2': Max('infinity')
        })
    })

    second = Map({
        'a': Sum(5),
        'b': Last(6),
        'c': First('7'),
        'd': Map({
            'd1': Min(4),
            'd2': Max('Inf')
        })
    })

# Generated at 2022-06-26 00:07:18.655471
# Unit test for method concat of class Max
def test_Max_concat():
    max_0 = Max(number_0)
    max_1 = max_0.concat(Max(number_1))
    assert max_1 == Max(number_1)



# Generated at 2022-06-26 00:07:24.699243
# Unit test for constructor of class Sum
def test_Sum():
    sum_0 = Sum(0)
    sum_0_0 = Sum(0)
    sum_1 = Sum(1)
    assert sum_0 == sum_0_0
    assert sum_0 != sum_1


# Generated at 2022-06-26 00:07:26.716030
# Unit test for method __str__ of class Min
def test_Min___str__():
    a = Min(0)
    print(a)
    assert a.__str__() == 'Min[value=0]'


# Generated at 2022-06-26 00:07:30.746444
# Unit test for method concat of class One
def test_One_concat():
    one_0 = One(1)
    one_1 = One(0)
    one_res = one_0.concat(one_1)
    assert one_res == One(1)


# Generated at 2022-06-26 00:07:35.820533
# Unit test for method concat of class All
def test_All_concat():
    sum_0 = Sum(5)
    sum_1 = Sum(6)
    sum_2 = sum_0.concat(sum_1)
    if sum_2.value != 11:
        raise ValueError("sum_2 value {} not equal 11".format(sum_2.value))


# Generated at 2022-06-26 00:07:45.391585
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = {"a": Last(1), "b": Last(2)}
    map2 = {"a": Last(3), "b": Last(4)}
    assert Map(map1).concat(Map(map2)) == Map({"a": Last(3), "b": Last(4)}) 
    
    map1 = {"a": First(1), "b": First(2)}
    map2 = {"a": First(3), "b": First(4)}
    assert Map(map1).concat(Map(map2)) == Map({"a": First(1), "b": First(2)}) 
    
    map1 = {"a": Last(1), "b": Last(2)}
    map2 = {"a": First(3), "b": First(4)}

# Generated at 2022-06-26 00:07:47.110694
# Unit test for constructor of class Max
def test_Max():
    max_0 = Max(2)
    assert max_0.value == 2


# Generated at 2022-06-26 00:07:53.233409
# Unit test for constructor of class Semigroup
def test_Semigroup():
    print("Testing constructor of Semigroup")
    try:
        value_0 = 0
        Semigroup(value_0)
    except Exception as e:
        print('There is some error in constructor of Semigroup')
        print(e)
        raise
    else:
        print('Testing constructor of Semigroup is completed')



# Generated at 2022-06-26 00:07:57.067250
# Unit test for constructor of class Last
def test_Last():
    # Test to see if an instance of the Last class can be created
    last_1 = Last(3)
    # Test if an instance of the Last class was successfully created
    assert last_1 is not None
    # Test to see if the value attribute of last_1 is equal to the value that was passed into the constructor
    assert last_1.value is 3


# Generated at 2022-06-26 00:08:02.703618
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup.neutral().fold(lambda x: x) is Semigroup.neutral_element

    assert Sum(0).fold(lambda x: x) == 0
    assert All(True).fold(lambda x: x) is True
    assert One(False).fold(lambda x: x) is False
    assert First(1).fold(lambda x: x) == 1
    assert Last(1).fold(lambda x: x) == 1



# Generated at 2022-06-26 00:08:11.803535
# Unit test for method concat of class All
def test_All_concat():
    test_cases = (
        (True, True, True),
        (True, False, False),
        (False, True, False),
        (False, False, False),
    )
    results = (True, False, False, False)

    sum_0 = All(True)
    sum_1 = All(True)
    sum_2 = All(False)
    sum_3 = All(False)

    for test_case, result in zip(test_cases, results):
        check_result = All(test_case[0]).concat(All(test_case[1])).value

# Generated at 2022-06-26 00:08:17.169301
# Unit test for method __str__ of class All
def test_All___str__():
    sum_0 = None
    all_0 = All(sum_0)
    result = all_0.__str__()
    assert isinstance(result, str)


# Generated at 2022-06-26 00:08:19.174160
# Unit test for method __str__ of class Max
def test_Max___str__():
    neutral = Max.neutral()
    assert str(neutral) == 'Max[value=-inf]'


# Generated at 2022-06-26 00:08:21.384444
# Unit test for constructor of class Max
def test_Max():
    max_test = Max(1)
    assert max_test.value == 1
    #assert max_test.neutral() == -float("inf")


# Generated at 2022-06-26 00:08:26.354657
# Unit test for method concat of class Map
def test_Map_concat():
    map_0 = Map({'add': Sum(0) , 'one': One(True)})
    map_1 = Map({'add': Sum(1) , 'one': One(False)})
    map_2 = map_0.concat(map_1)
    assert(map_2.value['add'] == Sum(1))
    assert(map_2.value['one'] == One(False))
    pass


# Generated at 2022-06-26 00:08:31.987972
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    all_1 = All(True)
    all_2 = All(True)
    all_3 = All(False)
    assert all_1.fold(bool) == True
    assert all_2.fold(bool) == True
    assert all_3.fold(bool) == False

    sum_1 = Sum(3)
    sum_2 = Sum(4)
    sum_3 = Sum(-4)
    assert sum_1.fold(bool) == True
    assert sum_2.fold(bool) == True
    assert sum_3.fold(bool) == False

    one_1 = One(True)
    one_2 = One(True)
    one_3 = One(False)
    assert one_1.fold(bool) == True
    assert one_2.fold(bool) == True
    assert one_3

# Generated at 2022-06-26 00:08:36.430852
# Unit test for method __str__ of class All
def test_All___str__():
    sum_0 = Sum(8)
    all_0 = All(sum_0)
    str_0 = all_0.__str__()
    assert str_0 == "All[value=Sum[value=8]]"


# Generated at 2022-06-26 00:08:39.024881
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    sum_0 = Sum(1)
    sum_1 = Sum(2)
    sum_2 = Sum(1)

    assert sum_0 == sum_2
    assert sum_0 != sum_1


# Generated at 2022-06-26 00:08:44.338335
# Unit test for method __str__ of class Max
def test_Max___str__():
    try:
        sum_1 = Max(10)
        all_1 = All(sum_1)

        assert all_1.value is not None
        assert all_1.value == 10

        all_2 = All(all_1.value)
        assert all_2.value is not None
        assert all_2.value == 10
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-26 00:08:46.217257
# Unit test for method __str__ of class One
def test_One___str__():
    actual = str(One(True))
    expected = 'One[value=True]'
    assert actual == expected



# Generated at 2022-06-26 00:08:49.106452
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)

    sum_0 = None
    all_0 = All(sum_0)
    assert all_0.concat(All(False)) == All(False)


# Generated at 2022-06-26 00:09:02.898790
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    # [2019-03-22]
    assert (First("hello") == First("hello")) == True
    assert (Last("hello") == Last("hello")) == True
    assert (All(True) == All(True)) == True
    assert (All(False) == All(False)) == True
    assert (First("hello") != First("world")) == True
    assert (Last("hello") != Last("world")) == True
    assert (All(True) != All(False)) == True
    assert (All(False) != All(True)) == True

    # [2019-03-24]
    assert (One(True) == One(True)) == True
    assert (One(False) == One(False)) == True
    assert (One(True) != One(False)) == True
    assert (One(False) != One(True)) == True

# Generated at 2022-06-26 00:09:04.813258
# Unit test for constructor of class Map
def test_Map():
    dict = {"A":First(1)}
    map = Map(dict)
    assert (map.value == dict)


# Generated at 2022-06-26 00:09:13.447857
# Unit test for constructor of class Sum
def test_Sum():
    # with value = 0
    value_0 = 0
    sum_0 = Sum(value_0)
    assert sum_0.value == value_0

    # with value = 20
    value_1 = 20
    sum_1 = Sum(value_1)
    assert sum_1.value == value_1

    # with value = 10238
    value_2 = 10238
    sum_2 = Sum(value_2)
    assert sum_2.value == value_2

    # with value = -10
    value_3 = -10
    sum_3 = Sum(value_3)
    assert sum_3.value == value_3

    # with value = None
    value_4 = None
    sum_4 = Sum(value_4)
    assert sum_4.value == value_4



# Generated at 2022-06-26 00:09:17.713644
# Unit test for method concat of class Sum
def test_Sum_concat():
    # Assert if semigroup has value
    assert Sum(1).concat(Sum(2)).value == 3
    # Assert if semigroup has no value
    assert Sum(1).concat(Sum(None)).value == 1
    # Assert if semigroups has no value
    assert Sum(None).concat(Sum(None)).value == 0


# Generated at 2022-06-26 00:09:26.312954
# Unit test for method concat of class All
def test_All_concat():
    """
    concat
    """
    try:
        # Test 0
        sum_0 = Sum(2)
        sum_1 = Sum(1)
        all_0 = All(sum_0)
        all_1 = All(sum_1)
        all_2 = all_0.concat(all_1)
        assert all_2.value == sum_0.value and all_2.value == sum_1.value
    except:
        # Test 1
        sum_0 = Sum(1)
        sum_1 = Sum(2)
        all_0 = All(sum_0)
        all_1 = All(sum_1)
        all_2 = all_0.concat(all_1)
        assert all_2.value == sum_1.value and all_2.value == sum_0

# Generated at 2022-06-26 00:09:35.024523
# Unit test for constructor of class One
def test_One():
    one = First(4)
    assert one.value == 4
    assert one.fold(lambda i: i + 1) == 5
    one_1 = Last(5)
    assert one_1.value == 5
    one_2 = one.concat(one_1)
    assert one.value == 4
    assert one_1.value == 5
    assert one_2.value == 5
    one_3 = one_1.concat(one)
    assert one.value == 4
    assert one_1.value == 5
    assert one_3.value == 4

test_case_0()
"""
    sum_0.concat(all_0)
    all_0.concat(sum_0)
"""



# Generated at 2022-06-26 00:09:37.512736
# Unit test for method concat of class Last
def test_Last_concat():
    sum_0 = Sum(0)
    sum_1 = sum_0.concat(Sum(1))
    sum_2 = sum_1.concat(Sum(2))
    return sum_2



# Generated at 2022-06-26 00:09:40.893336
# Unit test for method __str__ of class One
def test_One___str__():
    """
    test for method First.__str__

    :return:
    """
    try:
        one_200 = One(200)
    except RuntimeError:
        assert False
    else:
        assert str(one_200) == "One[value=True]"


# Generated at 2022-06-26 00:09:44.591095
# Unit test for constructor of class Sum
def test_Sum():
    sum_1 = Sum(4)
    sum_2 = Sum(4)
    sum_3 = Sum(3)
    assert (sum_1 == sum_2)
    assert (sum_1 != sum_3)


# Generated at 2022-06-26 00:09:46.415634
# Unit test for method __str__ of class One
def test_One___str__():
    one_0 = One(None)
    assert one_0.__str__() == 'One[value=None]'


# Generated at 2022-06-26 00:09:54.135146
# Unit test for constructor of class Last
def test_Last():
    last = Last(3)
    assert last != None


# Generated at 2022-06-26 00:09:55.915594
# Unit test for method concat of class First
def test_First_concat():
    assert First(10).concat(First(20)) == First(10)


# Generated at 2022-06-26 00:09:58.786555
# Unit test for method concat of class Map
def test_Map_concat():
    map_0 = Map({'a': Sum(1), 'b': All(0)})
    map_1 = Map({'b': Sum(0), 'c': All(1)})
    map_0.concat(map_1)


# Generated at 2022-06-26 00:10:01.206587
# Unit test for constructor of class Last
def test_Last():
    # Create an instance of class Last
    last = Last(300)
    # Make an assert
    assert (last.value == 300), "The assert is failed"
    print("test_Last is passed")
    print(last)



# Generated at 2022-06-26 00:10:04.020402
# Unit test for constructor of class All
def test_All():
    assert All(None) is not None
    assert All(1) is not None
    assert All("b") is not None
    assert All("a") is not None
    assert All(1.0) is not None


# Generated at 2022-06-26 00:10:06.985331
# Unit test for method concat of class First
def test_First_concat():
    # Check value of concat method
    assert First(1).concat(First(2)) == First(1), "Value of concat in First(1).concat(First(2)) is invalid"


# Generated at 2022-06-26 00:10:09.529890
# Unit test for constructor of class Map
def test_Map():
    map_0 = {1: First('a'), 2: Last('b')}
    map_1 = Map(map_0)
    assert map_1.value == map_0



# Generated at 2022-06-26 00:10:13.779434
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_0 = Sum(3)
    sum_1 = Sum(3)
    sum_2 = sum_0.concat(sum_1)
    sum_3 = Sum(6)
    assert sum_2 == sum_3


# Generated at 2022-06-26 00:10:15.792721
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(0)) == 'Sum[value=0]', 'Wrong __str__ from Sum'



# Generated at 2022-06-26 00:10:17.293565
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert All(True) == All(True)
    assert All(False) != All(True)


# Generated at 2022-06-26 00:10:25.868663
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(False)).value == False


# Generated at 2022-06-26 00:10:27.649109
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)



# Generated at 2022-06-26 00:10:29.944426
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum_1 = Sum(2)
    assert str(sum_1) == 'Sum[value=2]'


# Generated at 2022-06-26 00:10:32.871638
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(0)) == "Min[value=0]"
    assert str(Min(None)) == "Min[value=None]"
    assert str(Min(10)) == "Min[value=10]"



# Generated at 2022-06-26 00:10:41.937231
# Unit test for method __str__ of class Last

# Generated at 2022-06-26 00:10:47.620880
# Unit test for method concat of class One
def test_One_concat():
    one = One(True)
    other_one = One(False)
    assert (one.concat(other_one).value == True)
    other_one.value = True
    assert (one.concat(other_one).value == True)
    one.value = False
    other_one.value = False
    assert (one.concat(other_one).value == False)



# Generated at 2022-06-26 00:10:48.788605
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max('value')) == 'Max[value=value]'



# Generated at 2022-06-26 00:10:57.122835
# Unit test for method concat of class One
def test_One_concat():
    one_1 = One(True)
    one_2 = One(False)
    one_3 = One(3)
    one_4 = One("string")
    one_5 = One(None)
    one_6 = One([1, 2])
    one_7 = One(["a", "b"])
    one_8 = One({})
    one_9 = One({"a": 1})
    one_10 = One(())
    one_11 = One((1, 2))
    one_12 = One(Monoid())



# Generated at 2022-06-26 00:11:00.994102
# Unit test for constructor of class Max
def test_Max():
    assert Max(5).concat(Max(4)) == Max(5)
    assert Max(4).concat(Max(5)) == Max(5)
    assert Max(5).fold(lambda x: x) == 5
    

# Generated at 2022-06-26 00:11:03.234209
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)



# Generated at 2022-06-26 00:11:25.098362
# Unit test for constructor of class Semigroup
def test_Semigroup():
    sum_0 = Sum(0)
    sum_1 = Sum(1)
    sum_2 = Sum(2)

    all_0 = All()
    all_1 = All(True)
    all_2 = All(False)

    one_0 = One()
    one_1 = One(True)
    one_2 = One(False)

    first_0 = First()
    first_1 = First(1)
    first_2 = First(2)

    last_0 = Last()
    last_1 = Last(1)
    last_2 = Last(2)

    map_0 = Map()

    max_0 = Max()
    max_1 = Max(1)
    max_2 = Max(2)

    min_0 = Min()
    min_1 = Min(1)
    min_

# Generated at 2022-06-26 00:11:26.879779
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(2) != Semigroup(1)
    assert Semigroup(1) is not None


# Generated at 2022-06-26 00:11:36.184244
# Unit test for method __str__ of class Max
def test_Max___str__():
    min_0 = Min(20)
    min_1 = Min(10)
    min_2 = Min(15)
    max_0 = Max(5)
    max_1 = max_0.concat(min_1)
    assert max_1.__str__() == 'Max[value=10]'
    max_2 = max_0.concat(min_2)
    assert max_2.__str__() == 'Max[value=15]'
    min_3 = min_0.concat(min_2)
    assert min_3.__str__() == 'Min[value=15]'
    min_4 = Min(10)
    max_3 = max_1.concat(min_4)
    assert max_3.__str__() == 'Max[value=10]'

# Generated at 2022-06-26 00:11:39.997237
# Unit test for constructor of class Max
def test_Max():
    sum_0 = Sum(0)
    max_0 = Max(0)
    assert max_0 == Max(0), 'expected: Max[value=0], actual: {}'.format(max_0)


# Generated at 2022-06-26 00:11:42.792985
# Unit test for method __str__ of class First
def test_First___str__():
    source = First(None)
    expected = 'Fist[value=None]'
    actual = source.__str__()
    assert actual == expected, 'Expected {}, but got {}'.format(expected, actual)


# Generated at 2022-06-26 00:11:47.609172
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    semigroup_list = [Sum(0), All(True), One(False),
                      First(True), Last(True),
                      Map({}), Max(-3), Min(3)]
    def fn(x): return x
    for semigroup in semigroup_list:
        assert semigroup.fold(fn) == fn(semigroup.value)

# Generated at 2022-06-26 00:11:51.911183
# Unit test for method concat of class Min
def test_Min_concat():
    # Valid case
    Min1 = Min(0)
    assert Min1.concat(Min1).value == 0
    assert Min1.concat(Min(1)).value == 0
    # Invalid case:
    with pytest.raises(Exception):
        Min1.concat(None)


# Generated at 2022-06-26 00:11:59.177338
# Unit test for constructor of class Map
def test_Map():
    map= {'a':Min(10),'b':Min(20),'c':Min(30)}
    m=Map(map)
    expected={'a':Min(10),'b':Min(20),'c':Min(30)}
    assert m.value==expected

# Generated at 2022-06-26 00:12:02.167605
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(2).concat(Max(4)) == Max(4)
    assert Max(9).concat(Max(0)) == Max(9)
    assert Max(7).concat(Max(7)) == Max(7)


# Generated at 2022-06-26 00:12:04.242448
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum_0 = Sum(0)
    result = sum_0.__str__()
    assert result == "Sum[value=0]"


# Generated at 2022-06-26 00:12:32.556503
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value is True
    assert All(True).concat(All(False)).value is False
    assert All(False).concat(All(True)).value is False
    assert All(False).concat(All(False)).value is False


# Generated at 2022-06-26 00:12:34.279883
# Unit test for method __str__ of class First
def test_First___str__():
    o = First('abc')
    assert 'abc' == o.__str__()

# Generated at 2022-06-26 00:12:37.376068
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum_0 = Sum(1)
    assert_equal(str(sum_0), 'Sum[value=1]', 'test_Sum___str__:01')
    assert_equal(sum_0.value, 1, 'test_Sum___str__:02')


# Generated at 2022-06-26 00:12:38.500361
# Unit test for method __str__ of class First
def test_First___str__():
    # case 0
    First.__str__(First(None))

# Generated at 2022-06-26 00:12:43.200523
# Unit test for constructor of class First
def test_First():
    First(0)
    First('a')
    First(None)
    First(0)
    First(True)
    First([1,2])
    First({'a':1})
    First(('a',1))


# Generated at 2022-06-26 00:12:44.895890
# Unit test for constructor of class Last
def test_Last():
    last_0 = Last("John Lennon")
    assert last_0.value == "John Lennon"

# Generated at 2022-06-26 00:12:54.209777
# Unit test for constructor of class Max
def test_Max():
    # when "value" is float
    max = Max(1.0)
    assert max.value == 1.0

    # when "value" is int
    max = Max(1)
    assert max.value == 1

    # when "value" is zero
    max = Max(0)
    assert max.value == 0

    # when "value" is zero
    max = Max(0.0)
    assert max.value == 0.0

    # when "value" is least float value
    max = Max(-3.4E38)
    assert max.value == -3.4E38

    # when "value" is infinite
    max = Max(float("inf"))
    assert max.value == float("inf")

    # when "value" is least int value
    max = Max(-2147483648)

# Generated at 2022-06-26 00:12:58.228958
# Unit test for method concat of class Map
def test_Map_concat():
    map_0 = Map({"a": Sum(2), "b": Sum(2)})
    map_1 = Map({"b": Sum(1), "c": Sum(1)})
    assert map_0.concat(map_1) == Map({"a": Sum(2), "b": Sum(3), "c": Sum(1)})



# Generated at 2022-06-26 00:13:01.583369
# Unit test for constructor of class Last
def test_Last():
    l0 = Last(0)
    assert l0.value == 0
    l1 = Last(1)
    assert l1.value == 1
    l2 = Last(2)
    assert l2.value == 2
    l3 = Last(3)
    assert l3.value == 3


# Generated at 2022-06-26 00:13:03.443607
# Unit test for method concat of class Last
def test_Last_concat():
    l = Last(1)
    l = l.concat(Last(2))
    assert l.value == 2

# Generated at 2022-06-26 00:13:35.478547
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(0).concat(Max(0)) == Max(0)
    assert Max(0).concat(Max(1)) == Max(1)
    assert Max(1).concat(Max(0)) == Max(1)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-26 00:13:41.202481
# Unit test for method concat of class Max
def test_Max_concat():
    a = Max(-5)
    b = Max(-5)
    c = Max(-5)

    tp1 = a.concat(b)
    print(type(tp1))

    tp2 = a
    print(type(tp2))

    assert(type(tp1) == type(tp2))
    assert(tp1.value == tp2.value)

    c = a.concat(b)
    assert(c.value == a.value)



# Generated at 2022-06-26 00:13:44.064154
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    obj = Sum(2)
    assert obj.fold(lambda value: value + 1) == 3, 'Expected 3'



# Generated at 2022-06-26 00:13:45.632768
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-26 00:13:48.385694
# Unit test for method concat of class One
def test_One_concat():
    one_0 = One(True)
    one_1 = One(False)
    one_0.concat(one_1)


# Generated at 2022-06-26 00:13:49.535614
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == "Max[value=1]"


# Generated at 2022-06-26 00:13:52.197985
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_0 = Sum(1)
    sum_1 = Sum(2)

    sum_2 = sum_0.concat(sum_1)

    if sum_2.value != 3:
        raise Exception("wrong concat execution")


# Generated at 2022-06-26 00:13:57.215821
# Unit test for method concat of class One
def test_One_concat():
    one_0 = One(None)
    one_1 = One(False)
    one_2 = One(False)
    one_res_0 = one_0.concat(one_1)
    one_res_1 = one_1.concat(one_2)


# Generated at 2022-06-26 00:13:59.456187
# Unit test for constructor of class Max
def test_Max():
    assert Max(2) == Max(2)


# Generated at 2022-06-26 00:14:00.982200
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert "Max[value=10]" == str(Max(10))


# Generated at 2022-06-26 00:15:06.445838
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(2)) == "Sum[value=2]"


# Generated at 2022-06-26 00:15:15.509586
# Unit test for method concat of class Map
def test_Map_concat():
    m = Map({1: All(True), 2: All(False)})
    m1 = Map({1: All(True), 2: All(True)})
    m2 = Map({1: All(False), 2: All(True)})
    m3 = Map({1: All(True), 2: All(False)})

    assert(m.concat(m1).value[1].value == True)
    assert(m.concat(m1).value[2].value == False)

    assert(m.concat(m2).value[1].value == False)
    assert(m.concat(m2).value[2].value == True)

    assert(m.concat(m3).value[1].value == True)
    assert(m.concat(m3).value[2].value == False)



# Generated at 2022-06-26 00:15:18.068464
# Unit test for method concat of class First
def test_First_concat():
    first = First(0)
    other = First(1)
    concated = first.concat(other)
    assert concated == first


# Generated at 2022-06-26 00:15:19.791961
# Unit test for method __str__ of class All
def test_All___str__():
    all_0 = All(None)
    assert str(all_0) == 'All[value=None]'



# Generated at 2022-06-26 00:15:26.768258
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min(9)
    min_1 = Min(1)
    min_2 = Min(7)
    min_3 = Min(9)
    min_4 = Min(1)
    min_5 = Min(4)
    min_6 = Min(7)
    min_7 = Min(9)
    min_8 = Min(1)
    min_9 = Min(4)
    min_10 = min_0.concat(min_1)
    min_10.concat(min_2)
    min_10.concat(min_3)
    min_10.concat(min_4)
    min_10.concat(min_5)
    min_10.concat(min_6)
    min_10.concat(min_7)
    min_10

# Generated at 2022-06-26 00:15:33.200105
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum_0 = Sum(0.0)
    assert str(sum_0) == 'Sum[value=0.0]'
    # None
    sum_1 = Sum(sum(None))
    assert str(sum_1) == 'Sum[value=0]'
    # Iterable
    sum_2 = Sum(sum((1, 2, 3)))
    assert str(sum_2) == 'Sum[value=6]'
    sum_3 = Sum(sum(dict.fromkeys((1, 2, 3))))
    assert str(sum_3) == 'Sum[value=6]'


# Generated at 2022-06-26 00:15:34.222577
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)


# Generated at 2022-06-26 00:15:36.291787
# Unit test for method concat of class Last
def test_Last_concat():
    last_0 = Last(1)
    last_1 = Last(2)
    last_2 = last_0.concat(last_1)
    assert last_2 == Last(2)



# Generated at 2022-06-26 00:15:39.969645
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Sum(1) != Sum(4)
    assert Sum(1).value == 1
    assert All(True).value == True
    assert One(True).value == True
    assert First(1).value == 1
    assert Last(2).value == 2
    assert Map({'key':Sum(1)}).value == {'key':Sum(1)}
    assert Max(3).value == 3
    assert Min(3).value == 3

