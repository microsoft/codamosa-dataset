

# Generated at 2022-06-26 00:05:55.862675
# Unit test for constructor of class Semigroup
def test_Semigroup():
    with tap(Semigroup):
        assert Semigroup.neutral_element == None
        assert Semigroup(None).value == None



# Generated at 2022-06-26 00:05:58.759226
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(3)).value == 3
    assert Max(3).concat(Max(1)).value == 3
    assert Max(1).concat(Max(1)).value == 1


# Generated at 2022-06-26 00:06:04.235563
# Unit test for method concat of class First
def test_First_concat():
    # Assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(2)) == First(1)
    # Assert First(1).concat(First('test')) == First(1)
    assert First(1).concat(First('test')) == First(1)
    # Assert First(1).concat(First({'test': 1})) == First(1)
    assert First(1).concat(First({'test': 1})) == First(1)
    

# Generated at 2022-06-26 00:06:10.301361
# Unit test for method concat of class Map
def test_Map_concat():
    f_1 = First('first')
    f_2 = First('second')
    f_3 = First('third')
    expected_result = {'a': First('first'), 'b': First('second'), 'c': First('third')}
    result = Map(
        {'a': f_1, 'b': f_2}
    ).concat(
        Map({'c': f_3})
    )
    assert(result.value == expected_result)


# Generated at 2022-06-26 00:06:18.309399
# Unit test for method __str__ of class All
def test_All___str__():
    str_0 = '0\x00\x1e\x12\x0b\x15\x06\x03\x16\x1b\x16\x0c'
    all_0 = All(str_0)
    all_0_expected = 'All[value={}]'.format(str_0)
    all_0_actual = all_0.__str__()
    assert all_0_expected == all_0_actual, 'Expected : {}, but got: {}'.format(all_0_expected, all_0_actual)


# Generated at 2022-06-26 00:06:27.921042
# Unit test for constructor of class One
def test_One():
    _One = One(True)
    _One = One(False)
    _One = One(None)
    _One = One(1)
    _One = One(1.1)
    _One = One([1, 2, 3])
    _One = One((2, 3, 4))
    _One = One(object())
    _One = One(())
    _One = One('1')
    _One = One(b'1')
    _One = One(One(True))
    _One = One(One(1))
    _One = One(One([1, 2]))
    _One = One(One((1, 2, 3)))
    _One = One(One(object()))
    _One = One(One(()))
    _One = One(One('1'))
    _One

# Generated at 2022-06-26 00:06:36.521531
# Unit test for constructor of class All
def test_All():
    all_1 = All(1)
    assert all_1.value == 1
    all_2 = All(0)
    assert all_2.value == 0
    all_3 = All(True)
    assert all_3.value == True
    all_4 = All(False)
    assert all_4.value == False
    all_5 = All(None)
    assert all_5.value == None
    all_6 = All('')
    assert all_6.value == ""
    all_7 = All('a')
    assert all_7.value == 'a'
    all_8 = All([1, 2])
    assert all_8.value == [1, 2]


# Generated at 2022-06-26 00:06:38.860958
# Unit test for method concat of class Map
def test_Map_concat():
    map_0 = Map({'key-0': Last(True)})
    map_0_concat = map_0.concat(map_0)

    assert map_0 == map_0_concat


# Generated at 2022-06-26 00:06:43.834273
# Unit test for method concat of class First
def test_First_concat():
    assert First('P+').concat(First('T4k')) == First('P+')
    assert First('P+').concat(First('T4k')) != First('T4k')
    assert First('P+').concat(First('T4k')) == First('P+')
    assert First('P+').concat(First('T4k')) != First('T4k')
    assert First('P+').concat(First('T4k')) == First('P+')
    assert First('P+').concat(First('T4k')) != First('T4k')
    assert First('P+').concat(First('T4k')) == First('P+')
    assert First('P+').concat(First('T4k')) != First('T4k')
    assert First

# Generated at 2022-06-26 00:06:44.622519
# Unit test for method __str__ of class Last
def test_Last___str__():
    with pytest.raises(AttributeError):
        Last.__str__()


# Generated at 2022-06-26 00:07:00.662009
# Unit test for method concat of class Map
def test_Map_concat():
    str_0 = 'P+:*T4kBUCGP]_>1wPS'
    str_1 = 'Q~:*T4kBUCGP]_>1wPS'
    str_2 = 'R~:*T4kBUCGP]_>1wPS'
    str_3 = 'V~:*T4kBUCGP]_>1wPS'
    str_4 = 'W~:*T4kBUCGP]_>1wPS'
    str_5 = 'X~:*T4kBUCGP]_>1wPS'
    str_6 = 'Y~:*T4kBUCGP]_>1wPS'
    str_7 = 'Z~:*T4kBUCGP]_>1wPS'
    str_8 = '[~:*T4kBUCGP]_>1wPS'
    str

# Generated at 2022-06-26 00:07:04.330618
# Unit test for method __str__ of class One
def test_One___str__():
    str_0 = 'P+:*T4kBUCGP]_>1wPS'
    one_0 = One(str_0)
    assert str(one_0) == 'One[value=\'P+:*T4kBUCGP]_>1wPS\']'


# Generated at 2022-06-26 00:07:05.579772
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)


# Generated at 2022-06-26 00:07:10.017616
# Unit test for method __str__ of class All
def test_All___str__():
    str_0 = '1'
    all_0 = All(str_0)
    all_1 = All(all_0)
    all_2 = All(all_1)

    assert_equal(str(all_0), str_0)
    assert_equal(str(all_1), str_0)
    assert_equal(str(all_2), str_0)


# Generated at 2022-06-26 00:07:12.354152
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    str_0 = 'P+:*T4kBUCGP]_>1wPS'
    str_1 = '=HYYEu])tC&3qm<M[j'
    str_2 = 'P+:*T4kBUCGP]_>1wPS'
    bool_0 = str_0 == str_1
    bool_1 = str_0 == str_2
    # FIXME: Add more tests


# Generated at 2022-06-26 00:07:18.227325
# Unit test for method __str__ of class All
def test_All___str__():
    all_0 = All(12)
    assert str(all_0) == 'All[value=12]'

    all_0 = All(True)
    assert str(all_0) == 'All[value=True]'

    all_0 = All(False)
    assert str(all_0) == 'All[value=False]'



# Generated at 2022-06-26 00:07:23.680401
# Unit test for method concat of class Map
def test_Map_concat():
    map_0 = Map({})
    map_1 = Map({})
    map_1.concat(map_0)
    assert map_1.value == {}


# Generated at 2022-06-26 00:07:33.523536
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    This function is called to test the constructor of class Semigroup
    """
    print("----------------")
    print("Test for Semigroup")
    print("Input: ")
    
    # Test for Sum
    # Input value
    value = 7
    # Output
    print("Input value: ", value)
    print("Output: ", Sum(value))
    # Test for All
    # Input value
    value = True
    # Output
    print("Input value: ", value)
    print("Output: ", All(value))
    # Test for One
    # Input value
    value = True
    # Output
    print("Input value: ", value)
    print("Output: ", One(value))
    # Test for First
    # Input value
    value = True
    # Output
    print("Input value: ", value)
   

# Generated at 2022-06-26 00:07:39.444083
# Unit test for constructor of class One
def test_One():
    one0 = One(0)
    one1 = One(1)
    assert One.neutral_element == False, "Expected the value to be False"
    assert one0.value == False, "Expected the value to be False"
    assert str(one0) == "One[value=False]", "Expected the value of str to be: One[value=False]"
    assert one1.value == True, "Expected the value to be True"
    assert str(one1) == "One[value=True]", "Expected the value of str to be: One[value=True]"


# Generated at 2022-06-26 00:07:41.898093
# Unit test for constructor of class Last
def test_Last():
    instance_0 = Last(0)
    assert instance_0.value == 0
    instance_1 = Last(1)
    assert instance_1.value == 1


# Generated at 2022-06-26 00:07:59.246731
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(22).concat(Sum(33)) == Sum(55)
    assert Sum(1).concat(Sum(0)) != Sum(0)
    assert Sum(2).concat(Sum(0)) == Sum(2)
    assert Sum(2).concat(Sum(2)) == Sum(4)


# Generated at 2022-06-26 00:08:06.444104
# Unit test for method __str__ of class Min
def test_Min___str__():
    min_0 = Min(21)
    actual_value = str(min_0)
    expected_value = 'Min[value=21]'
    assert actual_value == expected_value
    min_1 = Min(67)
    actual_value = str(min_1)
    expected_value = 'Min[value=67]'
    assert actual_value == expected_value
    min_2 = Min(-15)
    actual_value = str(min_2)
    expected_value = 'Min[value=-15]'
    assert actual_value == expected_value
    min_3 = Min(80)
    actual_value = str(min_3)
    expected_value = 'Min[value=80]'
    assert actual_value == expected_value
    min_4 = Min(-76)

# Generated at 2022-06-26 00:08:08.836950
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    min_0 = Min(89)
    min_1 = Min(89)
    assert (min_0 == min_1)


# Generated at 2022-06-26 00:08:14.076379
# Unit test for method __str__ of class Max
def test_Max___str__():
    str_0 = 'B_zHcG~$-?3!G*>]{'
    max_0 = Max(str_0)

    assert (str(max_0) == "Max[value=B_zHcG~$-?3!G*>]{]")



# Generated at 2022-06-26 00:08:16.047810
# Unit test for method concat of class First
def test_First_concat():
    first = First(1)
    other = First(2)
    assert first.concat(other) == First(1)



# Generated at 2022-06-26 00:08:19.253219
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    str_0 = 'P+:*T4kBUCGP]_>1wPS'
    min_0 = Min(str_0)

    assert(min_0 == min_0)


# Generated at 2022-06-26 00:08:20.458356
# Unit test for constructor of class One
def test_One():
    obj = One(1)
    assert obj.value == 1



# Generated at 2022-06-26 00:08:21.342918
# Unit test for method __str__ of class One
def test_One___str__():
    pass


# Generated at 2022-06-26 00:08:28.076505
# Unit test for constructor of class Max
def test_Max():
    assert Max(3) == Max(3), "wrong behavior with set/get elements"
    assert Max(3).concat(Max(2)) == Max(3), "wrong behavior with concat"
    assert Max(3).fold(lambda acc: acc) == 3, "wrong behavior with fold"
    assert Max(3).concat(Max(3)) == Max(3), "wrong behavior with concat"
    assert Max(3).concat(Max(4)) == Max(4), "wrong behavior with concat"
    assert Max(4).concat(Max(3)) == Max(4), "wrong behavior with concat"


# Generated at 2022-06-26 00:08:34.606704
# Unit test for method concat of class First
def test_First_concat():
    str_0 = 'P+:*T4kBUCGP]_>1wPS'
    first_0 = First(str_0)
    str_1 = 'P+:*T4kBUCGP]_>1wPS'
    first_1 = First(str_1)
    first_2 = first_0.concat(first_1)
    assert type(first_2) == First
    assert first_2.value == 'P+:*T4kBUCGP]_>1wPS'


# Generated at 2022-06-26 00:08:49.187189
# Unit test for method concat of class First
def test_First_concat():
    str_0 = 'P+:*T4kBUCGP]_>1wPS'
    str_1 = 'P+:*T4kBUCGP]_>1wPS'
    first_0 = First(str_0)
    first_1 = First(str_1)
    first_2 = first_0.concat(first_1)
    assert first_2 == First(str_0)


# Generated at 2022-06-26 00:08:54.794838
# Unit test for method concat of class Sum
def test_Sum_concat():
    str_0 = '7R!Hs?u_2iX;~hxno'
    str_1 = 'lT)T$0h%7zdAFKqlhs'
    sum_0 = Sum(str_0)
    sum_1 = Sum(str_1)
    sum_2 = sum_0.concat(sum_1)
    assert sum_2.value == '7R!Hs?u_2iX;~hxnolT)T$0h%7zdAFKqlhs'


# Generated at 2022-06-26 00:09:00.304689
# Unit test for method concat of class One
def test_One_concat():
    one_0 = One()
    one_1 = One(True)
    one_2 = One(True)
    one_3 = one_1.concat(one_2)
    assert isinstance(one_3, One)
    assert one_3 == One(True)
    assert str(one_3) == 'One[value=True]'


# Generated at 2022-06-26 00:09:02.858590
# Unit test for method concat of class First
def test_First_concat():
    first_0 = First(1521)
    first_1 = First(1465)
    first_0.concat(first_1)


# Generated at 2022-06-26 00:09:04.119297
# Unit test for constructor of class First
def test_First():
    result = First(0)
    assert result == First(0)



# Generated at 2022-06-26 00:09:06.951948
# Unit test for method __str__ of class Map
def test_Map___str__():
    method__str__ = Map({1: First('hello'), 2: Last('world')})
    assert str(method__str__) == 'Map[value={1: Fist[value=hello], 2: Last[value=world]}]'


# Generated at 2022-06-26 00:09:10.913456
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    str_0 = 'P+:*T4kBUCGP]_>1wPS'
    min_0 = Min(str_0)

    assert min_0.fold(lambda x: x * 2) == 'P+:*T4kBUCGP]_>1wPSP+:*T4kBUCGP]_>1wPS'


# Generated at 2022-06-26 00:09:17.789410
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    str_1 = 'ABQ%cxGZtz01dX8W\n'
    str_2 = 'ABQ%cxGZtz01dX8W\n'
    first_1 = First(str_1)
    first_2 = First(str_2)
    first_3 = First('ABQ%cxGZtz01dX8W\n')
    #
    bool_1 = first_1 == first_2
    bool_2 = first_1 == first_3
    #
    bool_3 = first_1 != first_2
    bool_4 = first_1 != first_3



# Generated at 2022-06-26 00:09:21.159632
# Unit test for method __str__ of class Map
def test_Map___str__():
    str_0 = 'P+:*T4kBUCGP]_>1wPS'
    map_0 = Map(str_0)
    if str(map_0) == map_0.__str__():
        print(str(map_0))



# Generated at 2022-06-26 00:09:22.956629
# Unit test for constructor of class First
def test_First():
    semigroup = First(10)
    assert semigroup.value == semigroup.concat(First(20)).value


# Generated at 2022-06-26 00:09:44.185088
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1


# Generated at 2022-06-26 00:09:52.678653
# Unit test for method concat of class Map
def test_Map_concat():
    map_0 = Map({'a': Last(2), 'b': Last(1)})
    map_1 = Map({'a': Last(2), 'b': Last(1)})
    map_2 = Map({'a': Last(2), 'b': Last(2)})
    assert map_0.concat(map_1) == Map({'a': Last(2), 'b': Last(1)})
    assert map_2.concat(map_1) == Map({'a': Last(2), 'b': Last(2)})
    assert map_1.concat(map_0) == Map({'a': Last(2), 'b': Last(1)})
    assert map_1.concat(map_2) == Map({'a': Last(2), 'b': Last(1)})

# Generated at 2022-06-26 00:09:57.134304
# Unit test for constructor of class One
def test_One():
    print("----- Unit test for constructor of class One -----")
    one_0 = One(False)
    one_1 = One(True)
    print("one_0: {0}".format(one_0))
    print("one_1: {0}".format(one_1))



# Generated at 2022-06-26 00:10:00.645125
# Unit test for method concat of class Max
def test_Max_concat():
    str_0 = 'P+:*T4kBUCGP]_>1wPS'
    str_1 = 'c%<5d!W?Qi%Hn|,&C'
    max_0 = Max(str_0)
    max_1 = Max(str_1)

    res = max_0.concat(max_1)

    assert res.value == max(str_0, str_1)


# Generated at 2022-06-26 00:10:03.696931
# Unit test for method __str__ of class Last
def test_Last___str__():
    str_0 = '>F<8{dwG.^Z'
    last_0 = Last(str_0)
    assert last_0.__str__() == 'Last[value=\'>F<8{dwG.^Z\']'


# Generated at 2022-06-26 00:10:07.318465
# Unit test for constructor of class Min
def test_Min():
    str_1 = 'XzF;LSB|:v3^W$e%=.|'
    min_1 = Min(str_1)
    assert type(min_1) == Min
    assert min_1.value == str_1


# Generated at 2022-06-26 00:10:11.667030
# Unit test for method concat of class Max
def test_Max_concat():
    # testing cases
    case_0 = Max(10).fold(lambda x: x) == 10
    case_1 = Max(20).fold(lambda x: x) == 20

    assert case_0 and case_1, "Wrong test case returned"


# Generated at 2022-06-26 00:10:20.539755
# Unit test for constructor of class Min
def test_Min():
    text_0 = 'P+:*T4kBUCGP]_>1wPS'
    min_0 = Min(text_0)
    assert(str(min_0) == 'Min[value=P+:*T4kBUCGP]_>1wPS]')
    text_1 = 'J^_<q3A7U+]6UH~6X'
    min_1 = Min(text_1)
    assert(str(min_1) == 'Min[value=J^_<q3A7U+]6UH~6X]')
    try:
        min_2 = Min.neutral()
    except Exception as e:
        assert(str(e) == 'Can run only on inherited classes')

# Generated at 2022-06-26 00:10:30.318762
# Unit test for constructor of class One
def test_One():
    one_1 = One(1)
    assert isinstance(one_1, One);
    assert isinstance(one_1, Semigroup);
    assert one_1.value == 1;
    one_2 = One(False)
    assert isinstance(one_2, One);
    assert isinstance(one_2, Semigroup);
    assert one_2.value == False;
    one_3 = One(True)
    assert isinstance(one_3, One);
    assert isinstance(one_3, Semigroup);
    assert one_3.value == True;
    one_4 = One(0)
    assert isinstance(one_4, One);
    assert isinstance(one_4, Semigroup);
    assert one_4.value == 0;
    one_5 = One(None)

# Generated at 2022-06-26 00:10:35.692629
# Unit test for method concat of class Map
def test_Map_concat():
    str_0 = 'P+:*T4kBUCGP]_>1wPS'
    str_1 = 'P+:*T4kBUCGP]_>1wPS'
    min_0 = Min(str_0)
    min_1 = Min(str_1)
    Map_0 = Map(min_0)

    Map_0.concat(min_1)



# Generated at 2022-06-26 00:11:23.298945
# Unit test for method __str__ of class Min
def test_Min___str__():
    func_0 = Min.__str__
    first_0 = func_0(0)  # type: str
    assert first_0 == 'Min[value=0]'

    str_0 = 'P+:*T4kBUCGP]_>1wPS'
    min_0 = Min(str_0)
    second_0 = func_0(min_0)  # type: str
    assert second_0 == 'Min[value=P+:*T4kBUCGP]_>1wPS]'


# Generated at 2022-06-26 00:11:28.050326
# Unit test for method concat of class All
def test_All_concat():
    str_0 = 'P+:*T4kBUCGP]_>1wPS'
    all_0 = All(str_0)
    str_1 = 'P+:*T4kBUCGP]_>1wPS'
    all_1 = All(str_1)
    str_2 = 'P+:*T4kBUCGP]_>1wPS'
    all_2 = All(str_2)
    min_0 = all_0.concat(all_1)
    min_1 = min_0.concat(all_2)


# Generated at 2022-06-26 00:11:32.138095
# Unit test for method __str__ of class Max
def test_Max___str__():
    str_0 = 'P+:*T4kBUCGP]_>1wPS'
    min_0 = Min(str_0)
    assert min_0.__str__() == 'Min[value=P+:*T4kBUCGP]_>1wPS]'


# Generated at 2022-06-26 00:11:35.171599
# Unit test for method __str__ of class All
def test_All___str__():
    str_0 = 'P+:*T4kBUCGP]_>1wPS'
    all_0 = All(str_0)
    assert all_0.__str__() == 'All[value=P+:*T4kBUCGP]_>1wPS]'


# Generated at 2022-06-26 00:11:41.641803
# Unit test for method concat of class All
def test_All_concat():
    first_0 = All(True)
    first_1 = All(False)
    first_2 = All(True)

    first_3 = first_0.concat(first_1)
    first_3_result = first_3.value == False

    first_4 = first_2.concat(first_3)
    first_4_result = first_4.value == False

    print(first_3_result and first_4_result)


# Generated at 2022-06-26 00:11:52.353088
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    str_0 = 'P+:*T4kBUCGP]_>1wPS'
    min_0 = Min(str_0)

    str_1 = 'I|:^)5c%F[p;lI!'
    max_0 = Max(str_1)

    str_2 = 'DjvNQ9@'
    min_1 = Min(str_2)

    str_3 = '~%F(L I'
    max_1 = Max(str_3)

    str_4 = 'K/"()'
    sum_0 = Sum(str_4)

    str_5 = 'K/"()'
    sum_1 = sum_0.concat(sum_0)

    str_6 = '6'
    first_0 = First(str_6)


# Generated at 2022-06-26 00:12:04.795624
# Unit test for method concat of class One

# Generated at 2022-06-26 00:12:10.233504
# Unit test for method __str__ of class Last
def test_Last___str__():
    str_0 = '6z<<1AHBGdUxo"U8<lXL'
    last_0 = Last(str_0)
    assert last_0.__str__() == 'Last[value={}]'.format(str_0)


# Generated at 2022-06-26 00:12:14.017963
# Unit test for method concat of class Min
def test_Min_concat():
    str_0 = 'P+:*T4kBUCGP]_>1wPS'
    str_1 = 'h?7j+5Z5uV7v'
    min_0 = Min(str_0)
    min_1 = Min(str_1)
    min_2 = min_0.concat(min_1)
    assert min_2.value == min(str_0, str_1)


# Generated at 2022-06-26 00:12:17.580138
# Unit test for method __str__ of class Map
def test_Map___str__():
    str_2 = 'P+:*T4kBUCGP]_>1wPS'
    min_2 = Min(str_2)

    assert(str(min_2) == 'Min[value=P+:*T4kBUCGP]_>1wPS]')


# Generated at 2022-06-26 00:13:53.312675
# Unit test for constructor of class Min
def test_Min():
    str_0 = 'P+:*T4kBUCGP]_>1wPS'
    min_0 = Min(str_0)
    assert min_0.value == str_0
    assert min_0.__str__() == 'Min[value=P+:*T4kBUCGP]_>1wPS]'


# Generated at 2022-06-26 00:13:57.758367
# Unit test for method __str__ of class Last
def test_Last___str__():
    str_0 = '1'
    last_0 = Last(str_0)
    assert str_0 == last_0.__str__()

test_Last___str__()


# Generated at 2022-06-26 00:14:00.079122
# Unit test for method __str__ of class Map
def test_Map___str__():
    str_0 = 'P+:*T4kBUCGP]_>1wPS'
    max_0 = Max(str_0)
    assert str(max_0) == 'Max[value=P+:*T4kBUCGP]_>1wPS]'

# Generated at 2022-06-26 00:14:04.339312
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True) != All(False)
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-26 00:14:12.105539
# Unit test for constructor of class Min
def test_Min():
    min_0 = Min(1)
    min_1 = Min(True)
    min_2 = Min(0)
    min_3 = Min(None)
    min_4 = Min(1.1)
    min_5 = Min(str)
    min_6 = Min('0')
    min_7 = Min(False)
    min_8 = Min(0.1)
    min_9 = Min(True)
    min_10 = Min('0')
    min_11 = Min(1)
    min_12 = Min(1.1)
    min_13 = Min('0')
    min_14 = Min(1.1)
    min_15 = Min(None)
    min_16 = Min(False)
    min_17 = Min('0')
    min_18 = Min(False)
   

# Generated at 2022-06-26 00:14:18.425901
# Unit test for method concat of class All
def test_All_concat():
    assert All(All(True)).concat(All(True)) == All(True)
    assert All(All(True)).concat(All(False)) == All(False)
    assert All(All(False)).concat(All(True)) == All(False)
    assert All(All(False)).concat(All(False)) == All(False)



# Generated at 2022-06-26 00:14:20.685588
# Unit test for method __str__ of class Max
def test_Max___str__():
    str_0 = 'P+:*T4kBUCGP]_>1wPS'
    max_0 = Max(str_0)
    str_1 = str(max_0)


# Generated at 2022-06-26 00:14:28.075373
# Unit test for method concat of class Last
def test_Last_concat():
    str_0 = 'P+:*T4kBUCGP]_>1wPS'
    last_0 = Last(str_0)
    str_1 = 'P+:*T4kBUCGP]_>1wPS'
    last_1 = Last(str_1)
    last_0.concat(last_1)


# Generated at 2022-06-26 00:14:36.360387
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).concat(One(2)).value == 1
    assert One(0).concat(One(2)).value == 2
    assert One('').concat(One(2)).value == 2
    assert One(1).concat(One(0)).value == 1
    assert One(1).concat(One('')).value == 1
    assert One(1).concat(One(2)).fold(lambda x: x) == 1
    assert One(0).concat(One(2)).fold(lambda x: x) == 2
    assert One('').concat(One(2)).fold(lambda x: x) == 2
    assert One(1).concat(One(0)).fold(lambda x: x) == 1
    assert One(1).concat(One('')).fold(lambda x: x) == 1

# Generated at 2022-06-26 00:14:39.396274
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)
