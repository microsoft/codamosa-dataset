

# Generated at 2022-06-26 00:05:53.578262
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(0).concat(Min(0)) == Min(0)
    assert Min(0).concat(Min(1)) == Min(0)
    assert Min(1).concat(Min(0)) == Min(0)
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)


# Generated at 2022-06-26 00:05:57.511904
# Unit test for method concat of class Max
def test_Max_concat():
    list_0 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 3, 3, 3]
    max_0 = Max(list_0)
    assert max_0.concat(max_0) == Max(10)


# Generated at 2022-06-26 00:06:01.896410
# Unit test for method concat of class Max
def test_Max_concat():
    test_values = [
        (Max(0), Max(1), Max(1)),
        (Max(-10), Max(-5), Max(-5)),
        (Max(-10), Max(-20), Max(-10)),
    ]
    for first_obj, second_obj, expected_obj in test_values:
        assert first_obj.concat(second_obj) == expected_obj



# Generated at 2022-06-26 00:06:03.741081
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min(1)
    min_1 = Min(2)
    assert min_0.concat(min_1).value == 1


# Generated at 2022-06-26 00:06:06.102832
# Unit test for method concat of class Min
def test_Min_concat():
    min_10 = Min(10)
    min_5 = Min(5)
    assert min_5.concat(min_10) == Min(5)



# Generated at 2022-06-26 00:06:10.762484
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(4)) == Min(1)
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(0.0).concat(Min(1)) == Min(0.0)
    assert Min(3).concat(Min(False)) == Min(3)



# Generated at 2022-06-26 00:06:19.906357
# Unit test for method concat of class Max
def test_Max_concat():
    # Min(value=1) == Min(value=1)
    min_0 = Min(1)
    min_1 = Min(1)
    assert min_0.concat(min_1) == Min(1)

    # Min(value=1) == Min(value=2)
    min_0 = Min(1)
    min_1 = Min(2)
    assert min_0.concat(min_1) == Min(1)

    # Min(value=2) == Min(value=1)
    min_0 = Min(2)
    min_1 = Min(1)
    assert min_0.concat(min_1) == Min(1)


# Generated at 2022-06-26 00:06:24.689974
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2), 'Wrong result of method concat of class Max'
    assert Max(2).concat(Max(1)) == Max(2), 'Wrong result of method concat of class Max'


# Generated at 2022-06-26 00:06:27.605783
# Unit test for method concat of class Max
def test_Max_concat():
    semigroup_1 = Max(1)
    semigroup_2 = Max(2)
    result = semigroup_1.concat(semigroup_2)
    assert result.value == 2



# Generated at 2022-06-26 00:06:32.037112
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min(1)
    min_1 = min_0.concat(Min(2))
    min_2 = min_1.concat(Min(42))
    min_3 = min_2.concat(Min(-100000))
    assert(min_3.value == -100000)


# Generated at 2022-06-26 00:06:36.027014
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    value_0 = First(2)
    assert value_0.fold(lambda value: value) == 2


# Generated at 2022-06-26 00:06:39.168439
# Unit test for constructor of class Map
def test_Map():

    sum_list = [1,2,3,4]
    map_0 = Map({'sum': Sum(sum_list)})
    map_1 = Map({'sum': Sum(sum_list)})

    result = map_0.concat(map_1)
    expected_result = Map({'sum': Sum(sum_list + sum_list)})

    assert result == expected_result

# Generated at 2022-06-26 00:06:43.254878
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_0 = Sum(0)
    sum_1 = Sum(1)
    sum_2 = Sum(2)

    assert sum_0.concat(sum_1) == Sum(1)

    print('tests for Sum class PASSED')



# Generated at 2022-06-26 00:06:45.263861
# Unit test for constructor of class Last
def test_Last():
    list = [3, 4, 5]
    max_0 = Max(list)

    assert max_0.value == 5


# Generated at 2022-06-26 00:06:46.505547
# Unit test for constructor of class Max
def test_Max():
  assert Max(0) == Max(0)



# Generated at 2022-06-26 00:06:47.914179
# Unit test for constructor of class Min
def test_Min():
    list_0 = [1,2,3,4,5]
    min_0 = Min(list_0)
    assert min_0.value == 1


# Generated at 2022-06-26 00:06:50.293083
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(10).concat(Last(21)) == Last(21)


# Generated at 2022-06-26 00:06:52.970666
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(0).concat(Last(1)) == Last(1)
    assert Last(1).concat(Last(0)) == Last(0)


# Generated at 2022-06-26 00:07:03.060841
# Unit test for method concat of class Sum
def test_Sum_concat():

    # Case 0
    sum_a = Sum(1)
    sum_b = Sum(2)
    sum_r = sum_a.concat(sum_b)
    assert sum_r.value == 3, 'Case 0'

    # Case 1
    sum_a = Sum(None)
    sum_b = Sum(1)
    sum_r = sum_a.concat(sum_b)
    assert sum_r.value == 1, 'Case 1'

    # Case 2
    sum_a = Sum(1)
    sum_b = Sum(None)
    sum_r = sum_a.concat(sum_b)
    assert sum_r.value == 1, 'Case 2'

    # Case 3
    sum_a = Sum(None)
    sum_b = Sum(None)
    sum_

# Generated at 2022-06-26 00:07:09.943146
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert str(Sum(10)) == 'Sum[value=10]'
    assert str(All(10)) == 'All[value=True]'
    assert str(One(10)) == 'One[value=True]'
    assert str(First(10)) == 'Fist[value=10]'
    assert str(Last(10)) == 'Last[value=10]'
    assert str(Map({'a': First(10)})) == 'Map[value={\'a\': Fist[value=10]}]'
    assert str(Max(10)) == 'Max[value=10]'
    assert str(Min(10)) == 'Min[value=10]'


# Generated at 2022-06-26 00:07:20.100750
# Unit test for constructor of class Max
def test_Max():
    assert (Max(0), Max(1), Max(2), Max(3), Max(4), Max(5), Max(6), Max(7), Max(8), Max(9)) == ((Max(0)), Max(1), Max(2), Max(3), Max(4), Max(5), Max(6), Max(7), Max(8), Max(9))


# Generated at 2022-06-26 00:07:22.289645
# Unit test for constructor of class Min
def test_Min():
    assert Min(10) == Min(10)
    assert Min(-5) == Min(-5)
    assert Min(5.5) == Min(5.5)


# Generated at 2022-06-26 00:07:26.327967
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_0 = Sum(5)
    sum_1 = Sum(5)
    expected_result = Sum(10)
    actual_result = sum_0.concat(sum_1)
    assert expected_result == actual_result, "%s == %s" % (expected_result, actual_result)


# Generated at 2022-06-26 00:07:27.326276
# Unit test for constructor of class Last
def test_Last():
    Last(One(True))


# Generated at 2022-06-26 00:07:34.314456
# Unit test for method concat of class Max
def test_Max_concat():
    max_0 = Max(10)
    max_1 = Max(20)
    max_2 = Max(30)
    max_3 = Max(40)
    acc_0 = max_0.concat(max_1)
    acc_1 = max_2.concat(max_3)
    acc = acc_0.concat(acc_1)
    assert acc.value == max_3.value
    assert acc.concat(max_0).concat(max_1).concat(max_2) == max_3


# Generated at 2022-06-26 00:07:36.980592
# Unit test for constructor of class First
def test_First():
    assert First(12) == First(12)
    assert First(12) != First(11)
    assert First(12).concat(First(12)) == First(12)


# Generated at 2022-06-26 00:07:44.412686
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(True).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(False).concat(One(True)) == One(True)
    assert One("").concat(One("")) == One("")
    assert One("").concat(One("hello")) == One("hello")
    assert One("hello").concat(One("hello")) == One("hello")
    assert One("hello").concat(One("world")) == One("hello")


# Generated at 2022-06-26 00:07:45.766549
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(0)) == "Max[value=0]"



# Generated at 2022-06-26 00:07:56.436397
# Unit test for constructor of class Max
def test_Max():
    list_0 = [5,2,5,1,5,1]
    min_0 = Min(list_0)
    min_1 = min_0.concat(Min(list_0))
    max_0 = Max(list_0)
    max_1 = max_0.concat(Max(list_0))
    sum_0 = Sum(list_0)
    all_0 = All(list_0)
    one_0 = One(list_0)
    first_0 = First(list_0)
    last_0 = Last(list_0)
    list_0 = list_0*2
    map_0 = Map(list_0)
    assert min_1.value == 1
    assert max_1.value == 5
    assert sum_0.value == 16
    assert all_0

# Generated at 2022-06-26 00:08:00.761655
# Unit test for method __str__ of class First
def test_First___str__():
    assert First.__str__(First(1)) == 'Fist[value=1]'
    assert First.__str__(First(enabled=True)) == 'Fist[value=True]'
    assert First.__str__(First('hello')) == 'Fist[value=hello]'


# Generated at 2022-06-26 00:08:09.257392
# Unit test for constructor of class All
def test_All():
    cases = [
        (True, True),
        (False, False),
        ("a", True),
        ("", False),
        ({"a": "b"}, True)
    ]

    def test_All_case(value, expected):
        value_all = All(value)
        assert value_all.value == expected

    for case in cases:
        test_All_case(*case)


# Generated at 2022-06-26 00:08:15.437276
# Unit test for constructor of class Map
def test_Map():

    test_0 = Map({1 : Sum(2)})

    semigroup_0 = Map({})

    semigroup_1 = semigroup_0.concat(test_0)

    assert( semigroup_1.value[1] == Sum(2) )

    semigroup_1 = Map({1 : Sum(2)})

    semigroup_1.fold(lambda x : print(x))


# Generated at 2022-06-26 00:08:18.997504
# Unit test for method __str__ of class Min
def test_Min___str__():
    # Test case 0
    list_0 = []
    min_0 = Min(list_0)
    # Test result (test case 0)
    assert str(min_0) == "Min[value=inf]"



# Generated at 2022-06-26 00:08:21.550220
# Unit test for method __str__ of class One
def test_One___str__():
    one_0 = One(None)
    str_0 = one_0.__str__()
    assert str_0 == "One[value=False]", "Failed"


# Generated at 2022-06-26 00:08:26.828434
# Unit test for constructor of class Last
def test_Last():
    list_0 = []
    last_0 = Last(list_0)
    last_0.value = "Mahmood"
    assert last_0.value == "Mahmood"

    list_1 = [1, 2, 3]
    last_1 = Last(list_1)
    assert last_1.value == 3

    empty_list = []
    empty_last_0 = Last(empty_list)
    assert empty_last_0.value == []



# Generated at 2022-06-26 00:08:28.482722
# Unit test for method __str__ of class All
def test_All___str__():
    all_0 = All(None)
    expected_0 = 'All[value=None]'
    assert str(all_0) == expected_0



# Generated at 2022-06-26 00:08:30.214665
# Unit test for constructor of class Semigroup
def test_Semigroup():
    with pytest.raises(TypeError):
        semigroup_0 = Semigroup(0)



# Generated at 2022-06-26 00:08:32.771195
# Unit test for method concat of class Last
def test_Last_concat():
    last_0 = Last([1,2,3])
    last_1 = last_0.concat(Last([4]))
    assert last_1.value == [4]


# Generated at 2022-06-26 00:08:37.108082
# Unit test for method concat of class Map
def test_Map_concat():
    list_0 = []
    map_0 = Map(list_0)
    list_1 = []
    map_1 = Map(list_1)

    assert map_0.concat(map_1) == Map(list_0)

# Generated at 2022-06-26 00:08:40.011947
# Unit test for constructor of class First
def test_First():
    list_0 = list(range(0, 100))
    list_1 = First(list_0)
    assert list_0[0] == list_1.value
    assert len(list_1.value) == 100


# Generated at 2022-06-26 00:08:45.214545
# Unit test for constructor of class Map
def test_Map():
    """
    Test for constructor
    """

    map1 = Map({1: Sum(1), 2: Sum(2)})
    print(map1)


# Generated at 2022-06-26 00:08:50.369353
# Unit test for method concat of class All
def test_All_concat():
    all_0 = All(False)
    all_1 = all_0.concat(All(False))
    all_2 = All(True)
    all_3 = all_2.concat(All(False))
    all_4 = All(False)
    all_5 = all_4.concat(All(True))
    all_6 = All(True)
    all_7 = all_6.concat(All(False))



# Generated at 2022-06-26 00:08:51.597179
# Unit test for constructor of class All
def test_All():
    a = All([1, 2, 3])
    assert a.value == True


# Generated at 2022-06-26 00:08:53.825349
# Unit test for constructor of class Last
def test_Last():
    first = Last(1)
    second = Last(2)
    result = first.concat(second)
    print(result)



# Generated at 2022-06-26 00:08:56.930521
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'
    assert str(Sum(None)) == 'Sum[value=None]'


# Generated at 2022-06-26 00:09:00.684289
# Unit test for constructor of class All
def test_All():
    lst = [True, False, True]
    lst2 = [True]
    lst3 = [False]
    lst4 = [False, False, False]
    all_0 = All(lst3)
    all_1 = All(lst4)


# Generated at 2022-06-26 00:09:09.747348
# Unit test for method __str__ of class Last
def test_Last___str__():
    # Case 0

    last_0 = Last(68)

    assert str(last_0) == 'Last[value=68]'

    # Case 1

    last_1 = Last('hx')

    assert str(last_1) == 'Last[value=hx]'

    # Case 2

    last_2 = Last(68)

    assert str(last_2) == 'Last[value=68]'

    # Case 3

    last_3 = Last(0.859582937)

    assert str(last_3) == 'Last[value=0.859582937]'

    # Case 4

    last_4 = Last([])

    assert str(last_4) == 'Last[value=[]]'

    # Case 5

    last_5 = Last(['a'])


# Generated at 2022-06-26 00:09:18.233825
# Unit test for constructor of class All
def test_All():
    list_0 = [True, True, True]
    list_1 = [False, False, False]
    list_2 = [True, False, True]
    list_3 = [False, True, False]
    list_4 = []
    list_5 = [None]
    list_6 = [True]

    all_0 = All(list_0)
    all_1 = All(list_1)
    all_2 = All(list_2)
    all_3 = All(list_3)
    all_4 = All(list_4)
    all_5 = All(list_5)
    all_6 = All(list_6)

    assert all_0.value == all_1.value
    assert all_0.value != all_2.value
    assert all_0.value != all_

# Generated at 2022-06-26 00:09:21.558632
# Unit test for method concat of class First
def test_First_concat():
    list_0 = [First('b'), First('d'), First('c'), First('a')]
    first_0 = reduce(lambda x, y: x.concat(y), list_0)
    print(list_0)
    print(first_0)


# Generated at 2022-06-26 00:09:24.155087
# Unit test for method __str__ of class One
def test_One___str__():
    one_0 = One(1)
    assert str(one_0) == 'One[value=1]', 'Expected "One[value=1]", but got "{}"'.format(one_0)



# Generated at 2022-06-26 00:09:31.045864
# Unit test for constructor of class One
def test_One():
    obj = One(1)
    assert obj.value == 1


# Generated at 2022-06-26 00:09:33.350592
# Unit test for method __str__ of class First
def test_First___str__():
    value = 1
    should_be = "Fist[value=1]"
    is_ = First(value)


# Generated at 2022-06-26 00:09:34.861257
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert Max(1).__str__() == "Max[value=1]"


# Generated at 2022-06-26 00:09:37.042293
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min(-1)
    min_1 = Min(-1)
    assert min_0.concat(min_1) == Min(-1)


# Generated at 2022-06-26 00:09:40.772854
# Unit test for method concat of class Sum
def test_Sum_concat():
    list_0 = [1, 1, 2, 3, 5, 8, 13]
    sum_0 = Sum(list_0)
    sum_1 = sum_0.concat(Sum(list_0))
    assert(sum_1 == Sum(list_0 + list_0))


# Generated at 2022-06-26 00:09:44.795488
# Unit test for method __str__ of class Max
def test_Max___str__():
    list0 = [1, 8, 9, 5, 4, 6, 0, 2, 4, 6, 9, 5, 2, 3, 1]
    max0 = Max(list0)
    assert str(max0) == 'Max[value=9]'


# Generated at 2022-06-26 00:09:47.252750
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_0 = Sum(1)
    sum_1 = Sum(2)
    assert sum_0.concat(sum_1) == Sum(sum_0.value + sum_1.value)


# Generated at 2022-06-26 00:09:56.748120
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x) == 1
    assert All(True).fold(lambda x: x) == True
    assert All(False).fold(lambda x: x) == False
    assert One(True).fold(lambda x: x) == True
    assert One(False).fold(lambda x: x) == False
    assert First(1).fold(lambda x: x) == 1
    assert Last(1).fold(lambda x: x) == 1
    assert Map({}).fold(lambda x: x) == {}
    assert Max(-1).fold(lambda x: x) == -1
    assert Max(1).fold(lambda x: x) == 1
    assert Min(-1).fold(lambda x: x) == -1
    assert Min(1).fold(lambda x: x) == 1



# Generated at 2022-06-26 00:09:57.871154
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == "Min[value=1]"


# Generated at 2022-06-26 00:09:58.950805
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(True)) == 'Fist[value=True]'


# Generated at 2022-06-26 00:10:11.312754
# Unit test for method concat of class Max
def test_Max_concat():
    max_0 = Max(10)
    max_1 = Max(20)
    max_0.concat(max_1)

    max_0 = Max(10)
    max_1 = Max(-10)
    max_0.concat(max_1)

    max_0 = Max(-10)
    max_1 = Max(-20)
    max_0.concat(max_1)



# Generated at 2022-06-26 00:10:14.890502
# Unit test for method __str__ of class First
def test_First___str__():
    """
    Tests if method __str__ of class First returns the right output,
    for the given input, based on the documentation.
    """
    example0 = First(2)
    assert_equal(str(example0), 'Fist[value=2]')



# Generated at 2022-06-26 00:10:23.214276
# Unit test for method concat of class One
def test_One_concat():
    list_0 = []
    value_0 = 0
    list_1 = list_0
    class_0 = All(list_1)
    list_0 = []
    value_1 = 1
    list_1 = list_0
    class_1 = All(list_1)
    list_0 = []
    class_2 = All(list_0)
    list_0 = [class_0, class_1, class_2]
    value_2 = 1
    value_3 = 2
    list_1 = [value_2, value_3]
    value_4 = 1
    list_2 = []
    class_3 = All(list_2)
    value_5 = 1
    list_3 = []
    class_4 = All(list_3)
    value_6 = 1
    list_

# Generated at 2022-06-26 00:10:28.125220
# Unit test for constructor of class Semigroup
def test_Semigroup():
    Sum(5)
    First(5)
    Last(5)
    Min(5)
    Max(5)
    All(5)
    One(5)
    Map({'a': Sum(5), 'b': Sum(6)})
    print("Test for constructor of class Semigroup - SUCCESSFUL")



# Generated at 2022-06-26 00:10:33.109488
# Unit test for method __str__ of class All
def test_All___str__():
    try:
        expected_result = 'All[value=True]'
        All___str__result = str(All(True))
        assert All___str__result == expected_result
    except AssertionError as error:
        print('test_All___str__() failed: ', error)
        print('expected: ', expected_result)
        print('actual: ', All___str__result)


# Generated at 2022-06-26 00:10:42.130208
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_0 = Sum(0)
    sum_1 = Sum(1)
    sum_2 = Sum(2)
    sum_3 = Sum(3)
    sum_4 = Sum(4)
    sum_5 = Sum(5)
    sum_6 = Sum(6)
    sum_7 = Sum(7)
    sum_8 = Sum(8)
    sum_9 = Sum(9)
    sum_10 = Sum(10)
    sum_11 = Sum(11)
    sum_12 = Sum(12)
    sum_13 = Sum(13)
    sum_14 = Sum(14)
    sum_15 = Sum(15)
    sum_16 = Sum(16)
    sum_17 = Sum(17)
    sum_18 = Sum(18)
    sum_19 = Sum(19)

# Generated at 2022-06-26 00:10:47.865323
# Unit test for constructor of class Sum
def test_Sum():
    sum_1 = Sum(1)
    sum_2 = Sum(2)
    sum_3 = Sum(3)
    assert sum_1.concat(sum_2).value == 3
    assert sum_1.concat(sum_3).value == 4
    assert sum_2.concat(sum_3).value == 5
    assert Sum(3).neutral().value == 0



# Generated at 2022-06-26 00:10:56.313999
# Unit test for method concat of class One
def test_One_concat():
    """
    Test method concat of class One
    """
    One_0 = One(True)
    One_1 = One(False)
    One_2 = One(False)
    # concat
    One_3 = One_0.concat(One_1)
    assert One_3 == One(True)
    # concat
    One_3 = One_1.concat(One_2)
    assert One_3 == One(False)
    # concat
    One_3 = One_1.concat(One_0)
    assert One_3 == One(True)

# Generated at 2022-06-26 00:11:00.361993
# Unit test for method concat of class First
def test_First_concat():
    assert First(2).concat(First(3)).value == 2
    assert First(4).concat(First(4)).value == 4
    assert First(True).concat(First(False)).value == True


# Generated at 2022-06-26 00:11:08.640052
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    max_0 = Max(1)
    last_0 = Last(1)
    sum_0 = Sum(1)
    all_0 = All(1)
    map_0 = Map({1 : Sum(1)})
    list_0 = [max_0]
    assert max_0.fold(lambda value: value) == max_0.value
    assert last_0.fold(lambda value: value) == last_0.value
    assert sum_0.fold(lambda value: value) == sum_0.value
    assert all_0.fold(lambda value: value) == all_0.value
    assert map_0.fold(lambda value: value) == map_0.value
    assert list_0[0].fold(lambda value: value) == list_0[0].value


# Generated at 2022-06-26 00:11:23.015582
# Unit test for constructor of class First
def test_First():
    first_0 = First(1)
    first_1 = First(10)
    assert(first_0.concat(first_1) == first_0)


# Generated at 2022-06-26 00:11:29.280061
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Return passed function applied on value of Semigroup instance
    """
    sum_0 = Sum(1)
    result_0 = sum_0.fold(lambda x: x + 5)
    assert result_0 == 6
    all_0 = All(True)
    result_1 = all_0.fold(lambda x: x == True)
    assert result_1 == True
    one_0 = One(False)
    result_2 = one_0.fold(lambda x: x == False)
    assert result_2 == True
    first_0 = First(1)
    result_3 = first_0.fold(lambda x: x + 2)
    assert result_3 == 3
    last_0 = Last(5)
    result_4 = last_0.fold(lambda x: x * 6)
    assert result_

# Generated at 2022-06-26 00:11:33.617459
# Unit test for method concat of class All
def test_All_concat():
    all_0 = All(True)
    all_1 = All(True)
    all_2 = All(False)
    result = all_0.concat(all_1)
    print(result)
    result = all_0.concat(all_2)
    print(result)
    result = all_2.concat(all_2)
    print(result)


# Generated at 2022-06-26 00:11:35.022457
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-26 00:11:39.575700
# Unit test for constructor of class First
def test_First():
    # Arrange
    zero = First(0)
    one = First(1)

    # Assert
    assert one.concat(zero).value == 0
    assert zero.concat(one).value == 0



# Generated at 2022-06-26 00:11:41.442273
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)



# Generated at 2022-06-26 00:11:45.774767
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-26 00:11:48.268234
# Unit test for method __str__ of class One
def test_One___str__():
    list_0 = []
    one_0 = One(list_0)
    str_0 = 'One[value=[]]'
    assert one_0.__str__() == str_0


# Generated at 2022-06-26 00:11:51.960397
# Unit test for method __str__ of class Last
def test_Last___str__():
    list_0 = []
    min_0 = Min(list_0)
    result = min_0.__str__()
    assert result == 'Min[value=inf]', 'Expected different value but got %r' % (result,)


# Generated at 2022-06-26 00:11:55.670524
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First("foo")) == "Fist[value=foo]"


# Generated at 2022-06-26 00:12:09.654985
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) != Semigroup(2)


# Generated at 2022-06-26 00:12:11.444722
# Unit test for method __str__ of class Min
def test_Min___str__():
    min_0 = Min(0)
    assert min_0.__str__() == "Min[value=0]"


# Generated at 2022-06-26 00:12:12.698534
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(8)) == Sum(9)


# Generated at 2022-06-26 00:12:14.992089
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(True).__str__() == 'One[value=True]'
    assert One(False).__str__() == 'One[value=False]'
    assert One("").__str__() == 'One[value=]'
    assert One("test").__str__() == 'One[value=test]'


# Generated at 2022-06-26 00:12:23.244179
# Unit test for method concat of class Sum
def test_Sum_concat():
    list_0 = [4, 5, 2, 3, 1]
    list_1 = [10, 11]
    list_2 = [3, 4, 8, 3, 1]
    list_3 = [-1, 0, -3, -5, -7, -12]
    sum_0 = Sum(list_0)
    sum_1 = Sum(list_1)
    sum_2 = Sum(list_2)
    sum_3 = Sum(list_3)
    assert sum_0.concat(sum_1).value == 15
    assert sum_1.concat(sum_2).value == 28
    assert sum_2.concat(sum_3).value == -24
    assert sum_3.concat(sum_0).value == 6



# Generated at 2022-06-26 00:12:24.384516
# Unit test for constructor of class First
def test_First():
    first = First(1)
    assert first.value == 1


# Generated at 2022-06-26 00:12:34.318631
# Unit test for constructor of class Min
def test_Min():
    # Test with empty list
    list_0 = []
    min_0 = Min(list_0)
    assert min_0.value == float("inf")

    # Test with a list with one numerical value
    list_1 = [1]
    min_1 = Min(list_1)
    assert min_1.value == 1

    # Test with a list with multiple numerical values
    list_2 = [1, 4, 9, 2]
    min_2 = Min(list_2)
    assert min_2.value == 1

    # Test with a list with multiple duplicate numerical values
    list_3 = [1, 4, 9, 2, 2]
    min_3 = Min(list_3)
    assert min_3.value == 1

    # Test with a list with numerical values and non numerical values

# Generated at 2022-06-26 00:12:36.108113
# Unit test for constructor of class Sum
def test_Sum():
    value = Sum(100)
    #assert value.value == Sum(100)

    # Unit test for constructor of class All

# Generated at 2022-06-26 00:12:42.260968
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    list_0 = []
    sum_0 = Sum(list_0)
    list_1 = []
    sum_1 = Sum(list_1)
    assert sum_0 == sum_1
    list_2 = []
    all_0 = All(list_2)
    assert all_0 == sum_0
    list_3 = []
    last_0 = Last(list_3)
    assert sum_0 != last_0
    list_4 = []
    map_0 = Map(list_4)
    assert map_0 == sum_0
    list_5 = []
    one_0 = One(list_5)
    assert sum_0 != one_0
    list_6 = []
    max_0 = Max(list_6)
    assert sum_0 != max_0
    list_7 = []

# Generated at 2022-06-26 00:12:45.931772
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    list_0 = []
    max_0 = Max.neutral()
    list_0.append(max_0)
    max_1 = Max(list_0)
    assert max_1.fold(lambda x: x) == Max.neutral()



# Generated at 2022-06-26 00:13:02.039509
# Unit test for method concat of class Max
def test_Max_concat():
    # 1) Given
    max_0 = Max(0)
    max_1 = Max(1)

    # 2) When
    result = max_0.concat(max_1)

    # 3) Then
    assert result == Max(1)


# Generated at 2022-06-26 00:13:03.893032
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)).value == 1
    assert First(1).concat(First(False)).value == 1



# Generated at 2022-06-26 00:13:06.923789
# Unit test for constructor of class Min
def test_Min():
    min_1 = Min(10)
    assert min_1.value == 10
    # Assert that the value is an integer
    assert isinstance(min_1.value, int)
    # Assert that the value is not null
    assert min_1.value != None



# Generated at 2022-06-26 00:13:10.294349
# Unit test for method concat of class Last
def test_Last_concat():
    assert First('a').concat(First('b')) == First('a')
    assert First('a').concat(First('b')).concat(First('c')) == First('a')


# Generated at 2022-06-26 00:13:13.931071
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    #fold tests
    assert Sum(2).fold(lambda x: x * 2) == 4
    assert All(False).fold(lambda x: x * 2) == 0
    assert One(True).fold(lambda x: x * 2) == 2

# Generated at 2022-06-26 00:13:15.324656
# Unit test for method concat of class First
def test_First_concat():
    result = First(1).concat(First(2))
    assert result == First(1)


# Generated at 2022-06-26 00:13:19.007507
# Unit test for method __str__ of class Max
def test_Max___str__():

    assert 'Max[value=2]' == str(Max(2))
    assert 'Max[value=-100]' == str(Max(-100))
    assert 'Max[value=-inf]' == str(Max(float("-inf")))
    assert 'Max[value=inf]' == str(Max(float("inf")))



# Generated at 2022-06-26 00:13:19.776288
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert Min(5).__str__() == 'Min[value=5]'


# Generated at 2022-06-26 00:13:21.971107
# Unit test for constructor of class Min
def test_Min():
    list_0 = [1, 2]
    min_0 = Min(list_0)
    list_1 = [1, 2]
    min_1 = Min(list_1)
    assert(min_0.value == list_0)
    assert(min_0.value == min_1.value)


# Generated at 2022-06-26 00:13:22.718324
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1



# Generated at 2022-06-26 00:14:00.244044
# Unit test for constructor of class Max
def test_Max():
    assert_equal(Max(1), Max(1))
    assert_raise(TypeError, lambda: Max(2))



# Generated at 2022-06-26 00:14:02.027419
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(1)) == Min(1)




# Generated at 2022-06-26 00:14:04.934216
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    print("Testing function Sum.__str__")
    assert str(Sum(0)) == "Sum[value=0]"
    assert str(Sum(13)) == "Sum[value=13]"
    print("")


# Generated at 2022-06-26 00:14:07.100172
# Unit test for constructor of class Map
def test_Map():
    list_0 = []
    assert Map(list_0).value == list_0
    list_1 = [2,3,4]
    assert Map(list_1).value == list_1



# Generated at 2022-06-26 00:14:09.711030
# Unit test for constructor of class First
def test_First():
    f = First(1)
    if f.value != 1:
        print("FAILED: wrong value for class First")
    else:
        print("PASSED: correct value for class First")


# Generated at 2022-06-26 00:14:12.835737
# Unit test for constructor of class Semigroup
def test_Semigroup():
    list_0 = []
    min_0 = Min(list_0)
    min_0.concat(Min(-float("inf")))

# Generated at 2022-06-26 00:14:14.478250
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(5) == Sum(5)


# Generated at 2022-06-26 00:14:16.712342
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == "Sum[value=1]"


# Generated at 2022-06-26 00:14:19.718123
# Unit test for method __str__ of class Map
def test_Map___str__():
    value = {1: Sum(1), 2: Sum(2)}
    assert str(Map(value)) == 'Map[value={1: Sum[value=1], ' \
                             '2: Sum[value=2]}]'


# Generated at 2022-06-26 00:14:22.012982
# Unit test for constructor of class Semigroup
def test_Semigroup():
    # Test on abstract class, no attribute named 'neutral_element'
    try:
        Semigroup(None)
    except AttributeError:
        pass
    else:
        raise AttributeError('AttributeException expected')


# Generated at 2022-06-26 00:15:24.602343
# Unit test for method __str__ of class Map
def test_Map___str__():
    dict_0 = {}
    map_0 = Map(dict_0)
    assert __str__(map_0) == 'Map[value={}]'

# Generated at 2022-06-26 00:15:28.088022
# Unit test for constructor of class Map
def test_Map():
    id = 1
    map = Map(id)
    
    # Assert if instance is Map
    assert isinstance(map, Map)
    # Assert if value of Map is the same value passed to constructor
    assert map.value == id
    # Assert if concat method exists in Map
    assert hasattr(map, "concat")
  

# Generated at 2022-06-26 00:15:29.122457
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'

# Generated at 2022-06-26 00:15:31.037693
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"


# Generated at 2022-06-26 00:15:34.734969
# Unit test for constructor of class Min
def test_Min():
    list_0 = []

    min_0 = Min(list_0)

    min_1 = min_0.concat(0)

    assert str(min_0) == 'Min[value=inf]'
    assert str(min_1) == 'Min[value=0]'
    assert min_1.value == 0

# Generated at 2022-06-26 00:15:36.301903
# Unit test for method __str__ of class Map
def test_Map___str__():
    list_0 = []
    map_0 = Map(list_0)
    str_0 = map_0.__str__()


# Generated at 2022-06-26 00:15:38.022965
# Unit test for method __str__ of class First
def test_First___str__():
    value = 2
    map_0 = First(value)
    str_0 = str(map_0)
    assert str_0 == 'Fist[value=2]'



# Generated at 2022-06-26 00:15:39.463508
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-26 00:15:41.281001
# Unit test for method concat of class Max
def test_Max_concat():
    max_0 = Max(60)
    max_1 = Max(35)
    max_2 = max_0.concat(max_1)
    assert max_2 == Max(60)



# Generated at 2022-06-26 00:15:43.837980
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    list_0 = [1, 4, 0, 1]
    sum_0 = Sum(list_0)

    assert str(sum_0) == 'Sum[value=6]'
