

# Generated at 2022-06-26 00:05:57.459001
# Unit test for method concat of class Map
def test_Map_concat():
    float_0 = 6462.94318
    float_1 = -8146.697568
    float_2 = -7410.996578
    float_3 = -3290.803375
    float_4 = -2783.419378
    float_5 = -9658.62359
    float_6 = 7203.154028
    float_7 = -8810.620413
    float_8 = 5165.624897
    float_9 = -3428.542708
    float_10 = -4723.912594
    float_11 = -8011.878251
    float_12 = -7936.813503
    float_13 = -5048.607224
    float_14 = -7059.807
    float_15 = -8476.14

# Generated at 2022-06-26 00:06:04.949974
# Unit test for method concat of class Map
def test_Map_concat():
    float_0 = 1506.035823
    dict_0 = dict()
    dict_0['foo'] = Sum(float_0)
    semigroup_0 = Map(dict_0)
    float_1 = 1506.035823
    dict_1 = dict()
    dict_1['foo'] = Sum(float_1)
    semigroup_1 = Map(dict_1)
    float_2 = 1506.035823
    float_3 = float_0 + float_1
    dict_2 = dict()
    dict_2['foo'] = Sum(float_3)
    semigroup_2 = Map(dict_2)
    semigroup_3 = semigroup_0.concat(semigroup_1)
    assert semigroup_2 == semigroup_3


# Generated at 2022-06-26 00:06:09.515259
# Unit test for method concat of class Max
def test_Max_concat():
    float_0 = 167.24
    Max_0 = Max(float_0)
    float_1 = 1707.5
    Max_1 = Max(float_1)
    concat_0 = Max.concat(Max_0, Max_1)
    expected_0 = Max(1707.5)
    assert concat_0 == expected_0



# Generated at 2022-06-26 00:06:16.875902
# Unit test for method concat of class Min
def test_Min_concat():
    int_0 = 0
    semigroup_0 = Min(int_0)
    int_1 = -1083
    semigroup_1 = Min(int_1)
    int_2 = -1285
    semigroup_2 = Min(int_2)
    semigroup_3 = semigroup_0.concat(semigroup_1)
    semigroup_3 = semigroup_3.concat(semigroup_2)


# Generated at 2022-06-26 00:06:25.742925
# Unit test for method concat of class Max
def test_Max_concat():
    float_0 = 3979.488645
    float_1 = 9046.561481
    float_2 = 1553.672356
    float_3 = 6707.544074
    float_4 = 4291.772686
    float_5 = 8116.926558
    float_6 = 9020.042981
    float_7 = 4312.672893
    float_8 = 9659.684719
    float_9 = 1397.772665
    float_10 = 5430.067791
    float_11 = 2873.845123
    float_12 = 1844.446008
    float_13 = 6142.937695
    float_14 = 8043.406401
    float_15 = 1836.084185
    float_16 = 5

# Generated at 2022-06-26 00:06:35.349896
# Unit test for method concat of class Map
def test_Map_concat():
    dict_0 = {
        "sdfsdrgg": Min(13),
        "asdfdfdf": Max(15),
        "kl;kl;lk':": Sum(12),
        'qwerqwer': Min(7),
        "a;sldkfja": Last("lkjasdflkj") }
    dict_1 = {
        "sdfsdrgg": Min(12),
        "asdfdfdf": Max(14),
        "kl;kl;lk':": Sum(12),
        'qwerqwer': Min(5),
        "a;sldkfja": Last("lkjasdflkj2") }
    map_0 = Map(dict_0)
    map_1 = Map(dict_1)

# Generated at 2022-06-26 00:06:36.433623
# Unit test for method concat of class Map
def test_Map_concat():
    pass


# Generated at 2022-06-26 00:06:46.263209
# Unit test for method concat of class Min
def test_Min_concat():
    float_0 = -898.07
    float_1 = 1.907
    float_2 = -1.1866
    float_3 = 844.469
    float_4 = -36.9
    float_5 = 90.7
    float_6 = -743.881
    float_7 = -436.328
    float_8 = -608.76654

    semigroup_0 = Min(float_0)
    semigroup_1 = Min(float_1)
    semigroup_2 = Min(float_2)
    semigroup_3 = Min(float_3)
    semigroup_4 = Min(float_4)
    semigroup_5 = Min(float_5)
    semigroup_6 = Min(float_6)
    semigroup_7 = Min(float_7)


# Generated at 2022-06-26 00:06:48.439987
# Unit test for method concat of class Max
def test_Max_concat():
    float_0 = 1506.035823
    semigroup_0 = Max(float_0)
    float_1 = 642.33412
    semigroup_1 = Max(float_1)
    result = semigroup_0.concat(semigroup_1)
    assert result is not None


# Generated at 2022-06-26 00:06:53.624051
# Unit test for method concat of class Map
def test_Map_concat():
    semigroup_0 = Map({})
    semigroup_1 = Map({})
    semigroup_2 = semigroup_0.concat(semigroup_1)
    assert isinstance(semigroup_2, Map)
    assert isinstance(semigroup_2.value, dict)
    assert semigroup_2.value == {}


# Generated at 2022-06-26 00:07:04.968007
# Unit test for method concat of class All
def test_All_concat():
    float_0 = -0.0037588908351103497
    bool_0 = bool(0)
    semigroup_1 = All(bool_0)
    float_1 = -0.00567360204097668
    bool_1 = bool(0)
    semigroup_2 = All(bool_1)
    semigroup_3 = semigroup_1.concat(semigroup_2)
    float_2 = -0.0005690515792311588
    bool_2 = bool(0)
    all_0 = All(bool_2)
    semigroup_4 = semigroup_3.concat(all_0)
    assert isinstance(semigroup_3, All)
    assert semigroup_3.value == False
    assert isinstance(semigroup_4, All)
    assert semigroup

# Generated at 2022-06-26 00:07:12.577197
# Unit test for method concat of class Last
def test_Last_concat():
    bool_0 = bool(0)
    int_0 = 9.329556853170897
    Last_instance_0 = Last(int_0)
    Last_instance_1 = Last(bool_0)
    First_instance_0 = First(bool_0)
    Sum_instance_0 = Sum(4)
    Sum_instance_1 = Sum(5)
    Sum_instance_2 = Sum(5)
    Sum_instance_3 = Sum(2)
    Sum_instance_4 = Sum(9)
    Sum_instance_5 = Sum(7)
    val_0 = Last_instance_0.concat(Last_instance_1)
    val_1 = All(False).concat(All(False))
    val_2 = First_instance_0.concat(First_instance_0)
   

# Generated at 2022-06-26 00:07:14.791571
# Unit test for constructor of class First
def test_First():
    string_0 = "E"
    string_1 = "A"
    First_0 = First(string_0)
    First_1 = First(string_1)


# Generated at 2022-06-26 00:07:21.769147
# Unit test for method __str__ of class Max
def test_Max___str__():
    float_0 = 1680.004472
    semigroup_0 = Max(float_0)
    str_0 = 'Max[value=1680.004472]'
    result_str_0 = semigroup_0.__str__()
    assert result_str_0 == str_0, "expected {}, got {}".format(str_0, result_str_0)


# Generated at 2022-06-26 00:07:24.837134
# Unit test for method __str__ of class First
def test_First___str__():
    float_0 = 1506.035823
    semigroup_0 = First(float_0)

    assert_true(str(semigroup_0) == "Fist[value=1506.035823]")


# Generated at 2022-06-26 00:07:34.377817
# Unit test for method concat of class Min
def test_Min_concat():
    float_0 = 1506.035823
    semigroup_0 = Min(float_0)
    float_1 = -216.5064252
    semigroup_1 = Min(float_1)
    float_2 = float_0
    semigroup_0.concat(semigroup_1)
    float_3 = float_0
    if float_2 <= float_3:
        float_2 = float_2
    else:
        float_2 = float_3
    float_3 = float_2
    assert float_3 >= float_0
    semigroup_0.concat(semigroup_0)
    float_2 = float_1
    if float_3 <= float_2:
        float_3 = float_3
    else:
        float_3 = float_2
    float_2 = float_

# Generated at 2022-06-26 00:07:37.800721
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    float_0 = -1.80081725647
    semigroup_0 = Semigroup(float_0)
    float_1 = -2.2555153077
    semigroup_1 = Semigroup(float_1)
    assert semigroup_0 != semigroup_1



# Generated at 2022-06-26 00:07:39.746920
# Unit test for method __str__ of class Map
def test_Map___str__():
    map_0 = Map({})
    str_0 = map_0.__str__()
    assert type(str_0) == str


# Generated at 2022-06-26 00:07:42.217392
# Unit test for method __str__ of class Last
def test_Last___str__():
    string_0 = "Last[value=l]"
    semigroup_0 = Last('l')

    assert semigroup_0.__str__() == string_0


# Generated at 2022-06-26 00:07:47.177574
# Unit test for method concat of class Min
def test_Min_concat():
    # Create a class instance for testing
    float_0 = 1506.483922
    semigroup_0 = Min(float_0)

    # Create a class instance for testing
    float_1 = -1449.350934
    semigroup_1 = Min(float_1)

    ret = semigroup_0.concat(semigroup_1)
    assert ret.value == float_1



# Generated at 2022-06-26 00:08:03.921425
# Unit test for constructor of class One
def test_One():
    semigroup_0 = One(0)
    assert semigroup_0.value == 0
    assert semigroup_0.concat(Last(0)).value == 0
    assert semigroup_0.concat(Last(1)).concat(Last(False)).value == False
    assert semigroup_0.concat(Last(2)).concat(Last(False)).value == 2
    assert semigroup_0.concat(Last(2)).concat(Last(3)).value == 2
    assert semigroup_0.concat(Last(False)).concat(Last(3)).concat(Last(True)).value == True
    assert semigroup_0.concat(Last(2)).concat(Last(False)).value == 2
    semigroup_1 = One(True)
    assert semigroup_1.value == True
    assert semigroup_

# Generated at 2022-06-26 00:08:06.543504
# Unit test for method __str__ of class All
def test_All___str__():
    str_0 = All.neutral().fold(lambda x: str(x))
    str_1 = 'All[value=True]'
    assert str_0 == str_1



# Generated at 2022-06-26 00:08:10.331234
# Unit test for method __str__ of class One
def test_One___str__():
    str_0 = str(One(True))
    assert str_0 == 'One[value=True]', str_0
    str_0 = str(One(False))
    assert str_0 == 'One[value=False]', str_0


# Generated at 2022-06-26 00:08:11.788516
# Unit test for constructor of class Max
def test_Max():
    pass


# Generated at 2022-06-26 00:08:14.254331
# Unit test for constructor of class Sum
def test_Sum():
    float_0 = 9153.456945741249
    semigroup_0 = Sum(float_0)


# Generated at 2022-06-26 00:08:23.566106
# Unit test for method concat of class All
def test_All_concat():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()

    All_class_0 = All(bool_9)
    All_class_1 = All(bool_4)
    All_class_2 = All(bool_7)
    All_class_3 = All(bool_8)
    All_class_4 = All(bool_9)
    All_class_5 = All(bool_2)
    All_class_6 = All(bool_0)


# Generated at 2022-06-26 00:08:28.241036
# Unit test for method concat of class One
def test_One_concat():
    # Precondition
    bool_0 = bool(0)
    semigroup_1 = One(bool_0)
    bool_1 = bool(0)
    semigroup_0 = One(bool_1)
    # Invocation
    output_0 = semigroup_1.concat(semigroup_0)
    # Postconditions
    bool_2 = bool(0)
    assert(output_0.value == bool_2)

# Generated at 2022-06-26 00:08:31.265351
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Test case for testing method fold of class Semigroup
    """
    assert (Sum(1).fold(str)) != '1'

    assert (Sum(1).concat(Sum(1))).fold(str) != '2'



# Generated at 2022-06-26 00:08:41.352957
# Unit test for method concat of class One
def test_One_concat():
    float_0 = 0.7374919286194355
    bool_0 = bool(0)
    str_0 = "t (1)"
    dict_0 = dict()
    dict_0[10] = True
    dict_0[5] = False
    bool_1 = bool(0)
    float_1 = 0.5064509416789444
    int_0 = 7
    float_2 = 0.6817290756054724
    int_1 = 3
    float_3 = 0.8253857498213028
    str_1 = "t (1)"
    str_2 = "t (1)"
    int_2 = 8
    int_3 = 0
    int_4 = 3
    bool_2 = bool(0)
    float_4 = 0.103445679822

# Generated at 2022-06-26 00:08:49.385815
# Unit test for method __str__ of class One
def test_One___str__():
    float_0 = 1702.1054324058
    one_0 = One(float_0)
    one_1 = One(0.0)
    one_2 = First(0.0)
    one_3 = Map({one_1: one_2})
    one_3 = All(False)
    str_0 = one_1.__str__()
    str_1 = one_3.__str__()
    str_2 = one_1.__str__()
    assert str_0 == "One[value=1702.1054324058]"
    assert str_1 == "All[value=False]"
    assert str_2 == "One[value=0.0]"


# Generated at 2022-06-26 00:08:58.861771
# Unit test for constructor of class Sum
def test_Sum():
    float_0 = -1344.151486
    semigroup_0 = Sum(float_0)
    assert (semigroup_0.value == float_0), "Expected " + str(float_0) + ", got: " + str(semigroup_0.value) 


# Generated at 2022-06-26 00:09:00.429760
# Unit test for method __str__ of class Map
def test_Map___str__():
    map_0 = Map({})
    map_0.__str__()


# Generated at 2022-06-26 00:09:04.038574
# Unit test for method __str__ of class Min
def test_Min___str__():
    """Unit test for method __str__ of class Min
    """
    # Tests for method __str__ of class Min
    arg_0 = Min(23)
    arg_1 = arg_0.__str__()
    assert arg_1 == 'Min[value=23]'


# Generated at 2022-06-26 00:09:06.603942
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    float_0 = -2.060003
    semigroup_0 = Sum(float_0)
    assert semigroup_0.__str__() == 'Sum[value=-2.060003]'


# Generated at 2022-06-26 00:09:10.552238
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    # Arrange
    float_0 = 1506.035823
    semigroup_0 = Sum(float_0)

    # Act
    result = semigroup_0.__str__()

    # Assert
    expected = 'Sum[value={}]'.format(float_0)

    assert result == expected


# Generated at 2022-06-26 00:09:15.011613
# Unit test for method concat of class Last
def test_Last_concat():
    # Test data
    float_0 = 676.68
    Last_0 = Last(float_0)
    float_1 = -186.99
    Last_1 = Last(float_1)
    # Expected result
    expected = Last(-186.99)
    # Step with result actual
    actual = Last_0.concat(Last_1)
    # Result assert
    assert expected == actual


# Generated at 2022-06-26 00:09:16.505824
# Unit test for constructor of class All
def test_All():
    bool_0 = All(True)
    bool_1 = All(False)


# Generated at 2022-06-26 00:09:25.367381
# Unit test for method concat of class Map
def test_Map_concat():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_2['A'] = Min(1)
    dict_2['B'] = Min(3)
    dict_1['B'] = Min(3)
    dict_1['A'] = Min(2)
    dict_1['C'] = Min(1)
    dict_0['A'] = Min(4)
    dict_0['B'] = Min(4)
    dict_0['C'] = Min(4)
    dict_0['D'] = Min(4)
    semigroup_0 = Map(dict_0)
    semigroup_1 = Map(dict_1)
    semigroup_2 = Map(dict_2)
    semigroup_3 = semigroup_2.concat(semigroup_1)
    #

# Generated at 2022-06-26 00:09:28.164322
# Unit test for method concat of class First
def test_First_concat():
    x_0 = First(1)
    x_1 = First(2)
    obj_0 = x_0.concat(x_1)
    assert obj_0 is not None
    assert obj_0.value == 1


# Generated at 2022-06-26 00:09:31.618383
# Unit test for method __str__ of class Map
def test_Map___str__():
    float_0 = 93.23499266307959
    semigroup_0 = Map(float_0)
    assert str(semigroup_0) == 'Map[value=93.23499266307959]'


# Generated at 2022-06-26 00:09:44.510262
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    float_0 = -2558.696249
    semigroup_0 = Semigroup(float_0)
    #Test case 0
    float_0 = -2558.696249
    semigroup_0.fold(lambda n: n * n) == float_0


# Generated at 2022-06-26 00:09:49.436887
# Unit test for method __str__ of class Sum
def test_Sum___str__():

    float_0 = 255.22
    float_1 = 4051.94
    float_2 = 2235.12
    semigroup_0 = Sum(float_0)
    semigroup_1 = Sum(float_1)
    semigroup_2 = Sum(float_2)

    # Test case 0
    str_0 = semigroup_0.__str__()

    assert str_0 == "Sum[value=255.22]"


# Generated at 2022-06-26 00:09:58.546972
# Unit test for method __str__ of class Last
def test_Last___str__():
    float_0 = -1467.607827
    int_0 = -1467
    str_0 = 'L\u002c1\u000c\u0003'
    last_0 = Last(str_0)
    last_1 = Last(int_0)
    last_2 = Last(float_0)

    assert_equal(last_0.__str__(), "Last[value=L,1	]", 'AssertionError')
    assert_equal(last_1.__str__(), "Last[value=-1467]", 'AssertionError')
    assert_equal(last_2.__str__(), "Last[value=-1467.607827]", 'AssertionError')
    float_1 = -1467.607827
    int_1 = -1244
    str

# Generated at 2022-06-26 00:10:06.865041
# Unit test for method __str__ of class Last
def test_Last___str__():
    list_0 = [0] * 12
    list_1 = [0] * 13
    list_2 = [0] * 11
    First_0 = First(set_0)
    First_1 = First(None)
    First_2 = type('', (object,), dict(__le__ = lambda self, arg: Last_0))
    #
    construct_0 = construct()
    construct_1 = construct()
    construct_2 = construct()
    construct_3 = construct()
    construct_4 = construct()
    construct_5 = construct()
    construct_6 = construct()
    construct_7 = construct()
    construct_8 = construct()
    construct_9 = construct()
    construct_10 = construct()
    construct_11 = construct()
    construct_12 = construct()
    construct_13 = construct()
   

# Generated at 2022-06-26 00:10:09.106912
# Unit test for method __str__ of class All
def test_All___str__():
    import pytest
    obj = All()
    expected = str(obj)
    assert type(expected) == str
    assert expected == "All[value=True]"


# Generated at 2022-06-26 00:10:12.604970
# Unit test for method __str__ of class Max
def test_Max___str__():
    cast(None, Max(-13.01509819)).__str__()
    cast(None, Max(0.521192407)).__str__()



# Generated at 2022-06-26 00:10:17.697303
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    float_0 = -1096.3483
    float_1 = -836.499
    semigroup_0 = Semigroup(float_0)
    semigroup_1 = Semigroup(float_0)
    semigroup_2 = Semigroup(float_1)

    #assert semigroup_0.__eq__(semigroup_1)
    #assert not semigroup_0.__eq__(semigroup_2)


# Generated at 2022-06-26 00:10:26.977994
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(99).fold(lambda v: v * 2) == 198
    assert All(True).fold(lambda v: v) is True
    assert All(False).fold(lambda v: v) is False
    assert One(True).fold(lambda v: v) is True
    assert One(False).fold(lambda v: v) is False
    assert First(5).fold(lambda v: v) == 5
    assert Last(5).fold(lambda v: v) == 5
    assert Map({'a': Sum(1), 'b': Sum(2)}).fold(lambda v: v) == {'a': Sum(1), 'b': Sum(2)}
    assert Max(5).fold(lambda v: v) == 5
    assert Min(5).fold(lambda v: v) == 5


# Generated at 2022-06-26 00:10:31.289763
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    float_0 = 1506.035823
    semigroup_0 = Semigroup(float_0)

    # Invoke fold
    result = semigroup_0.fold(lambda num: num * 2)

    # Asserts if result is the same as expected
    assert result == (2 * float_0)


# Generated at 2022-06-26 00:10:36.370377
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    float_0 = 914.290664
    semigroup_0 = Sum(float_0)

    # Check if method __str__ of class Sum return same as str function
    assert str(semigroup_0) == semigroup_0.__str__()
    assert 'Sum[value={}]'.format(float_0) == semigroup_0.__str__()



# Generated at 2022-06-26 00:11:04.388586
# Unit test for method concat of class Min
def test_Min_concat():
    string_0 = "`"
    float_0 = 19095.0
    float_1 = -1166.10405901
    float_2 = 18893.0
    float_3 = 10.71084
    float_4 = -12677.0
    semigroup_0 = Min(float_0)
    semigroup_1 = Min(float_1)
    semigroup_2 = semigroup_0.concat(semigroup_1)
    string_1 = str(semigroup_2)
    string_2 = "Min[value=-1166.10405901]"
    assert string_1 == string_2
    semigroup_3 = Min(float_2)
    semigroup_4 = semigroup_3.concat(semigroup_2)
    string_3 = str(semigroup_4)
   

# Generated at 2022-06-26 00:11:08.720519
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert all([
        isinstance(Sum(1), Sum),
        isinstance(All(True), All),
        isinstance(One(False), One),
        isinstance(First(True), First),
        isinstance(Last(False), Last),
        isinstance(Max(10), Max),
        isinstance(Min(10), Min),
    ])


# Generated at 2022-06-26 00:11:13.193909
# Unit test for method concat of class Last
def test_Last_concat():
    float_0 = 0.60012133557488
    semigroup_0 = Last(float_0)
    float_1 = 0.078262896508325
    semigroup_1 = Last(float_1)
    semigroup_1_concated = semigroup_0.concat(semigroup_1)
    assert semigroup_1_concated == semigroup_1



# Generated at 2022-06-26 00:11:20.568794
# Unit test for constructor of class Map
def test_Map():
    assert Map({"one": Sum(1), "two": Sum(2)}) == Map({'one': Sum(1), 'two': Sum(2)})
    assert Map({"one": Sum(1), "two": Sum(2)}) == Map({'two': Sum(2), 'one': Sum(1)})
    assert Map({"one": Sum(2), "two": Sum(2)}) != Map({'two': Sum(1), 'one': Sum(1)})


# Generated at 2022-06-26 00:11:26.456128
# Unit test for method concat of class One
def test_One_concat():
    float_0 = 0.5242986765
    str_1 = '1em'
    bool_0 = bool(str_1)
    bool_1 = bool(float_0)
    semigroup_0 = One(bool_1)
    semigroup_1 = One(bool_0)
    semigroup_2 = semigroup_0.concat(semigroup_1)
    assert semigroup_0 == One(bool(float_0))
    assert semigroup_1 == One(bool(str_1))
    assert semigroup_2 == One(True)


# Generated at 2022-06-26 00:11:28.999393
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    float_0 = 1506.035823
    semigroup_0 = Semigroup(float_0)
    #print(semigroup_0)


# Generated at 2022-06-26 00:11:33.818978
# Unit test for method concat of class First
def test_First_concat():
    string_0 = 'G^[=o@Q+r'
    monoid_0 = First(string_0)
    string_1 = '#'
    monoid_1 = First(string_1)
    monoid_2 = monoid_0.concat(monoid_1)
    string_2 = 'G^[=o@Q+r'
    assert monoid_2.value == string_2



# Generated at 2022-06-26 00:11:39.575938
# Unit test for constructor of class Max
def test_Max():
    case_values = [
        [[0, 0], 0],
        [[1, 2], 2],
        [[0, 0.1], 0.1],
        [[9, 0.1], 9],
        [[0, 4], 4],
    ]

    for value, expected_id in case_values:
        assert (Max(value[0]).value == expected_id)


# Generated at 2022-06-26 00:11:42.948521
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)

# Generated at 2022-06-26 00:11:44.795064
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(7)) == 'Min[value=7]'


# Generated at 2022-06-26 00:12:31.976666
# Unit test for method concat of class Map
def test_Map_concat():
    float_0 = 1506.035823
    semigroup_0 = Semigroup(float_0)
    float_1 = -1506.035823
    semigroup_1 = Semigroup(float_1)
    int_0 = 692
    semigroup_2 = Semigroup(int_0)
    int_1 = -692
    semigroup_3 = Semigroup(int_1)
    int_2 = 982
    semigroup_4 = Semigroup(int_2)
    int_3 = -982
    semigroup_5 = Semigroup(int_3)
    int_4 = 835
    semigroup_6 = Semigroup(int_4)
    int_5 = -835
    semigroup_7 = Semigroup(int_5)
    int_6 = 492
    semigroup_

# Generated at 2022-06-26 00:12:35.454710
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    float_0 = 5453.912389184703
    semigroup_0 = Sum(float_0)
    assert semigroup_0.__str__() == 'Sum[value=5453.912389184703]'



# Generated at 2022-06-26 00:12:38.797826
# Unit test for method concat of class First
def test_First_concat():
    str_0 = 'a'
    str_1 = 'b'
    semigroup_0 = First(str_0)
    semigroup_1 = First(str_1)
    semigroup_0.concat(semigroup_1)

    test_case_0()


# Generated at 2022-06-26 00:12:45.585616
# Unit test for method concat of class One
def test_One_concat():
    boolean_0 = Boolean.valueOf(True)
    boolean_1 = Boolean.valueOf(True)
    one_0 = One(boolean_1)
    one_1 = One(boolean_0)
    one_3 = one_0.concat(one_1)
    assert (one_3 == None or not one_3.equals(one_0))
    assert (one_0 != one_1)


# Generated at 2022-06-26 00:12:47.163261
# Unit test for constructor of class All
def test_All():
    assert str(All(True)) == "All[value=True]"


# Generated at 2022-06-26 00:12:51.961632
# Unit test for method concat of class Min
def test_Min_concat():
    expected = True
    float_0 = -1.0
    float_1 = 1.0
    semigroup_0 = Min(float_0)
    semigroup_1 = Min(float_1)

    actual = semigroup_0.concat(semigroup_1)

    assert expected == actual, 'actual = {0}, expected = {1}'.format(actual, expected)


# Generated at 2022-06-26 00:13:00.262699
# Unit test for method concat of class Sum
def test_Sum_concat():
    float_0 = 4117.929
    float_1 = -1560.632404
    float_2 = -6132.751027
    float_3 = -9011.142766
    float_4 = -960.822
    float_5 = -3287.167923
    float_6 = -2774.161264
    float_7 = -1046.089898
    float_8 = -8575.834225
    float_9 = -3557.092891
    float_10 = -2057.301766
    float_11 = -2684.815021
    float_12 = -6841.267089
    float_13 = -9940.52766
    float_14 = -7385.418514
    float_15 = -2443.

# Generated at 2022-06-26 00:13:08.549952
# Unit test for method concat of class Map
def test_Map_concat():
    map_0 = Map(
        {
            'hello': Sum(1),
            'world': All(False),
            'foo': Last(2)
        }
    )
    map_1 = Map(
        {
            'hello': Sum(2),
            'world': All(True),
            'foo': Last(4)
        }
    )
    map_2 = map_0.concat(map_1)
    assert (map_2.value['hello'].fold(lambda x: x) == 3)
    assert (map_2.value['world'].fold(lambda x: x) == False)
    assert (map_2.value['foo'].fold(lambda x: x) == 4)


# Generated at 2022-06-26 00:13:09.757967
# Unit test for constructor of class One
def test_One():
    assert type(One(False)) == One


# Generated at 2022-06-26 00:13:14.876156
# Unit test for method __str__ of class One
def test_One___str__():
    float_0 = 1506.035823
    bool_0 = bool.from_value(float_0)
    bool_1 = bool.from_value(float_0)
    one_0 = One(bool_0)
    one_1 = One(bool_1)

    assert_equals(one_0.__str__(), 'One[value=True]')


# Generated at 2022-06-26 00:14:55.890189
# Unit test for method concat of class Map
def test_Map_concat():
    float_0 = -1402.372849
    dict_0 = dict()
    dict_0[0] = Semigroup(float_0)
    dict_1 = dict()
    dict_1[0] = Semigroup(float_0)
    map_0 = Map(dict_0)
    map_1 = Map(dict_1)
    map_2 = map_0.concat(map_1)
    assert isinstance(map_2, Map)
    assert map_2.value[0].value == -1402.372849


# Generated at 2022-06-26 00:14:57.931103
# Unit test for constructor of class First
def test_First():
    random_int = random.randint(0, 100)
    random_semigroup = First(random_int)
    assert random_semigroup.value == random_int, "First class don't work properly"


# Generated at 2022-06-26 00:15:01.394007
# Unit test for constructor of class Last
def test_Last():
    float_0 = float("nan")
    float_1 = float_0
    semigroup_0 = Last(float_1)
    semigroup_0.value
    int_0 = Float.compare(float_0, float_1)
    assert int_0 == 0

    str_0 = str(semigroup_0)
    assert str_0 == 'Last[value={}]'.format(float_0)



# Generated at 2022-06-26 00:15:09.636187
# Unit test for constructor of class Sum
def test_Sum():
    float_0 = 1506.035823
    float_1 = -214.51
    float_2 = 65193.6079
    int_0 = 10354
    int_1 = -5892
    int_2 = -6618
    bool_1 = True
    bool_2 = False
    map_tuple = (
        ('a', Sum(float_1)),
        ('b', Sum(int_1)),
        ('c', Sum(bool_2)),
        ('d', Sum(float_1)),
        ('e', Sum(int_1)),
    )
    map_dict = dict(map_tuple)

# Generated at 2022-06-26 00:15:14.792400
# Unit test for constructor of class All
def test_All():
    int_0 = 997223573
    all_0 = All(int_0)
    assert all_0.value == 997223573
    bool_0 = False
    all_1 = All(bool_0)
    assert all_1.value == False
    bool_1 = True
    all_2 = All(bool_1)
    assert all_2.value == True


# Generated at 2022-06-26 00:15:16.649910
# Unit test for method concat of class First
def test_First_concat():
    assert str(First(1).concat(First(2))) == 'Fist[value=1]'


# Generated at 2022-06-26 00:15:22.191187
# Unit test for method __str__ of class Max
def test_Max___str__():
    float_0 = 8.389589866404036e-05
    float_1 = 5.917679730231759e-06
    semigroup_0 = Max(float_0)
    semigroup_1 = Max(float_1)
    string_0 = semigroup_0.__str__()
    string_1 = semigroup_1.__str__()
    string_2 = 'Max[value=8.389589866404036e-05]'
    assert string_0 == string_2
    assert string_1 == string_2


# Generated at 2022-06-26 00:15:27.557804
# Unit test for method concat of class Sum
def test_Sum_concat():
    float_0 = 280.28873274
    string_0 = "Hello"
    float_1 = float_0
    Sum_var_0 = Sum(float_1)
    Sum_var_1 = Sum(float_0)
    Sum_var_0.concat(Sum_var_1)
    Sum_var_1.concat(Sum_var_0)
    Sum_var_1.concat(Sum_var_0)
    Sum_var_1.concat(Sum_var_0)
    Sum_var_1.concat(Sum_var_0)


# Generated at 2022-06-26 00:15:29.754010
# Unit test for method concat of class First
def test_First_concat():
    semigroup_0 = First(False)
    semigroup_1 = First(True)
    semigroup_0.concat(semigroup_1)



# Generated at 2022-06-26 00:15:32.303226
# Unit test for constructor of class All
def test_All():
    value = False
    semigroup = All(value)
    assert semigroup.value == value
    value = True
    semigroup = All(value)
    assert semigroup.value == value
