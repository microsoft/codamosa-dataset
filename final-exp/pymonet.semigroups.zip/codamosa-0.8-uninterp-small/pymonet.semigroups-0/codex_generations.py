

# Generated at 2022-06-26 00:05:48.415026
# Unit test for method concat of class Max
def test_Max_concat():
    a = Max(1)
    b = Max(2)
    c = Max(3)
    d = Max(2)
    f = Max(1)
    assert a.concat(b).value == b.value
    assert a.concat(c).value == c.value
    assert a.concat(d).value == d.value
    assert a.concat(f).value == a.value


# Generated at 2022-06-26 00:05:53.409677
# Unit test for method concat of class Map
def test_Map_concat():
    map_a = Map({
        'a': Min(5),
        'b': Min(2)
    })
    map_b = Map({
        'a': Min(5),
        'b': Min(2)
    })
    assert map_a.concat(map_b) == Map({
        'a': Min(5),
        'b': Min(2)
    })



# Generated at 2022-06-26 00:05:58.338478
# Unit test for method concat of class Map
def test_Map_concat():
    map_0 = Map({'key': First('val')})
    map_1 = Map({'key': First('val')})
    map_res = map_0.concat(map_1)
    map_exp = {'key': First('val')}
    assert map_res.value == map_exp, f"bad value actual = {map_res.value}, expected = {map_exp}"


# Generated at 2022-06-26 00:06:01.747043
# Unit test for method concat of class Max
def test_Max_concat():
    max_0 = Max(2)
    max_1 = Max(1)
    max_2 = Max(3)

    assert max_0.concat(max_1).concat(max_2) == max_0.concat(max_1.concat(max_2))



# Generated at 2022-06-26 00:06:05.003859
# Unit test for method concat of class Max
def test_Max_concat():
    expected_max_concat = Max(2)
    actual_max_concat = Max(1).concat(Max(2))
    assert (
        actual_max_concat == expected_max_concat
    ), f"actual_max_concat{actual_max_concat} <> expected_max_concat{expected_max_concat}"


# Generated at 2022-06-26 00:06:15.477584
# Unit test for method concat of class Max
def test_Max_concat():
    number_1 = 2
    number_2 = 5
    max_1 = Max(number_1)
    max_2 = Max(number_2)
    assert max_1.concat(max_2).value == number_2
    assert max_2.concat(max_1).value == number_2
    assert max_1.concat(max_1).value == number_1
    number_3 = 1
    max_3 = Max(number_3)
    assert max_1.concat(max_3).value == number_1
    assert max_3.concat(max_1).value == number_1
    assert max_3.concat(max_2).value == number_2
    assert max_2.concat(max_3).value == number_2


# Generated at 2022-06-26 00:06:23.390194
# Unit test for method concat of class Max
def test_Max_concat():
    one_0 = None
    sum_0 = Sum(one_0)
    
    one_1 = None
    sum_1 = Sum(one_1)
    
    one_2 = None
    sum_2 = Sum(one_2)
    
    one_3 = None
    sum_3 = Sum(one_3)
    
    one_4 = None
    sum_4 = Sum(one_4)
    
    one_5 = None
    sum_5 = Sum(one_5)
    
    one_6 = None
    sum_6 = Sum(one_6)
    
    one_7 = None
    sum_7 = Sum(one_7)
    
    one_8 = None
    sum_8 = Sum(one_8)
    
    one_9 = None
    sum_

# Generated at 2022-06-26 00:06:27.250105
# Unit test for method concat of class Map
def test_Map_concat():
    map_0 = Map({'one': Sum(1)})
    map_1 = Map({'one': Sum(2)})

    val = map_0.concat(map_1).value['one'].value == 3

    return val


# Generated at 2022-06-26 00:06:33.637787
# Unit test for method concat of class Max
def test_Max_concat():

    # TEST CASES
    ###################################################################################

    # TEST CASE 0
    sum_0 = Max(3)
    sum_1 = Max(4)
    sum_2 = sum_0.concat(sum_1)

    assert type(sum_0) == Max
    assert sum_0.value == 3
    assert type(sum_1) == Max
    assert sum_1.value == 4
    assert type(sum_2) == Max
    assert sum_2.value == 4



# Generated at 2022-06-26 00:06:36.076243
# Unit test for method concat of class Max
def test_Max_concat():
    a = Max(1)
    b = Max(3)
    c = Max(a.concat(b))
    assert c == 3


# Generated at 2022-06-26 00:06:40.303462
# Unit test for method concat of class All
def test_All_concat():
    all_0 = All(False)
    all_1 = All(True)
    all_0.concat(all_1)
    all_0.concat(all_0)


# Generated at 2022-06-26 00:06:42.680722
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2


# Generated at 2022-06-26 00:06:45.473549
# Unit test for method concat of class Min
def test_Min_concat():
    sum_0 = Min(10)
    sum_1 = Min(20)
    result = sum_0.concat(sum_1)
    assert result.value == 10


# Generated at 2022-06-26 00:06:47.374279
# Unit test for constructor of class Map
def test_Map():
    map_0 = Map({})
    assert map_0.value == {}
    map_1 = Map({'key': Sum(1)})
    assert map_1.value == {'key': Sum(1)}


# Generated at 2022-06-26 00:06:50.819638
# Unit test for method __str__ of class Min
def test_Min___str__():
    one_0 = None
    sum_0 = Sum(one_0)
    min_0 = Min(one_0)
    assert isinstance(str(min_0), str)


# Generated at 2022-06-26 00:06:55.009893
# Unit test for method __str__ of class First
def test_First___str__():
    one_0 = None
    first_0 = First(one_0)
    str_0 = str(first_0)
    assert str_0 == 'Fist[value=None]', "Expected: %s, Got: %s" % ('Fist[value=None]', str_0)


# Generated at 2022-06-26 00:06:57.424908
# Unit test for method __str__ of class Min
def test_Min___str__():
    min_0 = Min(None)
    assert min_0.__str__() == 'Min[value=None]'



# Generated at 2022-06-26 00:07:01.351663
# Unit test for method __str__ of class Max
def test_Max___str__():
    one_0 = None
    max_0 = Max(one_0)
    str_0 = max_0.__str__()
    str_1 = str_0
    str_0 = str_0
    str_1 = str_1


# Generated at 2022-06-26 00:07:07.847842
# Unit test for constructor of class One
def test_One():
    # Constructor of One
    message0 = "Constructor of One(one_0)"
    one_0 = True
    # Create instance of class One
    one_0 = One(one_0)
    # Create expected instance of class One
    one_1 = One(True)
    # Check if the constructed instance of class One is equal to the expected one
    assert(one_0 == one_1), message0
    # Check the string representation of the expected instance of class One
    assert(str(one_1) == "One[value=True]"), message0


# Generated at 2022-06-26 00:07:09.355971
# Unit test for method concat of class Max
def test_Max_concat():
    max_1 = Max(123)
    max_2 = Max(22)
    ret_value = max_1.concat(max_2)
    assert ret_value == Max(max(max_1.value, max_2.value))


# Generated at 2022-06-26 00:07:13.686562
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert First(5) == First(5)
    assert First(5) != First(10)



# Generated at 2022-06-26 00:07:15.258530
# Unit test for constructor of class Min
def test_Min():
    value = 1
    min_0 = Min(value)
    assert min_0.value == value


# Generated at 2022-06-26 00:07:20.235455
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    one_0 = None
    sum_0 = Sum(one_0)
    sum_1 = sum_0.__str__()
    assert sum_1 == 'None'



# Generated at 2022-06-26 00:07:26.959346
# Unit test for method concat of class One
def test_One_concat():
    one_0 = One(True)
    one_1 = One(True)
    one_2 = one_0.concat(one_1)
    assert one_2.value == True
    one_3 = One(False)
    one_4 = One(False)
    one_5 = one_3.concat(one_4)
    assert one_5.value == False
    one_6 = One(False)
    one_7 = One(True)
    one_8 = one_6.concat(one_7)
    assert one_8.value == True
    one_9 = One(True)
    one_10 = One(False)
    one_11 = one_9.concat(one_10)
    assert one_11.value == True


# Generated at 2022-06-26 00:07:32.023087
# Unit test for constructor of class Map
def test_Map():
    testMap = Map({'a' : Sum(1)})
    assert(testMap.value['a'] == Sum(1))
    assert(testMap.concat(Map({'a' : Sum(2), 'b' : Sum(3)})) == Map({'a' : Sum(3), 'b' : Sum(3)}))



# Generated at 2022-06-26 00:07:35.583293
# Unit test for method __str__ of class Min
def test_Min___str__():
    min_0 = Min(20)
    str_0 = str(min_0)
    assert str_0 == "Min[value=20]", f"Expected Min[value=20] but got {str_0}"


# Generated at 2022-06-26 00:07:37.552015
# Unit test for method __str__ of class One
def test_One___str__():
    one_0 = All(True)
    str_0 = one_0.__str__()



# Generated at 2022-06-26 00:07:39.867283
# Unit test for method concat of class Max
def test_Max_concat():
    max_0 = Max(5)
    max_1 = Max(5)
    result = max_0.concat(max_1)
    assert result.value == 5


# Generated at 2022-06-26 00:07:41.986640
# Unit test for method concat of class Map
def test_Map_concat():
    Map({'a': Sum(1)}).concat(Map({'a': Sum(2)})) == Map({'a': Sum(3)})


# Generated at 2022-06-26 00:07:43.562109
# Unit test for constructor of class One
def test_One():
    one_1 = One(1)
    assert one_1.value == 1


# Generated at 2022-06-26 00:07:49.140382
# Unit test for method concat of class First
def test_First_concat():
    first_0 = First.neutral()
    first_1 = First(0)
    val = first_0.concat(first_1)
    assert val == first_1


# Generated at 2022-06-26 00:07:53.480258
# Unit test for method concat of class First
def test_First_concat():
    one_1 = First(1)
    one_2 = First(2)

    assert one_1.concat(one_2) == one_1


# Generated at 2022-06-26 00:07:55.286512
# Unit test for method __str__ of class Min
def test_Min___str__():
    one_0 = 0.0
    one_1 = Min(one_0)
    one_2 = str(one_1)


# Generated at 2022-06-26 00:07:58.677435
# Unit test for method __str__ of class First
def test_First___str__():
    value = {}
    _str = 'Fist[value={}]'.format(value)
    first_0 = First(value)
    assert str(first_0) == _str


# Generated at 2022-06-26 00:08:00.481162
# Unit test for constructor of class Max
def test_Max():
    max_0 = Max(0)
    assert max_0.value == 0


# Generated at 2022-06-26 00:08:03.450001
# Unit test for method __str__ of class All
def test_All___str__():
    All(True).__str__() == 'All[value=True]'
    All(False).__str__() == 'All[value=False]'
    All(None).__str__() == 'All[value=None]'


# Generated at 2022-06-26 00:08:05.342522
# Unit test for method __str__ of class Min
def test_Min___str__():
    val = "Min[value=1]"

    assert Min(1).__str__() == val


# Generated at 2022-06-26 00:08:06.874774
# Unit test for constructor of class All
def test_All():
    some_value = True
    all = All(some_value)
    assert all.value is True


# Generated at 2022-06-26 00:08:13.809847
# Unit test for method concat of class First
def test_First_concat():
    one_0 = None
    sum_0 = Sum(one_0)
    all_0 = All(sum_0)
    sum_1 = Sum(all_0)
    sum_2 = Sum(sum_1)
    one_1 = One(all_0)
    one_2 = One(one_1)
    sum_3 = Sum(one_2)
    one_3 = One(sum_1)
    one_4 = One(one_3)
    sum_4 = Sum(one_4)
    sum_5 = Sum(sum_4)
    one_5 = One(sum_4)
    one_6 = One(one_5)
    sum_6 = Sum(one_6)
    sum_7 = Sum(sum_6)
    one_7 = One(sum_6)


# Generated at 2022-06-26 00:08:16.678166
# Unit test for method __str__ of class Min
def test_Min___str__():
    one_0 = Min(None)
    str_0 = one_0.__str__()
    assert str_0 == "Min[value=None]", "Fail: wrong string representation"


# Generated at 2022-06-26 00:08:27.977028
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert(
        Sum(1).fold(lambda value: str(value)) == "1"
    )
    assert(
        All(True).fold(lambda value: str(value)) == "True"
    )
    assert(
        One(False).fold(lambda value: str(value)) == "False"
    )
    assert(
        First("+").fold(lambda value: str(value)) == "+"
    )
    assert(
        Last("=+=").fold(lambda value: str(value)) == "=+="
    )
    assert(
        Map({"a": Sum(1), "b": Sum(2)}).fold(lambda value: str(value)) == "{'a': Sum[value=1], 'b': Sum[value=2]}"
    )

# Generated at 2022-06-26 00:08:30.293010
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    one_0 = 0
    sum_0 = Sum(one_0)
    assert sum_0.__str__() == 'Sum[value=0]'


# Generated at 2022-06-26 00:08:32.521623
# Unit test for constructor of class Semigroup
def test_Semigroup():
    '''
    Constructor of class Semigroup.
    '''
    s0 = Semigroup(1)
    assert s0.value == 1


# Generated at 2022-06-26 00:08:39.314993
# Unit test for method concat of class Sum
def test_Sum_concat():
    one_0 = Sum(None)
    one_1 = one_0.concat(Sum(Sum(None).concat(Sum(Sum(None).concat(Sum(None)))).concat(Sum(None))).concat(Sum(None)).value)
    assert (one_1 == Sum(Sum(None).concat(Sum(Sum(None).concat(Sum(None)))).concat(Sum(None))).concat(Sum(None)))


# Generated at 2022-06-26 00:08:42.173152
# Unit test for method __str__ of class Map
def test_Map___str__():
    one_0 = None
    map_0 = Map(one_0)
    string_0 = map_0.__str__()
    assert repr(string_0) == repr(None), repr(string_0)


# Generated at 2022-06-26 00:08:45.798259
# Unit test for method __str__ of class One
def test_One___str__():
    one_0 = One(None)
    assert one_0.__str__() == 'One[value=None]', 'One.__str__() value expected to be "One[value=None]" but given "{}"'.format(
        one_0.__str__())



# Generated at 2022-06-26 00:08:48.428903
# Unit test for constructor of class One
def test_One():
    one_1 = One(None)
    one_2 = One(0)
    one_3 = One(1)
    assert one_1 != one_2 != one_3


# Generated at 2022-06-26 00:08:49.492501
# Unit test for method __str__ of class First
def test_First___str__():
    one_0 = First(2)
    assert one_0.__str__() == "Fist[value=2]"


# Generated at 2022-06-26 00:08:53.779087
# Unit test for constructor of class One
def test_One():
    f = One(True)
    assert f == One(True)
    assert f != One(False)

    All(True)
    All(False)

    Max(1)
    Max(2)
    Min(1)
    Min(2)

    First(1)
    First(2)
    Last(1)
    Last(2)
    
    Map({1: 3, 2: 4})

# Generated at 2022-06-26 00:08:56.758756
# Unit test for constructor of class Map
def test_Map():
    map_0 = Map({1: Sum(1)})
    assert isinstance(map_0, Map)



# Generated at 2022-06-26 00:09:06.689303
# Unit test for method concat of class One
def test_One_concat():
    assert One(0).concat(One(1)) == One(0)
    assert One(1).concat(One(0)) == One(1)
    assert One(0).concat(One(0)) == One(0)
    assert One(1).concat(One(1)) == One(1)

# Unit tes for method concat of class All

# Generated at 2022-06-26 00:09:08.219974
# Unit test for constructor of class First
def test_First():
    first_0 = First(None)
    assert first_0.value == None


# Generated at 2022-06-26 00:09:09.313416
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(0)) == 'Max[value=0]'


# Generated at 2022-06-26 00:09:11.030124
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert (str(Sum(0)) == 'Sum[value=0]')


# Generated at 2022-06-26 00:09:13.248947
# Unit test for method concat of class Last
def test_Last_concat():
    semigroup_0 = Last(None)
    semigroup_1 = semigroup_0
    assert semigroup_1 == Last(semigroup_0.value)


# Generated at 2022-06-26 00:09:14.380875
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(12).fold(lambda x: x) == 12


# Generated at 2022-06-26 00:09:16.201406
# Unit test for constructor of class One
def test_One():
    one_0 = None
    sum_0 = Sum(one_0)
    assert sum_0.value == 0


# Generated at 2022-06-26 00:09:24.995581
# Unit test for constructor of class All
def test_All():
    sum_0 = All(False)
    sum_1 = All(True)
    sum_2 = All(True)
    sum_3 = All(False)
    sum_4 = All(True)
    sum_5 = All(True)

    assert sum_0 == sum_0
    assert sum_1 == sum_1
    assert sum_0 != sum_1

    assert sum_1 != sum_0
    assert sum_1 != sum_2
    assert sum_1 != sum_3
    assert sum_1 != sum_4
    assert sum_1 != sum_5
    assert sum_2 != sum_0
    assert sum_2 != sum_1
    assert sum_2 != sum_3
    assert sum_2 != sum_4
    assert sum_2 != sum_5
    assert sum_3 != sum_0

# Generated at 2022-06-26 00:09:27.436869
# Unit test for method concat of class One
def test_One_concat():
    one_0 = One(True)
    one_1 = One(True)
    expected = One(True)
    actual = one_0.concat(one_1)
    assert expected == actual



# Generated at 2022-06-26 00:09:30.121396
# Unit test for constructor of class Min
def test_Min():
    minValue_0 = Min(10)
    minValue_1 = Min(minValue_0.value + 10)
    assert minValue_1.value == 20


# Generated at 2022-06-26 00:09:37.323838
# Unit test for constructor of class Sum
def test_Sum():
    one_1 = 1
    sum_1 = Sum(one_1)


# Generated at 2022-06-26 00:09:43.407952
# Unit test for method concat of class First
def test_First_concat():
    first_0 = First(None)
    first_1 = first_0.concat(first_0)
    assert first_1 == First(None)
    first_2 = First(None)
    first_3 = first_0.concat(first_2)
    assert first_3 == First(None)
    first_4 = First(0)
    first_5 = first_0.concat(first_4)
    assert first_5 == First(0)


# Generated at 2022-06-26 00:09:46.656289
# Unit test for constructor of class First
def test_First():
    # create a new First with value = 1
    First_1 = First(1)
    # test if its value is 1
    assert First_1.value == 1
    # test if it's instance match with Class First
    assert isinstance(First_1, First)




# Generated at 2022-06-26 00:09:49.318351
# Unit test for constructor of class Map
def test_Map():
    m = Map({'key1': Sum(1), 'key2': Sum(2)})
    assert m.value['key1'].value == 1
    assert m.value['key2'].value == 2

# Generated at 2022-06-26 00:09:51.833175
# Unit test for constructor of class Last
def test_Last():
    last_0 = Last(1)
    last_1 = Last(2)
    last_2 = last_0.concat(last_1)
    assert last_2 == Last(2)


# Generated at 2022-06-26 00:09:55.348945
# Unit test for method __str__ of class Map
def test_Map___str__():
    value_0 = "value"
    map_0 = Map(value_0)
    str = map_0.__str__()
    assert str == "Map[value=value]"


# Generated at 2022-06-26 00:09:56.247465
# Unit test for constructor of class Sum
def test_Sum():
    one_1 = 1
    sum_1 = Sum(one_1)
    assert isinstance(sum_1.value, int)



# Generated at 2022-06-26 00:10:02.653576
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(None)) == "Sum[value=None]", "It should be: Sum[value=None]"
    assert str(Sum(0)) == "Sum[value=0]", "It should be: Sum[value=0]"
    assert str(Sum(4.4)) == "Sum[value=4.4]", "It should be: Sum[value=4.4]"
    assert str(Sum(True)) == "Sum[value=True]", "It should be: Sum[value=True]"
    assert str(Sum(False)) == "Sum[value=False]", "It should be: Sum[value=False]"

# Generated at 2022-06-26 00:10:07.238531
# Unit test for method concat of class Min
def test_Min_concat():
    one_0 = 12
    semigroup_0 = Min(one_0)
    one_1 = 14
    semigroup_1 = Min(one_1)
    semigroup_2 = semigroup_0.concat(semigroup_1)
    boolean_0 = semigroup_2.__eq__(Min(12))
    assert boolean_0 == True


# Generated at 2022-06-26 00:10:11.154743
# Unit test for method concat of class One
def test_One_concat():
    one_0 = None
    one_1 = One(one_0)
    int_0 = None
    one_2 = One(int_0)
    one_3 = one_1.concat(one_2)


# Generated at 2022-06-26 00:10:19.100096
# Unit test for method __str__ of class First
def test_First___str__():
    one_0 = First('0')
    assert str(one_0) == 'Fist[value=0]'


# Generated at 2022-06-26 00:10:25.744488
# Unit test for constructor of class First
def test_First():
    """
    Test function for First class constructor
    :return:
    """

    first_0 = First("First Data")
    print("first_0.fold(print) : {}".format(first_0.fold(print)))

    first_1 = First("First Data 1")
    print("first_1.fold(print) : {}".format(first_1.fold(print)))

    first_concat = first_0.concat(first_1)
    print("first_concat.fold(print) : {}".format(first_concat.fold(print)))


# Generated at 2022-06-26 00:10:29.954456
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First(2)) == 'Fist[value=2]'
    with pytest.raises(TypeError):
        First(None)
    with pytest.raises(TypeError):
        First("")


# Generated at 2022-06-26 00:10:39.445999
# Unit test for method concat of class One

# Generated at 2022-06-26 00:10:42.164810
# Unit test for method concat of class First
def test_First_concat():
    one_0 = First(None)
    one_1 = First(None)
    one_2 = one_0.concat(one_1)



# Generated at 2022-06-26 00:10:46.255839
# Unit test for method concat of class Map
def test_Map_concat():
    one_0 = Map({0: None, 1: Map({})})
    one_1 = None
    sum_0 = one_0.concat(one_1)
    assert isinstance(sum_0, Map)


# Generated at 2022-06-26 00:10:49.367344
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    # Arrange
    one_0 = 1
    expected = 'Sum[value=1]'
    # Act
    sum_0 = Sum(one_0)
    actual = str(sum_0)
    # Assert
    assert actual == expected


# Generated at 2022-06-26 00:10:51.941613
# Unit test for constructor of class All
def test_All():
    all_0 = All(True)
    assert all_0.value == True


# Generated at 2022-06-26 00:10:53.240057
# Unit test for constructor of class Map
def test_Map():
    assert Map({}) == Map({})

# Generated at 2022-06-26 00:10:54.633373
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(2)) == str(First(2))



# Generated at 2022-06-26 00:11:02.053556
# Unit test for constructor of class All
def test_All():
    a = All(True)
    assert a.value == True
    a = All(False)
    assert a.value == False


# Generated at 2022-06-26 00:11:06.948121
# Unit test for method concat of class Map
def test_Map_concat():
    expected = Map({'key_1': First(None), 'key_2': Last(2), 'key_3': Sum(0)})
    actual = Map({'key_1': First(None), 'key_2': First(1)}).concat(
        Map({'key_1': Last(None), 'key_2': Last(2), 'key_3': Sum(0)})
    )
    assert expected.value == actual.value


# Generated at 2022-06-26 00:11:08.640142
# Unit test for constructor of class Map
def test_Map():
    obj = Map()
    assert obj.value == {}, "Test Case 0 Failed"

# Generated at 2022-06-26 00:11:10.009398
# Unit test for constructor of class Min
def test_Min():
    min = Min(1)
    assert min is not None


# Generated at 2022-06-26 00:11:11.780487
# Unit test for method __str__ of class First
def test_First___str__():
    sut = First(3)
    result = str(sut)
    assert 'Fist[value=3]' == result


# Generated at 2022-06-26 00:11:21.651634
# Unit test for method __str__ of class Map
def test_Map___str__():
    print("-----test_Map___str__()-----")
    one_0 = None
    map_0 = Map(one_0)
    assert str(map_0) == 'Map[value=None]'
    one_0 = {}
    map_0 = Map(one_0)
    assert str(map_0) == 'Map[value={}]'
    one_0 = {1: All(True), 2: Sum(2), 3: Map({1: Last(2)})}
    map_0 = Map(one_0)
    assert str(map_0) == "Map[value={1: All[value=True], 2: Sum[value=2], 3: Map[value={1: Last[value=2]}]}]"


# Generated at 2022-06-26 00:11:22.814249
# Unit test for constructor of class Sum
def test_Sum():
    sum_0 = Sum(2)


# Generated at 2022-06-26 00:11:24.380133
# Unit test for method __str__ of class Map
def test_Map___str__():
    map_0 = Map(1)
    assert str(map_0) == 'Map[value=1]'


# Generated at 2022-06-26 00:11:26.783762
# Unit test for constructor of class Min
def test_Min():
    min_0 = Min(1000)
    min_1 = Min(500)
    min_2 = Min(1500)
    assert min_0.value == 1000
    assert min_1.value == 500
    assert min_2.value == 1500
    

# Generated at 2022-06-26 00:11:30.688396
# Unit test for method concat of class First
def test_First_concat():
    # Test case 1
    one_1 = First(1)
    one_2 = First(2)
    result = one_1.concat(one_2)
    expected_result = one_1
    assert result == expected_result

    

# Generated at 2022-06-26 00:11:46.504602
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(7).concat(Sum(6)) == Sum(13)
    assert Sum(6.0).concat(Sum(5.5)) == Sum(11.5)
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(2).concat(Sum(1)) == Sum(3)


# Generated at 2022-06-26 00:11:48.304639
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    This function tests the constructor of class Semigroup
    """
    assert Semigroup(1).value == 1



# Generated at 2022-06-26 00:11:50.226122
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-26 00:11:54.347262
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    sum_empty = Sum.neutral()
    sum_3 = Sum(3)
    sum_5 = Sum(5)
    assert sum_empty.fold(lambda x: x + 10) == 10
    assert sum_3.fold(lambda x: x + 10) == 13
    assert sum_5.fold(lambda x: x + 10) == 15


# Generated at 2022-06-26 00:11:56.289275
# Unit test for constructor of class Max
def test_Max():
    max_0 = Max(1)
    max_1 = Max(2)


# Generated at 2022-06-26 00:12:02.167749
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_0 = Sum(5)
    sum_1 = Sum(5)
    sum_2 = Sum(5)
    sum_2.concat(sum_1)
    sum_2 = Sum(sum_2.value + sum_0.value)
    assert sum_0 == sum_1
    assert sum_2.value == sum_0.value + sum_1.value


# Generated at 2022-06-26 00:12:05.168506
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(4).concat(Max(2)).value == 4
    assert Max(4).concat(Max(6)).value == 6
    assert Max(4).concat(Max(4)).value == 4


# Generated at 2022-06-26 00:12:11.071675
# Unit test for method concat of class One
def test_One_concat():
    assert One(False).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(True).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-26 00:12:12.866908
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map().concat(Sum.neutral()).value == Map().value
    assert Map().concat(Max.neutral()).value == Map().value



# Generated at 2022-06-26 00:12:17.692897
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    val_0, val_1 = 1, 2
    semigroup_0 = First(val_0)
    semigroup_1 = First(val_0)
    semigroup_2 = Last(val_0)
    assert semigroup_0.__eq__(semigroup_1)
    assert not semigroup_0.__eq__(semigroup_2)


# Generated at 2022-06-26 00:12:30.354546
# Unit test for constructor of class Map
def test_Map():
    map_0 = Map()



# Generated at 2022-06-26 00:12:32.045592
# Unit test for constructor of class Min
def test_Min():
    x = Min(3)
    y = Min(5)
    assert type(x) == Min
    assert x.value == 3


# Generated at 2022-06-26 00:12:36.145423
# Unit test for method concat of class First
def test_First_concat():

    # Setup
    first_0 = First()
    first_1 = First()

    expected_first_0 = first_0

    # Exercise
    actual_first_0 = first_0.concat(first_1)

    # Verification
    assert actual_first_0 == expected_first_0



# Generated at 2022-06-26 00:12:39.892773
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum_0 = Sum(0)
    sum_1 = Sum(1)
    sum_2 = Sum(2)

    assert sum_0.__str__() == "Sum[value=0]"
    assert sum_1.__str__() == "Sum[value=1]"
    assert sum_2.__str__() == "Sum[value=2]"



# Generated at 2022-06-26 00:12:43.334782
# Unit test for method __str__ of class Map
def test_Map___str__():
    map_0 = Map()
    str_0 = map_0.__str__()
    assert type(str_0) is str


# Generated at 2022-06-26 00:12:45.372850
# Unit test for method concat of class First
def test_First_concat():
    first = First(1)
    other = First(2)
    assert first.concat(other) == First(1)



# Generated at 2022-06-26 00:12:46.998358
# Unit test for constructor of class One
def test_One():
    one = One(1)
    assert one.value == 1


# Generated at 2022-06-26 00:12:48.738268
# Unit test for constructor of class First
def test_First():
    first_0 = First('First_0')
    print(assert_equal(first_0.value, 'First_0'))


# Generated at 2022-06-26 00:12:50.420455
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1
    assert Max(2).value == 2
    assert Max(-1).value == -1


# Generated at 2022-06-26 00:12:52.228823
# Unit test for constructor of class Last
def test_Last():
    res = Last('a')
    assert res.value == 'a'


# Generated at 2022-06-26 00:13:24.345942
# Unit test for constructor of class All
def test_All():
    # Case 0:
    # 1. Assert that All(True) is equal to All(True)
    # 2. Assert that All(True) is not equal to All(False)
    res = All(True)
    expected = All(True)
    assert res == expected, "Expected: {}\nActual: {}".format(expected, res)
    res = All(False)
    expected = All(True)
    assert res != expected, "Expected: {}\nActual: {}".format(expected, res)
    # Case 1:
    # 1. Assert that All(True).concat(All(True)) is equal to All(True)
    # 2. Assert that All(False).concat(All(True)) is equal to All(False)
    # 3. Assert that All(True).concat(

# Generated at 2022-06-26 00:13:32.170624
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x + 1) == 2
    assert All(False).fold(lambda x: x and True) == False
    assert One(True).fold(lambda x: x or False) == True
    assert First(1).fold(lambda x: x) == 1
    assert Last(1).fold(lambda x: x) == 1
    assert Map(
        {
            "as": First(1),
            "wqe": Last(2),
        }
    ).fold(lambda x: x) == {'as': First(1), 'wqe': Last(2)}
    assert Max(2).fold(lambda x: x) == 2
    assert Min(2).fold(lambda x: x) == 2


# Generated at 2022-06-26 00:13:36.066727
# Unit test for constructor of class Min
def test_Min():
    min_0 = Min.neutral()
    assert min_0.value == float("inf")
    min_1 = Min(1)
    min_2 = Min(2)
    min_0_concat = Min.neutral().concat(min_1)
    assert min_0_concat.value == 1
    assert min_1.concat(min_2).value == 1


# Generated at 2022-06-26 00:13:37.578884
# Unit test for method concat of class One
def test_One_concat():
    f1 = One(True)
    f2 = First(None)
    print(f1.concat(f2))



# Generated at 2022-06-26 00:13:44.146109
# Unit test for constructor of class Map
def test_Map():
    map_0 = Map({"key_01": First("value_01"), "key_02": Last("value_02")})
    assert map_0.value["key_01"] == First("value_01")
    assert map_0.value["key_02"] == Last("value_02")
   
    map_1 = Map({"key_01": First("value_01"), "key_02": First("value_02")})
    assert map_1.value["key_01"] == First("value_01")
    assert map_1.value["key_02"] == First("value_02")
   
    map_2 = Map({"key_01": First("value_01")})
    assert map_2.value["key_01"] == First("value_01")

# Generated at 2022-06-26 00:13:47.498689
# Unit test for method concat of class One
def test_One_concat():
    one_0 = One(True)
    one_1 = One(False)
    one_2 = one_0.concat(one_1)
    assert one_2.value == True


# Generated at 2022-06-26 00:13:49.421152
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(2)) == Sum(4)


# Generated at 2022-06-26 00:13:51.587919
# Unit test for constructor of class Max
def test_Max():
    # Test instances of Max class with value in range from -10 to 10
    for i in range(-10, 10):
        assert Max(i).value == i


# Generated at 2022-06-26 00:13:53.258156
# Unit test for method concat of class First
def test_First_concat():
    first_0 = First(False)
    first_1 = First(True)
    assert first_0.concat(first_1) == first_0


# Generated at 2022-06-26 00:13:59.695991
# Unit test for constructor of class First
def test_First():
    first_0 = First('abc')
    first_1 = First(False)
    first_2 = First(None)
    first_3 = First(0.0)
    first_4 = First('')
    first_5 = First('defg')
    first_6 = First(True)
    first_7 = First('hijklmnop')
    first_8 = First(1)
    first_9 = First(-1)


# Generated at 2022-06-26 00:14:59.011140
# Unit test for method __str__ of class All
def test_All___str__():
    All(True).__str__()



# Generated at 2022-06-26 00:15:00.191379
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert Sum(1).__str__() == 'Sum[value=1]'


# Generated at 2022-06-26 00:15:01.445305
# Unit test for constructor of class Max
def test_Max():
    max_0 = Max()
    max_1 = Max(max_0)
    assert max_0.value == max_1.value



# Generated at 2022-06-26 00:15:02.497072
# Unit test for constructor of class Max
def test_Max():
    m_1=Max(2)
    print(m_1)


# Generated at 2022-06-26 00:15:03.877262
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum_0 = Sum()
    assert str(sum_0) == 'Sum[value=0]'


# Generated at 2022-06-26 00:15:12.803048
# Unit test for method concat of class One
def test_One_concat():
    actual_one = One(True).concat(One(True))
    expected_one = One(True)
    assert actual_one == expected_one, "First test case failed"

    actual_one = One(True).concat(One(False))
    expected_one = One(True)
    assert actual_one == expected_one, "Second test case failed"

    actual_one = One(False).concat(One(False))
    expected_one = One(False)
    assert actual_one == expected_one, "Third test case failed"

    actual_one = One(False).concat(One(True))
    expected_one = One(True)
    assert actual_one == expected_one, "Fourth test case failed"


# Generated at 2022-06-26 00:15:14.233199
# Unit test for constructor of class Last
def test_Last():
    assert not hasattr(Last(1), 'value')
    assert Last(1).value == 1


# Generated at 2022-06-26 00:15:16.648042
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(2)) != Last(1)


# Generated at 2022-06-26 00:15:17.816244
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(5)) == "Max[value=5]"


# Generated at 2022-06-26 00:15:18.964312
# Unit test for constructor of class First
def test_First():
    assert First(10) == First(10)
