

# Generated at 2022-06-26 00:05:54.809743
# Unit test for method concat of class Max
def test_Max_concat():
    max_0 = Max(0)
    assert max_0.concat(Max(0)).value == 0
    max_1 = Max(0)
    assert max_1.concat(Max(0)).value == 0
    max_2 = Max(0)
    assert max_2.concat(Max(0)).value == 0


# Generated at 2022-06-26 00:06:03.101925
# Unit test for method concat of class Min
def test_Min_concat():
    # Case 0
    number_0 = 72
    number_1 = -2.235735
    min_0 = Min(number_0)
    min_1 = Min(number_1)
    min_2 = min_1.concat(min_0)
    assert min_2 == Min(-2.235735)

    # Case 1
    number_0 = -3
    number_1 = -71.2
    min_0 = Min(number_0)
    min_1 = Min(number_1)
    min_2 = min_1.concat(min_0)
    assert min_2 == Min(-71.2)

    # Case 2
    number_0 = -87
    number_1 = 78
    min_0 = Min(number_0)

# Generated at 2022-06-26 00:06:10.642748
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min(75)
    min_1 = Min(True)
    min_2 = Min(min_0)
    min_3 = min_0.concat(min_1)
    min_4 = Min(6.47015e-05)
    min_5 = Min(14)
    min_6 = Min(min_3)
    min_7 = min_4.concat(min_5)
    min_8 = min_7.concat(min_6)
    min_9 = Min(min_8)
    min_10 = min_2.concat(min_9)


# Generated at 2022-06-26 00:06:20.749927
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(4)) == Min(1)
    assert Min(4).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)
    assert Min(3).concat(First('A')) == Min(3)
    assert Min(3).concat(All(False)) == Min(3)
    assert Min(1).concat(One(True)) == Min(1)
    assert Min(1).concat(Sum(5)) == Min(1)
    assert Min(1).concat(Last('a')) == Min(1)
    assert Min(2).concat(One(True)) == Min(2)
    assert Min(1).concat(Sum(3)) == Min(1)
    assert Min(2).con

# Generated at 2022-06-26 00:06:30.442551
# Unit test for method concat of class Min
def test_Min_concat():
    print('>>> test_Min_concat:')
    value_0 = Min(True)
    value_1 = Min(value_0)
    if value_0.concat(value_1).value == value_1.concat(value_0).value and value_0.concat(value_1).value != value_0.value and value_0.concat(value_1).value != value_1.value:
        print('test_Min_concat: PASSED')
        print('test_Min_concat: PASSED')
    else:
        print('test_Min_concat: FAILED')


# Generated at 2022-06-26 00:06:33.858244
# Unit test for method concat of class Min
def test_Min_concat():
    """
    unit test for Min.concat
    """
    value_0 = Min(6)
    value_1 = Min(4)
    value_2 = value_0.concat(value_1)
    assert value_2.value == 4

# Generated at 2022-06-26 00:06:43.837224
# Unit test for method concat of class Max
def test_Max_concat():
    str_1 = 'A'
    int_1 = 17
    float_1 = 39.5
    bool_1 = True
    float_2 = float_1
    int_2 = int_1
    bool_2 = bool_1
    str_2 = str_1
    List_1 = [str_1, int_1, float_1, bool_1]
    List_2 = [float_2, int_2, bool_2, str_2]
    Tuple_1 = (str_1, int_1, float_1, bool_1)
    Tuple_2 = (float_2, int_2, bool_2, str_2)
    Dict_1 = {0: int_1, 1: float_1, 2: bool_1, 3: str_1}
    Dict_2

# Generated at 2022-06-26 00:06:48.851986
# Unit test for method concat of class Max
def test_Max_concat():
    max_0 = Max(87)
    max_1 = Max(91)
    max_0.concat(max_1)

    max_0 = Max(80)
    max_1 = Max(65)
    max_0.concat(max_1)

    max_0 = Max(0)
    max_1 = Max(3)
    max_0.concat(max_1)



# Generated at 2022-06-26 00:06:54.478042
# Unit test for method concat of class Max
def test_Max_concat():
    max_0 = Max(0)
    max_1 = Max(max_0.value)
    assert max_0.value == max_1.value
    assert max_0 == max_1
    max_value = max_0.concat(Max(1))
    assert max_value.value == 1
    assert max_value == Max(1)


# Generated at 2022-06-26 00:06:58.148671
# Unit test for method concat of class Min
def test_Min_concat():
    min_1 = Min(1)
    min_2 = Min(2)
    concatted = min_1.concat(min_1)
    assert isinstance(concatted, Min)
    assert concatted == Min(1)


# Generated at 2022-06-26 00:07:02.032942
# Unit test for constructor of class Semigroup
def test_Semigroup():
    pass



# Generated at 2022-06-26 00:07:04.371158
# Unit test for constructor of class Max
def test_Max():
    max_0 = Max(28)
    max_1 = Max(1)
    max_2 = Max(max_0.concat(max_1).value)


# Generated at 2022-06-26 00:07:06.017675
# Unit test for constructor of class Min
def test_Min():
    assert Min(13) == Min(13)
    assert Min(13) != Min(14)


# Generated at 2022-06-26 00:07:11.118573
# Unit test for constructor of class Semigroup
def test_Semigroup():
    all_0 = All('D0Qkwnt<')
    assert all_0.value == 'D0Qkwnt<'
    assert all_0.fold(lambda x: x) == 'D0Qkwnt<'
    all_1 = All.neutral()
    assert all_1.value == All.neutral_element
    all_2 = All('D0Qkwnt<')
    assert all_0 == all_2
    assert not all_0 != all_2


# Generated at 2022-06-26 00:07:12.544965
# Unit test for constructor of class One
def test_One():
    return One.neutral()


# Generated at 2022-06-26 00:07:14.463227
# Unit test for method __str__ of class Last
def test_Last___str__():
    str_0 = '|'
    last_0 = Last(str_0)
    str_1 = 'Last[value=|]'


# Generated at 2022-06-26 00:07:19.568821
# Unit test for constructor of class Sum
def test_Sum():
    assert str(Sum(1)) == 'Sum[value=1]'
    assert str(Sum(0)) == 'Sum[value=0]'
    assert str(Sum(100500)) == 'Sum[value=100500]'


# Generated at 2022-06-26 00:07:23.878665
# Unit test for method __str__ of class Map
def test_Map___str__():
    str_0 = 'D0Qkwnt<'
    map_0 = Map({str_0: str_0})

    assert str(map_0) == 'Map[value={\'D0Qkwnt<\': \'D0Qkwnt<\'}]'

test_Map___str__()


# Generated at 2022-06-26 00:07:28.853733
# Unit test for constructor of class Map
def test_Map():
    maps = Map({'foo': First(1), 'bar': Last(2)})
    assert len(maps) == 2
    assert 'foo' in maps.value
    assert 'bar' in maps.value
    assert maps['foo'] == 1
    assert maps['bar'] == 2
    assert maps['foo'].value == 1
    assert maps['bar'].value == 2


# Generated at 2022-06-26 00:07:31.084057
# Unit test for constructor of class Sum
def test_Sum():
    str_0 = ''
    sum_0 = Sum(str_0)


# Generated at 2022-06-26 00:07:36.292690
# Unit test for method __str__ of class Min
def test_Min___str__():
    str_0 = 'D0Qkwnt<'
    min_0 = Min(str_0)
    assert min_0.__str__() == 'Min[value=D0Qkwnt<]'


# Generated at 2022-06-26 00:07:38.550861
# Unit test for constructor of class Last
def test_Last():
    expected_value = "test string"
    last_1 = Last(expected_value)
    assert last_1.value == expected_value


# Generated at 2022-06-26 00:07:40.522931
# Unit test for method __str__ of class Min
def test_Min___str__():
    obj_0 = Min(4)
    assert str(obj_0) == 'Min[value=4]'


# Generated at 2022-06-26 00:07:47.020812
# Unit test for constructor of class Sum
def test_Sum():
    print('\n*********Unit test of constructor*********')
    print('Sum(int)')
    sum_1 = Sum(0)
    assert sum_1.value == 0
    assert type(sum_1.value) is int
    print('Sum(float)')
    sum_2 = Sum(0.0)
    assert sum_2.value == 0.0
    assert type(sum_2.value) is float
    print('Sum(list)')
    sum_3 = Sum([1, 2, 3])


# Generated at 2022-06-26 00:07:52.784759
# Unit test for method concat of class First
def test_First_concat():
    "def concat(self, semigroup)"
    last_0 = First('bN:')
    last_1 = First(')O')
    result = last_0.concat(last_1)
    assert str(result) == "Fist[value=bN:]"



# Generated at 2022-06-26 00:07:58.584251
# Unit test for method concat of class Max
def test_Max_concat():
    print("test_Max_concat")

    assert Max(0).concat(Max(0)) == Max(0)
    assert Max(1).concat(Max(0)) == Max(1)

    assert Max(0.0).concat(Max(0.0)) == Max(0.0)
    assert Max(1.1).concat(Max(0.0)) == Max(1.1)

    assert Max('a').concat(Max('a')) == Max('a')
    assert Max('b').concat(Max('a')) == Max('b')


# Generated at 2022-06-26 00:08:01.181572
# Unit test for constructor of class Last
def test_Last():
    last_0 = Last('D0Qkwnt<')
    output = str(last_0)

    assert 'value=D0Qkwnt<' == output


# Generated at 2022-06-26 00:08:06.381028
# Unit test for method concat of class Max
def test_Max_concat():
    max_0 = Max(1)
    max_1 = Max(2)
    max_2 = Max(max_0, max_1)
    max_3 = Max(1)
    max_4 = Max(3)
    max_5 = Max(max_3, max_4)
    max_6 = max_2.concat(max_5)
    assert max_6 == Max(3)


# Generated at 2022-06-26 00:08:10.162809
# Unit test for constructor of class Map
def test_Map():
    map_0 = Map({"key1": "value1", "key2": "value2"})
    assert isinstance(map_0, Map)
    assert map_0.value == {"key1": "value1", "key2": "value2"}


# Generated at 2022-06-26 00:08:15.353013
# Unit test for method concat of class Last
def test_Last_concat():
    str_0 = '2@us(J5]'
    str_1 = 'VpZu3'
    last_0 = Last(str_0)
    last_1 = Last(str_1)
    last_2 = last_0.concat(last_1)
    assert str_1 == last_2.value


# Generated at 2022-06-26 00:08:25.114640
# Unit test for method concat of class Last
def test_Last_concat():
    """
    Tests concat of Last semigroup, with 2 instances of different types.
    """
    int_0 = 10
    first_0 = First(int_0)
    str_0 = 'y<v>'
    first_1 = First(str_0)
    concat_0 = first_0.concat(first_1)
    assert str(concat_0) == 'Fist[value=10]'


# Generated at 2022-06-26 00:08:31.422564
# Unit test for method concat of class Sum
def test_Sum_concat():
    str_0 = 'D0Qkwnt<'
    all_0 = All(str_0)
    int_0 = 123
    num_0 = First(int_0)
    int_1 = 9
    max_0 = Max(int_1)
    int_2 = -187
    max_1 = Max(int_2)
    str_1 = 'a'
    map_0 = Map({str_1: sum_0})
    dict_0 = {str_0: sum_0}
    map_1 = Map(dict_0)
    str_2 = 'D0Qkwnt<'
    int_3 = -187
    max_2 = Max(int_3)
    str_3 = 'a'
    map_2 = Map({str_3: sum_1})
    dict_1

# Generated at 2022-06-26 00:08:35.832168
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_0 = Sum(23)
    sum_1 = Sum(33)
    sum_2 = sum_0.concat(sum_1)
    assert(sum_2.value == sum_0.value + sum_1.value)


# Generated at 2022-06-26 00:08:39.638905
# Unit test for method __str__ of class First
def test_First___str__():
    str_0 = '|(8g`dZ$'
    str_1 = '', ')W??'
    first_0 = First(str_0)
    assert first_0.__str__() == 'Fist[value=|(8g`dZ$]'


# Generated at 2022-06-26 00:08:42.830211
# Unit test for method concat of class Sum
def test_Sum_concat():
    str_0 = 'zq4p4'
    expected_value = Sum('zq4p4')
    actual_value = Sum.neutral().concat(Sum(str_0))
    assert actual_value == expected_value


# Generated at 2022-06-26 00:08:47.526560
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    str_0 = '+\x0f\\E@\x00\x00\x00\x00\x00'
    all_2 = Sum(str_0)
    actual = all_2.__str__()
    expected = 'Sum[value=+\x0f\\E@\x00\x00\x00\x00\x00]'
    assert actual == expected


# Generated at 2022-06-26 00:08:52.627070
# Unit test for constructor of class First
def test_First():
    str_0 = '\xa9\x0b\xa1H\x12\xe6\x01\xa8\x03\x15\x0e\x91'
    str_1 = 'Nw3\x7f\x0eQ\x8c\x9a'
    first_0 = First(str_1)
    assert(first_0.value == str_1)
    first_0 = First(str_0)
    assert(first_0.value == str_0)


# Generated at 2022-06-26 00:08:57.231393
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    from petri.core.semigroup import Sum

    str_0 = 'S_0'
    sum_0 = Sum(str_0)
    assert str(sum_0) == 'Sum[value=S_0]'


# Generated at 2022-06-26 00:09:00.305012
# Unit test for constructor of class Map
def test_Map():
    result = Map({'a': Sum(1), 'b': Sum(4)})
    expected = Map({'a': Sum(1), 'b': Sum(4)})
    assert result.value == expected.value


# Generated at 2022-06-26 00:09:07.829349
# Unit test for constructor of class All
def test_All():
    print('------Test Class All------')
    # inputs or default values
    str_0 = 'D0Qkwnt<'
    all_0 = All(str_0)

    result = str_0
    assert all_0.value == result

    # if we use All constructor with int, list or bool input
    all_1 = All(1)
    all_2 = All([1, 2, 3])
    all_3 = All(True)

    result = 1
    assert all_1.value == result
    result = [1, 2, 3]
    assert all_2.value == result
    result = True
    assert all_3.value == result


# Generated at 2022-06-26 00:09:20.913860
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    Test if Semigroup constructor's variable value is equal to its value
    """
    #str_0 = 'D0Qkwnt<'
    #all_0 = All(str_0)
    #assert all_0.value == str_0
    test_case_0()


# Generated at 2022-06-26 00:09:23.036545
# Unit test for method concat of class First
def test_First_concat():
    first_0 = First(True)
    first_1 = first_0.concat(First(False))
    assert first_1.value


# Generated at 2022-06-26 00:09:30.406085
# Unit test for constructor of class Min
def test_Min():
    min_0 = Min(10.0)
    min_1 = Min(20.0)
    min_2 = Min(min_0.value)
    if min_0.value != min_2.value:
        raise RuntimeError('min_0 is not equals to min_2')

    if min_0.concat(
            min_1).value != min_0.value:
        raise RuntimeError('min_0 is not equals to min_2')
    if min_0.concat(min_1).value != min_0.value:
        raise RuntimeError('min_0 is not equals to min_2')


# Generated at 2022-06-26 00:09:32.685391
# Unit test for method concat of class Sum
def test_Sum_concat():
    def test_case_0():
        sum_0 = Sum(1)
        sum_0.concat(Sum(1))


# Generated at 2022-06-26 00:09:34.862128
# Unit test for method concat of class One
def test_One_concat():
    str_0 = 'YpN8WSe_'
    one_0 = One(str_0)
    one_0.concat(one_0)


# Generated at 2022-06-26 00:09:37.032267
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    with raises(AssertionError):
        str_0 = 'e'
        Sum(str_0).__str__() == 'Sum[value=e]'


# Generated at 2022-06-26 00:09:38.832600
# Unit test for method concat of class Sum
def test_Sum_concat():
    x = Sum(2)
    assert x.concat(Sum(3)) == Sum(5)


# Generated at 2022-06-26 00:09:47.367889
# Unit test for method concat of class All
def test_All_concat():
    all_0 = All(False)
    all_1 = all_0.concat(all_0)
    assert all_1.value == False
    assert isinstance(all_1, All)
    str_0 = 'W=&'
    all_2 = All(str_0)
    all_3 = all_2.concat(all_2)
    assert all_3.value == str_0
    assert isinstance(all_3, All)
    num_0 = 0
    all_4 = All(num_0)
    all_5 = all_4.concat(all_4)
    assert all_5.value == num_0
    assert isinstance(all_5, All)


# Generated at 2022-06-26 00:09:50.431410
# Unit test for method concat of class Sum
def test_Sum_concat():
    str_0 = 'Qa3q@mEI'
    sum_0 = Sum(str_0)
    assert sum_0.concat(Sum(1)).value == 'Qa3q@mEI1'


# Generated at 2022-06-26 00:09:52.275050
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(10)) == 'Min[value=10]', 'Assertion error at line 70'


# Generated at 2022-06-26 00:10:13.477346
# Unit test for constructor of class Min
def test_Min():
    try:
        temp = Min(-10)
    except Exception as e:
        print(e)
    else:
        print("Min object created successfully")


# Generated at 2022-06-26 00:10:19.487359
# Unit test for method __str__ of class First
def test_First___str__():
    first_0 = First('d|V#>~D2QbYr]r0}0')
    str_5 = 'Fist[value=d|V#>~D2QbYr]r0}0]'
    # Expected: str_5 == 'Fist[value=d|V#>~D2QbYr]r0}0]'
    print(str_5 == 'Fist[value=d|V#>~D2QbYr]r0}0]')


# Generated at 2022-06-26 00:10:22.409150
# Unit test for method __str__ of class Last
def test_Last___str__():
    str_0 = 'D0Qkwnt<'
    last_0 = Last(str_0)
    last_0_str = str(last_0)
    assert last_0_str == 'Last[value=D0Qkwnt<]'


# Generated at 2022-06-26 00:10:23.441292
# Unit test for constructor of class Max
def test_Max():
    max_0 = Max(15)
    max_1 = Max(15.1)

    assert max_0 == max_1


# Generated at 2022-06-26 00:10:27.061227
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    str_0 = '6Uxv6p~D'
    all_0 = All(str_0)
    arr = [1, 2, 3]
    sum_0 = all_0.fold(lambda x: sum(arr))



# Generated at 2022-06-26 00:10:28.323539
# Unit test for constructor of class One
def test_One():
    obj = One(1)
    assert obj.value == 1


# Generated at 2022-06-26 00:10:30.149657
# Unit test for constructor of class Map
def test_Map():
    value = 1
    map_0 = Map(value)
    assert map_0.value == value



# Generated at 2022-06-26 00:10:32.434382
# Unit test for method concat of class First
def test_First_concat():
    first_0 = First('f5Bs5')
    first_1 = First('RYf3q')
    first_0.concat(first_1)



# Generated at 2022-06-26 00:10:36.409887
# Unit test for method concat of class One
def test_One_concat():
    one_1 = One(False)
    one_2 = One('EkjP=jx>')
    one_3 = one_1.concat(one_2)
    assert one_3.value == 'EkjP=jx>'


# Generated at 2022-06-26 00:10:39.708891
# Unit test for method concat of class Map
def test_Map_concat():
    obj = Map({'b': All(1)})
    param = Map({'b': All(1)})
    res = Map.concat(obj, param)
    result = res.value == {'b': All(1)}
    assert result == True


# Generated at 2022-06-26 00:11:18.710242
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-26 00:11:20.931122
# Unit test for method __str__ of class Map
def test_Map___str__():
    str_0 = 'D0Qkwnt<'
    map_0 = Map({str_0: str_0})
    str_1 = str(map_0)


# Generated at 2022-06-26 00:11:23.058537
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'



# Generated at 2022-06-26 00:11:25.756123
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    str_0 = 'D0Qkwnt<'
    all_0 = All(str_0)
    all_1 = all_0.fold(lambda e: e.upper())
    assert str_0 == 'D0Qkwnt<'
    assert all_1 == 'D0QKWNT<'


# Generated at 2022-06-26 00:11:29.456596
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(1) == All(True)
    assert All(2) == All(False)
    assert One(1) == One(True)
    assert One(2) == One(False)


# Generated at 2022-06-26 00:11:31.269596
# Unit test for method __str__ of class All
def test_All___str__():
    assert 'All[value=D0Qkwnt<]' == str(All('D0Qkwnt<'))


# Generated at 2022-06-26 00:11:33.010618
# Unit test for constructor of class Min
def test_Min():
    Min_0 = Min(False)
    assert str(Min_0) == 'Min[value=False]'


# Generated at 2022-06-26 00:11:38.397998
# Unit test for constructor of class One
def test_One():
    """
    Unit test for constructor of class One
    """
    number_0 = 0
    number_1 = 1
    one_0 = One(number_0)
    one_1 = One(number_1)
    assert one_0.value == number_0
    assert one_1.value == number_1


# Generated at 2022-06-26 00:11:42.828038
# Unit test for constructor of class Sum
def test_Sum():
    value = Sum(1)
    assert value.value == 1


# Generated at 2022-06-26 00:11:46.704641
# Unit test for method __str__ of class Last
def test_Last___str__():
    str_0 = 'D0Qkwnt<'
    last_0 = Last(str_0)
    str_1 = last_0.__str__()
    assert str_1 == 'Last[value=D0Qkwnt<]'


# Generated at 2022-06-26 00:13:05.053053
# Unit test for method __str__ of class All
def test_All___str__():
    str_0 = 'a'
    all_0 = All(str_0)
    str_1 = all_0.__str__()
    assert 'All[value=a]' == str_1


# Generated at 2022-06-26 00:13:11.358827
# Unit test for method __str__ of class Map
def test_Map___str__():
    dict_0 = {}
    dict_0['f'] = First('e')
    dict_0['t'] = All(True)
    dict_0['n'] = One(None)
    dict_0['fl'] = Last(1.2)
    dict_0['a'] = Sum(9)
    dict_0['m'] = Map(dict_0)
    map_0 = Map(dict_0)

    assert str(map_0) == str(dict_0)


# Generated at 2022-06-26 00:13:16.646090
# Unit test for method concat of class First
def test_First_concat():
    str_0 = 'D0Qkwnt<'
    first_0 = First(str_0)
    str_1 = 'e7'
    first_1 = First(str_1)
    first_2 = first_0.concat(first_1)
    str_2 = 'D0Qkwnt<'
    assert first_2.value == str_2



# Generated at 2022-06-26 00:13:23.731816
# Unit test for method concat of class Sum
def test_Sum_concat():
    int_0 = Sum(0)
    int_1 = Sum(1)
    int_2 = Sum(2)
    assert int_1.concat(int_2).fold(lambda x: x) == 3
    assert int_2.concat(int_1).fold(lambda x: x) == 3
    assert int_0.concat(int_0).fold(lambda x: x) == 0
    int_3 = Sum(3)
    int_4 = Sum(4)
    assert int_3.concat(int_4).fold(lambda x: x) == 7
    assert int_4.concat(int_3).fold(lambda x: x) == 7
    assert int_0.concat(int_0).fold(lambda x: x) == 0


# Generated at 2022-06-26 00:13:26.464244
# Unit test for constructor of class Max
def test_Max():
    max_0 = Max(1)
    assert max_0 is not None
    assert type(max_0) is Max
    assert max_0.value == 1


# Generated at 2022-06-26 00:13:27.489196
# Unit test for constructor of class First
def test_First():
    first_0 = First('&i=ht#d>6')


# Generated at 2022-06-26 00:13:30.221374
# Unit test for method __str__ of class All
def test_All___str__():
    all_0 = All('D0Qkwnt<')
    all_1 = All('D0Qkwnt<')
    all_1._value = all_0
    all_1._value = all_0.concat(all_0)


# Generated at 2022-06-26 00:13:31.528013
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert Max(5).__str__() == 'Max[value=5]'


# Generated at 2022-06-26 00:13:35.315462
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """Test function for the equivalent test of class Semigroup
    :return: boolean
    """
    str_0 = 'h0'
    str_1 = 'h1'
    all_0 = All(str_0)
    all_1 = All(str_1)
    assert not(all_0 == all_1)
    assert all_0 == all_0


# Generated at 2022-06-26 00:13:37.986283
# Unit test for method concat of class One
def test_One_concat():
    first_0 = First('d9jHW^[7')
    one_0 = One(first_0)
    one_1 = None
    one_2 = one_0.concat(one_1)
