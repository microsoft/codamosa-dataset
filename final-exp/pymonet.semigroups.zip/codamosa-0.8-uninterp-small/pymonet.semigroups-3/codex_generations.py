

# Generated at 2022-06-26 00:05:55.122708
# Unit test for method concat of class Max
def test_Max_concat():
    tuple_0 = None
    max_0 = Max(tuple_0)
    tuple_1 = None
    max_1 = Max(tuple_1)

    # Call method concat on object max_0 and pass max_1 as argument.
    # Assert the result is equal to max_1.
    assert max_0.concat(max_1) == max_1



# Generated at 2022-06-26 00:05:56.715020
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(4).concat(Min(1)) == Min(1)


# Generated at 2022-06-26 00:06:02.659888
# Unit test for method concat of class Max
def test_Max_concat():
    # Valid concat
    semigroup_0 = Max(0.0)
    semigroup_1 = Max(1.0)
    result = semigroup_0.concat(semigroup_1)
    assert result.value == 1.0

    # Invalid concat
    try:
        semigroup_0 = Max(0.0)
        semigroup_1 = Max(1.0)
        result = semigroup_0.concat(semigroup_1)
        assert result.value == 0.0
        assert False
    except:
        assert True


# Generated at 2022-06-26 00:06:12.891064
# Unit test for method concat of class Min
def test_Min_concat():
    input_A = Min(0)
    input_B = Min(1)
    func_input_A = Min(input_A)
    func_input_B = Min(input_B)

    # Check static type of func_input_A
    assert isinstance(func_input_A, Min)

    # Check static type of func_input_B
    assert isinstance(func_input_B, Min)

    # Call method concat of class Min with parameters func_input_A and func_input_B
    func_return = func_input_A.concat(func_input_B)

    # Check static type of func_return
    assert isinstance(func_return, Min)

    # Check value of func_return
    assert func_return.value == input_B.value


# Generated at 2022-06-26 00:06:17.495174
# Unit test for method concat of class Min
def test_Min_concat():
    instance_0 = Min(23)
    instance_1 = Min(46)
    instance_2 = instance_0.concat(instance_1)
    print(instance_2)
    print(type(instance_2))
    assert type(instance_2) == Min
    assert instance_2 == Min(23)


# Generated at 2022-06-26 00:06:26.980037
# Unit test for method concat of class Map
def test_Map_concat():
    map_0 = Map({})
    map_0_value = {}
    map_1 = Map({})
    map_1_value = {}
    map_2 = map_0.concat(map_1)
    map_2_value = {}
    assert map_2.value == map_2_value
    assert map_2.value == map_2_value
    map_0 = Map({'a': All(True)})
    map_0_value = {'a': All(True)}
    map_1 = Map({'b': All(False)})
    map_1_value = {'b': All(False)}
    map_2 = map_0.concat(map_1)
    map_2_value = {'a': All(True), 'b': All(False)}
    assert map_2

# Generated at 2022-06-26 00:06:30.901917
# Unit test for method concat of class Min
def test_Min_concat():
    tuple_0 = 5
    tuple_1 = 5
    min_0 = Min(tuple_1)
    expected_0 = tuple_0
    actual_0 = min_0.concat(min_0)
    assert expected_0 == actual_0, (expected_0, actual_0)



# Generated at 2022-06-26 00:06:40.303836
# Unit test for method concat of class Map
def test_Map_concat():
    map_0 = Map({
        'a': First(102),
        'b': Last(0),
        'c': Sum(100),
        'd': All(0),
        'e': One(1),
        'f': Max(3),
        'g': Min(1),
    })
    map_1 = Map({
        'a': Last(402),
        'b': First(4),
        'c': Sum(400),
        'd': All(4),
        'e': One(5),
        'f': Max(7),
        'g': Min(5),
    })
    map_2 = map_0.concat(map_1)
    assert isinstance(map_0.value['a'], First)
    assert isinstance(map_0.value['b'], Last)


# Generated at 2022-06-26 00:06:45.264677
# Unit test for method concat of class Max
def test_Max_concat():
    Max_0 = Max(2)
    Max_1 = Max(1)
    Max_2 = Max(1).concat(Max_1)
    assert Max_2 == Max(1)
    Max_3 = Max(2).concat(Max_1)
    assert Max_3 == Max(2)



# Generated at 2022-06-26 00:06:47.118758
# Unit test for method concat of class Map
def test_Map_concat():
    map_0 = Map({})
    map_1 = Map({})
    last_0 = Last(map_0)
    last_1 = Last(map_1)
    last_0.concat(last_1)



# Generated at 2022-06-26 00:06:53.014404
# Unit test for method concat of class One
def test_One_concat():
    value_0 = None
    semigroup_0 = One(value_0)
    value_1 = None
    semigroup_1 = One(value_1)
    semigroup_0.concat(semigroup_1)



# Generated at 2022-06-26 00:06:57.158913
# Unit test for constructor of class Last
def test_Last():
    # Assert if Last() raises a TypeError.
    try:
        Last()
        assert False
    except Exception as e:
        assert type(e) == TypeError

    # Assert if Last(1) is a instance of class Last.
    assert isinstance(Last(1), Last)



# Generated at 2022-06-26 00:06:59.435116
# Unit test for method concat of class Sum
def test_Sum_concat():
    result = Sum(1)
    expected_result = Sum(2)
    assert result.concat(Sum(1)) == expected_result


# Generated at 2022-06-26 00:07:03.499275
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    tuple_0 = None
    first_value_0 = First(tuple_0)
    tuple_1 = ()
    first_value_1 = First(tuple_1)
    test_0 = (first_value_0 == first_value_1)
    assert True == test_0


# Generated at 2022-06-26 00:07:11.637979
# Unit test for constructor of class First
def test_First():
    tuple_0 = None
    first_0 = First(tuple_0)
    assert first_0.value == tuple_0
    tuple_0 = First(None)
    first_1 = First(tuple_0)
    assert first_1.value is tuple_0
    tuple_0 = ()
    first_2 = First(tuple_0)
    assert first_2.value == tuple_0
    tuple_0 = (1, 2)
    first_3 = First(tuple_0)
    assert first_3.value == tuple_0
    tuple_0 = 42
    first_4 = First(tuple_0)
    assert first_4.value == tuple_0
    tuple_0 = "Life, uh, finds a way"
    first_5 = First(tuple_0)
    assert first_

# Generated at 2022-06-26 00:07:15.412634
# Unit test for constructor of class One
def test_One():
    assert(One(1).value == 1)
    assert(One(0).value == 0)
    assert(One(False).value == False)
    assert(One(True).value == True)
    assert(One(-5).value == -5)
    assert(One(None).value == None)



# Generated at 2022-06-26 00:07:25.819009
# Unit test for method concat of class All
def test_All_concat():
    # Test case for input instances of tuple
    tuple_0 = (None, )
    first_0 = All(tuple_0)
    tuple_1 = (first_0, )
    last_0 = All(tuple_1)
    assert last_0.concat(first_0) == All(tuple_1)
    # Test case for input instances of tuple
    tuple_2 = (None, )
    first_1 = All(tuple_2)
    tuple_3 = (first_1, )
    last_1 = All(tuple_3)
    assert last_1.concat(first_1) == All(tuple_3)
    # Test case for input instances of tuple
    tuple_4 = (None, )
    first_2 = All(tuple_4)

# Generated at 2022-06-26 00:07:34.309170
# Unit test for constructor of class One
def test_One():
    # Try to create an instance of class One
    # and check that the value of this instance is correct
    # using the get method
    try:
        new_One_instance = One(False)
        if new_One_instance.value == False:
            print('Passed test 1')
    except Exception:
        print('Failed test 1')

    # Try to create an instance of class One
    # and check that the value of this instance is correct
    # using the get method
    try:
        new_One_instance = One(True)
        if new_One_instance.value == True:
            print('Passed test 2')
    except Exception:
        print('Failed test 2')


# Generated at 2022-06-26 00:07:41.026710
# Unit test for method concat of class Max
def test_Max_concat():
    print("max_0 concat max_1")
    max_0 = Max(4)
    max_1 = Max(10)
    max_2 = max_0.concat(max_1)
    print(max_2.value)
    assert max_2.value == 10

    print("max_0 concat max_1")
    max_0 = Max(10)
    max_1 = Max(4)
    max_2 = max_0.concat(max_1)
    print(max_2.value)
    assert max_2.value == 10
    
    print("max_0 concat max_1")
    max_0 = Max(-10)
    max_1 = Max(-20)
    max_2 = max_0.concat(max_1)

# Generated at 2022-06-26 00:07:46.815128
# Unit test for method concat of class First
def test_First_concat():
    first_0 = First(tuple())
    first_1 = First(None)
    tuple_0 = (1, first_1)
    first_2 = First(tuple_0)
    first_3 = first_0.concat(first_2)
    assert first_3.value == tuple()
    first_4 = First('q')
    result_0 = first_4.concat(first_0)
    assert result_0.value == "q"



# Generated at 2022-06-26 00:07:54.557913
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(3).concat(Last(5)).value == 5
    last_0 = Last()
    last_1 = Last(3)
    assert last_1.concat(last_0).value == 3
    last_2 = Last(5)
    assert last_1.concat(last_2).value == 5



# Generated at 2022-06-26 00:07:57.700197
# Unit test for constructor of class First
def test_First():
    first_1 = First(1)
    first_0 = First(0)

    # Check non-neutral element
    assert first_1.value == 1
    assert first_0.value == 0

    # Check default neutral element
    first_neutral = First.neutral()
    assert first_neutral.value == True


# Generated at 2022-06-26 00:08:01.925028
# Unit test for constructor of class Map
def test_Map():
    ex1 = Map({})
    assert ex1 == {}, "Map() does not return {}"
    ex2 = Map({1: 1, 2: 3})
    assert ex2 == {1: 1, 2: 3}, "Map() does not return {1: 1, 2: 3}"


# Generated at 2022-06-26 00:08:03.113750
# Unit test for constructor of class Max
def test_Max():
    assert Max(5) == Max(5)

# Generated at 2022-06-26 00:08:08.436922
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    :return: True if test passed
    :rtype: bool
    """
    sum_0 = Sum(3)
    sum_1 = Sum(5)
    sum_0_concat_sum_1 = sum_0.concat(sum_1)
    if sum_0_concat_sum_1.value != 8:
        return False
    return True



# Generated at 2022-06-26 00:08:13.981987
# Unit test for constructor of class Last
def test_Last():
    last_0 = Last(8)
    last_1 = Last(10)
    last_2 = last_0.concat(last_1)
    last_3 = last_2.concat(last_0)
    assert last_2.value == 10
    assert last_3.value == 8


# Generated at 2022-06-26 00:08:16.849946
# Unit test for method concat of class First
def test_First_concat():
    first_0 = First(0)
    first_1 = First(1)

    # With 2 First, 1 is returned
    assert first_0.concat(first_1) == first_1



# Generated at 2022-06-26 00:08:18.367130
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(1)) == 'All[value=1]'


# Generated at 2022-06-26 00:08:26.985068
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    sum_0 = Sum(0)
    sum_1 = Sum(1)
    sum_2 = Sum(2)

    one_0 = One(False)
    one_1 = One(True)

    all_0 = All(False)
    all_1 = All(True)

    first_0 = First(0)
    first_1 = First(1)

    last_0 = Last(0)
    last_1 = Last(1)

    map_0 = Map({'age': Sum(0), 'name': Last('john')})
    map_1 = Map({'age': Sum(1), 'name': Last('ivanov')})

    max_0 = Max(0)
    max_1 = Max(1)

    min_0 = Min(0)
    min_1 = Min(1)


# Generated at 2022-06-26 00:08:30.491230
# Unit test for method concat of class All
def test_All_concat():
    assert (All(True).concat(All(False)).value == False)
    assert (All(False).concat(All(False)).value == False)
    assert (All(False).concat(All(True)).value == False)
    assert (All(True).concat(All(True)).value == True)


# Generated at 2022-06-26 00:08:37.935456
# Unit test for constructor of class Map
def test_Map():
    semigroup = dict(zip('abc', range(3)))
    m = Map(semigroup)
    assert isinstance(m, Map)
    assert m.value == semigroup
    assert m == Map(semigroup)



# Generated at 2022-06-26 00:08:39.843569
# Unit test for method __str__ of class All
def test_All___str__():
    all_0 = All(True)
    assert all_0.__str__() == 'All[value=True]'



# Generated at 2022-06-26 00:08:43.736973
# Unit test for constructor of class Semigroup
def test_Semigroup():

    try:
        semigroup = Semigroup(1)
    except:
        semigroup = Semigroup(1)

    # AssertionError: Can't instantiate abstract class Semigroup with abstract methods concat
    assert semigroup.value == 1, "test_case_0 failed"


# Generated at 2022-06-26 00:08:45.296585
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert Sum(1).__str__() == 'Sum[value=1]'


# Generated at 2022-06-26 00:08:48.223893
# Unit test for method concat of class Last
def test_Last_concat():

    last_a = Last(9)
    last_b = Last(2)
    assert last_a.concat(last_b) == Last(2)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 00:08:52.399887
# Unit test for method concat of class All
def test_All_concat():
    x1 = All(True)
    x2 = All(False)
    x3 = All(True)
    x4 = All(False)
    assert x1.concat(x2) == All(False)
    assert x1.concat(x3) == All(True)
    assert x2.concat(x4) == All(False)
    assert x1.concat(x4) == All(False)



# Generated at 2022-06-26 00:08:58.162793
# Unit test for constructor of class Last
def test_Last():
    # This test will be done with no input
    with pytest.raises(TypeError):
        test_case_0()

    last_1 = Last(1)
    # Type assertation
    assert isinstance(last_1, Last)
    # Value of constructor test
    assert last_1.value == 1



# Generated at 2022-06-26 00:09:03.536477
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum_0 = Sum(1)
    sum_1 = Sum(2)
    sum_2 = Sum(3)
    sum_3 = Sum(4)
    sum_4 = Sum(5)
    sum_5 = Sum(6)
    sum_6 = Sum(7)
    sum_7 = Sum(8)
    sum_8 = Sum(9)
    sum_9 = Sum(10)


# Generated at 2022-06-26 00:09:05.054656
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1).value == 1



# Generated at 2022-06-26 00:09:13.643412
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    last_0 = Last()
    _result_0 = last_0.fold(lambda x: x)
    assert _result_0 is None
    last_1 = Last()
    _result_1 = last_1.fold(lambda x: x)
    assert _result_1 is None
    last_2 = Last()
    _result_2 = last_2.fold(lambda x: x)
    assert _result_2 is None
    last_3 = Last()
    _result_3 = last_3.fold(lambda x: x)
    assert _result_3 is None
    last_4 = Last()
    _result_4 = last_4.fold(lambda x: x)
    assert _result_4 is None
    last_5 = Last()

# Generated at 2022-06-26 00:09:21.757095
# Unit test for constructor of class Min
def test_Min():
    assert Min(1)
    assert Min(1.1)
    assert Min(False)
    assert Min('1')


# Generated at 2022-06-26 00:09:25.310244
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    # check positive case
    sum_0 = Sum(1)
    sum_1 = Sum(1)
    assert sum_0 == sum_1

    # check negative case
    sum_0 = Sum(1)
    sum_1 = Sum(2)
    assert sum_0 != sum_1



# Generated at 2022-06-26 00:09:29.041803
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(1)).value == 1
    assert Min(2).concat(Min(1)).value == 1
    assert Min(1).concat(Min(2)).value == 1
    assert Min(2).concat(Min(2)).value == 2


# Generated at 2022-06-26 00:09:31.088964
# Unit test for method __str__ of class Min
def test_Min___str__():
    obj = Min(1)
    str_obj = str(obj)
    assert str_obj == 'Min[value=1]'


# Generated at 2022-06-26 00:09:34.659981
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min(9)
    min_1 = Min(4)
    min_2 = Min(7)
    min_3 = min_1.concat(min_2)
    assert min_0.value == min_3.value


# Generated at 2022-06-26 00:09:38.055171
# Unit test for method __str__ of class Last
def test_Last___str__():
    last_0 = Last("value")
    try:
        assert str(last_0) == "Last[value=value]"
    except AssertionError:
        raise AssertionError("str(last_0) == 'Last[value=value]'")


# Generated at 2022-06-26 00:09:47.253173
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(1).concat(Max(0)) == Max(1)
    assert Max(1).concat(Sum(0)) == Max(1)
    assert Max(2).concat(Last(0)) == Max(2)
    assert Max(1).concat(Last(0)) == Max(1)
    assert Max(2).concat(First(0)) == Max(2)
    assert Max(1).concat(First(0)) == Max(1)
    assert Max(1).concat(All(True)) == Max(1)
    assert Max(2).concat(All(True)) == Max(2)
    assert Max(2).concat(One(False)) == Max(2)

# Generated at 2022-06-26 00:09:56.785274
# Unit test for method concat of class Map
def test_Map_concat():
    map_0 = Map({'a': Sum(1), 'b': Sum(2)})
    map_1 = Map({'a': Sum(3), 'b': Sum(4)})
    map_2 = Map({'a': Sum(1), 'b': Sum(2)})
    map_3 = Map({'a': Sum(0), 'b': Sum(1)})
    map_0 = map_0.concat(map_1)
    map_2 = map_2.concat(map_3)
    assert (map_0.value['a'].value == 4)
    assert (map_0.value['b'].value == 6)
    assert (map_2.value['a'].value == 1)
    assert (map_2.value['b'].value == 3)



# Generated at 2022-06-26 00:10:02.631745
# Unit test for method concat of class All
def test_All_concat():
    all_truth = All(True)
    assert all_truth.concat(All(True)) == All(True)
    assert all_truth.concat(All(False)) == All(False)
    assert all_truth.concat(All(None)) == All(False)
    assert all_truth.concat(All(0)) == All(False)

    assert All(False).concat(All(None)) == All(False)

    assert All(True).concat(All(1)) == All(True)

    all_false = All(False)
    assert all_false.concat(All(None)) == All(False)

    assert All(False).concat(All('')) == All(False)


# Generated at 2022-06-26 00:10:12.885458
# Unit test for constructor of class All
def test_All():
    a = All(False)
    assert type(a) is All
    assert a.neutral_element is True
    assert not a.value

    a = All(True)
    assert type(a) is All
    assert a.neutral_element is True
    assert a.value

    a = All(0)
    assert type(a) is All
    assert a.neutral_element is True
    assert not a.value

    a = All(1)
    assert type(a) is All
    assert a.neutral_element is True
    assert a.value

    a = All('F')
    assert type(a) is All
    assert a.neutral_element is True
    assert not a.value

    a = All('T')
    assert type(a) is All
    assert a.neutral_element is True

# Generated at 2022-06-26 00:10:28.819749
# Unit test for constructor of class Last
def test_Last():
    try:
        last_0 = Last()
    except AssertionError as inst:
        assert(inst.args[0] == 'Semigroup requires a value')
    else:
        assert(False)


# Generated at 2022-06-26 00:10:32.755729
# Unit test for method concat of class Min
def test_Min_concat():
    min_a = Min(15)
    min_b = Min(20)
    min_c = Min(10)
    sum_a = min_a.concat(min_b)
    sum_b = min_a.concat(min_c)
    assert sum_a.value == 15
    assert sum_b.value == 10

# Generated at 2022-06-26 00:10:41.834492
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(0) == Sum(0)
    assert Sum(1) == Sum(1)
    assert Sum(2) != Sum(1)
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)
    assert One(False) == One(False)
    assert One(True) == One(True)
    assert One(False) != One(True)
    assert First(1) == First(1)
    assert First(2) == First(2)
    assert First(1) != First(2)
    assert Last(1) == Last(1)
    assert Last(2) == Last(2)
    assert Last(1) != Last(2)
    assert Max(1) == Max(1)

# Generated at 2022-06-26 00:10:44.147663
# Unit test for method concat of class First
def test_First_concat():
    a = First("I")
    b = First("II")
    c = a.concat(b)
    assert c.value == "I"


# Generated at 2022-06-26 00:10:46.816444
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert Min(1).__str__() == 'Min[value=1]'


# Generated at 2022-06-26 00:10:55.414410
# Unit test for method concat of class First
def test_First_concat():
    a = First({'one': 1})
    b = First({'two': 2})
    c = First({'three': 3})
    d = First({'four': 4})
    e = First({'five': 5})
    x = a.concat(b)
    assert isinstance(x, First)
    assert x.value == b.value
    x = x.concat(c)
    assert x.value == c.value
    x = x.concat(d)
    assert x.value == d.value
    x = x.concat(e)
    assert x.value == e.value


# Generated at 2022-06-26 00:10:59.148900
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    first_0 = First(2)
    first_1 = First(7)
    assert first_0 != first_1
    first_1 = First(2)
    assert first_0 == first_1


# Generated at 2022-06-26 00:11:00.801476
# Unit test for constructor of class One
def test_One():
    value_0 = One(True)
    value_1 = One(False)



# Generated at 2022-06-26 00:11:07.532020
# Unit test for method concat of class Last
def test_Last_concat():

    # Case 0 - No any param
    last_0 = Last()
    last_1 = Last(1)
    r = last_0.concat(last_1)
    assert r.value == 1

    # Case 1 - One param
    last_0 = Last()
    last_1 = Last(1)
    r = last_0.concat(last_1)
    assert r.value == 1

    # Case 2 - Two params
    last_0 = Last(1)
    last_1 = Last(2)
    r = last_0.concat(last_1)
    assert r.value == 2


if __name__ == '__main__':  # pragma: no cover
    test_case_0()
    test_Last_concat()

# Generated at 2022-06-26 00:11:15.674240
# Unit test for constructor of class Map
def test_Map():
    number_map_0 = Map({1: Last(1), 2: Last(2), 3: Last(3)})
    number_map_1 = Map({1: Last(8), 2: Last(2), 3: Last(3)})
    number_map_2 = Map({1: Last(8), 2: Last(15), 3: Last(3)})
    number_map_3 = Map({1: Last(8), 2: Last(15), 3: Last(23)})

    number_map_0.concat(number_map_1).concat(number_map_2).concat(number_map_3)




# Generated at 2022-06-26 00:11:45.938195
# Unit test for method concat of class Min
def test_Min_concat():
    min_0 = Min(5)
    min_1 = Min(2)
    min_2 = min_0.concat(min_1)
    assert min_2.value == 2
    print('case 0 of test for concat of Min')


# Generated at 2022-06-26 00:11:48.682962
# Unit test for method __str__ of class Last
def test_Last___str__():
    last_0 = Last()

    try:
        assert str(last_0) == 'Last[value=None]'
    except AssertionError:
        print('test_Last___str__()") -> AssertionError')
        raise


# Generated at 2022-06-26 00:11:52.817566
# Unit test for constructor of class Min
def test_Min():
    min_0 = Min(1)
    min_1 = Min(2)
    min_2 = Min(3)
    assert min_0.value == 1
    assert min_1.value == 2
    assert min_2.value == 3


# Generated at 2022-06-26 00:12:04.796616
# Unit test for constructor of class All
def test_All():
    # Test All with a falsy value
    assert All(False) == All(False), "All(False) == All(False)"

    # Test All with a truly value
    assert All(True) == All(True), "All(True) == All(True)"

    # Test All with a empty value
    assert All("") == All(""), "All('') == All('')"

    # Test All with a integer value
    assert All(2) == All(2), "All(2) == All(2)"

    # Test All with a string value
    assert All("Foo") == All("Foo"), "All('Foo') == All('Foo')"

    # Test All with a list value

# Generated at 2022-06-26 00:12:13.020308
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(5).fold(lambda acc: acc) == 5
    assert All(True).fold(lambda acc: acc) == True
    assert One(True).fold(lambda acc: acc) == True
    assert First(True).fold(lambda acc: acc) == True
    assert Last(True).fold(lambda acc: acc) == True
    assert Map({'a': Sum(5)}).fold(lambda acc: acc) == {'a': Sum(5)}
    assert Max(5).fold(lambda acc: acc) == 5
    assert Min(5).fold(lambda acc: acc) == 5


# Generated at 2022-06-26 00:12:18.709606
# Unit test for method concat of class Min
def test_Min_concat():
    min_1 = Min(1)
    min_2 = Min(2)
    min_3 = min_1.concat(min_2)
    assert min_3.value == 1
    min_4 = Min(4)
    min_5 = Min(5)
    min_6 = min_4.concat(min_5)
    assert min_6.value == 4

if __name__ == '__main__':
    test_Min_concat()

# Generated at 2022-06-26 00:12:27.892995
# Unit test for constructor of class Semigroup
def test_Semigroup():

    sum_0 = Sum(2)
    assert type(sum_0) == Sum
    assert sum_0.value == 2
    assert str(sum_0) == 'Sum[value=2]'

    all_true = All(True)
    assert type(all_true) == All
    assert all_true.value == True
    assert str(all_true) == 'All[value=True]'

    all_false = All(False)
    assert type(all_false) == All
    assert all_false.value == False
    assert str(all_false) == 'All[value=False]'

    one_true = One(True)
    assert type(one_true) == One
    assert one_true.value == True
    assert str(one_true) == 'One[value=True]'


# Generated at 2022-06-26 00:12:30.810516
# Unit test for method __str__ of class Map
def test_Map___str__():
    # Test: Map
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == 'Map[value={\'a\': Sum[value=1], \'b\': Sum[value=2]}]'



# Generated at 2022-06-26 00:12:31.903979
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First()) == 'Fist[value=None]'


# Generated at 2022-06-26 00:12:34.747928
# Unit test for method concat of class Last
def test_Last_concat():
    last_0 = Last('test')
    last_1 = Last('test')
    assert last_0.concat(last_1) == 'test'


# Generated at 2022-06-26 00:13:32.973269
# Unit test for method concat of class Min
def test_Min_concat():
    min = Min(1)
    min = min.concat(Min(2))
    print(min)



# Generated at 2022-06-26 00:13:41.233769
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    sum_0 = Sum(value=10)
    sum_1 = sum_0.fold(lambda x: Sum(value=x + 10))
    assert sum_1.value == 20

    last_0 = Last(value=10)
    last_1 = last_0.fold(lambda x: Last(value=x + 10))
    assert last_1.value == 10

    all_0 = All(value=True)
    all_1 = all_0.fold(lambda x: All(value=not x))
    assert all_1.value == False

    one_0 = One(value=False)
    one_1 = one_0.fold(lambda x: One(value=not x))
    assert one_1.value == True

    first_0 = First(value=True)

# Generated at 2022-06-26 00:13:45.255843
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    semigroup_0 = Sum(0)
    semigroup_1 = Sum(0)
    semigroup_2 = Sum(0)
    semigroup_3 = Sum(0)
    semigroup_4 = Sum(0)
    assert semigroup_0 == semigroup_1
    assert semigroup_2 == semigroup_3
    assert semigroup_3 == semigroup_4
    assert not (semigroup_0 != semigroup_1)
    assert not (semigroup_2 != semigroup_3)
    assert not (semigroup_3 != semigroup_4)

# Generated at 2022-06-26 00:13:55.454350
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value is True
    assert All(True).concat(All(False)).value is False
    assert All(False).concat(All(True)).value is False
    assert All(False).concat(All(False)).value is False
    
    assert All(True).concat(False) == All(False)
    assert All(False).concat(True) == All(False)
    assert All(True).concat(0) == All(False)
    assert All(False).concat(1) == All(False)
    assert All(True).concat(1) == All(True)
    assert All(False).concat(0) == All(False)
    assert All(True).concat(0.0) == All(False)
    assert All(False).concat

# Generated at 2022-06-26 00:13:58.025663
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(0)) == 'Max[value=0]', """
    Max.__str__ method return wrong name for class
    """


# Generated at 2022-06-26 00:14:00.363468
# Unit test for constructor of class Sum
def test_Sum():
    sum_0 = Sum(1)
    assert sum_0.value == 1


# Generated at 2022-06-26 00:14:02.390742
# Unit test for constructor of class One
def test_One():
    one_0 = One(True)
    one_1 = One(False)
    assert one_0 != one_1


# Generated at 2022-06-26 00:14:10.558669
# Unit test for method concat of class First
def test_First_concat():
    first_0 = First(5)
    first_1 = First(4)
    first_2 = first_0.concat(first_1)
    assert first_0.value == first_2.value
    first_0 = First(None)
    first_1 = First(4)
    first_2 = first_0.concat(first_1)
    assert first_0.value == first_2.value
    first_0 = First(None)
    first_1 = First(None)
    first_2 = first_0.concat(first_1)
    assert first_0.value == first_2.value
    first_0 = First(3)
    first_1 = First(None)
    first_2 = first_0.concat(first_1)
    assert first_0.value == first

# Generated at 2022-06-26 00:14:13.022483
# Unit test for method __str__ of class First
def test_First___str__():
    assert (str(First(1)) == "Fist[value=1]")


# Generated at 2022-06-26 00:14:21.920194
# Unit test for constructor of class All
def test_All():
    assert All(False).value == False
    assert All(True).value == True
    assert All(None).value == None
    assert All(1).value == True
    assert All(0).value == False
    assert All('0').value == True
    assert All('').value == False
    assert All(1.1).value == True
    assert All(0.0).value == False
    assert All({'a': 1}).value == True
    assert All({}).value == False
    assert All(['a']).value == True
    assert All([]).value == False
    assert All(set()).value == False
    assert All((1,)).value == True
    assert All(()).value == False
