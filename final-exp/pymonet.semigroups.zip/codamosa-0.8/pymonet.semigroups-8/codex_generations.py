

# Generated at 2022-06-12 05:23:52.311546
# Unit test for method concat of class Min
def test_Min_concat():
    method = Min(2).concat
    assert method(Min(3)).value == 2
    assert method(Min(1)).value == 1


# Generated at 2022-06-12 05:23:58.673105
# Unit test for method concat of class Map
def test_Map_concat():
    # Arrange
    m0 = Map({'a': Sum(1), 'b': Sum(2)})
    m1 = Map({'a': Sum(2), 'b': Sum(1)})
    expected = Map({'a': Sum(3), 'b': Sum(3)})
    # Act
    actual = m0.concat(m1)
    # Assert
    assert expected == actual


# Generated at 2022-06-12 05:24:06.258500
# Unit test for method concat of class Map
def test_Map_concat():
    """
    Implement a method concat for merging two Semigroups of the same type into one.
    The Semigroup’s concat method accepts an argument of the same type and returns a result of the same type. Some example implementations are below.

    Note that in these implementations, the data type needs to be specified on the left-hand-side of the concat method, and the method itself should accept an argument of the same data type.
    """

    data = {
        'a': Sum(1),
        'b': Sum(2),
        'c': Sum(3),
    }

# Generated at 2022-06-12 05:24:10.085221
# Unit test for method concat of class Min
def test_Min_concat(): # pragma: no cover
    a = Min(50)
    b = Min(40)
    c = a.concat(b)
    print(c.value)
    assert c.value == 40
    assert isinstance(c, Min)


# Generated at 2022-06-12 05:24:14.253648
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({
        'one': First(1),
        'two': Last(21)
    }).concat(Map({
        'one': First(2),
        'two': Last(22)
    })) == Map({
        'one': First(1),
        'two': Last(22)
    })


# Generated at 2022-06-12 05:24:18.028634
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)


# Generated at 2022-06-12 05:24:22.578531
# Unit test for method concat of class Min
def test_Min_concat():
    min_1 = Min(2)
    min_2 = Min(0)
    min_3 = Min(3)
    # Test 1
    assert min_1.concat(min_2).value == min_2.value
    # Test 2
    assert min_1.concat(min_3).value == min_1.value


# Generated at 2022-06-12 05:24:25.049517
# Unit test for method concat of class Map
def test_Map_concat():  # pragma: no cover
    a = Map({'a': Sum(1)})
    b = Map({'b': Sum(2)})
    a.concat(b) == Map({'a': Sum(1), 'b': Sum(2)})

# Generated at 2022-06-12 05:24:30.968989
# Unit test for method concat of class Map
def test_Map_concat():
    obj1 = Map({1: All(True), 2: Sum(2)})
    obj2 = Map({1: All(False), 2: Sum(4)})
    expected = Map({1: All(False), 2: Sum(6)})
    value = obj1.concat(obj2)
    assert value == expected

# Generated at 2022-06-12 05:24:33.264510
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(6).concat(Min(7)) == Min(6)
    assert Min(6).concat(Min(3)) == Min(3)
    assert Min(3).concat(Min(3)) == Min(3)



# Generated at 2022-06-12 05:24:36.597790
# Unit test for method concat of class Min
def test_Min_concat(): 
    one = Min(1)
    two = Min(2)
    expect = 1
    actual = one.concat(two).value
    M.assert_equals(actual, expect)


# Generated at 2022-06-12 05:24:48.126751
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False
    assert All(1).value == True
    assert All(0).value == False
    assert All(None).value == False
    assert All('').value == False
    assert All([0, 1]).value == True
    assert All([0, 0]).value == False
    assert All(['']).value == False
    assert All([None]).value == False
    assert All({'a': 1, 'b': 0}).value == False
    assert All({}).value == True
    assert All(set([0, 1])).value == True
    assert All(set([0, 0])).value == False


# Generated at 2022-06-12 05:24:50.243381
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(1)) == Sum(2)


# Generated at 2022-06-12 05:24:52.248759
# Unit test for method concat of class Last
def test_Last_concat():
    last = Last(1)
    assert last.concat(Last(2)) == Last(2)


# Generated at 2022-06-12 05:24:54.614571
# Unit test for method __str__ of class First
def test_First___str__():
    first = First(1)
    assert str(first) == 'Fist[value=1]'


# Generated at 2022-06-12 05:24:55.661694
# Unit test for constructor of class First
def test_First():
    First(1)


# Generated at 2022-06-12 05:24:57.635831
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert str(Sum(2)) == 'Sum[value=2]'



# Generated at 2022-06-12 05:24:59.229493
# Unit test for constructor of class Max
def test_Max():
    assert Max() == Max(Max.neutral_element)


# Generated at 2022-06-12 05:25:01.342096
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(3)).fold(lambda x: x) == 2



# Generated at 2022-06-12 05:25:05.494647
# Unit test for method concat of class Min
def test_Min_concat():
    m1 = Min(3)
    m2 = Min(4)
    assert m1.concat(m2).value == 3
    m2 = Min(2)
    assert m1.concat(m2).value == 2

test_Min_concat()


# Generated at 2022-06-12 05:25:14.073167
# Unit test for method concat of class First
def test_First_concat():
    assert First(3).concat(First(2)) == First(3)
    assert First('python is a best programming language').concat(
        First('for data science')
    ) == First('python is a best programming language')
    assert First([1, 2, 3]).concat(First([4, 5, 6])) == First([1, 2, 3])
    assert First((1, 2, 3)).concat(First((4, 5, 6))) == First((1, 2, 3))
    assert First({'language': 'python',
                  'executable': '/usr/bin/python'}).concat(
        First({'language': 'c', 'executable': '/usr/bin/c'})
    ) == First({'language': 'python',
                'executable': '/usr/bin/python'})

# Unit test

# Generated at 2022-06-12 05:25:17.207483
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: First(1), 2: Max(2)})) == 'Map[value={1: First[value=1], 2: Max[value=2]}]'


# Generated at 2022-06-12 05:25:20.003044
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    a = Sum(0)
    b = Sum(0)
    assert a == b



# Generated at 2022-06-12 05:25:26.307684
# Unit test for method concat of class Min
def test_Min_concat():
    min_A = Min(1)
    min_B = Min(2)
    min_C = Min(-2)
    assert min_A.concat(min_B).value == 1
    assert min_A.concat(min_C).value == -2
    assert min_B.concat(min_C).value == -2
    assert min_B.concat(min_A).value == 1
    assert min_C.concat(min_B).value == -2
    assert min_C.concat(min_A).value == -2


# Generated at 2022-06-12 05:25:28.316457
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == 'Map[value={\'a\': Sum[value=1], \'b\': Sum[value=2]}]'


# Generated at 2022-06-12 05:25:29.930514
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    actual = Sum(5)
    expected = 'Sum[value=5]'
    assert str(actual) == expected



# Generated at 2022-06-12 05:25:32.559736
# Unit test for method concat of class Min
def test_Min_concat(): # pragma: no cover
    """
    Unit test for method concat of class Min
    """
    assert Min(1).concat(Min(2)) == Min(1)

# Generated at 2022-06-12 05:25:36.330546
# Unit test for constructor of class Map
def test_Map():
    map_items = {'a': Sum(2), 'b': Sum(3), 'c': Sum(5)}
    assert Map(map_items)
    assert type(Map(map_items).value) == dict
    assert map_items == Map(map_items).value

# Generated at 2022-06-12 05:25:40.160779
# Unit test for constructor of class Sum
def test_Sum():
    x  = Sum(1)
    y  = Sum(2)
    assert x.value == 1 and y.value == 2
    assert x == Sum(1) and y == Sum(2)

# Unit tests for concat method of Sum class

# Generated at 2022-06-12 05:25:41.963603
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'



# Generated at 2022-06-12 05:25:47.200664
# Unit test for constructor of class Min
def test_Min():
    min = Min(1)
    assert min.value == 1
    assert min.neutral_element == float('inf')


# Generated at 2022-06-12 05:25:49.804441
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == "Last[value=1]"
    assert str(Last(True)) == "Last[value=True]"


# Generated at 2022-06-12 05:25:50.822453
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1

# Generated at 2022-06-12 05:25:54.497953
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1) == Max(5).concat(Max(1)), 'Max(5).concat(Max(1)) should return Max(1)'
    #assert Max(1) == Max(0).concat(Max(1)), 'Max(0).concat(Max(1)) should return Max(1)'

# Generated at 2022-06-12 05:25:57.656415
# Unit test for constructor of class Min
def test_Min():
    assert Min(5) == Min(5)


if __name__ == '__main__':
    test_Min()

# Generated at 2022-06-12 05:26:00.119219
# Unit test for method concat of class All
def test_All_concat():
    a = All(True)
    b = All(False)
    assert a.concat(b) == All(False)


# Generated at 2022-06-12 05:26:04.072377
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value == True
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
    assert All(False).concat(All(False)).value == False


# Generated at 2022-06-12 05:26:06.007295
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    for value in [0, 1, 3.14, "foo"]:
        assert str(Sum(value)) == "Sum[value={}]".format(value)



# Generated at 2022-06-12 05:26:14.405243
# Unit test for method concat of class Min
def test_Min_concat():
    print("\nUnit test for method concat of class Min")
    min1 = Min(10)
    min2 = Min(20)
    min3 = min1.concat(min2)
    print(min3)
    min4 = Min(20)
    min5 = Min(10)
    min6 = min4.concat(min5)
    print(min6)
    min7 = Min(10)
    min8 = Min(10)
    min9 = min7.concat(min8)
    print(min9)


# Generated at 2022-06-12 05:26:15.692374
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert "Min[value=10.0]" == str(Min(10.0))


# Generated at 2022-06-12 05:26:23.778886
# Unit test for method __str__ of class Map
def test_Map___str__():
    # given
    given = {1: One(True), 2: One(False)}
    # when
    when = Map(given)
    # then
    then = str(when)
    expected = 'Map[value={1: One[value=True], 2: One[value=False]}]'
    assert then == expected


# Generated at 2022-06-12 05:26:28.080336
# Unit test for constructor of class One
def test_One():
    assert One(True)
    assert One(False)
    assert One(1)
    assert One(0)
    assert One("")
    assert One("text")
    assert One(None)
    assert One(object())



# Generated at 2022-06-12 05:26:29.408062
# Unit test for method __str__ of class All
def test_All___str__():
    assert isinstance(All(True).__str__(), str)


# Generated at 2022-06-12 05:26:31.324118
# Unit test for constructor of class One
def test_One():
    one = One(True)
    assert one.value == True

# Generated at 2022-06-12 05:26:38.803486
# Unit test for method concat of class Map
def test_Map_concat():
  assert Map({"a": Sum(1)}).concat(Map({"a": Sum(1)})).value['a'].value == 2
  assert Map({"a": Sum(1)}).concat(Map({"b": Sum(1)})).value['b'].value == 1
  assert Map({"a": Sum(1)}).concat(Map({"a": Sum(1),"b": Sum(1)})).value['a'].value == 2
  assert Map({"a": Sum(1)}).concat(Map({"a": Sum(1),"b": Sum(1)})).value['b'].value == 1



# Generated at 2022-06-12 05:26:43.753061
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)).value == 2
    assert Max(1).concat(Max(-1)).value == 1
    assert Max(-1).concat(Max(1)).value == 1
    assert Max(-1).concat(Max(-2)).value == -1


# Generated at 2022-06-12 05:26:45.251069
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(100)) == "Max[value=100]"



# Generated at 2022-06-12 05:26:47.854762
# Unit test for method concat of class All
def test_All_concat():
    all_concat = All(True)
    assert all_concat.concat(All(True)).value == all_concat.concat(All(False)).value



# Generated at 2022-06-12 05:26:52.161187
# Unit test for method concat of class Map
def test_Map_concat():
    a = {1: Sum(1), 2: Sum(2)}
    b = {1: Sum(1), 2: Sum(2)}
    assert Map(a).concat(Map(b)) == Map({1: Sum(2), 2: Sum(4)})

# Generated at 2022-06-12 05:26:54.172120
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum_data = Sum(1)
    assert str(sum_data) == 'Sum[value=1]'



# Generated at 2022-06-12 05:27:02.615401
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(2) != Semigroup(1)



# Generated at 2022-06-12 05:27:03.541203
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False).value == False


# Generated at 2022-06-12 05:27:09.717325
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(4).fold(lambda v: v) == 4
    assert (Last(4).concat(Last(0))).fold(lambda v: v) == 0
    assert (Last(4).concat(Last(3))).fold(lambda v: v) == 3
    assert (Last(4).concat(Last(101))).fold(lambda v: v) == 101


# Generated at 2022-06-12 05:27:11.200999
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'



# Generated at 2022-06-12 05:27:13.878292
# Unit test for constructor of class Min
def test_Min():
    semigroup1 = Min(3)
    semigroup2 = Min(1)
    assert(semigroup1.value == 3)
    assert(semigroup2.value == 1)

# Generated at 2022-06-12 05:27:17.640188
# Unit test for method __str__ of class Min
def test_Min___str__():

    assert Min(1).__str__() == 'Min[value=1]'
    assert Min(2).__str__() == 'Min[value=2]'
    assert Min(3).__str__() == 'Min[value=3]'
    assert Min(4).__str__() == 'Min[value=4]'



# Generated at 2022-06-12 05:27:20.693739
# Unit test for method __str__ of class First
def test_First___str__():
    # Given
    expected = 'Fist[value=1]'

    # When
    actual = str(First(1))

    # Then
    assert actual == expected



# Generated at 2022-06-12 05:27:22.892122
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(5)).concat(Sum(15)) == Sum(22)


# Generated at 2022-06-12 05:27:25.172619
# Unit test for constructor of class Last
def test_Last():
    last = Last(5)
    assert last.__str__() == "Last[value=5]"
    assert last.value == 5


# Generated at 2022-06-12 05:27:28.857496
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    Type: Unit
    Module: semigroup
    Method: Sum.concat
    """
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-12 05:27:42.692642
# Unit test for method concat of class Sum
def test_Sum_concat():
    a = Sum(1)
    b = Sum(1)
    c = a.concat(b)
    assert c == Sum(2)



# Generated at 2022-06-12 05:27:47.842189
# Unit test for constructor of class Map
def test_Map():
    map_init = Map({'one': 1, 'two': 2, 'three': 3})
    assert map_init is not None
    assert isinstance(map_init, Map)
    assert isinstance(map_init.value, dict)
    assert all(x in map_init.value.keys() for x in ('one', 'two', 'three'))
    assert all(isinstance(x, int) for x in map_init.value.values())



# Generated at 2022-06-12 05:27:48.945179
# Unit test for constructor of class Min
def test_Min():
    assert Min(4).value == 4


# Generated at 2022-06-12 05:27:52.777457
# Unit test for constructor of class Map
def test_Map():
    m = Map({"a": Sum(1), "b": Sum(2)})
    n = Map({"a": Sum(3), "c": Sum(4)})
    p = Map({"a": Sum(4), "b": Sum(2), "c": Sum(4)})
    assert m.concat(n) == p



# Generated at 2022-06-12 05:28:01.048316
# Unit test for method __str__ of class First
def test_First___str__():
    """
    Method __str__ returns a string describing an object
    """
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First(None)) == 'Fist[value=None]'
    assert str(First('')) == 'Fist[value=]'
    assert str(First(False)) == 'Fist[value=False]'
    assert str(First(True)) == 'Fist[value=True]'
    assert str(First([])) == 'Fist[value=[]]'
    assert str(First({})) == 'Fist[value={}]'



# Generated at 2022-06-12 05:28:02.992839
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)



# Generated at 2022-06-12 05:28:10.286572
# Unit test for method concat of class Max
def test_Max_concat():
    """
    :returns: True if all test passed, otherwise False
    :rtype: bool
    """
    return all((
        Max(1).concat(Max(3)) == Max(3),
        Max(100).concat(Max(0)) == Max(100),
        Max(1).concat(Max(0)) == Max(1),
        Max(-1).concat(Max(-2)) == Max(-1),
    ))



# Generated at 2022-06-12 05:28:18.374394
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    ::

        >>> from adt.Maybe import Just, Maybe
        >>> from adt.ADT import ADT
        >>> from adt.Semigroup import Semigroup
        >>>
        >>> def add(x):
        ...     return x + 1
        ...
        >>> Semigroup(1).fold(add)
        2
        >>> Semigroup(2).fold(add)
        3
        >>> Semigroup(3).fold(add)
        4
    """



# Generated at 2022-06-12 05:28:20.589969
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({"test": Sum(1)})) == "Map[value={'test': Sum[value=1]}]"

# Generated at 2022-06-12 05:28:22.170888
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-12 05:28:35.218137
# Unit test for constructor of class Semigroup
def test_Semigroup():
    value = 42
    semigroup = Semigroup(value)
    assert semigroup.value == value


# Generated at 2022-06-12 05:28:37.841891
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(3)
    b = Min(2)
    c = a.concat(b)
    assert c.value == 2



# Generated at 2022-06-12 05:28:39.971495
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(0) == Semigroup(0)
    assert Semigroup(0) != Semigroup(1)
# Unit tests for constructor of class Sum

# Generated at 2022-06-12 05:28:42.179894
# Unit test for constructor of class Min
def test_Min():
    min = Min(2)
    assert min.value == 2
    assert min.concat(Min(1)).value == 1


# Generated at 2022-06-12 05:28:44.112600
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(5).concat(Min(20)).concat(Min(-5)) == Min(-5)


# Generated at 2022-06-12 05:28:45.618473
# Unit test for constructor of class First
def test_First():
    assert First(10) == First(10)
    assert First(10) != First(20)


# Generated at 2022-06-12 05:28:49.110457
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(10).concat(Max(20)).value == Max(20).concat(Max(10)).value
    assert Max(10).concat(Max(20)).value == 20


# Generated at 2022-06-12 05:28:50.512951
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)


# Generated at 2022-06-12 05:28:55.725225
# Unit test for method concat of class Last
def test_Last_concat():
    """
    GIVEN 2 different Last instances
    WHEN concat method is called
    THEN return a new Last instance with the last value
    """
    last1 = Last(1)
    last2 = Last(2)

    new_last = last1.concat(last2)
    assert new_last == Last(2)



# Generated at 2022-06-12 05:28:56.984311
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-12 05:29:26.327129
# Unit test for constructor of class All
def test_All():
    assert All(False) == All(False)
    assert All(not False) != All(not True)
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-12 05:29:31.065289
# Unit test for constructor of class Sum
def test_Sum():
    """
    :returns: unit test pass or fail
    :rtype: bool
    """
    assert Sum(12) == Sum(12)
    assert not Sum(12) == Sum(42)
    assert Sum(1).fold(lambda v: v) == 1



# Generated at 2022-06-12 05:29:34.328083
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    # GIVEN
    semigroup_1 = Sum(1)
    semigroup_2 = Sum(1)
    # THEN
    assert semigroup_1 == semigroup_2



# Generated at 2022-06-12 05:29:35.877418
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-12 05:29:37.857676
# Unit test for constructor of class One
def test_One():
    semigroup = One(True)
    assert semigroup.value is True
    assert isinstance(semigroup, One)



# Generated at 2022-06-12 05:29:39.726617
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1
    assert Last(2).value == 2
    assert Last("text").value == "text"


# Generated at 2022-06-12 05:29:51.113564
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert First(1) == First(1)
    assert First(2) != First(1)
    assert Last(1) == Last(1)
    assert Last(2) != Last(1)
    assert Max(1) == Max(1)
    assert Max(2) != Max(1)
    assert Min(1) == Min(1)
    assert Min(2) != Min(1)
    assert Sum(1) == Sum(1)
    assert Sum(2) != Sum(1)
    assert All(True) == All(True)
    assert All(False) != All(True)
    assert One(True) == One(True)
    assert One(False) != One(True)
    # Test with 2 different values types
    assert First(1) != Last(1)
    # Test with 2 different Semigroup classes


# Generated at 2022-06-12 05:29:53.325898
# Unit test for constructor of class One
def test_One():
    assert One(1).value == 1
    assert One(False).value == False
    assert One(True).value == True
    assert One(None).value == None
    assert One("string").value == "string"


# Generated at 2022-06-12 05:29:58.737866
# Unit test for method concat of class Sum
def test_Sum_concat():
    print('- Unit test method concat of class Sum')
    sum_semigroup = Sum(2)
    another_sum_semigroup = Sum(5)
    combined_sum_semigroup = sum_semigroup.concat(another_sum_semigroup)
    print(combined_sum_semigroup)
    assert 7 == combined_sum_semigroup.value, 'combined value of Sum semigroups must be 7'



# Generated at 2022-06-12 05:30:01.482141
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(3)).concat(Min(1)) == Min(1)



# Generated at 2022-06-12 05:30:52.735916
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    assert repr(Last(123)) == 'Last[value=123]'
    assert repr(Last(123.45)) == 'Last[value=123.45]'



# Generated at 2022-06-12 05:30:54.455673
# Unit test for method __str__ of class Max
def test_Max___str__():
    result = 'Max[value=10]'
    assert str(Max(10)) == result


# Generated at 2022-06-12 05:30:58.897683
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"a": Sum(1), "b": All(True)}).concat(
        Map({"a": Sum(2), "c": One(False)})
    ).value == {"a": Sum(3), "b": All(True), "c": One(False)}

# Generated at 2022-06-12 05:31:00.926914
# Unit test for method __str__ of class Min
def test_Min___str__():
    actual = str(Min(-1))
    assert actual == 'Min[value=-1]'


# Generated at 2022-06-12 05:31:02.026478
# Unit test for constructor of class One
def test_One():
    assert One(0) == One(0)



# Generated at 2022-06-12 05:31:03.271266
# Unit test for constructor of class All
def test_All():
    assert All(True).value
    assert All(0).value



# Generated at 2022-06-12 05:31:04.982465
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) != All(True)



# Generated at 2022-06-12 05:31:08.490362
# Unit test for constructor of class All
def test_All():
    x = All(True)
    y = All(False)
    assert x.concat(y) == All(False)
    assert x.fold(lambda x: x) == x.value == True
    assert y.fold(lambda x: x) == y.value == False



# Generated at 2022-06-12 05:31:10.867094
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(2) == Semigroup(1)



# Generated at 2022-06-12 05:31:12.967206
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)


# Generated at 2022-06-12 05:32:57.319005
# Unit test for method __str__ of class Min
def test_Min___str__():
    actual = str(Min(2))
    expected = "Min[value=2]"
    assert actual == expected


# Generated at 2022-06-12 05:33:00.769252
# Unit test for method concat of class First
def test_First_concat():
    first = First(10)
    second = First(20)

    assert first.concat(second) == First(10)



# Generated at 2022-06-12 05:33:04.384567
# Unit test for method __str__ of class Map
def test_Map___str__(): # pragma: no cover
    """
    Tests '__str__' method of Map class
    """
    assert Map({'Sum': Sum(1), 'All': All(False)}).__str__() == "Map[value={'Sum': Sum[value=1], 'All': All[value=False]}]"


# Generated at 2022-06-12 05:33:06.865703
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert Map({'key': Sum(123)}).__str__() == 'Map[value={\'key\': Sum[value=123]}]'



# Generated at 2022-06-12 05:33:11.051281
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1) == Min(1)
    assert Min(1) == Min(1).concat(Min(10))
    assert Min(1) == Min(10).concat(Min(1))
    assert Min(10) == Min(10).concat(Min(10))


# Generated at 2022-06-12 05:33:20.809130
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(3).fold(lambda x: x * x) == 9
    assert All(True).fold(lambda x: x * x) == True
    assert All(False).fold(lambda x: x * x) == False
    assert First("a").fold(lambda x: x * x) == "a"
    assert First("b").fold(lambda x: x + x) == "bb"
    assert Last("a").fold(lambda x: x * x) == "a"
    assert Last("b").fold(lambda x: x + x) == "bb"
    assert Max(3).fold(lambda x: x * x) == 9
    assert Min(3).fold(lambda x: x * x) == 9
    d = {"a": Sum(3), "b": All(True)}

# Generated at 2022-06-12 05:33:22.376701
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-12 05:33:23.845575
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)



# Generated at 2022-06-12 05:33:30.396403
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    # check equals
    sg1 = Sum(1)
    sg2 = Sum(1)
    assert sg1 == sg2

    # check not equals
    sg1 = All(False)
    sg2 = Sum(2)
    assert sg1 != sg2

    # check not equals if other is not semigroup
    sg1 = All(False)
    assert sg1 != 2


# Generated at 2022-06-12 05:33:32.032555
# Unit test for constructor of class Min
def test_Min():
  assert Min(1).value == 1
  assert Min(2).value == 2
