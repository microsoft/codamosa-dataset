

# Generated at 2022-06-12 05:23:55.997974
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(4)) == Min(1)
    assert Min(4).concat(Min(1)) == Min(1)
    assert Min(4).concat(Min(5)) == Min(4)
    assert Min(5).concat(Min(4)) == Min(4)
# test_Min_concat()



# Generated at 2022-06-12 05:23:58.576903
# Unit test for method concat of class Max
def test_Max_concat():
    left = Max(5)
    right = Max(7)
    assert left.concat(right) == Max(7)


# Generated at 2022-06-12 05:24:01.632966
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)

# Generated at 2022-06-12 05:24:06.694001
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map(
        {"K1": Sum(1), "K2": Sum(2)}
    ).concat(Map({"K1": Sum(3), "K2": Sum(4)})) == Map({"K1": Sum(4), "K2": Sum(6)})

# Generated at 2022-06-12 05:24:09.522714
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).value == 1
    assert Min(2).concat(Min(3)).value == 2


# Generated at 2022-06-12 05:24:12.377440
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(3).concat(Max(5)) == Max(5)
    assert Max(3).concat(Max(2)) == Max(3)



# Generated at 2022-06-12 05:24:15.923026
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map({'a': All(True)})
    map2 = Map({'a': All(False)})
    m = map1.concat(map2)

    assert m.value['a'] == All(False)

# Generated at 2022-06-12 05:24:20.383567
# Unit test for method concat of class Min
def test_Min_concat():
    min_1 = Min(5)
    min_2 = Min(6)
    min_3 = min_1.concat(min_2)
    assert min_1.value == 5
    assert min_2.value == 6
    assert min_3.value == 5


# Generated at 2022-06-12 05:24:26.470572
# Unit test for method concat of class Map
def test_Map_concat():  # pragma: no cover
    assert Map({1: Sum(1), 2: Sum(2)}).concat(Map({1: Sum(1), 2: Sum(2)})) == Map({1: Sum(2), 2: Sum(4)})
    assert Map({1: All(True)}).concat(Map({1: All(False)})) == Map({1: All(False)})
    assert Map({1: First(1), 2: First(2)}).concat(Map({1: First(3), 2: First(4)})) == Map({1: First(1), 2: First(2)})
    assert Map({1: Last(1), 2: Last(2)}).concat(Map({1: Last(3), 2: Last(4)})) == Map({1: Last(3), 2: Last(4)})

# Generated at 2022-06-12 05:24:28.515257
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(5)) == Min(2)
    assert Min(5).concat(Min(2)) == Min(2)


# Generated at 2022-06-12 05:24:34.596907
# Unit test for constructor of class Map
def test_Map():
    class_map = Map({})
    assert isinstance(class_map, Map)
    class_map = Map({'one': 'two'})
    assert isinstance(class_map, Map)
    assert class_map.value['one'] == 'two'



# Generated at 2022-06-12 05:24:36.692563
# Unit test for method concat of class Sum
def test_Sum_concat():
    expected = Sum(15)
    actual = Sum(4).concat(Sum(11))
    assert expected == actual



# Generated at 2022-06-12 05:24:41.350079
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)).value is True
    assert One(False).concat(One(True)).value is True
    assert One(False).concat(One(False)).value is False



# Generated at 2022-06-12 05:24:47.045616
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-12 05:24:50.948347
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'
    assert str(One(True)) == 'One[value=True]'
    assert str(One(None)) == 'One[value=None]'
    assert str(One([1,2,3])) == 'One[value=[1, 2, 3]]'



# Generated at 2022-06-12 05:25:01.059490
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'key1': Sum(1)}).concat(Map({'key1': Sum(2)})) \
        == Map({'key1': Sum(3)})
    assert Map({'key1': Sum(1)}).concat(Map({'key2': Sum(2)})) \
        == Map({'key1': Sum(1), 'key2': Sum(2)})
    assert Map({}).concat(Map({})) == Map({})
    assert Map({'key1': Sum(1)}).concat(Map({'key1': Sum(2)})) \
        == Map({'key1': Sum(3)})



# Generated at 2022-06-12 05:25:02.848008
# Unit test for constructor of class Max
def test_Max():
    max = Max(1)
    assert max.value == 1



# Generated at 2022-06-12 05:25:04.221504
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(123)) == 'Max[value=123]'



# Generated at 2022-06-12 05:25:05.538827
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(2)) == 'Max[value=2]'

# Generated at 2022-06-12 05:25:07.585708
# Unit test for method concat of class Max
def test_Max_concat():
    a = Max(2)
    b = Max(3)
    assert a.concat(b) == Max(3)


# Generated at 2022-06-12 05:25:14.099143
# Unit test for constructor of class Semigroup
def test_Semigroup():# pragma: no cover
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1).value == Semigroup(1).value
    assert Semigroup(1).value == 1

    assert Semigroup("foo") == Semigroup("foo")
    assert Semigroup("foo").value == Semigroup("foo").value
    assert Semigroup("foo").value == "foo"



# Generated at 2022-06-12 05:25:20.755145
# Unit test for constructor of class Map
def test_Map():
    # assert Map({'age': Last(1), 'id': First(1)}).concat(
    #     Map({'age': Last(2), 'id': First(2)})) == Map({'age': Last(2), 'id': First(1)})
    print("test_Map: ", Map({'age': Last(1), 'id': First(1)}).concat(
        Map({'age': Last(2), 'id': First(2)})))



# Generated at 2022-06-12 05:25:22.334528
# Unit test for method __str__ of class First
def test_First___str__():
    f1 = First('hello')
    assert str(f1) == 'Fist[value=hello]'



# Generated at 2022-06-12 05:25:23.972658
# Unit test for constructor of class Sum
def test_Sum():
    """
    1. Sum not accept non-numeric values
    """
    with pytest.raises(ValueError) as e:
        Sum('a')



# Generated at 2022-06-12 05:25:25.784058
# Unit test for method __str__ of class Map
def test_Map___str__():

    assert str(Map({1: Sum(1)})) == 'Map[value={1: Sum[value=1]}]'



# Generated at 2022-06-12 05:25:26.890686
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-12 05:25:32.549412
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert not Sum(0) == Sum(1)
    assert Sum(0) == Sum(0)

    assert not All(True) == All(False)
    assert All(False) == All(False)

    assert not One(False) == One(True)
    assert One(False) == One(False)

    assert not First('a') == First('b')
    assert First('c') == First('c')

    assert not Last('a') == Last('b')
    assert Last('c') == Last('c')

    assert not Map({'a': Sum(1)}) == Map({'b': Sum(1)})
    assert Map({'a': Sum(1)}) == Map({'a': Sum(1)})

    assert not Max(0) == Max(1)
    assert Max(1) == Max(1)



# Generated at 2022-06-12 05:25:35.260097
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)).value == Sum(3).value
    assert Sum(1).concat(Sum(0)).value == Sum(1).value


# Generated at 2022-06-12 05:25:44.889622
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    Unit test for method concat of class Sum
    """
    assert Sum(7).concat(Sum(11)) == Sum(18), "concat of Sum(7) and Sum(11) must be equal 18"
    assert Sum(0).concat(Sum(1)) == Sum(1), "concat of Sum(0) and Sum(1) must be equal 1"
    assert Sum(64).concat(Sum(1)) == Sum(65), "concat of Sum(64) and Sum(1) must be equal 65"
    assert Sum(0).concat(Sum(3)) == Sum(3), "concat of Sum(0) and Sum(3) must be equal 3"

# Generated at 2022-06-12 05:25:48.118793
# Unit test for constructor of class Max
def test_Max():
    assert Max(2) == Max(2)
    assert Max(-2) == Max(-2)
    assert Max(2) != Min(2)


# Generated at 2022-06-12 05:25:51.451378
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3), 'Sum concat failed'

# Generated at 2022-06-12 05:25:52.774858
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(0)) == 'Max[value=0]'


# Generated at 2022-06-12 05:25:56.715910
# Unit test for method concat of class Min
def test_Min_concat():
    semigroup_1 = Min(1)
    semigroup_2 = Min(2)
    answer = semigroup_1.concat(semigroup_2)
    assert answer.value == 1, "The result is incorrect!"

# Generated at 2022-06-12 05:26:06.303717
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({1: All(True)}).concat(Map({1: All(False)})).value[1] == All(False)
    assert Map({1: Sum(1)}).concat(Map({1: Sum(1)})).value[1] == Sum(2)
    assert Map({1: First(1)}).concat(Map({1: First(3)})).value[1] == First(1)
    assert Map({1: Last(2)}).concat(Map({1: Last(0)})).value[1] == Last(0)
    assert Map({1: Min(5)}).concat(Map({1: Min(1)})).value[1] == Min(1)
    assert Map({1: Max(1)}).concat(Map({1: Max(2)})).value[1] == Max(2)
   

# Generated at 2022-06-12 05:26:07.577958
# Unit test for constructor of class Last
def test_Last():
    semigroup = Last(2)
    assert semigroup.value == 2


# Generated at 2022-06-12 05:26:09.172037
# Unit test for method concat of class Min
def test_Min_concat():
    s = Min(3)
    assert s.concat(Min(4)).value == 3


# Generated at 2022-06-12 05:26:16.062695
# Unit test for constructor of class All
def test_All():
    all_true = All(True)
    all_false = All(False)
    assert all_true.concat(all_false) == All(False)
    assert all_false.concat(all_true) == All(False)
    assert all_false.concat(all_false) == All(False)
    assert all_true.concat(all_true) == All(True)



# Generated at 2022-06-12 05:26:17.721119
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(5)) == "Sum[value=5]"
    assert str(Sum(-1)) == "Sum[value=-1]"



# Generated at 2022-06-12 05:26:20.425914
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First(1)) == "Fist[value=1]"



# Generated at 2022-06-12 05:26:24.275103
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-12 05:26:34.181845
# Unit test for method concat of class Map
def test_Map_concat():
    result = Result.of({'a': Sum(1), 'b': Sum(2), 'c': Sum(3)}).concat(Result.of({'a': Sum(4), 'b': Sum(5), 'c': Sum(6)}))
    assert result.get('a') == Sum(5)
    assert result.get('b') == Sum(7)
    assert result.get('c') == Sum(9)

# Generated at 2022-06-12 05:26:38.097085
# Unit test for method __str__ of class Map
def test_Map___str__():
    """
    Test __str__ method of Map class
    :return:
    """
    obj = Map({
        'users': Sum(10),
        'products': Sum(20)
    })
    assert str(obj) == "Map[value={'users': Sum[value=10], 'products': Sum[value=20]}]"



# Generated at 2022-06-12 05:26:39.558986
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-12 05:26:43.218608
# Unit test for method concat of class Min
def test_Min_concat():
    min1 = Min(1)
    min2 = Min(2)

    assert min1.concat(min2).value == 1
    assert min2.concat(min1).value == 1


# Generated at 2022-06-12 05:26:47.128789
# Unit test for method concat of class Last
def test_Last_concat():

    l1 = Last(1)
    l2 = Last(2)
    l3 = Last(3)

    print(l1.concat(l2))  # 2
    print(l1.concat(l2).concat(l3))  # 3



# Generated at 2022-06-12 05:26:51.857448
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"a": Sum(1), "b": Sum(2)}).concat(Map({"a": Sum(3), "c": Sum(4)})) == Map({
        "a": Sum(4),
        "b": Sum(2),
        "c": Sum(4)
    })

# Generated at 2022-06-12 05:26:55.476851
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"a": All(True), "b": All(False)}).concat(
        Map({"a": All(False), "b": All(True)})
    ).value == {"a": All(False), "b": All(False)}



# Generated at 2022-06-12 05:26:57.464043
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'



# Generated at 2022-06-12 05:27:01.571271
# Unit test for method __str__ of class Last
def test_Last___str__():
    # Arrange
    expected = 'Last[value=9]'
    label = Last(9)
    # Act
    actual = label.__str__()
    # Assert
    assert actual == expected

# Generated at 2022-06-12 05:27:03.941876
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last('Petr')) == "Last[value=Petr]"



# Generated at 2022-06-12 05:27:09.257354
# Unit test for method concat of class All
def test_All_concat():
    semigroup = All(False)
    monoid = All(True)
    assert semigroup.concat(monoid) == All(False)
    print('All concat is OK')



# Generated at 2022-06-12 05:27:10.770603
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-12 05:27:15.696793
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    # Parameter fn is function that accepts value A, and produces value B.
    fn = lambda x: x * x
    Sum_ = Sum(2).fold(fn)  # Sum_ == 4
    assert Sum_ == 4
    First_ = First(2).fold(fn)  # First_ == 4
    assert First_ == 4



# Generated at 2022-06-12 05:27:18.081804
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert 'Min[value=1]' == str(Min(1))


# Generated at 2022-06-12 05:27:22.136472
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(10)) == 'Sum[value=10]'
    assert str(Sum(20)) == 'Sum[value=20]'
    assert str(Sum(10 + 10)) == 'Sum[value=20]'



# Generated at 2022-06-12 05:27:24.183907
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
	assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-12 05:27:27.883041
# Unit test for method concat of class Min
def test_Min_concat():  # pragma: no cover
    assert Min(2).concat(Min(3)).value == 2
    assert Min(3).concat(Min(2)).value == 2


# Generated at 2022-06-12 05:27:30.909962
# Unit test for constructor of class Map
def test_Map():
    assert Map({'first': Sum(1), 'second': Sum(2)}).value == {'first': Sum(1), 'second': Sum(2)}



# Generated at 2022-06-12 05:27:38.582905
# Unit test for method concat of class Map
def test_Map_concat():
    m = Map({
        'one': Sum(1),
        'two': Sum(2),
    })

    l = Map({
        'three': Sum(3),
        'four': Sum(4),
    })
    assert m.concat(l) == Map({
        'one': Sum(1),
        'two': Sum(2),
        'three': Sum(3),
        'four': Sum(4),
    })
    assert l.concat(m) == Map({
        'one': Sum(1),
        'two': Sum(2),
        'three': Sum(3),
        'four': Sum(4),
    })


# Generated at 2022-06-12 05:27:41.552646
# Unit test for constructor of class Max
def test_Max():
    with pytest.raises(TypeError):
        Max('a')
    with pytest.raises(TypeError):
        Max({})



# Generated at 2022-06-12 05:27:44.372319
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)

# Generated at 2022-06-12 05:27:48.417429
# Unit test for method __str__ of class Min
def test_Min___str__():
    semigroup = Min(1)
    expected = "Min[value=1]"
    actual = semigroup.__str__()
    assert expected == actual, 'Expected "{}", but got "{}"'.format(
        expected, actual
    )

# Generated at 2022-06-12 05:27:50.624503
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]", "All.__str__ is broken"



# Generated at 2022-06-12 05:27:52.050663
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
  assert str(Max(10)) == 'Max[value=10]'


# Generated at 2022-06-12 05:27:55.121226
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():  # pragma: no cover
    assert Sum(5) == Sum(5)
    assert All(5) == All(5)
    assert All(5) == All(True)
    assert All(5) != All(False)

# Generated at 2022-06-12 05:27:59.583542
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({'a': Sum(1), 'b': Sum(2)})
    m2 = Map({'a': Sum(3), 'b': Sum(4)})
    assert m1.concat(m2) == Map({'a': Sum(4), 'b': Sum(6)})



# Generated at 2022-06-12 05:28:00.960580
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(42)) == 'One[value=42]'


# Generated at 2022-06-12 05:28:08.768344
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({'a': Last(1), 'b': Last(2), 'c': Last(3)})
    m2 = Map({'x': Last(100), 'b': Last(200), 'z': Last(300)})
    assert m1.concat(m2) == Map(
        {
            'a': Last(1),
            'b': Last(2),
            'c': Last(3),
            'x': Last(100),
            'z': Last(300),
        }
    )

# Generated at 2022-06-12 05:28:12.397024
# Unit test for constructor of class All
def test_All():
    a = All(True)
    b = All(False)
    assert a.value is True
    assert b.value is False


# Generated at 2022-06-12 05:28:16.057277
# Unit test for method concat of class Min
def test_Min_concat():
    m1 = Min(1)
    m2 = Min(2)
    assert m1.concat(m2) == Min(1)


# Generated at 2022-06-12 05:28:22.991717
# Unit test for method concat of class Map
def test_Map_concat():
    # Init some map
    m1 = Map({'a': Sum(1), 'b': Sum(2)})

    # Init expected map
    exp = Map({'a': Sum(2), 'b': Sum(4)})

    # Init map to concat
    m2 = Map({'a': Sum(1), 'b': Sum(2)})

    # Execute method
    res = m1.concat(m2)

    assert exp == res

# Generated at 2022-06-12 05:28:28.619151
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(5)) == 'Last[value=5]'
    assert str(Last(True)) == 'Last[value=True]'
    assert str(Last(False)) == 'Last[value=False]'
    assert str(Last(None)) == 'Last[value=None]'
    assert str(Last('test')) == 'Last[value=test]'
    assert str(Last(['test'])) == 'Last[value=test]'



# Generated at 2022-06-12 05:28:31.988349
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    all = All(True)
    assert str(all) == 'All[value=True]'


# Generated at 2022-06-12 05:28:33.493678
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(4) == Sum(4)


# Generated at 2022-06-12 05:28:43.695665
# Unit test for constructor of class Last
def test_Last():
    assert isinstance(Last("TEST1"), Last)
    assert isinstance(Last("TEST2"), Semigroup)
    assert Last("TEST1").value == "TEST1"
    assert not Last("TEST1") == Last("TEST2")
    assert Last("TEST1").concat(Last("TEST2")).value == "TEST2"
    assert Last("TEST1").fold(lambda x: "TEST") == "TEST"
    assert isinstance(Last.neutral(), Last)
    assert Last.neutral().value == False
    assert Last("TEST1").fold(lambda x: x) == "TEST1"
    assert Last("TEST1").__str__() == "Last[value=TEST1]"


# Generated at 2022-06-12 05:28:45.825022
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert Sum(5) == Sum(5)



# Generated at 2022-06-12 05:28:48.163475
# Unit test for constructor of class One
def test_One():
    a = One(True)
    b = One(False)
    c = One(True)
    assert a == c
    assert a != b


# Generated at 2022-06-12 05:28:49.871639
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(2)) == 'Max[value=2]'


# Generated at 2022-06-12 05:28:59.469051
# Unit test for constructor of class Map
def test_Map():
    x = Map({"a": Sum(1), "b": All(True)})
    assert (x.value == {"a": Sum(1), "b": All(True)})

    x = Map({"a": Sum(1), "b": All(True)})
    assert (x.value == {"a": Sum(1), "b": All(True)})

    x = Map({"a": Sum(1), "b": All(False)})
    assert (x.value == {"a": Sum(1), "b": All(False)})

    x = Map({"a": Sum(1), "b": All(0)})
    assert (x.value == {"a": Sum(1), "b": All(0)})



# Generated at 2022-06-12 05:29:03.261790
# Unit test for method concat of class One
def test_One_concat():
    S = One('foo')
    assert S.concat(Last(One('bar'))).value == 'bar'



# Generated at 2022-06-12 05:29:06.241438
# Unit test for constructor of class Last
def test_Last():
    assert str(Last(2)) == 'Last[value=2]'


# Generated at 2022-06-12 05:29:09.934306
# Unit test for method __str__ of class All
def test_All___str__():
    """Unit test for method __str__ of class All."""
    assert 'All[value=True]' == str(All(True))
    assert 'All[value=False]' == str(All(False))



# Generated at 2022-06-12 05:29:13.987065
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"1": "one", "2": "two"}).concat(Map({"1": "een", "2": "twee"})) == Map({'1': First('one'), '2': First('two')})

# Generated at 2022-06-12 05:29:21.760954
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Sum(1)
    assert Semigroup(1) == All(1)
    assert Semigroup(1) == One(1)
    assert Semigroup(1) == Last(1)
    assert Semigroup(1) == First(1)
    assert Semigroup(1) == Max(1)
    assert Semigroup(1) == Min(1)
    assert Semigroup(1) == Map({1: Sum(1)})
    assert Semigroup(1) == Map({1: All(1)})
    assert Semigroup(1) == Map({1: One(1)})
    assert Semigroup(1) == Map({1: Last(1)})
    assert Semigroup(1) == Map({1: First(1)})
    assert Semigroup(1) == Map({1: Max(1)})


# Generated at 2022-06-12 05:29:24.072916
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(5) == Sum(5)
    assert Sum(5) != Sum(4)



# Generated at 2022-06-12 05:29:25.678498
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(3)) == 'Sum[value=3]'


# Generated at 2022-06-12 05:29:29.928060
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'
    assert str(Last(True)) == 'Last[value=True]'
    assert str(Last(None)) == 'Last[value=None]'


# Generated at 2022-06-12 05:29:39.546696
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2) == Sum(2)
    assert Sum(2).concat(Sum(2)) == Sum(4)
    assert Sum(2).concat(Sum(1)) == Sum(3)
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(2).concat(Sum(3)) == Sum(5)
    assert Sum(3).concat(Sum(2)) == Sum(5)
    assert Sum(3).concat(Sum(3)) == Sum(6)
    assert Sum(3).concat(Sum(4)) == Sum(7)
    assert Sum(4).concat(Sum(4)) == Sum(8)
    assert Sum(4).concat(Sum(5)) == Sum(9)

# Generated at 2022-06-12 05:29:41.307940
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1


# Generated at 2022-06-12 05:29:41.936294
# Unit test for constructor of class One
def test_One():
    assert One(True)

# Generated at 2022-06-12 05:29:46.629396
# Unit test for constructor of class All
def test_All():
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-12 05:29:49.875891
# Unit test for method concat of class Min
def test_Min_concat():
    min_semigroup = Min(5)
    min_semigroup2 = Min(10)
    assert min_semigroup.concat(min_semigroup2) == Min(5)


# Generated at 2022-06-12 05:29:52.428449
# Unit test for method __str__ of class Max
def test_Max___str__():
    print("test Max.__str__()")
    assert "(Max[value=0])" == str(Max(0))
    print("test Max.__str__() end")


# Generated at 2022-06-12 05:29:53.835318
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)


# Generated at 2022-06-12 05:29:56.726031
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': First(1), 'b': Max(1)})) == "Map[value={'a': Fist[value=1], 'b': Max[value=1]}]"


# Generated at 2022-06-12 05:30:02.900268
# Unit test for method concat of class Map
def test_Map_concat():
    """
    Test for concat of Map

    :return: bool
    """

    a = Map({'a': Sum(1), 'b': Sum(2)})
    b = Map({'a': Sum(3), 'b': Sum(4)})
    c = Map({'a': Sum(4), 'b': Sum(6)})

    assert a.concat(b) == c
    return True


# Generated at 2022-06-12 05:30:07.318319
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(None).concat(First(None)) == First(None)
    assert First(1).concat(First(None)) == First(1)


# Generated at 2022-06-12 05:30:14.712605
# Unit test for method concat of class All
def test_All_concat():
    """
    case 1: true, true = true
    case 2: true, false = false
    case 3: false, false = false
    """
    a = All(True)
    b = All(True)
    c = All(False)

    # case 1: true, true = true
    assert a.concat(b) == All(True)

    # case 2: true, false = false
    assert a.concat(c) == All(False)

    # case 3: false, false = false
    assert c.concat(c) == All(False)



# Generated at 2022-06-12 05:30:23.236601
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value == True, "All(True).concat(All(True)).value == True"
    assert All(True).concat(All(False)).value == False, "All(True).concat(All(False)).value == False"
    assert All(False).concat(All(True)).value == False, "All(False).concat(All(True)).value == False"
    assert All(False).concat(All(False)).value == False, "All(False).concat(All(False)).value == False"


# Generated at 2022-06-12 05:30:25.650435
# Unit test for constructor of class All
def test_All():  # pragma: no cover
    assert All(True).fold(lambda x: x) is True
    assert All(False).fold(lambda x: x) is False



# Generated at 2022-06-12 05:30:31.509617
# Unit test for method concat of class Last
def test_Last_concat():
    last_one = Last(1)
    last_two = Last(2)
    expected = Last(2)

    assert last_one.concat(last_two) == expected


# Generated at 2022-06-12 05:30:34.419430
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(True).fold(lambda x: not x) is False
    assert Semigroup(False).fold(lambda x: not x) is True



# Generated at 2022-06-12 05:30:35.558951
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(2).value == 2



# Generated at 2022-06-12 05:30:36.899845
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(10)) == 'Last[value=10]'



# Generated at 2022-06-12 05:30:38.822743
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert Sum(1).__str__() == 'Sum[value=1]'



# Generated at 2022-06-12 05:30:45.631491
# Unit test for constructor of class One
def test_One(): # pragma: no cover
    assert One(True) == One(True)
    assert One(True).value == True
    assert One(False).value == False
    assert One(1) == One(1)
    assert One(1).value == 1
    assert One(0).value == 0
    assert One('string') == One('string')
    assert One('string').value == 'string'
    assert One('').value == ''


# Generated at 2022-06-12 05:30:46.646076
# Unit test for constructor of class Last
def test_Last():
    assert Last("hello") == Last("hello")


# Generated at 2022-06-12 05:30:50.724986
# Unit test for method concat of class Max
def test_Max_concat():
    """
    method concat of class Max returns new Max with largest value
    """
    a = Max(1)
    b = Max(2)
    assert a.concat(b) == b
    assert a.concat(b) == Max(2)
    assert a.concat(b).value == 2



# Generated at 2022-06-12 05:30:52.890809
# Unit test for constructor of class First
def test_First():
    assert First


# Generated at 2022-06-12 05:30:55.475303
# Unit test for method concat of class Max
def test_Max_concat():
    expexted = Max(10)
    actual = Max(5).concat(Max(10))
    assert expexted == actual


# Generated at 2022-06-12 05:30:59.973639
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda v: v + 5) == 6
    assert Semigroup('text').fold(lambda v: v + ' ') == 'text '



# Generated at 2022-06-12 05:31:01.882447
# Unit test for method __str__ of class First
def test_First___str__():
    first = First(1)
    assert 'Fist[value=1]' == first.__str__()



# Generated at 2022-06-12 05:31:03.477210
# Unit test for method __str__ of class Min
def test_Min___str__():  # pragma: no cover
    assert Min(4).__str__() == 'Min[value=4]'


# Generated at 2022-06-12 05:31:06.986069
# Unit test for method concat of class Map
def test_Map_concat():
    map_ = Map({'a': First(1), 'b': First(2)})
    assert map_.concat(Map({'a': First(3), 'b': First(4)})) == Map(
        {'a': First(1), 'b': First(2)}
    )

# Generated at 2022-06-12 05:31:08.391811
# Unit test for constructor of class Last
def test_Last():
    instance: Last = Last({'name': 'chris'})
    assert instance is not None


# Generated at 2022-06-12 05:31:18.372526
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x + 3) == 4
    assert All(True).fold(lambda x: not x) is False
    assert One(True).fold(lambda x: not x) is True
    assert First(1).fold(lambda x: x + 3) == 1
    assert Last(1).fold(lambda x: x + 3) == 4
    assert Map({'foo': Sum(1), 'bar': Sum(2)}).fold(lambda x: x['bar'] + x['foo']) == 3
    assert Max(3).fold(lambda x: x + 3) == 6
    assert Min(3).fold(lambda x: x + 3) == 6


# Generated at 2022-06-12 05:31:26.335738
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    sum_one = Sum(1)
    sum_two = Sum(2)

    assert sum_one.fold(lambda v: v + 1) == 2
    assert sum_two.fold(lambda v: v + 1) == 3

    all_true = All(True)
    all_false = All(False)

    assert all_true.fold(lambda v: v and True) is True
    assert all_false.fold(lambda v: v and True) is False


# Generated at 2022-06-12 05:31:28.596828
# Unit test for constructor of class All
def test_All():
    c = All(True)
    c1 = All(False)
    assert c.value == True
    assert c1.value == False


# Generated at 2022-06-12 05:31:40.181817
# Unit test for method concat of class Max
def test_Max_concat():
    # Case 1:
    # Input:
    #   - semigroup1 = 2
    #   - semigroup2 = 3
    # Expected output:
    #   - Max instance with value 3
    assert Max(2).concat(Max(3)) == Max(3)
    # Case 2:
    # Input:
    #   - semigroup1 = -3
    #   - semigroup2 = 1
    # Expected output:
    #   - Max instance with value 1
    assert Max(-3).concat(Max(1)) == Max(1)
    # Case 3:
    # Input:
    #   - semigroup1 = -2
    #   - semigroup2 = -4
    # Expected output:
    #   - Max instance with value -2
    assert Max(-2).concat(Max(-4))

# Generated at 2022-06-12 05:31:41.915354
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)



# Generated at 2022-06-12 05:31:49.706755
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(0)) == "Min[value=0]"


# Generated at 2022-06-12 05:31:52.175437
# Unit test for constructor of class Max
def test_Max():
    max = Max(25)
    assert max.value == 25


# Generated at 2022-06-12 05:31:54.430047
# Unit test for method concat of class Last
def test_Last_concat():  # pragma: no cover
    assert Last(1).concat(Last(2)).value == 2
    assert Last(1).concat(Last(1)).value == 1



# Generated at 2022-06-12 05:31:57.583233
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert Sum(10) == Sum(10)


# Generated at 2022-06-12 05:31:59.949253
# Unit test for constructor of class One
def test_One():  # pragma: no cover
    result = One(True)
    assert result is not None



# Generated at 2022-06-12 05:32:01.301245
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(2).concat(Last(1)) == Last(1)

# Generated at 2022-06-12 05:32:05.114896
# Unit test for method concat of class Min
def test_Min_concat():
    min_a = Min(3)
    min_b = Min(4)
    print(f'Min_concat() -> {min_a.concat(min_b)}')


# Generated at 2022-06-12 05:32:10.750012
# Unit test for method __str__ of class All
def test_All___str__():
    from nose.tools import assert_equal
    assert_equal(
        str(All(True)),
        'All[value=True]',
        'All should be True'
    )
    assert_equal(
        str(All(False)),
        'All[value=False]',
        'All should be False'
    )


# Generated at 2022-06-12 05:32:13.739230
# Unit test for method __str__ of class First
def test_First___str__():
    first = First(1)
    assert first.__str__() == 'Fist[value=1]'



# Generated at 2022-06-12 05:32:16.174096
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-12 05:32:31.047583
# Unit test for method concat of class Sum
def test_Sum_concat():  # pragma: no cover
    assert Sum(1).concat(Sum(2)).value == 3


# Generated at 2022-06-12 05:32:32.441861
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"


# Generated at 2022-06-12 05:32:34.324428
# Unit test for constructor of class Min
def test_Min():
    minValue = Min(10)
    assert minValue.value == 10, 'Test fail'



# Generated at 2022-06-12 05:32:37.482065
# Unit test for method concat of class Min
def test_Min_concat():  # pragma: no cover
    x = Min(1)
    y = Min(2)
    assert x.concat(y) == Min(1)


# Generated at 2022-06-12 05:32:40.692940
# Unit test for constructor of class All
def test_All():
    assert All.neutral() == All(True)
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)
    assert All(None) == All(None)


# Generated at 2022-06-12 05:32:43.224072
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'  # pragma: no cover


# Generated at 2022-06-12 05:32:48.483003
# Unit test for method concat of class Min
def test_Min_concat():
    min1 = Min(2)
    min2 = Min(1)
    min3 = Min(3)
    assert min1.concat(min2).value == min2.value == 1
    assert min1.concat(min3).value == min3.value == 3


# Generated at 2022-06-12 05:32:53.300341
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)


# Generated at 2022-06-12 05:32:54.712928
# Unit test for constructor of class Max
def test_Max():
    assert Max(2) == Max(2)


# Generated at 2022-06-12 05:32:57.366963
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert "<class 'monoid.max'>({'value': 0})".format(Max(0)) == str(Max(0))


# Generated at 2022-06-12 05:33:36.322010
# Unit test for method concat of class First
def test_First_concat():
    semigroup_A = First("X")
    semigroup_B = First("Y")

    assert semigroup_A == semigroup_B, \
           'Two First instances with different values should be equal'
    assert semigroup_A.concat(semigroup_B) == semigroup_A, \
           'First concated with something else should be First'

    assert semigroup_A.concat(semigroup_B) != semigroup_B, \
           'First concated with something else should not be equal with something else'

    assert type(semigroup_A.concat(semigroup_B)) == First, \
           'First concated with something should be of type First'


# Generated at 2022-06-12 05:33:37.457888
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'

# Generated at 2022-06-12 05:33:47.156806
# Unit test for constructor of class All
def test_All():
    # pylint: disable=unused-variable
    # Semigroups
    sg_1 = All(True)
    sg_2 = All(False)
    sg_3 = All(False)
    sg_4 = All(True)
    # Monoids
    m_1 = Sum(10)
    m_2 = Sum(5)
    m_3 = All(True)
    m_4 = All(False)
    m_5 = First('test')
    m_6 = Last('test')
    m_7 = Map({'key1': Sum(1), 'key2': Sum(2), 'key3': Sum(3)})
    m_8 = Max(10)
    m_9 = Min(10)

