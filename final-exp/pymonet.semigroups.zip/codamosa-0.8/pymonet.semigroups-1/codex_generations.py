

# Generated at 2022-06-12 05:23:55.760984
# Unit test for method concat of class One
def test_One_concat():
    assert One(0).concat(One(1)).value == True
    assert One(1).concat(One(0)).value == True
    assert One(1).concat(One(1)).value == True



# Generated at 2022-06-12 05:23:58.765375
# Unit test for method __str__ of class One
def test_One___str__():
    expected = 'One[value=5]'
    One.neutral_element = 5
    one = One.neutral()
    actual = str(one)
    assert actual == expected



# Generated at 2022-06-12 05:24:00.119554
# Unit test for constructor of class First
def test_First():
    assert First(3).value == 3 and First(3).value == 3

# Generated at 2022-06-12 05:24:02.916322
# Unit test for constructor of class Last
def test_Last():
    # given
    value = 'value'

    # when
    last = Last(value)

    # then
    assert last.value == value


# Generated at 2022-06-12 05:24:06.943095
# Unit test for constructor of class First
def test_First():
    """
    >>> f1 = First(1)
    >>> f2 = First(2)
    >>> f1.concat(f2)
    Fist[value=1]
    """
    pass


# Generated at 2022-06-12 05:24:08.630982
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)


# Generated at 2022-06-12 05:24:10.958497
# Unit test for method concat of class First
def test_First_concat():
    first = First(1)
    first_concated = first.concat(first)
    assert first_concated.value == 1

# Generated at 2022-06-12 05:24:14.614893
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(4).concat(Max(7)) == Max(7)
    assert Max(3).concat(Max(5)) == Max(5)
    assert Max(4).concat(Max(4)) == Max(4)


# Generated at 2022-06-12 05:24:17.171265
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(3)) == 'Min[value=3]'


# Generated at 2022-06-12 05:24:20.237626
# Unit test for method __str__ of class Max
def test_Max___str__():
    actual = str(Max(1))
    expected = "Max[value=1]"
    assert actual == expected, "actual = %s, expected = %s" % (actual, expected)


# Generated at 2022-06-12 05:24:26.332199
# Unit test for method concat of class Map
def test_Map_concat():
    Map({'1': '2'}).concat(Map({'3': '4'})) == Map({'1': '2', '3': '4'})

# Generated at 2022-06-12 05:24:28.864630
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-12 05:24:29.941969
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-12 05:24:32.474448
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    from pymonet.monoid import Sum

    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-12 05:24:35.762503
# Unit test for method concat of class Min
def test_Min_concat():
    min_ = Min(0)
    min_2 = Min(1)
    result = min_.concat(min_2)
    expected = Min(0)
    assert result == expected


# Generated at 2022-06-12 05:24:38.447864
# Unit test for constructor of class Semigroup
def test_Semigroup():
    first = Semigroup(1)
    second = Semigroup(1)
    assert first == second


# Generated at 2022-06-12 05:24:43.691522
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(20).concat(Max(15)) == Max(20)
    assert Max(20).concat(Max(25)) == Max(25)
    assert Max(20).concat(Max(25)).concat(Max(30)) == Max(30)
test_Max_concat()


# Generated at 2022-06-12 05:24:45.268167
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-12 05:24:50.167677
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)

test_All_concat()


# Generated at 2022-06-12 05:24:53.290868
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(100)
    b = Min(90)
    c = a.concat(b)
    assert c.value == b.value


# Generated at 2022-06-12 05:25:02.581301
# Unit test for method concat of class Last
def test_Last_concat():
    # The method concat of class Last should return a Last with last value
    assert Last(1).concat(Last(2)).value == 2
    assert Last('1').concat(Last('2')).value == '2'


# Generated at 2022-06-12 05:25:04.787412
# Unit test for method concat of class First
def test_First_concat():
    first = First(5)
    second = First(6)
    assert first.concat(second) == First(5)



# Generated at 2022-06-12 05:25:07.265576
# Unit test for method concat of class Min
def test_Min_concat():
    min_value = Min(4)
    min_value2 = Min(5)
    assert min_value.concat(min_value2) == Min(4)



# Generated at 2022-06-12 05:25:08.461628
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(8)) == 'Last[value=8]'



# Generated at 2022-06-12 05:25:10.172538
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)



# Generated at 2022-06-12 05:25:11.475015
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)).value == 1


# Generated at 2022-06-12 05:25:12.983977
# Unit test for constructor of class First
def test_First():  # pragma: no cover
    assert First(100)


# Generated at 2022-06-12 05:25:16.181166
# Unit test for constructor of class Map
def test_Map():
    m = Map({1:Min(1), 2:Min(2)})
    assert m.value[1].value == 1
    assert m.value[2].value == 2


# Generated at 2022-06-12 05:25:17.927313
# Unit test for method __str__ of class Min
def test_Min___str__():
    o = Min(4)
    assert (str(o) == "Min[value=4]")


# Generated at 2022-06-12 05:25:25.666856
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert First(1).fold(lambda x: x + 1) == 2
    assert Last(1).fold(lambda x: x + 1) == 2
    assert One(False).fold(lambda x: x + 1) == 2
    assert All(True).fold(lambda x: x + 1) == 2
    assert Sum(1).fold(lambda x: x + 1) == 2
    assert Map({1: Sum(1)}).fold(lambda x: {key: value.fold(lambda x: x + 1) for key, value in x.items()}) == {
        1: 2
    }
    assert Min(1).fold(lambda x: x + 1) == 2
    assert Max(1).fold(lambda x: x + 2) == 3

# Generated at 2022-06-12 05:25:36.983887
# Unit test for constructor of class One
def test_One():  # pragma: no cover
    assert One(10) is not None


# Generated at 2022-06-12 05:25:39.065413
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(3).concat(Min(5)) == Min(3)
    assert Min(5).concat(Min(5)) == Min(5)
    assert Min(5).concat(Min(3)) == Min(3)
    assert Min(3).concat(Min(3)) == Min(3)

# Generated at 2022-06-12 05:25:40.209641
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)


# Generated at 2022-06-12 05:25:43.024294
# Unit test for constructor of class Last
def test_Last():
    last_ = Last(2)  # => Last[value=2]
    assert last_.value == 2
    assert type(last_) == Last


# Generated at 2022-06-12 05:25:45.160222
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(3) == Sum(3)
    assert Sum(3).value == 3


# Generated at 2022-06-12 05:25:48.768519
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    Unit test for method __eq__ of class Semigroup
    """
    assert All(1) == All(1)
    assert All(1) != All(2)



# Generated at 2022-06-12 05:25:50.141219
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'

# Generated at 2022-06-12 05:25:51.636393
# Unit test for method concat of class First
def test_First_concat():
    assert First('a').concat(First('b')) == First('a')

# Generated at 2022-06-12 05:25:53.291818
# Unit test for constructor of class Last
def test_Last():
    assert Last(5) == Last(5)
    assert Last(5) != Last(6)


# Generated at 2022-06-12 05:26:03.450524
# Unit test for method concat of class First
def test_First_concat():
    value = {}
    semigroup = First(value)
    assert value == semigroup.concat(First('str')).value
    assert value == semigroup.concat(Sum(value)).value
    assert value == semigroup.concat(All(value)).value
    assert value == semigroup.concat(One(value)).value
    assert value == semigroup.concat(First(value)).value
    assert value == semigroup.concat(Last(value)).value
    assert value == semigroup.concat(Map(value)).value
    assert value == semigroup.concat(Max(value)).value
    assert value == semigroup.concat(Min(value)).value


# Generated at 2022-06-12 05:26:24.518421
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(5)) == 'Max[value=5]'



# Generated at 2022-06-12 05:26:27.081139
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(1) != Max(2)

test_Max()


# Generated at 2022-06-12 05:26:30.219966
# Unit test for constructor of class Min
def test_Min():
    assert (Min(1) == Min(1)).value
    assert Min(1).value == 1



# Generated at 2022-06-12 05:26:33.914157
# Unit test for method concat of class One
def test_One_concat():
    """
    Unit test for method concat of class One
    :return: None
    """
    actual = One(True).concat(One(False))
    expected = One(True)
    assert actual == expected



# Generated at 2022-06-12 05:26:35.349966
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(2) == Semigroup(2)



# Generated at 2022-06-12 05:26:38.063739
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(None).concat(Last(1)).value == 1
    assert Last(2).concat(Last(1)).value == 1
    assert Last(None).concat(Last(None)).value is None


# Generated at 2022-06-12 05:26:39.901498
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(2) != Max(1)


# Generated at 2022-06-12 05:26:43.161845
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).fold(operator.neg) == -1


# Generated at 2022-06-12 05:26:46.320535
# Unit test for constructor of class Map
def test_Map():
    m = Map({'a':Sum(3), 'b':Sum(4)})
    assert m.value['a'].value == 3
    assert m.value['b'].value == 4


# Generated at 2022-06-12 05:26:47.681820
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(0)) == 'Sum[value=0]'



# Generated at 2022-06-12 05:27:29.064936
# Unit test for constructor of class All
def test_All():
    all_data = All(True)
    assert all_data.value == True



# Generated at 2022-06-12 05:27:35.120722
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(False).__str__() == 'One[value=False]'
    assert One(True).__str__() == 'One[value=True]'
    assert One(42).__str__() == 'One[value=42]'
    assert One('42').__str__() == 'One[value=42]'
    assert One(object()).__str__() == One(object()).__str__()


# Generated at 2022-06-12 05:27:39.591432
# Unit test for method concat of class Max
def test_Max_concat():
    """
    :returns: Test pass or fail
    :rtype: bool
    """
    # Class Init
    a = Max(3)
    b = Max(5)

    # Test method
    return b.concat(a).value == b.value


# Generated at 2022-06-12 05:27:45.379040
# Unit test for constructor of class All
def test_All():
    # Testing of constructor
    assert All(0).value == False
    assert All(1).value == True
    assert All("string").value == True
    assert All([0]).value == True
    assert All([1]).value == True
    assert All([]).value == True
    assert All([[]]).value == True
    assert All({}).value == True


# Generated at 2022-06-12 05:27:49.416500
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({1: Sum(1), 2: Sum(2)}).concat(Map({1: Sum(2), 3: Sum(1)})) == Map({1: Sum(3), 2: Sum(2), 3: Sum(1)})


# Generated at 2022-06-12 05:27:51.610056
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-12 05:28:00.434662
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(5) == Sum(5)
    assert Sum(5) != Sum(6)

    assert All(True) == All(True)
    assert All(True) != All(False)

    assert One(False) == One(False)
    assert One(False) != One(True)

    assert First(5) == First(5)
    assert First(5) != First(6)

    assert Last(5) == Last(5)
    assert Last(5) != Last(6)

    assert Max(5) == Max(5)
    assert Max(5) != Max(6)

    assert Min(5) == Min(5)
    assert Min(5) != Min(6)


# Generated at 2022-06-12 05:28:02.352598
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(2).fold(lambda n: n * n) == 4


# Generated at 2022-06-12 05:28:07.114610
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    a1 = Sum(1)
    a2 = Sum(1)
    a3 = Sum(2)
    assert a1 == a2, "a1 == a2 is True"
    assert a1 != a3, "a1 == a3 is True"



# Generated at 2022-06-12 05:28:09.115465
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(3)) == Max(3)


# Generated at 2022-06-12 05:29:32.057916
# Unit test for constructor of class Max
def test_Max():
    assert Max(2) == Max(2)
    assert Max(2) != Max(3)


# Generated at 2022-06-12 05:29:35.072635
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)
    assert One(False) != One(True)


# Generated at 2022-06-12 05:29:39.432208
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False
    assert All(True).concat(All(True)).value
    assert not All(True).concat(All(False)).value
    assert not All(False).concat(All(True)).value
    assert not All(False).concat(All(False)).value


# Generated at 2022-06-12 05:29:41.690824
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(10) == Sum(10)


# Generated at 2022-06-12 05:29:42.645456
# Unit test for constructor of class First
def test_First():
    pass  # pragma: no cover


# Generated at 2022-06-12 05:29:47.741123
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(None).concat(First(None)) == First(None)



# Generated at 2022-06-12 05:29:49.519429
# Unit test for constructor of class Last
def test_Last():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-12 05:29:51.193634
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)


# Generated at 2022-06-12 05:29:52.322087
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == "One[value=True]"



# Generated at 2022-06-12 05:29:56.771813
# Unit test for method concat of class Sum
def test_Sum_concat():
    v1 = Sum(1)
    v2 = Sum(2)
    v3 = Sum(4)

    assert v1.concat(v2) == Sum(3)
    assert v2.concat(v3) == Sum(6)
    assert v1.concat(v3) == Sum(5)


# Generated at 2022-06-12 05:31:19.030114
# Unit test for constructor of class Map
def test_Map():
    assert Map({'sum': Sum(1), 'max': Max(10)}).value == {'sum': Sum(1), 'max': Max(10)}



# Generated at 2022-06-12 05:31:20.927026
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-12 05:31:23.418078
# Unit test for method __str__ of class One
def test_One___str__():
    one = One(True)
    assert 'One[value=True]' == one.__str__()


# Generated at 2022-06-12 05:31:25.809942
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)



# Generated at 2022-06-12 05:31:26.809327
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True


# Generated at 2022-06-12 05:31:28.198505
# Unit test for constructor of class Map
def test_Map():
    assert Map({}).concat(Map({})) == Map({})

# Generated at 2022-06-12 05:31:30.062040
# Unit test for constructor of class Map
def test_Map():
    m = Map({'a': Sum(1), 'b': Sum(2)})
    assert isinstance(m, Map)


# Generated at 2022-06-12 05:31:34.964061
# Unit test for constructor of class Map
def test_Map():
    a = Map({'a': Sum(1), 'b': Sum(2)})
    b = Map({'a': Sum(2), 'b': Sum(3)})
    c = Map({'a': Sum(2), 'b': Sum(5)})
    assert a.concat(b) == c

# Generated at 2022-06-12 05:31:38.584024
# Unit test for method concat of class Min
def test_Min_concat():
    min_semigroup_1 = Min(5)
    min_semigroup_2 = Min(2)
    result = min_semigroup_1.concat(min_semigroup_2)
    result.value == 2

# Generated at 2022-06-12 05:31:40.762477
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)

