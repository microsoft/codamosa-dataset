

# Generated at 2022-06-12 05:23:55.479832
# Unit test for method concat of class Map
def test_Map_concat():  # pragma: no cover
    instance1 = Map({ 'k1': Max(10) })
    instance2 = Map({ 'k1': Max(20) })
    assert instance1.concat(instance2) == Map({ 'k1': Max(20) })
    assert Map.neutral().concat(instance2) == Map({ 'k1': Max(20) })

# Generated at 2022-06-12 05:24:00.070429
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(3)).value == 3
    assert Max(3).concat(Max(1)).value == 3
    assert Max(1).concat(Max(1)).value == 1
    assert Max(3).concat(Max(3)).value == 3


# Generated at 2022-06-12 05:24:01.722753
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)


# Generated at 2022-06-12 05:24:06.693564
# Unit test for method concat of class Max
def test_Max_concat():
    # 1. Arrange
    semigroup1 = Max(10)
    semigroup2 = Max(6)

    # 2. Act
    result = semigroup1.concat(semigroup2)

    # 3. Assert
    assert result.value == 10



# Generated at 2022-06-12 05:24:09.469071
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).value == Min(2).concat(Min(1)).value == 1


# Generated at 2022-06-12 05:24:12.120287
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(1)
    b = Min(2)
    assert a.concat(b) == Min(1) 


# Generated at 2022-06-12 05:24:15.009953
# Unit test for method concat of class Map
def test_Map_concat():
    expected = Map({"1": Sum(1), "2": Sum(2)})
    actual = Map({"1": Sum(1)}).concat(Map({"2": Sum(2)}))
    assert expected == actual


# Generated at 2022-06-12 05:24:17.460114
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(10).concat(Max(20)) == Max(20)



# Generated at 2022-06-12 05:24:18.930101
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)

# Generated at 2022-06-12 05:24:24.058164
# Unit test for method concat of class Min
def test_Min_concat():
    print(Min(1).concat(Min(2)))
    assert str(Min(1).concat(Min(2))) == 'Min[value=1]'
    assert str(Min(2).concat(Min(1))) == 'Min[value=1]'
    assert str(Min(2).concat(Min(3))) == 'Min[value=2]'
    assert str(Min(3).concat(Min(2))) == 'Min[value=2]'

# Generated at 2022-06-12 05:24:30.572081
# Unit test for method concat of class Min
def test_Min_concat():
    min_a = Min(1)
    min_b = Min(3)
    min_c = Min(2)

    assert min_a.concat(min_b) == Min(min_a.value)
    assert min_a.concat(min_c) == Min(min_a.value)
    assert min_b.concat(min_c) == Min(min_c.value)



# Generated at 2022-06-12 05:24:32.424443
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)


# Generated at 2022-06-12 05:24:37.307696
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Callback that takes 3 arguments passed to fold
    """
    def callback(arg, arg2, arg3):
        """
        Returns sum of arguments
        """
        return arg + arg2 + arg3

    assert Semigroup(9).fold(callback, 1, 2) == 12
    assert Semigroup(3).fold(callback, 4, 5) == 12



# Generated at 2022-06-12 05:24:39.190422
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-12 05:24:41.132676
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert str(All(True)) == "All[value=True]"



# Generated at 2022-06-12 05:24:44.656115
# Unit test for constructor of class Map
def test_Map():
    map = Map({'hello': Sum(100), 'world': All(True)})
    assert map.value == {'hello': Sum(100), 'world': All(True)}

# Generated at 2022-06-12 05:24:49.469425
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-12 05:24:51.313097
# Unit test for constructor of class One
def test_One():
    one = One(2)
    assert one.value == 2


# Generated at 2022-06-12 05:24:53.583876
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(1)) == Min(1)


# Generated at 2022-06-12 05:24:56.200569
# Unit test for method concat of class Max
def test_Max_concat():
    """
    Test concat method of Max class
    """
    assert Max(2).concat(Max(3)) == Max(3)


# Generated at 2022-06-12 05:25:00.149431
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-12 05:25:05.258871
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-12 05:25:07.358692
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-12 05:25:08.868299
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1



# Generated at 2022-06-12 05:25:13.957057
# Unit test for method concat of class Map
def test_Map_concat():
    semigroup = Map({
        'A': First('a'),
        'B': First('b'),
    })
    other = Map({
        'A': First('A'),
        'B': First('B'),
    })
    result = semigroup.concat(other)
    assert isinstance(result, Map)
    assert result == Map({
        'A': First('a'),
        'B': First('b'),
    })

# Generated at 2022-06-12 05:25:16.367521
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-12 05:25:18.123994
# Unit test for constructor of class One
def test_One():
    assert isinstance(One(1), One)
    assert isinstance(One(False), One)


# Generated at 2022-06-12 05:25:26.195399
# Unit test for method concat of class Min
def test_Min_concat():
    x = Min(5)
    y = Min(4)
    assert x.concat(y).value == 4
    assert y.concat(x).value == 4

    x = Min(5)
    y = Min(5)
    assert x.concat(y).value == 5
    assert y.concat(x).value == 5

    x = Min(float("inf"))
    y = Min(5)
    assert x.concat(y).value == 5
    assert y.concat(x).value == 5

    x = Min(float("inf"))
    y = Min(float("inf"))
    assert x.concat(y).value == float("inf")
    assert y.concat(x).value == float("inf")



# Generated at 2022-06-12 05:25:28.450508
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).value == 1
    assert Min(3).concat(Min(4)).value == 3
    assert Min(1).concat(Min(4)).value == 1


# Generated at 2022-06-12 05:25:34.154301
# Unit test for constructor of class Map
def test_Map():
    # Given
    key = "key"
    value = 1
    dict_1 = {key: value}
    dict_2 = {key: Sum(value)}
    # When
    map_1 = Map(dict_1)
    map_2 = Map(dict_2)
    # Then
    assert (value == eval(repr(map_1)))
    assert (dict_2 == eval(repr(map_2)))


# Generated at 2022-06-12 05:25:37.909743
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert Sum(1) == Sum(1)



# Generated at 2022-06-12 05:25:38.982416
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1)



# Generated at 2022-06-12 05:25:41.264192
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)



# Generated at 2022-06-12 05:25:46.170642
# Unit test for constructor of class Map
def test_Map():
    """
    Unit test for constructor of class Map.
    """
    map = Map({"key": Max(5), "key2": Min(100)})

    assert isinstance(map, Map)
    assert map.value["key"] == Max(5)
    assert map.value["key2"] == Min(100)


# Generated at 2022-06-12 05:25:48.368940
# Unit test for constructor of class Semigroup
def test_Semigroup():
    semigroup = Semigroup(2)

    assert isinstance(semigroup, Semigroup)



# Generated at 2022-06-12 05:25:50.140818
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(True).__str__() == 'One[value=True]'


# Generated at 2022-06-12 05:25:51.494497
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(5)) == 'Sum[value=5]'


# Generated at 2022-06-12 05:25:53.150313
# Unit test for constructor of class Semigroup
def test_Semigroup():
    # create a new semigroup with a value
    assert Semigroup(1).value == 1


# Generated at 2022-06-12 05:25:55.407865
# Unit test for method concat of class Max
def test_Max_concat():
    max_of_three = Max(3).concat(Max(4)).concat(Max(5))  # => Max[value=5]

    assert max_of_three == Max(5)



# Generated at 2022-06-12 05:26:01.836423
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(False)) == 'One[value=False]'
    assert str(One(0)) == 'One[value=0]'
    assert str(One(True)) == 'One[value=True]'
    assert str(One(-1)) == 'One[value=-1]'
    assert str(One(1)) == 'One[value=1]'

test_One___str__()



# Generated at 2022-06-12 05:26:10.355314
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Sum(10) == Sum(10)
    assert Sum(10) != Sum(11)
    assert All(True)
    assert not All(False)
    assert One(True)
    assert not One(False)
    assert First(10) == First(10)
    assert First(10) != First(11)
    assert Last(10) == Last(10)
    assert Last(10) != Last(11)
    assert Map({'a': Sum(1), 'b': Sum(2)}) == Map({'a': Sum(1), 'b': Sum(2)})
    assert Max(10) == Max(10)
    assert Max(10) != Max(11)
    assert Min(10) == Min(10)
    assert Min(10) != Min(9)


# Generated at 2022-06-12 05:26:14.825924
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    unit test for fold method of class Semigroup
    """

    fn = lambda value: value + 10
    assert Semigroup(5).fold(fn) == 15

    fn = lambda value: value * 10
    assert Semigroup(5).fold(fn) == 50



# Generated at 2022-06-12 05:26:16.341715
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)

# Unit test of the method neutral

# Generated at 2022-06-12 05:26:17.721541
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert(str(Max(3)) == "Max[value=3]")


# Generated at 2022-06-12 05:26:23.250536
# Unit test for method concat of class First
def test_First_concat():
    """
    This function tests the method concat of class First
    """
    first1 = First(4)
    first2 = First(5)
    result = first1.concat(first2)
    expected = First(4)
    assert result == expected, "error"


# Generated at 2022-06-12 05:26:28.948456
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(0).concat(Min(2)) == Min(0)
    assert Min(0).concat(Min(0)) == Min(0)
    assert Min(2).concat(Min(0)) == Min(0)
    assert Min(2).concat(Min(2)) == Min(2)

# Generated at 2022-06-12 05:26:30.282768
# Unit test for constructor of class First
def test_First():
    assert First(1)



# Generated at 2022-06-12 05:26:32.086080
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last("a")) == "Last[value=a]"


# Generated at 2022-06-12 05:26:33.752822
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)


# Generated at 2022-06-12 05:26:35.549116
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum_ = Sum(1)
    assert str(sum_) == 'Sum[value=1]'


# Generated at 2022-06-12 05:26:49.412333
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert isinstance(All(True), All)
    assert isinstance(Sum(111), Sum)
    assert isinstance(One(True), One)
    assert isinstance(First('Hello'), First)
    assert isinstance(Last('Hello'), Last)
    assert isinstance(Map({'a': Sum(1)}), Map)
    assert isinstance(Max(1), Max)
    assert isinstance(Min(7), Min)
    assert One(True).value == True
    assert All(True).value == True
    assert Sum(111).value == 111
    assert First('Hello').value == 'Hello'
    assert Last('Hello').value == 'Hello'
    assert Map({'a': Sum(1)}).value == {'a': Sum(1)}
    assert Max(1).value == 1
    assert Min(7).value == 7


# Generated at 2022-06-12 05:26:55.817608
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First('a')) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(None).concat(First('a')) == First(None)
    assert First(1).concat(First(None)) == First(1)
    assert First('a').concat(First(None)) == First('a')


# Generated at 2022-06-12 05:27:00.109898
# Unit test for method __str__ of class First
def test_First___str__():
    """
    test_First___str__
    """
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First('1')) == "Fist[value=1]"
    assert str(First({'a': 1})) == "Fist[value={'a': 1}]"


# Generated at 2022-06-12 05:27:03.884282
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)).value == 2
    assert Last(1).concat(Last(2)).value == Last(1).concat(Last(2)).value


# Generated at 2022-06-12 05:27:08.431200
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Test for Semigroup.fold
    """

    result1 = Sum(4).fold(lambda number: number ** 2)
    assert result1 == 16

    result2 = First(4).fold(lambda number: number ** 2)
    assert result2 == 4



# Generated at 2022-06-12 05:27:14.230509
# Unit test for method concat of class Map
def test_Map_concat():
    init_Map = Map({1: Sum(1), 2: Sum(2), 3: Sum(3)})
    concated_Map = Map({1: Sum(1), 2: Sum(2), 3: Sum(3)})
    assert init_Map.concat(concated_Map) == Map({1: Sum(2), 2: Sum(4), 3: Sum(6)})

# Generated at 2022-06-12 05:27:15.836953
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'



# Generated at 2022-06-12 05:27:18.234756
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-12 05:27:22.307574
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    istanbul cover test/monoids.py
    """
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(2).concat(Sum(1)) == Sum(3)


# Generated at 2022-06-12 05:27:25.620555
# Unit test for method __str__ of class Max
def test_Max___str__():
    import random
    value = random.random()
    max_ = Max(value)
    assert max_.__str__() == 'Max[value={}]'.format(value)


# Generated at 2022-06-12 05:27:30.230856
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(0)) == 'Max[value=0]'


# Generated at 2022-06-12 05:27:32.193774
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'foo': 1})) == "Map[value={'foo': 1}]"



# Generated at 2022-06-12 05:27:35.932850
# Unit test for constructor of class Sum
def test_Sum():
    sum_1 = Sum(1)
    sum_2 = Sum(2)

    assert sum_1 == Sum(1)
    assert sum_2 == Sum(2)

    assert sum_1.value == 1
    assert sum_2.value == 2



# Generated at 2022-06-12 05:27:38.060285
# Unit test for method __str__ of class Last
def test_Last___str__(): # pragma: no cover
    str(Last(1)) == 'Last[value=1]'



# Generated at 2022-06-12 05:27:41.072561
# Unit test for method concat of class One
def test_One_concat():
    one = One(True)
    assert one.concat(One(False)) == One(True)
    assert one.concat(One(True)) == One(True)



# Generated at 2022-06-12 05:27:43.981696
# Unit test for method __str__ of class Map
def test_Map___str__():
    result = Map({"a": 1, "b": 2})
    assert str(result) == "Map[value={'a': 1, 'b': 2}]"


# Generated at 2022-06-12 05:27:45.701623
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'



# Generated at 2022-06-12 05:27:49.668722
# Unit test for constructor of class Map
def test_Map():
    assert Map({}).value == {}
    assert Map("abc").value == "abc"
    assert Map("abc").value == "abc"
    assert Map("aaa").value == "aaa"
    assert Map("aba").value == "aba"



# Generated at 2022-06-12 05:27:52.081292
# Unit test for method __str__ of class Min
def test_Min___str__():
    actual = str(Min(7))
    expected = "Min[value=7]"
    assert actual == expected


# Generated at 2022-06-12 05:27:53.978731
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-12 05:28:06.650096
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(5).fold(lambda x: x+1) == 6
    assert All(True).fold(lambda x: x*2) == 2
    assert One(False).fold(lambda x: x+1) == 1
    assert First('N.e.m').fold(lambda x: x+'o') == 'N.e.m'
    assert Last('N.e.m').fold(lambda x: x+'o') == 'o'


# Generated at 2022-06-12 05:28:16.118766
# Unit test for method concat of class Map
def test_Map_concat():  # pragma: no cover
    """
    Testing for cuncat method in Map class
    """

    map_a = Map({'a': First(1), 'b': All(True), 'c': Sum(10),
                 'd': Min(10.1), 'e': Max(10.0)})
    map_b = Map({'a': First(1), 'b': All(True), 'c': Sum(20),
                 'd': Min(10.0), 'e': Max(9.0)})

    map_result = Map({'a': First(1), 'b': All(True), 'c': Sum(30),
                      'd': Min(10.0), 'e': Max(10.0)})

    assert map_result == map_a.concat(map_b)

# Generated at 2022-06-12 05:28:18.021962
# Unit test for method concat of class All
def test_All_concat():
    semigroup = All(True).concat(All(False))
    assert str(semigroup) == "All[value=False]"


# Generated at 2022-06-12 05:28:19.513431
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-12 05:28:22.483986
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(-1).concat(Min(-3)).value == -3
    assert Min(-1).concat(Min(-1)).value == -1
    assert Min(-1).concat(Min(2)).value == -1



# Generated at 2022-06-12 05:28:24.521174
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(4) == Sum(4)
    assert Sum(4).value == 4



# Generated at 2022-06-12 05:28:28.854906
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(5).concat(Min(10)).value == Min(5).value
    assert Min(5).concat(Min(3)).value == Min(3).value
    assert Min(5).concat(Min(5)).value == Min(5).value
    assert Min(5).concat(Min(4)).value == Min(4).value


# Generated at 2022-06-12 05:28:35.270362
# Unit test for method concat of class One
def test_One_concat():
    """
    test One concat
    """
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(False)) == One(True)
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-12 05:28:40.511369
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)).value == 1
    assert First(1).concat(First('1')).value == 1
    assert First(1).concat(First(True)).value == 1
    assert First(1).concat(First([1])).value == 1
    assert First(1).concat(First(('1', ))).value == 1



# Generated at 2022-06-12 05:28:45.111770
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-12 05:29:03.045740
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1)}).concat(Map({'a': Sum(1)})).value == {'a': Sum(2)}
    assert Map({'a': Sum(0)}).concat(Map({'a': Sum(1)})).value == {'a': Sum(1)}
    assert Map({'a': Sum(1)}).concat(Map({'a': Sum(0)})).value == {'a': Sum(1)}
    assert Map({'a': All(False)}).concat(Map({'a': All(False)})).value == {'a': All(False)}
    assert Map({'a': All(False)}).concat(Map({'a': All(True)})).value == {'a': All(False)}

# Generated at 2022-06-12 05:29:05.072488
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-12 05:29:06.486164
# Unit test for constructor of class Sum
def test_Sum():
    assert 10 == Sum(10).value

# Unit test instance of Sum

# Generated at 2022-06-12 05:29:11.816022
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False
    assert All(1).value == True
    assert All(0).value == False
    assert All('').value == False
    assert All([1, 2]).value == True
    assert All([]).value == False


# Generated at 2022-06-12 05:29:15.494822
# Unit test for method concat of class Max
def test_Max_concat():
    x = Max(324.89)
    y = Max(234.45)
    z = Max(914.73)
    assert x.concat(y).concat(z).value == 914.73


# Generated at 2022-06-12 05:29:19.361598
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)
    assert Min(1).value == 1
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)

# Generated at 2022-06-12 05:29:22.507170
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    assert Semigroup("str").fold(lambda x: x + "ing") == "string"



# Generated at 2022-06-12 05:29:24.179872
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First("A")) == "Fist[value=A]"


# Generated at 2022-06-12 05:29:29.002282
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)).equals(Sum(3))
    assert Sum(None).concat(Sum(2)).equals(Sum(2))
    assert Sum(1).concat(Sum(None)).equals(Sum(1))


# Generated at 2022-06-12 05:29:32.109518
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(False) != All(True)
    assert All(True) != All(False)    


# Generated at 2022-06-12 05:29:59.698268
# Unit test for method concat of class Min
def test_Min_concat():
    s1 = Min(1)
    s2 = Min(2)
    s3 = s1.concat(s2)
    assert s3 == Min(1)
    s4 = Min(-1)
    s5 = s3.concat(s4)
    assert s5 == Min(-1)

# Generated at 2022-06-12 05:30:01.970778
# Unit test for constructor of class All
def test_All():
    assert All(1) == All(1)


# Generated at 2022-06-12 05:30:02.943299
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1



# Generated at 2022-06-12 05:30:05.341022
# Unit test for constructor of class One
def test_One():
    assert One(1)
    assert One(0)
    assert One(False)
    assert One(True)


# Generated at 2022-06-12 05:30:06.606627
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'



# Generated at 2022-06-12 05:30:08.090169
# Unit test for method __str__ of class First
def test_First___str__(): # pragma: no cover
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-12 05:30:13.549304
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    """
    >>> @dataclasses.dataclass
    ... class MyValue(Semigroup):
    ...     value: int
    ...     @classmethod
    ...     def neutral(cls):
    ...         return cls(0)
    ...
    >>> MyValue(123)
    MyValue(value=123)
    """



# Generated at 2022-06-12 05:30:14.465866
# Unit test for method __str__ of class All
def test_All___str__():
    assert All(0).__str__() == "All[value=0]"

# Generated at 2022-06-12 05:30:15.721339
# Unit test for constructor of class First
def test_First():
    assert First(5) == First(5)


# Generated at 2022-06-12 05:30:17.797609
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'



# Generated at 2022-06-12 05:30:47.117941
# Unit test for method concat of class First
def test_First_concat():
    # GIVEN
    semigroup_1 = First(1)
    semigroup_2 = First("250")

    # WHEN
    result = semigroup_1.concat(semigroup_2)

    # THEN
    assert semigroup_1 == First(1)
    assert semigroup_2 == First("250")
    assert result == First(1)


# Generated at 2022-06-12 05:30:48.731720
# Unit test for constructor of class Semigroup
def test_Semigroup():
    s = Semigroup(1)
    assert isinstance(s, Semigroup)


# Generated at 2022-06-12 05:30:50.114803
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x + 1) == 2

# Generated at 2022-06-12 05:31:01.832301
# Unit test for method concat of class One
def test_One_concat():
    left = One(True)
    right = One(False)
    actual = left.concat(right)
    expected = One(True)
    assert actual == expected,\
        "Test One concat with true, false failed, expected {}, got {}".format(expected, actual)

    left = One(False)
    right = One(True)
    actual = left.concat(right)
    expected = One(True)
    assert actual == expected,\
        "Test One concat with false, true failed, expected {}, got {}".format(expected, actual)

    left = One(False)
    right = One(False)
    actual = left.concat(right)
    expected = One(False)

# Generated at 2022-06-12 05:31:07.966486
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(10).fold(lambda x: x + 1) == 11
    assert Semigroup("aaa").fold(lambda x: x + "bbb") == "aaabbb"
    assert Semigroup([1, 2, 3]).fold(lambda x: x + [4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert Semigroup({"a": "AAA", "b": "BBB"}).fold(lambda x: x) == {"a": "AAA", "b": "BBB"}


# Generated at 2022-06-12 05:31:11.591980
# Unit test for method concat of class One
def test_One_concat():
    one1 = One(True)
    one2 = One(False)
    assert one1.concat(one2) == One(True)
    assert one2.concat(one1) == One(True)


# Generated at 2022-06-12 05:31:15.277961
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)


# Generated at 2022-06-12 05:31:18.373210
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(4).concat(Min(2)) == Min(2)
    assert Min(-2).concat(Min(-5)) == Min(-5)

print("test_Min_concat ran successfully")


# Generated at 2022-06-12 05:31:20.797062
# Unit test for constructor of class Last
def test_Last():
    r = Last(5)
    assert isinstance(r, Last) and r.value == 5


# Generated at 2022-06-12 05:31:23.661563
# Unit test for constructor of class Min
def test_Min():
    min = Min(1)
    assert min.value == 1
    assert min.neutral_element == float("inf")


# Generated at 2022-06-12 05:32:22.294528
# Unit test for method concat of class Map
def test_Map_concat():
    """
    test for method concat with simple value and map
    """
    first_map = Map({'a': First('a'), 'b': First('b')})
    second_map = Map({'a': First('c'), 'b': First(None)})
    result = first_map.concat(second_map)
    assert_equal(result.value['a'].value, 'a')
    assert_equal(result.value['b'].value, 'b')
    assert_equal(type(result), Map)

test_Map_concat()

# Generated at 2022-06-12 05:32:28.727836
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({'a': Sum(1), 'b': Sum(2)})
    m2 = Map({'a': Sum(1), 'b': Sum(2)})
    m3 = m1.concat(m2)
    assert isinstance(m3, Map)
    assert m3 == Map({'a': Sum(2), 'b': Sum(4)})

# Generated at 2022-06-12 05:32:33.302369
# Unit test for constructor of class Map
def test_Map():
    map_semigroup = Map({
        Max: Sum(1),
        Sum: Sum(2)
    })
    assert map_semigroup.value == {
        Max: Sum(1),
        Sum: Sum(2)
    }

# Generated at 2022-06-12 05:32:34.717277
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)).value == 1



# Generated at 2022-06-12 05:32:38.846961
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)
    assert Semigroup(1) == Semigroup(2)
    assert not Semigroup(1) == Semigroup(3)
    assert Semigroup(2) == Semigroup(3)
    assert not Semigroup(1) == Semigroup(4)
    assert not Semigroup(2) == Semigroup(4)
    assert Semigroup(3) == Semigroup(4)
    assert not Semigroup(1) == Semigroup(5)
    assert not Semigroup(2) == Semigroup(5)
    assert not Semigroup(3) == Semigroup(5)
    assert Semigroup(4) == Semigroup(5)


# Generated at 2022-06-12 05:32:40.904816
# Unit test for method concat of class One
def test_One_concat():
    one = One(True)
    other = One(True)
    expected = One(True)
    assert one.concat(other) == expected



# Generated at 2022-06-12 05:32:45.566626
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(1)
    b = Min(3)
    c = Min(2)
    d = Min(4)
    e = Min(0)

    assert a.concat(b).concat(c).concat(d).concat(e).value == e.value



# Generated at 2022-06-12 05:32:48.483406
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert str(Semigroup(10)) == 'Semigroup[value=10]'


# Generated at 2022-06-12 05:32:50.522787
# Unit test for method concat of class First
def test_First_concat():
    f = First(2)
    assert f.concat(First(3)) == First(2)



# Generated at 2022-06-12 05:32:54.859166
# Unit test for constructor of class Map
def test_Map():
    data = {
        "key1": Sum(1),
        "key2": First('a'),
        "key3": Last('b'),
        "key4": All(True),
        "key5": All(False),
    }

    instance = Map(data)
    assert instance.value == data
    assert str(instance) == 'Map[value={'
    assert str(instance) == 'Map[value={'

