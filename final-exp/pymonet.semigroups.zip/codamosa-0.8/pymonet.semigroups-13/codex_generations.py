

# Generated at 2022-06-12 05:24:02.074482
# Unit test for method concat of class Map
def test_Map_concat():
    """
    :returns: True
    :rtype: bool
    """
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b':Sum(4)})).value['b'].value == 6, 'should be equal to 6'
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b':Sum(4)})).value['a'].value == 4, 'should be equal to 4'
    return True

# Generated at 2022-06-12 05:24:11.412477
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = {'a': Sum(1), 'b': Sum(2)}
    m2 = {'a': Sum(2), 'b': Sum(3)}

    res = Map(m1).concat(Map(m2))

    m3 = {'a': Sum(3), 'b': Sum(5)}

    assert m3 == res.value
    assert res.value['a'] == m3['a']
    assert res.value['b'] == m3['b']
    assert res.value['a'] == Sum(3)
    assert res.value['b'] == Sum(5)



# Generated at 2022-06-12 05:24:15.844078
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map({'a': Sum(1), 'b': Sum(2)})
    map2 = Map({'a': Sum(3), 'b': Sum(4)})
    assert map1.concat(map2) == Map({'a': Sum(4), 'b': Sum(6)})



# Generated at 2022-06-12 05:24:19.000125
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map({'a': Sum(1)})
    map2 = Map({'a': Sum(2)})

    map_concat = map1.concat(map2)

    assert isinstance(map_concat, Map)
    assert map_concat.value == {'a': Sum(3)}

# Generated at 2022-06-12 05:24:24.922316
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({
        'a': Sum(1),
        'b': Sum(2),
        'c': Sum(3),
    })
    m2 = Map({
        'a': Sum(4),
        'b': Sum(5),
        'c': Sum(6),
    })
    expected = Map({
        'a': Sum(5),
        'b': Sum(7),
        'c': Sum(9),
    })
    actual = m1.concat(m2)
    assert expected == actual


# Generated at 2022-06-12 05:24:28.797803
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"a": First("hello"), "b": First("world")})\
        .concat(Map({"a": Last("!"), "b": First("!")}))\
        .value == {"a": "hello", "b": "world!"}

# Generated at 2022-06-12 05:24:32.418837
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'1': Sum(1), '2': First('foo')}).concat(
        Map({'1': Sum(1), '2': First('bar')})
    ).concat(
        Map({'1': Sum(1), '2': First('baz')})
    ).value == {'1': Sum(3), '2': First('foo')}



# Generated at 2022-06-12 05:24:37.809470
# Unit test for method concat of class Map
def test_Map_concat():
    # Given:
    map1 = Map({'a': Sum(1), 'b': Sum(2)})
    map2 = Map({'a': Sum(3), 'b': Sum(4)})

    # When:
    result = map1.concat(map2)

    # Then:
    assert result.value['a'] == Sum(4)
    assert result.value['b'] == Sum(6)


# Generated at 2022-06-12 05:24:42.972667
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map({1: All(True), 2: All(True)})
    map2 = Map({1: All(False), 2: All(True)})

    result = map1.concat(map2)
    expected = Map({1: All(False), 2: All(True)})

    assert result == expected

# Generated at 2022-06-12 05:24:49.917037
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({}).concat(Map({})) == Map({})
    assert Map({}).concat(Map({'a': Sum(0)})) == Map({'a': Sum(0)})
    assert Map({'a': Sum(0)}).concat(Map({})) == Map({'a': Sum(0)})
    assert Map({'a': Sum(0)}).concat(Map({'a': Sum(1)})) == Map({'a': Sum(1)})


# Generated at 2022-06-12 05:24:53.733081
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert Min(3).__str__() == 'Min[value=3]'


# Generated at 2022-06-12 05:24:55.562529
# Unit test for constructor of class Min
def test_Min():
    min = Min(1)
    assert min.value == 1


# Generated at 2022-06-12 05:24:58.653907
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(3).concat(Max(3)) == Max(3)
    assert Max(4).concat(Max(5)) == Max(5)


# Generated at 2022-06-12 05:25:01.148406
# Unit test for method concat of class Max
def test_Max_concat():
    """ Unit test for method concat of class Max """
    assert Max(1).concat(Max(2)) == Max(2)



# Generated at 2022-06-12 05:25:03.303785
# Unit test for method concat of class Min
def test_Min_concat():
    minSum = Min(2).concat(Min(1))

    assert minSum == Min(1)


# Generated at 2022-06-12 05:25:05.917936
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1)}).concat(Map({'a': Sum(2)})).value.items() == Map({'a': Sum(3)}).value.items()

# Generated at 2022-06-12 05:25:08.568978
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(10), 'b': Sum(1000)})) == "Map[value={'a': Sum[value=10], 'b': Sum[value=1000]}]"


# Generated at 2022-06-12 05:25:10.916742
# Unit test for method __str__ of class Last
def test_Last___str__():
    lst = Last(value=10)
    assert lst.__str__() == 'Last[value=10]'


# Generated at 2022-06-12 05:25:13.365577
# Unit test for method concat of class Min
def test_Min_concat():
    first = Min(10)
    second = Min(8)
    third = first.concat(second)

    assert third.value == 8


# Generated at 2022-06-12 05:25:16.994027
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-12 05:25:22.216998
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-12 05:25:24.113399
# Unit test for method __str__ of class Map
def test_Map___str__():  # pragma: no cover
    assert str(Map({1: All(True), 2: All(False)})) == "Map[value={1: All[value=True], 2: All[value=False]}]"



# Generated at 2022-06-12 05:25:26.853619
# Unit test for constructor of class Semigroup
def test_Semigroup():
    a = Semigroup(3)
    b = Semigroup(5)
    assert a.fold(lambda x: x) == 3
    assert a.fold(lambda x: x) != b.fold(lambda x: x)


# Generated at 2022-06-12 05:25:28.669429
# Unit test for constructor of class First
def test_First():
    assert First(1).concat(First(2)) == First(1)
    assert First(2).concat(First(1)).value == 2



# Generated at 2022-06-12 05:25:33.085825
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)



# Generated at 2022-06-12 05:25:34.684910
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(False)) == 'One[value=False]'



# Generated at 2022-06-12 05:25:39.410199
# Unit test for constructor of class Min
def test_Min():
    m = Min(4)

    if m.value == 4:
        print('Test for Min: OK')
    else:
        print('Test for Min: Failed')
    if m.neutral_element == float('inf'):
        print('Test for Min: OK')
    else:
        print('Test for Min: Failed')


# Generated at 2022-06-12 05:25:41.263822
# Unit test for constructor of class Last
def test_Last():
    assert Last(10) == Last(10)



# Generated at 2022-06-12 05:25:43.236136
# Unit test for constructor of class Max
def test_Max():
    assert Max(3) == Max(3)
    assert Max(3).concat(Max(2)) == Max(3)


# Generated at 2022-06-12 05:25:44.890636
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(10) == Sum(10)



# Generated at 2022-06-12 05:25:55.131737
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    In mathematics, a semigroup is an algebraic structure
    consisting of a set together with an associative binary operation.
    A semigroup generalizes a monoid in that there might not exist an identity element.
    It also (originally) generalized a group (a monoid with all inverses)
    to a type where every element did not have to have an inverse, this the name semigroup.
    """
    a = Sum(4)
    assert type(a) == Sum
    assert a.value == 4
    b = Sum(5)
    assert type(b) == Sum
    assert b.value == 5
    b = Sum(5)
    assert type(b) == Sum
    assert b.value == 5



# Generated at 2022-06-12 05:26:00.990477
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-12 05:26:06.885585
# Unit test for constructor of class Map
def test_Map():
    m1 = Map({
        'first': Sum(1),
        'second': Min(2)
    })
    m2 = Map({
        'first': Sum(2),
        'third': Max(3)
    })
    m3 = Map({
        'first': Sum(3),
        'second': Min(4)
    })
    assert m1.concat(m2).concat(m3) == Map({
        'first': Sum(6),
        'second': Min(2),
        'third': Max(3)
    })


# Generated at 2022-06-12 05:26:08.460798
# Unit test for method __str__ of class Max
def test_Max___str__():
    x = Max(1)
    assert str(x) == 'Max[value=1]'


# Generated at 2022-06-12 05:26:10.755288
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)


# Generated at 2022-06-12 05:26:13.334743
# Unit test for constructor of class Last
def test_Last():
    last = Last(True)
    assert last.value == True
    assert str(last) == 'Last[value=True]'



# Generated at 2022-06-12 05:26:16.821090
# Unit test for method __str__ of class Map
def test_Map___str__():  # pragma: no cover
    assert str(Map({"a": Sum(1), "b": Sum(2)})) == "Map[value={'a': Sum[value=1], 'b': Sum[value=2]}]"



# Generated at 2022-06-12 05:26:21.127401
# Unit test for constructor of class One
def test_One():
    instance = One(1)
    assert instance.value == 1, f"error in One.__init__()"
    assert str(instance) == "One[value=1]", f"error in One.__str__()"


# Generated at 2022-06-12 05:26:30.339889
# Unit test for method concat of class Min
def test_Min_concat():
    # Test with positive numbers
    assert Min(0).concat(Min(-2)) == Min(-2)
    assert Min(0).concat(Min(2)) == Min(0)
    assert Min(-1).concat(Min(2)) == Min(-1)
    assert Min(3).concat(Min(2)) == Min(2)
    # Test with negative numbers
    assert Min(-1).concat(Min(-2)) == Min(-2)
    assert Min(-4).concat(Min(-2)) == Min(-2)
    assert Min(-1).concat(Min(-4)) == Min(-4)
    # Test with zero
    assert Min(0).concat(Min(0)) == Min(0)
    assert Min(0).concat(Min(-4)) == Min(-4)
    assert Min(0).concat

# Generated at 2022-06-12 05:26:34.022361
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    # Given
    sum_value = Sum(1)
    # When
    sum_str = str(sum_value)
    # Then
    assert 'Sum[value=1]' == sum_str


# Generated at 2022-06-12 05:26:37.308937
# Unit test for method concat of class First
def test_First_concat():  # pragma: no cover
    assert str(First("1").concat(First("2"))) == "Fist[value=1]"


# Generated at 2022-06-12 05:26:38.782681
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(False)) == 'One[value=False]'



# Generated at 2022-06-12 05:26:40.206711
# Unit test for constructor of class Sum
def test_Sum():
    assert str(Sum(1)) == 'Sum[value=1]'

# Generated at 2022-06-12 05:26:43.440091
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)  # Test for equal
    assert Max(1) != Max(2)  # Test for not equal


# Generated at 2022-06-12 05:26:54.054084
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert not Sum(1) == Sum(2)
    assert Sum(2) == Sum(2)
    assert not All(True) == All(False)
    assert All(True) == All(True)
    assert not One(True) == One(False)
    assert One(True) == One(True)
    assert not First(0) == First(1)
    assert First(1) == First(1)
    assert not Last(0) == Last(1)
    assert Last(1) == Last(1)
    assert not Map({'a': First(0)}) == Map({'b': First(1)})
    assert Map({'a': First(1)}) == Map({'a': First(1)})
    assert not Max(1) == Max(2)
    assert Max(2) == Max(2)



# Generated at 2022-06-12 05:26:58.830178
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({'a': Sum(2), 'b': Sum(3)})
    m2 = Map({'a': Sum(1), 'b': Sum(2)})
    assert m1.concat(m2) == Map({'a': Sum(3), 'b': Sum(5)})



# Generated at 2022-06-12 05:27:01.515990
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(3).concat(Min(4)) == Min(3)

# Generated at 2022-06-12 05:27:04.707859
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_1 = Sum(1)
    sum_2 = Sum(2)
    assert sum_1.concat(sum_2) == Sum(3)



# Generated at 2022-06-12 05:27:09.044404
# Unit test for method __str__ of class Map
def test_Map___str__():  # pragma: no cover
    """
    Unit test for method __str__ of class Map
    """
    assert str(Map({'a': 1, 'b': 2})) == 'Map[value={a: 1, b: 2}]'



# Generated at 2022-06-12 05:27:10.589555
# Unit test for method __str__ of class One
def test_One___str__():
    test_value = One(False)
    assert(str(test_value) == "One[value=False]")


# Generated at 2022-06-12 05:27:15.557000
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First('a')) == 'Fist[value=a]'


# Generated at 2022-06-12 05:27:19.435714
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1.0)) == 'Max[value=1.0]'
    assert str(Max(2.0)) == 'Max[value=2.0]'


# Generated at 2022-06-12 05:27:21.968899
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'



# Generated at 2022-06-12 05:27:25.697696
# Unit test for method concat of class First
def test_First_concat():
    """Unit test for method concat of class First"""

    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(1)) == First(1)



# Generated at 2022-06-12 05:27:28.097731
# Unit test for constructor of class Sum
def test_Sum():
    sum = Sum(1)
    assert sum.value == 1
    assert sum == Sum(1)
    assert sum != Sum(2)



# Generated at 2022-06-12 05:27:29.875140
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(2)) == "Min[value=2]"


# Generated at 2022-06-12 05:27:31.308380
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)



# Generated at 2022-06-12 05:27:32.495148
# Unit test for constructor of class Min
def test_Min():
    assert Min(1).value == 1


# Generated at 2022-06-12 05:27:34.236302
# Unit test for constructor of class One
def test_One():
    with pytest.raises(TypeError): One()


# Generated at 2022-06-12 05:27:38.367470
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(3).concat(Min(2)) == Min(2)
    assert Min(3).concat(Min(3)) == Min(3)

# Generated at 2022-06-12 05:27:44.112747
# Unit test for method concat of class First
def test_First_concat():
    assert First("").concat(First("a")).value == "a"
    assert First("a").concat(First("b")).value == "a"


# Generated at 2022-06-12 05:27:45.379375
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)


# Generated at 2022-06-12 05:27:50.167288
# Unit test for method concat of class Sum
def test_Sum_concat():  # pragma: no cover
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(3).concat(Sum(4)) == Sum(7)
    assert Sum(2).concat(Sum(3)).concat(Sum(4)) == Sum(9)


# Generated at 2022-06-12 05:27:52.370510
# Unit test for constructor of class Min
def test_Min():
    num1 = Min(1)
    num2 = Min(2)
    assert num1.value == 1
    assert num2.value == 2


# Generated at 2022-06-12 05:27:55.727602
# Unit test for method concat of class First
def test_First_concat():  # pragma: no cover
    """
    Unit test for method concat of class First
    """
    first = First(42)
    second = First(1)
    assert first.concat(second) == First(42)



# Generated at 2022-06-12 05:27:58.692998
# Unit test for method __str__ of class Max
def test_Max___str__():
    """
    Test for method __str__ of class Max.
    """
    expected = 'Max[value=2.2]'
    actual = str(Max(2.2))
    assert expected == actual



# Generated at 2022-06-12 05:28:01.056907
# Unit test for constructor of class First
def test_First():
    a = First(3)
    b = First('a')
    assert a == First(3)
    assert b == First('a')


# Generated at 2022-06-12 05:28:05.309828
# Unit test for method concat of class Min
def test_Min_concat():
    min1 = Min(1)
    min2 = Min(2)
    concat = min1.concat(min2)
    assert concat == min1
    assert concat.value == min1.value
    assert concat.value == 1



# Generated at 2022-06-12 05:28:07.370239
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-12 05:28:11.594305
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"


# Generated at 2022-06-12 05:28:20.918825
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert Sum(10) == Sum(10)
    assert Sum(10) != Sum(20)

    assert Sum(10).value == 10
    assert Sum(10).value != 20



# Generated at 2022-06-12 05:28:25.361833
# Unit test for constructor of class Map
def test_Map():
    m = Map({'a': Sum(1), 'b': Sum(2)})
    assert m
    assert m.value == {'a': Sum(1), 'b': Sum(2)}


# Generated at 2022-06-12 05:28:26.399069
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(100)) == "Max[value=100]"



# Generated at 2022-06-12 05:28:30.150473
# Unit test for method concat of class Last
def test_Last_concat():
    last1 = Last(4)
    last2 = Last(5)
    concated = last1.concat(last2)
    assert concated.value == 5



# Generated at 2022-06-12 05:28:31.715271
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(13)) == 'Fist[value=13]'


# Generated at 2022-06-12 05:28:40.688962
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(-inf).concat(Max(-inf)) == Max(-inf)
    assert Max(-inf).concat(Max(1)) == Max(1)
    assert Max(1).concat(Max(-inf)) == Max(1)
    assert Max(1).concat(Max(1)) == Max(1)
    assert Max(1).concat(Max(5)) == Max(5)
    assert Max(5).concat(Max(1)) == Max(5)
    assert Max(10).concat(Max(5)) == Max(10)
    assert Max(5).concat(Max(10)) == Max(10)


# Generated at 2022-06-12 05:28:42.046235
# Unit test for method __str__ of class All
def test_All___str__():
    assert 'All[value=True]' == str(All(True))



# Generated at 2022-06-12 05:28:44.516848
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'
    assert isinstance(str(Sum(1)), str)


# Generated at 2022-06-12 05:28:56.392392
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x + 1) == 2
    assert All(True).fold(lambda x: not x) is False
    assert (First(100).fold(lambda x: x + 1)) == 100
    assert (Last(100).fold(lambda x: x + 1)) == 101
    # Map, Max and Min tests
    map_first = Map(
        {
            'key1': First(12),
            'key2': First(9),
            'key3': First(4)
        }
    )
    map_first = map_first.fold(lambda x: x)
    map_last = Map(
        {
            'key1': Last(12),
            'key2': Last(9),
            'key3': Last(4)
        }
    )
    map_last = map

# Generated at 2022-06-12 05:28:58.901456
# Unit test for constructor of class One
def test_One():
    assert One(False) == One(False)
    assert One(True) == One(True)
    assert One.neutral() == One(False)



# Generated at 2022-06-12 05:29:13.515185
# Unit test for method __str__ of class Min
def test_Min___str__():
    """
    test_Min___str__
    """
    assert 'Min[value=22]' == str(Min(22))


# Generated at 2022-06-12 05:29:21.092697
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Unit test for method fold of class Semigroup
    """

    identity = lambda x: x
    assert Sum(10).fold(identity) == 10
    assert All(True).fold(identity) == All(True).value
    assert One(False).fold(identity) == One(False).value
    assert First(10).fold(identity) == 10
    assert Last(20).fold(identity) == 20
    assert Min(5).fold(identity) == 5
    assert Max(10).fold(identity) == 10
    assert Map({'first': First(10), 'last': Last(20)}).fold(
        identity) == Map({'first': First(10), 'last': Last(20)}).value


# Generated at 2022-06-12 05:29:23.792714
# Unit test for constructor of class Sum
def test_Sum():
    """
    Test constructor Sum
    """

    sum_line = lambda x: Sum(x)
    assert sum_line('123') == Sum('123')

# Generated at 2022-06-12 05:29:25.818692
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(5)) == 'Sum[value=5]'



# Generated at 2022-06-12 05:29:28.902955
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_test = Sum(1).concat(Sum(2))
    assert sum_test == Sum(3)


# Generated at 2022-06-12 05:29:30.764283
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2, "Should be equal"


# Generated at 2022-06-12 05:29:34.369250
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)



# Generated at 2022-06-12 05:29:35.239934
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)

# Generated at 2022-06-12 05:29:39.582898
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)
    assert One(True) == One(True)
    assert One(None) == One(None)
    assert One(None) != One(True)
    assert One(1).is_instance(One)
    assert One(True).is_instance(One)
    assert One(None).is_instance(One)


# Generated at 2022-06-12 05:29:41.741475
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"


# Generated at 2022-06-12 05:30:11.858403
# Unit test for method concat of class Map
def test_Map_concat():
    a = Map({0: Sum(1), 1: All(True), 2: One(True), 3: First(1), 4: Last(2)})
    b = Map({0: Sum(2), 1: All(False), 2: One(False), 3: First(2), 4: Last(1)})
    assert a.concat(b).value == {
        0: Sum(3),
        1: All(False),
        2: One(True),
        3: First(1),
        4: Last(2)
    }

# Generated at 2022-06-12 05:30:15.436904
# Unit test for constructor of class Semigroup
def test_Semigroup(): # pragma: no cover
    test_obj = Semigroup(1)
    assert test_obj
    assert test_obj.value == 1
    test_obj = Semigroup(value=1)
    assert test_obj
    assert test_obj.value == 1



# Generated at 2022-06-12 05:30:17.172136
# Unit test for constructor of class Last
def test_Last():
    """
    Unit test for constructor of class Last
    """
    assert Last(1).value == 1

# Generated at 2022-06-12 05:30:19.717248
# Unit test for method __str__ of class First
def test_First___str__():
    assert 'Fist[value=foo]' == str(First('foo'))


# Generated at 2022-06-12 05:30:23.895053
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    class TestClass():
        pass
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(2) != Semigroup(3)
    assert Semigroup(3) != TestClass()


# Generated at 2022-06-12 05:30:27.626801
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({
        'foo': Sum(2),
        'bar': Last(3)
    }).concat(Map({
        'foo': Last(1),
        'bar': Sum(4)
    })).value == {'foo': Sum(3), 'bar': Sum(7)}

# Generated at 2022-06-12 05:30:30.331771
# Unit test for method __str__ of class All
def test_All___str__():
    all_ = All(123)
    assert str(all_) == 'All[value=123]'
    assert repr(all_) == 'All[value=123]'


# Generated at 2022-06-12 05:30:34.028821
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(42)) == 'Sum[value=42]', 'value - expected `Sum[value=42]`'
    assert str(Sum(0)) == 'Sum[value=0]', 'value - expected `Sum[value=0]`'


# Generated at 2022-06-12 05:30:35.741827
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-12 05:30:37.847965
# Unit test for method __str__ of class First
def test_First___str__():
    value = 1
    expected = 'Fist[value=1]'
    actual = str(First(value))
    assert expected == actual



# Generated at 2022-06-12 05:31:29.844572
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda value: value + 1) == 2
    assert Semigroup(1).fold(lambda value: value < 3) == True


# Generated at 2022-06-12 05:31:32.245408
# Unit test for method concat of class First
def test_First_concat():
    assert First(2).concat(First(3)) == First(2)



# Generated at 2022-06-12 05:31:42.581394
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x + 1) == 2
    assert All(True).fold(lambda x: not x) == False
    assert One(True).fold(lambda x: not x) == False
    assert First(1).fold(lambda x: x + 1) == 1
    assert Last(1).fold(lambda x: x + 1) == 2

    assert Max(1).fold(lambda x: x + 1) == 1
    assert Max(1).fold(lambda x: x - 1) == -1

    assert Max(2).fold(lambda x: x - 1) == 1
    assert Min(2).fold(lambda x: x - 1) == 1
    assert Min(2).fold(lambda x: x + 1) == 2


# Generated at 2022-06-12 05:31:49.048726
# Unit test for constructor of class Max
def test_Max():
    # This will be a normal Max,
    # but the semigroup hierarchy does not explicitly require this to exist.
    assert Max(4) == Max(4)
    # This will be a neutral element,
    # but the semigroup hierarchy does not explicitly require this to exist.
    assert Max(4).concat(Max.neutral()) == Max(4)
    assert Max(4) != Max.neutral()
    assert Max.neutral().concat(Max(4)) == Max(4)


# Generated at 2022-06-12 05:31:53.253012
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(1).concat(Min(0)) == Min(0)


# Generated at 2022-06-12 05:31:58.979605
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: Sum(1), 2: Sum(2)})) == 'Map[value={1: Sum[value=1], 2: Sum[value=2]}]'



# Generated at 2022-06-12 05:32:01.388281
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert Sum(3) == Sum(3)
    assert Sum(3).value == 3



# Generated at 2022-06-12 05:32:03.341502
# Unit test for method __str__ of class Last
def test_Last___str__():
    last = Last(1)
    assert str(last) == 'Last[value=1]'



# Generated at 2022-06-12 05:32:05.313106
# Unit test for constructor of class Sum
def test_Sum():
    sum = Sum(4)
    assert sum.value == 4

# Generated at 2022-06-12 05:32:06.800555
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One("test")) == "One[value=test]"

