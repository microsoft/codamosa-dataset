

# Generated at 2022-06-12 05:23:57.048913
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(-1)) == Min(-1)
    assert Min(-1).concat(Min(-2)) == Min(-2)

# Generated at 2022-06-12 05:24:02.820477
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map({'at': Min(0), 'inc': Sum(0)})
    map2 = Map({'at': Min(1), 'inc': Sum(1)})
    map3 = Map({'at': Min(2), 'inc': Sum(2)})
    actual = map1.concat(map2).concat(map3)
    expected = Map({'at': Min(0), 'inc': Sum(3)})
    assert actual == expected

# Generated at 2022-06-12 05:24:07.837811
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(5), 'b': Sum(6)}).concat(
        Map({'a': Sum(5), 'b': Sum(6)})).value == {
        'a': Sum(10),
        'b': Sum(12)
    }

# Generated at 2022-06-12 05:24:11.053763
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': All(1)}).concat(Map({'a': Sum(2)})).value == {'a': Sum(3), 'b': All(1)}

# Generated at 2022-06-12 05:24:17.767784
# Unit test for method concat of class Map
def test_Map_concat():
    """
    :returns: True if method concat of class Map works correct else return False
    :rtype: bool
    """
    m1 = Map({1: Sum(1), 2: Sum(2), 3: Sum(3)})
    m2 = Map({1: Sum(1), 2: Sum(2)})
    if m1.concat(m2) == Map({1: Sum(2), 2: Sum(4), 3: Sum(3)}):
        return True
    return False

# Generated at 2022-06-12 05:24:26.082273
# Unit test for method concat of class Map

# Generated at 2022-06-12 05:24:34.682861
# Unit test for method concat of class Map
def test_Map_concat():
    def f(a):
        return a + 1

    def g(a):
        return a * 10

    def h(a):
        return a - 1
    a = Map({'a': Sum(1), 'b': Sum(2)})
    b = Map({'a': Sum(10), 'c': Sum(20)})

    assert a.concat(b) == Map({'a': Sum(11), 'b': Sum(2), 'c': Sum(20)})
    assert a.concat(Map({})) == a
    assert b.concat(Map({})) == b
    assert a.concat(a) == a.fold(f)
    assert b.concat(b) == b.fold(g)
    assert a.concat(b).concat(Map({})) == a.concat

# Generated at 2022-06-12 05:24:38.661664
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"a": Sum(1), "b": All(True)}).concat(
        Map({"b": Sum(2), "c": All(False)})
    ).value == {"a": Sum(1), "b": Sum(3), "c": All(False)}

# Generated at 2022-06-12 05:24:44.428293
# Unit test for method concat of class Min
def test_Min_concat():
    min_zero = Min(0)
    min_one = Min(1)
    min_two = Min(2)
    assert min_zero.concat(min_one) == min_one
    assert min_one.concat(min_two) == min_one
    assert min_two.concat(min_one) == min_one



# Generated at 2022-06-12 05:24:47.355448
# Unit test for method concat of class Min
def test_Min_concat():
    print("Testing method concat of class Min")
    a = Min(1)
    b = Min(2)
    c = a.concat(b)
    assert c == Min(1), 'Error in concat'


# Generated at 2022-06-12 05:24:53.497279
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(5).__str__() == 'One[value=5]'
    assert One(True).__str__() == 'One[value=True]'
    assert One(False).__str__() == 'One[value=False]'

# Unit testing for method concat of class One

# Generated at 2022-06-12 05:24:57.886443
# Unit test for constructor of class Semigroup
def test_Semigroup():
    class TestSemigroup(Semigroup):
        pass

    try:
        TestSemigroup(1)
    except TypeError as e:
        assert str(e) == 'Can\'t instantiate abstract class TestSemigroup with abstract methods neutral'
    else:
        assert False



# Generated at 2022-06-12 05:25:00.961277
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(None) == One(None)
    assert One(1) == One(1)



# Generated at 2022-06-12 05:25:04.744159
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    _ = {'semigroup': Sum(5),
         'initial': First(10),
         'check': First(5)
         }
    assert _['check'] == _['semigroup'].fold(_['initial'].concat)



# Generated at 2022-06-12 05:25:06.104461
# Unit test for constructor of class One
def test_One():
    assert One(True) != One(False)



# Generated at 2022-06-12 05:25:08.091686
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    test Semigroup constructor
    """
    semigroup = Semigroup(1)

    assert semigroup.value == 1



# Generated at 2022-06-12 05:25:10.029291
# Unit test for constructor of class Sum
def test_Sum():
    sum = Sum(1)
    assert sum.value == 1



# Generated at 2022-06-12 05:25:11.680987
# Unit test for method concat of class Sum
def test_Sum_concat():  # pragma: no cover
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-12 05:25:15.396665
# Unit test for method concat of class First
def test_First_concat():  # pragma: no cover
    a = First('first')
    b = First('second')

    assert a.concat(b).value == 'first'
    assert b.concat(a).value == 'second'



# Generated at 2022-06-12 05:25:19.235980
# Unit test for method concat of class Map
def test_Map_concat():
    """
    Function to test concat method of class Map
    """
    x = Map({"a": Sum(1), "b": Sum(2)})
    y = Map({"a": Sum(1), "b": Sum(2)})
    assert x == y, "Error Map.concat"



# Generated at 2022-06-12 05:25:28.679392
# Unit test for constructor of class Map
def test_Map():
    map_value = {'a': Sum(0), 'b': All(True)}

    map_value2 = {'a': Sum(5), 'b': All(False)}

    map = Map(map_value)
    map2 = Map(map_value2)

    assert map == Map(map_value)

    with pytest.raises(ValueError):
        map.concat(map2)

    assert map.concat(Map({})) == Map(map_value)

    with pytest.raises(AttributeError):
        map.concat(map2)

    assert map.concat(Map({})) == Map(map_value)

    with pytest.raises(AttributeError):
        map.concat(Max(5))


# Generated at 2022-06-12 05:25:30.277035
# Unit test for constructor of class Min
def test_Min():
    assert Min(2) == Min(2) and Min(2).value == 2

# Generated at 2022-06-12 05:25:31.723288
# Unit test for constructor of class First
def test_First():
    assert First(8) == First(8)


# Generated at 2022-06-12 05:25:34.872116
# Unit test for method __str__ of class One
def test_One___str__():
    # arrange
    one = One(True)
    # act
    actual = one.__str__()
    # assert
    assert actual.__eq__('One[value=True]')



# Generated at 2022-06-12 05:25:36.512249
# Unit test for constructor of class All
def test_All():
    all_monoid = All(True)
    assert all_monoid.value == True



# Generated at 2022-06-12 05:25:40.308060
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1).value == 1
    assert Semigroup(1).fold(lambda x: x + 1) == 2



# Generated at 2022-06-12 05:25:48.817007
# Unit test for method concat of class One
def test_One_concat():
    assert One.neutral().concat(One.neutral()) == One(False)
    assert One(True).concat(One.neutral()) == One(True)
    assert One.neutral().concat(One(False)) == One(False)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(False).concat(One(True)) == One(True)
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-12 05:25:51.016705
# Unit test for method __str__ of class Last
def test_Last___str__():
    from types import GeneratorType
    last = Last(1)
    assert isinstance(last.__str__(), str)



# Generated at 2022-06-12 05:25:53.041209
# Unit test for method __str__ of class Sum
def test_Sum___str__(): # pragma: no cover
    foo = Sum(10)
    assert str(foo) == 'Sum[value=10]'


# Generated at 2022-06-12 05:25:54.487406
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-12 05:25:59.707281
# Unit test for constructor of class Map
def test_Map():
    assert Map({"a": First("a"), "b": First("b")}).value == {"a": First("a"), "b": First("b")}

# Generated at 2022-06-12 05:26:01.598827
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(2) != First(1)


# Generated at 2022-06-12 05:26:02.682043
# Unit test for constructor of class Max
def test_Max():
    assert Max(2) == Max(2)



# Generated at 2022-06-12 05:26:05.611229
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
    assert All(True).concat(All(True)).value == True



# Generated at 2022-06-12 05:26:07.185877
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First(1)) == "Fist[value=1]"



# Generated at 2022-06-12 05:26:09.124642
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(False)) == 'All[value=False]'
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-12 05:26:20.144530
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert not Sum(1) == Sum(2)
    assert Sum(1) == Sum(1)
    assert not All(False) == All(True)
    assert All(True) == All(True)
    assert not One(False) == One(True)
    assert One(False) == One(False)
    assert not First('a') == First('b')
    assert First('a') == First('a')
    assert not Last('a') == Last('b')
    assert Last('a') == Last('a')
    assert not Map({'a':First('b'), 'b':First('c')}) == Map({'a':First('b'), 'b':First('d')})

# Generated at 2022-06-12 05:26:24.797265
# Unit test for constructor of class Map
def test_Map():
    m1 = Map({1: Sum(2), 3: Sum(4)})
    m2 = Map({1: Sum(2), 3: Sum(4)})
    assert m1 == m2
    m3 = m1.concat(m2)
    m3.fold(lambda i: print(i))

# Generated at 2022-06-12 05:26:28.874949
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    Unit test for constructor of class Semigroup
    """
    # noinspection PyTypeChecker
    assert Semigroup(1).value == 1



# Generated at 2022-06-12 05:26:34.948882
# Unit test for method concat of class Map
def test_Map_concat():
    result = Map({'key1': 'value1', 'key2': 'value2'}) \
                .concat(Map({'key1': 'value3', 'key3': 'value3'}))
    expected = Map({'key1': 'value1value3', 'key2': 'value2', 'key3': 'value3'})
    assert result == expected

# Generated at 2022-06-12 05:26:41.516838
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert (str(Min(30)) == 'Min[value=30]')
    assert (str(Min(40)) == 'Min[value=40]')


# Generated at 2022-06-12 05:26:42.444060
# Unit test for method concat of class First
def test_First_concat():
    assert First('a').concat(First('b')).value == 'a'


# Generated at 2022-06-12 05:26:45.659214
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)
    assert All(False) != All(True)


# Generated at 2022-06-12 05:26:48.940154
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(10)) == 'Last[value=10]'
    assert str(Last([])) == 'Last[value=[]]'
    assert str(Last(None)) == 'Last[value=None]'


# Generated at 2022-06-12 05:26:51.757685
# Unit test for method concat of class Min
def test_Min_concat():
    s = Min(3)
    s1 = s.concat(Min(4))
    assert s1 == Min(3)

# Generated at 2022-06-12 05:26:53.470177
# Unit test for method __str__ of class Last
def test_Last___str__():
    last = Last(1)
    assert last.__str__() == 'Last[value=1]'


# Generated at 2022-06-12 05:26:57.923260
# Unit test for constructor of class Last
def test_Last():
    """
    Test method constriuctor of class Last.
    """
    assert Last(10).value == 10
    assert Last("Hello").value == "Hello"
    assert Last(True).value
    assert Last({1, 2, 3}) == {1, 2, 3}



# Generated at 2022-06-12 05:27:04.764565
# Unit test for constructor of class Map
def test_Map():
    assert Map({"a": 2, "b": 4}) == Map({"a": 2, "b": 4})
    assert Map({"a": 2, "b": 4}) != Map({"a": 2, "c": 4})
    assert Map({"a": 2, "b": 4}) != Map({"a": 2, "b": 3})


# Generated at 2022-06-12 05:27:09.079632
# Unit test for method __str__ of class Max
def test_Max___str__():
    """
    Test for method __str__ of class Max
    :return:
    """
    assert str(Max(5)) == 'Max[value=5]'
    assert str(Max(-10)) == 'Max[value=-10]'



# Generated at 2022-06-12 05:27:10.721637
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(2)) == 'Min[value=2]'


# Generated at 2022-06-12 05:27:25.090030
# Unit test for constructor of class All
def test_All():
    try:
        assert All(True) == All(True)
        assert All(False) == All(False)
        assert All(True) != All(False)
    except:
        print('test_All failed')



# Generated at 2022-06-12 05:27:28.856614
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': First(3), 'b': Last(1)})) == 'Map[value={"a": Fist[value=3], "b": Last[value=1]}]'


# Generated at 2022-06-12 05:27:30.598109
# Unit test for constructor of class Sum
def test_Sum():
    sum = Sum(1)
    assert sum.value == 1


# Generated at 2022-06-12 05:27:33.132074
# Unit test for method concat of class Min
def test_Min_concat():
    min1 = Min(-1)
    min2 = Min(0)
    assert min1.concat(min2).value == -1



# Generated at 2022-06-12 05:27:37.023091
# Unit test for method concat of class First
def test_First_concat():
    assert First(True).concat(First(False)) == First(True)
    assert First(False).concat(First(True)) == First(False)
    assert First(False).concat(First(False)) == First(False)
    assert First(True).concat(First(True)) == First(True)

# Generated at 2022-06-12 05:27:38.368966
# Unit test for method __str__ of class Min
def test_Min___str__():
    x = Min(1)
    assert str(x) == 'Min[value=1]'



# Generated at 2022-06-12 05:27:45.135637
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    """
    Test that method concat of class All returns new All with last truly value or first falsy
    """
    assert All(True).concat(All(True)).value == True
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False


# Generated at 2022-06-12 05:27:50.452000
# Unit test for constructor of class One
def test_One():
    assert bool(One(3)) == True
    assert bool(One(0)) == False
    assert bool(One('')) == False
    assert bool(One('text')) == True
    assert bool(One(None)) == False
    assert bool(One(True)) == True
    assert bool(One(False)) == False


# Generated at 2022-06-12 05:27:53.372281
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    one_str = str(One(True))
    assert one_str == 'One[value=True]'



# Generated at 2022-06-12 05:27:58.879960
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value == True
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
    assert All(False).concat(All(False)).value == False


# Generated at 2022-06-12 05:28:23.941096
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(3).value == 3 and Sum(3).neutral() == Sum(0)


# Generated at 2022-06-12 05:28:25.742222
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)



# Generated at 2022-06-12 05:28:28.274595
# Unit test for constructor of class Map
def test_Map():
    def test_Map():
        m = Map({1: "a", 2: "b"})
        assert m.value == {1: "a", 2: "b"}

    test_Map()



# Generated at 2022-06-12 05:28:31.501292
# Unit test for method concat of class One
def test_One_concat():
    assert str(One(True).concat(One(False))) == 'One[value=True]'



# Generated at 2022-06-12 05:28:36.325733
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum.neutral() == Sum(0)
    assert Sum(0) == Sum(0)
    assert Sum(1) == Sum(1)
    assert Sum(-1) == Sum(-1)
    assert Sum(0) != Sum(1)
    assert Sum(2) != Sum(-2)


# Generated at 2022-06-12 05:28:44.777438
# Unit test for constructor of class Map
def test_Map():
    assert Map({"a": Sum(1), "b": All(True)}) == Map({"a": Sum(1), "b": All(True)})
    assert Map({"a": Sum(2), "b": All(True)}) != Map({"a": Sum(1), "b": All(True)})
    assert Map({"a": Sum(1), "b": All(False)}) != Map({"a": Sum(1), "b": All(True)})
    assert Map({"a": Sum(2), "b": All(False)}) != Map({"a": Sum(1), "b": All(True)})



# Generated at 2022-06-12 05:28:46.850850
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    print()
    x = Last(10)
    print('{}'.format(x))

# Generated at 2022-06-12 05:28:48.964053
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(False)) == "All[value=False]"


# Generated at 2022-06-12 05:28:53.476128
# Unit test for constructor of class Sum
def test_Sum():
    """
    Unit test for constructor of class Sum
    """
    assert Sum(1)
    assert Sum(1).value == 1  # pragma: no cover
    assert Sum(0)
    assert Sum(0).value == 0  # pragma: no cover



# Generated at 2022-06-12 05:28:54.348243
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)).value is True


# Generated at 2022-06-12 05:29:40.733947
# Unit test for method concat of class Last
def test_Last_concat():
    assert First(1).concat(First(2)).value == 1


# Generated at 2022-06-12 05:29:43.770731
# Unit test for constructor of class First
def test_First():
    assert First(True) == First(True)
    assert First(True) != First(False)
    assert First(False) != First(True)
    assert First(False) == First(False)


# Generated at 2022-06-12 05:29:53.119016
# Unit test for method concat of class Map
def test_Map_concat():
    """
    Map is a Semigroup that will always return contated all values inside Map value
    """
    obj1 = Map({
        1: Sum(3),
        2: Sum(4),
        3: Sum(5),
    })
    obj2 = Map({
        4: Sum(6),
        5: Sum(7),
        6: Sum(8),
    })
    assert obj1.concat(obj2).value == {
        1: Sum(3),
        2: Sum(4),
        3: Sum(5),
        4: Sum(6),
        5: Sum(7),
        6: Sum(8),
    }
    assert isinstance(obj1.concat(obj2), Map)



# Generated at 2022-06-12 05:29:56.445305
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(1)) == 'All[value=True]'
    assert str(All(0)) == 'All[value=False]'
    assert str(All(None)) == 'All[value=False]'


# Generated at 2022-06-12 05:29:58.114257
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)

# Generated at 2022-06-12 05:29:59.390648
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)

# Generated at 2022-06-12 05:30:02.007483
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)).fold(lambda x: x) == 3



# Generated at 2022-06-12 05:30:03.429950
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1).value == 1


# Generated at 2022-06-12 05:30:05.414233
# Unit test for constructor of class Semigroup
def test_Semigroup():
    sum_test = Sum(1)
    assert sum_test.value == 1



# Generated at 2022-06-12 05:30:06.985222
# Unit test for constructor of class Min
def test_Min():
    assert Min(10) == Min(10)
    assert Min(10) != Sum(0)

# Generated at 2022-06-12 05:31:45.610974
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(10).fold( lambda x: x ) == 10
    assert First(10).fold( lambda x: x ) == 10
    assert All(True).fold( lambda x: x ) == True
    assert One(True).fold( lambda x: x ) == True
    assert Max(10).fold( lambda x: x ) == 10
    assert Max(10).fold( lambda x: x ) == 10

# Generated at 2022-06-12 05:31:49.988769
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'
    assert str(One(1)) == 'One[value=1]'
    assert str(One('true')) == 'One[value=true]'


# Generated at 2022-06-12 05:31:53.757883
# Unit test for method __str__ of class First
def test_First___str__():
    # given
    semigroup = First(42)

    # when
    value = semigroup.__str__()

    # then
    assert value == 'First[value=42]'


# Generated at 2022-06-12 05:31:57.944273
# Unit test for method concat of class First
def test_First_concat():
    oneFirst = First(1)
    twoFirst = First(2)

    assert oneFirst == oneFirst.concat(twoFirst)


# Generated at 2022-06-12 05:32:04.647339
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert (Sum(1) == Sum(1)), "Sum values equals"
    assert (All(True) == All(True)), "All values equals"
    assert (One(True) == One(True)), "One values equals"
    assert (First(1) == First(1)), "First values equals"
    assert (Last(1) == Last(1)), "Last values equals"
    assert (Max(1) == Max(1)), "Max values equals"
    assert (Min(1) == Min(1)), "Min values equals"
    assert (Map({"1": Sum(1)}) == Map({"1": Sum(1)})), "Map values equals"



# Generated at 2022-06-12 05:32:09.539599
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1).value == 1
    try:
        Semigroup(1).neutral()
    except NotImplementedError:
        assert True
    else:
        assert False


# Generated at 2022-06-12 05:32:13.499595
# Unit test for constructor of class One
def test_One():  # pragma: no cover
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(1) == One(1)
    assert One('1') == One('1')
    assert One('a') == One('a')
    assert One([1]) == One([1])
    assert One({'a': 1}) == One({'a': 1})


# Generated at 2022-06-12 05:32:19.719703
# Unit test for constructor of class Map
def test_Map():
    map1 = Map({'a': Sum(10), 'b': Sum(20)})
    map2 = Map({'a': Sum(20), 'b': Sum(30)})
    assert map1 == Map({'a': Sum(10), 'b': Sum(20)})
    assert map1.concat(map2) == Map({'a': Sum(30), 'b': Sum(50)})


# Generated at 2022-06-12 05:32:21.660053
# Unit test for method concat of class Sum
def test_Sum_concat():
    a = Sum(2)
    b = Sum(3)
    assert a.concat(b).value == 5


# Generated at 2022-06-12 05:32:25.082146
# Unit test for method __str__ of class Min
def test_Min___str__():    # pragma: no cover
    assert str(Min(2)) == 'Min[value=2]'

