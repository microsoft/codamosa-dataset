

# Generated at 2022-06-12 05:23:45.131003
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)


# Generated at 2022-06-12 05:23:48.453517
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(5).concat(Min(3.3)) == Min(3.3)
    assert Min(3.1).concat(Min(3.3)) == Min(3.1)
    assert Min(3.3).concat(Min(3.3)) == Min(3.3)


# Generated at 2022-06-12 05:23:54.257340
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(10).concat(Min(2)) == Min(2)
    assert Min(10).concat(Min(10)) == Min(10)
    assert Min(10).concat(Min(20)) == Min(10)
    assert Min(20).concat(Min(10)) == Min(10)


# Generated at 2022-06-12 05:23:55.521064
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(4).concat(Min(3)) == Min(3)
    assert Min(4).concat(Min(4)) == Min(4)
    assert Min(4).concat(Min(5)) == Min(4)



# Generated at 2022-06-12 05:23:58.576421
# Unit test for method concat of class Min
def test_Min_concat():
    m1 = Min(1)
    m2 = Min(2)
    assert m1.concat(m2) == Min(1)


# Generated at 2022-06-12 05:24:02.894632
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"1": Min(1), "2": Min(3), "3": Min(2)}).concat(
        Map({"1": Min(5), "2": Min(2), "3": Min(1)})).value == {
            "1": Min(1), "2": Min(2), "3": Min(1)
        }


# Generated at 2022-06-12 05:24:07.462840
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(3).concat(Min(4)) == Min(4)
    assert Min(4).concat(Min(4)) == Min(4)


# Generated at 2022-06-12 05:24:18.002039
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"apple": Last("apple"), "banana": Last("banana")}).concat(
        Map({"apple": Last("cider"), "banana": Last("cream")})
    ) == Map({"apple": Last("cider"), "banana": Last("cream")})
    assert Map({"apple": Last("apple"), "banana": Last("banana")}).concat(
        Map({"apple": Last("cider")})
    ) == Map({"apple": Last("cider"), "banana": Last("banana")})
    assert Map({"apple": Last("apple")}).concat(
        Map({"apple": Last("cider"), "banana": Last("cream")})
    ) == Map({"apple": Last("cider"), "banana": Last("cream")})

# Generated at 2022-06-12 05:24:22.267474
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(2)).value == 1


# Generated at 2022-06-12 05:24:24.704199
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(1)
    b = Min(2)
    assert Min(1) == a.concat(b)
    assert Min(2) == b.concat(a)


# Generated at 2022-06-12 05:24:30.794106
# Unit test for constructor of class Min
def test_Min():
    assert Min(10) == Min(10)
    assert Min(10).neutral() == Min(float("inf"))


# Generated at 2022-06-12 05:24:35.712383
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(0).concat(Min(-1)) == Min(-1)
    assert Min(-100).concat(Min(-99)) == Min(-99)
    assert Min(-1).concat(Min(-1)) == Min(-1)



# Generated at 2022-06-12 05:24:37.927461
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'



# Generated at 2022-06-12 05:24:41.925523
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == "Last[value=1]"
    assert str(Last(1)) != "Last[value=2]"
    assert str(Last(1)) != "Last[value={}]".format(1)


# Generated at 2022-06-12 05:24:46.998238
# Unit test for constructor of class One
def test_One():
    assert One(1)
    assert One(True)
    assert One(None)
    assert One(0)
    assert One('')
    assert One(False)
    assert One(0.0)
    assert One(())
    assert One({})
    assert One([])



# Generated at 2022-06-12 05:24:48.040007
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1



# Generated at 2022-06-12 05:24:59.745450
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert (Sum(1) == Sum(1)) == True
    assert (Sum(1) == Sum(2)) == False
    assert (All(True) == All(True)) == True
    assert (All(True) == All(False)) == False
    assert (All(False) == All(False)) == True
    assert (One(True) == One(True)) == True
    assert (One(True) == One(False)) == False
    assert (One(False) == One(False)) == True
    assert (First(1) == First(1)) == True
    assert (First(1) == First(2)) == False
    assert (Last(1) == Last(1)) == True
    assert (Last(1) == Last(2)) == False
    assert (Map({1: 1}) == Map({1: 1})) == True

# Generated at 2022-06-12 05:25:01.441143
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)


# Generated at 2022-06-12 05:25:06.340597
# Unit test for constructor of class Map
def test_Map(): # pragma: no cover
    _map = Map({'A': Sum(10), 'B': All(True), 'C': One(True), 'D': Map({'A': Sum(10)})})
    for key, value in _map.value.items():
        print('key: {}, value: {}'.format(key, value))


# Generated at 2022-06-12 05:25:08.009808
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(4) == Sum(4)

# Unit tests for constructor of class All

# Generated at 2022-06-12 05:25:12.262647
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1).value == 1
    assert Semigroup('str').value == 'str'
    assert Semigroup(object).value == object



# Generated at 2022-06-12 05:25:14.648281
# Unit test for constructor of class One
def test_One():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-12 05:25:16.415818
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)


# Generated at 2022-06-12 05:25:18.174897
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(1)) == Sum(2)



# Generated at 2022-06-12 05:25:19.272999
# Unit test for constructor of class Last
def test_Last():
    last = Last(1)
    assert last.value == 1

# Generated at 2022-06-12 05:25:25.911033
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(10).fold(lambda x: x) == 10
    assert All(True).fold(lambda x: x) == True
    assert One(False).fold(lambda x: x) == False
    assert First(10).fold(lambda x: x) == 10
    assert Last(10).fold(lambda x: x) == 10
    assert Map({'a': 10, 'b': 50}).fold(lambda x: x) == {'a': 10, 'b': 50}
    assert Max(100).fold(lambda x: x) == 100
    assert Min(100).fold(lambda x: x) == 100

# Generated at 2022-06-12 05:25:27.069613
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'

# Generated at 2022-06-12 05:25:27.867287
# Unit test for constructor of class First
def test_First():
    assert First(123) == First(123)


# Generated at 2022-06-12 05:25:29.034653
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(3) == Sum(3)



# Generated at 2022-06-12 05:25:33.643034
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(8)) == Sum(10)
    assert Sum(2).concat(Sum(0)) == Sum(2)
    assert Sum(0).concat(Sum(0)) == Sum(0)
    assert Sum(0).concat(Sum(2)) == Sum(2)



# Generated at 2022-06-12 05:25:36.461196
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-12 05:25:39.749383
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': First(1), 'b': First(2)}).concat(Map({'a': First(3)})) == Map({'a': First(1), 'b': First(2)})

# Generated at 2022-06-12 05:25:41.965755
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)

# Generated at 2022-06-12 05:25:43.530268
# Unit test for method __str__ of class Min
def test_Min___str__():
    class_ = Min
    assert (
        class_(inf).__str__()
        == 'Min[value={}]'.format(inf)
    )


# Generated at 2022-06-12 05:25:49.156685
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(False).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)


# Generated at 2022-06-12 05:25:51.342936
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Last(1), 'b': Max(2)}) == Map({'b': Max(2), 'a': Last(1)})

# Generated at 2022-06-12 05:25:54.262187
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    s1 = Sum(15)
    s2 = Sum(165)
    s3 = Sum(15)
    assert s1 == s3
    assert s1 != s2



# Generated at 2022-06-12 05:25:58.142678
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: Sum(1), 2: Sum(2)})) == 'Map[value={1: Sum[value=1], 2: Sum[value=2]}]'



# Generated at 2022-06-12 05:26:03.009418
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).fold(lambda value: value) == 1
    assert One(True).fold(lambda value: value) == True
    assert One(2).concat(One(1)).fold(lambda value: value) == 1
    assert One(False).concat(One(True)).fold(lambda value: value) == True


# Generated at 2022-06-12 05:26:07.996840
# Unit test for method concat of class All
def test_All_concat():
    """
    Tests for All.concat method
    """
    # TODO:assert All(False).concat(All(False)).value == All(False).value
    assert All(False).concat(All(True)).value == True
    assert All(True).concat(All(False)).value == False
    assert All(True).concat(All(True)).value == True
    assert All(False).concat(All(False)).value == False
    # TODO: assert All(True).concat(All(True)).value == All(False).value


# Generated at 2022-06-12 05:26:20.286752
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert (Sum(1) == Sum(1))
    assert (Sum(2) != Sum(1))
    assert (All(True) == All(True))
    assert (All(False) != All(True))
    assert (One(True) == One(True))
    assert (One(False) != One(True))
    assert (First(1) == First(1))
    assert (First(2) != First(1))
    assert (Last(1) == Last(1))
    assert (Last(2) != Last(1))
    assert (Map({1: 1}) == Map({1: 1}))
    assert (Map({2: 2}) != Map({1: 1}))
    assert (Max(1) == Max(1))
    assert (Max(2) != Max(1))

# Generated at 2022-06-12 05:26:21.841810
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == "Max[value=1]"



# Generated at 2022-06-12 05:26:23.522028
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(0)) == 'Min[value=0]'


# Generated at 2022-06-12 05:26:25.354257
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(5)) == "Sum[value=5]"
    assert str(Sum(-2)) == "Sum[value=-2]"


# Generated at 2022-06-12 05:26:30.023086
# Unit test for method __str__ of class Min
def test_Min___str__():
    actual_result = str(Min(5))
    expected_result = 'Min[value=5]'
    assert actual_result == expected_result


# Generated at 2022-06-12 05:26:34.998580
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'foo': Min(1), 'bar': Min(-1)})) == 'Map[value={\'foo\': Min[value=1], \'bar\': Min[value=-1]}]'
    # assert str(Map({})) == 'Map[value={}]'



# Generated at 2022-06-12 05:26:39.902330
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(True).concat(All(0)) == All(False)
    assert All(True).concat(All("Hi")) == All(True)



# Generated at 2022-06-12 05:26:42.773869
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    sum_semigroup = Sum(3)
    assert sum_semigroup.value == 3



# Generated at 2022-06-12 05:26:52.009854
# Unit test for constructor of class Max
def test_Max():  # pragma: no cover
    assert Max(5) == Max(5)
    assert Max(5) != Max(10)
    assert Max(-5) != Max(-10)
    assert Max(-5) == Max(-5)
    assert Max('5') == Max('5')
    assert Max('5') != Max('10')
    assert Max('-5') != Max('-10')
    assert Max('-5') == Max('-5')
    assert Max('5') == Max(5)
    assert Max('5') != Max(10)
    assert Max('-5') != Max(-10)
    assert Max('-5') == Max(-5)


# Generated at 2022-06-12 05:26:56.583067
# Unit test for method concat of class Map
def test_Map_concat():
    obj1 = Map({'a': Sum(1), 'b': Sum(2), 'c': Sum(3)})
    obj2 = Map({'a': Sum(10), 'b': Sum(20), 'c': Sum(30), 'd': Sum(40)})
    assert obj1.concat(obj2) == Map({'a': Sum(11), 'b': Sum(22), 'c': Sum(33), 'd': Sum(40)})

# Generated at 2022-06-12 05:27:04.191161
# Unit test for method __str__ of class One
def test_One___str__():
    """
    Unit test for method __str__ of class One
    """
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'



# Generated at 2022-06-12 05:27:08.356494
# Unit test for method __str__ of class First
def test_First___str__():
    """
    Unit test for method __str__ of class First
    """
    first = First(1)
    assert str(first) == 'Fist[value=1]', "First.__str__ does not return a correct value"



# Generated at 2022-06-12 05:27:11.008800
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert Min(0.0).__str__() == 'Min[value=0.0]'


# Generated at 2022-06-12 05:27:12.421312
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-12 05:27:13.500732
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1)



# Generated at 2022-06-12 05:27:15.605427
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    Semigroup(1) == Semigroup(1)
    Semigroup(1) != Semigroup(2)


# Generated at 2022-06-12 05:27:20.348429
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'
    assert str(One(None)) == 'One[value=None]'


# Generated at 2022-06-12 05:27:22.021286
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(12)) == "Fist[value=12]"


# Generated at 2022-06-12 05:27:26.290196
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)).value == True
    assert One(True).concat(One(True)).value == True
    assert One(False).concat(One(False)).value == False
    assert One(False).concat(One(True)).value == True



# Generated at 2022-06-12 05:27:28.305746
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-12 05:27:36.455801
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).concat(Sum(2)).fold(lambda x: x) == 3



# Generated at 2022-06-12 05:27:38.162532
# Unit test for constructor of class Semigroup
def test_Semigroup():
    s = Semigroup(1)
    assert isinstance(s, Semigroup)



# Generated at 2022-06-12 05:27:40.111178
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-12 05:27:44.409002
# Unit test for method concat of class First
def test_First_concat():
    """
    Test for concat method of class First

    :returns: None
    :rtype: NoneType
    """
    first = First(1)
    first2 = First(2)

    assert first.concat(first2) == First(1)



# Generated at 2022-06-12 05:27:45.534530
# Unit test for constructor of class All
def test_All():
    assert All


# Generated at 2022-06-12 05:27:47.822844
# Unit test for method __str__ of class Max
def test_Max___str__():
    max_ = Max(1)
    assert max_.__str__() == "Max[value=1]"



# Generated at 2022-06-12 05:27:49.717262
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    semigroup = Sum(1)
    assert str(semigroup) == 'Sum[value=1]'


# Generated at 2022-06-12 05:27:56.922911
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert not Semigroup(0) == Semigroup(1)
    assert Semigroup(0) == Semigroup(0)
    assert not Semigroup(None) == Semigroup(None)
    assert not Semigroup(None) == Semigroup(0)
    assert not Semigroup(0) == Semigroup(None)
    assert Semigroup('') == Semigroup('')
    assert not Semigroup('') == Semigroup('1')
    assert not Semigroup('1') == Semigroup('')


# Generated at 2022-06-12 05:27:58.832337
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    s = Sum(3)
    assert s == Sum(3)
    assert s != Sum(4)


# Generated at 2022-06-12 05:28:01.994451
# Unit test for method concat of class Min
def test_Min_concat():
    min1 = Min(-1)
    min2 = Min(3)
    expected = Min(-1)
    actual = min1.concat(min2)
    assert expected == actual


# Generated at 2022-06-12 05:28:09.683319
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)


# Generated at 2022-06-12 05:28:13.330711
# Unit test for method __str__ of class Map
def test_Map___str__():
    obj = Map({'a': Sum(1)})
    assert str(obj) == 'Map[value={a: Sum[value=1]}]'


# Generated at 2022-06-12 05:28:15.719782
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)


# Generated at 2022-06-12 05:28:17.303782
# Unit test for method concat of class One
def test_One_concat():
    assert(One(True).concat(One(False)) == One(True))


# Generated at 2022-06-12 05:28:20.226717
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(7).concat(Max(5)) == Max(7)
    assert Max(5).concat(Max(7)) == Max(7)



# Generated at 2022-06-12 05:28:24.863742
# Unit test for method concat of class Min
def test_Min_concat():
    first_value = Min('a')
    second_value = Min('z')
    expected_value = Min('a')
    assert first_value.concat(second_value) == expected_value
    third_value = Min('9')
    expected_value = Min('9')
    assert first_value.concat(third_value) == expected_value
    fourth_value = Min('b')
    expected_value = Min('a')
    assert first_value.concat(fourth_value) == expected_value


# Generated at 2022-06-12 05:28:26.190489
# Unit test for method concat of class Min
def test_Min_concat():
    s = Min(5).concat(Min(6))
    assert s == Min(5)



# Generated at 2022-06-12 05:28:30.381650
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    assert One('test').__str__() == 'One[value=test]'
    assert One(False).__str__() == 'One[value=False]'


# Generated at 2022-06-12 05:28:41.396748
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(2) == Sum(2)
    assert not Sum(2) == Sum(3)
    assert not Sum(2) == 2
    assert First('abc') == First('abc')
    assert not First('abc') == First('def')
    assert not First('abc') == 'abc'
    assert Last('abc') == Last('abc')
    assert not Last('abc') == Last('def')
    assert not Last('abc') == 'abc'
    assert All(True) == All(True)
    assert not All(True) == All(False)
    assert not All(True) == True
    assert One(False) == One(False)
    assert not One(False) == One(True)
    assert not One(False) == False

# Generated at 2022-06-12 05:28:43.469031
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    assert str(One(True)) == "One[value=True]"


# Generated at 2022-06-12 05:28:57.648811
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(10).concat(Min(20)) == Min(10)
    assert Min(10).concat(Min(5)) == Min(5)


# Generated at 2022-06-12 05:29:00.332577
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_one = Sum(2)
    sum_two = Sum(1)
    assert sum_one.concat(sum_two) == Sum(3)
    assert sum_two.concat(sum_one) == Sum(3)



# Generated at 2022-06-12 05:29:04.228607
# Unit test for constructor of class All
def test_All():
    assert(All(True).value == True)
    assert(All(False).value == False)
    assert(All(7).value == True)
    assert(All(0).value == False)


# Generated at 2022-06-12 05:29:06.224807
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    # Given
    def mult_2(value: int) -> int:
        return value * 2

    semigroup = Sum(1)
    result = semigroup.fold(mult_2)

    # Then
    assert result == 2



# Generated at 2022-06-12 05:29:07.396579
# Unit test for method __str__ of class All
def test_All___str__():
    assert 'All[value=True]' == str(All(True))


# Generated at 2022-06-12 05:29:12.232887
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(11).concat(Max(12)) == Max(12)
    assert Max(12).concat(Max(11)) == Max(12)
    assert Max(11).concat(Max(11)) == Max(11)


# Generated at 2022-06-12 05:29:14.240992
# Unit test for constructor of class Min
def test_Min():
    min_one = Min(123)
    assert min_one.value == 123


# Generated at 2022-06-12 05:29:16.103029
# Unit test for method concat of class Sum
def test_Sum_concat():  # pragma: no cover
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-12 05:29:17.934791
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(None)) == 'One[value=None]'



# Generated at 2022-06-12 05:29:21.693020
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(0).concat(Sum(0)) == Sum(0)
    assert Sum(-5).concat(Sum(-2)) == Sum(-7)


# Generated at 2022-06-12 05:29:46.817219
# Unit test for method concat of class Last
def test_Last_concat():
    result = First(2).concat(First(1))
    assert result == First(2)



# Generated at 2022-06-12 05:29:48.105697
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-12 05:29:50.647892
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"

    assert str(All(False)) == "All[value=False]"



# Generated at 2022-06-12 05:29:54.865207
# Unit test for constructor of class Sum
def test_Sum():
    sum_with_int = Sum(1)
    sum_with_float = Sum(1.0)
    sum_with_none = Sum(None)

    assert isinstance(sum_with_int, Sum)
    assert isinstance(sum_with_float, Sum)
    assert isinstance(sum_with_none, Sum)
    assert sum_with_int.value == 1
    assert sum_with_float.value == 1.0
    assert sum_with_none.value is None



# Generated at 2022-06-12 05:30:01.243625
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(1).__str__() == 'One[value=1]'


# Unit tests for method concat of class One

# Generated at 2022-06-12 05:30:11.038584
# Unit test for constructor of class Map
def test_Map():
    with pytest.raises(TypeError):
        Map()

    map_1 = Map({'foo': Sum(1), 'bar': All(True)})
    map_2 = Map({'bar': All(False)})
    map_3 = map_1.concat(map_2)

    assert isinstance(map_1, Map)
    assert isinstance(map_2, Map)
    assert isinstance(map_3, Map)
    assert isinstance(map_1.value['foo'], Sum)
    assert isinstance(map_1.value['bar'], All)
    assert isinstance(map_2.value['bar'], All)
    assert isinstance(map_3.value['foo'], Sum)
    assert map_3.value['foo'].value == 1

# Generated at 2022-06-12 05:30:15.851496
# Unit test for method concat of class Last
def test_Last_concat():
    """
    Last concat always returns first value
    """

    Forall = Lambda.Forall()
    f = Forall.f
    x = Forall.x
    y = Forall.y

    assert_that(
        f >> f.concat(x).concat(y),
        equal_to(
            f >> f.concat(x)
        )
    )


# Generated at 2022-06-12 05:30:17.515946
# Unit test for constructor of class First
def test_First():
    first = First(2)
    assert first.value == 2
    assert first == First(2)



# Generated at 2022-06-12 05:30:20.597804
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    Unit test for constructor of class Semigroup
    """
    assert Semigroup(42).value == 42



# Generated at 2022-06-12 05:30:23.496417
# Unit test for method concat of class Sum
def test_Sum_concat():
    a = Sum(1)
    b = Sum(2)
    c = a.concat(b)
    assert c.value == 3



# Generated at 2022-06-12 05:31:12.916802
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(5)) == "Min[value=5]"


# Generated at 2022-06-12 05:31:16.007020
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)


# Generated at 2022-06-12 05:31:21.471991
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).concat(One(2)) == One(True)
    assert One(0).concat(One(1)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(False).concat(One(0)) == One(False)


# Generated at 2022-06-12 05:31:26.429515
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"
    assert str(All({True: "First", False: {1: "one"}})) == 'All[value=True]'



# Generated at 2022-06-12 05:31:28.705287
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    sum_number = Sum(1).fold(lambda x: x + 2)
    assert sum_number == 3



# Generated at 2022-06-12 05:31:36.184853
# Unit test for method concat of class Max
def test_Max_concat():
    """
    test concat method of Max
    """
    list_number = [4, 7, 5, 8, 3, 7, 8, 1, 6, 7, 4, 10, 6, 7, 10, 8, 6, 2, 5, 2, 9]
    max_list = []
    for i in list_number:
        max_list.append(Max(i).concat(Max(5)))
    assert all(map(lambda x: x.value == 10, max_list))


# Generated at 2022-06-12 05:31:38.071112
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == "Min[value=1]"


# Generated at 2022-06-12 05:31:39.447568
# Unit test for constructor of class Semigroup
def test_Semigroup():
    # type: () -> None
    assert Semigroup(12)



# Generated at 2022-06-12 05:31:42.673649
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'
    assert str(One(None)) == 'One[value=None]'


# Generated at 2022-06-12 05:31:44.173681
# Unit test for method __str__ of class Max
def test_Max___str__():
    m = Max(42)
    assert str(m) == "Max[value=42]"



# Generated at 2022-06-12 05:33:38.158025
# Unit test for constructor of class Map
def test_Map():
    assert Map({1: Sum(3)}) == Map({1: Sum(3)})
    assert Map({1: Sum(3), 2: Sum(5)}) == Map({1: Sum(3), 2: Sum(5)})
