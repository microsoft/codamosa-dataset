

# Generated at 2022-06-12 05:24:01.165123
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)
    assert Max(-1).concat(Max(-2)) == Max(-1)
    assert Max(-2).concat(Max(-1)) == Max(-1)


# Generated at 2022-06-12 05:24:03.644170
# Unit test for method concat of class Max
def test_Max_concat():
    expected = Max(2)
    actual = Max(1).concat(Max(2))
    assert expected == actual


# Generated at 2022-06-12 05:24:07.409191
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(1)) == Max(5)
    assert Max(5).concat(Max(10)) == Max(10)


# Generated at 2022-06-12 05:24:10.231500
# Unit test for method concat of class Max
def test_Max_concat():
    max_one = Max(1)
    max_two = Max(2)
    assert max_one.concat(max_two) == Max(2)



# Generated at 2022-06-12 05:24:12.634575
# Unit test for method concat of class Max
def test_Max_concat():  # pragma: no cover
    max_1 = Max(2)
    max_2 = Max(3)
    assert max_1.concat(max_2).value == 3



# Generated at 2022-06-12 05:24:14.657619
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(3)) == Max(3)



# Generated at 2022-06-12 05:24:21.142453
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)
    assert Max(1).concat(Max(-2)) == Max(1)
    assert Max(-2).concat(Max(1)) == Max(1)
    assert Max(-1).concat(Max(-2)) == Max(-1)
    assert Max(-2).concat(Max(-1)) == Max(-1)


# Generated at 2022-06-12 05:24:23.123487
# Unit test for method concat of class Max
def test_Max_concat():
    max_1 = Max(1)
    max_2 = Max(2)
    assert max_1.concat(max_2) == Max(2)


# Generated at 2022-06-12 05:24:24.758332
# Unit test for method concat of class Max
def test_Max_concat():
    a = Max(3)
    b = Max(5)
    print(a.concat(b))



# Generated at 2022-06-12 05:24:26.649787
# Unit test for method concat of class Max
def test_Max_concat():  # pragma: no cover
    assert(Max(1).concat(Max(2)) == Max(2))



# Generated at 2022-06-12 05:24:31.991791
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last('Dmitrii')) == 'Last[value=Dmitrii]'



# Generated at 2022-06-12 05:24:35.663605
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(True)) == 'Fist[value=True]'
    assert str(First(False)) == 'Fist[value=False]'
    assert str(First(None)) == 'Fist[value=None]'


# Generated at 2022-06-12 05:24:38.714795
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1
    assert First(2) == First(2)
    assert First(1) != First(2)



# Generated at 2022-06-12 05:24:40.226716
# Unit test for method __str__ of class All
def test_All___str__():
    assert repr(All(True)) == 'All[value=True]'


# Generated at 2022-06-12 05:24:42.741761
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda value: value * 3) == 3


# Generated at 2022-06-12 05:24:44.427711
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert 'Max[value=2]' == str(Max(2))


# Generated at 2022-06-12 05:24:49.918455
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)).value == 3
    assert Sum(2).concat(Sum(1)).value == 3
    assert Sum(0).concat(Sum(1)).value == 1
    assert Sum(1).concat(Sum(0)).value == 1
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).value == 6



# Generated at 2022-06-12 05:24:51.154313
# Unit test for constructor of class Sum
def test_Sum():
    value = 3
    semigroup = Sum(value)

    assert value == semigroup.value


# Generated at 2022-06-12 05:24:53.392881
# Unit test for constructor of class Max
def test_Max():  # pragma: no cover
    assert Max(6) == Max(6)


# Generated at 2022-06-12 05:24:55.180799
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(2)) == 'Max[value=2]'


# Generated at 2022-06-12 05:25:00.200241
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1).value == 1


# [Unit test for constructor of class Semigroup]
#

# Generated at 2022-06-12 05:25:01.384655
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1


# Generated at 2022-06-12 05:25:05.113111
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-12 05:25:08.533849
# Unit test for method concat of class All
def test_All_concat():
    # Given 2 falsy values
    all1 = All(False)
    all2 = All(False)

    # When concat 2 values
    result = all1.concat(all2)

    # Then result must be false
    assert result.value is False


# Generated at 2022-06-12 05:25:12.466180
# Unit test for constructor of class Sum
def test_Sum():
    try:
        v1 = Sum(1)
        v2 = Sum(3)
        assert v1.value == 1
        assert v2.value == 3
        assert v1 != v2
    except AssertionError as error:
        print(error)



# Generated at 2022-06-12 05:25:16.082118
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).concat(One(2)) == One(1)
    assert One(0).concat(One(2)) == One(2)
    assert One(0).concat(One(0)) == One(0)


# Generated at 2022-06-12 05:25:19.686183
# Unit test for method __str__ of class Last
def test_Last___str__(): # pragma: no cover
    assert str(Last(1)) == 'Last[value=1]'
    assert str(Last(True)) == 'Last[value=True]'


# Generated at 2022-06-12 05:25:22.762172
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-12 05:25:25.229746
# Unit test for constructor of class Min
def test_Min():
    """
    unit test
    """
    # arrange
    number = 4

    # act
    result = Min(number)

    # assert
    assert result.value == number



# Generated at 2022-06-12 05:25:26.451797
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-12 05:25:30.822135
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)).value == 3
    assert Sum(1).concat(Sum(2)).value == Sum(3).value


# Generated at 2022-06-12 05:25:32.271373
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-12 05:25:34.639787
# Unit test for constructor of class Max
def test_Max():
    """
    This is a test for the constructor of class Max
    """
    assert Max(1).value == 1


# Generated at 2022-06-12 05:25:45.502214
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'
    assert str(All(123)) == 'All[value=123]'
    assert str(All(None)) == 'All[value=None]'
    assert str(All('Will')) == 'All[value=Will]'
    assert str(All({'Will': 'Game of Thrones'})) == "All[value={'Will': 'Game of Thrones'}]"
    assert str(All(['Will', 'Rickon', 'Bran', 'Jon'])) == "All[value=['Will', 'Rickon', 'Bran', 'Jon']]"

# Generated at 2022-06-12 05:25:48.369457
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(5)) == 'Max[value=5]'
# Test case to check if method concat of class Max return correct value

# Generated at 2022-06-12 05:25:50.132643
# Unit test for method concat of class Last
def test_Last_concat():
    Last(1).concat(Last(2)) == Last(2)

# Generated at 2022-06-12 05:25:52.594498
# Unit test for method __str__ of class Max
def test_Max___str__():
    # Arrange
    max = Max(2)

    # Act
    actual = str(max)

    # Assert
    assert 'Max[value=2]' == actual

# Generated at 2022-06-12 05:25:54.421771
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(3).concat(Max(5)).value == 5
    assert Max(5).concat(Max(1)).value == 5


# Generated at 2022-06-12 05:26:02.682274
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(4).concat(Last(8)) == Last(8)
    assert Last('a').concat(Last('b')) == Last('b')
    assert Last(False).concat(Last(False)) == Last(False)
    assert Last(None).concat(Last(None)) == Last(None)
    assert Last(4).concat(Last(None)) == Last(None)
    assert Last('4').concat(Last('8')) == Last('8')


# Generated at 2022-06-12 05:26:09.185041
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert (
        One(True).concat(First("second")).concat(One(False)) ==
        One(True).concat(First("first")).concat(One(False))
    )
    assert (
        One(True).concat(First("second")).concat(One(False)) ==
        One(True).concat(First("first")).concat(One(True))
    )
    assert (
        One(True).concat(First("second")).concat(One(False)) !=
        One(False).concat(First("first")).concat(One(True))
    )
    assert (
        One(True).concat(First("second")).concat(One(False)) !=
        One(True).concat(First("first")).concat(One(True))
    )

# Generated at 2022-06-12 05:26:12.731087
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(3)) == "One[value=3]"


# Generated at 2022-06-12 05:26:14.773429
# Unit test for constructor of class Min
def test_Min():
    f = Min(5)
    assert f is not None
    assert f.value == 5


# Generated at 2022-06-12 05:26:16.829046
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1).value == 1



# Generated at 2022-06-12 05:26:19.825879
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(10)) == 'Max[value=10]'
    assert str(Max(-1)) == 'Max[value=-1]'


# Generated at 2022-06-12 05:26:23.307497
# Unit test for method concat of class Map
def test_Map_concat():
    print(Map)
    print(Map({1: '1', 2: '2'}).concat(Map({3: '3', 4: '4'})))

test_Map_concat()

# Generated at 2022-06-12 05:26:29.689409
# Unit test for method concat of class Map
def test_Map_concat():
    semigroup = Map({
        "one": Sum(1),
        "two": Sum(2),
        "three": Sum(3)
    })
    assert semigroup.concat(semigroup) == Map({
        "one": Sum(2),
        "two": Sum(4),
        "three": Sum(6)
    })



# Generated at 2022-06-12 05:26:31.567468
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'



# Generated at 2022-06-12 05:26:34.948171
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({"a": Sum(1), "b": First(2)})) == \
        'Map[value={"a": Sum[value=1], "b": Fist[value=2]}]'


# Generated at 2022-06-12 05:26:36.914841
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"



# Generated at 2022-06-12 05:26:40.726313
# Unit test for method concat of class Last
def test_Last_concat():
    last1 = Last(1)
    last2 = Last(2)
    assert last1.concat(last2) == Last(2)
    assert last2.concat(last1) == Last(1)


# Generated at 2022-06-12 05:26:44.489289
# Unit test for constructor of class Max
def test_Max():
    assert Max.neutral().value == float('-inf')
    assert Max(1).value == 1
    assert Max(2).value == 2


# Generated at 2022-06-12 05:26:47.968701
# Unit test for method concat of class One
def test_One_concat():
    one = One(True)
    other_one = One(False)
    assert one.concat(other_one) == One(True)


# Generated at 2022-06-12 05:26:49.317395
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-12 05:26:51.085785
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(0)) == "Min[value=0]"


# Generated at 2022-06-12 05:26:52.871496
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(0)) == "Max[value=0]"


# Generated at 2022-06-12 05:26:55.475519
# Unit test for constructor of class Last
def test_Last():
    last  = Last(1)
    last2 = Last(2)
    assert last.value == 1
    assert last.concat(last2).value == 2


# Generated at 2022-06-12 05:26:57.463625
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(5)) == 'Max[value=5]'



# Generated at 2022-06-12 05:27:03.309871
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)).value is True
    assert One(False).concat(One(True)).value is True
    assert One(True).concat(One(True)).value is True
    assert One(False).concat(One(False)).value is False



# Generated at 2022-06-12 05:27:11.971882
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert First(10).fold(lambda x: x + 1) == 11
    assert Last(10).fold(lambda x: x + 1) == 11
    assert Max(10).fold(lambda x: x + 1) == 11
    assert Min(10).fold(lambda x: x + 1) == 11
    assert All(True).fold(lambda x: x + 1) == 1
    assert All(False).fold(lambda x: x + 1) == 0
    assert One(True).fold(lambda x: x + 1) == 1
    assert One(False).fold(lambda x: x + 1) == 0
    assert Sum(10).fold(lambda x: x + 1) == 11

# Unit tests for method __eq__ of class Semigroup

# Generated at 2022-06-12 05:27:14.979336
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(0) == Semigroup(1)
    assert Semigroup(1).value == 1


# Generated at 2022-06-12 05:27:21.180985
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(0) == Semigroup(0)
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(0) != Semigroup(1)
    assert Semigroup(1) != Semigroup(0)


# Generated at 2022-06-12 05:27:21.921444
# Unit test for method __str__ of class First
def test_First___str__():
    first = First(1)
    assert str(first) == 'Fist[value=1]'


# Generated at 2022-06-12 05:27:25.955974
# Unit test for method concat of class Sum
def test_Sum_concat():  # pragma: no cover
    # Given
    left = Sum(10)
    right = Sum(11)

    # When
    result = left.concat(right)

    # Then
    expected = Sum(21)
    assert result == expected


# Generated at 2022-06-12 05:27:27.501630
# Unit test for constructor of class One
def test_One():
    a = One(1)
    assert a.value == 1


# Generated at 2022-06-12 05:27:30.547396
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)


# Generated at 2022-06-12 05:27:32.085541
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)



# Generated at 2022-06-12 05:27:35.551264
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(2) == Sum(2)
    assert Sum(2) != Sum(3)
    assert Sum(2).value == 2
    assert str(Sum(3)) == 'Sum[value=3]'


# Generated at 2022-06-12 05:27:38.869336
# Unit test for constructor of class Max
def test_Max():
    result = Max(1)
    assert result.value == 1

    result = Max(-float("inf"))
    assert result.value == -float("inf")



# Generated at 2022-06-12 05:27:40.959392
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert Sum(1) == Sum(1)


# Generated at 2022-06-12 05:27:44.571807
# Unit test for constructor of class Min
def test_Min():
    assert Min(10) == Min(10)
    assert Min(10).fold(lambda x: x + 1) == 11
    assert Min(7).concat(Min(11)).value == 7

test_Min()

# Generated at 2022-06-12 05:27:54.933926
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda value: value) == 1
    assert All(True).fold(lambda value: value) == True
    assert One(False).fold(lambda value: value) == False
    assert First('a').fold(lambda value: value) == 'a'
    assert Last('b').fold(lambda value: value) == 'b'
    assert Map({'a': Sum(1)}).fold(lambda value: value) == {'a': Sum(1)}
    assert Max(1).fold(lambda value: value) == 1
    assert Min(1).fold(lambda value: value) == 1

# Generated at 2022-06-12 05:27:56.439809
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)

# Generated at 2022-06-12 05:28:00.351917
# Unit test for method __str__ of class Map
def test_Map___str__():
    map = Map({
        'a': List([1]),
        'b': List([2, 3]),
    })
    assert 'Map[value={\'a\': List[value=[1]], \'b\': List[value=[2, 3]]}]' == str(map)


# Generated at 2022-06-12 05:28:07.214583
# Unit test for method concat of class All
def test_All_concat():
    """
    Tests that All.concat returns True if at least one of the values is True, and False otherwise.
    """
    assert All(True).concat(All(False)) == All(True)
    assert All(False).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(True).concat(All(True)) == All(True)


# Generated at 2022-06-12 05:28:09.599707
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(2) == Sum(2)
    assert Sum(0).value == 0
    assert Sum(1).value == 1


# Generated at 2022-06-12 05:28:10.919180
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(3)) == 'Min[value=3]'


# Generated at 2022-06-12 05:28:15.345910
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(5)) == 'Fist[value=5]'
    assert str(First('hello')) == 'Fist[value=hello]'


# Generated at 2022-06-12 05:28:16.526422
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-12 05:28:19.199220
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(2)
    b = Min(3)
    c = Min(1)
    assert a.concat(b) == Min(2)
    assert b.concat(c) == Min(1)


# Generated at 2022-06-12 05:28:20.546642
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(5)) == 'Max[value=5]'

# Generated at 2022-06-12 05:28:25.115971
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    check method __eq__ for class Semigroup
    """
    assert Sum(1) == Sum(1)
    assert not (Sum(1) == Sum(2))

# Generated at 2022-06-12 05:28:26.436188
# Unit test for method __str__ of class First
def test_First___str__():
    first = First("test")
    assert str(first) == "Fist[value=test]"


# Generated at 2022-06-12 05:28:30.259306
# Unit test for constructor of class Last
def test_Last():
    assert Last(5) == Last(5)
    assert Last(5) != Last(None)
    assert Last(5) != Last("string")


# Generated at 2022-06-12 05:28:32.197644
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)


# Generated at 2022-06-12 05:28:33.276991
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True


# Generated at 2022-06-12 05:28:35.951942
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    expected = 'Max[value=1]'
    observed = str(Max(1))

    assert expected == observed


# Generated at 2022-06-12 05:28:36.581244
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)



# Generated at 2022-06-12 05:28:42.046358
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(4).concat(First(2)) != First(2)
    assert First(2).concat(First(4)) == First(2)
    assert First(2).concat(First(2)) == First(2)
    assert First(1).concat(First(1)) == First(1)


# Generated at 2022-06-12 05:28:43.085729
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)


# Generated at 2022-06-12 05:28:45.935319
# Unit test for constructor of class All
def test_All():
    test_list = [True, False]
    for i in range(len(test_list)):
        obj = All(test_list[i])
        assert obj.value == test_list[i], 'Error in constructing All'


# Generated at 2022-06-12 05:28:56.308043
# Unit test for method concat of class Map
def test_Map_concat():
    """
    unit test for method concat of class Map
    """
    m = Map({'a': Sum(1), 'b': Sum(2)})
    m1 = Map({'a': Sum(3), 'b': Sum(4)})
    value = m.concat(m1)
    code = value.value
    code_type = type(code)
    assert code == {'a': Sum(4), 'b': Sum(6)}, "Method Map concat failed"
    assert code_type == dict, "Method Map concat failed"



# Generated at 2022-06-12 05:29:00.267001
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-12 05:29:04.230167
# Unit test for method concat of class Min
def test_Min_concat():

    assert Min(3).concat(Min(2)).value == 2
    assert Min(3).concat(Min(3)).value == 3
    assert Min(3).concat(Min(4)).value == 3

# Generated at 2022-06-12 05:29:10.184663
# Unit test for method concat of class First
def test_First_concat():
    """
    Test result of method concat of class First
    """
    assert First('first').concat(First('second')) == First('first')
    assert First(1).concat(First(0)) == First(1)
    assert First(0).concat(First(1)) == First(0)
    assert First('').concat(First('last')) == First('')
    assert First('first').concat(First('')) == First('first')
    assert First('').concat(First('last')) == First('')


# Generated at 2022-06-12 05:29:13.778437
# Unit test for method concat of class Min
def test_Min_concat():
    min1 = Min(1)
    min5 = Min(5)
    min_result = min1.concat(min5)
    assert min_result.value == 1


# Generated at 2022-06-12 05:29:16.413367
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(1)) == First(1)


# Generated at 2022-06-12 05:29:22.718013
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    eq_(Sum(1), Sum(1))
    eq_(All(True), All(True))
    eq_(One(False), One(False))
    eq_(First(1), First(1))
    eq_(Last(1), Last(1))
    eq_(Map({1: First(1), 2: Last(2)}), Map({1: First(1), 2: Last(2)}))
    eq_(Max(1), Max(1))
    eq_(Min(1), Min(1))

    assert Sum(1) != Sum(2)
    assert All(True) != All(False)
    assert One(False) != One(True)
    assert First(1) != First(2)
    assert Last(1) != Last(2)

# Generated at 2022-06-12 05:29:24.479678
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'

# Generated at 2022-06-12 05:29:26.356756
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert Semigroup.__doc__
    assert Semigroup(1)



# Generated at 2022-06-12 05:29:29.882905
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-12 05:29:38.037853
# Unit test for constructor of class Map
def test_Map():
    """
    >>> test_Map()
    Map[value={}] Map[value={}] Map[value={0: Sum[value=0], 1: Sum[value=1]}]
    """
    print(Map({}))
    print(Map({'_': Sum(1)}))
    print(Map({0: Sum(0), 1: Sum(1)}))

# Generated at 2022-06-12 05:29:40.123591
# Unit test for method concat of class First
def test_First_concat():
    value = 8
    result = First(value)
    assert isinstance(result, First)
    assert result.concat(result).value is result.value


# Generated at 2022-06-12 05:29:41.839106
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(2)) == "Max[value=2]"


# Generated at 2022-06-12 05:29:52.323361
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert str(Sum(0)) == "Sum[value=0]"
    assert str(All(True)) == "All[value=True]"
    assert str(One(False)) == "One[value=False]"
    assert str(First("first")) == "Fist[value=first]"
    assert str(Last("last")) == "Last[value=last]"
    assert str(Map({"a": Sum(0)})) == "Map[value={'a': Sum[value=0]}]"
    assert str(Max(5)) == "Max[value=5]"
    assert str(Min(5)) == "Min[value=5]"
    assert Sum(0).concat(Sum(3)).value == Sum(3).concat(Sum(0)).value == 3
    assert All(True).concat(All(True)).value is True
   

# Generated at 2022-06-12 05:29:54.129228
# Unit test for method __str__ of class First
def test_First___str__(): # pragma: no cover
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-12 05:29:55.972147
# Unit test for constructor of class One
def test_One():
    one = One(True)
    assert_that(one.value).is_equal_to(True)


# Generated at 2022-06-12 05:29:57.236976
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-12 05:29:58.469689
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)


# Generated at 2022-06-12 05:30:00.709715
# Unit test for constructor of class Max
def test_Max():
    assert Max(5).fold(lambda x: x) == 5


# Generated at 2022-06-12 05:30:02.745567
# Unit test for constructor of class Min
def test_Min():
    MonoidTest = Min(3)
    assert MonoidTest.value == 3


# Generated at 2022-06-12 05:30:07.599047
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert not Semigroup(1).__eq__(Semigroup(2))
    assert Semigroup(1).__eq__(Semigroup(1))

# Generated at 2022-06-12 05:30:08.816063
# Unit test for constructor of class One
def test_One():
    one = One(True)


# Tests for Sum Monoid

# Generated at 2022-06-12 05:30:12.454794
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    # Given
    sum_value = 5
    sum_instance = Sum(sum_value)

    # When
    result = semigroup_fold(sum_instance.fold)

    # Than
    assert result == sum_instance.value

# Generated at 2022-06-12 05:30:15.502794
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last("first").concat(Last("second")) == Last("second")
    assert Last(None).concat(Last(False)) == Last(False)


# Generated at 2022-06-12 05:30:17.260938
# Unit test for constructor of class Last
def test_Last():
    actual = Last(False)
    expected = Last(False)
    assert actual == expected


# Generated at 2022-06-12 05:30:20.356140
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'



# Generated at 2022-06-12 05:30:25.150876
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(4).concat(Sum(3)) == Sum(7)
    assert Sum(0).concat(Sum(1)) == Sum(1)
    assert Sum(1).concat(Sum(0)) == Sum(1)



# Generated at 2022-06-12 05:30:26.633366
# Unit test for constructor of class First
def test_First():
    semigroup = First(1)

    assert semigroup.value == 1



# Generated at 2022-06-12 05:30:29.751399
# Unit test for method __str__ of class First
def test_First___str__():
    """test_First___str__() -> NoneType
    Expect 'Fist[value={}]'.format(value)
    """
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-12 05:30:32.143973
# Unit test for method concat of class Map
def test_Map_concat():
    a = Map({"a": Min(0)})
    b = Map({"a": Min(100)})
    assert a.concat(b).value == {"a": Min(0)}



# Generated at 2022-06-12 05:30:36.720618
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'



# Generated at 2022-06-12 05:30:38.636613
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First(1)) == 'First[value=1]'


# Generated at 2022-06-12 05:30:42.075200
# Unit test for method __str__ of class Min
def test_Min___str__():
    from hamcrest import assert_that, equal_to

    obj = Min(1)

    actual = str(obj)
    expected = 'Min[value=1]'

    assert_that(actual, equal_to(expected))



# Generated at 2022-06-12 05:30:44.361798
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(2)) == "Last[value=2]"



# Generated at 2022-06-12 05:30:47.249200
# Unit test for method __str__ of class One
def test_One___str__():
    assert 'One[value=False]' == str(One(False))
    assert 'One[value=True]' == str(One(True))
    assert 'One[value=1]' == str(One(1))



# Generated at 2022-06-12 05:30:48.579456
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(10)) == "Last[value=10]"


# Generated at 2022-06-12 05:30:55.369309
# Unit test for constructor of class Map
def test_Map():
    assert Map({0: First(2), 1: Last(3)}) == Map({0: First(2), 1: Last(3)})



# Generated at 2022-06-12 05:30:57.700245
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(6).concat(Max(8)) == Max(8)


# Generated at 2022-06-12 05:30:58.539477
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(5)) == 'Last[value=5]'

# Generated at 2022-06-12 05:31:00.659404
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(0)) == 'Min[value=0]'  # pragma: no cover

# Generated at 2022-06-12 05:31:06.086969
# Unit test for constructor of class Map
def test_Map():
    assert Map({1: Sum(1), 2: Sum(1)}).value == {1: Sum(1), 2: Sum(1)}


# Generated at 2022-06-12 05:31:09.942894
# Unit test for method concat of class First
def test_First_concat():  # pragma: no cover
    assert First('x').concat(First('y')) == First('x')
    assert First('y').concat(First('x')) == First('x')


# Generated at 2022-06-12 05:31:13.830928
# Unit test for method concat of class Last
def test_Last_concat():  # pragma: no cover
    last1 = Last(1)
    last2 = Last(2)
    last3 = last1.concat(last2)
    assert last3.value == last2.value


# Generated at 2022-06-12 05:31:16.442080
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1), "Last should have 1 as value"



# Generated at 2022-06-12 05:31:18.702671
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'

# Unit tes for method concat of class Max

# Generated at 2022-06-12 05:31:20.881977
# Unit test for method __str__ of class First
def test_First___str__():
    f = First(1)
    assert str(f) == 'Fist[value=1]'



# Generated at 2022-06-12 05:31:27.130248
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    assert Last(1).__str__() == 'Last[value=1]'
    assert Last(None).__str__() == 'Last[value=None]'
    assert Last('test').__str__() == 'Last[value=test]'
    assert Last(True).__str__() == 'Last[value=True]'


# Generated at 2022-06-12 05:31:30.716445
# Unit test for constructor of class Last
def test_Last():
    assert Last(123).value == 123, 'Last(123).value == 123'
    assert Last(567).value == 567, 'Last(567).value == 567'

    assert not hasattr(Last, 'neutral_element'), 'not hasattr(Last, "neutral_element")'


# Generated at 2022-06-12 05:31:32.609132
# Unit test for method __str__ of class Last
def test_Last___str__():
    s = Last(1)
    assert str(s) == "Last[value=1]"


# Generated at 2022-06-12 05:31:34.043183
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == "Max[value=1]"

# Generated at 2022-06-12 05:31:38.768518
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(5) == Sum(5)

# Generated at 2022-06-12 05:31:45.836522
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert First('a') == First('a')
    assert Last('a') == Last('a')
    assert Sum(1) == Sum(1)
    assert Max(2) == Max(2)
    assert Min(2) == Min(2)
    assert not First('a') == First('b')
    assert not Last('a') == Last('b')
    assert not Sum(1) == Sum(2)
    assert not Max(2) == Max(1)
    assert not Min(2) == Min(1)



# Generated at 2022-06-12 05:31:47.240833
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-12 05:31:49.275834
# Unit test for constructor of class All
def test_All():  # pragma: no cover
    assert All(True).value is True
    assert All(False).value is False


# Generated at 2022-06-12 05:31:51.638594
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1


# Generated at 2022-06-12 05:31:58.174236
# Unit test for constructor of class Semigroup
def test_Semigroup():
    test_sum = Sum(3)
    assert test_sum.value == 3
    assert str(test_sum) == 'Sum[value=3]'
    test_all = All(False)
    assert test_all.value == False
    assert str(test_all) == 'All[value=False]'
    test_one = One(False)
    assert test_one.value == False
    assert str(test_one) == 'One[value=False]'
    test_first = First(3)
    assert test_first.value == 3
    assert str(test_first) == 'Fist[value=3]'
    test_last = Last(3)
    assert test_last.value == 3
    assert str(test_last) == 'Last[value=3]'

# Generated at 2022-06-12 05:32:01.165207
# Unit test for method __str__ of class Max
def test_Max___str__():
    value = random.randrange(0, 101)

    assert str(Max(value)) == 'Max[value={}]'.format(value)



# Generated at 2022-06-12 05:32:02.200379
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(4)) == 'Last[value=4]'


# Generated at 2022-06-12 05:32:04.676780
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'



# Generated at 2022-06-12 05:32:07.877481
# Unit test for constructor of class One
def test_One():
    assert One(False) == One(False)
    assert One(False) != One(True)

    assert One(True).value
    assert not One(False).value


# Generated at 2022-06-12 05:32:15.924319
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(2) == Sum(2)
    assert Sum(3) == Sum(3)


# Generated at 2022-06-12 05:32:17.681776
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(10)) == 'Sum[value=10]'


# Generated at 2022-06-12 05:32:20.489374
# Unit test for constructor of class Max
def test_Max():
    assert Max(3) == Max(3)
    assert not Max(3) == Sum(3)
    assert Max(7) != Max(3)


# Generated at 2022-06-12 05:32:30.155738
# Unit test for method concat of class Map
def test_Map_concat():
    map_1 = Map({'sum1': Sum(1).concat(Sum(2)), 'all1': All(True).concat(All(False))})
    map_2 = Map({'sum1': Sum(3).concat(Sum(4)), 'all1': All(False).concat(All(True))})
    assert map_1.concat(map_2).value['sum1'] == Sum(10), "Concat didn't work"
    assert map_1.concat(map_2).value['all1'].value, "Concat didn't work"

# Generated at 2022-06-12 05:32:34.123622
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(5).concat(Min(3)) == Min(3)
    assert Min(3).concat(Min(5)) == Min(3)


# Generated at 2022-06-12 05:32:35.970825
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(5)) == "Max[value=5]"


# Generated at 2022-06-12 05:32:38.347009
# Unit test for method __str__ of class All
def test_All___str__():
    all_obj = All(True)
    assert str(all_obj) == 'All[value=True]'


# Generated at 2022-06-12 05:32:42.401094
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(None)) == Last(None)
    assert Last(None).concat(Last(2)) == Last(2)

# Generated at 2022-06-12 05:32:43.797554
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(5)) == 'Max[value=5]'


# Generated at 2022-06-12 05:32:49.071269
# Unit test for method concat of class Map
def test_Map_concat():
    map_1 = Map({1: Sum(1), 2: Sum(2)})
    map_2 = Map({1: Sum(2), 2: Sum(3)})
    assert map_1.concat(map_2) == Map({1: Sum(3), 2: Sum(5)})



# Generated at 2022-06-12 05:32:54.033805
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(123)) == 'Min[value=123]'


# Generated at 2022-06-12 05:33:05.194626
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(Last(2)) == First(1)
    assert First(1).concat(All(True)) == First(1)
    assert First(1).concat(All(False)) == First(1)
    assert First(1).concat(Sum(2)) == First(1)
    assert First(1).concat(Max(2)) == First(1)
    assert First(1).concat(Min(2)) == First(1)
    assert First(1).concat(One(True)) == First(1)
    assert First(1).concat(One(False)) == First(1)

    assert First(1).concat(First(2)).concat(First(3)) == First(1)

# Generated at 2022-06-12 05:33:16.235195
# Unit test for method concat of class Map
def test_Map_concat():
    """
    :returns: True of Map.concat is working correctly, False otherwise
    :rtype: bool
    """
    x = Map(
        {
            "a": First(1),
            "b": Last(2),
            "c": Max(3),
            "d": Min(4),
            "e": Sum(5),
            "f": All(6),
            "g": One(7),
        }
    )
    y = Map(
        {
            "a": First(8),
            "b": Last(9),
            "c": Max(10),
            "d": Min(11),
            "e": Sum(12),
            "f": All(13),
            "g": One(14),
        }
    )
    z = x.concat(y)
   

# Generated at 2022-06-12 05:33:18.458184
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    def add_one(value):
        return value + 1
    assert Semigroup(3).fold(add_one) == 4

# Generated at 2022-06-12 05:33:19.430383
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == "Min[value=1]"



# Generated at 2022-06-12 05:33:22.762993
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(0).concat(Min(5)).concat(Min(-2)).value == -2


# Generated at 2022-06-12 05:33:28.023808
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(True).concat(One(True)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-12 05:33:29.908281
# Unit test for method __str__ of class Min
def test_Min___str__():
    min_ = Min(10)
    assert str(min_) == "Min[value=10]"



# Generated at 2022-06-12 05:33:31.225779
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(5) == Sum(5)



# Generated at 2022-06-12 05:33:34.024254
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(2) == Sum(2)
    assert Sum(2).value == 2
    assert Sum(2) != 2
    assert Sum(2) != Sum(3)
    assert not Sum(2).neutral().value


# Generated at 2022-06-12 05:33:48.127738
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert Semigroup(123) == Semigroup(123)
    assert Semigroup([1, 2, 3]) == Semigroup([1, 2, 3])
    assert Semigroup([1, 2, 3]) != Semigroup([1, 2, 3, 4])
    assert Semigroup([1, 2, 3]) != Semigroup([1, 2])
    assert Semigroup('a') == Semigroup('a')
    assert Semigroup('a') != Semigroup('abc')
    assert Semigroup('abc') != Semigroup('abcde')
    assert Semigroup([1, 2, 3]) != Semigroup('abc')
    assert Semigroup(123) != Semigroup(456)
    assert Semigroup(123) != Semigroup(1230)
    assert Semigroup(123) != Semigroup(12)