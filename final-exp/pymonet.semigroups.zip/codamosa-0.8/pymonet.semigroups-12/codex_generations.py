

# Generated at 2022-06-12 05:23:57.556158
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map({'a': All(True), 'b': First(1), 'c': Sum(1)})
    map2 = Map({'a': All(True), 'b': First(2), 'c': Sum(2)})
    map_res = map1.concat(map2)
    res = Map({'a': All(True), 'b': First(1), 'c': Sum(3)})
    assert map_res == res, 'wrong result'

# Generated at 2022-06-12 05:24:01.213162
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"a": 1, "b": 2}).concat(Map({"a": 3, "c": -1})) == Map({"a": 4, "b": 2, "c": -1})


# Generated at 2022-06-12 05:24:13.144790
# Unit test for method concat of class Map
def test_Map_concat():
    """
    :returns: AssertionError | None

    >>> test_Map_concat()
    """
    test_1 = Map({1: Sum(1), 2: Sum(2), 3: Sum(3)})
    test_2 = Map({4: Sum(4), 5: Sum(5), 6: Sum(6)})
    test_3 = Map({7: Sum(7), 8: Sum(8), 9: Sum(9)})

    test_4 = Map({1: Sum(1), 2: Sum(2), 3: Sum(3)})
    test_5 = Map({4: Sum(4), 5: Sum(5), 6: Sum(6)})
    test_6 = Map({7: Sum(7), 8: Sum(8), 9: Sum(9)})


# Generated at 2022-06-12 05:24:17.436914
# Unit test for method concat of class Map
def test_Map_concat():
    """
    Test for method concat of class Map
    """
    assert Map({"one": Sum(1), "two": Sum(2)}).concat(Map({"one": Sum(1), "two": Sum(2)})
    ) == Map({"one": Sum(2), "two": Sum(4)})

# Generated at 2022-06-12 05:24:22.733059
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"key": Sum(1)}).concat(
        Map({"key": Sum(1)})).value == Map({"key": Sum(2)}).value
    assert Map({"key": Sum(1)}).concat(
        Map({"key_new": Sum(1)})).value == Map({"key": Sum(1), "key_new": Sum(1)}).value

# Generated at 2022-06-12 05:24:25.611142
# Unit test for method concat of class Map
def test_Map_concat():
    map_1 = Map({1: Sum(1), 2: Sum(2)})
    map_2 = Map({1: Sum(2), 3: Sum(3)})
    assert map_1.concat(map_2).value == {1: Sum(3), 2: Sum(2), 3: Sum(3)}

# Generated at 2022-06-12 05:24:30.936724
# Unit test for method concat of class Map
def test_Map_concat():
    m = Map({'a': Sum(1)})
    n = Map({'a': Sum(2)})
    result = m.concat(n)
    assert result.value == {'a': Sum(3)}

    p = Map({'a': Max(1)})
    q = Map({'a': Max(2)})
    result = p.concat(q)
    assert result.value == {'a': Max(2)}

    p = Map({'a': Min(1)})
    q = Map({'a': Min(2)})
    result = p.concat(q)
    assert result.value == {'a': Min(1)}


if __name__ == "__main__":
    test_Map_concat()

# Generated at 2022-06-12 05:24:35.469113
# Unit test for method concat of class Map
def test_Map_concat():
    result = Map({'name': First('John'), 'age': Sum(42)}).concat(
        Map({'name': Last('Doe'), 'age': Sum(1)}))
    assert result == Map({'name': Last('Doe'), 'age': Sum(43)})



# Generated at 2022-06-12 05:24:43.525568
# Unit test for method concat of class Map
def test_Map_concat():
    # Arrange
    Map1 = Map({1: Sum(1), 2: Sum(2), 3: Sum(3)})
    Map2 = Map({1: Sum(4), 2: Sum(5), 3: Sum(6)})
    expected = Map({1: Sum(5), 2: Sum(7), 3: Sum(9)})

    # Act
    actual = Map1.concat(Map2)

    # Assert
    assert expected.value == actual.value

# Generated at 2022-06-12 05:24:48.126752
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({1: Sum(1), 2: Min(2)}).concat(Map({1: Sum(4), 2: Min(1), 3: Min(8)})) == Map({
        1: Sum(5), 2: Min(1), 3: Min(8)
    })


# Generated at 2022-06-12 05:24:53.189712
# Unit test for constructor of class Max
def test_Max():
    number_one = Max(1)
    number_two = Max(2)
    a = number_one.concat(number_two)
    assert a.value == 2

# Generated at 2022-06-12 05:24:55.804627
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({
        1: Sum(1)
    })) == 'Map[value={1: Sum[value=1]}]'



# Generated at 2022-06-12 05:25:03.303614
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'
    assert str(Last('hello')) == 'Last[value=hello]'
    assert str(Last(('a', 3))) == 'Last[value=(\'a\', 3)]'
    assert str(Last(['a', 3])) == 'Last[value=[\'a\', 3]]'
    assert str(Last(['a', ['a', 3]])) == 'Last[value=[\'a\', [\'a\', 3]]]'


# Generated at 2022-06-12 05:25:04.787324
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == "Min[value=1]"


# Generated at 2022-06-12 05:25:06.152619
# Unit test for constructor of class Sum
def test_Sum():
    sum = Sum(2)
    assert sum.value == 2



# Generated at 2022-06-12 05:25:08.132009
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'
    assert str(Sum(2)) == 'Sum[value=2]'


# Generated at 2022-06-12 05:25:10.445854
# Unit test for method __str__ of class All
def test_All___str__():
    actual = str(All(False))
    assert actual == 'All[value=False]'



# Generated at 2022-06-12 05:25:11.681057
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(2)) == 'Last[value=2]'


# Generated at 2022-06-12 05:25:13.548485
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(3) == Min(3).concat(Min(5))


# Generated at 2022-06-12 05:25:15.248715
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(8)) == 'Min[value=8]'


# Generated at 2022-06-12 05:25:18.581823
# Unit test for method concat of class Last
def test_Last_concat():
    print("test_Last_concat")
    assert Last("bar").concat("foo") == "foo", "dont work"


# Generated at 2022-06-12 05:25:19.934271
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2



# Generated at 2022-06-12 05:25:22.681738
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    l = Semigroup(1)
    r = Semigroup(1)
    assert l == r

    l = Semigroup(True)
    r = Semigroup(True)
    assert l == r


# Generated at 2022-06-12 05:25:25.150008
# Unit test for constructor of class Map
def test_Map():
    m = Map({'a': Sum(1), 'b': Sum(2)})
    assert m.value == {'a': Sum(1), 'b': Sum(2)}



# Generated at 2022-06-12 05:25:26.314918
# Unit test for constructor of class Max
def test_Max():
    assert Max(4).value == Max(4).value


# Generated at 2022-06-12 05:25:30.542551
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """test_Semigroup_fold

    :returns: TODO

    """
    assert Semigroup(0).fold(lambda a: a + 5) == 5
    assert Semigroup(1).fold(lambda a: a + 5) == 6
    assert Semigroup(100).fold(lambda a: a + 5) == 105
    assert Semigroup(-1).fold(lambda a: a + 5) == 4
    assert Semigroup(-10).fold(lambda a: a + 5) == -5



# Generated at 2022-06-12 05:25:34.020176
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)

# Generated at 2022-06-12 05:25:35.398536
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(3) == Semigroup(3)


# Generated at 2022-06-12 05:25:42.898852
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert fold(Sum, [1, 2, 3]) == 6
    assert fold(All, [True, False, True]) is False
    assert fold(All, [True, True]) is True
    assert fold(One, [True, False, False]) is True
    assert fold(One, [False, False, False]) is False
    assert fold(First, [1, 2, 3]) == 1
    assert fold(Last, [1, 2, 3]) == 3
    assert fold(Min, [1, 2, 3]) == 1



# Generated at 2022-06-12 05:25:46.426103
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First('2')) == "Fist[value=2]"


# Generated at 2022-06-12 05:25:50.774887
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert First(1).__str__() == 'Fist[value=1]'
    assert First('First').__str__() == 'Fist[value=First]'


# Generated at 2022-06-12 05:25:52.069452
# Unit test for constructor of class First
def test_First():
    assert First(123) == First(123)


# Generated at 2022-06-12 05:25:57.145794
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Sum(1)) == 'Sum[value=1]'
    assert str(All(True)) == 'All[value=True]'
    assert str(One(True)) == 'One[value=True]'
    assert str(First(1)) == 'Fist[value=1]'
    assert str(Last(1)) == 'Last[value=1]'
    assert str(Map({})) == 'Map[value={}]'
    assert str(Max(1)) == 'Max[value=1]'
    assert str(Min(1)) == 'Min[value=1]'



# Generated at 2022-06-12 05:25:57.911000
# Unit test for constructor of class Min
def test_Min():# -> None:
    assert Min(5) == Min(5)

test_Min()

# Generated at 2022-06-12 05:26:01.187437
# Unit test for method concat of class First
def test_First_concat():  # pragma: no cover
    first = First('first')
    last = Last('last')
    result = first.concat(last)
    assert result.value == first.value



# Generated at 2022-06-12 05:26:03.646316
# Unit test for constructor of class Max
def test_Max():
    assert Max(9) == Max(9)
    assert Max(9).value == 9
    assert Max(9).value == Max(9).value


# Generated at 2022-06-12 05:26:06.888412
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).concat(Min(3)) == Min(3)
    assert Min(3).concat(Min(2)).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(3)).concat(Min(2)) == Min(2)



# Generated at 2022-06-12 05:26:11.863719
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value == True
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
    assert All(False).concat(All(False)).value == False


# Generated at 2022-06-12 05:26:19.637285
# Unit test for method concat of class Map
def test_Map_concat():
    """
    :returns: True if test passed, otherwise False
    :rtype: bool
    """
    v1 = Map({
        'first': Sum(1),
        'second': All(True),
        'third': One(True)
    })
    v2 = Map({
        'first': Sum(2),
        'second': All(False),
        'third': One(False)
    })
    assert v1.concat(v2) == Map({
        'first': Sum(3),
        'second': All(False),
        'third': One(True)
    })


# Generated at 2022-06-12 05:26:24.751078
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)



# Generated at 2022-06-12 05:26:32.888254
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    Unit test for method __eq__ of class Semigroup
    """
    assert Sum(1) == Sum(1)
    assert One("world") == One("world")
    assert not All(False) == All(True)
    assert First("hello") == First("world")

# Generated at 2022-06-12 05:26:35.549866
# Unit test for method concat of class Min
def test_Min_concat():
    x = Min(3)
    y = Min(5)
    assert x.concat(y).value == 3
    assert y.concat(x).value == 3


# Generated at 2022-06-12 05:26:41.496508
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    my_semigroup = Semigroup(["a","b","c"])
    assert(my_semigroup.fold(len) == 3)

    my_semigroup = Semigroup([1,2,3,4,5])
    assert(my_semigroup.fold(lambda x: x[0] * x[1]) == 120)


# Generated at 2022-06-12 05:26:42.740116
# Unit test for method concat of class Last
def test_Last_concat():
    last_one = Last('1')
    last_two = Last('2')
    assert last_two.concat(last_one) == Last('1')



# Generated at 2022-06-12 05:26:46.320420
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-12 05:26:55.219600
# Unit test for method concat of class First
def test_First_concat():
    """
    :return: void
    """
    assert First(5).concat(First(7)) == First(5)
    assert First(5).concat(First(None)) == First(5)
    assert First(5).concat(First(3)) == First(5)
    assert First(None).concat(First(3)) == First(None)
    assert First(None).concat(First(None)) == First(None)
    assert First([]).concat(First([1])) == First([])
    assert First([1]).concat(First([2])) == First([1])
    assert First([1]).concat(First([1, 2])) == First([1])



# Generated at 2022-06-12 05:26:57.597841
# Unit test for method __str__ of class Min
def test_Min___str__():  # pragma: no cover
    assert str(Min(1)) == 'Min[value=1]'



# Generated at 2022-06-12 05:27:05.131566
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():  # pragma: no cover
    sg_a = Sum(1)
    sg_b = Sum(2)
    sg_c = Sum(1)

    assert sg_a == sg_a
    assert sg_a == sg_c
    assert sg_a != sg_b
    assert sg_b != sg_a
    assert sg_b == sg_b


# Generated at 2022-06-12 05:27:07.346776
# Unit test for constructor of class Max
def test_Max():
    assert Max(10) == (Max(10))


# Generated at 2022-06-12 05:27:09.893513
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    one = One(True)
    assert str(one) == 'One[value=True]'


# Generated at 2022-06-12 05:27:15.174970
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    sum = Sum(10)
    assert sum.value == 10


# Generated at 2022-06-12 05:27:16.346550
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(2) == Semigroup(2)


# Generated at 2022-06-12 05:27:19.429406
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(5) == Sum(5)
    assert not Sum(5) == Sum(10)


# Generated at 2022-06-12 05:27:20.965017
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-12 05:27:24.028387
# Unit test for method concat of class Max
def test_Max_concat():
    max_a = Max(10)
    max_b = Max(20)
    assert max_a.concat(max_b) == Max(20)



# Generated at 2022-06-12 05:27:25.847433
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)


# Generated at 2022-06-12 05:27:34.997494
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x + 1) == 2
    assert All(True).fold(lambda x: x) == True
    assert One(False).fold(lambda x: x) == False
    assert First(True).fold(lambda x: x) == True
    assert Last(True).fold(lambda x: x) == True
    assert Map({"a": Sum(1), "b": Sum(2)}).fold(lambda x: x["a"].value) == 1
    assert Max(1).fold(lambda x: x) == 1
    assert Min(1).fold(lambda x: x) == 1



# Generated at 2022-06-12 05:27:36.603244
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(10).concat(Last(99)).value == 99


# Generated at 2022-06-12 05:27:39.282337
# Unit test for constructor of class Max
def test_Max():
    """
    >>> test_Max()
    Max[value=0]
    """
    print(Max(0))



# Generated at 2022-06-12 05:27:45.134984
# Unit test for method concat of class Map
def test_Map_concat():
    map = Map({'a': Last(1), 'b': Last(2), 'c': Last(3)})
    map = map.concat(Map({'a': Last(4), 'b': Last(5), 'c': Last(6)}))
    assert map.value == {'a': Last(4), 'b': Last(5), 'c': Last(6)}

# Generated at 2022-06-12 05:27:51.738504
# Unit test for method __str__ of class Max
def test_Max___str__(): # pragma: no cover
    sum_ = Max(100500)
    assert str(sum_) == "Max[value=100500]", "Method __str__ of class Max worked incorrect!"


# Generated at 2022-06-12 05:27:54.026725
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"


# Generated at 2022-06-12 05:27:56.354998
# Unit test for method concat of class Map
def test_Map_concat():
    # TODO: provide tests
    pass

# Generated at 2022-06-12 05:28:02.549428
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(0)) == Sum(1)
    assert Sum(-1).concat(Sum(-2)) == Sum(-3)
    assert Sum(-1).concat(Sum(0)) == Sum(-1)
    assert Sum(10).concat(Sum(0)) == Sum(10)
    assert Sum(0).concat(Sum(0)) == Sum(0)
    assert Sum(0).concat(Sum(0)) == Sum(1).concat(Sum(-1))



# Generated at 2022-06-12 05:28:03.986179
# Unit test for constructor of class Min
def test_Min():
    assert Min(2).value == 2


# Generated at 2022-06-12 05:28:08.913700
# Unit test for method __str__ of class Map
def test_Map___str__():
    """
    :returns: None
    :rtype: None
    """
    assert str(Map({'a': Min(12), 'b': Sum(1)})) == "Map[value={'a': Min[value=12], 'b': Sum[value=1]}]"



# Generated at 2022-06-12 05:28:12.398635
# Unit test for constructor of class Last
def test_Last():
    last = Last(3)
    assert last.value == 3
    assert str(last) == "Last[value=3]"


# Generated at 2022-06-12 05:28:15.248418
# Unit test for method __str__ of class Min
def test_Min___str__():  # pragma: no cover
    assert str(Min(123)) == "Min[value=123]"


# Generated at 2022-06-12 05:28:16.800677
# Unit test for constructor of class All
def test_All():
    assert All(False).value == False
    assert All(True).value == True


# Generated at 2022-06-12 05:28:17.983193
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == "Fist[value=1]"


# Generated at 2022-06-12 05:28:24.569243
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(10).concat(Sum(10)) == Sum(20), "Simples test for Sum concat."



# Generated at 2022-06-12 05:28:27.795735
# Unit test for method concat of class Last
def test_Last_concat():
    """
    Test for method concat of class Last
    """
    assert Last(10).concat(Last(5)) == Last(5)
    assert Last(5).concat(Last(10)) == Last(10)



# Generated at 2022-06-12 05:28:31.880330
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)



# Generated at 2022-06-12 05:28:33.382327
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(3)) == 'Max[value=3]'



# Generated at 2022-06-12 05:28:38.940947
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():  # pragma: no cover
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)
    assert not Semigroup(1) == Semigroup('foo')
    l = []
    for i in range(1, 26):
        l.append(i)
    assert not Semigroup(l) == Semigroup(l)


# Generated at 2022-06-12 05:28:40.348218
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(10)) == "Min[value=10]"


# Generated at 2022-06-12 05:28:43.652466
# Unit test for constructor of class First
def test_First():
    assert First(10) == First(10)
    assert str(First(10)) == 'Fist[value=10]'
    assert First(10).concat(First(100)) == First(10)


# Generated at 2022-06-12 05:28:47.441637
# Unit test for constructor of class Map
def test_Map():
    # arrange
    expected = Sum(2)
    data_dict = {1: Sum(1), 2: Sum(2)}

    # act
    result = Map(data_dict)

    # assert
    assert result.value[2] == expected



# Generated at 2022-06-12 05:28:50.020457
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-12 05:28:51.673446
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)

# Generated at 2022-06-12 05:28:59.021867
# Unit test for constructor of class One
def test_One():  # pragma: no cover
    a = One(56)
    assert(a.value == 56)


# Generated at 2022-06-12 05:29:01.644361
# Unit test for method __str__ of class One
def test_One___str__():
    result = One(1)
    assert str(result) == 'One[value=1]'



# Generated at 2022-06-12 05:29:05.544577
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == "Map[value={'a': Sum[value=1], 'b': Sum[value=2]}]"



# Generated at 2022-06-12 05:29:07.262447
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'
    assert str(One(False)) == 'One[value=False]'



# Generated at 2022-06-12 05:29:13.408193
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-12 05:29:15.745750
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'



# Generated at 2022-06-12 05:29:17.337584
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum.concat(Sum(2), Sum(3)) == Sum(5)



# Generated at 2022-06-12 05:29:19.265622
# Unit test for method concat of class First
def test_First_concat():
    assert First('first').concat(First('second')).value == 'first'


# Generated at 2022-06-12 05:29:21.424178
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(5).concat(Min(6)) == Min(5)



# Generated at 2022-06-12 05:29:32.350475
# Unit test for method concat of class Map
def test_Map_concat():
    """
    Unit test for method concat of class Map

    :returns: if test passed returns True, otherwise returns False
    :rtype: bool
    """
    # create first Map with numbers
    _dict1 = Map({1: Sum(1), 2: Sum(2), 3: Sum(3)})

    # create second Map with numbers
    _dict2 = Map({1: Sum(100), 2: Sum(200), 3: Sum(300)})

    # concat 2 maps:
    _dict = _dict1.concat(_dict2)

    # create test map with numbers
    _dict_test = {1: Sum(101), 2: Sum(202), 3: Sum(303)}

    return _dict.value == _dict_test

# Generated at 2022-06-12 05:29:46.051539
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x + 1) == 2


# Generated at 2022-06-12 05:29:47.386330
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-12 05:29:51.311728
# Unit test for method concat of class Last
def test_Last_concat():
    """
    Ensure method concat
    :return:
    """
    l1 = Last(1)
    l2 = Last(2)
    assert l1.concat(l2).value == 2
    assert l2.concat(l1).value == 1



# Generated at 2022-06-12 05:29:54.865389
# Unit test for method concat of class All
def test_All_concat():
    assert (All(True).concat(All(False))).equals(All(False)) == True
    assert (All(False).concat(All(True))).equals(All(False)) == True
    assert (All(True).concat(All(True))).equals(All(True)) == True
    assert (All(False).concat(All(False))).equals(All(False)) == True


# Generated at 2022-06-12 05:29:58.076730
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(5).concat(Last(6)).value == 6
    assert Last('Hello').concat(Last('world')).value == 'world'
    assert Last(True).concat(Last(False)).value is False

# Generated at 2022-06-12 05:30:02.294755
# Unit test for method __str__ of class Min
def test_Min___str__():
    """
    Unit test for method __str__ of class Min
    """
    min_test = Min(5)
    min_test_str = 'Min[value=5]'
    assert str(min_test) == min_test_str



# Generated at 2022-06-12 05:30:03.972419
# Unit test for constructor of class First
def test_First():
    assert First(True)
    assert First(False)
    assert not First(None)



# Generated at 2022-06-12 05:30:05.938402
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert Min(4).__str__() == 'Min[value=4]'


# Generated at 2022-06-12 05:30:08.090786
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(2) == First(2)
    assert First(1) != First(2)



# Generated at 2022-06-12 05:30:12.004386
# Unit test for method __str__ of class Map
def test_Map___str__():
    map_ = Map({'foo': First('bar'), 'baz': Last('qux')})
    assert str(map_) == 'Map[value={\'foo\': Fist[value=bar], \'baz\': Last[value=qux]}]'



# Generated at 2022-06-12 05:30:38.199159
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'

# Generated at 2022-06-12 05:30:46.003527
# Unit test for method concat of class Min
def test_Min_concat():
    """
    Test for method concat of class Min
    """
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)
    assert Min(-1).concat(Min(-2)) == Min(-2)
    assert Min(-2).concat(Min(-1)) == Min(-2)
    assert Min(-1).concat(Min(-1)) == Min(-1)


# Generated at 2022-06-12 05:30:47.040670
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == "Last[value=1]"


# Generated at 2022-06-12 05:30:53.232459
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(None).concat(One(True)) == One(True)
    assert One(1).concat(One(0)) == One(1)
    assert One(1).concat(One(1)) == One(1)
    assert One(0).concat(One(None)) == One(None)


# Generated at 2022-06-12 05:30:54.922462
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]', 'Wrong value of All'


# Generated at 2022-06-12 05:30:59.311354
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    fold method map value with function
    """
    assert Semigroup(10).fold(lambda x: x ** 2) == 100
    assert Semigroup("hello").fold(lambda x: x.upper()) == "HELLO"

    # Unit test for method concat of class Sum

# Generated at 2022-06-12 05:31:01.356661
# Unit test for constructor of class Min
def test_Min():
    min_instance = Min(50)
    assert min_instance.value == 50


# Generated at 2022-06-12 05:31:09.531071
# Unit test for method concat of class Min
def test_Min_concat():
    """
    Test for concat method of Min class.
    """
    # Test with int values
    first_value = 100
    second_value = 200
    assert Min(first_value).concat(Min(second_value)) == Min(first_value)
    first_value = 200
    second_value = 100
    assert Min(first_value).concat(Min(second_value)) == Min(second_value)

    # Test with float values
    first_value = 100.55
    second_value = 100.55
    assert Min(first_value).concat(Min(second_value)) == Min(first_value)
    first_value = 100.55
    second_value = 100
    assert Min(first_value).concat(Min(second_value)) == Min(second_value)
    first_value = 100

# Generated at 2022-06-12 05:31:11.745958
# Unit test for method concat of class All
def test_All_concat():
    """
    Test concat method of All instance
    """
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(False)) == All(False)


# Generated at 2022-06-12 05:31:22.071071
# Unit test for method concat of class Max
def test_Max_concat():
    # Tests for None value
    assert isinstance(Max(None).concat(Max(-100)), Max)
    assert isinstance(Max(-100).concat(Max(None)), Max)
    assert isinstance(Max(None).concat(Max(None)), Max)
    # Tests for float value
    assert isinstance(Max(10.0).concat(Max(20.0)), Max)
    assert isinstance(Max(10.0).concat(Max(20.0)).value, float)
    assert Max(10.0).concat(Max(20.0)).value == 20.0
    # Tests for int value
    assert isinstance(Max(10).concat(Max(20)), Max)
    assert isinstance(Max(10).concat(Max(20)).value, int)

# Generated at 2022-06-12 05:32:16.760689
# Unit test for method concat of class First
def test_First_concat():
    left = First("first")
    right = First("second")
    concat = left.concat(right)
    assert concat.value == "first"



# Generated at 2022-06-12 05:32:21.384665
# Unit test for method concat of class Min
def test_Min_concat():
    """
    Unit test for method concat of class Min
    """
    assert Min(1).concat(Min(5)) == Min(1)
    assert Min(5).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-12 05:32:25.024369
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(4)) == Sum(6)


# Generated at 2022-06-12 05:32:26.465416
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)

test_Sum()


# Generated at 2022-06-12 05:32:28.869353
# Unit test for method __str__ of class First
def test_First___str__():
    first: First = First(1)
    assert first.__str__() == "Fist[value=1]"


# Generated at 2022-06-12 05:32:32.267585
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'



# Generated at 2022-06-12 05:32:38.300237
# Unit test for method concat of class First
def test_First_concat():
    """
    Unit test for method concat of class First
    """
    first1 = First(2)
    first2 = First(3)
    first3 = First(8)
    assert first1.concat(first2) == First(2)
    assert first2.concat(first1) == First(3)
    assert first2.concat(first3) == First(3)


# Generated at 2022-06-12 05:32:43.137830
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Sum(4).value == 4
    assert All(True).value is True
    assert One(False).value is False
    assert First(1).value == 1
    assert Last(2).value == 2
    assert Map({
        'foo': Sum(1),
        'bar': Sum(2),
    }) == Map({
        'foo': Sum(1),
        'bar': Sum(2),
    })
    assert Max(-2).value == -2
    assert Min(6).value == 6


# Generated at 2022-06-12 05:32:44.546402
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == "One[value=1]"



# Generated at 2022-06-12 05:32:50.524566
# Unit test for method concat of class One
def test_One_concat():
    assert One(0).concat(One(2)) == One(2)
    assert One(0).concat(One(1)) == One(1)
    assert One(1).concat(One(0)) == One(1)
    assert One(1).concat(One(2)) == One(1)
