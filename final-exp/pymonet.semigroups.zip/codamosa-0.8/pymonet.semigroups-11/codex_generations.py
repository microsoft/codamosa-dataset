

# Generated at 2022-06-12 05:23:47.405422
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(8).concat(
        Max(10)
    ) == Max(10)


# Generated at 2022-06-12 05:23:51.244394
# Unit test for method concat of class Max
def test_Max_concat():  # pragma: no cover
    assert Max(3).concat(Max(5)) == Max(5)
    assert Max(5).concat(Max(3)) == Max(5)


# Generated at 2022-06-12 05:23:54.255155
# Unit test for method concat of class Min
def test_Min_concat():
    result = Min(1).concat(Min(2))
    assert Min(1) == result
    assert isinstance(result, Min)

test_Min_concat()


# Generated at 2022-06-12 05:23:57.358273
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)


# Generated at 2022-06-12 05:24:04.541555
# Unit test for method concat of class Min
def test_Min_concat():
    min1 = Min(1)
    min2 = Min(2)
    min3 = Min(3)
    min4 = Min(4)
    min5 = Min(5)
    min6 = Min(6)
    test2 = min1.concat(min2)
    test3 = test2.concat(min3)
    test4 = test3.concat(min4)
    test5 = test4.concat(min5)
    actual_result = test5.concat(min6)
    expected_result = Min(1)
    assert actual_result == expected_result, "{} != {}".format(actual_result, expected_result)


# Generated at 2022-06-12 05:24:10.762056
# Unit test for method concat of class Max
def test_Max_concat():
    """
    :returns: tuple with test result
    :rtype: (bool, str)
    """
    if Max(1).concat(Max(2)) == Max(2) and Max(2).concat(Max(1)) == Max(2):
        return True, 'Test Passed'
    else:
        return False, 'Test Failed'


# Generated at 2022-06-12 05:24:14.524638
# Unit test for method concat of class Min
def test_Min_concat():
    min1 = Min(0)
    min2 = Min(1)
    min3 = min1.concat(min2)
    assert isinstance(min3, Min)
    assert min3.value == 0


# Generated at 2022-06-12 05:24:18.134337
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(-1).concat(Max(3)) == Max(3)
    assert Max(3).concat(Max(3)) == Max(3)
    assert Max(10).concat(Max(1)) == Max(10)
    print("Method concat of class Max works correctly")


# Generated at 2022-06-12 05:24:19.219312
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(1)
    b = Min(2)
    assert (a.concat(b)).value == 1

# Generated at 2022-06-12 05:24:24.953383
# Unit test for method concat of class Min
def test_Min_concat():
    """
    :type semigroup: Min[B]
    :returns: new Min with smallest value
    :rtype: Min[A | B]
    """
    Min_obj1 = Min(10)
    Min_obj2 = Min(5)
    assert Min_obj1.concat(Min_obj2).value == 5



# Generated at 2022-06-12 05:24:30.279801
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)

# Generated at 2022-06-12 05:24:32.235704
# Unit test for method __str__ of class Min
def test_Min___str__():  # pragma: no cover
    assert str(Min(1)) == 'Min[value=1]'

# Generated at 2022-06-12 05:24:37.688521
# Unit test for method concat of class One
def test_One_concat():
    one1 = One(True)
    one2 = One(True)
    one3 = One(False)
    one4 = One(True)

    assert one1.concat(one2) == One(True)
    assert one1.concat(one3) == One(True)
    assert one3.concat(one4) == One(True)
    assert one3.concat(one3) == One(False)



# Generated at 2022-06-12 05:24:41.032133
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"foo": Sum(1), "bar": Sum(1)}).concat(Map({"foo": Sum(2)})).value == {"foo": Sum(3), "bar": Sum(1)}


# Generated at 2022-06-12 05:24:46.867396
# Unit test for method concat of class First
def test_First_concat():
    assert First(3).concat(First(2)).fold(lambda x: x) == 3
    assert First([1]).concat(First([2])).fold(lambda x: x) == [1]
    assert First('a').concat(First('b')).fold(lambda x: x) == 'a'


# Generated at 2022-06-12 05:24:47.739345
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1


# Generated at 2022-06-12 05:24:49.740863
# Unit test for method concat of class Sum
def test_Sum_concat():
    a = Sum(1)
    b = Sum(2)
    assert a.concat(b) == Sum(3)



# Generated at 2022-06-12 05:24:51.572117
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)



# Generated at 2022-06-12 05:24:55.365938
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: All(True), 2: All(False)})) == "Map[value={1: All[value=True], 2: All[value=False]}]"


# Generated at 2022-06-12 05:24:57.491541
# Unit test for constructor of class First
def test_First():  # pragma: no cover
    first = First(10)
    assert first.value == 10



# Generated at 2022-06-12 05:25:01.971357
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)


# Generated at 2022-06-12 05:25:05.444469
# Unit test for constructor of class Min
def test_Min():
    a = Min(1)
    b = Min(2)
    c = Min(1)
    c.concat(b)
    assert a.value == 1
    assert b.value == 2
    assert c.value == 1


# Generated at 2022-06-12 05:25:12.867116
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat({'a': Sum(3), 'b': Sum(4)}) == Map({'a': Sum(4), 'b': Sum(6)}).value
    assert Map({'a': First(1), 'b': First(2)}).concat({'a': First(3), 'b': First(4)}) == Map({'a': First(1), 'b': First(2)}).value
    assert Map({'a': Last(1), 'b': Last(2)}).concat({'a': Last(3), 'b': Last(4)}) == Map({'a': Last(3), 'b': Last(4)}).value


# Generated at 2022-06-12 05:25:14.264577
# Unit test for constructor of class Max
def test_Max():
    assert Max(2) == Max(2)


# Generated at 2022-06-12 05:25:15.887010
# Unit test for constructor of class Last
def test_Last():
    l = Last("a")
    l1 = Last("b")

# Generated at 2022-06-12 05:25:17.849627
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1, 'Last.__init__ return deepest value'


# Generated at 2022-06-12 05:25:19.526418
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)

# Generated at 2022-06-12 05:25:22.214561
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_1 = Sum(12.5)
    sum_2 = Sum(5.5)
    assert sum_1.concat(sum_2) == Sum(18)



# Generated at 2022-06-12 05:25:24.045225
# Unit test for method __str__ of class One
def test_One___str__():
    o = One(False)
    assert str(o) == 'One[value=False]', 'test_One___str__ failed'



# Generated at 2022-06-12 05:25:25.548638
# Unit test for constructor of class Min
def test_Min():
    assert Min(3).value == 3
    assert Min(7).value == 7



# Generated at 2022-06-12 05:25:29.682724
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert isinstance(Min(2).__str__(), str), "Method __str__ of class Min must returns string"
    assert Min(2).__str__() == "Min[value=2]", "Method __str__ of class Min must returns string 'Sum[value=2]'"

# Generated at 2022-06-12 05:25:35.488315
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    # GIVEN
    f1 = All(True)
    f2 = All(False)
    f3 = All(True)
    f4 = All(False)

    # WHEN
    ff1 = f1.concat(f2)
    ff2 = f3.concat(f4)

    # THEN
    assert ff1.value is False
    assert ff2.value is False



# Generated at 2022-06-12 05:25:40.401261
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-12 05:25:42.191928
# Unit test for constructor of class Semigroup
def test_Semigroup():
    s = Sum(5)
    assert(s.value == 5)



# Generated at 2022-06-12 05:25:43.503018
# Unit test for constructor of class Map
def test_Map():
    assert Map({1: Sum(1), 2: Sum(2)}) == Map({1: Sum(1), 2: Sum(2)})


# Generated at 2022-06-12 05:25:45.356515
# Unit test for constructor of class Min
def test_Min():
    assert Min(5) == Min(5)


# Generated at 2022-06-12 05:25:50.578898
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(True).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(False).concat(One(True)) == One(True)


# Generated at 2022-06-12 05:25:51.940789
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == "First[value=1]"


# Generated at 2022-06-12 05:25:53.236416
# Unit test for constructor of class Min
def test_Min():
    assert Min(0) == Min(0)

# Generated at 2022-06-12 05:25:55.230922
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)



# Generated at 2022-06-12 05:26:06.332383
# Unit test for method concat of class Map
def test_Map_concat():
    data = {
        'a': Max(1),
        'b': Min(2),
        'c': Sum(3),
        'd': All(False),
        'e': One(True),
    }
    data1 = {
        'a': Max(100),
        'b': Min(50),
        'c': Sum(60),
        'd': All(True),
        'e': One(False),
    }
    map = Map(data)
    map1 = Map(data1)
    assert map.concat(map1).value == Map({
        'a': Max(100),
        'b': Min(2),
        'c': Sum(63),
        'd': All(False),
        'e': One(True),
    }).value



# Generated at 2022-06-12 05:26:09.405305
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(2).fold(lambda x: x + 2) == 4
    assert Semigroup(5).fold(lambda x: x * 5) == 25
    assert Semigroup(10).fold(lambda x: x % 3) == 1



# Generated at 2022-06-12 05:26:12.847096
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(5).value == 5
    assert Semigroup(5) == Semigroup(5)
    assert Semigroup(5) != 5


# Generated at 2022-06-12 05:26:14.458402
# Unit test for constructor of class Last
def test_Last():
    assert Last(2) == Last(2)


# Generated at 2022-06-12 05:26:15.988529
# Unit test for method __str__ of class Max
def test_Max___str__():
    t1 = Max(1)
    print(t1)
    assert t1.__str__() == 'Max[value=1]'



# Generated at 2022-06-12 05:26:16.956018
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2

# Generated at 2022-06-12 05:26:19.583190
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(4).concat(Max(5)) == Max(5)


# Generated at 2022-06-12 05:26:29.676965
# Unit test for method concat of class One
def test_One_concat():
    monoidA = One(True)
    monoidB = One(False)
    monoidC = One(True)
    one = monoidA.concat(monoidB).concat(monoidC)
    assert one == One(True)

    monoidA = One(False)
    monoidB = One(False)
    monoidC = One(True)
    one = monoidA.concat(monoidB).concat(monoidC)
    assert one == One(True)

    monoidA = One(False)
    monoidB = One(False)
    monoidC = One(False)
    one = monoidA.concat(monoidB).concat(monoidC)
    assert one == One(False)

    monoidA = One(True)
    monoidB = One

# Generated at 2022-06-12 05:26:32.028546
# Unit test for constructor of class All
def test_All():
    assert All(
        All(All(True))
    ).value == True



# Generated at 2022-06-12 05:26:35.349886
# Unit test for method concat of class First
def test_First_concat():
    first_inst1 = First('fox')
    first_inst2 = First('dog')
    result = first_inst1.concat(first_inst2)
    assert result == First('fox')


# Generated at 2022-06-12 05:26:42.005937
# Unit test for constructor of class All
def test_All():
    assert All(True).concat(All(True))  == All(True)
    assert All(False).concat(All(True)) == All(False)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-12 05:26:45.709855
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)



# Generated at 2022-06-12 05:26:55.611716
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    a_value = 'a_value'
    b_value = 'b_value'
    assert Sum(a_value) == Sum(a_value)
    assert Sum(a_value) != Sum(b_value)
    assert All(a_value) == All(a_value)
    assert All(a_value) != All(b_value)
    assert One(a_value) == One(a_value)
    assert One(a_value) != One(b_value)
    assert First(a_value) == First(a_value)
    assert First(a_value) != First(b_value)
    assert Last(a_value) == Last(a_value)
    assert Last(a_value) != Last(b_value)
    assert Map({a_value: Sum('a_value')}) == Map

# Generated at 2022-06-12 05:26:58.895983
# Unit test for constructor of class Min
def test_Min():
    assert Min(3).value == Min(3).neutral().concat(Min(3)).value
    assert Min(3).value == Min(3).concat(Min(3).neutral()).value


# Generated at 2022-06-12 05:27:04.918160
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value == True
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
    assert All(False).concat(All(False)).value == False


# Generated at 2022-06-12 05:27:07.130058
# Unit test for constructor of class Max
def test_Max():
    max1 = Max(1)
    assert max1.value == 1



# Generated at 2022-06-12 05:27:09.044456
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == "Min[value=1]"  # pragma: no cover


# Generated at 2022-06-12 05:27:10.083346
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)


# Generated at 2022-06-12 05:27:12.372567
# Unit test for constructor of class First
def test_First():
    first = First(6)
    assert first.value == 6
    assert first.__str__() == 'Fist[value=6]'



# Generated at 2022-06-12 05:27:13.877802
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(2)) == "Min[value=2]"


# Generated at 2022-06-12 05:27:21.233544
# Unit test for constructor of class Semigroup
def test_Semigroup():
    semigroup = Semigroup(9)
    assert isinstance(semigroup, Semigroup)
    assert isinstance(semigroup, object)
    assert isinstance(semigroup, Sum) is False
    assert semigroup.value == 9


# Generated at 2022-06-12 05:27:22.949627
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)).value == 3



# Generated at 2022-06-12 05:27:27.908153
# Unit test for method concat of class Min
def test_Min_concat():
    """
    >>> a = Min(3)
    >>> b = Min(2)
    >>> c = a.concat(b)
    min is 2
    >>> a = Min(2)
    >>> b = Min(3)
    >>> c = a.concat(b)
    min is 2
    >>> a = Min(4)
    >>> b = Min(4)
    >>> c = a.concat(b)
    min is 4
    """



# Generated at 2022-06-12 05:27:32.686253
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)).value is True
    assert One(False).concat(One(True)).value is True
    assert One(False).concat(One(False)).value is False
    assert One(True).concat(One(True)).value is True


# Generated at 2022-06-12 05:27:34.414561
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(42)) == 'Sum[value=42]'


# Generated at 2022-06-12 05:27:36.937243
# Unit test for constructor of class First
def test_First():
    # Arrange
    # Act
    first = First(12)
    # Assert
    assert first.value == 12
    

# Generated at 2022-06-12 05:27:38.630206
# Unit test for constructor of class One
def test_One():
    one = One(True)
    assert one.value == True


# Generated at 2022-06-12 05:27:42.008946
# Unit test for method __str__ of class All
def test_All___str__():
    assert "All[value=True]" == str(All(True))
    assert "All[value=False]" == str(All(False))
    assert "All[]" == str(All(None))


# Generated at 2022-06-12 05:27:45.824520
# Unit test for method concat of class All
def test_All_concat():
    x = All(True)
    y = All(False)
    z = All(True)
    assert z.concat(x) == All(True)
    assert z.concat(y) == All(False)


# Generated at 2022-06-12 05:27:49.819267
# Unit test for constructor of class Sum
def test_Sum():
    a = Sum(1)
    b = Sum(2)
    assert a == Sum(1)
    assert b == Sum(2)
    assert a == Sum(1)
    assert b == Sum(2)

# Test concat of class Sum

# Generated at 2022-06-12 05:27:54.694914
# Unit test for method concat of class Last
def test_Last_concat():
    assert Semigroup(Last(1)).concat(Semigroup(Last(2))).fold(lambda x: x) == 2



# Generated at 2022-06-12 05:27:59.541694
# Unit test for method concat of class All
def test_All_concat():
    one = All(True).concat(All(False))
    assert one.value == False
    one = All(False).concat(All(True))
    assert one.value == False
    one = All(True).concat(All(True))
    assert one.value == True


# Generated at 2022-06-12 05:28:00.912445
# Unit test for constructor of class Last
def test_Last():
    last = Last (6)
    assert last == Last(6)


# Generated at 2022-06-12 05:28:02.846242
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(2).concat(Last(3)) == Last(3)


# Generated at 2022-06-12 05:28:05.068918
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    assert str(One(False)) == 'One[value=False]'



# Generated at 2022-06-12 05:28:09.588214
# Unit test for method concat of class Map
def test_Map_concat():
    assert (
        Map({"test": Sum(1)}).concat(
            Map({"test2": Sum(2), "test3": Sum(3)})
        ).value
    ) == {"test": Sum(1), "test2": Sum(2), "test3": Sum(3)}

# Generated at 2022-06-12 05:28:12.460439
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)

test_Last_concat()


# Generated at 2022-06-12 05:28:15.311212
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert Min(1).__str__() == 'Min[value=1]'


# Generated at 2022-06-12 05:28:19.044765
# Unit test for method concat of class All
def test_All_concat():
    assert All(False).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(True).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)


# Generated at 2022-06-12 05:28:21.552269
# Unit test for method __str__ of class Map
def test_Map___str__(): # pragma: no cover
    assert Map({'a': Sum(1)}).__str__() == "Map[value={'a': Sum[value=1]}]"


# Generated at 2022-06-12 05:28:31.880400
# Unit test for method concat of class First
def test_First_concat():
    fst = First(5)
    snd = First(6)
    res = First(5)
    assert fst.concat(snd) == res


# Generated at 2022-06-12 05:28:33.381517
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)


# Generated at 2022-06-12 05:28:38.215048
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False
    assert All(1).value == True
    assert All(0).value == False
    assert All('').value == False
    assert All('hello').value == True
    assert All(None).value == False


# Generated at 2022-06-12 05:28:41.582212
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First(True)) == 'Fist[value=True]'
    assert str(First(None)) == 'Fist[value=None]'



# Generated at 2022-06-12 05:28:43.652425
# Unit test for method __str__ of class Min
def test_Min___str__(): # pragma: no cover
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-12 05:28:45.257582
# Unit test for method concat of class Sum
def test_Sum_concat():  # pragma: no cover
    assert Sum(1).concat(Sum(1)) == Sum(2)



# Generated at 2022-06-12 05:28:46.891031
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)


# Generated at 2022-06-12 05:28:49.424950
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(2)) == 'Sum[value={}]'.format(2)


# Generated at 2022-06-12 05:28:51.827978
# Unit test for method concat of class Sum
def test_Sum_concat():
    a = Sum(10)
    b = Sum(100)
    assert(a.concat(b) == Sum(110))


# Generated at 2022-06-12 05:28:53.709531
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"


# Generated at 2022-06-12 05:29:07.430502
# Unit test for method concat of class First
def test_First_concat():
    f = First("a")
    assert f.concat(First("b")) == First("a")
    assert f.concat(First("a")) == First("a")


# Generated at 2022-06-12 05:29:13.669397
# Unit test for method concat of class Sum
def test_Sum_concat():
    # Positive test
    assert Sum(1).concat(Sum(1)) == Sum(2)
    assert Sum(1).concat(Sum(0)) == Sum(1)
    # Negative test
    try:
        Sum(1).concat(1)
    except Exception as e:
        assert type(e) == TypeError


# Generated at 2022-06-12 05:29:15.951886
# Unit test for method concat of class First
def test_First_concat():  # pragma: no cover
    first = First(1)
    second = First(2)
    assert first.concat(second).value == 1

# Generated at 2022-06-12 05:29:19.298609
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup("Hello") == Semigroup("Hello")
    assert Semigroup(False) != Semigroup(True)
    assert Semigroup("A") != Semigroup("B")
    assert Semigroup(0) != Semigroup(1)


# Generated at 2022-06-12 05:29:22.833134
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-12 05:29:24.532846
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == "Sum[value=1]"


# Generated at 2022-06-12 05:29:30.461302
# Unit test for method concat of class Sum
def test_Sum_concat():  # pragma: no cover
    tests = [
        (1, 1, 2),
        (1, 2, 3),
        (2, 1, 3),
    ]
    for test in tests:
        assert Sum(test[0]).concat(Sum(test[1])) == Sum(test[2]), 'expected %s' % test[2]



# Generated at 2022-06-12 05:29:37.167903
# Unit test for method concat of class Map
def test_Map_concat():
    """
    :returns: assert True if Map.concat of 2 semigroups as result new Map with all value from all 2 semigroups
    :rtype: bool
    """
    first = Map({"1": Sum(1), "2": Sum(2)})
    second = Map({"3": Sum(3), "4": Sum(4)})
    assert first.concat(second) == Map({"1": Sum(1), "2": Sum(2), "3": Sum(3), "4": Sum(4)})
    return True

# Generated at 2022-06-12 05:29:43.684489
# Unit test for constructor of class Map
def test_Map():
    """
    Unit test for constructor of class Map

    :returns: Empty list if test is successful
    :rtype: list

    :raises AssertionError:
    """
    try:
        keys = ["name"]
        map1 = Map({"name": Sum(1)})
        assert map1.value["name"].value == 1
        keys = ["name", "tag"]
        map1 = Map({"name": Sum(1), "tag": Sum(2)})
        assert map1.value["name"].value == 1
        assert map1.value["tag"].value == 2
        map1 = Map({"name": Sum(1)})
    except AssertionError:
        log.exception("AssertionError occurred")
        return ["Fail", "AssertionError occurred"]
    return []


#

# Generated at 2022-06-12 05:29:49.875435
# Unit test for constructor of class Map
def test_Map():
    assert Map({}) == Map({})
    assert Map({1: Sum(1)}) == Map({1: Sum(1)})
    assert Map({1: 2}) != Map({1: 3})
    assert Map({1: 2, 2: 3}) == Map({1: 2, 2: 3})
    assert Map({1: 2, 2: 3}) != Map({3: 2, 2: 3})

# Generated at 2022-06-12 05:30:15.078026
# Unit test for method __str__ of class Max
def test_Max___str__():
    m = Max(100)
    actual = str(m)
    assert actual == "Max[value=100]", f"actual: {actual}, expected: Max[value=100]"

# Generated at 2022-06-12 05:30:20.551370
# Unit test for method concat of class All
def test_All_concat():
    """
    test for concat method of All class
    """
    # arrange
    first_semigroup = All(True)
    second_semigroup = All(True)

    # action
    result = first_semigroup.concat(second_semigroup)

    # assert
    assert result == All(True)


# Generated at 2022-06-12 05:30:22.225363
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(4) == Semigroup(4)


# Generated at 2022-06-12 05:30:23.699892
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First("str")) == "Fist[value=str]"


# Generated at 2022-06-12 05:30:27.188093
# Unit test for constructor of class Last
def test_Last():
    """
    Test whether the class Last is constructed properly.
    """
    ex1 = Last(5)
    assert ex1.value == 5
    with pytest.raises(AssertionError):
        Last(4) == 4

# Generated at 2022-06-12 05:30:28.405010
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(3)) == 'Last[value=3]'


# Generated at 2022-06-12 05:30:29.965736
# Unit test for method __str__ of class All
def test_All___str__():
    assert 'All[value=True]' == str(All(True))


# Generated at 2022-06-12 05:30:31.510754
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert Min(4).__str__() == 'Min[value=4]'


# Generated at 2022-06-12 05:30:32.834840
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'

# Generated at 2022-06-12 05:30:35.560733
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)


# Generated at 2022-06-12 05:31:30.170225
# Unit test for method concat of class One
def test_One_concat():  # pragma: no cover
    semigroup_1 = One(0)
    semigroup_2 = One(1)
    assert semigroup_1.concat(semigroup_2).value == 1
    semigroup_3 = semigroup_2.concat(semigroup_1)
    assert semigroup_3.value == 1
    assert semigroup_3 == semigroup_2
    semigroup_4 = One(0)
    semigroup_5 = semigroup_4.concat(semigroup_4)
    assert semigroup_4 == semigroup_5



# Generated at 2022-06-12 05:31:33.498795
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5) == Max(5)
    assert Max(5).concat(Max(1)) == Max(5)
    assert Max(5).concat(Max(7)) == Max(7)

# Generated at 2022-06-12 05:31:35.982839
# Unit test for method __str__ of class Last
def test_Last___str__(): # pragma: no cover
    assert str(Last('my_value')) == 'Last[value=my_value]'


# Generated at 2022-06-12 05:31:40.307969
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value
    assert not All(True).concat(All(False)).value
    assert not All(False).concat(All(True)).value
    assert not All(False).concat(All(False)).value


# Generated at 2022-06-12 05:31:42.040699
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)


# Generated at 2022-06-12 05:31:43.618604
# Unit test for method __str__ of class Min
def test_Min___str__():  # pragma: no cover
    assert 'Min[value=1]' == str(Min(1))



# Generated at 2022-06-12 05:31:45.656398
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-12 05:31:47.056181
# Unit test for constructor of class Last
def test_Last():
    l = Last(2)
    assert l.value == 2


# Generated at 2022-06-12 05:31:48.448389
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(5)) == 'Sum[value=5]'



# Generated at 2022-06-12 05:31:54.946434
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    all_test_1 = All(True)
    all_test_2 = All(True)
    assert all_test_1.concat(all_test_2) == All(True)

    all_test_3 = All(True)
    all_test_4 = All(False)
    assert all_test_3.concat(all_test_4) == All(False)
