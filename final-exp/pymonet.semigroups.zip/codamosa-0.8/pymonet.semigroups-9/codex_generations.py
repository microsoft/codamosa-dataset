

# Generated at 2022-06-12 05:23:51.195086
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({1: Sum(1), 2: Sum(2)}).concat(Map({1: Sum(2), 3: Sum(1)})) == Map(
        {1: Sum(3), 2: Sum(2), 3: Sum(1)}
    )

# Generated at 2022-06-12 05:23:56.276418
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'k1': Sum(2), 'k2': Sum(4)}).concat(Map({'k1': Sum(4), 'k2': Sum(4)})) == Map({
        'k1': Sum(6),
        'k2': Sum(8),
    })



# Generated at 2022-06-12 05:24:04.882374
# Unit test for method concat of class Map
def test_Map_concat():
    with pytest.raises(TypeError):
        Map({}).concat(True)

    obj_map = Map({'foo': Sum(1)})
    assert obj_map.concat(Map({'foo': Sum(2)})) == Map({'foo': Sum(3)})
    assert obj_map.concat(Map({'foo': Sum(2)})).value['foo'] == Sum(3)

    with pytest.raises(TypeError):
        obj_map = Map({'foo': Sum(1)})
        obj_map.concat(Map('foo'))

    obj_map = Map({'foo': Sum(1)})
    assert obj_map.concat(Map({'bar': Sum(2)})) == Map({'foo': Sum(1), 'bar': Sum(2)})
    assert obj_

# Generated at 2022-06-12 05:24:13.743911
# Unit test for method concat of class Map
def test_Map_concat():
    # sample-input
    m1 = Map({
        '1': All(True),
        '2': All(True),
        '3': All(True),
    })
    m2 = Map({
        '1': All(True),
        '2': All(False),
        '4': All(True),
    })
    assert m1.concat(m2) == Map({
        '1': All(True),
        '2': All(False),
        '3': All(True),
        '4': All(True),
    })
    # sample-output

# Generated at 2022-06-12 05:24:19.194887
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({1: Sum(2), 2:Sum(3)})
    m2 = Map({1: Sum(4), 2:Sum(6)})
    m = m1.concat(m2)
    assert(m.value[1] == Sum(6))
    assert(m.value[2] == Sum(9))

# Generated at 2022-06-12 05:24:24.082130
# Unit test for method concat of class Map
def test_Map_concat():
    result = Map({"A": Sum(2)}).concat(Map({"B": Sum(3)}))
    assert result.value == {"A": Sum(2), "B": Sum(3)}

# Generated at 2022-06-12 05:24:28.028491
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map(
        {'a': Sum(1), 'b': Sum(2)}
    ).concat(
        Map({'a': Sum(1), 'b': Sum(2)})
    ) == Map(
        {'a': Sum(2), 'b': Sum(4)}
    )

# Generated at 2022-06-12 05:24:30.615970
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Min(2), 'b': Min(5)}).concat(Map({'a': Min(3), 'b': Min(0)})) \
        == Map({'a': Min(2), 'b': Min(0)})

# Generated at 2022-06-12 05:24:35.952992
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({'a': Sum(1)})
    m2 = Map({'a': Sum(1), 'b': Sum(2)})
    m3 = Map({'a': Sum(1), 'b': Sum(3)})
    assert m1.concat(m2).concat(m3) == Map({'a': Sum(3), 'b': Sum(5)})

# Generated at 2022-06-12 05:24:40.445351
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(2), 'b': Sum(2)})) == Map({'a': Sum(3), 'b': Sum(4)})

# Generated at 2022-06-12 05:24:44.311731
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1
    assert Sum(2.2).value == 2.2


# Generated at 2022-06-12 05:24:47.205837
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(3)) == Sum(5)
    assert Sum(2).concat(Sum(3)).value == 5


# Generated at 2022-06-12 05:24:50.320469
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(10)) == 'Max[value=10]'
    assert str(Max(-10)) == 'Max[value=-10]'
    assert str(Max(None)) == 'Max[value=None]'


# Generated at 2022-06-12 05:24:53.394105
# Unit test for constructor of class Map
def test_Map():
    assert Map({'first': First('first'), 'last': Last('last')}) == Map({'first': First('first'), 'last': Last('last')})


# Generated at 2022-06-12 05:24:55.661482
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-12 05:24:57.635234
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)



# Generated at 2022-06-12 05:25:00.095637
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]', '__str__() must return string representation of Monoid'

# Generated at 2022-06-12 05:25:02.485859
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1)}).value == {'a': Sum(1)}


# Generated at 2022-06-12 05:25:04.221369
# Unit test for method __str__ of class Max
def test_Max___str__():
    import comonad

    assert str(Max(10)) == 'Max[value=10]'



# Generated at 2022-06-12 05:25:05.594212
# Unit test for constructor of class First
def test_First():
    first = First(1)
    assert first.value == 1



# Generated at 2022-06-12 05:25:09.074512
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-12 05:25:10.502178
# Unit test for constructor of class Sum
def test_Sum():
    """
    Unit tests for Sum class constructor
    """
    assert Sum(3).value == 3


# Generated at 2022-06-12 05:25:11.767512
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == "Max[value=1]"


# Generated at 2022-06-12 05:25:13.604253
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(4)).value == 2
    assert Min(4).concat(Min(2)).value == 2


# Generated at 2022-06-12 05:25:19.484834
# Unit test for method __str__ of class All
def test_All___str__():
    """
    To unit test a method __str__ of class All
    """

    print("-> test_All___str__:", end='')

    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"
    print("\tPass")



# Generated at 2022-06-12 05:25:20.772079
# Unit test for constructor of class All
def test_All():
    assert All(1) == All(1)



# Generated at 2022-06-12 05:25:22.593402
# Unit test for constructor of class Last
def test_Last():
    value = Last(4)
    assert value.value == 4


# Generated at 2022-06-12 05:25:26.344014
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(2)})) == "Map[value={'a': Sum[value=2]}]"
    assert str(Map({'a': Sum(2), 'b': Sum(2)})) == "Map[value={'a': Sum[value=2], 'b': Sum[value=2]}]"


# Generated at 2022-06-12 05:25:27.322133
# Unit test for constructor of class Min
def test_Min():
    assert str(Min(5)) == 'Min[value=5]'


# Generated at 2022-06-12 05:25:28.898981
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One('True') == One('True')

# Generated at 2022-06-12 05:25:31.724204
# Unit test for constructor of class First
def test_First():
    first = First(1)
    assert first.value == 1


# Generated at 2022-06-12 05:25:33.594216
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)



# Generated at 2022-06-12 05:25:38.674571
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False
    assert All(True).concat(All(True)).value == True
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
    assert All(False).concat(All(False)).value == False


# Generated at 2022-06-12 05:25:40.692328
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First(5)) == 'Fist[value=5]'



# Generated at 2022-06-12 05:25:46.667570
# Unit test for method concat of class All
def test_All_concat():
    """Tests that logical disjunction OR works correctly for All class"""
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-12 05:25:49.705609
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-12 05:25:51.154944
# Unit test for method __str__ of class One
def test_One___str__(): # pragma: no cover
    assert str(One(True)) == 'One[value=True]'

# Generated at 2022-06-12 05:25:52.084986
# Unit test for constructor of class First
def test_First():
    assert First(10).value == 10



# Generated at 2022-06-12 05:25:53.710954
# Unit test for constructor of class All
def test_All():
    """
    Test All with bool value
    """
    assert All(True).value == True


# Generated at 2022-06-12 05:25:55.577634
# Unit test for method __str__ of class Min
def test_Min___str__():
    """
    Unit test for method __str__ of class Min
    """
    assert str(Min(0)) == "Min[value=0]"



# Generated at 2022-06-12 05:25:57.746155
# Unit test for constructor of class First
def test_First():
    assert First(4) == First(4)


# Generated at 2022-06-12 05:26:00.217970
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1)})) == 'Map[value={\'a\': Sum[value=1]}]'


# Generated at 2022-06-12 05:26:05.599951
# Unit test for method __str__ of class All
def test_All___str__():
    def test():
        assert 'All[value=True]' == str(All(True))
        assert 'All[value=False]' == str(All(False))
        assert 'All[value=True]' == str(All(True).concat(All(True)))
        assert 'All[value=False]' == str(All(True).concat(All(False)))
        assert 'All[value=False]' == str(All(True).concat(All(None)))
    test()

# Generated at 2022-06-12 05:26:12.444305
# Unit test for constructor of class One
def test_One():
    assert One(True) != One(False)
    assert One(True).concat(One(True)).concat(One(True)).concat(One(False)) == One(True)
    assert One(None).concat(One(False)).concat(One(True)).concat(One(False)) == One(True)
    assert One(False).concat(One(False)).concat(One(False)).concat(One(False)) == One(False)


# Generated at 2022-06-12 05:26:14.513079
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)



# Generated at 2022-06-12 05:26:16.574279
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == 'Map[value={\'a\': Sum[value=1], \'b\': Sum[value=2]}]'


# Generated at 2022-06-12 05:26:18.978860
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)


# Generated at 2022-06-12 05:26:20.913367
# Unit test for constructor of class One
def test_One():
    assert isinstance(One(True), One)
    assert isinstance(One(False), One)


# Generated at 2022-06-12 05:26:26.022925
# Unit test for method concat of class All
def test_All_concat():
    assert (
        All(True).concat(All(False)) ==
        All(False)
    )

    assert (
        All(True).concat(All(True)) ==
        All(True)
    )

    # Test concat
    assert (
        All(True).concat(All(True)).value ==
        True
    )



# Generated at 2022-06-12 05:26:30.784992
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_1 = Sum(1)
    sum_2 = Sum(2)
    assert sum_1.concat(sum_2) == Sum(3)


# Generated at 2022-06-12 05:26:36.228485
# Unit test for method concat of class First
def test_First_concat():
    val1 = First(1)
    val2 = First(2)
    val3 = val1.concat(val2)
    assert val3 == First(1)



# Generated at 2022-06-12 05:26:37.936612
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == "One[value=True]"


# Generated at 2022-06-12 05:26:47.728992
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(12)) == "Min[value=12]"
    assert str(Max(12)) == "Max[value=12]"
    assert str(First(12)) == "Fist[value=12]"
    assert str(Last(12)) == "Last[value=12]"
    assert str(One(12)) == "One[value=12]"
    assert str(All(12)) == "All[value=12]"
    assert str(Sum(12)) == "Sum[value=12]"
    assert str(Map({"one": Sum(1), "two": Sum(2)})) == 'Map[value={\'one\': Sum[value=1], \'two\': Sum[value=2]}]'


# Generated at 2022-06-12 05:26:49.080219
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-12 05:26:53.377276
# Unit test for method concat of class First
def test_First_concat():  # pragma: no cover
    first = First(1)

    assert first.concat(First(2)).value == 1
    assert first.concat(First(1)).value == 1
    assert first.concat(First(3)).value == 1



# Generated at 2022-06-12 05:26:58.512184
# Unit test for method concat of class All
def test_All_concat():
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)


# Generated at 2022-06-12 05:27:02.172232
# Unit test for method __str__ of class First
def test_First___str__():
    expected = 'Fist[value=some_string_value]'
    assert str(First('some_string_value')) == expected


# Generated at 2022-06-12 05:27:04.444370
# Unit test for method concat of class First
def test_First_concat():
    value1 = First(3).concat(First(2))
    assert value1 == First(3)


# Generated at 2022-06-12 05:27:07.900332
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(3).concat(Max(2)) == Max(3)


# Generated at 2022-06-12 05:27:13.305461
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(0).concat(Max(-1)) == Max(0)
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(3).concat(Max(3)) == Max(3)


# Generated at 2022-06-12 05:27:19.008737
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First("Piotr")) == "Fist[value=Piotr]"

# Generated at 2022-06-12 05:27:21.024882
# Unit test for constructor of class All
def test_All():  # pragma: no cover
    assert All(True).value == True
    assert All(False).value == False


# Generated at 2022-06-12 05:27:24.504663
# Unit test for constructor of class Map
def test_Map():
    map_1 = {1: Sum(1), 2: Sum(2)}
    map_2 = {1: Sum(3), 2: Sum(4)}
    assert Map(map_1).value == map_1

# Generated at 2022-06-12 05:27:26.611293
# Unit test for constructor of class Last
def test_Last():
    assert Last(5) == Last(5)



# Generated at 2022-06-12 05:27:28.591727
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last('ass').concat(Last('hole')) == Last('hole')


# Generated at 2022-06-12 05:27:32.495427
# Unit test for method concat of class Last
def test_Last_concat():
    # Given
    semigroup1 = Last(1)
    semigroup2 = Last(3)

    # When
    semigroup3 = semigroup1.concat(semigroup2)

    # Then
    assert semigroup3 == Last(3)

# Generated at 2022-06-12 05:27:34.582832
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert Min(5).__str__() == 'Min[value=5]'


# Generated at 2022-06-12 05:27:36.996006
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1)})) == 'Map[value={\'a\': Sum[value=1]}]'



# Generated at 2022-06-12 05:27:39.655815
# Unit test for method __str__ of class Map
def test_Map___str__():
    m = Map({'a': Max(1), 'b': Min(2), 'c': Sum(3)})
    assert m.__str__() == "Map[value={'a': Max[value=1], 'b': Min[value=2], 'c': Sum[value=3]}]"

# Generated at 2022-06-12 05:27:40.958197
# Unit test for constructor of class Min
def test_Min():
    assert Min(0) == Min(0)

# Generated at 2022-06-12 05:27:46.594247
# Unit test for constructor of class Max
def test_Max():
    """
    Test Max constructor.
    """
    max_monoid = Max(1)
    assert max_monoid.value == 1


# Generated at 2022-06-12 05:27:50.409806
# Unit test for method concat of class First
def test_First_concat():
    first = First(1)
    assert first.concat(First(1)).concat(First()).value == 1
    assert first.concat(First(None)).concat(First(1)).value == 1



# Generated at 2022-06-12 05:27:54.125963
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(0).concat(Max(2)) == Max(2)


# Generated at 2022-06-12 05:27:56.703041
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(5)) == 'Min[value=5]'


# Generated at 2022-06-12 05:27:58.221907
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(10)) == 'Min[value=10]'



# Generated at 2022-06-12 05:28:02.544744
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value == True
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
    assert All(False).concat(All(False)).value == False


# Generated at 2022-06-12 05:28:04.378385
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-12 05:28:06.261761
# Unit test for constructor of class Last
def test_Last():
    last = Last(1)
    assert last.value == 1


# Generated at 2022-06-12 05:28:09.491349
# Unit test for method concat of class First
def test_First_concat():  # pragma: no cover
    """
    Unit test for method concat of class First
    """
    assert First(1).concat(First(2)) == First(1)


# Generated at 2022-06-12 05:28:15.106686
# Unit test for method __str__ of class Map
def test_Map___str__():  # pragma: no cover
    assert 'Map[value={}]' == Map({})
    assert 'Map[value={1: "1", 2: "2", 3: "3"}]' == Map({1: "1", 2: "2", 3: "3"})



# Generated at 2022-06-12 05:28:19.513065
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(3) == Sum(3)



# Generated at 2022-06-12 05:28:21.628350
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    """
    Check that __str__ method is correct
    """
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-12 05:28:25.459163
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) == Last(2)
    assert Last(1) != Last(3)
    assert Last(1) != Last(4)


# Generated at 2022-06-12 05:28:26.792584
# Unit test for constructor of class One
def test_One():
    result = One(True)
    expected = One(True)
    assert result == expected
#


# Generated at 2022-06-12 05:28:31.290744
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert Sum(1) == Sum(1)
    assert Sum(1).value == 1
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-12 05:28:33.226124
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1
    assert Last(2).value == 2


# Generated at 2022-06-12 05:28:34.852823
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-12 05:28:37.040864
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': 1})) == 'Map[value={\'a\': 1}]'



# Generated at 2022-06-12 05:28:39.647219
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    method fold of class Semigroup returns given function with value of semigroup
    """
    assert Sum(1).fold(lambda x: x * 2) == 2


# Generated at 2022-06-12 05:28:44.516513
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-12 05:28:52.030485
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'


# Generated at 2022-06-12 05:28:58.820871
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First(1) == First(1)
    assert Last(2) == Last(2)
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)
    assert Map({'a': First(1), 'b': Last(2)}) == Map({'b': Last(2), 'a': First(1)})


# Generated at 2022-06-12 05:29:03.749658
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'
    assert str(Min(2)) == 'Min[value=2]'
    assert str(Min(3)) == 'Min[value=3]'



# Generated at 2022-06-12 05:29:06.866337
# Unit test for constructor of class Max
def test_Max():
    """
    Test Max construct
    """
    assert Max(1).value == 1
    assert Max(2).value == 2
    assert Max("test").value == "test"


# Generated at 2022-06-12 05:29:09.344330
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-12 05:29:10.745345
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1


# Generated at 2022-06-12 05:29:13.232329
# Unit test for constructor of class One
def test_One():
    assert One(True)
    assert One(False)
    assert One(0)
    assert One(1)



# Generated at 2022-06-12 05:29:16.713874
# Unit test for constructor of class Sum
def test_Sum():
    def fn(value):
        return value

    actual = Sum(5).fold(fn)
    assert actual == 5
    actual = Sum(5).concat(Sum(6)).fold(fn)
    assert actual == 11



# Generated at 2022-06-12 05:29:21.899399
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(2).fold(lambda a: a * 3) == 6
    assert All(True).fold(lambda a: a * 3) == 3
    assert Last(4).fold(lambda a: a * 3) == 12
    assert First(4).fold(lambda a: a * 3) == 12

# Generated at 2022-06-12 05:29:25.006893
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert(Sum(1).concat(Sum(2)) == Sum(3))
    assert(Sum(2).concat(Sum(1)) == Sum(3))


# Generated at 2022-06-12 05:29:39.657342
# Unit test for method __str__ of class All
def test_All___str__():

    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"
    assert str(All(None)) == "All[value=False]"


# Generated at 2022-06-12 05:29:41.742069
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(6)) == 'Max[value=6]'


# Generated at 2022-06-12 05:29:43.544338
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(2) == Sum(2)
    assert Sum(2) != Sum(1)


# Generated at 2022-06-12 05:29:45.183127
# Unit test for constructor of class Min
def test_Min():
    assert Min(1).value == 1


# Generated at 2022-06-12 05:29:47.295249
# Unit test for constructor of class One
def test_One():
    try:
        assert One(True) == True
        assert One(False) == False
    except:
        pass



# Generated at 2022-06-12 05:29:49.427569
# Unit test for constructor of class Last
def test_Last():
    assert Last(42).value == 42
    assert Last("42").value == "42"


# Generated at 2022-06-12 05:29:51.114538
# Unit test for method __str__ of class Min
def test_Min___str__():
    x = Min(10)
    assert str(x) == 'Min[value=10]'


# Generated at 2022-06-12 05:29:53.054560
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(True).value == True
    assert One(True).__str__() == 'One[value=True]'



# Generated at 2022-06-12 05:29:57.824433
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map({'a': Sum(1), 'b': Sum(2), 'c': Sum(3)})
    map2 = Map({'a': Sum(2), 'b': Sum(2), 'c': Sum(3)})
    assert map1.concat(map2) == Map({'a': Sum(3), 'b': Sum(4), 'c': Sum(6)})

# Generated at 2022-06-12 05:30:02.013325
# Unit test for method __str__ of class All
def test_All___str__():
    """Test if method __str__ of class All works correctly"""
    an_all = All(True)
    assert str(an_all) == "All[value=True]", 'str method of All is incorrect'



# Generated at 2022-06-12 05:30:29.145664
# Unit test for method concat of class Max
def test_Max_concat():
    max_a = Max(1)
    max_b = Max(2)
    max_c = max_a.concat(max_b)
    assert max_c.value == 2



# Generated at 2022-06-12 05:30:35.200037
# Unit test for method __str__ of class Last

# Generated at 2022-06-12 05:30:39.732072
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-12 05:30:42.035634
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(0)
    b = Min(-1)
    assert a.concat(b) == b



# Generated at 2022-06-12 05:30:44.312988
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-12 05:30:46.365359
# Unit test for constructor of class Last
def test_Last():
    """
    :returns: tests Last class constructor
    :rtype: None
    """
    assert Last(7)



# Generated at 2022-06-12 05:30:47.338967
# Unit test for constructor of class Min
def test_Min():
    assert Min(10) == Min(10)


# Generated at 2022-06-12 05:30:55.241452
# Unit test for method concat of class Max
def test_Max_concat():  # pragma: no cover
    assert Max(1).concat(Max(2)).concat(Max(3)) == Max(3)
    assert Max(1).concat(Max(2)).concat(Max(3)).concat(Max(1)) == Max(3)
    assert Max(3).concat(Max(1)).concat(Max(2)).concat(Max(1)) == Max(3)
    assert Max(2).concat(Max(1)).concat(Max(3)) == Max(3)



# Generated at 2022-06-12 05:31:04.106987
# Unit test for constructor of class Last
def test_Last():
    # Test with Last[Int]
    last_int = Last(1)
    assert last_int.value == 1

    # Test with Last[List[Int]]
    last_list_int = Last([1, 2, 3])
    assert last_list_int.value == [1, 2, 3]

    # Test with Last["String"]
    last_string = Last("string")
    assert last_string.value == "string"

    # Test with Last[Dict[Int:Float]]
    d = {1: 1.5, 2: 2.5, 3: 3.5}
    last_dict = Last(d)
    assert last_dict.value == d



# Generated at 2022-06-12 05:31:05.597683
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-12 05:32:00.931318
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True))   == All(True)
    assert All(True).concat(All(False))  == All(False)
    assert All(False).concat(All(True))  == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-12 05:32:02.002369
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 2) == 3

# Generated at 2022-06-12 05:32:04.919663
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(10).concat(Sum(10)) == Sum(20)


# Generated at 2022-06-12 05:32:06.853266
# Unit test for method __str__ of class One
def test_One___str__():
    s = One(True)
    assert str(s) == 'One[value=True]'


# Generated at 2022-06-12 05:32:10.467023
# Unit test for constructor of class Sum
def test_Sum():
    """
    Test constructor of class Sum.
    :returns: None
    """
    assert type(Sum(3)) == Sum
    assert Sum(3).value == 3


# Generated at 2022-06-12 05:32:11.611406
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)


# Generated at 2022-06-12 05:32:18.903500
# Unit test for constructor of class One
def test_One():
    """
    :returns: test failed or passed
    :rtype: bool
    """
    try:
        assert One(False) == One(False)
    except AssertionError:
        print(
            "Test failed. One(False) is not true."
        )
        return False
    print("Test passed.")
    return True


# Generated at 2022-06-12 05:32:24.543409
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(3).fold(lambda x: x) == 3
    assert All(True).fold(lambda x: x) == True
    assert One(True).fold(lambda x: x) == True
    assert First(3).fold(lambda x: x) == 3
    assert Last(3).fold(lambda x: x) == 3
    assert Map({'id': Sum(3)}).fold(lambda x: x) == {'id': Sum(3)}
    assert Max(3).fold(lambda x: x) == 3
    assert Min(3).fold(lambda x: x) == 3


# Generated at 2022-06-12 05:32:28.640226
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(4)) == 'Min[value=4]'
    assert str(Min(1.023)) == 'Min[value=1.023]'
    assert str(Min("hello")) == 'Min[value=hello]'


# Generated at 2022-06-12 05:32:29.971465
# Unit test for constructor of class Max
def test_Max():
    max = Max(1)
    assert max.value == 1
