

# Generated at 2022-06-12 05:23:56.485870
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-12 05:24:04.548378
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"a": Sum(1), "b": Sum(2)}).concat(Map({"a": Sum(1), "b": Sum(2)})).value == {"a": Sum(2), "b": Sum(4)}
    assert Map({"a": Last("x"), "b": Last("y")}).concat(
        Map({"a": Last("x"), "b": Last("y")})
    ).value == {"a": Last("y"), "b": Last("y")}

    assert Map({"a": First("x"), "b": First("y")}).concat(
        Map({"a": First("x"), "b": First("y")})
    ).value == {"a": First("x"), "b": First("y")}

# Generated at 2022-06-12 05:24:06.743552
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == "Last[value=1]"


# Generated at 2022-06-12 05:24:10.092195
# Unit test for constructor of class Min
def test_Min():
    """
    :returns: assert for instanciating Min with correct value
    :rtype: None
    """
    assert Min(10) == Min(10)


# Generated at 2022-06-12 05:24:11.910198
# Unit test for method __str__ of class Last
def test_Last___str__():
    last = Last(100)
    assert last.__str__() == 'Last[value=100]'


# Generated at 2022-06-12 05:24:22.231281
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Max(10).fold(Max.neutral) == Max(10)
    assert Last("10").fold(Last.neutral) == Last("10")
    assert Min(10).fold(Min.neutral) == Min(10)
    assert Max(10).fold(Min.neutral) == Max(10)
    assert Sum(10).fold(Sum.neutral) == Sum(0)
    assert Last("10").fold(Last.neutral) == Last("10")
    assert First(10).fold(First.neutral) == First(10)
    assert All(True).fold(All.neutral) == All(True)
    assert All(False).fold(All.neutral) == All(True)
    assert All(False).fold(All.neutral) == All(True)
    assert All(10).fold(All.neutral) == All(True)
   

# Generated at 2022-06-12 05:24:23.719243
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-12 05:24:26.400225
# Unit test for constructor of class All
def test_All():
    """
    Tests All constructor
    """
    semigroup = All(True)
    assert semigroup.value
    semigroup = All(False)
    assert not semigroup.value



# Generated at 2022-06-12 05:24:31.256856
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'
    assert str(Min(1.2)) == 'Min[value=1.2]'
    assert str(Min(25)) == 'Min[value=25]'
    assert str(Min(25.3)) == 'Min[value=25.3]'



# Generated at 2022-06-12 05:24:33.265078
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'name': First('John'), 'age': Min(25)})) == 'Map[value={\'name\': Fist[value=John], \'age\': Min[value=25]}]'


# Generated at 2022-06-12 05:24:39.460484
# Unit test for method __str__ of class Last
def test_Last___str__():
    value = 'test_value'
    item = Last(value)
    expected = 'Last[value={}]'.format(value)
    actual = item.__str__()
    assert actual == expected



# Generated at 2022-06-12 05:24:41.508383
# Unit test for constructor of class Min
def test_Min():
    assert isinstance(Min(1), Min)
    assert Min(1).value == 1


# Generated at 2022-06-12 05:24:46.715409
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)

# Generated at 2022-06-12 05:24:48.494857
# Unit test for method concat of class First
def test_First_concat():  # pragma: no cover
    assert First(42).concat(First(22)) == First(42)



# Generated at 2022-06-12 05:24:51.519936
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(2).concat(Max(3)) == Max(3)
    assert Max(3).concat(Max(2)) == Max(3)


# Generated at 2022-06-12 05:24:55.366144
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert Map({1: Sum(1), 2: Sum(2)}).__str__() == 'Map[value={1: Sum[value=1], 2: Sum[value=2]}]'


# Generated at 2022-06-12 05:24:58.084068
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)
    assert Min(2) == Min(2)
    assert Min(-1) == Min(-1)


# Generated at 2022-06-12 05:24:59.743716
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(23)) == 'Max[value=23]'


# Generated at 2022-06-12 05:25:02.043764
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-12 05:25:03.952904
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-12 05:25:07.268636
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last('2').concat(Last('3')).value == '3'



# Generated at 2022-06-12 05:25:12.426604
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Sum(1).value == 1
    assert All(True).value == True
    assert One(False).value == False
    assert First(1).value == 1
    assert Last(1).value == 1
    assert Map({}).value == {}
    assert Max(1).value == 1
    assert Min(2).value == 2


# Generated at 2022-06-12 05:25:17.137195
# Unit test for method concat of class All
def test_All_concat():
    assert All(False).concat(All(True)) == All(False)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)


# Generated at 2022-06-12 05:25:19.730205
# Unit test for constructor of class First
def test_First():
    first = First(1)
    assert first.value == 1


# Generated at 2022-06-12 05:25:23.438295
# Unit test for method concat of class Min
def test_Min_concat():
    c1 = Min(3)
    c2 = Min(5)
    assert c1.concat(c2) == Min(3)
    assert c2.concat(c1) == Min(3)
    assert c1.concat(c1) == Min(3)


# Generated at 2022-06-12 05:25:26.233479
# Unit test for constructor of class Map
def test_Map():
    m1 = Map({'a': First(1)})
    m2 = Map({'a': First(2)})
    m3 = m1.concat(m2)
    assert m3.value['a'].value == 1


# Generated at 2022-06-12 05:25:28.526265
# Unit test for constructor of class One
def test_One():
    empty = One().value
    of_val = One(1).value
    of_other = One(First()).value

    assert empty == False
    assert of_val == True
    assert of_other == First()

# Generated at 2022-06-12 05:25:29.658869
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(3) == Semigroup(3)



# Generated at 2022-06-12 05:25:31.853086
# Unit test for constructor of class Last
def test_Last():
    value = Last(6)
    assert value != Last(8)
    assert value == Last(6)
    assert value.value == 6


# Generated at 2022-06-12 05:25:37.335663
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First(10) == First(10)
    assert Last(20) == Last(20)
    assert Max(30) == Max(30)
    assert Min(40) == Min(40)


# Unit tests for method concat of class Sum

# Generated at 2022-06-12 05:25:43.685227
# Unit test for method concat of class One
def test_One_concat():
    concat = One(1).concat(One(True))
    assert concat(One(None).value)
    assert concat(One(0).value)
    assert concat(One(0).concat(One('')).value)
    assert not concat(One(1).concat(One(0)).value)


# Generated at 2022-06-12 05:25:54.347071
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First(2.3)) == 'Fist[value=2.3]'
    assert str(First([1, 2, 3])) == 'Fist[value=[1, 2, 3]]'
    assert str(First({1, 2, 3})) == 'Fist[value={1, 2, 3}]'
    assert str(First({1:1, 2:2, 3:3})) == 'Fist[value={1: 1, 2: 2, 3: 3}]'
    assert str(First(True)) == 'Fist[value=True]'
    assert str(First(False)) == 'Fist[value=False]'
    assert str(First(None)) == 'Fist[value=None]'


# Generated at 2022-06-12 05:26:00.936548
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First("a") == First("a")
    assert Last("z") == Last("z")
    assert Max(1) == Max(1)
    assert Min(2) == Min(2)



# Generated at 2022-06-12 05:26:04.107230
# Unit test for method __str__ of class Map
def test_Map___str__():
    Map({'foo': Sum(5)}).__str__() == "{'foo': Sum(5)}"
    Map({'foo': Sum(5)}).__str__() != "{'foo': Sum(1)}"


# Generated at 2022-06-12 05:26:05.390424
# Unit test for constructor of class Min
def test_Min():
    """
            Function to test constructor of class Min.

            Raises
            ------
            AssertionError
                If test not passed.
            """

    assert Min(5).concat(Min(6)) == Min(5)


# Generated at 2022-06-12 05:26:06.665119
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-12 05:26:08.590378
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(str) == '1'
    assert Sum(2).fold(str) == '2'



# Generated at 2022-06-12 05:26:18.967049
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(2).fold(lambda x: x * 2) == 4
    assert All(False).fold(lambda x: x * 2) == 0
    assert One(False).fold(lambda x: x * 2) == 0
    assert First("first").fold(lambda x: x * 2) == "first"
    assert Last("last").fold(lambda x: x * 2) == "last"
    assert Max(4).fold(lambda x: x * 2) == 8
    assert Min(4).fold(lambda x: x * 2) == 8
    assert Max(-2).fold(lambda x: x * 2) == -4
    assert Min(-2).fold(lambda x: x * 2) == -4


# Generated at 2022-06-12 05:26:22.450818
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == 'Map[value={\'a\': Sum[value=1], \'b\': Sum[value=2]}]'



# Generated at 2022-06-12 05:26:29.872496
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({'test': Last(2), 'test2': Last(3)})
    m2 = Map({'test': Last(4), 'test3': Last(5)})
    m3 = Map({'test': Last(2), 'test2': Last(3)})
    assert m1.concat(m2).value == {'test': Last(4), 'test2': Last(3), 'test3': Last(5)}
    assert m3.concat(m2).concat(m3).value == {'test': Last(2), 'test2': Last(3), 'test3': Last(5)}



# Generated at 2022-06-12 05:26:36.650882
# Unit test for method concat of class Sum
def test_Sum_concat():
    first = Sum(1)
    second = Sum(4)
    third = Sum(12)

    assert first.concat(second) == Sum(5)
    assert first.concat(second).concat(third) == Sum(17)
    assert first.concat(Sum(2)).concat(Sum(3)) == Sum(6)



# Generated at 2022-06-12 05:26:47.588502
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert First(1) == First(1)
    assert Last(1) == Last(1)
    assert All(1) == All(1)
    assert One(1) == One(1)
    assert Map({1: 1}) == Map({1: 1})
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)

    assert not Sum(1) == Sum(2)
    assert not First(1) == First(2)
    assert not Last(1) == Last(2)
    assert not All(1) == All(2)
    assert not One(1) == One(2)
    assert not Map({1: 1}) == Map({2: 2})
    assert not Max(1) == Max(2)
    assert not Min

# Generated at 2022-06-12 05:26:49.743738
# Unit test for method concat of class First
def test_First_concat():
    """
    >>> First('a').concat(First('b')).value
    'a'
    """



# Generated at 2022-06-12 05:26:51.806781
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)

# Generated at 2022-06-12 05:26:54.482605
# Unit test for method concat of class Max
def test_Max_concat():
    """
    Test for method concat of class Max.

    :returns: None
    :rtype: None
    """
    assert Max(1).concat(Max(2)) == Max(2)



# Generated at 2022-06-12 05:26:56.852392
# Unit test for constructor of class Sum
def test_Sum():
    a = Sum(1)
    assert a == Sum(1)


# Generated at 2022-06-12 05:26:58.028372
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == "Sum[value=1]"


# Generated at 2022-06-12 05:27:00.550821
# Unit test for constructor of class First
def test_First():
    first = First(1)
    assert first.value == 1


# Generated at 2022-06-12 05:27:02.118836
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(100)) == "Max[value=100]"



# Generated at 2022-06-12 05:27:05.287126
# Unit test for constructor of class Sum
def test_Sum():
    print("Sum")
    s = Sum(1)
    print(s)
    assert type(s) is Sum
    assert s.value == 1


# Generated at 2022-06-12 05:27:09.849580
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(5).concat(Last(3)) == Last(3)
    assert Last(1).concat(Last(5)) == Last(5)



# Generated at 2022-06-12 05:27:12.116958
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'



# Generated at 2022-06-12 05:27:17.800030
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Last(10).fold(lambda x: x * 2) == 20
    assert First(10).fold(lambda x: x * 2) == 20
    assert One(10).fold(lambda x: x * 2) == 20
    assert All(10).fold(lambda x: x * 2) == 20
    assert Sum(10).fold(lambda x: x * 2) == 20
    assert Max(10).fold(lambda x: x * 2) == 20
    assert Min(10).fold(lambda x: x * 2) == 20

# Generated at 2022-06-12 05:27:21.860756
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)).value == True
    assert One(True).concat(One(True)).value == True
    assert One(False).concat(One(False)).value == False


# Generated at 2022-06-12 05:27:24.770149
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(3)
    assert Sum(1) != 3
    assert Sum(1) != {}

# Generated at 2022-06-12 05:27:27.667805
# Unit test for method concat of class Min
def test_Min_concat():
    min1 = Min(1)
    min2 = Min(2)
    assert min1.concat(min2) == Min(1)

# Generated at 2022-06-12 05:27:29.216606
# Unit test for constructor of class Max
def test_Max():
    assert Max.neutral() == Max.neutral_element

# Generated at 2022-06-12 05:27:30.207879
# Unit test for method concat of class All
def test_All_concat():
    all_ = All(True).concat(All(False))
    assert all_.__dict__ == {'value': False}


# Generated at 2022-06-12 05:27:36.956153
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(2)
    b = Min(6)
    c = a.concat(b)
    assert c.value == 2


Sum.neutral_element = Sum.neutral_element
All.neutral_element = All.neutral_element
One.neutral_element = One.neutral_element
First.neutral_element = First.neutral_element
Last.neutral_element = Last.neutral_element
Map.neutral_element = Map.neutral_element
Max.neutral_element = Max.neutral_element
Min.neutral_element = Min.neutral_element

# Generated at 2022-06-12 05:27:39.076416
# Unit test for constructor of class First
def test_First():  # pragma: no cover
    a = First()
    assert a.value is None



# Generated at 2022-06-12 05:27:42.051935
# Unit test for constructor of class First
def test_First():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-12 05:27:46.158615
# Unit test for constructor of class All
def test_All():
    try:
        assert All(True) == All(True)
        assert All(False) == All(False)
        assert not All(True) != All(False)
    except AssertionError:
        print("AssertionError - all unit test")


# Generated at 2022-06-12 05:27:47.947601
# Unit test for constructor of class First
def test_First():
    final = First('first')
    assert final.value == 'first'



# Generated at 2022-06-12 05:27:49.416563
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-12 05:27:53.052521
# Unit test for constructor of class Map
def test_Map():
    # Assert to value of the variable
    assert Map({'A': 1, 'B': 2}).value == {'A': 1, 'B': 2}

    # Assert not to value of the variable
    assert Map({'A': 1, 'B': 2}).value != {'A': 2, 'B': 1}

# Generated at 2022-06-12 05:27:55.592438
# Unit test for constructor of class Semigroup
def test_Semigroup():
    with pytest.raises(TypeError):
        Semigroup()

# Generated at 2022-06-12 05:28:03.169698
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(1)) == "All[value=True]"
    assert str(All(0)) == "All[value=False]"
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"
    assert str(All('1')) == "All[value=True]"
    assert str(All('0')) == "All[value=False]"
    assert str(All('')) == "All[value=False]"
    assert str(All([1])) == "All[value=True]"
    assert str(All([])) == "All[value=False]"
    assert str(All([[]])) == "All[value=True]"
    assert str(All({})) == "All[value=False]"


# Generated at 2022-06-12 05:28:05.262373
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(-2).concat(Sum(3)) == Sum(1)



# Generated at 2022-06-12 05:28:07.317064
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)



# Generated at 2022-06-12 05:28:11.934709
# Unit test for constructor of class Last
def test_Last():
    assert Last(0)
    assert Last(1)
    assert Last(True)
    assert Last(False)
    assert Last('')
    assert Last('x')
    assert Last([0, 1])
    assert Last([])
    assert Last({0:1, 2:3})
    assert Last(None)



# Generated at 2022-06-12 05:28:21.888915
# Unit test for constructor of class Last
def test_Last():
    assert Last(5).value == 5
    # Check that the equality of the value is 5
    assert Last(5) == Last(5)
    # Check that the equality is true
    assert str(Last(5)) == 'Last[value=5]'
    # Check that the string representation is equal to the expected value
    assert Last(5).concat(Last('6')) == Last('6')
    # Check that the concat method of the class Last return the correct value
    assert Last(5).fold(lambda val: val * 2) == 10
    # Check that the fold method of the class semigroup return the correct value



# Generated at 2022-06-12 05:28:24.328999
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(10)) == Max(10)



# Generated at 2022-06-12 05:28:26.500294
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert Max(0).__str__() == 'Max[value=0]'
test_Max___str__()


# Generated at 2022-06-12 05:28:27.510328
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)

# Generated at 2022-06-12 05:28:31.559758
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'
    assert str(Sum(5)) == 'Sum[value=5]'



# Generated at 2022-06-12 05:28:33.032164
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-12 05:28:35.113604
# Unit test for constructor of class One
def test_One():
    one_object = One(1)

    assert one_object.value == 1


# Generated at 2022-06-12 05:28:37.238719
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)



# Generated at 2022-06-12 05:28:39.881475
# Unit test for constructor of class First
def test_First():
    a = First(1)
    assert a is not None
    assert a.value is 1
    assert a.concat(First(2)).value is 1


# Generated at 2022-06-12 05:28:42.863591
# Unit test for constructor of class Last
def test_Last():
    last = Last(1)
    assert last.value == 1
    assert last == Last(1)
    assert str(last) == "Last[value=1]"


# Generated at 2022-06-12 05:28:47.528648
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1
    assert Max(2).value == 2

# Generated at 2022-06-12 05:28:51.573585
# Unit test for constructor of class One
def test_One():
    """
    Unit test for constructor of class One.
    """
    one = One(True)
    assert one.value is True
    one = One(False)
    assert one.value is False



# Generated at 2022-06-12 05:28:55.766991
# Unit test for constructor of class Last
def test_Last():
    last = Last(3)
    assert last.value == 3
    assert last.concat(Last(4)).value == 4
    assert last.fold(lambda value: value ** 2) == 9
    assert last == Last(3)
    assert last != Last(4)



# Generated at 2022-06-12 05:28:57.026496
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x + x) == 2



# Generated at 2022-06-12 05:28:58.536002
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)


# Generated at 2022-06-12 05:29:00.250582
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(3)) == 'Max[value=3]'


# Generated at 2022-06-12 05:29:05.945510
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    Get last value from List[A]
    """
    assert Semigroup(2).value == 2
    assert Semigroup([1, 2, 3]).value == [1, 2, 3]
    assert Semigroup({'a': 1, 'b': 2}).value == {'a': 1, 'b': 2}



# Generated at 2022-06-12 05:29:09.442376
# Unit test for method concat of class One
def test_One_concat():
    one = One(True)
    other = One(False)
    assert one.concat(other) == One(True)
    assert other.concat(one) == One(True)


# Generated at 2022-06-12 05:29:11.206551
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(10)) == 'Fist[value=10]'



# Generated at 2022-06-12 05:29:14.141481
# Unit test for method concat of class First
def test_First_concat():
    f1 = First('a')
    f2 = First('b')
    assert f1.concat(f2) == First('a')


# Generated at 2022-06-12 05:29:31.901892
# Unit test for method __str__ of class First
def test_First___str__():
    # must be true
    assert str(First(1)) == "Fist[value=1]", 'class First method __str__() does not work as expected'
    assert str(First(True)) == "Fist[value=True]", 'class First method __str__() does not work as expected'
    assert str(First(None)) == "Fist[value=None]", 'class First method __str__() does not work as expected'
    assert str(First([])) == "Fist[value=[]]", 'class First method __str__() does not work as expected'
    assert str(First({})) == "Fist[value={}]", 'class First method __str__() does not work as expected'

# Generated at 2022-06-12 05:29:35.277239
# Unit test for method concat of class One
def test_One_concat():
    one = One(True)
    another_one = One(False)
    assert one.concat(another_one).value == one.value
    assert another_one.concat(one).value == one.value

# Generated at 2022-06-12 05:29:38.290382
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == "Sum[value=1]"
    assert str(Sum(2)) == "Sum[value=2]"
    assert str(Sum(3)) == "Sum[value=3]"


# Generated at 2022-06-12 05:29:40.058647
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-12 05:29:42.552379
# Unit test for method __str__ of class Min
def test_Min___str__():
    value = 1

    semigroup = Min(value)

    assert str(semigroup) == "Min[value=%d]" % value


# Generated at 2022-06-12 05:29:52.830342
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    inc = lambda x: x + 1
    dec = lambda x: x - 1
    sum_ = lambda x: x + 0
    assert Sum(10).fold(inc).fold(dec).fold(sum_) == 10
    assert All(True).fold(sum_) == True
    assert All(False).fold(sum_) == False
    assert One(True).fold(sum_) == True
    assert One(False).fold(sum_) == False
    assert First(1).fold(sum_) == 1
    assert Last(10).fold(sum_) == 10
    assert Map({
        'key': Sum(1)
    }).fold(sum_) == {'key': 1}
    assert Max(7).fold(sum_) == 7
    assert Min(1).fold(sum_) == 1

# Unit test

# Generated at 2022-06-12 05:29:56.486021
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False


# Generated at 2022-06-12 05:30:02.482669
# Unit test for constructor of class Map
def test_Map():
    map_ = {'key': Sum(2)}
    map_1 = {'key': Sum(7)}

    concated = Map(map_).concat(Map(map_1))

    assert concated.value == {'key': Sum(9)}
    assert concated.value['key'] == Sum(9)
    assert concated.value['key'].value == 9


# Generated at 2022-06-12 05:30:04.225756
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True
    assert One(False).value == False


# Generated at 2022-06-12 05:30:06.198949
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(3)) == Max(5)


# Generated at 2022-06-12 05:30:20.394229
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(10)) == "Fist[value=10]"



# Generated at 2022-06-12 05:30:23.370629
# Unit test for constructor of class All
def test_All():
    all_true = All(True)
    assert all_true.value is True

    all_false = All(False)
    assert all_false.value is False


# Generated at 2022-06-12 05:30:24.618314
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(3).concat(Last(2)).value == 2



# Generated at 2022-06-12 05:30:26.514857
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    assert str(Last(2)) == 'Last[value=2]'


# Generated at 2022-06-12 05:30:31.031840
# Unit test for method concat of class Last
def test_Last_concat():
    last_a = Last(1)
    last_b = Last(2)
    assert last_a.concat(last_b) == Last(2)
    assert last_b.concat(last_a) == Last(1)
    assert last_a.concat(last_a) == Last(1)


# Generated at 2022-06-12 05:30:37.121648
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(None)) is None
    assert One(None).concat(One(None)) is None
    assert One(None).concat(One(False)) is None
    assert One(None).concat(One(True)) is None


# Generated at 2022-06-12 05:30:41.584383
# Unit test for constructor of class Map
def test_Map():
    map = {1: "one", 2: "two"}
    map2 = {1: "eins", 2: "zwei"}
    _map = Map(map)
    _map2 = Map(map2)

    assert isinstance(_map, Map)
    assert isinstance(_map2, Map)


# Generated at 2022-06-12 05:30:43.711362
# Unit test for method concat of class First
def test_First_concat():
    assert First('a').concat(First('b')).value == 'a'

# Generated at 2022-06-12 05:30:47.313036
# Unit test for constructor of class Min
def test_Min():
    assert Min(5).value == 5
    assert Min(5).concat(Min(6)).value == 5
    assert Min(6).concat(Min(5)).value == 5
    assert Min(7).concat(Min(6)).value == 6

# Generated at 2022-06-12 05:30:49.144276
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({"a": 1})) == 'Map[value={"a": 1}]'


# Generated at 2022-06-12 05:31:16.829624
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(2) == Sum(2)
    assert not Semigroup(2) == Sum(3)


# Generated at 2022-06-12 05:31:20.703949
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value == True
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
    assert All(False).concat(All(False)).value == False



# Generated at 2022-06-12 05:31:23.178980
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    obj = Sum(1)
    assert str(obj) == 'Sum[value=1]'


# Generated at 2022-06-12 05:31:24.634221
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)


# Generated at 2022-06-12 05:31:28.049595
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)


# Generated at 2022-06-12 05:31:29.402850
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-12 05:31:32.246072
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert(Sum(1) == Sum(1))
    assert(Sum(2) == Sum(2))


# Generated at 2022-06-12 05:31:39.227337
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert Last(1) != All(True)
    assert Last(1) != Sum(1)
    assert Last(1) != One(False)
    assert Last(1) != First(1)
    assert Last(1) != Map({})
    assert Last(1) != Max(1)
    assert Last(1) != Min(1)


# Generated at 2022-06-12 05:31:40.165178
# Unit test for constructor of class Sum
def test_Sum(): # pragma: no cover
    print(Sum(2))



# Generated at 2022-06-12 05:31:42.246990
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1).value == 1
    assert str(First(1))


# Generated at 2022-06-12 05:32:36.069975
# Unit test for constructor of class One
def test_One():
    one = One(1)
    assert one.value == 1


# Generated at 2022-06-12 05:32:40.038920
# Unit test for method concat of class Map
def test_Map_concat():
    m = Map({'a': Sum(1), 'b': Sum(2)})
    m1 = Map({'a': Sum(1), 'b': Sum(2)})
    assert m.concat(m1) == Map({'a': Sum(2), 'b': Sum(4)})


# Generated at 2022-06-12 05:32:42.005898
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-12 05:32:43.401991
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    unit test for constructor of Semigroup class
    """
    assert Semigroup(5).value == 5



# Generated at 2022-06-12 05:32:45.150690
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1
    assert First(1) == First(1)


# Generated at 2022-06-12 05:32:48.120545
# Unit test for method __str__ of class Last
def test_Last___str__():
    obj = Last(3)
    assert str(obj) == 'Last[value=3]'


# Generated at 2022-06-12 05:32:49.869500
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert 'Min[value=5]' == str(Min(5))

# Generated at 2022-06-12 05:32:51.974858
# Unit test for method __str__ of class Min
def test_Min___str__(): # pragma: no cover
    min_4 = Min(4)
    assert str(min_4) == "Min[value=4]"


# Generated at 2022-06-12 05:32:53.665891
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'
    assert str(Max(10)) == 'Max[value=10]'


# Generated at 2022-06-12 05:32:56.933085
# Unit test for method concat of class Sum
def test_Sum_concat():  # pragma: no cover
    # Sum[value=10]
    assert Sum(1).concat(Sum(9)) == Sum(10)

