

# Generated at 2022-06-12 05:23:47.508347
# Unit test for method concat of class Map
def test_Map_concat():
    m = Map({'a': Sum(1), 'b': Sum(2)})
    m2 = Map({'a': Sum(1), 'b': Sum(2)})
    assert m.concat(m2) == Map({'a': Sum(2), 'b': Sum(4)})



# Generated at 2022-06-12 05:23:54.703506
# Unit test for method concat of class Map
def test_Map_concat():
    # Given
    map_obj = Map({"foo": Sum(1), "bar": Sum(2)})

    # When
    actual_result = map_obj.concat(Map({"foo": Sum(3), "bar": Sum(4)}))

    # Then
    assert actual_result.value["foo"] == Sum(4).value
    assert actual_result.value["bar"] == Sum(6).value



# Generated at 2022-06-12 05:23:59.542666
# Unit test for method concat of class Map
def test_Map_concat():
    semigroup1 = Map({1: First(1), 2: First(2)})
    semigroup2 = Map({1: First(1), 2: First(2), 3: None})
    assert semigroup1.concat(semigroup2) == Map({1: First(1), 2: First(2), 3: None})

# Generated at 2022-06-12 05:24:06.740324
# Unit test for method concat of class Map
def test_Map_concat():
    my_map = Map({'key': Sum(1), 'key2': Sum(2), 'key3': Sum(3)})
    my_map2 = Map({'key': Sum(1), 'key2': Sum(2)})
    my_map3 = Map({'key': Sum(1), 'key2': Sum(2), 'key3': Sum(3)})
    my_map4 = my_map.concat(Map({'key': Sum(1), 'key2': Sum(2), 'key3': Sum(3)}))
    assert my_map.value['key'].value == 2
    assert my_map.value['key2'].value == 4
    assert my_map.value['key3'].value == 6

# Generated at 2022-06-12 05:24:12.870891
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({'a': Sum(1), 'b': Sum(2), 'c': Sum(3)})
    m2 = Map({'a': Sum(4), 'b': Sum(5), 'c': Sum(6)})
    assert m1.concat(m2) == Map({'a': Sum(5), 'b': Sum(7), 'c': Sum(9)})


# Generated at 2022-06-12 05:24:18.445620
# Unit test for method concat of class Map
def test_Map_concat():
    map_one = Map({'a': First('a'), 'b': Last(3)})
    map_two = Map({'a': First('bb'), 'c': Last(4)})
    map_three = Map({'a': First('a'), 'b': Last(4), 'c': Last(4)})
    assert map_one.concat(map_two) == map_three



# Generated at 2022-06-12 05:24:26.460891
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'one': First(1), 'two': First('2')}).concat(Map({'one': First(3), 'two': First('4')})) == Map({'one': First(1), 'two': First('2')})
    assert Map({'one': Last(1), 'two': Last('2')}).concat(Map({'one': Last(3), 'two': Last('4')})) == Map({'one': Last(3), 'two': Last('4')})
    assert Map({'one': Sum(1), 'two': Sum(2)}).concat(Map({'one': Sum(3), 'two': Sum(4)})) == Map({'one': Sum(4), 'two': Sum(6)})
    assert Map({'one': All(1), 'two': All(2)}).concat

# Generated at 2022-06-12 05:24:29.583545
# Unit test for method concat of class Map
def test_Map_concat():
    """
    Test concat of Map
    """
    map_one = Map({"foo": Sum(1)})
    map_two = Map({"foo": Sum(2), "bar": Sum(1)})
    map_result = Map({"foo": Sum(3), "bar": Sum(1)})
    assert map_one.concat(map_two) == map_result


# Generated at 2022-06-12 05:24:33.103260
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map({1: Sum(1), 2: Sum(2)})
    map2 = Map({1: Sum(3), 3: Sum(3)})

    assert isinstance(map1.concat(map2), Map)
    assert map1.concat(map2) == Map({1: Sum(4), 2: Sum(2), 3: Sum(3)})

# Generated at 2022-06-12 05:24:40.135202
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({}).concat(Map({})) == Map({})

    assert Map({'one': Sum(1)}).concat(Map({'one': Sum(1)})) == Map({'one': Sum(2)})
    assert Map({'one': First(1)}).concat(Map({'one': First(1)})) == Map({'one': First(1)})
    assert Map({'one': Last(1)}).concat(Map({'one': Last(1)})) == Map({'one': Last(1)})
    assert Map({'one': All(True)}).concat(Map({'one': All(True)})) == Map({'one': All(True)})

# Generated at 2022-06-12 05:24:46.133812
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-12 05:24:48.655178
# Unit test for method __str__ of class Max
def test_Max___str__():
    from nose.tools import assert_equal  # type: ignore
    assert_equal(Max(1).__str__(), "Max[value=1]")



# Generated at 2022-06-12 05:24:50.908527
# Unit test for constructor of class Last
def test_Last():
    expect(
        Last(10)
    ).to(
        equal(Last(10))
    )


# Generated at 2022-06-12 05:24:53.138550
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: Sum(10)})) == 'Map[value={1: Sum[value=10]}]'

# Generated at 2022-06-12 05:24:57.121926
# Unit test for method __str__ of class Last
def test_Last___str__():
    # Arrange
    value = 'abc'
    last = Last(value)

    # Act
    result = last.__str__()

    # Assert
    assert result == 'Last[value=abc]'


# Generated at 2022-06-12 05:25:04.972077
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'
    assert str(Last("Hello")) == 'Last[value=Hello]'
    assert str(Last([])) == 'Last[value=[]]'
    assert str(Last(())) == 'Last[value=()]'
    assert str(Last({})) == 'Last[value={}]'
    assert str(Last({'a': 1, 'b': 2})) == 'Last[value={\'a\': 1, \'b\': 2}]'



# Generated at 2022-06-12 05:25:08.425035
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(2) == First(2)

    assert First(1) != First(2)
    assert First(1) != First(4)
    assert First(2) != First(3)


# Generated at 2022-06-12 05:25:10.492687
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(4).concat(Max(2)) == Max(4)


# Generated at 2022-06-12 05:25:11.762045
# Unit test for constructor of class Max
def test_Max():
    result = Max(1)
    assert result.value == 1


# Generated at 2022-06-12 05:25:13.088309
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-12 05:25:16.320810
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    assert 'Last[value=3]' == str(Last(3))



# Generated at 2022-06-12 05:25:18.045153
# Unit test for method __str__ of class One
def test_One___str__():
    assert(str(One(2)) == 'One[value=2]')


# Generated at 2022-06-12 05:25:19.709395
# Unit test for method concat of class One
def test_One_concat():
    value = One(True).concat(One(False))
    assert isinstance(value, One)
    assert value == One(True)



# Generated at 2022-06-12 05:25:21.072120
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-12 05:25:23.280784
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    """
    Unit test for method __str__ of class Sum
    """
    assert str(Sum(2)) == 'Sum[value=2]'



# Generated at 2022-06-12 05:25:24.498433
# Unit test for constructor of class Max
def test_Max():
    max = Max(-100)
    assert max.value == -100


# Generated at 2022-06-12 05:25:31.177204
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """test_Semigroup___eq__"""
    assert Sum(1) == Sum(1)
    assert Sum(2) != Sum(1)
    assert All(True) == All(True)
    assert All(False) != All(True)
    assert One(True) == One(True)
    assert One(False) != One(True)
    assert First("abc") == First("abc")
    assert First("abc") != First("def")
    assert Last("abc") == Last("abc")
    assert Last("abc") != Last("def")
    assert Max(1) == Max(1)
    assert Max(2) != Max(1)
    assert Min(1) == Min(1)
    assert Min(2) != Min(1)

# Generated at 2022-06-12 05:25:42.064686
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(2)).concat(Min(3)) == Min(1)
    assert Min(2).concat(Min(1)).concat(Min(3)) == Min(1)
    assert Min(3).concat(Min(2)).concat(Min(1)) == Min(1)
    assert Min(3).concat(Min(1)).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(3)).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(3)).concat(Min(2)) == Min(1)



# Generated at 2022-06-12 05:25:43.822140
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: Sum(1), 2: Sum(2)})) == 'Map[value={1: Sum[value=1], 2: Sum[value=2]}]'


# Generated at 2022-06-12 05:25:54.461513
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():

    assert Sum(4) == Sum(4)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First(3) == First(3)
    assert Last(2) == Last(2)
    assert (
        Map({'a': Sum(1), 'b': Sum(2), 'c': Sum(3)}) ==
        Map({'a': Sum(1), 'b': Sum(2), 'c': Sum(3)})
    )
    assert Max(4) == Max(4)
    assert Min(3) == Min(3)

    assert Sum(4) != Sum(5)
    assert All(False) != All(True)
    assert One(True) != One(False)
    assert First(3) != First(5)

# Generated at 2022-06-12 05:25:58.688400
# Unit test for method concat of class All
def test_All_concat():
    a = All(True)
    b = All(False)
    assert a.concat(b) == All(False)



# Generated at 2022-06-12 05:26:02.327302
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(3)) == Sum(5)
    assert Sum(3).concat(Sum(3)) == Sum(6)
    assert Sum(3).concat(Sum(2)) == Sum(5)


# Generated at 2022-06-12 05:26:08.026311
# Unit test for method concat of class One
def test_One_concat():
    one_1 = One(True)
    one_2 = One(False)
    one_3 = One(True)
    one_4 = One(False)

    assert one_1.concat(one_2) == One(True)
    assert one_2.concat(one_1) == One(True)

    assert one_2.concat(one_4) == one_4
    assert one_4.concat(one_2) == one_4

    assert one_1.concat(one_3) == one_1
    assert one_3.concat(one_1) == one_3



# Generated at 2022-06-12 05:26:11.105604
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-12 05:26:16.158798
# Unit test for method concat of class Min
def test_Min_concat():
    # True case with smallest
    _min = Min(100)
    assert _min.concat(Min(200)) == Min(100)
    # False case with smallest
    assert _min.concat(Min(20)) == Min(20)
    # False case with smallest
    assert _min.concat(Min(-20)) == Min(-20)

# Generated at 2022-06-12 05:26:17.122228
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(123)) == 'Sum[value=123]'



# Generated at 2022-06-12 05:26:19.825695
# Unit test for constructor of class Semigroup
def test_Semigroup():
    semigroup = Semigroup(1)
    assert semigroup.value == 1



# Generated at 2022-06-12 05:26:21.791420
# Unit test for method __str__ of class Last
def test_Last___str__(): # pragma: no cover
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-12 05:26:30.595149
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    semigroup_sum = Sum(2)
    assert semigroup_sum.fold(lambda a: a * 2) == 4
    semigroup_all = All(True)
    assert semigroup_all.fold(lambda a: a * 2) == 2
    semigroup_one = One(True)
    assert semigroup_one.fold(lambda a: a * 2) == 2
    semigroup_first = First(2)
    assert semigroup_first.fold(lambda a: a * 2) == 4
    semigroup_last = Last(2)
    assert semigroup_last.fold(lambda a: a * 2) == 4
    semigroup_map = Map({'a': Sum(1), 'b': Sum(2)})
    assert semigroup_map.fold(lambda a: a['a'].concat(a['b']))

# Generated at 2022-06-12 05:26:35.430800
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({1: Sum(1), 2: Sum(2)})
    m2 = Map({1: Sum(3), 2: Sum(4)})

    assert m1.concat(m2) == Map({1: Sum(4), 2: Sum(6)})



# Generated at 2022-06-12 05:26:40.256691
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    _1 = Semigroup(42)
    _2 = Semigroup(42)
    _3 = Semigroup(43)

    assert _1 == _2
    assert _1 != _3



# Generated at 2022-06-12 05:26:42.237950
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value is True
    assert All(True).concat(All(False)).value is False
    assert All(False).concat(All(True)).value is False
    assert All(False).concat(All(False)).value is False



# Generated at 2022-06-12 05:26:43.802963
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-12 05:26:46.945721
# Unit test for constructor of class First
def test_First():  # pragma: no cover
    first = First('yay')
    assert first.value == 'yay'
    assert first.concat(First('nay')).value == 'yay'



# Generated at 2022-06-12 05:26:47.954768
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1



# Generated at 2022-06-12 05:26:49.650973
# Unit test for constructor of class Semigroup
def test_Semigroup():
    semigroup = Semigroup(10)
    assert semigroup.value == 10



# Generated at 2022-06-12 05:26:52.057738
# Unit test for constructor of class One
def test_One():
    assert One(3) == One(3)
    assert One(3) != One(None)


# Generated at 2022-06-12 05:26:54.053547
# Unit test for constructor of class Last
def test_Last():  # pragma: no cover
    value = 10
    instance = Last(value)
    assert instance.value == value



# Generated at 2022-06-12 05:26:55.704552
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'



# Generated at 2022-06-12 05:26:58.016081
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)


# Generated at 2022-06-12 05:27:09.409239
# Unit test for method concat of class Max
def test_Max_concat(): 
    # Create 2 max semigroups
    max1 = Max(8)
    max2 = Max(10)

    # Create concated max semigroup
    max3 = max1.concat(max2)

    # Print out the concated max semigroup
    print(max3)

    # ---
    # Create 2 min semigroups
    min1 = Min(8)
    min2 = Min(10)

    # Create concated min semigroup
    min3 = min1.concat(min2)

    # Print out the concated min semigroup
    print(min3)


test_Max_concat()

# Generated at 2022-06-12 05:27:11.628983
# Unit test for constructor of class Sum
def test_Sum():
    sum_one = Sum(1)
    sum_two = Sum(2)

    assert(sum_one != sum_two)



# Generated at 2022-06-12 05:27:13.090190
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert 'Max[value=1]' == str(Max(1))


# Generated at 2022-06-12 05:27:16.248379
# Unit test for method concat of class First
def test_First_concat():
    hello = First("Hello")
    world = First("World")
    result = hello.concat(world)
    assert result == First("Hello")
    assert result != First("World")



# Generated at 2022-06-12 05:27:20.294773
# Unit test for method concat of class Max
def test_Max_concat():
    m = Max(3)
    n = Max(2)
    p = Max(15)
    assert m.concat(n).concat(p).value == 15



# Generated at 2022-06-12 05:27:22.420511
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    a = Sum(2)
    assert str(a) == 'Sum[value=2]'


# Generated at 2022-06-12 05:27:24.853503
# Unit test for constructor of class Max
def test_Max():
    assert Max(5) == Max(5)
    assert Max(5) != Max(6)
    assert Max(5).value == 5


# Generated at 2022-06-12 05:27:27.723012
# Unit test for method __str__ of class First
def test_First___str__():
    first_str = First(1).__str__()
    assert first_str == 'Fist[value=1]'



# Generated at 2022-06-12 05:27:31.208267
# Unit test for method concat of class Min
def test_Min_concat():
    s1 = Min(10)
    s2 = Min(5)
    expected = 5
    actual = s1.concat(s2).value
    assert expected == actual



# Generated at 2022-06-12 05:27:33.910213
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    val = Semigroup(Sum(1)).fold(lambda x: x.concat(Sum(2)))
    assert val == Sum(3)

# Generated at 2022-06-12 05:27:39.591156
# Unit test for constructor of class Max
def test_Max():
    max_1 = Max(5)
    max_2 = Max(2)
    assert max_1.fold(lambda x: x) == 5
    assert max_2.fold(lambda x: x) == 2


# Generated at 2022-06-12 05:27:43.609115
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'
    assert str(Max("a")) == 'Max[value=a]'
    assert str(Max(None)) == 'Max[value=None]'



# Generated at 2022-06-12 05:27:46.593541
# Unit test for method concat of class Last
def test_Last_concat():  # pragma: no cover
    assert Last('a').concat(Last('b')) == Last('b')



# Generated at 2022-06-12 05:27:48.362786
# Unit test for method __str__ of class First
def test_First___str__():
    assert isinstance(First(None).__str__(), str)



# Generated at 2022-06-12 05:27:51.592569
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == str(Max(1))
    assert str(Max(1)) != str(Max(2))
    assert 'value=1' in str(Max(1))

# Generated at 2022-06-12 05:28:00.436231
# Unit test for method concat of class Map
def test_Map_concat():
    expected = Map(
        {
            "a": Sum(2),
            "b": First("b"),
            "c": Last("c1"),
            "d": All(False),
        }
    )
    actual = Map(
        {
            "a": Sum(1),
            "b": First("b"),
            "c": Last("c2"),
            "d": All(True),
        }
    )
    actual2 = Map(
        {
            "a": Sum(1),
            "b": First("b"),
            "c": Last("c1"),
            "d": All(False),
        }
    )
    assert actual.concat(actual2) == expected

# Generated at 2022-06-12 05:28:07.857755
# Unit test for constructor of class Map
def test_Map():
    assert Map({
        'name': First("alex"),
        'age': Max(15),
    }) == Map({
        'name': First("alex"),
        'age': Max(15),
    })

    assert str(Map({
        'name': First("alex"),
        'age': Max(15),
    })) == "Map[value={'name': Fist[value=alex], 'age': Max[value=15]}]"


# Generated at 2022-06-12 05:28:12.647540
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    semigroup1 = All(True)
    semigroup2 = All(False)
    assert semigroup1.concat(semigroup2) == All(False)
    assert semigroup2.concat(semigroup1) == All(False)
    assert semigroup1.concat(semigroup1) == All(True)


# Generated at 2022-06-12 05:28:16.585796
# Unit test for method concat of class Last
def test_Last_concat():
    """
    Test concat method of class Last
    """
    last_a = Last('a')
    last_b = Last('b')
    assert last_a.concat(last_b) == last_b

# Generated at 2022-06-12 05:28:18.715501
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(2).concat(Max(3)) == Max(3)
    assert Max(3).concat(Max(2)) == Max(3)



# Generated at 2022-06-12 05:28:29.455778
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x + 2) == 3
    assert One(False).fold(lambda x: 2) == 2
    assert All(False).fold(lambda x: 2) == False
    assert First("test").fold(lambda x: 2) == "test"
    assert Last("test").fold(lambda x: 2) == "test"
    assert Max(5).fold(lambda x: 2) == 5
    assert Min(5).fold(lambda x: 2) == 5
    assert Map({'a': Sum(1)}).fold(lambda x: x['a'].concat(Sum(2))).value == 3


# Generated at 2022-06-12 05:28:34.485832
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)).value == True
    assert One(True).concat(One(True)).value == True
    assert One(False).concat(One(True)).value == True
    assert One(True).concat(One(False)).value == True



# Generated at 2022-06-12 05:28:41.115358
# Unit test for method concat of class Last
def test_Last_concat():
    last_1 = Last(1)
    last_2 = Last(2)
    last_3 = Last(3)
    assert last_1.concat(last_2) == last_2.concat(last_1)
    assert last_2.concat(last_3) == last_3
    assert last_1.concat(last_2).concat(last_3) == last_2.concat(last_1).concat(last_3)



# Generated at 2022-06-12 05:28:46.943205
# Unit test for method concat of class Map
def test_Map_concat():
    list_key_value = [{"a":Sum(1)},{"a":Sum(2)},{"a":Sum(3)}]
    list_key_value_new = []
    for i in range(len(list_key_value) - 1):
        list_key_value_new.append(list_key_value[i].concat(list_key_value[i+1]))
    print(list_key_value_new)

if __name__ == "__main__":
    test_Map_concat()

# Generated at 2022-06-12 05:28:49.061242
# Unit test for constructor of class One
def test_One():
    assert (One(False).value == False)


# Generated at 2022-06-12 05:28:54.768646
# Unit test for method concat of class Map
def test_Map_concat():
    left = Map({"a": Sum(1), "b": Sum(2), "c": Sum(3)})
    right = Map({"a": Sum(3), "b": Sum(2), "c": Sum(1)})
    assert left.concat(right).value == {"a": Sum(4), "b": Sum(4), "c": Sum(4)}


# Generated at 2022-06-12 05:28:56.432543
# Unit test for constructor of class Semigroup
def test_Semigroup():
    semigroup = Semigroup(0)
    assert semigroup.value == 0

# Unit tests for constructor of class Sum

# Generated at 2022-06-12 05:29:01.122674
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map({'a': Sum(1)})
    map2 = Map({'a': Sum(2)})
    map3 = Map({'a': Sum(3)})
    sum1 = map1.concat(map2)
    assert sum1.value == {'a': Sum(3)}
    sum2 = sum1.concat(map3)
    assert sum2.value == {'a': Sum(6)}


# Generated at 2022-06-12 05:29:02.724908
# Unit test for constructor of class Min
def test_Min():
    assert Min(5).value == 5


# Generated at 2022-06-12 05:29:04.329029
# Unit test for constructor of class Min
def test_Min():
    assert Min(2) == Min(2)


# Generated at 2022-06-12 05:29:10.638230
# Unit test for method __str__ of class Min
def test_Min___str__(): # pragma: no cover
    assert str(Min(-2)) == "Min[value=-2]"


# Generated at 2022-06-12 05:29:12.709800
# Unit test for constructor of class One
def test_One():
    value = True
    monoid = One(value)
    assert monoid.value == value


# Generated at 2022-06-12 05:29:14.194058
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-12 05:29:16.053775
# Unit test for constructor of class Last
def test_Last():
    result = construct('Last', 1)
    expected = Last(1)
    assert result == expected


# Generated at 2022-06-12 05:29:18.193957
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x * 2) == 2
    assert Semigroup(1).fold(lambda x: x) == 1



# Generated at 2022-06-12 05:29:26.186791
# Unit test for method concat of class Min
def test_Min_concat():  # pragma: no cover
    """
    :returns: bool, result test method concat of class Min
    :rtype: bool
    """
    min_one = Min(1)
    min_three = Min(3)
    min_five = Min(5)
    assert (min_one.concat(min_three).value == 1)
    assert (min_three.concat(min_five).value == 3)
    assert (min_one.concat(min_five).value == 1)


# Generated at 2022-06-12 05:29:31.703447
# Unit test for method concat of class Last
def test_Last_concat():
    assert First('a').concat(First('b')) == First('a')
    assert First('a').concat(Last('b')) == Last('b')
    assert Last('a').concat(Last('b')) == Last('b')
    assert Last('a').concat(First('b')) == Last('a')



# Generated at 2022-06-12 05:29:34.158160
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'



# Generated at 2022-06-12 05:29:36.035506
# Unit test for method concat of class Last
def test_Last_concat():
    l1 = Last(1)
    l2 = Last(2)
    assert l1.concat(l2) == Last(2)

# Generated at 2022-06-12 05:29:43.245215
# Unit test for method concat of class Map
def test_Map_concat():
    monoid_map = Map({"a": First("b"), "b": Last("c"), "c": Sum(1), "d": All(False)})
    semigroup_map = Map({"a": Last("z"), "b": First("a"), "c": Sum(2), "d": All(True)})
    try:
        assert monoid_map.concat(semigroup_map).fold(lambda x: x) == {
            'a': First('b'),
            'b': Last('c'),
            'c': Sum(3),
            'd': All(False),
        }
    except AssertionError:
        print(
            'test for method concat of class Map failed. The result is ',
            monoid_map.concat(semigroup_map).fold(lambda x: x),
        )




# Generated at 2022-06-12 05:29:47.517290
# Unit test for constructor of class First
def test_First():
    assert First(2) == First(2)



# Generated at 2022-06-12 05:29:49.646298
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    semigroup = Semigroup(5)
    assert semigroup.value == 5



# Generated at 2022-06-12 05:29:50.645137
# Unit test for constructor of class Min
def test_Min():
    assert Min(5).value == 5


# Generated at 2022-06-12 05:29:52.140613
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert Sum(10).__str__() == 'Sum[value=10]'


# Generated at 2022-06-12 05:29:53.457275
# Unit test for constructor of class One
def test_One():
    one = One(1)
    assert one.value == 1


# Generated at 2022-06-12 05:29:58.544958
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(4).concat(Sum(4)) == Sum(8)
    assert Sum(4).concat(Sum(4)) == Sum(8)

    assert Sum(4).concat(Sum(-4)) == Sum(0)
    assert Sum(-4).concat(Sum(-4)) == Sum(-8)



# Generated at 2022-06-12 05:30:03.767479
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(1) == One(1)
    assert One("test") == One("test")
    assert One(None) == One(None)
    assert One([]) == One([])
    assert One(One(True)) == One(True)



# Generated at 2022-06-12 05:30:12.547390
# Unit test for method concat of class Map
def test_Map_concat():
    groups = [
        {'a': First(1), 'b': First(1), 'c': First(1)},
        {'a': First(2), 'b': First(1), 'c': First(1)},
        {'a': First(2), 'b': First(2), 'c': First(2)}
    ]
    result = Map({'a': First(1), 'b': First(1), 'c': First(1)})
    for group in groups:
        result = result.concat(Map(group))
    assert result.value['a'].value == 1
    assert result.value['b'].value == 1
    assert result.value['c'].value == 1

# Generated at 2022-06-12 05:30:18.746247
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(True) == One(True)
    assert First(1) == First(1)
    assert Last(1) == Last(1)
    assert Max(2) == Max(2)
    assert Min(2) == Min(2)
    assert Map({'a': 1}) == Map({'a': 1})
    assert Sum(1) != Sum(3)
    assert All(True) != All(False)
    assert One(True) != One(False)
    assert First(1) != First(2)
    assert Last(1) != Last(2)
    assert Max(2) != Max(3)
    assert Min(2) != Min(1)

# Generated at 2022-06-12 05:30:22.226562
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(
        Map({"one": Sum(1), "two": Sum(2)})) == "Map[value={'one': Sum[value=1], 'two': Sum[value=2]}]"



# Generated at 2022-06-12 05:30:27.383027
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last("last").concat(Last("first")).value == "last"


# Generated at 2022-06-12 05:30:29.286071
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(2).fold(lambda x: x ** 2) == 4



# Generated at 2022-06-12 05:30:31.261814
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)).value == 2
    assert Last(2).concat(Last(1)).value == 1


# Generated at 2022-06-12 05:30:33.358804
# Unit test for constructor of class One
def test_One():
    """
    Unit testing for constructor of class One
    """
    x = One(True)
    assert True == x.value



# Generated at 2022-06-12 05:30:35.431031
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'

# Generated at 2022-06-12 05:30:39.990413
# Unit test for method concat of class First
def test_First_concat():
    assert First.neutral().concat(First.neutral()) == First.neutral()
    assert First(1).concat(First.neutral()) == First(1)
    assert First.neutral().concat(First(2)) == First(2)
    assert First(1).concat(First(2)) == First(1)


# Generated at 2022-06-12 05:30:41.872328
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 2) == 3



# Generated at 2022-06-12 05:30:47.507192
# Unit test for method __str__ of class One
def test_One___str__():
    try:
        assert isinstance(One(True).__str__(), str)
    except AssertionError:
        print('AssertionError: test_One___str__')

    try:
        assert One(True).__str__() == 'One[value=True]'
    except AssertionError:
        print('AssertionError: test_One___str__')



# Generated at 2022-06-12 05:30:50.170827
# Unit test for method concat of class First
def test_First_concat():
    test1 = First(5)
    test2 = First(10)
    assert test1.concat(test2) == First(5)


# Generated at 2022-06-12 05:30:53.398089
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(2) != Semigroup(1)


# Generated at 2022-06-12 05:30:57.651181
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(True).value == True
    assert One(False).value == False


# Generated at 2022-06-12 05:31:02.577106
# Unit test for constructor of class All
def test_All():
    """
    Set up of the test for constructor of class All
    """
    assert All(5) == All(5)
    assert All("5") != All("6")
    assert All("5") != All("5")
    assert All("5") == All("5")
    assert All("5") != All("50")

    # Unit test for constructor of class Sum

# Generated at 2022-06-12 05:31:04.196346
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First(10)) == 'Fist[value=10]'



# Generated at 2022-06-12 05:31:08.457638
# Unit test for method concat of class Sum
def test_Sum_concat():  # pragma: no cover
    assert Sum(5).concat(Sum(7)) == Sum(12)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)) == Sum(10)


# Generated at 2022-06-12 05:31:09.994609
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(5)) == "Fist[value=5]"


# Generated at 2022-06-12 05:31:15.399680
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2), 'c': Sum(3)})) == 'Map[value={\'a\': Sum[value=1], \'b\': Sum[value=2], \'c\': Sum[value=3]}]'



# Generated at 2022-06-12 05:31:16.875619
# Unit test for constructor of class Max
def test_Max():
    assert Max(5) == Max(5)



# Generated at 2022-06-12 05:31:18.702898
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False


# Generated at 2022-06-12 05:31:23.131126
# Unit test for constructor of class Sum
def test_Sum():
    """
    test if Sum is working properly with:
    - adding numbers
    - adding empty value
    """
    assert Sum(2).value == 2
    assert Sum(Sum.neutral_element).value == Sum.neutral_element



# Generated at 2022-06-12 05:31:24.585768
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(0) == Sum(Sum(0).neutral_element)


# Generated at 2022-06-12 05:31:33.735570
# Unit test for method concat of class One
def test_One_concat():
    one = One(True)
    one = one.concat(One(False))
    assert one.value == True
    one = one.concat(One(False))
    assert one.value == True
    one = one.concat(One(True))
    assert one.value == True
    one = one.concat(One(0))
    assert one.value == True
    one = one.concat(One(None))
    assert one.value == True
    one = one.concat(One(''))
    assert one.value == True
    one = one.concat(One('false'))
    assert one.value == 'false'
    one = one.concat(One('false'))
    assert one.value == 'false'
    one = one.concat(One(''))

# Generated at 2022-06-12 05:31:35.832938
# Unit test for method __str__ of class One
def test_One___str__():
    one = One(True)
    assert str(one) == 'One[value=True]'


# Generated at 2022-06-12 05:31:39.361378
# Unit test for method __str__ of class Last
def test_Last___str__():

    actual = str(Last("Vinh"))
    expect = "Last[value=Vinh]"

    assert actual == expect, "actual: {} - expect: {}".format(actual, expect)


# Generated at 2022-06-12 05:31:41.186452
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(0).concat(Max(1)) == Max(1)


# Generated at 2022-06-12 05:31:42.794680
# Unit test for constructor of class One
def test_One():
    one = One(True)
    assert isinstance(one, Semigroup)



# Generated at 2022-06-12 05:31:51.733878
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(10)) == 'Last[value=10]'
    assert str(Last([])) == "Last[value=[]]"
    assert str(Last(())) == "Last[value=()]"
    assert str(Last("")) == "Last[value='']"
    assert str(Last("test")) == "Last[value='test']"
    assert str(Last([10, 20, 30])) == "Last[value=[10, 20, 30]]"
    assert str(Last((10, 20, 30))) == "Last[value=(10, 20, 30)]"

# Generated at 2022-06-12 05:31:53.757588
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-12 05:31:56.142609
# Unit test for constructor of class One
def test_One():
    pass



# Generated at 2022-06-12 05:32:01.345123
# Unit test for method concat of class Last
def test_Last_concat():
    result = First('John').concat(First('Peter'))
    assert (
        result == First('John')
    ), 'Expected: result == First(\'John\'), but got result == {}'.format(result)
    print('test_Last_concat is successful!')


# Generated at 2022-06-12 05:32:02.668141
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"


# Generated at 2022-06-12 05:32:08.169629
# Unit test for constructor of class Max
def test_Max():
    max_ = Max(10)
    assert max_.value == 10


# Generated at 2022-06-12 05:32:11.770067
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'
    assert str(All(0)) == 'All[value=False]'


# Generated at 2022-06-12 05:32:15.569291
# Unit test for method concat of class First
def test_First_concat():
    first = First('first')
    last = First('last')

    assert First('first').concat(last) == First('first')

# Generated at 2022-06-12 05:32:17.732200
# Unit test for method __str__ of class One
def test_One___str__():
    one = One(1)
    assert str(one) == 'One[value=1]'


# Generated at 2022-06-12 05:32:20.527285
# Unit test for method concat of class First
def test_First_concat():
    assert First(4).concat(First(5)) == First(4)
    assert First(5).concat(First(4)) == First(5)


# Generated at 2022-06-12 05:32:22.806991
# Unit test for constructor of class Min
def test_Min():
    assert Min(1)==Min(1)


# Generated at 2022-06-12 05:32:25.716482
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert str(Max(1)) == "Max[value=1]"



# Generated at 2022-06-12 05:32:27.391325
# Unit test for constructor of class Max
def test_Max():
    x = Max(15)
    assert x.value == 15


# Generated at 2022-06-12 05:32:29.211969
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-12 05:32:32.619493
# Unit test for constructor of class Map
def test_Map():
    assert Map({1: Sum(1), 2: Sum(2)}).value == {1: Sum(1), 2: Sum(2)}


# Generated at 2022-06-12 05:32:42.544917
# Unit test for method __str__ of class Last
def test_Last___str__():
    # arrange
    last = Last(2)

    # act
    actual = str(last)

    # assert
    assert actual == 'Last[value=2]'



# Generated at 2022-06-12 05:32:45.431572
# Unit test for constructor of class Min
def test_Min():
    assert Min(6).value == 6
    assert Min(1).value == 1
    assert Min("6").value == "6"
    assert Min("1").value == "1"


# Generated at 2022-06-12 05:32:48.818010
# Unit test for method concat of class Min
def test_Min_concat():
    """
    :returns: assert result
    :rtype: void
    """

    assert Min(1).concat(Min(2)).value == 1

# Generated at 2022-06-12 05:32:51.603175
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) != Last(2)
    assert Last(1) != First(1)
    assert Last(1) != sum([1, 2, 3])



# Generated at 2022-06-12 05:32:52.839196
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-12 05:32:55.097543
# Unit test for method concat of class Last
def test_Last_concat():  # pragma: no cover
    assert Last(1).concat(Last(2)).value == 2


# Generated at 2022-06-12 05:32:56.619637
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == "Min[value=1]"



# Generated at 2022-06-12 05:33:00.923934
# Unit test for method __str__ of class Last
def test_Last___str__():
    """
    Test `__str__` method of class Last
    :return: None
    """
    last = Last(1)
    assert str(last) == 'Last[value=1]'



# Generated at 2022-06-12 05:33:03.393868
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).value == 1


# Generated at 2022-06-12 05:33:06.360139
# Unit test for method __str__ of class First
def test_First___str__():
    first = First(10)
    assert str(first) == 'Fist[value=10]'



# Generated at 2022-06-12 05:33:24.017015
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(1)}).value == {'a': Sum(1), 'b': Sum(1)}



# Generated at 2022-06-12 05:33:28.155144
# Unit test for method __str__ of class Map
def test_Map___str__():
    test_map = Map({'a': Sum(1), 'b': Sum(2)})
    assert test_map.__str__() == 'Map[value={\'a\': Sum[value=1], \'b\': Sum[value=2]}]'

# Generated at 2022-06-12 05:33:29.341943
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1


# Generated at 2022-06-12 05:33:30.716834
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'



# Generated at 2022-06-12 05:33:32.917899
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(5)
    b = Min(3)
    c = a.concat(b)

    assert c.value == 3


# Generated at 2022-06-12 05:33:33.718928
# Unit test for constructor of class First
def test_First():
    assert First.neutral().value == True


# Generated at 2022-06-12 05:33:34.542317
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)

# Generated at 2022-06-12 05:33:38.058470
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
