

# Generated at 2022-06-12 05:23:59.400817
# Unit test for method concat of class Map
def test_Map_concat():
    a = Map({'a': Sum(1), 'b': Last(2), 'c': First(3)})
    b = Map({'a': Sum(4), 'b': Last(5), 'c': First(6)})
    assert a.concat(b).value['a'] == Sum(5)
    assert a.concat(b).value['b'] == Last(5)
    assert a.concat(b).value['c'] == First(3)


# Generated at 2022-06-12 05:24:03.217432
# Unit test for method concat of class Map
def test_Map_concat():
    a = Map({2: Sum(2), 3: Sum(3)})
    b = Map({2: Sum(5), 4: Sum(6)})
    expected = Map({2: Sum(7), 3: Sum(3), 4: Sum(6)})
    assert a.concat(b) == expected



# Generated at 2022-06-12 05:24:11.660919
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map({
        'a': Sum(5),
        'b': Sum(10),
        'c': Sum(14),
    })

    map2 = Map({
        'a': Sum(4),
        'b': Sum(11),
        'c': Sum(15),
    })

    map_result = Map({
        'a': Sum(9),
        'b': Sum(21),
        'c': Sum(29),
    })

    assert map_result == map1.concat(map2)

# Generated at 2022-06-12 05:24:15.284291
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(1), 'b': Sum(2)})) == Map({'a': Sum(2), 'b': Sum(4)})


# Generated at 2022-06-12 05:24:19.195043
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({'a': Sum(1), 'b': Sum(2)})
    m2 = Map({'b': Sum(3), 'c': Sum(4)})
    assert m1.concat(m2) == Map({'a': Sum(1), 'b': Sum(5), 'c': Sum(4)})

# Generated at 2022-06-12 05:24:24.056017
# Unit test for method concat of class Map
def test_Map_concat():  # pragma: no cover
    m = Map({1: Sum(1), 2: Sum(2)})
    m2 = Map({1: Sum(3), 2: Sum(4)})
    m3 = m.concat(m2)
    assert m3.value == {1: Sum(4), 2: Sum(6)}



# Generated at 2022-06-12 05:24:30.354430
# Unit test for method concat of class Map
def test_Map_concat():
    # GIVEN
    map1 = Map({'a': Sum(2), 'b': Sum(4), 'c': Sum(6)})
    map2 = Map({'a': Sum(4), 'b': Sum(4), 'c': Sum(7)})

    # WHEN
    map3 = map1.concat(map2)

    # THEN
    assert(map3.value['a'].value == 6)
    assert(map3.value['b'].value == 8)
    assert(map3.value['c'].value == 13)

# Generated at 2022-06-12 05:24:39.076401
# Unit test for method concat of class Map
def test_Map_concat():  # pragma: no cover
    """
    test_Map_concat
    """
    '''
    a = Map(Sum(1), Sum(2))
    b = Map(Sum(2), Sum(4))
    c = Map(Sum(3), Sum(6))
    '''
    a = Map({'ka':Sum(1), 'kb':Sum(2)})
    b = Map({'ka':Sum(2), 'kb':Sum(4)})
    c = Map({'ka':Sum(3), 'kb':Sum(6)})
    assert(a.concat(b).value == c.value) # Test 1
    assert(b.concat(a).value == c.value) # Test 2
    assert(a.concat(a).value == a.value) # Test 3

# Generated at 2022-06-12 05:24:50.309196
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"a": Map({"a": Sum(1)}), "b": Map({"b": Sum(1)})}) ==\
        Map({"a": Sum(1)}).concat(Map({"b": Sum(1)}))
    assert Map({"a": Map({"a": All(True), "b": All(False)}), "b": Map({"a": All(False), "b": All(True)})}) ==\
        Map({"a": All(True)}).concat(Map({"b": All(True)}))

# Generated at 2022-06-12 05:24:55.804938
# Unit test for method concat of class Map
def test_Map_concat():
    """
    test Map concat method
    """
    assert Map({'a': Sum(1), 'b': Sum(1)}).concat(
        Map({'a': Sum(1), 'c': Sum(1)})
    ).value == {'a': Sum(2), 'b': Sum(1), 'c': Sum(1)}

# Generated at 2022-06-12 05:24:59.129780
# Unit test for constructor of class One
def test_One():
    assert One(True).value == One(1).value == True


# Generated at 2022-06-12 05:25:03.124506
# Unit test for method concat of class Sum
def test_Sum_concat():
    s = Sum(1)
    right = Sum(2)
    left = Sum(3)
    assert s.concat(right) == Sum(3)
    assert s.concat(left) == Sum(4)



# Generated at 2022-06-12 05:25:04.605563
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)


# Generated at 2022-06-12 05:25:06.341014
# Unit test for method concat of class Last
def test_Last_concat():
    semigroup = Last(1)
    assert semigroup.concat(Last(2)).value == 2


# Generated at 2022-06-12 05:25:08.766593
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1
    assert Sum(2).value == 2

# Generated at 2022-06-12 05:25:12.618914
# Unit test for method concat of class One
def test_One_concat():
    one = One(0)
    other_one = One('string')
    assert one.concat(other_one) == One('string')
    assert one == One(0)
    assert other_one == One('string')


test_One_concat()



# Generated at 2022-06-12 05:25:16.576139
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(4).concat(Sum(5)).concat(Sum(6)) == Sum(4).concat(Sum(5 + 6))
    assert Sum(4).concat(Sum(5)).concat(Sum(6)) == Sum(4 + 5 + 6)


# Generated at 2022-06-12 05:25:25.229645
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert Last(None) == Last(None)
    assert Last(False) == Last(False)
    assert Last(True) == Last(True)
    assert Last(float('inf')) == Last(float('inf'))
    assert Last(float('nan')) == Last(float('nan'))
    assert Last(float('-inf')) == Last(float('-inf'))
    assert Last(float('-nan')) == Last(float('-nan'))
    assert Last(1 + 1j) == Last(1 + 1j)
    assert Last('F') == Last('F')
    assert Last(b'F') == Last(b'F')
    assert Last(()) == Last(())
    assert Last([]) == Last

# Generated at 2022-06-12 05:25:31.146037
# Unit test for method concat of class One
def test_One_concat():
    """
    :returns: test results for method concat of class One
    :rtype: None
    """
    print("test_One_concat()")
    assert (One(False).concat(One(False)) == One(False))
    assert (One(False).concat(One(True)) == One(True))
    assert (One(True).concat(One(False)) == One(True))
    assert (One(True).concat(One(True)) == One(True))
    print("test_One_concat() is completed.")


# Generated at 2022-06-12 05:25:36.161666
# Unit test for method concat of class One
def test_One_concat():  # pragma: no cover
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-12 05:25:42.059075
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(2).concat(Sum(1)) == Sum(3)


# Generated at 2022-06-12 05:25:44.535156
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-12 05:25:54.825159
# Unit test for constructor of class First
def test_First():
    value = 1
    semigroup = First(value)
    assert semigroup.value == value
    semigroup = First(First(value))
    assert semigroup.value == value
    semigroup = First(Min(value))
    assert semigroup.value == Min(value)
    semigroup = First(Last(value))
    assert semigroup.value == Last(value)
    semigroup = First(All(value))
    assert semigroup.value == All(value)
    semigroup = First(One(value))
    assert semigroup.value == One(value)
    semigroup = First(Sum(value))
    assert semigroup.value == Sum(value)
    semigroup = First(Max(value))
    assert semigroup.value == Max(value)
    semigroup = First(Map({1: Min(value)}))

# Generated at 2022-06-12 05:26:00.125778
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(2).fold(lambda x: x + 1) == 3
    assert Last(1).fold(lambda x: x + 1) == 1
    assert Map({'a': Sum(2)}).fold(lambda x: x['a'].value) == 2


# Generated at 2022-06-12 05:26:01.455322
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(0)) == 'Max[value=0]'



# Generated at 2022-06-12 05:26:02.637610
# Unit test for constructor of class All
def test_All():
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"

# Generated at 2022-06-12 05:26:04.445612
# Unit test for method concat of class First
def test_First_concat():
    a = First(42)
    b = First(666)
    assert a.concat(b) == First(42)


# Generated at 2022-06-12 05:26:07.011662
# Unit test for constructor of class One
def test_One():
    assert One(False) == One(False)
    assert One(True) == One(True)
    assert One(True) != One(False)
    assert One(False) != One(True)



# Generated at 2022-06-12 05:26:08.929862
# Unit test for method __str__ of class First
def test_First___str__():
    result = First(1)
    expected = 'Fist[value=1]'
    assert result.__str__() == expected


# Generated at 2022-06-12 05:26:14.131091
# Unit test for method concat of class Sum
def test_Sum_concat():  # pragma: no cover
    s = Sum(1)
    assert s.fold(lambda x: x + 1) == 2
    s2 = s.concat(Sum(2))
    assert s2.fold(lambda x: x + 1) == 4



# Generated at 2022-06-12 05:26:21.231693
# Unit test for method concat of class Last
def test_Last_concat():
    last = Last({'foo': 1, 'bar': 2, 'baz': 3})
    last1 = last.concat(Last({'baz': 4}))
    assert last1.value == {'baz': 4}



# Generated at 2022-06-12 05:26:23.830585
# Unit test for method concat of class Sum
def test_Sum_concat():
    a = Sum(3)
    b = Sum(2)
    assert a.concat(b) == Sum(5)



# Generated at 2022-06-12 05:26:28.080393
# Unit test for method concat of class First
def test_First_concat():
    first  = First(42)
    second = First(666)
    assert first.concat(second).value == first.value
    # assert first.concat(second).concat(second).value == first.value



# Generated at 2022-06-12 05:26:31.682595
# Unit test for method concat of class Sum
def test_Sum_concat():
    fst = Sum(2)
    snd = Sum(3)
    assert fst.concat(snd) == Sum(5)



# Generated at 2022-06-12 05:26:33.807352
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-12 05:26:37.273367
# Unit test for constructor of class Map
def test_Map():
    a = Map({'a': Sum(1), 'b': Sum(2)})
    b = Map({'a': Sum(3), 'b': Sum(4)})
    assert a.concat(b) == Map({'a': Sum(4), 'b': Sum(6)})

# Generated at 2022-06-12 05:26:39.128540
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(3).concat(Max(7)) == Max(7)


# Generated at 2022-06-12 05:26:42.325505
# Unit test for constructor of class Last
def test_Last():
    try:
        Last(10)
        assert True
    except Exception:
        assert False, "constructor of class Last should not raise exception"


# Generated at 2022-06-12 05:26:45.111157
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({First(1): Sum(2)})) == 'Map[value={Fist[value=1]: Sum[value=2]}]'



# Generated at 2022-06-12 05:26:46.612930
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'

# Generated at 2022-06-12 05:26:52.112453
# Unit test for method __str__ of class One
def test_One___str__():
    aSubject = One(False)
    aResult = 'One[value=False]'
    assert aSubject.__str__() == aResult


# Generated at 2022-06-12 05:26:53.809445
# Unit test for constructor of class Map
def test_Map():
    expect = Map({})
    actual = Map({})
    assert actual == expect


# Generated at 2022-06-12 05:26:56.805407
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    sum1 = Sum(1)
    assert str(sum1) == 'Sum[value=1]'



# Generated at 2022-06-12 05:27:02.014380
# Unit test for method concat of class Max
def test_Max_concat():
    a = Max(1)
    b = Max(2)
    c = a.concat(b)
    assert c.value == 2

    a = Max(2)
    b = Max(1)
    c = a.concat(b)
    assert c.value == 2


# Generated at 2022-06-12 05:27:03.935480
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)).value == 3


# Generated at 2022-06-12 05:27:09.408696
# Unit test for method concat of class Map
def test_Map_concat():
    a = Map({ 1: First(1), 2: First(2), 3: First(3), })
    b = Map({ 1: Last(1), 2: Last(2) })
    result = a.concat(b)
    expected = Map({ 1: First(1), 2: First(2), 3: First(3), })
    assert result == expected

# Generated at 2022-06-12 05:27:12.021304
# Unit test for method concat of class One
def test_One_concat():
    one = One(1)
    expected = One(True)
    actual = one.concat(One(True))
    assert actual == expected


# Generated at 2022-06-12 05:27:16.873415
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True
    assert One(False).value == False
    assert One(None).value == False
    assert One(0).value == False
    assert One("").value == False
    assert One("0123").value == True
    assert One("0").value == False
    assert One("1").value == True
    assert One("123").value == True


# Generated at 2022-06-12 05:27:23.213830
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    assert (All(True).concat(All(True))) == All(True)
    assert (All(True).concat(All(False))) == All(False)
    assert (All(False).concat(All(True))) == All(False)
    assert (All(False).concat(All(False))) == All(False)


# Generated at 2022-06-12 05:27:25.051017
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)



# Generated at 2022-06-12 05:27:29.986605
# Unit test for constructor of class One
def test_One():
    assert One(1).value == 1
    assert One(-10).value == -10



# Generated at 2022-06-12 05:27:31.407240
# Unit test for method concat of class Min
def test_Min_concat(): 
    assert Min(5).concat(Min(7)) == Min(5)

# Generated at 2022-06-12 05:27:35.742424
# Unit test for method concat of class All
def test_All_concat():
    All(True).concat(All(True)) == All(True)
    All(True).concat(All(False)) == All(False)
    All(False).concat(All(True)) == All(False)
    All(False).concat(All(False)) == All(False)


# Generated at 2022-06-12 05:27:37.596908
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert 'Sum[value=1]' == str(Sum(1))


# Generated at 2022-06-12 05:27:47.675224
# Unit test for constructor of class Map
def test_Map():
    map1 = Map({'g': Sum(3), 'h': One(1), 'j': First(1), 'k': Last(1)})
    map2 = Map({'g': Sum(4), 'h': One(1), 'j': First(2), 'k': Last(10)})
    map3 = Map({'this': Sum(300), 'is': Sum(100), 'a': Sum(40), 'dict': Sum(20)})
    assert str(map1) == "Map[value={'g': Sum[value=3], 'h': All[value=1], 'j': Fist[value=1], 'k': Last[value=1]}]"

# Generated at 2022-06-12 05:27:55.027774
# Unit test for method concat of class All
def test_All_concat():
    a1 = All(True)
    a2 = All(True)
    assert a1.concat(a2) == All(True)
    a2 = All(False)
    assert a1.concat(a2) == All(False)
    a1 = All(False)
    a2 = All(True)
    assert a1.concat(a2) == All(False)
    a2 = All(False)
    assert a1.concat(a2) == All(False)


# Generated at 2022-06-12 05:27:56.646926
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum = Sum(1)
    assert str(sum) == 'Sum[value=1]'


# Generated at 2022-06-12 05:28:01.381985
# Unit test for method __str__ of class Map
def test_Map___str__():
    map1 = Map({})
    assert str(map1) == 'Map[value={}]'

    map2 = Map({'a': Sum(1), 'b': All(True), 'c': First(5)})
    assert str(map2) == 'Map[value={\'a\': Sum[value=1], \'b\': All[value=True], \'c\': Fist[value=5]}]'



# Generated at 2022-06-12 05:28:04.085065
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    Test method __eq__ of class Semigroup.
    """
    assert Semigroup(1) == Semigroup(1)



# Generated at 2022-06-12 05:28:05.486975
# Unit test for constructor of class Last
def test_Last():
    assert Last(10) == Last(10)

# Generated at 2022-06-12 05:28:15.532355
# Unit test for method __str__ of class One
def test_One___str__():
    """
    Unit test for method __str__ of class One
    """
    one = One(True)
    assert repr(one) == 'One[value=True]'



# Generated at 2022-06-12 05:28:17.099265
# Unit test for method __str__ of class First
def test_First___str__(): # pragma: no cover
    assert str(First("xxx")) == "Fist[value=xxx]"

# Generated at 2022-06-12 05:28:20.358308
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-12 05:28:21.396449
# Unit test for constructor of class Max
def test_Max():
    Max(3)


# Generated at 2022-06-12 05:28:23.797381
# Unit test for constructor of class Min
def test_Min():
    assert(Min(10) == Min(10))



# Generated at 2022-06-12 05:28:28.171512
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-12 05:28:34.652715
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-12 05:28:36.815406
# Unit test for constructor of class One
def test_One(): # pragma: no cover
    one = One(True)
    assert one.value == True


# Generated at 2022-06-12 05:28:40.209429
# Unit test for method __str__ of class Map
def test_Map___str__():  # pragma: no cover
    """
    Used for manual testing with coverage.
    """

    import funcy

    result = funcy.Map({"test": 123, 456: "test"}).__str__()
    print(result)



# Generated at 2022-06-12 05:28:42.089801
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    

# Generated at 2022-06-12 05:28:49.880591
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-12 05:28:51.519051
# Unit test for constructor of class Max
def test_Max():
    assert Max(10) == Max(10)



# Generated at 2022-06-12 05:28:53.429024
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)


# Generated at 2022-06-12 05:28:54.855318
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1).value == 1



# Generated at 2022-06-12 05:29:02.386499
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(None)) == "All[value=False]"
    assert str(All(bool(None))) == "All[value=False]"
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"
    assert str(All(1)) == "All[value=True]"
    assert str(All(0)) == "All[value=False]"
    assert str(All(1.0)) == "All[value=True]"
    assert str(All(0.0)) == "All[value=False]"
    assert str(All([])) == "All[value=False]"
    assert str(All(set())) == "All[value=False]"
    assert str(All(dict())) == "All[value=False]"

# Generated at 2022-06-12 05:29:05.072349
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(10) == Sum(10)
    assert str(Sum(10)) == 'Sum[value=10]'



# Generated at 2022-06-12 05:29:06.865176
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)


# Generated at 2022-06-12 05:29:10.898717
# Unit test for method concat of class One
def test_One_concat():
    semigroup1 = One(False)
    semigroup2 = One(True)

    expected = True

    actual = semigroup1.concat(semigroup2)

    assert actual.value == expected



# Generated at 2022-06-12 05:29:12.554018
# Unit test for constructor of class Sum
def test_Sum():
    sum = Sum(3)
    assert sum.value == 3


# Generated at 2022-06-12 05:29:14.039150
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)


# Generated at 2022-06-12 05:29:21.422749
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"



# Generated at 2022-06-12 05:29:23.501166
# Unit test for constructor of class One
def test_One():
    one = One(1)
    assert isinstance(one, One)
    assert one.value == 1

# Generated at 2022-06-12 05:29:25.148294
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'



# Generated at 2022-06-12 05:29:30.774379
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'key1': First(1), 'key2': Last(2)})) == 'Map[value={\'key1\': Fist[value=1], \'key2\': Last[value=2]}]'
    assert str(Map({'key1': First(1), 'key2': Last(2), 'key3': First(3), 'key4': Last(4)})) == \
        'Map[value={\'key1\': Fist[value=1], \'key2\': Last[value=2], \'key3\': Fist[value=3], \'key4\': Last[value=4]}]'



# Generated at 2022-06-12 05:29:35.399679
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(4)) == Max(4)
    assert Max(4).concat(Max(1)) == Max(4)
    assert Max(1).concat(Max(1)) == Max(1)
    assert Max(5).concat(Max(5)) == Max(5)


# Generated at 2022-06-12 05:29:37.679468
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    expected_result = 'Sum[value=0]'
    actual_result = str(Sum(0))
    assert expected_result == actual_result



# Generated at 2022-06-12 05:29:40.369258
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)

# Generated at 2022-06-12 05:29:42.264096
# Unit test for method __str__ of class Last
def test_Last___str__():
    first = Last(1)
    assert str(first) == 'Last[value=1]'



# Generated at 2022-06-12 05:29:44.046318
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).concat(Min(3)) == Min(1)


# Generated at 2022-06-12 05:29:51.567636
# Unit test for method concat of class Min
def test_Min_concat():
    # Default, neutral_element
    assert Min(33).concat(Min(66)).value == 33
    # Default, neutral_element
    assert Min(-33).concat(Min(-66)).value == -66
    # None, neutral_element
    assert Min(None).concat(Min(66)).value == 66
    # None, neutral_element
    assert Min(None).concat(Min(None)).value is None
    # Not default, neutral_element
    assert Min(Min.neutral_element).concat(Min(66)).value == 66


# Generated at 2022-06-12 05:29:59.467474
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    assert str(Last(3)) == 'Last[value=3]'


# Generated at 2022-06-12 05:30:02.905297
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(True).__str__() == 'One[value=True]'
    assert One(False).__str__() == 'One[value=False]'



# Generated at 2022-06-12 05:30:06.030297
# Unit test for constructor of class Min
def test_Min():  # pragma: no cover
    import pytest
    from werkzeug.exceptions import BadRequest
    with pytest.raises(BadRequest):
        Min(None)


# Generated at 2022-06-12 05:30:07.206221
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(4)) == 'Min[value=4]'


# Generated at 2022-06-12 05:30:10.582009
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)
    assert Max(2).concat(Max(1)) == Max(2)


# Generated at 2022-06-12 05:30:15.036960
# Unit test for constructor of class One
def test_One():
    # Given
    value = False
    # When
    one = One(value)
    # Then
    assert one.value == value
    assert one.concat(One(value)) == One(value)
    assert one.concat(One(True)) == One(True)
    assert one.concat(True) == One(True)


# Generated at 2022-06-12 05:30:16.942960
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(2)) == 'Sum[value=2]'

# Unit test of method fold of class Sum

# Generated at 2022-06-12 05:30:20.968903
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1).value == 1
    assert Sum(1).concat(Sum(2)).fold(lambda x: x) == 3



# Generated at 2022-06-12 05:30:25.883408
# Unit test for method __str__ of class All
def test_All___str__():
    """
    This is a unit test for method __str__ of class All
    """
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'
    assert str(All(1)) == 'All[value=True]'
    assert str(All(0)) == 'All[value=False]'


# Generated at 2022-06-12 05:30:26.601893
# Unit test for constructor of class Min
def test_Min():
    semigroup = Min(45)
    assert semigroup


# Generated at 2022-06-12 05:30:40.875845
# Unit test for constructor of class Map
def test_Map():
    m = Map({
        "abc": First(1234),
        "def": Last(None),
        "ghi": Sum(1),
        "jkl": Min(1),
        "mno": Max(1),
        "pqr": One(False),
    })

    assert m.value == {
        "abc": First(1234),
        "def": Last(None),
        "ghi": Sum(1),
        "jkl": Min(1),
        "mno": Max(1),
        "pqr": One(False),
    }

# Generated at 2022-06-12 05:30:44.818132
# Unit test for method concat of class Min
def test_Min_concat():
    min_instance_1 = Min(7)
    min_instance_2 = Min(5)
    assert min_instance_1.concat(min_instance_2) == Min(5)


# Generated at 2022-06-12 05:30:46.869887
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)


# Generated at 2022-06-12 05:30:48.770519
# Unit test for method concat of class All
def test_All_concat():
    first = All(True)
    second = All(False)
    assert first.concat(second) == All(False)



# Generated at 2022-06-12 05:30:53.088281
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)).value is True
    assert One(False).concat(One(False)).value is False
    assert One(True).concat(One(True)).value is True


# Generated at 2022-06-12 05:31:03.575016
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert All(True) == All(True)
    assert All(True) != All(False)
    assert One(False) == One(False)
    assert One(False) != One(True)
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert Min(3) == Min(3)
    assert Min(3) != Min(4)
    assert Max(3) == Max(3)
    assert Max(3) != Max(4)

# Generated at 2022-06-12 05:31:05.466160
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1)
    assert Semigroup('hello')
    assert Semigroup(object)



# Generated at 2022-06-12 05:31:06.986494
# Unit test for constructor of class Last
def test_Last():
    assert str(Semigroup(1)) == 'Semigroup[value=1]'


# Generated at 2022-06-12 05:31:09.325857
# Unit test for method __str__ of class First
def test_First___str__():
    first = First(1)
    assert first.__str__() == 'Fist[value=1]' # pragma: no cover
    assert first.__str__() == 'Fist[value=%s]' % first.value


# Generated at 2022-06-12 05:31:12.480702
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    value = 'value'
    semigroup = Semigroup(value)

    assert semigroup.value == value
    assert semigroup == Semigroup('value')



# Generated at 2022-06-12 05:31:24.816215
# Unit test for constructor of class All
def test_All():
    assert All(True).value is True
    assert All(False).value is False
    assert All(12).value is True
    assert All('').value is False
    assert All([1, 2, 3]).value is True
    assert All({2, 3, 4}).value is True
    assert All([]).value is False
    assert All({}).value is False



# Generated at 2022-06-12 05:31:26.571665
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)



# Generated at 2022-06-12 05:31:29.478423
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(1)
    b = Min(2)
    assert a.concat(b) == Min(1)
    assert b.concat(a) == Min(1)



# Generated at 2022-06-12 05:31:33.056559
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_1 = Sum(1)
    sum_2 = Sum(2)
    assert sum_1.concat(sum_2) == Sum(3)


# Generated at 2022-06-12 05:31:35.156468
# Unit test for method __str__ of class Min
def test_Min___str__():  # pragma: no cover
    assert str(Min(1)) == 'Min[value=1]'

# Generated at 2022-06-12 05:31:43.499801
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map({"a": Sum(1), "b": Sum(2), "c": Sum(3)})
    map2 = Map({"a": Sum(4), "b": Sum(5), "c": Sum(6)})
    assert map1.concat(map2) == Map({"a": Sum(5), "b": Sum(7), "c": Sum(9)})
    assert map2.concat(map1) == Map({"a": Sum(5), "b": Sum(7), "c": Sum(9)})


if __name__ == "__main__":
    test_Map_concat()

# Generated at 2022-06-12 05:31:45.873516
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum = Sum(1)
    assert str(sum) == 'Sum[value=1]'


# Generated at 2022-06-12 05:31:49.242237
# Unit test for method __str__ of class One
def test_One___str__(): # pragma: no cover
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'
    assert str(One(10)) == 'One[value=10]'


# Generated at 2022-06-12 05:31:52.360676
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(2).concat(Last(5)) == Last(5)


# Generated at 2022-06-12 05:31:53.955126
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    m = Sum(100)
    assert m.fold(lambda x: x ** 2) == 10000

# Generated at 2022-06-12 05:32:02.962235
# Unit test for method concat of class First
def test_First_concat():
    a = First(3)
    b = First(6)
    assert a.concat(b) == First(3)


# Generated at 2022-06-12 05:32:05.267313
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(4)) == "Last[value=4]"


# Generated at 2022-06-12 05:32:08.042034
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(4).concat(Sum(5)) == Sum(9)
    print("test_Sum_concat: OK")


# Generated at 2022-06-12 05:32:10.325012
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last('boo')) == "Last[value=boo]"


# Generated at 2022-06-12 05:32:17.634435
# Unit test for method concat of class All
def test_All_concat():
    """
    :params: void
    :returns: void
    """

    all_result1 = All(True).concat(All(True))
    assert all_result1.value == True

    all_result2 = All(True).concat(All(False))
    assert all_result2.value == False

    all_result3 = All(False).concat(All(False))
    assert all_result3.value == False


# Generated at 2022-06-12 05:32:19.719248
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(4).concat(Sum(6)) == Sum(10)



# Generated at 2022-06-12 05:32:20.483183
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == "Min[value=1]"

# Generated at 2022-06-12 05:32:25.026758
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(5).concat(Min(3)) == Min(3)
    assert Min(5).concat(Min(7)) == Min(5)

# Generated at 2022-06-12 05:32:29.850845
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_int = Sum(1).concat(Sum(2))
    assert isinstance(sum_int, Sum)
    assert sum_int.value == 3
    sum_float = Sum(1.5).concat(Sum(2.5))
    assert isinstance(sum_float, Sum)
    assert sum_float.value == 4


# Generated at 2022-06-12 05:32:32.016949
# Unit test for constructor of class Max
def test_Max():
    assert Max(5).value == 5


# Generated at 2022-06-12 05:32:42.192206
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    Unit test for method concat of class Sum
    """
    assert Sum(3).concat(Sum(5)) == Sum(8)
    assert Sum(10).concat(Sum(-10)) == Sum()
    assert Sum(-2).concat(Sum(-5)) == Sum(-7)



# Generated at 2022-06-12 05:32:43.556206
# Unit test for constructor of class Last
def test_Last():
    last = Last(2)
    assert last.value == 2


# Generated at 2022-06-12 05:32:49.964893
# Unit test for method concat of class Map
def test_Map_concat():
    m = Map({"foo": Sum(5), "bar": Sum(20)})
    n = Map({"foo": Sum(10), "bar": Sum(22)})
    mn = m.concat(n)
    assert mn.value == {"foo": Sum(15), "bar": Sum(42)}
    print("test_Map_concat test - OK")


# Generated at 2022-06-12 05:32:51.310528
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'

# Generated at 2022-06-12 05:32:52.916017
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(5).concat(Last(15)) == Last(15)



# Generated at 2022-06-12 05:32:55.437460
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(100).concat(Min(200)) == Min(100)



# Generated at 2022-06-12 05:32:56.479572
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)

# Generated at 2022-06-12 05:32:58.610287
# Unit test for constructor of class Last
def test_Last():  # pragma: no cover
    assert Last(10) == Last(10)


# Generated at 2022-06-12 05:33:01.082542
# Unit test for constructor of class First
def test_First():
    first = First(2)
    assert first.value == 2


# Generated at 2022-06-12 05:33:03.250672
# Unit test for method __str__ of class One
def test_One___str__():
    actual = str(One(False))
    expected = 'One[value=False]'
    assert actual == expected


# Generated at 2022-06-12 05:33:12.174931
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1


# Generated at 2022-06-12 05:33:14.468078
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(5).concat(Last(2)) == Last(2)


# Generated at 2022-06-12 05:33:16.490659
# Unit test for method concat of class Sum
def test_Sum_concat():
    _ = Sum(3).concat(Sum(5)) == Sum(8)
    _ = Sum(3).concat(Sum(5)).value == 8
    _ = Sum(3).concat(Sum(5)).__class__ == Sum


# Generated at 2022-06-12 05:33:18.457985
# Unit test for constructor of class One
def test_One():
    actual = One(1)
    expected = One(1)
    assert actual == expected


# Generated at 2022-06-12 05:33:19.194104
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    print(Sum(1))


# Generated at 2022-06-12 05:33:29.032433
# Unit test for method concat of class All
def test_All_concat():
    all1 = All(True)
    all2 = All(True)
    assert all1.concat(all2) == All(True)

    all1 = All(True)
    all2 = All(False)
    assert all1.concat(all2) == All(False)

    all1 = All(False)
    all2 = All(True)
    assert all1.concat(all2) == All(False)

    all1 = All(False)
    all2 = All(False)
    assert all1.concat(all2) == All(False)



# Generated at 2022-06-12 05:33:29.576721
# Unit test for constructor of class Semigroup
def test_Semigroup():
    pass

# Generated at 2022-06-12 05:33:32.572387
# Unit test for method concat of class Max
def test_Max_concat():
    max_first = Max(3)
    max_second = Max(5)

    assert max_first.concat(max_second).value == 5
    assert max_second.concat(max_first).value == 5



# Generated at 2022-06-12 05:33:34.314548
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'

# Generated at 2022-06-12 05:33:39.486856
# Unit test for constructor of class First
def test_First():
    sg = First('hola')
    assert isinstance(sg, First)

