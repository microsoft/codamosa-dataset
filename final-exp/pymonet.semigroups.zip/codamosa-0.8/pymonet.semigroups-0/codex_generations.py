

# Generated at 2022-06-12 05:23:53.036212
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)


# Generated at 2022-06-12 05:23:55.043893
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(2).concat(Max(3)) == Max(3)


# Generated at 2022-06-12 05:23:59.071415
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-12 05:24:01.123289
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(3).concat(Max(5)).value == 5
    assert Max(3).concat(Max(3)).value == 3


# Generated at 2022-06-12 05:24:03.986380
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(3).concat(Min(5)) == Min(3)
    assert Min(5).concat(Min(3)) == Min(3)


# Generated at 2022-06-12 05:24:07.165905
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(5)).value == 5
    assert Max(5).concat(Max(1)).value == 5

# Generated at 2022-06-12 05:24:10.909530
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(0).concat(Min(1)) == Min(0)
    assert Min(1).concat(Min(0)) == Min(0)
    assert Min(0).concat(Min(0)) == Min(0)


# Generated at 2022-06-12 05:24:13.833739
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(7).concat(Min(8)) == Min(7)
    assert Min(8).concat(Min(7)) == Min(7)


# Generated at 2022-06-12 05:24:17.170564
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).value == 1

# Generated at 2022-06-12 05:24:19.861713
# Unit test for method concat of class Max
def test_Max_concat():
    max = Max(10)
    assert max.concat(Max(20)).value == 20
    assert max.concat(Max(5)).value == 10


# Generated at 2022-06-12 05:24:25.539707
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(5)) == "Min[value=5]"

# Type test for method __str__ of class Min

# Generated at 2022-06-12 05:24:33.329645
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(True)).concat(All(False)) == All(False)
    assert All(True).concat(All(True)).concat(All(True)) == All(True)
    assert All(True).concat(All(True)).concat(All(True)).concat(All(False)) == All(False)


# Generated at 2022-06-12 05:24:35.273308
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-12 05:24:38.238940
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(2)) == 'Max[value=2]', 'ERROR: test_Max___str__()'


# Generated at 2022-06-12 05:24:41.033185
# Unit test for constructor of class Last
def test_Last():
    a = Last(1)
    b = Last(2)
    assert a.value == 1
    assert b.value == 2

test_Last()


# Generated at 2022-06-12 05:24:44.596373
# Unit test for constructor of class Min
def test_Min():
    assert Min(12).value == 12
    assert Min(14).value == 14
    assert Min(-2).value == -2
    assert Min(-1).value == -1


# Generated at 2022-06-12 05:24:47.465587
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(10)) == "Sum[value=10]", "str(Sum(10) == 'Sum[value=10]' failed"



# Generated at 2022-06-12 05:24:53.449878
# Unit test for method concat of class Map
def test_Map_concat():
    map_instance1 = Map({'a': Sum(5), 'b': Sum(3)})
    map_instance2 = Map({'a': Sum(8), 'b': Sum(2)})
    assert str(map_instance1.concat(map_instance2)) == "Map[value={'a': Sum[value=13], 'b': Sum[value=5]}]"



# Generated at 2022-06-12 05:24:55.710043
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)


# Generated at 2022-06-12 05:24:58.080981
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)

# Generated at 2022-06-12 05:25:06.475531
# Unit test for method __str__ of class First
def test_First___str__():
    model = First(1)
    assert str(model) == 'Fist[value=1]'
    model = First('sebastian')
    assert str(model) == 'Fist[value=sebastian]'
    model = First('sebastian')
    assert str(model) == 'Fist[value=sebastian]'
    model = First(None)
    assert str(model) == 'Fist[value=None]'


# Generated at 2022-06-12 05:25:10.295119
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-12 05:25:12.468145
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(10) == Semigroup(10)
    assert not Semigroup(10) == Semigroup(20)



# Generated at 2022-06-12 05:25:13.877358
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert 'Sum[value=1]' == str(Sum(1))



# Generated at 2022-06-12 05:25:19.079962
# Unit test for constructor of class Map
def test_Map():
    """Test for constructor of class Map"""
    # Create instances of Empty and Map
    empty = Empty()
    map_ = Map({1: Sum(3), 2: Sum(10)})
    # Assert that both are equal
    assert (empty == map_) == False



# Generated at 2022-06-12 05:25:20.168539
# Unit test for constructor of class First
def test_First():
    result = First(10)
    assert result.value == 10


# Generated at 2022-06-12 05:25:21.891066
# Unit test for method __str__ of class Last
def test_Last___str__():
    last = Last(1)
    assert str(last) == "Last[value=1]"



# Generated at 2022-06-12 05:25:23.724595
# Unit test for constructor of class Min
def test_Min():
    a = Min(10)
    b = Min(20)
    c = Min(15)
    print(a, b, c)



# Generated at 2022-06-12 05:25:24.579190
# Unit test for constructor of class Max
def test_Max():
    assert Max(2).value == 2


# Generated at 2022-06-12 05:25:25.744620
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1


# Test for concat method of class Last

# Generated at 2022-06-12 05:25:28.277106
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)).value == 1


# Generated at 2022-06-12 05:25:32.271621
# Unit test for method concat of class Max
def test_Max_concat():
    assert str(Max(1).concat(Max(2))) == 'Max[value=2]'
    assert str(Max(1).concat(Max(1))) == 'Max[value=1]'
    assert str(Max(2).concat(Max(1))) == 'Max[value=2]'



# Generated at 2022-06-12 05:25:36.411954
# Unit test for method concat of class All
def test_All_concat():
    s1 = All(True)
    s2 = All(True)
    s3 = s1.concat(s2)
    s4 = All(True).concat(All(False))

    assert(s3 == All(True))
    assert(s4 == All(False))


# Generated at 2022-06-12 05:25:37.627774
# Unit test for constructor of class Max
def test_Max():
    a = Max(5)
    assert a.value == 5
    assert a.fold(lambda x: x) == 5


# Generated at 2022-06-12 05:25:38.730546
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)


# Generated at 2022-06-12 05:25:40.971856
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-12 05:25:42.404957
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == "Min[value=1]"


# Generated at 2022-06-12 05:25:43.476192
# Unit test for constructor of class Sum
def test_Sum():
    test = Sum(1)
    ret = test.value
    expected = 1
    assert ret == expected

# Generated at 2022-06-12 05:25:45.304481
# Unit test for constructor of class First
def test_First():
    first = First(1)
    assert first.value == 1



# Generated at 2022-06-12 05:25:48.519394
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)


# Generated at 2022-06-12 05:25:52.426468
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(4)) == Min(2)
    assert Min(4).concat(Min(2)) == Min(2)


# Generated at 2022-06-12 05:25:54.591306
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(30) == Sum(30)
    assert Sum(30) != Sum(20)
    assert Sum(30).value == 30


# Generated at 2022-06-12 05:25:57.383578
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(5)) == 'One[value=5]'

# Generated at 2022-06-12 05:26:05.773518
# Unit test for method concat of class One
def test_One_concat():
    assert One(0).concat(One(1)) == One(1)
    assert One(0).concat(One(None)) == One(None)
    assert One(0).concat(One(0)) == One(0)
    assert One(None).concat(One(1)) == One(1)
    assert One(None).concat(One(None)) == One(None)
    assert One('0').concat(One(1)) == One('0')
    assert One('0').concat(One('1')) == One('1')
    assert One('0').concat(One('0')) == One('0')
    assert One(None).concat(One('')) == One('')

# Generated at 2022-06-12 05:26:07.053843
# Unit test for constructor of class First
def test_First():
    assert type(First(1)) is First


# Generated at 2022-06-12 05:26:08.292472
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(10)) == 'Max[value=10]'


# Generated at 2022-06-12 05:26:11.921536
# Unit test for constructor of class Min
def test_Min():
    a = Min(5)
    b = Min(10)
    c = a.concat(b)
    assert c.value == 5


# Generated at 2022-06-12 05:26:15.675364
# Unit test for method concat of class Max
def test_Max_concat():  # pragma: no cover
    result = Max(2).concat(Max(4))
    assert result == Max(4)
    result = Max(2).concat(Max(2))
    assert result == Max(2)


# Generated at 2022-06-12 05:26:17.567509
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(8)) == Max(8)
    assert Max(8).concat(Max(5)) == Max(8)



# Generated at 2022-06-12 05:26:20.858860
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'
    assert str(Sum(2)) == 'Sum[value=2]'



# Generated at 2022-06-12 05:26:28.658080
# Unit test for method __str__ of class Map
def test_Map___str__():
    # arrange
    value = {'a':1, 'b':2}

    # action
    v = Map(value).__str__()

    # assert
    assert v == "Map[value={'a': 1, 'b': 2}]"


# Generated at 2022-06-12 05:26:31.683262
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(1)) == 'Sum[value=1]'


# Unit tests for method concat of class Sum

# Generated at 2022-06-12 05:26:34.649721
# Unit test for method __str__ of class One
def test_One___str__():
    """
    Unit test for method __str__ of class One
    """
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-12 05:26:35.665672
# Unit test for constructor of class Map
def test_Map():
    Map({
        'x': Sum(2),
        'y': Sum(3)
    })


# Generated at 2022-06-12 05:26:38.294593
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(5)) == 'Max[value=5]'
    assert str(Max(10)) == 'Max[value=10]'
    assert str(Max(20)) == 'Max[value=20]'


# Generated at 2022-06-12 05:26:40.603384
# Unit test for constructor of class One
def test_One():
    assert One == One(1).__class__
    assert One == One(0).__class__
    assert One == One(True).__class__
    assert One == One(1).__class__
    assert One == One(None).__class__
    assert One == One([]).__class__



# Generated at 2022-06-12 05:26:45.656490
# Unit test for constructor of class All
def test_All():
    a = All(True)
    b = All(False)
    assert (a.value == True)
    assert (b.value == False)
    assert (a.concat(a).value == True)
    assert (a.concat(b).value == False)
    assert (b.concat(b).value == False)


# Generated at 2022-06-12 05:26:51.905223
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert First(['a', 'b', 'c']).fold(lambda x: x[0]) == 'a' \
        and Last(['a', 'b', 'c']).fold(lambda x: x[-1]) == 'c' \
        and Max([4, 2, 3]).fold(lambda x: x) == 4 \
        and Min([4, 2, 3]).fold(lambda x: x) == 2



# Generated at 2022-06-12 05:26:53.598290
# Unit test for method concat of class One
def test_One_concat():
    assert One(False).concat(One(True)) == One(True)



# Generated at 2022-06-12 05:26:54.892798
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == "Max[value=1]"


# Generated at 2022-06-12 05:27:00.448864
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)


# Generated at 2022-06-12 05:27:02.617148
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():  # pragma: no cover
    assert Semigroup(0) == Semigroup(0)


# Generated at 2022-06-12 05:27:05.547022
# Unit test for method __str__ of class First
def test_First___str__():
    one = First(1)
    two = First(2)
    expected = 'Fist[value=1]'
    actual = str(one)
    assert actual == expected



# Generated at 2022-06-12 05:27:08.431679
# Unit test for constructor of class Max
def test_Max():
    m = Max(2)
    assert Max(2) == m
    assert Max(2).value == 2


# Generated at 2022-06-12 05:27:11.705038
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    value = Sum(123)
    # method __str__ should return string Sum[value=<value>]
    assert value.__str__() == 'Sum[value=123]'
    # method __str__ should return string Sum[value=<value>]
    assert value.__repr__() == 'Sum[value=123]'

# Generated at 2022-06-12 05:27:14.679180
# Unit test for constructor of class One
def test_One():
    # Initializing class
    value = One('one')
    assert type(value) is One
    assert value is not One
    assert value.concat is One.concat


# Generated at 2022-06-12 05:27:15.923421
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert str(Max(2)) == 'Max[value=2]'


# Generated at 2022-06-12 05:27:20.755199
# Unit test for method concat of class First
def test_First_concat():
    assert First('foo').concat(First('bar')) == First('foo'), 'foo concat bar should be foo'
    assert First(1).concat(First(2)) == First(1), '1 concat 2 should be 1'



# Generated at 2022-06-12 05:27:22.893026
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert 'Max[value=10]' == str(Max(10))



# Generated at 2022-06-12 05:27:24.450901
# Unit test for constructor of class All
def test_All():
    instance = All(True)
    assert instance.value is True



# Generated at 2022-06-12 05:27:31.105055
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"a": Sum(4), "b": Sum(1)}).concat(
        Map({"b": Sum(3), "a": Sum(2)})
    ).value == {"a": Sum(6), "b": Sum(4)}

# Generated at 2022-06-12 05:27:33.346938
# Unit test for constructor of class First
def test_First():
    assert First(5) == First(5)
    assert First(5) != First(4)



# Generated at 2022-06-12 05:27:34.668010
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-12 05:27:36.273110
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(True)) == 'Fist[value=True]'



# Generated at 2022-06-12 05:27:38.009333
# Unit test for constructor of class One
def test_One():
    one = One(1)
    assert one.value == 1



# Generated at 2022-06-12 05:27:39.540607
# Unit test for constructor of class One
def test_One():
    one = One(True)
    assert one.value


# Generated at 2022-06-12 05:27:46.561988
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    
    """
    sum = Sum(10)
    assert sum.value == 10
    assert sum.neutral_element == 0

    one = One(1)
    assert one.value == 1
    assert one.neutral_element == False

    all = All(True)
    assert all.value == True
    assert all.neutral_element == True

    found = First(False)
    assert found.value == False

    last = Last(None)
    assert last.value == None


# Generated at 2022-06-12 05:27:50.021083
# Unit test for constructor of class Map
def test_Map():
    assert str(Map({'a': Sum(3), 'b': Sum(2)})) == "Map[value={'a': Sum[value=3], 'b': Sum[value=2]}]"


# Generated at 2022-06-12 05:27:51.978805
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == "Min[value=1]"



# Generated at 2022-06-12 05:27:53.475221
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(5)) == 'Sum[value=5]'



# Generated at 2022-06-12 05:27:58.927055
# Unit test for constructor of class Map
def test_Map():
    semigroup = Map({'a': Sum(1), 'b': Sum(2)})
    assert semigroup.value == {'a': Sum(1), 'b': Sum(2)}

# Generated at 2022-06-12 05:28:00.914044
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    sum = Sum(1).fold(lambda x: x + 1)
    assert sum == 2



# Generated at 2022-06-12 05:28:02.443980
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-12 05:28:04.625295
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    assert One(True).__str__() == 'One[value=True]'



# Generated at 2022-06-12 05:28:06.593286
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(3)) == str(Min(3))


# Generated at 2022-06-12 05:28:08.165845
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-12 05:28:10.607698
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)
    assert One(None) == One(None)
    assert One(1) != One(2)


# Generated at 2022-06-12 05:28:15.347189
# Unit test for constructor of class One
def test_One():
    """
    A function that tests the class One constructor.
    """
    assert One(True)

    assert One(False)

    assert One(1)

    assert One(0)

    assert One(None)



# Generated at 2022-06-12 05:28:20.330397
# Unit test for method concat of class Map
def test_Map_concat():
    map_1 = Map({
        '1': Sum(1),
        '2': Sum(2)
    })
    map_2 = Map({
        '2': Sum(2),
        '3': Sum(3)
    })

    new_map = map_1.concat(map_2)

    assert new_map.value['1'] == Sum(1)
    assert new_map.value['2'] == Sum(4)
    assert new_map.value['3'] == Sum(3)

# Generated at 2022-06-12 05:28:22.241626
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(False)) == 'All[value=False]'
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-12 05:28:26.328026
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(5) == Sum(5)



# Generated at 2022-06-12 05:28:30.036462
# Unit test for method __str__ of class Min
def test_Min___str__():
    """
    test for method __str__
    """
    value = Min(4)
    assert str(value) == 'Min[value=4]'


# Generated at 2022-06-12 05:28:32.879490
# Unit test for method __str__ of class All
def test_All___str__():
    assert(str(All(True)) == 'All[value=True]')
    assert(str(All(False)) == 'All[value=False]')


# Generated at 2022-06-12 05:28:34.600995
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(2)) == 'Last[value=2]'


# Generated at 2022-06-12 05:28:39.556946
# Unit test for method concat of class Last
def test_Last_concat():
    # Test with 2 instances of Last semigroup
    actual = Last(2).concat(Last(1))
    expected = Last(1)
    assert actual == expected
    # Test with 2 instances of semigroup and 1 instance of Last
    actual = Sum(2).concat(Last(1))
    expected = Last(1)
    assert actual == expected

# Generated at 2022-06-12 05:28:47.495944
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(2) == Sum(2)
    assert Sum(3) != Sum(2)
    assert Last(2) == Last(2)
    assert Last(3) != Last(2)
    assert All(2) == All(2)
    assert All(3) != All(2)
    assert One(2) == One(2)
    assert One(3) != One(2)
    assert First(2) == First(2)
    assert First(3) != First(2)
    assert Max(2) == Max(2)
    assert Max(3) != Max(2)
    assert Min(2) == Min(2)
    assert Min(3) != Min(2)


# Generated at 2022-06-12 05:28:53.242758
# Unit test for method concat of class Map
def test_Map_concat():
    a = Map({'a': Sum(1), 'b': Sum(2)})
    b = Map({'a': Sum(1), 'c': Sum(2)})

    assert a.concat(b) == Map({'a': Sum(2), 'b': Sum(2), 'c': Sum(2)})

# Generated at 2022-06-12 05:28:55.040508
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    Sum(1).fold(int) == 1



# Generated at 2022-06-12 05:28:57.953256
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    Function for unit test for method concat of class Sum
    """
    expected = Sum(4)
    actual = Sum(2).concat(Sum(2))
    assert expected == actual


# Generated at 2022-06-12 05:28:59.175839
# Unit test for constructor of class One
def test_One():
    one = One(True)
    assert one.value == True

# Generated at 2022-06-12 05:29:04.800080
# Unit test for constructor of class One
def test_One():
    assert One(False).value == False, "One constructor should return boolean value"


# Generated at 2022-06-12 05:29:06.628348
# Unit test for method __str__ of class Max
def test_Max___str__():
    a = Max(10)
    assert a.__str__() == "Max[value=10]"


# Generated at 2022-06-12 05:29:09.446017
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    last = Last(2)
    assert str(last) == 'Last[value=2]'



# Generated at 2022-06-12 05:29:15.595595
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Unit test for method fold of Semigroup
    """
    import pyprel
    pyprel.print_title("Test Semigroup fold")
    obj1 = Semigroup(1)
    obj2 = Semigroup(2)
    print(obj1.fold(lambda x: x + 1))
    print(obj1.concat(obj2).fold(lambda x: x + 1))


# Generated at 2022-06-12 05:29:26.054861
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)

    assert All(True) == All(True)
    assert All(True) != All(False)

    assert One(True) == One(True)
    assert One(True) != One(False)

    assert First(1) == First(1)
    assert First(1) != First(2)

    assert Last(1) == Last(1)
    assert Last(1) != Last(2)

    assert Max(1) == Max(1)
    assert Max(1) != Max(2)

    assert Min(1) == Min(1)
    assert Min(1) != Min(2)



# Generated at 2022-06-12 05:29:29.520539
# Unit test for constructor of class Last
def test_Last():
    """
    :return: nothing
    :rtype: None
    """

    last = Last(42)
    assert last.value == 42



# Generated at 2022-06-12 05:29:31.750589
# Unit test for method concat of class First
def test_First_concat():
    a = First("banana")
    b = First("pear")
    assert a.concat(b) == First("banana")



# Generated at 2022-06-12 05:29:33.485917
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)).value == 3

# Generated at 2022-06-12 05:29:35.075573
# Unit test for constructor of class All
def test_All():
    a = All(True)
    assert a.concat(a) == All(True)



# Generated at 2022-06-12 05:29:38.072342
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(2).concat(Max(5)) == Max(5)
    assert Max(5).concat(Max(2)) == Max(5)
    assert Max(5).concat(Max(5)) == Max(5)


# Generated at 2022-06-12 05:29:43.955700
# Unit test for constructor of class First
def test_First():
    x = First(1)
    y = First(2)
    assert 1 == x.value
    assert 1 == x.concat(y).value


# Generated at 2022-06-12 05:29:47.829779
# Unit test for method __str__ of class Map
def test_Map___str__():
    m = Map({1: Last(1), 2: Last(2)})  # pragma: no cover
    assert 'Map[value={1: Last[value=1], 2: Last[value=2]}]' == str(m)


# Generated at 2022-06-12 05:29:49.965052
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(3)) == Min(2)


# Generated at 2022-06-12 05:29:51.608449
# Unit test for method __str__ of class One
def test_One___str__():
    one = One(True)
    assert one.__str__() == "One[value=True]"


# Generated at 2022-06-12 05:29:52.678760
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(2) == Sum(2)



# Generated at 2022-06-12 05:29:54.873179
# Unit test for method concat of class Sum
def test_Sum_concat():
    semigroup = Sum(1)
    result = semigroup.concat(Sum(2))
    assert result.value == 3



# Generated at 2022-06-12 05:30:01.683250
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(False)) == One(False)

    assert One(True).concat(One(True)) == One(True)

    assert One(None).concat(One(False)) == One(False)
    assert One(None).concat(One(0)) == One(0)

    assert One(None).concat(One(None)) == One(None)



# Generated at 2022-06-12 05:30:04.564485
# Unit test for method concat of class Min
def test_Min_concat():
    first_value = Min(1)
    second_value = Min(2)
    result_value = first_value.concat(second_value)
    assert result_value == Min(1)


# Generated at 2022-06-12 05:30:07.166226
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1
    assert Last("a").value == "a"
    assert Last(Last("b")).value == Last("b")



# Generated at 2022-06-12 05:30:11.250771
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x) == 1
    assert Semigroup(3).fold(lambda x: x) == 3
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    assert Semigroup(3).fold(lambda x: x + 3) == 6

# Generated at 2022-06-12 05:30:16.531935
# Unit test for constructor of class All
def test_All():
    assert All(True).value == All.neutral_element
    assert All(False).value == All.neutral_element


# Generated at 2022-06-12 05:30:27.702744
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(10).fold(lambda x: (6 + x)*2) == 42
    assert All(True).fold(lambda x: (x and True))
    assert One(False).fold(lambda x: (x or False))
    assert First('a').fold(lambda x: (x[0] != 't'))
    assert Last('a').fold(lambda x: (x[0] != 't'))
    assert Map({'a': Sum(10)}).fold(lambda x: x['a'] == 10)
    assert Max(10).fold(lambda x: x > 5)
    assert Min(10).fold(lambda x: x > 5)

    # Raise exception if value is not instance of Semigroup
    with pytest.raises(AttributeError):
        Semigroup(10).fold(lambda x: x)


# Unit test

# Generated at 2022-06-12 05:30:30.424222
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'
    assert str(One('string')) == 'One[value=string]'


# Generated at 2022-06-12 05:30:37.441807
# Unit test for method concat of class Map
def test_Map_concat():  # pragma: no cover
    """
    Method concat of class Map test
    """
    result = Map({'a': Sum(1), 'b': Sum(5), 'c': All(True)}) \
            .concat(Map({'a': Sum(2), 'b': Sum(3), 'd': All(True)}))
    assert(result == Map({'a': Sum(3), 'b': Sum(8), 'c': All(True), 'd': All(True)}))
    print('Map test concat ok')

# Generated at 2022-06-12 05:30:39.327336
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1
    assert Max(2).value == 2

# Generated at 2022-06-12 05:30:40.966396
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(3) == Sum(3)



# Generated at 2022-06-12 05:30:41.872119
# Unit test for constructor of class Max
def test_Max():
    assert Max(10).value == 10


# Generated at 2022-06-12 05:30:44.508428
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-12 05:30:48.431037
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(2).concat(Max(3)) == Max(3)
    assert Max(3).concat(Max(2)) == Max(3)
    assert Max(1).concat(Max(1)) == Max(1)
    assert Max(2).concat(Max(2)) == Max(2)
    assert Max(3).concat(Max(3)) == Max(3)


# Generated at 2022-06-12 05:30:54.739565
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(1)) == Sum(2)
    assert Sum(2).concat(Sum(7)) == Sum(9)
    assert Sum(2).concat(Sum(1)) == Sum(3)
    assert Sum(9).concat(Sum(0)) == Sum(9)
    assert Sum(5).concat(Sum(4)) == Sum(9)


# Generated at 2022-06-12 05:31:00.344113
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
        >>> _ = Semigroup(42)
    """



# Generated at 2022-06-12 05:31:03.023676
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-12 05:31:04.013733
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1


# Generated at 2022-06-12 05:31:08.816480
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last("a").concat(Last("b")) == Last("b")
    assert Last([]).concat(Last([1])) == Last([1])
    assert Last({}).concat(Last({1: 1})) == Last({1: 1})
    assert Last(True).concat(Last(False)) == Last(False)



# Generated at 2022-06-12 05:31:11.645554
# Unit test for constructor of class All
def test_All():
    assert All(1) == All(True)
    assert All(0) == All(False)
    assert All(1) != All(0)


# Generated at 2022-06-12 05:31:13.831272
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(2) == Sum(2)
    assert Sum(2) != Sum(3)


# Generated at 2022-06-12 05:31:16.005976
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'

# Generated at 2022-06-12 05:31:20.030820
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(False).concat(None) == One(False)


# Generated at 2022-06-12 05:31:22.660750
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'

# Generated at 2022-06-12 05:31:24.490097
# Unit test for constructor of class Max
def test_Max():
    max = Max(100)
    assert str(max) == 'Max[value=100]'


# Generated at 2022-06-12 05:31:31.312408
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)


# Generated at 2022-06-12 05:31:35.883811
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map({1: Sum(3), 2: Sum(1)})
    map2 = Map({1: Sum(2), 2: Sum(4)})
    map3 = Map({1: Sum(5), 2: Sum(5)})
    assert map1.concat(map2) == map3

# Generated at 2022-06-12 05:31:37.789417
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(5)) == 'Last[value=5]'


# Generated at 2022-06-12 05:31:42.332928
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-12 05:31:45.346183
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)



# Generated at 2022-06-12 05:31:47.897168
# Unit test for constructor of class Semigroup
def test_Semigroup():
    #: :type: Semigroup
    value = Sum(1)
    assert repr(value) == 'Sum[value=1]'


# Unit test to concat 2 Sum instances

# Generated at 2022-06-12 05:31:49.934915
# Unit test for method __str__ of class Map
def test_Map___str__():
    m = Map({})
    assert str(m) == 'Map[value={}]'



# Generated at 2022-06-12 05:31:52.360380
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'



# Generated at 2022-06-12 05:31:55.879159
# Unit test for constructor of class Map
def test_Map():
    # Test for each constructor
    assert Map({"a": 1, "b": 2}) == Map({"a": 1, "b": 2})

    # Test for each constructor
    with pytest.raises(KeyError):
        Map({"a": 1, "b": 2}) == Map({"a": 1, "c": 2})



# Generated at 2022-06-12 05:31:58.978252
# Unit test for method concat of class One
def test_One_concat():
    first = One(True)
    second = One(False)
    assert first.concat(second) == One(True)


# Generated at 2022-06-12 05:32:08.819523
# Unit test for constructor of class Last
def test_Last():
    last = Last("last_value")
    assert last.value == "last_value"



# Generated at 2022-06-12 05:32:15.461944
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert All(False) == All(False)
    assert All(False) != All(True)

    assert First(1) == First(1)
    assert First(1) != First(0)

    assert Last(1) == Last(1)
    assert Last(1) != Last(0)

    assert Max(1) == Max(1)
    assert Max(1) != Max(0)

    assert Min(1) == Min(1)
    assert Min(1) != Min(0)

    assert One(1) == One(1)
    assert One(1) != One(0)

    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(0)

    assert Map({'a': Sum(1)}) == Map({'a': Sum(1)})

# Generated at 2022-06-12 05:32:16.906906
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(5)) == "Sum[value=5]"



# Generated at 2022-06-12 05:32:21.167947
# Unit test for method __str__ of class Map
def test_Map___str__():
    """
    method __str__ of class Map
    """
    test_case = {'a': Sum(5), 'b': Sum(10)}
    assert str(Map(test_case)) == str({'a': Sum(5), 'b': Sum(10)})



# Generated at 2022-06-12 05:32:29.331150
# Unit test for constructor of class One
def test_One():
    assert One(False) == One(False)
    assert One(False) != One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(False).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-12 05:32:34.716945
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First("")) == 'Fist[value=]'
    assert str(First([])) == 'Fist[value=[]]'
    assert str(First({})) == 'Fist[value={}]'


# Generated at 2022-06-12 05:32:38.346229
# Unit test for method concat of class First
def test_First_concat():
    value = 1
    first = First(value)
    semigroup = First(2)

    expected = first
    actual = first.concat(semigroup)

    assert expected.value == actual.value



# Generated at 2022-06-12 05:32:40.553312
# Unit test for method __str__ of class Last
def test_Last___str__():
    expected = "Last[value=123]"

    obj = Last(123)

    assert str(obj) == expected

# Generated at 2022-06-12 05:32:41.935490
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    semigroup = Semigroup(1)
    assert semigroup.value == 1


# Generated at 2022-06-12 05:32:43.701683
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)


# Generated at 2022-06-12 05:33:01.580289
# Unit test for method concat of class Max
def test_Max_concat():
    actual_value = Max(3).concat(Max(5)).concat(Max(1))
    expected_value = Max(5)
    assert actual_value == expected_value


# Generated at 2022-06-12 05:33:04.151009
# Unit test for constructor of class One
def test_One():
    # Unit test for constructor of class One
    assert One(True).value is True
    assert One(False).value is False
    assert One('1').value is True
    assert One({}).value is False


# Generated at 2022-06-12 05:33:06.412591
# Unit test for constructor of class Last
def test_Last():
    # GIVEN
    last = Last(5)

    # THEN
    assert last.value == 5

# Generated at 2022-06-12 05:33:09.829484
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).fold(lambda x: x) == 1
    assert Max(1) == Max(1)
    assert Max(1) != Max(2)

    assert Max.neutral().value == -float("inf")


# Generated at 2022-06-12 05:33:10.924012
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(3).value == 3



# Generated at 2022-06-12 05:33:20.266185
# Unit test for method concat of class Map
def test_Map_concat():
    from copy import deepcopy

    map = Map({
        'a': First(1),
        'b': First(2),
        'c': First(3),
    })
    
    # Create new map with same structure
    map_tmp = Map(deepcopy(map.value))
    
    # Change values of tmp map
    map_tmp.value['a'].value = 0
    map_tmp.value['b'].value = 0
    map_tmp.value['c'].value = 0

    map = map.concat(map_tmp)

    assert map.value['a'].value == 1
    assert map.value['b'].value == 2
    assert map.value['c'].value == 3

# Generated at 2022-06-12 05:33:24.271734
# Unit test for method concat of class One
def test_One_concat():
    """
    Test method concat of One semigroup.
    """
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(False)).value == False



# Generated at 2022-06-12 05:33:25.602597
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)



# Generated at 2022-06-12 05:33:27.751953
# Unit test for constructor of class Sum
def test_Sum(): # pragma: no cover
    assert Sum(1).value == 1


# Generated at 2022-06-12 05:33:33.408825
# Unit test for method concat of class Map
def test_Map_concat():
    """
    :returns: void
    :rtype: None
    """
    obj_1 = Map({1: Sum(1), 2: Sum(4), 3: Sum(5)})
    obj_2 = Map({1: Sum(2), 2: Sum(3), 4: Sum(6)})
    assert obj_1.concat(obj_2) == Map({1: Sum(3), 2: Sum(7), 3: Sum(5), 4: Sum(6)})