

# Generated at 2022-06-12 05:23:48.901873
# Unit test for method concat of class Max
def test_Max_concat():  # pragma: no cover
    assert Max(1).concat(Max(2)) == Max(2)


# Generated at 2022-06-12 05:23:51.488271
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)


# Generated at 2022-06-12 05:23:57.457350
# Unit test for method concat of class Max
def test_Max_concat():
    r"""
    Test if Max.concat(Max) returns expected result
    """
    # setup
    s = Max(0)
    # assert
    assert s.concat(Max(1)).value == s.value
    assert s.concat(Max(9)).value == Max(9).value
    assert s.concat(Max(0)).value == s.value



# Generated at 2022-06-12 05:23:59.499157
# Unit test for method concat of class Min
def test_Min_concat():          # pragma: no cover
    assert Min(10).concat(Min(20)) == Min(10)



# Generated at 2022-06-12 05:24:01.803309
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).value == 1
    assert Min(2).concat(Min(1)).value == 1

test_Min_concat()



# Generated at 2022-06-12 05:24:03.789389
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)


# Generated at 2022-06-12 05:24:10.183358
# Unit test for method concat of class Map
def test_Map_concat():
    # Try to concat 2 Maps
    assert Map(
        {'a': Sum(1), 'b': Sum(3)}
    ).concat(
        Map({'b': Sum(5), 'c': Sum(7)})
    ) == Map(
        {'a': Sum(1), 'b': Sum(8), 'c': Sum(7)}
    )



# Generated at 2022-06-12 05:24:18.343930
# Unit test for method concat of class Map
def test_Map_concat():
    #Dict of Sum
    m1 = Map({'1': Sum(1), '2': Sum(2)})
    m2 = Map({'1': Sum(1), '2': Sum(2)})
    assert m1.concat(m2) == Map({'1': Sum(2), '2': Sum(4)})
    #Dict of All
    m3 = Map({'1': All(True), '2': All(False)})
    m4 = Map({'1': All(True), '2': All(False)})
    assert m3.concat(m4) == Map({'1': All(True), '2': All(False)})
    #Dict of One
    m5 = Map({'1': One(True), '2': One(False)})

# Generated at 2022-06-12 05:24:20.939021
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-12 05:24:26.430119
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(3)) == Min(1)
    assert Min(1).concat(Min(0)) == Min(0)
    assert Min(1).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(0)) == Min(0)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(2).concat(Min(2)) == Min(2)
    assert Min(2).concat(Min(3)) == Min(2)
    assert Min(3).concat(Min(3)) == Min(3)
    assert Min(3).concat(Min(2)) == Min(2)

# Generated at 2022-06-12 05:24:31.813822
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(2).concat(Max(3)) == Max(3)
    assert Max(3).concat(Max(2)) == Max(3)



# Generated at 2022-06-12 05:24:33.406389
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-12 05:24:34.878580
# Unit test for constructor of class Last
def test_Last():
    assert Last("last value").value == "last value"


# Generated at 2022-06-12 05:24:39.964231
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-12 05:24:44.368835
# Unit test for method concat of class Last
def test_Last_concat():
    # given
    semigroup = Last(1)
    second_semigroup = Last(2)

    #when
    actual = semigroup.concat(second_semigroup)

    # then
    assert actual.value == 2


# Generated at 2022-06-12 05:24:45.900181
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'

# Generated at 2022-06-12 05:24:47.420036
# Unit test for method concat of class Map
def test_Map_concat():
    """
    Add your test here.
    """
    pass

# Generated at 2022-06-12 05:24:50.409318
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': First(1), 'b': First(2)}).concat(Map({'a': First(3), 'b': First(4)})) == Map({'a': First(1), 'b': First(2)})

# Generated at 2022-06-12 05:24:51.987450
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).concat(One(2)) == One(True)

# Generated at 2022-06-12 05:25:00.094767
# Unit test for method concat of class Min
def test_Min_concat():
    """

    :param semigroup: other semigroup to concat
    :type semigroup: Min[B]
    :returns: new Min with smallest value
    :rtype: Min[A | B]
    """

    assert Min(5).concat(Min(6)) == Min(5)
    assert Min(6).concat(Min(5)) == Min(5)
    assert Min(5).concat(Min(5)) == Min(5)
    assert Min(0).concat(Min(0)) == Min(0)


# Generated at 2022-06-12 05:25:06.155342
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(3) == Sum(3)
    assert 3 == Sum(3).value
    assert Sum(3) == Sum(3)
    assert not Sum(3) == Sum(4)
    assert Sum(4) != Sum(3)
    assert Sum(3) != 3


# Generated at 2022-06-12 05:25:10.057725
# Unit test for method concat of class One
def test_One_concat():
    assert One(False).concat(One(False)).value == False
    assert One(False).concat(One(True)).value == True
    assert One(True).concat(One(False)).value == True
    assert One(True).concat(One(True)).value == True

test_One_concat()


# Generated at 2022-06-12 05:25:11.680373
# Unit test for method concat of class Sum
def test_Sum_concat():  # pragma: no cover
    assert Sum(1).concat(Sum(2)).value == 3



# Generated at 2022-06-12 05:25:13.970804
# Unit test for constructor of class Max
def test_Max():
    max_5 = Max(5)
    assert max_5.value == 5
    print(max_5)


# Generated at 2022-06-12 05:25:17.380016
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'
    assert str(All(1)) == 'All[value=True]'


# Generated at 2022-06-12 05:25:19.910003
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(7)) == 'Min[value=7]'


# Generated at 2022-06-12 05:25:22.336317
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    assert str(Last("foo")) == 'Last[value=foo]'
    assert str(Last("bar")) == 'Last[value=bar]'



# Generated at 2022-06-12 05:25:23.744972
# Unit test for constructor of class Min
def test_Min():
    min = Min(2)
    assert min.value == 2
    assert min.concat(Min(1)).value == 1


# Generated at 2022-06-12 05:25:25.853895
# Unit test for constructor of class Last
def test_Last():
    """
    Unit test for constructor of class Last
    """
    assert First(2).value == 2
    assert First('foo').value == 'foo'
    assert First({'foo': 2}).value == {'foo': 2}


# Generated at 2022-06-12 05:25:26.962346
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(10)) == 'Max[value=10]'



# Generated at 2022-06-12 05:25:32.851983
# Unit test for method __str__ of class Last
def test_Last___str__():
    """
    Test for method __str__ of class Last
    """

    assert str(Last('Test value')) == 'Last[value=Test value]'



# Generated at 2022-06-12 05:25:38.784352
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({'a': All(True), 'b': All(True)})
    m2 = Map({'c': All(True), 'd': All(False)})
    m3 = m1.concat(m2)
    assert_that(m3).is_equal_to(Map({'a': All(True), 'b': All(True), 'c': All(True), 'd': All(False)}))



# Generated at 2022-06-12 05:25:40.068694
# Unit test for constructor of class Semigroup
def test_Semigroup():
    print(Semigroup(1))



# Generated at 2022-06-12 05:25:51.299799
# Unit test for method concat of class Map
def test_Map_concat():

    assert Map({"key1": Sum(1), "key2": Sum(2)}).concat(Map({"key1": Sum(2), "key2": Sum(1)})).value["key1"].value == 3
    assert Map({"key1": Sum(1), "key2": Sum(2)}).concat(Map({"key1": Sum(2), "key2": Sum(1)})).value["key2"].value == 3
    assert Map({"key1": Sum(1), "key2": Sum(2)}).concat(Map({"key1": Sum(2), "key2": Sum(1)})).value["key1"].value == 3

# Generated at 2022-06-12 05:25:52.934585
# Unit test for constructor of class First
def test_First():
    value = 'first'
    semigroup = First(value)

    assert semigroup.value == value


# Generated at 2022-06-12 05:25:54.716378
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-12 05:25:59.293805
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    >>> test_Semigroup_fold()
    Sum[value=10]
    """
    sum = Sum(10)
    print(sum.fold(lambda x: x))



# Generated at 2022-06-12 05:26:01.454912
# Unit test for method concat of class Map
def test_Map_concat():
    actual = Map({'foo': Sum(0), 'bar': Sum(1)}).concat(Map({'foo': Sum(1), 'baz': Sum(3)}))
    expected = Map({'foo': Sum(1), 'bar': Sum(1), 'baz': Sum(3)})
    assert actual == expected


# Generated at 2022-06-12 05:26:04.180248
# Unit test for method __str__ of class Map
def test_Map___str__(): # pragma: no cover
    map_ = Map({'1': First('1')})
    assert str(map_) == "Map[value={'1': Fist[value='1']}]"



# Generated at 2022-06-12 05:26:06.586925
# Unit test for method concat of class Map
def test_Map_concat():
    """
    :returns: void
    :rtype: NoneType
    """

    assert Map({'a': Sum(1)}).concat(Map({'a': Sum(2)})).value['a'].value == 3



# Generated at 2022-06-12 05:26:15.182064
# Unit test for constructor of class All
def test_All():
    assert All(False)
    assert All(True)
    assert not All(None)
    assert not All(1)



# Generated at 2022-06-12 05:26:16.700487
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    Unit test for method __eq__ of class Semigroup
    """
    assert Semigroup(1) == Semigroup(1)


# Generated at 2022-06-12 05:26:19.179958
# Unit test for method __str__ of class All
def test_All___str__():
    assert All(True).__str__() == 'All[value=True]'



# Generated at 2022-06-12 05:26:24.707010
# Unit test for method concat of class Map
def test_Map_concat(): # pragma: no cover
    """
    :returns: None
    :rtype: None
    """
    assert Map({'a': Sum(2), 'b': Sum(3)}).concat(
        Map({'a': Sum(4), 'b': Sum(8)})).value == {'a': Sum(6), 'b': Sum(11)}



# Generated at 2022-06-12 05:26:31.510039
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({
        'A': All(False),
        'B': One(False)
    }).concat(Map({
        'A': All(True),
        'B': One(True)
    })).value == {
        'A': All(False),
        'B': One(False)
    }



# Generated at 2022-06-12 05:26:35.302996
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)


# Generated at 2022-06-12 05:26:40.458617
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map(
        {
            'a': Sum(1),
            'b': Sum(2),
            'c': Sum(3)
        }
    )
    m2 = Map(
        {
            'a': Sum(3),
            'b': Sum(5),
            'c': Sum(10)
        }
    )
    m3 = m1.concat(m2)
    assert m3.value['a'].value == 4
    assert m3.value['b'].value == 7
    assert m3.value['c'].value == 13



# Generated at 2022-06-12 05:26:42.567049
# Unit test for constructor of class Map
def test_Map():
    m = Map({'a': Sum(1), 'b': Sum(2)})
    assert m.value == {'a': Sum(1), 'b': Sum(2)}
    assert m.concat(Map({'a': Sum(3), 'b': Sum(4)})).value == {'a': Sum(4), 'b': Sum(6)}

# Generated at 2022-06-12 05:26:52.257198
# Unit test for constructor of class Map
def test_Map(): # pragma: no cover
    assert Map({1: Sum(1), 2: Sum(2)}).value == {1: Sum(1), 2: Sum(2)}
    assert Map({1: Sum(1), 2: Sum(2)}).__str__() == 'Map[value={1: Sum[value=1], 2: Sum[value=2]}]'
    assert Map({1: Sum(1), 2: Sum(2)}).__repr__() == 'Map[value={1: Sum[value=1], 2: Sum[value=2]}]'
    assert Map({1: Sum(1), 2: Sum(2)}).__eq__(Map({1: Sum(1), 2: Sum(2)}))


# Generated at 2022-06-12 05:26:54.557725
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(0)
    assert Sum(0) != Sum({})


# Generated at 2022-06-12 05:27:13.823896
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)



# Generated at 2022-06-12 05:27:17.201749
# Unit test for method concat of class Max
def test_Max_concat():
    """
    Test for method concat of class Max.

    :returns: None
    :rtype: None
    """

    max1 = Max(0)
    max2 = Max(5)
    assert max1.concat(max2) == Max(5)



# Generated at 2022-06-12 05:27:19.109857
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(10)) == 'Max[value=10]'


# Generated at 2022-06-12 05:27:21.076141
# Unit test for constructor of class Map
def test_Map():
    i = Map({1: First(1), 2: First(2)})
    assert i.value[1].value == 1

# Generated at 2022-06-12 05:27:26.322458
# Unit test for method concat of class All
def test_All_concat():
    """
    test concat for class All
    """
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-12 05:27:36.796656
# Unit test for constructor of class Last

# Generated at 2022-06-12 05:27:39.435588
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'key': 'value'})) == 'Map[value={\'key\': \'value\'}]'


# Generated at 2022-06-12 05:27:46.492685
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True
    assert One(False).value == False
    assert One(0).value == False
    assert One(1).value == True
    assert One('').value == False
    assert One('string').value == True
    assert One(None).value == False
    assert One({}).value == False
    assert One({'key': 'value'}).value == True
    assert One([]).value == False
    assert One([0, 1]).value == True


# Generated at 2022-06-12 05:27:49.155250
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-12 05:27:59.624172
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': All(True)}).concat(Map({'a': All(False)})).value == {'a': All(False)}
    assert Map({'a': All(True)}).concat(Map({'b': All(False)})).value == {
        'a': All(True),
        'b': All(False)
    }
    assert str(Map({'a': All(True)}).concat(Map({'a': All(False)}))) == 'Map[value={\'a\': All[value=False]}]'
    assert Map({'a': Max(1)}).concat(Map({'a': Max(2)})).value == {'a': Max(2)}

# Generated at 2022-06-12 05:28:27.342423
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    Test Semigroup.__eq__()
    """
    assert Semigroup(1) == Semigroup(1) == 1
    assert Semigroup(1) != Semigroup(2) != 2


# Generated at 2022-06-12 05:28:31.291495
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True
    assert One(False).value == False
    assert One(123).value == 123


# Generated at 2022-06-12 05:28:32.774013
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-12 05:28:38.823093
# Unit test for method concat of class Max
def test_Max_concat():
    print(Max(10).concat(Max(20)))
    print(Max(10).concat(Max(20)).concat(Max(30)))
    print(Max(10).concat(Max(20)).concat(Max(30)).concat(Max(40)))
    print(Max(10).concat(Max(20)).concat(Max(30)).concat(Max(40)).concat(Max(5)))

# Generated at 2022-06-12 05:28:41.163904
# Unit test for method __str__ of class Min
def test_Min___str__():
    # A string is printed when we call __str__ method
    assert str(Min(3)) == "Min[value=3]"


# Generated at 2022-06-12 05:28:43.241130
# Unit test for method __str__ of class All
def test_All___str__():
    x = All(True)
    assert str(x) == "All[value=True]"


# Generated at 2022-06-12 05:28:46.878323
# Unit test for method concat of class All
def test_All_concat():
    """
    :returns: True if contains are equal else False
    :rtype: bool
    :raises: None
    """

    al = All(False)
    semigroup_1 = al.concat(All(True))
    semigroup_2 = All(False)
    return semigroup_1 == semigroup_2



# Generated at 2022-06-12 05:28:53.336371
# Unit test for method concat of class Map
def test_Map_concat():
    map_a = Map({'a': Sum(1), 'b': Sum(2)})
    map_b = Map({'b': Sum(3), 'c': Sum(4)})
    assert map_a.concat(map_b) == Map({'a': Sum(1), 'b': Sum(5), 'c': Sum(4)})



# Generated at 2022-06-12 05:28:54.293138
# Unit test for constructor of class One
def test_One():
    assert One(1).value == 1

# Generated at 2022-06-12 05:28:57.110193
# Unit test for method concat of class Max
def test_Max_concat():
    object_Max1 = Max(10)
    object_Max2 = Max(5)
    assert (object_Max1.concat(object_Max2) == Max(10))



# Generated at 2022-06-12 05:29:50.644493
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-12 05:29:52.140703
# Unit test for method __str__ of class Last
def test_Last___str__():
    a = Last(87)
    assert str(a) == "Last[value=87]"


# Generated at 2022-06-12 05:29:53.798231
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    assert str(One(True)) == 'One[value=True]'



# Generated at 2022-06-12 05:29:56.726891
# Unit test for constructor of class Map
def test_Map():
    """
    GIVEN an empty Map
    WHEN create a new Map
    THEN should return a Map instance with value is a empty Map
    """
    assert Map(
        {}
    ) == Map({})

# Generated at 2022-06-12 05:30:02.053814
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)



# Generated at 2022-06-12 05:30:07.658860
# Unit test for method concat of class Min
def test_Min_concat():
    min1 = Min(10)
    min2 = Min(20)
    min3 = Min(20)

    min1.concat(min2) == Min(min(min1.value, min2.value))
    min1.concat(min3) == Min(min(min1.value, min3.value))
    min2.concat(min3) == Min(min(min2.value, min3.value))


# Generated at 2022-06-12 05:30:10.005453
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-12 05:30:12.547164
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    # Empty
    assert Sum(1) == Sum(1)
    assert Sum(2) != Sum(1)
    assert Sum(1) != 1



# Generated at 2022-06-12 05:30:18.094637
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(None) == All(None)
    assert All('') == All('')
    assert All('a') == All('a')
    assert All(0) == All(0)
    assert All(3) == All(3)
    assert All(True) == All(True)
    assert All(True) == All(True)
    assert All(True) == All(True)
    assert All(True) == All(True)
    assert All(True) == All(True)
    assert All(True) == All(True)



# Generated at 2022-06-12 05:30:21.500509
# Unit test for method __str__ of class First
def test_First___str__():
    def function_test(x):
        assert str(First(5)) == "Fist[value=5]"
    return function_test


# Generated at 2022-06-12 05:31:17.992810
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(3)) == 'Max[value=3]'


# Generated at 2022-06-12 05:31:23.131986
# Unit test for constructor of class Map
def test_Map():
    m = Map({1: First(10), 2: First(20)})
    n = Map({1: Last(100), 2: Last(200)})
    assert m.concat(n).value == {1: First(10), 2: First(20)}



# Generated at 2022-06-12 05:31:24.586365
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(2)) == 'Last[value=2]'


# Generated at 2022-06-12 05:31:26.438691
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'



# Generated at 2022-06-12 05:31:28.695413
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(False)) == 'One[value=False]'
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-12 05:31:30.755794
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(9)) == "Sum[value=9]"



# Generated at 2022-06-12 05:31:36.089647
# Unit test for constructor of class Map
def test_Map():
    """
    should construct with m = {'a': Max 2, 'b': Min 4, 'c': All True}
    """
    m = Map({"a": Max(2), "b": Min(4), "c": All(True)})
    assert m.value == {"a": Max(2), "b": Min(4), "c": All(True)}



# Generated at 2022-06-12 05:31:39.227120
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(4) == Sum(4), "Not equal to"
    assert str(Sum(4)) == 'Sum[value=4]', "Not equal print"



# Generated at 2022-06-12 05:31:41.420013
# Unit test for constructor of class Sum
def test_Sum():
    sum = Sum(1)
    assert sum.value == 1
    assert str(sum) == "Sum[value=1]"


# Generated at 2022-06-12 05:31:44.283562
# Unit test for method __str__ of class Map
def test_Map___str__():
    """Tests whether string representation of the class object is the same as the expected value"""
    assert str(Map({'a': 1, 'b': 2})) == 'Map[value={\'a\': 1, \'b\': 2}]'

