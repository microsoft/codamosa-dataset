

# Generated at 2022-06-24 00:31:40.095672
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True))  == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:31:51.465070
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert First(1).fold(lambda x: x + 2) == 3
    assert Last(3).fold(lambda x: x + 2) == 5
    assert Sum(1).fold(lambda x: x + 2) == 3
    assert Min(2).fold(lambda x: x + 2) == 4
    assert Max(1).fold(lambda x: x + 2) == 3
    assert All(False).fold(lambda x: x) == False
    assert All(True).fold(lambda x: x) == True
    assert One(True).fold(lambda x: x) == True
    assert One(False).fold(lambda x: x) == False
    assert Map({'a': Sum(1), 'b': Sum(2)}).fold(lambda x: x) == {'a': Sum(1), 'b': Sum(2)}

#

# Generated at 2022-06-24 00:31:54.620104
# Unit test for method __str__ of class One
def test_One___str__():
    """
    Unit test for method __str__ of class One
    """
    one = One("Hello World")
    assert one.__str__() == 'One[value=Hello World]'


# Generated at 2022-06-24 00:31:58.657881
# Unit test for constructor of class Map
def test_Map():
    value = Map({"a": First(1), "b": Last(2), "c": Sum(3)})
    result = Map({"a": First(1), "b": Last(2), "c": Sum(3)})

    assert value == result


# Generated at 2022-06-24 00:31:59.971918
# Unit test for constructor of class Max
def test_Max():  # pragma: no cover
    assert Max(3).value == 3



# Generated at 2022-06-24 00:32:02.466763
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert Sum(1)
    assert Sum('2')
    assert Sum(True)
    assert Sum(())
    assert Sum({'a': 1})



# Generated at 2022-06-24 00:32:05.470399
# Unit test for constructor of class Semigroup
def test_Semigroup():
    a = Semigroup(1)
    b = Semigroup(2)
    assert a != b
    assert a.value == 1
    assert b.value == 2



# Generated at 2022-06-24 00:32:06.590243
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(4)) == 'Fist[value=4]'



# Generated at 2022-06-24 00:32:08.142874
# Unit test for constructor of class First
def test_First():
    assert First(5) == First(5)


# Generated at 2022-06-24 00:32:10.313739
# Unit test for method concat of class First
def test_First_concat():
    assert First('a').concat(First('b')).fold(lambda x: x) == 'a'


# Generated at 2022-06-24 00:32:13.115211
# Unit test for method concat of class Min
def test_Min_concat():  # pragma: no cover
    assert Min(10).concat(Min(5)).value == 5



# Generated at 2022-06-24 00:32:17.092987
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == "Sum[value=1]"


# Generated at 2022-06-24 00:32:21.617366
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(2).concat(Sum(1)) == Sum(3)
    assert Sum(5).concat(Sum(10)) == Sum(15)
    assert Sum(11).concat(Sum(3)) == Sum(14)


# Generated at 2022-06-24 00:32:24.038569
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    l = Last(1)
    assert str(l) == 'Last[value=1]'


# Generated at 2022-06-24 00:32:26.262336
# Unit test for method __str__ of class Min
def test_Min___str__():
    with pytest.raises(Exception) as e_info:
        assert str(Min(2)) == 'Min[value=2]'

# Generated at 2022-06-24 00:32:29.423314
# Unit test for method concat of class First
def test_First_concat():
    assert First(True).concat(First(False)).value == First(True).value
    assert First(False).concat(First(True)).value == First(False).value


# Generated at 2022-06-24 00:32:30.818067
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)


# Generated at 2022-06-24 00:32:32.785602
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'  # pragma: no cover


# Generated at 2022-06-24 00:32:35.550054
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert Map({1: Sum(1), 2: Sum(2)}).__str__() == "Map[value={1: Sum[value=1], 2: Sum[value=2]}]"


# Generated at 2022-06-24 00:32:39.292530
# Unit test for constructor of class All
def test_All():
    # Arrange
    test_semigroup = All(False)
    # Act
    result = test_semigroup.value
    # Assert
    assert result == test_semigroup.value
    assert result == False



# Generated at 2022-06-24 00:32:41.844965
# Unit test for method concat of class First
def test_First_concat():
    assert First("Hello").concat(First("World")) == First("Hello")
    assert First("Hello").concat(First("")) == First("Hello")

# Generated at 2022-06-24 00:32:45.685002
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"f1":First(1), "f2":First(2)}).concat(Map({"f1":First(2), "f2":First(10)})) == Map({"f1":First(1), "f2":First(2)})


# Generated at 2022-06-24 00:32:47.076035
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(2)) == 'Sum[value=2]'


# Generated at 2022-06-24 00:32:52.120407
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)



# Generated at 2022-06-24 00:32:53.088126
# Unit test for constructor of class Last
def test_Last():
    assert Last(2) == Last(2)

# Generated at 2022-06-24 00:32:54.383578
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(1) == One(1)
    assert One(1).__str__() == "One[value=1]"
    assert One(False).__str__() == "One[value=False]"


# Generated at 2022-06-24 00:32:59.531595
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(4).concat(Max(4)) == Max(4)
    assert Max(4).concat(Max(5)) == Max(5)
    assert Max(5).concat(Max(4)) == Max(5)

# Generated at 2022-06-24 00:33:03.279387
# Unit test for method concat of class Map
def test_Map_concat():
    instance_A = Map({1: Sum(1)})
    instance_B = Map({1: Sum(2)})
    instance_C = instance_A.concat(instance_B)

    assert 3 == instance_C.value[1].value

# Generated at 2022-06-24 00:33:04.310408
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)



# Generated at 2022-06-24 00:33:06.918574
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(10)) == 'Min[value=10]'


# Generated at 2022-06-24 00:33:11.148966
# Unit test for constructor of class Max
def test_Max():
    instance = Max(1)
    assert isinstance(instance, Max)
    assert isinstance(instance, Semigroup)
    assert instance.value == 1
    assert str(instance) == 'Max[value=1]'


# Generated at 2022-06-24 00:33:13.430112
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(123).concat(Last(456)) == Last(456)

# unit test for method concat of class First

# Generated at 2022-06-24 00:33:16.868470
# Unit test for method concat of class Min
def test_Min_concat():
    min_5 = Min(5)  # min_5 = Min[value=5]
    min_10 = Min(10)  # min_10 = Min[value=10]
    assert min_5.concat(min_10) == Min(5)  # Min[value=5]



# Generated at 2022-06-24 00:33:24.887800
# Unit test for method concat of class Last
def test_Last_concat():
    case_1 = Last(5)
    case_2 = Last(7)

    assert (case_1.concat(case_2) == Last(7))

    case_1 = Last(5)
    case_2 = Last(7)

    assert (case_1.concat(case_2) == Last(7))

    case_1 = Last(None)
    case_2 = Last('a')

    assert (case_1.concat(case_2) == Last('a'))

    case_1 = Last({'a': 5, 'b': 7})
    case_2 = Last({'a': 10, 'b': 14})

    assert (case_1.concat(case_2) == Last({'a': 10, 'b': 14}))


# Generated at 2022-06-24 00:33:26.640939
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1

# Generated at 2022-06-24 00:33:37.835595
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)

    assert All(True) == All(True)
    assert All(True) != All(False)

    assert One(True) == One(True)
    assert One(True) != One(False)

    assert First(1) == First(1)
    assert First(1) != First(2)

    assert Last(1) == Last(1)
    assert Last(1) != Last(2)

    assert Map({1: Sum(1)}) == Map({1: Sum(1)})
    assert Map({1: Sum(1)}) != Map({1: Sum(2)})
    assert Map({1: Sum(1)}) != Map({2: Sum(1)})

    assert Max(1) == Max(1)
   

# Generated at 2022-06-24 00:33:46.550112
# Unit test for constructor of class Semigroup
def test_Semigroup():
    123 | Map({"a": Sum(1), "b": Min(2)})
    Test.assert_equals(
        Sum(1).concat(Sum(2)).value,
        Sum(3).value,
        'Sum(1).concat(Sum(2)) == Sum(3)',
    )

    Test.assert_equals(
        All(True).concat(All(True)).value,
        All(True).value,
        'All(True).concat(All(True)) == All(True)',
    )
    Test.assert_equals(
        All(True).concat(All(False)).value,
        All(False).value,
        'All(True).concat(All(False)) == All(False)',
    )

# Generated at 2022-06-24 00:33:47.685052
# Unit test for constructor of class Max
def test_Max():
    assert Max(2).value == 2



# Generated at 2022-06-24 00:33:54.294683
# Unit test for constructor of class First
def test_First():
    assert str(First(1)) == "Fist[value=1]"
    assert str(First("a")) == "Fist[value=a]"
    assert str(First([1,2,3])) == "Fist[value=[1, 2, 3]]"
    assert str(First({"1": 1, "2": 2, "3": 3})) == "Fist[value={'1': 1, '2': 2, '3': 3}]"



# Generated at 2022-06-24 00:33:59.714279
# Unit test for method __str__ of class One
def test_One___str__():
    firstOne = One(True)
    assert firstOne.__str__() == 'One[value=True]'

    secondOne = One(False)
    assert secondOne.__str__() == 'One[value=False]'


# Generated at 2022-06-24 00:34:02.354828
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(True)).value == True
    assert One(False).concat(One(False)).value == False
    assert One(True).concat(One(True)).value == True


# Generated at 2022-06-24 00:34:03.744698
# Unit test for constructor of class Min
def test_Min():
    try:
        assert Min(5) == Min(5)
    except AssertionError:
        print("AssertionError")


# Generated at 2022-06-24 00:34:05.772165
# Unit test for constructor of class First
def test_First():
    first = First(1)

    assert first.value == first.fold(lambda x: x)


# Generated at 2022-06-24 00:34:07.247177
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(4)) == 'Max[value=4]'



# Generated at 2022-06-24 00:34:13.514058
# Unit test for method concat of class Last
def test_Last_concat():
    """
    Checks the concat method of class Last
    """
    assert Last(3).concat(Last(2)) == Last(2)
    assert Last(2).concat(Last(3)) == Last(3)
    assert Last(2).concat(Last(2)) == Last(2)
    assert Last('hello').concat(Last('world')) == Last('world')



# Generated at 2022-06-24 00:34:16.199365
# Unit test for constructor of class All
def test_All():
    a = All(True)
    b = All(False)
    assert a.value == True and b.value == False


# Generated at 2022-06-24 00:34:20.709494
# Unit test for method __str__ of class One
def test_One___str__():
    expect(One(True)).to(equal('One[value=True]'))
    expect(One(False)).to(equal('One[value=False]'))
    expect(One(None)).to(equal('One[value=None]'))


# Generated at 2022-06-24 00:34:24.101743
# Unit test for constructor of class Max
def test_Max():
    assert Max(4).value == 4


# Generated at 2022-06-24 00:34:28.775568
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(5)) == 'Sum[value=5]'
    assert str(Sum(-5)) == 'Sum[value=-5]'
    assert str(Sum(0)) == 'Sum[value=0]'
    assert str(Sum(1)) == 'Sum[value=1]'
    assert str(Sum(-1)) == 'Sum[value=-1]'
    assert str(Sum(-0.0)) == 'Sum[value=0.0]'
    assert str(Sum(1.0)) == 'Sum[value=1.0]'


# Generated at 2022-06-24 00:34:31.271618
# Unit test for constructor of class Last
def test_Last():
    assert isinstance(Last(1), Last)
    assert Last(1) == Last(1)



# Generated at 2022-06-24 00:34:32.563618
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(42).fold(lambda x: x + 1) == 43



# Generated at 2022-06-24 00:34:34.505196
# Unit test for constructor of class One
def test_One():
    one = One(False)
    assert one.value is False

# Unit test First.concat able to concat

# Generated at 2022-06-24 00:34:36.116585
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-24 00:34:37.710058
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First("a")) == 'Fist[value=a]'



# Generated at 2022-06-24 00:34:48.186753
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(3).concat(Last(4)) == Last(4)
    assert Last(5).concat(Last(6)) == Last(6)
    assert Last(7).concat(Last(8)) == Last(8)
    assert Last(9).concat(Last(10)) == Last(10)
    assert Last('a').concat(Last('b')) == Last('b')
    assert Last('c').concat(Last('d')) == Last('d')
    assert Last('e').concat(Last('f')) == Last('f')
    assert Last('g').concat(Last('h')) == Last('h')
    assert Last('i').concat(Last('j')) == Last('j')

# Generated at 2022-06-24 00:34:50.595956
# Unit test for method concat of class One
def test_One_concat():
    semigroup = One(2)
    assert semigroup.concat(One(1)) == One(2)
    assert semigroup.concat(One(False)) == One(False)



# Generated at 2022-06-24 00:34:58.085184
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    # assert Min(2).concat(Min(2)) == Min(1)
    # assert Min(1).concat(Min(2)) == Min(2)
    # assert Min(2).concat(Min(2)) == Min(2)
    # assert Min(1).concat(Min(1)) == Min(1)
    # assert Min(2).concat(Min(2)) == Min(2)


# Generated at 2022-06-24 00:35:00.433396
# Unit test for method concat of class Last
def test_Last_concat():  # pragma: no cover
    """
    Unit test for method concat of class Last
    """
    assert Last(1).concat(Last(2)).value == 2, "Last(1).concat(Last(2)).value == 2"



# Generated at 2022-06-24 00:35:05.575168
# Unit test for method concat of class Min
def test_Min_concat():
    semigroup01 =  Min(7)
    semigroup02 =  Min(2)
    semigroup03 =  Min(3)
    semigroup_concat_01 = semigroup01.concat(semigroup02)
    semigroup_concat_02 = semigroup02.concat(semigroup03)
    semigroup_concat_03 = semigroup_concat_02.concat(semigroup01)
    assert semigroup_concat_01.value == 2
    assert semigroup_concat_02.value == 2
    assert semigroup_concat_03.value == 2

test_Min_concat()

# Generated at 2022-06-24 00:35:11.046733
# Unit test for method concat of class Map
def test_Map_concat():
    # unit_test for method concat of class Map
    assert Map({"a": Sum(1), "b": Sum(1)}).concat(Map({"a": Sum(1), "c": Sum(1)})) == Map({
        "a": Sum(1).concat(Sum(1)),
        "b": Sum(1).concat(Sum(None)),
        "c": Sum(None).concat(Sum(1)),
    })

# Generated at 2022-06-24 00:35:16.001066
# Unit test for constructor of class One
def test_One():
    one = One(True)
    assert 'One[value=True]' == str(one)
    assert 'True' == str(one.value)
    assert False == one.concat(One(False)).value
    assert True == one.concat(One(True)).value
    assert One(False) == one.concat(One(False))
    assert One(True) == one.concat(One(False)).concat(One(True))



# Generated at 2022-06-24 00:35:19.268504
# Unit test for constructor of class Map
def test_Map():
    m1 = Map({'a': Sum(1), 'b': Last('x')})
    m2 = Map({'a': Sum(2), 'b': First('y')})
    m3 = m1.concat(m2)
    assert isinstance(m3, Map)
    assert m3.value == {'a': Sum(3), 'b': Last('y')}

# Generated at 2022-06-24 00:35:22.322318
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    assert str(Last(3)) == 'Last[value=3]'
    assert str(Last('a')) == "Last[value='a']"


# Unit tests for method concat of class Last

# Generated at 2022-06-24 00:35:24.689319
# Unit test for method concat of class Last
def test_Last_concat():
    assert {
        str(Last(Max(1)).concat(Last(Max(2))))
        == str(Last(Max(2)))
    }


# Generated at 2022-06-24 00:35:29.305425
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1
    assert Sum("s").value == "s"

    assert Sum(1) == Sum(1)
    assert Sum("s") == Sum("s")



# Generated at 2022-06-24 00:35:31.093332
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'



# Generated at 2022-06-24 00:35:32.749531
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1))=="Max[value=1]"
    assert str(Max(2))=="Max[value=2]"


# Generated at 2022-06-24 00:35:36.442101
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    obj = Sum(1)
    assert str(obj) == "Sum[value=1]"



# Generated at 2022-06-24 00:35:37.477878
# Unit test for constructor of class Map
def test_Map():
    assert Map({'key': Sum(1)}) == Map({'key': Sum(1)})



# Generated at 2022-06-24 00:35:39.220651
# Unit test for method __str__ of class All
def test_All___str__():
    """
    Test method __str__ of class All
    """
    all_instance_1 = All(True)
    assert all_instance_1.__str__() == "All[value=True]"
    assert str(all_instance_1) == "All[value=True]"


# Generated at 2022-06-24 00:35:41.974438
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(4)) == Min(2)


# Generated at 2022-06-24 00:35:45.323596
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'
    assert str(Sum(13)) == 'Sum[value=13]'
    assert str(Sum(4)) == 'Sum[value=4]'


# Generated at 2022-06-24 00:35:46.817576
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(0)) == 'Min[value=0]'


# Generated at 2022-06-24 00:35:51.343766
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)
    assert not Semigroup(1) == 1


# Generated at 2022-06-24 00:35:52.579746
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)



# Generated at 2022-06-24 00:35:53.868243
# Unit test for constructor of class One
def test_One():
    actual = One(1)
    expected = One(1)

    assert actual == expected


# Generated at 2022-06-24 00:35:54.812355
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-24 00:35:56.470088
# Unit test for method __str__ of class Max
def test_Max___str__():
    obj = Max(5)
    assert str(obj) == 'Max[value=5]'



# Generated at 2022-06-24 00:35:57.644866
# Unit test for constructor of class One
def test_One():  # pragma: no cover
    one = One(True)
    assert one.value

# Generated at 2022-06-24 00:36:00.351841
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    """
    :returns: pass or fail results of test
    :rtype: String

    output:
    "Sum[value=1]"
    """
    return Sum.neutral().__str__()


# Generated at 2022-06-24 00:36:01.934525
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(1).__str__() == "One[value=1]"


# Generated at 2022-06-24 00:36:05.037679
# Unit test for constructor of class One
def test_One():
    result = One(True)
    expected = One(True)

    assert result == expected


# Generated at 2022-06-24 00:36:06.350834
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)


# Generated at 2022-06-24 00:36:12.443102
# Unit test for method concat of class All
def test_All_concat():
    all1 = All(True)
    all2 = All(True)
    assert all1.concat(all2).value == True
    all1 = All(True)
    all2 = All(False)
    assert all1.concat(all2).value == False
    all1 = All(False)
    all2 = All(True)
    assert all1.concat(all2).value == False
    all1 = All(False)
    all2 = All(False)
    assert all1.concat(all2).value == False


# Generated at 2022-06-24 00:36:14.240364
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    assert Last(1).__str__() == 'Last[value={}]'.format(1)



# Generated at 2022-06-24 00:36:15.486144
# Unit test for constructor of class Sum
def test_Sum():
    s = Sum(1)
    assert s.value == 1
    assert s.concat(Sum(2)).value == 3


# Generated at 2022-06-24 00:36:20.402934
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-24 00:36:24.881352
# Unit test for method concat of class All
def test_All_concat():
    _f1 = All(True)
    _f2 = All(True)
    _f3 = All(False)
    assert _f1.concat(_f2) == _f2.concat(_f1)
    assert _f1.concat(_f3) == _f3
    assert _f3.concat(_f1) == _f3



# Generated at 2022-06-24 00:36:27.781404
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert Sum(3) == Sum(3)
    assert Sum(4) == Sum(4)
    assert Sum(4) != Sum(5)


# Generated at 2022-06-24 00:36:29.323617
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'


# Generated at 2022-06-24 00:36:33.981236
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)).value == False
    assert All(True).concat(All(True)).value == True
    assert All(False).concat(All(True)).value == False
    assert All(False).concat(All(False)).value == False


# Generated at 2022-06-24 00:36:36.621156
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x) == 1
    assert All(True).fold(lambda x: x)
    assert One(False).fold(lambda x: x)
    assert First(False).fold(lambda x: x)
    assert Last(False).fold(lambda x: x)
    assert Map({"key": Sum(1)}).fold(lambda x: x) == {"key": 1}


# Generated at 2022-06-24 00:36:38.265308
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(1) != Map(1)



# Generated at 2022-06-24 00:36:43.407388
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) != All(True)
    assert All(True).value
    assert not All(False).value

    # Calling neutral() without argument is ok
    assert All.neutral() == All(True)
    # Calling neutral() with argument raises TypeError
    with pytest.raises(TypeError):
        All.neutral(False) == All(False)
    # Calling .neutral() on All is an error
    with pytest.raises(TypeError):
        All(True).neutral() == All(True)


# Generated at 2022-06-24 00:36:45.690513
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert(str(Map({'a': Sum(100)})) == 'Map[value={\'a\': Sum[value=100]}]')

# Generated at 2022-06-24 00:36:47.968316
# Unit test for constructor of class First
def test_First():
    semigroup_first = First(5)

    assert semigroup_first.value == 5



# Generated at 2022-06-24 00:36:51.751448
# Unit test for constructor of class Min
def test_Min():
    from pytest import raises
    with raises(TypeError):
        Min(None)
# Test for factory functions

# Generated at 2022-06-24 00:36:54.944522
# Unit test for constructor of class Map
def test_Map():
    assert Map({1: Sum(1), 2: Sum(2)}).value == {1: Sum(1), 2: Sum(2)}
    assert Map({1: Sum(1), 2: Sum(2)}) == Map({1: Sum(1), 2: Sum(2)})

# Generated at 2022-06-24 00:36:58.839074
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)



# Generated at 2022-06-24 00:37:00.317035
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(0) == Semigroup(0)



# Generated at 2022-06-24 00:37:03.742885
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value
    assert All(True).concat(All(False)).value is False
    assert All(False).concat(All(True)).value is False
    assert All(False).concat(All(False)).value is False


# Generated at 2022-06-24 00:37:05.265868
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(42)) == "Sum[value=42]"



# Generated at 2022-06-24 00:37:11.791110
# Unit test for method concat of class Map
def test_Map_concat():
    map_1 = Map({"k1": Sum(1), "k2": Sum(2)})
    map_2 = Map({"k1": Sum(3), "k2": Sum(4)})

    result = map_1.concat(map_2)

    assert result.value["k1"].value == Sum(4).value
    assert result.value["k2"].value == Sum(6).value

# Generated at 2022-06-24 00:37:21.998078
# Unit test for constructor of class Semigroup
def test_Semigroup():
    s = Sum(5)
    assert s.value == 5
    assert str(s) == 'Sum[value=5]'
    a = All(True)
    assert a.value == True
    assert str(a) == 'All[value=True]'
    o = One(True)
    assert o.value == True
    assert str(o) == 'One[value=True]'
    f = First(1)
    assert f.value == 1
    assert str(f) == 'Fist[value=1]'
    l = Last(1)
    assert l.value == 1
    assert str(l) == 'Last[value=1]'
    m = Map({1: Sum(1), 2: Sum(2)})
    assert m.value == {1: Sum(1), 2: Sum(2)}

# Generated at 2022-06-24 00:37:25.223420
# Unit test for constructor of class Sum
def test_Sum():
    sum_ = Sum(10)
    assert sum_.value == 10



# Generated at 2022-06-24 00:37:34.083420
# Unit test for constructor of class Map
def test_Map():
    # 'm' is a map that contains the values of different types.
    m = Map({'a': Max(100), 'b': Min(5.5), 'c': All(True), 'd': One(True), 'e': First(False), 'f': Last(True)})
    m2 = Map({'a': Max(10), 'b': Min(55), 'c': All(False), 'd': One(False), 'e': First(False), 'f': Last(True)})
    print(m.concat(m2))
    assert m.concat(m2) == Map({'a': Max(100), 'b': Min(5.5), 'c': All(False), 'd': One(True), 'e': First(False), 'f': Last(True)})

# Generated at 2022-06-24 00:37:35.338881
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)



# Generated at 2022-06-24 00:37:37.315856
# Unit test for constructor of class One
def test_One():
    assert One(1).value == 1
    assert One(False).value == False
    assert One("Hello").value == "Hello"
    assert One("True").value == "True"
    assert One("False").value == "False"
    assert One("1").value == "1"
    assert One("0").value == "0"



# Generated at 2022-06-24 00:37:43.844478
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(10)) == Max(10)
    assert Max(10).concat(Max(5)) == Max(10)
    assert Max(5).concat(Max(5)) == Max(5)
    assert Max(10).concat(Max(10)) == Max(10)

#test_Max_concat()


# Generated at 2022-06-24 00:37:45.931804
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1
    assert Sum(2).value == 2


# Generated at 2022-06-24 00:37:48.924672
# Unit test for constructor of class Semigroup
def test_Semigroup():
    a = Semigroup(1)
    b = Semigroup(1)
    assert a == b
    assert a.value == 1
    assert b.value == 1


# Generated at 2022-06-24 00:37:50.297107
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(2 + 3) == First(5)


# Generated at 2022-06-24 00:37:51.358860
# Unit test for constructor of class Min
def test_Min():
    min = Min(1)
    assert min == Min(1)



# Generated at 2022-06-24 00:37:52.410427
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-24 00:37:53.578317
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == "Last[value=1]"


# Generated at 2022-06-24 00:37:58.598520
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1).value == 1
    assert Semigroup(2).value == 2
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(2) != Semigroup(1)


# Generated at 2022-06-24 00:37:59.913804
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(3).value == 3
#

# Generated at 2022-06-24 00:38:07.335914
# Unit test for method concat of class First
def test_First_concat():
    assert First("first").concat(First("second")) == First("first")
    assert First("second").concat(First("first")) == First("second")
    assert First("first").concat("second") == First("first")
    assert "first".concat(First("second")) == First("second")


# Generated at 2022-06-24 00:38:08.952645
# Unit test for constructor of class Sum
def test_Sum():
    sum = Sum(1)
    assert type(sum) == Sum
    assert sum.value == 1


# Generated at 2022-06-24 00:38:10.286482
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(4)) == 'Fist[value=4]'

# Generated at 2022-06-24 00:38:11.949550
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-24 00:38:15.965271
# Unit test for constructor of class Max
def test_Max():
    """
    :returns: test success or not
    :rtype: bool
    """

    return Max(10) == Max(10)



# Generated at 2022-06-24 00:38:19.050532
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)


# Generated at 2022-06-24 00:38:22.494588
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value == True
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(False)).value == False


# Generated at 2022-06-24 00:38:27.596321
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True) != All(False)
    assert All(True).concat(All(True))
    assert All(False).concat(All(True))
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:38:32.154945
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:38:33.897090
# Unit test for constructor of class Last
def test_Last():
    assert Last(0).value == 0
    assert Last(1).value == 1
    assert Last('').value == ''
    assert Last([1]).value == [1]


# Generated at 2022-06-24 00:38:35.820406
# Unit test for method concat of class One
def test_One_concat():
    one1 = One(1)
    one2 = One(2)
    assert one1.concat(one2) == One(1)


# Generated at 2022-06-24 00:38:39.358614
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-24 00:38:41.104289
# Unit test for method __str__ of class Max
def test_Max___str__():
    m = Max(10)
    assert 'Max[value=10]' == str(m)

# Generated at 2022-06-24 00:38:41.923249
# Unit test for constructor of class Semigroup
def test_Semigroup():
    with raises(NotImplementedError):
        Semigroup(1)



# Generated at 2022-06-24 00:38:43.555703
# Unit test for method concat of class First
def test_First_concat():
    first = First(1)
    second = First(2)
    assert first.concat(second) == First(1)


# Generated at 2022-06-24 00:38:48.447016
# Unit test for constructor of class Last
def test_Last():
    l = Last(1), Last(4), Last(8), Last(1), Last(23), Last(4), Last(8), Last(12)
    l = reduce(lambda final, x: x.concat(final), l, Last.neutral())
    assert l == Last(12)


# Generated at 2022-06-24 00:38:50.428576
# Unit test for method __str__ of class Min
def test_Min___str__():
    m = Min(1)
    assert m.__str__() == 'Min[value=1]'


# Generated at 2022-06-24 00:38:52.853513
# Unit test for constructor of class Max
def test_Max(): # pragma: no cover
    assert Max(1).value == 1


# Generated at 2022-06-24 00:38:56.547381
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First(None)) == 'Fist[value=None]'
    assert str(First('One')) == 'Fist[value=One]'
    assert str(First(True)) == 'Fist[value=True]'


# Generated at 2022-06-24 00:39:04.539513
# Unit test for constructor of class One
def test_One():
    """
    Unit test for constructor of class One
    """
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert isinstance(One(False), One)
    assert not isinstance(One(False), All)
    assert One(False).__class__ == One
    assert One(False).__class__ != All
    assert One(False).value == False
    assert isinstance(One(False).value, bool)



# Generated at 2022-06-24 00:39:09.643830
# Unit test for method concat of class First
def test_First_concat():
    assert str(First(1).concat(First(2))) == "Fist[value=1]"
    assert str(First(1).concat(First(2)).concat(First(3))) == "Fist[value=1]"



# Generated at 2022-06-24 00:39:14.085291
# Unit test for constructor of class Map
def test_Map():
    semigroup = Map({'a': Sum(1), 'b': Sum(2)})
    assert semigroup.value == {'a': Sum(1), 'b': Sum(2)}


# Generated at 2022-06-24 00:39:18.890032
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(True) == One(True)
    assert First(True) == First(True)
    assert Last(True) == Last(True)
    assert Map({First(1): First(True)}) == Map({First(1): First(True)})
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)


# Generated at 2022-06-24 00:39:21.465394
# Unit test for method concat of class First
def test_First_concat():
    first = First(2)
    last = Last(1)
    assert first.concat(last) == First(2)



# Generated at 2022-06-24 00:39:24.356042
# Unit test for method concat of class Min
def test_Min_concat():
    min1 = Min(4)
    min2 = Min(5)
    min_ = min1.concat(min2)
    assert min_ == Min(4)


# Generated at 2022-06-24 00:39:27.136380
# Unit test for method __str__ of class Last
def test_Last___str__():
    last = Last(3)
    assert str(last) == 'Last[value=3]'



# Generated at 2022-06-24 00:39:32.189316
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    Test for __eq__ function
    """
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum("test") == Sum("test")
    assert All(True) == All(True)
    assert All(False) != All(True)
    assert One(True) == One(True)
    assert One(False) != One(True)
    assert First("test") == First("test")
    assert First("test") != First("wrong_test")
    assert Last("test") == Last("test")
    assert Last("test") != Last("wrong_test")
    assert Max(10) == Max(10)
    assert Max(-10) != Max(10)
    assert Min(10) == Min(10)
    assert Min(-10) != Min(10)



# Generated at 2022-06-24 00:39:33.367590
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)).value == 2


# Generated at 2022-06-24 00:39:38.141227
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert (Sum(5).concat(Sum(3)) == Sum(8))



# Generated at 2022-06-24 00:39:42.098621
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(True)).value == True
    assert One(False).concat(One(False)).value == False
    assert One(True).concat(One(True)).value == True



# Generated at 2022-06-24 00:39:43.267639
# Unit test for constructor of class Min
def test_Min():
    assert Min(58).value == 58


# Generated at 2022-06-24 00:39:44.808698
# Unit test for constructor of class Min
def test_Min():  # pragma: no cover
    assert Min(3) == Min(3)

# Generated at 2022-06-24 00:39:49.227022
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == "Max[value=1]"


# Generated at 2022-06-24 00:39:53.691557
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(10) == Sum(10)
    assert Sum(10) != Sum(100)



# Generated at 2022-06-24 00:39:56.358715
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup.neutral().fold(lambda x: x is None)



# Generated at 2022-06-24 00:40:00.315363
# Unit test for method __str__ of class Map
def test_Map___str__(): # pragma: no cover
    assert str(Map({'a': First(1), 'b': First(2)})) == 'Map[value={\'a\': Fist[value=1], \'b\': Fist[value=2]}]'


# Generated at 2022-06-24 00:40:07.983133
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    sum = Sum(1)
    assert isinstance(sum, Sum)
    assert isinstance(sum, Semigroup)
    assert isinstance(sum, object)
    assert isinstance(sum.value, int)
    assert isinstance(Sum.neutral_element, int)
    assert repr(sum) == 'Sum[value={}]'.format(sum.value)
    assert str(sum) == 'Sum[value={}]'.format(sum.value)



# Generated at 2022-06-24 00:40:11.719693
# Unit test for method concat of class First
def test_First_concat():
    first = First(1)
    second = First(2)
    assert first.concat(second) == first


# Generated at 2022-06-24 00:40:15.377926
# Unit test for constructor of class One
def test_One():  # pragma: no cover
    assert One(4) == One(4)
    assert One(4).value == 4
    assert str(One(4)) == 'One[value=4]'


# Generated at 2022-06-24 00:40:16.617055
# Unit test for constructor of class All
def test_All():
    value = True
    assert All(value) == value


# Generated at 2022-06-24 00:40:18.206210
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(0)) == 'Sum[value=0]'



# Generated at 2022-06-24 00:40:19.160802
# Unit test for constructor of class One
def test_One():
    assert One(10).value == 10


# Generated at 2022-06-24 00:40:20.310911
# Unit test for constructor of class Semigroup
def test_Semigroup():
    s = Semigroup(1)
    assert s.value == 1


# Generated at 2022-06-24 00:40:26.006125
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).concat(One(0)) == One(1)
    assert One(0).concat(One(1)) == One(1)
    assert One(0).concat(One(0)) == One(0)
    assert One(1).concat(One(1)) == One(1)
    assert One(None).concat(One(False)) == One(False)
    assert One(None).concat(One(None)) == One(None)
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-24 00:40:27.134327
# Unit test for constructor of class Min
def test_Min():
    expected = Min(1)
    actual = Min(1)
    assert expected == actual


# Generated at 2022-06-24 00:40:29.677117
# Unit test for constructor of class All
def test_All():
    instance = All(True)

    assert isinstance(instance, All)
    assert instance.value is True



# Generated at 2022-06-24 00:40:34.356228
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1).value == 1
    assert Semigroup(1.0).value == 1.0
    assert Semigroup('test').value == 'test'
    assert Semigroup(None).value == None



# Generated at 2022-06-24 00:40:40.268331
# Unit test for method concat of class Sum
def test_Sum_concat():
    sg = Sum(1)
    sg2 = Sum(2)
    assert sg.concat(sg2) == Sum(3)
    sg = Sum(1)
    sg2 = Sum(0)
    assert sg.concat(sg2) == Sum(1)


# Generated at 2022-06-24 00:40:43.117299
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(10).value == 10
    assert Sum(-100).value == -100
    assert Sum(120).value == 120


# Generated at 2022-06-24 00:40:47.663563
# Unit test for constructor of class Max
def test_Max():
    pass

    # def test_Sum():
    #     assert Sum(1).concat(Sum(5)).value == 6
    #     assert Sum(5).concat(Sum(1)).value == 6
    #     assert Sum(0).concat(Sum(0)).value == 0



# Generated at 2022-06-24 00:40:50.380116
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert Last("value").__str__() == 'Last[value=value]'


# Generated at 2022-06-24 00:40:53.120716
# Unit test for method __str__ of class First
def test_First___str__():
    """
    Test __str__ method of class First.
    """
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-24 00:40:56.182787
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First("SomeString")) == "Fist[value=SomeString]"



# Generated at 2022-06-24 00:40:59.749949
# Unit test for method __str__ of class First
def test_First___str__():
    semigroup = First(1)
    result = str(semigroup)
    assert result == 'Fist[value=1]'



# Generated at 2022-06-24 00:41:01.043293
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'

# Generated at 2022-06-24 00:41:06.963209
# Unit test for method concat of class Map
def test_Map_concat():  # pragma: no cover
    # GIVEN
    semigroup1 = Map({'a': First('A'), 'b': First('B')})
    semigroup2 = Map({'a': First('A'), 'b': First('B')})

    assert semigroup1.concat(semigroup2).value['a'].value == 'A'
    assert semigroup1.concat(semigroup2).value['b'].value == 'B'


# Generated at 2022-06-24 00:41:08.644344
# Unit test for method __str__ of class Sum
def test_Sum___str__():   # pragma: no cover
    print(Sum(10))
    print(Sum(0))


# Generated at 2022-06-24 00:41:18.475232
# Unit test for method concat of class One
def test_One_concat():
    assert One('a').concat(One('b')) == One('a')
    assert One('a').concat(One('')) == One('a')
    assert One('a').concat(One(False)) == One('a')
    assert One('').concat(One('')) == One('')
    assert One('a').concat(One(True)) == One(True)
    assert One('').concat(One(False)) == One(False)
    assert One('').concat(One(True)) == One(True)
    assert One(False).concat(One(True)) == One(False)
    assert One('a').concat(One('a')) == One('a')


# Generated at 2022-06-24 00:41:21.841328
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    # Set up
    s = Sum(100)
    # Exercise
    actual = str(s)

    # Verify
    assert 'Sum[value=100]' == actual



# Generated at 2022-06-24 00:41:24.413244
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert repr(Max(2)) == 'Max[value=2]'


# Generated at 2022-06-24 00:41:26.473768
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-24 00:41:28.089716
# Unit test for method __str__ of class All
def test_All___str__():
    assert All(True).__str__() == 'All[value=True]'
    assert All(False).__str__() == 'All[value=False]'



# Generated at 2022-06-24 00:41:32.483390
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:41:34.192121
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
