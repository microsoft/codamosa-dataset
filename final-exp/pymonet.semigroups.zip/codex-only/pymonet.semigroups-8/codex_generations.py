

# Generated at 2022-06-24 00:31:38.386956
# Unit test for constructor of class Map
def test_Map():
    assert Map({1: Sum(2), 2: Max(1)}).value.get(1).value == Sum(2).value


# Generated at 2022-06-24 00:31:42.473561
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(0) == Sum.neutral()
#unit test for constructor of class All

# Generated at 2022-06-24 00:31:47.742504
# Unit test for constructor of class Map
def test_Map():
    map = Map({
        'a': Sum.neutral(),
        'b': One.neutral(),
    })

    assert map.value == {
        'a': Sum(0),
        'b': One(False),
    }


# Generated at 2022-06-24 00:31:50.019282
# Unit test for constructor of class Map
def test_Map():
    # WHEN
    map_ = Map({str : Sum(1), int : Sum(2)})

    # THEN
    assert isinstance(map_, Map)


############################################################

# Generated at 2022-06-24 00:31:51.985560
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(1) != Max(2)


# Generated at 2022-06-24 00:31:56.938331
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)


# Generated at 2022-06-24 00:31:59.380447
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x + 1) == 2
    assert First(1).fold(lambda x: x - 1) == 0
    assert All(True).fold(lambda x: not x) == False



# Generated at 2022-06-24 00:32:01.021859
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)



# Generated at 2022-06-24 00:32:02.821150
# Unit test for constructor of class Last
def test_Last():
    res = Last(True)
    assert res.value == True
    res = Last(False)
    assert res.value == False


# Generated at 2022-06-24 00:32:05.096397
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'



# Generated at 2022-06-24 00:32:07.215380
# Unit test for constructor of class Last
def test_Last():
    last = Last(8)
    assert last.value == 8
    assert last == Last(8)
    assert last != Last(9)



# Generated at 2022-06-24 00:32:12.628843
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-24 00:32:17.926101
# Unit test for constructor of class Map
def test_Map():
    monoid = Map({'a': Sum(5), 'b': Sum(9)})
    assert isinstance(monoid, Map)


# Generated at 2022-06-24 00:32:19.269807
# Unit test for constructor of class Min
def test_Min():
    instance = Min(5)
    assert isinstance(instance, Min)


# Generated at 2022-06-24 00:32:21.125897
# Unit test for method __str__ of class All
def test_All___str__(): # pragma: no cover
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-24 00:32:23.941025
# Unit test for constructor of class All
def test_All():
    """
    :returns: True if test passed
    :rtype: bool
    """

    return All(True).value is True and All(False).value is False


# Generated at 2022-06-24 00:32:34.899169
# Unit test for method __str__ of class Map
def test_Map___str__():

    assert str(Map({1: Sum(1), 2: Sum(2)})) == 'Map[value={1: Sum[value=1], 2: Sum[value=2]}]'
    assert str(Map({1: All(True), 2: All(False)})) == 'Map[value={1: All[value=True], 2: All[value=False]}]'
    assert str(Map({1: One(True), 2: One(False)})) == 'Map[value={1: One[value=True], 2: One[value=False]}]'
    assert str(Map({1: First(1), 2: First(2)})) == 'Map[value={1: Fist[value=1], 2: Fist[value=2]}]'

# Generated at 2022-06-24 00:32:37.796824
# Unit test for constructor of class Last
def test_Last():
    l = Last(5)
    l1 = Last(6)
    assert l.value == 5
    assert l1.value == 6


# Generated at 2022-06-24 00:32:38.809665
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True


# Generated at 2022-06-24 00:32:45.911241
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    """
    In mathematics, a semigroup is an algebraic structure consisting of a set
    together with an associative binary operation.
    A semigroup generalizes a monoid in that there might not exist
    an identity element. It also (originally) generalized a group (a monoid with
    all inverses) to a type where every element did not have to have an inverse,
     this the name semigroup.
    :return:
    """
    sum_semigroup = Sum(3)  # 3 = Sum.neutral_element = 1
    assert sum_semigroup == Sum(3)
    assert sum_semigroup.value == 3
    assert sum_semigroup.fold(lambda x: x) == 3
    assert isinstance(sum_semigroup, Sum)
    assert isinstance(sum_semigroup, Semigroup)


# Generated at 2022-06-24 00:32:56.037557
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1) == Min(1).concat(Min(1))
    assert Min(1) == Min(1).concat(Min(2))
    assert Min(2) == Min(2).concat(Min(1))
    assert Min(3) == Min(3).concat(Min(4))
    assert Min(4) == Min(4).concat(Min(3))
    assert Min(-Inf) == Min(-Inf).concat(Min(-Inf))
    assert Min(-Inf) == Min(-Inf).concat(Min(0))
    assert Min(-Inf) == Min(-Inf).concat(Min(Inf))
    assert Min(-Inf) == Min(-Inf).concat(Min(-0.0001))
    assert Min(-Inf) == Min(-Inf).concat(Min(0.0001))


# Generated at 2022-06-24 00:32:58.344022
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-24 00:32:59.926741
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-24 00:33:04.321234
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert (Sum(2).fold(lambda x: x + 2) == 4)
    assert (Max(2).fold(lambda x: x + 2) == 4)
    assert (Map({1: Last(1)}).fold(lambda x: {1: x[1].value}) == {1: 1})



# Generated at 2022-06-24 00:33:08.643249
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False).concat(All(True)) == All(False)
    assert All(True).concat(All(True)) == All(True)


# Generated at 2022-06-24 00:33:11.188814
# Unit test for method __str__ of class Max
def test_Max___str__():
    value = 42
    m = Max(value)
    print(m)


# Generated at 2022-06-24 00:33:13.727680
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'foo': Sum(1), 'bar': One(True)})) == "Map[value={'foo': Sum[value=1], 'bar': All[value=True]}]"


# Generated at 2022-06-24 00:33:16.946797
# Unit test for method __str__ of class First
def test_First___str__():
    a = First(1)
    b = First('a')
    c = First(3.14)

    assert(str(a) == 'Fist[value=1]')
    assert(str(b) == 'Fist[value=a]')
    assert(str(c) == 'Fist[value=3.14]')



# Generated at 2022-06-24 00:33:17.817685
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)


# Generated at 2022-06-24 00:33:21.784702
# Unit test for constructor of class All
def test_All():
    assert All(1).value == True
    assert All(0).value == False
    assert All(False).value == False
    assert All([1,2]).value == True
    assert All([]).value == False
    assert All({"a":1,"b":2}).value == True
    assert All({}).value == False


# Generated at 2022-06-24 00:33:23.289514
# Unit test for constructor of class Map
def test_Map():
    a = Map({'a': Sum(2), 'b': All(False)})
    assert a.value.get('a').value == 2
    assert a.value.get('b').value is False

# Generated at 2022-06-24 00:33:27.522011
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(1)).value == 2
    assert Sum(1).concat(Sum(2)).value == 3
    assert Sum(1).concat(Sum(42)).value == 43



# Generated at 2022-06-24 00:33:38.552883
# Unit test for constructor of class Min
def test_Min():
    Min_positive_0 = Min(0)
    Min_positive_1 = Min(1)
    Min_positive_2 = Min(2)
    Min_negative_0 = Min(-0)
    Min_negative_1 = Min(-1)
    Min_negative_2 = Min(-2)
    Min_positive_inf = Min(float("inf"))
    Min_negative_inf = Min(-float("inf"))

    assert Min_positive_0.value == 0
    assert Min_positive_1.value == 1
    assert Min_positive_2.value == 2
    assert Min_negative_0.value == 0
    assert Min_negative_1.value == -1
    assert Min_negative_2.value == -2
    assert Min_positive_inf.value == float("inf")

# Generated at 2022-06-24 00:33:39.909870
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1)}) == Map({'a': Sum(1)})



# Generated at 2022-06-24 00:33:40.855984
# Unit test for constructor of class One
def test_One():
    One(True)

# Generated at 2022-06-24 00:33:44.076788
# Unit test for constructor of class First
def test_First():
    assert First([1, 2]).value == [1, 2]
    assert First(1).value == 1
    assert First(True).value == True


# Generated at 2022-06-24 00:33:46.584664
# Unit test for method __str__ of class First
def test_First___str__():
    actual = str(First(2))
    expected = "Fist[value=2]"
    assert actual == expected


# Generated at 2022-06-24 00:33:47.447270
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-24 00:33:53.718870
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)).value is True
    assert One(True).concat(One(False)).value is True
    assert One(False).concat(One(True)).value is True
    assert One(False).concat(One(False)).value is False
    assert One(True).concat(One(None)).value is True
    assert One(False).concat(One(None)).value is False


# Generated at 2022-06-24 00:33:59.713361
# Unit test for method concat of class First
def test_First_concat():
    f1 = First(1)
    f2 = First(2)
    f3 = f1.concat(f2)
    f4 = f2.concat(f1)
    assert f3.value == 1
    assert f4.value == 2


# Generated at 2022-06-24 00:34:05.867863
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Min(2)) == Sum(3)
    assert Sum(1).concat(Min(3)) == Sum(4)
    assert Sum(1).concat(Min(2)).concat(Sum(2)) == Sum(5)
    assert Sum(1).concat(Max(2)).concat(Sum(2)) == Sum(5)



# Generated at 2022-06-24 00:34:09.416558
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(5)) == "Max[value=5]"
    assert str(Max(-5)) == "Max[value=-5]"
    assert str(Max(-5.5)) == "Max[value=-5.5]"


# Generated at 2022-06-24 00:34:11.124269
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(True).__str__() == 'One[value=True]'



# Generated at 2022-06-24 00:34:21.365426
# Unit test for method concat of class All
def test_All_concat():
    all_true = All(True).concat(All(True))
    assert all_true.concat(All(True)).value == True
    assert all_true.concat(All(False)).value == False
    assert all_true.concat(All(False)).concat(All(True)).value == False
    assert all_true.concat(All(False)).concat(All(False)).value == False

    all_false = All(False).concat(All(False))
    assert all_false.concat(All(True)).value == False
    assert all_false.concat(All(False)).value == False
    assert all_false.concat(All(False)).concat(All(True)).value == False
    assert all_false.concat(All(False)).concat(All(False)).value == False

   

# Generated at 2022-06-24 00:34:25.029374
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-24 00:34:27.519623
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'key': Sum(2), 'value': Sum(3)})) == "Map[value={'key': Sum[value=2], 'value': Sum[value=3]}]"


# Generated at 2022-06-24 00:34:28.619556
# Unit test for constructor of class One
def test_One():
    assert One(False)
    assert not One(True)


# Generated at 2022-06-24 00:34:30.031361
# Unit test for constructor of class Sum
def test_Sum():
    sum = Sum(1)
    assert sum.value == 1
    assert sum.neutral_element == 0



# Generated at 2022-06-24 00:34:31.897941
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(1)) == "Sum[value=1]"
    assert str(Sum(0)) == "Sum[value=0]"
    assert str(Sum(-1)) == "Sum[value=-1]"



# Generated at 2022-06-24 00:34:34.354756
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)).value == 3
    assert Sum(2).concat(Sum(2)).value == 4
    assert Sum(1).concat(Sum(0)).value == 1
    assert Sum(0).concat(Sum(1)).value == 1
    assert Sum(0).concat(Sum(0)).value == 0


# Generated at 2022-06-24 00:34:36.371174
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    value = 1
    assert str(Sum(value)) == 'Sum[value=' + str(value) + ']'


# Generated at 2022-06-24 00:34:37.620647
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-24 00:34:39.882167
# Unit test for constructor of class All
def test_All():  # pragma: no cover
    true_semigroup = All(True)
    assert true_semigroup == All(True)



# Generated at 2022-06-24 00:34:42.789520
# Unit test for constructor of class Map
def test_Map():
    _dict = {
        1: Sum(1),
        'key': All(True)
    }
    assert Map(_dict).value == _dict



# Generated at 2022-06-24 00:34:45.469583
# Unit test for method concat of class First
def test_First_concat():
    first = First(1)
    assert first.concat(first).value == 1
    assert isinstance(first.concat(first), First)


# Generated at 2022-06-24 00:34:48.627076
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'foo': Min(3), 'bar': Max(7)}).concat(Map({'foo': Min(9), 'bar': Max(8)})) \
        == Map({'foo': Min(3), 'bar': Max(8)})

# Generated at 2022-06-24 00:34:49.789530
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(None)) == 'Last[value=None]'



# Generated at 2022-06-24 00:34:50.980225
# Unit test for constructor of class One
def test_One():
    one = One('something')
    assert one.value == 'something'

# Generated at 2022-06-24 00:34:52.468140
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-24 00:34:57.462462
# Unit test for method concat of class Sum
def test_Sum_concat():
    a = Sum(2)
    b = Sum(1)
    assert a.concat(b).value == 3

    a = Sum(-2)
    b = Sum(1)
    assert a.concat(b).value == -1

    a = Sum(-2)
    b = Sum(-5)
    assert a.concat(b).value == -7


# Generated at 2022-06-24 00:35:00.443782
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    """
    test_Sum___str__(): Test the method __str__ method in the class Sum
    """
    # assert True is True
    assert Sum(1).__str__() == "Sum[value=1]"
    assert Sum(0).__str__() == "Sum[value=0]"

# Generated at 2022-06-24 00:35:01.497073
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-24 00:35:06.084382
# Unit test for method concat of class One
def test_One_concat():
    assert (One(True).concat(One(True)) == One(True))
    assert (One(True).concat(One(False)) == One(True))
    assert (One(False).concat(One(True)) == One(True))
    assert (One(False).concat(One(False)) == One(False))


# Generated at 2022-06-24 00:35:10.867862
# Unit test for constructor of class Map
def test_Map():  # pragma: no cover
    test_map = Map({
        "one": Sum(1),
        "two": Sum(2),
        "three": Sum(3)
    })
    assert test_map.value == {
        "one": Sum(1),
        "two": Sum(2),
        "three": Sum(3)
    }


# Generated at 2022-06-24 00:35:13.384534
# Unit test for method concat of class All
def test_All_concat():
    assert All(False).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:35:19.014641
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last('1').concat(Last('2')) == Last('2')
    assert Last('1').concat(Last(1)) == Last(1)
    assert Last('1').concat(Last({})) == Last({})


# Generated at 2022-06-24 00:35:22.514931
# Unit test for constructor of class First
def test_First():
    foo = First(3)
    assert foo.value == 3


# Generated at 2022-06-24 00:35:32.640118
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():  # pragma: no cover
    assert All(True) == All(True)
    assert All(True) != All(False)

    assert First("a") == First("a")
    assert First("a") != First("b")

    assert Last("a") == Last("a")
    assert Last("a") != Last("b")

    assert Map({1: Sum(1), 2: Sum(2)}) == Map({1: Sum(1), 2: Sum(2)})
    assert Map({1: Sum(1), 2: Sum(2)}) != Map({1: Sum(1), 2: Sum(3)})

    assert Min(1) == Min(1)
    assert Min(1) != Min(2)

    assert Max(1) == Max(1)
    assert Max(1) != Max(2)

# Unit test

# Generated at 2022-06-24 00:35:37.051277
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert First(1).value == 1

# Unit tests for constructor of class Last

# Generated at 2022-06-24 00:35:42.272477
# Unit test for method concat of class One
def test_One_concat():
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)

# Generated at 2022-06-24 00:35:44.099676
# Unit test for method __str__ of class One
def test_One___str__():
    one = One(False)
    assert str(one) == 'One[value=False]'


# Generated at 2022-06-24 00:35:45.865812
# Unit test for constructor of class Min
def test_Min():
    monoid = Min(1)
    assert monoid == Min(1)


# Generated at 2022-06-24 00:35:47.799928
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert(str(Min(9)) == 'Min[value=9]')



# Generated at 2022-06-24 00:35:50.862295
# Unit test for constructor of class Min
def test_Min():
    # Test to create a Min instance
    value = 2
    min = Min(value)
    assert min.value == value
    assert min.neutral_element == float("inf")


# Generated at 2022-06-24 00:35:52.344781
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False


# Generated at 2022-06-24 00:35:53.408395
# Unit test for constructor of class Last
def test_Last():
    v = Last(1)
    assert v.value == 1


# Generated at 2022-06-24 00:35:54.794482
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)



# Generated at 2022-06-24 00:35:58.314274
# Unit test for method concat of class One
def test_One_concat():

    a = One(True)
    b = One(True)
    c = One(False)

    assert a.concat(b) == One(True)
    assert a.concat(c) == One(True)
    assert c.concat(a) == One(True)



# Generated at 2022-06-24 00:36:01.277326
# Unit test for method concat of class First
def test_First_concat():
    """
    concat method for First class
    """
    first_value = First(1)
    second_value = First(2)
    concated_value = first_value.concat(second_value)
    assert concated_value.value == 1


# Generated at 2022-06-24 00:36:05.222653
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': 1, 'b': 2})) == "Map[value={'a': 1, 'b': 2}]"

# Generated at 2022-06-24 00:36:07.585796
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)



# Generated at 2022-06-24 00:36:09.821236
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == "One[value=True]"
    assert str(One(False)) == "One[value=False]"

# Generated at 2022-06-24 00:36:11.682668
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(False).__str__() == 'One[value=False]'


# Generated at 2022-06-24 00:36:12.854190
# Unit test for constructor of class Sum
def test_Sum():
    A = Sum(2)
    assert A.value == 2


# Generated at 2022-06-24 00:36:14.000901
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(2)) == 'Sum[value=2]'



# Generated at 2022-06-24 00:36:14.870439
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup('value')



# Generated at 2022-06-24 00:36:20.395592
# Unit test for constructor of class Map
def test_Map():
    assert Map({"a": Sum(1), "b": Sum(2)}).value == {"a": Sum(1), "b": Sum(2)}


# Generated at 2022-06-24 00:36:23.224751
# Unit test for constructor of class All
def test_All():
    assert All(False) == All(False)
    assert All(True) == All(True)
    assert All(False) != All(True)
    assert All(True) != All(False)


# Generated at 2022-06-24 00:36:25.134830
# Unit test for method concat of class One
def test_One_concat():
    expected = One(True)
    actual = One(True).concat(One(True))
    assert expected == actual



# Generated at 2022-06-24 00:36:26.771532
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-24 00:36:29.478824
# Unit test for constructor of class Semigroup
def test_Semigroup():
    def f(x):
        return x

    square = Semigroup(f)

    assert square.f == f
    assert square.fold(f) == f



# Generated at 2022-06-24 00:36:32.902405
# Unit test for constructor of class Map
def test_Map():
    assert Map({'foo': Sum(1),'bar': Sum(2)}).value['foo'].value == 1 and Map({'foo': Sum(1),'bar': Sum(2)}).value['bar'].value == 2


# Generated at 2022-06-24 00:36:37.170709
# Unit test for method concat of class All
def test_All_concat():
    """
    Check concat in semigroup All
    """
    assert All(True).concat(All(False)).value is False
    assert All(True).concat(All(True)).value is True
    assert All(False).concat(All(False)).value is False


# Generated at 2022-06-24 00:36:38.985080
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)).value == 2
    assert Max(2).concat(Max(1)).value == 2
    assert Max(1).concat(Max(1)).value == 1


# Generated at 2022-06-24 00:36:40.089666
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(10)) == 'Sum[value=10]'


# Generated at 2022-06-24 00:36:44.649523
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(1)) == First(None)
    assert First(None).concat(First(None)) == First(None)



# Generated at 2022-06-24 00:36:47.919079
# Unit test for method concat of class Max
def test_Max_concat():
    a = Max(1)
    b = Max(2)
    c = a.concat(b)  # returns Max(2)

    assert c.value == 2


# Generated at 2022-06-24 00:36:51.519513
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)


# Generated at 2022-06-24 00:36:53.115868
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert str(Max(5)) == "Max[value=5]"


# Generated at 2022-06-24 00:36:55.229392
# Unit test for constructor of class Last
def test_Last():
    assert Last(5) is not None


# Generated at 2022-06-24 00:36:58.369050
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(0)) == 'Sum[value=0]'



# Generated at 2022-06-24 00:36:59.611687
# Unit test for constructor of class Min
def test_Min():
    x = Min(10)
    assert x.value == 10


# Generated at 2022-06-24 00:37:02.317508
# Unit test for constructor of class Max
def test_Max():
    n1 = Max(3)
    n2 = Max(-4)
    result = n1.concat(n2)
    assert result == Max(3)


# Generated at 2022-06-24 00:37:04.375616
# Unit test for constructor of class Semigroup
def test_Semigroup():
    initial = Semigroup(1)
    assert initial.value == 1


# Generated at 2022-06-24 00:37:05.856448
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(6)) == 'Fist[value=6]'



# Generated at 2022-06-24 00:37:09.105934
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-24 00:37:11.350250
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert Sum(2) == Sum(2)
    assert Sum(2).value == 2
    assert Sum(2).fold(lambda x: x + 2) == 4


# Generated at 2022-06-24 00:37:13.747549
# Unit test for constructor of class Min
def test_Min():
    assert Min(5).value == 5


# Generated at 2022-06-24 00:37:14.570597
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-24 00:37:17.316027
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(10)) == 'Sum[value=10]'


# Generated at 2022-06-24 00:37:18.081081
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)


# Generated at 2022-06-24 00:37:19.110059
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)


# Generated at 2022-06-24 00:37:22.251878
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)


# Generated at 2022-06-24 00:37:25.524353
# Unit test for method __str__ of class One
def test_One___str__():
    value = True
    expected_result = 'One[value=True]'
    actual_result = One(value).__str__()
    assert actual_result == expected_result



# Generated at 2022-06-24 00:37:27.810965
# Unit test for constructor of class First
def test_First():
    a = First()
    assert a.value is None

    b = First(1)
    assert b.value == 1


# Generated at 2022-06-24 00:37:31.303611
# Unit test for method __str__ of class Map
def test_Map___str__():
    """ Unit test for method __str__ of class Map
    """
    assert str(Map({1: Sum(1), 2: Sum(2)})) == "Map[value={1: Sum[value=1], 2: Sum[value=2]}]"  # noqa: E501



# Generated at 2022-06-24 00:37:31.934564
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == "Fist[value=1]"


# Generated at 2022-06-24 00:37:33.444855
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True) == All(False).concat(All(True))


# Generated at 2022-06-24 00:37:37.208734
# Unit test for method concat of class Max
def test_Max_concat():  # pragma: no cover
    assert Max(1).concat(Max(2)).value == 2
    assert Max(1).concat(Max(0)).value == 1
    assert Max(0).concat(Max(1)).value == 1
    assert Max(0).concat(Max(0)).value == 0


# Generated at 2022-06-24 00:37:40.570026
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert isinstance(Max(100).__str__(), str) is True


# Generated at 2022-06-24 00:37:42.800135
# Unit test for constructor of class All
def test_All():
    assert(All(True).value == True)
    assert(All(False).value == False)



# Generated at 2022-06-24 00:37:46.948335
# Unit test for constructor of class One
def test_One():
    assert One(True).value is True
    assert One(False).value is False

    assert One(1).value is True
    assert One(0).value is False


# Generated at 2022-06-24 00:37:52.543455
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    # check if 2 Semigroup instances are equal with one has .neutral() value
    assert (Semigroup(Sum(1)) == Sum.neutral()) is False

    # check if 2 Semigroup instances are equal with .neutral() values
    assert (Sum.neutral() == Sum.neutral()) is True

    # check if 2 Semigroup instances are equal with random values
    assert (Semigroup(Sum(1)) == Sum(1)) is True
    assert (Semigroup(Sum(1)) == Semigroup(Sum(1))) is True
    assert (Sum(1) == Semigroup(Sum(1))) is True



# Generated at 2022-06-24 00:37:54.839742
# Unit test for constructor of class Map
def test_Map():
    map = Map({'a': First(1), 'b': First(2)})
    assert map.value == {'a': First(1), 'b':First(2)}

# Generated at 2022-06-24 00:37:58.750450
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) != All(True)



# Generated at 2022-06-24 00:38:00.930395
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    x = Semigroup(1)
    y = Semigroup(2)
    z = Semigroup(1)
    assert x == z
    assert not(x == y)
    print('Done!')


# Generated at 2022-06-24 00:38:05.622298
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(2)).value == 2


# Generated at 2022-06-24 00:38:07.222013
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    test_semigroup = Semigroup(5)
    assert test_semigroup.fold(lambda a: a + 1) == 6


# Generated at 2022-06-24 00:38:08.950882
# Unit test for method __str__ of class Min
def test_Min___str__():  # pragma: no cover
    assert str(Min(1)) == 'Min[value=1]'



# Generated at 2022-06-24 00:38:12.757606
# Unit test for constructor of class Map
def test_Map(): # pragma: no cover
    input_ = {
        'a': Sum(1),
        'b': Sum(2),
    }
    output = Map(input_)

    assert output is not None
    assert isinstance(output, Map)


# Generated at 2022-06-24 00:38:15.200673
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(True)) == 'Fist[value=True]'



# Generated at 2022-06-24 00:38:18.364533
# Unit test for method concat of class Min
def test_Min_concat():
    expected_value = 2
    Min(4).concat(Min(2)).value == expected_value


# Generated at 2022-06-24 00:38:20.538013
# Unit test for method __str__ of class All
def test_All___str__():
    assert(str(All(True)) == 'All[value=True]')


# Generated at 2022-06-24 00:38:22.637322
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup("a") == Semigroup("a")
    assert not Semigroup("a") == Semigroup("b")


# Generated at 2022-06-24 00:38:25.976011
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(True).__str__() == str(
        'One[value={}]'.format(One(True).value))
    assert One(False).__str__() == str(
        'One[value={}]'.format(One(False).value))


# Generated at 2022-06-24 00:38:28.131662
# Unit test for method __str__ of class Min
def test_Min___str__():
    min1 = Min('asd')
    assert str(min1) == "Min[value=asd]"



# Generated at 2022-06-24 00:38:29.498488
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(2) == Sum(2)


# Generated at 2022-06-24 00:38:33.253945
# Unit test for method concat of class First
def test_First_concat():  # pragma: no cover
    f1 = First(1)
    f2 = First(2)
    f3 = First(3)
    f = f1.concat(f2).concat(f3)
    assert f.value == 1
    assert f == First(1)



# Generated at 2022-06-24 00:38:34.184057
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1


# Generated at 2022-06-24 00:38:36.020196
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True), "Some message"


# Generated at 2022-06-24 00:38:42.989954
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({'a': First(4), 'b': First(2), 'c': First(1), 'd': First(3)})
    m2 = Map({'a': Last(1), 'b': Last(2), 'c': Last(3), 'd': Last(4)})
    assert m1.concat(m2) == Map({'a': Last(1), 'b': Last(2), 'c': Last(3), 'd': Last(4)})



# Generated at 2022-06-24 00:38:44.896139
# Unit test for method __str__ of class Min
def test_Min___str__():
    actual = Min(1).__str__()
    expected = 'Min[value=1]'
    assert actual == expected


# Generated at 2022-06-24 00:38:50.427425
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-24 00:38:55.699226
# Unit test for method concat of class One
def test_One_concat():
    one1 = One(True)
    one2 = One(False)
    assert one1.concat(one2).value == True
    assert one2.concat(one1).value == True
    assert one1.concat(one1).value == True
    assert one2.concat(one2).value == False


# Generated at 2022-06-24 00:38:57.656287
# Unit test for constructor of class All
def test_All():  # pragma: no cover
    assert All(False) == All(All(0).value)
    assert All(True) == All(All(1).value)



# Generated at 2022-06-24 00:38:58.983668
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(2)) == 'Max[value=2]'



# Generated at 2022-06-24 00:39:03.979207
# Unit test for method __str__ of class All
def test_All___str__():
    """
    Method __str__ should return string with value
    """
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"



# Generated at 2022-06-24 00:39:09.562722
# Unit test for method __str__ of class All
def test_All___str__():
    all_1 = All(True)
    assert str(all_1) == 'All[value=True]'

    all_2 = All(False)
    assert str(all_2) == 'All[value=False]'


# Generated at 2022-06-24 00:39:12.577483
# Unit test for constructor of class Max
def test_Max():
    assert str(Max(20)) == 'Max[value=20]'


# Generated at 2022-06-24 00:39:15.427467
# Unit test for constructor of class Semigroup
def test_Semigroup():
    semigroup = Semigroup(value=42)
    assert semigroup.value == 42


# Generated at 2022-06-24 00:39:17.041333
# Unit test for method __str__ of class Last
def test_Last___str__():
    result = Last(1)
    assert str(result) == 'Last[value=1]'



# Generated at 2022-06-24 00:39:18.246832
# Unit test for constructor of class Last
def test_Last():
    assert Last(5).value == 5



# Generated at 2022-06-24 00:39:20.688889
# Unit test for method __str__ of class First
def test_First___str__():
    assert First(1).__str__() == 'Fist[value=1]'


# Generated at 2022-06-24 00:39:23.367122
# Unit test for constructor of class One
def test_One():
    # Creating object of class One
    one = One(True)
    assert one.value == True
    assert one.concat(One(True)).value == True
    assert one.concat(One(False)).value == False

# Generated at 2022-06-24 00:39:25.300775
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1), "Constructor of Semigroup"


# Generated at 2022-06-24 00:39:28.187818
# Unit test for method concat of class Min
def test_Min_concat():
    assert(Min(2).concat(Min(1)) == Min(1))
    assert(Min(1).concat(Min(2)) == Min(1))

# Generated at 2022-06-24 00:39:32.976359
# Unit test for method concat of class One
def test_One_concat():
    one_one = One(True)
    one_two = One(False)
    one_true = one_one.concat(one_two) 
    one_false = one_two.concat(one_one)
    assert(one_true.value == True)
    assert(one_false.value == True)

# Generated at 2022-06-24 00:39:35.062042
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"


# Generated at 2022-06-24 00:39:36.495096
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-24 00:39:37.620139
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-24 00:39:39.176835
# Unit test for method __str__ of class Last
def test_Last___str__():
    last = Last('a')
    assert str(last) == 'Last[value=a]'


# Generated at 2022-06-24 00:39:42.537006
# Unit test for constructor of class Map
def test_Map():
    # test constructor
    d = Map({1: Sum(1), 2: Sum(2)})
    assert d.value[1] == Sum(1)
    assert d.value[2] == Sum(2)


# Generated at 2022-06-24 00:39:47.682500
# Unit test for method concat of class One
def test_One_concat():
    """
    unit test for method concat of class One
    """
    first = One(1)
    second = One(2)
    assert first.concat(second).value == True
    assert second.concat(first).value == True

    first = One(0)
    second = One(2)
    assert first.concat(second).value == True
    assert second.concat(first).value == True
    


# Generated at 2022-06-24 00:39:49.471818
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    one = One([1, 2, 3])
    assert str(one) == 'One[value=[1, 2, 3]]'


# Generated at 2022-06-24 00:39:54.085108
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert(Semigroup(1) == Semigroup(1))
    assert(not Semigroup(1) == Semigroup(2))


# Generated at 2022-06-24 00:39:57.292706
# Unit test for method __str__ of class First
def test_First___str__():
    result = First(1).__str__()
    expected = 'Fist[value=1]'
    assert result == expected


# Generated at 2022-06-24 00:40:00.499403
# Unit test for method __str__ of class Last
def test_Last___str__():
    """
    Unit test for method __str__ of class Last
    """

    assert str(Last(1)) == 'Last[value=1]'



# Generated at 2022-06-24 00:40:02.841859
# Unit test for constructor of class First
def test_First():
    first1 = First(1)
    assert first1.value == 1
    first2 = First(2)
    assert first2.value == 2


# Generated at 2022-06-24 00:40:06.571588
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == "Max[value=1]"
    assert str(Max(None)) == "Max[value=None]"


# Generated at 2022-06-24 00:40:11.071612
# Unit test for method __str__ of class All
def test_All___str__():
    result = str(All(True))
    expected = 'All[value=True]'
    assert result == expected



# Generated at 2022-06-24 00:40:20.746386
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    # Test fold() with Max
    assert Sum(1).fold(lambda x: x * 2) == 2
    assert All(True).fold(lambda x: x * 2) == 2
    assert One(True).fold(lambda x: x * 2) == 2
    assert First('some-value').fold(lambda x: x * 2) == 'somesome-valuesome-value'
    assert Last('some-value').fold(lambda x: x * 2) == 'some-valuesome-value'
    assert Map({'value': Sum(1)}).fold(lambda x: x) == {'value': Sum(1)}
    assert Max(1).fold(lambda x: x * 2) == 2
    assert Min(1).fold(lambda x: x * 2) == 2



# Generated at 2022-06-24 00:40:26.120042
# Unit test for method concat of class All
def test_All_concat():
    all_1 = All(True)
    all_2 = All(True)
    all_3 = All(False)
    assert all_1.concat(all_2).value == all_2.concat(all_1).value == True
    assert all_1.concat(all_3).value == all_3.concat(all_1).value == False
    assert all_2.concat(all_3).value == all_3.concat(all_2).value == False

# Generated at 2022-06-24 00:40:27.661682
# Unit test for constructor of class Max
def test_Max():
    max1 = Max(1)
    assert max1.value == 1


# Generated at 2022-06-24 00:40:34.707376
# Unit test for constructor of class Min
def test_Min():
    instance = Min(1)
    assert isinstance(instance, Min)
    assert isinstance(instance.value, int)
    assert instance.value == 1
    assert (
        str(instance)
        == 'Min[value=1]'
    )


# Generated at 2022-06-24 00:40:36.995829
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Same('a').value == 'a'
    assert isinstance(Same('a').value, str)


# Unit tests for method __eq__ of class Semigroup

# Generated at 2022-06-24 00:40:38.908726
# Unit test for method concat of class Sum
def test_Sum_concat():
    first = Sum(2)
    second = Sum(3)
    assert first.concat(second) == Sum(5)


# Generated at 2022-06-24 00:40:42.991234
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1
    assert First(True).value == True
    assert First('1').value == '1'



# Generated at 2022-06-24 00:40:45.782378
# Unit test for constructor of class All
def test_All():
    assert All(False).value == False
    assert All(True).value == True


# Generated at 2022-06-24 00:40:47.059051
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(42)) == "One[value=42]"


# Generated at 2022-06-24 00:40:50.807205
# Unit test for method concat of class First
def test_First_concat():
    x = First("blah")
    y = First("lol")
    result = x.concat(y)
    expected = First("blah")
    assert result == expected



# Generated at 2022-06-24 00:40:53.208029
# Unit test for constructor of class Last
def test_Last():  # pragma: no cover
    # Given
    last = Last(3)
    # When
    # Then
    assert last.value == 3
    assert str(last) == "Last[value=3]"



# Generated at 2022-06-24 00:40:59.151853
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    test_Semigroup_fold() takes a function fn as parameter,
    and returns a value by applying its parameter to the fn
    """
    assert Sum(10).fold(lambda x: x * x) == 100


# Generated at 2022-06-24 00:41:01.830629
# Unit test for constructor of class Semigroup
def test_Semigroup():
    from nose.tools import assert_equal
    a = Semigroup(1)
    assert_equal(a.value, 1)
    assert_equal(str(a), 'Semigroup[value=1]')

# Generated at 2022-06-24 00:41:06.231769
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)
    assert One(1) == One(True)
    assert One(1) == One(object)
    assert One(1) == One(Semigroup)
    assert One(1) == One(1.0)
    assert One(1) == One(1.0)



# Generated at 2022-06-24 00:41:07.180105
# Unit test for method __str__ of class Last
def test_Last___str__():
    actual = str(Last(1))
    expected = 'Last[value=1]'
    assert actual == expected


# Generated at 2022-06-24 00:41:10.319242
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'
    assert str(Max(2)) == 'Max[value=2]'
    assert str(Max(3)) == 'Max[value=3]'

# Unit Test for method __eq__ of class Max

# Generated at 2022-06-24 00:41:16.990251
# Unit test for method __str__ of class Max
def test_Max___str__():
    _method_name = "__str__"
    _method = getattr(Max(3), _method_name)

    print("--- start test_Map___str__ ---")
    print(Max(3))
    print("--- end test_Map___str__ ---")
    print("\n\n")

    assert _method() == "Max[value=3]"



# Generated at 2022-06-24 00:41:21.692951
# Unit test for constructor of class Max
def test_Max():
    max_1 = Max(1)
    max_2 = Max(2)
    max_3 = Max(-1)

    assert max_1.value == 1
    assert max_2.value == 2
    assert max_3.value == -1


# Generated at 2022-06-24 00:41:23.918426
# Unit test for constructor of class Last
def test_Last():
    with pytest.raises(TypeError):
        Last()


# Generated at 2022-06-24 00:41:24.960504
# Unit test for constructor of class Max
def test_Max(): # pragma: no cover
    assert Max(1) == Max(1)
    assert Max(1) != Max(2)


# Generated at 2022-06-24 00:41:26.196307
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(100)) == "Max[value=100]"

# Generated at 2022-06-24 00:41:27.036529
# Unit test for method __str__ of class One
def test_One___str__():
    result = str(One(True))
    assert "One[value=True]" == result


# Generated at 2022-06-24 00:41:30.723342
# Unit test for constructor of class One
def test_One():
    assert One(True) != All(True)


# Generated at 2022-06-24 00:41:31.972227
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-24 00:41:36.338609
# Unit test for method concat of class Map
def test_Map_concat():
    obj1 = Map({'a': All(True), 'b': All(True)})
    obj2 = Map({'a': All(False), 'c': All(True)})
    print(obj1.concat(obj2))


test_Map_concat()


