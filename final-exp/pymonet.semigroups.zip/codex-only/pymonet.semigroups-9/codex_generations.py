

# Generated at 2022-06-24 00:31:39.514248
# Unit test for method __str__ of class Min
def test_Min___str__():
    # given
    semigroup = Min(1)

    # when
    result = semigroup.__str__()

    # then
    assert result == "Min[value=1]"



# Generated at 2022-06-24 00:31:40.870605
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).__str__() == 'Last[value=1]'



# Generated at 2022-06-24 00:31:45.520535
# Unit test for method concat of class Last
def test_Last_concat():
    a = Last(1)
    b = Last(2)
    c = a.concat(b)
    assert c.value == 2



# Generated at 2022-06-24 00:31:47.342103
# Unit test for constructor of class One
def test_One():
    one = One()
    assert one.value == False


# Generated at 2022-06-24 00:31:49.750300
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last("foo")) == "Last[value=foo]"


# Generated at 2022-06-24 00:31:51.542748
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(2)) == 'Min[value=2]'


# Generated at 2022-06-24 00:31:53.454864
# Unit test for constructor of class Min
def test_Min():
    """
    Unit test of constructor for class Min
    """
    assert Min(3).value == 3


# Generated at 2022-06-24 00:32:00.829047
# Unit test for constructor of class All
def test_All():
    # all1 = All(True)
    # all2 = All(False)
    # all3 = All(True)
    # all4 = All(False)
    # all5 = All(True)
    # assert all1.concat(all2) == All(False)
    # assert all2.concat(all3) == All(False)
    # assert all3.concat(all4) == All(False)
    # assert all4.concat(all5) == All(False)
    # assert all5.concat(all1) == All(True)
    pass

# Generated at 2022-06-24 00:32:01.370085
# Unit test for method __str__ of class Last
def test_Last___str__():
    pass

# Generated at 2022-06-24 00:32:05.600519
# Unit test for method concat of class All
def test_All_concat():
    all_instance1 = All(True)
    all_instance2 = All(False)
    assert all_instance1.concat(all_instance2) == All(False)
    assert all_instance2.concat(all_instance1) == All(False)
    all_instance3 = All(False)
    assert all_instance3.concat(all_instance2) == All(False)


# Generated at 2022-06-24 00:32:07.313524
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(10).value == 10
    assert Sum(30).value == 30
    assert Sum(50) == Sum(50)


# Generated at 2022-06-24 00:32:10.720292
# Unit test for method concat of class All
def test_All_concat():
    assert str(All(True).concat(All(True))) == "All[value=True]"
    assert str(All(True).concat(All(False))) == "All[value=False]"



# Generated at 2022-06-24 00:32:13.681873
# Unit test for constructor of class First
def test_First():
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-24 00:32:17.507296
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-24 00:32:20.155728
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)



# Generated at 2022-06-24 00:32:22.878402
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True
    assert One(False).value == False

    one = One(False)
    assert one.value == False


# Generated at 2022-06-24 00:32:24.273720
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-24 00:32:27.353919
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == 'Map[value={"a": Sum[value=1], "b": Sum[value=2]}]'


# Generated at 2022-06-24 00:32:29.275320
# Unit test for constructor of class One
def test_One():  # pragma: no cover
    assert One(True)


# Generated at 2022-06-24 00:32:35.142099
# Unit test for constructor of class Min
def test_Min():
    """
    The test_Min function tests the Min constructor.
    """
    min1 = Min(12)
    min2 = Min(7)
    min3 = Min(21)
    min4 = Min(Const(42))

    expected = Min(7)
    actual = min2

    assert actual == expected


# Generated at 2022-06-24 00:32:45.934278
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup('abc') == Semigroup('abc')
    assert not Semigroup('abc') == Semigroup('cda')
    assert Semigroup('abc') != Semigroup('cda')
    assert Semigroup('abc') == 'abc'
    assert not Semigroup('abc') == 'cda'
    assert Semigroup('abc') != 'cda'
    assert 'abc' == Semigroup('abc')
    assert not 'cda' == Semigroup('abc')
    assert 'cda' != Semigroup('abc')
    assert Semigroup(1) == 1
    assert not Semigroup(1) == 2
    assert Semigroup(1) != 2

# Generated at 2022-06-24 00:32:51.178780
# Unit test for method concat of class Max
def test_Max_concat():
    m = Max(17)
    n = Max(42)
    assert m.concat(n).value == n.concat(m).value



# Generated at 2022-06-24 00:32:55.513868
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert Sum(5) == Sum(5)


# Generated at 2022-06-24 00:33:02.817069
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    test = All(True).concat(All(True))
    assert test.value == True

    test = All(True).concat(All(False))
    assert test.value == False

    test = All(False).concat(All(True))
    assert test.value == False

    test = All(False).concat(All(False))
    assert test.value == False



# Generated at 2022-06-24 00:33:04.284663
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).concat(One(2)) == One(1)
    assert One(0).concat(One(2)) == One(2)


# Generated at 2022-06-24 00:33:07.262272
# Unit test for constructor of class One
def test_One():
    assert One(42) == One(42)
    assert One(42) != One(43)



# Generated at 2022-06-24 00:33:12.155517
# Unit test for method __str__ of class Map
def test_Map___str__():
    seed = random.randint(0, 100)
    random.seed(seed)
    d = {random.randint(1, 100): random.randint(1, 100) for _ in range(10)}
    assert str(Map(d)) == 'Map[value={}]'.format(d)

# Generated at 2022-06-24 00:33:13.482768
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last('a').concat(Last('b')) == Last('b')


# Generated at 2022-06-24 00:33:15.831955
# Unit test for constructor of class Last
def test_Last():
    zero = Last(0)
    one = Last(1)
    two = Last(2)

    assert zero.value == 0
    assert one.value == 1
    assert two.value == 2



# Generated at 2022-06-24 00:33:17.386816
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)


# Generated at 2022-06-24 00:33:21.675794
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)).value == 2
    assert Max(2).concat(Max(1)).value == 2
    assert Max(2).concat(Max(3)).value == 3
    assert Max(3).concat(Max(2)).value == 3
    assert Max(2).concat(Max(2)).value == 2


# Generated at 2022-06-24 00:33:23.008971
# Unit test for constructor of class One
def test_One():
    one = One(True)
    assert one.value == True


# Generated at 2022-06-24 00:33:25.304889
# Unit test for method concat of class Max
def test_Max_concat():
    assert Sum(2).concat(Sum(2)) == Sum(4)
    assert Sum(2).concat(Sum(3)) == Sum(5)
    assert Sum(3).concat(Sum(2)) == Sum(5)



# Generated at 2022-06-24 00:33:28.652006
# Unit test for method __str__ of class Map
def test_Map___str__():
    test = Map({'a': Sum(1), 'b': Sum(3)})

    assert str(test) == "Map[value={'a': Sum[value=1], 'b': Sum[value=3]}]"


# Generated at 2022-06-24 00:33:33.013183
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:33:34.501188
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == "Sum[value=1]"


# Generated at 2022-06-24 00:33:36.913028
# Unit test for constructor of class One
def test_One():

    assert(One(True) == One(True))
    assert(One(123) == One(123))
    assert(One('abc') == One('abc'))


# Generated at 2022-06-24 00:33:38.429175
# Unit test for method concat of class First
def test_First_concat():
    assert First('foo').concat(First('bar')) == First('foo')



# Generated at 2022-06-24 00:33:43.041826
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-24 00:33:44.577558
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First('b').concat(First([1,2,3])) == First('b')


# Generated at 2022-06-24 00:33:46.179325
# Unit test for constructor of class Last
def test_Last():
    assert Last(3) == Last(3)


# Generated at 2022-06-24 00:33:48.185325
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({"key": 1})) == "Map[value={'key': 1}]"



# Generated at 2022-06-24 00:33:49.591573
# Unit test for constructor of class Map
def test_Map():
    assert Map({
        "key1": Sum(1),
        "key2": Sum(2)
    }) == Map({
        "key1": Sum(1),
        "key2": Sum(2)
    })

# Generated at 2022-06-24 00:33:51.043215
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)



# Generated at 2022-06-24 00:33:54.782310
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True


# Generated at 2022-06-24 00:33:56.042822
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-24 00:34:00.566424
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)
    assert Min(1) != Min(2)
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(3).concat(Min(2)) == Min(2)


# Generated at 2022-06-24 00:34:03.818001
# Unit test for method __str__ of class All
def test_All___str__():                                                   # pragma: no cover
    assert str(All(True)) == 'All[value=True]', 'Value mismatch'
    assert str(All(False)) == 'All[value=False]', 'Value mismatch'



# Generated at 2022-06-24 00:34:06.652412
# Unit test for method __str__ of class All
def test_All___str__():
    # Given
    semigroup = All(True)
    # When
    actual = semigroup.__str__()
    # Then
    assert actual == 'All[value=True]'



# Generated at 2022-06-24 00:34:08.393699
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum = Sum(10)
    assert str(sum) == 'Sum[value=10]'


# Generated at 2022-06-24 00:34:09.959973
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)


# Generated at 2022-06-24 00:34:12.553605
# Unit test for method concat of class First
def test_First_concat():
    a = First('a')
    b = First('b')

    assert(a.concat(b) == First('a'))


# Generated at 2022-06-24 00:34:15.385034
# Unit test for constructor of class Map
def test_Map():
    x = Map({'a': 1, 'b': 2, 'c': 3})
    y = Map({'a': 1, 'b': 2, 'c': 3})
    assert x.value['a'].value == 1
    assert x.value['b'].value == 2
    assert x.value['c'].value == 3
    assert x == y


# Generated at 2022-06-24 00:34:18.916928
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({})) == 'Map[value={}]'



# Generated at 2022-06-24 00:34:20.990132
# Unit test for constructor of class Map
def test_Map():
    expected = {'a': Sum(1), 'b': Sum(1), 'c': Sum(1)}
    actual = Map(expected)
    assert actual.value == expected


# Generated at 2022-06-24 00:34:24.997974
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(5).concat(Last(10)) == Last(10)
    assert Last("A").concat(Last("B")) == Last("B")

# Generated at 2022-06-24 00:34:25.986607
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert 'Last[value=3]' == str(Last(3))


# Generated at 2022-06-24 00:34:31.211872
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)


# Generated at 2022-06-24 00:34:32.210268
# Unit test for constructor of class Max
def test_Max():
    m = Max(5)
    assert m.value == 5


# Generated at 2022-06-24 00:34:33.578085
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-24 00:34:35.034368
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(2)) == 'Sum[value=2]'


# Generated at 2022-06-24 00:34:37.665047
# Unit test for constructor of class Semigroup
def test_Semigroup():
    import pytest

    with pytest.raises(Exception) as excinfo:
        Semigroup(None)

    assert excinfo.value.args[0] == 'Semigroup value can not be None'



# Generated at 2022-06-24 00:34:39.523683
# Unit test for method __str__ of class One
def test_One___str__():
    one = One(10)
    assert str(one) == 'One[value=10]'


# Generated at 2022-06-24 00:34:42.440841
# Unit test for constructor of class One
def test_One():
    assert One(3) == One(3)
    assert One('Hello') == One('Hello')
    assert One(False) == One(False)


# Generated at 2022-06-24 00:34:45.198048
# Unit test for method concat of class Last
def test_Last_concat():  # pragma: no cover
    assert Last('a').concat(Last('b')).value == Last('b').concat(Last('a')).value

# Generated at 2022-06-24 00:34:47.142924
# Unit test for constructor of class Max
def test_Max():
    """
    The unit test for constructor of class Max
    """
    assert Max(0).value == 0



# Generated at 2022-06-24 00:34:48.534267
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)


# Generated at 2022-06-24 00:34:53.002211
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First("abc") == First("abc")
    assert Last("abc") == Last("abc")
    assert Map({1: Sum(1)}) == Map({1: Sum(1)})
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)



# Generated at 2022-06-24 00:34:57.368945
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    Semigroup constructor
    """
    assert Semigroup(42) != None


# Generated at 2022-06-24 00:34:59.395239
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(4)
    assert Sum(4) == Sum(4)
    assert str(Sum(4)) == 'Sum[value=4]'
    assert Sum(4).value == 4


# Generated at 2022-06-24 00:35:00.337373
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda v: v + 1) == 2

# Generated at 2022-06-24 00:35:04.146210
# Unit test for method concat of class All
def test_All_concat():
    assert All(True) == All(True).concat(All(True))
    assert All(False) == All(False).concat(All(False))
    assert All(True) == All(True).concat(All(False))
    assert All(False) == All(False).concat(All(True))
    assert All(True) == All(False).concat(All(True))


# Generated at 2022-06-24 00:35:07.137207
# Unit test for constructor of class Last
def test_Last():
    """
    Unit test for constructor of class Last
    """
    assert Last(1).value == 1
    assert Last(0).value == 0
    assert Last(2.1).value == 2.1



# Generated at 2022-06-24 00:35:09.624594
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(3)}) == Map({'a': Sum(1), 'b': Sum(3)})


# Generated at 2022-06-24 00:35:11.259248
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(3).concat(Max(2)) == Max(3)



# Generated at 2022-06-24 00:35:20.667372
# Unit test for constructor of class All
def test_All():
    assert All(None)            == All(True)
    assert All(True)            == All(True)
    assert All(False)           == All(False)
    assert All('abc')           == All(True)
    assert All('')              == All(False)
    assert All(0)               == All(False)
    assert All(-1)              == All(True)
    assert All({'a': 1})        == All(True)
    assert All({})              == All(False)
    assert All([1,2,3])         == All(True)
    assert All([])              == All(False)
    assert All(())              == All(False)
    assert All(set([1, 2, 3]))  == All(True)
    assert All(set())           == All(False)

# Generated at 2022-06-24 00:35:21.722946
# Unit test for method concat of class Min
def test_Min_concat():
    actual = Min(3).concat(Min(1))
    expected = Min(1)
    assert actual == expected



# Generated at 2022-06-24 00:35:26.818566
# Unit test for constructor of class Map
def test_Map():
    map = Map({"1": Max(1), "2": Min(2)})
    assert map.value == {"1": Max(1), "2": Min(2)}, "Map value is incorrect"
    assert map.concat(Map({"2": Max(10), "3": Max(100)})).value == {"1": Max(1), "2": Max(10), "3": Max(100)}, "Concat of maps is incorrect"

test_Map()

# Generated at 2022-06-24 00:35:28.737454
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(False)) == 'One[value=False]'
    assert str(One('test')) == 'One[value=test]'



# Generated at 2022-06-24 00:35:29.883271
# Unit test for constructor of class Max
def test_Max():
    a = Max(3)
    assert a.value == 3
    assert a.neutral_element == -float("inf")
    assert a.fold(int) == 3


# Generated at 2022-06-24 00:35:31.088644
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)



# Generated at 2022-06-24 00:35:33.485047
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x) == 1
    assert Sum(1).fold(lambda x: x + 1) == 2
    assert Sum(1).fold(lambda x: x + 2) == 3
    assert Sum(1).fold(lambda x: x - 1) == 0

# Generated at 2022-06-24 00:35:36.589390
# Unit test for method __str__ of class Min
def test_Min___str__():
    # Test with some value
    assert str(Min(3)) == 'Min[value=3]'



# Generated at 2022-06-24 00:35:39.898799
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(2).fold(lambda x: x * 2) == 4



# Generated at 2022-06-24 00:35:43.303321
# Unit test for constructor of class All
def test_All():
    assert All(1) == All(1)
    assert All(True) == All(True)
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-24 00:35:45.915558
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"key": Sum(4)}).concat(Map({"key": Sum(6)})).value["key"] == Sum(10)


# Generated at 2022-06-24 00:35:47.319669
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(2)) == 'Sum[value=2]'


# Generated at 2022-06-24 00:35:53.132091
# Unit test for method __str__ of class Min
def test_Min___str__():
    """
    Test __str__ method of Min class
    :return: void
    """

    test_data = {
        0: 'Min[value=0]',
        1: 'Min[value=1]',
        'string': 'Min[value=string]',
        'string string': 'Min[value=string string]'
    }

    for test_value, expected in test_data.items():
        assert expected == str(Min(test_value))


# Generated at 2022-06-24 00:35:55.073050
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)


# Generated at 2022-06-24 00:35:57.380800
# Unit test for constructor of class Last
def test_Last():
    last1 = Last(1)
    last2 = Last(2)
    last3 = last1.concat(last2)
    assert last3 == Last(2)


# Generated at 2022-06-24 00:35:59.004693
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First('test')) == 'Fist[value=test]'


# Generated at 2022-06-24 00:35:59.948947
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last('1')) == 'Last[value=1]'


# Generated at 2022-06-24 00:36:02.996779
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(5)) == Last(5)
    assert Last(5).concat(Last(1)) == Last(1)
    assert Last(1).concat(Last(1)) == Last(1)


# Generated at 2022-06-24 00:36:05.904926
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)
#

# Generated at 2022-06-24 00:36:09.862520
# Unit test for method concat of class One
def test_One_concat():  # pragma: no cover
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)

    assert One(1).concat(One(2)) == One(1)



# Generated at 2022-06-24 00:36:14.752946
# Unit test for method concat of class Last
def test_Last_concat():
    last1 = Last(2)
    last2 = Last(3)

    assert last1.concat(last2) == Last(3)


# Generated at 2022-06-24 00:36:15.606692
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1



# Generated at 2022-06-24 00:36:24.189958
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(2)) == 'One[value=2]'
    assert str(One('hello')) == "One[value=hello]"
    assert str(One(['hello'])) == "One[value=['hello']]"
    assert str(
        One({'k1': 'hello', 'k2': 'world'})
    ) == "One[value={'k1': 'hello', 'k2': 'world'}]"


# Generated at 2022-06-24 00:36:27.406037
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:36:31.781745
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert One(True) == One(True)
    assert All(False) == All(False)
    assert List(1) == List(1)
    assert Map({"a": One(True), "b": All(True)}) == Map({"a": One(True), "b": All(False)})



# Generated at 2022-06-24 00:36:41.455163
# Unit test for method concat of class Map
def test_Map_concat():
    value1 = Map({
        'first_name': First('John'),
        'last_name': Last('Doe'),
        'age': Sum(30),
        'is_adult': All(True),
        'favorite_numbers': Map({
            'first': Max(-5),
            'last': Min(-100)
        })
    })
    value2 = Map({
        'first_name': First('John'),
        'last_name': Last('Doe'),
        'age': Sum(30),
        'is_adult': All(True),
        'favorite_numbers': Map({
            'first': Max(-5),
            'last': Min(-100)
        })
    })
    assert(Map(value1.concat(value2)) == Map(value2.concat(value1)))



# Generated at 2022-06-24 00:36:44.655857
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Unit test for method fold() of class Semigroup
    """
    sum_ = Sum(10).fold(lambda x: x + 20)
    assert sum_ == 30, "Method fold of class Semigroup not work"



# Generated at 2022-06-24 00:36:52.453184
# Unit test for constructor of class Map
def test_Map():
    """
    :returns: test results
    :rtype: [bool]
    """
    return [
        Map.neutral() == {},
        Map({'a': Sum(1), 'b': Sum(2)}) == {'a': Sum(1), 'b': Sum(2)},
        Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(1), 'b': Sum(2)}))
        == Map({'a': Sum(2), 'b': Sum(4)}),
    ]


# Generated at 2022-06-24 00:36:55.506971
# Unit test for constructor of class Map
def test_Map():
    test_map = Map({1: 2, 3: 4})
    assert test_map.value[1] == 2
    assert test_map.value[3] == 4


# Generated at 2022-06-24 00:37:00.220212
# Unit test for method __str__ of class All
def test_All___str__():
    a = All(True)
    b = All(False)
    assert a.__str__() == 'All[value=True]'
    assert b.__str__() == 'All[value=False]'

# Generated at 2022-06-24 00:37:03.356068
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(1)) == Last(1)
    assert Last(2).concat(Last(1)) == Last(1)


# Generated at 2022-06-24 00:37:06.771521
# Unit test for method concat of class Last
def test_Last_concat():

    # Create 2 Last instances with value 10, 100
    x = Last(10)
    y = Last(100)

    # Create 3rd instance with result of concat x, y
    z = x.concat(y)

    # Check if z.value is equal 100
    assert z.value == 100



# Generated at 2022-06-24 00:37:08.735060
# Unit test for method __str__ of class One
def test_One___str__():
    a = One(1)
    assert str(a) == 'One[value=1]', "One's __str__ method must return {One[value=1]} for One(1)"

# Generated at 2022-06-24 00:37:09.732488
# Unit test for constructor of class Max
def test_Max():
    assert Max(100) == Max(100)



# Generated at 2022-06-24 00:37:10.964127
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'

# Generated at 2022-06-24 00:37:12.181478
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(-2)) == First(1)



# Generated at 2022-06-24 00:37:14.176755
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(7)) == 'Sum[value=7]'



# Generated at 2022-06-24 00:37:15.392899
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1).value == 1

# Monoid instances

# Generated at 2022-06-24 00:37:17.195412
# Unit test for method concat of class Sum
def test_Sum_concat():
    # TODO
    pass



# Generated at 2022-06-24 00:37:19.914583
# Unit test for constructor of class Semigroup
def test_Semigroup():
    # assert that Sum(3) == Sum(3)
    assert Sum(3) == Sum(3)
    # assert that Sum(3) != Sum(4)
    assert Sum(3) != Sum(4)


# Generated at 2022-06-24 00:37:22.486255
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(5) == Sum(5)
    assert Sum(5) != Sum(6)



# Generated at 2022-06-24 00:37:24.450058
# Unit test for constructor of class One
def test_One():
    assert One.neutral() == One(False)


# Generated at 2022-06-24 00:37:28.591285
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(3).concat(Min(5)) == Min(3)
    assert Min(5).concat(Min(3)) == Min(3)
    assert Min(3).concat(Min(3)) == Min(3)
    print("test_Min_concat finished")


# Generated at 2022-06-24 00:37:30.304253
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First('a')) == "Fist[value=a]"



# Generated at 2022-06-24 00:37:34.728439
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    # if true
    assert Sum(1) == Sum(1)

    # if false
    assert Sum(1) != Sum(2)

# Generated at 2022-06-24 00:37:36.054168
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    _ = Sum(1).__str__()



# Generated at 2022-06-24 00:37:43.111245
# Unit test for method concat of class One
def test_One_concat():
    """
    Unit test for method concat of class One
    """
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(False).concat(One(True)) == One(True)


# Generated at 2022-06-24 00:37:47.302255
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: Sum(1), 2: Sum(2)})) == 'Map[value={1: Sum[value=1], 2: Sum[value=2]}]'


# Generated at 2022-06-24 00:37:48.246070
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'


# Base test for method concat of class One

# Generated at 2022-06-24 00:37:52.854354
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({1: Sum(1), 2: Last(2), 3: First(3)})
    m2 = Map({1: Sum(2), 2: Last(9), 3: First(8), 4: Last(4)})
    m3 = Map({1: Sum(3), 2: Last(9), 3: First(3), 4: Last(4)})

    assert m1.concat(m2) == m3

# Generated at 2022-06-24 00:37:54.459795
# Unit test for constructor of class Sum
def test_Sum():
    assert(Sum(6) == Sum(6))
    assert(Sum(6) != Sum(7))


# Generated at 2022-06-24 00:37:58.126256
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-24 00:38:00.789298
# Unit test for method concat of class Max
def test_Max_concat():
    max_value = Max(3)
    next_max_value = Max(5)
    expected_value = Max(5)
    actual_value = max_value.concat(next_max_value)
    assert actual_value == expected_value

# Generated at 2022-06-24 00:38:03.700865
# Unit test for method concat of class One
def test_One_concat():
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-24 00:38:05.476595
# Unit test for constructor of class Map
def test_Map():
    assert Map({1: Sum(1), 2: Sum(2)}).value == {1: Sum(1), 2: Sum(2)}



# Generated at 2022-06-24 00:38:09.045998
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(6)) == Max(6)

# Generated at 2022-06-24 00:38:10.388146
# Unit test for constructor of class Min
def test_Min():
    assert Min(5) == Min(5)


# Generated at 2022-06-24 00:38:11.753511
# Unit test for constructor of class One
def test_One():
    one = One(2)
    assert one.value == 2


# Generated at 2022-06-24 00:38:18.362573
# Unit test for method concat of class One
def test_One_concat():
    x = One(True)
    y = One(True)
    assert x.concat(y).value == True
    x = One(False)
    y = One(True)
    assert x.concat(y).value == True
    x = One(True)
    y = One(False)
    assert x.concat(y).value == True
    x = One(False)
    y = One(False)
    assert x.concat(y).value == False


# Generated at 2022-06-24 00:38:21.363098
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(0) == Semigroup(0)
    assert Semigroup(0) != Semigroup(1)
    assert Semigroup(1) != Semigroup(0)


# Generated at 2022-06-24 00:38:24.402410
# Unit test for constructor of class All
def test_All():
    assert isinstance(All(True), All)
    assert isinstance(All(False), All)
    assert All(True).value is True
    assert All(False).value is False


# Generated at 2022-06-24 00:38:25.767256
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(6)) == 'Min[value=6]'


# Generated at 2022-06-24 00:38:28.438848
# Unit test for constructor of class One
def test_One():
    assert One(False).value is False
    assert One(True).value is True
    assert One(1).value is True
    assert One(0).value is False


# Generated at 2022-06-24 00:38:30.898087
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)



# Generated at 2022-06-24 00:38:32.154474
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(2)) == 'Max[value=2]'

# Generated at 2022-06-24 00:38:34.673101
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(2) != Semigroup(1)
    assert Semigroup(1) == Semigroup(1.0)



# Generated at 2022-06-24 00:38:36.171770
# Unit test for constructor of class Last
def test_Last():
    last = Last(3)
    assert last.value == 3

# Generated at 2022-06-24 00:38:38.872913
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert Semigroup(123).value == 123
    assert Semigroup(Sum(1)).value == Sum(1)



# Generated at 2022-06-24 00:38:41.639889
# Unit test for method __str__ of class Max
def test_Max___str__():
    """
    Unit test for method __str__ of class Max
    """
    assert str(Max(3)) == "Max[value=3]"



# Generated at 2022-06-24 00:38:44.267970
# Unit test for method __str__ of class Map
def test_Map___str__():  # pragma: no cover
    assert str(Map({'a': Sum(1), 'b': Sum(1)})) == "Map[value={'a': Sum[value=1], 'b': Sum[value=1]}]"


# Generated at 2022-06-24 00:38:54.977845
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) == Last(2)
    assert First(1) == First(1)
    assert First(1) == First(2)
    assert First(1) == Last(1)
    assert First(1) == Last(2)
    assert First('Hello') == First('Hello')
    assert First('Hello') == First('World')
    assert First('Hello') == Last('Hello')
    assert First('Hello') == Last('World')
    assert First(0) == Last(False)
    assert First(0) == Last(None)
    assert First(0) == Last([])
    assert First(0) == Last('')



# Generated at 2022-06-24 00:38:56.546409
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last('foo').concat(Last('bar')).value == 'bar'


# Generated at 2022-06-24 00:39:04.538122
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(3) == Sum(3)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First(1) == First(1)
    assert Last(9) == Last(9)
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)
    assert Map({'a':Sum(1)}) == Map({'a':Sum(1)})
    assert None == None



# Generated at 2022-06-24 00:39:07.244254
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
    assert All(True).concat(All(True)).value == True


# Generated at 2022-06-24 00:39:08.056753
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1



# Generated at 2022-06-24 00:39:12.005855
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map([1, 2, 3])) == 'Map[value=[1, 2, 3]]'



# Generated at 2022-06-24 00:39:13.790840
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(3).concat(Sum(4)) == Sum(7)



# Generated at 2022-06-24 00:39:16.513074
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert str(Max(0)) == 'Max[value=0]'



# Generated at 2022-06-24 00:39:18.489018
# Unit test for constructor of class Max
def test_Max():
    a = Max(1)
    b = Max(2)
    assert a.value == 1
    assert b.value == 2


# Generated at 2022-06-24 00:39:21.202211
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(False)) == 'One[value=False]'
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-24 00:39:22.827890
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)



# Generated at 2022-06-24 00:39:24.356282
# Unit test for constructor of class First
def test_First():
    s = First(3)
    assert 3 == s.value


# Generated at 2022-06-24 00:39:27.045201
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert First(10).fold(lambda x: x + 2) == 12
    assert Sum(10).fold(lambda x: x + 2) == 12


# Generated at 2022-06-24 00:39:27.935726
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(0)) == 'Max[value=0]'



# Generated at 2022-06-24 00:39:32.731133
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)  # Equal
    assert All(True) != All(False)  # Not equal
    assert All(False) != All(True)  # Not equal
    assert All(False) != All(1)  # Not equal
    assert All(True) != All(1)  # Not equal



# Generated at 2022-06-24 00:39:34.452575
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)


# Generated at 2022-06-24 00:39:38.967558
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    actual_first = str(First('value'))
    assert actual_first == 'Fist[value=value]'



# Generated at 2022-06-24 00:39:40.257649
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'

# Generated at 2022-06-24 00:39:41.433509
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"


# Generated at 2022-06-24 00:39:43.366875
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert_equal(str(Max(1)), 'Max[value=1]')


# Generated at 2022-06-24 00:39:46.970580
# Unit test for method __str__ of class Map
def test_Map___str__():
    from fp import *
    from pytest import approx
    assert Map({'a': Sum(1), 'b': All(True)}).__str__() == 'Map[value={a: Sum[value=1], b: All[value=True]}]'

# Generated at 2022-06-24 00:39:48.428703
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-24 00:39:51.031226
# Unit test for method __str__ of class Map
def test_Map___str__():
    instance = Map(dict(a=1, b=2, c='foo'))
    assert str(instance) == 'Map[value={a: 1, b: 2, c: foo}]'



# Generated at 2022-06-24 00:39:56.698280
# Unit test for method concat of class Min
def test_Min_concat():  # pragma: no cover
    min_0 = Min(0)
    min_1 = Min(1)
    min_2 = Min(2)

    assert min_0.concat(min_1) == min_0
    assert min_1.concat(min_0) == min_0
    assert min_1.concat(min_2) == min_1

# Generated at 2022-06-24 00:40:03.455190
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert Semigroup(value=1) == Semigroup(value=1)
    assert Sum(value=1).value == 1
    assert All(value=False).value == False
    assert One(value=True).value == True
    assert First(value=True).value == True
    assert Last(value=True).value == True
    assert Map(value={'key': Sum(1)}).value == {'key': Sum(1)}


#  Unit test for function fold of class Semigroup

# Generated at 2022-06-24 00:40:07.522274
# Unit test for method __str__ of class First
def test_First___str__():
    for value in (1, 1.2, '1', [1, 2], {'key': 1, 'other': 'value'}, 'First[value=1]', ('First[value=1]', '1')):
        semigroup = First(value)
        assert str(semigroup) == 'First[value=' + str(value) + ']'

# Generated at 2022-06-24 00:40:09.214363
# Unit test for constructor of class Max
def test_Max():
    assert Max(11).value == 11
    assert Max(10000).value == 10000
    assert Max(50.25).value == 50.25


# Generated at 2022-06-24 00:40:11.817954
# Unit test for constructor of class Max
def test_Max():
    a = Max(1)
    assert a.value == 1
    assert str(a) == 'Max[value=1]'


# Generated at 2022-06-24 00:40:15.014260
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(3)) == Max(5)
    assert Max(3).concat(Max(5)) == Max(5)


# Generated at 2022-06-24 00:40:16.946846
# Unit test for constructor of class Max
def test_Max():
    assert Max(3).value == 3
    assert Max(100).value == 100
    assert Max(-10).value == -10


# Generated at 2022-06-24 00:40:18.729684
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(2) == Sum(2)
    assert Sum(2) != Sum(3)


# Generated at 2022-06-24 00:40:20.891525
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    """
    Unit test for method __str__ of class Sum
    """
    assert str(Sum(10)) == "Sum[value=10]"



# Generated at 2022-06-24 00:40:23.597090
# Unit test for method concat of class All
def test_All_concat():
    assert(All(True).concat(All(True)) == All(True))
    assert(All(True).concat(All(False)) == All(False))
    assert(All(False).concat(All(True)) == All(False))
    assert(All(False).concat(All(False)) == All(False))


# Generated at 2022-06-24 00:40:28.611428
# Unit test for constructor of class Sum
def test_Sum():
    sum_1 = Sum(5)
    sum_2 = Sum(10)
    assert isinstance(sum_1, Sum)
    assert isinstance(sum_2, Sum)
    assert sum_1 == Sum(5)


# Generated at 2022-06-24 00:40:30.923354
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    """
    Unit test for constructor of class Sum
    """
    assert Sum(1).value == 1



# Generated at 2022-06-24 00:40:35.031972
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)).value == True
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(False)).value == False
    assert One(False).concat(One(True)).value == True


# Generated at 2022-06-24 00:40:36.194286
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'



# Generated at 2022-06-24 00:40:40.539154
# Unit test for method concat of class Map
def test_Map_concat():
    """
    test for method concat of class Map
    """
    assert (
        Map({"first": First(1), "second": First(2)}).concat(Map({"first": First(3)}))
        == Map({"first": First(1), "second": First(2)})
    )

# Generated at 2022-06-24 00:40:43.159133
# Unit test for method __str__ of class Min
def test_Min___str__():
    actual = Min(5)
    expected = "Min[value=5]"
    assert str(actual) == expected


# Generated at 2022-06-24 00:40:45.614430
# Unit test for method __str__ of class All
def test_All___str__():
    assert All(True).__str__() == 'All[value=True]'

# Generated at 2022-06-24 00:40:48.409085
# Unit test for method concat of class Last
def test_Last_concat():
    a = Last("ajde")
    b = Last("ludik")
    assert a.concat(b) == Last("ludik")



# Generated at 2022-06-24 00:40:51.271361
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(True)) == All(False)


# Generated at 2022-06-24 00:40:53.487810
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)


# Generated at 2022-06-24 00:41:02.509427
# Unit test for method concat of class Map
def test_Map_concat():  # pragma: no cover
    assert get_run_value(Map({1: All(True), 2: All(False), 3: All(True)})
                         .concat(Map({1: All(False), 2: All(True), 4: All(True)})
                                 .fold(lambda value: value))) == {1: All(False), 2: All(True), 3: All(True), 4: All(True)}


# The value of Sum[15].concat(Sum[19]).fold(lambda value: value) is 34.

# Generated at 2022-06-24 00:41:06.914992
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:41:09.854809
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({1: Sum(4), 2: Sum(4)}).concat(Map({1: Sum(10), 2: Sum(20)})).value == {
        1: Sum(14), 2: Sum(24)
    }

# Generated at 2022-06-24 00:41:16.880968
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(1)) == 'Sum[value=1]'
    assert str(Sum(2.3)) == 'Sum[value=2.3]'
    assert str(Sum("string")) == 'Sum[value=string]'
    assert str(Sum("!")) == 'Sum[value=!]'
    assert str(Sum(None)) == 'Sum[value=None]'


# Generated at 2022-06-24 00:41:19.591493
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)

# Generated at 2022-06-24 00:41:21.274059
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(3)).value == 5



# Generated at 2022-06-24 00:41:24.583952
# Unit test for method concat of class Last
def test_Last_concat():  # pragma: no cover
  assert Last(2).concat(Last(3)).value == 3
  assert Last(2).concat(Last(2)).value == 2


# Generated at 2022-06-24 00:41:26.175446
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(4)) == 'One[value=4]'



# Generated at 2022-06-24 00:41:28.833409
# Unit test for method concat of class Min
def test_Min_concat():
    first = Min(100)
    second = Min(200)
    value = Min(50)
    assert first.concat(value) == Min(50)
    assert value.concat(second) == Min(50)


# Generated at 2022-06-24 00:41:31.059443
# Unit test for constructor of class One
def test_One():
    assert One(1)
    assert One("True")
    assert One(False)
    assert One("false")
    assert One("1")


# Generated at 2022-06-24 00:41:31.972691
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)

# Generated at 2022-06-24 00:41:35.947880
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(False).concat(One(True)) == One(True)
