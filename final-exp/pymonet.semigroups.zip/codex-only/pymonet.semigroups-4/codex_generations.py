

# Generated at 2022-06-24 00:31:39.621990
# Unit test for constructor of class Max
def test_Max():
    print("test_Max")
    S = Max(1)
    assert S.value == 1
    assert S.fold(lambda x: x) == 1
    print('.')


# Generated at 2022-06-24 00:31:41.242761
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x) == 1
    assert Semigroup(1).fold(lambda x: x + 1) == 2

# Generated at 2022-06-24 00:31:45.221303
# Unit test for method concat of class Max
def test_Max_concat():
    a = Max(5)
    b = Max(7)

    assert a.concat(b) == Max(7)



# Generated at 2022-06-24 00:31:47.703426
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)


# Generated at 2022-06-24 00:31:50.660982
# Unit test for constructor of class All
def test_All():
    assert All(1) == All(1)
    assert All(1) != All(0)
    assert All(1).fold(lambda x: x + 1) == 2


# Generated at 2022-06-24 00:31:54.427975
# Unit test for method concat of class First
def test_First_concat():
    # Arrange
    fst = First(1)
    snd = First(2)

    # Act
    result = fst.concat(snd)

    # Assert
    assert result == First(1)


# Generated at 2022-06-24 00:31:55.836260
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(0)) == 'Min[value=0]'



# Generated at 2022-06-24 00:31:56.943442
# Unit test for method concat of class Last
def test_Last_concat():
    s1 = Last(1)
    s2 = Last(2)
    assert s1.concat(s2) == Last(2)


# Generated at 2022-06-24 00:32:03.140312
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    # given
    true_one = All(True)
    true_two = All(True)
    false_one = All(False)
    false_two = All(False)

    # when
    true_two_true_one = true_two.concat(true_one)
    true_two_false_one = true_two.concat(false_one)
    false_two_false_one = false_two.concat(false_one)

    # then
    assert true_two_true_one.value == True
    assert true_two_false_one.value == False
    assert false_two_false_one.value == False


# Generated at 2022-06-24 00:32:04.946885
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)


# Generated at 2022-06-24 00:32:06.681979
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({"a": 1, "b": 2})) == "Map[value={'a': 1, 'b': 2}]"



# Generated at 2022-06-24 00:32:10.292304
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(5).concat(Min(7)) == Min(5)
    assert Min(5).concat(Min(3)) == Min(3)
    assert Min(5).concat(Min(5)) == Min(5)

# Generated at 2022-06-24 00:32:13.116094
# Unit test for method __str__ of class Last
def test_Last___str__():
    semigroup = Last(20)
    assert str(semigroup) == 'Last[value=20]'


# Generated at 2022-06-24 00:32:18.298996
# Unit test for method concat of class First
def test_First_concat():  # pragma: no cover
    first = First(1)
    last = First(2)
    assert first.concat(last) == First(1)



# Generated at 2022-06-24 00:32:29.178363
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert (Sum(1).fold(lambda x: x + 1)) == 2
    assert (Sum(1).fold(lambda x: x - 1)) == 0
    assert (Sum(1).fold(lambda x: x * 2)) == 2
    assert (Sum(2).fold(lambda x: x / 2)) == 1
    assert (All(True).fold(lambda x: x == True))
    assert (All(False).fold(lambda x: x == False))
    assert (One(True).fold(lambda x: x == True))
    assert (One(False).fold(lambda x: x == False))
    assert (First([1, 2, 3]).fold(lambda x: x[0])) == 1
    assert (Last([1, 2, 3]).fold(lambda x: x[-1])) == 3

# Generated at 2022-06-24 00:32:33.489034
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(None)) == 'One[value=None]'



# Generated at 2022-06-24 00:32:35.058286
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(10) == Semigroup(10)
    assert not Semigroup(10) == Semigroup(15)


# Generated at 2022-06-24 00:32:37.796852
# Unit test for constructor of class Max
def test_Max():
    max_positive_value = Max(-float('inf'))
    assert max_positive_value.value == -float('inf')



# Generated at 2022-06-24 00:32:40.274119
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1

test_Max()

# Unit test of concat() method of Max class

# Generated at 2022-06-24 00:32:42.703972
# Unit test for constructor of class All
def test_All():
    assert bool(All(True))

    assert bool(All(None))

    assert not bool(All(False))



# Generated at 2022-06-24 00:32:44.377771
# Unit test for method __str__ of class All
def test_All___str__():
    expected_str = 'All[value=True]'
    actual_str = All(True).__str__()
    assert actual_str == expected_str



# Generated at 2022-06-24 00:32:51.057199
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)).value == 1
    assert First("hello").concat(First("world")).value == "hello"
    assert First({"name": "Joe"}).concat(First({"name": "Jack"})).value == {"name": "Joe"}



# Generated at 2022-06-24 00:32:56.066384
# Unit test for constructor of class First
def test_First():
    import pytest
    first = First(True)
    assert first.value is True
    with pytest.raises(TypeError):
        first = First(None)


# Generated at 2022-06-24 00:32:58.865784
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)

# Generated at 2022-06-24 00:33:01.496307
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    semigroup1 = Sum(1)
    semigroup2 = Sum(1)
    assert semigroup1 == semigroup2


# Generated at 2022-06-24 00:33:02.583042
# Unit test for constructor of class Max
def test_Max():
    assert Max(4).value == 4



# Generated at 2022-06-24 00:33:07.791464
# Unit test for constructor of class Max
def test_Max():
    f = Max(1)
    g = Max(2)
    assert f == Max(1)
    assert f.value == 1
    assert isinstance(f, Max)
    assert f.concat(g) == Max(2)
    assert Max(3).concat(Max(4)) == Max(4)
    assert Max(1).fold(lambda x: x * 2) == 2
    assert Max(2).neutral() == Max(-float("inf"))


# Generated at 2022-06-24 00:33:08.725711
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(6)) == "Min[value=6]"


# Generated at 2022-06-24 00:33:11.621339
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(3)
    b = Min(9)
    assert a.concat(b) == Min(3)


# Generated at 2022-06-24 00:33:13.513109
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(5)) == 'Sum[value=5]'


# Generated at 2022-06-24 00:33:14.359088
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1)

# Generated at 2022-06-24 00:33:22.437013
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Semigroup fold method applies function over value
    """
    assert Sum(2).fold(inc) == 3
    assert All(False).fold(inc) == 1
    assert One('e').fold(inc) == 2
    assert First('e').fold(inc) == 1
    assert Last(32).fold(inc) == 33
    assert Map({'a': Sum(1), 'b': Sum(2)}).fold(inc) == {'a': 2, 'b': 3}
    assert Max(2).fold(inc) == 3
    assert Min(4).fold(inc) == 5


# Generated at 2022-06-24 00:33:26.335880
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(42) == Semigroup(42)
    assert not Semigroup(42) == Semigroup(24)
    assert not Semigroup(42) == Semigroup(24.0)



# Generated at 2022-06-24 00:33:29.108444
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert Semigroup(2) == Semigroup(2)
    assert Semigroup(2) != Semigroup(3)



# Generated at 2022-06-24 00:33:31.239682
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(2)) == "One[value=2]"

# Generated at 2022-06-24 00:33:32.670527
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(0)) == 'Last[value=0]'



# Generated at 2022-06-24 00:33:35.685162
# Unit test for method __str__ of class Map
def test_Map___str__():
    """Test Semigroup map __str__ method"""
    assert str(Map({'expect': 'expected'})) == "Map[value={'expect': 'expected'}]"



# Generated at 2022-06-24 00:33:40.577795
# Unit test for method concat of class First
def test_First_concat():
    assert (First(0).concat(First(2)) == First(0))



# Generated at 2022-06-24 00:33:43.041881
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(5).fold(lambda x: x + 1) == 6


# Generated at 2022-06-24 00:33:45.126117
# Unit test for constructor of class Map
def test_Map():
    assert Map({}) == Map({})
    assert Map({1: First(1)}) == Map({1: First(1)})  # pragma: no cover



# Generated at 2022-06-24 00:33:48.909119
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:33:53.450414
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(2).fold(lambda x: x) == 2
    assert All(True).fold(lambda x: x) == True
    assert One(True).fold(lambda x: x) == True
    assert First(2).fold(lambda x: x) == 2
    assert Last(True).fold(lambda x: x) == True
    assert Map({1: First(1), 2: First(2)}).fold(lambda x: x) == {1: First(1), 2: First(2)}
    assert Max(3).fold(lambda x: x) == 3
    assert Min(3).fold(lambda x: x) == 3


# Generated at 2022-06-24 00:33:58.644020
# Unit test for method concat of class Max
def test_Max_concat():
    x = Max(4)
    y = Max(6)
    assert x.concat(y).value == 6  # operator '>' return True, because 6 > 4
    assert y.concat(x).value == 6  # operator '>' return False, because 4 <= 6


# Generated at 2022-06-24 00:34:04.921086
# Unit test for constructor of class Map
def test_Map():
    # Given
    f = {"a": First(1), "b": First(3)}
    m = {"a": Last(2), "b": Last(4)}

    # When
    map_ = Map(f)

    # Then
    assert map_.value == {"a": First(1), "b": First(3)}

    # Given
    map_ = Map(f)

    # When
    map_.concat(Map(m))

    # Then
    assert map_.value == {"a": Last(2), "b": Last(4)}

# Generated at 2022-06-24 00:34:06.499306
# Unit test for constructor of class One
def test_One():
    assert One(123).value == 123



# Generated at 2022-06-24 00:34:07.891931
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-24 00:34:10.568389
# Unit test for constructor of class Semigroup
def test_Semigroup():
    semigroup = Semigroup(3)
    assert semigroup.value == 3
    assert str(semigroup) == 'Semigroup[value=3]'


# Generated at 2022-06-24 00:34:15.146847
# Unit test for method __str__ of class Map
def test_Map___str__():
    map1 = Map({1: Sum(1), 2: Sum(2)})
    assert str(map1) == 'Map[value={1: Sum[value=1], 2: Sum[value=2]}]'



# Generated at 2022-06-24 00:34:20.333531
# Unit test for method concat of class First
def test_First_concat():
    """test_First_concat"""
    first = First("hello")
    second = First("world")
    assert first.concat(second) == First("hello")
    assert second.concat(first) == First("world")



# Generated at 2022-06-24 00:34:24.649903
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-24 00:34:25.666786
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(3)) == 'Max[value=3]'



# Generated at 2022-06-24 00:34:27.488296
# Unit test for constructor of class Last
def test_Last():
    last = Last(1)
    assert last.value == 1
    assert last != Last(2)
    assert last == Last(1)



# Generated at 2022-06-24 00:34:28.578549
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-24 00:34:31.169718
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(0).concat(Sum(2)) == Sum(2)
    assert Sum(1).concat(Sum(0)) == Sum(1)
    assert Sum(0).concat(Sum(0)) == Sum(0)



# Generated at 2022-06-24 00:34:32.176192
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(2)) == 'Min[value=2]'


# Generated at 2022-06-24 00:34:42.214385
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    # Sum([1, 2, 3, 4]).fold(lambda s: s) == 10
    assert Sum(10).fold(lambda s: s) == 10

    # All([False, True, False, True]).fold(lambda x: x) == False
    assert All(False).fold(lambda x: x) == False

    # One([False, True, False, True]).fold(lambda x: x) == False
    assert One(False).fold(lambda x: x) == False

    # First([False, True, False, True]).fold(lambda x: x) == First(False)
    assert First(False).fold(lambda x: x) == False

    # Last([False, True, False, True]).fold(lambda x: x) == Last(True)
    assert Last(True).fold(lambda x: x) == True

    # Map

# Generated at 2022-06-24 00:34:43.371136
# Unit test for constructor of class First
def test_First():
    assert First(0).value == 0



# Generated at 2022-06-24 00:34:44.864136
# Unit test for constructor of class Min
def test_Min():
    assert Min(1).value == 1


# Generated at 2022-06-24 00:34:46.936890
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(Min(6))) == "Min[value=6]"


# Generated at 2022-06-24 00:34:50.459132
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(True)) == All(False)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-24 00:34:51.906767
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(420)) == 'Sum[value=420]'



# Generated at 2022-06-24 00:34:56.697337
# Unit test for method concat of class First
def test_First_concat():
    """
    Unit test for method concat of class First
    """
    assert First(2).concat(First(1)) == First(2)


# Generated at 2022-06-24 00:35:00.522126
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First(1) == First(1)
    assert Last(3) == Last(3)
    assert Map({1: Sum(3)}) == Map({1: Sum(3)})
    assert Max(5) == Max(5)
    assert Min(0) == Min(0)
    assert First(0) != Sum(0)
    assert Last(1) != Last(2)
    assert Sum(2) != All(2)


# Generated at 2022-06-24 00:35:01.716822
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-24 00:35:03.237907
# Unit test for constructor of class First
def test_First():
    assert First(5) == First(5)



# Generated at 2022-06-24 00:35:04.486402
# Unit test for constructor of class All
def test_All():
    assert All(1) == All(1)


# Generated at 2022-06-24 00:35:08.261903
# Unit test for method concat of class First
def test_First_concat():
    f1 = First(1)
    f2 = First(2)
    f3 = First(3)
    assert f1.concat(f2).concat(f3) == f1.concat(f2.concat(f3)) == First(1)


# Generated at 2022-06-24 00:35:12.206925
# Unit test for constructor of class Sum
def test_Sum():
    sum_ = Sum(1)
    assert sum_.value == 1



# Generated at 2022-06-24 00:35:13.060099
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)



# Generated at 2022-06-24 00:35:21.544190
# Unit test for method concat of class Map
def test_Map_concat():
    # Create 2 maps
    map1 = Map({'0': Sum(1), '1': Sum(2)})
    map2 = Map({'0': Sum(3), '1': Sum(4)})

    # Contat maps
    map3 = map1.concat(map2)

    # Get map3 values
    map3_value = map3.value

    # Get sum for each value of merged maps.
    sums = {
        '0': map3_value['0'].value,
        '1': map3_value['1'].value
    }

    # Assert map3 values
    assert sums == {
        '0': 4,
        '1': 6
    }

# Generated at 2022-06-24 00:35:23.581865
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: Sum(1), 2: Sum(2), 'foo': Sum(3)})) == 'Map[value={1: Sum[value=1], 2: Sum[value=2], foo: Sum[value=3]}]'


# Generated at 2022-06-24 00:35:27.381913
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)) == Sum(10)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)).concat(Sum(5)) == Sum(15)


# Generated at 2022-06-24 00:35:30.777419
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    from hypothesis import given
    from hypothesis.strategies import integers
    @given(integers())
    def test(value):
        assert str(Max(value)) == 'Max[value={}]'.format(value)
    test()



# Generated at 2022-06-24 00:35:33.009260
# Unit test for method concat of class Last
def test_Last_concat():
    # it should return first value
    assert Last("first").concat(Last("second")) == Last("second")


# Generated at 2022-06-24 00:35:40.025533
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:35:42.677204
# Unit test for method concat of class First
def test_First_concat():  # pragma: no cover
    assert First(1).concat(First(2)) == First(1)

# Generated at 2022-06-24 00:35:45.232229
# Unit test for constructor of class Last
def test_Last():
    last1 = Last("Hello")
    last2 = Last("World")

    assert last1.value == "Hello"
    assert last2.value == "World"


# Generated at 2022-06-24 00:35:47.930122
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(2).concat(First(1)) == First(2)


# Generated at 2022-06-24 00:35:49.623742
# Unit test for constructor of class Max
def test_Max():
    m = Max(1)
    assert m.value == 1


# Generated at 2022-06-24 00:35:51.828532
# Unit test for constructor of class One
def test_One():
    assert One(False) == One(False)
    assert One(True) == One(True)
    assert One(True) != One(False)


# Generated at 2022-06-24 00:35:53.539938
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(5)) == 'Sum[value=5]'
    assert str(Sum(0)) == 'Sum[value=0]'


# Generated at 2022-06-24 00:35:54.753926
# Unit test for method __str__ of class Last
def test_Last___str__():
    last = Last(1)
    assert last.__str__() == 'Last[value=1]'



# Generated at 2022-06-24 00:35:56.798318
# Unit test for constructor of class Map
def test_Map():
    data = Map({'a': Sum(1), 'b': Sum(2), 'c': Sum(3)})
    assert data.fold(lambda x: x) == {'a': 1, 'b': 2, 'c': 3}


# Generated at 2022-06-24 00:35:58.258436
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-24 00:36:00.701402
# Unit test for method concat of class Max
def test_Max_concat():
    first_value = Max(3)
    second_value = Max(4)

    result = first_value.concat(second_value)

    assert result == Max(4)


# Generated at 2022-06-24 00:36:04.565116
# Unit test for method __str__ of class All
def test_All___str__():
    assert 'All[value=True]' == str(All(True))
    assert 'All[value=False]' == str(All(False))



# Generated at 2022-06-24 00:36:06.622626
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-24 00:36:09.540100
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'
    assert str(Last(2)) == 'Last[value=2]'
    assert str(Last(None)) == 'Last[value=None]'


# Generated at 2022-06-24 00:36:10.671848
# Unit test for method __str__ of class One
def test_One___str__():
    assert 'One[value=True]' == str(One(True))


# Generated at 2022-06-24 00:36:14.781106
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert Last(4).__str__() == 'Last[value=4]'


# Generated at 2022-06-24 00:36:16.004812
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-24 00:36:21.736941
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: Sum(1), 2: Sum(2)})) == "Map[value={1: Sum[value=1], 2: Sum[value=2]}]"

# Generated at 2022-06-24 00:36:22.873073
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1).value == 1



# Generated at 2022-06-24 00:36:24.623917
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': 1, 'b': 2}) == Map({'a': 1, 'b': 2})


# Generated at 2022-06-24 00:36:27.552334
# Unit test for constructor of class Last
def test_Last():
    assert Last(2) == Last(2)
    assert Last(2) is not Last(2)
    assert Last(2).value == 2
    assert Last(2).value is not 2



# Generated at 2022-06-24 00:36:31.140826
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value == True
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(False)).value == False



# Generated at 2022-06-24 00:36:33.775612
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'



# Generated at 2022-06-24 00:36:38.265200
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map({1: Sum(10), 2: One(True)})
    map2 = Map({2: Last(False), 3: First('foo')})
    map3 = Map({1: Sum(14), 2: One(False), 3: First('foo')})
    assert map1.concat(map2) == map3



# Generated at 2022-06-24 00:36:39.798634
# Unit test for method concat of class Min
def test_Min_concat():
    min_value = Min(0)
    min_value_one = Min(1)

    assert min_value.concat(min_value_one) == Min(0)

# Generated at 2022-06-24 00:36:44.941160
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)).value == 2, "Expected 2, concat of 1 and 2"
    assert Max(1).concat(Max(1)).value == 1, "Expected 1, concat of 1 and 1"
    assert Max(2).concat(Max(1)).value == 2, "Expected 2, concat of 2 and 1"



# Generated at 2022-06-24 00:36:46.285138
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1



# Generated at 2022-06-24 00:36:52.489860
# Unit test for method concat of class Map
def test_Map_concat():
	map1 = Map({'1': Sum(1), '2': Sum(2)})
	map2 = Map({'1': Sum(1)})
	map3 = Map({'2': Sum(2), '3': Sum(3)})
	map_concat = Map({'1': Sum(2), '2': Sum(4), '3': Sum(3)})
	assert map3.concat(map2).concat(map1).value == map_concat.value

# Generated at 2022-06-24 00:36:54.316723
# Unit test for method __str__ of class Max
def test_Max___str__():
    """
    test_Max___str__()
    """
    assert str(Max(5)) == "Max[value=5]"



# Generated at 2022-06-24 00:36:55.383525
# Unit test for method __str__ of class All
def test_All___str__():
    assert 'All[value=True]' == str(All(True))
    assert 'All[value=False]' == str(All(False))



# Generated at 2022-06-24 00:37:00.120239
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == "One[value=True]"
    assert str(One(False)) == "One[value=False]"
    assert str(One(1)) == "One[value=1]"

# Generated at 2022-06-24 00:37:04.473013
# Unit test for method concat of class All
def test_All_concat():
    all = All(True).concat(All(True))
    assert all.concat(All(False)).value is False

    all = All(False).concat(All(True))
    assert all.concat(All(False)).value is False

    all = All(False).concat(All(False))
    assert all.concat(All(False)).value is False


# Generated at 2022-06-24 00:37:10.230270
# Unit test for method concat of class Min
def test_Min_concat():
    s0 = Min(4)
    s1 = Min(6)
    assert s0.concat(s1).value == 4
    s0 = Min(4)
    s1 = Min(1)
    assert s0.concat(s1).value == 1
    s0 = Min(4)
    s1 = Min(4)
    assert s0.concat(s1).value == 4
    s0 = Min(0)
    s1 = Min(-5)
    assert s0.concat(s1).value == -5



# Generated at 2022-06-24 00:37:16.862276
# Unit test for constructor of class Sum
def test_Sum():
    """
    Test Sum class constructor.
    """
    test_semigroup = Sum(1)
    assert isinstance(test_semigroup, Sum)
    assert test_semigroup.value == 1



# Generated at 2022-06-24 00:37:19.435668
# Unit test for method fold of class Semigroup
def test_Semigroup_fold(): # pragma: no cover
    unit_value = "Unit value string"
    assert Semigroup(unit_value).fold(lambda x: x) == unit_value

# Generated at 2022-06-24 00:37:24.154607
# Unit test for constructor of class Max
def test_Max():
    assert Max(2) == Max(2)
    assert not Max(2) == Max(3)
    assert Max(2).concat(Max(3)) == Max(3)
    assert Max(2).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(-1)) == Max(2)


# Generated at 2022-06-24 00:37:28.963923
# Unit test for method concat of class First
def test_First_concat():
    first_value = First(12)
    expect_value = 12
    # assert first_value.concat(First(13)).value == expect_value
    # assert first_value.concat(First(10)).value == expect_value
    # assert first_value.concat(first_value).value == expect_value

test_First_concat()



# Generated at 2022-06-24 00:37:31.068525
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(-1) == All(-1)
    assert All(-1) != All(1)



# Generated at 2022-06-24 00:37:39.377239
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) == All(True).concat(All(False))
    assert All(False) == All(False).concat(All(True))
    assert All(False) == All(False).concat(All(False))
    assert All(True) == All(True).concat(All(True))
    assert isinstance(All(True), All)
    assert isinstance(All(False), All)
    assert All(False).concat(All(True)).concat(All(False)).concat(All(False)).concat(All(True)) == All(False)

# Generated at 2022-06-24 00:37:42.878670
# Unit test for constructor of class Min
def test_Min():
    assert Min(10) == Min(10)

    assert type(Min(121)) == Min
    assert Min(121).value == 121

    with pytest.raises(TypeError):
        Min("abc")


# Generated at 2022-06-24 00:37:47.951277
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)).value == True
    assert One(False).concat(One(False)).value == False
    assert One(False).concat(One(True)).value == True
    assert One(True).concat(One(False)).value == True

# Generated at 2022-06-24 00:37:53.007238
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Sum(sum).value == sum, "Sum not constructed"
    assert All(all).value == all, "All not constructed"
    assert One(one).value == one, "One not constructed"
    assert First(first).value == first, "First not constructed"
    assert Last(last).value == last, "Last not constructed"
    assert Map(map).value == map, "Map not constructed"
    assert Max(max).value == max, "Max not constructed"
    assert Min(min).value == min, "Min not constructed"



# Generated at 2022-06-24 00:37:59.640543
# Unit test for method concat of class Max
def test_Max_concat():  # pragma: no cover
    assert Max(3).concat(Max(2)).concat(Max(4)) == Max(4)
    assert Max(3).concat(Max(2)).concat(Min(4)) == Max(3)
    assert Max(3).concat(Min(2)).concat(Max(4)) == Max(4)



# Generated at 2022-06-24 00:38:00.931892
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-24 00:38:07.672669
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)).fold(bool) is True
    assert One(False).concat(One(True)).fold(bool) is True
    assert One(False).concat(One(False)).fold(bool) is False
    assert One(True).concat(One(True)).fold(bool) is True


# Generated at 2022-06-24 00:38:09.541953
# Unit test for constructor of class Semigroup
def test_Semigroup():
    semigroup = Semigroup(1)
    assert semigroup.value == 1
    assert isinstance(semigroup, Semigroup)


# Generated at 2022-06-24 00:38:11.949351
# Unit test for constructor of class One
def test_One():
    x = One(False)
    y = One(True)
    assert x.value == y.value
    assert x is y


# Generated at 2022-06-24 00:38:14.258998
# Unit test for constructor of class Map
def test_Map():
    assert Map({'key': Sum(1), 'key2': Sum(2)}) == Map({'key': Sum(1), 'key2': Sum(2)})



# Generated at 2022-06-24 00:38:16.488845
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(2).concat(Max(3)) == Max(3)
    assert Max(2).concat(Max(1)) == Max(2)


# Generated at 2022-06-24 00:38:21.756416
# Unit test for constructor of class Sum
def test_Sum():
    """
    Unit test for constructor of class Sum
    """
    v = Sum(7)
    assert v.value == 7
    assert v.concat(Sum(2)) == Sum(9)
    assert v.concat(Sum(0)) == Sum(7)


# Generated at 2022-06-24 00:38:27.409316
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({'a': Sum(1), 'b': Sum(2), 'c': Sum(3)})
    m2 = Map({'a': Sum(4), 'b': Sum(5), 'c': Sum(6)})
    expected = Map({'a': Sum(5), 'b': Sum(7), 'c': Sum(9)})
    assert m1.concat(m2) == expected

# Generated at 2022-06-24 00:38:30.234763
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True).value == All(True).value
    assert All(True).value == True
    assert All(False).value == False


# Generated at 2022-06-24 00:38:31.511548
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-24 00:38:38.523757
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    # Semigroup initialisation
    my_sum = Sum(1)
    my_all = All(True)
    my_one = One(False)
    my_first = First("First")
    my_last = Last("Last")
    my_map = Map({"value": Sum(1)})
    my_max = Max(3)
    my_min = Min(3)
    
    # fold function
    def f(x):
        return x*x

    # fold test
    assert my_sum.fold(f) == my_sum.value*my_sum.value
    assert my_all.fold(f) == my_all.value
    assert my_one.fold(f) == my_one.value
    assert my_first.fold(f) == my_first.value*my_first.value
   

# Generated at 2022-06-24 00:38:39.619452
# Unit test for constructor of class Max
def test_Max():
    assert Max(10).value == 10


# Generated at 2022-06-24 00:38:42.909321
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(7)) == Max(7)
    assert Max(-5).concat(Max(-7)) == Max(-5)
    assert Max(5).concat(Max(-7)) == Max(5)


# Generated at 2022-06-24 00:38:48.781209
# Unit test for constructor of class Map
def test_Map():
    assert Map({1: Max(1), 2: Sum(1), 3: All(True)}) == Map({1: Max(1), 2: Sum(1), 3: All(True)})
    assert Map({1: Max(1), 2: Sum(1), 3: All(True)}) != Map({1: Max(1), 2: Sum(0), 3: All(True)})


# Generated at 2022-06-24 00:38:51.212032
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'



# Generated at 2022-06-24 00:38:54.285393
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert Map({'a': Sum(1)}).__str__() == 'Map[value={\'a\': Sum[value=1]}]'


# Generated at 2022-06-24 00:38:55.532945
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(add1) == 2


# Generated at 2022-06-24 00:38:58.940137
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-24 00:39:02.448724
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(2).concat(Last(1)) == Last(1)


# Generated at 2022-06-24 00:39:04.547366
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == "One[value=True]"
    assert str(One(False)) == "One[value=False]"


# Generated at 2022-06-24 00:39:05.698902
# Unit test for constructor of class Max
def test_Max():
    from pytest import raises

    with raises(TypeError):
        Max()

    assert Max(10) == Max(10)
    assert Max(10) != Max(11)

# Generated at 2022-06-24 00:39:06.323799
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1

# Generated at 2022-06-24 00:39:08.502637
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: Sum(1), 2: Sum(2)})) == 'Map[value={1: Sum[value=1], 2: Sum[value=2]}]'

# Generated at 2022-06-24 00:39:12.153454
# Unit test for method __str__ of class Last
def test_Last___str__(): # pragma: no cover
    assert str(Last(1)) == "Last[value=1]"


# Generated at 2022-06-24 00:39:13.600165
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-24 00:39:19.608863
# Unit test for method concat of class Max
def test_Max_concat():
    a = Max(1)
    b = Max(100)
    c = Max(5)
    d = Max(2)
    e = Max(1)
    f = a.concat(b)
    g = c.concat(d)
    h = f.concat(g)
    assert h.value == 100 and f.value == 100 and f == d.concat(f) == e.concat(a)


# Generated at 2022-06-24 00:39:21.785362
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)).value == Sum(3).value



# Generated at 2022-06-24 00:39:23.777572
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-24 00:39:25.250058
# Unit test for method __str__ of class One
def test_One___str__():
    a = One('One')
    assert str(a) == 'One[value=One]'

# Generated at 2022-06-24 00:39:29.964698
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    semigroup_1 = Sum(10)
    semigroup_2 = Sum(20)
    semigroup_3 = Sum(10)

    # Check the case of equal semigroup
    assert semigroup_1 == semigroup_3

    # Check the case of not equal semigroups
    assert semigroup_1 != semigroup_2



# Generated at 2022-06-24 00:39:33.066552
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert Map({"a": Sum(1), "b": Sum(2)}).__str__() == "Map[value={'a': Sum[value=1], 'b': Sum[value=2]}]"



# Generated at 2022-06-24 00:39:37.510549
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(5)) == 'One[value=5]'


# Generated at 2022-06-24 00:39:39.086940
# Unit test for method __str__ of class Max
def test_Max___str__():
    m = Max(5)
    assert m.__str__() == 'Max[value=5]'


# Generated at 2022-06-24 00:39:40.391409
# Unit test for constructor of class Last
def test_Last():
    assert Last("a").value == "a"


# Generated at 2022-06-24 00:39:42.681518
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': 1})) == 'Map[value={\'a\': 1}]'


# Generated at 2022-06-24 00:39:45.599541
# Unit test for constructor of class Map
def test_Map():

    assert Map({'a': Sum(1), 'b': Sum(2)}).value == {'a': Sum(1), 'b': Sum(2)}


# Generated at 2022-06-24 00:39:51.001874
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(2).concat(Max(3)) == Max(3)
    assert Max(2).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)



# Generated at 2022-06-24 00:39:52.028931
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'



# Generated at 2022-06-24 00:40:03.502050
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert (
        Sum(1).concat(Sum(2)).concat(Sum(4)) ==
        Sum(7)
    )
    assert (
        Sum(1).concat(Sum(2)).concat(Sum(4)).concat(Sum(7)) ==
        Sum(14)
    )
    assert (
        Sum(1).concat(Sum(2)).concat(Sum(4)).concat(Sum(7)).concat(Sum(2)) ==
        Sum(16)
    )
    assert (
        Sum(1).concat(Sum(2)).concat(Sum(4)).concat(Sum(7)).concat(Sum(2)).concat(Sum(0)) ==
        Sum(16)
    )

# Generated at 2022-06-24 00:40:05.126372
# Unit test for method concat of class First
def test_First_concat():
    assert First('a').concat(First('b')).value == 'a'


# Generated at 2022-06-24 00:40:05.829893
# Unit test for constructor of class All
def test_All():
    assert All(False).value == False


# Generated at 2022-06-24 00:40:06.995015
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(5)) == 'Min[value=5]'


# Generated at 2022-06-24 00:40:11.785023
# Unit test for method concat of class Last
def test_Last_concat():
    last_1 = Last(1)
    last_2 = Last(2)

    assert last_1.concat(last_2) == last_2


# Generated at 2022-06-24 00:40:13.327927
# Unit test for constructor of class All
def test_All():
    assert All
    

# Generated at 2022-06-24 00:40:16.951108
# Unit test for method __str__ of class Min
def test_Min___str__():
    '''
    :returns: True if test was successful, False otherwise
    :rtype: bool
    '''
    value = Min(5)
    is_equal = value.__str__() == 'Min[value=5]'
    return is_equal


# Generated at 2022-06-24 00:40:22.769022
# Unit test for method __str__ of class Map
def test_Map___str__():
    import pytest
    assert str(Map({'a': Sum(1)})) == 'Map[value={\'a\': Sum[value=1]}]'
    assert str(
        Map({
            'a': Sum(1),
            'b': Sum(2)
        })
    ) == 'Map[value={\'a\': Sum[value=1], \'b\': Sum[value=2]}]'

# Generated at 2022-06-24 00:40:26.013195
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-24 00:40:32.282357
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    test_Sum_concat:
    """
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(5)).concat(Sum(2)) == Sum(8)
    assert Sum(1).concat(Sum(5)).concat(Sum(5)).concat(Sum(2)) == Sum(13)



# Generated at 2022-06-24 00:40:34.355783
# Unit test for constructor of class Sum
def test_Sum():
    sum_semigroup = Sum(5)

    assert sum_semigroup.value == 5


# Generated at 2022-06-24 00:40:38.412906
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)
    assert One(False) != One(True)

S = One

# Generated at 2022-06-24 00:40:40.123703
# Unit test for method concat of class Last
def test_Last_concat():
    last_result = Last(1).concat(Last(2))
    assert last_result.value == 2


# Generated at 2022-06-24 00:40:46.527044
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:40:53.692090
# Unit test for method concat of class All
def test_All_concat():
    """
    The test checks if the method concat works correctly
    """

    a = All(True)
    b = All(True)
    c = All(False)

    assert a.concat(b) == All(True)
    assert c.concat(a) == All(False)
    assert a.concat(c) == All(False)
    assert b.concat(a) == All(True)
    assert c.concat(b) == All(False)
    assert b.concat(c) == All(False)



# Generated at 2022-06-24 00:40:59.234414
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(None)) == 'Fist[value=None]'
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First('hi')) == "Fist[value='hi']"


# Generated at 2022-06-24 00:41:00.912753
# Unit test for constructor of class Max
def test_Max():
    assert Max(5) == Max(5)
    assert Max(5) != Max(6)


# Generated at 2022-06-24 00:41:04.119816
# Unit test for method concat of class Last
def test_Last_concat():
    semigroup1 = Last(5)
    semigroup2 = Last(2)

    assert semigroup1.concat(semigroup2).value == 2
    assert semigroup1.concat(semigroup2) != Last(5)



# Generated at 2022-06-24 00:41:06.680415
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last('a').concat(Last('b')) == Last('b')



# Generated at 2022-06-24 00:41:09.668268
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:41:18.214427
# Unit test for constructor of class One
def test_One():

    # false or true
    result_1 = One(False).concat(One(True))
    assert result_1.value == True

    # false or false
    result_2 = One(False).concat(One(False))
    assert result_2.value == False

    # true or true
    result_3 = One(True).concat(One(True))
    assert result_3.value == True

    # true or false
    result_4 = One(True).concat(One(False))
    assert result_4.value == True



# Generated at 2022-06-24 00:41:20.746882
# Unit test for method __str__ of class Min
def test_Min___str__():
    test_value = 1
    assert str(Min(test_value)) == 'Min[value={}]'.format(test_value)



# Generated at 2022-06-24 00:41:22.023639
# Unit test for constructor of class Min
def test_Min():
    assert Min(9) == Min(9)
    assert Min(9) != Min(8)



# Generated at 2022-06-24 00:41:25.962717
# Unit test for constructor of class Map
def test_Map():
    x = Map({'first': First(1), 'second': First(2), 'last': Last(3)})
    assert x.value == {'first': First(1), 'second': First(2), 'last': Last(3)}


# Generated at 2022-06-24 00:41:27.487946
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-24 00:41:28.362495
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)


# Generated at 2022-06-24 00:41:29.483243
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(False)) == "All[value=False]"


# Generated at 2022-06-24 00:41:40.342816
# Unit test for method concat of class One
def test_One_concat():
    assert One("foo").concat(One("bar")) == One("foo")
    assert One("").concat(One("")) == One("")
    assert One("1").concat(One("2")) == One("1")
    assert One("").concat(One("1")) == One("1")
    assert One("1").concat(One("")) == One("1")
    assert One([]).concat(One([])) == One([])
    assert One([]).concat(One([1])) == One([1])
    assert One([1]).concat(One([])) == One([1])
    assert One(1).concat(One(False)) == One(1)
    assert One(False).concat(One(1)) == One(1)