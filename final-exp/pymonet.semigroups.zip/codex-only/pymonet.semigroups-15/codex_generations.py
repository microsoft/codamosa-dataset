

# Generated at 2022-06-24 00:31:37.891511
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(-1)).value == 1


# Generated at 2022-06-24 00:31:44.597166
# Unit test for constructor of class Semigroup
def test_Semigroup():
    one = One(1)
    two = One(2)
    assert one == One(1)
    assert one != One(2)
    assert one != two
    assert one.concat(two) == One(1)
    assert two.concat(one) == One(2)
    assert one.fold(lambda value: value + 1) == 2


# Generated at 2022-06-24 00:31:51.101994
# Unit test for method fold of class Semigroup
def test_Semigroup_fold(): 
    assert Sum(2).fold(lambda x: x + 1) == 3
    assert All(True).fold(lambda x: x) == True
    assert One(True).fold(lambda x: not x) == False
    assert First("abc").fold(lambda x: x[1]) == "b"
    assert Last("abc").fold(lambda x: x[0]) == "c"
    assert Max(1, 2).fold(lambda x: x * x) == 4
    assert Min(1, 2).fold(lambda x: x * x) == 1



# Generated at 2022-06-24 00:31:52.432774
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(5)) == "Min[value=5]"


# Generated at 2022-06-24 00:31:54.087312
# Unit test for constructor of class Min
def test_Min():
    x = Min(1)
    assert x == Min(1)


# Generated at 2022-06-24 00:31:55.512304
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-24 00:31:59.891413
# Unit test for method concat of class All
def test_All_concat():

    assert All(True).concat(All(True)).value == True
    assert All(False).concat(All(False)).value == False
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False


# Generated at 2022-06-24 00:32:02.849724
# Unit test for method __str__ of class Map
def test_Map___str__():
    """
    Unit test for metho __str__ of class Map
    """

    assert Map({'key': 'value'}).__str__() == "Map[value={'key': 'value'}]", 'Should return a string of Map'



# Generated at 2022-06-24 00:32:05.113993
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(12) == Sum(12)


# Generated at 2022-06-24 00:32:10.639564
# Unit test for method __str__ of class All
def test_All___str__():
    All(True).__str__() == 'All[value=True]'
    All(None).__str__() == 'All[value=None]'
    All(1).__str__() == 'All[value=1]'
    All(1.0).__str__() == 'All[value=1.0]'
    All(False).__str__() == 'All[value=False]'
    All("").__str__() == 'All[value=""]'
    All(" ").__str__() == 'All[value=" "]'
    All("str").__str__() == 'All[value="str"]'


# Generated at 2022-06-24 00:32:17.019248
# Unit test for constructor of class One
def test_One():
    """
    In mathematics, a semigroup is an algebraic structure
    consisting of a set together with an associative binary operation.
    A semigroup generalizes a monoid in that there might not exist an identity element.
    It also (originally) generalized a group (a monoid with all inverses)
    to a type where every element did not have to have an inverse, this the name semigroup.
    """
    test = One(2)
    assert isinstance(test, One)
    assert test.value == 2


# Generated at 2022-06-24 00:32:18.785206
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)


# Generated at 2022-06-24 00:32:23.600238
# Unit test for method concat of class First
def test_First_concat():
    first = First(12)
    other_first = First('ff')
    res = first.concat(other_first)
    if res == 12:
        print("\ntest_First_concat: OK")
    else:
        raise AssertionError("\ntest_First_concat: FAILED")


# Generated at 2022-06-24 00:32:26.664551
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1)}).concat(Map({'a': Sum(1), 'b': Sum(2)})) == Map({'a': Sum(2), 'b': Sum(2)})

# Generated at 2022-06-24 00:32:29.422860
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    sum_value = Sum(2).fold(lambda x: x + 2)
    assert sum_value == 4


# Generated at 2022-06-24 00:32:34.464859
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'key1': Sum(1), 'key2': Sum(2)})) == "Map[value={'key1': Sum[value=1], 'key2': Sum[value=2]}]"



# Generated at 2022-06-24 00:32:40.980777
# Unit test for method concat of class Min
def test_Min_concat():
    assert (Min(5).concat(Min(3)) == Min(3))
    assert (Min(3).concat(Min(5)) == Min(3))
    assert (Min(5).concat(Min(5)) == Min(5))


# Generated at 2022-06-24 00:32:42.653764
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert type(Semigroup(1)) == Semigroup



# Generated at 2022-06-24 00:32:44.836706
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(5).value == 5
    assert Sum('5').value == '5'

# Unit test to compare 2 instances of class Sum

# Generated at 2022-06-24 00:32:45.833026
# Unit test for constructor of class Last
def test_Last():
    assert Last(2) == Last(2)

# Generated at 2022-06-24 00:32:48.707850
# Unit test for method concat of class Sum
def test_Sum_concat():
    left = Sum(5)
    right = Sum(3)
    concat = Sum(8)
    result = left.concat(right)
    assert result == concat


# Generated at 2022-06-24 00:32:55.598812
# Unit test for constructor of class Sum
def test_Sum():
    """
    Test case for constructor of class Sum
    """
    assert Sum(1) == Sum(1)
    assert Sum(2) == Sum(2)
    assert Sum(1) != Sum(2)

    assert Sum(1).fold(lambda x: x) == 1
    assert Sum(2).fold(lambda x: x) == 2

    assert Sum.neutral().value == 0


# Generated at 2022-06-24 00:33:06.625695
# Unit test for constructor of class Map
def test_Map():
    class MaxF(Max):
        def __str__(self):
            return 'MaxF[value={}]'.format(self.value)

    class MinF(Min):
        def __str__(self):
            return 'MinF[value={}]'.format(self.value)

    # Test for constructor of class Map
    m = Map({
        'maxF': MaxF(4),
        'minF': MinF(2)
    })
    assert str(m) == 'Map[value={\'maxF\': MaxF[value=4], \'minF\': MinF[value=2]}]'
    assert m.value == {'maxF': MaxF(4), 'minF': MinF(2)}

# Generated at 2022-06-24 00:33:09.373872
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup.neutral() == Semigroup(True)
    assert Semigroup.neutral() != Semigroup(False)
    assert Semigroup.neutral() != Semigroup(False)


# Generated at 2022-06-24 00:33:11.435221
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-24 00:33:13.106483
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(1)) == Min(1)



# Generated at 2022-06-24 00:33:16.771600
# Unit test for constructor of class One
def test_One():
    one = One(True)

    assert one.value == True


# Generated at 2022-06-24 00:33:20.471984
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(5) == Sum(5)
    assert Sum(5).value == 5
    assert Sum(5).fold(lambda x: x) == 5
    assert Sum(5).concat(Sum(3)).fold(lambda x: x) == 8
    assert Sum.neutral().value == 0



# Generated at 2022-06-24 00:33:23.771579
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(2).concat(Max(2)) == Max(2)



# Generated at 2022-06-24 00:33:30.078169
# Unit test for method concat of class All
def test_All_concat():
    assert Sum(3).concat(Sum(5)) == Sum(8)
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert First("Monoid").concat(First("Monoid")) == First("Monoid")

# Generated at 2022-06-24 00:33:32.242562
# Unit test for method __str__ of class Min
def test_Min___str__():
    t = Min(1)
    assert t.__str__() == "Min[value=1]"

# Generated at 2022-06-24 00:33:34.893633
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).fold(lambda current: current) == 1


# Generated at 2022-06-24 00:33:36.227209
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(42)) == 'Min[value=42]'


# Generated at 2022-06-24 00:33:41.059695
# Unit test for constructor of class Min
def test_Min():
    min1 = Min(4)
    assert min1.value == 4
    min2 = Min(3)
    assert min2.value == 3


# Generated at 2022-06-24 00:33:43.664413
# Unit test for method concat of class First
def test_First_concat():
    first = First('a')
    first2 = First('A')
    assert first.concat(first2) == first


# Generated at 2022-06-24 00:33:45.291600
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)

# Generated at 2022-06-24 00:33:46.693882
# Unit test for constructor of class Max
def test_Max():
    assert Max(30) == Max(30)
    assert str(First(30)) == 'Fist[value=30]'


# Generated at 2022-06-24 00:33:47.796614
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True


# Generated at 2022-06-24 00:33:52.822409
# Unit test for method concat of class Map
def test_Map_concat():
    topic = Map({"a":Sum(1), "b":Sum(2)})
    other = Map({"a":Sum(1), "b":Sum(1), "c":Sum(1)})
    assert topic.concat(other) == Map({"a":Sum(2), "b":Sum(3), "c":Sum(1)})

# Generated at 2022-06-24 00:33:57.302175
# Unit test for method __str__ of class Map
def test_Map___str__():
    print(Map({}))
    print(Map({'key1': Max(1)}))
    print(Map({'key1': Max(1), 'key2': Max(2)}))
    print(Map({'key1': Max(1), 'key2': Max(2), 'key3': Max(3)}))


# Generated at 2022-06-24 00:34:00.273849
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First('a')) == "Fist[value='a']"


# Generated at 2022-06-24 00:34:02.703092
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Unit test for method fold of class Semigroup
    """
    from math import sqrt
    assert Sum(5).fold(sqrt) == sqrt(5)

# Generated at 2022-06-24 00:34:07.807252
# Unit test for method concat of class Min
def test_Min_concat():
    """
    Test for concat method of class Min
    """
    # Arrange
    min_a = Min(2)
    min_b = Min(1)

    # Act
    min_c = min_a.concat(min_b)

    # Assert
    assert min_c.value == 1

# Generated at 2022-06-24 00:34:09.737130
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1
    assert Max(2).value == 2


# Generated at 2022-06-24 00:34:16.369621
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1), 'Should be First(1)'
    assert (
        First(1)
        .concat(First(2))
        .concat(First(3))
        .concat(First(4))
        .concat(First(5)) == First(1)
    ), 'Should be First(1)'


# Generated at 2022-06-24 00:34:20.144299
# Unit test for method __str__ of class Last
def test_Last___str__():
    # Define a value
    value = 6

    # Create a Last
    last = Last(value)

    assert str(last) == "Last[value=6]"

# Generated at 2022-06-24 00:34:24.932663
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(4) == Semigroup(4)
    assert Semigroup(4).fold(lambda x: x * 3) == 12


# Generated at 2022-06-24 00:34:30.847839
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'x': Sum(2)}).concat(Map({'x': Sum(2)})) == Map({'x': Sum(4)})
    assert Map({'x': Sum(2)}).concat(Map({'y': Sum(2)})) == Map({'x': Sum(2), 'y': Sum(2)})
    assert Map({'x': Sum(2)}).concat(Map({})) == Map({'x': Sum(2)})
    assert Map({'x': Sum(2)}).concat(Map({'x': Sum(5)})) == Map({'x': Sum(7)})
    assert Map({}).concat(Map({'x': Sum(2)})) == Map({'x': Sum(2)})



# Generated at 2022-06-24 00:34:32.158285
# Unit test for constructor of class All
def test_All():
    actual = All(True)
    expected = All(True)
    assert actual == expected


# Generated at 2022-06-24 00:34:35.077378
# Unit test for method concat of class All
def test_All_concat():
    all_ = All(True)
    assert all_.concat(All(False)) == All(False)
    assert all_.concat(All(True)) == All(True)


# Generated at 2022-06-24 00:34:36.329404
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert 'Max[value=4]' == str(Max(4))



# Generated at 2022-06-24 00:34:38.982577
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({"a": Sum(1), "b": Sum(2)})) == "Map[value={'a': Sum[value=1], 'b': Sum[value=2]}]"


# Generated at 2022-06-24 00:34:40.037242
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(-10) == Max(-10)
    assert Max(-10) != Sum(-10)


# Generated at 2022-06-24 00:34:42.109869
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2


# Generated at 2022-06-24 00:34:43.756702
# Unit test for constructor of class Max
def test_Max():
    assert Max(-2).value == -2


# Generated at 2022-06-24 00:34:46.447435
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)  # pylint: disable=comparison-with-itself


# Generated at 2022-06-24 00:34:49.075170
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'

# Generated at 2022-06-24 00:34:50.446622
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-24 00:34:54.861673
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(5).concat(Min(10)) == Min(5)
    assert Min(10).concat(Min(5)) == Min(5)
    assert Min(5).concat(Min(3)) == Min(3)
    assert Min(3).concat(Min(5)) == Min(3)

# Generated at 2022-06-24 00:34:55.874672
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(False)) == "All[value=False]"



# Generated at 2022-06-24 00:34:57.245275
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-24 00:34:58.491468
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    assert str(One(True)) == 'One[value=True]'



# Generated at 2022-06-24 00:35:00.003447
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map({'a': Sum(2)})
    map2 = Map({'a': Sum(4)})
    assert map1.concat(map2) == Map({'a': Sum(2 + 4)})

# Generated at 2022-06-24 00:35:00.824771
# Unit test for constructor of class First
def test_First():
    assert First(10).value == 10


# Generated at 2022-06-24 00:35:03.521674
# Unit test for method concat of class Max
def test_Max_concat():
    assert(Max(1).concat(Max(0)) == Max(1))
    assert(Max(0).concat(Max(10)) == Max(10))
    assert(Max(1.1).concat(Max(1.2)) == Max(1.2))


# Generated at 2022-06-24 00:35:04.787362
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(11)) == 'One[value=11]'



# Generated at 2022-06-24 00:35:10.696325
# Unit test for constructor of class Min
def test_Min():
    min_1 = Min(10)
    min_2 = Min(20)
    min_3 = Min(5)
    min_4 = min_2.concat(min_3)
    min_5 = min_1.concat(min_4)
    assert min_5.value == 5
    assert min_4.value == 5
    assert min_3.value == 5
    assert min_2.value == 20
    assert min_1.value == 10



# Generated at 2022-06-24 00:35:13.577664
# Unit test for method __str__ of class Map
def test_Map___str__():
    m = Map({'k1': Last(1), 'k2': Last(2)})
    assert str(m) == "Map[value={'k1': Last[value=1], 'k2': Last[value=2]}]"


# Generated at 2022-06-24 00:35:18.388184
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == "One[value=True]"
    assert str(One(False)) == "One[value=False]"


# Generated at 2022-06-24 00:35:20.690693
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1)})) == 'Map[value={\'a\': Sum[value=1]}]'
    assert str(Map({1: Sum(1)})) == 'Map[value={1: Sum[value=1]}]'


# Generated at 2022-06-24 00:35:23.162871
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'name': First('foo'), 'age': Max(38)}).concat(Map({'name': First('bar'), 'age': Max(41)})).concat(Map({'name': First('baz'), 'age': Max(42)})) == Map({'name': First('foo'), 'age': Max(42)})


# Generated at 2022-06-24 00:35:26.946997
# Unit test for constructor of class First
def test_First():
    first = First(1)
    assert first.value == 1


# Generated at 2022-06-24 00:35:28.595562
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)



# Generated at 2022-06-24 00:35:31.372321
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'



# Generated at 2022-06-24 00:35:32.458382
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == "Max[value=1]"



# Generated at 2022-06-24 00:35:35.678547
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).__class__ == Last


# Generated at 2022-06-24 00:35:44.365689
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    # asserting First semigroup
    assert First(100) == First(100)
    assert First(100) != First(1)
    assert First(100) == First(100)
    assert First(100) != First(1)
    assert First(100) == First(100)
    assert First(100) != First(1)

    # asserting Last semigroup
    assert Last(100) == Last(100)
    assert Last(100) != Last(1)
    assert Last(100) == Last(100)
    assert Last(100) != Last(1)
    assert Last(100) == Last(100)
    assert Last(100) != Last(1)

    # asserting All semigroup
    assert All(False) == All(False)
    assert All(False) != All(True)

# Generated at 2022-06-24 00:35:45.773505
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(5)) == 'Max[value=5]'



# Generated at 2022-06-24 00:35:47.210929
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-24 00:35:50.755248
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    assert str(Last(99)) == 'Last[value=99]'



# Generated at 2022-06-24 00:35:53.132265
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a':Sum(1), 'b':Sum(2)})) == "Map[value={'a': Sum[value=1], 'b': Sum[value=2]}]"


# Generated at 2022-06-24 00:35:57.500293
# Unit test for method concat of class One
def test_One_concat():
    class Name(Semigroup):
        def concat(self, other):
            return Name(self.value + ' ' + other.value)

    name = Name('Ophelia').concat(Name('Marie'))
    assert name == Name('Ophelia Marie')
    assert name != Name('Ophelia')



# Generated at 2022-06-24 00:36:04.760333
# Unit test for method concat of class Map
def test_Map_concat():
    # example with int:
    value = {
        1: Sum(1),
        2: Sum(2),
        3: Sum(3)
    }
    map = Map(value)
    map2 = Map({
        1: Sum(4),
        2: Sum(5),
        3: Sum(6)
    })
    result = Map.concat(map, map2)
    assert {
        1: Sum(5),
        2: Sum(7),
        3: Sum(9)
    } == result.value
    #example with string:
    value = {
        "one": All(True),
        "two": All(False),
        "three": All(True)
    }
    map = Map(value)

# Generated at 2022-06-24 00:36:05.724901
# Unit test for constructor of class Max
def test_Max():
    x = Max(3)

# Generated at 2022-06-24 00:36:07.374669
# Unit test for constructor of class Max
def test_Max():
    assert Max(5).value == 5
    assert Max(3).value == 3


# Generated at 2022-06-24 00:36:08.271881
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(2).value == 2


# Generated at 2022-06-24 00:36:15.756724
# Unit test for constructor of class Semigroup
def test_Semigroup():
    # Create list
    list_value = [1, 2, 3]

    # Create Semigroup instance
    instance = Semigroup(list_value)
    # Test attribute value
    assert instance.value == list_value

    # Test __eq__
    assert instance.__eq__(instance) == True

    # Test fold
    fn = lambda x: len(x)
    assert instance.fold(fn) == 3


# Generated at 2022-06-24 00:36:20.654450
# Unit test for constructor of class Min
def test_Min():
    """
    Test constructor of class Min
    """

    min = Min(1)
    assert min.value == 1

# Generated at 2022-06-24 00:36:26.678452
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    :return: test result
    :rtype: bool
    """

    assert (Sum(10) == Sum(10)) is True
    assert (Sum(10) == Sum(20)) is False
    assert (Sum(10) == All(False)) is False

    assert (All(10) == All(10)) is True
    assert (All(10) == All(20)) is False
    assert (All(10) == Sum(10)) is False

    assert (Min(10) == Min(10)) is True
    assert (Min(10) == Min(20)) is False
    assert (Min(10) == Sum(10)) is False

    assert (Max(10) == Max(10)) is True
    assert (Max(10) == Max(20)) is False
    assert (Max(10) == Sum(10)) is False

# Generated at 2022-06-24 00:36:32.260565
# Unit test for method __str__ of class Min
def test_Min___str__():
    cases = (
        (Min(5), 'Min[value=5]'),
        (Min(-1), 'Min[value=-1]'),
        (Min(4.6), 'Min[value=4.6]'),
        (Min('four.five'), 'Min[value=four.five]'),
    )
    for mt, result in cases:
        assert mt.__str__() == result

# Generated at 2022-06-24 00:36:34.529400
# Unit test for method __str__ of class First
def test_First___str__(): # pragma: no cover
    assert First(1).__str__() == "First[value=1]"


# Generated at 2022-06-24 00:36:37.570926
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Unit test for fold method of Semigroup
    """

    def sum(x, y):
        return x + y

    assert Semigroup(0).fold(sum) == 0



# Generated at 2022-06-24 00:36:41.043937
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(2) == Semigroup(2)
    assert Sum(2) != Semigroup(2)
    assert Semigroup(2) != Sum(2)
    assert Semigroup(2).value == 2
    assert Semigroup(2).fold(lambda x: x) == 2


# Generated at 2022-06-24 00:36:42.799154
# Unit test for method concat of class Last
def test_Last_concat():
    assert (Last(2).concat(Last(3)) == Last(3))

# Generated at 2022-06-24 00:36:44.099789
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-24 00:36:49.312649
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(True)) == All(False)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:36:52.104002
# Unit test for constructor of class Map
def test_Map():
    map_ = Map({'a': Sum(1), 'b': Min(2)})
    assert map_ == Map({'a': Sum(1), 'b': Min(2)})



# Generated at 2022-06-24 00:36:53.637110
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(5)) == 'Sum[value=5]'



# Generated at 2022-06-24 00:36:56.075066
# Unit test for method __str__ of class Max
def test_Max___str__(): # pragma: no cover
    assert str(Max(2)) == "Max[value=2]"


# Generated at 2022-06-24 00:37:02.961646
# Unit test for constructor of class One
def test_One():
    assert One(2) == One(2)
    assert not One(2) == One(3)
    assert not One(2) == 2
    assert not One(2) == One(2.0)
    assert One(2).equals(One(2))
    assert not One(2).equals(One(3))
    assert str(One(2)) == 'One[value=2]'


# Generated at 2022-06-24 00:37:06.900529
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(5) == Semigroup(5)
    assert Semigroup(5) != Semigroup(7)
    assert Semigroup('a') != Semigroup('b')
    assert Semigroup([1, 2, 3]) == Semigroup([1, 2, 3])
    assert Semigroup([1, 2, 3]) != Semigroup([1, 2, 4])


# Generated at 2022-06-24 00:37:08.587735
# Unit test for method __str__ of class Last
def test_Last___str__():
    obj = Last({'first': 1})
    assert str(obj) == "Last[value={'first': 1}]"



# Generated at 2022-06-24 00:37:09.950529
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(2) == Semigroup(2)
    assert Semigroup(2) != Semigroup(3)



# Generated at 2022-06-24 00:37:10.688622
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(4).value == 4


# Generated at 2022-06-24 00:37:14.026584
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'



# Generated at 2022-06-24 00:37:14.844286
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(2)) == "Sum[value=2]"


# Generated at 2022-06-24 00:37:20.345537
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    :returns: True if concat method of class Sum works correctly, otherwise it raises AssertionError
    :rtype: bool
    """
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(0)) == Sum(1)
    assert Sum(0).concat(Sum(2)) == Sum(2)
    assert Sum(0).concat(Sum(0)) == Sum(0)



# Generated at 2022-06-24 00:37:26.497347
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert First(1) == First(1)
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)


# Generated at 2022-06-24 00:37:28.281393
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(False).__str__() == 'One[value=False]'



# Generated at 2022-06-24 00:37:29.977436
# Unit test for method concat of class First
def test_First_concat():  # pragma: no cover
    assert First(5).concat(First(8)) == First(5)



# Generated at 2022-06-24 00:37:31.297457
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'



# Generated at 2022-06-24 00:37:33.521548
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(3)) == Min(2)
    assert Min(3).concat(Min(3)) == Min(3)



# Generated at 2022-06-24 00:37:34.988455
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    s = Sum(1)
    assert str(s) == 'Sum[value=1]'


# Generated at 2022-06-24 00:37:36.600937
# Unit test for constructor of class Last
def test_Last():
    with pytest.raises(NotImplementedError) as excinfo:
        Last(1)



# Generated at 2022-06-24 00:37:42.878680
# Unit test for constructor of class One
def test_One():
    actual = One(False)
    assert actual is not None
    assert actual.__class__ == One
    assert actual.value == False

    actual = One(True)
    assert actual is not None
    assert actual.__class__ == One
    assert actual.value == True



# Generated at 2022-06-24 00:37:45.759183
# Unit test for method concat of class Last
def test_Last_concat():
    result = Last(2).concat(Last(3))
    assert result == Last(3)


# Generated at 2022-06-24 00:37:49.162546
# Unit test for constructor of class All
def test_All():                           # pragma: no cover
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(0) == All(False)
    assert All(1) == All(True)


# Generated at 2022-06-24 00:37:53.209588
# Unit test for method __str__ of class First
def test_First___str__():
    first_1_instance = First(1)
    assert str(first_1_instance) == 'Fist[value=1]'


# Generated at 2022-06-24 00:37:59.500234
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:38:01.351514
# Unit test for constructor of class One
def test_One():  # pragma: no cover
    assert One.neutral() == One(One.neutral_element)
    assert One(True) == One(True)



# Generated at 2022-06-24 00:38:05.346805
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(2).value == 2
    assert Sum(2).concat(Sum(1)) == Sum(3)



# Generated at 2022-06-24 00:38:08.953259
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(3)) == 'Sum[value=3]'



# Generated at 2022-06-24 00:38:09.843270
# Unit test for method __str__ of class First
def test_First___str__():
    assert isinstance(str(First(1)), str)

# Generated at 2022-06-24 00:38:15.737472
# Unit test for method concat of class Map
def test_Map_concat():
    val1 = {1:Sum(1), 2: Sum(2)}
    val2 = {1:Sum(1), 2: Sum(2)}
    semigroup1_map = Map(val1)
    semigroup2_map = Map(val2)
    semigroup3_map = semigroup1_map.concat(semigroup2_map)
    assert semigroup3_map.value[1].value == 2
    assert semigroup3_map.value[2].value == 4

# Generated at 2022-06-24 00:38:19.517186
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: First(1)})) == 'Map[value={1: Fist[value=1]}]'



# Generated at 2022-06-24 00:38:22.160986
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1).__eq__(Semigroup(1)) == True
    assert Semigroup(1).__eq__(Semigroup(2)) == False

test_Semigroup___eq__()



# Generated at 2022-06-24 00:38:27.028459
# Unit test for method concat of class One
def test_One_concat():
    assert One(4).concat(One(5)) == One(4)
    assert One(None).concat(One(5)) == One(5)
    assert One(None).concat(One(None)) == One(None)
    assert One("hello").concat(One("world")) == One("hello")



# Generated at 2022-06-24 00:38:28.700026
# Unit test for constructor of class Max
def test_Max():
    max_value = Max(10)
    assert max_value.value == 10


# Generated at 2022-06-24 00:38:33.210020
# Unit test for method concat of class One
def test_One_concat():
    one_1 = One(True)
    one_2 = One(False)
    assert one_1.concat(one_1).value == True
    assert one_1.concat(one_2).value == True
    assert one_2.concat(one_1).value == True
    assert one_2.concat(one_2).value == False


# Generated at 2022-06-24 00:38:35.535438
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert Map({1: Sum(2), 3: Sum(4)}).__str__() == "Map[value={1: Sum[value=2], 3: Sum[value=4]}]"

# Generated at 2022-06-24 00:38:40.251632
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value == True
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
    assert All(False).concat(All(False)).value == False


# Generated at 2022-06-24 00:38:41.050806
# Unit test for method concat of class Min
def test_Min_concat():
    result = Min(3).concat(Min(5))
    assert result.value == 3

# Generated at 2022-06-24 00:38:44.003516
# Unit test for method __str__ of class Map
def test_Map___str__():
    # Test case
    map = Map({"1": Sum(1), "2": Sum(2)})
    # Assert
    assert str(map) == "Map[value={'1': Sum[value=1], '2': Sum[value=2]}]"

# Generated at 2022-06-24 00:38:47.542095
# Unit test for constructor of class Min
def test_Min():
    assert str(Min(5)) == 'Min[value=5]'
    assert str(Min(1)) == 'Min[value=1]'
    assert str(Min(3)) == 'Min[value=3]'

# Generated at 2022-06-24 00:38:50.635721
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)


# Generated at 2022-06-24 00:38:54.166804
# Unit test for constructor of class Max
def test_Max():
    m = Max(5)
    assert isinstance(m, Max)
    assert isinstance(m, Semigroup)
    assert isinstance(m, object)


# Generated at 2022-06-24 00:38:55.406195
# Unit test for constructor of class Sum
def test_Sum():
    sum = Sum(1)
    assert sum.value == 1


# Generated at 2022-06-24 00:38:59.110989
# Unit test for constructor of class Semigroup
def test_Semigroup():
    semigroup = Semigroup(5)

    assert semigroup.value == 5



# Generated at 2022-06-24 00:39:03.029371
# Unit test for method __str__ of class Map
def test_Map___str__():
    Map({'a': Sum(1)}).__str__() == 'Map[value={"a": Sum[value=1]}]'

# Generated at 2022-06-24 00:39:04.366698
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(4)) == 'Min[value=4]'

# Generated at 2022-06-24 00:39:06.536097
# Unit test for method concat of class Min
def test_Min_concat():
    min_1 = Min(1)
    min_2 = Min(2)
    assert min_1.concat(min_2) == Min(1)


# Generated at 2022-06-24 00:39:10.834278
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    '''
    >>> test_Semigroup_fold()
    'Semigroup fold'
    '''
    print('Semigroup fold')

    assert Sum(1).fold(lambda a: a + 1) == 2


# Generated at 2022-06-24 00:39:12.620491
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(10)) == "Sum[value=10]"



# Generated at 2022-06-24 00:39:16.557548
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)
    assert All(False) != All(True)



# Generated at 2022-06-24 00:39:17.805453
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1 + 2) == Sum(3)


# Generated at 2022-06-24 00:39:19.017763
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(2)) == 'Min[value=2]'


# Generated at 2022-06-24 00:39:20.743432
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'



# Generated at 2022-06-24 00:39:24.095324
# Unit test for method concat of class First
def test_First_concat():
    semigroup_1 = First(0)
    semigroup_2 = First(1)
    result = semigroup_1.concat(semigroup_2)
    assert result == First(0)


# Generated at 2022-06-24 00:39:25.556382
# Unit test for method concat of class First
def test_First_concat():
    assert First(5).concat(First(6)).value == 5



# Generated at 2022-06-24 00:39:28.489420
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    m = Last(1)
    assert m.__str__() == 'Last[value=1]'

    m = Last(None)
    assert m.__str__() == 'Last[value=None]'

    m = Last('abc')
    assert m.__str__() == 'Last[value=abc]'



# Generated at 2022-06-24 00:39:32.875066
# Unit test for method __str__ of class Map
def test_Map___str__():
    m = Map({'a': 'first', 'b': 'second'})
    assert str(m) == "Map[value={'a': 'first', 'b': 'second'}]"


if __name__ == '__main__':  # pragma: no cover
    test_Map___str__()

# Generated at 2022-06-24 00:39:34.968827
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(2).concat(Last(1)).value == 1
    assert Last(1).concat(Last(2)).value == 2


# Generated at 2022-06-24 00:39:39.041400
# Unit test for constructor of class Last
def test_Last():
    # Test with None value
    assert Last(None) == Last(None)
    # Test with integer value
    assert Last(1) == Last(1)
    # Test with float value
    assert Last(3.14) == Last(3.14)
    # Test with string value
    assert Last('last') == Last('last')


# Generated at 2022-06-24 00:39:40.678856
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(5)) == 'Last[value=5]'  # pragma: no cover


# Generated at 2022-06-24 00:39:43.518610
# Unit test for constructor of class Min
def test_Min(): # pragma: no cover
    min1 = Min(5)
    min2 = Min(10)
    assert min1.concat(min2) == Min(5)

# Generated at 2022-06-24 00:39:46.266777
# Unit test for constructor of class Min
def test_Min():
    m1 = Min(3)
    m2 = Min(5)
    assertMin(m1, 3)
    assertMin(m2, 5)



# Generated at 2022-06-24 00:39:47.094116
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(False)) == 'One[value=False]'



# Generated at 2022-06-24 00:39:48.279658
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2


# Generated at 2022-06-24 00:39:49.293161
# Unit test for constructor of class Max
def test_Max():
    assert Max(2) == Max(2)


# Generated at 2022-06-24 00:39:53.678289
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-24 00:39:58.758786
# Unit test for method concat of class Last
def test_Last_concat():
    t = Last(0)
    t1 = Last(3)
    print(t)
    print(t1)
    t2 = t.concat(t1)
    print(t2)
    expected = Last(3)
    assert t2 == expected


# Generated at 2022-06-24 00:40:00.315335
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1


# Generated at 2022-06-24 00:40:02.498425
# Unit test for constructor of class Last
def test_Last():
    assert Last(5).value == 5
    assert Last(5) == Last(5)
    assert Last(5) != 5
    assert Last('a') != 'a'



# Generated at 2022-06-24 00:40:03.813072
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'

# Generated at 2022-06-24 00:40:11.348301
# Unit test for constructor of class Semigroup
def test_Semigroup():
    # Neutral elements
    assert Sum(10) == Sum(10)
    assert Sum(10) != Sum(20)
    assert All(True) == All(True)
    assert All(True) != All(False)
    assert One(True) == One(True)
    assert One(True) != One(False)
    assert First(True) == First(True)
    assert First(True) != First(False)
    assert Last(True) == Last(True)
    assert Last(True) != Last(False)
    assert Map({}) == Map({})
    assert Map({}) != Map({'a': 1})
    assert Max(3) == Max(3)
    assert Max(3) != Max(20)
    assert Min(3) == Min(3)
    assert Min(3) != Min(20)

# Generated at 2022-06-24 00:40:14.380024
# Unit test for method concat of class First
def test_First_concat():
    s1 = First(20)
    s2 = First(5)
    assert s1.concat(s2).concat(s2) == s2

# Generated at 2022-06-24 00:40:17.708725
# Unit test for constructor of class Last
def test_Last():
    assert Last(4).value == 4



# Generated at 2022-06-24 00:40:18.991691
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(2)) == 'Sum[value=2]'



# Generated at 2022-06-24 00:40:22.849978
# Unit test for method concat of class One
def test_One_concat():
    find_true_1 = One(False)
    find_true_2 = One(True)
    find_true_3 = One(False)

    assert find_true_1.concat(find_true_2).value == True  # Returns the second value
    assert find_true_1.concat(find_true_3).value == False  # Returns the first value



# Generated at 2022-06-24 00:40:27.282621
# Unit test for constructor of class Map
def test_Map():
    map = Map({'hello': First(5), 'world': First(6)})
    assert map == Map({'hello': First(5), 'world': First(6)})



# Generated at 2022-06-24 00:40:29.387282
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == "Min[value=1]"


# Generated at 2022-06-24 00:40:31.212201
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)



# Generated at 2022-06-24 00:40:37.375991
# Unit test for method concat of class Map
def test_Map_concat():
    """
    >>> first_map = Map({1: Sum(1), 2: Sum(2), 3: Sum(3)})
    >>> second_map = Map({1: Sum(10), 2: Sum(20), 3: Sum(30)})
    >>> assert Map({1: Sum(11), 2: Sum(22), 3: Sum(33)}) == first_map.concat(second_map)
    """



# Generated at 2022-06-24 00:40:40.643428
# Unit test for constructor of class First
def test_First():
    assert First(1).concat(First(2)) == First(1)
    assert First(None).concat(First(True)) == First(None)
    assert First(None).concat(First(None)).value == None
    print('Test for constructor of class First has passed')


# Generated at 2022-06-24 00:40:43.159315
# Unit test for method concat of class Max
def test_Max_concat():
    m = Max(2)
    n = Max(8)
    assert m.concat(n).value == 8



# Generated at 2022-06-24 00:40:46.864640
# Unit test for constructor of class Max
def test_Max():
    assert Max(2).value == 2

    assert Max(2).concat(Max(3)).value == 3

    assert Max(2).concat(Max(1)).value == 2


# Generated at 2022-06-24 00:40:49.941548
# Unit test for constructor of class One
def test_One():
    actual = One(1)
    expected = 1
    assert actual == expected, "One failed"

test_One()


# Generated at 2022-06-24 00:40:51.188074
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(1)) == 'All[value=1]'



# Generated at 2022-06-24 00:40:59.381192
# Unit test for constructor of class Map
def test_Map():
    assert Map({}) == Map({})
    assert Map({"a": 1}) == Map({"a": 1})
    assert Map({"a": 1, "b": 2}) == Map({"a": 1, "b": 2})

    assert Map({"a": 1}).value == {"a": 1}
    assert Map({1: 1}).value == {1: 1}
    assert Map({1: Set([1])}).value == {1: Set([1])}
    assert Map({"a": 1, "b": 1}).value == {"a": 1, "b": 1}
    assert Map({"a": 1, "b": 2}).value == {"a": 1, "b": 2}
    


# Generated at 2022-06-24 00:41:00.694085
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(20)) == 'Min[value=20]'


# Generated at 2022-06-24 00:41:02.764443
# Unit test for method __str__ of class First
def test_First___str__():
    x = First('hello')
    assert str(x) == 'Fist[value={}]'.format('hello')


# Generated at 2022-06-24 00:41:04.119376
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-24 00:41:05.904622
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1).value == 1


# Generated at 2022-06-24 00:41:17.042792
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(None).concat(All(0)) == All(False)
    assert All(None).concat(All(1)) == All(True)
    assert All(None).concat(All(None)) == All(True)
    assert All(None).concat(All(None)) == All(True)
    assert All([]).concat(All([])) == All(True)
    assert All([]).concat(All([0])) == All(True)
    assert All([]).concat

# Generated at 2022-06-24 00:41:20.249778
# Unit test for constructor of class Last
def test_Last():
    "Test constructor of class Last"
    last = Last(5)
    assert last.value == 5
    assert last.last_value == last.value



# Generated at 2022-06-24 00:41:24.018975
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)
    assert not Min(1) == Min(2)
    assert Min(1).value == 1



# Generated at 2022-06-24 00:41:26.444465
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert Max(3).__str__() == 'Max[value=3]'


# Generated at 2022-06-24 00:41:30.558208
# Unit test for method concat of class Map
def test_Map_concat():
    test_values = {'a': Sum(1), 'b': Sum(2), 'c': Sum(3)}
    new_values = {'a': Sum(4), 'b': Sum(5), 'c': Sum(6)}
    assert Map(test_values).concat(Map(new_values)).value['a'] == Sum(5)
    assert Map(test_values).concat(Map(new_values)).value['b'] == Sum(7)
    assert Map(test_values).concat(Map(new_values)).value['c'] == Sum(9)

# Generated at 2022-06-24 00:41:32.495467
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)



# Generated at 2022-06-24 00:41:35.259513
# Unit test for method __str__ of class Max
def test_Max___str__():
    max_semigroup = Max(1)
    assert str(max_semigroup) == 'Max[value=1]'


# Generated at 2022-06-24 00:41:39.021105
# Unit test for method __str__ of class Min
def test_Min___str__():

    # Given
    m = Min(1)

    # When
    str_value = m.__str__()

    # Then
    assert str_value == "Min[value=1]"

