

# Generated at 2022-06-24 00:31:38.065540
# Unit test for constructor of class Map
def test_Map():
    test_obj = Map({'1': Sum(1)})
    assert (test_obj.value == {'1': Sum(1)})



# Generated at 2022-06-24 00:31:40.577095
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:31:42.792240
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"a": Sum(1), "b": Sum(3)}).concat(Map({"a": Sum(2), "b": Sum(3)})) ==  Map({"a": Sum(3), "b": Sum(6)})


# Generated at 2022-06-24 00:31:46.253694
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]', 'str(Min(1))'



# Generated at 2022-06-24 00:31:51.270057
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    :returns: Unit test for method fold for class Semigroup
    :rtype: bool
    """
    f = lambda x: x + 1
    m = Semigroup(1)
    assert m.fold(f) == 2
    return True



# Generated at 2022-06-24 00:31:53.978734
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    first = Sum(1)
    second = Sum(2)

    assert first == first
    assert not first == second
    assert not second == first



# Generated at 2022-06-24 00:31:55.746059
# Unit test for constructor of class Min
def test_Min():
    s = Min(1)
    assert isinstance(s, Min)
    assert s.value == 1


# Generated at 2022-06-24 00:31:57.763263
# Unit test for constructor of class First
def test_First():
    result = First('hello')
    expected = First('hello')
    assert result == expected



# Generated at 2022-06-24 00:31:59.933399
# Unit test for method concat of class Last
def test_Last_concat():
    value = Last(1)
    semigroup = Last(2)
    assert value.concat(semigroup) == Last(2)



# Generated at 2022-06-24 00:32:07.766814
# Unit test for method concat of class Map
def test_Map_concat():
    # Arrange
    m1 = {
        "key1": Min(6),
        "key2": Min(2),
        "key3": Min(7),
        "key4": Min(3),
    }
    m2 = {
        "key1": Min(1),
        "key2": Min(5),
        "key3": Min(5),
        "key4": Min(9),
    }
    m1_map = Map(m1)
    m2_map = Map(m2)
    # Act
    m1_map_concated = m1_map.concat(m2_map)
    # Assert

# Generated at 2022-06-24 00:32:09.981835
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == "Sum[value=1]"



# Generated at 2022-06-24 00:32:14.434183
# Unit test for method concat of class Min
def test_Min_concat():
    min1 = Min(2)
    min2 = Min(4)
    min_result = Min(min1.value if min1.value <= min2.value else min2.value)
    assert min1.concat(min2) == min_result


# Generated at 2022-06-24 00:32:17.091632
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(First(2)) == 'Fist[value=2]'



# Generated at 2022-06-24 00:32:18.829794
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)



# Generated at 2022-06-24 00:32:20.729514
# Unit test for method __str__ of class Last
def test_Last___str__(): 
    assert Last(123).__str__() == "Last[value=123]"


# Generated at 2022-06-24 00:32:30.024461
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Unit test for method fold of class Semigroup
    """
    assert 1 == Sum(1).fold(lambda x: x)
    assert 1 == All(1).fold(lambda x: x)
    assert 1 == One(1).fold(lambda x: x)
    assert 1 == First(1).fold(lambda x: x)
    assert 1 == Last(1).fold(lambda x: x)
    assert {1: Sum(1)} == Map({1: Sum(1)}).fold(lambda x: x)
    assert 1 == Max(1).fold(lambda x: x)
    assert 1 == Min(1).fold(lambda x: x)


# Generated at 2022-06-24 00:32:34.288218
# Unit test for method concat of class Min
def test_Min_concat():
    actual = Min(1).concat(Min(2))
    assert actual == Min(1)
    actual = Min(1).concat(Min(0.5))
    assert actual == Min(0.5)



# Generated at 2022-06-24 00:32:42.039305
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Sum(100).value == 100
    assert All(True).value == True
    assert One(False).value == False
    assert First(None).value == None
    assert Last('Last').value == 'Last'
    assert Map({'Key': 'Value'}).value == {'Key': 'Value'}
    assert Max(100).value == 100
    assert Min(0).value == 0
    print('::: unit test {}() ok :::'.format(test_Semigroup.__name__))


# Generated at 2022-06-24 00:32:51.082823
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert not Sum(1) == Sum(2)
    assert not Sum(2) == Sum(1)

    assert All(True) == All(True)
    assert not All(True) == All(False)
    assert not All(False) == All(True)

    assert One(True) == One(True)
    assert not One(True) == One(False)
    assert not One(False) == One(True)

    assert First(False) == First(False)
    assert First(True) == First(True)
    assert not First(False) == First(True)
    assert not First(True) == First(False)

    assert Last(False) == Last(False)
    assert Last(True) == Last(True)

# Generated at 2022-06-24 00:32:58.318206
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({1: Min(1), 2: Min(2)}).concat(Map({1: Min(3), 2: Min(4)})
                                           ) == Map({1: Min(1), 2: Min(2)})
    assert Map({1: Sum(1), 2: Sum(2)}).concat(Map({1: Sum(3), 2: Sum(4)})
                                           ) == Map({1: Sum(4), 2: Sum(6)})

# Generated at 2022-06-24 00:32:59.926744
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(2)) == 'Last[value=2]'


# Generated at 2022-06-24 00:33:05.379467
# Unit test for method concat of class Last
def test_Last_concat():  # pragma: no cover
    last_1 = Last(1)
    last_2 = Last(2)

    assert last_1.concat(last_2).value == 2
    assert Last(1).concat(last_1).value == 1
    assert last_1.concat(Last(2)).value == 2
    assert last_1.concat(Last(1)).value == 1


# Generated at 2022-06-24 00:33:07.785483
# Unit test for constructor of class Map
def test_Map():  # pragma: no cover
    Map({'key1': Min(1), 'key2': Min(2)}) == Map({'key1': Min(1), 'key2': Min(2)})



# Generated at 2022-06-24 00:33:13.554263
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value is True
    assert All(True).concat(All(False)).value is False
    assert All(False).concat(All(False)).value is False
    assert All(True).concat(All(True)).value is True
    assert All(False).concat(All(True)).value is False



# Generated at 2022-06-24 00:33:20.465913
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({0: First(5), 1: First(5), 2: First(5)})
    m2 = Map({0: First(3), 1: First(3), 2: First(3)})
    assert m1.concat(m2) == Map({0: First(5), 1: First(5), 2: First(5)})

# Generated at 2022-06-24 00:33:28.932032
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert (Sum(1) == Sum(1))
    assert (All(True) == All(True))
    assert (All(False) == All(False))
    assert (First(1) == First(1))
    assert (Last(1) == Last(1))
    assert (Map({"a": Sum(1)}))
    assert (Max(1) == Max(1))
    assert (Min(1) == Min(1))
    assert not (Sum(1) == Sum(2))
    assert not (All(True) == All(False))
    assert not (Max(1) == Max(2))
    assert not (Min(1) == Min(2))


# Generated at 2022-06-24 00:33:31.541751
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(3) == Sum(3)
    assert Sum(3) != Sum(2)


# Generated at 2022-06-24 00:33:32.916891
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == "One[value=True]"


# Generated at 2022-06-24 00:33:34.795946
# Unit test for method __str__ of class Min
def test_Min___str__(): # pragma: no cover
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-24 00:33:37.438836
# Unit test for method concat of class Last
def test_Last_concat():
    # Given that
    first = Last(1)
    second = Last(2)

    # When
    result = first.concat(second)

    # Then
    assert result.value == 2


# Generated at 2022-06-24 00:33:38.626229
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(False)) == 'All[value=False]'



# Generated at 2022-06-24 00:33:39.737104
# Unit test for method __str__ of class One
def test_One___str__():
    one = One(False)
    assert str(one) == 'One[value=False]'


# Generated at 2022-06-24 00:33:42.133882
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    x = Sum(15)
    assert str(x) == "Sum[value=15]"


# Generated at 2022-06-24 00:33:44.326425
# Unit test for constructor of class One
def test_One():  # pragma: no cover
    assert One(True) == One(True)



# Generated at 2022-06-24 00:33:48.131132
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    one = One(True)
    assert str(one) == "One[value=True]"
    one = One(False)
    assert str(one) == "One[value=False]"


# Generated at 2022-06-24 00:33:49.674424
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-24 00:33:50.896272
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)).value == 1



# Generated at 2022-06-24 00:33:55.131908
# Unit test for constructor of class Min
def test_Min():
    assert Min(2) == Min(2)
    assert Min(2).value == 2


# Generated at 2022-06-24 00:33:59.877900
# Unit test for method concat of class First
def test_First_concat():
    """
    Unit test for method concat of class First
    """
    assert First(0).concat(First(1)) == First(0)


# Generated at 2022-06-24 00:34:03.099167
# Unit test for constructor of class Map
def test_Map():
    """
    Test for constructor of class Map
    """
    m = Map({"a": Sum(4), "b": Sum(2)})
    assert m.value == {
        "a": Sum(4),
        "b": Sum(2),
    }


# Generated at 2022-06-24 00:34:06.278602
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(10)) == Sum(12)
    assert Sum(10).concat(Sum(2)) == Sum(12)



# Generated at 2022-06-24 00:34:09.783765
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(True) == All(True)
    assert All(True).neutral() == All(True)
    assert All(False) != All(True)
    assert All(False).value == False


# Generated at 2022-06-24 00:34:14.392231
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Sum(1).value == Semigroup(1).value
    assert All(True).value == Semigroup(True).value
    assert One(False).value == Semigroup(False).value
    assert First(1).value == Semigroup(1).value
    assert Last(1).value == Semigroup(1).value
    assert Min(1).value == Semigroup(1).value
    assert Max(1).value == Semigroup(1).value
    assert Map({"test": Sum(1)}).value == Semigroup({"test": Sum(1)}).value


# Generated at 2022-06-24 00:34:18.271274
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)).value == Last(2).value
    assert Last(1).concat(Last(2)).value is not Last(1).value
    assert Last(1).concat(Last(2)).value is not Last(2).value


# Generated at 2022-06-24 00:34:19.421978
# Unit test for constructor of class First
def test_First():
    x = First(1)
    assert str(x) == 'Fist[value=1]'


# Generated at 2022-06-24 00:34:20.883290
# Unit test for constructor of class Min
def test_Min():
    x = Min(4)
    y = Min(8)
    assert x.concat(y).value == x.value

# Generated at 2022-06-24 00:34:27.030791
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-24 00:34:28.686649
# Unit test for method __str__ of class Min
def test_Min___str__():
    semigroup = Min(1)
    assert str(semigroup) == 'Min[value=1]'


# Generated at 2022-06-24 00:34:30.927880
# Unit test for constructor of class Max
def test_Max():
    max_ = Max(3)
    assert max_
    assert max_.concat(Max(2)) == max_
    assert max_.concat(Max(100)) == Max(100)



# Generated at 2022-06-24 00:34:31.744288
# Unit test for constructor of class First
def test_First():
    first = First('A')
    assert first.value == 'A'


# Generated at 2022-06-24 00:34:34.044908
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First('hello')) == 'Fist[value=hello]'
    assert str(First([])) == 'Fist[value=[]]'


# Generated at 2022-06-24 00:34:35.470489
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)).value == 1

# Generated at 2022-06-24 00:34:38.459117
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).concat(One(2)) == One(True)
    assert One(0).concat(One(2)) == One(True)
    assert One(0).concat(One(0)) == One(False)



# Generated at 2022-06-24 00:34:42.743168
# Unit test for method __str__ of class Map
def test_Map___str__():
    """
    Unit test for method __str__ of class Map
    """
    dict_ = {1: 2, 3: 4}
    value = Map(dict_)
    assert str(value) == 'Map[value={1: 2, 3: 4}]'



# Generated at 2022-06-24 00:34:45.866861
# Unit test for method concat of class Sum
def test_Sum_concat():
    lhs = Sum(1)
    rhs = Sum(2)
    actual = lhs.concat(rhs)
    expected = Sum(3)
    assert actual == expected



# Generated at 2022-06-24 00:34:48.186538
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"


# Generated at 2022-06-24 00:34:58.516921
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(True) == One(True)
    assert First('A') == First('A')
    assert Last('A') == Last('A')
    assert First('A') == Last('A')
    assert Map({'A': Min(1), 'B': Max(2)}) == Map({'A': Min(1), 'B': Max(2)})
    assert Sum(1) != Sum(2)
    assert All(True) != All(False)
    assert One(True) != One(False)
    assert First('A') != First('B')
    assert Last('A') != Last('B')

# Generated at 2022-06-24 00:35:00.621141
# Unit test for method concat of class First
def test_First_concat():
    left = First(1)
    right = First(2)
    assert left.concat(right) == First(1)


# Generated at 2022-06-24 00:35:02.883532
# Unit test for constructor of class Max
def test_Max():
    assert Max(2) == Max(2)
    assert Max(-1) == Max(-1)
    assert Max(-1) != Max(-2)
    assert Max(-1).value == -1


# Generated at 2022-06-24 00:35:04.390085
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(True).__str__() == 'One[value=True]'


# Generated at 2022-06-24 00:35:10.340631
# Unit test for method concat of class Map
def test_Map_concat():
    from_list = Map({'a': Sum(1), 'b': Sum(2), 'c': Sum(3)})
    from_list2 = Map({'a': Sum(10), 'b': Sum(20), 'd': Sum(30)})

    result = Map({'a': Sum(11), 'b': Sum(22), 'c': Sum(3), 'd': Sum(30)})

    assert from_list.concat(from_list2) == result

# Generated at 2022-06-24 00:35:11.937339
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(0)) == "Min[value=0]", "Should be Min[value=0]"

# Generated at 2022-06-24 00:35:13.291609
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    def sum_identity(x):
        return x

    assert Semigroup(1).fold(sum_identity) == 1


# Generated at 2022-06-24 00:35:17.785764
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-24 00:35:19.100503
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == "Max[value=1]"


# Generated at 2022-06-24 00:35:20.482216
# Unit test for method __str__ of class One
def test_One___str__():
    x = One(True)
    assert One(True).__str__() == 'One[value={}]'.format(True)
    assert x == One(True)



# Generated at 2022-06-24 00:35:22.626673
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(123)) == 'Last[value=123]'

# Generated at 2022-06-24 00:35:23.828191
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-24 00:35:29.556565
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map(
        {'a': Sum(4), 'b': Sum(6)}
    )

# Generated at 2022-06-24 00:35:36.967772
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(0).concat(Last(1)) == Last(1)
    assert Last(0).concat(Last(0)) == Last(0)
    assert Last(0).concat(Last(1)).concat(Last(2)) == Last(2)
    assert Last(0).concat(Last(1)).concat(Last(2)).concat(Last(3)) == Last(3)
    assert Last(0).concat(Last(1)).concat(Last(2)).concat(Last(3)).concat(Last(4)) == Last(4)


# Generated at 2022-06-24 00:35:40.254895
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == "Sum[value=1]"


# Generated at 2022-06-24 00:35:45.491247
# Unit test for method concat of class All
def test_All_concat():

    assert All(True).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:35:47.004587
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)



# Generated at 2022-06-24 00:35:58.183513
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({0: Min(10), 1: Min(20)}).concat(Map({0: Min(31), 1: Min(2)})) == Map({0: Min(31), 1: Min(2)})
    assert Map({0: First(10), 1: First(20)}).concat(Map({0: First(31), 1: First(2)})) == Map({0: First(10), 1: First(20)})
    assert Map({0: Last(10), 1: Last(20)}).concat(Map({0: Last(31), 1: Last(2)})) == Map({0: Last(31), 1: Last(2)})

# Generated at 2022-06-24 00:35:59.481939
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'



# Generated at 2022-06-24 00:36:03.703365
# Unit test for constructor of class Sum
def test_Sum():
    sum = Sum(1)
    assert sum.value == 1
    assert str(sum) == 'Sum[value=1]'
    assert repr(sum) == 'Sum(1)'



# Generated at 2022-06-24 00:36:07.245007
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    Unit test for constructor of class Semigroup
    """

    assert Semigroup(5) == Semigroup(5)
    assert Semigroup(5).value == 5
    assert repr(Semigroup(5)) == "<Semigroup value=5>"


# Generated at 2022-06-24 00:36:09.775389
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == 'Map[value={\'a\': Sum[value=1], \'b\': Sum[value=2]}]'



# Generated at 2022-06-24 00:36:14.133049
# Unit test for method concat of class Sum
def test_Sum_concat():
    x = Sum(4)
    y = Sum(5)
    assert isinstance(x.concat(y), Sum)
    assert x.concat(y) == Sum(9)
    assert x.concat(y).concat(x) == Sum(13)
    assert x.concat(y).concat(x).concat(y) == Sum(18)



# Generated at 2022-06-24 00:36:19.315412
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    Unit test for constructor of class Semigroup
    """

    assert Sum(4) == Sum(4)
    assert Sum(4) != Sum(6)
    assert All(True).fold(lambda x: x) is True
    assert One(True).fold(lambda x: x) is True
    assert First(True).fold(lambda x: x) is True
    assert Last(True).fold(lambda x: x) is True
    assert Max(6).fold(lambda x: x) == 6
    assert Min(6).fold(lambda x: x) == 6

# Generated at 2022-06-24 00:36:20.677919
# Unit test for method __str__ of class First
def test_First___str__():
    value = "first"
    first = First(value)
    assert str(first) == 'Fist[value=first]'


# Generated at 2022-06-24 00:36:22.226788
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(2).fold(lambda val: val + 2) == 4



# Generated at 2022-06-24 00:36:25.048090
# Unit test for method __str__ of class Map
def test_Map___str__():
    expected = 'Map[value={0: Map[value=0], 1: Map[value=1], 2: Map[value=2]}]'
    assert str(Map({0: Map(0), 1: Map(1), 2: Map(2)})) == expected

# Generated at 2022-06-24 00:36:26.556162
# Unit test for method __str__ of class Min
def test_Min___str__():
    """
    Case "Min[value=Infinity]"
    """
    assert str(Min(float("inf"))) == "Min[value=Infinity]"


# Generated at 2022-06-24 00:36:30.518467
# Unit test for method concat of class Min
def test_Min_concat():
    first, second = Min(1), Min(3)
    assert first.concat(second).value == first.value
    assert second.concat(first).value == first.value
    assert first.concat(first).value == first.value



# Generated at 2022-06-24 00:36:33.930818
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({})) == "Map[value={}]"
    assert str(Map({'foo': 'bar'})) == "Map[value={'foo': 'bar'}]"



# Generated at 2022-06-24 00:36:38.433130
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    assert All(True).concat(All(True)).value == True
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
    assert All(False).concat(All(False)).value == False



# Generated at 2022-06-24 00:36:39.291061
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-24 00:36:44.440503
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(5).fold(lambda x: x) == 5
    assert All(True).fold(lambda x: x) == True
    assert One(False).fold(lambda x: x) == False
    assert First('first').fold(lambda x: x) == 'first'
    assert Last('last').fold(lambda x: x) == 'last'
    assert Map({'a': First(1), 'b': Last(2)}).fold(lambda x: x) == {'a': First(1), 'b': Last(2)}
    assert Max(5).fold(lambda x: x) == 5
    assert Min(5).fold(lambda x: x) == 5



# Generated at 2022-06-24 00:36:46.609197
# Unit test for method __str__ of class One
def test_One___str__():
    one = One(True)
    assert str(one) == 'One[value=True]'


# Generated at 2022-06-24 00:36:55.747780
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(0) == Sum(0)
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert First(0) == First(0)
    assert First(1) == First(1)
    assert Last(0) == Last(0)
    assert Last(1) == Last(1)
    assert Map({}) == Map({})
    assert Map({1: First(1)}) == Map({1: First(1)})
    assert Max(5) == Max(5)
    assert Max(3) == Max(3)
    assert Min(5) == Min(5)
    assert Min(3) == Min(3)

# Generated at 2022-06-24 00:36:59.213448
# Unit test for method __str__ of class Max
def test_Max___str__(): # pragma: no cover
    assert "Max[value=42]" == str(Max(42))



# Generated at 2022-06-24 00:37:00.728625
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)

# Generated at 2022-06-24 00:37:05.787628
# Unit test for method concat of class First
def test_First_concat():
    first_1 = First(10)
    first_2 = First(20)
    assert first_1.concat(first_2) == First(10), "Wrong!"


# Generated at 2022-06-24 00:37:11.406535
# Unit test for method concat of class First
def test_First_concat():  # pragma: no cover
    assert str(First(1).concat(First(2))) == 'Fist[value=1]'
    assert str(First(1).fold(lambda value: value)) == '1'
    assert str(First(None).concat(First(2))) == 'Fist[value=None]'


# Generated at 2022-06-24 00:37:14.694744
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'one': Sum(1)})) == 'Map[value={\'one\': Sum[value=1]}]'

# Generated at 2022-06-24 00:37:17.966052
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(4)) == Max(5)
    assert Max(4).concat(Max(5)) == Max(5)


# Generated at 2022-06-24 00:37:19.757895
# Unit test for constructor of class One
def test_One():
    o = One(True)
    assert o.value == True
    assert o.__str__() == "One[value=True]"
    o = One(False)
    assert o.value == False
    assert o.__str__() == "One[value=False]"


# Generated at 2022-06-24 00:37:22.356666
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]", "__str__"


# Generated at 2022-06-24 00:37:23.778515
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)).value == 2, 'Should be equal'


# Generated at 2022-06-24 00:37:25.474291
# Unit test for constructor of class Map
def test_Map():
    assert Map({"test": Sum(3)}) == Map({"test": Sum(3)})

# Generated at 2022-06-24 00:37:28.113598
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert not Sum(1) != Sum(1)
    assert Sum(1).value == 1



# Generated at 2022-06-24 00:37:29.785372
# Unit test for constructor of class First
def test_First():  # pragma: no cover
    assert First(1) == First(1)


# Generated at 2022-06-24 00:37:39.293800
# Unit test for constructor of class Max
def test_Max():  # pragma: no cover
    # Unit tests with empty value
    assert Max().value == -float("inf")
    # Unit tests with set value
    assert Max(10).value == 10
    assert Max(15).value == 15
    assert Max(1).value == 1
    assert Max(-2).value == -2
    assert Max(11.5).value == 11.5
    assert Max(-11.5).value == -11.5
    assert Max(1.1 + 0.1).value == 1.2
    # Unit tests with combined Max objects
    assert Max(10).concat(Max(15)).value == 15
    assert Max(15).concat(Max(10)).value == 15
    assert Max(1).concat(Max(2)).value == 2
    assert Max(2).concat(Max(1)).value == 2

# Generated at 2022-06-24 00:37:42.132367
# Unit test for constructor of class All
def test_All():
    all_1 = All(True)
    all_2 = All(False)
    assert all_1 == All(1)
    assert all_2 == All(None)


# Generated at 2022-06-24 00:37:45.294879
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x + 1) == 2


# Generated at 2022-06-24 00:37:48.075698
# Unit test for constructor of class One
def test_One():
    assert One(True)
    assert One(False)
    assert One([])
    assert One({})
    assert not One(None)
    assert not One(0)



# Generated at 2022-06-24 00:37:50.122222
# Unit test for constructor of class Last
def test_Last():  # pragma: no cover
    # arrange
    expected = Last(1)

    # act
    actual = Last(1)

    # assert
    assert actual == expected


# Generated at 2022-06-24 00:37:53.497647
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1
    assert Sum(4).value == 4
    assert Sum(5).concat(Sum(6)).value == 11

# Generated at 2022-06-24 00:37:59.428385
# Unit test for method concat of class First
def test_First_concat():
    f1 = First(1)
    f2 = First(2)
    assert f1.concat(f2) == First(1)
    f1 = First(1)
    f2 = None
    assert f1.concat(f2) == First(1)



# Generated at 2022-06-24 00:38:00.219798
# Unit test for constructor of class Semigroup
def test_Semigroup():
    semigroup = Semigroup(4)
    assert semigroup.value == 4


# Generated at 2022-06-24 00:38:09.973866
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    Unit test for method __eq__ of class Semigroup
    """
    assert All(True) == All(True)
    assert not All(True) == All(False)

    assert Max(16) == Max(16)
    assert not Max(16) == Max(17)

    assert First(15) == First(15)
    assert not First(15) == First(17)

    assert Last(16) == Last(16)
    assert not Last(16) == Last(17)

    assert Map({"key": Last(17)}) == Map({"key": Last(17)})
    assert not Map({"key": Last(17)}) == Map({"key": Last(18)})

    assert Min(-10) == Min(-10)
    assert not Min(-10) == Min(-9)

    assert One(False)

# Generated at 2022-06-24 00:38:11.678844
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(3)) == 'Sum[value=3]'



# Generated at 2022-06-24 00:38:16.087945
# Unit test for method concat of class Max
def test_Max_concat():

    max1 = Min(1)
    max2 = Min(5)
    max1.concat(max2)

    assert max1 == Min(1)
    assert max2 == Min(5)
    assert max1.concat(max2) == Min(1)
    assert max2.concat(max1) == Min(1)


# Generated at 2022-06-24 00:38:22.128957
# Unit test for method concat of class First
def test_First_concat():
    n1 = First(1)
    n2 = First(2)
    n3 = First(3)
    assert n1.concat(n2).value == 1
    assert n2.concat(n1).value == 1
    assert n1.concat(n3).value == 1
    assert n3.concat(n1).value == 1

# Generated at 2022-06-24 00:38:23.774461
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert repr(Max(10)) == 'Max[value=10]'


# Generated at 2022-06-24 00:38:27.265933
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__(): # pragma: no cover
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)
    assert All(False) != All(True)



# Generated at 2022-06-24 00:38:29.722532
# Unit test for constructor of class One
def test_One():
    """
    Test instatiation of class One.
    """

    test = One(1)

    assert isinstance(test, One)
    assert test.value == 1



# Generated at 2022-06-24 00:38:31.030792
# Unit test for constructor of class First
def test_First():
    assert First(8) == First(8)



# Generated at 2022-06-24 00:38:38.223848
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'
    assert str(Max(1.1)) == 'Max[value=1.1]'
    assert str(Max(1.1)) == 'Max[value=1.1]'
    assert str(Max(float("inf"))) == 'Max[value=inf]'
    assert str(Max(float("-inf"))) == 'Max[value=-inf]'
    assert str(Max(Max(1).neutral())) == 'Max[value=-inf]'
    assert str(Max(True)) == 'Max[value=True]'
    assert str(Max(False)) == 'Max[value=False]'
    assert str(Max(None)) == 'Max[value=None]'
    assert str(Max('a')) == 'Max[value=a]'
    assert str(Max(''))

# Generated at 2022-06-24 00:38:42.786761
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-24 00:38:43.901816
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-24 00:38:46.287168
# Unit test for method concat of class First
def test_First_concat():
    first = First('first')
    second = First('second')
    assert first.concat(second) == first


# Generated at 2022-06-24 00:38:52.229087
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-24 00:38:53.587438
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map(1)) == 'Map[value=1]'


# Generated at 2022-06-24 00:38:55.060081
# Unit test for constructor of class One
def test_One():
    # Semigroup
    t = One(True)
    f = One(False)
    assert isinstance(t, One)
    assert isinstance(f, One)


# Generated at 2022-06-24 00:38:56.869191
# Unit test for method concat of class Last
def test_Last_concat():
    last = Last(3)
    last1 = Last(4)

    assert last.concat(last1) == Last(4)


# Generated at 2022-06-24 00:38:58.949755
# Unit test for method concat of class First
def test_First_concat():
    first = First(['a', 'b'])
    other = First(['c', 'd'])
    expected = ['a', 'b']
    actual = first.concat(other).value
    assert expected == actual


# Generated at 2022-06-24 00:39:03.577404
# Unit test for method concat of class Last
def test_Last_concat():
    # Given
    a = Last('a')
    b = Last('b')

    # When
    when = a.concat(b)

    # Then
    assert when.value == 'b'


# Generated at 2022-06-24 00:39:08.137337
# Unit test for constructor of class Sum
def test_Sum():
    """
    This test shows that the Sum constructor requires 1 numeric argument.
    """

    try:
        sum1 = Sum(1)
        Sum(1.0)
        Sum('1')
    except TypeError:
        assert True
    else:
        assert False

    try:
        Sum()
        Sum(1, 1)
    except TypeError:
        assert True
    else:
        assert False



# Generated at 2022-06-24 00:39:13.981996
# Unit test for method __str__ of class Max
def test_Max___str__():
    from fptools import empty, foldl, compose, identity

    assert str(Max(0)) == 'Max[value=0]'

    items = range(10)
    foldMax = foldl(Max.neutral().concat)

    assert str(foldMax(items)) == "Max[value=9]"



# Generated at 2022-06-24 00:39:19.053908
# Unit test for method concat of class All
def test_All_concat():
    a = All(False)
    b = All(True)
    assert a.concat(a).value == a.value
    assert a.concat(b).value == b.value
    assert b.concat(a).value == a.value
    assert b.concat(b).value == b.value


# Generated at 2022-06-24 00:39:21.190784
# Unit test for method __str__ of class All
def test_All___str__():
    semigroup = All(10)
    assert str(semigroup) == "All[value=10]"



# Generated at 2022-06-24 00:39:24.935729
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(3)}).concat(Map({'a': Sum(2), 'b': Sum(4)})) == Map({'a': Sum(3), 'b': Sum(7)})



# Generated at 2022-06-24 00:39:28.453261
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    # Arrange
    semigroup = All(True)

    # Act
    actual_result = str(semigroup)

    # Assert
    assert actual_result == "All[value=True]"



# Generated at 2022-06-24 00:39:32.444849
# Unit test for constructor of class Last
def test_Last():
    semigroup = Last(2)
    assert isinstance(semigroup, Semigroup) == True
    assert isinstance(semigroup, Last) == True
    assert isinstance(semigroup.value, int) == True
    assert semigroup.value == 2


# Generated at 2022-06-24 00:39:34.920986
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(False))  == 'One[value=False]'
    assert str(One(True))  == 'One[value=True]'


# Generated at 2022-06-24 00:39:37.000814
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(False)) == 'One[value=False]'
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-24 00:39:38.527964
# Unit test for method __str__ of class Last
def test_Last___str__():
    inst = Last(3)
    assert str(inst) == "Last[value=3]"


# Generated at 2022-06-24 00:39:40.172628
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(3.14)) == 'Min[value=3.14]'


# Generated at 2022-06-24 00:39:41.611733
# Unit test for constructor of class First
def test_First():
    first = First(1)
    assert first.value == 1



# Generated at 2022-06-24 00:39:43.909556
# Unit test for constructor of class Last
def test_Last():
    assert Last(1)
    assert Last(1) == Last(1)
    assert Last(2) != Last(1)


# Generated at 2022-06-24 00:39:48.304749
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    """
    Testing concat method of class All, with some examples.
    """
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:39:49.324432
# Unit test for method __str__ of class First
def test_First___str__():
    assert eval(str(First(1))) == First(1)


# Generated at 2022-06-24 00:39:53.781224
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)



# Generated at 2022-06-24 00:39:57.843722
# Unit test for constructor of class Sum
def test_Sum():
    # given
    value = 0
    semigroup = Sum(value)
    # then
    assert semigroup.value == value
    assert str(semigroup) == 'Sum[value=0]'



# Generated at 2022-06-24 00:40:00.315851
# Unit test for method __str__ of class First
def test_First___str__():
    first = First(1)
    assert str(first) == 'Fist[value=1]'


# Generated at 2022-06-24 00:40:06.247855
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    ::

        semigroup = Semigroup(1)
        other_semigroup = Semigroup(1)
        assert semigroup == other_semigroup
        assert semigroup is not other_semigroup

        integer = 1
        assert semigroup != integer
    """
    pass


# Generated at 2022-06-24 00:40:08.012840
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-24 00:40:10.196632
# Unit test for constructor of class Min
def test_Min():
    assert Min(-2).value == -2

if __name__ == "__main__":  # pragma: no cover

    import os

    os.system("pytest -s test_semigroups.py")

# Generated at 2022-06-24 00:40:11.685618
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last('value')) == 'Last[value=value]'


# Generated at 2022-06-24 00:40:13.782041
# Unit test for constructor of class Min
def test_Min():
    minim = Min(10)
    assert minim.value == 10


# Generated at 2022-06-24 00:40:17.648654
# Unit test for constructor of class Min
def test_Min():
    assert Min(3) is not None


# Generated at 2022-06-24 00:40:18.850799
# Unit test for method __str__ of class One
def test_One___str__():
    assert repr(One(True)) == 'One[value=True]'


# Generated at 2022-06-24 00:40:19.702871
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(10).concat(Sum(20)) == Sum(30)



# Generated at 2022-06-24 00:40:25.782345
# Unit test for method concat of class All
def test_All_concat():
    """
    :returns: true if method concat of class All works correct
    :rtype: bool
    """
    truth_table = [
        (All(True), All(True), All(True)),
        (All(True), All(False), All(False)),
        (All(False), All(True), All(False)),
        (All(False), All(False), All(False))
    ]

    for pair in truth_table:
        print(f'Testing pair: {pair}')
        assert pair[0].concat(pair[1]) == pair[2]

    return True


# Generated at 2022-06-24 00:40:31.122729
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:40:32.617656
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)).value == 3



# Generated at 2022-06-24 00:40:34.547559
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'
    
    

# Generated at 2022-06-24 00:40:36.079519
# Unit test for constructor of class Last
def test_Last():
    """
    Test for constructor of class Last
    """
    assert Last(2).value == 2


# Generated at 2022-06-24 00:40:38.789673
# Unit test for method concat of class Min
def test_Min_concat():
    x = Min(3)
    y = Min(2)
    assert x.concat(y) == Min(2)
    assert x == Min(3)
    assert y == Min(2)



# Generated at 2022-06-24 00:40:45.239009
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(2).concat(First(1)) == First(2)
    assert First(1).concat(First(1)) == First(1)


# Generated at 2022-06-24 00:40:49.767854
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:40:53.735263
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)


# Generated at 2022-06-24 00:41:05.555639
# Unit test for method concat of class Map

# Generated at 2022-06-24 00:41:08.096328
# Unit test for constructor of class First
def test_First():  # pragma: no cover
    assert First("first") == First("first")
    assert First("first").concat(First("second")) == First("first")



# Generated at 2022-06-24 00:41:10.114071
# Unit test for constructor of class All
def test_All():
    initial = All(True)
    next = All("3")
    expected = All(True)

    actual = initial.concat(next)
    assert actual == expected



# Generated at 2022-06-24 00:41:13.262615
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == "One[value=True]"

# Generated at 2022-06-24 00:41:21.364642
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(2) == Sum(2)
    assert All(True) == All(True)
    assert One(True) == One(True)
    assert Map({"a": Sum(2), "b": Sum(3)}) == Map({"b": Sum(3), "a": Sum(2)})
    assert Max(2) == Max(2)
    assert Min(2) == Min(2)
    assert not (All(True) == All(False))
    assert not (All(True) == One(True))
    assert not (All(True) == Map({"a": Sum(2), "b": Sum(3)}))
    assert not (All(True) == Max(2))
    assert not (All(True) == Min(2))
    assert not (One(True) == All(True))

# Generated at 2022-06-24 00:41:22.749794
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(0)) == 'Max[value=0]'


# Generated at 2022-06-24 00:41:23.833730
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)).value == 2
    assert Max(2).concat(Max(1)).value == 2


# Generated at 2022-06-24 00:41:28.503442
# Unit test for method __str__ of class Map
def test_Map___str__():
    map_ = Map({'name': All('Jack'), 'is_king': All(True), 'age': Min(23)})
    assert str(map_) == "Map[value={'name': All[value=Jack], 'is_king': All[value=True], 'age': Min[value=23]}]"
    assert str(Map({})) == "Map[value={}]"



# Generated at 2022-06-24 00:41:30.081760
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First('a')) == 'Fist[value=a]'


# Generated at 2022-06-24 00:41:31.615209
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True) != All(False)



# Generated at 2022-06-24 00:41:36.338914
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(42) == Semigroup(42)
    assert Semigroup(42) != Semigroup(24)
    assert Semigroup(42) != 42
    assert str(Semigroup(42)) == 'Semigroup[value=42]'
    assert Semigroup(42).fold(lambda x: x) == 42
