

# Generated at 2022-06-24 00:31:38.128688
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True
    assert One(False).value == False


# Generated at 2022-06-24 00:31:45.246408
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    # Test fold on Sum
    assert Sum(1).fold(lambda x: x + 1) == 2
    # Test fold on Min
    assert Min(5).fold(lambda x: x + 1) == 6
    # Test fold on Last
    assert Last(1).fold(lambda x: x + 1) == 2
    # Test fold on First
    assert First(4).fold(lambda x: x + 1) == 5



# Generated at 2022-06-24 00:31:47.434439
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max('test')) == "Max[value='test']"


# Generated at 2022-06-24 00:31:48.564266
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'

# Generated at 2022-06-24 00:31:50.897854
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(100).concat(Max(50)) == Max(100)
    assert Max(100).concat(Max(200)) == Max(200)
    assert Max(100).concat(Max(100)) == Max(100)


# Generated at 2022-06-24 00:31:55.607450
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map({'c1': First(1), 'c2': First(2)})
    map2 = Map({'c1': First(1), 'c2': First(2)})
    result = map1.concat(map2)
    assert result.value == {'c1': First(1), 'c2': First(2)}

# Generated at 2022-06-24 00:32:00.341560
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:32:01.529096
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-24 00:32:02.995416
# Unit test for constructor of class Semigroup
def test_Semigroup():
    semigroup = Semigroup(10)
    assert semigroup.value == 10



# Generated at 2022-06-24 00:32:05.134453
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]", "test All __str__ method"


# Generated at 2022-06-24 00:32:06.543364
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(100) == Sum(100)
    assert Sum(100) != Sum(101)



# Generated at 2022-06-24 00:32:08.996258
# Unit test for method __str__ of class All
def test_All___str__():
    assert 'All[value=True]' == str(All(True))
    assert 'All[value=False]' == str(All(False))



# Generated at 2022-06-24 00:32:12.951922
# Unit test for constructor of class Max
def test_Max():
    """
    :returns: True if Max class is successfully created, False otherwise
    :rtype: Boolean
    """

    return Max(5) == Max(5)

# Generated at 2022-06-24 00:32:25.916624
# Unit test for method concat of class Min
def test_Min_concat():
    value1 = Min(1)
    value2 = Min(0)
    value3 = Min(-1)
    assert value3.concat(value1) == Min(-1)
    assert value2.concat(value3) == Min(-1)
    assert value1.concat(value2) == Min(0)
    
    value1 = Min(1.4344)
    value2 = Min(0.0000)
    value3 = Min(-0.3434)
    assert value3.concat(value1) == Min(-0.3434)
    assert value2.concat(value3) == Min(-0.3434)
    assert value1.concat(value2) == Min(0.0000)

    value1 = Min(-1)
    value2 = Min(0)

# Generated at 2022-06-24 00:32:26.619865
# Unit test for constructor of class Max

# Generated at 2022-06-24 00:32:32.048728
# Unit test for method concat of class Last
def test_Last_concat():  # pragma: no cover
    """
    Test concat function of class Last
    """
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(3.5).concat(Last(2)) == Last(2)
    assert Last(False).concat(Last(True)) == Last(True)



# Generated at 2022-06-24 00:32:34.287994
# Unit test for constructor of class First
def test_First():
    A = First(1)
    B = First(2)
    C = A.concat(B)
    assert C == A



# Generated at 2022-06-24 00:32:38.464412
# Unit test for constructor of class Sum
def test_Sum():
    sum_value = Sum(1)
    assert sum_value.value == 1

# Generated at 2022-06-24 00:32:40.705652
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First(1)) == "Fist[value=1]"



# Generated at 2022-06-24 00:32:43.554133
# Unit test for method concat of class Min
def test_Min_concat():  # pragma: no cover
    expected = Min(1)
    actual = Min(1).concat(Min(2))
    assert actual == expected



# Generated at 2022-06-24 00:32:44.247775
# Unit test for constructor of class Min
def test_Min(): # pragma: no cover
    assert Min(2) == Min(2)

# Generated at 2022-06-24 00:32:46.931885
# Unit test for constructor of class Min
def test_Min():
    assert Min(7) == Min(7)
    assert Min(float("inf")) == Min(float("inf"))
    assert Min(float("inf")) != Min(float("-inf"))


# Generated at 2022-06-24 00:32:48.708196
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    Pass constructor of Semigroup
    """
    assert Semigroup(42)



# Generated at 2022-06-24 00:32:51.744497
# Unit test for constructor of class Max
def test_Max():
    max1 = Max(10)
    max2 = Max(20)
    assert max1.value == 10
    assert max1.concat(max2).value == 20
    assert max2.concat(max1).value == 20


# Generated at 2022-06-24 00:32:59.726482
# Unit test for method concat of class Max
def test_Max_concat():
    import pytest
    # Test with positive number
    assert Max(2).concat(Max(1)).value == 2
    # Test with negative numbers
    assert Max(-2).concat(Max(-3)).value == -2
    # Test with negative and positive numbers
    assert Max(-2).concat(Max(2)).value == 2
    # Test with None
    with pytest.raises(TypeError):
        Max(None).concat(Max(1)).value
    # Test with string
    assert Max("1").concat(Max(2)).value == 2


# Generated at 2022-06-24 00:33:03.459692
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'
    assert str(Sum(None)) == 'Sum[value=None]'
    assert str(Sum('2')) == 'Sum[value=2]'



# Generated at 2022-06-24 00:33:06.736908
# Unit test for constructor of class All
def test_All():
    t = All(True)
    assert t.value is True
    assert t.fold(lambda x: x) is True
    t = All(False)
    assert t.value is False
    assert t.fold(lambda x: x) is False


# Generated at 2022-06-24 00:33:13.387357
# Unit test for method concat of class Map
def test_Map_concat():
    """
    :returns: True if tests of method Map.concat() were passed, False otherwise
    :rtype: bool
    """
    a = Map({1: Sum(2), 2: Sum(3)})
    b = Map({1: Sum(1), 2: Sum(2)})
    c = Map({1: Sum(3), 2: Sum(5)})
    return a.concat(b) == c



# Generated at 2022-06-24 00:33:14.644716
# Unit test for method concat of class First
def test_First_concat():
    assert str(First('First').concat(First('Second'))) == 'Fist[value=First]'


# Generated at 2022-06-24 00:33:15.637639
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-24 00:33:17.201844
# Unit test for constructor of class Min
def test_Min():
    assert Min(20) == Min(20)
    assert not Min(20) == Min(30)



# Generated at 2022-06-24 00:33:18.761199
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-24 00:33:23.901547
# Unit test for method concat of class All
def test_All_concat():
    All(True).concat(All(True)) == All(True)
    All(True).concat(All(False)) == All(False)
    All(False).concat(All(False)) == All(False)
    All(False).concat(All(True)) == All(False)


# Generated at 2022-06-24 00:33:26.736543
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True 
    assert All(False).value == False


# Generated at 2022-06-24 00:33:37.874090
# Unit test for constructor of class Map
def test_Map():
  assert Map({'a': First('aa'), 'b': First('bb')}) == Map({'a': First('aa'), 'b': First('bb')})
  assert Map({'a': First(3), 'b': First(5)}) == Map({'a': First(3), 'b': First(5)})
  assert Map({'a': First('aa'), 'b': First('bb')}) != Map({'a': First('aa'), 'b': First('cc')})
  assert Map({'a': First(3), 'b': First(5)}) != Map({'a': First(3), 'b': First(7)})
  assert Map({'a': First('aa'), 'b': First('bb')}) != Map({'a': First('aa'), 'c': First('bb')})

# Generated at 2022-06-24 00:33:39.077195
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-24 00:33:40.287600
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)



# Generated at 2022-06-24 00:33:43.718057
# Unit test for constructor of class Max
def test_Max():
    max_10 = Max(10)
    max_20 = Max(20)
    assert max_10 == Max(10)
    assert max_10 != Max(20)



# Generated at 2022-06-24 00:33:51.920657
# Unit test for method concat of class All
def test_All_concat():
    all = All(True)
    all2 = All(False)
    all3 = All(True)
    all4 = All(False)
    assert all.concat(all2) == All(False)
    assert all2.concat(all) == All(False)
    assert all.concat(all3) == All(True)
    assert all3.concat(all) == All(True)
    assert all2.concat(all4) == All(False)
    assert all4.concat(all2) == All(False)


# Generated at 2022-06-24 00:34:01.889974
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)
    assert Max(1).concat(Max(-2)) == Max(1)
    assert Max(-2).concat(Max(1)) == Max(1)
    assert Max(5.5).concat(Max(1.1)) == Max(5.5)
    assert Max(1.1).concat(Max(5.5)) == Max(5.5)


# Generated at 2022-06-24 00:34:05.034643
# Unit test for constructor of class Min
def test_Min():
    assert Min(24)

# Generated at 2022-06-24 00:34:15.316569
# Unit test for method concat of class Max
def test_Max_concat():
    a1 = Max(3)
    a2 = Max(4)
    a3 = Max(5)
    a4 = Max(6)
    a5 = Max(7)
    b1 = Max(3)
    b2 = Max(4)
    b3 = Max(5)
    b4 = Max(6)
    b5 = Max(7)
    assert a1.concat(a2).concat(a3).concat(a4).concat(a5).value == 7
    assert b1.concat(b2.concat(b3)).concat(b4).concat(b5).value == 7


# Generated at 2022-06-24 00:34:19.525888
# Unit test for method __str__ of class Max
def test_Max___str__():
    max_number = Max(10)
    assert str(max_number) == 'Max[value=10]'


# Generated at 2022-06-24 00:34:21.213284
# Unit test for constructor of class Map
def test_Map():
    M = Map({1: Sum(2)})
    assert M.value.__eq__({1: Sum(2)})



# Generated at 2022-06-24 00:34:28.060254
# Unit test for constructor of class All
def test_All():
    """
    Run unit test for constructor of class All
    """
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(1) == All(True)
    assert All(0) == All(False)
    assert All(1) < All(0)
    assert All(False) < All(True)
    assert All(None) < All(True)
    assert All(False) < All(1)



# Generated at 2022-06-24 00:34:29.728487
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(2) == Semigroup(2)
    assert Semigroup(2) != Semigroup(3)


# Generated at 2022-06-24 00:34:32.427840
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)



# Generated at 2022-06-24 00:34:35.511445
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    Unit test for method __eq__ of class Semigroup
    """
    # Arrange
    semigroup_1 = Sum(10)
    semigroup_2 = Sum(10)
    semigroup_3 = Sum(20)

    # Act
    result_1 = semigroup_1 == semigroup_1
    result_2 = semigroup_1 == semigroup_2
    result_3 = semigroup_1 == semigroup_3

    # Assert
    assert result_1
    assert result_2
    assert not result_3


# Generated at 2022-06-24 00:34:37.452718
# Unit test for method __str__ of class Min
def test_Min___str__():
    result = str(Min(5))
    expected = 'Min[value=5]'

    assert result == expected



# Generated at 2022-06-24 00:34:38.720711
# Unit test for constructor of class Last
def test_Last():
    assert Last([1, 2, 3]) == Last([1, 2, 3])

# Generated at 2022-06-24 00:34:41.801412
# Unit test for method concat of class First
def test_First_concat():
    a = First('first')
    b = First('second')
    c = a.concat(b)
    assert c == First('first')


# Generated at 2022-06-24 00:34:43.371401
# Unit test for constructor of class One
def test_One():
    one = One(True)
    assert one.value == True


# Generated at 2022-06-24 00:34:47.142665
# Unit test for method concat of class First
def test_First_concat():
    assert First(10).concat(First(20)).value == 10
    assert First(10).concat(First(20)).value == First(20).concat(First(10)).value


# Generated at 2022-06-24 00:34:48.978173
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup.neutral().fold(lambda _: 'ok') == 'ok'


# Generated at 2022-06-24 00:34:59.261743
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    result1 = Sum(2).fold(lambda x: x + 2).value
    result2 = All(True).fold(lambda x: x and True).value
    result3 = All(True).fold(lambda x: x and 1).value
    result4 = All(1).fold(lambda x: x and 1).value
    result5 = All(False).fold(lambda x: x and True).value
    result6 = All(False).fold(lambda x: x and 1).value
    result7 = All(0).fold(lambda x: x and 1).value
    result8 = All(None).fold(lambda x: x and True).value
    result9 = All(None).fold(lambda x: x and 1).value
    result10 = All('').fold(lambda x: x and True).value
    result11 = All('').fold

# Generated at 2022-06-24 00:35:01.829663
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert Map({1: Sum(1), 2: Sum(2)}).__str__() == 'Map[value={1: Sum[value=1], 2: Sum[value=2]}]'


test_Map___str__()



# Generated at 2022-06-24 00:35:06.994955
# Unit test for constructor of class Map
def test_Map():
    map_a = Map({1: Sum(1), 2: Sum(2)})
    map_b = Map({1: Sum(2), 3: Sum(1)})
    assert map_a.value == {1: Sum(1), 2: Sum(2)}
    assert map_a.concat(map_b).value == {1: Sum(3), 2: Sum(2), 3: Sum(1)}



# Generated at 2022-06-24 00:35:15.707159
# Unit test for method concat of class Min
def test_Min_concat():
    """
    Unit test for method concat of class Min.
    :return: test, results
    :rtype: boolean, string
    """
    t1 = Min(1)
    t2 = Min(2)

    test1 = t1.concat(t2)
    test2 = t2.concat(t1)

    return (test1.value == 1) and (test2.value == 1), "Min.concat"


if __name__ == '__main__':  # pragma: no cover

    def test(t):
        """
        Unit tests for this module.
        :return: test, results
        :rtype: boolean, string
        """
        function_name = t.__name__
        results = t()
        return results[0], function_name

    is_passed_all_

# Generated at 2022-06-24 00:35:17.102632
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-24 00:35:23.478074
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:35:29.141375
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert not Semigroup(1) == Semigroup(2)
    assert Semigroup(2) == Semigroup(2)
    assert not Semigroup(1) == Semigroup(True)


# Generated at 2022-06-24 00:35:31.873753
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-24 00:35:35.630979
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():  # pragma: no cover
    assert Sum(1).fold(lambda x: x + 1) == 2



# Generated at 2022-06-24 00:35:37.729524
# Unit test for constructor of class Max
def test_Max(): # pragma: no cover
    assert Max(1).value == 1
    assert Max("foo").value == 'foo'


# Generated at 2022-06-24 00:35:40.936779
# Unit test for constructor of class All
def test_All():
    """Test constructor of class All"""
    assert All(True).value is True
    assert All(False).value is False
    assert All(None).value is None
    assert All(1).value is 1
    assert All(True).__class__ == All

# Generated at 2022-06-24 00:35:43.755294
# Unit test for constructor of class First
def test_First():
    obj = First(1)
    assert (obj.value == 1)
    obj2 = First()
    assert (obj2.value == None)


# Generated at 2022-06-24 00:35:46.470338
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1)}).concat(Map({'a': Sum(2)})) == Map({'a': Sum(3)})



# Generated at 2022-06-24 00:35:50.662358
# Unit test for method concat of class Sum
def test_Sum_concat():  # pragma: no cover
    assert Sum(1).concat(Sum(2)).value == 3



# Generated at 2022-06-24 00:35:51.839983
# Unit test for constructor of class First
def test_First():
    assert First('first') == First('first')


# Generated at 2022-06-24 00:36:00.038982
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert All(True).fold(lambda x: x) == True
    assert All(False).fold(lambda x: x) == False
    assert Sum(1).fold(lambda x: x) == 1
    assert Sum(2).fold(lambda x: x) == 2
    assert One(True).fold(lambda x: x) == True
    assert One(False).fold(lambda x: x) == False
    assert First(1).fold(lambda x: x) == 1
    assert First(2).fold(lambda x: x) == 2
    assert Last(1).fold(lambda x: x) == 1
    assert Last(2).fold(lambda x: x) == 2
    assert Map({0: Sum(1)}).fold(lambda x: x) == {0: Sum(1)}
    assert Map({0: Sum(2)}).fold

# Generated at 2022-06-24 00:36:01.189482
# Unit test for constructor of class Last
def test_Last():
    assert Last(10) == Last(10)



# Generated at 2022-06-24 00:36:04.380109
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-24 00:36:07.159010
# Unit test for method concat of class Sum
def test_Sum_concat():
    semigroup_a = Sum(2)
    semigroup_b = Sum(3)
    assert semigroup_a.concat(semigroup_b) == Sum(5)


# Generated at 2022-06-24 00:36:11.875259
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(2) == Sum(2)
    assert All(False) == All(False)
    assert One([2]) == One([2])
    assert First("string") == First("string")
    assert Last("string") == Last("string")
    assert Map({1: 2}) == Map({1: 2})
    assert Max(2) == Max(2)
    assert Min(2) == Min(2)



# Generated at 2022-06-24 00:36:13.053630
# Unit test for constructor of class Min
def test_Min():
    assert Min(-1).value == -1


# Generated at 2022-06-24 00:36:16.596361
# Unit test for method concat of class Map
def test_Map_concat():
    map0 = Map({"a": Sum(1), "b": Sum(2)})
    map1 = Map({"a": Sum(3), "b": Sum(4)})
    result = Map({"a": Sum(4), "b": Sum(6)})
    assert map0.concat(map1) == result, "Map concat failed!"

# Generated at 2022-06-24 00:36:21.463728
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'



# Generated at 2022-06-24 00:36:28.310676
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    s1 = Sum(42)
    s2 = Sum(42)
    s3 = Sum(43)
    s4 = All(True)
    s5 = First(42)
    s6 = Max(42)

    assert s1 == s2
    assert not(s1 == s3)
    assert not(s1 == s4)
    assert not(s1 == s5)
    assert not(s1 == s6)
    assert not(s4 == s5)
    assert not(s4 == s6)
    assert not(s5 == s6)


# Generated at 2022-06-24 00:36:35.613545
# Unit test for method concat of class Sum
def test_Sum_concat():
    # test concat method
    assert Sum(2).concat(Sum(3)) == Sum(5)
    # test identity element
    assert Sum(3).concat(Semigroup.neutral(Sum)) == Sum(3)
    assert Sum(3) == Sum(3).concat(Semigroup.neutral(Sum))
    assert Semigroup.neutral(Sum).concat(Sum(3)) == Sum(3)
    assert Semigroup.neutral(Sum) == Semigroup.neutral(Sum).concat(Sum(3))



# Generated at 2022-06-24 00:36:37.037407
# Unit test for constructor of class First
def test_First():
    assert First("foobar").value == "foobar"

# Generated at 2022-06-24 00:36:38.654739
# Unit test for method __str__ of class Max
def test_Max___str__():
    m = Max(5)
    assert str(m) == 'Max[value=5]'



# Generated at 2022-06-24 00:36:39.530607
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last("str")) == "Last[value=str]"


# Generated at 2022-06-24 00:36:42.177903
# Unit test for constructor of class Sum
def test_Sum():
    left = Sum(0)
    right = Sum(1)
    assert(left.concat(right) == Sum(1))



# Generated at 2022-06-24 00:36:43.459408
# Unit test for constructor of class Last
def test_Last():
    last = Last(1)
    assert last.value == 1


# Generated at 2022-06-24 00:36:45.742598
# Unit test for method __str__ of class Last
def test_Last___str__():
    expectation = 'Last[value=1]'
    actual = str(Last(1))
    assert expectation == actual


# Generated at 2022-06-24 00:36:48.060886
# Unit test for constructor of class Min
def test_Min():  # pragma: no cover
    assert Min(1) == Min(1)



# Generated at 2022-06-24 00:36:51.354088
# Unit test for method __str__ of class All
def test_All___str__():
    all_false = All(False)
    assert 'All[value=False]' == all_false.__str__()

    all_true = All(True)
    assert 'All[value=True]' == all_true.__str__()


# Generated at 2022-06-24 00:36:53.277155
# Unit test for constructor of class Max
def test_Max():
    assert Max(9) == Max(9)
    assert Max(9).concat(Max(0)) == Max(9)


# Generated at 2022-06-24 00:36:58.880222
# Unit test for method __str__ of class Min
def test_Min___str__():
    semigroup_value = 5
    semigroup = Min(semigroup_value)
    assert str(semigroup) == 'Min[value={}]'.format(semigroup_value)


# Generated at 2022-06-24 00:37:01.612321
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    x = Semigroup(1)
    y = Semigroup(1)

    z = Semigroup(2)

    assert x == y
    assert x != z



# Generated at 2022-06-24 00:37:04.082614
# Unit test for constructor of class One
def test_One():
    assert not One(True);
    assert not One(False);
    assert One(None);
    assert One('');
    assert One(0);
    assert One(1)

# Generated at 2022-06-24 00:37:05.856389
# Unit test for method __str__ of class One
def test_One___str__():
    one = One(1)
    assert str(one) == 'One[value=1]'



# Generated at 2022-06-24 00:37:08.623949
# Unit test for method __str__ of class One
def test_One___str__():
    # Test with true value
    one = One(True)
    assert str(one) == 'One[value=True]'

    # Test with false value
    one = One(False)
    assert str(one) == 'One[value=False]'



# Generated at 2022-06-24 00:37:09.697246
# Unit test for constructor of class Last
def test_Last():
    last = Last('zero')
    assert last.value == 'zero'


# Generated at 2022-06-24 00:37:11.628340
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)


# Generated at 2022-06-24 00:37:17.015725
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True) != All(False)
    assert All(False) != All(True)
    assert All(False) == All(False)


# Generated at 2022-06-24 00:37:18.511896
# Unit test for method __str__ of class Map
def test_Map___str__():
    map_value = {'foo': 'bar'}
    result = Map(map_value).__str__()
    assert result == "Map[value={'foo': 'bar'}]", result


# Generated at 2022-06-24 00:37:23.708775
# Unit test for constructor of class One
def test_One():
    """
    :returns: [Success, Failed]
    :rtype: {str}
    """

    try:
        one = One(1)
        assert one.value == 1
    except AssertionError as e:
        print('One(1) Failed!')
        print(e)
        return 'Failed'
    print('One(1) Success!')
    return 'Success'



# Generated at 2022-06-24 00:37:28.882629
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'key1': Sum(1), 'key2': All(True), 'key3': Last('future')}).concat(
        Map({'key1': Sum(5), 'key2': All(True), 'key3': Last('future')})
    ) == Map({'key1': Sum(6), 'key2': All(True), 'key3': Last('future')})


# Generated at 2022-06-24 00:37:31.340637
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)


# Generated at 2022-06-24 00:37:35.617198
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(3).concat(Min(4)) == Min(3)
    assert Min(1).concat(Min(0)) == Min(0)
    assert Min(1).concat(Min(2)) == Min(1)



# Generated at 2022-06-24 00:37:42.058382
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First([1, 2, 4])) == 'Fist[value=[1, 2, 4]]'


# Generated at 2022-06-24 00:37:52.574805
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(Sum.neutral().concat) == Sum(1)
    assert All(True).fold(All.neutral().concat) == All(True)
    assert All(False).fold(All.neutral().concat) == All(False)
    assert One(False).fold(One.neutral().concat) == One(False)
    assert One(True).fold(One.neutral().concat) == One(True)
    assert Map({'a': Sum(1)}).fold(Map.neutral().concat) == Map({'a': Sum(1)})
    assert Max(5).fold(Max.neutral().concat) == Max(5)
    assert Min(2).fold(Min.neutral().concat) == Min(2)

# Generated at 2022-06-24 00:37:53.795073
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'



# Generated at 2022-06-24 00:37:56.159926
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(42)) == "Min[value=42]"

# Generated at 2022-06-24 00:37:58.863817
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'
# Tests for method concat of class Last

# Generated at 2022-06-24 00:38:01.050430
# Unit test for constructor of class Map
def test_Map():
    m = Map({'a': Sum(1), 'b': Sum(1)})
    assert m.value == {'a': Sum(1), 'b': Sum(1)}



# Generated at 2022-06-24 00:38:09.046670
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(100)) == 'Max[value=100]'
    assert str(Max(None)) == 'Max[value=None]'
    assert str(Max(False)) == 'Max[value=False]'
    assert str(Max(0)) == 'Max[value=0]'
    assert str(Max(True)) == 'Max[value=True]'
    assert str(Max(-1)) == 'Max[value=-1]'
    assert str(Max('')) == 'Max[value=]'
    assert str(Max('0')) == 'Max[value=0]'



# Generated at 2022-06-24 00:38:10.387486
# Unit test for constructor of class First
def test_First():
    f1 = First(1)
    assert f1.value == 1



# Generated at 2022-06-24 00:38:12.043349
# Unit test for constructor of class Sum
def test_Sum():
    assert_that(Sum(1), equal_to(Sum(1)))


# Generated at 2022-06-24 00:38:13.651498
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(0)



# Generated at 2022-06-24 00:38:15.662332
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]', "__str__ method of One instance doesn't work properly"


# Generated at 2022-06-24 00:38:19.784548
# Unit test for method __str__ of class One
def test_One___str__():
    # Arrange
    semigroup = One(True)

    # Act
    result = semigroup.__str__()

    # Assert
    assert result == 'One[value=True]'

# Generated at 2022-06-24 00:38:28.780422
# Unit test for method concat of class One
def test_One_concat():
    assert One("a").concat(One("b")) == One("b")
    assert One("a").concat(One("")) == One("a")
    assert One("").concat(One("")) == One("")
    assert One(False).concat(One("b")) == One("b")
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(False)) == One(True)
    assert One(1).concat(One(0)) == One(1)
    assert One(1).concat(One(2)) == One(2)
    assert One([1, 2]).concat(One([3, 4])) == One([3, 4])
    assert One([1, 2]).concat(One("a")) == One("a")

# Generated at 2022-06-24 00:38:31.297872
# Unit test for constructor of class Map
def test_Map():  # pragma: no cover
    m = Map({'a': Sum(1),'b': Sum(2)})
    assert m.value == {'a': Sum(1),'b': Sum(2)}



# Generated at 2022-06-24 00:38:32.869249
# Unit test for method __str__ of class Last
def test_Last___str__():
    instance = Last(2)
    assert 'Last[value=2]' == str(instance)


# Generated at 2022-06-24 00:38:34.793227
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'
    assert str(Max(-1)) == 'Max[value=-1]'



# Generated at 2022-06-24 00:38:37.887028
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    semigroup = Semigroup(5)

    assert semigroup.value == 5
    assert semigroup.fold(lambda x: x) == 5



# Generated at 2022-06-24 00:38:39.405996
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'



# Generated at 2022-06-24 00:38:40.782170
# Unit test for method concat of class Min
def test_Min_concat():
    assert_equal(Min(2).concat(Min(1)), Min(1))

# Generated at 2022-06-24 00:38:43.221321
# Unit test for constructor of class One
def test_One():
    assert isinstance(One(3), One)
    assert isinstance(One(True), One)
    assert isinstance(One(True), Semigroup)


# Generated at 2022-06-24 00:38:44.012486
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)).value == 2



# Generated at 2022-06-24 00:38:46.165322
# Unit test for method concat of class One
def test_One_concat(): 
    a = One(True)
    b = One(False)
    c = a.concat(b)
    d = b.concat(a)
    assert isinstance(c, One)
    assert isinstance(d, One)
    assert c.value == True
    assert d.value == True


# Generated at 2022-06-24 00:38:47.968677
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(5)) == 'Max[value=5]'



# Generated at 2022-06-24 00:38:49.998322
# Unit test for constructor of class All
def test_All():
    assert (All(True))
    assert (All(False))
    assert (All(None) == True)
    assert (All(1) == True)
    assert (All(2.2) == True)
    assert (All('something'))



# Generated at 2022-06-24 00:38:53.670054
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert not All(True) == All(False)
    assert All(True).value == True


# Generated at 2022-06-24 00:38:54.747316
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True) != All(False)


# Generated at 2022-06-24 00:38:58.965859
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)
    assert Min.neutral() == Min(Min.neutral_element)



# Generated at 2022-06-24 00:39:03.257037
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    Tests the constructor of class Semigroup
    """

    sg = Semigroup('')
    assert(sg.value == '')


# Generated at 2022-06-24 00:39:05.583143
# Unit test for constructor of class First
def test_First():
    first = First(2)
    first_instance = isinstance(first, First)
    first_value = first.value
    assert first_instance and first_value == 2


# Generated at 2022-06-24 00:39:07.406136
# Unit test for method concat of class Last
def test_Last_concat():  # pragma: no cover
    value = Last(5)
    semigroup = Last(2)
    assert value.concat(semigroup).value == 2



# Generated at 2022-06-24 00:39:09.064681
# Unit test for method __str__ of class Map
def test_Map___str__():
    expected = 'Map[value={}]'
    assert expected == str(Map({}))


# Generated at 2022-06-24 00:39:12.246992
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == "Max[value=1]"


# Generated at 2022-06-24 00:39:15.435409
# Unit test for method concat of class Max
def test_Max_concat():
    # Given
    given1 = Max(1)
    given2 = Max(2)

    # When
    actual = given1.concat(given2)

    # Then
    expected = Max(2)
    assert actual == expected



# Generated at 2022-06-24 00:39:16.413981
# Unit test for method __str__ of class Min
def test_Min___str__():
    print(Min(4))
    # Min[value=4]


# Generated at 2022-06-24 00:39:19.840312
# Unit test for method __str__ of class First
def test_First___str__():
    """
    Unit test for method __str__ of class First
    """
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First(3)) == 'Fist[value=3]'
    assert str(First('pp')) == "Fist[value=pp]"


# Generated at 2022-06-24 00:39:23.778211
# Unit test for method concat of class Max
def test_Max_concat():
    # given
    semigroup1 = Max(1)
    semigroup2 = Max(2)

    # when
    result = semigroup1.concat(semigroup2)

    # then
    assert result.value == 2



# Generated at 2022-06-24 00:39:33.203025
# Unit test for method concat of class All
def test_All_concat():
    """
    :returns: assert all concat value
    :rtype: bool
    """
    assert All(True).concat(All(True)).value
    assert not All(True).concat(All(False)).value
    assert not All(False).concat(All(False)).value
    assert All(True).concat(All(True)).concat(All(True)).value
    assert not All(False).concat(All(True)).concat(All(True)).value
    assert All(False).concat(All(True)).concat(All(False)).value
    assert All(False).concat(All(False)).concat(All(False)).value
    assert not All(True).concat(All(True)).concat(All(False)).value
    assert not All(False).concat(All(True)).concat

# Generated at 2022-06-24 00:39:37.727048
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)



# Generated at 2022-06-24 00:39:42.002168
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:39:43.962498
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(2).concat(Last(1)) == Last(1)



# Generated at 2022-06-24 00:39:46.587411
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'foo': Sum(3)}).concat(Map({'foo': Sum(2)})) == Map({'foo': Sum(5)})



# Generated at 2022-06-24 00:39:49.692788
# Unit test for constructor of class All
def test_All():
    all = All(True)
    assert all.value is True, 'All have not value of True'


# Generated at 2022-06-24 00:39:54.125579
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(False)) == "One[value=False]"
    assert str(One(True)) == "One[value=True]"


# Generated at 2022-06-24 00:40:04.504744
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert All(True).fold(bool) == True
    assert All(False).fold(bool) == False
    assert All(True).fold(bool) == True
    assert Max(2).fold(int) == 2
    assert Max(2).fold(str) == '2'
    assert Max(2).fold(float) == 2.0
    assert Last(3).fold(int) == 3
    assert Min(2).fold(int) == 2
    assert Min(2).fold(str) == '2'
    assert Min(2).fold(float) == 2.0
    assert Sum(2).fold(int) == 2
    assert Sum(2).fold(str) == '2'
    assert Sum(2).fold(float) == 2.0

# Generated at 2022-06-24 00:40:12.141628
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"1": Max(2)}) == Map({"1": Max(2)})
    assert Map({"1": Max(2)}) != Max(2)
    assert Map({"1": Max(2)}).concat(Map({"1": Max(3)})).value == {"1": Sum(5)}
    assert Map({"1": Max(2), "2": Min(4)}).concat(Map({"1": Max(3), "2": Max(4)})) == Map({"1": Sum(5), "2": Min(4)})



# Generated at 2022-06-24 00:40:14.826417
# Unit test for method concat of class First
def test_First_concat():
    """
    Return new First with first value
    """
    assert First(3).concat(First(5)) == First(3)


# Generated at 2022-06-24 00:40:20.392855
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)

# Generated at 2022-06-24 00:40:22.758726
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)

# Generated at 2022-06-24 00:40:23.740466
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-24 00:40:26.472789
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-24 00:40:27.338791
# Unit test for constructor of class Semigroup
def test_Semigroup():
    semigroup = Semigroup(4)
    assert semigroup.value == 4

# Generated at 2022-06-24 00:40:29.436682
# Unit test for constructor of class First
def test_First():
    val = First(1)
    assert val.value == 1


# Generated at 2022-06-24 00:40:31.674993
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert iseq([1, 2, 3], Semigroup([1, 2, 3]).fold(lambda a: a))


# Generated at 2022-06-24 00:40:33.930664
# Unit test for method concat of class Sum
def test_Sum_concat():  # pragma: no cover
    assert Sum(10).concat(Sum(100)) == Sum(110)



# Generated at 2022-06-24 00:40:44.197571
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():

    assert Sum(5) == Sum(5)
    assert Sum(5) != Sum(-5)

    assert First(5) == First(5)
    assert First(5) != First(-5)

    assert Last(5) == Last(5)
    assert Last(5) != Last(-5)

    assert Max(5) == Max(5)
    assert Max(5) != Max(-5)

    assert Min(5) == Min(5)
    assert Min(5) != Min(-5)

    assert All(True) == All(True)
    assert All(True) != All(False)

    assert One(True) == One(True)
    assert One(True) != One(False)

    # Map with equal keys and same types of values must be equals

# Generated at 2022-06-24 00:40:54.687348
# Unit test for method concat of class Map
def test_Map_concat():
    actual = Map({
        "a": Sum(1),
        "b": Sum(2),
        "c": Sum(3),
        "d": First("First"),
        "e": Last("Last"),
        "f": Max(1),
        "g": Min(2)
    })

    expected = Map({
        "a": Sum(11),
        "b": Sum(22),
        "c": Sum(33),
        "d": First("First"),
        "e": Last("Last"),
        "f": Max(11),
        "g": Min(22)
    })


# Generated at 2022-06-24 00:40:56.233898
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'

# Generated at 2022-06-24 00:41:00.522211
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert str(Sum(1).concat(Sum(2))) == 'Sum[value=3]'



# Generated at 2022-06-24 00:41:03.271150
# Unit test for method concat of class Max
def test_Max_concat():
    a = Max(10)
    b = Max(20)
    c = Max(40)
    d = a.concat(b).concat(c)

    assert d.value == 40


# Generated at 2022-06-24 00:41:04.292610
# Unit test for constructor of class Max
def test_Max():
    assert Max(6).value == 6


# Generated at 2022-06-24 00:41:08.012249
# Unit test for constructor of class Max
def test_Max():  # pragma: no cover
    a = Max(5)
    b = Max(3)
    print('Max(5) = ', a)
    print('Max(3) = ', b)
    assert a.value == 5
    assert b.value == 3



# Generated at 2022-06-24 00:41:15.651352
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max("1") == Max("1")
    assert Max("a") == Max("a")
    assert Max(True) == Max(True)
    assert Max([1, 1]) == Max([1, 1])
    assert Max((1, 1)) == Max((1, 1))
    assert Max(None) == Max(None)
    assert Max({1: 1}) == Max({1: 1})


# Generated at 2022-06-24 00:41:21.463213
# Unit test for constructor of class Last
def test_Last():
    # arrange


    # act
    first_last = Last(Sum(1))
    second_last = Last(Sum(2))
    third_last = Last(Sum(3))

    # assert
    assert first_last.concat(second_last).concat(third_last) == Last(Sum(3))

# Generated at 2022-06-24 00:41:24.412988
# Unit test for method __str__ of class First
def test_First___str__():
    first = First("value")
    result = first.__str__()
    assert result == "Fist[value=value]"


# Generated at 2022-06-24 00:41:27.295208
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"a": Sum(1), "b": Sum(2)}).concat(
        Map({"a": Sum(3), "b": Sum(4)})
    ).value == {"a": Sum(4), "b": Sum(6)}

# Generated at 2022-06-24 00:41:33.016245
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(3)) == Max(5)
    assert Max(3).concat(Max(5)) == Max(5)
    assert Max(5).concat(Max(-2)) == Max(5)
    assert Max(-2).concat(Max(5)) == Max(5)
    assert Max(-2).concat(Max(-5)) == Max(-2)
    assert Max(-5).concat(Max(-2)) == Max(-2)
    assert Max(0).concat(Max(0)) == Max(0)
    assert Max(0).concat(Max(-0)) == Max(0)
    assert Max(-0).concat(Max(0)) == Max(0)
    assert Max(-0).concat(Max(-0)) == Max(0)


# Generated at 2022-06-24 00:41:35.707233
# Unit test for constructor of class Sum
def test_Sum():
    # Given
    given = Sum(7)

    # Then
    expect = Sum(7)

    # Testing
    assert given == expect



# Generated at 2022-06-24 00:41:37.040288
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(3)) == "Last[value=3]"

