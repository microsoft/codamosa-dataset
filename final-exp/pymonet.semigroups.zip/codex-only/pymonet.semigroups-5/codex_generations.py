

# Generated at 2022-06-24 00:31:37.842388
# Unit test for constructor of class Last
def test_Last():
    l = Last(1)
    assert l.value == 1


# Generated at 2022-06-24 00:31:38.794453
# Unit test for method concat of class First
def test_First_concat():
    assert First(10).concat(First(20)).value == 10



# Generated at 2022-06-24 00:31:42.457720
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(10)) == 'Sum[value=10]'



# Generated at 2022-06-24 00:31:47.821060
# Unit test for constructor of class Sum
def test_Sum():
    from hypothesis import given
    from hypothesis.strategies import integers
    @given(integers())
    def test(x):
        Sum(x).fold(lambda x1: x1 == x)
    test()


# Generated at 2022-06-24 00:31:51.053440
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1).value == 1
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)
    assert Semigroup(3).fold(lambda x: x ** 2) == 9
    assert Semigroup.neutral().value == True
    assert Semigroup.neutral().value == False



# Generated at 2022-06-24 00:31:52.961680
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(1)) == "Sum[value=1]"



# Generated at 2022-06-24 00:31:54.379123
# Unit test for constructor of class Max
def test_Max():
    s = Max(1)
    assert s.value == 1



# Generated at 2022-06-24 00:31:56.263001
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(123).fold(fn=lambda x: x) == 123



# Generated at 2022-06-24 00:31:57.813413
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(4)) == 'Fist[value=4]'


# Generated at 2022-06-24 00:32:00.341555
# Unit test for constructor of class Map
def test_Map():
    x = Map({'a': Sum(1), 'b': Sum(2)})
    assert x.value == {'a': Sum(1), 'b': Sum(2)}


# Generated at 2022-06-24 00:32:02.186942
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)).value == 2
    assert Last('a').concat(Last('b')).value == 'b'

# Generated at 2022-06-24 00:32:06.340844
# Unit test for constructor of class One
def test_One():
    assert isinstance(One(True), One)
    assert isinstance(One(False), One)
    assert One(True).value == True
    assert One(False).value == False


# Generated at 2022-06-24 00:32:11.656006
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x + 1) == 2
    assert All(False).fold(lambda x: not x)
    assert One(True).fold(lambda x: not x)
    assert First("foo").fold(lambda x: x + "bar") == "foobar"
    assert Last("foo").fold(lambda x: x + "bar") == "bar"
    assert Map({"foo": Sum(1)}).fold(lambda x: x["foo"]) == Sum(1)
    assert Max(12).fold(lambda x: x + 1) == 13
    assert Min(2).fold(lambda x: x - 1) == 1

# Generated at 2022-06-24 00:32:13.826600
# Unit test for constructor of class All
def test_All():

    assert All(True) == All(True)
    assert All(False) == All(False)



# Generated at 2022-06-24 00:32:16.675418
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1


# Generated at 2022-06-24 00:32:21.662053
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
        Semigroup[T](T) -> Semigroup[T]
    """
    res = Semigroup(1)
    assert isinstance(res, Semigroup)

    res = Semigroup('str')
    assert isinstance(res, Semigroup)

    res = Semigroup(lambda x: x)
    assert isinstance(res, Semigroup)


# Generated at 2022-06-24 00:32:32.825910
# Unit test for constructor of class Min
def test_Min():
    # FIXME: Thông thường, constructors được test bằng cách cộng 2 số thứ nhất và thứ hai thu được giá trị tương ứng.
    #        Ở đây, như tiêu đề của class là "tổng", nên chúng ta cộng 2 số và so sánh với kết quả của phép cộng tương ứng.
    assert Min(1).con

# Generated at 2022-06-24 00:32:35.013203
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(3)) == Min(1)
    assert Min(3).concat(Min(1)) == Min(1)

# Generated at 2022-06-24 00:32:37.392336
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False


# Generated at 2022-06-24 00:32:38.758443
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)


# Generated at 2022-06-24 00:32:42.301748
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(1)) == Sum(3)

    assert Sum(2).concat(Sum(-1)) == Sum(1)

    assert Sum(0).concat(Sum(-5)) == Sum(-5)



# Generated at 2022-06-24 00:32:49.910198
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    a = All(False)
    b = All(False)
    assert (a.concat(b) == All(False))

    a = All(False)
    b = All(True)
    assert (a.concat(b) == All(False))

    a = All(True)
    b = All(False)
    assert (a.concat(b) == All(False))

    a = All(True)
    b = All(True)
    assert (a.concat(b) == All(True))



# Generated at 2022-06-24 00:32:51.908505
# Unit test for method __str__ of class Min
def test_Min___str__():
    a = Min(1)
    assert str(a) == 'Min[value=1]'


# Generated at 2022-06-24 00:32:56.329501
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-24 00:33:07.202547
# Unit test for constructor of class Map
def test_Map():
    # Case 1
    actual = Map({1: Sum(1), 2: Sum(2), 3: Sum(3)})
    expected = Map({1: Sum(1), 2: Sum(2), 3: Sum(3)})
    assert actual == expected
    assert actual.value == expected.value

    # Case 2
    actual = Map({4: Sum(4), 5: Sum(5), 6: Sum(6)})
    expected = Map({4: Sum(4), 5: Sum(5), 6: Sum(6)})
    assert actual == expected
    assert actual.value == expected.value

    # Case 3
    actual = Map({7: Sum(7), 8: Sum(8), 9: Sum(9)})
    expected = Map({7: Sum(7), 8: Sum(8), 9: Sum(9)})

# Generated at 2022-06-24 00:33:09.182805
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert(str(Sum(1)) == "Sum[value=1]")


# Generated at 2022-06-24 00:33:15.235519
# Unit test for method concat of class All
def test_All_concat():
    a = All(True)
    b = All(True)
    c = All(True)
    assert a.concat(b).concat(c).fold(lambda x: x) is True

    d = All(False)
    assert a.concat(d).fold(lambda x: x) is False

    e = All(False)
    assert d.concat(e).fold(lambda x: x) is False


# Generated at 2022-06-24 00:33:17.121407
# Unit test for constructor of class One
def test_One():
    """
    Unit test for constructor of class One
    """
    assert One(1) == One(1)



# Generated at 2022-06-24 00:33:18.702461
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(42)) == "Sum[value=42]"



# Generated at 2022-06-24 00:33:20.908903
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1


# Generated at 2022-06-24 00:33:22.257012
# Unit test for constructor of class All
def test_All():
    assert All(True).value
    assert not All(False).value



# Generated at 2022-06-24 00:33:23.804255
# Unit test for constructor of class Max
def test_Max():  # pragma: no cover
    assert Max(1) == Max(1)
    assert Max(-10) == Max(-10)


# Generated at 2022-06-24 00:33:24.787877
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'



# Generated at 2022-06-24 00:33:26.902382
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(2)) == 'Sum[value=2]'


# Generated at 2022-06-24 00:33:29.823225
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert Semigroup(0).value == 0
    assert Semigroup(1).value == 1


# Generated at 2022-06-24 00:33:32.192296
# Unit test for constructor of class Min
def test_Min():  # pragma: no cover
    min = Min(1)
    assert min.value == 1


# Generated at 2022-06-24 00:33:34.452833
# Unit test for constructor of class One
def test_One():
    one = One(True)
    assert one.value == True
    assert str(one) == 'One[value=True]'


# Generated at 2022-06-24 00:33:36.872155
# Unit test for constructor of class Last
def test_Last():
    last = Last('a')
    assert last.value == 'a'
    assert last == Last('a')
    assert last == Last('a')


# Generated at 2022-06-24 00:33:38.283915
# Unit test for method __str__ of class Max
def test_Max___str__():
    from expecter import expect
    expect(str(Max(1))) == 'Max[value=1]'


# Generated at 2022-06-24 00:33:40.679305
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'
    assert str(One(False)) == 'One[value=False]'
    assert str(One('Foo bar')) == 'One[value=Foo bar]'


# Generated at 2022-06-24 00:33:45.686594
# Unit test for method concat of class Map
def test_Map_concat(): # pragma: no cover
    result = Map({'a': Sum(1), 'b': Sum(2), 'c': Sum(3)}).concat(
        Map({'a': Sum(1), 'b': Sum(5), 'd': Sum(8)})
    )
    return result.value


# Generated at 2022-06-24 00:33:51.623460
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 2) == 3
    assert Semigroup([1, 2]).fold(lambda x: x[0] + x[1]) == 3
    assert Semigroup([1, 2, 'a']).fold(lambda x: x[0] + x[1] + len(x[2])) == 5

# Unit tests for method neutral of class Semigroup

# Generated at 2022-06-24 00:33:56.233672
# Unit test for constructor of class One
def test_One():
    assert One(True).concat(One(True)).fold(bool) == True
    assert One(False).concat(One(True)).fold(bool) == True
    assert One(True).concat(One(False)).fold(bool) == True
    assert One(False).concat(One(False)).fold(bool) == False


# Generated at 2022-06-24 00:33:56.988738
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1).value == 1



# Generated at 2022-06-24 00:33:59.384764
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1).value == 1
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-24 00:34:00.605738
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert Min(1) == Min(1)



# Generated at 2022-06-24 00:34:02.118363
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(25) == Sum(25)
    assert Sum(25).value == 25


# Generated at 2022-06-24 00:34:07.973548
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(3).concat(Min(2)) == Min(2)
    assert Min(3).concat(Min(-2)) == Min(-2)
    assert Min(-1).concat(Min(-2)) == Min(-2)


# Generated at 2022-06-24 00:34:09.916739
# Unit test for method concat of class All
def test_All_concat():
    res = All(True).concat(All(False))
    assert res == All(False)



# Generated at 2022-06-24 00:34:11.339730
# Unit test for constructor of class Max
def test_Max():    # pragma: no cover
    assert Max(1).value == 1


# Generated at 2022-06-24 00:34:13.555328
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-24 00:34:15.358795
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-24 00:34:19.206789
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert str(Max(0)) == 'Max[value=0]'



# Generated at 2022-06-24 00:34:26.888689
# Unit test for constructor of class Map
def test_Map():
    # Map
    assert Map({'a': Sum(1), 'b': First(0)}).value == {'a': Sum(1), 'b': First(0)}
    assert Map({'a': Sum(1), 'b': First(0)}).concat(Map({'a': Sum(1), 'b': First(0)})).value == {'a': Sum(2), 'b': First(0)}
    # Sum
    assert Sum(1).value == 1
    assert Sum(1).concat(Sum(1)).value == 2
    # First
    assert First(1).value == 1
    assert First(1).concat(First(2)).value == 1
    # Last
    assert Last(1).value == 1
    assert Last(2).concat(Last(1)).value == 1
    # All

# Generated at 2022-06-24 00:34:27.579271
# Unit test for constructor of class Map
def test_Map():
    Map(1)


# Generated at 2022-06-24 00:34:28.465363
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'


# Generated at 2022-06-24 00:34:31.238012
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    # Unit test for method __eq__ of class Semigroup
    assert First('a') == Last('a')
    assert First('a') != Last('b')
    assert First('a') != First('b')
    assert Last('a') != Last('b')



# Generated at 2022-06-24 00:34:32.529160
# Unit test for constructor of class Sum
def test_Sum():
    value = 123
    semigroup = Sum(value)
    assert semigroup.value == value


# Generated at 2022-06-24 00:34:34.860249
# Unit test for method concat of class First
def test_First_concat():
    first = First(1)
    second = First(2)
    assert first.concat(second) == Second(2)


# Generated at 2022-06-24 00:34:36.117227
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x) == 1

# Generated at 2022-06-24 00:34:38.761602
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1), "Semigroup __eq__ fail"
    assert Semigroup(1) != Semigroup(2), "Semigroup __eq__ fail"


# Generated at 2022-06-24 00:34:41.389543
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).value == 1
    assert Min(2).concat(Min(1)).value == 1


# Generated at 2022-06-24 00:34:44.675147
# Unit test for method __str__ of class Min
def test_Min___str__():
    value = -13.37
    instance = Min(value)
    assert type(instance.__str__()) is str
    assert 'Min[value=-13.37]' == instance.__str__()


# Generated at 2022-06-24 00:34:46.383302
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-24 00:34:51.531390
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    assert All(True).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:34:54.257390
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1).value == 1
    assert Semigroup(1).fold(lambda x: x) == 1


# Generated at 2022-06-24 00:34:56.092723
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    s = Sum(1)
    assert s.fold(lambda v: 2 * v) == 2


# Generated at 2022-06-24 00:35:05.100925
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Test fold of Semigroup
    """
    assert Semigroup(Sum(5)).fold(lambda a: a.value) == 5
    assert Semigroup(Sum(-5)).fold(lambda a: a.value) == -5
    assert Semigroup(All(True)).fold(lambda a: a.value) == True
    assert Semigroup(All(False)).fold(lambda a: a.value) == False
    assert Semigroup(First(5)).fold(lambda a: a.value) == 5
    assert Semigroup(First(True)).fold(lambda a: a.value) == True
    assert Semigroup(Last(5)).fold(lambda a: a.value) == 5
    assert Semigroup(Last(True)).fold(lambda a: a.value) == True

# Generated at 2022-06-24 00:35:06.768172
# Unit test for constructor of class Last
def test_Last():
    last_monoid = Last(1)
    assert last_monoid.value == 1
    assert str(last_monoid) == 'Last[value=1]'


# Generated at 2022-06-24 00:35:09.986504
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(4).concat(Max(2)) == Max(4)
    assert Max(4).concat(Max(4)) == Max(4)


# Generated at 2022-06-24 00:35:11.214826
# Unit test for method concat of class First
def test_First_concat():
    assert First('first').concat(First('mostly')) == First('first')


# Generated at 2022-06-24 00:35:17.931936
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({"a": Sum(3), "b": All(False), "c": Max(1)})
    m2 = Map({"a": Sum(7), "b": All(True), "c": Max(2)})
    m3 = m1.concat(m2)
    assert m3.value == {"a": Sum(10), "b": All(False), "c": Max(2)}


# Generated at 2022-06-24 00:35:22.741506
# Unit test for method concat of class Sum
def test_Sum_concat():
    # 1. True if Sum(2).concat(Sum(3)) == Sum(5) else False
    assert Sum(2).concat(Sum(3)) == Sum(5)

# Generated at 2022-06-24 00:35:24.312230
# Unit test for constructor of class First
def test_First():
    value = True
    assert(First(value))



# Generated at 2022-06-24 00:35:27.746226
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'



# Generated at 2022-06-24 00:35:31.991114
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map({"a": Sum(1), "b": Sum(2)})

    map2 = Map({"a": Sum(3), "b": Sum(4)})

    assert map1.concat(map2).value["a"] == Sum(4).value
    assert map1.concat(map2).value["b"] == Sum(6).value

# Generated at 2022-06-24 00:35:33.217109
# Unit test for method __str__ of class Map
def test_Map___str__():
    m = Map({})
    assert str(m) == 'Map[value={}]'



# Generated at 2022-06-24 00:35:37.211566
# Unit test for method __str__ of class First
def test_First___str__():
    first = First({'a': 2})
    assert str(first) == "Fist[value={'a': 2}]"


# Generated at 2022-06-24 00:35:41.404611
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    true = All(True)
    false = All(False)

    assert true.concat(true) == All(True)
    assert true.concat(false) == All(False)
    assert false.concat(true) == All(False)
    assert false.concat(false) == All(False)



# Generated at 2022-06-24 00:35:43.254730
# Unit test for constructor of class Sum
def test_Sum():
    sum_1 = Sum(1)
    assert sum_1.value == 1


# Generated at 2022-06-24 00:35:47.879635
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({"1": Min(1), "2": Sum(1)})
    m2 = Map({"1": Min(3), "3": Sum(3)})
    assert m1.concat(m2) == Map({"1": Min(1), "2": Sum(1), "3": Sum(3)})

# Generated at 2022-06-24 00:35:50.615817
# Unit test for method __str__ of class All
def test_All___str__():
    assert All(True).__str__() == 'All[value=True]'
    assert All(False).__str__() == 'All[value=False]'



# Generated at 2022-06-24 00:35:54.523626
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)).value == True
    assert One(None).concat(One(False)).value == False
    assert One(False).concat(One(True)).value == True
    assert One(True).concat(One(True)).value == True


# Generated at 2022-06-24 00:35:55.940775
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)).value == 3


# Generated at 2022-06-24 00:35:58.085750
# Unit test for constructor of class Sum
def test_Sum():
    s = Sum(3)
    assert s.value == 3, 'Should be 3'
    assert s.neutral_element == 0, 'Should be 0'


# Generated at 2022-06-24 00:35:59.673499
# Unit test for method __str__ of class First
def test_First___str__():
    first = First("Foo")
    assert str(first) == 'Fist[value=Foo]'


# Generated at 2022-06-24 00:36:01.245966
# Unit test for constructor of class Map
def test_Map():
    """
    :returns: True if class Map is created
    :rtype: Boolean
    """
    return Map({1: "test"})



# Generated at 2022-06-24 00:36:04.898333
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(3)).concat(Min(4)) == Min(2)

# Generated at 2022-06-24 00:36:09.859546
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert str(Max(10)) == 'Max[value=10]'


# Generated at 2022-06-24 00:36:10.672693
# Unit test for constructor of class Sum
def test_Sum():
    # Nothing to test
    pass



# Generated at 2022-06-24 00:36:15.799310
# Unit test for method concat of class Min
def test_Min_concat(): # pragma: no cover
    assert Min(1).concat(Min(2)).value == 1
    assert Min(2).concat(Min(1)).value == 1
# End of unit test



# Generated at 2022-06-24 00:36:18.177043
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(False)) == 'All[value=False]'
    assert str(All(True)) == 'All[value=True]'
    assert str(All(42)) == 'All[value=42]'


# Generated at 2022-06-24 00:36:19.382911
# Unit test for method __str__ of class Max
def test_Max___str__():
    result = Max(1)
    assert str(result) == 'Max[value=1]'



# Generated at 2022-06-24 00:36:20.279102
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(1)).value == 2



# Generated at 2022-06-24 00:36:21.850772
# Unit test for constructor of class Min
def test_Min():
    assert Min(5) == Min(5)


# Generated at 2022-06-24 00:36:26.342196
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-24 00:36:27.738706
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-24 00:36:29.272150
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)).value == 1


# Generated at 2022-06-24 00:36:32.706793
# Unit test for constructor of class Max
def test_Max():
    # Setup
    max0 = Max(0)
    
    # Exercise
    max1 = Max(1)
    
    # Verify
    assert max0.value == 0
    assert max1.value == 1


# Generated at 2022-06-24 00:36:35.464266
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"



# Generated at 2022-06-24 00:36:38.307320
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)

    assert All(True) != All(False)
    assert All(False) != All(True)



# Generated at 2022-06-24 00:36:39.537033
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-24 00:36:42.591711
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    result = Sum(1).__str__()

    assert type(result) == str # Test result type
    assert result == "Sum[value=1]" # Test result value



# Generated at 2022-06-24 00:36:44.230868
# Unit test for constructor of class Semigroup
def test_Semigroup():           # pragma: no cover
    semigroup = Semigroup(3)
    assert semigroup.value == 3


# Generated at 2022-06-24 00:36:47.143291
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    assert str(Last(1)) == 'Last[value=1]'
    assert str(Last('Hello')) == 'Last[value=Hello]'



# Generated at 2022-06-24 00:36:56.643688
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({1: Sum(1), 2: Sum(2)}).concat(Map({1: Sum(10), 2: Sum(20)})) == Map({1: Sum(11), 2: Sum(22)})
    assert Map({1: Sum(1), 2: Sum(2)}).concat(Map({2: Sum(20), 3: Sum(300)})) == Map({1: Sum(1), 2: Sum(22), 3: Sum(300)})
    assert Map({1: Sum(1), 2: Sum(2)}).concat(Map({3: Sum(300), 4: Sum(4000)})) == Map({1: Sum(1), 2: Sum(2), 3: Sum(300), 4: Sum(4000)})


# Generated at 2022-06-24 00:36:59.185462
# Unit test for method __str__ of class Map
def test_Map___str__():
    """
    Test case for method __str__ of class Map
    """
    map_ = Map({'a': All(False), 'b': All(True)})
    assert str(map_) == 'Map[value={\'a\': All[value=False], \'b\': All[value=True]}]'


test_Map___str__()

# Generated at 2022-06-24 00:37:01.572285
# Unit test for constructor of class Last
def test_Last():
    Last(2) == Last(2)
    isinstance(Last(3), Last)
    isinstance(Last(3), Semigroup)


# Generated at 2022-06-24 00:37:05.265023
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) != All(True)
    assert All(True).value == True


# Generated at 2022-06-24 00:37:06.289826
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)



# Generated at 2022-06-24 00:37:07.337497
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-24 00:37:08.444303
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(5)) == 'Last[value=5]'


# Generated at 2022-06-24 00:37:12.630157
# Unit test for method concat of class Map
def test_Map_concat():
    p = Map({'a': Sum(1), 'b': Sum(2), 'c': Sum(3)})
    q = Map({'a': Sum(2), 'c': Sum(4), 'd': Sum(5)})
    r = Map({'a': Sum(3), 'b': Sum(2), 'c': Sum(7), 'd': Sum(5)})
    assert p.concat(q) == r

test_Map_concat()


# Generated at 2022-06-24 00:37:18.251825
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-24 00:37:19.537691
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)



# Generated at 2022-06-24 00:37:21.721579
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)

# Generated at 2022-06-24 00:37:25.103523
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(0)
    assert First(1).value == 1



# Generated at 2022-06-24 00:37:29.931301
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False
    assert All(True).concat(All(True)).value == True
    assert All(False).concat(All(False)).value == False
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False


# Generated at 2022-06-24 00:37:31.250639
# Unit test for constructor of class One
def test_One():
    assert One(True).concat(One(False)) == One(True)


# Generated at 2022-06-24 00:37:33.485270
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    assert str(One(1)) == 'One[value=1]', 'str(One(1)) must be "One[value=1]"'


# Generated at 2022-06-24 00:37:38.094774
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)).concat(All(False)).concat(All(False)) == All(False)
    assert All(True).concat(All(False)).concat(All(True)).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:37:40.372111
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(4) == Sum(4)


# Generated at 2022-06-24 00:37:43.817226
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    sum = Sum(1)
    max = Max(1)
    all = All(True)
    assert sum.value == 1
    assert max.value == 1
    assert all.value == True



# Generated at 2022-06-24 00:37:45.571077
# Unit test for constructor of class Max
def test_Max():
    ab = Max(2)
    assert ab.value == 2


# Generated at 2022-06-24 00:37:47.301905
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(True)) == 'Fist[value=True]'


# Generated at 2022-06-24 00:37:48.524000
# Unit test for constructor of class Last
def test_Last():
    expected = Last(1)
    actual = Last(1)
    assert expected == actual

# Generated at 2022-06-24 00:37:52.812405
# Unit test for constructor of class Semigroup
def test_Semigroup():
    semigroup_one = Semigroup(1)
    assert semigroup_one.value == 1



# Generated at 2022-06-24 00:37:57.863150
# Unit test for constructor of class First
def test_First():
    assert First(True) == First(True)
    assert First(True) != First(False)
    assert First(False) == First(False)
    assert First(False) != First(True)


# Generated at 2022-06-24 00:37:59.113414
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(0)) == 'Fist[value=0]'



# Generated at 2022-06-24 00:38:00.514085
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-24 00:38:07.139892
# Unit test for method __str__ of class Map
def test_Map___str__():
    # Arrange
    value = {"First": 1, "Second": 2}
    expected = 'Map[value={First: 1, Second: 2}]'

    # Act
    result = Map(value)

    # Assert
    assert str(result) == expected



# Generated at 2022-06-24 00:38:09.843265
# Unit test for constructor of class Map
def test_Map():
    obj = Map({'a': Sum(20)})
    assert obj.value['a'].value == 20
    assert obj.concat(obj).value['a'].value == 40



# Generated at 2022-06-24 00:38:12.219386
# Unit test for constructor of class Min
def test_Min():
    assert Min(10) == Min(10)
    assert Min(10) != Max(10)
    assert Min(10) != Min(11)



# Generated at 2022-06-24 00:38:13.480403
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-24 00:38:18.332733
# Unit test for constructor of class One
def test_One():
    """
    test_One function is a unit test function.
    Test case with success and error.
    """
    try:
        # Test with success
        assert One(False).value == False
        assert One(True).value == True
    except AssertionError:
        # Test with error
        print('AssertionError')


# Generated at 2022-06-24 00:38:20.150515
# Unit test for constructor of class One
def test_One():
    assert One(5) == One(5)


# Generated at 2022-06-24 00:38:21.095830
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1



# Generated at 2022-06-24 00:38:23.044013
# Unit test for method __str__ of class Min
def test_Min___str__():  # pragma: no cover
    assert str(Min(1)) == 'Min[value=1]'



# Generated at 2022-06-24 00:38:27.164176
# Unit test for constructor of class Semigroup
def test_Semigroup():
    # all 4 assertions should be passed
    assert type(Sum(2)) == Sum
    assert type(All(True)) == All
    assert type(Last(3)) == Last
    assert type(Max(3)) == Max
    assert type(Min(3)) == Min
    assert type(Map({'a': 1})) == Map

# Generated at 2022-06-24 00:38:28.834593
# Unit test for constructor of class Last
def test_Last():
    last = Last(10)
    assert last.value == 10, "Constructor should set 'value' property"

# Generated at 2022-06-24 00:38:30.746271
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(0)) == "Sum[value=0]"
    assert str(Sum(1)) == "Sum[value=1]"



# Generated at 2022-06-24 00:38:33.035051
# Unit test for method __str__ of class One
def test_One___str__():
    """
    Unit test for method __str__ of class One
    """
    assert str(One(1)) == 'One[value=1]'



# Generated at 2022-06-24 00:38:34.556044
# Unit test for method __str__ of class Min
def test_Min___str__():
    expected = 'Min[value=1]'
    assert Min(1).__str__() == expected


# Generated at 2022-06-24 00:38:40.276672
# Unit test for method concat of class First
def test_First_concat():
    first1 = First("d")
    first2 = First("a")
    assert first1.concat(first2) == first1
    first1 = First("")
    assert first1.concat(first2) == first2
    first1 = First(None)
    assert first1.concat(first2) == first2
    first1 = First(None)
    first2 = First(None)
    assert first1.concat(first2) == first1
    first1 = First(0)
    first2 = First(None)
    assert first1.concat(first2) == first1
    first1 = First(0)
    first2 = First(3)
    assert first1.concat(first2) == first1
    first1 = First(-3)
    first2 = First(0)

# Generated at 2022-06-24 00:38:42.969905
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    Test that concat method of Sum monoid works properly.
    """

    semigroup: 'Sum' = Sum(2)
    semigroup_to_concat: 'Sum' = Sum(3)

    result = semigroup.concat(semigroup_to_concat)

    assert result.value == 5
    assert isinstance(result, Sum)



# Generated at 2022-06-24 00:38:50.221598
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(2) == Sum(2)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First('first') == First('first')
    assert Last('last') == Last('last')
    assert Map({'a': Sum(1), 'b': Sum(2)}) == Map({'a': Sum(1), 'b': Sum(2)})
    assert Max(5) == Max(5)
    assert Min(5) == Min(5)

# Generated at 2022-06-24 00:38:55.533580
# Unit test for method concat of class One
def test_One_concat():
    assert One(True) == One(True).concat(One(True))
    assert One(True) == One(False).concat(One(True))
    assert One(0) == One(False).concat(One(0))
    assert One(False) == One(False).concat(One(False))


# Generated at 2022-06-24 00:38:57.524418
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1) != 1


# Generated at 2022-06-24 00:39:02.891768
# Unit test for method concat of class Sum
def test_Sum_concat():  # pragma: no cover
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(3).concat(Sum(3)) == Sum(6)
    assert Sum(4).concat(Sum(5)) == Sum(9)


# Generated at 2022-06-24 00:39:04.910874
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(2).concat(Min(2)) == Min(2)



# Generated at 2022-06-24 00:39:06.419333
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)


# Generated at 2022-06-24 00:39:08.336981
# Unit test for method concat of class Max
def test_Max_concat():
    assert 3 == Max(1).concat(Max(3)).value
    assert 2 == Max(2).concat(Max(1)).value


# Generated at 2022-06-24 00:39:12.883499
# Unit test for method concat of class Last
def test_Last_concat():  # pragma: no cover
    assert Last('b').concat(Last('b')).concat(Last('a')).value == 'a'


# Generated at 2022-06-24 00:39:16.040330
# Unit test for constructor of class Min
def test_Min():
    min = Min(1)
    assert min.value == 1
    assert min.__eq__(min)


# Generated at 2022-06-24 00:39:20.748275
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    str(One(False)) == 'One[value=False]'
    str(One(5)) == 'One[value=5]'
    str(One(None)) == 'One[value=None]'
    str(One('hello world!')) == 'One[value=hello world!]'

    # raise exception with unexpected type
    try:
        str(One([]))
        assert False
    except:
        assert True


# Generated at 2022-06-24 00:39:21.608916
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-24 00:39:27.970419
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(3)) == Min(2)
    assert Min(3).concat(Min(2)) == Min(2)
    assert Min(2).concat(Min(2)) == Min(2)


# Generated at 2022-06-24 00:39:34.412554
# Unit test for constructor of class One
def test_One():
    """
    Check if an instance of 'One' is defined correctly
    """
    one = One(True)

    # if properties exists
    assert hasattr(one, "value")

    # Check the type of an instance attribute
    assert isinstance(one.value, bool)

    

# Generated at 2022-06-24 00:39:39.642038
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)).value == One(False).concat(One(False)).value == True
    assert One(True).concat(One(False)).value == One(False).concat(One(True)).value == True


# Generated at 2022-06-24 00:39:43.316842
# Unit test for constructor of class Map
def test_Map():
    assert Map({1: Sum(1), 2: Sum(3), 3: Sum(5)}).value[1].value == 1
    assert Map({1: Sum(1), 2: Sum(3), 3: Sum(5)}).value[2].value == 3
    assert Map({1: Sum(1), 2: Sum(3), 3: Sum(5)}).value[3].value == 5


# Generated at 2022-06-24 00:39:45.769710
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: 1, 2: 2})) == 'Map[value={1: 1, 2: 2}]'



# Generated at 2022-06-24 00:39:47.956677
# Unit test for constructor of class Min
def test_Min():  # pragma: no cover
    assert Min(1) == Min(1)
    assert Min(2) != Min(1)
    assert Min(1) != All(1)
    assert Min(2) != All(1)


# Generated at 2022-06-24 00:39:50.700558
# Unit test for method concat of class Max
def test_Max_concat():
    max1 = Max(1)
    max2 = Max(2)
    assert max1.concat(max2) == Max(2)


# Generated at 2022-06-24 00:39:52.278377
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(3).concat(Last(4)) == Last(4)



# Generated at 2022-06-24 00:39:56.995468
# Unit test for method concat of class All
def test_All_concat():
    """
    Purpose: test concat method
    Preconditions:
        :param semigroup: Semigroup instance
    Post-conditions:
        :return: new Semigroup instance with expected value
    Test-cases:
        >>> test_All_concat()
        True
    """
    semigroup = All(True)
    new_semigroup = semigroup.concat(All(False))
    return new_semigroup.value == False



# Generated at 2022-06-24 00:39:59.011709
# Unit test for method __str__ of class Max
def test_Max___str__():
    semigroup = Max(1)
    assert str(semigroup) == 'Max[value=1]'


# Generated at 2022-06-24 00:40:01.254931
# Unit test for method concat of class Sum
def test_Sum_concat():

    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-24 00:40:02.862798
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert Min(2).__str__() == "Min[value=2]"


# Generated at 2022-06-24 00:40:04.050986
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert str(Max(1)) == "Max[value=1]"


# Generated at 2022-06-24 00:40:07.748799
# Unit test for method concat of class Map
def test_Map_concat():
    data1 = {'a': Map({'a': First(1), 'c': Min(2)}), 'b': Min(1)}
    data2 = {'a': Map({'a': First(2), 'c': Min(1)}), 'b': Sum(1)}
    assert data1 == data2.concat(data1).value


# Generated at 2022-06-24 00:40:08.860595
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(3).fold(lambda values: values) == 3



# Generated at 2022-06-24 00:40:11.158931
# Unit test for method __str__ of class All
def test_All___str__():
    assert 'All[value=True]' == str(All(True))
    assert 'All[value=False]' == str(All(False))


# Generated at 2022-06-24 00:40:12.344692
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': 1})) == 'Map[value={\'a\': 1}]'



# Generated at 2022-06-24 00:40:14.527326
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1
    assert First('a').value == 'a'


# Generated at 2022-06-24 00:40:19.080126
# Unit test for method concat of class First
def test_First_concat():
    first = First(1)
    other_first = First(2)
    expected = First(1)
    assert first.concat(other_first).value == expected.value

# Generated at 2022-06-24 00:40:20.704774
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'one': Sum(1), 'two': Sum(2)})) == "Map[value={'one': Sum[value=1], 'two': Sum[value=2]}]"


# Generated at 2022-06-24 00:40:21.568402
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-24 00:40:23.620860
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(3)) == Max(3)
    assert Max(1).concat(Max(1)) == Max(1)
    assert Max(3).concat(Max(1)) == Max(3)


# Generated at 2022-06-24 00:40:26.370836
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)



# Generated at 2022-06-24 00:40:27.437813
# Unit test for constructor of class Min
def test_Min():
    assert Min(1).value == 1


# Generated at 2022-06-24 00:40:30.008682
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First('hello')) == "Fist[value=hello]"



# Generated at 2022-06-24 00:40:34.848851
# Unit test for method concat of class Min
def test_Min_concat():
    """
    This function will test the functionality of method concat  of class Min.
    """
    min_a = Min(1)
    min_b = Min(2)
    assert min_a.concat(min_b).value == 1, 'Something wrong with Min.concat method'

# Generated at 2022-06-24 00:40:36.832107
# Unit test for constructor of class All
def test_All():
    assert All(True)
    assert All(False)
    assert All(True).value == True
    assert All(False).value == False


# Generated at 2022-06-24 00:40:39.065566
# Unit test for method concat of class Max
def test_Max_concat():
    semigroup1 = Max(10)
    semigroup2 = Max(12)
    assert semigroup1.concat(semigroup2).value == 12



# Generated at 2022-06-24 00:40:42.646357
# Unit test for method __str__ of class Map
def test_Map___str__():
    result = Map.__str__()
    assert result == "Map[value={}]"


# Generated at 2022-06-24 00:40:45.451034
# Unit test for constructor of class Sum
def test_Sum():
    s = Sum(1)
    assert repr(s) == 'Sum[value=1]'



# Generated at 2022-06-24 00:40:46.599069
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(3)) == 'Min[value=3]'



# Generated at 2022-06-24 00:40:49.681943
# Unit test for constructor of class Min
def test_Min():  # pragma: no cover
    # test
    a = Min(999)
    # expect
    assert a.value == 999


# Generated at 2022-06-24 00:40:51.271664
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-24 00:40:53.707303
# Unit test for constructor of class First
def test_First():
    assert First(12).value == 12

    assert First(12).value is not None
    assert First(12).value is not 12



# Generated at 2022-06-24 00:40:59.979375
# Unit test for method concat of class All
def test_All_concat():
    """
    Test for method concat of All
    """

    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)



# Generated at 2022-06-24 00:41:04.606415
# Unit test for constructor of class Min
def test_Min():
    pass  # pragma: no cover
    # assert Min(3) == 3 and Min(3).value == 3
    # assert Min(3).neutral() == Min(Min.neutral_element)
    # assert Min(5).fold(lambda x: x) == 5
    # assert Min(5).concat(Min(10)) == Min(5)

test_Min()

# Generated at 2022-06-24 00:41:06.443956
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1
    assert First(2).value == 2



# Generated at 2022-06-24 00:41:08.848837
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value == All(True).value
    assert All(True).concat(All(False)).value == All(False).value


# Generated at 2022-06-24 00:41:10.669869
# Unit test for constructor of class All
def test_All():
    assert All(True).value is True
    assert All(False).value is False
    assert All(9).value is True


# Generated at 2022-06-24 00:41:13.746981
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-24 00:41:18.244385
# Unit test for constructor of class Last
def test_Last():
    with pytest.raises(TypeError):
        Last()
    assert Last(1) == Last(1)
    assert Last(0) == Last(0)
    assert Last(1) != Last(0)
    assert str(Last(0)) == "Last[value=0]"
    assert str(Last(1)) == "Last[value=1]"



# Generated at 2022-06-24 00:41:20.430578
# Unit test for method concat of class Min
def test_Min_concat():  # pragma: no cover
    assert Min(23).concat(Min(5)).value == 5



# Generated at 2022-06-24 00:41:25.241899
# Unit test for method concat of class Map
def test_Map_concat():
    assert {'a': Sum(1), 'b': Sum(2)} == Map(
        {'a': Sum(1), 'b': Sum(1)}
    ).concat(Map({'b': Sum(1), 'c': Sum(3)})).value



# Generated at 2022-06-24 00:41:26.771402
# Unit test for method __str__ of class All
def test_All___str__():
    assert 'All[value=True]' == str(All(True))
    assert 'All[value=False]' == str(All(False))

# Generated at 2022-06-24 00:41:30.695995
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: Sum(2)})) == 'Map[value={1: Sum[value=2]}]'

# Generated at 2022-06-24 00:41:40.931198
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)
    assert One(None).concat(One(True)) == One(True)
    assert One(False).concat(One(None)) == One(False)
    assert One(None).concat(One(None)) == One(None)
    assert One(True).concat(One(None)) == One(True)
    assert One(None).concat(One(False)) == One(False)

