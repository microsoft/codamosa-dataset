

# Generated at 2022-06-24 00:31:34.188430
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-24 00:31:38.625272
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'

# Generated at 2022-06-24 00:31:43.443298
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    """
    Unit test for method __str__ of class Sum
    """
    assert Sum.neutral().__str__() == 'Sum[value=0]'
    assert Sum(9).__str__() == 'Sum[value=9]'



# Generated at 2022-06-24 00:31:50.592170
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True), 'first true and true'
    assert All(True).concat(All(False)) == All(False), 'first true and false'
    assert All(False).concat(All(True)) == All(False), 'first false and true'
    assert All(False).concat(All(False)) == All(False), 'first false and false'



# Generated at 2022-06-24 00:31:53.928121
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1
    assert Max(2).value == 2
    assert Max(1) == Max(1)
    assert Max(2) == Max(2)



# Generated at 2022-06-24 00:31:55.698758
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert Semigroup("a").value == "a"



# Generated at 2022-06-24 00:31:57.765697
# Unit test for method __str__ of class First
def test_First___str__():
    semigroup = First(10)

    assert str(semigroup) == 'Fist[value=10]'


# Generated at 2022-06-24 00:31:58.955396
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert str(All(True)) == 'All[value=True]'

# Generated at 2022-06-24 00:32:02.810596
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First("value")) == 'Fist[value=value]'
    assert str(First(42)) == 'Fist[value=42]'
    assert str(First(True)) == 'Fist[value=True]'


# Generated at 2022-06-24 00:32:05.923375
# Unit test for constructor of class Semigroup
def test_Semigroup():
    Test.assert_equals(Sum(1), Sum(1), "Should return new Semigroup instance with given value")
    Test.assert_equals(Sum(1), Sum(1), "Should be equal to second instance with same value")

# Unite test for method fold of class Semigroup

# Generated at 2022-06-24 00:32:09.454039
# Unit test for constructor of class Min
def test_Min():  # pragma: no cover
    assert str(Min(1)) == 'Min[value=1]', 'The value of Min is not correct'
    assert str(Min(0)) == 'Min[value=0]', 'The value of Min is not correct'
    assert str(Min(3)) == 'Min[value=3]', 'The value of Min is not correct'

# Generated at 2022-06-24 00:32:16.393347
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value == All(True).concat(All(False)).value == True
    assert All(False).concat(All(True)).value == All(False).concat(All(False)).value == False
    assert All(False).concat(All(True)).concat(All(True)).value == False
    assert All(False).concat(All(True)).concat(All(True)).concat(All(False)).value == False


# Generated at 2022-06-24 00:32:18.608522
# Unit test for constructor of class One
def test_One():
    one = One(True)
    assert one.value == True
    assert str(one) == 'One[value=True]'



# Generated at 2022-06-24 00:32:19.936417
# Unit test for constructor of class All
def test_All():
    sem = All(True)
    assert sem.value == True


# Generated at 2022-06-24 00:32:24.276404
# Unit test for method concat of class Max
def test_Max_concat():
    max_a = Max(2)
    max_b = Max(4)
    assert max_a.concat(max_b).value == 4
    max_a = Max(4)
    max_b = Max(2)
    assert max_a.concat(max_b).value == 4



# Generated at 2022-06-24 00:32:25.692019
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(0)) == 'Last[value=0]'



# Generated at 2022-06-24 00:32:27.604572
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(4).concat(Sum(5)) == Sum(9)



# Generated at 2022-06-24 00:32:30.298480
# Unit test for method __str__ of class Max
def test_Max___str__():
    actual = str(Max(12))
    expected = 'Max[value=12]'
    assert actual == expected


# Generated at 2022-06-24 00:32:33.776799
# Unit test for constructor of class Min
def test_Min():
    assert Min(3) == Min(3)
    assert Min(3).concat(Min(2)) == Min(2)
    assert Min(3).concat(Min(4)) == Min(3)


# Generated at 2022-06-24 00:32:40.516615
# Unit test for constructor of class Last
def test_Last():  # pragma: no cover
    assert Last(1).value == 1
    assert Last(None).value is None
    assert Last('test').value == 'test'
    assert Last(True).value is True



# Generated at 2022-06-24 00:32:43.353883
# Unit test for method concat of class First
def test_First_concat():
    a = First(2)
    b = First(3)
    assert str(a.concat(b)) == 'Fist[value=2]'



# Generated at 2022-06-24 00:32:45.488439
# Unit test for constructor of class Sum
def test_Sum():
    """
    The task of this unit test is to check constructor of class Sum.
    """
    assert Sum(1).value == 1
    assert Sum(2).value == 2
    assert Sum(-10).value == -10
    assert Sum(-2).value == -2


# Generated at 2022-06-24 00:32:46.657883
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(5)) == "Max[value=5]"


# Generated at 2022-06-24 00:32:50.870202
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == "One[value=True]"



# Generated at 2022-06-24 00:32:52.250183
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(2)) == "Fist[value=2]"



# Generated at 2022-06-24 00:32:54.440288
# Unit test for constructor of class Last
def test_Last():  # pragma: no cover
    assert Last(3) == Last(3)
    assert Last(2) == Last(2)
    assert Last(4) == Last(4)


# Generated at 2022-06-24 00:33:06.271767
# Unit test for method concat of class All
def test_All_concat():
    assert All(False).concat(All(1)).concat(All(True)) == All(False).concat(All(1)).concat(All(False))
    assert All(True).concat(All(False)).concat(All(True)) == All(False).concat(All(False)).concat(All(False))
    assert All(True).concat(All(True)).concat(All(True)) == All(True).concat(All(True)).concat(All(0))
    assert All(True).concat(All(0)).concat(All(0.0)) == All(True).concat(All(0.1)).concat(All(True))
    assert All(True).concat(All(0)).concat(All('s')) == All(True).concat(All('')).concat

# Generated at 2022-06-24 00:33:08.032174
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-24 00:33:13.387320
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(-1)) == Max(1)
    assert Max(-1).concat(Max(1)) == Max(1)


# Generated at 2022-06-24 00:33:16.798837
# Unit test for constructor of class First
def test_First():
    first = First('first')
    assert first.value == 'first'

# Generated at 2022-06-24 00:33:19.938106
# Unit test for method concat of class Last
def test_Last_concat():
    last = Last(2).concat(Last(3))
    assert last == Last(3)


test_Last_concat()



# Generated at 2022-06-24 00:33:23.910406
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(3)) == Sum(5), "Sum(2).concat(Sum(3)) should be Sum(5)."
    assert Sum(1).concat(Sum(1)) == Sum(2), "Sum(1).concat(Sum(1)) should be Sum(2)."
    assert Sum(2).concat(Sum(5)) == Sum(7), "Sum(2).concat(Sum(5)) should be Sum(7)."
    assert Sum(2).concat(Sum(0)) == Sum(2), "Sum(2).concat(Sum(0)) should be Sum(2)."


# Generated at 2022-06-24 00:33:26.731719
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)



# Generated at 2022-06-24 00:33:34.306675
# Unit test for constructor of class One
def test_One():
    o1 = One(1)
    o2 = One(2)
    o3 = o1.concat(o2)
    o4 = o2.concat(o1)
    o5 = o1.concat(o1)
    o6 = o2.concat(o2)

    assert o3.value == 1
    assert o4.value == 2
    assert o5.value == 1
    assert o6.value == 2



# Generated at 2022-06-24 00:33:37.718586
# Unit test for method concat of class Min
def test_Min_concat():
    semigroup_first = Min(3)
    semigroup_second = Min(45)
    assert semigroup_first.concat(semigroup_second) == Min(3)
    assert semigroup_second.concat(semigroup_first) == Min(3)


# Generated at 2022-06-24 00:33:40.714825
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert(str(Max(9)) == 'Max[value=9]')


# Generated at 2022-06-24 00:33:42.873553
# Unit test for method __str__ of class Min
def test_Min___str__():
    a = Min(3)
    assert str(a) == 'Min[value=3]'



# Generated at 2022-06-24 00:33:45.518633
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-24 00:33:48.405289
# Unit test for constructor of class Map
def test_Map():
    map = Map({"1": Min(1), "2": Min(2)})
    assert map.value == {"1": Min(1), "2": Min(2)}


# Generated at 2022-06-24 00:33:49.943571
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-24 00:33:51.869838
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-24 00:33:56.053245
# Unit test for method concat of class Last
def test_Last_concat():
    first_last = Last(1)
    second_last = Last(2)
    last_last = first_last.concat(second_last)
    assert last_last.value == 2



# Generated at 2022-06-24 00:33:59.055724
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1.1)) == 'One[value=1.1]'


# Generated at 2022-06-24 00:34:00.741620
# Unit test for method concat of class Min
def test_Min_concat():
    m1 = Min(1)
    m2 = Min(2)
    assert m1.concat(m2).value == 1

# Generated at 2022-06-24 00:34:05.187191
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'



# Generated at 2022-06-24 00:34:11.751670
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(10).fold(lambda x: x + 1) == 11
    assert All(True).fold(lambda x: x)
    assert One(False).fold(lambda x: x)
    assert First('First').fold(lambda x: x) == 'First'
    assert Last('Last').fold(lambda x: x) == 'Last'
    assert Max(10).fold(lambda x: x) == 10
    assert Min(10).fold(lambda x: x) == 10


# Generated at 2022-06-24 00:34:13.965115
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(False)) == "Last[value=False]"



# Generated at 2022-06-24 00:34:17.297396
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    """ test_Sum() -> Unit test for constructor of class Sum """
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)


# Generated at 2022-06-24 00:34:18.517379
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(2)) == 'Max[value=2]'


# Generated at 2022-06-24 00:34:22.015385
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert Min(5).__str__() == 'Min[value=5]'
    assert Min(float("inf")).__str__() == 'Min[value=inf]'
    assert Min(-float("inf")).__str__() == 'Min[value=-inf]'
    assert Min("a").__str__() == 'Min[value=a]'


# Generated at 2022-06-24 00:34:27.646312
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(True).concat(Last(False)).value == False
    assert Last(1).concat(Last(2)).value == 2
    assert Last('a').concat(Last('b')).value == 'b'
    assert Last([1,2,3,4]).concat(Last([5,6,7,8])).value == [5,6,7,8]


# Generated at 2022-06-24 00:34:29.873206
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)

# Generated at 2022-06-24 00:34:31.527014
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1)})) == 'Map[value={\'a\': Sum[value=1]}]'


# Generated at 2022-06-24 00:34:33.758237
# Unit test for method __str__ of class One
def test_One___str__():
    one = One(True)
    assert str(one) == 'One[value=True]'
    assert repr(one) == 'One(True)'



# Generated at 2022-06-24 00:34:36.244821
# Unit test for constructor of class One
def test_One():
    a = One(True)
    assert a.fold(bool) is True

    a = One(False)
    assert a.fold(bool) is False



# Generated at 2022-06-24 00:34:39.881556
# Unit test for constructor of class Max
def test_Max():
    max_ = Max(0)
    assert max_.value == 0
    assert max_.concat(Max(1)).value == 1
    assert max_.concat(Max(-1)).value == 0
    assert max_.concat(Max(-2)).value == 0


# Generated at 2022-06-24 00:34:41.946698
# Unit test for constructor of class Max
def test_Max():
    assert 5 <= Max(5)
    assert -2 <= Max(-2)


# Generated at 2022-06-24 00:34:43.553637
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert isinstance(Last(5).__str__(), str)


# Generated at 2022-06-24 00:34:46.735680
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(1)
    b = Min(2)
    c = Min(3)
    assert a.concat(b).concat(c).value == 1


# Generated at 2022-06-24 00:34:50.118604
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]', "All's __str__ method failed"
    assert str(All(False)) == 'All[value=False]', "All's __str__ method failed"


# Generated at 2022-06-24 00:34:52.568688
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1).fold(lambda x: x) == 1


# Generated at 2022-06-24 00:34:56.697746
# Unit test for constructor of class Last
def test_Last():
    x = Last(1)
    assert x.value == 1


# Generated at 2022-06-24 00:34:57.594598
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(5)) == "Fist[value=5]"



# Generated at 2022-06-24 00:34:59.394605
# Unit test for method __str__ of class Map
def test_Map___str__():
    m = Map({"a": Sum(1)})
    assert str(m) == 'Map[value={a: Sum[value=1]}]'



# Generated at 2022-06-24 00:35:01.003967
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'



# Generated at 2022-06-24 00:35:02.123310
# Unit test for constructor of class Last
def test_Last():  # pragma: no cover
    assert Last(10).value == 10


# Generated at 2022-06-24 00:35:06.127581
# Unit test for method concat of class One
def test_One_concat():
    x = One(True)
    y = One(False)
    assert x.concat(y) == One(True)
    assert y.concat(x) == One(True)
    assert x.concat(x) == One(True)
    assert y.concat(y) == One(False)

# Generated at 2022-06-24 00:35:07.605780
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)).value == 3


# Generated at 2022-06-24 00:35:08.981791
# Unit test for constructor of class Last
def test_Last():
    last = Last('hello')
    assert last.value == 'hello'



# Generated at 2022-06-24 00:35:17.131017
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(True)).concat(All(True)) == All(True)
    assert All(True).concat(All(True)).concat(All(False)) == All(False)
    assert All(True).concat(All(False)).concat(All(True)) == All(False)
    assert All(True).concat(All(False)).concat(All(False)) == All(False)

# Generated at 2022-06-24 00:35:18.447034
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1


# Generated at 2022-06-24 00:35:19.488276
# Unit test for constructor of class Max
def test_Max():
    # assert Max(5).value == 5
    pass



# Generated at 2022-06-24 00:35:20.651371
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"


# Generated at 2022-06-24 00:35:21.395016
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)



# Generated at 2022-06-24 00:35:23.272943
# Unit test for constructor of class Semigroup
def test_Semigroup():
    x = Semigroup(1)
    y = Semigroup(1)
    assert x == y
    assert x != y



# Generated at 2022-06-24 00:35:28.558032
# Unit test for method concat of class First
def test_First_concat():  # pragma: no cover
    f1 = First('a')
    f2 = First('b')
    assert f1.concat(f2).value == 'a'


# Generated at 2022-06-24 00:35:30.070156
# Unit test for method concat of class First
def test_First_concat():  # pragma: no cover
    assert First(1).concat(First(2)) == First(1)


# Generated at 2022-06-24 00:35:31.212690
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-24 00:35:32.598881
# Unit test for constructor of class Last
def test_Last():
    last = Last(1)
    assert last.value == 1
    assert last == Last(1)


# Generated at 2022-06-24 00:35:36.656195
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == "Min[value=1]"
    assert str(Min(2)) == "Min[value=2]"



# Generated at 2022-06-24 00:35:40.225190
# Unit test for constructor of class All
def test_All():
    assert All(True).value
    assert not All(False).value
    assert All.neutral().value



# Generated at 2022-06-24 00:35:42.328516
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'



# Generated at 2022-06-24 00:35:43.352280
# Unit test for constructor of class One
def test_One():
    assert One(True)



# Generated at 2022-06-24 00:35:47.135012
# Unit test for method concat of class Last
def test_Last_concat():  # pragma: no cover
    """
    :returns: True if it works, raises an exception otherwise
    :rtype: bool
    """
    first = Last(1)
    second = Last(2)
    assert first.concat(second).value == 2



# Generated at 2022-06-24 00:35:50.287016
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)



# Generated at 2022-06-24 00:35:51.653879
# Unit test for constructor of class Max
def test_Max():
    a = Max(1)
    assert(a.value == 1)


# Generated at 2022-06-24 00:35:53.454515
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)
    assert Min(1).value == 1

# Generated at 2022-06-24 00:35:55.299025
# Unit test for constructor of class Max
def test_Max():
    assert Max(10).value == 10
    assert Max(-10).value == -10


# Generated at 2022-06-24 00:35:57.886213
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not (Semigroup(1) == Semigroup(2))
    assert not (Semigroup(1) == Semigroup("a"))



# Generated at 2022-06-24 00:35:58.885705
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    assert One(True).__str__() == "One[value=True]"



# Generated at 2022-06-24 00:36:00.130885
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert Semigroup(1).value == 1



# Generated at 2022-06-24 00:36:03.855737
# Unit test for constructor of class Max
def test_Max():
    """
    :returns: result of unit test
    :rtype: bool
    """
    return Max(1).value == 1


# Generated at 2022-06-24 00:36:07.330544
# Unit test for constructor of class Max
def test_Max():

    a = Max(4)
    b = Max(5)
    assert a.concat(b).value == 5
    assert b.concat(a).value == 5
    assert Max(Min.neutral_element).value == float("inf")


# Generated at 2022-06-24 00:36:10.475350
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    :returns: `Non`e
    :raises: AssertionError if any test fails
    """
    s = Semigroup(2)
    assert isinstance(s, Semigroup)
    assert s.value == 2
    assert not s.value == 3

# Generated at 2022-06-24 00:36:12.288442
# Unit test for method __str__ of class One
def test_One___str__():
    assert _.compose(
        _.eq("One[value=1]"),
        str,
        One
    )(1)



# Generated at 2022-06-24 00:36:17.067852
# Unit test for method concat of class Map
def test_Map_concat():
    """
    Test concat method of Map class
    """
    map1 = Map({'A': Sum(2)})
    map2 = Map({'A': Sum(3)})
    # map1 = Map({'A': { 'A': Sum(2) }})
    # map2 = Map({'A': { 'A': Sum(2) }})
    result = map1.concat(map2)
    assert result.value['A'].value == 5



# Generated at 2022-06-24 00:36:20.812413
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-24 00:36:22.989963
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'



# Generated at 2022-06-24 00:36:27.090831
# Unit test for method __str__ of class Map
def test_Map___str__():
    """
    Compare expected result with method __str__ value result.
    """
    assert str(Map({ "a": Sum(5), "b": Sum(10) })) == "Map[value={'a': Sum[value=5], 'b': Sum[value=10]}]"


# Generated at 2022-06-24 00:36:29.845289
# Unit test for method __str__ of class Min
def test_Min___str__():
    # Given
    semigroup = Min(-12)

    # When
    result = str(semigroup)

    # Then
    assert result == 'Min[value=-12]'


# Generated at 2022-06-24 00:36:34.471099
# Unit test for method concat of class First
def test_First_concat():
    """
    Method concat - always return the first, value when 2 First instances are combined.
    """
    semigroup_1 = First('A')
    semigroup_2 = First('B')
    assert semigroup_1.concat(semigroup_2) == First('A')



# Generated at 2022-06-24 00:36:40.789926
# Unit test for constructor of class Min
def test_Min():
    assert Min(0) == Min(0)
    assert Min(1) == Min(1)
    assert Min(2) == Min(2)
    assert Min(3) == Min(3)
    assert Min(4) == Min(4)
    assert Min(5) == Min(5)
    assert Min(6) == Min(6)
    assert Min(7) == Min(7)
    assert Min(8) == Min(8)
    assert Min(9) == Min(9)
# End test

# Generated at 2022-06-24 00:36:42.926942
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(3)).concat(Min(1)) == Min(1)

test_Min_concat()

# Generated at 2022-06-24 00:36:45.496638
# Unit test for method concat of class Last
def test_Last_concat():
    last_first = Last('first').concat(Last('second'))

    assert last_first == Last('second')


# Unit tests for method concat of class First

# Generated at 2022-06-24 00:36:50.201704
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)).value is False
    assert All(True).concat(All(True)).value is True
    assert All(False).concat(All(True)).value is False
    assert All(False).concat(All(False)).value is False


# Generated at 2022-06-24 00:36:51.905221
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    assert One(1).__str__() == 'One[value=1]'


# Generated at 2022-06-24 00:36:53.403412
# Unit test for method __str__ of class Min
def test_Min___str__():
    """
    Unit test for method __str__ of class Min
    """

    assert str(Min(3)) == 'Min[value=3]'


# Generated at 2022-06-24 00:37:05.130828
# Unit test for method concat of class Map
def test_Map_concat():
    """
    Unit test for method concat of class Map
    """
    assert Map({"a": Sum(1), "b": Sum(2)}).concat(Map({"a": Sum(2)})) == Map(
        {"a": Sum(3), "b": Sum(2)}
    )
    assert Map({"a": Sum(1), "b": Sum(2)}).concat(Map({"b": Sum(2)})) == Map(
        {"a": Sum(1), "b": Sum(4)}
    )
    assert Map({"a": Sum(1), "b": Sum(2)}).concat(Map({"c": Sum(2)})) == Map(
        {"a": Sum(1), "b": Sum(2), "c": Sum(2)}
    )

# Generated at 2022-06-24 00:37:09.300394
# Unit test for method __str__ of class First
def test_First___str__():
    first = First(3)
    assert str(first) == "Fist[value=3]"


# Generated at 2022-06-24 00:37:10.800501
# Unit test for constructor of class Max
def test_Max():
    expected = Max(3)
    actual = Max(3)
    assert actual.value == expected.value


# Generated at 2022-06-24 00:37:12.026562
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Foldable(Sum(1)).fold(Sum) == Sum(1)



# Generated at 2022-06-24 00:37:12.921608
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(100)) == 'Sum[value=100]'


# Generated at 2022-06-24 00:37:17.662308
# Unit test for constructor of class Semigroup
def test_Semigroup():   # pragma: no cover
    a = Semigroup(7)
    b = Semigroup(7)
    c = Semigroup(9)

    assert a == b
    assert a.value == 7
    assert not a == c


# Unit tests for class Sum

# Generated at 2022-06-24 00:37:18.940411
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(6).fold(lambda a: a*a) == 6*6

# Generated at 2022-06-24 00:37:20.038562
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == "One[value=True]"


# Generated at 2022-06-24 00:37:28.919512
# Unit test for method concat of class Last

# Generated at 2022-06-24 00:37:31.767831
# Unit test for constructor of class Sum
def test_Sum():
    a = Sum(1)
    b = Sum(2)
    assert a.value == 1
    assert b.value == 2
    assert a.concat(b) == Sum(3)



# Generated at 2022-06-24 00:37:35.117083
# Unit test for constructor of class One
def test_One():
    """Test constructor of class One"""
    assert_equal(One(True).value, True)
    assert_equal(One(False).value, False)


# Generated at 2022-06-24 00:37:36.189001
# Unit test for constructor of class Last
def test_Last():  # pragma: no cover
    assert Last(1).value == 1
    assert Last(True).value == True


# Generated at 2022-06-24 00:37:40.496390
# Unit test for constructor of class Min
def test_Min():
    expected = Min(1)
    actual = Min(1)
    assert expected == actual


# Generated at 2022-06-24 00:37:44.146190
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({})) == 'Map[value={}]'
    assert str(Map({'a': 'a', 'b': 'c'})) == 'Map[value={\'a\': \'a\', \'b\': \'c\'}]'


# Generated at 2022-06-24 00:37:52.879203
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Max(1), 'b': Last(2)}).concat(
        Map({'a': Min(1), 'b': First(2)})
    ) == Map({'a': Max(1), 'b': Last(2)})

    assert Map({'a': Last(2), 'b': Max(1)}).concat(
        Map({'a': Min(1), 'b': First(2)})
    ) == Map({'a': Last(2), 'b': Max(1)})

    assert Map({'a': Min(1), 'b': First(2)}).concat(
        Map({'a': Last(2), 'b': Max(1)})
    ) == Map({'a': Last(2), 'b': Max(1)})


# Generated at 2022-06-24 00:37:54.181035
# Unit test for constructor of class One
def test_One():
    one = One(True)
    assert one.value is True


# Generated at 2022-06-24 00:37:59.426824
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(3)) == Min(2)
    assert Min(2).concat(Min(2)) == Min(2)
    assert Min(3).concat(Min(2)) == Min(2)



# Generated at 2022-06-24 00:38:02.562721
# Unit test for method concat of class Min
def test_Min_concat():
    val = Min(1)
    other = Min(2)
    assert val.concat(other) == Min(1)
    other = Min(1)
    assert val.concat(other) == Min(1)
    other = Min(0)
    assert val.concat(other) == Min(0)



# Generated at 2022-06-24 00:38:03.676896
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-24 00:38:04.511992
# Unit test for constructor of class Max
def test_Max():  # pragma: no cover
    assert Max(1).value == 1


# Generated at 2022-06-24 00:38:09.494001
# Unit test for method concat of class Map
def test_Map_concat():
    """
    Unit test for method concat of class Map
    """
    assert Map({1: Sum(2)}).concat(Map({1: Sum(3)})) == Map({1: Sum(5)})



# Generated at 2022-06-24 00:38:18.976509
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True, 'Constructor of All return incorrect value!'
    assert All(False).value == False, 'Constructor of All return incorrect value!'
    assert All(5).value == True, 'Constructor of All return incorrect value!'
    assert All(-5).value == True, 'Constructor of All return incorrect value!'
    assert All('5').value == True, 'Constructor of All return incorrect value!'
    assert All('one').value == True, 'Constructor of All return incorrect value!'
    assert All([]).value == True, 'Constructor of All return incorrect value!'
    assert All({}).value == True, 'Constructor of All return incorrect value!'
    assert All(()).value == True, 'Constructor of All return incorrect value!'



# Generated at 2022-06-24 00:38:20.637773
# Unit test for method concat of class First
def test_First_concat():
    result = First(1).concat(First(2))
    assert result.value == 1


# Generated at 2022-06-24 00:38:22.152392
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2


# Generated at 2022-06-24 00:38:25.160874
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True) != All(False)
    assert All(False) == All(False)
    assert All(False) != All(True)


# Generated at 2022-06-24 00:38:27.264919
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First('a')) == 'Fist[value=a]'



# Generated at 2022-06-24 00:38:28.520799
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First("a")) == 'Fist[value=a]'


# Generated at 2022-06-24 00:38:29.896876
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-24 00:38:33.551736
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    :returns: List of results
    :rtype: list
    """

    results = [
        Semigroup(1).fold(lambda x: x + 1) == 2,
        Semigroup("Hello").fold(lambda x: x + "!") == "Hello!"
    ]

    return results



# Generated at 2022-06-24 00:38:38.482780
# Unit test for method __str__ of class One
def test_One___str__():
    # 1. Arrange
    value1 = 1
    one1 = One(value1)
    expected = 'One[value={}]'.format(value1)
    # 2. Act
    actual = str(one1)
    # 3. Assert
    assert expected == actual



# Generated at 2022-06-24 00:38:45.190209
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(5) == Sum(5)
    assert All(True) == All(True)
    assert One(True) == One(True)
    assert First(5) == First(5)
    assert Last(5) == Last(5)
    assert Max(5) == Max(5)
    assert Min(5) == Min(5)
    assert Map({1: Sum(1), 2: Sum(2)}) == Map({2: Sum(2), 1: Sum(1)})
    assert Map({1: Sum(1), 2: Sum(2)}) != Map({2: Sum(1), 1: Sum(1)})


# Generated at 2022-06-24 00:38:47.805449
# Unit test for constructor of class Min
def test_Min():
    assert Min(1).value == 1
    assert Min(1) == Min(1)
    assert Min(1) != Min(2)



# Generated at 2022-06-24 00:38:57.849745
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """ Test fold function of Semigroup """

    # return identity
    assert Semigroup(1).fold(lambda x: x) == 1

    # apply a function to return another value
    assert Semigroup(1).fold(lambda x: x + 2) == 3

    # curry
    assert Semigroup(1).fold(lambda x: lambda y: x + y)(2) == 3

    # sum
    assert Semigroup(1).fold(lambda x: lambda y: x + y)(2) == 3

    # sum four values
    assert Semigroup(1).fold(lambda x: lambda y: x + y)(2).fold(lambda x: lambda y: x + y)(2)\
        .fold(lambda x: lambda y: x + y)(2).value == 7


# Generated at 2022-06-24 00:39:03.621071
# Unit test for method concat of class One
def test_One_concat():
    """
    Test concat method of class One
    """
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-24 00:39:06.531076
# Unit test for method concat of class Min
def test_Min_concat():
    """
    Test "concat" method of "Min" class
    """
    assert Min(5).concat(Min(3)) == Min(3)
    assert Min(3).concat(Min(5)) == Min(3)
    assert Min(5).concat(Min(-3)) == Min(-3)
    assert Min(-3).concat(Min(5)) == Min(-3)

# Generated at 2022-06-24 00:39:08.173550
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True
    assert One(False).value == False


# Generated at 2022-06-24 00:39:12.158510
# Unit test for method concat of class First
def test_First_concat():
    a = First(5)
    b = First(7)
    assert a.concat(b) == First(a.value)



# Generated at 2022-06-24 00:39:21.341915
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert First("fist").fold(lambda v: v) == "fist"
    assert Last("last").fold(lambda v: v) == "last"
    assert Min(1).fold(lambda v: v) == 1
    assert Min("1").fold(lambda v: v) == "1"
    assert Max(1).fold(lambda v: v) == 1
    assert Max("1").fold(lambda v: v) == "1"
    assert All(True).fold(lambda v: v)
    assert All("True").fold(lambda v: v)
    assert All(False).fold(lambda v: v)
    assert not All("False").fold(lambda v: v)
    assert One(True).fold(lambda v: v)
    assert One("True").fold(lambda v: v)

# Generated at 2022-06-24 00:39:23.371530
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"


# Generated at 2022-06-24 00:39:27.057724
# Unit test for constructor of class Max
def test_Max(): 
    m = Max(3)
    assert m.value == 3
    
    

# Generated at 2022-06-24 00:39:31.102515
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1
    assert Max("abc").value == "abc"
    assert Max(1.0).value == 1.0
    assert Max(None).value == None
    assert Max({}).value == {}
    assert Max([]).value == []


# Generated at 2022-06-24 00:39:40.088094
# Unit test for method concat of class Map
def test_Map_concat():
    # Test with dict
    dict1 = {
        'key1': Sum(1),
        'key2': Sum(2)
    }
    dict2 = {
        'key1': Sum(3),
        'key2': Sum(4)
    }
    assert Map(dict1).concat(Map(dict2)).value == {
        'key1': Sum(4),
        'key2': Sum(6)
    }
    # Test with list
    list1 = [
        Sum(1),
        Sum(2)
    ]
    list2 = [
        Sum(3),
        Sum(4)
    ]
    assert Map(list1).concat(Map(list2)).value == [
        Sum(4),
        Sum(6)
    ]
    # Test with string

# Generated at 2022-06-24 00:39:41.318668
# Unit test for constructor of class One
def test_One():
    one = One(True)
    assert one


# Generated at 2022-06-24 00:39:43.373351
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'

test_Max___str__()

# Generated at 2022-06-24 00:39:45.468913
# Unit test for constructor of class Min
def test_Min():  # pragma: no cover
    assert Min(1) == Min(1)



# Generated at 2022-06-24 00:39:50.733906
# Unit test for constructor of class Last
def test_Last():
    a = Last(1)
    b = Last(2)
    assert a.value == 1
    assert b.value == 2
    assert a.concat(b).value == 2


# Generated at 2022-06-24 00:40:02.174369
# Unit test for method concat of class One
def test_One_concat():
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(False)) == One(True)
    assert One(True).concat(One(True)) == One(True)
    assert One(False).concat(First(False)) == One(False)
    assert First(False).concat(One(False)) == One(False)
    assert First(False).concat(One(True)) == One(True)
    assert First(True).concat(One(False)) == One(True)
    assert First(True).concat(One(True)) == One(True)
    assert First(False).concat(Last(False)) == First(False)

# Generated at 2022-06-24 00:40:03.501092
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-24 00:40:05.084560
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)

# Unit tests for method fold

# Generated at 2022-06-24 00:40:06.698475
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: Sum(1), 2: Sum(2)})) == 'Map[value={1: Sum[value=1], 2: Sum[value=2]}]'

# Generated at 2022-06-24 00:40:10.665135
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(5)) == 'All[value=5]'


# Generated at 2022-06-24 00:40:17.481480
# Unit test for constructor of class Max
def test_Max():
    assert Max(10).value == 10
    assert Max(-10).value == -10
    assert Max(10.1).value == 10.1
    assert Max(-10.1).value == -10.1
    assert Max(10.1 + 10.1j).value == 10.1 + 10.1j
    assert Max(-10.1 - 10.1j).value == -10.1 - 10.1j
    assert Max((10, 2)).value == (10, 2)


# Generated at 2022-06-24 00:40:21.872257
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert Sum == type(Sum(1)), 'Sum is class'
    assert Sum(1).value == 1, 'Sum stored value'
    assert Sum(1) == Sum(1), 'Sum is equal'
    assert not Sum(1) == Sum(2), 'Sum is not equal'
    assert str(Sum(1)) == "Sum[value=1]", 'Sum string representation'



# Generated at 2022-06-24 00:40:23.061142
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert str(Max(2)) == 'Max[value=2]'



# Generated at 2022-06-24 00:40:29.239379
# Unit test for method __str__ of class Map
def test_Map___str__():
    m1 = Map({'a': Sum(1), 'b': Sum(2), 'c': Sum(3)})
    assert str(m1) == 'Map[value={"a": Sum[value=1], "b": Sum[value=2], "c": Sum[value=3]}]'


# Generated at 2022-06-24 00:40:32.868826
# Unit test for constructor of class Semigroup
def test_Semigroup():
    one = Semigroup(1)
    other = Semigroup(1)
    assert one == other



# Generated at 2022-06-24 00:40:34.691775
# Unit test for constructor of class Max
def test_Max():  # pragma: no cover
    assert Max(2) == Max(2)



# Generated at 2022-06-24 00:40:36.884417
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One([1, 2, 3])) == 'One[value=[1, 2, 3]]'



# Generated at 2022-06-24 00:40:37.778257
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-24 00:40:42.573853
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1:Sum(1), 2:All(True)})) == 'Map[value={1: Sum[value=1], 2: All[value=True]}]'
    assert str(Map({1:Min(1), 2:Last(True)})) == 'Map[value={1: Min[value=1], 2: Last[value=True]}]'


# Generated at 2022-06-24 00:40:49.778529
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(1)) == Sum(3)
    assert Sum(1).concat(Sum(-1)) == Sum(0)
    assert Sum(-1).concat(Sum(0)) == Sum(-1)
    assert Sum(-1).concat(Sum(-2)) == Sum(-3)
    assert Sum(0).concat(Sum(-1)) == Sum(-1)
    assert Sum(0).concat(Sum(0)) == Sum(0)
    assert Sum(1).concat(Sum(1)) == Sum(2)


# Generated at 2022-06-24 00:40:51.293991
# Unit test for method concat of class Last
def test_Last_concat():

    actual = Last(2)
    expected = Last(3)
    assert actual.concat(Last(3)) == expected;
    pass



# Generated at 2022-06-24 00:40:55.018303
# Unit test for method concat of class Max
def test_Max_concat():
    # positive testing
    assert Max(10).concat(Max(20)) == Max(20)
    assert Max(9).concat(Max(11)) == Max(11)
    assert Max(11).concat(Max(11)) == Max(11)
    # negative testing
    assert Max(20).concat(Max(10)) != Max(10)


# Generated at 2022-06-24 00:41:01.589723
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'
    assert str(Max(2)) == 'Max[value=2]'
    assert str(Max(1.1)) == 'Max[value=1.1]'
    assert str(Max(-1)) == 'Max[value=-1]'
    assert str(Max(-1.1)) == 'Max[value=-1.1]'


# Generated at 2022-06-24 00:41:04.167565
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(6)) == Max(6)
    assert Max(6).concat(Max(5)) == Max(6)



# Generated at 2022-06-24 00:41:06.342427
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'



# Generated at 2022-06-24 00:41:07.733597
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert repr(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-24 00:41:10.629656
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """Test that Semigroup fold, return correct value after passed function.
    """
    # Arrange
    semigroup = Sum(10)
    fn = lambda x: x * 2

    # Act & assert
    assert semigroup.fold(fn) == 20



# Generated at 2022-06-24 00:41:13.708995
# Unit test for constructor of class All
def test_All():
    assert All(3) == All(3)



# Generated at 2022-06-24 00:41:21.621563
# Unit test for constructor of class Semigroup
def test_Semigroup():
    type_error = TypeError(
        'Value of Semigroup should be any subtype of Semigroup, but not {}'
    )
    assert_raises(
        type_error,
        Semigroup,
        [1, 2, 3]
    )
    assert_raises(
        type_error,
        Semigroup,
        {'key': 'value'}
    )
    assert_raises(
        type_error,
        Semigroup,
        123
    )
    assert_raises(
        type_error,
        Semigroup,
        'semigroup'
    )
    assert_raises(
        type_error,
        Semigroup,
        None
    )
    assert_raises(
        type_error,
        Semigroup,
        True
    )

    sum_semigroup = Sum

# Generated at 2022-06-24 00:41:24.941707
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)
    assert not Semigroup(1) == "foo"


# Generated at 2022-06-24 00:41:29.020402
# Unit test for method concat of class Sum
def test_Sum_concat():  # pragma: no cover
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(0).concat(Sum(2)) == Sum(2)
    assert Sum(10).concat(Sum(0)) == Sum(10)
    assert Sum(10).concat(Sum(0)) != Sum(0)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)


# Generated at 2022-06-24 00:41:30.039132
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert 'Last[value=3.14]' == str(Last(3.14))



# Generated at 2022-06-24 00:41:31.928942
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"

