

# Generated at 2022-06-24 00:31:33.920361
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    '''Test case for method __eq__ of class Semigroup'''
    obj1 = Sum(1)
    obj2 = Sum(2)
    assert not obj1 == obj2


# Generated at 2022-06-24 00:31:38.242149
# Unit test for method __str__ of class First
def test_First___str__():
    assert(str(First(1)) == 'Fist[value=1]')


# Generated at 2022-06-24 00:31:40.705359
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)


# Generated at 2022-06-24 00:31:45.892456
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(Sum(10)) == Semigroup(Sum(10))
    assert Semigroup(First(10)) == Semigroup(First(10))
    assert Semigroup(Last(10)) == Semigroup(Last(10))

# Generated at 2022-06-24 00:31:49.494258
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(3) != All(4)


# Generated at 2022-06-24 00:31:51.846810
# Unit test for constructor of class Map
def test_Map():
    """
    Test for class Map
    """
    assert str(Map({'1': Sum(1), '2': Sum(2)})) == 'Map[value={1: Sum[value=1], 2: Sum[value=2]}]'

# Generated at 2022-06-24 00:31:55.017240
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum1 = Sum(5)
    sum2 = Sum(7)
    expected = Sum(12)
    result = sum1.concat(sum2)
    assert (result == expected)



# Generated at 2022-06-24 00:31:59.422466
# Unit test for method concat of class All
def test_All_concat():
    assert True == All(True).concat(All(True)).value
    assert False == All(True).concat(All(False)).value
    assert False == All(False).concat(All(True)).value
    assert False == All(False).concat(All(False)).value


# Generated at 2022-06-24 00:32:03.403399
# Unit test for method __str__ of class Max
def test_Max___str__():
    max = Max(1)
    assert max.__str__() == 'Max[value=1]'
    max = Max(0)
    assert max.__str__() == 'Max[value=0]'
    max = Max(-1)
    assert max.__str__() == 'Max[value=-1]'


# Generated at 2022-06-24 00:32:05.308023
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    s = Sum(1)
    assert s.value == 1
    assert not s.neutral()



# Generated at 2022-06-24 00:32:06.135039
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True

# Generated at 2022-06-24 00:32:09.592786
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'
    assert str(One(0)) == 'One[value=0]'
    assert str(One(False)) == 'One[value=False]'
    assert str(One(None)) == 'One[value=None]'
    assert str(One('foo')) == "One[value=foo]"


# Generated at 2022-06-24 00:32:11.681568
# Unit test for constructor of class One
def test_One():
    assert One(3) == One(3)

# Generated at 2022-06-24 00:32:14.187893
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    :returns: bool
    """
    sg = Semigroup(1)

    res = sg.value == 1

    return res


# Generated at 2022-06-24 00:32:22.428942
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert 'Last[value=None]' == str(Last(None))
    assert 'Last[value=1]' == str(Last(1))
    assert 'Last[value=True]' == str(Last(True))
    assert 'Last[value=test]' == str(Last('test'))
    assert 'Last[value=[1, 2, 3]]' == str(Last([1, 2, 3]))
    assert 'Last[value=None]' == str(Last((None, None)))


# Generated at 2022-06-24 00:32:24.234781
# Unit test for method concat of class Min
def test_Min_concat():
    min1 = Min(7)
    min2 = Min(5)
    print(min1.concat(min2))

# Generated at 2022-06-24 00:32:26.917626
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(2).concat(Last(3)) == Last(3)



# Generated at 2022-06-24 00:32:28.487689
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(False)) == "All[value=False]"


# Generated at 2022-06-24 00:32:33.456337
# Unit test for constructor of class Min
def test_Min():
    """
    Testing for constructor of class Min.
    This will test if constructor works properly.
    """
    assert Min(1) == Min(1)

# Generated at 2022-06-24 00:32:37.199952
# Unit test for method concat of class Map
def test_Map_concat():
    map_a = Map({
        "a": First(1),
        "b": First(2),
        "c": First(3)
    })
    map_b = Map({
        "a": First(4),
        "b": First(5),
        "c": First(6)
    })
    assert map_a.concat(map_b) == Map({
        "a": First(4),
        "b": First(5),
        "c": First(6)
    })



# Generated at 2022-06-24 00:32:38.614871
# Unit test for constructor of class Semigroup
def test_Semigroup():
    with raises(TypeError):
        Semigroup()



# Generated at 2022-06-24 00:32:42.148626
# Unit test for method concat of class Sum
def test_Sum_concat(): # pragma: no cover
    Sum(0).concat(Sum(1)).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)).concat(Sum(5)) == Sum(15)



# Generated at 2022-06-24 00:32:44.742661
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum1 = Sum(1)
    sum2 = Sum(2)
    assert sum1.concat(sum2) == Sum(3)



# Generated at 2022-06-24 00:32:46.672455
# Unit test for constructor of class Max
def test_Max():
    max = Max(10)
    assert max.value == 10, "Max value should be 10"


# Generated at 2022-06-24 00:32:51.821610
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert Min(2).__str__() == 'Min[value=2]'
    assert Min(3).__str__() == 'Min[value=3]'



# Generated at 2022-06-24 00:32:57.019031
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert (
        str(Map({"key": Sum(123), "k": All(True)})) == "Map[value={'key': Sum[value=123], 'k': All[value=True]}]"
    )



# Generated at 2022-06-24 00:33:01.114519
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    t = Sum(1)
    t2 = Sum(1)
    t3 = Sum(2)
    assert t == t2
    assert t != t3


# Generated at 2022-06-24 00:33:05.129354
# Unit test for constructor of class One
def test_One():  # type: ignore
    assert One(True).concat(One(True)).value == True
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(True)).value == True
    assert One(False).concat(One(False)).value == False

test_One()

# Generated at 2022-06-24 00:33:07.881327
# Unit test for method concat of class First
def test_First_concat():
    assert First(123).concat(First(456)) == First(123)

# Generated at 2022-06-24 00:33:08.913485
# Unit test for constructor of class Min
def test_Min():

    assert (Min(1).value == 1)

# Generated at 2022-06-24 00:33:12.111014
# Unit test for constructor of class Max
def test_Max():
    x = Max(10)
    assert x.value == 10
    assert isinstance(x, Semigroup)
    assert isinstance(x, Max)


# Generated at 2022-06-24 00:33:13.449170
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First(12)) == 'Fist[value=12]'


# Generated at 2022-06-24 00:33:15.241842
# Unit test for method __str__ of class Map
def test_Map___str__():
    d = Map({'x': Sum(1)})
    expected = 'Map[value={\'x\': Sum[value=1]}]'
    assert str(d) == expected

# Generated at 2022-06-24 00:33:21.070663
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(5)) == "Last[value=5]", "Should be equals"
    assert str(Last({1:2, 3:5})) == "Last[value={1: 2, 3: 5}]", "Should be equals"
    assert str(Last(['a', 'b', 'c'])) == "Last[value=['a', 'b', 'c']]", "Should be equals"



# Generated at 2022-06-24 00:33:26.596433
# Unit test for constructor of class First
def test_First():
    fst = First(1)
    assert fst.value == 1



# Generated at 2022-06-24 00:33:31.432505
# Unit test for constructor of class Min
def test_Min():
    # given
    m_1 = Min(1)
    m_2 = Min(2)

    # when
    res = m_1.concat(m_2)

    # then
    assert res == Min(1)

# Generated at 2022-06-24 00:33:40.491616
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(True)).concat(All(False)) == All(False)
    assert All(True).concat(All(False)).concat(All(False)) == All(False)
    assert All(False).concat(All(True)).concat(All(False)) == All(False)
    assert All(False).concat(All(False)).concat(All(False)) == All(False)



# Generated at 2022-06-24 00:33:42.959927
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(5)) == 'Last[value=5]'


# Generated at 2022-06-24 00:33:43.979699
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(123)) == 'One[value=123]'


# Generated at 2022-06-24 00:33:48.844896
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2), 'c': All(True)})) == 'Map[value={\'a\': Sum[value=1], \'b\': Sum[value=2], \'c\': All[value=True]}]'



# Generated at 2022-06-24 00:33:49.767698
# Unit test for method __str__ of class Last
def test_Last___str__():
    last = Last(1)
    assert str(last) == 'Last[value=1]'


# Generated at 2022-06-24 00:33:51.182067
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(3)) == Sum(5)


# Generated at 2022-06-24 00:33:54.791029
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(3)) == Max(3)
    assert Max(3).concat(Max(1)) == Max(3)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-24 00:33:59.746422
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    result = First(4).__str__()
    assert_equal(result, 'Fist[value=4]')



# Generated at 2022-06-24 00:34:00.733148
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)



# Generated at 2022-06-24 00:34:06.388398
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not (Semigroup(1) == Semigroup(2))
    assert not (Semigroup(1) == Semigroup('string'))
    assert not (Semigroup(1) == Semigroup([1,2]))
    assert Semigroup(True) == Semigroup(True)
    assert not (Semigroup(True) == Semigroup(False))
    assert Semigroup(None) == Semigroup(None)
    assert Semigroup('string') == Semigroup('string')
    assert not(Semigroup('string') == Semigroup('string2'))
    assert Semigroup([1,2,3]) == Semigroup([1,2,3])
    assert not (Semigroup([1,2,3]) == Semigroup([1,2,31]))


# Generated at 2022-06-24 00:34:09.137863
# Unit test for constructor of class Min
def test_Min():
    min_semigroup = Min(2)

    assert min_semigroup.value == 2
    assert str(min_semigroup) == "Min[value=2]"


# Generated at 2022-06-24 00:34:19.758960
# Unit test for method concat of class Map
def test_Map_concat():
    first_Map = Map({
        'Max': Max(10),
        'Min': Min(9),
        'Last': Last(8),
        'First': First(7),
        'One': One(True),
        'All': All(False),
        'Sum': Sum(6),
    })

    second_Map = Map({
        'Max': Max(6),
        'Min': Min(5),
        'Last': Last(4),
        'First': First(3),
        'One': One(True),
        'All': All(False),
        'Sum': Sum(2),
    })

    concated_Map = first_Map.concat(second_Map)
    print(concated_Map)
    assert concated_Map.value['Max'].value == 10

# Generated at 2022-06-24 00:34:25.532444
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False
    assert All(1).value == True
    assert All().value == True
    assert All(0).value == False



# Generated at 2022-06-24 00:34:28.001045
# Unit test for constructor of class One
def test_One():
    try:
        assert One(2) == One(2)
        assert One(False) == One(False)
        assert One('string') == One('string')
    except AssertionError:  # pragma: no cover
        print('AssertionError')


# Generated at 2022-06-24 00:34:31.915154
# Unit test for constructor of class Map
def test_Map():
    sum_a = First(1)
    sum_b = First(1)
    map_a = Map({"a": sum_a})
    map_b = Map({"a": sum_b})
    value = map_a.concat(map_b)
    assert value.value["a"] == First(1)
    assert value.value["a"] == First(1)


# Generated at 2022-06-24 00:34:34.767324
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]', \
        'Str should return \'All[value=True]\', but it returned {}'.format(str(All(True)))


# Generated at 2022-06-24 00:34:36.370418
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(1 + 2)



# Generated at 2022-06-24 00:34:37.620811
# Unit test for constructor of class One
def test_One():
    one = One(41)
    one.value == 42


# Generated at 2022-06-24 00:34:41.685387
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    Unit test for method __eq__ of class Semigroup
    """

    # test with equal values
    assert Semigroup("1") == Semigroup("1")

    # test with not equal values
    assert Semigroup("1") != Semigroup("2")



# Generated at 2022-06-24 00:34:47.040927
# Unit test for constructor of class Max
def test_Max():
  assert Max(1) == Max(1)
  assert Max(1) != Max(2)
  assert Max(2) != Max(1)
  assert Max(1) != Sum(1)
  assert Max(2) != Sum(2)
  assert Max(1) != All(1)
  assert Max(2) != All(2)


# Generated at 2022-06-24 00:34:48.484388
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-24 00:34:58.753480
# Unit test for method concat of class Map
def test_Map_concat():
    list1 = [1, 2, 3]
    list2 = [4, 5, 6]
    map1 = Map({1: All(False), 2: All(True), 3: All(True), 4: All(False), 5: All(True), 6: All(False)})
    map2 = Map({1: All(False), 2: All(True), 3: All(True), 4: All(False), 5: All(False), 6: All(True)})
    map3 = Map({1: All(False), 2: All(True), 3: All(True), 4: All(False), 5: All(True), 6: All(False)})


# Generated at 2022-06-24 00:35:00.578519
# Unit test for method __str__ of class First
def test_First___str__():
    First(5).__str__() == "Fist[value=5]"



# Generated at 2022-06-24 00:35:02.050282
# Unit test for constructor of class Last
def test_Last():
    value = 3
    semigroup = Last(value)
    assert semigroup.value == value


# Generated at 2022-06-24 00:35:04.264111
# Unit test for method concat of class Sum
def test_Sum_concat():  # pragma: no cover
    result = Sum(4).concat(Sum(5))
    expected = Sum(9)
    assert result == expected


# Generated at 2022-06-24 00:35:06.488890
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1
    assert Sum(1) != Sum(2)
    assert Sum(1) == Sum(1)



# Generated at 2022-06-24 00:35:08.260885
# Unit test for constructor of class First
def test_First():
    assert First('first') == First('first')
    assert not First('first') == First('second')



# Generated at 2022-06-24 00:35:09.210948
# Unit test for constructor of class Max
def test_Max():
    assert Max(4).value == 4


# Generated at 2022-06-24 00:35:13.226558
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:35:17.716487
# Unit test for method concat of class Sum
def test_Sum_concat():  # pragma: no cover
    assert Sum(1).concat(Sum(2)).value == 3



# Generated at 2022-06-24 00:35:19.049586
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1
    assert Sum(2).value == 2



# Generated at 2022-06-24 00:35:19.956604
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert 'Min[value=1]' == str(Min(1))


# Generated at 2022-06-24 00:35:21.778891
# Unit test for method __str__ of class All
def test_All___str__(): # pragma: no cover
    assert str(All(1)) == 'All[value=1]'


# Generated at 2022-06-24 00:35:23.435710
# Unit test for method concat of class Min
def test_Min_concat():
    """
    :returns: assert that returned value is smallest
    :rtype: bool
    """
    return Min(0).concat(Min(2)) == Min(0)



# Generated at 2022-06-24 00:35:29.754367
# Unit test for method concat of class Sum
def test_Sum_concat(): # pragma: no cover
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(0)) == Sum(1)
    assert Sum(-1).concat(Sum(-2)) == Sum(-3)



# Generated at 2022-06-24 00:35:31.255822
# Unit test for method concat of class Max
def test_Max_concat():
    assert Sum(5).concat(Sum(10)) == Sum(5 + 10)


# Generated at 2022-06-24 00:35:32.919469
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'



# Generated at 2022-06-24 00:35:33.813755
# Unit test for constructor of class Max
def test_Max():
    four = Max(4)
    assert four.value == 4


# Generated at 2022-06-24 00:35:39.963473
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value == True
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
    assert All(False).concat(All(False)).value == False


# Generated at 2022-06-24 00:35:44.594675
# Unit test for constructor of class One
def test_One():
    assert One(False) == One(False)
    assert One(True).concat(One(False)).value == False
    assert One(False).concat(One(True)).value == True
    assert One(True).concat(One(True)).value == True



# Generated at 2022-06-24 00:35:46.557630
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-24 00:35:54.347169
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'
    assert str(Last('abc')) == 'Last[value=abc]'
    assert str(Last(None)) == 'Last[value=None]'
    assert str(Last(True)) == 'Last[value=True]'
    assert str(Last({'a': 1, 'b': 2})) == 'Last[value={\'a\': 1, \'b\': 2}]'


# Generated at 2022-06-24 00:35:58.789536
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(7)) == Max(7)
    assert Max(5).concat(Max(5)) == Max(5)
    assert Max(-5).concat(Max(-7)) == Max(-5)
    assert Max(-5).concat(Max(-5)) == Max(-5)
    assert Max(-5).concat(Max(-7)) == Max(-5)



# Generated at 2022-06-24 00:36:00.051981
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == "Last[value=1]"


# Generated at 2022-06-24 00:36:04.898182
# Unit test for method concat of class Sum
def test_Sum_concat():
    # test for Sum class
    assert Sum(1).concat(Sum(2)).value == 3
    assert Sum(1).concat(Sum(0)).value == 1
    assert Sum(0).concat(Sum(0)).value == 0



# Generated at 2022-06-24 00:36:09.630966
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(2)) == "Min[value=2]"


# Generated at 2022-06-24 00:36:10.734667
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)

# Generated at 2022-06-24 00:36:15.214377
# Unit test for method __str__ of class One
def test_One___str__():

    # Test when value is None
    one = One(None)
    assert str(one) == 'One[value=None]'



# Generated at 2022-06-24 00:36:16.316057
# Unit test for constructor of class Last
def test_Last():
    semigroup = Last(100)
    assert semigroup.value == 100


# Generated at 2022-06-24 00:36:20.420487
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-24 00:36:27.558855
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert First("Hello") == First("Hello")
    assert Last("last") == Last("last")
    assert Map({1: Sum(1), 2: Sum(2)}) == Map({1: Sum(1), 2: Sum(2)})
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)



# Generated at 2022-06-24 00:36:28.940082
# Unit test for constructor of class Min
def test_Min():
    assert Min(2) == Min(2)


# Generated at 2022-06-24 00:36:31.289248
# Unit test for method concat of class First
def test_First_concat():
    f = First(2)
    g = First(3)
    assert f.concat(g) == First(2)


# Generated at 2022-06-24 00:36:34.274373
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():  # pragma: no cover
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)


# Generated at 2022-06-24 00:36:37.354104
# Unit test for constructor of class Map
def test_Map():
    m = Map({'a': Sum(1), 'b': Sum(2)})
    assert m.value == {'a': Sum(1), 'b': Sum(2)}



# Generated at 2022-06-24 00:36:38.520543
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(False)) == 'All[value=False]'
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-24 00:36:39.149743
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True


# Generated at 2022-06-24 00:36:41.732047
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(5).concat(Min(10)) == Min(5)
    assert Min(5).concat(Min(3)) == Min(3)
    assert Min(5).concat(Min(5)) == Min(5)

# Generated at 2022-06-24 00:36:43.059125
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(10)) == "Max[value=10]"


# Generated at 2022-06-24 00:36:44.738690
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-24 00:36:53.797643
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    :returns: pass or fail test
    :rtype: str
    """
    assert(Semigroup.neutral_element == True)
    assert(All(True).value == True)
    assert(All(False).value == False)
    assert(One(True).value == True)
    assert(One(False).value == False)
    assert(First('first').value == 'first')
    assert(Last('last').value == 'last')
    assert(Map({'key': Sum(1)}).value == {'key': Sum(1)})
    assert(Max(1000).value == 1000)
    assert(Min(100).value == 100)
    return 'test_Semigroup passed'



# Generated at 2022-06-24 00:36:55.014077
# Unit test for constructor of class Last
def test_Last():
    assert last(3) == Last(3)

# Generated at 2022-06-24 00:37:01.404333
# Unit test for method concat of class Last
def test_Last_concat():
    l1 = Last(1)
    l2 = Last(2)
    result1 = l1.concat(l2)
    result2 = l2.concat(l1)
    expected1 = Last(2)
    expected2 = Last(1)
    assert result1 == expected1
    assert result2 == expected2


# Generated at 2022-06-24 00:37:03.895239
# Unit test for method __str__ of class Map
def test_Map___str__():
    """
    Test for method __str__ of class Map
    """
    assert str(Map({"my": Sum(10)})) == "Map[value={'my': Sum[value=10]}]"



# Generated at 2022-06-24 00:37:07.336820
# Unit test for method concat of class One
def test_One_concat():
    """
    Test method concat of class One
    """
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-24 00:37:08.161818
# Unit test for constructor of class One
def test_One():
    assert One(1).fold(identity) == 1



# Generated at 2022-06-24 00:37:10.084820
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(2)
    assert Min(5).concat(Min(3)) == Min(3)


# Generated at 2022-06-24 00:37:14.296009
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(100).fold(lambda x: x + 1) == 101



# Generated at 2022-06-24 00:37:21.053589
# Unit test for constructor of class One
def test_One():
    assert One( None) == One(None)
    # True stored in first place
    assert One(True).concat(One(False)).value == True
    # False stored in second place
    assert One(False).concat(One(True)).value == True
    # True stored in second place
    assert One(False).concat(One(True)).value == True
    # False stored in first place
    assert One(False).concat(One(False)).value == False

# Unit tests for constructor of class First

# Generated at 2022-06-24 00:37:24.096341
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)

# Generated at 2022-06-24 00:37:25.804343
# Unit test for constructor of class First
def test_First():
    assert (First(123).concat(First(2))).fold(lambda x: x) == 123

# Generated at 2022-06-24 00:37:28.071391
# Unit test for constructor of class First
def test_First():
    assert First(1) != First(2)
    assert First(1).value == 1
    assert First(1) == First(1)


# Generated at 2022-06-24 00:37:28.964773
# Unit test for method __str__ of class First
def test_First___str__():
    return First(1)


# Generated at 2022-06-24 00:37:30.708495
# Unit test for constructor of class One
def test_One():
    instance = One(True)
    expected = True

    assert instance.value == expected

# Generated at 2022-06-24 00:37:34.506073
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)).concat(Last(3)) == Last(3)



# Generated at 2022-06-24 00:37:38.435425
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1)}).value == {'a': Sum(1)}
    assert Map({'a': Sum(1), 'b': Sum(2)}).value == {'a': Sum(1), 'b': Sum(2)}
    try:
        assert Map(1)
    except:
        print("Map() only accept dict as arg")



# Generated at 2022-06-24 00:37:39.758998
# Unit test for method concat of class Max
def test_Max_concat():
  assert Max(1).concat(Max(2)).value == 2
  assert Max(2).concat(Max(1)).value == 2


# Generated at 2022-06-24 00:37:40.759577
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1, "Sum the value should be equal to 1"


# Generated at 2022-06-24 00:37:43.878532
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': All(True)})) == "Map[value={'a': Sum[value=1], 'b': All[value=True]}]"


# Generated at 2022-06-24 00:37:45.570906
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'

# Generated at 2022-06-24 00:37:47.996842
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    my_sum = Sum(1)
    assert str(my_sum) == 'Sum[value=1]'



# Generated at 2022-06-24 00:37:49.469194
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-24 00:37:52.236737
# Unit test for method concat of class Last
def test_Last_concat():
    a = Last(1)
    b = Last(3)
    assert a.concat(b) == Last(3)
    c = Last(None)
    d = Last(False)
    assert c.concat(d) == Last(False)


# Generated at 2022-06-24 00:37:53.445445
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)



# Generated at 2022-06-24 00:37:59.086940
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"a": First(1), "b": First(2)}).concat(Map({"a": First(2), "c": First(3)})).value == {"a": First(1), "b": First(2), "c": First(3)}


# Generated at 2022-06-24 00:38:00.737413
# Unit test for method concat of class All
def test_All_concat():
    num = First(2).concat(First(3)) == All(True)
    assert num.value == True

# Generated at 2022-06-24 00:38:01.739612
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(123)) == 'Fist[value=123]'


# Generated at 2022-06-24 00:38:05.700652
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == All(False)
    assert One(True) != All(True)


# Generated at 2022-06-24 00:38:07.040664
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(3)) == Sum(5)



# Generated at 2022-06-24 00:38:08.398925
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'


# Generated at 2022-06-24 00:38:18.230063
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)).concat(One(False)).concat(One(True)).value == True
    assert One(False).concat(One(False)).concat(One(False)).concat(One(False)).value == False
    assert One(True).concat(One(False)).concat(One(True)).concat(One(True)).value == True
    assert One(False).concat(One(True)).concat(One(True)).concat(One(False)).value == True
    assert One(True).concat(One(True)).concat(One(True)).concat(One(True)).value == True
    assert One(False).concat(One(False)).concat(One(False)).concat(One(False)).value == False

# Generated at 2022-06-24 00:38:24.912213
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    :return: result of execution unit test
    :rtype: bool
    """
    a = Sum(5)
    b = Sum(5)
    c = Sum(3)
    assert a == Sum(5)
    assert a == b
    assert b == a
    assert a.concat(b) == Sum(10)
    assert a.concat(c) == Sum(8)
    assert a.concat(b).concat(c) == Sum(13)
    return True


# Generated at 2022-06-24 00:38:26.979458
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)



# Generated at 2022-06-24 00:38:28.307871
# Unit test for constructor of class Semigroup
def test_Semigroup():
    # raise: TypeError
    assert Semigroup(None)


# Generated at 2022-06-24 00:38:31.116092
# Unit test for method __str__ of class Map
def test_Map___str__():
    map = Map({'key': 'value'})
    result = str(map)
    expected = 'Map[value={\'key\': \'value\'}]'
    assert result == expected


# Generated at 2022-06-24 00:38:34.965737
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    """
    Testing method __str__ in Semigroup Sum for type hinting
    """
    assert str(Sum(1)) == 'Sum[value=1]'
    assert str(Sum(3.14)) == 'Sum[value=3.14]'
    assert str(Sum(-5)) == 'Sum[value=-5]'


# Generated at 2022-06-24 00:38:38.871837
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)
    assert not Semigroup(1) == 1
    assert not Semigroup(1) == '1'



# Generated at 2022-06-24 00:38:43.595793
# Unit test for constructor of class Max
def test_Max():
    # Unit test for constructor of class Max
    assert Max(1) == Max(1)
    assert Max(1) != Max(2)
    assert Max(1).concat(Max(2)).value == 2
    assert Max(2).concat(Max(1)).value == 2
    assert Max(1).concat(Max(1)).value == 1


# Generated at 2022-06-24 00:38:44.901186
# Unit test for constructor of class First
def test_First():
    a = First()
    assert isinstance(a, First)

# Generated at 2022-06-24 00:38:46.436596
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(0).concat(Last(1)) == First(0)

# Generated at 2022-06-24 00:38:48.894499
# Unit test for constructor of class One
def test_One():
    one_instance = One(True)
    assert one_instance.value == True


# Generated at 2022-06-24 00:38:50.568425
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'



# Generated at 2022-06-24 00:38:55.448710
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == "One[value=True]"
    assert str(One(False)) == "One[value=False]"
    assert str(One(10)) == "One[value=10]"
    assert str(One("Something")) == "One[value=Something]"


# Generated at 2022-06-24 00:38:58.640752
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)
    assert One(0) == One(0)
    assert One(False) == One(False)
    assert One(None) == One(None)
    assert One(1) == One(True)
    assert One(0) == One(False)
    assert One(1) != One(0)

# Generated at 2022-06-24 00:38:59.967842
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-24 00:39:03.544326
# Unit test for constructor of class All
def test_All():
    assert All(True)
    assert All(False)
    assert not All(None)



# Generated at 2022-06-24 00:39:07.323484
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)



# Generated at 2022-06-24 00:39:08.933292
# Unit test for constructor of class Max
def test_Max():  # pragma: no cover
    assert Max(5) == Max(5)


# Generated at 2022-06-24 00:39:12.105017
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert 'Max[value=-10]' == str(Max(-10))



# Generated at 2022-06-24 00:39:15.599158
# Unit test for method concat of class Min
def test_Min_concat():
    min_concat_instance = Min(100).concat(Min(10))
    assert min_concat_instance.value == 10, \
        'Expected value is 10, but result is {}'.format(min_concat_instance.value)


# Generated at 2022-06-24 00:39:16.864131
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)

# Generated at 2022-06-24 00:39:20.677333
# Unit test for method concat of class All
def test_All_concat():
    a1 = All(True)
    a2 = All(True)
    assert a1.concat(a2).value == True

    a3 = All(False)
    a4 = All(True)
    assert a3.concat(a4).value == False

    a5 = All(True)
    a6 = All(False)
    assert a5.concat(a6).value == False


# Generated at 2022-06-24 00:39:21.341676
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True



# Generated at 2022-06-24 00:39:22.959035
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert (str(Last(15))) == 'Last[value=15]'


# Generated at 2022-06-24 00:39:27.752585
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-24 00:39:30.502148
# Unit test for constructor of class First
def test_First():
    """
    :returns: True if all conditions work
    :rtype: bool
    """
    return First(1).value == 1 and First(2).value == 2


# Generated at 2022-06-24 00:39:33.648118
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-24 00:39:38.649637
# Unit test for method __str__ of class Min
def test_Min___str__():
    actual = str(Min(10))
    expected = "Min[value=10]"
    assert actual == expected


# Generated at 2022-06-24 00:39:41.911704
# Unit test for method concat of class Last
def test_Last_concat():
    """
    >>> last = Last('first')
    >>> last1 = Last('last')
    >>> last2 = last.concat(last1)
    >>> last2.value 
    'last'
    """


# Generated at 2022-06-24 00:39:43.858343
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(1).__str__() == 'One[value=1]'


# Generated at 2022-06-24 00:39:47.463406
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(10), 'b': Sum(20)}).concat(
        Map({'a': Sum(10), 'b': Sum(20), 'c': Sum(30)})
    ) == Map({'a': Sum(20), 'b': Sum(40), 'c': Sum(30)})

# Generated at 2022-06-24 00:39:51.544754
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Unit test for method fold of class Semigroup
    """
    square = lambda x: x ** 2
    semigroup = Semigroup(9)
    assert semigroup.fold(square) == 81
    semigroup = Semigroup(5)
    assert semigroup.fold(square) == 25



# Generated at 2022-06-24 00:39:52.731830
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-24 00:40:04.412872
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup.fold(Sum(0), lambda x: x + 1) == 1
    assert Semigroup.fold(Sum(1), lambda x: x + 1) == 2
    assert Semigroup.fold(All(True), lambda x: x and True) is True
    assert Semigroup.fold(All(False), lambda x: x and True) is False
    assert Semigroup.fold(All(None), lambda x: x and True) is False
    assert Semigroup.fold(Max(1), lambda x: x + 1) == 2
    assert Semigroup.fold(Max(-1), lambda x: x + 1) == 1
    assert Semigroup.fold(Max(2), lambda x: x - 1) == 1
    assert Semigroup.fold(Min(1), lambda x: x + 1) == 2

# Generated at 2022-06-24 00:40:06.836916
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)
    assert One(False) != One(True)



# Generated at 2022-06-24 00:40:10.537398
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1


# Generated at 2022-06-24 00:40:12.490227
# Unit test for constructor of class First
def test_First():
    first = First(1)
    assert first.value == 1


# Generated at 2022-06-24 00:40:16.740044
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Sum(1)
    assert Map({'a': Sum(1), 'b': Sum(2)})
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).fold(lambda v: v) == 1



# Generated at 2022-06-24 00:40:17.626595
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-24 00:40:19.206848
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)).fold(lambda x: x) == 1



# Generated at 2022-06-24 00:40:20.050269
# Unit test for constructor of class Max
def test_Max():
    assert Max(7) == Max(7)


# Generated at 2022-06-24 00:40:22.460702
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-24 00:40:26.678986
# Unit test for method concat of class One
def test_One_concat():
    one = One('A')
    expected = one
    result = one.concat(one)
    assert result == expected

    one = One(False)
    expected = one
    result = one.concat(one)
    assert result == expected

    one = One(1)
    expected = one
    result = one.concat(one)
    assert result == expected



# Generated at 2022-06-24 00:40:31.591161
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value is True
    assert All(True).concat(All(False)).value is False
    assert All(False).concat(All(True)).value is False
    assert All(False).concat(All(False)).value is False



# Generated at 2022-06-24 00:40:34.659763
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    """
    test if Sum class __str__ method
    """
    sum_ = Sum(12)
    assert str(sum_) == 'Sum[value=12]'

# Generated at 2022-06-24 00:40:38.346063
# Unit test for constructor of class All
def test_All():  # pragma: no cover
    assert All(True).__str__() == 'All[value=True]'
    assert All(False).__str__() == 'All[value=False]'
    assert All(True) == All(True)
    assert All(False) == All(False)


# Generated at 2022-06-24 00:40:41.533256
# Unit test for constructor of class Last
def test_Last():
    try:
        assert Last(1) == Last(1)
    except AssertionError:
        assert False
    else:
        assert True

# Generated at 2022-06-24 00:40:43.117597
# Unit test for method __str__ of class Max
def test_Max___str__():
    x = Max(1)
    assert str(x) == "Max[value=1]"


# Generated at 2022-06-24 00:40:46.524434
# Unit test for constructor of class Map
def test_Map():
    m = Map({1:Sum(1), 2:Sum(2)})
    assert m.value == {1:Sum(1), 2:Sum(2)}


# Generated at 2022-06-24 00:40:51.667420
# Unit test for method concat of class Min
def test_Min_concat():
    # Given
    num_a = 5
    num_b = -10
    min_a = Min(num_a)
    min_b = Min(num_b)

    # When
    min_c = min_a.concat(min_b)

    # Then
    assert min_c.value == num_b



# Generated at 2022-06-24 00:40:55.975284
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum_ = Sum(10)
    assert str(sum_) == 'Sum[value=10]'



# Generated at 2022-06-24 00:40:59.888824
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)



# Generated at 2022-06-24 00:41:02.676800
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1
    assert Max(10).value == 10
    assert Max("1").value == "1"
    assert Max("test").value == "test"



# Generated at 2022-06-24 00:41:04.036385
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(15)) == "Min[value=15]"

# Generated at 2022-06-24 00:41:05.477772
# Unit test for constructor of class Min
def test_Min():
    assert isinstance(Min(2), Min)


# Generated at 2022-06-24 00:41:07.199126
# Unit test for method concat of class First
def test_First_concat():
    assert First('first').concat(First('second')) == First('first')


# Generated at 2022-06-24 00:41:10.073796
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(None)) == 'Fist[value=None]'
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First('test')) == 'Fist[value=test]'


# Generated at 2022-06-24 00:41:17.953616
# Unit test for method concat of class All
def test_All_concat():
    # Test 1st
    assert All(True).concat(All(True)).value is True
    # Test 2nd
    assert All(False).concat(All(True)).value is False
    # Test 3rd
    assert All(True).concat(All(False)).value is False
    # Test 4th
    assert All(False).concat(All(False)).value is False
    # Test 5th
    assert All(10).concat(All(0)).value is False


# Generated at 2022-06-24 00:41:19.723826
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert 'Max[value=10]' == str(Max(10))



# Generated at 2022-06-24 00:41:21.585115
# Unit test for constructor of class Min
def test_Min():
    assert Min(10) == Min(10)

# Generated at 2022-06-24 00:41:24.499023
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-24 00:41:25.763140
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(0)) == 'Max[value=0]'



# Generated at 2022-06-24 00:41:30.015763
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First(1) == First(1)
    assert Last(1) == Last(1)
    assert Map({1: Sum(3)}) == Map({1: Sum(3)})
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)


# Generated at 2022-06-24 00:41:31.013692
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
