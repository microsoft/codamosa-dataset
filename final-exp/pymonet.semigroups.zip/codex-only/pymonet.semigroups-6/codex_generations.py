

# Generated at 2022-06-24 00:31:38.774634
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(10)) == Max(10)
    assert Max(10).concat(Max(1)) == Max(10)
    assert Max(1).concat(Max(1)) == Max(1)
    assert Max(1).concat(Max(0)) == Max(1)


# Generated at 2022-06-24 00:31:47.547051
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Test fold method of Semigroup
    """
    assert Sum(1).fold(lambda v: v + 10) == 11
    assert All(True).fold(lambda v: not v) is False
    assert One(False).fold(lambda v: not v) is True
    assert First(1).fold(lambda v: v + 10) == 1
    assert Last(1).fold(lambda v: v + 10) == 11
    assert Map({1: Sum(1)}).fold(lambda v: v) == {1: Sum(1)}
    assert Max(1).fold(lambda v: v * 10) == 10
    assert Min(1).fold(lambda v: v * 10) == 0


test_Semigroup_fold()

# Generated at 2022-06-24 00:31:49.805201
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-24 00:31:54.443676
# Unit test for constructor of class Min
def test_Min():
    # Create expected Min instance
    expected_semigroup_instance = Min(-2)
    # Create new Min instance
    semigroup_instance = Min(-2)
    # Assert that created Min instance and expected Min instance are equal
    assert semigroup_instance == expected_semigroup_instance


# Generated at 2022-06-24 00:32:01.652678
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(0)) == Max(1)
    assert Max(0).concat(Max(1)) == Max(1)
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(1).concat(Max(0.5)) == Max(1)
    assert Max(0).concat(Max(-1)) == Max(0)
    assert Max(-1).concat(Max(0)) == Max(0)
    assert Max(-1).concat(Max(-2)) == Max(-1)


# Generated at 2022-06-24 00:32:03.135961
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)


# Generated at 2022-06-24 00:32:04.703950
# Unit test for constructor of class Min
def test_Min():
    assert Min(2).value == 2


# Generated at 2022-06-24 00:32:06.440716
# Unit test for method concat of class First
def test_First_concat():
    """
    test for method concat of class First
    """
    assert First(1).concat(First(2)) == First(1)



# Generated at 2022-06-24 00:32:13.034596
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).fold(lambda x: x) is True
    assert All(True).concat(All(False)).fold(lambda x: x) is False
    assert All(False).concat(All(False)).fold(lambda x: x) is False
    assert All(False).concat(All(True)).fold(lambda x: x) is False


# Generated at 2022-06-24 00:32:17.092165
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    value = Sum(1)
    assert value == Sum(1)



# Generated at 2022-06-24 00:32:21.256746
# Unit test for method concat of class Min
def test_Min_concat():  # pragma: no cover
    assert Min(1).concat(Min(2)).fold(lambda a: a) == 1
    assert Min(2).concat(Min(1)).fold(lambda a: a) == 1
    assert Min(1).concat(Min(1)).fold(lambda a: a) == 1


# Generated at 2022-06-24 00:32:23.303246
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1
    assert Sum(2).value == 2



# Generated at 2022-06-24 00:32:26.775584
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:32:29.914026
# Unit test for method concat of class First
def test_First_concat():
    first = First(1)
    expected = First(1)
    actual = first.concat(First(2))
    assert expected == actual



# Generated at 2022-06-24 00:32:33.034989
# Unit test for constructor of class Last
def test_Last():
    semigroup = Last(6)
    assert semigroup.value == 6


# Generated at 2022-06-24 00:32:34.779989
# Unit test for method concat of class One
def test_One_concat():
    result = One(False).concat(One(True))
    assert result == One(True)



# Generated at 2022-06-24 00:32:36.929209
# Unit test for method concat of class First
def test_First_concat():
    assert First(2).concat(First(3)), First(2)


# Generated at 2022-06-24 00:32:39.103160
# Unit test for constructor of class Min
def test_Min():
    assert Min(5).value == 5
    new_min = Min(5)
    assert new_min.value == 5


# Generated at 2022-06-24 00:32:43.101443
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():  # pragma: no cover
    # Arrange
    a = First(1)
    b = First(2)

    # Act
    result = a != b

    # Assert
    assert result, "Expect different values of a semigroup to not equal each other"

# Generated at 2022-06-24 00:32:44.885545
# Unit test for constructor of class Min
def test_Min():
    assert Min(10).value == 10
    assert Min.neutral_element == float("inf")


# Generated at 2022-06-24 00:32:46.012760
# Unit test for constructor of class First
def test_First():
    assert First(3) == First(3)


# Generated at 2022-06-24 00:32:47.213620
# Unit test for method __str__ of class All
def test_All___str__():
    assert 'All[value=True]' == str(All(True))

# Generated at 2022-06-24 00:32:51.685397
# Unit test for constructor of class Last
def test_Last():
    last_val = Last("foo")
    assert last_val.value == "foo"



# Generated at 2022-06-24 00:32:55.892901
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(5) == Sum(5)
    assert Sum(5) != Sum(6)


# Generated at 2022-06-24 00:33:03.050669
# Unit test for method concat of class All
def test_All_concat():
    assert All(True)  .concat(All(True))  .value == All(True)  .value
    assert All(True)  .concat(All(False)) .value == All(False) .value
    assert All(False) .concat(All(True))  .value == All(False) .value
    assert All(False) .concat(All(False)) .value == All(False) .value


# Generated at 2022-06-24 00:33:04.157391
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)



# Generated at 2022-06-24 00:33:07.526065
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_value = Sum(1).concat(Sum(1)).value
    assert_eq(sum_value, 2)


# Generated at 2022-06-24 00:33:09.122061
# Unit test for constructor of class Last
def test_Last():
    assert Last('first').value == 'first'



# Generated at 2022-06-24 00:33:11.157676
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: Sum(2)})) == 'Map[value={1: Sum[value=2]}]'


# Generated at 2022-06-24 00:33:13.415055
# Unit test for constructor of class Max
def test_Max():
    assert Max(10) == Max(10)
    assert not Max(10) == Max(9)
    assert not Max(10) == 9


# Generated at 2022-06-24 00:33:16.858907
# Unit test for method __str__ of class Min
def test_Min___str__():
    first = Min(3)
    second = Min(2)
    third = Min(1)

    assert(first.__str__() == "Min[value=3]")
    assert(second.__str__() == "Min[value=2]")
    assert(third.__str__() == "Min[value=1]")


# Generated at 2022-06-24 00:33:20.658182
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-24 00:33:25.431381
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(5).concat(Sum(2)) == Sum(7)
    assert Sum(0).concat(Sum(0)) == Sum(0)
    assert Sum(0).concat(Sum(5)) == Sum(5)
    assert Sum(5).concat(Sum(0)) == Sum(5)


# Generated at 2022-06-24 00:33:27.703984
# Unit test for constructor of class Sum
def test_Sum():
    sum_value = Sum(1)
    assert sum_value is not None


# Generated at 2022-06-24 00:33:32.335828
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1
    assert Max(-1).value == -1
    assert Max(float("inf")).value == float("inf")
    assert Max(-float("inf")).value == -float("inf")


# Generated at 2022-06-24 00:33:34.148231
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'  # pragma: no cover


# Generated at 2022-06-24 00:33:37.912174
# Unit test for method __str__ of class One
def test_One___str__():
    one = One(True)
    assert str(one) == 'One[value=True]', 'semigroup not false'
    one = One(False)
    assert str(one) == 'One[value=False]', 'semigroup not false'


test_One___str__()



# Generated at 2022-06-24 00:33:39.398128
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': 1, 'b': 2, 'c': 3})



# Generated at 2022-06-24 00:33:42.927786
# Unit test for method concat of class Last
def test_Last_concat():
    """
    last = Last(1)
    last2 = Last(2)
    assert last.concat(last2) == Last(2)
    """

    pass

# Generated at 2022-06-24 00:33:44.655406
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(10)) == 'Min[value=10]'


# Generated at 2022-06-24 00:33:49.342987
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).concat(One(2)) == One(1)
    assert One(0).concat(One(2)) == One(2)
    assert One(0).concat(One(0)) == One(0)
    assert One(1).concat(One(0)) == One(1)

# Generated at 2022-06-24 00:33:55.708878
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)


# Generated at 2022-06-24 00:33:59.645068
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(30)) == 'Last[value=30]'


# Generated at 2022-06-24 00:34:00.886652
# Unit test for method __str__ of class First
def test_First___str__():
    assert First(1).__str__() == 'Fist[value=1]'



# Generated at 2022-06-24 00:34:07.865083
# Unit test for method concat of class Map
def test_Map_concat():
    m = Map({'abc': Min(0), 'foo': Min(1)})
    m2 = Map({'abc': Min(1), 'bar': Min(2)})
    assert m.concat(m2) == Map({'abc': Min(0), 'foo': Min(1), 'bar': Min(2)})



# Generated at 2022-06-24 00:34:09.783491
# Unit test for constructor of class Sum
def test_Sum():
    left = Sum(1)
    right = Sum(2)
    
    print(left == right)

# Generated at 2022-06-24 00:34:15.100879
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1).fold(int) == 1
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum.neutral().fold(int) == 0
    assert Sum(0) == Sum.neutral()


# Generated at 2022-06-24 00:34:18.297043
# Unit test for constructor of class Min
def test_Min():
    assert Min(30).value == 30


# Generated at 2022-06-24 00:34:23.404693
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)
    assert All.neutral() == All(True)
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)


# Generated at 2022-06-24 00:34:24.973690
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(1).__str__() == 'One[value=1]'


# Generated at 2022-06-24 00:34:29.572095
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda _: 2) == 2
    assert All(True).fold(lambda _: 2) == 2
    assert One(False).fold(lambda _: 2) == 2
    assert First('a').fold(lambda _: 2) == 2
    assert Last('b').fold(lambda _: 2) == 2
    assert Map({1: Sum(1)}).fold(lambda _: 2) == 2
    assert Max(1).fold(lambda _: 2) == 2
    assert Min(2).fold(lambda _: 2) == 2



# Generated at 2022-06-24 00:34:31.479252
# Unit test for method __str__ of class Last
def test_Last___str__():
    """
    Test for method __str__ of class Last
    """
    obj = Last(1)

    assert str(obj) == 'Last[value=1]'


# Generated at 2022-06-24 00:34:34.781645
# Unit test for constructor of class All
def test_All():
    # test of the constructor
    assert All(True).value == True
    assert All(False).value == False
    assert All(None).value == False
    assert All({}).value == False
    assert All([]).value == False
    assert All(()).value == False
    assert All('').value == False
    assert All(0).value == False


# Generated at 2022-06-24 00:34:37.060656
# Unit test for constructor of class One
def test_One():
    """
    Test One class constructor
    """
    value = One(True)
    assert isinstance(value, One)
    assert value.value == True



# Generated at 2022-06-24 00:34:47.602769
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(5) == Sum(5)
    assert Sum(5) != Sum(6)
    assert All(True) == All(True)
    assert All(True) != All(False)
    assert One(True) == One(True)
    assert One(True) != One(False)
    assert First(5) == First(5)
    assert First(5) != First(6)
    assert Last(5) == Last(5)
    assert Last(5) != Last(6)
    assert Map({1: Sum(5), 2: Sum(6)}) == Map({1: Sum(5), 2: Sum(6)})
    assert Map({1: Sum(5), 2: Sum(6)}) != Map({1: Sum(5), 2: Sum(7)})
    assert Max(5) == Max(5)

# Generated at 2022-06-24 00:34:52.366520
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:34:57.021888
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(True)) == All(False)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-24 00:35:01.355453
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(3).concat(Sum(3)) == Sum(6)
    assert Sum(2).concat(Sum(3)) == Sum(5)
    assert Sum(2).concat(Sum(0)) == Sum(2)


# Generated at 2022-06-24 00:35:03.873516
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)


# Generated at 2022-06-24 00:35:05.950181
# Unit test for method __str__ of class All
def test_All___str__():
    expected = 'All[value=True]'
    actual = str(All(True))
    assert (expected == actual)



# Generated at 2022-06-24 00:35:07.421683
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'



# Generated at 2022-06-24 00:35:16.037143
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({1: Sum(10), 2: Sum(20)}).concat(Map({1: Sum(30), 2: Sum(40)})) == Map({1: Sum(40), 2: Sum(60)})
    assert Map({1: All(False), 2: All(True)}).concat(Map({1: All(True), 2: All(False)})) == Map({1: All(False), 2: All(True)})
    assert Map({1: One(False), 2: One(True)}).concat(Map({1: One(True), 2: One(False)})) == Map({1: One(True), 2: One(True)})

# Generated at 2022-06-24 00:35:22.407020
# Unit test for method concat of class First
def test_First_concat():
    assert First(4).concat(First(3)) == First(4)
    assert First(3).concat(First(4)) == First(3)
    assert First(3).concat(First('foobar')) == First(3)
    assert First('foobar').concat(First(3)) == First('foobar')


# Generated at 2022-06-24 00:35:24.279130
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).__str__() == "Last[value=1]"


# Generated at 2022-06-24 00:35:28.596001
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)


# Generated at 2022-06-24 00:35:32.513286
# Unit test for constructor of class All
def test_All():
    """
    :return: -
    """
    assert All(True) == All(True)


# Generated at 2022-06-24 00:35:36.573863
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True).value == True
    assert All(False).value == False


# Generated at 2022-06-24 00:35:38.963402
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(10)) == "Fist[value=10]"



# Generated at 2022-06-24 00:35:40.197340
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(10)) == 'Sum[value=10]'


# Generated at 2022-06-24 00:35:42.326890
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(10)) == "Max[value=10]"

# Generated at 2022-06-24 00:35:44.939393
# Unit test for method __str__ of class Max
def test_Max___str__():
    """
    Receives a number and checks if it was converted to string as expected
    """
    assert str(Max(10)) == 'Max[value=10]'



# Generated at 2022-06-24 00:35:46.509491
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-24 00:35:57.579779
# Unit test for method concat of class One
def test_One_concat():
    assert One(False).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)
    assert One(None).concat(One(None)) == One(None)
    assert One(None).concat(One(False)) == One(False)
    assert One(None).concat(One(True)) == One(True)
    assert One(False).concat(One(None)) == One(True)
    assert One(True).concat(One(None)) == One(True)


# Generated at 2022-06-24 00:36:00.596841
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'
    assert str(Max(0.89)) == 'Max[value=0.89]'
    assert str(Max('97')) == "Max[value=97]"



# Generated at 2022-06-24 00:36:04.850658
# Unit test for constructor of class Map
def test_Map():
    m = Map({"one": One(True), "two": One(True)})
    assert m.value == {"one": One(True), "two": One(True)}

# Generated at 2022-06-24 00:36:13.053526
# Unit test for constructor of class All
def test_All():
    result = All(True).concat(All(True))
    expected = All(True)
    assert result == expected, "Should be All(True), but got: {}".format(result)
    result = All(False).concat(All(True))
    expected = All(False)
    assert result == expected, "Should be All(False), but got: {}".format(result)
    result = All(True).concat(All(False))
    expected = All(False)
    assert result == expected, "Should be All(False), but got: {}".format(result)
    result = All(False).concat(All(False))
    expected = All(False)
    assert result == expected, "Should be All(False), but got: {}".format(result)



# Generated at 2022-06-24 00:36:14.239926
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert 'Last[value=1]' == str(Last(1))


# Generated at 2022-06-24 00:36:16.133600
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda s: s + 1) == 2
    assert One(True).fold(lambda s: s) == True

# Generated at 2022-06-24 00:36:17.950084
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(10) == Semigroup(10)
    assert not Semigroup(10) == Semigroup(12)
    assert not Semigroup(10) == '10'



# Generated at 2022-06-24 00:36:19.646262
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    res = All(True)
    assert isinstance(res, All)
    assert res.__str__() == 'All[value=True]'



# Generated at 2022-06-24 00:36:20.524280
# Unit test for method __str__ of class One
def test_One___str__():
    assert 'One[value=True]' == str(One(True))


# Generated at 2022-06-24 00:36:22.090413
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-24 00:36:23.571961
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'foo': 2})) == 'Map[value={\'foo\': 2}]'


# Generated at 2022-06-24 00:36:27.832807
# Unit test for method __str__ of class Map
def test_Map___str__():
    """
    Unit test for method __str__ of class Map
    """
    map_class = Map({"one": Sum(1), "two": Sum(2)})
    assert (str(map_class) == 'Map[value={\'one\': Sum[value=1], \'two\': Sum[value=2]}]')



# Generated at 2022-06-24 00:36:35.908775
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(True).concat(All(False)) == All(False)
    assert All(1).concat(All(0)) == All(0)
    assert All(0).concat(All(1)) == All(0)
    assert All(1).concat(All(1)) == All(1)


# Generated at 2022-06-24 00:36:37.657209
# Unit test for method __str__ of class Min
def test_Min___str__():  # pragma: no cover
    assert 'Min[value=1]' == str(Min(1))

# Generated at 2022-06-24 00:36:38.648491
# Unit test for method concat of class First
def test_First_concat():
    assert First(42).concat(First(10)) == First(42)



# Generated at 2022-06-24 00:36:41.080853
# Unit test for constructor of class First
def test_First():
    # Constructor of class First
    result = First("a").value
    expected = "a"
    assert result == expected, "Expected {} but got {}".format(expected, result)


# Generated at 2022-06-24 00:36:44.650808
# Unit test for method concat of class Min
def test_Min_concat():
    minimum = Min(1)
    another_minimum = Min(2)
    assert minimum.concat(another_minimum).value == 1
    assert another_minimum.concat(minimum).value == 1
    assert minimum.value == 1
    assert another_minimum.value == 2



# Generated at 2022-06-24 00:36:54.357371
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({"a": Sum(1), "b": Sum(2)})) == "Map[value={'a': Sum[value=1], 'b': Sum[value=2]}]"
    assert str(Map({1: Sum(1), 2: Sum(2)})) == "Map[value={1: Sum[value=1], 2: Sum[value=2]}]"
    assert str(Map({"a": Sum(1), 2: Sum(2)})) == "Map[value={'a': Sum[value=1], 2: Sum[value=2]}]"
    assert str(Map({1: Sum(1), "b": Sum(2)})) == "Map[value={1: Sum[value=1], 'b': Sum[value=2]}]"



# Generated at 2022-06-24 00:36:55.934057
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1).value == 1



# Generated at 2022-06-24 00:37:00.633830
# Unit test for method __str__ of class First
def test_First___str__():
    expected = 'Fist[value=foo]'
    result = First('foo').__str__()
    assert result == expected, 'Expected "{}", but got "{}"'.format(expected, result)



# Generated at 2022-06-24 00:37:04.139222
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'


# Generated at 2022-06-24 00:37:07.265584
# Unit test for method __str__ of class First
def test_First___str__():
    from unittest import TestCase
    from operator import attrgetter
    from itertools import starmap
    from expect import expect

    class First___str__(TestCase):

        def test_First___str__(self):
            expect(str(First("Foo")))

# Generated at 2022-06-24 00:37:08.952839
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'



# Generated at 2022-06-24 00:37:12.091797
# Unit test for constructor of class Map
def test_Map():
    """
    """
    size_of_Map_without_values = 0
    size_of_Map_with_values = 1
    assert len(Map({})) == size_of_Map_without_values
    assert len(Map({'a': Sum(0)})) == size_of_Map_with_values


# Generated at 2022-06-24 00:37:16.738992
# Unit test for method concat of class Max
def test_Max_concat():  # pragma: no cover
    result = Max(1).concat(Max(2))
    expected = Max(2)
    assert result == expected


# Generated at 2022-06-24 00:37:17.794065
# Unit test for method __str__ of class Min
def test_Min___str__():
    r = Min(1)
    assert str(r) == 'Min[value=1]'


# Generated at 2022-06-24 00:37:18.856505
# Unit test for method __str__ of class Last
def test_Last___str__(): # pragma: no cover
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-24 00:37:20.294536
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert All(True).__str__() == 'All[value=True]'


# Generated at 2022-06-24 00:37:25.289275
# Unit test for constructor of class First
def test_First():
    assert First(10) == First(10)
    assert First(10) != First(11)
    assert First(10) != First('10')


# Generated at 2022-06-24 00:37:27.592081
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First({'key': 'value'})) == "Fist[value={'key': 'value'}]"


# Generated at 2022-06-24 00:37:31.069021
# Unit test for method concat of class Last
def test_Last_concat():
    last = Last(1)
    last_concatenated = last.concat(Last(2))
    expected = Last(2)

    assert last_concatenated.value == expected.value
    assert last_concatenated == expected



# Generated at 2022-06-24 00:37:32.014497
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1



# Generated at 2022-06-24 00:37:34.118591
# Unit test for method concat of class Min
def test_Min_concat():
    min_1 = Min(1)
    min_2 = Min(2)
    assert Min.concat(min_1, min_2) == Min(1)



# Generated at 2022-06-24 00:37:35.318222
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-24 00:37:36.690803
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup("Hello").fold(fn=lambda x: x.replace("Hello", "World")) == "World"
    assert Semigroup("").fold(fn=lambda x: x.replace("Hello", "World")) == ""

# Generated at 2022-06-24 00:37:40.226700
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-24 00:37:43.706584
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(4).concat(Max(2)).value == 4
    assert Max(2).concat(Max(4)).value == 4
    assert Max(4).concat(Max(4)).value == 4



# Generated at 2022-06-24 00:37:44.882639
# Unit test for constructor of class Map
def test_Map():
    map = Map({'a': Sum(1), 'b': Sum(2)})
    assert map.value['a'] == Sum(1)
    assert map.value['b'] == Sum(2)


# Generated at 2022-06-24 00:37:49.296309
# Unit test for method concat of class Min
def test_Min_concat():  # pragma: no cover
    min1 = Min(1)
    min2 = Min(2)
    min3 = Min(3)
    min4 = Min(4)
    min5 = Min(5)
    min6 = Min(6)
    min7 = Min(7)

    assert min1.concat(min2) == Min(1)
    assert min1.concat(min2).concat(min3) == Min(1)
    assert min2.concat(min3) == Min(2)
    assert min3.concat(min4) == Min(3)
    assert min4.concat(min5) == Min(4)
    assert min5.concat(min6) == Min(5)
    assert min6.concat(min7) == Min(6)



# Generated at 2022-06-24 00:37:54.015139
# Unit test for method concat of class All
def test_All_concat():
    first = All(True)
    second = All(False)
    result = first.concat(second)

    assert result is not None, 'should have value'
    assert result.value is False, 'should be false'



# Generated at 2022-06-24 00:38:03.995786
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert All(True) == All(True)
    assert All(False) != All(True)
    assert One(True) == One(True)
    assert One(False) != One(True)
    assert First(1) == First(1)
    assert First(2) != First(1)
    assert Last(1) == Last(1)
    assert Last(2) != Last(1)
    assert Map({'a': Sum(100), 'b': Sum(200)}) == Map({'a': Sum(100), 'b': Sum(200)})
    assert Map({'a': Sum(100), 'b': Sum(200)}) != Map({'a': Sum(200), 'b': Sum(200)})
    assert Max

# Generated at 2022-06-24 00:38:06.521491
# Unit test for constructor of class Last
def test_Last():
    last = Last(10)
    assert last.value == 10
    last = Last('abc')
    assert last.value == 'abc'



# Generated at 2022-06-24 00:38:10.104827
# Unit test for method __str__ of class Map
def test_Map___str__():
    expected = 'Map[value=0]'
    actual = str(Map(0))
    assert expected == actual, 'Expect: {}. Given: {}'.format(expected, actual)


# Generated at 2022-06-24 00:38:19.512116
# Unit test for method concat of class Min
def test_Min_concat():
    # test with int
    assert Min(1).concat(Min(2)).value == 1
    assert Min(1).concat(Min(0)).value == 0
    # test with float
    assert Min(1.0).concat(Min(2.0)).value == 1.0
    assert Min(1).concat(Min(0.0)).value == 0.0
    # test with string
    assert Min("a").concat(Min("b")).value == "a"
    assert Min("a").concat(Min("0")).value == "0"
    # test with list
    assert Min([1]).concat(Min([2])).value == [1]
    assert Min([1]).concat(Min([0])).value == [0]
    # test with tuple

# Generated at 2022-06-24 00:38:21.833506
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(3)) == Sum(5)
    assert Sum(0).concat(Sum(3)) == Sum(3)



# Generated at 2022-06-24 00:38:24.524935
# Unit test for constructor of class Last
def test_Last():
    """
    :return: nothing
    """
    lst = Last(7)
    assert str(lst) == 'Last[value=7]'


# Generated at 2022-06-24 00:38:26.930642
# Unit test for constructor of class Max
def test_Max():
    max_ = Max(1)
    assert max_.value == 1
    assert max_.fold(lambda fn: fn) == 1



# Generated at 2022-06-24 00:38:35.140635
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(True).concat(One(None)) == One(True)

    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(False).concat(One(None)) == One(False)

    assert One(None).concat(One(True)) == One(True)
    assert One(None).concat(One(False)) == One(False)
    assert One(None).concat(One(None)) == One(None)



# Generated at 2022-06-24 00:38:43.559454
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    Unit test for method __eq__ of class Semigroup
    """
    param = 1
    assert Semigroup(param) == Semigroup(param)
    assert Semigroup(param) == Sum(param)
    assert Semigroup(param) == All(param)
    assert Semigroup(param) == One(param)
    assert Semigroup(param) == First(param)
    assert Semigroup(param) == Last(param)
    assert Semigroup(param) == Max(param)
    assert Semigroup(param) == Min(param)
    assert Semigroup(param) == Map({'a': Semigroup(param)})


# Generated at 2022-06-24 00:38:46.237184
# Unit test for method __str__ of class Max
def test_Max___str__():
    max_instance = Max(10)
    string_max_instance = str(max_instance)
    assert string_max_instance == 'Max[value=10]'



# Generated at 2022-06-24 00:38:55.861430
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(False).concat(One(True)) == One(True)
    assert One(True).concat(One(True)) == One(True)
    assert One(1).concat(One(0)) == One(1)
    assert One(0).concat(One(0)) == One(0)
    assert One(0).concat(One(1)) == One(1)
    assert One(1).concat(One(1)) == One(1)


# Generated at 2022-06-24 00:38:57.288987
# Unit test for constructor of class First
def test_First():
    # Create new instance of class First with value=False
    assert First(False)



# Generated at 2022-06-24 00:38:58.616304
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-24 00:39:03.978274
# Unit test for constructor of class All
def test_All():
    assert All(True).value is True
    assert All(True).concat(All(False)).value is False
    assert All(False).concat(All(True)).value is False
    assert All(False).concat(All(False)).value is False



# Generated at 2022-06-24 00:39:06.786970
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(4)) == Min(1)
    assert Min(4).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-24 00:39:09.011321
# Unit test for constructor of class Min
def test_Min():
    # Min with neutral element and value
    m1 = Min(8)
    assert m1.value == 8
    assert m1.neutral_element == float("inf")



# Generated at 2022-06-24 00:39:12.530245
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False


# Generated at 2022-06-24 00:39:15.369759
# Unit test for method concat of class All
def test_All_concat():
    x = All(True)
    y = All(False)
    z = All(True)

    assert x.concat(y).value == False
    assert z.concat(x).value == True



# Generated at 2022-06-24 00:39:19.017438
# Unit test for constructor of class Min
def test_Min():
    for i in range(0,10):
        for j in range(0,10):
            if i < j:
                assert(Min(i).concat(Min(j)).value == i)
            else:
                assert(Min(i).concat(Min(j)).value == j)


# Generated at 2022-06-24 00:39:23.456589
# Unit test for method concat of class Min
def test_Min_concat():
    min_1 = Min(1)
    min_2 = Min(2)
    min_3 = Min(3)
    assert min_1.concat(min_2).value == 1
    assert min_1.concat(min_3).value == 1



# Generated at 2022-06-24 00:39:24.761229
# Unit test for constructor of class Sum
def test_Sum():
    sum_instance = Sum(0)
    assert sum_instance.value == 0


# Generated at 2022-06-24 00:39:29.758018
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"a": Sum(2)}).concat(Map({"a": Sum(2)})).value == {"a": Sum(4)}
    assert Map({"a": Sum(2), "b": Sum(4)}).concat(
        Map({"a": Sum(2), "b": Sum(4)})
    ).value == {"a": Sum(4), "b": Sum(8)}



# Generated at 2022-06-24 00:39:32.536928
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)

# Generated at 2022-06-24 00:39:36.315102
# Unit test for method concat of class One
def test_One_concat():
    # False || False = False
    assert One(False).concat(One(False)) == One(False)

    # False || True = True
    assert One(False).concat(One(True)) == One(True)

    # True || False = True
    assert One(True).concat(One(False)) == One(True)

    # True || True = True
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-24 00:39:37.463277
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)



# Generated at 2022-06-24 00:39:41.667329
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)



# Generated at 2022-06-24 00:39:43.611279
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    lhs = Sum(1)
    rhs = Sum(1)
    assert lhs == rhs



# Generated at 2022-06-24 00:39:46.305003
# Unit test for method concat of class First
def test_First_concat():
    # arrange
    first = First(1)
    second = First(2)

    # act
    result = first.concat(second)

    # assert
    assert result.value == 1

# Generated at 2022-06-24 00:39:47.385760
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)


# Generated at 2022-06-24 00:39:49.503626
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(10)) == 'Min[value=10]'



# Generated at 2022-06-24 00:39:54.085329
# Unit test for method __str__ of class Last
def test_Last___str__():
    value = 1
    last = Last(value)
    assert str(last) == 'Last[value=1]'


# Generated at 2022-06-24 00:39:56.921802
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(10).fold(lambda x: x) == 10


# Unit tests for method concat of class Sum

# Generated at 2022-06-24 00:39:58.437922
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(4)) == 'Min[value=4]'



# Generated at 2022-06-24 00:40:01.784651
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)
    assert not Semigroup(1) == Sum(1)


# Generated at 2022-06-24 00:40:03.825363
# Unit test for method __str__ of class All
def test_All___str__():
    assert 'All[value=True]' == str(All(True))
    assert 'All[value=False]' == str(All(False))


# Generated at 2022-06-24 00:40:08.000593
# Unit test for constructor of class Map
def test_Map():  # pragma: no cover
    Semigroup({1: Min(1), 2: Min(2)}).concat(Semigroup({1: Min(1), 2: Min(2)})) == Map({1: Min(1), 2: Min(2)})
    Semigroup(None).concat(Semigroup(None)) == Semigroup(None)
    Semigroup([]).concat(Semigroup([])) == Semigroup([])
    Semigroup("").concat(Semigroup("")) == Semigroup("")
    Semigroup(0).concat(Semigroup(0)) == Semigroup(0)
    Semigroup("").concat(Semigroup("")) == Semigroup("")
    Semigroup({}).concat(Semigroup({})) == Semigroup({})
    Semigroup(True).concat(Semigroup(True)) == Semigroup(True)


# Generated at 2022-06-24 00:40:08.596865
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1


# Generated at 2022-06-24 00:40:10.076648
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(4).concat(Last(5)) == Last(5)


# Generated at 2022-06-24 00:40:19.779517
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    Unit test for method __eq__ of class Semigroup
    """
    assert Sum(3) == Sum(3)
    assert Sum(3) != Sum(4)

    assert All(True) == All(True)
    assert All(True) != All(False)

    assert One(True) == One(True)
    assert One(True) != One(False)

    assert First('John') == First('John')
    assert First('John') != First('Doe')

    assert Last('John') == Last('John')
    assert Last('John') != Last('Doe')

    assert Max(3) == Max(3)
    assert Max(3) != Max(4)

    assert Min(3) == Min(3)
    assert Min(3) != Min(4)



# Generated at 2022-06-24 00:40:23.277217
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(7).concat(Min(8)).value == 7
    assert Min(7).concat(Min(6)).value == 6
    assert Min(7).concat(Min(7)).value == 7

# Generated at 2022-06-24 00:40:33.777916
# Unit test for constructor of class Map
def test_Map():
    assert Map({
        'a': All(True),
        'b': One(False),
        'c': First(1),
        'd': Last(2)
    }) == Map(
        {
            'a': All(True),
            'b': One(False),
            'c': First(1),
            'd': Last(2)
        })



# Generated at 2022-06-24 00:40:36.911662
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)


# Generated at 2022-06-24 00:40:38.508216
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)



# Generated at 2022-06-24 00:40:44.696423
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) != 1
    assert Last(1).value == 1
    assert Last(1).value != 2
    assert repr(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-24 00:40:50.068370
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(1)).value == 2
    assert Sum(123).concat(Sum(456)).value == 579
    assert Sum(123.123).concat(Sum(456.456)).value == 579.579


# Generated at 2022-06-24 00:40:51.316516
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One('a')) == "One[value=a]"


# Generated at 2022-06-24 00:40:55.460810
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1).value == 1
    # Testing from another class
    assert Sum(1).value == 1
    assert All(True).value == True
    assert One(True).value == True
    assert First("foo").value == "foo"
    assert Last("bar").value == "bar"
    assert Map({1: Sum(1)}).value == {1: Sum(1)}
    assert Min(1).value == 1
    assert Max(2).value == 2



# Generated at 2022-06-24 00:40:59.843333
# Unit test for constructor of class Last
def test_Last():
    """
    Test a Last class, add two Last classes
    """
    assert Last(3) == Last(3)
    assert Last(3).concat(Last(5)) == Last(5)



# Generated at 2022-06-24 00:41:01.125694
# Unit test for method concat of class First
def test_First_concat():
    assert First(10).concat(First(20)).value == 10


# Generated at 2022-06-24 00:41:02.844578
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)


# Generated at 2022-06-24 00:41:05.760225
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(True).value == True
    assert One(True) != All(False)
    assert One(True) != None


# Generated at 2022-06-24 00:41:16.532878
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    :returns: True if test successful, False otherwise
    :rtype: bool
    """
    return bool(
        Sum(10).fold(lambda x: x + 1) == 11
        and All(True).fold(lambda x: x) == True
        and One(True).fold(lambda x: x) == True
        and First(10).fold(lambda x: x) == 10
        and Last(10).fold(lambda x: x) == 10
        and Map({1: Sum(10)}).fold(lambda x: x) == {1: Sum(10)}
        and Max(10).fold(lambda x: x) == 10
        and Min(1).fold(lambda x: x) == 1
    )


# Generated at 2022-06-24 00:41:18.046193
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-24 00:41:24.498675
# Unit test for method concat of class Min
def test_Min_concat():
    min_a = Min(1)
    min_b = Min(2)
    min_c = Min.neutral()

    assert min_a.concat(min_b) == Min(1)
    assert min_a.concat(min_c) == Min(1)
    assert min_b.concat(min_c) == Min(2)



# Generated at 2022-06-24 00:41:26.146800
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'key': 'value'})) == "Map[value={'key': 'value'}]"



# Generated at 2022-06-24 00:41:27.925931
# Unit test for method concat of class Max
def test_Max_concat():
    """
    testing method concat of class Max
    """
    assert Max(1).concat(Max(2)).value == 2



# Generated at 2022-06-24 00:41:31.006821
# Unit test for method concat of class Min
def test_Min_concat():  # pragma: no cover
    x = Min(10)
    y = Min(30)
    z = x.concat(y)
    assert z.value == min(x.value, y.value)



# Generated at 2022-06-24 00:41:32.321826
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)



# Generated at 2022-06-24 00:41:36.999737
# Unit test for method concat of class Max
def test_Max_concat():
    semigroup1 = Max(6)
    semigroup2 = Max(-10)
    print(semigroup1)
    print(semigroup2)
    print(semigroup1.concat(semigroup2))


if __name__ == "__main__":
    test_Max_concat()