

# Generated at 2022-06-24 00:31:39.347347
# Unit test for constructor of class Sum
def test_Sum():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    assert issubclass(Sum, Functor)
    assert issubclass(Sum, Monad)
    assert Sum(2).value == 2



# Generated at 2022-06-24 00:31:42.220198
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1


# Generated at 2022-06-24 00:31:45.749668
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(10).concat(Max(55)) == Max(55)


# Generated at 2022-06-24 00:31:50.454623
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(2) == First(2)
    assert First(1) != First(2)

    assert First(1).concat(First('abc')) == First(1)
    assert First(1).concat(First(2)) == First(1)
    assert First(2).concat(First(1)) == First(2)



# Generated at 2022-06-24 00:31:54.637192
# Unit test for method __str__ of class Map
def test_Map___str__():
    """
    Test that method __str__ of class Semigroup return correct string;
    """
    map = Map({'a': Sum(5)})
    assert str(map) == 'Map[value={\'a\': Sum[value=5]}]'



# Generated at 2022-06-24 00:31:56.163594
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(2)) == 'Max[value=2]'


# Generated at 2022-06-24 00:31:58.157361
# Unit test for constructor of class Max
def test_Max():
    assert Max(10) == Max(10)
    assert Max(10) != Max(5)


# Generated at 2022-06-24 00:31:59.849059
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    sum_fun = lambda i: i + i
    assert Semigroup(10).fold(sum_fun) == 20

# Generated at 2022-06-24 00:32:01.012564
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(0)) == "Max[value=0]"


# Generated at 2022-06-24 00:32:03.136136
# Unit test for method concat of class First
def test_First_concat():
    first_1 = First(1)
    first_2 = First(2)

    assert first_1.concat(first_2) == first_1


# Generated at 2022-06-24 00:32:05.248780
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(30)) == 'Min[value=30]'

# Generated at 2022-06-24 00:32:15.102198
# Unit test for method concat of class Map
def test_Map_concat():
    first_map = Map({
        'Name': First('Joe'),
        'Age': Max(30),
        'Employed': All(True),
        'Children': Sum(0)
    })
    second_map = Map({
        'Name': Last('Jane'),
        'Age': Min(21),
        'Employed': All(False),
        'Children': Sum(3)
    })
    expect = Map({
        'Name': Last('Jane'),
        'Age': Min(21),
        'Employed': All(False),
        'Children': Sum(3)
    })
    actual = first_map.concat(second_map)
    assert expect == actual


# Generated at 2022-06-24 00:32:17.617921
# Unit test for constructor of class One
def test_One():
    one = One(True)
    assert isinstance(one, One)
    assert one.value == True


# Generated at 2022-06-24 00:32:21.001100
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)).value == True
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(False)).value == False


# Generated at 2022-06-24 00:32:23.022509
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)


# Generated at 2022-06-24 00:32:24.411872
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-24 00:32:25.777079
# Unit test for constructor of class Last
def test_Last():
    l = Last(1)
    assert l.value == 1



# Generated at 2022-06-24 00:32:28.233484
# Unit test for constructor of class Map
def test_Map():
    assert Map({'name': First('Fabián')}).value == {'name': First('Fabián')}



# Generated at 2022-06-24 00:32:30.392697
# Unit test for constructor of class Min
def test_Min():
    assert Min(3) == Min(3)
    assert Min(3) != Min(2)



# Generated at 2022-06-24 00:32:32.542701
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First("pewpew")) == 'Fist[value=pewpew]'



# Generated at 2022-06-24 00:32:35.090746
# Unit test for method __str__ of class Min
def test_Min___str__(): # pragma: no cover
    test = Min(3)
    expected = "Min[value=3]"
    result = test.__str__()
    assert result == expected


# Generated at 2022-06-24 00:32:36.647872
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1



# Generated at 2022-06-24 00:32:38.418054
# Unit test for constructor of class Min
def test_Min():
    assert Min(2) == Min(2)
    assert Min(2).value == 2


# Generated at 2022-06-24 00:32:40.155058
# Unit test for method __str__ of class First
def test_First___str__():
    instance = First(1)
    assert str(instance) == 'Fist[value=1]'



# Generated at 2022-06-24 00:32:43.005688
# Unit test for method concat of class Last
def test_Last_concat():
    last1 = Last(1)
    last2 = Last(2)

    assert last1.concat(last2) == Last(2)


# Generated at 2022-06-24 00:32:44.183166
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': All(True), 'b': All(False)}).value == {'a': All(True), 'b': All(False)}



# Generated at 2022-06-24 00:32:45.212656
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(5)) == Last(5)


# Generated at 2022-06-24 00:32:46.378854
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == "Sum[value=1]"


# Generated at 2022-06-24 00:32:48.281249
# Unit test for constructor of class First
def test_First():
    """
    Unit test for constructor of class First
    """
    assert First(1) == First(1)

# Generated at 2022-06-24 00:32:51.887344
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-24 00:32:56.328546
# Unit test for method __str__ of class Min
def test_Min___str__():
    test_Min = Min(10)
    assert 'Min[value=10]' == str(test_Min)


# Generated at 2022-06-24 00:32:58.819509
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-24 00:33:00.481692
# Unit test for constructor of class Max
def test_Max():
    assert Max(3).fold(lambda value: value) == 3


# Generated at 2022-06-24 00:33:01.992332
# Unit test for constructor of class One
def test_One():
    one = One(True)
    assert type(one) == One


# Generated at 2022-06-24 00:33:03.796493
# Unit test for method __str__ of class Min
def test_Min___str__():
    minimal = Min(0)

    assert minimal.__str__() == 'Min[value=0]'


# Generated at 2022-06-24 00:33:05.420465
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(2).fold(lambda x: x + 1) == 3


# Generated at 2022-06-24 00:33:07.167791
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: Sum(1)})) == "Map[value={1: Sum[value=1]}]"
    

# Generated at 2022-06-24 00:33:11.387031
# Unit test for method __str__ of class Map
def test_Map___str__():
    semigroup = Map({'hello': Sum(12), 'world': Sum(12)})
    assert str(semigroup) == "Map[value={'hello': Sum[value=12], 'world': Sum[value=12]}]"



# Generated at 2022-06-24 00:33:19.742928
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert First(1) == First(1) and First(1) != First(2)
    assert One(True) == One(True) and One(True) != One(False)
    assert Last(1) == Last(1) and Last(1) != Last(2)
    assert All(True) == All(True) and All(True) != All(False)
    assert Max(1) == Max(1) and Max(1) != Max(2)
    assert Min(1) == Min(1) and Min(1) != Min(2)
    assert Sum(1) == Sum(1) and Sum(1) != Sum(2)

# Generated at 2022-06-24 00:33:21.429068
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-24 00:33:29.247145
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(False).concat(One(None)) == One(None)
    assert One(False).concat(One(0)) == One(0)
    assert One(False).concat(One('')) == One('')
    assert One(False).concat(One(' ')) == One(' ')
    assert One(False).concat(One('0')) == One('0')


# Generated at 2022-06-24 00:33:32.192764
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)).value == 1
    assert First(1).concat(Last(2)).value == 1


# Generated at 2022-06-24 00:33:35.239180
# Unit test for method concat of class Max
def test_Max_concat():
    a = Max(1)
    b = Max(3)
    c = Max(2)

    assert a.concat(b).value == 3
    assert b.concat(c).value == 3

# Generated at 2022-06-24 00:33:40.038464
# Unit test for method __str__ of class Last
def test_Last___str__():
    print(Last(10))



# Generated at 2022-06-24 00:33:51.061928
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).concat(Max(1)).value == 1
    assert Max(2).concat(Max(1)).value == 2
    assert Max(1).concat(Max(2)).value == 2
    assert Max(1).concat(Max(1)).concat(Max(1)).value == 1
    assert Max(1).concat(Max(2)).concat(Max(3)).value == 3
    assert Max(3).concat(Max(2)).concat(Max(1)).value == 3
    assert Max(3).concat(Max(3)).concat(Max(1)).value == 3
    assert Max(1).concat(Max(3)).concat(Max(2)).value == 3


# Generated at 2022-06-24 00:33:55.169708
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) == Sum(1)



# Generated at 2022-06-24 00:34:00.419014
# Unit test for method concat of class Last
def test_Last_concat():
    """
    >>> Last(1).concat(Last(2)) == Last(2)
    True
    >>> Last(2).concat(Last(3)) == Last(3)
    True
    """
    pass



# Generated at 2022-06-24 00:34:02.343451
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(['a']).fold(bool) == Semigroup(['a']).fold(bool)



# Generated at 2022-06-24 00:34:08.436305
# Unit test for method concat of class All
def test_All_concat():
    """
    Unit test for method concat of class All
    """
    assert (All(True).concat(All(True))).value == True
    assert (All(True).concat(All(False))).value == False
    assert (All(False).concat(All(False))).value == False
    assert (All(False).concat(All(True))).value == False


# Generated at 2022-06-24 00:34:10.012928
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-24 00:34:12.953350
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'
    assert str(Sum(2)) == 'Sum[value=2]'


# Generated at 2022-06-24 00:34:22.487484
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    A generalization of foldRight and foldLeft that works on any Monoid
    See https://github.com/fantasyland/fantasy-land#foldable
    """

    # Sum
    assert Sum.neutral().fold(lambda x: x) == 0
    assert Sum(1).fold(lambda x: x) == 1
    assert Sum(2).fold(lambda x: x) == 2
    assert Sum(3).fold(lambda x: x) == 3

    # All
    assert All.neutral().fold(lambda x: x) is True
    assert All(False).fold(lambda x: x) is False
    assert All(True).fold(lambda x: x) is True

    # One
    assert One.neutral().fold(lambda x: x) is False
    assert One(False).fold(lambda x: x) is False


# Generated at 2022-06-24 00:34:24.863528
# Unit test for method __str__ of class First
def test_First___str__():
    t = First('the')
    assert str(t) == 'Fist[value=the]'


# Generated at 2022-06-24 00:34:26.439293
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'

# Generated at 2022-06-24 00:34:32.763839
# Unit test for constructor of class Map
def test_Map():
    assert Map({'key1': Sum(1), 'key2': Sum(2)}) == Map({'key1': Sum(1), 'key2': Sum(2)})
    assert Map({'key1': Sum(1), 'key2': Sum(2)}) != Map({'key1': Sum(1), 'key2': Sum(1)})



# Generated at 2022-06-24 00:34:34.819808
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert(Sum(1) == Sum(1))
    assert(Max(1) == Max(1))



# Generated at 2022-06-24 00:34:36.413003
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert Min(5.5).__str__() == 'Min[value=5.5]'  


# Generated at 2022-06-24 00:34:39.671178
# Unit test for constructor of class Min
def test_Min():
    min_a = Min(4)
    min_b = Min(3)
    assert min_a.concat(min_b).value == 3
    assert min_a.concat(min_a).value == 4



# Generated at 2022-06-24 00:34:45.432492
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(2).fold(lambda x: x * 3) == 6
    assert First('a').fold(lambda x: x + 'A') == 'a'
    assert All(True).fold(lambda x: not x) == False
    assert Map({'a': Sum(2), 'b': First('b')}).fold(lambda x: x['a'] + x['b']) == 4



# Generated at 2022-06-24 00:34:47.392115
# Unit test for constructor of class Semigroup
def test_Semigroup():
    test = Semigroup(123)
    assert isinstance(test, Semigroup)



# Generated at 2022-06-24 00:34:49.978334
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)



# Generated at 2022-06-24 00:34:52.830471
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(9).concat(Max(5)) == Max(9)
    assert Max(9).concat(Max(9)) == Max(9)


# Generated at 2022-06-24 00:34:58.297145
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(2)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-24 00:34:59.517835
# Unit test for constructor of class Last
def test_Last():
    assert Last(4) == Last(4) and Last(4).value == 4


# Generated at 2022-06-24 00:35:01.161489
# Unit test for constructor of class Map
def test_Map():
    assert Map({1: First(2), 3: First(4)}) == Map({1: First(2), 3: First(4)})



# Generated at 2022-06-24 00:35:03.279196
# Unit test for method __str__ of class Map
def test_Map___str__():
    """
    Unit test for method __str__
    """
    assert str(Map({'map': Last('value')})) == "Map[value={'map': Last[value='value']}]"



# Generated at 2022-06-24 00:35:07.607617
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'
    assert str(One(1)) == 'One[value=1]'
    assert str(One(None)) == 'One[value=None]'


# Generated at 2022-06-24 00:35:16.350607
# Unit test for method concat of class Map
def test_Map_concat():
    class Product(Semigroup):
        """
        Product is a Monoid that will combines 2 numbers, resulting in the product of the two.
        """

        neutral_element = 1

        def __str__(self) -> str:  # pragma: no cover
            return 'Product[value={}]'.format(self.value)

        def concat(self, semigroup):
            """
            :param semigroup: other semigroup to concat
            :type semigroup: Product[B]
            :returns: new Product with concated values
            :rtype: Product[A | B]
            """
            return Product(self.value * semigroup.value)
    

# Generated at 2022-06-24 00:35:17.619830
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(5)) == 'One[value=5]'


# Generated at 2022-06-24 00:35:18.664293
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'


# Generated at 2022-06-24 00:35:22.151927
# Unit test for constructor of class Map
def test_Map():
    with pytest.raises(TypeError):
        Map('')


# Generated at 2022-06-24 00:35:23.263712
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)).value == 2


# Generated at 2022-06-24 00:35:28.040249
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]', 'Should be "One[value=True]"'



# Generated at 2022-06-24 00:35:30.074708
# Unit test for method __str__ of class First
def test_First___str__():
    # Given
    first = First()

    # When
    result = str(first)

    # Then
    expected = 'Fist[value=None]'
    assert result == expected



# Generated at 2022-06-24 00:35:30.921305
# Unit test for constructor of class All
def test_All():  # pragma: no cover
    a = All(True)
    assert a.value == True



# Generated at 2022-06-24 00:35:32.422749
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(False)) == "One[value=False]"


# Generated at 2022-06-24 00:35:36.131828
# Unit test for method __str__ of class Max
def test_Max___str__():
    monoid = Max(5)
    assert str(monoid) == "Max[value=5]"



# Generated at 2022-06-24 00:35:37.051219
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)

# Generated at 2022-06-24 00:35:40.305867
# Unit test for constructor of class One
def test_One():
    one = One(False)
    assert one.value == False

# Generated at 2022-06-24 00:35:41.812558
# Unit test for method __str__ of class First
def test_First___str__():
    result = str(First(1))
    assert result == 'Fist[value=1]'


# Generated at 2022-06-24 00:35:45.183197
# Unit test for constructor of class Map
def test_Map():
    """
    Test the function with given value and should return the same value
    """
    assert Map({'a': Sum(1), 'b': Sum(2)}).value == {'a': Sum(1), 'b': Sum(2)}


# Generated at 2022-06-24 00:35:47.056717
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-24 00:35:51.029972
# Unit test for constructor of class Last
def test_Last():
    assert Last(10).value == 10
    assert Last(None).value is None
    assert Last(True).value is True


# Generated at 2022-06-24 00:35:53.445118
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(1).__str__() == 'One[value=1]'
    assert One(True).__str__() == 'One[value=True]'

# Generated at 2022-06-24 00:35:58.256581
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert First("text").fold(lambda x: x + x) == "texttext"
    assert Last("text").fold(lambda x: x + x) == "texttext"
    assert Sum(5).fold(lambda x: x + x) == 10
    assert All(True).fold(lambda x: x and True) == True
    assert One(True).fold(lambda x: x or True) == True
    assert Map({'key': First(10)}).fold(lambda x: x['key'].value) == 10



# Generated at 2022-06-24 00:35:58.887135
# Unit test for constructor of class One
def test_One():
    assert One(4).value == 4



# Generated at 2022-06-24 00:36:09.234584
# Unit test for constructor of class Map
def test_Map():
    class UnitTest(unittest.TestCase):
        def test_Sum(self):
            semigroup = Sum(5)

            self.assertEqual(5, semigroup.value)

        def test_all(self):
            semigroup = All(True)

            self.assertEqual(True, semigroup.value)

        def test_one(self):
            semigroup = One(False)

            self.assertEqual(False, semigroup.value)

        def test_first(self):
            semigroup = First(5)

            self.assertEqual(5, semigroup.value)

        def test_last(self):
            semigroup = Last(5)

            self.assertEqual(5, semigroup.value)

        def test_max(self):
            semigroup = Max(5)


# Generated at 2022-06-24 00:36:16.145802
# Unit test for method concat of class Min
def test_Min_concat():
    min_1 = Min(4)
    min_2 = Min(2)
    assert min_1.concat(min_2) == Min(2)
    assert min_1.concat(min_2).concat(min_2) == Min(2)
    assert min_1.concat(min_1) == Min(4)


# Generated at 2022-06-24 00:36:20.684139
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda value: value + value) == 2
    assert First(1).fold(lambda value: value + value) == 1
    assert Last(1).fold(lambda value: value + value) == 1
    assert Max(1).fold(lambda value: value + value) == 2
    assert Min(1).fold(lambda value: value + value) == 1
    assert All(True).fold(lambda value: not value) == False
    assert One(False).fold(lambda value: not value) == True


# Generated at 2022-06-24 00:36:22.228378
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)



# Generated at 2022-06-24 00:36:26.557854
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(1)
    b = Min(2)
    assert a.concat(b) == Min(1)
    b = Min(-1)
    assert a.concat(b) == Min(-1)

# Generated at 2022-06-24 00:36:30.101438
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(False)) == One(True)


# Generated at 2022-06-24 00:36:34.374656
# Unit test for method __str__ of class One
def test_One___str__():
    """
    Unit test for method __str__ of class One.
    """

    # call method
    result = str(One(True))

    # check result
    assert result == 'One[value=True]', 'Result of method __str__ is not valid!'



# Generated at 2022-06-24 00:36:36.709704
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(2) != Semigroup(1)


# Generated at 2022-06-24 00:36:40.345868
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)).value is True
    assert One(True).concat(One(False)).value is True
    assert One(False).concat(One(True)).value is True
    assert One(False).concat(One(False)).value is False



# Generated at 2022-06-24 00:36:43.551135
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).fold(lambda x: x) == 1
    assert Sum(1).fold(lambda x: x + 1) == 2



# Generated at 2022-06-24 00:36:45.847948
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-24 00:36:51.881283
# Unit test for constructor of class Max
def test_Max():  # pragma: no cover
    # Test to make sure value is set
    test = Max(1.1)
    assert test.value == 1.1

    # Test __eq__
    assert Max(1) == Max(1)

    # Test __str__
    assert str(Max(2)) == 'Max[value=2]'

    # Test neutral
    assert Max.neutral() == Max(-float("inf"))



# Generated at 2022-06-24 00:36:53.758139
# Unit test for method concat of class Max
def test_Max_concat():
    x = Max(1)
    y = Max(2)
    assert x.concat(y) == Max(2)


# Generated at 2022-06-24 00:36:54.979179
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-24 00:37:02.357421
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    print(ClsTestFrame.getClassName() +' - test_Semigroup - begin')

    listOfTests = ['test_Semigroup_1', 'test_Semigroup_2']
    for item in listOfTests:
        test = SemigroupTest(item)
        test.test()

    print(ClsTestFrame.getClassName() +' - test_Semigroup - end')


# Generated at 2022-06-24 00:37:06.289708
# Unit test for method concat of class Max
def test_Max_concat():
    res = [Max(i).concat(Max(i+1)) for i in range(1, 5)]
    assert res[0].value == 2
    assert res[1].value == 3
    assert res[2].value == 4
    assert res[3].value == 5

test_Max_concat()


# Generated at 2022-06-24 00:37:08.224289
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1).value == 1
    assert Sum(1).fold(lambda x: x) == 1



# Generated at 2022-06-24 00:37:09.603055
# Unit test for constructor of class Min
def test_Min():
    assert Min(3).value == 3
    assert Min(3) == Min(3)


# Generated at 2022-06-24 00:37:11.065131
# Unit test for constructor of class Last
def test_Last():
    assert Last(0).value == 0
    assert Last(1).value == 1
    assert Last(2).value == 2
    assert Last(3).value == 3


# Generated at 2022-06-24 00:37:14.659130
# Unit test for method __str__ of class Last
def test_Last___str__():
    a = Last(1)
    assert isinstance(a, Last)
    assert a.__str__() == 'Last[value=1]'

# Generated at 2022-06-24 00:37:20.332650
# Unit test for method concat of class Max
def test_Max_concat():
    seq = [3, 1, 2, 4, 3]
    semigroup = Max(seq[0])

    result = semigroup.concat(semigroup.neutral())
    assert result == semigroup

    for item in seq[1:]:
        semigroup = semigroup.concat(Max(item))

    result = semigroup.concat(Max(2))
    assert result == Max(4)



# Generated at 2022-06-24 00:37:25.288846
# Unit test for constructor of class One
def test_One():
    x = One(3)
    y = One(5)
    z = x.concat(y)
    assert z == One(3)


# Generated at 2022-06-24 00:37:26.351941
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)

# Generated at 2022-06-24 00:37:28.500053
# Unit test for constructor of class Sum
def test_Sum():
    """
    Test that Sum constructor functions as expected
    """
    assert Sum(1) == Sum(1)



# Generated at 2022-06-24 00:37:29.834946
# Unit test for constructor of class First
def test_First():
    assert First(3) == First(3)


# Generated at 2022-06-24 00:37:35.472120
# Unit test for constructor of class One
def test_One():
    assert One(1).value == 1, "One value should be 1"
    assert One(False).value == False, "One value should be False"
    assert One("test").value == "test", "One value should be 'test'"



# Generated at 2022-06-24 00:37:41.045253
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == Sum(1).value
    assert Sum(2).value == Sum(2).value
    assert Sum(1).value != Sum(2).value


# Generated at 2022-06-24 00:37:44.733349
# Unit test for method concat of class Max
def test_Max_concat():
    # Prepare test data
    s: Max = Max(3)
    other: Max = Max(4)
    # Run test method
    result = s.concat(other)
    # Check results
    assert result == Max(4)
    assert result.fold(int) == 4


# Generated at 2022-06-24 00:37:47.748179
# Unit test for method concat of class Max
def test_Max_concat():
    m1 = Max(1)
    m2 = Max(4)
    m2.concat(m1)
    assert(m2.value == 4)


# Generated at 2022-06-24 00:37:49.244690
# Unit test for constructor of class First
def test_First():
    assert First("first").value == "first"
    assert Last("last").value == "last"


# Generated at 2022-06-24 00:37:57.368265
# Unit test for method concat of class Map
def test_Map_concat():
    # Given
    map1 = Map({
        'x': Sum(10),
        'y': Sum(20),
        'z': First('hello'),
        'u': All(True),
        'i': Last('world'),
        'o': One(True),
    })
    map2 = Map({
        'x': Sum(15),
        'y': Sum(19),
        'z': Last('hello'),
        'u': First('hello'),
        'i': All(True),
        'o': One(True),
    })

    # When
    result = map1.concat(map2)

    # Then

# Generated at 2022-06-24 00:38:00.107118
# Unit test for constructor of class First
def test_First():
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First(None)) == 'Fist[value=None]'
    assert str(First('a')) == 'Fist[value=a]'



# Generated at 2022-06-24 00:38:07.613197
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(None).concat(First(None)) == First(None)


# Generated at 2022-06-24 00:38:08.477025
# Unit test for constructor of class Min
def test_Min():
    assert Min(5).value == 5


# Generated at 2022-06-24 00:38:10.100058
# Unit test for method __str__ of class One
def test_One___str__():
    assert One('a').__str__() == 'One[value=a]'


# Generated at 2022-06-24 00:38:12.128745
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup.neutral() == Semigroup(Semigroup.neutral_element)



# Generated at 2022-06-24 00:38:13.741375
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)



# Generated at 2022-06-24 00:38:15.394179
# Unit test for method __str__ of class All
def test_All___str__():
    x = All(True)

    assert str(x) == "All[value=True]"


# Generated at 2022-06-24 00:38:19.784485
# Unit test for method concat of class All
def test_All_concat():
    all_semigroup = All(True).concat(All(True))
    assert all_semigroup.value is True
    assert All(False).concat(All(True)).value is False



# Generated at 2022-06-24 00:38:22.074412
# Unit test for constructor of class First
def test_First():
    obj1 = First(1)
    obj2 = First(2)
    assert obj1.value == 1
    obj1.concat(obj2)


# Generated at 2022-06-24 00:38:23.389723
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-24 00:38:31.601255
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    Unit test for constructor of all classes Semigroup.
    """

    assert Sum(123).value == 123
    assert All(True).value == True
    assert All(False).value == False
    assert Last(123).value == 123
    assert Last('abc').value == 'abc'
    assert First(123).value == 123
    assert First('abc').value == 'abc'
    assert Map({'test': Sum(1)}).value == {'test': Sum(1)}
    assert Max(123).value == 123
    assert Min(123).value == 123
    print('PASSED ALL TESTS')

test_Semigroup()

print('END OF LINE')

# Generated at 2022-06-24 00:38:37.739064
# Unit test for method concat of class Map
def test_Map_concat():
    map_obj = Map({'a': Map({'b': Last(1), 'd': Max(1)}), 'c': Min(2)})
    map_obj2 = Map({'a': Map({'b': Last(2), 'd': Max(5)}), 'c': Min(1)})
    assert map_obj.concat(map_obj2) == \
        Map({'a': Map({'b': Last(2), 'd': Max(5)}), 'c': Min(1)})

# Generated at 2022-06-24 00:38:39.269766
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-24 00:38:44.324418
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup('1') == Semigroup('1')
    assert not Semigroup('1') == Semigroup('2')
    assert Semigroup('2') == Semigroup('2')
    assert not Semigroup('3') == Semigroup('2')
    assert not Semigroup(2) == Semigroup(3)
    assert Semigroup(2) == Semigroup(2)
    assert not Semigroup(3) == Semigroup(2)


# Generated at 2022-06-24 00:38:49.401299
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(2)).value == 4
    assert Sum(1).concat(Sum(2)).value == 3
    assert Sum(2).concat(Sum(1)).value == 3
    assert Sum(1).concat(Sum(1)).value == 2


# Generated at 2022-06-24 00:38:50.958873
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-24 00:38:59.442981
# Unit test for method concat of class Map
def test_Map_concat():
    m = Map({})
    assert {} == m.concat(m).value
    assert {} == m.concat(m.neutral()).value
    assert {} == m.neutral().concat(m).value
    assert {} == m.neutral().concat(m.neutral()).value # pragma: no cover

    m = Map({"a": All(True), 'b': All(False), 'c': One(True)})
    assert {'a': All(True), 'b': All(False), 'c': One(True)} == m.concat(m).value
    assert {'a': All(True), 'b': All(False), 'c': One(True)} == m.concat(m.neutral()).value

# Generated at 2022-06-24 00:39:05.825450
# Unit test for method concat of class One
def test_One_concat():  # pragma: no cover
    """
    :return: tests result
    :rtype: bool
    """
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)



# Generated at 2022-06-24 00:39:16.326512
# Unit test for method concat of class Map
def test_Map_concat():
    """
    Method concat of class Map
    """
    concat1 = Map({1: Sum(2), 2: Sum(3)}).concat(
        Map({1: Sum(3), 2: Sum(6)})
    )
    assert concat1.value == {1: Sum(5), 2: Sum(9)}

    concat2 = Map({1: Sum(3), 2: Sum(3)}).concat(
        Map({1: Sum(3), 2: Sum(3)})
    )
    assert concat2.value == {1: Sum(6), 2: Sum(6)}

    concat3 = Map({1: Sum(3), 2: Sum(3)}).concat(Map({}))
    assert concat3.value == {1: Sum(3), 2: Sum(3)}

    concat

# Generated at 2022-06-24 00:39:22.392065
# Unit test for constructor of class Map

# Generated at 2022-06-24 00:39:23.938193
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)



# Generated at 2022-06-24 00:39:25.400616
# Unit test for constructor of class One
def test_One():  # pragma: no cover
    assert One(True) == One(True)

# Generated at 2022-06-24 00:39:26.604403
# Unit test for method __str__ of class All
def test_All___str__():
    a = All(2)
    assert str(a) == 'All[value=2]'


# Generated at 2022-06-24 00:39:30.125142
# Unit test for method concat of class Last
def test_Last_concat():
    x = Last('a')
    y = Last('b')
    z = x.concat(y)
    assert z.value == 'b', "Last concat method is not correct!"
    print('Passed!')

test_Last_concat()

# Generated at 2022-06-24 00:39:32.232457
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(3).concat(Sum(4)) == Sum(7)


# Generated at 2022-06-24 00:39:34.774468
# Unit test for constructor of class Map
def test_Map():
    try:
        Map({'key1': Sum(1), 'key2': Sum(2)})
    except:
        return False

    try:
        Map({'key1': Sum(1), 'key2': All(True)})
    except:
        return False

    return True


# Generated at 2022-06-24 00:39:35.636605
# Unit test for method __str__ of class Last
def test_Last___str__():
    a = Last(1)
    assert a.__str__() == 'Last[value=1]'

# Generated at 2022-06-24 00:39:37.224127
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)).value == False, "Failure to concat"

# Generated at 2022-06-24 00:39:42.583389
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)
    assert One(False) != One(True)

    assert isinstance(One(True), One)
    assert isinstance(One(False), One)
    assert isinstance(One(1), One)
    assert isinstance(One(0), One)

test_One()


# Generated at 2022-06-24 00:39:44.102648
# Unit test for constructor of class Min
def test_Min():  # pragma: no cover
    assert Min(20).value == 20


# Generated at 2022-06-24 00:39:46.114581
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(4)) == Min(4)



# Generated at 2022-06-24 00:39:50.534181
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)



# Generated at 2022-06-24 00:39:56.276831
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1
    assert Last('foo').value == 'foo'
    assert Last(True).value is True
    assert Last([1, 2, 3]).value == [1, 2, 3]
    assert Last({'a': 1, 'b': 2}).value == {'a': 1, 'b': 2}

# Generated at 2022-06-24 00:39:57.980751
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).concat(One(2)) == One(1).value or One(2).value



# Generated at 2022-06-24 00:39:58.832935
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(0)) == 'Max[value=0]'



# Generated at 2022-06-24 00:40:02.520503
# Unit test for method concat of class Last
def test_Last_concat():
    # Arrange
    x = Last(10)
    y = Last(20)
    expected = 20

    # Act
    actual = x.concat(y)

    # Assert
    assert actual.value == expected

# Generated at 2022-06-24 00:40:03.228163
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)



# Generated at 2022-06-24 00:40:05.479467
# Unit test for constructor of class Min
def test_Min():
    """
    The constructor of the class Min
    """
    x = Min(4)
    y = Min(5)
    assert x.value == 4 and y.value == 5



# Generated at 2022-06-24 00:40:06.368971
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-24 00:40:08.086712
# Unit test for method concat of class Sum
def test_Sum_concat():
    a = Sum(2)
    b = Sum(2)
    assert a.concat(b) == Sum(4)



# Generated at 2022-06-24 00:40:09.883084
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(2) == Sum(2)
    assert Sum(1) != Sum(2)


# Generated at 2022-06-24 00:40:12.593725
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == "Sum[value=1]"
    assert str(Sum(2)) == "Sum[value=2]"


# Generated at 2022-06-24 00:40:14.941849
# Unit test for method concat of class Map
def test_Map_concat():
    d = Map({'a': Map({'b': Sum(1)})})
    e = Map({'a': Map({'b': Sum(2)})})
    assert d.concat(e) == Map({'a': Map({'b': Sum(3)})})


# Generated at 2022-06-24 00:40:16.861044
# Unit test for constructor of class All
def test_All(): # pragma: no cover
    assert All(True) == All(True)
    assert All(False) == All(False)


# Generated at 2022-06-24 00:40:18.991493
# Unit test for constructor of class Max
def test_Max():
    assert Max(2) == Max(2)
    assert Max(2) != Max(3)

test_Max()


# Generated at 2022-06-24 00:40:19.958966
# Unit test for constructor of class Min
def test_Min():
    assert Min(11) == Min(11)
    assert Min(11).value == 11


# Generated at 2022-06-24 00:40:25.588434
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
    assert All(False).concat(All(False)).value == False
    assert All(True).concat(All(True)).value == True


# Generated at 2022-06-24 00:40:34.902109
# Unit test for method __str__ of class Map
def test_Map___str__():
    actual = Map({
        "a": Sum(1),
        "b": All(True),
        "c": One(True),
        "d": First("a"),
        "e": Last("b"),
        "f": Max(1),
        "g": Min(1)
    })
    expected = 'Map[value={\'a\': Sum[value=1], \'b\': All[value=True], \'c\': One[value=True], \'d\': Fist[value=a], \'e\': Last[value=b], \'f\': Max[value=1], \'g\': Min[value=1]}]'
    assert str(actual) == expected


# Generated at 2022-06-24 00:40:36.076206
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(7)) == "Sum[value=7]"

# Generated at 2022-06-24 00:40:37.417843
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)


# Generated at 2022-06-24 00:40:38.346349
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(12).value == 12



# Generated at 2022-06-24 00:40:41.543134
# Unit test for method concat of class One
def test_One_concat():
    val_1 = One(True)
    val_2 = One(False)
    val_3 = One(False)

    assert One(True).concat(val_1).concat(val_2) == One(True)
    assert One(False).concat(val_2).concat(val_3) == One(False)



# Generated at 2022-06-24 00:40:45.701857
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(10).concat(Max(20)) == Max(20)
    assert Max(10).concat(Max(10)) == Max(10)
    assert Max(20).concat(Max(10)) == Max(20)


# Generated at 2022-06-24 00:40:47.354450
# Unit test for method __str__ of class All
def test_All___str__():
    result = All(False)
    assert result.__str__() == 'All[value=False]'


# Generated at 2022-06-24 00:40:55.826976
# Unit test for method concat of class Map
def test_Map_concat():
    _a = Map({
        'a': 3,
        'b': 4,
        'c': 2,
        'd': 'x',
        'e': 'y',
        'f': 'z'
    })
    _b = Map({
        'a': None,
        'b': 4,
        'c': '2',
        'd': 'x',
        'e': 'y',
        'f': 'z'
    })
    expect = Map({
        'a': Sum(3),
        'b': Sum(8),
        'c': All(True),
        'd': Last('x'),
        'e': Last('y'),
        'f': Last('z')
    })
    actual = _a.concat(_b)

# Generated at 2022-06-24 00:40:59.797248
# Unit test for method __str__ of class Min
def test_Min___str__():
    """
    Unit test for method __str__ of class Min
    """

    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-24 00:41:04.076848
# Unit test for method concat of class Last
def test_Last_concat():
    last = Last(0)
    result = last.concat(Last(2))
    # check result
    print(result)
    result_expected = Last(2)
    assert result == result_expected
    print(result)
    print(result_expected)
    print('::: TEST for Last class :::')


# Generated at 2022-06-24 00:41:06.231808
# Unit test for constructor of class One
def test_One():
    assert One(True)
    assert One(1)
    assert One(False)
    assert One(None)


# Generated at 2022-06-24 00:41:07.588237
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(5)) == "Max[value=5]"


# Generated at 2022-06-24 00:41:08.838713
# Unit test for constructor of class Map
def test_Map():
    assert Map({1: Sum(1)}).value == {1: Sum(1)}



# Generated at 2022-06-24 00:41:09.876622
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'



# Generated at 2022-06-24 00:41:12.508541
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-24 00:41:14.145050
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(2)) == 'Fist[value=2]'


# Generated at 2022-06-24 00:41:16.840701
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(2).fold(lambda x: x * 2) == 4


Semigroup.__new__.__defaults__ = (None,)  # type: ignore



# Generated at 2022-06-24 00:41:18.393062
# Unit test for constructor of class All
def test_All():
    r = All(True)
    assert r.value == True



# Generated at 2022-06-24 00:41:28.867801
# Unit test for constructor of class Max
def test_Max():
    print("Unit test for constructor of class Max")
    # Test 1.1:
    print("Test 1.1:", end=' ')
    try:
        assert Max(-1) == Max(-1)
        print("Passed")
    except AssertionError:
        print("Failed")
    except Exception as e:
        print("Failed. Error: {}".format(e))
    # Test 1.2:
    print("Test 1.2:", end=' ')
    try:
        assert Max(0) == Max(0)
        print("Passed")
    except AssertionError:
        print("Failed")
    except Exception as e:
        print("Failed. Error: {}".format(e))
    # Test 1.3:
    print("Test 1.3:", end=' ')
   

# Generated at 2022-06-24 00:41:30.148641
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-24 00:41:33.001252
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert isinstance(Semigroup(12), Semigroup)
    assert isinstance(Semigroup(12), Semigroup)
    assert isinstance(Semigroup(), Semigroup)



# Generated at 2022-06-24 00:41:40.828140
# Unit test for method concat of class One
def test_One_concat():
    a = One(False)
    b = One(False)

    assert a.concat(b) == One(False)

    a = One(False)
    b = One(True)

    assert a.concat(b) == One(True)

    a = One(True)
    b = One(False)

    assert a.concat(b) == One(True)

    a = One(True)
    b = One(True)

    assert a.concat(b) == One(True)
