

# Generated at 2022-06-24 00:31:37.831770
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    print('test_First_concat success')

if __name__ == '__main__':
    test_First_concat()

# Generated at 2022-06-24 00:31:39.513653
# Unit test for method __str__ of class First
def test_First___str__():
    value = 'ABC'
    assert str(First(value)) == 'Fist[value=%s]' % value


# Generated at 2022-06-24 00:31:43.291046
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    fold = Semigroup(5).fold
    assert fold(lambda x: x + 1) == 6
    assert fold(lambda x: x * 2) == 10



# Generated at 2022-06-24 00:31:44.392889
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)



# Generated at 2022-06-24 00:31:46.423876
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-24 00:31:49.560230
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(1)).value == 2


# Generated at 2022-06-24 00:31:54.723290
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:31:56.261561
# Unit test for constructor of class Semigroup
def test_Semigroup():
    s = Semigroup(12)
    assert s.value == 12

# Generated at 2022-06-24 00:31:58.253745
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First("a")) == First(1)


# Generated at 2022-06-24 00:32:04.106909
# Unit test for method concat of class Map
def test_Map_concat():
    # given
    concated_map_1 = Map({'is_admin': All(True), 'email': First('john@example.com')})
    concated_map_2 = Map({'is_admin': All(True), 'email': First('admin@example.com')})

    # when
    result = concated_map_1.concat(concated_map_2)

    # then
    expected = Map({'is_admin': All(True), 'email': First('john@example.com')})
    assert result == expected

# Generated at 2022-06-24 00:32:05.144401
# Unit test for method __str__ of class Last
def test_Last___str__():
    last = Last(3)
    assert(str(last) == "Last[value=3]")



# Generated at 2022-06-24 00:32:06.574089
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert Min(2).__str__() == 'Min[value=2]'



# Generated at 2022-06-24 00:32:09.913675
# Unit test for constructor of class Max
def test_Max():  # pragma: no cover
    assert Max(1) == Max(1)
    assert Max(1).value == 1
    assert Max(1).fold(lambda x: x + 1) == 2


# Generated at 2022-06-24 00:32:11.281559
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)

# Generated at 2022-06-24 00:32:13.613161
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(10)) == 'Min[value=10]'



# Generated at 2022-06-24 00:32:19.401040
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():  # pragma: no cover
    assert Semigroup(1).__eq__(Semigroup(1)) is True
    assert Semigroup(1) == Semigroup(1) is True
    assert Semigroup(1).__eq__(Semigroup(2)) is False



# Generated at 2022-06-24 00:32:20.910163
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == "Min[value=1]"



# Generated at 2022-06-24 00:32:23.302819
# Unit test for constructor of class Min
def test_Min():  # pragma: no cover
    # Given
    a = Min(3)

    # Then
    assert a.value == 3


# Generated at 2022-06-24 00:32:34.372753
# Unit test for method concat of class Map
def test_Map_concat():
    test_obj = Map({1: Sum(123), 2: All(True)})
    test_obj2 = Map({1: Sum(456), 2: All(False)})

    test_obj3 = test_obj.concat(test_obj2)

    assert isinstance(test_obj3, Map)
    assert test_obj3.value[1] == Sum(579)
    assert test_obj3.value[2] == All(False)

    test_obj4 = Map({1: First(123), 2: Last(True)})
    test_obj5 = Map({1: First(456), 2: Last(False)})

    test_obj6 = test_obj4.concat(test_obj5)

    assert isinstance(test_obj6, Map)
    assert test_obj6.value[1] == First

# Generated at 2022-06-24 00:32:38.228032
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == "Last[value=1]"



# Generated at 2022-06-24 00:32:48.473511
# Unit test for constructor of class Min
def test_Min():
    min_1 = Min(2)
    min_2 = Min(1)

    assert min_1 == min_1.concat(Min.neutral())
    assert min_2 == min_2.concat(Min.neutral())

    assert min_2 == min_1.concat(min_2)
    assert min_1 == min_2.concat(min_1)

    assert min_1.concat(min_2.concat(min_1)) == min_1

    assert min_1.concat(min_2.concat(Min(float("inf")))) == min_2

    min_3 = Min(float("inf"))
    min_4 = Min(float("inf"))
    assert min_3 == min_4
    assert min_3.concat(min_4) == min_3


# Generated at 2022-06-24 00:32:50.525614
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    semigroup = Semigroup(34)
    other_semigroup = Semigroup(34)

    assert semigroup == other_semigroup



# Generated at 2022-06-24 00:32:53.376934
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value is True
    assert All(True).concat(All(False)).value is False
    assert All(False).concat(All(True)).value is False



# Generated at 2022-06-24 00:32:54.779617
# Unit test for constructor of class One
def test_One():
    assert One(5) == One(5)
    assert One(5) != One(6)



# Generated at 2022-06-24 00:33:01.446166
# Unit test for method concat of class All
def test_All_concat():
    """
    Create two semigroups and test if concat method return correct boolean value under logical conjunction
    """
    assert All(True).concat(All(False)).value == False
    assert All(True).concat(All(True)).value == True
    assert All(False).concat(All(False)).value == False


# Generated at 2022-06-24 00:33:07.536950
# Unit test for method concat of class Min
def test_Min_concat():
    """
    >>> m1 = Min(1)
    >>> m2 = Min(2)
    >>> m1 > m2
    False
    >>> m1.concat(m2) == m1
    True
    >>> m1.concat(m2) == m2
    False
    >>> m2.concat(m1) == m1
    False
    >>> m2.concat(m1) == m2
    True
    >>> m2.concat(m2) == m2
    True
    """


# Generated at 2022-06-24 00:33:08.738020
# Unit test for constructor of class Map
def test_Map():
    with raises(TypeError):
        Map(Sum(8))



# Generated at 2022-06-24 00:33:11.130778
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    u = One('test')
    assert str(u) == "One[value=test]"


# Generated at 2022-06-24 00:33:14.358517
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)



# Generated at 2022-06-24 00:33:15.494998
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == "Sum[value=1]"


# Generated at 2022-06-24 00:33:18.500783
# Unit test for constructor of class First
def test_First():
    f = First
    # Create new First
    f = f('a')
    # Check value
    assert f.value == 'a'
    # Check output of function str
    assert str(f) == 'Fist[value=a]'
    # Check output of function repr
    assert repr(f) == str(f)



# Generated at 2022-06-24 00:33:21.784228
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(5)) == 'Min[value=5]'

# Unit tests for method fold() of class Min

# Generated at 2022-06-24 00:33:23.901606
# Unit test for method __str__ of class Min
def test_Min___str__():
    # Arrange
    SUT = Min(4)

    # Act
    result = SUT.__str__()

    # Assert
    assert result == 'Min[value=4]'



# Generated at 2022-06-24 00:33:28.710833
# Unit test for method concat of class One
def test_One_concat():  # pragma: no cover
    assert One(False).concat(One(False)).value == False
    assert One(False).concat(One(True)).value == True
    assert One(True).concat(One(False)).value == True
    assert One(True).concat(One(True)).value == True



# Generated at 2022-06-24 00:33:31.432493
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(3)) == Sum(5)


# Generated at 2022-06-24 00:33:35.239367
# Unit test for method __str__ of class Map
def test_Map___str__():
    map1 = Map({'test': Sum(1), 'test2': Sum(2)})
    map2 = Map({'test': Sum(1), 'test2': Sum(2)})

    assert str(map1) == str(map2)


# Generated at 2022-06-24 00:33:44.944788
# Unit test for method concat of class Map
def test_Map_concat():
    mapper = Map({'age': Sum(4), 'height': All('1m10')})
    mapper2 = Map({'age': Sum(3), 'height': All('2m22')})
    mapper3 = mapper.concat(mapper2)
    assert mapper3.value['age'].value == 7
    assert mapper3.value['height'].value == True
    assert mapper2 == Map({'age': Sum(3), 'height': All('2m22')})
    assert mapper == Map({'age': Sum(4), 'height': All('1m10')})
    mapper3 = mapper3.concat(mapper)
    assert mapper3.value['age'].value == 11
    assert mapper3.value['height'].value == True
    mapper3 = mapper

# Generated at 2022-06-24 00:33:52.667402
# Unit test for constructor of class Map
def test_Map():
    with pytest.raises(TypeError):
        Map(1)
    with pytest.raises(TypeError):
        Map('1')
    with pytest.raises(TypeError):
        Map([])
    with pytest.raises(AttributeError):
        Map(None)
    # Test for correct value argument of constructor
    assert str(Map({'a': Sum(1)})) == 'Map[value={\'a\': Sum[value=1]}]'
    assert str(Map({})) == 'Map[value={}]'


# Generated at 2022-06-24 00:34:00.741572
# Unit test for method concat of class Map
def test_Map_concat():
    try:
        map1 = Map({'a': Sum(1), 'b': Sum(2)})
        map2 = Map({'a': Sum(2), 'b': Sum(1)})
        map_result = Map({'a': Sum(3), 'b': Sum(3)})
        assert map1.concat(map2) == map_result
    except AssertionError:
        print("test_Map_concat raise AssertionError.")

if __name__ == '__main__':
    test_Map_concat()

# Generated at 2022-06-24 00:34:06.557579
# Unit test for constructor of class Min
def test_Min():  # pragma: no cover
    assert Min(4) == Min(4)
    assert Min(-4) == Min(-4)
    assert Min(4) != Min(-4)
    assert not Min(0)


# Generated at 2022-06-24 00:34:17.763678
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x * 3) == 3
    assert All(True).fold(lambda x: not x) == False
    assert One(True).fold(lambda x: not x) == True
    assert First(1).fold(lambda x: x * 3) == 1
    assert Last(1).fold(lambda x: x * 3) == 1
    assert Map({"a": Sum(3), "b": Sum(5)}).fold(lambda x: {
        key: value.fold(lambda x: x * 3) for key, value in x.items()
    }) == {"a": 9, "b": 15}
    assert Max(5).fold(lambda x: x * 3) == 15
    assert Min(5).fold(lambda x: x * 3) == 5


# Generated at 2022-06-24 00:34:18.997697
# Unit test for constructor of class Min
def test_Min():
    t = Min(10)
    assert t == Min(10)


# Generated at 2022-06-24 00:34:22.126128
# Unit test for constructor of class Last
def test_Last():
    assert Last(5) == Last(5)
    assert Last(5) is not Last(5)
    assert Last(5).concat(Last(8)) == Last(8)
    assert Last(5).concat(Last('a')).concat(Last(8)) == Last(8)



# Generated at 2022-06-24 00:34:25.775715
# Unit test for constructor of class Sum
def test_Sum():
    value1 = Sum(2)
    value2 = Sum(2)
    value3 = Sum(40)
    assert value1 == value2
    assert value1 != value3


# Generated at 2022-06-24 00:34:28.955098
# Unit test for method __str__ of class One
def test_One___str__():
  assert str(One(True)) == 'One[value=True]'
  assert str(One(False)) == 'One[value=False]'
  assert str(One(1)) == 'One[value=1]'
  assert str(One(0)) == 'One[value=0]'


# Generated at 2022-06-24 00:34:30.212565
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum = Sum(10)
    assert str(sum) == 'Sum[value=10]', "Test __str__ of class Sum"


# Generated at 2022-06-24 00:34:31.876858
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert Semigroup(10) == Semigroup(10)
    assert Semigroup(10) != Sum(10)
    assert Semigroup(10) != First(10)


# Generated at 2022-06-24 00:34:34.172932
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({0: Sum(1), 1: Sum(2)}).concat(Map({0: Sum(3), 1: Sum(4)})) == Map(
        {0: Sum(4), 1: Sum(6)}
    )



# Generated at 2022-06-24 00:34:36.538122
# Unit test for method __str__ of class First
def test_First___str__():  # type: ignore
    assert (
        str(First(1)) == 'Fist[value=1]'
    ), "First must return string with value"


# Generated at 2022-06-24 00:34:38.850460
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(2) == Sum(2)
    assert Sum(2).value == 2
    assert Sum(2).fold(lambda x: 2 * x) == 4


# Generated at 2022-06-24 00:34:45.278827
# Unit test for method concat of class Map
def test_Map_concat():
    """
    :returns: Test success
    :rtype: bool
    """
    test = Map({'id': Sum(10), 'title': First('hello')})
    second_test = Map({'id': Sum(10), 'title': First('hello')})
    assert test.concat(second_test) == Map({'id': Sum(20), 'title': First('hello')})
    return True


# Generated at 2022-06-24 00:34:48.431031
# Unit test for constructor of class All
def test_All():
    assert All(False) == All(False)
    assert All(True) == All(True)
    assert All(True).value == True
    assert All(True).fold(lambda value: value) == True


# Generated at 2022-06-24 00:34:50.213564
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(5) == Sum(5)
    assert Sum(5) != Sum(10)



# Generated at 2022-06-24 00:34:53.489238
# Unit test for constructor of class Map
def test_Map():
    test_map = Map({'name': Sum(3), 'age': Max(1)})
    assert test_map.value == {'name': Sum(3), 'age': Max(1)}


# Generated at 2022-06-24 00:34:56.141257
# Unit test for constructor of class Map
def test_Map():
    """
    Test for constructor of class Map
    """
    assert Map({1: Sum(1)}).value == {1: Sum(1)}


# Generated at 2022-06-24 00:34:57.149828
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-24 00:34:58.460229
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(4).value == 4
    assert Sum(4) == Sum(4)



# Generated at 2022-06-24 00:35:00.412033
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-24 00:35:02.505748
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert str(Last(3)) == 'Last[value=3]'



# Generated at 2022-06-24 00:35:05.821608
# Unit test for constructor of class Map
def test_Map():
    # test if it returns Map class
    assert Map({'a': Sum(1)}).__class__ == Map
    # test if value is passed correctly
    assert Map({'a': Sum(1)}).value == {'a': Sum(1)}


# Generated at 2022-06-24 00:35:07.653316
# Unit test for constructor of class Max
def test_Max():
    assert Max(10).fold(lambda x: x) == 10  # pragma: no cover


# Generated at 2022-06-24 00:35:09.391849
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) is not Last(1)



# Generated at 2022-06-24 00:35:12.061577
# Unit test for method __str__ of class All
def test_All___str__():
    # Arrange
    semigroup = All(True)

    # Act
    str(semigroup)

    # Assert
    assert semigroup.__str__() == 'All[value=True]'

# Generated at 2022-06-24 00:35:13.578409
# Unit test for method __str__ of class First
def test_First___str__():
    semigroup = First('foo')
    assert str(semigroup) == 'Fist[value=foo]'



# Generated at 2022-06-24 00:35:18.509244
# Unit test for method concat of class One
def test_One_concat():
    from functools import reduce
    from operator import or_

    def run_semigroup(fn, value):
        return value.concat(fn).value

    def run_reduce(fn, value):
        return reduce(fn, value)

    one = One(1)
    zero = One(0)

    assert run_semigroup(one, zero) == run_reduce(or_, [0, 1])
    assert run_semigroup(zero, one) == run_reduce(or_, [0, 1])



# Generated at 2022-06-24 00:35:22.330264
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)


# Generated at 2022-06-24 00:35:24.719101
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)


# Generated at 2022-06-24 00:35:27.680938
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(5).concat(Min(3)) == Min(3)
    assert Min(5).concat(Min(5)) == Min(5)
    print("test_Min_concat() - Done")

test_Min_concat()



# Generated at 2022-06-24 00:35:29.101716
# Unit test for constructor of class Min
def test_Min():
    semigroup = Min(3)
    assert semigroup.value == 3

# Generated at 2022-06-24 00:35:30.584010
# Unit test for method __str__ of class Min
def test_Min___str__():
    result = str(Min(5))
    assert result == 'Min[value=5]'



# Generated at 2022-06-24 00:35:31.719100
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)


# Generated at 2022-06-24 00:35:36.895026
# Unit test for constructor of class Map
def test_Map():
    m = Map({'a': Sum(1), 'b': Sum(2)})
    assert m.value == {'a': 1, 'b': 2}, "Should be {'a': 1, 'b': 2}"
    print(m)
    m = Map(True)
    assert m.value == True, "Should be True"
    print(m)
    m = Map(1)
    assert m.value == 1, "Should be 1"
    print(m)
    m = Map('test...test')
    assert m.value == 'test...test', "Should be test...test"
    print(m)
    m = Map(['a', 'b', 'c', 'd'])

# Generated at 2022-06-24 00:35:40.480399
# Unit test for method concat of class All
def test_All_concat():
    semigroup = All(True)

    assert semigroup.concat(All(True)).value == True
    assert semigroup.concat(All(False)).value == False


# Generated at 2022-06-24 00:35:44.050691
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: Sum(1), 2: Sum(2)})) == 'Map[value={1: Sum[value=1], 2: Sum[value=2]}]'



# Generated at 2022-06-24 00:35:47.096905
# Unit test for constructor of class Max
def test_Max():
    """
    Test for constructor of class Max
    """
    assert Max(1).value == 1
    assert Max(2).value == 2
    assert Max(3).value == 3


# Generated at 2022-06-24 00:35:50.286200
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-24 00:35:52.964995
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert Map({1: First(2), 3: First(4)}).__str__() == 'Map[value={1: First[value=2], 3: First[value=4]}]'


# Generated at 2022-06-24 00:35:54.218624
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert( str(Max(42)) == "Max[value=42]" )


# Generated at 2022-06-24 00:35:59.161681
# Unit test for constructor of class Min
def test_Min():
    assert not Min(1) == 1
    assert Min(1) == Min(1)
    assert Min(1).fold(lambda x: x) == 1
    assert isinstance(Min(1).concat(Min(2)), Min)
    assert Min(1).concat(Min(2)).fold(lambda x: x) == 1
    assert isinstance(Min.neutral(), Min)
    assert Min.neutral().fold(lambda x: x) == float("inf")


# Generated at 2022-06-24 00:36:01.339135
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(2).fold(lambda x: x ** 2) == 4
    assert Semigroup('abcd').fold(lambda x: x[::-1]) == 'dcba'



# Generated at 2022-06-24 00:36:11.953936
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    Unit test for method __eq__ of class Semigroup
    """

    # Test with class Min
    min_1 = Min(1)
    assert min_1 == Min(1)

    # Test with class Max
    max_1 = Max(1)
    assert max_1 == Max(1)

    # Test with class First
    first_1 = First(1)
    assert first_1 == First(1)

    # Test with class Last
    last_1 = Last(1)
    assert last_1 == Last(1)

    # Test with class All
    all_1 = All(1)
    assert all_1 == All(1)

    # Test with class One
    one_1 = One(1)
    assert one_1 == One(1)

    # Test with class Sum

# Generated at 2022-06-24 00:36:15.297621
# Unit test for method concat of class Max
def test_Max_concat():  # pragma: no cover
    assert Max(1).concat(Max(2)) == Max(2)



# Generated at 2022-06-24 00:36:17.999579
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    # Setup
    s = Semigroup(1)
    s2 = Semigroup(1)
    s3 = Semigroup(2)
    # Exercise
    # Verify
    assert s == s2
    assert not s == s3


# Generated at 2022-06-24 00:36:21.452778
# Unit test for method concat of class All
def test_All_concat():
    value_1 = All(True)
    value_2 = All(False)
    expected_1 = All(False)
    expected_2 = All(True)
    result_1 = value_1.concat(value_2)
    result_2 = value_2.concat(value_1)
    assert result_1 == expected_1
    assert result_2 == expected_2

# Generated at 2022-06-24 00:36:23.225843
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]', '"__str__" of class "Sum" not works'


# Generated at 2022-06-24 00:36:24.342597
# Unit test for constructor of class Last
def test_Last():
    last = Last('foo')
    assert last.value == 'foo'



# Generated at 2022-06-24 00:36:26.820352
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_01 = Sum(3)
    sum_02 = Sum(5)
    assert sum_01.concat(sum_02) == Sum(8)


# Generated at 2022-06-24 00:36:28.212806
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == "One[value=1]"


# Generated at 2022-06-24 00:36:30.203417
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert str(Max(10)) == 'Max[value=10]'


# Generated at 2022-06-24 00:36:40.307034
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({1: First("a"), 2: First("b")}).concat(Map({1: First("c"), 2: First("d")})) == Map({1: First("a"), 2: First("b")})
    assert Map({1: Last("a"), 2: First("b")}).concat(Map({1: Last("c"), 2: First("d")})) == Map({1: Last("c"), 2: First("b")})
    assert Map({1: Last("a"), 2: Last("b")}).concat(Map({1: Last("c"), 2: Last("d")})) == Map({1: Last("c"), 2: Last("d")})
    assert Map({1: All(True), 2: All(False)}).concat(Map({1: All(True), 2: All(False)})) == Map

# Generated at 2022-06-24 00:36:43.559467
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(2).concat(Max(3)) == Max(3)
    assert Max(3).concat(Max(3)) == Max(3)
    assert Max(-3).concat(Max(3)) == Max(3)

# Generated at 2022-06-24 00:36:44.512384
# Unit test for constructor of class Last
def test_Last():
    assert Last(3).value == 3


# Generated at 2022-06-24 00:36:47.046033
# Unit test for constructor of class Max
def test_Max():
    max_semigroup = Max(3)
    assert max_semigroup == Max(3)
    assert max_semigroup.value == 3


# Generated at 2022-06-24 00:36:49.918176
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:36:55.216966
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True), 'One should return first truthy value'
    assert One(True).concat(One(False)) == One(True), 'One should return first truthy value'
    assert One(False).concat(One(False)) == One(False), 'One should return last falsy value'
    assert One(False).concat(One(True)) == One(True), 'One should return first truthy value'



# Generated at 2022-06-24 00:36:59.045079
# Unit test for method __str__ of class All
def test_All___str__():
    expected = 'All[value=False]'
    actual = str(All(False))
    assert actual == expected


# Generated at 2022-06-24 00:37:01.446856
# Unit test for method concat of class Max
def test_Max_concat():
    semigroup = Max(1)
    assert semigroup.concat(Max(2)) == Max(2)



# Generated at 2022-06-24 00:37:02.636774
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(10).concat(Last(20)) == Last(20)

# Generated at 2022-06-24 00:37:04.117930
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(3).value == 3
    assert Semigroup(3) != Semigroup(4)


# Generated at 2022-06-24 00:37:07.267093
# Unit test for constructor of class One
def test_One():
    one = One(True)
    assert one.value == True
    assert one.concat(one).value == True
    assert one.concat(One(False)).value == False
    assert one.concat(One(True)).value == True


# Generated at 2022-06-24 00:37:08.978603
# Unit test for constructor of class Min
def test_Min():
    assert Min(5).value == 5

# Generated at 2022-06-24 00:37:11.681759
# Unit test for constructor of class Map
def test_Map():
    assert isinstance(Map({"a": All(True), "b": One(False)}), Map)
    assert Map({"a": All(True), "b": One(False)}).value == {"a": All(True), "b": One(False)}


# Generated at 2022-06-24 00:37:14.432727
# Unit test for method __str__ of class First
def test_First___str__():

    semigroup = First(1)
    assert str(semigroup) == 'Fist[value=1]'



# Generated at 2022-06-24 00:37:15.910950
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)).fold(lambda x: x) == 1
    assert First(2).concat(First(1)).fold(lambda x: x) == 2


# Generated at 2022-06-24 00:37:16.898071
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)



# Generated at 2022-06-24 00:37:17.785711
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-24 00:37:18.853154
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-24 00:37:20.248381
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(3).concat(Sum(4)) == Sum(7)



# Generated at 2022-06-24 00:37:23.392776
# Unit test for method concat of class First
def test_First_concat():
    first = First(5)
    assert first.concat(First(5)).value == 5
    assert first.concat(First(3)).value == 5



# Generated at 2022-06-24 00:37:24.309549
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True

# Generated at 2022-06-24 00:37:26.111628
# Unit test for constructor of class Semigroup
def test_Semigroup():
    semigroup = Semigroup(0)
    assert semigroup.value == 0



# Generated at 2022-06-24 00:37:29.361378
# Unit test for constructor of class One
def test_One(): # pragma: no cover
    assert One(None) == One(None)
    assert One(1) == One(1)
    assert One(True) == One(True)
    assert One(False) == One(False)


# Generated at 2022-06-24 00:37:33.818355
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1
    assert Last(1).neutral().value == 1

# Generated at 2022-06-24 00:37:35.318487
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-24 00:37:36.925224
# Unit test for method __str__ of class First
def test_First___str__():
    expected_value = 'Fist[value=1]'
    actual_value = str(First(1))
    assert expected_value == actual_value


# Generated at 2022-06-24 00:37:48.327091
# Unit test for method __eq__ of class Semigroup

# Generated at 2022-06-24 00:37:49.472077
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(4)).value == 1


# Generated at 2022-06-24 00:37:52.887781
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'



# Generated at 2022-06-24 00:37:54.507675
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False



# Generated at 2022-06-24 00:37:58.165733
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-24 00:38:01.368725
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(0)) == 'All[value=False]'
    assert str(All(1)) == 'All[value=True]'
    assert str(All('')) == 'All[value=False]'
    assert str(All(' ')) == 'All[value=True]'



# Generated at 2022-06-24 00:38:06.640475
# Unit test for method concat of class Max
def test_Max_concat():
    a = Max(4)
    b = Max(10)
    assert a.concat(b) == Max(10)
    assert b.concat(a) == Max(10)


# Generated at 2022-06-24 00:38:08.556734
# Unit test for method concat of class Last
def test_Last_concat():
    last = Last(2)
    another_last = Last(1)

    print(last.concat(another_last))


# Generated at 2022-06-24 00:38:10.191149
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(value=3)) == 'Sum[value=3]'



# Generated at 2022-06-24 00:38:13.607755
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(0)) == 'Max[value=0]'
    assert str(Max(5)) == 'Max[value=5]'
    assert str(Max(-99)) == 'Max[value=-99]'



# Generated at 2022-06-24 00:38:19.688504
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).concat(One(2)) == One(1)  # Test concat with two values
    assert One(None).concat(One('a')) == One('a')  # Test concat with two strings
    assert One(1).concat(One(None)) == One(1)  # Test concat with two different instances
    try:
        One('a').concat(None)
    except TypeError:
        assert True
    else:
        assert False  # Test if instance of class One is None



# Generated at 2022-06-24 00:38:22.128740
# Unit test for constructor of class All
def test_All():  # pragma: no cover
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"


# Generated at 2022-06-24 00:38:24.483548
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == "One[value=True]"
    assert str(One(False)) == "One[value=False]"


# Generated at 2022-06-24 00:38:27.689891
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    assert One(True).__str__() == 'One[value=True]'
    assert One(False).__str__() == 'One[value=False]'


# Generated at 2022-06-24 00:38:32.574984
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    semigroup_1 = Max()
    assert str(semigroup_1) == "Max[value=-inf]"
    semigroup_2 = Max(999)
    assert str(semigroup_2) == "Max[value=999]"
    semigroup_3 = Max(-999)
    assert str(semigroup_3) == "Max[value=-999]"


# Generated at 2022-06-24 00:38:33.468609
# Unit test for constructor of class Last
def test_Last():
    assert Last("value") == Last("value")

# Generated at 2022-06-24 00:38:35.453548
# Unit test for constructor of class Last
def test_Last():
    result = Last(2).value
    expected = 2
    assert result == expected



# Generated at 2022-06-24 00:38:37.740307
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-24 00:38:40.443032
# Unit test for constructor of class All
def test_All():
    """
    >>> All(True) == All(True)
    True
    >>> All(False) == All(True)
    False
    """



# Generated at 2022-06-24 00:38:46.957066
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    def check_Semigroup___eq__(semigroup_1, semigroup_2, expected):
        actual = semigroup_1.__eq__(semigroup_2)
        assert actual == expected, 'Expected {} but got {}'.format(actual, expected)

    check_Semigroup___eq__(Sum(4), Sum(4), True)
    check_Semigroup___eq__(Sum(3), Sum(4), False)
    check_Semigroup___eq__(
        All(True),
        All(True)
    , True)
    check_Semigroup___eq__(
        All(False),
        All(False)
    , True)
    check_Semigroup___eq__(
        All(True),
        All(False)
    , False)

# Generated at 2022-06-24 00:38:57.624513
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert eval(str(Map({"a": Sum(1), "b": Sum(2)}))) == Map({"a": Sum(1), "b": Sum(2)})
    assert eval(str(Map({1: All(False), 2: All(True)}))) == Map({1: All(False), 2: All(True)})
    assert eval(str(Map({1: First("a"), 2: First("b")}))) == Map({1: First("a"), 2: First("b")})
    assert eval(str(Map({1: Last("a"), 2: Last("b")}))) == Map({1: Last("a"), 2: Last("b")})
    assert eval(str(Map({1: Max(1), 2: Max(2)}))) == Map({1: Max(1), 2: Max(2)})
    assert eval

# Generated at 2022-06-24 00:38:59.688770
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'fist': First('1')})) == "Map[value={'fist': Fist[value=1]}]"


# Generated at 2022-06-24 00:39:02.891985
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert repr(Last(5)) == 'Last[value=5]'


# Generated at 2022-06-24 00:39:04.580750
# Unit test for constructor of class First
def test_First():
    assert First(1).__str__() == 'Fist[value=1]'

test_First()


# Generated at 2022-06-24 00:39:06.460664
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({a: 1, b: 2})) == 'Map[value={a: 1, b: 2}]'


# Generated at 2022-06-24 00:39:08.056691
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-24 00:39:12.005474
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-24 00:39:16.568686
# Unit test for method __str__ of class All
def test_All___str__():
    """
    Property-based testing using hypothesis
    """

    @given(values=st.integers())
    @settings(max_examples=10 * 3, deadline=1000)
    def test_value(values):
        semigroup_1 = All(values)
        assert str(semigroup_1) == 'All[value={}]'.format(values)

    test_value()


# Generated at 2022-06-24 00:39:18.505710
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(False)) == 'All[value=False]'
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-24 00:39:29.651328
# Unit test for constructor of class One
def test_One():
    assert One(True).concat(One(True)).concat(One(False)) == One(False)
    assert \
        First("a").concat(First("b")).concat(First("c")) == \
        First("a")
    assert Last("a").concat(Last("b")).concat(Last("c")) == Last("c")
    assert Max(10).concat(Max(2)).concat(Max(50)) == Max(50)
    assert Min(10).concat(Min(2)).concat(Min(50)) == Min(2)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)
    assert All(True).concat(All(False)).concat(All(True)) == All(False)


# Generated at 2022-06-24 00:39:33.208435
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(8).concat(Min(9)) == Min(8)
    assert Min(8).concat(Min(3)) == Min(3)
    assert Min(9).concat(Min(8)) == Min(8)


# Generated at 2022-06-24 00:39:38.029986
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert Max(1).__str__() == 'Max[value=1]'



# Generated at 2022-06-24 00:39:39.615465
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(0) == Sum.neutral()
    assert Sum(1) != Sum.neutral()


# Generated at 2022-06-24 00:39:42.146623
# Unit test for constructor of class All
def test_All():
    all1 = All(True)
    all2 = All(False)
    assert type(all1) == All
    assert type(all2) == All


# Generated at 2022-06-24 00:39:44.058334
# Unit test for method __str__ of class All
def test_All___str__():
    all = All(True)
    assert str(all) == 'All[value=True]'


# Generated at 2022-06-24 00:39:45.727174
# Unit test for constructor of class Last
def test_Last():
    assert isinstance(Last(5), Last)



# Generated at 2022-06-24 00:39:49.618984
# Unit test for constructor of class Map
def test_Map():
    assert Map({"one": Sum(1)}).value["one"] == Sum(1)


# Generated at 2022-06-24 00:39:56.053529
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:39:57.798900
# Unit test for constructor of class Map
def test_Map():
    assert Map({"sum": Sum(1)}).fold(lambda x: 1) == 1


# Generated at 2022-06-24 00:40:00.269476
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)


# Generated at 2022-06-24 00:40:02.259532
# Unit test for constructor of class Min
def test_Min():
    min_test = Min(3)
    assert min_test.value == 3

if __name__ == '__main__':
    test_Min()

# Generated at 2022-06-24 00:40:03.543847
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)



# Generated at 2022-06-24 00:40:06.223561
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert All("") == All("")
    assert All(False) == All(False)
    assert (All(1) == All(0)) == False
    assert (All(True) == All(False)) == False
    assert (One(1) == One(1)) == True
    assert (One(1) == One(0)) == False
    assert All(None) == All(None)
    assert (All(1) == All(1)) == True



# Generated at 2022-06-24 00:40:08.572377
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'foo': 10, 'bar': 20})) == 'Map[value={"foo": Sum[value=10], "bar": Sum[value=20]}]'


# Generated at 2022-06-24 00:40:09.687311
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True), "should be equal"



# Generated at 2022-06-24 00:40:11.197777
# Unit test for constructor of class One
def test_One():  # pragma: no cover
    assert One(True).value == True


# Generated at 2022-06-24 00:40:13.437721
# Unit test for method concat of class Max
def test_Max_concat():
    assert (Max(10).concat(Max(20)) == Max(20)) is True
    assert (Max(10).concat(Max(-20)) == Max(10)) is True
    assert (Max(-10).concat(Max(-20)) == Max(-10)) is True

# Generated at 2022-06-24 00:40:22.560547
# Unit test for method concat of class First
def test_First_concat():  # pragma: no cover
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First('2a')) == First(1)
    assert First(1).concat(First(3.5)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(1).concat(First(False)) == First(1)
    assert First(1).concat(First(True)) == First(1)
    assert First(1).concat(First([])) == First(1)
    assert First(1).concat(First({})) == First(1)



# Generated at 2022-06-24 00:40:26.120278
# Unit test for constructor of class First
def test_First():
    a = First(1)
    b = First(2)
    assert a.value == 1, 'First constructor failed'
    assert a.concat(b) == First(1), 'First.concat failed'


# Generated at 2022-06-24 00:40:34.672499
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():  # pragma: no cover
    """
    Unit test for method fold of class Semigroup.
    :returns: boolean value.
    :rtype: bool
    """
    value = 2
    semigroup = Sum(value)
    assert semigroup.fold(lambda v: v + 1) == value + 1
    assert semigroup.fold(lambda v: v - 1) == value - 1
    assert semigroup.fold(lambda v: v * 2) == value * 2
    assert semigroup.fold(lambda v: v / 2) == value / 2
    return True



# Generated at 2022-06-24 00:40:36.879003
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last("a")) == 'Last[value=a]'
    assert str(Last("b")) == 'Last[value=b]'


# Generated at 2022-06-24 00:40:39.103789
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"



# Generated at 2022-06-24 00:40:41.997851
# Unit test for constructor of class Min
def test_Min():
    assert Min(10).value == 10


# Generated at 2022-06-24 00:40:46.710884
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(2)
    assert not Semigroup('2')
    assert Semigroup(2).__eq__(Semigroup(2))
    assert not Semigroup(2).__eq__(Semigroup('2'))
    assert Semigroup(2).fold(lambda x: x + 2) == 4


# Generated at 2022-06-24 00:40:50.108992
# Unit test for method __str__ of class Map
def test_Map___str__():
    a = Map({'a': 2})
    b = Map({'a': 1})
    assert str(a.concat(b)) == 'Map[value={}]'



# Generated at 2022-06-24 00:40:51.325750
# Unit test for constructor of class One
def test_One():
    assert One(True).value is True
    assert One(False).value is False


# Generated at 2022-06-24 00:40:53.318923
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-24 00:41:02.181819
# Unit test for method concat of class All
def test_All_concat():
    a = All(True)
    b = All(True)
    assert a.concat(b).value == True

    a = All(True)
    b = All(False)
    assert a.concat(b).value == False

    a = All(False)
    b = All(True)
    assert a.concat(b).value == False

    a = All(False)
    b = All(False)
    assert a.concat(b).value == False


# Generated at 2022-06-24 00:41:03.902755
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-24 00:41:07.962061
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'
    assert str(All(1)) == 'All[value=True]'
    assert str(All([])) == 'All[value=False]'


# Generated at 2022-06-24 00:41:09.047182
# Unit test for constructor of class Last
def test_Last():
    last = Last(5)
    assert last.value == 5


# Generated at 2022-06-24 00:41:13.827054
# Unit test for method __str__ of class First
def test_First___str__():
    def check(value):
        assert str(First(value)) == "Fist[value=%s]" % (str(value),)

    check(None)
    check(False)
    check(True)
    check(42)


# Generated at 2022-06-24 00:41:15.651352
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-24 00:41:19.488678
# Unit test for method concat of class Min
def test_Min_concat():  # pragma: no cover
    assert Min(1).concat(Min(2)).value == 1
    assert Min(2).concat(Min(1)).value == 1


# Generated at 2022-06-24 00:41:21.189459
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First("string")) == "Fist[value=string]"



# Generated at 2022-06-24 00:41:30.260943
# Unit test for method concat of class One
def test_One_concat():  # pragma: no cover
    assert One(True).concat(
        One(False)
    ) == One(True)
    assert One(False).concat(
        One(False)
    ) == One(False)
    assert One(False).concat(
        One(True)
    ) == One(True)
    assert One(True).concat(
        One(True)
    ) == One(True)
    assert One(None).concat(
        One(None)
    ) == One(None)
    assert One('string').concat(
        One('string')
    ) == One('string')
    assert One('').concat(One('')) == One('')
    assert One('string').concat(
        One(None)
    ) == One('string')

# Generated at 2022-06-24 00:41:33.150391
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1)
    assert Sum(0)
    assert Sum(-1)
    assert Sum(1) != Sum(2)
    assert Sum.neutral() == Sum(0)


# Generated at 2022-06-24 00:41:35.804626
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == "Max[value=1]"
    assert str(Max(2)) == "Max[value=2]"

