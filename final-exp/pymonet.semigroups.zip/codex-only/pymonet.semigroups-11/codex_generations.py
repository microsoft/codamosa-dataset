

# Generated at 2022-06-24 00:31:36.553868
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)


# Generated at 2022-06-24 00:31:38.642723
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(3).concat(Max(2)) == Max(3)



# Generated at 2022-06-24 00:31:44.562821
# Unit test for constructor of class One
def test_One():
    assert One(True)
    assert One(False)
    assert One(1)
    assert One(0)
    assert One('a')
    assert One('')
    assert One([1,2])
    assert One([])
    assert One(None)


# Generated at 2022-06-24 00:31:45.387339
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(False)) == 'One[value=False]'



# Generated at 2022-06-24 00:31:48.486589
# Unit test for method concat of class Sum
def test_Sum_concat():
    semigroup_a = Sum(1)
    semigroup_b = Sum(2)
    res = semigroup_a.concat(semigroup_b)
    assert res.value == 3


# Generated at 2022-06-24 00:31:50.117125
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last([1, 2, 3]).concat(Last([4, 5, 6])).value == [4, 5, 6]


# Generated at 2022-06-24 00:31:51.670267
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)


# Generated at 2022-06-24 00:31:54.821264
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    """
    Unit test for method __str__ of class Last
    """
    expected_value = "Last[value=pen]"

    assert expected_value == str(Last("pen"))

# Generated at 2022-06-24 00:31:56.794228
# Unit test for method __str__ of class Max
def test_Max___str__():
    text_result = str(Max(1))

    assert text_result == 'Max[value=1]'


# Generated at 2022-06-24 00:31:58.304936
# Unit test for constructor of class First
def test_First():
    first = First("first")
    assert first.value == "first"


# Generated at 2022-06-24 00:31:59.290047
# Unit test for constructor of class Min
def test_Min():
    assert Min(2) == Min(2)


# Generated at 2022-06-24 00:32:01.251521
# Unit test for constructor of class Map
def test_Map():
    assert Map({"one": First("one")}) == Map({"one": First("one")})

# Generated at 2022-06-24 00:32:03.962983
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1) == First(1).concat(First(1))
    assert First(2) == First(2).concat(First(1))


# Generated at 2022-06-24 00:32:06.216769
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    Test for constructor of class Semigroup
    """
    assert Semigroup(5).value == 5
    assert Semigroup("test").value == "test"



# Generated at 2022-06-24 00:32:08.952073
# Unit test for method __str__ of class Map
def test_Map___str__():
    actual = Map({
        "1": All(True),
        "2": All(True)
    })
    expected = 'Map[value={"1": All[value=True], "2": All[value=True]}]'
    assert str(actual) == expected



# Generated at 2022-06-24 00:32:12.458777
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).concat(One(True)) == One(True)
    assert One(False).concat(One(1)) == One(1)
    assert One(0).concat(One(None)) == One(None)
    assert One('').concat(One('a')) == One('a')
    assert One([1, 2]).concat(One([2, 3])) == One([2, 3])


# Generated at 2022-06-24 00:32:18.654030
# Unit test for constructor of class First
def test_First():
    a = First(1)
    b = First(2)
    assert a.value == 1
    assert b.value == 2
    assert a.concat(b) == a



# Generated at 2022-06-24 00:32:23.446066
# Unit test for method concat of class Map
def test_Map_concat():
    """Unit test for method concat of class Map"""
    assert Map({'a': Sum(1)}).concat(Map({'a': Sum(1)})) == Map({'a': Sum(2)})
    assert Map({'a': All(True)}).concat(Map({'a': All(False)})) == Map({'a': All(False)})

# Generated at 2022-06-24 00:32:25.271050
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert str(All(False)) == "All[value=False]"


# Generated at 2022-06-24 00:32:30.435335
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-24 00:32:34.245359
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})).value == {'a': Sum(4), 'b': Sum(6)}


# Generated at 2022-06-24 00:32:38.961369
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(4).concat(Min(2)) == Min(2)
    assert Min(4).concat(Min(6)) == Min(4)

test_Min_concat()

# Generated at 2022-06-24 00:32:42.207741
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).concat(One(2)) == One(True)
    assert One(0).concat(One(1)) == One(True)
    assert One(0).concat(One(0)) == One(False)

# Generated at 2022-06-24 00:32:44.046656
# Unit test for constructor of class Map
def test_Map():
    assert(isinstance(Map({'a': Sum(1), 'b': Sum(3)}), Map))


# Generated at 2022-06-24 00:32:45.284371
# Unit test for method __str__ of class All
def test_All___str__():
    assert 'All[value=True]' == str(All(True))
    assert 'All[value=False]' == str(All(False))


# Generated at 2022-06-24 00:32:46.659980
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)


# Generated at 2022-06-24 00:32:51.509663
# Unit test for method concat of class Min
def test_Min_concat():
    """
    Unit test for method concat of class Min
    """

    assert Min(4).concat(Min(3)) == Min(3)

# Generated at 2022-06-24 00:32:56.796205
# Unit test for method __str__ of class One
def test_One___str__():
    """
    Unit test for method __str__ of class One:
    """
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-24 00:33:00.193336
# Unit test for method __str__ of class Last
def test_Last___str__():
    last = Last(value=1)
    assert last.__str__() == "Last[value=1]"



# Generated at 2022-06-24 00:33:04.459119
# Unit test for constructor of class First
def test_First():
    a = First("foo")
    assert a.value == "foo"
    assert a.concat("bar").value == "foo"
    assert a.concat(None).value == "foo"
    assert a.concat(1).value == "foo"

# Unit test constructor of class Last

# Generated at 2022-06-24 00:33:07.982362
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).value == 1
    assert Min(3).concat(Min(2)).value == 2



# Generated at 2022-06-24 00:33:17.212282
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2) == Min(2)
    assert Min(1) == Min(1)
    assert Min(5) == Min(5)
    assert Min(1) != Min(2)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(3)) == Min(1)
    assert Min(3).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)
    assert Min(2).concat(Min(2)) == Min(2)
    assert Min(0).concat(Min(1)) == Min(0)
    assert Min(0).concat(Min(0)) == Min(0)


# Generated at 2022-06-24 00:33:20.005163
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    :returns: True if fold for class Semigroup return value of function
    :rtype: bool
    """
    assert Semigroup(5).fold(lambda x: x + 1) == 6



# Generated at 2022-06-24 00:33:21.418272
# Unit test for constructor of class All
def test_All():
    """
    Test constructor class All
    """
    assert All(False).value == False


# Generated at 2022-06-24 00:33:25.432914
# Unit test for method concat of class One
def test_One_concat():  # pragma: no cover
    assert One(False).concat(One(10)) == One(10)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)


# Generated at 2022-06-24 00:33:28.282134
# Unit test for constructor of class Map
def test_Map():
    mp = Map({1: All(True), 2: First(10)})
    assert mp.value == {1: All(True), 2: First(10)}


# Generated at 2022-06-24 00:33:31.645616
# Unit test for method __str__ of class First
def test_First___str__():
    string = 'Fist[value={}]'.format(1)
    assert str(First(1)) == string



# Generated at 2022-06-24 00:33:40.416788
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    Test for method __eq__
    """

    #
    # Setup test data
    #
    test_data = [
        {
            'name': 'equal objects',
            'expected': True,
            'arguments': [Sum(1), Sum(1)],
        },
        {
            'name': 'different objects',
            'expected': False,
            'arguments': [Sum(1), Sum(2)],
        },
    ]

    #
    # Run test
    #
    for test in test_data:
        #
        # Setup test
        #
        argument_0 = test['arguments'][0]
        argument_1 = test['arguments'][1]

        #
        # Run test
        #
        result = argument_0 == argument_1

        #
        # Check

# Generated at 2022-06-24 00:33:43.280750
# Unit test for method __str__ of class Min
def test_Min___str__():  # pragma: no cover
    semigroup = Min(0)
    assert str(semigroup) == "Min[value=0]"



# Generated at 2022-06-24 00:33:45.345651
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(123)) == 'Sum[value=123]'


# Generated at 2022-06-24 00:33:46.917707
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(12)) == 'Max[value=12]'


# Generated at 2022-06-24 00:33:48.909127
# Unit test for method concat of class Min
def test_Min_concat():
    _sum = Min(1).concat(Min(2))
    assert _sum.value == 1


# Generated at 2022-06-24 00:33:51.325907
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'



# Generated at 2022-06-24 00:33:52.111718
# Unit test for constructor of class First
def test_First():
    first = First(1)
    assert first.value == 1



# Generated at 2022-06-24 00:33:53.674478
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-24 00:33:56.194048
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': First('hey')}).value == {'a': Sum(1), 'b': First('hey')}


# Generated at 2022-06-24 00:33:57.868239
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert not Sum(1) == Sum(2)


# Generated at 2022-06-24 00:33:59.900278
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"


# Generated at 2022-06-24 00:34:10.197297
# Unit test for method concat of class One
def test_One_concat():
    # test with positive values
    a_semigroup = One(value=True)
    b_semigroup = One(value=True)
    res = a_semigroup.concat(semigroup=b_semigroup)
    assert isinstance(res, One)
    assert res.value is True
    # test with negative values
    a_semigroup = One(value=False)
    b_semigroup = One(value=False)
    res = a_semigroup.concat(semigroup=b_semigroup)
    assert isinstance(res, One)
    assert res.value is False
    # test with mixed values
    a_semigroup = One(value=True)
    b_semigroup = One(value=False)
    res = a_semigroup.concat(semigroup=b_semigroup)
    assert isinstance

# Generated at 2022-06-24 00:34:13.645156
# Unit test for method __str__ of class Map
def test_Map___str__():  # pragma: no cover
    t = Map({0: First(1)})
    assert str(t) == 'Map[value={0: Fist[value=1]}]'


# Generated at 2022-06-24 00:34:19.982175
# Unit test for constructor of class Map
def test_Map():
    empty_map = Map({})
    assert empty_map.value == {}
    one_map = Map({'a': 1})
    assert one_map.value == {'a': 1}
    two_map = Map({'a': 1, 'b': 2})
    assert two_map.value == {'a': 1, 'b': 2}


# Generated at 2022-06-24 00:34:27.734666
# Unit test for method concat of class One
def test_One_concat():
    """
    Unit test for method concat of class One
    """
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)

test_One_concat()


# Generated at 2022-06-24 00:34:35.870539
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1)}).value == {'a': Sum(1)}
    assert Map({'a': Sum(1), 'b': Sum(2)}).value == {'a': Sum(1), 'b': Sum(2)}
    assert Map({'c': Sum(1), 'b': Sum(2), 'a': Sum(3)}).value == {'c': Sum(1), 'b': Sum(2), 'a': Sum(3)}
    assert Map({'c': Max(10), 'b': Max(2), 'a': Max(3)}).value == {'c': Max(10), 'b': Max(2), 'a': Max(3)}

    # Tests for type Map[A]

    assert isinstance(Map({'a': Sum(1)}).value, dict)

# Generated at 2022-06-24 00:34:37.146773
# Unit test for constructor of class First
def test_First():
    monoid = First(1)
    assert monoid.value == 1


# Generated at 2022-06-24 00:34:38.766616
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(10)) == Max(10)



# Generated at 2022-06-24 00:34:40.959939
# Unit test for constructor of class Last
def test_Last():  # pragma: no cover
    """ unit test for constructor of class Last """
    assert Last(1)


# Generated at 2022-06-24 00:34:44.627679
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)).value == 2
    assert Max(1).concat(Max(1)).value == 1
    assert Max(1).concat(Max(0)).value == 1


# Generated at 2022-06-24 00:34:46.230856
# Unit test for constructor of class Sum
def test_Sum():
    sum = Sum(1)
    assert sum.value == 1



# Generated at 2022-06-24 00:34:49.605481
# Unit test for method __str__ of class Map
def test_Map___str__():  # pragma: no cover
    map = Map({1: Sum(1), 2: Sum(2)})
    assert str(map) == "Map[value={1: Sum[value=1], 2: Sum[value=2]}]"



# Generated at 2022-06-24 00:34:53.233211
# Unit test for constructor of class Map
def test_Map():  # pragma: no cover
    assert Map({}).value == {}
    assert Map({"a": 2}).value == {"a": 2}
    assert Map({"a": "asda"}).value == {"a": "asda"}


# Generated at 2022-06-24 00:34:56.634088
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(2).concat(Last(1)) == Last(1)
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(1)) == Last(1)


# Generated at 2022-06-24 00:34:57.308754
# Unit test for constructor of class Max
def test_Max():
    assert Max(10).value == 10


# Generated at 2022-06-24 00:34:59.333651
# Unit test for method concat of class Min
def test_Min_concat():
    assert type(1).__name__ == type(1).__name__  # Bool
    assert type(1).__name__ == 'int'
    assert type(1).__name__ == 'str'


# Generated at 2022-06-24 00:35:01.241231
# Unit test for constructor of class Min
def test_Min():
    """
    Test that ensures the class Min has a constructor.
    """
    min_instance = Min(5)
    assert isinstance(min_instance, Min)


# Generated at 2022-06-24 00:35:11.174172
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert Sum(2) != Sum(1)
    assert All(True) == All(True)
    assert All(False) != All(True)
    assert One(True) == One(True)
    assert One(False) != One(True)
    assert First(1) == First(1)
    assert First(2) != First(1)
    assert Last(1) == Last(1)
    assert Last(2) != Last(1)
    assert Max(1) == Max(1)
    assert Max(2) != Max(1)
    assert Min(1) == Min(1)
    assert Min(2) != Min(1)
    assert Map({"a": Sum(1)}) == Map({"a": Sum(1)})

# Generated at 2022-06-24 00:35:12.394061
# Unit test for constructor of class Last
def test_Last():
    return Last(5) == Last(5)


# Generated at 2022-06-24 00:35:14.211230
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup('first')



# Generated at 2022-06-24 00:35:15.875062
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    Unit test for the constructor of class Semigroup
    """

    assert Semigroup(1).value == 1
    assert Semigroup(2.0).value == 2.0



# Generated at 2022-06-24 00:35:16.874893
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)



# Generated at 2022-06-24 00:35:17.640815
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First('data')) == 'Fist[value=data]'

# Generated at 2022-06-24 00:35:19.634515
# Unit test for method __str__ of class Map
def test_Map___str__():
    m1 = Map({'a': Sum(1), 'b': Sum(2)})
    assert str(m1) == 'Map[value={\'a\': Sum[value=1], \'b\': Sum[value=2]}]'



# Generated at 2022-06-24 00:35:21.398848
# Unit test for method __str__ of class Min
def test_Min___str__():
  f = Min(2)
  assert str(f) == "Min[value=2]"


# Generated at 2022-06-24 00:35:22.322419
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)
    assert One(1) != First(2)



# Generated at 2022-06-24 00:35:25.188903
# Unit test for method concat of class Max
def test_Max_concat():
    # arrange
    value = Max(3)
    another = Max(2)
    expected = Max(3)

    # act
    result = value.concat(another)

    # assert
    assert result == expected


# Generated at 2022-06-24 00:35:28.672872
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-24 00:35:30.430548
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(True)) == 'Fist[value=True]'
    assert str(First(False)) == 'Fist[value=False]'



# Generated at 2022-06-24 00:35:31.868223
# Unit test for constructor of class Last
def test_Last():
    l = Last(('a', 'b', 'c'))
    assert l.value == ('a', 'b', 'c')


# Generated at 2022-06-24 00:35:33.038955
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum = Sum(2)
    assert str(sum) == 'Sum[value=2]'



# Generated at 2022-06-24 00:35:36.355948
# Unit test for constructor of class Semigroup
def test_Semigroup():
    some = Sum(2)
    assert some.value == 2



# Generated at 2022-06-24 00:35:39.078973
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(10) == Sum(10)
    assert Sum(10) != Sum(1)



# Generated at 2022-06-24 00:35:41.091922
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-24 00:35:42.728116
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-24 00:35:46.605175
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    a = Semigroup(100)
    b = Semigroup(100)
    c = Semigroup(200)

    assert a == b
    assert a != c
    assert b != c
    assert b == a
    assert c != b
    assert c != a



# Generated at 2022-06-24 00:35:52.964780
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Sum(4).value == 4
    assert All(False).value is False
    assert All(True).value is True
    assert First(4).value == 4
    assert Last(4).value == 4
    assert Map({}).value == {}
    assert Min(4).value == 4
    assert Max(4).value == 4



# Generated at 2022-06-24 00:35:53.718053
# Unit test for method __str__ of class All
def test_All___str__():
    x = All(True)
    assert str(x) == 'All[value=True]'


# Generated at 2022-06-24 00:35:56.639809
# Unit test for constructor of class Sum
def test_Sum():
    a = Sum(5)
    b = Sum(6)
    assert a.value == 5
    assert type(a) is Sum
    assert b.value == 6
    assert type(b) is Sum



# Generated at 2022-06-24 00:35:57.574257
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True

# Generated at 2022-06-24 00:35:59.977003
# Unit test for constructor of class Map
def test_Map():
    assert Map({"a": Min(1), "b": Max(2)}) == Map({"a": Min(1), "b": Max(2)})


# Generated at 2022-06-24 00:36:04.802019
# Unit test for method __str__ of class All
def test_All___str__():
    all_true = All(True)
    assert all_true.__str__() == 'All[value=True]'
    all_false = All(False)
    assert all_false.__str__() == 'All[value=False]'


# Generated at 2022-06-24 00:36:06.845788
# Unit test for method concat of class Last
def test_Last_concat():
    """Test result of concat Last"""
    assert str(Last(1).concat(Last(2))) == 'Last[value=2]'



# Generated at 2022-06-24 00:36:08.618065
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: Sum(20)})) == 'Map[value={1: Sum[value=20]}]'

# Generated at 2022-06-24 00:36:10.208533
# Unit test for method concat of class First
def test_First_concat():
    assert First("a").concat(First("b")).value == "a"



# Generated at 2022-06-24 00:36:11.371067
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(False) == All(False)


# Generated at 2022-06-24 00:36:12.518316
# Unit test for constructor of class Min
def test_Min():
    assert Min(10) == Min(10)


# Generated at 2022-06-24 00:36:15.842206
# Unit test for method concat of class Last
def test_Last_concat():
    # given
    l1 = Last(1)
    l2 = Last(2)
    # when
    l3 = l1.concat(l2)
    # then
    assert l3.value == 2
    assert l3 == l2
    assert l3 != l1


# Generated at 2022-06-24 00:36:19.933609
# Unit test for method concat of class First
def test_First_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(3)) == Last(3)
    assert Last(1).concat(Last(0)) == Last(0)

    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(3)) == First(1)
    assert First(1).concat(First(0)) == First(1)


# Generated at 2022-06-24 00:36:21.190928
# Unit test for method __str__ of class Max
def test_Max___str__():
    max_ = Max(42)
    assert str(max_) == 'Max[value=42]'



# Generated at 2022-06-24 00:36:25.850202
# Unit test for method __str__ of class All
def test_All___str__():
    assert All(True).__str__() == "All[value=True]"


# Generated at 2022-06-24 00:36:30.000847
# Unit test for constructor of class Max
def test_Max():
    max = Max(0)   # Pass
    max = Max(10)  # Pass

    try:
        max = Max("10")  # Fail
    except AssertionError:
        print("test_Max Pass")
    else:  # pragma: no cover
        print("test_Max Fail")


# Generated at 2022-06-24 00:36:32.656855
# Unit test for constructor of class Min
def test_Min():
   assert Min(42) == Min(42)
   assert Min(0) == Min(0)
   assert Min(23) == Min(23)



# Generated at 2022-06-24 00:36:34.522045
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)).value == True


# Generated at 2022-06-24 00:36:36.007247
# Unit test for constructor of class Max
def test_Max():
    max = Max(1)
    assert max.value == 1


# Generated at 2022-06-24 00:36:40.070659
# Unit test for method __str__ of class All
def test_All___str__():
    assert 'All[value=True]' == str(All(True))
    assert 'All[value=False]' == str(All(False))
    assert 'All[value=True]' == str(All(True).concat(All(True)))
    assert 'All[value=False]' == str(All(True).concat(All(False)))


# Generated at 2022-06-24 00:36:41.734431
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(100)) == 'Last[value=100]'

# Generated at 2022-06-24 00:36:44.880782
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First({'foo': Sum(1), 'bar': Sum(2)})) == "Fist[value={'foo': Sum[value=1], 'bar': Sum[value=2]}]"



# Generated at 2022-06-24 00:36:48.973633
# Unit test for method __str__ of class All
def test_All___str__():
    # Create an instance of class All with some value
    inst = All(True)
    # Check if it equal to a hardcoded string-like value
    assert str(inst) == 'All[value=True]', 'Not equal!'


# Generated at 2022-06-24 00:36:51.788301
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'1': Sum(1), '2': Sum(2)})) == 'Map[value={\'1\': Sum[value=1], \'2\': Sum[value=2]}]'



# Generated at 2022-06-24 00:36:53.677504
# Unit test for method concat of class Sum
def test_Sum_concat():
    expected = Sum(9)
    result = Sum(1).concat(Sum(8))

    assert expected == result

# Generated at 2022-06-24 00:36:58.566345
# Unit test for constructor of class First
def test_First():
    test_sum = First("sum")
    assert test_sum.value == "sum"
    assert test_sum.fold(_) == "sum"


# Generated at 2022-06-24 00:37:01.315005
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(2), 'b': Sum(3)}).value == {'a': Sum(2), 'b': Sum(3)}


# Generated at 2022-06-24 00:37:06.094056
# Unit test for method __str__ of class All
def test_All___str__():
    """
    Unit test for method __str__ of class All
    """
    semigroup = All(True)
    expected = 'All[value=True]'
    actual = str(semigroup)
    assert expected == actual



# Generated at 2022-06-24 00:37:09.927502
# Unit test for method __str__ of class Map
def test_Map___str__():
    print('>>> test_Map___str__()')
    print(Map({'a': Sum(3), 'b': Last('foo')}))
    assert True


# Generated at 2022-06-24 00:37:10.897636
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(5)) == 'Max[value=5]'


# Generated at 2022-06-24 00:37:13.491569
# Unit test for method concat of class Min
def test_Min_concat():
    """
    Unit test for method concat of class Min
    """
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)



# Generated at 2022-06-24 00:37:17.216069
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert (str(Map({'a': 1, 'bb': 2})) == "Map[value={'a': 1, 'bb': 2}]")


# Generated at 2022-06-24 00:37:18.559705
# Unit test for constructor of class First
def test_First():
    monoid = First("Hello world!")

    assert monoid.value == "Hello world!"
    assert str(monoid) == 'Fist[value=Hello world!]'



# Generated at 2022-06-24 00:37:19.539977
# Unit test for method __str__ of class All
def test_All___str__():
    assert All(True).__str__() == 'All[value=True]'

# Generated at 2022-06-24 00:37:24.723384
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False
    assert All(True).concat(All(True)).value == True
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
    assert All(False).concat(All(False)).value == False
    assert All.neutral().value == True


# Generated at 2022-06-24 00:37:27.418287
# Unit test for method concat of class First
def test_First_concat():
    assert First(10).concat(First(15)) == First(10)
    assert First(-3).concat(First(-7)) == First(-3)


# Generated at 2022-06-24 00:37:29.409724
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-24 00:37:36.413003
# Unit test for method concat of class Last
def test_Last_concat():
    value_A = 5
    semigroup_A = Last(value_A)

    value_B = 10
    semigroup_B = Last(value_B)

    semigroup_A_concat_B = semigroup_A.concat(semigroup_B)
    value_A_concat_B = semigroup_A_concat_B.value

    assert value_B == value_A_concat_B



# Generated at 2022-06-24 00:37:40.815194
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    s = Sum(1)
    assert str(s) == 'Sum[value=1]'
    

# Generated at 2022-06-24 00:37:43.671016
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)
    assert One(True) == One(True)
    assert One(False) == One(False)



# Generated at 2022-06-24 00:37:45.921329
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First('test')) == 'Fist[value=test]'



# Generated at 2022-06-24 00:37:47.620046
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1 # Sum is constructed


# Generated at 2022-06-24 00:37:48.802276
# Unit test for constructor of class First
def test_First():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-24 00:37:51.324926
# Unit test for constructor of class Map
def test_Map():
    m = Map({"a": Sum(1), "b": Sum(2)})
    m_value = m.value
    assert m_value == {"a": Sum(1), "b": Sum(2)}


# Generated at 2022-06-24 00:37:52.634957
# Unit test for method __str__ of class Max
def test_Max___str__():
    a = Max(8)
    assert str(a) == 'Max[value=8]'


# Generated at 2022-06-24 00:37:57.667097
# Unit test for constructor of class Min
def test_Min():
    min = Min(None)
    min1 = Min(1)
    min2 = Min(2)
    assert min.concat(min2).value == 2

test_Min()


# Generated at 2022-06-24 00:37:58.723776
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-24 00:37:59.926928
# Unit test for constructor of class Max
def test_Max():
    monoid = Max(1)

    assert monoid.value == 1



# Generated at 2022-06-24 00:38:05.188710
# Unit test for method __str__ of class First
def test_First___str__():
    semigroup = First('test_value')
    assert str(semigroup) == 'Fist[value=test_value]'


# Generated at 2022-06-24 00:38:12.168721
# Unit test for method concat of class Map
def test_Map_concat():
    map_one = Map({'a': Sum(1), 'b': Sum(2)})
    map_two = Map({'a': Sum(3), 'b': Sum(4)})

    assert map_one.concat(map_two).value['a'].value == 4
    assert map_one.concat(map_two).value['b'].value == 6
    assert map_one.concat(map_two).value == {'a': Sum(4), 'b': Sum(6)}


# Generated at 2022-06-24 00:38:14.133501
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(False)) == str(One(False))
    assert str(One(False)) != str(One(True))



# Generated at 2022-06-24 00:38:15.438292
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(3)) == 'Sum[value=3]'

# Generated at 2022-06-24 00:38:20.963369
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(2).concat(Max(3)).concat(Last(1)) == Max(3)
    assert Max(2).concat(Max(3)).concat(Max(1)) == Max(3)
    assert Max(2).concat(Max(3)) == Max(3)


# Generated at 2022-06-24 00:38:23.604713
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(-1).concat(Sum(-2)) == Sum(-3)



# Generated at 2022-06-24 00:38:28.876474
# Unit test for method concat of class Map
def test_Map_concat():
    M = Map({'a': Sum(1), 'b': Sum(2)})
    M2 = Map({'a': Sum(2), 'b': Sum(1), 'c': Sum(3)})
    result = Map({'a': Sum(3), 'b': Sum(3), 'c': Sum(3)})
    assert M.concat(M2) == result



# Generated at 2022-06-24 00:38:30.282983
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(0).fold(lambda v: v == 0)



# Generated at 2022-06-24 00:38:32.575447
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert not All(True) == All(False)



# Generated at 2022-06-24 00:38:34.461226
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(2)
    assert not First(1) == First(3)
    assert First(1).value == 1
    asse

# Generated at 2022-06-24 00:38:38.499053
# Unit test for method concat of class Map
def test_Map_concat():  # pragma: no cover
    obj1 = Map({
        "a": Sum(1),
        "b": All(True),
        "c": One(False),
    })
    obj2 = Map({
        "a": Sum(1),
        "b": All(False),
        "c": One(True),
    })
    assert obj1.concat(obj2) == Map({
        "a": Sum(2),
        "b": All(False),
        "c": One(True),
    })

# Generated at 2022-06-24 00:38:39.284001
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == "Min[value=1]"



# Generated at 2022-06-24 00:38:41.952821
# Unit test for constructor of class Map
def test_Map():
    map = Map({'key': Sum(1)})
    assert (str(map) == "Map[value={'key': Sum[value=1]}]")


# Generated at 2022-06-24 00:38:43.354638
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)
    assert One(True) == One(True)
    assert One('ev') == One('ev')



# Generated at 2022-06-24 00:38:45.213448
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    assert One(True).__str__() == 'One[value=True]'


# Generated at 2022-06-24 00:38:47.805598
# Unit test for constructor of class Min
def test_Min():
    m = Min(0)
    if m.value != 0:
        print("Error on Min(0)")

test_Min()



# Generated at 2022-06-24 00:38:49.609696
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup
    assert Semigroup(1)


# Generated at 2022-06-24 00:38:51.627365
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-24 00:38:54.549179
# Unit test for constructor of class Semigroup
def test_Semigroup():
    try:
        s = Semigroup(0)
    except Exception as e:  # pragma: no cover
        raise e

# Generated at 2022-06-24 00:38:58.756901
# Unit test for constructor of class Max
def test_Max():
    result = Max(10)
    expected = Max(10)
    assert result == expected

test_Max()


# Generated at 2022-06-24 00:39:07.859738
# Unit test for method concat of class Map
def test_Map_concat():
    """
    Testing of method concat of class Map
    """
    assert Map({"a": 1, "b": 2}).concat(Map({"b": 3, "c": 4})) == Map(
        {"a": 1, "b": 5, "c": 4}
    )
    assert Map({}).concat(Map({"a": 1, "b": 2})) == Map({"a": 1, "b": 2})
    assert Map({"a": 1, "b": 2}).concat(Map({})) == Map({"a": 1, "b": 2})
    assert Map({}).concat(Map({})) == Map({})


# Generated at 2022-06-24 00:39:13.760008
# Unit test for constructor of class All
def test_All():
    allValues = [True, False, 1, 0, None, "abc", -1, 10, [], {} ]
    for value in allValues:
        result = bool(value)
        for allValue in allValues:
            result = result and bool(allValue)
            assert All(result).value == result


# Generated at 2022-06-24 00:39:15.786624
# Unit test for constructor of class Last
def test_Last():
    assert Last(5).value == 5



# Generated at 2022-06-24 00:39:16.766976
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(10)) == 'Last[value=10]'

# Generated at 2022-06-24 00:39:20.081526
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(2) == Last(2)
    assert Last(1) != Last(2)
    assert str(Last(1)) == 'Last[value=1]'
    assert str(Last('a')) == 'Last[value=a]'


# Generated at 2022-06-24 00:39:22.116085
# Unit test for method __str__ of class Max
def test_Max___str__():
    x = 1
    assert str(Max(x)) == "Max[value=1]"


# Generated at 2022-06-24 00:39:26.994107
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(4).concat(Last(5)) == Last(5)
    assert Last(4).concat(Last(4)) == Last(4)
    assert Last(0).concat(Last(-5)) == Last(-5)
    assert Last(0).concat(Last(0)) == Last(0)


# Generated at 2022-06-24 00:39:28.453599
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last('foo')) == 'Last[value=foo]'


# Generated at 2022-06-24 00:39:30.399998
# Unit test for constructor of class Max
def test_Max():
    max_int = Max(500)
    assert max_int.value == 500



# Generated at 2022-06-24 00:39:34.985850
# Unit test for method concat of class Map
def test_Map_concat():
    """
    This function is a unit test for method concat of class Map.
    :returns: None
    :rtype: None
    """
    first = Map({1: Sum(1), 2: Sum(2), 3: Sum(3)})
    second = Map({1: Sum(3), 2: Sum(2), 3: Sum(1)})
    third = Map({1: Sum(4), 2: Sum(4), 3: Sum(4)})
    assert(first.concat(second) == third)
    return None



# Generated at 2022-06-24 00:39:38.406226
# Unit test for method concat of class Max
def test_Max_concat():
    # Given
    semigroup_1 = Max(5)
    semigroup_2 = Max(2)

    # When
    semigroup_3 = semigroup_1.concat(semigroup_2)

    # Then
    assert semigroup_3 == Max(5)


# Generated at 2022-06-24 00:39:40.718112
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)


# Generated at 2022-06-24 00:39:44.390552
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(0)) == Sum(1)
    assert Sum(0).concat(Sum(0)) == Sum(0)


# Generated at 2022-06-24 00:39:47.715317
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    value_1 = Semigroup(1)
    value_2 = Semigroup(2)
    value_3 = Semigroup(1)

    assert value_1 == value_3
    assert value_1 != value_2
    assert not(value_2 == value_1)



# Generated at 2022-06-24 00:39:54.589832
# Unit test for method concat of class One
def test_One_concat():
    one_one = One(True)
    one_two = One(False)
    one_three = One(False)
    assert one_one.concat(one_two) == One(True)
    assert one_one.concat(one_three) == One(True)
    assert one_two.concat(one_three) == One(False)


test_One_concat()



# Generated at 2022-06-24 00:40:04.113322
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1) != All(2)
    assert All(2) == All(2)
    assert All(2) != All(3)
    assert All(2) != Sum(2)
    assert One(2) == One(2)
    assert One(2) != One(3)
    assert One(2) != Sum(2)
    assert First(2) == First(2)
    assert First(2) != Sum(2)
    assert Last(2) == Last(2)
    assert Last(2) != Sum(2)

# Generated at 2022-06-24 00:40:05.632421
# Unit test for constructor of class Map
def test_Map():
    m = Map({0: Max(1)})
    assert isinstance(m, Map)



# Generated at 2022-06-24 00:40:11.785430
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).concat(One(0)) == One(1)
    assert One(1).concat(One(1)) == One(1)
    assert One(0).concat(One(1)) == One(1)
    assert One(0).concat(One(0)) == One(0)



# Generated at 2022-06-24 00:40:13.781835
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(0)) == 'Last[value=0]'



# Generated at 2022-06-24 00:40:19.650563
# Unit test for method __str__ of class Last
def test_Last___str__():
    myLast = Last(True)
    assert str(myLast) == "Last[value=True]"
    print("All test for method __str__ of class Last were passed")

test_Last___str__()


# Generated at 2022-06-24 00:40:21.732233
# Unit test for method concat of class Min
def test_Min_concat():
    # Arrange
    semigroup = Min(4.0)
    other = Min(2.4)
    # Act
    result = semigroup.concat(other)
    # Assert
    assert result.value == 2.4, 'Test Failed'


# Generated at 2022-06-24 00:40:23.759231
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(4).concat(Max(2)) == Max(4)
    assert Max(4).concat(Max(5)) == Max(5)
    assert Max(4).concat(Max(4)) == Max(4)


# Generated at 2022-06-24 00:40:30.883702
# Unit test for method concat of class One
def test_One_concat():
    assert One(True)  .concat(One(False)).fold(lambda x: x) == True
    assert One(False) .concat(One(False)).fold(lambda x: x) == False
    assert One(False) .concat(One(True)).fold(lambda x: x) == True
    assert One(True)  .concat(One(True)).fold(lambda x: x) == True


# Generated at 2022-06-24 00:40:32.063265
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(0) == One(0)

# Generated at 2022-06-24 00:40:36.228510
# Unit test for method concat of class All
def test_All_concat():
    """
    Test concat method of class All
    """
    expected = All(True)
    actual = All(True).concat(All(True))
    assert actual == expected

    expected = All(False)
    actual = All(True).concat(All(False))
    assert actual == expected

    expected = All(False)
    actual = All(False).concat(All(False))
    assert actual == expected


# Generated at 2022-06-24 00:40:37.126065
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(2)


# Generated at 2022-06-24 00:40:38.385759
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(4)) == 'Min[value=4]'



# Generated at 2022-06-24 00:40:40.360702
# Unit test for method concat of class Max
def test_Max_concat():
    first = Max(3)
    second = Max(5)
    assert first.concat(second).value == 5
    assert second.concat(first).value == 5



# Generated at 2022-06-24 00:40:45.409894
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)


# Generated at 2022-06-24 00:40:49.397982
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)



# Generated at 2022-06-24 00:40:52.026640
# Unit test for method concat of class All
def test_All_concat():
    assert not All(True).concat(All(False)).value
    assert All(True).concat(All(True)).value
    assert not All(False).concat(All(False)).value

# Generated at 2022-06-24 00:40:55.615275
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(3)) == 'Min[value=3]'


# Generated at 2022-06-24 00:41:04.737963
# Unit test for method concat of class All
def test_All_concat():
    # case 1
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)

    # case 2
    assert All(True).concat(True) == All(True)
    assert All(True).concat(False) == All(False)

    # case 3
    assert All(True).concat(All(True)).concat(True) == All(True)


# Generated at 2022-06-24 00:41:09.091249
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(3)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(3)) == First(None)
    assert First(None).concat(First(None)) == First(None)


# Generated at 2022-06-24 00:41:11.713823
# Unit test for constructor of class Min
def test_Min():
    assert Min(3).value == 3
    assert Min(5).value == 5
    assert Min(2).value == 2


# Generated at 2022-06-24 00:41:16.876149
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    sum_fold_result = Sum(5).fold(lambda x: str(x) + '!')
    all_fold_result = All(True).fold(lambda x: str(x) + '!')
    assert sum_fold_result == '5!'
    assert all_fold_result == 'True!'


# Generated at 2022-06-24 00:41:19.592184
# Unit test for constructor of class Sum
def test_Sum():
    num = Sum(2)
    assert num.value == 2
    assert num.fold(lambda x: x) == 2


# Generated at 2022-06-24 00:41:29.453298
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    :returns: True if all test passed
    :rtype: bool
    """
    assert First(1).concat(First(2)) == First(1)
    assert Last(1).concat(Last(2)) == Last(2)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(True).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert Sum(1).concat(Sum(1)) == Sum(2)

# Generated at 2022-06-24 00:41:31.358832
# Unit test for method concat of class Last
def test_Last_concat():
    last = Last(10)
    result = last.concat(Last(1))
    assert result and result.value == 1



# Generated at 2022-06-24 00:41:34.655055
# Unit test for method concat of class First
def test_First_concat():
    semigroup_1 = First(1)
    semigroup_2 = First(2)

    result = semigroup_1.concat(semigroup_2)

    assert result == First(1)


# Generated at 2022-06-24 00:41:38.512739
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    assert str(One(True)) == "One[value=True]"
    assert str(One(False)) == "One[value=False]"
    assert str(One(None)) == "One[value=None]"
