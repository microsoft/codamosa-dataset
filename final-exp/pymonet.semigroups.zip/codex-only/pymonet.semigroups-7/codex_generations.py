

# Generated at 2022-06-24 00:31:35.476846
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1



# Generated at 2022-06-24 00:31:40.417507
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value == True
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
    assert All(False).concat(All(False)).value == False



# Generated at 2022-06-24 00:31:42.739141
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(4).value == 4



# Generated at 2022-06-24 00:31:48.799980
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-24 00:31:50.889574
# Unit test for constructor of class First
def test_First():
    assert First(99).value == 99
    assert First(1).value == 1
    assert First(False).value == False
    assert First(None).value == None



# Generated at 2022-06-24 00:31:53.210414
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(0) == Semigroup(0)
    assert not Semigroup(0) == Semigroup(1)


# Generated at 2022-06-24 00:31:54.277836
# Unit test for constructor of class All
def test_All():
    _ = All(True)


# Generated at 2022-06-24 00:31:59.809231
# Unit test for method concat of class All
def test_All_concat():
    """
    concat method for All class.
    """
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-24 00:32:00.971295
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-24 00:32:02.810659
# Unit test for method __str__ of class Min
def test_Min___str__():
    actual = Min(3)
    expected = 'Min[value=3]'
    assert actual.__str__() == expected


# Generated at 2022-06-24 00:32:05.249885
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-24 00:32:06.681712
# Unit test for method concat of class Max
def test_Max_concat():
    max = Max(1).concat(Max(2))
    assert max == Max(2)


# Generated at 2022-06-24 00:32:08.143414
# Unit test for constructor of class All
def test_All():
    result = All(True)
    assert result.value == True


# Generated at 2022-06-24 00:32:16.718569
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(10).concat(Max(2)) == Max(10)
    assert Max(10).concat(Max(11)) == Max(11)
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)
    assert Max(10).concat(Max(2)) == Max(10)
    assert Max(10).concat(Max(11)) == Max(11)


# Generated at 2022-06-24 00:32:18.926992
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(False)) == 'One[value=False]'
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-24 00:32:21.180969
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():  # pragma: no cover
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)



# Generated at 2022-06-24 00:32:25.545576
# Unit test for constructor of class Map
def test_Map():
    # Given
    m1 = Map({"a": Sum(1)})
    m2 = Map({"b": Sum(1)})

    # Then
    assert m1.value == {"a": Sum(1)}
    assert m2.value == {"b": Sum(1)}



# Generated at 2022-06-24 00:32:31.560307
# Unit test for constructor of class Map
def test_Map():
    m0 = Map({'a': First(True), 'b': First(False)})
    m1 = Map({'b': First(True), 'c': First(False)})
    assert m0.value == {'a': First(True), 'b': First(False)}
    assert m1.value == {'b': First(True), 'c': First(False)}


# Generated at 2022-06-24 00:32:35.127302
# Unit test for method concat of class Max
def test_Max_concat():
    one = Max(4)
    two = Max(1)

    assert one.concat(two) == Max(4)
    assert one.concat(one) == Max(4)
    assert two.concat(one) == Max(4)


# Generated at 2022-06-24 00:32:45.933934
# Unit test for method concat of class First
def test_First_concat():
    first1 = First(1)
    first2 = First(2)
    assert str(first1.concat(first2)) == 'Fist[value=1]'
    first3 = First(3)
    assert str(first1.concat(first2).concat(first3)) == 'Fist[value=1]'
    first4 = First(4)
    assert str(
            first1.concat(first2)
            .concat(first3)
            .concat(first4)
    ) == 'Fist[value=1]'

# Generated at 2022-06-24 00:32:54.283320
# Unit test for method concat of class Map
def test_Map_concat():
    import math
    import pytest
    s = Map({'a': Sum(1), 'b': Sum(2)})
    t = Map({'a': Sum(3), 'c': Sum(4)})
    v = Map({'a': Sum(4), 'b': Sum(2), 'c': Sum(4)})
    assert s.concat(t) == v
    pytest.raises(ValueError, s.concat, Sum(1))
    pytest.raises(ValueError, s.concat, "Map")


# Generated at 2022-06-24 00:32:55.409797
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert (str(Min(2)) == 'Min[value=2]')


# Generated at 2022-06-24 00:33:00.762299
# Unit test for constructor of class Map
def test_Map():
    test_case = Map({'a': Sum(1), 'b': Sum(2), 'c': Sum(3)})
    assert test_case.value == {'a': Sum(1), 'b': Sum(2), 'c': Sum(3)}



# Generated at 2022-06-24 00:33:04.458893
# Unit test for constructor of class One
def test_One():
    assert isinstance(One(True), One)
    assert isinstance(One(False), One)
    assert isinstance(One([]), One)
    # assert One(None) == One(False) # Not working for None
# Test for semantic concat for class One

# Generated at 2022-06-24 00:33:09.623494
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(999)).value == 999, "Max(1).concat(Max(999)) == 999"
    assert Max(-999).concat(Max(-1)).value == -1, "Max(-999).concat(Max(-1)) == -1"
    assert Max(1).concat(Max(-1)).value == 1, "Max(1).concat(Max(-1)) == 1"
    assert Max(1).concat(Max(1)).value == 1, "Max(1).concat(Max(1)) == 1"


# Generated at 2022-06-24 00:33:12.667751
# Unit test for method __str__ of class Max
def test_Max___str__():
    value = 5
    max_ = Max(value)
    assert str(max_) == 'Max[value={}]'.format(value)



# Generated at 2022-06-24 00:33:13.720840
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True


# Generated at 2022-06-24 00:33:15.759348
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(15) == Semigroup(15)
    assert Semigroup(15) != Semigroup(2)
    assert Semigroup(15) != None



# Generated at 2022-06-24 00:33:19.045084
# Unit test for method __str__ of class Last
def test_Last___str__():
    """
    Test case:
        Check that the method __str__ of class Last returns the correct value.
    """
    last = Last(0)
    assert last.__str__() == "Last[value=0]"


# Generated at 2022-06-24 00:33:23.586984
# Unit test for constructor of class Semigroup
def test_Semigroup():
    with pytest.raises(TypeError) as error_info:
        Semigroup(None)
    assert str(error_info.value) == 'Cannot create instance of abstract Semigroup class'
    assert isinstance(Semigroup(True), Semigroup) is True

# Generated at 2022-06-24 00:33:26.335618
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-24 00:33:29.372476
# Unit test for constructor of class Last
def test_Last():  # pragma: no cover
    last_cats = Last("cats")
    assert last_cats.value == "cats"



# Generated at 2022-06-24 00:33:34.244856
# Unit test for method concat of class Sum
def test_Sum_concat():
    semigroup1 = Sum(1)
    semigroup2 = Sum(2)
    sum_semigroup1_semigroup2 = Sum(semigroup1.value + semigroup2.value)
    assert semigroup1.concat(semigroup2) == sum_semigroup1_semigroup2


# Generated at 2022-06-24 00:33:36.713726
# Unit test for constructor of class One
def test_One():
    # Expected value
    expected = 1
    # Actual value
    actual = One(1).value
    # Test the equality of expected & actual values
    assert actual == expected


# Generated at 2022-06-24 00:33:42.941212
# Unit test for method concat of class Map
def test_Map_concat():
    """
    :raises: AssertionError if concat method of Map return not new Map with concated all values
    """
    assert Map({"a": Sum(1), "b": Sum(2)}).concat(
        Map({"a": Sum(3), "c": Sum(4)})
    ).value == {"a": Sum(4), "b": Sum(2), "c": Sum(4)}, "test_Map_concat"

# Generated at 2022-06-24 00:33:44.712110
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(2)) == "Last[value=2]"



# Generated at 2022-06-24 00:33:47.192904
# Unit test for method __str__ of class Min
def test_Min___str__():
    obj = Min(5)
    assert str(obj) == "Min[value=5]", "Error in test_Min__str__"


# Generated at 2022-06-24 00:33:49.181366
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert First(1) == First(1)


# Generated at 2022-06-24 00:33:50.741255
# Unit test for constructor of class Min
def test_Min():  # pragma: no cover
    assert Min(0).value == 0


# Generated at 2022-06-24 00:33:54.823457
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-24 00:34:04.329237
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x + 2) == 3
    assert All(True).fold(lambda x: not x) == False
    assert One(False).fold(lambda x: not x) == True
    assert First('first').fold(lambda x: x + 'bar') == 'firstbar'
    assert Last('last').fold(lambda x: x + 'foo') == 'lastfoo'
    assert Map({'a': First('first'), 'b': Last('last')}).fold(lambda x: x['a'].concat(x['b'])) == First('first').concat(Last('last'))
    assert Max(-1).fold(lambda x: x + 2) == 1
    assert Min(1).fold(lambda x: x + 2) == 3

# Test for methods concat of class Semigroup

# Generated at 2022-06-24 00:34:06.507836
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Unit test for method fold of class Semigroup
    """
    assert Semigroup(10).fold(str) == "10"
    assert Semigroup(10).fold(lambda x: x + 5) == 15
    assert Semigroup(10).fold(lambda x: True if x % 2 == 0 else False)

# Generated at 2022-06-24 00:34:14.271579
# Unit test for method concat of class Map
def test_Map_concat():  # pragma: no cover
    a = Map({'sum': Sum(1), 'all': All(True)})
    b = Map({'sum': Sum(2), 'all': All(False)})
    c = a.concat(b)
    c_exp = Map({'sum': Sum(3), 'all': All(False)})
    assert c.value['sum'].value == c_exp.value['sum'].value
    assert c.value['all'].value == c_exp.value['all'].value


# Generated at 2022-06-24 00:34:16.578714
# Unit test for constructor of class One
def test_One():
    one = One(9)
    assert one.value == 9
    assert isinstance(one, One)


# Generated at 2022-06-24 00:34:18.476084
# Unit test for method concat of class First
def test_First_concat():
    a = First(1)
    b = First(2)
    assert a.concat(b).value == 1


# Generated at 2022-06-24 00:34:19.906535
# Unit test for method concat of class Last
def test_Last_concat():  # pragma: no cover
    assert Last(1).concat(Last(2)) == Last(2)



# Generated at 2022-06-24 00:34:24.576992
# Unit test for constructor of class Semigroup
def test_Semigroup():
    actual = Semigroup(1).value
    expected = 1
    assert actual == expected


# Generated at 2022-06-24 00:34:25.632352
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-24 00:34:31.577433
# Unit test for constructor of class Map
def test_Map():
    map = Map({'one': All(True), 'two': All(False), 'three': All(True)})
    assert map.value == {
        'one': All(True), 'two': All(False), 'three': All(True)
    }
    other_map = Map({
        'one': All(True),
        'two': All(True),
        'three': All(True)
    })
    assert other_map.value == {
        'one': All(True),
        'two': All(True),
        'three': All(True)
    }
    assert map == other_map
    assert map.fold(lambda x: x) == {
        'one': All(True), 'two': All(False), 'three': All(True)
    }
    assert map.concat(other_map)

# Generated at 2022-06-24 00:34:35.428247
# Unit test for constructor of class Sum
def test_Sum():
    # given
    assert Sum(3).value == 3
    assert Sum(3).fold(lambda a: a) == 3
    # when
    assert Sum(3) == Sum(3)
    assert Sum(3) != Sum(4)
    assert Sum(3) != None
    # then


# Generated at 2022-06-24 00:34:37.019880
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).concat(One(2)) == One(1)


# Generated at 2022-06-24 00:34:39.571919
# Unit test for method concat of class Map
def test_Map_concat():
    value = Map({'a': Sum(1)})
    value = value.concat(value)
    assert value == Map({'a': Sum(2)})



# Generated at 2022-06-24 00:34:41.177650
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=True]'


# Generated at 2022-06-24 00:34:43.654535
# Unit test for constructor of class Last
def test_Last(): # pragma: no cover
    last = Last(9)
    assert last.__str__() == 'Last[value=9]'


# Generated at 2022-06-24 00:34:45.393494
# Unit test for method __str__ of class Map
def test_Map___str__():
    obj = Map({})
    assert str(obj) == 'Map[value={}]'



# Generated at 2022-06-24 00:34:46.936346
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-24 00:34:49.123785
# Unit test for method __str__ of class Last
def test_Last___str__():
    expected = 'Last[value=value]'
    instance = Last('value')
    assert expected == str(instance)


# Generated at 2022-06-24 00:34:51.047720
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First('A')) == 'Fist[value=A]'



# Generated at 2022-06-24 00:34:55.745998
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({"asd": Sum(1)})) == "Map[value={'asd': Sum[value=1]}]"

    assert str(Map({"asd": Sum(1), "q": Sum(2)})) == "Map[value={'asd': Sum[value=1], 'q': Sum[value=2]}]"



# Generated at 2022-06-24 00:35:04.555034
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    result = Sum(2).fold(lambda x: x ** 2)
    assert result == 4, 'Wrong!'
    print(result)

    result = Min(2).fold(lambda x: x ** 2)
    assert result == 2, 'Wrong!'
    print(result)

    result = Min(2).fold(lambda x: x ** 2)
    assert result == 2, 'Wrong!'
    print(result)

    result = All(True).fold(lambda x: x - 2)
    assert result is False, 'Wrong!'
    print(result)

    result = Last(2).fold(lambda x: x ** 2)
    assert result == 4, 'Wrong!'
    print(result)


if __name__ == '__main__':
    test_Semigroup_fold()

# Generated at 2022-06-24 00:35:07.941967
# Unit test for constructor of class One
def test_One():
    """
    Unit test for constructor of class One
    :return: None
    :rtype: None
    """
    assert One(1)
    assert One(0)
    assert One(False)
    assert One(True)



# Generated at 2022-06-24 00:35:12.101067
# Unit test for method __str__ of class First
def test_First___str__():
    assert 'Fist[value=first]' == str(First('first'))


# Generated at 2022-06-24 00:35:12.758454
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True

# Generated at 2022-06-24 00:35:19.457228
# Unit test for constructor of class Min
def test_Min():
    assert Min(1).value == 1
    assert Min(1).concat(Min(2)).value == 1
    assert Min(2).concat(Min(1)).value == 1
    assert Min(1).concat(Min(1)).value == 1
    assert Min(1.0).concat(Min(2.0)).value == 1.0


# Generated at 2022-06-24 00:35:22.552826
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-24 00:35:25.302553
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    sumInstance = Sum(1)

    assert str(Sum(1)) == 'Sum[value=1]'
    assert sumInstance.value == 1
    assert sumInstance.neutral_element == 0


# Generated at 2022-06-24 00:35:26.849433
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'
    assert str(One(0)) == 'One[value=0]'



# Generated at 2022-06-24 00:35:30.469259
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == "One[value=True]", "Test failed!"
    assert str(One(False)) == "One[value=False]", "Test failed!"
    assert str(One(None)) == "One[value=None]", "Test failed!"


# Generated at 2022-06-24 00:35:32.493066
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(4)) == Min(4)
    assert Min(4).concat(Min(2)) == Min(2)


# Generated at 2022-06-24 00:35:36.222670
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    assert str(Last(1)) == 'Last[value=1]'



# Generated at 2022-06-24 00:35:38.519174
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)



# Generated at 2022-06-24 00:35:40.811981
# Unit test for method concat of class First
def test_First_concat():
    # Given
    semigroup1 = First(1)
    semigroup2 = First(2)
    # When
    result = semigroup1.concat(semigroup2)
    # Then
    assert result == First(1)


# Generated at 2022-06-24 00:35:46.558096
# Unit test for method concat of class Map
def test_Map_concat():
    map = Map({"key_1": First(1), "key_2": Last(2)})
    another_map = Map({"key_1": Last(3), "key_2": Last(4)})
    result = map.concat(another_map)
    expected = Map({"key_1": First(1), "key_2": Last(4)})
    assert(result == expected)

# Generated at 2022-06-24 00:35:50.220207
# Unit test for constructor of class All
def test_All():
    all = All(True)
    assert all.value is True


# Generated at 2022-06-24 00:35:52.730894
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    """
    >>> test_Sum___str__()
    'Sum[value=0]'

    >>> from ramda import __
    >>> __ == Sum(0).__str__()
    True
    """

# Generated at 2022-06-24 00:35:54.299265
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-24 00:35:58.410791
# Unit test for method concat of class Last
def test_Last_concat():
    # concat last with current
    assert Last(1).concat(Last(2)) == Last(2)
    # concat last with other
    assert Last(1).concat(Last(2)) == Last(2)
    # concat last with itself
    assert Last(1).concat(Last(1)) == Last(1)


# Generated at 2022-06-24 00:35:59.855686
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():  # pragma: no cover
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)


# Generated at 2022-06-24 00:36:04.241926
# Unit test for method __str__ of class Min
def test_Min___str__():
    # equation 1
    assert str(Min(1)) == 'Min[value=1]'

    # equation 2
    assert str(Min(2.0)) == 'Min[value=2.0]'



# Generated at 2022-06-24 00:36:06.667954
# Unit test for constructor of class All
def test_All(): # pragma: no cover
    assert All(True) == All(True)
    assert All(False) != All(True)
    assert All(True) != All(False)


# Generated at 2022-06-24 00:36:07.935506
# Unit test for constructor of class One
def test_One():
    assert One(False)
    assert not One(False)


# Generated at 2022-06-24 00:36:10.208309
# Unit test for method __str__ of class Last
def test_Last___str__():
    # arrange
    value = Last(1)
    # act
    actual = str(value)
    # assert
    assert actual == 'Last[value=1]'


# Generated at 2022-06-24 00:36:16.645104
# Unit test for constructor of class Map
def test_Map():
    m = Map({
        'a': Sum(1),
        'b': Sum(2),
        'c': Sum(3)
    })

    assert m.value['a'] == Sum(1)
    assert m.value['b'] == Sum(2)
    assert m.value['c'] == Sum(3)



# Generated at 2022-06-24 00:36:20.732089
# Unit test for method __str__ of class All
def test_All___str__(): # pragma: no cover
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-24 00:36:23.262834
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-24 00:36:26.046106
# Unit test for method concat of class Min
def test_Min_concat():
    semigroup_a = Min(2)
    semigroup_b = Min(3)
    assert semigroup_a.concat(semigroup_b) == Min(2)


# Generated at 2022-06-24 00:36:27.362518
# Unit test for constructor of class Sum
def test_Sum():
    sum = Sum(0)
    assert sum.value == 0



# Generated at 2022-06-24 00:36:32.112951
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(2)) == Max(5)
    assert Max(2).concat(Max(5)) == Max(5)
    assert Max(5).concat(Max(5)) == Max(5)
    assert Max(2).concat(Max(2)) == Max(2)

# Generated at 2022-06-24 00:36:33.981907
# Unit test for constructor of class Last
def test_Last():
    last = Last(5)
    assert last.value == 5


# Generated at 2022-06-24 00:36:37.441997
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(4).concat(Min(2)).value == 2
    assert Min(4).concat(Min(4)).value == 4
    assert Min(4).concat(Min(6)).value == 4


# Generated at 2022-06-24 00:36:38.697407
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(3)) == 'Sum[value=3]'



# Generated at 2022-06-24 00:36:43.334399
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    # Test by using MustEqual
    s = Sum(1)
    iret = s.__eq__(s)
    # Assertion
    assert iret == True
    # Test by using MustNotEqual
    s = Sum(1)
    iret = s.__eq__(Sum(2))
    # Assertion
    assert iret == False


# Generated at 2022-06-24 00:36:45.580910
# Unit test for method concat of class One
def test_One_concat():
    concated_value = One(True).concat(One(False))
    assert concated_value == One(True)



# Generated at 2022-06-24 00:36:47.869808
# Unit test for method __str__ of class All
def test_All___str__():
    assert All(False).__str__() == 'All[value=False]'


# Generated at 2022-06-24 00:36:52.296015
# Unit test for method concat of class One
def test_One_concat():
    """
    This function test concat method of class One
    """
    one = One(False)
    second = One(True)
    assert one.concat(second).value is True



# Generated at 2022-06-24 00:36:54.160209
# Unit test for constructor of class First
def test_First():
    """
    Test semigroup class First constructor
    """
    first = First(43)
    assert first == First(43)


# Generated at 2022-06-24 00:36:55.747635
# Unit test for method concat of class Max
def test_Max_concat():
    a = Max(1)
    b = Max(2)
    assert a.concat(b) == b



# Generated at 2022-06-24 00:37:02.679451
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    eq_(Sum(4), Sum(4))
    eq_(First(4), First(4))
    eq_(Last(4), Last(4))
    eq_(Map({4: First(4)}), Map({4: First(4)}))
    eq_(All(4), All(4))
    eq_(Min(4), Min(4))
    eq_(Max(4), Max(4))



# Generated at 2022-06-24 00:37:04.633448
# Unit test for method __str__ of class Map
def test_Map___str__():  # pragma: no cover
    assert str(Map({1: Sum(1)})) == "Map[value={1: Sum[value=1]}]"



# Generated at 2022-06-24 00:37:07.237065
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'
    assert str(Last('a')) == "Last[value='a']"
    assert str(Last(None)) == 'Last[value=None]'



# Generated at 2022-06-24 00:37:10.053200
# Unit test for method concat of class Max
def test_Max_concat():
    semigroup1 = Max(20)
    semigroup2 = Max(50)
    semigroup3 = Max(50)
    assert semigroup1.concat(semigroup2).value == 50
    assert semigroup2.concat(semigroup3).value == 50


# Generated at 2022-06-24 00:37:11.831127
# Unit test for constructor of class Max
def test_Max(): # pragma: no cover
    assert Max(2) == Max(2)



# Generated at 2022-06-24 00:37:12.509838
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True


# Generated at 2022-06-24 00:37:16.779799
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    from pymonet.monoid.semigroup import Sum as Sum
    s = Sum(1)
    assert (str(s) == 'Sum[value=1]')


# Generated at 2022-06-24 00:37:18.321217
# Unit test for method __str__ of class One
def test_One___str__():
    value = {'key': 10}
    expected = 'One[value={}]'.format(value)
    result = One(value).__str__()
    assert expected == result


# Generated at 2022-06-24 00:37:19.271679
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)


# Generated at 2022-06-24 00:37:21.721971
# Unit test for constructor of class One
def test_One():
    assert isinstance(One(True), One)
    assert isinstance(One(False), One)


# Generated at 2022-06-24 00:37:25.851927
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(10) == Semigroup(10)
    assert not Semigroup(1) == Semigroup(2)


# Generated at 2022-06-24 00:37:27.311878
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(1)) == 'All[value=1]'



# Generated at 2022-06-24 00:37:28.596584
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)


# Generated at 2022-06-24 00:37:30.304637
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)


# Generated at 2022-06-24 00:37:38.496208
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    semigroup = Sum(1)
    assert semigroup.fold(lambda x: x + 1) == 2

    semigroup = All(True)
    assert semigroup.fold(lambda x: str(x)) == "True"

    semigroup = One(False)
    assert semigroup.fold(lambda x: str(x)) == "False"

    semigroup = Last(1)
    assert semigroup.fold(lambda x: str(x)) == "1"

    semigroup = Max(1)
    assert semigroup.fold(lambda x: x + 1) == 2

    semigroup = Map({'a': Sum(1), 'b': Sum(2)})

# Generated at 2022-06-24 00:37:43.421703
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    :returns: str
    :rtype: str
    """
    assert Sum(2) == Sum(2)
    assert Sum(3) == Sum(3)
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert Last(2) == Last(2)
    assert Last(3) == Last(3)
    assert Map({'a': Sum(1), 'b': Sum(2)}) == Map({'a': Sum(1), 'b': Sum(2)})
    assert Max(2) == Max(2)
    assert Max(3) == Max(3)
    assert Min(1) == Min(1)
    assert Min(2) == Min(2)


# Generated at 2022-06-24 00:37:46.696108
# Unit test for method __str__ of class Max
def test_Max___str__(): # pragma: no cover
    max = Max(10)
    assert str(max) == 'Max[value=10]'


# Generated at 2022-06-24 00:37:47.365984
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'



# Generated at 2022-06-24 00:37:48.113284
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == "Fist[value=1]"



# Generated at 2022-06-24 00:37:49.478922
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last('bar').concat(Last('baz')).value == 'baz'



# Generated at 2022-06-24 00:37:50.304247
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == "Max[value=1]"



# Generated at 2022-06-24 00:37:54.844064
# Unit test for constructor of class All
def test_All():
    assert not All(True).fold(lambda x: False)
    assert All(True).fold(lambda x: True)
    assert All(False).fold(lambda x: False)
    assert All(False).fold(lambda x: True)
    assert All.neutral().value
    assert not All(False).value
    assert All(True).value



# Generated at 2022-06-24 00:38:03.239018
# Unit test for method concat of class Map
def test_Map_concat():
    first = Map({'a': Sum(2)})
    second = Map({'a': Sum(3), 'b': Sum(1)})
    assert first.concat(second) == Map({'a': Sum(5), 'b': Sum(1)})

    first = Map({'a': All(False), 'b': All(True)})
    second = Map({'a': All(False), 'b': All(False), 'c': All(True)})
    assert first.concat(second) == Map({'a': All(False), 'b': All(False), 'c': All(True)})

    first = Map({'a': One(False), 'b': One(True)})
    second = Map({'a': One(False), 'b': One(False), 'c': One(False)})
    assert first

# Generated at 2022-06-24 00:38:09.911467
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).concat(One(2)).value == One(2).concat(One(1)).value
    assert One(1).concat(One(1)).value == 1
    assert One(1).concat(One(True)).value == True
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(False)).value == False


# Generated at 2022-06-24 00:38:15.816285
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(2).concat(Sum(1)) == Sum(3)
    assert Sum(0).concat(Sum(0)) == Sum(0)
    assert Sum(0).concat(Sum(11)) == Sum(11)
    assert Sum(11).concat(Sum(0)) == Sum(11)
    assert Sum(11).concat(Sum(11)) == Sum(22)


# Generated at 2022-06-24 00:38:18.820411
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(42)) == 'One[value=42]'


# Generated at 2022-06-24 00:38:27.322554
# Unit test for method concat of class Map
def test_Map_concat():
    """
    >>> m1 = Map({'a': Sum(10), 'b': Sum(20), 'c': Sum(30)})
    >>> m2 = Map({'a': Sum(15), 'b': Sum(25)})
    >>> m3 = Map({'a': Sum(20), 'b': Sum(30), 'c': Sum(40), 'd': Sum(50)})
    >>> m1.concat(m2).value
    {'a': Sum[value=25], 'b': Sum[value=45]}
    >>> m1.concat(m3).value
    {'a': Sum[value=30], 'b': Sum[value=50], 'c': Sum[value=70]}
    """
    pass


# Generated at 2022-06-24 00:38:31.205095
# Unit test for method concat of class Last
def test_Last_concat():
    v1 = Last(4)
    v2 = Last(9)
    v3 = Last(2)

    assert v1.concat(v2).value == 9
    assert v2.concat(v3).value == 2
    assert v1.concat(v3).value == 2


# Generated at 2022-06-24 00:38:32.782068
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)




# Generated at 2022-06-24 00:38:34.635195
# Unit test for constructor of class One
def test_One():
    assert One("")
    assert One("1")
    assert One(1)
    assert One(True)


# Generated at 2022-06-24 00:38:38.182937
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False
    assert All(1).value == True
    assert All("").value == False
    assert All("a").value == True


# Generated at 2022-06-24 00:38:40.055746
# Unit test for method __str__ of class Last
def test_Last___str__():
    result = str(Last(42))
    assert result == 'Last[value=42]'


# Generated at 2022-06-24 00:38:45.080122
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    all_obj_1 = All(True)
    all_obj_2 = All(False)
    all_obj_3 = All(False)
    result_1 = all_obj_1.concat(all_obj_2)
    result_2 = all_obj_1.concat(all_obj_3)
    assert result_1.concat(All(True)) == All(True)
    assert result_2.concat(All(True)) == All(False)
    assert all_obj_1.concat(all_obj_2).concat(All(False)) == All(False)
    assert all_obj_1.concat(all_obj_2).concat(All(True)) == All(False)



# Generated at 2022-06-24 00:38:47.222584
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semi(1) == Semigroup(1)


# Unit tests for class Sum

# Generated at 2022-06-24 00:38:49.400132
# Unit test for method __str__ of class Last
def test_Last___str__():
    result = str(Last(1))
    assert result == 'Last[value=1]'



# Generated at 2022-06-24 00:38:56.229378
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    Unit test for method __eq__ of class Semigroup

    This test asserts that all of the following calls return True

    >>> test_Semigroup___eq__()
    True
    """
    a = Semigroup(1)
    b = Semigroup(1)
    c = Semigroup(2)

    return assert_equal(a == b, True) \
        and assert_equal(a == a, True) \
        and assert_equal(a == c, False)



# Generated at 2022-06-24 00:38:58.249355
# Unit test for constructor of class Sum
def test_Sum():
    sum = Sum(1)
    assert sum.value == 1


# Generated at 2022-06-24 00:38:59.921320
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-24 00:39:06.537313
# Unit test for constructor of class Sum
def test_Sum():
    """test_Sum
    Test that Sum class construct an object with a precise value
    """

    sum_1 = Sum(0)
    assert sum_1.value == 0, "sum_1 %r is not 0" % sum_1

    sum_2 = Sum(10)
    assert sum_2.value == 10, "sum_2 %r is not 10" % sum_2


# Generated at 2022-06-24 00:39:15.801808
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    The concat() method should combine items according to the Semigroup algebraic laws.
    For example take the numbers 3 and 4. First, add them together using the plus operation.
    The result will be 7. Second, the value 3 is returned when 3 is added to the neutral value for this instance of Sum.
    Finally, the value 4 is returned when the neutral value is added to 4.
    """
    assert Sum(4).concat(Sum(3)) == Sum(7)
    assert Sum(3).concat(Sum.neutral()) == Sum(3)
    assert Sum.neutral().concat(Sum(4)) == Sum(4)



# Generated at 2022-06-24 00:39:18.101270
# Unit test for method concat of class One
def test_One_concat():
    semigroup = One(True)
    other_semigroup = One(False)

    assert One(True).concat(other_semigroup) == semigroup


# Generated at 2022-06-24 00:39:19.265749
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last("a")) == "Last[value=a]"



# Generated at 2022-06-24 00:39:20.968122
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == "Last[value=1]"


# Generated at 2022-06-24 00:39:23.124332
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert First(1) == First(1)
    assert First(2) != First(3)

# Generated at 2022-06-24 00:39:29.241864
# Unit test for method __str__ of class Map
def test_Map___str__():
    # Given
    map = Map({0: All(True), 1: First(3), 2: Min(1)})

    # When
    string = str(map)

    # Then
    assert string == 'Map[value={0: All[value=True], 1: Fist[value=3], 2: Min[value=1]}]'



# Generated at 2022-06-24 00:39:30.852508
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-24 00:39:31.919840
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-24 00:39:35.994149
# Unit test for constructor of class Map
def test_Map():
    m1 = Map({'a': First(1), 'b': First('b')})
    m1 = Map({'a': First(1), 'b': First('b')})
    m2 = Map({'a': Last(2), 'b': First('c')})
    m3 = m1.concat(m2)
    assert m3.value == {'a': Last(2), 'b': First('b')}


# Constructor of class Map

# Generated at 2022-06-24 00:39:37.299210
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-24 00:39:38.823265
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(10).concat(Max(15)) == Max(15)



# Generated at 2022-06-24 00:39:42.098515
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 100) == 101
    assert Semigroup(100).fold(lambda x: x * 2) == 200
    assert Semigroup(200).fold(lambda x: x // 2) == 100


# Generated at 2022-06-24 00:39:45.154878
# Unit test for method __str__ of class All
def test_All___str__():
    """
    This method will test the method __str__ of the class All
    """
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-24 00:39:49.267830
# Unit test for constructor of class Max
def test_Max():
    assert Max(25) == Max(25)



# Generated at 2022-06-24 00:39:53.432918
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)


# Generated at 2022-06-24 00:39:56.556266
# Unit test for constructor of class Min
def test_Min():
    """
    Unit test for constructor of class Min
    """
    assert Min(5).value == 5



# Generated at 2022-06-24 00:39:57.891151
# Unit test for constructor of class One
def test_One():
    a = One("A")
    assert a.value == "A"


# Generated at 2022-06-24 00:40:01.038983
# Unit test for constructor of class One
def test_One():
    c1 = One(True)
    c2 = One(False)
    assert(c1.value == True)
    assert(c2.value == False)


# Generated at 2022-06-24 00:40:03.422091
# Unit test for method concat of class Max
def test_Max_concat():
    max1 = Max(10)
    max2 = Max(5)

    assert max1.concat(max2) == Max(10)


# Generated at 2022-06-24 00:40:07.485191
# Unit test for method concat of class One
def test_One_concat():
    """
    Test that concat will return a new class instance with a combined value
    """
    assert One(True).concat(One(True)).value == True
    assert One(False).concat(One(False)).value == False
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(True)).value == True



# Generated at 2022-06-24 00:40:08.308804
# Unit test for constructor of class Max
def test_Max():
    assert Max(3) == Max(3)



# Generated at 2022-06-24 00:40:09.396722
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)



# Generated at 2022-06-24 00:40:10.641603
# Unit test for method __str__ of class Min
def test_Min___str__():
    class_ = Min(1)
    assert str(class_) == 'Min[value=1]'


# Generated at 2022-06-24 00:40:12.488633
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(5)) == 'Min[value=5]'



# Generated at 2022-06-24 00:40:17.055671
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map({'a': Sum(1), 'b': Sum(2)})
    map2 = Map({'a': Sum(3), 'b': Sum(4)})
    m = Map({'a': Sum(4), 'b': Sum(6)})
    assert map1.concat(map2) == m


# Generated at 2022-06-24 00:40:18.861447
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1).value == 1



# Generated at 2022-06-24 00:40:19.883713
# Unit test for constructor of class First
def test_First():
    assert First('foo').value == 'foo'


# Generated at 2022-06-24 00:40:22.083267
# Unit test for constructor of class First
def test_First():
    data = First(6)
    assert data.value == 6



# Generated at 2022-06-24 00:40:23.172399
# Unit test for constructor of class Sum
def test_Sum():
    assert(Sum(1).fold(lambda x:x) == 1)


# Generated at 2022-06-24 00:40:26.936503
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    assert str(One(False)) == 'One[value=False]'
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-24 00:40:31.419728
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)
    assert All(All(True)).concat(All(All(True))) == All(All(True))



# Generated at 2022-06-24 00:40:32.822991
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-24 00:40:34.456174
# Unit test for constructor of class Last
def test_Last():
    last = Last(10)
    assert last.value == 10



# Generated at 2022-06-24 00:40:37.697681
# Unit test for constructor of class One
def test_One():
    assert eval(str(One(False))) == eval(str(One(False)))
    assert eval(str(One(True))) == eval(str(One(True)))


# Generated at 2022-06-24 00:40:42.725598
# Unit test for method concat of class One
def test_One_concat():
    """
    Test method concat for class One.
    """
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-24 00:40:45.196345
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == "Min[value=1]"


# Generated at 2022-06-24 00:40:47.599592
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    Test method concat for class Sum
    """
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-24 00:40:50.337665
# Unit test for constructor of class Semigroup
def test_Semigroup():
    with pytest.raises(TypeError):
        sg = Semigroup(5)


# Generated at 2022-06-24 00:40:51.635301
# Unit test for constructor of class One
def test_One():
    one = One()
    assert one.value is False



# Generated at 2022-06-24 00:40:55.568113
# Unit test for constructor of class Last
def test_Last():
    value = Last(1)
    assert value.value == 1


# Generated at 2022-06-24 00:40:59.187107
# Unit test for method __str__ of class One
def test_One___str__():
    expected = 'One[value=1]'
    actual = One(1).__str__()
    assert expected == actual

# Generated at 2022-06-24 00:41:00.523046
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(5)) == 'Sum[value=5]'


# Generated at 2022-06-24 00:41:01.615662
# Unit test for constructor of class Max
def test_Max():
    assert Max(8) == Max(8)
    assert Max(8).__str__() == 'Max[value=8]'


# Generated at 2022-06-24 00:41:02.359712
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(3)) == 'Max[value=3]'


# Generated at 2022-06-24 00:41:03.692219
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(10).concat(Min(0)).value == 0



# Generated at 2022-06-24 00:41:07.023791
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)

# Generated at 2022-06-24 00:41:09.329404
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(None)
    assert Semigroup(1)
    assert Semigroup("1")
    assert Semigroup(True)
    assert Semigroup(False)



# Generated at 2022-06-24 00:41:11.324778
# Unit test for constructor of class Map
def test_Map():
    m = Map({'a': Sum(1)})
    assert m.value == {'a': Sum(1)}

# Generated at 2022-06-24 00:41:15.797827
# Unit test for constructor of class Last
def test_Last():
    assert Last(22) == Last(22)
    assert Last(22) != Last(23)
    assert Last(22) != Last('22')


# Generated at 2022-06-24 00:41:21.509119
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'
    assert str(Last(123)) == 'Last[value=123]'
    assert str(Last(True)) == 'Last[value=True]'
    assert str(Last('value1')) == 'Last[value=value1]'



# Generated at 2022-06-24 00:41:24.455712
# Unit test for method __str__ of class One
def test_One___str__():
    o = One("value")
    result = str(o)
    assert result == "One[value=value]"


# Generated at 2022-06-24 00:41:27.331207
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(2).concat(Last(1)) == Last(1)
    assert Last(1).concat(Last(1)) == Last(1)



# Generated at 2022-06-24 00:41:28.738589
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-24 00:41:30.045656
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == "Sum[value=1]"



# Generated at 2022-06-24 00:41:31.019864
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1)



# Generated at 2022-06-24 00:41:41.573758
# Unit test for method concat of class Map
def test_Map_concat():  # pragma: no cover
    assert Map({'key': Sum(1)}).concat(Map({'key': Sum(2)})) == Map({'key': Sum(3)})
    assert Map({'key': All(True)}).concat(Map({'key': All(False)})) == Map({'key': All(False)})
    assert Map({'key': One(True)}).concat(Map({'key': One(False)})) == Map({'key': One(True)})
    assert Map({'key': First(1)}).concat(Map({'key': First(2)})) == Map({'key': First(1)})
    assert Map({'key': Last(1)}).concat(Map({'key': Last(2)})) == Map({'key': Last(2)})