

# Generated at 2022-06-24 00:31:33.969389
# Unit test for constructor of class Max
def test_Max():
    """
    Here we will test constructor of class Max
    """
    assert Max(1) == Max(1)

    assert Max(1) != Max(2)


# Generated at 2022-06-24 00:31:40.165604
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    The test_Semigroup___eq__ method of the Semigroup module.
    """
    obj_1 = Semigroup(1)
    obj_2 = Semigroup(1)
    obj_3 = Semigroup(2)
    assert obj_1 == obj_2
    assert (obj_1 == obj_3) is False


# Generated at 2022-06-24 00:31:45.384254
# Unit test for method __str__ of class Min
def test_Min___str__():
    """
    Test method __str__ of class Min
    """
    min = Min(2)
    assert str(min) == 'Min[value=2]'



# Generated at 2022-06-24 00:31:46.546866
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1



# Generated at 2022-06-24 00:31:53.620258
# Unit test for method concat of class Map
def test_Map_concat():
    # Arrange
    map_value = {
        'one': Sum(1),
        'two': Sum(2)
    }
    map_value2 = {
        'one': Sum(1),
        'three': Sum(3)
    }
    result = {
        'one': Sum(2),
        'two': Sum(2),
        'three': Sum(3)
    }
    expected = Map(result)

    # Act
    map_value = Map(map_value)
    map_value2 = Map(map_value2)
    got = map_value.concat(map_value2)

    # Assert
    assert got == expected


# Generated at 2022-06-24 00:31:58.514141
# Unit test for method __str__ of class All
def test_All___str__():
    """All is a Monoid that will combine 2 values of any type using logical conjunction on their coerced Boolean values"""
    all_foo = All(True)
    all_bar = All(False)
    assert str(all_foo) == 'All[value=True]'
    assert str(all_bar) == 'All[value=False]'


# Generated at 2022-06-24 00:31:59.509636
# Unit test for constructor of class All
def test_All():
    assert All(True).value is True


# Generated at 2022-06-24 00:32:04.184732
# Unit test for constructor of class All
def test_All():
    assert All("0")
    assert All("false")
    assert All("False")
    assert All("")
    assert All([])
    assert not All("ABC")
    assert not All("true")
    assert not All("True")
    assert not All("0.0")
    assert not All(0)
    assert not All(0.0)
    assert not All([0])
    assert not All(False)



# Generated at 2022-06-24 00:32:05.326055
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(2)) == 'Sum[value=2]'


# Generated at 2022-06-24 00:32:15.188014
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x + 1) == 2
    assert All(True).fold(lambda x: x and True)
    assert One(True).fold(lambda x: x or False) is True
    assert First(1).fold(lambda x: x + 1) == 2
    assert Last(1).fold(lambda x: x + 1) == 2
    assert Map({1: 1}).fold(lambda x: {k: v + 1 for k, v in x.items()}) == {1: 2}
    assert Max(1).fold(lambda x: max(x, 0)) == 1
    assert Min(1).fold(lambda x: min(x, 0)) == 0



# Generated at 2022-06-24 00:32:16.820333
# Unit test for method concat of class First
def test_First_concat():
    first = First('a')

    first_concat_first = first.concat(First('b'))

    assert first_concat_first == First('a')



# Generated at 2022-06-24 00:32:20.263080
# Unit test for method __str__ of class Min
def test_Min___str__():
    # arrange
    number = 10
    min10 = Min(number)
    expected = 'Min[value={}]'.format(number)

    # act
    actual = str(min10)

    # assert
    assert actual == expected



# Generated at 2022-06-24 00:32:23.020860
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    # arrange
    expected = Sum(0)

    # act
    actual = Sum(0)

    # assert
    assert expected == actual



# Generated at 2022-06-24 00:32:27.255731
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value is True
    assert All(True).concat(All(False)).value is False
    assert All(False).concat(All(True)).value is False
    assert All(False).concat(All(False)).value is False



# Generated at 2022-06-24 00:32:30.028430
# Unit test for constructor of class Max
def test_Max():
    sum = Sum(1)
    value = sum.concat(Sum(2))
    assert value == Sum(3)

# Generated at 2022-06-24 00:32:37.612842
# Unit test for constructor of class Map
def test_Map():
    _ = Map
    assert Map({}).value == {}
    assert Map({'key': 'value'}).value == {'key': 'value'}
    assert Map({
        'key1': 'value1',
        'key2': 'value2'
    }).value == {
        'key1': 'value1',
        'key2': 'value2'
    }
    assert Map({
        'key1': 'value1',
        'key2': {
            'key3': 'value3'
        }
    }).value == {
        'key1': 'value1',
        'key2': {
            'key3': 'value3'
        }
    }

# Generated at 2022-06-24 00:32:42.354528
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(True).concat(One(True)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-24 00:32:46.930147
# Unit test for method concat of class Max
def test_Max_concat():
    # First value is bigger
    assert Max(10).concat(Max(9)) == Max(10)
    # Second value is bigger
    assert Max(8).concat(Max(9)) == Max(9)
    # Two values are equal
    assert Max(10).concat(Max(10)) == Max(10)


# Generated at 2022-06-24 00:32:52.973280
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    with pytest.raises(Exception) as e_info:
        Semigroup()

    with pytest.raises(Exception) as e_info:
        Semigroup(1, 2)

    assert Semigroup(1).value == 1


# Generated at 2022-06-24 00:32:53.969403
# Unit test for method concat of class Min
def test_Min_concat():
    min = Min(4)
    min2 = Min(5)
    assert min.concat(min2) == Min(4)


# Generated at 2022-06-24 00:32:54.454586
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(3).value == 3



# Generated at 2022-06-24 00:32:56.545822
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-24 00:33:01.016834
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert All(True).fold(lambda value: not value) is False
    assert Last(42).fold(lambda value: value + 1) == 43
    assert Min(5).fold(lambda value: value + 3) == 8

# Generated at 2022-06-24 00:33:06.661721
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    """
    Test for method concat of class All
    """
    assert All(True).concat(All(True)).equals(All(True))
    assert not All(True).concat(All(False)).equals(All(True))
    assert not All(False).concat(All(True)).equals(All(True))
    assert not All(False).concat(All(False)).equals(All(True))


# Generated at 2022-06-24 00:33:08.593732
# Unit test for constructor of class Last
def test_Last():
    actual = Last(3)
    expected = Last(3)
    assert actual == expected


# Generated at 2022-06-24 00:33:14.264807
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert All(True).fold(lambda x: True)

    assert First(2).fold(lambda x: True)

    assert Max(2).fold(lambda x: True)

    assert Min(2).fold(lambda x: True)

    assert Map({1: Sum(2), 2: Sum(3)}).fold(lambda x: {1: 2, 2: 3}) == {1: 2, 2: 3}

    assert One(True).fold(lambda x: True)

    assert Last(2).fold(lambda x: True)

    assert Sum(2).fold(lambda x: x) == 2


# Generated at 2022-06-24 00:33:17.315638
# Unit test for method concat of class One
def test_One_concat():
    x = One(21)
    y = One(32)
    assert x.concat(y).value == 32



# Generated at 2022-06-24 00:33:21.602460
# Unit test for constructor of class First
def test_First():
    assert First(None)
    assert First(1)
    assert First(True)
    assert First(False)
    assert First('string')
    assert First(['one', 'two', 'three'])
    assert First((1, 2, 3, 4))
    assert First({'key1': 1, 'key2': 2, 'key3': 3})



# Generated at 2022-06-24 00:33:24.441679
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(One)



# Generated at 2022-06-24 00:33:27.222629
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1)})) == "Map[value={'a': Sum[value=1]}]"


# Generated at 2022-06-24 00:33:29.428522
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-24 00:33:32.336465
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(42)) == "Max[value=42]"
    assert str(Max(0)) == "Max[value=0]"


# Generated at 2022-06-24 00:33:34.990575
# Unit test for constructor of class Sum
def test_Sum():
    """
    test_Sum is function to test Sum neutral constructor
    """
    assert Sum(1) == Sum(1)
    assert Sum(2) != Sum(1)



# Generated at 2022-06-24 00:33:36.269260
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert "Last(value=1)" == str(Last(1))


# Generated at 2022-06-24 00:33:39.077724
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(0) == Sum.neutral()
    assert Sum(0).value == 0
    assert Sum(1).value == 1
    assert Sum(0) == Sum(0)
    assert Sum(1) != Sum(0)


# Generated at 2022-06-24 00:33:41.565211
# Unit test for method __str__ of class Last
def test_Last___str__():
    last = Last(5)
    assert str(last) == 'Last[value=5]'



# Generated at 2022-06-24 00:33:46.917760
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)


# Generated at 2022-06-24 00:33:47.924115
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'
    assert str(Min(2)) == 'Min[value=2]'


# Generated at 2022-06-24 00:33:49.889013
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert Min(2).__str__() == 'Min[value=2]'



# Generated at 2022-06-24 00:33:51.424745
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(True)) == "Fist[value=True]"


# Generated at 2022-06-24 00:33:53.719336
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1)})) == 'Map[value={\'a\': Sum[value=1]}]'


# Generated at 2022-06-24 00:33:55.096132
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'



# Generated at 2022-06-24 00:34:01.100771
# Unit test for constructor of class Max
def test_Max():
    assert Max(2).value == 2
    assert Max('abc').value == 'abc'
    assert Max([1, 2, 3]).value == [1, 2, 3]
    assert Max({1: 1, 2: 2, 3: 3}).value == {1: 1, 2: 2, 3: 3}


# Generated at 2022-06-24 00:34:05.553733
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(2) != First(1)

# Generated at 2022-06-24 00:34:10.608959
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(None) == Semigroup(None)
    assert not Semigroup(1) == Semigroup(2)
    assert not Semigroup(1) == Semigroup(None)
    assert not Semigroup(None) == Semigroup(1)
    assert not Semigroup(1) == Semigroup('1')


# Generated at 2022-06-24 00:34:13.686935
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert First(1) != 1



# Generated at 2022-06-24 00:34:15.054727
# Unit test for constructor of class Min
def test_Min():
    assert Min(10).value == 10


# Generated at 2022-06-24 00:34:18.269438
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True
    assert One(False).value != True
    assert One(1).value == True
    assert One(0).value != True
    assert One('').value == False
    assert One('hello').value != False


# Generated at 2022-06-24 00:34:20.495571
# Unit test for constructor of class Map
def test_Map():
    assert Map({'x': Sum(1), 'y': First(1)}).value == {'x': Sum(1), 'y': First(1)}


# Generated at 2022-06-24 00:34:25.347178
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a':Sum(1), 'b':Sum(2)}) == Map({'a':Sum(1), 'b':Sum(2)})


# Generated at 2022-06-24 00:34:26.927740
# Unit test for constructor of class Last
def test_Last():
    test = Last(1)
    assert type(test) == Last
    assert test.value == 1


# Generated at 2022-06-24 00:34:30.071064
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(0).concat(Min(-1)) == Min(-1)
    assert Min(3).concat(Min(3)) == Min(3)
    assert Min(1).concat(Min(3)) == Min(1)
    assert Min(3).concat(Min(1)) == Min(1)



# Generated at 2022-06-24 00:34:31.600642
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)


# Generated at 2022-06-24 00:34:33.855044
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(10).concat(Max(15)) == Max(15)
    assert Max(10).concat(Max(5)) == Max(10)


# Generated at 2022-06-24 00:34:38.066847
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(True)) == All(False)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-24 00:34:39.571390
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(0)) == 'Sum[value=0]'



# Generated at 2022-06-24 00:34:41.177165
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'



# Generated at 2022-06-24 00:34:44.061029
# Unit test for method concat of class Max
def test_Max_concat(): 
    assert Max(1).concat(Max(2)).value == 2
    assert Max(-1).concat(Max(-2)).value == -1



# Generated at 2022-06-24 00:34:45.972963
# Unit test for method concat of class Last
def test_Last_concat():  # pragma: no cover
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-24 00:34:49.461755
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(4).concat(Last(5)) == Last(5)
    assert Last(4).concat(Last(1)) == Last(1)
    assert Last(4).concat(Last(4)) == Last(4)


# Generated at 2022-06-24 00:34:50.942999
# Unit test for constructor of class Map
def test_Map():
    assert Map({"test": Min(2)}).value == {"test": Min(2)}



# Generated at 2022-06-24 00:34:54.457276
# Unit test for constructor of class Max
def test_Max():
    """
    Unit test for constructor of class Max.
    """
    assert Max(12) == Max(12)
    assert Max(12) != Max(11)
    assert str(Max(12)) == "Max[value=12]"


# Generated at 2022-06-24 00:34:58.228970
# Unit test for method __str__ of class All
def test_All___str__():
    assert 'All[value={}]'.format(True) == str(All(True))
    assert 'All[value={}]'.format(False) == str(All(False))
    assert 'All[value={}]'.format(True) == str(All.neutral())


# Generated at 2022-06-24 00:35:02.086823
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    # True
    assert Semigroup(True).fold(lambda x : x) == True

    # int
    assert Semigroup(1).fold(lambda x : x) == 1

    # String
    assert Semigroup('hello').fold(lambda x : x) == 'hello'

    # List
    assert Semigroup([1,2,3]).fold(lambda x : x) == [1,2,3]



# Generated at 2022-06-24 00:35:05.426027
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    assert Semigroup.neutral() == Semigroup.neutral_element


# Unit tests for class Sum

# Generated at 2022-06-24 00:35:07.991582
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    max_test = Max(10)
    assert (str(max_test) == 'Max[value=10]')


# Generated at 2022-06-24 00:35:10.434454
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(0).__eq__(Semigroup(0))
    assert not Semigroup(1).__eq__(Semigroup(0))


# Generated at 2022-06-24 00:35:11.236400
# Unit test for constructor of class Min
def test_Min():
    min = Min(0)
    assert min == Min(0)


# Generated at 2022-06-24 00:35:11.817848
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(3).value == 3



# Generated at 2022-06-24 00:35:13.051094
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-24 00:35:14.747780
# Unit test for method __str__ of class One
def test_One___str__():
    X = One(True)
    assert X.__str__() == 'One[value=True]'

    X = One(False)
    assert X.__str__() == 'One[value=False]'



# Generated at 2022-06-24 00:35:25.277938
# Unit test for constructor of class Map
def test_Map():
    object_map1 = Map({"a":Sum(5),"b":Sum(5),"c":Sum(5)})   # create a Map object
    object_map2 = Map({"a":Sum(2),"b":Sum(2),"c":Sum(2)})   # create a Map object

    object_map3 = object_map1.concat(object_map2)        # concatenate 2 maps
    assert object_map3.fold(lambda x: x["a"].value == 7) # test for concatenate 2 maps
    assert object_map3.fold(lambda x: x["b"].value == 7) # test for concatenate 2 maps
    assert object_map3.fold(lambda x: x["c"].value == 7) # test for concatenate 2 maps
    print(object_map3)                                   # print

# Generated at 2022-06-24 00:35:26.742201
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(3).concat(Max(2)) == Max(3)


# Generated at 2022-06-24 00:35:28.717264
# Unit test for constructor of class Min
def test_Min():
    assert Min(1).value == 1
    assert Min(0).value == 0



# Generated at 2022-06-24 00:35:29.910923
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)



# Generated at 2022-06-24 00:35:32.561247
# Unit test for method concat of class Sum
def test_Sum_concat():  # pragma: no cover
    assert Sum(1).concat(Sum(1)) == Sum(2)
    assert Sum(3).concat(Sum(4)) == Sum(7)
    assert Sum(5).concat(Sum(3)) == Sum(8)


# Generated at 2022-06-24 00:35:36.265145
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1
    assert Sum(2).value == 2


# Generated at 2022-06-24 00:35:39.594384
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(3).concat(Sum(5)) == Sum(8)
    assert Sum(10).concat(Sum(2)) == Sum(12)



# Generated at 2022-06-24 00:35:42.524486
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(Two(True)) == Two(True)


# Generated at 2022-06-24 00:35:45.089018
# Unit test for constructor of class Map
def test_Map():
    assert Map({0: Sum(1), 1: Sum(2)}).__eq__(Map({0: Sum(1), 1: Sum(2)}))


# Generated at 2022-06-24 00:35:46.651304
# Unit test for constructor of class Last
def test_Last():
    l = Last(1)
    assert(l.value == 1)



# Generated at 2022-06-24 00:35:55.161290
# Unit test for method concat of class One
def test_One_concat():
    x = One(True)
    y = One(False)
    z = One(True)
    assert x.concat(y).value == True
    assert x.concat(y).concat(z).value == True
    assert y.concat(x).concat(z).value == True
    assert y.concat(z).concat(x).value == True
    assert z.concat(x).concat(y).value == True
    assert z.concat(y).concat(x).value == True

# Generated at 2022-06-24 00:35:58.052638
# Unit test for constructor of class Sum
def test_Sum():
    x = Sum(1)
    y = Sum(3)
    assert x.value == 1
    assert isinstance(x, Sum)
    assert y.value == 3
    assert isinstance(y, Sum)



# Generated at 2022-06-24 00:35:58.890925
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(2) == Sum(2)

# Generated at 2022-06-24 00:36:09.230862
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():

    assert First("awesome").fold(str) == "awesome"
    assert First("awesome").fold(int) == 0
    assert First("awesome").fold(bool) is True
    assert First("awesome").fold(Sum).value == 0
    assert First("awesome").fold(All).value is True
    assert First("awesome").fold(One).value is True

    assert Last("awesome").fold(str) == "awesome"
    assert Last("awesome").fold(int) == 0
    assert Last("awesome").fold(bool) is True
    assert Last("awesome").fold(Sum).value == 0
    assert Last("awesome").fold(All).value is True
    assert Last("awesome").fold(One).value is True

    assert Sum(4).fold(str) == "4"

# Generated at 2022-06-24 00:36:10.285698
# Unit test for constructor of class First
def test_First():
    assert First('a')


# Generated at 2022-06-24 00:36:14.897964
# Unit test for method concat of class One
def test_One_concat():
    """
    >>> One(True).concat(One(False))
    One[value=True]
    >>> One(True).concat(One(True))
    One[value=True]
    >>> One(False).concat(One(False))
    One[value=False]
    >>> One(False).concat(One(True))
    One[value=True]
    >>>
    """
    pass



# Generated at 2022-06-24 00:36:15.629201
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(5)) == 'Max[value=5]'



# Generated at 2022-06-24 00:36:21.343524
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(False)) == 'All[value=False]'
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-24 00:36:25.688753
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(3) == Sum(3)



# Generated at 2022-06-24 00:36:26.561336
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True


# Generated at 2022-06-24 00:36:28.748893
# Unit test for method concat of class First
def test_First_concat():
    first = First(56)
    second = First(45)
    assert first.concat(second).value == 56



# Generated at 2022-06-24 00:36:30.360540
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-24 00:36:32.160522
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First("bla")) == 'Fist[value=bla]'


# Generated at 2022-06-24 00:36:36.068524
# Unit test for method __str__ of class One
def test_One___str__():
    """
    Unit test for method __str__ of class One
    """
    n1 = One(False)
    assert str(n1) == "One[value=False]", "test__str__ of One fail"


# Generated at 2022-06-24 00:36:36.601810
# Unit test for constructor of class Sum
def test_Sum():
  assert Sum(1).value == 1


# Generated at 2022-06-24 00:36:39.413689
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({"a": Sum(1), "b": Sum(2)})
    m2 = Map({"a": Sum(3), "b": Sum(4)})
    m3 = m1.concat(m2)
    assert m3.value == {'a': Sum(4), 'b': Sum(6)}
    print('Map concat() testing is OK')


# Generated at 2022-06-24 00:36:42.837607
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(4)) == Min(1)
    assert Min(1).concat(Min(0)) == Min(0)
    assert Min(-3).concat(Min(-2)) == Min(-3)
    assert Min(-3).concat(Min(0)) == Min(-3)
    assert Min(-3).concat(Min(-10)) == Min(-10)

# Generated at 2022-06-24 00:36:44.568354
# Unit test for method __str__ of class All
def test_All___str__(): # pragma: no cover
    assert str(All(1)) == "All[value=1]"


# Generated at 2022-06-24 00:36:50.201118
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert isinstance(Semigroup(list()), Semigroup)
    assert Semigroup(list()) == Semigroup(list())
    assert not Semigroup(list()) != Semigroup(list())
    assert Semigroup(list()).fold(list) == list()
    assert Semigroup.neutral().value == Semigroup.neutral_element



# Generated at 2022-06-24 00:36:54.838227
# Unit test for method concat of class One
def test_One_concat():
    """
    Tests for the One concat function
    """
    assert One(True).concat(One(True)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(False)) == One(False)



# Generated at 2022-06-24 00:36:55.887697
# Unit test for constructor of class First
def test_First():
    assert First('first') == First('first')


# Generated at 2022-06-24 00:36:59.302135
# Unit test for constructor of class Last
def test_Last():
    actual = Last(1)
    expected = Last(1)
    assert actual == expected



# Generated at 2022-06-24 00:37:00.449511
# Unit test for constructor of class One
def test_One():
    assert One(True).value is True


# Generated at 2022-06-24 00:37:02.886249
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: 2 * x) == 2
    assert All(True).fold(lambda x: not x) == False


# Generated at 2022-06-24 00:37:04.298360
# Unit test for constructor of class Sum
def test_Sum():
    s = Sum(1)
    assert str(s) == 'Sum[value=1]'


# Generated at 2022-06-24 00:37:06.622603
# Unit test for constructor of class Map
def test_Map():
    assert Map({"A": Sum(1), "B": Sum(2)}).value == {"A": Sum(1), "B": Sum(2)}


# Generated at 2022-06-24 00:37:10.994887
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(7).concat(Max(6)) == Max(7)
    assert Max(6).concat(Max(7)) == Max(7)
    assert Max(1).concat(Max(2)).concat(Max(3)) == Max(3)


# Generated at 2022-06-24 00:37:12.717881
# Unit test for constructor of class First
def test_First():
    """
    Test the constructor of class First
    """
    assert First(5) == First(5)
    assert First(5) == First(6)


# Generated at 2022-06-24 00:37:14.252142
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-24 00:37:15.066794
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == "Fist[value=1]"


# Generated at 2022-06-24 00:37:18.390520
# Unit test for method concat of class Min
def test_Min_concat():
    # Arrange
    min1 = Min(1)
    min2 = Min(2)

    # Act
    result = min1.concat(min2)

    # Assert
    assert result.value == min1.value

# Generated at 2022-06-24 00:37:19.342469
# Unit test for constructor of class Max
def test_Max():
    result = Max(1)
    assert result.value == 1


# Generated at 2022-06-24 00:37:23.781250
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)).value == 1
    assert First(2).concat(First(1)).value == 1
    assert First(2).concat(First(2)).value == 2
    assert First(1).concat(First(1)).value == 1



# Generated at 2022-06-24 00:37:25.898588
# Unit test for method __str__ of class Map
def test_Map___str__():
    p = Map({'a': First(1)})
    assert str(p) == "Map[value={'a': Fist[value=1]}]"

# Generated at 2022-06-24 00:37:29.340939
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    sum_a = Sum(1)
    sum_a_duplicate = Sum(1)
    sum_b = Sum(2)

    assert sum_a == sum_a_duplicate
    assert not sum_a == sum_b


# Generated at 2022-06-24 00:37:31.386645
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    Test case for class Semigroup constructor
    """
    singroup = Semigroup(10)
    assert singroup.value == 10



# Generated at 2022-06-24 00:37:32.632875
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'



# Generated at 2022-06-24 00:37:34.665754
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)


# Generated at 2022-06-24 00:37:36.640932
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"


# Generated at 2022-06-24 00:37:40.852691
# Unit test for constructor of class First
def test_First():
    """
    test for First
    """
    first = First(10)
    assert first.value == 10



# Generated at 2022-06-24 00:37:44.189558
# Unit test for method concat of class One
def test_One_concat():
    one = One(False)
    any = one.concat(One(False))
    any1 = one.concat(One(True))
    assert Any(False) == any
    assert Any(True) == any1


# Generated at 2022-06-24 00:37:46.695686
# Unit test for constructor of class Sum
def test_Sum():
    """
    Test constructor of Sum
    """
    assert Sum(1).value == 1



# Generated at 2022-06-24 00:37:50.940472
# Unit test for method concat of class Map
def test_Map_concat():
    test_map_1 = Map({'first_key': Sum(4), 'second_key': Sum(6)})
    test_map_2 = Map({'first_key': Sum(2), 'second_key': Sum(3)})
    assert test_map_1.concat(test_map_2) == Map({'first_key': Sum(6), 'second_key': Sum(9)})

# Generated at 2022-06-24 00:37:54.864249
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(2).concat(Max(10)) == Max(10)
    assert Max(10).concat(Max(2)) == Max(10)
    assert Max(2).concat(Max(2)) == Max(2)
    assert Max(10).concat(Max(10)) == Max(10)



# Generated at 2022-06-24 00:37:58.797075
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert Sum(1).__str__() == 'Sum[value=1]'
    assert Sum(2).__str__() == 'Sum[value=2]'
    assert Sum(3).__str__() == 'Sum[value=3]'


# Generated at 2022-06-24 00:38:00.213741
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True) != All(False)



# Generated at 2022-06-24 00:38:06.831779
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(1)) == Sum(2)
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(2).concat(Sum(1)) == Sum(3)


# Generated at 2022-06-24 00:38:12.043411
# Unit test for method __str__ of class Map
def test_Map___str__():
    # Arrange
    map_ = Map({
        1: Sum(100),
        2: Sum(500),
        3: Sum(1000),
    })

    # Act
    result = str(map_)

    # Assert
    assert result == 'Map[value={1: Sum[value=100], 2: Sum[value=500], 3: Sum[value=1000]}]'


# Generated at 2022-06-24 00:38:15.965092
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(5) == Sum(5)
    assert Sum(5) != Sum(6)
    assert Sum(5).fold(lambda value: value) == 5


# Generated at 2022-06-24 00:38:23.083545
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1).fold(lambda v: v + 1) == 2
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(2)) != Sum(4)
    assert str(Sum(1)) == "Sum[value=1]"
    assert repr(Sum(1)) == "Sum[value=1]"


# Generated at 2022-06-24 00:38:24.360666
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == "Last[value=1]"


# Generated at 2022-06-24 00:38:27.498994
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    result = Sum(1) == Sum(1)

    expected = True

    assert result == expected, 'Expected: {}, instead got: {}'.format(
        expected, result)



# Generated at 2022-06-24 00:38:29.953293
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    return 'test_Semigroup passed!'



# Generated at 2022-06-24 00:38:31.600616
# Unit test for constructor of class Min
def test_Min():
    min = Min(1)
    assert min.value == 1, "Should have min value 1"


# Generated at 2022-06-24 00:38:33.832442
# Unit test for method concat of class One
def test_One_concat():
    one_1 = One(True)
    one_2 = One(False)

    assert one_1.concat(one_2).value is True
    assert one_2.concat(one_1).value is True


# Generated at 2022-06-24 00:38:44.153694
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    :returns: True if all test case succeed
    :rtype: bool
    """
    def f(x):
        return x

    true = All(True).fold(f)
    false = All(False).fold(f)
    assert(true is True)
    assert(false is False)

    I = First('I').fold(f)
    U = Last('U').fold(f)
    assert(I == 'I')
    assert(U == 'U')

    c1 = Sum(1).fold(f)
    c2 = Sum(2).fold(f)
    assert(c1 == 1)
    assert(c2 == 2)

    m1 = Max(1).fold(f)
    m2 = Max(2).fold(f)
    assert(m1 == 1)

# Generated at 2022-06-24 00:38:47.647845
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)


# Generated at 2022-06-24 00:38:54.328874
# Unit test for method concat of class All
def test_All_concat():
    """
    Test for concat method of class All.
    """
    assert All(False).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(True).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)



# Generated at 2022-06-24 00:38:56.847378
# Unit test for constructor of class Min
def test_Min():
    assert Min(10) == Min(10)
    assert Min(10) != Min(11)



# Generated at 2022-06-24 00:38:59.790645
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_class_instance_1 = Sum(1)
    sum_class_instance_2 = Sum(2)
    sum_class_instance_3 = Sum(3)
    sum_class_concat_value = sum_class_instance_1.concat(sum_class_instance_2).concat(sum_class_instance_3)
    assert sum_class_concat_value.value == 6

# Generated at 2022-06-24 00:39:06.105626
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(True).value is True
    assert One(False).value is False
    assert One(False).concat(One(True)).value is True
    assert One(True).concat(One(False)).value is True
    assert One(False).concat(One(False)).value is False


# Generated at 2022-06-24 00:39:07.335370
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)


# Generated at 2022-06-24 00:39:12.391013
# Unit test for method concat of class One
def test_One_concat():
    one1 = One(True)
    one2 = One(False)

    assert one1.concat(one2) == One(True)
    assert one2.concat(one1) == One(True)


# Generated at 2022-06-24 00:39:16.326270
# Unit test for method concat of class Last
def test_Last_concat():
    """
    Test for Last.concat method
    """
    assert Last([10, 20]).concat(Last([30])).value == [10, 20, 30]
    assert Last(30).concat(Last(40)).value == 40
    assert Last('last').concat(Last('value')).value == 'value'



# Generated at 2022-06-24 00:39:18.609308
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert Sum(0).__str__() == 'Sum[value=0]'
    assert Sum(1).__str__() == 'Sum[value=1]'


# Generated at 2022-06-24 00:39:22.552823
# Unit test for constructor of class One
def test_One():
    """
    :return: True if input value is same as output value
    :rtype: bool
    """
    assert One(True) == One(True)
    assert One(False) == One(False)



# Generated at 2022-06-24 00:39:24.737830
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert All(True) == All(True)
    assert not All(True) == All(False)
    assert Last(10) == Last(10)
    assert not Last(10) == Last(11)


# Generated at 2022-06-24 00:39:26.635393
# Unit test for constructor of class Semigroup
def test_Semigroup():
    # semigroup = Semigroup(10)
    # assert semigroup.value == 10
    assert True

# Generated at 2022-06-24 00:39:28.626728
# Unit test for constructor of class All
def test_All():
    a = All(True)
    assert a.value == True, "All(True).value is not True."



# Generated at 2022-06-24 00:39:33.755384
# Unit test for method concat of class First
def test_First_concat():  # pragma: no cover
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(None).concat(First(None)) == First(None)


# Generated at 2022-06-24 00:39:38.650208
# Unit test for constructor of class Semigroup
def test_Semigroup():
    sum = Sum(1)
    assert sum.value == 1
    assert sum.fold(identity) == 1



# Generated at 2022-06-24 00:39:41.911360
# Unit test for method concat of class Sum
def test_Sum_concat():
    v1 = Sum(1)
    v2 = Sum(2)
    assert v1.concat(v2) == Sum(3)
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-24 00:39:46.025711
# Unit test for constructor of class Min
def test_Min():
    """
    NOTE: This test is an example and will not generally pass because of rounding issues.
    The author is choosing to leave it in, nonetheless, as a reminder.
    """

    assert Min(0.1 + 0.3).value == 0.3



# Generated at 2022-06-24 00:39:50.534217
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(5).fold(lambda x: x * x) == 25
    assert Semigroup("hello").fold(lambda x: x + " world") == "hello world"



# Generated at 2022-06-24 00:39:52.731351
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(1)}).value == {'a': Sum(1), 'b': Sum(1)}



# Generated at 2022-06-24 00:39:54.776456
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'


# Generated at 2022-06-24 00:39:58.669310
# Unit test for constructor of class Max
def test_Max():
    assert Max(5) == Max(5)
    assert Max(5).concat(Max(10)) == Max(10)
    
    assert isinstance(Max(10), Max)


# Generated at 2022-06-24 00:40:03.028451
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).concat(One(2)).value == 1
    assert One(0).concat(One(2)).value == 2
    assert One(0).concat(One(0)).value == 0
    assert One(0).concat(One(1)).value == 1



# Generated at 2022-06-24 00:40:07.148579
# Unit test for method concat of class One
def test_One_concat():
    # test concat method from class One
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)



# Generated at 2022-06-24 00:40:12.344258
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(1)) == Sum(2)
    assert Sum(2).concat(Sum(1)) == Sum(3)
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-24 00:40:14.921958
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-24 00:40:18.952331
# Unit test for method concat of class Map
def test_Map_concat():
    map_a = Map({"a": First(1), "b": First(2)})
    map_b = Map({"a": First(3), "b": First(4)})
    expected_map = Map({"a": First(1), "b": First(4)})
    assert map_a.concat(map_b) == expected_map



# Generated at 2022-06-24 00:40:20.128106
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-24 00:40:22.155671
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    """
    Test method __str__ of class Sum
    """
    assert str(Sum(0)) == 'Sum[value=0]'


# Generated at 2022-06-24 00:40:23.522987
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-24 00:40:26.730469
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First(1)) == 'Fist[value=1]'  # pragma: no cover


# Generated at 2022-06-24 00:40:34.450639
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum.neutral().fold(lambda value: value) == 0
    assert All.neutral().fold(lambda value: value) == True
    assert One.neutral().fold(lambda value: value) == False
    assert First(1).fold(lambda value: value) == 1
    assert Last(1).fold(lambda value: value) == 1
    assert Map({}).fold(lambda value: value) == {}
    assert Max.neutral().fold(lambda value: value) == -float("inf")
    assert Min.neutral().fold(lambda value: value) == float("inf")

# Generated at 2022-06-24 00:40:37.466680
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(2) == Semigroup(1)


# Generated at 2022-06-24 00:40:39.025981
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    number = Sum(1)
    assert str(number) == 'Sum[value=1]'


# Generated at 2022-06-24 00:40:45.240774
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert 'Last[value=10]' == str(Last(10))
    assert 'Last[value=None]' == str(Last(None))
    assert 'Last[value=last]' == str(Last('last'))



# Generated at 2022-06-24 00:40:47.271941
# Unit test for method concat of class One
def test_One_concat():
    assert One('world').concat(One('hello')) == One('world')



# Generated at 2022-06-24 00:40:49.987930
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert (Sum(1).concat(Sum(2)).fold(lambda x: x)) == 3



# Generated at 2022-06-24 00:40:51.583628
# Unit test for method __str__ of class Min
def test_Min___str__():  # pragma: no cover
    assert str(Min(2)) == 'Min[value=2]'



# Generated at 2022-06-24 00:40:55.568045
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-24 00:40:59.560733
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Unit test for method fold of class Semigroup
    """

    assert Semigroup(10).fold(lambda x: x * 10) == 100



# Generated at 2022-06-24 00:41:01.227115
# Unit test for method __str__ of class Max
def test_Max___str__():
    _max = Max(10)
    assert str(_max) == 'Max[value=10]'



# Generated at 2022-06-24 00:41:03.733092
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    Sum(1).fold(print)  # Output: 1
    Sum(1).fold(lambda x: x + 2)  # Output: 3



# Generated at 2022-06-24 00:41:06.631400
# Unit test for method __str__ of class Max
def test_Max___str__(): # pragma: no cover
    expected = 'Max[value=100]'
    actual = str(Max(100))
    assert expected == actual, 'Expected {} and got {}'.format(expected, actual)


# Generated at 2022-06-24 00:41:13.980958
# Unit test for method concat of class Map
def test_Map_concat():
    """
    >>> test_Map_concat()
    Map[value={'value': Sum[value=3], 'other': Sum[value=4]}]
    """
    print(
        Map({'value': Sum(1)}).concat(
            Map({'value': Sum(2), 'other': Sum(3)})
        ).concat(
            Map(
                {
                    'value': Sum(-2),
                    'other': Sum(1)
                }
            )
        )
    )

# Generated at 2022-06-24 00:41:17.573162
# Unit test for method concat of class First
def test_First_concat():
    # is_deeply(First(2).concat(First(1)), First(2), 'First.concat() should return the first value')
    assert First(2).concat(First(1)) == First(2), 'First.concat() should return the first value'


# Generated at 2022-06-24 00:41:21.692596
# Unit test for method __str__ of class Map
def test_Map___str__():
    test_Map = Map({'name': 'Sam', 'lastname': 'Sparrow'})
    assert test_Map.__str__() == 'Map[value={\'name\': \'Sam\', \'lastname\': \'Sparrow\'}]'

# Generated at 2022-06-24 00:41:26.654223
# Unit test for method concat of class First
def test_First_concat():
    """
    :return: True if method concat of class First returns a new instance of First
    :rtype: bool
    """
    first_instance = First(0)
    second_instance = First(1)
    new_semigroup = first_instance.concat(second_instance)
    return isinstance(new_semigroup, First)

# Generated at 2022-06-24 00:41:27.796476
# Unit test for constructor of class Max
def test_Max():  # pragma: no cover
    assert Max(3) == Max(3)



# Generated at 2022-06-24 00:41:30.318655
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(True).concat(One(True)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)



# Generated at 2022-06-24 00:41:31.368224
# Unit test for method __str__ of class First
def test_First___str__():
    assert First("foo").__str__() == "Fist[value=foo]"

