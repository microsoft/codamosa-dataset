

# Generated at 2022-06-18 01:53:30.769519
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:53:37.742302
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(6)})
    assert Map({'a': All(True), 'b': All(False)}).concat(Map({'a': All(True), 'b': All(True)})) == Map({'a': All(True), 'b': All(False)})
    assert Map({'a': One(True), 'b': One(False)}).concat(Map({'a': One(True), 'b': One(True)})) == Map({'a': One(True), 'b': One(True)})

# Generated at 2022-06-18 01:53:41.517541
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(6)})


# Generated at 2022-06-18 01:53:49.297081
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(6)})
    assert Map({'a': All(True), 'b': All(False)}).concat(Map({'a': All(False), 'b': All(True)})) == Map({'a': All(False), 'b': All(False)})
    assert Map({'a': One(True), 'b': One(False)}).concat(Map({'a': One(False), 'b': One(True)})) == Map({'a': One(True), 'b': One(True)})

# Generated at 2022-06-18 01:53:52.945802
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:53:55.513415
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:54:00.852806
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)
    assert Max(2).concat(Max(1)) == Max(2)


# Generated at 2022-06-18 01:54:04.605926
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:54:08.112828
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:54:11.658628
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:54:16.716442
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:54:17.990189
# Unit test for constructor of class Sum
def test_Sum():
    sum_ = Sum(1)
    assert sum_.value == 1


# Generated at 2022-06-18 01:54:23.817157
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First(1) == First(1)
    assert Last(1) == Last(1)
    assert Map({1: Sum(1)}) == Map({1: Sum(1)})
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)



# Generated at 2022-06-18 01:54:28.429444
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:54:29.474494
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(1) != Max(2)


# Generated at 2022-06-18 01:54:30.780725
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-18 01:54:33.143941
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-18 01:54:34.732319
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-18 01:54:36.000769
# Unit test for constructor of class Min
def test_Min():
    assert Min(1).value == 1


# Generated at 2022-06-18 01:54:39.486623
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(6)})


# Generated at 2022-06-18 01:54:48.047315
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(2)).concat(Last(3)) == Last(3)
    assert Last(1).concat(Last(2)).concat(Last(3)).concat(Last(4)) == Last(4)
    assert Last(1).concat(Last(2)).concat(Last(3)).concat(Last(4)).concat(Last(5)) == Last(5)
    assert Last(1).concat(Last(2)).concat(Last(3)).concat(Last(4)).concat(Last(5)).concat(Last(6)) == Last(6)

# Generated at 2022-06-18 01:54:50.641905
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-18 01:54:53.502695
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1).value == 1
    assert Semigroup(1).fold(lambda x: x) == 1


# Generated at 2022-06-18 01:54:55.350835
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)


# Generated at 2022-06-18 01:55:06.714219
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(None).concat(First(None)) == First(None)
    assert First(1).concat(First(2)).concat(First(3)) == First(1)
    assert First(1).concat(First(2)).concat(First(None)) == First(1)
    assert First(1).concat(First(None)).concat(First(3)) == First(1)
    assert First(1).concat(First(None)).concat(First(None)) == First(1)

# Generated at 2022-06-18 01:55:10.308319
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(None).concat(First(None)) == First(None)


# Generated at 2022-06-18 01:55:14.884587
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(1)) == Last(1)
    assert Last(2).concat(Last(1)) == Last(1)
    assert Last(2).concat(Last(2)) == Last(2)


# Generated at 2022-06-18 01:55:25.800911
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert All(True) == All(True)
    assert All(True) != All(False)
    assert One(True) == One(True)
    assert One(True) != One(False)
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert Map({'a': Sum(1)}) == Map({'a': Sum(1)})
    assert Map({'a': Sum(1)}) != Map({'a': Sum(2)})
    assert Max(1) == Max(1)
    assert Max(1) != Max(2)

# Generated at 2022-06-18 01:55:35.783902
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1) != Semigroup('1')
    assert Semigroup(1) != Semigroup(True)
    assert Semigroup(1) != Semigroup(None)
    assert Semigroup(1) != Semigroup(object)
    assert Semigroup(1) != Semigroup(object())
    assert Semigroup(1) != Semigroup(Semigroup(1))
    assert Semigroup(1) != Semigroup(Sum(1))
    assert Semigroup(1) != Semigroup(All(1))
    assert Semigroup(1) != Semigroup(One(1))
    assert Semigroup(1) != Semigroup(First(1))
    assert Semigroup(1) != Semigroup(Last(1))
    assert Semigroup

# Generated at 2022-06-18 01:55:39.611449
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:55:45.133104
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-18 01:55:46.802915
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-18 01:55:48.769079
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(1) != Max(2)


# Generated at 2022-06-18 01:55:51.096720
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)


# Generated at 2022-06-18 01:55:52.844908
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)


# Generated at 2022-06-18 01:55:56.061873
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False
    assert All(1).value == True
    assert All(0).value == False
    assert All('').value == False
    assert All('a').value == True


# Generated at 2022-06-18 01:56:00.686769
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-18 01:56:03.224629
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert First(1) != First('1')


# Generated at 2022-06-18 01:56:05.688666
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)


# Generated at 2022-06-18 01:56:07.137088
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-18 01:56:13.044737
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == 'Map[value={\'a\': Sum[value=1], \'b\': Sum[value=2]}]'


# Generated at 2022-06-18 01:56:15.283040
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1).value == 1
    assert Semigroup(1).fold(lambda x: x) == 1


# Generated at 2022-06-18 01:56:16.450009
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-18 01:56:20.147075
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(None).concat(First(None)) == First(None)


# Generated at 2022-06-18 01:56:24.348446
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-18 01:56:25.307777
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1


# Generated at 2022-06-18 01:56:26.345916
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1


# Generated at 2022-06-18 01:56:27.404856
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-18 01:56:35.309635
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'
    assert str(One(None)) == 'One[value=None]'
    assert str(One(1)) == 'One[value=1]'
    assert str(One('1')) == 'One[value=1]'
    assert str(One(1.0)) == 'One[value=1.0]'
    assert str(One([])) == 'One[value=[]]'
    assert str(One(())) == 'One[value=()]'
    assert str(One({})) == 'One[value={}]'


# Generated at 2022-06-18 01:56:37.944331
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)
    assert not Semigroup(1) == 1


# Generated at 2022-06-18 01:56:54.504068
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    assert Semigroup(1).fold(lambda x: x - 1) == 0
    assert Semigroup(1).fold(lambda x: x * 2) == 2
    assert Semigroup(1).fold(lambda x: x / 2) == 0.5
    assert Semigroup(1).fold(lambda x: x ** 2) == 1
    assert Semigroup(1).fold(lambda x: x % 2) == 1
    assert Semigroup(1).fold(lambda x: x // 2) == 0
    assert Semigroup(1).fold(lambda x: x << 2) == 4
    assert Semigroup(1).fold(lambda x: x >> 2) == 0
    assert Semigroup(1).fold(lambda x: x & 2) == 0

# Generated at 2022-06-18 01:56:56.380488
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(1).value == 1


# Generated at 2022-06-18 01:56:57.821685
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-18 01:57:02.660116
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:57:04.148510
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 01:57:07.608526
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:57:11.045005
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:57:13.905091
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == 'Map[value={\'a\': Sum[value=1], \'b\': Sum[value=2]}]'


# Generated at 2022-06-18 01:57:18.367050
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert Last(1).value == 1
    assert Last(1).concat(Last(2)).value == 2
    assert Last(1).concat(Last(2)).concat(Last(3)).value == 3
    assert Last(1).concat(Last(2)).concat(Last(3)).concat(Last(4)).value == 4


# Generated at 2022-06-18 01:57:21.592057
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)


# Generated at 2022-06-18 01:57:45.118714
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)) == Sum(10)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)).concat(Sum(5)) == Sum(15)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)).concat(Sum(5)).concat(Sum(6)) == Sum(21)

# Generated at 2022-06-18 01:57:48.371574
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(None).concat(First(None)) == First(None)


# Generated at 2022-06-18 01:57:50.650887
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(1)) == Last(1)
    assert Last(2).concat(Last(1)) == Last(1)


# Generated at 2022-06-18 01:57:53.162536
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-18 01:57:54.338715
# Unit test for constructor of class Min
def test_Min():
    assert Min(1).value == 1


# Generated at 2022-06-18 01:57:56.093153
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)


# Generated at 2022-06-18 01:57:58.693366
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 01:57:59.464674
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-18 01:58:01.062468
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-18 01:58:09.085635
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x + 1) == 2
    assert All(True).fold(lambda x: not x) is False
    assert One(False).fold(lambda x: not x) is True
    assert First(1).fold(lambda x: x + 1) == 1
    assert Last(1).fold(lambda x: x + 1) == 2
    assert Max(1).fold(lambda x: x + 1) == 2
    assert Min(1).fold(lambda x: x + 1) == 1
    assert Map({'a': Sum(1)}).fold(lambda x: x['a'].value) == 1



# Generated at 2022-06-18 01:58:39.416740
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(2)}).value == {'a': Sum(1), 'b': Sum(2)}


# Generated at 2022-06-18 01:58:41.652686
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-18 01:58:43.195275
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1)})) == 'Map[value={\'a\': Sum[value=1]}]'


# Generated at 2022-06-18 01:58:44.543747
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-18 01:58:45.591335
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-18 01:58:49.392460
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1).value == 1
    assert Semigroup(1).fold(lambda x: x) == 1
    assert Semigroup.neutral().value == Semigroup.neutral_element


# Generated at 2022-06-18 01:58:52.842060
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)
    assert Min(1) != Min(2)
    assert Min(1).value == 1


# Generated at 2022-06-18 01:58:59.737842
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert First(1).value == 1
    assert First(1).concat(First(2)).value == 1
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(2)).concat(First(3)).value == 1
    assert First(1).concat(First(2)).concat(First(3)) == First(1)
    assert First(1).concat(First(2)).concat(First(3)).concat(First(4)).value == 1
    assert First(1).concat(First(2)).concat(First(3)).concat(First(4)) == First(1)
    assert First(1).concat(First(2)).concat

# Generated at 2022-06-18 01:59:02.650844
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(2)}).value == {'a': Sum(1), 'b': Sum(2)}


# Generated at 2022-06-18 01:59:04.294411
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-18 01:59:36.348630
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-18 01:59:37.579579
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 01:59:39.375420
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1


# Generated at 2022-06-18 01:59:41.480572
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)


# Generated at 2022-06-18 01:59:42.538784
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-18 01:59:45.617962
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == 'Map[value={\'a\': Sum[value=1], \'b\': Sum[value=2]}]'


# Generated at 2022-06-18 01:59:48.628436
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:59:52.136640
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:59:55.546968
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:59:57.914455
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-18 02:00:37.321197
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 02:00:40.294883
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: Sum(1), 2: Sum(2)})) == 'Map[value={1: Sum[value=1], 2: Sum[value=2]}]'


# Generated at 2022-06-18 02:00:42.324872
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-18 02:00:45.094842
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-18 02:00:47.251167
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)


# Generated at 2022-06-18 02:00:48.481173
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-18 02:00:51.819092
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(6)})

# Generated at 2022-06-18 02:00:55.971355
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-18 02:00:57.092735
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-18 02:00:58.140623
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-18 02:01:38.691951
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 02:01:42.516896
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(None).concat(First(None)) == First(None)



# Generated at 2022-06-18 02:01:44.192022
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(2)}).value == {'a': Sum(1), 'b': Sum(2)}


# Generated at 2022-06-18 02:01:45.103207
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-18 02:01:47.203069
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)


# Generated at 2022-06-18 02:01:48.712107
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1)})) == 'Map[value={\'a\': Sum[value=1]}]'


# Generated at 2022-06-18 02:01:52.831114
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 02:01:54.403294
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1
    assert Sum(2).value == 2
    assert Sum(3).value == 3


# Generated at 2022-06-18 02:01:58.553127
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)) == Sum(10)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)).concat(Sum(5)) == Sum(15)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)).concat(Sum(5)).concat(Sum(6)) == Sum(21)

# Generated at 2022-06-18 02:02:05.893106
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    assert Semigroup(1).fold(lambda x: x * 2) == 2
    assert Semigroup(1).fold(lambda x: x ** 2) == 1
    assert Semigroup(1).fold(lambda x: x ** 3) == 1
    assert Semigroup(1).fold(lambda x: x ** 4) == 1
    assert Semigroup(1).fold(lambda x: x ** 5) == 1
    assert Semigroup(1).fold(lambda x: x ** 6) == 1
    assert Semigroup(1).fold(lambda x: x ** 7) == 1
    assert Semigroup(1).fold(lambda x: x ** 8) == 1
    assert Semigroup(1).fold(lambda x: x ** 9) == 1

# Generated at 2022-06-18 02:03:12.345457
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)


# Generated at 2022-06-18 02:03:13.361877
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 02:03:14.124447
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-18 02:03:15.175164
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 02:03:17.419107
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1).value == 1
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1).fold(lambda x: x) == 1


# Generated at 2022-06-18 02:03:19.759336
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1).value == 1
    assert Semigroup(1).fold(lambda x: x) == 1


# Generated at 2022-06-18 02:03:21.613502
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 02:03:22.772823
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-18 02:03:29.160147
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(2)).concat(First(3)) == First(1)
    assert First(1).concat(First(2)).concat(First(3)).concat(First(4)) == First(1)
    assert First(1).concat(First(2)).concat(First(3)).concat(First(4)).concat(First(5)) == First(1)
