

# Generated at 2022-06-18 01:53:34.301378
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:53:37.626563
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).value == 1
    assert Min(2).concat(Min(1)).value == 1
    assert Min(1).concat(Min(1)).value == 1


# Generated at 2022-06-18 01:53:41.370229
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:53:43.331478
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)


# Generated at 2022-06-18 01:53:46.321649
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:53:50.941517
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:53:55.921075
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:54:00.077454
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:54:04.784110
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:54:08.287666
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:54:12.860091
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'



# Generated at 2022-06-18 01:54:18.217490
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert First(1).value == 1
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(2)).value == 1
    assert First(1).concat(First(2)).concat(First(3)) == First(1)
    assert First(1).concat(First(2)).concat(First(3)).value == 1


# Generated at 2022-06-18 01:54:20.448146
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-18 01:54:22.648591
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)


# Generated at 2022-06-18 01:54:23.992142
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-18 01:54:33.638453
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(2)).concat(First(3)) == First(1)
    assert First(1).concat(First(2)).concat(First(3)).concat(First(4)) == First(1)
    assert First(1).concat(First(2)).concat(First(3)).concat(First(4)).concat(First(5)) == First(1)
    assert First(1).concat(First(2)).concat(First(3)).concat(First(4)).concat(First(5)).concat(First(6)) == First(1)

# Generated at 2022-06-18 01:54:35.233269
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-18 01:54:44.886194
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).fold(lambda x: x) == 1
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)) == Sum(10)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)).concat(Sum(5)) == Sum(15)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)).concat(Sum(5)).concat(Sum(6))

# Generated at 2022-06-18 01:54:48.182958
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)) == Sum(10)


# Generated at 2022-06-18 01:54:57.269865
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True
    assert One(False).value == False
    assert One(1).value == True
    assert One(0).value == False
    assert One(None).value == False
    assert One('').value == False
    assert One('1').value == True
    assert One('0').value == False
    assert One([]).value == False
    assert One([1]).value == True
    assert One([0]).value == False
    assert One({}).value == False
    assert One({'1': 1}).value == True
    assert One({'0': 0}).value == False


# Generated at 2022-06-18 01:55:03.006874
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-18 01:55:09.718556
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x + 1) == 2
    assert All(True).fold(lambda x: not x) is False
    assert One(True).fold(lambda x: not x) is True
    assert First(1).fold(lambda x: x + 1) == 1
    assert Last(1).fold(lambda x: x + 1) == 2
    assert Map({1: Sum(1)}).fold(lambda x: x[1].value) == 1
    assert Max(1).fold(lambda x: x + 1) == 2
    assert Min(1).fold(lambda x: x + 1) == 1


# Generated at 2022-06-18 01:55:14.780783
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert First(1).value == 1
    assert First(1).value != 2
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(2)).value == 1
    assert First(1).concat(First(2)).value != 2


# Generated at 2022-06-18 01:55:16.123034
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 01:55:20.467818
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1) != 1


# Generated at 2022-06-18 01:55:23.386414
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)
    assert All(False) != All(True)


# Generated at 2022-06-18 01:55:24.069858
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-18 01:55:34.222968
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert Last(1).value == 1
    assert Last(1).concat(Last(2)).value == 2
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(2)).concat(Last(3)) == Last(3)
    assert Last(1).concat(Last(2)).concat(Last(3)).concat(Last(4)) == Last(4)
    assert Last(1).concat(Last(2)).concat(Last(3)).concat(Last(4)).concat(Last(5)) == Last(5)

# Generated at 2022-06-18 01:55:35.646045
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 01:55:36.960050
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)


# Generated at 2022-06-18 01:55:42.662329
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-18 01:55:46.569869
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(1)) == Last(1)
    assert Last(2).concat(Last(1)) == Last(1)


# Generated at 2022-06-18 01:55:48.212001
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-18 01:55:49.416464
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-18 01:55:51.108804
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 01:55:53.149575
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-18 01:55:54.959465
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).value == 1


# Generated at 2022-06-18 01:55:58.314484
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(1) != Max(2)
    assert Max(1).fold(lambda x: x) == 1


# Generated at 2022-06-18 01:56:01.429545
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(None).concat(First(None)) == First(None)



# Generated at 2022-06-18 01:56:05.022219
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(1)) == Last(1)
    assert Last(2).concat(Last(1)) == Last(1)


# Generated at 2022-06-18 01:56:14.671169
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1).fold(lambda x: x) == 1
    assert Semigroup(1).fold(lambda x: x + 1) == 2


# Generated at 2022-06-18 01:56:16.132602
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-18 01:56:17.293966
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)


# Generated at 2022-06-18 01:56:18.510765
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-18 01:56:20.209762
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)


# Generated at 2022-06-18 01:56:24.705632
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(2)).value == 1
    assert First(1).concat(First(2)).fold(lambda x: x) == 1


# Generated at 2022-06-18 01:56:28.092577
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:56:30.680550
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)
    assert One(False) != One(True)


# Generated at 2022-06-18 01:56:32.946623
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)


# Generated at 2022-06-18 01:56:34.292965
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 01:56:52.719760
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1).fold(lambda x: x) == 1
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    assert Semigroup.neutral().value == Semigroup.neutral_element


# Generated at 2022-06-18 01:56:56.893980
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-18 01:57:08.670669
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    assert Semigroup(1).fold(lambda x: x - 1) == 0
    assert Semigroup(1).fold(lambda x: x * 2) == 2
    assert Semigroup(1).fold(lambda x: x / 2) == 0.5
    assert Semigroup(1).fold(lambda x: x ** 2) == 1
    assert Semigroup(1).fold(lambda x: x % 2) == 1
    assert Semigroup(1).fold(lambda x: x // 2) == 0
    assert Semigroup(1).fold(lambda x: x & 2) == 0
    assert Semigroup(1).fold(lambda x: x | 2) == 3
    assert Semigroup(1).fold(lambda x: x ^ 2) == 3

# Generated at 2022-06-18 01:57:13.214343
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-18 01:57:15.086631
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-18 01:57:17.754674
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(6)})


# Generated at 2022-06-18 01:57:23.543241
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First(1) == First(1)
    assert Last(1) == Last(1)
    assert Map({1: Sum(1)}) == Map({1: Sum(1)})
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)


# Generated at 2022-06-18 01:57:25.345272
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)


# Generated at 2022-06-18 01:57:29.572057
# Unit test for method concat of class Map
def test_Map_concat():
    """
    Test for method concat of class Map
    """
    assert Map({"a": Sum(1), "b": Sum(2)}).concat(Map({"a": Sum(3), "b": Sum(4)})) == Map(
        {"a": Sum(4), "b": Sum(6)}
    )



# Generated at 2022-06-18 01:57:32.079031
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-18 01:58:05.319150
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-18 01:58:09.325370
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(None).concat(First(None)) == First(None)


# Generated at 2022-06-18 01:58:14.099465
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)) == Sum(10)


# Generated at 2022-06-18 01:58:21.047697
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True
    assert One(False).value == False
    assert One(1).value == True
    assert One(0).value == False
    assert One(None).value == False
    assert One('').value == False
    assert One('1').value == True
    assert One('0').value == False
    assert One('True').value == True
    assert One('False').value == False
    assert One('None').value == False
    assert One(' ').value == False
    assert One([]).value == False
    assert One([1]).value == True
    assert One([0]).value == False
    assert One([None]).value == False
    assert One(()).value == False
    assert One((1,)).value == True
    assert One((0,)).value == False

# Generated at 2022-06-18 01:58:23.198074
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-18 01:58:25.472576
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(2)}) == Map({'a': Sum(1), 'b': Sum(2)})


# Generated at 2022-06-18 01:58:27.170601
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)


# Generated at 2022-06-18 01:58:29.119252
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)
    assert One(False) != One(True)


# Generated at 2022-06-18 01:58:30.469512
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-18 01:58:32.420027
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 01:59:35.779789
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)
    assert Min(1).value == 1


# Generated at 2022-06-18 01:59:38.344016
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1).fold(lambda x: x) == 1


# Generated at 2022-06-18 01:59:40.403471
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 01:59:47.594802
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).value == 1
    assert Sum(1).fold(lambda x: x) == 1
    assert Sum(1).fold(lambda x: x + 1) == 2
    assert Sum(1).fold(lambda x: x - 1) == 0
    assert Sum(1).fold(lambda x: x * 2) == 2
    assert Sum(1).fold(lambda x: x / 2) == 0.5
    assert Sum(1).fold(lambda x: x ** 2) == 1
    assert Sum(1).fold(lambda x: x % 2) == 1
    assert Sum(1).fold(lambda x: x // 2) == 0
    assert Sum(1).fold(lambda x: x + x) == 2
    assert Sum

# Generated at 2022-06-18 01:59:49.524071
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)


# Generated at 2022-06-18 01:59:52.512908
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(2)}).value == {'a': Sum(1), 'b': Sum(2)}



# Generated at 2022-06-18 01:59:53.907378
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 01:59:58.124620
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)
    assert One(False) != One(True)
    assert One(True).value == True
    assert One(False).value == False


# Generated at 2022-06-18 02:00:00.443916
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(2)}).value == {'a': Sum(1), 'b': Sum(2)}


# Generated at 2022-06-18 02:00:02.665325
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(2)}).value == {'a': Sum(1), 'b': Sum(2)}


# Generated at 2022-06-18 02:02:25.684136
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)


# Generated at 2022-06-18 02:02:29.451182
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(1) != Max(2)
    assert Max(1).value == 1
    assert Max(1).neutral() == Max(-float("inf"))


# Generated at 2022-06-18 02:02:31.090087
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(1) != Max(2)


# Generated at 2022-06-18 02:02:34.244377
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)
    assert One(False) != One(True)


# Generated at 2022-06-18 02:02:42.343206
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)).value == 3
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).value == 6
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)).value == 10
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)).concat(Sum(5)).value == 15
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)).concat(Sum(5)).concat(Sum(6)).value == 21

# Generated at 2022-06-18 02:02:43.651412
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-18 02:02:55.179382
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(2)).concat(First(3)) == First(1)
    assert First(1).concat(First(2)).concat(First(3)).concat(First(4)) == First(1)
    assert First(1).concat(First(2)).concat(First(3)).concat(First(4)).concat(First(5)) == First(1)
    assert First(1).concat(First(2)).concat(First(3)).concat(First(4)).concat(First(5)).concat(First(6)) == First(1)

# Generated at 2022-06-18 02:02:57.738577
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 02:03:00.650328
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(1)) == Last(1)
    assert Last(2).concat(Last(1)) == Last(1)


# Generated at 2022-06-18 02:03:02.132007
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2
