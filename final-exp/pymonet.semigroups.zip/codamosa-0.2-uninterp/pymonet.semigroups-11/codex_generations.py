

# Generated at 2022-06-18 01:53:31.054517
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(2).concat(Max(2)) == Max(2)


# Generated at 2022-06-18 01:53:33.744891
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:53:37.124707
# Unit test for method concat of class Map
def test_Map_concat():
    """
    Test for method concat of class Map
    """
    map1 = Map({'a': Sum(1), 'b': Sum(2)})
    map2 = Map({'a': Sum(3), 'b': Sum(4)})
    assert map1.concat(map2) == Map({'a': Sum(4), 'b': Sum(6)})



# Generated at 2022-06-18 01:53:45.497980
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(-1)) == Max(1)
    assert Max(-1).concat(Max(1)) == Max(1)
    assert Max(-1).concat(Max(-1)) == Max(-1)
    assert Max(-1).concat(Max(-2)) == Max(-1)
    assert Max(-2).concat(Max(-1)) == Max(-1)


# Generated at 2022-06-18 01:53:49.351963
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:53:51.691617
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(6)})

# Generated at 2022-06-18 01:53:55.404199
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(6)})


# Generated at 2022-06-18 01:53:58.275465
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(6)})


# Generated at 2022-06-18 01:54:01.952189
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:54:07.770673
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)
    assert Max(2).concat(Max(2)) == Max(2)


# Generated at 2022-06-18 01:54:13.345381
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:54:15.316173
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)


# Generated at 2022-06-18 01:54:17.505504
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(2)}).value == {'a': Sum(1), 'b': Sum(2)}


# Generated at 2022-06-18 01:54:18.495516
# Unit test for constructor of class Min
def test_Min():
    assert Min(1).value == 1


# Generated at 2022-06-18 01:54:19.838978
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-18 01:54:21.428894
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-18 01:54:22.817230
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-18 01:54:26.747577
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True) != All(False)
    assert All(False) != All(True)
    assert All(False) == All(False)


# Generated at 2022-06-18 01:54:28.310928
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-18 01:54:32.220886
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(None).concat(First(None)) == First(None)


# Generated at 2022-06-18 01:54:36.046668
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)


# Generated at 2022-06-18 01:54:41.695251
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First(1) == First(1)
    assert Last(1) == Last(1)
    assert Map({1: Sum(1)}) == Map({1: Sum(1)})
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)


# Generated at 2022-06-18 01:54:42.989661
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-18 01:54:44.721746
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 01:54:47.353014
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(6)})

# Generated at 2022-06-18 01:54:50.900481
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-18 01:54:54.773549
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'
    assert str(One(None)) == 'One[value=None]'


# Generated at 2022-06-18 01:54:59.248721
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(1)) == Last(1)
    assert Last(2).concat(Last(1)) == Last(1)


# Generated at 2022-06-18 01:55:03.151635
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(1)) == Last(1)
    assert Last(2).concat(Last(1)) == Last(1)


# Generated at 2022-06-18 01:55:06.003429
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)
    assert One(False) != One(True)


# Generated at 2022-06-18 01:55:09.849544
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-18 01:55:10.870027
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'



# Generated at 2022-06-18 01:55:15.609400
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert Last(1).value == 1
    assert Last(1).concat(Last(2)).value == 2
    assert Last(1).concat(Last(2)).concat(Last(3)).value == 3


# Generated at 2022-06-18 01:55:22.389454
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert First(1).value == 1
    assert First(1).fold(lambda x: x) == 1
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(2)).value == 1


# Generated at 2022-06-18 01:55:24.849240
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)
    assert One(False) != One(True)


# Generated at 2022-06-18 01:55:26.751154
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-18 01:55:32.771534
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert Last(1).value == 1
    assert Last(1).concat(Last(2)).value == 2
    assert Last(1).concat(Last(2)).concat(Last(3)).value == 3
    assert Last(1).concat(Last(2)).concat(Last(3)).concat(Last(4)).value == 4


# Generated at 2022-06-18 01:55:34.087796
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)


# Generated at 2022-06-18 01:55:35.462745
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-18 01:55:36.798347
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-18 01:55:53.025607
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert Last(1) != Last(1.0)
    assert Last(1) != Last('1')
    assert Last(1) != Last(True)
    assert Last(1) != Last(None)
    assert Last(1) != Last([1])
    assert Last(1) != Last((1,))
    assert Last(1) != Last({1})
    assert Last(1) != Last({'1': 1})
    assert Last(1) != Last(set())
    assert Last(1) != Last(frozenset())
    assert Last(1) != Last(range(1))
    assert Last(1) != Last(bytearray(1))

# Generated at 2022-06-18 01:55:55.539229
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == 'Map[value={\'a\': Sum[value=1], \'b\': Sum[value=2]}]'



# Generated at 2022-06-18 01:55:59.463088
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:56:09.508919
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(2)).value == 1
    assert First(1).concat(First(2)).fold(lambda x: x) == 1
    assert First(1).concat(First(2)).fold(lambda x: x + 1) == 2
    assert First(1).concat(First(2)).fold(lambda x: x + 2) == 3
    assert First(1).concat(First(2)).fold(lambda x: x + 3) == 4
    assert First(1).concat(First(2)).fold(lambda x: x + 4) == 5

# Generated at 2022-06-18 01:56:13.761720
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)



# Generated at 2022-06-18 01:56:14.980650
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-18 01:56:16.813867
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-18 01:56:19.289235
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)
    assert All(False) != All(True)


# Generated at 2022-06-18 01:56:20.375629
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-18 01:56:26.400799
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)) == Sum(10)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)).concat(Sum(5)) == Sum(15)


# Generated at 2022-06-18 01:56:36.589776
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(None).concat(First(None)) == First(None)


# Generated at 2022-06-18 01:56:39.594206
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:56:40.972341
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)
    assert not Semigroup(1) == 1


# Generated at 2022-06-18 01:56:46.036682
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-18 01:56:50.835746
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-18 01:56:53.470597
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1
    assert Last(2).value == 2
    assert Last(3).value == 3
    assert Last(4).value == 4
    assert Last(5).value == 5


# Generated at 2022-06-18 01:56:56.565529
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:57:02.570064
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(None).concat(First(None)) == First(None)


# Generated at 2022-06-18 01:57:07.360324
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-18 01:57:16.690137
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    assert Semigroup(2).fold(lambda x: x + 1) == 3
    assert Semigroup(3).fold(lambda x: x + 1) == 4
    assert Semigroup(4).fold(lambda x: x + 1) == 5
    assert Semigroup(5).fold(lambda x: x + 1) == 6
    assert Semigroup(6).fold(lambda x: x + 1) == 7
    assert Semigroup(7).fold(lambda x: x + 1) == 8
    assert Semigroup(8).fold(lambda x: x + 1) == 9
    assert Semigroup(9).fold(lambda x: x + 1) == 10
    assert Semigroup(10).fold(lambda x: x + 1) == 11


# Generated at 2022-06-18 01:57:32.080489
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:57:36.204856
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(6)})


# Generated at 2022-06-18 01:57:45.503420
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)) == Sum(10)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)).concat(Sum(5)) == Sum(15)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)).concat(Sum(5)).concat(Sum(6)) == Sum(21)

# Generated at 2022-06-18 01:57:46.494232
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-18 01:57:50.069869
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-18 01:57:51.020721
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1


# Generated at 2022-06-18 01:57:52.211103
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1


# Generated at 2022-06-18 01:57:55.049681
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(2)}).value == {'a': Sum(1), 'b': Sum(2)}


# Generated at 2022-06-18 01:57:59.048494
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)
    assert One(False) != One(True)


# Generated at 2022-06-18 01:58:00.940905
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(None).concat(First(None)) == First(None)


# Generated at 2022-06-18 01:58:27.979708
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(2)}).value == {'a': Sum(1), 'b': Sum(2)}


# Generated at 2022-06-18 01:58:29.119140
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2


# Generated at 2022-06-18 01:58:30.086868
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 01:58:31.254992
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 01:58:33.734941
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)


# Generated at 2022-06-18 01:58:43.102151
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(None).concat(First(None)) == First(None)
    assert First([]).concat(First([1, 2])) == First([])
    assert First([1, 2]).concat(First([])) == First([1, 2])
    assert First([1, 2]).concat(First([3, 4])) == First([1, 2])
    assert First([1, 2]).concat(First([3, 4])) == First([1, 2])
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat

# Generated at 2022-06-18 01:58:46.657334
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-18 01:58:48.650333
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)


# Generated at 2022-06-18 01:58:52.230687
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1).value == 1
    assert Semigroup(1).fold(lambda x: x) == 1



# Generated at 2022-06-18 01:58:52.894433
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-18 01:59:26.114115
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-18 01:59:29.317936
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(6)})

# Generated at 2022-06-18 01:59:32.816633
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-18 01:59:34.916335
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)


# Generated at 2022-06-18 01:59:36.827612
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-18 01:59:44.627500
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    assert Semigroup(1).fold(lambda x: x - 1) == 0
    assert Semigroup(1).fold(lambda x: x * 2) == 2
    assert Semigroup(1).fold(lambda x: x / 2) == 0.5
    assert Semigroup(1).fold(lambda x: x ** 2) == 1
    assert Semigroup(1).fold(lambda x: x % 2) == 1
    assert Semigroup(1).fold(lambda x: x // 2) == 0
    assert Semigroup(1).fold(lambda x: x & 2) == 0
    assert Semigroup(1).fold(lambda x: x | 2) == 3
    assert Semigroup(1).fold(lambda x: x ^ 2) == 3

# Generated at 2022-06-18 01:59:51.085140
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert Last(1).value == 1
    assert Last(1).concat(Last(2)).value == 2
    assert Last(1).concat(Last(2)).concat(Last(3)).value == 3
    assert Last(1).concat(Last(2)).concat(Last(3)).concat(Last(4)).value == 4
    assert Last(1).concat(Last(2)).concat(Last(3)).concat(Last(4)).concat(Last(5)).value == 5
    assert Last(1).concat(Last(2)).concat(Last(3)).concat(Last(4)).concat(Last(5)).concat(Last(6)).value == 6

# Generated at 2022-06-18 01:59:55.038793
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(6)})


# Generated at 2022-06-18 01:59:59.542695
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-18 02:00:01.168717
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)


# Generated at 2022-06-18 02:01:15.399465
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-18 02:01:16.676981
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-18 02:01:18.417928
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 02:01:20.456943
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(2)}).value == {'a': Sum(1), 'b': Sum(2)}


# Generated at 2022-06-18 02:01:22.656589
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)
    assert One(False) != One(True)


# Generated at 2022-06-18 02:01:29.660096
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert Last(1).value == 1
    assert Last(1).concat(Last(2)).value == 2
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(2)).concat(Last(3)) == Last(3)
    assert Last(1).concat(Last(2)).concat(Last(3)).concat(Last(4)) == Last(4)


# Generated at 2022-06-18 02:01:30.629098
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1


# Generated at 2022-06-18 02:01:33.032858
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1).fold(lambda x: x) == 1


# Generated at 2022-06-18 02:01:34.195418
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-18 02:01:34.966300
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'
