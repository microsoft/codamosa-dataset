

# Generated at 2022-06-18 01:53:36.535268
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)


# Generated at 2022-06-18 01:53:38.445767
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-18 01:53:39.353907
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1


# Generated at 2022-06-18 01:53:44.591908
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(None).concat(First(None)) == First(None)


# Generated at 2022-06-18 01:53:48.035143
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(6)})


# Generated at 2022-06-18 01:53:50.386243
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(False)).value == False
    assert One(False).concat(One(True)).value == True
    assert One(True).concat(One(True)).value == True


# Generated at 2022-06-18 01:53:55.925867
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(2).concat(Max(2)) == Max(2)


# Generated at 2022-06-18 01:54:00.143398
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1) != Semigroup('1')


# Generated at 2022-06-18 01:54:01.993619
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-18 01:54:07.389483
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    assert Semigroup(2).fold(lambda x: x + 1) == 3
    assert Semigroup(3).fold(lambda x: x + 1) == 4
    assert Semigroup(4).fold(lambda x: x + 1) == 5
    assert Semigroup(5).fold(lambda x: x + 1) == 6
    assert Semigroup(6).fold(lambda x: x + 1) == 7
    assert Semigroup(7).fold(lambda x: x + 1) == 8
    assert Semigroup(8).fold(lambda x: x + 1) == 9
    assert Semigroup(9).fold(lambda x: x + 1) == 10
    assert Semigroup(10).fold(lambda x: x + 1) == 11

# Generated at 2022-06-18 01:54:18.457812
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).value == 1
    assert Sum(1).fold(lambda x: x) == 1
    assert Sum(1).concat(Sum(2)).value == 3
    assert Sum(1).concat(Sum(2)).fold(lambda x: x) == 3
    assert Sum.neutral().value == 0
    assert Sum.neutral().fold(lambda x: x) == 0
    assert Sum.neutral().concat(Sum(1)).value == 1
    assert Sum.neutral().concat(Sum(1)).fold(lambda x: x) == 1
    assert Sum(1).concat(Sum.neutral()).value == 1
    assert Sum(1).concat(Sum.neutral()).fold(lambda x: x) == 1



# Generated at 2022-06-18 01:54:21.187233
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(2)}).value == {'a': Sum(1), 'b': Sum(2)}


# Generated at 2022-06-18 01:54:31.893172
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).value == 1
    assert Sum(1).fold(lambda x: x) == 1
    assert Sum(1).fold(lambda x: x + 1) == 2
    assert Sum(1).fold(lambda x: x * 2) == 2
    assert Sum(1).fold(lambda x: x / 2) == 0.5
    assert Sum(1).fold(lambda x: x - 1) == 0
    assert Sum(1).fold(lambda x: x ** 2) == 1
    assert Sum(1).fold(lambda x: x % 2) == 1
    assert Sum(1).fold(lambda x: x // 2) == 0
    assert Sum(1).fold(lambda x: x << 2) == 4
    assert Sum

# Generated at 2022-06-18 01:54:34.200735
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)


# Generated at 2022-06-18 01:54:37.449586
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True) != All(False)
    assert All(False) != All(True)
    assert All(False) == All(False)


# Generated at 2022-06-18 01:54:46.332686
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert First(1).value == 1
    assert First(1).concat(First(2)).value == 1
    assert First(1).concat(First(2)).value == 1
    assert First(1).concat(First(2)).value == 1
    assert First(1).concat(First(2)).value == 1
    assert First(1).concat(First(2)).value == 1
    assert First(1).concat(First(2)).value == 1
    assert First(1).concat(First(2)).value == 1
    assert First(1).concat(First(2)).value == 1
    assert First(1).concat(First(2)).value == 1

# Generated at 2022-06-18 01:54:53.593731
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First(1) == First(1)
    assert Last(1) == Last(1)
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)
    assert Map({'a': Sum(1)}) == Map({'a': Sum(1)})


# Generated at 2022-06-18 01:54:57.599576
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1) != Semigroup('1')
    assert Semigroup(1) != 1
    assert Semigroup(1) != '1'


# Generated at 2022-06-18 01:55:02.911825
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-18 01:55:05.822059
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == 'Map[value={\'a\': Sum[value=1], \'b\': Sum[value=2]}]'


# Generated at 2022-06-18 01:55:11.175664
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:55:14.076485
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)
    assert One(False) != One(True)


# Generated at 2022-06-18 01:55:15.174680
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-18 01:55:21.365886
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    assert Semigroup(1).fold(lambda x: x * 2) == 2
    assert Semigroup(1).fold(lambda x: x - 1) == 0
    assert Semigroup(1).fold(lambda x: x / 2) == 0.5


# Generated at 2022-06-18 01:55:22.876828
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-18 01:55:24.031901
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 01:55:26.907943
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == 'Map[value={\'a\': Sum[value=1], \'b\': Sum[value=2]}]'


# Generated at 2022-06-18 01:55:29.828234
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)


# Generated at 2022-06-18 01:55:33.178347
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)
    assert Max(2).concat(Max(1)) == Max(2)


# Generated at 2022-06-18 01:55:40.586092
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False
    assert All(1).value == True
    assert All(0).value == False
    assert All(None).value == False
    assert All([]).value == False
    assert All([1]).value == True
    assert All(()).value == False
    assert All((1,)).value == True
    assert All({}).value == False
    assert All({1: 1}).value == True
    assert All('').value == False
    assert All('1').value == True


# Generated at 2022-06-18 01:55:51.769673
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1).value == 1
    assert Semigroup(2).value == 2
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1).fold(lambda x: x) == 1
    assert Semigroup(2).fold(lambda x: x) == 2


# Generated at 2022-06-18 01:55:56.103551
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(True).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-18 01:55:58.357150
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-18 01:56:00.109002
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(1) != Max(2)
    assert Max(1).value == 1


# Generated at 2022-06-18 01:56:03.225196
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(6)})


# Generated at 2022-06-18 01:56:07.244128
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).value == 1
    assert Sum(1).fold(lambda x: x) == 1
    assert Sum.neutral().value == 0


# Generated at 2022-06-18 01:56:10.838006
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(1)) == Last(1)
    assert Last(2).concat(Last(1)) == Last(1)


# Generated at 2022-06-18 01:56:12.175637
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-18 01:56:16.134011
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-18 01:56:17.009017
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1


# Generated at 2022-06-18 01:56:32.910308
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:56:38.282935
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1
    assert Last(2).value == 2
    assert Last(3).value == 3
    assert Last(4).value == 4
    assert Last(5).value == 5
    assert Last(6).value == 6
    assert Last(7).value == 7
    assert Last(8).value == 8
    assert Last(9).value == 9
    assert Last(10).value == 10


# Generated at 2022-06-18 01:56:40.442400
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)
    assert All(False) != All(True)


# Generated at 2022-06-18 01:56:42.582303
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == "Map[value={'a': Sum[value=1], 'b': Sum[value=2]}]"


# Generated at 2022-06-18 01:56:43.387729
# Unit test for constructor of class Min
def test_Min():
    assert Min(5) == Min(5)


# Generated at 2022-06-18 01:56:46.654815
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)


# Generated at 2022-06-18 01:56:50.023757
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(3).concat(Min(4)) == Min(3)
    assert Min(4).concat(Min(3)) == Min(3)
    assert Min(4).concat(Min(4)) == Min(4)


# Generated at 2022-06-18 01:56:51.619024
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)
    assert Min(1) != Min(2)


# Generated at 2022-06-18 01:56:57.319477
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)) == Sum(10)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)).concat(Sum(5)) == Sum(15)


# Generated at 2022-06-18 01:57:05.245625
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)) == Sum(10)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)).concat(Sum(5)) == Sum(15)


# Generated at 2022-06-18 01:57:31.470577
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-18 01:57:34.673340
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True) != All(False)
    assert All(False) != All(True)
    assert All(False) == All(False)


# Generated at 2022-06-18 01:57:36.688098
# Unit test for constructor of class Min
def test_Min():
    assert Min(1).value == 1


# Generated at 2022-06-18 01:57:39.520224
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)


# Generated at 2022-06-18 01:57:42.396758
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)
    assert All(False) != All(True)


# Generated at 2022-06-18 01:57:45.754186
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert First(1).concat(First(2)) == First(1)
    assert First(1).fold(lambda x: x) == 1
    assert First.neutral().value == None


# Generated at 2022-06-18 01:57:51.252771
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x + 1) == 2
    assert All(True).fold(lambda x: not x) is False
    assert One(False).fold(lambda x: not x) is True
    assert First(1).fold(lambda x: x + 1) == 1
    assert Last(1).fold(lambda x: x + 1) == 2
    assert Map({1: Sum(1)}).fold(lambda x: x[1].value) == 1
    assert Max(1).fold(lambda x: x + 1) == 2
    assert Min(1).fold(lambda x: x + 1) == 1


# Generated at 2022-06-18 01:57:55.575704
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(True)).value == True
    assert One(False).concat(One(False)).value == False
    assert One(True).concat(One(True)).value == True


# Generated at 2022-06-18 01:58:00.930139
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-18 01:58:04.209896
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)


# Generated at 2022-06-18 01:59:03.315782
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-18 01:59:04.392682
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-18 01:59:05.401566
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-18 01:59:07.170190
# Unit test for constructor of class Map
def test_Map():
    assert Map({1: Sum(1), 2: Sum(2)}) == Map({1: Sum(1), 2: Sum(2)})



# Generated at 2022-06-18 01:59:09.319558
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)


# Generated at 2022-06-18 01:59:10.457299
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-18 01:59:12.998359
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-18 01:59:16.575343
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:59:18.329643
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-18 01:59:21.831474
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False
    assert All(1).value == True
    assert All(0).value == False
    assert All('').value == False
    assert All('test').value == True


# Generated at 2022-06-18 02:00:24.412747
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-18 02:00:25.312700
# Unit test for constructor of class Min
def test_Min():
    assert Min(1).value == 1


# Generated at 2022-06-18 02:00:26.471087
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-18 02:00:27.550356
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 02:00:29.408096
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)


# Generated at 2022-06-18 02:00:31.090132
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-18 02:00:34.702879
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-18 02:00:35.737595
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-18 02:00:39.036468
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 02:00:41.925097
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)


# Generated at 2022-06-18 02:02:00.645407
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1).fold(lambda x: x) == 1
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    assert Semigroup.neutral().fold(lambda x: x) == Semigroup.neutral_element


# Generated at 2022-06-18 02:02:02.399739
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).value == 1


# Generated at 2022-06-18 02:02:07.690529
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(2)).concat(First(3)) == First(1)
    assert First(1).concat(First(2)).concat(First(3)).concat(First(4)) == First(1)
    assert First(1).concat(First(2)).concat(First(3)).concat(First(4)).concat(First(5)) == First(1)


# Generated at 2022-06-18 02:02:11.349180
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 02:02:12.428093
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-18 02:02:13.483300
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-18 02:02:15.051729
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 02:02:19.751607
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First(1) == First(1)
    assert Last(1) == Last(1)
    assert Map({1: Sum(1)}) == Map({1: Sum(1)})
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)


# Generated at 2022-06-18 02:02:22.006574
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(2)}).value == {'a': Sum(1), 'b': Sum(2)}


# Generated at 2022-06-18 02:02:23.097515
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'
