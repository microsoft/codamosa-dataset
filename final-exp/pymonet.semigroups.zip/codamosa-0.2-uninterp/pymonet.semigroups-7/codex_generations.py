

# Generated at 2022-06-18 01:53:34.207328
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1.1)) == Min(1)
    assert Min(1.1).concat(Min(1)) == Min(1)
    assert Min(1.1).concat(Min(1.1)) == Min(1.1)


# Generated at 2022-06-18 01:53:37.483855
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:53:41.194813
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:53:44.718923
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:53:48.034874
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:53:50.007856
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(6)})


# Generated at 2022-06-18 01:53:53.439327
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:53:56.590127
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:54:00.077199
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:54:04.733557
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({1: Sum(1), 2: Sum(2)}).concat(Map({1: Sum(3), 2: Sum(4)})) == Map({1: Sum(4), 2: Sum(6)})


# Generated at 2022-06-18 01:54:08.553918
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)


# Generated at 2022-06-18 01:54:12.416315
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert Last(1).value == 1
    assert Last(1).concat(Last(2)).value == 2


# Generated at 2022-06-18 01:54:14.432845
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-18 01:54:17.103430
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True) != All(False)
    assert All(False) != All(True)
    assert All(False) == All(False)


# Generated at 2022-06-18 01:54:19.145927
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-18 01:54:21.527972
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1).value == 1
    assert Semigroup(2).value == 2
    assert Semigroup(3).value == 3


# Generated at 2022-06-18 01:54:22.976834
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 01:54:27.370557
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:54:30.012812
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)
    assert not Semigroup(1) == 1


# Generated at 2022-06-18 01:54:31.224842
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-18 01:54:36.994752
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-18 01:54:40.849368
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).value == 1
    assert Sum(1).fold(lambda x: x) == 1
    assert Sum.neutral().value == 0


# Generated at 2022-06-18 01:54:42.500342
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)
    assert Min(1) != Min(2)


# Generated at 2022-06-18 01:54:46.076930
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-18 01:54:47.023053
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-18 01:54:51.935430
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert First(1).value == 1
    assert First(1).concat(First(2)).value == 1


# Generated at 2022-06-18 01:54:52.897956
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1


# Generated at 2022-06-18 01:54:57.009899
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-18 01:55:00.761622
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:55:05.912900
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-18 01:55:13.832712
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'



# Generated at 2022-06-18 01:55:25.330161
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(1) != Max(2)
    assert Max(1).value == 1
    assert Max(1).concat(Max(2)).value == 2
    assert Max(1).concat(Max(2)).concat(Max(3)).value == 3
    assert Max(1).concat(Max(2)).concat(Max(3)).concat(Max(4)).value == 4
    assert Max(1).concat(Max(2)).concat(Max(3)).concat(Max(4)).concat(Max(5)).value == 5
    assert Max(1).concat(Max(2)).concat(Max(3)).concat(Max(4)).concat(Max(5)).concat(Max(6)).value == 6

# Generated at 2022-06-18 01:55:32.101770
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)) == Sum(10)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)).concat(Sum(5)) == Sum(15)


# Generated at 2022-06-18 01:55:37.977639
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:55:39.792507
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(1)) == Last(1)
    assert Last(2).concat(Last(1)) == Last(1)


# Generated at 2022-06-18 01:55:51.225316
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert All(True) == All(True)
    assert All(True) != All(False)
    assert One(False) == One(False)
    assert One(False) != One(True)
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert Map({1: Sum(1)}) == Map({1: Sum(1)})
    assert Map({1: Sum(1)}) != Map({1: Sum(2)})
    assert Max(1) == Max(1)
    assert Max(1) != Max(2)
    assert Min(1) == Min(1)

# Generated at 2022-06-18 01:56:01.009578
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(None).concat(First(None)) == First(None)
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(None).concat(First(None)) == First(None)
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)

# Generated at 2022-06-18 01:56:02.874378
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-18 01:56:05.364977
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True).value == True
    assert All(False).value == False


# Generated at 2022-06-18 01:56:11.564855
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(2)).value == 1
    assert First(1).concat(First(2)).fold(lambda x: x) == 1
    assert First(1).concat(First(2)).fold(lambda x: x + 1) == 2


# Generated at 2022-06-18 01:56:20.844536
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({'a': Sum(1), 'b': Sum(2)})
    m2 = Map({'a': Sum(3), 'b': Sum(4)})
    assert m1.concat(m2) == Map({'a': Sum(4), 'b': Sum(6)})

# Generated at 2022-06-18 01:56:22.886406
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)


# Generated at 2022-06-18 01:56:32.430295
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert First(1).value == 1
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(2)).value == 1
    assert First(1).concat(First(2)).fold(lambda x: x) == 1
    assert First(1).concat(First(2)).fold(lambda x: x + 1) == 2
    assert First(1).concat(First(2)).fold(lambda x: x + 1) == 2
    assert First(1).concat(First(2)).fold(lambda x: x + 1) == 2
    assert First(1).concat(First(2)).fold(lambda x: x + 1) == 2

# Generated at 2022-06-18 01:56:34.205328
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-18 01:56:39.319527
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First(1) == First(1)
    assert Last(1) == Last(1)
    assert Map({1: Sum(1)}) == Map({1: Sum(1)})
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)


# Generated at 2022-06-18 01:56:40.687292
# Unit test for method concat of class First
def test_First_concat():
    """
    Test for method concat of class First
    """
    assert First(1).concat(First(2)) == First(1)



# Generated at 2022-06-18 01:56:41.765682
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-18 01:56:42.667071
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-18 01:56:44.181594
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == 'Map[value={\'a\': Sum[value=1], \'b\': Sum[value=2]}]'


# Generated at 2022-06-18 01:56:48.680932
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:57:03.978075
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(6)})


# Generated at 2022-06-18 01:57:06.169336
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-18 01:57:09.676826
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(1)) == Last(1)
    assert Last(2).concat(Last(1)) == Last(1)


# Generated at 2022-06-18 01:57:13.171907
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:57:18.301416
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert First(1).value == 1
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(2)).value == 1
    assert First(1).concat(First(2)).concat(First(3)) == First(1)
    assert First(1).concat(First(2)).concat(First(3)).value == 1


# Generated at 2022-06-18 01:57:19.922216
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 01:57:20.869012
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1


# Generated at 2022-06-18 01:57:24.107421
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:57:25.207947
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-18 01:57:27.041496
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-18 01:57:55.226860
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-18 01:58:06.344023
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    assert Semigroup(1).fold(lambda x: x - 1) == 0
    assert Semigroup(1).fold(lambda x: x * 2) == 2
    assert Semigroup(1).fold(lambda x: x / 2) == 0.5
    assert Semigroup(1).fold(lambda x: x ** 2) == 1
    assert Semigroup(1).fold(lambda x: x % 2) == 1
    assert Semigroup(1).fold(lambda x: x // 2) == 0
    assert Semigroup(1).fold(lambda x: x + x) == 2
    assert Semigroup(1).fold(lambda x: x - x) == 0
    assert Semigroup(1).fold(lambda x: x * x) == 1

# Generated at 2022-06-18 01:58:07.809805
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-18 01:58:09.547219
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-18 01:58:11.952068
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)


# Generated at 2022-06-18 01:58:14.523534
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)
    assert All(False) != All(True)


# Generated at 2022-06-18 01:58:19.132143
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-18 01:58:20.823611
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-18 01:58:25.075411
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-18 01:58:26.387228
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1).value == 1
    assert Semigroup(2).value == 2
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)


# Generated at 2022-06-18 01:59:30.303926
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(6)})

# Generated at 2022-06-18 01:59:32.421782
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(1)) == Last(1)
    assert Last(2).concat(Last(1)) == Last(1)


# Generated at 2022-06-18 01:59:35.519988
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1).fold(lambda x: x) == 1


# Generated at 2022-06-18 01:59:38.105428
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == "Map[value={'a': Sum[value=1], 'b': Sum[value=2]}]"


# Generated at 2022-06-18 01:59:41.681691
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).value == 1
    assert Sum(1).fold(lambda x: x) == 1


# Generated at 2022-06-18 01:59:42.468008
# Unit test for constructor of class Min
def test_Min():
    assert Min(1).value == 1


# Generated at 2022-06-18 01:59:46.813028
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-18 01:59:50.479572
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First(1) == First(1)
    assert Last(1) == Last(1)
    assert Map({1: Sum(1)}) == Map({1: Sum(1)})
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)


# Generated at 2022-06-18 01:59:53.317837
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-18 01:59:54.728107
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-18 02:02:15.454104
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-18 02:02:16.560707
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-18 02:02:17.984848
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)


# Generated at 2022-06-18 02:02:18.864086
# Unit test for constructor of class Min
def test_Min():
    assert Min(1).value == 1


# Generated at 2022-06-18 02:02:21.856286
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(2).concat(Max(2)) == Max(2)


# Generated at 2022-06-18 02:02:22.925672
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-18 02:02:24.197220
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-18 02:02:27.244626
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)
    assert One(False) != One(True)


# Generated at 2022-06-18 02:02:34.918605
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    assert Semigroup(1).fold(lambda x: x - 1) == 0
    assert Semigroup(1).fold(lambda x: x * 2) == 2
    assert Semigroup(1).fold(lambda x: x / 2) == 0.5
    assert Semigroup(1).fold(lambda x: x ** 2) == 1
    assert Semigroup(1).fold(lambda x: x % 2) == 1
    assert Semigroup(1).fold(lambda x: x // 2) == 0
    assert Semigroup(1).fold(lambda x: x & 2) == 0
    assert Semigroup(1).fold(lambda x: x | 2) == 3
    assert Semigroup(1).fold(lambda x: x ^ 2) == 3

# Generated at 2022-06-18 02:02:38.093727
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"a": Sum(1), "b": Sum(2)}).concat(Map({"a": Sum(3), "b": Sum(4)})) == Map({"a": Sum(4), "b": Sum(6)})