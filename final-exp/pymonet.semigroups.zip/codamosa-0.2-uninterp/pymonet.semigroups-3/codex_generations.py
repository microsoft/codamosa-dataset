

# Generated at 2022-06-18 01:53:34.508089
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:53:39.650845
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(6)})
    assert Map({'a': All(True), 'b': All(False)}).concat(Map({'a': All(True), 'b': All(True)})) == Map({'a': All(True), 'b': All(False)})
    assert Map({'a': One(True), 'b': One(False)}).concat(Map({'a': One(True), 'b': One(True)})) == Map({'a': One(True), 'b': One(True)})

# Generated at 2022-06-18 01:53:43.464947
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:53:46.990836
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:53:49.060375
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:53:52.799387
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:53:55.966799
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:54:00.076853
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:54:04.774608
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:54:08.632547
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({1: Sum(1), 2: Sum(2)})
    m2 = Map({1: Sum(3), 2: Sum(4)})
    assert m1.concat(m2) == Map({1: Sum(4), 2: Sum(6)})

# Generated at 2022-06-18 01:54:12.959750
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-18 01:54:17.827475
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First(1) == First(1)
    assert Last(1) == Last(1)
    assert Map({1: Sum(1)}) == Map({1: Sum(1)})
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)


# Generated at 2022-06-18 01:54:22.450691
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-18 01:54:23.863057
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-18 01:54:33.147095
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).fold(lambda x: x) == 1
    assert Sum(1).concat(Sum(2)).fold(lambda x: x) == 3
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).fold(lambda x: x) == 6
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)).fold(lambda x: x) == 10
    assert Sum(1).concat(Sum(2)).concat(Sum(3)).concat(Sum(4)).concat(Sum(5)).fold(lambda x: x) == 15


# Generated at 2022-06-18 01:54:36.181495
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).fold(lambda x: x) == 1


# Generated at 2022-06-18 01:54:45.391804
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    assert Semigroup(1).fold(lambda x: x * 2) == 2
    assert Semigroup(1).fold(lambda x: x ** 2) == 1
    assert Semigroup(1).fold(lambda x: x / 2) == 0.5
    assert Semigroup(1).fold(lambda x: x - 1) == 0
    assert Semigroup(1).fold(lambda x: x % 2) == 1
    assert Semigroup(1).fold(lambda x: x // 2) == 0
    assert Semigroup(1).fold(lambda x: x ** 3) == 1
    assert Semigroup(1).fold(lambda x: x ** 4) == 1
    assert Semigroup(1).fold(lambda x: x ** 5) == 1

# Generated at 2022-06-18 01:54:46.867834
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2


# Generated at 2022-06-18 01:54:49.876409
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1)})) == 'Map[value={\'a\': Sum[value=1]}]'


# Generated at 2022-06-18 01:54:52.629440
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-18 01:54:58.149302
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-18 01:55:01.036497
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).value == 1
    assert Sum(1).fold(lambda x: x) == 1


# Generated at 2022-06-18 01:55:04.599554
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == "Map[value={'a': Sum[value=1], 'b': Sum[value=2]}]"


# Generated at 2022-06-18 01:55:06.351200
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)


# Generated at 2022-06-18 01:55:10.990791
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False
    assert All(1).value == True
    assert All(0).value == False
    assert All('').value == False
    assert All('a').value == True
    assert All([]).value == False
    assert All([1]).value == True
    assert All({}).value == False
    assert All({'a': 1}).value == True


# Generated at 2022-06-18 01:55:12.555366
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-18 01:55:14.886959
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(1) != Max(2)
    assert Max(1).value == 1


# Generated at 2022-06-18 01:55:16.861647
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-18 01:55:20.972261
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)



# Generated at 2022-06-18 01:55:22.475780
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-18 01:55:31.933871
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(True) != One(False)
    assert One(False) != One(True)
    assert One(False) == One(False)


# Generated at 2022-06-18 01:55:34.305901
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)


# Generated at 2022-06-18 01:55:36.785898
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(2)}).value == {'a': Sum(1), 'b': Sum(2)}


# Generated at 2022-06-18 01:55:41.377280
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(None).concat(First(None)) == First(None)


# Generated at 2022-06-18 01:55:52.419590
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).value == 1
    assert Sum(1).fold(lambda x: x) == 1
    assert Sum(1).fold(lambda x: x + 1) == 2
    assert Sum(1).fold(lambda x: x - 1) == 0
    assert Sum(1).fold(lambda x: x * 2) == 2
    assert Sum(1).fold(lambda x: x / 2) == 0.5
    assert Sum(1).fold(lambda x: x ** 2) == 1
    assert Sum(1).fold(lambda x: x % 2) == 1
    assert Sum(1).fold(lambda x: x // 2) == 0
    assert Sum(1).fold(lambda x: x + x) == 2
    assert Sum

# Generated at 2022-06-18 01:55:56.269175
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-18 01:55:59.196443
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-18 01:56:01.716367
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == "Map[value={'a': Sum[value=1], 'b': Sum[value=2]}]"


# Generated at 2022-06-18 01:56:05.308191
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(6)})

# Generated at 2022-06-18 01:56:08.194228
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1).value == 1
    assert Semigroup(1).fold(lambda x: x) == 1


# Generated at 2022-06-18 01:56:22.965081
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)
    assert One(False) != One(True)


# Generated at 2022-06-18 01:56:23.868189
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1


# Generated at 2022-06-18 01:56:26.777645
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)
    assert One(False) != One(True)


# Generated at 2022-06-18 01:56:36.014385
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(2)}).value == {'a': Sum(1), 'b': Sum(2)}
    assert Map({'a': Sum(1), 'b': Sum(2)}).value != {'a': Sum(1), 'b': Sum(3)}
    assert Map({'a': Sum(1), 'b': Sum(2)}).value != {'a': Sum(1), 'b': Sum(2), 'c': Sum(3)}
    assert Map({'a': Sum(1), 'b': Sum(2)}).value != {'a': Sum(1), 'c': Sum(2)}
    assert Map({'a': Sum(1), 'b': Sum(2)}).value != {'a': Sum(1), 'b': Sum(2), 'c': Sum(3)}


# Generated at 2022-06-18 01:56:39.245252
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)
    assert not Semigroup(1) == 1
    assert not Semigroup(1) == None


# Generated at 2022-06-18 01:56:40.799494
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)
    assert All(False) != All(True)


# Generated at 2022-06-18 01:56:43.088998
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(1)) == Last(1)
    assert Last(2).concat(Last(1)) == Last(1)


# Generated at 2022-06-18 01:56:48.381223
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(1)) == Last(1)
    assert Last(2).concat(Last(1)) == Last(1)


# Generated at 2022-06-18 01:56:55.558887
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    assert Semigroup(1).fold(lambda x: x * 2) == 2
    assert Semigroup(1).fold(lambda x: x ** 2) == 1
    assert Semigroup(1).fold(lambda x: x - 1) == 0
    assert Semigroup(1).fold(lambda x: x / 2) == 0.5
    assert Semigroup(1).fold(lambda x: x // 2) == 0
    assert Semigroup(1).fold(lambda x: x % 2) == 1
    assert Semigroup(1).fold(lambda x: x ** 2) == 1
    assert Semigroup(1).fold(lambda x: x ** 3) == 1
    assert Semigroup(1).fold(lambda x: x ** 4) == 1

# Generated at 2022-06-18 01:56:59.913627
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-18 01:57:25.790904
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-18 01:57:34.373195
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(2)}) == Map({'a': Sum(1), 'b': Sum(2)})
    assert Map({'a': Sum(1), 'b': Sum(2)}) != Map({'a': Sum(1), 'b': Sum(3)})
    assert Map({'a': Sum(1), 'b': Sum(2)}) != Map({'a': Sum(1), 'b': Sum(2), 'c': Sum(3)})
    assert Map({'a': Sum(1), 'b': Sum(2)}) != Map({'a': Sum(1), 'b': Sum(2), 'c': Sum(3)})

# Generated at 2022-06-18 01:57:44.655028
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert First(1).value == 1
    assert First(1).concat(First(2)).value == 1
    assert First(1).concat(First(2)).concat(First(3)).value == 1
    assert First(1).concat(First(2)).concat(First(3)).concat(First(4)).value == 1
    assert First(1).concat(First(2)).concat(First(3)).concat(First(4)).concat(First(5)).value == 1
    assert First(1).concat(First(2)).concat(First(3)).concat(First(4)).concat(First(5)).concat(First(6)).value == 1

# Generated at 2022-06-18 01:57:47.557702
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1).value == 1
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1).fold(lambda x: x) == 1
    assert Semigroup(1).fold(lambda x: x + 1) == 2


# Generated at 2022-06-18 01:57:49.842332
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(2)}) == Map({'a': Sum(1), 'b': Sum(2)})


# Generated at 2022-06-18 01:57:51.126041
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-18 01:57:54.586526
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == "Map[value={'a': Sum[value=1], 'b': Sum[value=2]}]"


# Generated at 2022-06-18 01:57:56.585814
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(2)}).value == {'a': Sum(1), 'b': Sum(2)}


# Generated at 2022-06-18 01:58:07.848123
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(1).value == 1
    assert Max(1).concat(Max(2)).value == 2
    assert Max(1).concat(Max(2)).concat(Max(3)).value == 3
    assert Max(1).concat(Max(2)).concat(Max(3)).concat(Max(4)).value == 4
    assert Max(1).concat(Max(2)).concat(Max(3)).concat(Max(4)).concat(Max(5)).value == 5
    assert Max(1).concat(Max(2)).concat(Max(3)).concat(Max(4)).concat(Max(5)).concat(Max(6)).value == 6
    assert Max(1).concat(Max(2)).concat(Max(3)).concat

# Generated at 2022-06-18 01:58:12.158250
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({'a': Sum(1), 'b': Sum(2)})
    m2 = Map({'a': Sum(3), 'b': Sum(4)})
    assert m1.concat(m2) == Map({'a': Sum(4), 'b': Sum(6)})


# Generated at 2022-06-18 01:59:16.071204
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-18 01:59:19.760450
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).value == 1
    assert Sum(1).fold(lambda x: x) == 1
    assert Sum.neutral().value == 0


# Generated at 2022-06-18 01:59:26.022017
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1).fold(lambda x: x) == 1
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    assert Semigroup(1).fold(lambda x: x + 2) == 3
    assert Semigroup(1).fold(lambda x: x + 3) == 4
    assert Semigroup(1).fold(lambda x: x + 4) == 5
    assert Semigroup(1).fold(lambda x: x + 5) == 6
    assert Semigroup(1).fold(lambda x: x + 6) == 7
    assert Semigroup(1).fold(lambda x: x + 7) == 8
    assert Semigroup(1).fold(lambda x: x + 8) == 9

# Generated at 2022-06-18 01:59:35.295620
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    assert Semigroup(1).fold(lambda x: x * 2) == 2
    assert Semigroup(1).fold(lambda x: x ** 2) == 1
    assert Semigroup(1).fold(lambda x: x ** 3) == 1
    assert Semigroup(1).fold(lambda x: x ** 4) == 1
    assert Semigroup(1).fold(lambda x: x ** 5) == 1
    assert Semigroup(1).fold(lambda x: x ** 6) == 1
    assert Semigroup(1).fold(lambda x: x ** 7) == 1
    assert Semigroup(1).fold(lambda x: x ** 8) == 1
    assert Semigroup(1).fold(lambda x: x ** 9) == 1

# Generated at 2022-06-18 01:59:36.859734
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) != First(2)


# Generated at 2022-06-18 01:59:39.009519
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).fold(lambda x: x) == 1


# Generated at 2022-06-18 01:59:48.494425
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    assert Semigroup(1).fold(lambda x: x * 2) == 2
    assert Semigroup(1).fold(lambda x: x - 1) == 0
    assert Semigroup(1).fold(lambda x: x / 2) == 0.5
    assert Semigroup(1).fold(lambda x: x ** 2) == 1
    assert Semigroup(1).fold(lambda x: x % 2) == 1
    assert Semigroup(1).fold(lambda x: x // 2) == 0
    assert Semigroup(1).fold(lambda x: x & 2) == 0
    assert Semigroup(1).fold(lambda x: x | 2) == 3
    assert Semigroup(1).fold(lambda x: x ^ 2) == 3

# Generated at 2022-06-18 01:59:51.116658
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == 'Map[value={\'a\': Sum[value=1], \'b\': Sum[value=2]}]'


# Generated at 2022-06-18 01:59:57.556276
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).value == 1
    assert Min(2).concat(Min(1)).value == 1
    assert Min(1).concat(Min(1)).value == 1
    assert Min(1).concat(Min(2)).value == 1
    assert Min(2).concat(Min(1)).value == 1
    assert Min(2).concat(Min(2)).value == 2


# Generated at 2022-06-18 02:00:02.574787
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1
    assert Last(2).value == 2
    assert Last(3).value == 3
    assert Last(4).value == 4
    assert Last(5).value == 5
    assert Last(6).value == 6
    assert Last(7).value == 7
    assert Last(8).value == 8
    assert Last(9).value == 9
    assert Last(10).value == 10


# Generated at 2022-06-18 02:02:28.131522
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-18 02:02:31.286164
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1).value == 1
    assert Sum(1).fold(lambda x: x) == 1
    assert Sum.neutral().value == 0


# Generated at 2022-06-18 02:02:35.816347
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert Last(1).value == 1
    assert Last(1).concat(Last(2)).value == 2
    assert Last(1).concat(Last(2)).concat(Last(3)).value == 3



# Generated at 2022-06-18 02:02:38.559769
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)


# Generated at 2022-06-18 02:02:42.214276
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1).value == 1
    assert Semigroup(1).fold(lambda x: x) == 1
    assert Semigroup.neutral().value == Semigroup.neutral_element
    assert Semigroup.neutral().fold(lambda x: x) == Semigroup.neutral_element


# Generated at 2022-06-18 02:02:44.697958
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-18 02:02:45.810109
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1


# Generated at 2022-06-18 02:02:48.185120
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)


# Generated at 2022-06-18 02:02:49.781945
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-18 02:02:51.786113
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'
