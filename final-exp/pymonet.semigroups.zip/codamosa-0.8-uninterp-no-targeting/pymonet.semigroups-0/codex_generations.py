

# Generated at 2022-06-21 19:34:23.285851
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-21 19:34:25.098209
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)).value == 1


# Generated at 2022-06-21 19:34:27.980968
# Unit test for method __str__ of class Max
def test_Max___str__():
    max = Max(5)
    assert max.__str__() == 'Max[value=5]'


# Generated at 2022-06-21 19:34:32.074359
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    try:
        Sum(1) == Sum(1)
    except:
        raise AssertionError("Can't create Sum class instance")
    finally:
        print('1. Test constructor of Sum class\n')


# Generated at 2022-06-21 19:34:33.587576
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).value == 1


# Generated at 2022-06-21 19:34:35.048643
# Unit test for constructor of class Last
def test_Last():
    result = Last(15)
    assert result.value == 15



# Generated at 2022-06-21 19:34:38.092916
# Unit test for method concat of class First
def test_First_concat():
    from dataclasses import dataclass

    @dataclass
    class A:
        value: int

    @dataclass
    class B:
        value: int

    a = A(1)
    b = B(2)
    assert First(a).concat(First(b)).value is a

# Generated at 2022-06-21 19:34:43.629170
# Unit test for constructor of class One
def test_One():
    a = One(None)
    b = One(0)
    c = One(1)
    d = One(False)
    e = One(True)

    assert a.value == a.neutral_element
    assert b.value == b.neutral_element
    assert c.value == c.neutral_element
    assert d.value == d.neutral_element
    assert e.value == e.neutral_element

# Generated at 2022-06-21 19:34:45.530955
# Unit test for method __str__ of class Max
def test_Max___str__():
    max_semigroup = Max(10)
    assert str(max_semigroup) == 'Max[value=10]'



# Generated at 2022-06-21 19:34:56.539227
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value is True
    assert All(True).concat(All(False)).value is False
    assert All(False).concat(All(False)).value is False
    assert All(True).concat(All(True)).value is True
    assert All(True).concat(All(0)).value is False
    assert All(True).concat(All(1)).value is True
    assert All(True).concat(All(2)).value is True
    assert All(None).concat(All(None)).value is False
    assert All("").concat(All("")).value is False
    assert All("").concat(All("bla-bla")).value is False
    assert All("bla-bla").concat(All("bla-bla")).value is True


# Generated at 2022-06-21 19:35:01.460432
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    expected = 'Fist[value=True]'
    actual = First(True).__str__()
    assert expected == actual

# Generated at 2022-06-21 19:35:03.184939
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(2)) == 'Last[value=2]'



# Generated at 2022-06-21 19:35:06.369384
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(2).concat(Max(3)) == Max(3)
    assert Max(3).concat(Max(2)) == Max(3)


# Generated at 2022-06-21 19:35:08.227182
# Unit test for constructor of class Semigroup
def test_Semigroup():
    class Int(Semigroup):
        pass
    assert Int(10).value == 10



# Generated at 2022-06-21 19:35:10.755258
# Unit test for constructor of class Map
def test_Map():
    #: Setup
    map_object = Map({"test": "me"})
    #: Test
    assert map_object.value == {"test": "me"}



# Generated at 2022-06-21 19:35:12.919742
# Unit test for method concat of class First
def test_First_concat():  # pragma: no cover
    assert First(1).concat(First(2)).value == First(1).value


# Generated at 2022-06-21 19:35:17.095517
# Unit test for method concat of class Last
def test_Last_concat():
    """
    >>> test_Last_concat()
    Last('23')
    """
    a = Last('1')
    b = Last('23')
    c = a.concat(b)
    print(c)
    return c


# Generated at 2022-06-21 19:35:18.796808
# Unit test for method __str__ of class One
def test_One___str__():
    one = One("test string")
    assert str(one) == 'One[value=test string]'



# Generated at 2022-06-21 19:35:22.123371
# Unit test for constructor of class First
def test_First():
    """
    Test if class accepts a string as input parameter
    
    Test id: T102
    
    Test data:
        value: "Test"
    Expected outcome:
        should be accepted
    """
    m = First("Test")
    assert m.value == "Test"
    

# Generated at 2022-06-21 19:35:23.185821
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(10)) == 'Max[value={}]'.format(10)



# Generated at 2022-06-21 19:35:27.152423
# Unit test for constructor of class Max
def test_Max():
    assert Max(0).value == 0



# Generated at 2022-06-21 19:35:30.282090
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map(value={"key 1": First(value="first value")})) == 'Map[value={\'key 1\': Fist[value=first value]}]'


# Generated at 2022-06-21 19:35:38.476448
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert Last(1).__str__() == 'Last[value=1]'
    assert Last(0).__str__() == 'Last[value=0]'
    assert Last("test").__str__() == 'Last[value=test]'
    assert Last("").__str__() == 'Last[value=]'
    assert Last([]).__str__() == 'Last[value=[]]'
    assert Last(['test0', 'test1']).__str__() == 'Last[value=[test0, test1]]'
    assert Last(()).__str__() == 'Last[value=()]'
    assert Last(('test0', 'test1')).__str__() == 'Last[value=(test0, test1)]'



# Generated at 2022-06-21 19:35:43.216861
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    test_cases = [
        (Sum(1), 'Sum[value=1]'),
        (Sum(-1), 'Sum[value=-1]'),
        (Sum(0.01), 'Sum[value=0.01]')
    ]

    for (input, expected) in test_cases:
        assert str(input) == expected



# Generated at 2022-06-21 19:35:45.100805
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'


# Generated at 2022-06-21 19:35:46.723379
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)).value == 2
    assert Last(1).concat(Last(1)).value == 1


# Generated at 2022-06-21 19:35:50.313670
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert Map({'a': Sum(5)}).__str__() == 'Map[value={\'a\': Sum[value=5]}]'


# Generated at 2022-06-21 19:35:51.784534
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(5)) == 'Max[value=5]'


# Generated at 2022-06-21 19:35:54.192531
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-21 19:35:54.855548
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)



# Generated at 2022-06-21 19:36:02.027960
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).concat(One(3)).value == 1
    assert One(1).concat(One(0)).value == 1
    assert One(0).concat(One(1)).value == 1
    assert One(0).concat(One(0)).value == 0



# Generated at 2022-06-21 19:36:05.506146
# Unit test for method concat of class Min
def test_Min_concat():
    x = Min(10)
    y = Min(12)
    z = Min(9)
    assert(x.concat(y).value == 10)
    assert(x.concat(z).value == 9)


# Generated at 2022-06-21 19:36:08.941005
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"one": Sum(1), "two": Sum(2)}).concat(Map({"two": Sum(2), "three": Sum(5)})) == Map({"one": Sum(1), "two": Sum(4), "three": Sum(5)})


# Generated at 2022-06-21 19:36:12.988156
# Unit test for constructor of class Max
def test_Max():  # pragma: no cover
    assert Max(1).value == 1
    assert Max(1.0).value == 1.0
    assert Max(1.0).value != 1



# Generated at 2022-06-21 19:36:14.390550
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)


# Generated at 2022-06-21 19:36:19.171012
# Unit test for constructor of class Semigroup
def test_Semigroup():
    test_1 = Semigroup(12)
    test_2 = Semigroup(34)

    assert test_1 == test_1
    assert not test_1 == test_2
    assert test_1.fold(lambda x: x == 12)
    assert not test_2.fold(lambda x: x == 12)


# Generated at 2022-06-21 19:36:21.067100
# Unit test for method concat of class One
def test_One_concat():
   result = One(True).concat(One(False))
   assert result.value == True


# Generated at 2022-06-21 19:36:23.239771
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert str(Max(5)) == 'Max[value=5]'
    assert str(Max(-1)) == 'Max[value=-1]'


# Generated at 2022-06-21 19:36:26.511436
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last('Jakub').concat(Last('test')) == Last('test')
    assert Last('Jakub').concat(Last(123)) == Last(123)
    assert Last(123).concat(Last('Jakub')) == Last('Jakub')
    assert Last(Last('Jakub')).concat(Last('test')) == Last('test')



# Generated at 2022-06-21 19:36:30.038552
# Unit test for method __str__ of class Max
def test_Max___str__():
    """
    Test the method __str__ of the class Max
    """
    max_semigroup = Max(3)
    assert str(max_semigroup) == 'Max[value=3]'


# Generated at 2022-06-21 19:36:37.971838
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum_instance = Sum(2)
    assert str(sum_instance) == 'Sum[value=2]'



# Generated at 2022-06-21 19:36:41.188712
# Unit test for method concat of class Max
def test_Max_concat():
    a = Max(1)
    b = Max(2)
    c = a.concat(b)
    assert c.value == 2, 'assertion error: c.value == 2'


# Generated at 2022-06-21 19:36:53.712232
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    Unit test for method concat of class Sum
    """
    num1 = 1
    num2 = 2
    num3 = 3
    sum1 = Sum(num1)
    sum2 = Sum(num2)
    sum3 = Sum(num3)
    assert sum1.concat(sum2).concat(sum3).fold(lambda val: val) == 6
    assert sum1.concat(sum2) == Sum(3)
    assert sum3.concat(sum1).concat(sum2) == Sum(6)
    assert sum3.concat(Sum.neutral()) == Sum(num3)
    assert Sum.neutral().concat(sum2) == Sum(num2)
    assert Sum.neutral().concat(Sum.neutral()) == Sum.neutral()

# Generated at 2022-06-21 19:36:57.238089
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First("1").concat(First(2)) == First("1")


# Generated at 2022-06-21 19:36:59.392083
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)


# Generated at 2022-06-21 19:37:00.781625
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(10)) == 'Min[value=10]'



# Generated at 2022-06-21 19:37:02.075609
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'

# Generated at 2022-06-21 19:37:04.298292
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    last = Last('test')
    assert str(last) == 'Last[value=test]'



# Generated at 2022-06-21 19:37:05.570236
# Unit test for constructor of class First
def test_First():
    value = 'first'
    first = First(value)
    assert first.value == value



# Generated at 2022-06-21 19:37:08.498603
# Unit test for constructor of class Last
def test_Last():
    assert Last(123).value == 123
    assert Last(123).fold(lambda x: x) == 123


# Generated at 2022-06-21 19:37:22.261989
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)


# Generated at 2022-06-21 19:37:23.813366
# Unit test for constructor of class First
def test_First():
    assert str(First(2)) == "Fist[value=2]"


# Generated at 2022-06-21 19:37:24.776335
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1



# Generated at 2022-06-21 19:37:26.662790
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-21 19:37:28.258418
# Unit test for method __str__ of class All
def test_All___str__():
    assert All([1, 2]).__str__() is 'All[value=[1, 2]]'


# Generated at 2022-06-21 19:37:33.683488
# Unit test for constructor of class Map
def test_Map():
    m = Map({})
    assert m.value == {}, "Should be equal"
    assert m == Map({}), "Should be equal"

    m = Map({1: Sum(1)})
    assert m.value == {1: Sum(1)}, "Should be equal"
    assert m == Map({1: Sum(1)}), "Should be equal"



# Generated at 2022-06-21 19:37:38.114530
# Unit test for method concat of class Last
def test_Last_concat():
    assert First(None).concat(First('abc')).value == None
    assert First(None).concat(First(None)).value == None
    assert First(1).concat(First('abc')).value == 1
    assert First(1).concat(First(None)).value == 1


# Generated at 2022-06-21 19:37:39.482122
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-21 19:37:48.758414
# Unit test for constructor of class Max
def test_Max():
    # Max(input_value)
    assert Max(2) == Max(2)
    assert Max(2.0) == Max(2.0)
    assert Max(float("inf")) == Max(float("inf"))
    assert Max(-float("inf")) == Max(-float("inf"))
    assert Max(float("nan")) == Max(float("nan"))
    assert Max(float("NaN")) == Max(float("NaN"))
    assert Max(None) == Max(None)
    assert Max(True) == Max(True)
    assert Max(False) == Max(False)
    assert Max(2.0) != Max(float("inf"))
    assert Max(float("NaN")) != Max(float("inf"))
    assert Max(None) != Max(float("inf"))
    assert Max(True) != Max(float("inf"))

# Generated at 2022-06-21 19:37:54.654897
# Unit test for constructor of class Max
def test_Max():
    max_1 = Max(1)
    max_2 = Max(2)
    max_3 = Max(3)
    assert max_1.concat(max_2).concat(max_3).concat(max_2) == max_3



# Generated at 2022-06-21 19:38:19.818658
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert Sum(1).value == 1


# Generated at 2022-06-21 19:38:23.301452
# Unit test for method concat of class Min
def test_Min_concat():
    x = Min(4)
    y = Min(44)
    assert x.concat(y).value == 4
    assert y.concat(x).value == 4



# Generated at 2022-06-21 19:38:26.473171
# Unit test for method concat of class Max
def test_Max_concat():
    semigroup_0 = Max(5)
    semigroup_1 = Max(10)
    assert semigroup_0.concat(semigroup_1) == Max(10)



# Generated at 2022-06-21 19:38:30.199042
# Unit test for method concat of class Min
def test_Min_concat():
    min_value_1 = Min(2)
    min_value_2 = Min(1)

    assert Min.neutral() == Min(-float("inf")), 'neutral() should return -float("inf")'
    assert min_value_1.concat(min_value_2) == min_value_2

# Generated at 2022-06-21 19:38:35.202194
# Unit test for method concat of class Map
def test_Map_concat():
    x = Map({"a": Sum(1), "b": Sum(2)})
    y = Map({"a": Sum(3), "b": Sum(4)})
    assert x.concat(y) == Map({"a": Sum(4), "b": Sum(6)})



# Generated at 2022-06-21 19:38:36.836306
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'



# Generated at 2022-06-21 19:38:40.477386
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({'foo': Sum(5), 'bar': All(True)})
    m2 = Map({'foo': Sum(4), 'bar': All(False)})
    assert m1.concat(m2) == Map({'foo': Sum(9), 'bar': All(False)})



# Generated at 2022-06-21 19:38:45.716077
# Unit test for method concat of class One
def test_One_concat():
    assert One(False).concat(One(False)) == One(False)
    assert One(False).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(True).concat(One(True)) == One(True)



# Generated at 2022-06-21 19:38:51.853736
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(1)) == Sum(2)
    assert Sum(5).concat(Sum(1)) == Sum(6)
    assert Sum(8).concat(Sum(2)) == Sum(10)
    assert Sum(0).concat(Sum(2)) == Sum(2)
    assert Sum(6).concat(Sum(-3)) == Sum(3)
    assert Sum(-4).concat(Sum(-3)) == Sum(-7)


# Generated at 2022-06-21 19:38:52.895869
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(5) == Sum(5)
    assert Sum(5) != Sum(6)



# Generated at 2022-06-21 19:39:40.494864
# Unit test for method concat of class First
def test_First_concat():
    assert First('Python').concat(First('Scala')) == First('Python')


# Generated at 2022-06-21 19:39:41.867291
# Unit test for constructor of class First
def test_First():
    f = First("a")
    assert f.value == "a"


# Generated at 2022-06-21 19:39:46.546645
# Unit test for method __str__ of class Map
def test_Map___str__(): # pragma: no cover
    assert Map({}).__str__() == 'Map[value={}]'
    assert Map({1: '2'}).__str__() == "Map[value={1: '2'}]"


# Generated at 2022-06-21 19:39:53.736110
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    """
    class Sum(Semigroup):
        def __str__(self) -> str:
            return 'Sum[value={}]'.format(self.value)
    """
    assert str(Sum(1)) == "Sum[value=1]"
    assert str(Sum(-1)) == "Sum[value=-1]"
    assert str(Sum(0)) == "Sum[value=0]"
    assert str(Sum(3.14)) == "Sum[value=3.14]"
    assert str(Sum(-3.14)) == "Sum[value=-3.14]"



# Generated at 2022-06-21 19:39:55.284886
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    assert str(Last(value=1)) == 'Last[value=1]'


# Generated at 2022-06-21 19:39:56.890416
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-21 19:40:00.544487
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(2)).concat(Max(3)) == Max(3)


# Generated at 2022-06-21 19:40:02.590789
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)).value == First(1).value


# Generated at 2022-06-21 19:40:04.324880
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-21 19:40:05.990247
# Unit test for method concat of class First
def test_First_concat():
    assert str(First(1).concat(First(2))) == "Fist[value=1]"



# Generated at 2022-06-21 19:41:49.955286
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    result = Semigroup(-1).fold(lambda value: value + 2)
    assert result == 1



# Generated at 2022-06-21 19:41:51.367333
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(2)) == 'Min[value=2]'


# Generated at 2022-06-21 19:41:54.471675
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-21 19:41:57.277230
# Unit test for method concat of class First
def test_First_concat():
    a = First(1)
    b = First(2)
    c = First(3)

    assert a.concat(b).concat(c).value == 1



# Generated at 2022-06-21 19:41:59.460703
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Unit tests for method concat of class Last

# Generated at 2022-06-21 19:42:01.202624
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)


# Generated at 2022-06-21 19:42:02.998091
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(5).concat(Min(7)) == Min(5)
    assert Min(2).concat(Min(3)) == Min(2)

# Generated at 2022-06-21 19:42:05.401575
# Unit test for method concat of class All
def test_All_concat():
    assert True == All(True).concat(All(True)).value
    assert False == All(True).concat(All(False)).value
    assert False == All(False).concat(All(False)).value


# Generated at 2022-06-21 19:42:07.614856
# Unit test for constructor of class Sum
def test_Sum(): # pragma: no cover
    assert Sum(1).value == 1


# Generated at 2022-06-21 19:42:11.131782
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)).value == 3
    assert Sum(0).concat(Sum(2)).value == 2
    assert Sum(1).concat(Sum(0)).value == 1
