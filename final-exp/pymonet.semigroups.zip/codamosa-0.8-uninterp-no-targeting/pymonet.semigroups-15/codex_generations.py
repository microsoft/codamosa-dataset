

# Generated at 2022-06-21 19:34:26.366941
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    last = Last([1, 2, 3])
    assert str(last) == 'Last[value=[1, 2, 3]]'



# Generated at 2022-06-21 19:34:30.552694
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(4)) == Sum(5)
    assert Sum(2).concat(Sum(2)) == Sum(4)


# Generated at 2022-06-21 19:34:32.426090
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(-5)) == Min(-5)


# Generated at 2022-06-21 19:34:35.187855
# Unit test for method __str__ of class First
def test_First___str__():
    assert First(0).__str__() == 'Fist[value=0]'
    assert First('a').__str__() == 'Fist[value=a]'


# Generated at 2022-06-21 19:34:39.041521
# Unit test for constructor of class Last
def test_Last():  # pragma: no cover
    assert Last(1) == Last(1)
    assert Last(1) is not Last(1)
    assert Last(1) is not Sum(1)
    assert Last(1) is not First(1)
    assert Last(1) is not All(1)
    assert Last(1) is not One(1)
    assert Last(1) is not Min(1)
    assert Last(1) is not Max(1)



# Generated at 2022-06-21 19:34:41.327495
# Unit test for method __str__ of class First
def test_First___str__():
    """
    Unit test for method __str__ of class First
    """

    assert str(First('test')) == 'Fist[value=test]'

# Generated at 2022-06-21 19:34:43.775758
# Unit test for method concat of class First
def test_First_concat():
    a = First(2)
    b = First(3)
    result = a.concat(b)
    assert isinstance(result, First)
    assert result.value == 2



# Generated at 2022-06-21 19:34:46.390573
# Unit test for method __str__ of class Map
def test_Map___str__():
    m = Map({'first_one': Sum(1), 'second_one': Sum(2)})
    compare(m.__str__(), 'Map[value={\'first_one\': Sum[value=1], \'second_one\': Sum[value=2]}]')


# Generated at 2022-06-21 19:34:52.416820
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2), 'Test failed'
    assert Max(2).concat(Max(1)) == Max(2), 'Test failed'
    assert Max(2).concat(Max(2)) == Max(2), 'Test failed'
    assert Max(1).concat(Max(1)) == Max(1), 'Test failed'


# Generated at 2022-06-21 19:34:55.634386
# Unit test for constructor of class One
def test_One():
    """ Test constructor of class One """
    assert One(True).value == True
    assert One(1).value == 1
    assert One(lambda x: x).value(1) == 1
    return "test_One ok"


# Generated at 2022-06-21 19:35:00.483992
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert str(All(True)) == "All[value=True]"



# Generated at 2022-06-21 19:35:05.194766
# Unit test for constructor of class Sum
def test_Sum():
    monoid = Sum(2)
    cls = Sum.__name__
    assert monoid != 2
    assert monoid.value == 2
    assert monoid.__class__.__name__ == cls
    assert isinstance(monoid, Sum)



# Generated at 2022-06-21 19:35:07.769696
# Unit test for constructor of class Map
def test_Map():
    assert Map({"foo": First(1), "bar": Last(2)}) == Map({"foo": First(1), "bar": Last(2)})
    assert Map({"foo": First(1), "bar": Last(2)}).value == {"foo": First(1), "bar": Last(2)}


# Generated at 2022-06-21 19:35:10.459312
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    a = Semigroup(1)
    b = Semigroup(1)
    c = Semigroup(2)
    assert a == b
    assert a != c


# Generated at 2022-06-21 19:35:11.923124
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(0)) == 'Max[value=0]'



# Generated at 2022-06-21 19:35:19.025293
# Unit test for method concat of class Min
def test_Min_concat():
    """
    concat - min is a Monoid that will combines 2 numbers, resulting in the smallest of the two.
    """
    asser(Min(1).concat(Min(2)) == Min(1))
    asser(Min(2).concat(Min(2)) == Min(2))
    asser(Min(3).concat(Min(2)) == Min(2))
    asser(Min(2).concat(Min(3)) == Min(2))
    asser(Min(4).concat(Min(3)) == Min(3))
    asser(Min(3).concat(Min(4)) == Min(3))



# Generated at 2022-06-21 19:35:21.811073
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(7)) == Max(7)
    assert Max(5).concat(Max(5)) == Max(5)
    assert Max(5).concat(Max(-1)) == Max(5)


# Generated at 2022-06-21 19:35:29.333096
# Unit test for method concat of class All
def test_All_concat():
    actual = All(True).concat(All(True))
    expected = All(True)
    assert actual == expected, 'All(True).concat(All(True)) -> All[value=True]'

    actual = All(True).concat(All(False))
    expected = All(False)
    assert actual == expected, 'All(True).concat(All(False)) -> All[value=False]'

    actual = All(False).concat(All(False))
    expected = All(False)
    assert actual == expected, 'All(False).concat(All(False)) -> All[value=False]'

# Generated at 2022-06-21 19:35:32.072784
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    :param semigroup:
    :type semigroup:
    """
    assert Semigroup(1).fold(lambda value: value * 2) == 2

# Generated at 2022-06-21 19:35:34.098385
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True).value == True
    assert All(False).value == False


# Generated at 2022-06-21 19:35:43.494725
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)
    assert All(True).fold(lambda x: x) == True
    assert All(True).neutral().value == True


# Generated at 2022-06-21 19:35:50.484346
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)
    assert Min(1).concat(Max(2)) == Min(1)
    assert Min(2).concat(Max(1)) == Min(1)
    assert Min(1).concat(Max(1)) == Min(1)
    assert Min(1).concat(Last(1)) == Min(1)
    assert Min(2).concat(Last(1)) == Min(1)
    assert Min(1).concat(Last(2)) == Min(1)
    assert Min(1).concat(First(1)) == Min(1)

# Generated at 2022-06-21 19:35:51.925917
# Unit test for constructor of class Max
def test_Max():
    value = 3
    assert Max(value).value == value


# Generated at 2022-06-21 19:35:54.730013
# Unit test for constructor of class Last
def test_Last():
    lst = Last('a')
    assert lst.value == 'a'


# Generated at 2022-06-21 19:35:56.540151
# Unit test for method concat of class Min
def test_Min_concat():
    min_4 = Min(4)
    min_10 = Min(10)
    assert min_4.concat(min_10) == Min(4)
    assert min_10.concat(min_4) == Min(4)


# Generated at 2022-06-21 19:35:57.441609
# Unit test for constructor of class One
def test_One():
    assert(One(True).value)


# Generated at 2022-06-21 19:36:00.376506
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(0).concat(Min(-1)) == Min(-1)
    assert Min(0).concat(Min(1)) == Min(0)

test_Min_concat()



# Generated at 2022-06-21 19:36:03.235343
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_one = Sum(1)
    sum_two = Sum(2)

    assert(sum_one.concat(sum_two) == Sum(3))



# Generated at 2022-06-21 19:36:04.659615
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(10)) == 'One[value=10]'



# Generated at 2022-06-21 19:36:12.453339
# Unit test for method __str__ of class All
def test_All___str__():
    assert First(1).__str__() == 'Fist[value=1]'
    assert Last(2).__str__() == 'Last[value=2]'
    assert Map({'one': Sum(1), 'two': Sum(2)}).__str__() == "Map[value={'one': Sum[value=1], 'two': Sum[value=2]}]"
    assert Sum(1).__str__() == 'Sum[value=1]'
    assert All(True).__str__() == 'All[value=True]'
    assert One(False).__str__() == 'One[value=False]'
    assert Max(1).__str__() == 'Max[value=1]'
    assert Min(1).__str__() == 'Min[value=1]'



# Generated at 2022-06-21 19:36:17.413518
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True).value == True
    assert One(False).value == False


# Generated at 2022-06-21 19:36:19.218955
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert (str(Max(10)) == 'Max[value=10]')


# Generated at 2022-06-21 19:36:21.574370
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(10).fold(lambda x: x * 2) == 20
    assert Semigroup("test").fold(lambda x: x * 4) == "testtesttesttest"


# Generated at 2022-06-21 19:36:22.908928
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True) != All(False)



# Generated at 2022-06-21 19:36:25.597403
# Unit test for constructor of class Max
def test_Max():
    assert Max(10) == Max(10)
    assert Max(-10) == Max(-10)


# Generated at 2022-06-21 19:36:30.688435
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1) == Max(1).concat(Max(1))
    assert Max(10) == Max(6).concat(Max(10))
    assert Max(0) == Max(0).concat(Max(0))
    assert Max(-1) == Max(-10).concat(Max(-1))



# Generated at 2022-06-21 19:36:35.125675
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(None)) == First(None)


# Generated at 2022-06-21 19:36:37.725265
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(3).concat(Min(2)) == Min(2)


# Generated at 2022-06-21 19:36:38.882185
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)



# Generated at 2022-06-21 19:36:40.564532
# Unit test for method concat of class Last
def test_Last_concat():
    assert str(Last(3).concat(Last(4))) == 'Last[value=4]'


# Generated at 2022-06-21 19:36:46.974573
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    SemigroupMock = mock.create_autospec(Semigroup)
    function = mock.Mock()
    assert SemigroupMock(5).fold(function) == function(5)


# Generated at 2022-06-21 19:36:51.001473
# Unit test for method concat of class Max
def test_Max_concat():
    # given
    first_value = Max(0)
    second_value = Max(1)

    # when
    result_value = first_value.concat(second_value)

    # then
    assert result_value == Max(1)


# Generated at 2022-06-21 19:36:52.370654
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == "Min[value=1]"


# Generated at 2022-06-21 19:36:53.761478
# Unit test for constructor of class Last
def test_Last():
    last = Last(1)
    print(last)



# Generated at 2022-06-21 19:36:59.547676
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True
    assert One(False).value == False
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(True)).value == True
    assert One(False).concat(One(False)).value == False
    assert One(False).concat(One(False)).value == False


# Generated at 2022-06-21 19:37:00.906654
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-21 19:37:01.866810
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert 'Max[value=10]' == str(Max(10))



# Generated at 2022-06-21 19:37:03.582977
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)).value == 1



# Generated at 2022-06-21 19:37:06.514063
# Unit test for method concat of class One
def test_One_concat():  # pragma: no cover
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(False)) == One(False)



# Generated at 2022-06-21 19:37:09.764126
# Unit test for method __str__ of class Max
def test_Max___str__():
    max_ = Max(1)
    assert str(max_) == 'Max[value=1]'


# Generated at 2022-06-21 19:37:14.414876
# Unit test for method __str__ of class Last
def test_Last___str__():
    source = Last(1)
    assert str(source) == 'Last[value=1]'



# Generated at 2022-06-21 19:37:18.267443
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).concat(Min(3)) == Min(1)
    assert Min(5).concat(Min(3)).concat(Min(1)) == Min(1)
    assert Min(4).concat(Min(4)).concat(Min(4)) == Min(4)

# Generated at 2022-06-21 19:37:20.969551
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_1 = Sum(1)
    sum_2 = Sum(2)
    assert sum_1.concat(sum_2) == Sum(sum_1.value + sum_2.value)


# Generated at 2022-06-21 19:37:23.173866
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(5) == Semigroup(5)
    assert Semigroup(5) != Semigroup(6)
    assert Semigroup(5) != 5



# Generated at 2022-06-21 19:37:25.439818
# Unit test for constructor of class All
def test_All():
    s = All(True)
    assert s.value == True
    assert s.fold(str) == 'All[value=True]'


# Generated at 2022-06-21 19:37:35.793508
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'
    assert str(Sum(0)) == 'Sum[value=0]'
    assert str(Sum(float("inf"))) == 'Sum[value=' + str(float("inf")) + ']'
    assert str(Sum(float("-inf"))) == 'Sum[value=' + str(float("-inf")) + ']'
    assert str(Sum("aa")) == 'Sum[value=aa]'
    assert str(Sum("")) == 'Sum[value=]'
    assert str(Sum("ab")) == 'Sum[value=ab]'
    assert str(Sum(Sum(20))) == 'Sum[value=Sum[value=20]]'
    assert str(Sum(True)) == 'Sum[value=True]'
    assert str(Sum(False)) == 'Sum[value=False]'


# Generated at 2022-06-21 19:37:38.016937
# Unit test for constructor of class Min
def test_Min():
    a = Min(1)
    assert a.value == 1
    assert a.neutral_element == float("inf")


# Generated at 2022-06-21 19:37:39.387583
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == "Max[value=1]"


# Generated at 2022-06-21 19:37:43.681258
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(Sum(1).fold(lambda x: x)).fold(lambda x: x + 2) == 3
    assert Max(Max(1).fold(lambda x: x + 2)).fold(lambda x: x) == 3
    assert Min(Min(1).fold(lambda x: x)).fold(lambda x: x) == 1

# Generated at 2022-06-21 19:37:44.961873
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-21 19:37:53.497668
# Unit test for constructor of class Max
def test_Max():
    """
    :returns: test result
    :rtype: bool
    """
    return Max(5) == Max(5)


# Generated at 2022-06-21 19:37:55.067134
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-21 19:37:57.721088
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(2).concat(First(1)) == First(1)


# Generated at 2022-06-21 19:37:59.539219
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).__str__() == 'Sum[value=1]'



# Generated at 2022-06-21 19:38:03.130871
# Unit test for method __str__ of class Max
def test_Max___str__():
    # Arrange
    max_ = Max(100)
    except_result = 'Max[value=100]'

    # Act
    result = str(max_)

    # Assert
    assert result == except_result



# Generated at 2022-06-21 19:38:06.101902
# Unit test for constructor of class First
def test_First():
    # Setup
    test_value = {1, 2, 3}
    sut = First(test_value)
    assert str(sut) == "Fist[value={1, 2, 3}]"



# Generated at 2022-06-21 19:38:10.346401
# Unit test for method __str__ of class Last
def test_Last___str__():
    # Given
    _last = Last(value='test')

    # When
    _actual = _last.__str__()

    # Then
    _expected = "Last[value=test]"
    assert _actual == _expected



# Generated at 2022-06-21 19:38:14.588903
# Unit test for constructor of class First
def test_First():
    assert First(1)
    assert First(0)
    assert First(None)
    assert First(False)
    assert First(True)
    assert First(0)
    assert First(float('inf'))


# Generated at 2022-06-21 19:38:18.999888
# Unit test for method concat of class All
def test_All_concat():
    result = All(True).concat(All(True))
    assert result == All(True)

    result = All(True).concat(All(False))
    assert result == All(False)

    result = All(False).concat(All(True))
    assert result == All(False)

    result = All(False).concat(All(False))
    assert result == All(False)


# Generated at 2022-06-21 19:38:22.242691
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1
    assert Sum(1.1).value == 1.1
    assert Sum("a").value == "a"



# Generated at 2022-06-21 19:38:37.275778
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1
    assert Last(0).value == 0
    assert Last(1) == Last(1)
    assert Last(0) == Last(0)
    assert Last(1) != Last(0)



# Generated at 2022-06-21 19:38:38.931572
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    :returns: None
    :rtype: NoneType
    """
    assert Semigroup(True) == Semigroup(True)



# Generated at 2022-06-21 19:38:40.926714
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1


# Generated at 2022-06-21 19:38:42.239110
# Unit test for constructor of class Max
def test_Max():
    assert Max(3) == Max(3)


# Generated at 2022-06-21 19:38:45.564109
# Unit test for method __str__ of class Last
def test_Last___str__():
    """
    Check if method __str__ of Last return correct string
    """
    assert str(Last(1)) == "Last[value=1]"



# Generated at 2022-06-21 19:38:48.000358
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-21 19:38:49.018159
# Unit test for constructor of class Max
def test_Max():
    assert Max(-1).value == -1

# Generated at 2022-06-21 19:38:51.683397
# Unit test for constructor of class First
def test_First():
    sum1 = First(3)
    sum2 = First(4)
    sum3 = sum1.concat(sum2)
    assert sum3.value == 3



# Generated at 2022-06-21 19:38:53.573788
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    _x = Max(10).__str__()
    assert _x == "Max[value=10]"

# Generated at 2022-06-21 19:38:55.651319
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-21 19:39:20.983276
# Unit test for constructor of class Max
def test_Max():
    assert Max(5).value == 5


# Generated at 2022-06-21 19:39:24.770521
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'
    assert str(Sum(2)) == 'Sum[value=2]'
    assert str(Sum(3)) == 'Sum[value=3]'



# Generated at 2022-06-21 19:39:26.098543
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'


# Generated at 2022-06-21 19:39:31.552577
# Unit test for constructor of class Min
def test_Min():
    m = Min(1)
    assert m.value == 1
    assert m.neutral_element == float("inf")
    assert m.concat(Min(2)).value == 1
    assert m.concat(Min(1)).value == 1
    assert m.concat(Min(0)).value == 0
    assert m.concat(Min(m.neutral_element)).value == 1


# Generated at 2022-06-21 19:39:35.986664
# Unit test for method concat of class All
def test_All_concat():
    assert All(False).concat(All(True)) == All(False)
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(False)) == All(False)
    assert type(All(False).concat(All(True))) == All
    assert type(All(True).concat(All(True))) == All
    assert type(All(False).concat(All(False))) == All



# Generated at 2022-06-21 19:39:38.085598
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    assert str(Last(1)) == "Last[value=1]"


# Generated at 2022-06-21 19:39:42.896003
# Unit test for constructor of class First
def test_First():
    # when
    a = First(1)
    b = First(2)
    c = First(3)
    d = First(4)

    # then
    assert a == First(1)
    assert b == First(2)
    assert c == First(3)
    assert d == First(4)



# Generated at 2022-06-21 19:39:46.187050
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert str(Max(2)) == 'Max[value=2]'


# Generated at 2022-06-21 19:39:56.229244
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(123) == Semigroup(123)
    assert Semigroup(123) == Sum(123)
    assert Semigroup(123) == All(123)
    assert Semigroup(123) == One(123)
    assert Semigroup(123) == First(123)
    assert Semigroup(123) == Last(123)
    assert Semigroup(123) == Map({'value': Sum(123)})
    assert Semigroup(123) == Max(123)
    assert Semigroup(123) == Min(123)

    assert Semigroup(123) != Semigroup(321)
    assert Semigroup(123) != Sum(321)
    assert Semigroup(123) != All(321)
    assert Semigroup(123) != One(321)
    assert Semigroup(123) != First(321)
    assert Semigroup(123) != Last

# Generated at 2022-06-21 19:39:59.958567
# Unit test for method __str__ of class Map
def test_Map___str__(): # pragma: no cover
    assert str(Map({'key_1': First(1), 'key_2': Last(2)})) == 'Map[value={\'key_1\': Fist[value=1], \'key_2\': Last[value=2]}]'


# Generated at 2022-06-21 19:40:50.663482
# Unit test for method concat of class Last
def test_Last_concat():
    last = Last("a")
    last = last.concat(Last("b"))
    assert last == Last("b")



# Generated at 2022-06-21 19:40:54.598529
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(1)) == 'All[value=1]'
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'
    assert str(All(None)) == 'All[value=None]'
    assert str(All('test')) == 'All[value=test]'


# Generated at 2022-06-21 19:40:56.874423
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-21 19:41:01.982987
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).value == 1
    assert Min(-1).concat(Min(-2)).value == -2
    assert Min(13).concat(Min(3)).value == 3
    assert Min(1).concat(Min(-2)).value == -2
    assert Min(-4).concat(Min(-4)).value == -4

# Generated at 2022-06-21 19:41:02.711710
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__(): ...

# Generated at 2022-06-21 19:41:04.162740
# Unit test for constructor of class Min
def test_Min():
    assert Min(2) == Min(2)
    assert Min(3) != Min(4)


# Generated at 2022-06-21 19:41:05.292548
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(2)) == "Last[value=2]"


# Generated at 2022-06-21 19:41:07.437012
# Unit test for method __str__ of class All
def test_All___str__():
    """
    Simple unit test for method __str__ of class All
    """

    string = 'All[value=True]'
    assert str(All(True)) == string



# Generated at 2022-06-21 19:41:08.504797
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(10)) == 'Max[value=10]'



# Generated at 2022-06-21 19:41:09.863751
# Unit test for constructor of class One
def test_One():
    a = One(True)
    b = One(True)
    assert a == b


# Generated at 2022-06-21 19:43:09.422982
# Unit test for method concat of class Sum
def test_Sum_concat():
    v1 = Sum(5)
    v2 = Sum(1)
    v3 = Sum(-5)
    assert v1.concat(v2) == Sum(6)
    assert v2.concat(v1) == Sum(6)
    assert v3.concat(v1) == Sum(0)


# Generated at 2022-06-21 19:43:10.561534
# Unit test for constructor of class Last
def test_Last():
    assert Last(10) == Last(10)


# Generated at 2022-06-21 19:43:11.965371
# Unit test for constructor of class First
def test_First():
    Semigroup(instantiate=First)


# Generated at 2022-06-21 19:43:13.875139
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-21 19:43:16.152816
# Unit test for constructor of class Min
def test_Min():  # pragma: no cover
    assert Min(5) == Min(5)


# Generated at 2022-06-21 19:43:17.339400
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert Sum(4) == Sum(4)

# Generated at 2022-06-21 19:43:22.150998
# Unit test for constructor of class One
def test_One():
    assert One(True) is One(True)
    assert One(True) is not One(False)
    assert One(False) is not One(True)
    assert One(False) is One(False)
    assert One(None) is One(None)
    assert One(None) is not One(True)
    assert One(None) is not One(False)

# Generated at 2022-06-21 19:43:25.065732
# Unit test for constructor of class Min
def test_Min():
    assert Min(10).value == 10, "Min value"


# Generated at 2022-06-21 19:43:26.659915
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-21 19:43:33.300657
# Unit test for constructor of class All
def test_All():
    assert All(None) == All(None)
    assert All(True) == All(True)
    assert All(42) == All(42)
    assert All(1) == All(1)
    assert All(None) != All(True)
    assert All(True) != All(42)
    assert All(42) != All(1)
    assert All(1) != All(None)
