

# Generated at 2022-06-21 19:34:15.552107
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(3).concat(Min(4)) == Min(3)
    assert Min(3).concat(Min(2)) == Min(2)
    assert Min(4).concat(Min(4)) == Min(4)
    assert Min(4).concat(Min(3)) == Min(3)



# Generated at 2022-06-21 19:34:19.878253
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    Test to create Semigroup.
    """
    assert Semigroup(1) == Sum(1)
    assert Semigroup(True) == All(True)
    assert Semigroup(False) == One(False)
    assert Semigroup([1, 2]) == Map({'value': Last([1, 2])})
    assert Semigroup({'value': Last([1, 2])}) == Map({'value': Last([1, 2])})


# Generated at 2022-06-21 19:34:21.071565
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)).value == False



# Generated at 2022-06-21 19:34:28.568770
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    all_true = All(True)
    all_false = All(False)
    assert all_false.concat(all_true) == All(False)
    assert all_true.concat(all_false) == All(False)
    assert all_false.concat(all_false) == All(False)
    assert all_true.concat(all_true) == All(True)


# Generated at 2022-06-21 19:34:30.661079
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert __str__(Sum(2)) == 'Sum[value=2]'


# Generated at 2022-06-21 19:34:32.922135
# Unit test for constructor of class Semigroup
def test_Semigroup():
    s = Semigroup(99)
    assert s.value == 99
    assert s.fold(sum) == 99
    assert str(s) == '-> 99'
    assert s == Semigroup(99)


# Generated at 2022-06-21 19:34:35.938183
# Unit test for method concat of class One
def test_One_concat():
    one = One(True)
    false_one = One(False)

    result = one.concat(false_one)
    expected = One(True)

    assert result == expected


# Generated at 2022-06-21 19:34:37.225815
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(3).value == 3


# Generated at 2022-06-21 19:34:38.737470
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert 'Sum[value=1]' == str(Sum(1))


# Generated at 2022-06-21 19:34:40.546199
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1

# Generated at 2022-06-21 19:34:47.036411
# Unit test for constructor of class Map
def test_Map():
    """
    test_Map() - unit test for constructor of class Map
    """

    data = {1: Sum(1), 2: Sum(2), 3: Sum(3)}
    m = Map(data)
    assert m.fold(list) == data
    assert m == Map(data)
    assert m.value == data



# Generated at 2022-06-21 19:34:48.778422
# Unit test for constructor of class Last
def test_Last():  # pragma: no cover
    last = Last(4)
    assert last.value == 4


# Generated at 2022-06-21 19:34:52.325560
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'key1': Sum(0), 'key2': Sum(0)}).concat(Map({'key1': Sum(1), 'key2': Sum(2)})) == Map({'key1': Sum(1), 'key2': Sum(2)})

# Generated at 2022-06-21 19:34:54.134159
# Unit test for constructor of class Max
def test_Max():
    assert Max(5) == Max(5)
    assert Max(5) != Max(6)



# Generated at 2022-06-21 19:35:00.330083
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(4)) == 'Max[value=4]'



# Generated at 2022-06-21 19:35:01.757530
# Unit test for constructor of class Last
def test_Last():
    semigroup = Last(1)
    assert semigroup.value == 1

# Generated at 2022-06-21 19:35:04.262469
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(4) == Max(4)


# Generated at 2022-06-21 19:35:05.210147
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"


# Generated at 2022-06-21 19:35:06.668779
# Unit test for constructor of class Max
def test_Max():
    max = Max(10)
    assert max.value == 10


# Generated at 2022-06-21 19:35:07.575188
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(3)) == "Fist[value=3]"


# Generated at 2022-06-21 19:35:11.396534
# Unit test for method __str__ of class All
def test_All___str__():
    assert All(True).__str__() == 'All[value=True]'
    assert All(False).__str__() == 'All[value=False]'


# Generated at 2022-06-21 19:35:13.522675
# Unit test for method __str__ of class Min
def test_Min___str__():
    number = 12
    semigroup = Min(number)
    assert str(semigroup) == "Min[value=12]"


# Generated at 2022-06-21 19:35:17.277743
# Unit test for constructor of class Map
def test_Map():
    """
    Unit test for constructor of class Map
    """
    dict_map = {
        1: Sum(1),
        2: Sum(2)
    }
    assert Map(dict_map) == Map(dict_map)



# Generated at 2022-06-21 19:35:19.202292
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(1)) == 'All[value=1]'
    assert str(All('a')) == 'All[value=a]'


# Generated at 2022-06-21 19:35:20.313844
# Unit test for constructor of class Min
def test_Min():
    minValue = Min(2)
    assert minValue.value == 2


# Generated at 2022-06-21 19:35:22.124221
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)



# Generated at 2022-06-21 19:35:23.041690
# Unit test for method __str__ of class First
def test_First___str__():
    s = First('lorem ipsum')
    assert str(s) == "Fist[value=lorem ipsum]"


# Generated at 2022-06-21 19:35:23.953555
# Unit test for constructor of class First
def test_First():
    # testing constructor
    first_result = First(4)
    assert first_result.value == 4



# Generated at 2022-06-21 19:35:27.893776
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-21 19:35:34.556614
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(True) == One(True)
    assert First('a') == First('a')
    assert Last('a') == Last('a')
    assert Map({'a': First('b')}) == Map({'a': First('b')})
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)



# Generated at 2022-06-21 19:35:37.594375
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(2)) == 'Sum[value=2]'



# Generated at 2022-06-21 19:35:39.944254
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)


# Generated at 2022-06-21 19:35:42.170984
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert str(All(True)) == "All[value=True]"  # pragma: no cover


# Generated at 2022-06-21 19:35:47.226382
# Unit test for constructor of class Semigroup
def test_Semigroup():
    sg0 = Sum(0)
    sg1 = Sum(1)
    sg2 = Sum(2)
    assert sg0 == sg0
    assert sg1 == sg1
    assert sg2 == sg2
    assert sg0 != sg1
    assert sg1 != sg2



# Generated at 2022-06-21 19:35:50.929856
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'



# Generated at 2022-06-21 19:35:55.253531
# Unit test for method concat of class First
def test_First_concat():  # pragma: no cover
    assert First('abc').concat(First('def')).value == 'abc'
    assert First('abc').concat(First('def')).__str__() == 'Fist[value=abc]'


# Generated at 2022-06-21 19:35:56.497300
# Unit test for constructor of class Last
def test_Last():
    last = Last(8)
    assert last.value == 8



# Generated at 2022-06-21 19:36:03.380380
# Unit test for method concat of class Map
def test_Map_concat():
    """
    Test for method concat of class Map
    """
    first_map_semigroup = Map({"first": Sum(1), "second": All(True)})
    second_map_semigroup = Map({"first": Sum(2), "second": All(True), "third": One(False)})

    map_concated = first_map_semigroup.concat(second_map_semigroup)

    assert map_concated == Map({"first": Sum(3), "second": All(True), "third": One(False)})

# Generated at 2022-06-21 19:36:05.651887
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-21 19:36:07.742144
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True
    assert One(False).value == False
    assert One("").value == ""


# Generated at 2022-06-21 19:36:16.059431
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First("a") == First("a")
    assert Last("z") == Last("z")
    assert Map({1: Sum(1)}) == Map({1: Sum(1)})
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)


# Generated at 2022-06-21 19:36:20.678164
# Unit test for method concat of class One
def test_One_concat():
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)


# Generated at 2022-06-21 19:36:22.609452
# Unit test for method __str__ of class One
def test_One___str__():
    unit_test_value = 'One[value=1]'
    assert One(1).__str__() == unit_test_value



# Generated at 2022-06-21 19:36:23.947747
# Unit test for constructor of class Min
def test_Min():
    min_test = Min(1)
    assert min_test.value == 1



# Generated at 2022-06-21 19:36:27.302579
# Unit test for method __str__ of class Map
def test_Map___str__():
    actual = Map({'a': Sum(1)}).__str__()
    expected = 'Map[value={\'a\': Sum[value=1]}]'
    assert actual == expected



# Generated at 2022-06-21 19:36:30.141093
# Unit test for constructor of class First
def test_First():
    """
    Tests constructor of class First with valid value.
    """
    First(1)
    First('hello')
    First(['item one', 'item two'])



# Generated at 2022-06-21 19:36:38.570114
# Unit test for constructor of class Map
def test_Map():
    map1 = Map({'a': 2, 'b': 4, 'c': 5})
    map2 = Map({'a': Sum(2), 'b': Sum(4), 'c': Sum(5)})
    assert map1.value == map2.value
    # map is not a Semigroup, it is a Monoid
    # with Map.neutral() as map3:
    #    assert map1.concat(map3).value == map1.value
    #    assert map1.concat(map3) == map1



# Generated at 2022-06-21 19:36:45.912134
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(34).fold(lambda x: x * 2) == 68
    assert Semigroup(34).fold(lambda x: x + 2) == 36
    assert Semigroup(34).fold(lambda x: x - 2) == 32

    assert Sum(34).fold(lambda x: x * 2) == 68
    assert Sum(34).fold(lambda x: x + 2) == 36
    assert Sum(34).fold(lambda x: x - 2) == 32

    assert All(True).fold(lambda x: x * 2) == 2
    assert All(True).fold(lambda x: x + 2) == 3
    assert All(True).fold(lambda x: x - 2) == -1

    assert One(True).fold(lambda x: x * 2) == 2
    assert One(True).fold(lambda x: x + 2)

# Generated at 2022-06-21 19:36:47.025342
# Unit test for constructor of class First
def test_First():
    pass # TODO



# Generated at 2022-06-21 19:36:49.392970
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == "One[value=True]"
    assert str(One(False)) == "One[value=False]"

# Generated at 2022-06-21 19:36:55.007868
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(10) == Min(10)
    assert Min(4) == Min(5).concat(Min(4))
    assert Min(5) == Min(5).concat(Min(5))
    assert Min(1).concat(Min(5)) == Min(1)


# Generated at 2022-06-21 19:36:56.630789
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(30)) == "Min[value=30]"


# Generated at 2022-06-21 19:36:58.167167
# Unit test for constructor of class Sum
def test_Sum():
    semigroup = Sum(1)
    assert semigroup.value == 1


# Generated at 2022-06-21 19:37:00.513419
# Unit test for method concat of class One
def test_One_concat():
    expected = One(True)
    actual = First(True).concat(Last(True))
    assert expected == actual

# Generated at 2022-06-21 19:37:07.861837
# Unit test for constructor of class Semigroup
def test_Semigroup():
    # Sum
    assert Sum(1) == Sum(1)
    assert Sum(2).fold(int) == 2
    assert Sum.neutral().value == 0
    # All
    assert All(True) == All(True)
    assert All(True).fold(bool) is True
    assert All.neutral().value is True
    # One
    assert One(True) == One(True)
    assert One(True).fold(bool) is True
    assert One.neutral().value is False
    # First
    assert First(True) == First(True)
    assert First(True) != First(False)
    assert First(True).fold(bool) is True
    # Last
    assert Last(True) == Last(True)
    assert Last(True) != Last(False)
    assert Last(True).fold(bool) is True


# Generated at 2022-06-21 19:37:10.307427
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(3)) == Sum(5)



# Generated at 2022-06-21 19:37:13.447810
# Unit test for constructor of class Sum
def test_Sum():
    value = 1
    assert Sum(value) == Sum(value), "Value of Sum is correct, it's equal"
    assert Sum(value).value == value, "Value of Sum is correct, it's equal"



# Generated at 2022-06-21 19:37:15.967171
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(5).concat(Min(7)) == Min(5)
    assert Min(5).concat(Min(2)) == Min(2)


# Generated at 2022-06-21 19:37:17.703838
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last('last').concat(Last('word')) == Last('word')


# Generated at 2022-06-21 19:37:20.471325
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup('1')
    assert not Semigroup(1) == Semigroup(2)


# Generated at 2022-06-21 19:37:30.518636
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': 1, 'b': 2})) == "Map[value={'a': 1, 'b': 2}]"



# Generated at 2022-06-21 19:37:33.485920
# Unit test for method concat of class First
def test_First_concat():
    """
    Test `concat` method of class `First`
    """
    assert First(1).concat(First(2)).value == 1



# Generated at 2022-06-21 19:37:43.854712
# Unit test for method concat of class First
def test_First_concat():
    result = First(1).concat(First(2))
    assert result.value == 1

    result = First(1).concat(First(None))
    assert result.value == 1

    result = First(None).concat(First(1))
    assert result.value is None

    result = First([1, 2]).concat(First([2, 3]))
    assert result.value == [1, 2]

    result = First([2, 3]).concat(First([1, 2]))
    assert result.value == [2, 3]

    result = First({'a':1}).concat(First({'b':2}))
    assert result.value == {'a':1}

    result = First({'b':2}).concat(First({'a':1}))

# Generated at 2022-06-21 19:37:45.129898
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)



# Generated at 2022-06-21 19:37:48.731135
# Unit test for constructor of class Last
def test_Last():  # pragma: no cover
    last_instance = Last(1)
    assert last_instance.value == 1
    assert str(last_instance) == 'Last[value=1]'



# Generated at 2022-06-21 19:37:51.213709
# Unit test for method __str__ of class Map
def test_Map___str__():
    expected = 'Map[value={1: Sum[value=1], 2: Sum[value=2]}]'
    actual = str(Map({1: Sum(1), 2: Sum(2)}))
    assert expected == actual


# Generated at 2022-06-21 19:37:58.926787
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(10) == Sum(10)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First(10) == First(10)
    assert Last(10) == Last(10)
    assert Map({'key1': Sum(10), 'key2': Sum(20)}) == Map({'key1': Sum(10), 'key2': Sum(20)})
    assert Max(10) == Max(10)
    assert Min(10) == Min(10)


# Generated at 2022-06-21 19:38:04.022170
# Unit test for method __str__ of class Map
def test_Map___str__():
    """
    :return: True if unit test successful
    :rtype: bool
    """
    dict_test = {'test_key': 'test_value'}
    map_test = Map(dict_test)
    assert str(map_test) == "Map[value={'test_key': 'test_value'}]", 'Method __str__ of class Map is failed'
    return True



# Generated at 2022-06-21 19:38:08.191741
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: First(1), 2: First(2)})) == 'Map[value={1: Fist[value=1], 2: Fist[value=2]}]'



# Generated at 2022-06-21 19:38:10.394830
# Unit test for constructor of class One
def test_One():
    x = One(False)
    assert x.value == False
    assert str(x) == 'One[value=False]'


# Generated at 2022-06-21 19:38:18.067960
# Unit test for constructor of class Min
def test_Min():
    assert Min(4) == Min(4)
    assert Min(4).concat(Min(2)) == Min(2)


# Generated at 2022-06-21 19:38:19.429242
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(2).concat(Max(3)) == Max(3)


# Generated at 2022-06-21 19:38:20.557557
# Unit test for method concat of class Last
def test_Last_concat():
    assert str(Last(7).concat(Last(5))) == "Last[value=5]"


# Generated at 2022-06-21 19:38:23.400925
# Unit test for constructor of class Map
def test_Map():
    assert Map({"a": Sum(1), "b": All(False)}) == Map({"a": Sum(1), "b": All(False)})


# Generated at 2022-06-21 19:38:27.031844
# Unit test for method __str__ of class Last
def test_Last___str__():
    tester = Last('asd')
    assert str(tester) == "Last[value=asd]"
    assert repr(tester) == "Last[value=asd]"


# Generated at 2022-06-21 19:38:31.384665
# Unit test for method concat of class First
def test_First_concat():
    """
    Test that concat method of class First works correctly
    """
    assert First(1).concat(First(2)) == First(1)  # pragma: no cover


# Generated at 2022-06-21 19:38:33.328144
# Unit test for method __str__ of class First
def test_First___str__():
    assert First([1, 2]).__str__() == 'Fist[value=[1, 2]]'


# Generated at 2022-06-21 19:38:35.687686
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-21 19:38:38.070415
# Unit test for method __str__ of class Last
def test_Last___str__():
    value = 'value'
    assert Last(value).__str__() == 'Last[value={}]'.format(value)



# Generated at 2022-06-21 19:38:42.278993
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """Test constructor of class Semigroup."""
    semigroup = Semigroup(42)
    assert semigroup.value == 42
    assert semigroup.fold(lambda x: x * 2) == 84
    assert semigroup == Semigroup(42)


# Unit tests for class Sum

# Generated at 2022-06-21 19:38:56.446159
# Unit test for constructor of class All
def test_All():
    """
    Unit test for class All
    :return: None
    """

    # Check if the constructor of class All works correctly
    assert All(True).value == True
    assert All(False).value == False
    assert All(True).neutral() == True
    assert All(False).fold(lambda x: x) == False


# Generated at 2022-06-21 19:38:57.393164
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == "One[value=True]"


# Generated at 2022-06-21 19:39:00.096304
# Unit test for method __str__ of class Max
def test_Max___str__():
    """
    Test Max __str__ method
    """
    x = Max(1)
    assert str(x) == 'Max[value=1]'


# Generated at 2022-06-21 19:39:02.525660
# Unit test for constructor of class Last
def test_Last():  # pragma: no cover
    assert Last(1) == Last(1)



# Generated at 2022-06-21 19:39:04.047319
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(3)) == 'Min[value=3]'


# Generated at 2022-06-21 19:39:05.169272
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-21 19:39:10.241297
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    Unit test for method __eq__ of class Semigroup
    """

    semigroup1 = Sum(1)
    semigroup2 = Sum(2)
    semigroup3 = Sum(1)
    assert semigroup1 == semigroup3
    assert not (semigroup1 == semigroup2)


# Generated at 2022-06-21 19:39:11.631438
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(0) == 'Min[value=0]')


# Generated at 2022-06-21 19:39:12.712467
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(3)) == 'Max[value=3]', 'test_Max___str__'



# Generated at 2022-06-21 19:39:18.304970
# Unit test for method concat of class Max
def test_Max_concat():
    left = Max(2)
    right = Max(1)

    assert Max(2).concat(Max(2)) == Max(2)
    assert Max(1, 1, 2, 1).concat(Max(1, 1, 2, 1, 2)) == Max(2, 2)
    assert left.concat(right) == Max(2)


# Generated at 2022-06-21 19:39:42.385365
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(2)) == 'Sum[value=2]'



# Generated at 2022-06-21 19:39:47.376185
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'
    assert str(Max(2)) == 'Max[value=2]'
    assert str(Max(1).concat(Max(2))) == 'Max[value=2]'


# Generated at 2022-06-21 19:39:53.450853
# Unit test for method concat of class One
def test_One_concat():
    assert not One(1).concat(One(False)).value
    assert One(False).concat(One(42)).value == 42
    assert not One(0).concat(One(0)).value
    assert not One(None).concat(One(0)).value
    assert One(None).concat(One(42)).value == 42
    assert One(False).concat(One(1)).value == 1
    assert One(False).concat(One(True)).value

# Generated at 2022-06-21 19:39:58.708710
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True), "Test 1 failed"
    assert One(False).concat(One(True)) == One(True), "Test 2 failed"
    assert One(True).concat(One(False)) == One(True), "Test 3 failed"
    assert One(False).concat(One(False)) == One(False), "Test 4 failed"


# Generated at 2022-06-21 19:40:00.497495
# Unit test for constructor of class All
def test_All():
    all_true = All(True)
    assert all_true.value is True


# Generated at 2022-06-21 19:40:02.189422
# Unit test for constructor of class Min
def test_Min(): 
    min = Min(1)
    assert min.value == 1



# Generated at 2022-06-21 19:40:07.272384
# Unit test for method concat of class Map
def test_Map_concat():
    x = Map({'a': Sum(1), 'b': Sum(2), 'c': Sum(3)})
    y = Map({'a': Sum(2), 'b': Sum(3), 'c': Sum(4)})
    z = Map({'a': Sum(3), 'b': Sum(5), 'c': Sum(7)})
    assert x.concat(y).concat(z) == z



# Generated at 2022-06-21 19:40:12.141524
# Unit test for method concat of class All
def test_All_concat():
    cases = [
        (All(True), All(True), All(True)),
        (All(True), All(False), All(False)),
        (All(False), All(True), All(False)),
        (All(False), All(False), All(False)),
    ]

    for (s1, s2, exp) in cases:
        assert s1.concat(s2) == exp


# Generated at 2022-06-21 19:40:15.157305
# Unit test for constructor of class One
def test_One():
    """
    :return: None
    :rtype: None
    """
    assert One(True).value == True
    assert One(False).value == False


# Generated at 2022-06-21 19:40:20.106117
# Unit test for constructor of class Last
def test_Last():
    assert str(Last([1, 2, 3])) == "Last[[1, 2, 3]]"
    assert Last([1, 2, 3]).concat(Last([4, 5, 6])) == Last([4, 5, 6])
    assert Last([1, 2, 3]).concat(Last([4, 5, 6])) == Last([4, 5, 6])

# Generated at 2022-06-21 19:41:14.406186
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-21 19:41:15.740113
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(10)) == 'Max[value=10]'



# Generated at 2022-06-21 19:41:21.810776
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(True).fold(lambda value: value) is True
    assert Semigroup(54).fold(lambda value: value * 2) == 108
    assert Semigroup(54).fold(lambda value: 'sum: {}'.format(value)) == 'sum: 54'
    try:
        Semigroup(54).fold()
        raise AssertionError('Semigroup.fold() without argument should raise TypeError exception')
    except TypeError:
        pass



# Generated at 2022-06-21 19:41:26.881090
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-21 19:41:29.388851
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert str(Max(1)) == "Max[value=1]"
    assert str(Max(2)) == "Max[value=2]"


# Generated at 2022-06-21 19:41:30.244723
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1


# Generated at 2022-06-21 19:41:36.082179
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)).value == True
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(True)).value == True
    assert One(False).concat(One(False)).value == False
    assert One(False).concat(False).value == False
    assert One(True).concat(True).value == True


# Generated at 2022-06-21 19:41:37.342599
# Unit test for constructor of class First
def test_First():
    assert First(True) == First(True)



# Generated at 2022-06-21 19:41:42.465332
# Unit test for method concat of class Map
def test_Map_concat():
    """
    Concating 2 Maps together, will result in Map instance with the concated values of each key.
    """
    mapA = Map({"a": Sum(1), "b": All(True), "c": One(True)})
    mapB = Map({"a": Sum(2), "b": All(True), "c": One(False)})
    assert mapA.concat(mapB) == Map({"a": Sum(3), "b": All(True), "c": One(True)})

# Generated at 2022-06-21 19:41:43.956656
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(3).concat(Last(7)).value == 7


# Generated at 2022-06-21 19:43:42.350599
# Unit test for method __str__ of class Min
def test_Min___str__():  # pragma: no cover
    assert str(Min(3)) == 'Min[value=3]'


# Generated at 2022-06-21 19:43:44.462288
# Unit test for method __str__ of class Min
def test_Min___str__():
    """
    Test if str represent Min with value
    """
    assert str(Min(0)) == 'Min[value=0]'



# Generated at 2022-06-21 19:43:49.455943
# Unit test for method concat of class All
def test_All_concat():
    """
    :returns: AssertionError if test failed
    :rtype: AssertionError
    """
    all_true = All(True)
    all_false = All(False)
    true_false = All(all_true.concat(all_false))
    assert true_false.value == False



# Generated at 2022-06-21 19:43:51.740836
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert str(Max(10)) == 'Max[value=10]'


# Generated at 2022-06-21 19:43:52.627628
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == 'One[value=1]'


# Generated at 2022-06-21 19:43:54.044239
# Unit test for constructor of class Map
def test_Map():
    # test_Map.test_fold()
    assert Map({}).fold(lambda v: v) == {}  # pragma: no cover



# Generated at 2022-06-21 19:43:57.945948
# Unit test for constructor of class Sum
def test_Sum():
    value = Sum(1)

    assert 1 == value.value

    assert value.__eq__(value) is True



# Generated at 2022-06-21 19:43:59.967722
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(3)) == Sum(5)



# Generated at 2022-06-21 19:44:02.380522
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == "Min[value=1]"


# Generated at 2022-06-21 19:44:03.886901
# Unit test for constructor of class All
def test_All():
    a = All(True)
    assert a.value == True

