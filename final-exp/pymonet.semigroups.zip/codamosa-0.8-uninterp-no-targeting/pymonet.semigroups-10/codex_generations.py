

# Generated at 2022-06-21 19:34:15.589565
# Unit test for method __str__ of class Min
def test_Min___str__():  # pragma: no cover
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-21 19:34:16.972348
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(2) == Semigroup(2)
    assert not (Semigroup(1) == Semigroup(2))

# Generated at 2022-06-21 19:34:20.607126
# Unit test for constructor of class Map
def test_Map():
    x = Map({'a': All(False), 'b': One(True)})
    y = Map({'a': All(True)})
    assert x.value == {'a': All(False), 'b': One(True)}
    assert y.value == {'a': All(True)}

if __name__ == '__main__':
    test_Map()

# Generated at 2022-06-21 19:34:22.029218
# Unit test for constructor of class Last
def test_Last():
    last = Last(1)
    assert last(5) == Last(5)

# Generated at 2022-06-21 19:34:23.021733
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == Last(1).value

# Generated at 2022-06-21 19:34:35.188235
# Unit test for method concat of class Map
def test_Map_concat():
    a = Map({'a': Sum(1), 'b': Sum(1), 'c': Sum(1)})
    b = Map({'c': Sum(2), 'd': Sum(2), 'e': Sum(2)})
    assert a.concat(b) == Map({'a': Sum(1), 'b': Sum(1), 'c': Sum(3), 'd': Sum(2), 'e': Sum(2)})

    try:
        a = Map({'a': Sum(1), 'b': Sum(1)})
        b = Map({'a': Sum(2), 'b': Sum(2)})
        a.concat(b)
    except AttributeError as e:
        pass
    # print(e)  # it's OK


# Generated at 2022-06-21 19:34:38.604304
# Unit test for method concat of class Max
def test_Max_concat():
    """
    Unit test for method concat of class Max
    """

    # Test case 1
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)

    # Test case 2
    assert Max(3).concat(Max(3)) == Max(3)



# Generated at 2022-06-21 19:34:43.820148
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(2) == Last(2)
    assert Last(1) != Last(2)
    assert Last(2) != Last(1)
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(2).concat(Last(1)) == Last(1)
    assert Last(1).fold(int) == 1



# Generated at 2022-06-21 19:34:45.502993
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)



# Generated at 2022-06-21 19:34:48.778038
# Unit test for method __str__ of class All
def test_All___str__():
    # Arrange
    a = All(True)
    # Act
    result = str(a)
    # Assert
    assert result == 'All[value=True]'



# Generated at 2022-06-21 19:34:53.419083
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'
    assert str(Last(2)) == 'Last[value=2]'


# Generated at 2022-06-21 19:34:55.799005
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    init_value = 10
    instance = Sum(init_value)

    assert str(instance) == 'Sum[value={}]'.format(init_value)



# Generated at 2022-06-21 19:35:00.670369
# Unit test for method __str__ of class Last
def test_Last___str__():
    test_Last = Last(12)
    assert str(test_Last) == 'Last[value=12]'

# Generated at 2022-06-21 19:35:04.429741
# Unit test for constructor of class Map
def test_Map():
    x = Map({"key1": Max(1), "key2": Max(2)})
    assert x.value == {"key1": Max(1), "key2": Max(2)}



# Generated at 2022-06-21 19:35:06.097216
# Unit test for method concat of class First
def test_First_concat():
    assert (First(1).concat(First(2)) == First(1))
    assert (First(1).concat(First(2.3)) == First(1))



# Generated at 2022-06-21 19:35:07.934204
# Unit test for method __str__ of class All
def test_All___str__():
    assert (
        All(121).__str__() == "All[value=121]"
    )



# Generated at 2022-06-21 19:35:11.670040
# Unit test for method __str__ of class Map
def test_Map___str__():
    map1 = Map({})
    map2 = Map({'key': Sum(1)})
    assert str(map1) == 'Map[value={}]'
    assert str(map2) == 'Map[value={\'key\': Sum[value=1]}]'



# Generated at 2022-06-21 19:35:13.836166
# Unit test for constructor of class Last
def test_Last():
    assert Last(5).value == 5
    assert Last(5) == Last(5)
    assert Last(5) != Last(6)

# Generated at 2022-06-21 19:35:15.407515
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1)}).value == {'a': Sum(1)}


# Generated at 2022-06-21 19:35:19.239519
# Unit test for method concat of class Last
def test_Last_concat():
    """
    :returns: True if Last.concat works correctly, throws assert error otherwise
    :rtype: bool
    """
    assert Last(1).concat(Last(5)) == Last(5)
    assert Last(5).concat(Last(1)) == Last(1)
    assert Last(1).concat(Last(1)) == Last(1)


# Generated at 2022-06-21 19:35:26.949569
# Unit test for method concat of class All
def test_All_concat():
    assert All('value').concat(
        All(True)
    ) == All(True), 'All should combine the last truly value with the first falsy.'
    assert All(None).concat(
        All(False)
    ) == All(False), 'All should combine the last truly value with the first falsy.'
    assert All('True').concat(
        All('False')
    ) == All(True), 'All should combine the last truly value with the first falsy.'
    assert All(1).concat(
        All(0)
    ) == All(0), 'All should combine the last truly value with the first falsy.'
    assert All('').concat(
        All('')
    ) == All(False), 'All should combine the last truly value with the first falsy.'

# Generated at 2022-06-21 19:35:29.333079
# Unit test for constructor of class First
def test_First():
    assert First(1).concat(First(2)).concat(First(3)) == First(1)


# Generated at 2022-06-21 19:35:34.602878
# Unit test for constructor of class Min
def test_Min(): # pragma: no cover
    a = Min(2)
    b = Min(3)
    assert isinstance(Min(1), Min)
    assert isinstance(a, Min)
    assert isinstance(b, Min)
    assert a.value == Min.neutral_element == 2
    assert isinstance(a.concat(b), Min)


# Generated at 2022-06-21 19:35:35.777948
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1

# Generated at 2022-06-21 19:35:38.689453
# Unit test for constructor of class Sum
def test_Sum():
    """
    :returns: True if instances of Sum class created correctly
    :rtype: bool
    """
    return Sum(5) == Sum(5)



# Generated at 2022-06-21 19:35:40.621528
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-21 19:35:42.829881
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-21 19:35:45.277647
# Unit test for constructor of class First
def test_First():
    name = First('Pedro')
    assert name.value == "Pedro"



# Generated at 2022-06-21 19:35:48.601616
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """Test if obj1 == obj2
    """
    assert Sum(1) == Sum(1)
    assert All(False) == All(False)
    assert One(True) == One(True)
    assert First(False) == First(False)
    assert Last(True) == Last(True)
    assert Max(3) == Max(3)
    assert Min(3) == Min(3)



# Generated at 2022-06-21 19:35:54.929291
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(2)) == 'Sum[value=2]'

# Unit tests for method concat of class Sum

# Generated at 2022-06-21 19:35:59.917298
# Unit test for constructor of class Map
def test_Map():
    m = Map({'a': 1, 'b': 2, 'c': 3})
    m2 = Map({'a': 1, 'b': 2, 'c': 3})
    assert m == m2


# Generated at 2022-06-21 19:36:01.240594
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == "Max[value=1]"



# Generated at 2022-06-21 19:36:02.804265
# Unit test for constructor of class Last
def test_Last():
    """
    Test for constructor of class Last
    """
    assert Last(1) == Last(1)
    assert Last(2) == Last(2)


# Generated at 2022-06-21 19:36:04.984231
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(1)
    b = Min(2)
    assert a.concat(b) == Min(1)



# Generated at 2022-06-21 19:36:05.719171
# Unit test for constructor of class Max
def test_Max():
    assert isinstance(Max(10), Max) is True


# Generated at 2022-06-21 19:36:13.227628
# Unit test for method concat of class Sum
def test_Sum_concat():
    a = Sum(1)
    b = Sum(2)
    assert a.concat(b) == Sum(3), \
        'concat of Sum must return a Sum with value = {}'.format(Sum(3))
    assert a.concat(b) != Sum(2), \
        'concat of Sum must return a Sum with value = {}'.format(Sum(3))
    assert a.concat(b) == b.concat(a), \
        'concat of Sum must be associative'
    assert a.concat(Sum.neutral()) == a, \
        'concat of Sum with neutral element must return value of first operand'
    assert Sum.neutral().concat(a) == a, \
        'concat of Sum with neutral element must return value of second operand'



# Generated at 2022-06-21 19:36:15.343851
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True), "Test for All constructor failed. "


# Generated at 2022-06-21 19:36:20.044176
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)


# Generated at 2022-06-21 19:36:20.824938
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1

# Generated at 2022-06-21 19:36:23.579861
# Unit test for method concat of class Last
def test_Last_concat():
    """
    Unit tests for method concat of class Last
    """
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(1)) == Last(1)


# Generated at 2022-06-21 19:36:29.100402
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)

    assert Sum(1).value == 1



# Generated at 2022-06-21 19:36:31.319181
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'



# Generated at 2022-06-21 19:36:36.946974
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-21 19:36:38.709421
# Unit test for constructor of class First
def test_First():
        assert First('hello').value == 'hello'


# Generated at 2022-06-21 19:36:41.189000
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(6)) == Max(6)
    assert Max(-5).concat(Max(-1)) == Max(-1)


# Generated at 2022-06-21 19:36:44.775593
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)



# Generated at 2022-06-21 19:36:51.604264
# Unit test for method concat of class One
def test_One_concat():
    assert One.neutral().concat(One(False)) == One(False)
    assert One.neutral().concat(One(True)) == One(True)
    assert One(True).concat(One.neutral()) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(False).concat(One(True)) == One(True)


# Generated at 2022-06-21 19:36:53.851596
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)


# Generated at 2022-06-21 19:36:58.304754
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First('str')) == 'Fist[value=str]'
    assert str(First({'key': 'value'})) == 'Fist[value={\'key\': \'value\'}]'



# Generated at 2022-06-21 19:37:00.644945
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-21 19:37:09.764396
# Unit test for constructor of class Last
def test_Last():
    last = Last('pari')
    assert last.value == 'pari'


# Generated at 2022-06-21 19:37:13.689717
# Unit test for method __str__ of class Map
def test_Map___str__():
    empty = Map({})
    assert str(empty) == "Map[{}]"

    non_empty = Map({'a': 1, 'b':2})
    assert str(non_empty) == "Map[{'a': 1, 'b': 2}]"


# Generated at 2022-06-21 19:37:16.932160
# Unit test for method __str__ of class Map
def test_Map___str__():  # pragma: no cover
    assert str(Map({'a': Sum(1), 'b': All(True)})) == 'Map[value={\'a\': Sum[value=1], \'b\': All[value=True]}]'


# Generated at 2022-06-21 19:37:18.310487
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(5).concat(Min(2)) == Min(2)



# Generated at 2022-06-21 19:37:22.966617
# Unit test for constructor of class First
def test_First():
    assert First(1)
    assert First(5)
    assert not First(False)
    assert First(True)
    assert First('hello')
    assert First('world')
    assert First('!')
    assert First({1: 'hello', 2: 'world'})
    assert First({2: 'hello', 3: 'world'})
    assert First({7: 'hello', 8: 'world'})



# Generated at 2022-06-21 19:37:25.317591
# Unit test for method __str__ of class Max
def test_Max___str__():
    """Should return string.
    """
    assert str(Max(10)) == "Max[value=10]"



# Generated at 2022-06-21 19:37:26.829334
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert 'Min[value=inf]' == str(Min(float('inf')))


# Generated at 2022-06-21 19:37:28.424728
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(1) != Max(2)


# Generated at 2022-06-21 19:37:33.082141
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).concat(One(2)) == One(1)
    assert One(None).concat(One(2)) == One(2)
    assert One(1).concat(One(None)) == One(1)
    assert One(None).concat(One(None)) == One(None)

# Generated at 2022-06-21 19:37:35.986231
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert Sum(1) == Sum(1)
    with pytest.raises(Exception):
        Sum(None)



# Generated at 2022-06-21 19:37:46.189975
# Unit test for constructor of class Map
def test_Map():
    # arrange
    values = {
        1: First(3),
        2: First(4),
        3: First(5),
    }

    expected = {
        1: First(3),
        2: First(4),
        3: First(5),
    }

    # act
    result = Map(values)

    # assert
    assert result.value == expected

# Generated at 2022-06-21 19:37:47.463450
# Unit test for constructor of class Max
def test_Max():
    assert Max(20) == Max(20)


# Generated at 2022-06-21 19:37:52.045646
# Unit test for constructor of class First
def test_First():
    first = First(None)
    assert isinstance(first, First)
    assert isinstance(first, Semigroup)
    assert first.value is None


# Generated at 2022-06-21 19:37:57.066825
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    + Semigroup:
        + fold:
            + all values should be evaluated
    """
    assert Sum(2).fold(lambda x: x + 1) == 3
    assert All(True).fold(lambda x: x)
    assert All(False).fold(lambda x: x) == All(False)



# Generated at 2022-06-21 19:37:58.118410
# Unit test for constructor of class Min
def test_Min():
    assert Min(2).value == 2


# Generated at 2022-06-21 19:38:00.317330
# Unit test for constructor of class Map
def test_Map():
    value = {"key1":"value1"}
    map = Map(value)
    assert map.value == value



# Generated at 2022-06-21 19:38:02.812976
# Unit test for constructor of class Last
def test_Last():
    value = "value"
    last = Last(value)

    assert last is not None
    assert last.value == value

# Generated at 2022-06-21 19:38:03.711124
# Unit test for constructor of class Min
def test_Min():
    x = Min(1)
    assert x.value == 1


# Generated at 2022-06-21 19:38:07.877547
# Unit test for method __str__ of class Map
def test_Map___str__(): # pragma: no cover
    s = Map({'a': Sum(1)})
    assert str(s) == 'Map[value={\'a\': Sum[value=1]}]'


# Generated at 2022-06-21 19:38:09.729713
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(
        5
    )) == 'Max[value=5]'


# Generated at 2022-06-21 19:38:18.598647
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    To test method fold of class Semigroup
    """
    def add1(x):
        return x + 1

    assert Semigroup(1).fold(add1) == 2
    assert Semigroup(1).fold(lambda x: x + 1) == 2


# Generated at 2022-06-21 19:38:20.871136
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).__str__() == "Max[value=1]"
    

# Generated at 2022-06-21 19:38:23.352209
# Unit test for constructor of class First
def test_First():
    a = First(1)
    b = First(2)
    assert a.concat(b).value == 1


# Generated at 2022-06-21 19:38:25.005509
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)



# Generated at 2022-06-21 19:38:33.068685
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    #  Test case with sum Semigroups
    semigroupA = Sum(5)
    semigroupB = Sum(5)
    assert semigroupA == semigroupB == Sum(5)

    #  Test case with all Semigroups
    semigroupA = All(True)
    semigroupB = All(True)
    assert semigroupA == semigroupB == All(True)

    #  Test case with one Semigroups
    semigroupA = One(False)
    semigroupB = One(False)
    assert semigroupA == semigroupB == One(False)

    #  Test case with first Semigroups
    semigroupA = First(True)
    semigroupB = First(False)
    assert semigroupA == semigroupA

    #  Test case with last Semigroups
    semigroupA = Last(True)

# Generated at 2022-06-21 19:38:37.170109
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1) != 1
    assert Semigroup(1) != Sum(1)



# Generated at 2022-06-21 19:38:39.079900
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert Semigroup(22) == Semigroup(22)



# Generated at 2022-06-21 19:38:42.816211
# Unit test for constructor of class Map
def test_Map():
    m = Map({1: Max(5), 2: Max(2)})
    assert m.value == {1: Max(5), 2: Max(2)}

# Unit test to fold fn

# Generated at 2022-06-21 19:38:44.906137
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(4)).value == 2


# Generated at 2022-06-21 19:38:48.323780
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First(None)) == 'Fist[value=None]'
    assert str(First('1')) == 'Fist[value=1]'


# Generated at 2022-06-21 19:38:58.902602
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(0).concat(Min(1)) == Min(0)
    assert Min(1).concat(Min(0)) == Min(0)
    assert Min(2).concat(Min(0)) == Min(0)
    assert Min(0).concat(Min(10)) == Min(0)
    assert Min(3).concat(Min(3)) == Min(3)


# Generated at 2022-06-21 19:39:01.023788
# Unit test for method concat of class Last
def test_Last_concat(): # pragma: no cover
    Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-21 19:39:06.898990
# Unit test for method __str__ of class Map
def test_Map___str__():
    """
    Unit test for method __str__ of class Map    
    """
    from pymonet.monoid import Map

    m = Map({'name':'Waldo','age':25})

# Generated at 2022-06-21 19:39:09.058239
# Unit test for method __str__ of class Last
def test_Last___str__():
    last = Last(2)
    assert str(last) == 'Last[value=2]'



# Generated at 2022-06-21 19:39:12.287076
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    assert isinstance(str(One(0)), str)
    assert str(One(0)) == 'One[value=0]'
    assert str(One(1)) == 'One[value=1]'
    assert str(One(2)) == 'One[value=2]'


# Generated at 2022-06-21 19:39:15.567778
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert Max(1).__str__() == 'Max[value=1]'
    assert Max(-2).__str__() == 'Max[value=-2]'
    assert Max(-10).__str__() == 'Max[value=-10]'
    assert Max(10).__str__() == 'Max[value=10]'



# Generated at 2022-06-21 19:39:17.101015
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)).value == 2


# Generated at 2022-06-21 19:39:18.346075
# Unit test for constructor of class One
def test_One():
    pass


# Generated at 2022-06-21 19:39:20.126494
# Unit test for method __str__ of class Min
def test_Min___str__():
    min_ = Min(10)
    assert str(min_) == 'Min[value=10]'


# Generated at 2022-06-21 19:39:23.317534
# Unit test for method __str__ of class Min
def test_Min___str__():
    actual = str(Min(1))
    expected = "Min[value=1]"
    assert actual == expected


# Generated at 2022-06-21 19:39:34.781127
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert str(Sum(1)) == 'Sum[value=1]'
    assert str(All(True)) == 'All[value=True]'
    assert str(One(False)) == 'One[value=False]'
    assert str(Map({'key': Sum(43)})) == "Map[value={'key': Sum[value=43]}]"
    assert str(Max(10)) == 'Max[value=10]'
    assert str(Min(10)) == 'Min[value=10]'
test_Semigroup()


# Generated at 2022-06-21 19:39:37.141093
# Unit test for method __str__ of class First
def test_First___str__():
    assert 'Fist[value=A]' == str(First('A'))


# Generated at 2022-06-21 19:39:40.115476
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(3).concat(Min(4)) == Min(3)
    assert Min(4).concat(Min(3)) == Min(3)



# Generated at 2022-06-21 19:39:47.267735
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    all_true = All(True)
    all_false = All(False)
    all_true_2 = All(True)
    all_false_2 = All(False)
    assert All.neutral().concat(all_false) == All(False)
    assert all_true.concat(All.neutral()) == All(True)
    assert all_true.concat(all_true_2) == All(True)
    assert all_false.concat(all_false_2) == All(False)
    assert all_false.concat(all_true) == All(False)
    assert all_true.concat(all_false) == All(False)


# Generated at 2022-06-21 19:39:48.915756
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert str(Sum(5)) == "Sum[value=5]"

# Generated at 2022-06-21 19:39:50.619533
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-21 19:39:58.855814
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All('a')).value == bool('a')
    assert All(False).concat(All('a')).value == False
    assert All(True).concat(All(None)) == All(False)
    assert All(False).concat(All(None)) == All(False)



# Generated at 2022-06-21 19:40:01.938071
# Unit test for constructor of class Min
def test_Min():
    assert Min(0).fold(lambda x: x) == 0
    assert Min(1).fold(lambda x: x) == 1
    assert Min(2).fold(lambda x: x) == 2


# Generated at 2022-06-21 19:40:03.706027
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) != All(True)



# Generated at 2022-06-21 19:40:07.267300
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'c': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(2), 'c': Sum(4)})

test_Map_concat()

# Generated at 2022-06-21 19:40:20.303012
# Unit test for constructor of class First
def test_First():
    assert First.neutral_element is None



# Generated at 2022-06-21 19:40:29.586634
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    :return: None
    """

    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)

    assert All(1) == All(1)
    assert All(1) != All(2)
    assert All(True) == All(True)
    assert All(True) != All(0)

    assert One(1) == One(1)
    assert One(1) != One(2)
    assert One(True) == One(True)
    assert One(True) != One(1)

    assert First(1) == First(1)
    assert First(1) != First(2)
    assert First(True) == First(True)
    assert First(True) != First(1)

    assert Last(1) == Last(1)

# Generated at 2022-06-21 19:40:31.061988
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert (str(Sum(1)) == 'Sum[value=1]')


# Generated at 2022-06-21 19:40:32.673943
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1).value == 1

# Generated at 2022-06-21 19:40:39.097435
# Unit test for method concat of class All
def test_All_concat():
    a = All(False)
    b = All(False)
    c = All(True)
    d = All(True)
    assert a.concat(b).fold(lambda x: x) is False
    assert a.concat(c).fold(lambda x: x) is False
    assert b.concat(c).fold(lambda x: x) is False
    assert c.concat(d).fold(lambda x: x) is True
    assert d.concat(c).fold(lambda x: x) is True



# Generated at 2022-06-21 19:40:43.492170
# Unit test for method __str__ of class Map
def test_Map___str__():
    asserts.equal(
        str(Map({'a': Sum(2), 'b': Sum(3)})),
        'Map[value={\'a\': Sum[value=2], \'b\': Sum[value=3]}]'
    )


# Generated at 2022-06-21 19:40:47.254683
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert Sum(2) == Sum(2)
    assert All(True) == All(True)
    assert All(False) == All(False)



# Generated at 2022-06-21 19:40:52.843681
# Unit test for method concat of class Map
def test_Map_concat():
    mapA = {
        'a': First(1),
        'b': First(2)
    }
    mapB = {
        'c': First(3),
        'b': First(4)
    }
    map = Map.neutral().concat(Map(mapA)).concat(Map(mapB))
    assert map.value['a'] == First(1)
    assert map.value['b'] == First(2)
    assert map.value['c'] == First(3)

# Generated at 2022-06-21 19:40:54.027524
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert "Max[value=2]" == str(Max(2))


# Generated at 2022-06-21 19:40:56.980611
# Unit test for method concat of class Sum
def test_Sum_concat():
    print("Sum concat = ", Sum(10).concat(Sum(20)))



# Generated at 2022-06-21 19:41:27.919312
# Unit test for method __str__ of class Map
def test_Map___str__():
    obj1 = Map({'a': 1})
    obj2 = Map({'a': 1})
    assert str(obj1) == str(obj2)
    assert obj1 != obj2
    assert obj1 == obj2
    assert not id(obj1) == id(obj2)



# Generated at 2022-06-21 19:41:30.579181
# Unit test for constructor of class Map
def test_Map():
    result = Map({'key': Sum(10), 'key2': Sum(11)})
    expected = Map({'key': Sum(10), 'key2': Sum(11)})

    assert result == expected

# Generated at 2022-06-21 19:41:32.536670
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'
    assert str(Sum(2)) == 'Sum[value=2]'



# Generated at 2022-06-21 19:41:35.197970
# Unit test for constructor of class One
def test_One():
    m = One(3)
    assert(One.neutral().value == False)


# Generated at 2022-06-21 19:41:36.869048
# Unit test for method __str__ of class First
def test_First___str__():
    a = First(0)
    assert str(a) == "Fist[value=0]"



# Generated at 2022-06-21 19:41:38.164965
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert_true(Sum(5) == Sum(5))


# Generated at 2022-06-21 19:41:45.094576
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)

    assert All(True).concat(One(True)) == All(True)
    assert All(True).concat(One(False)) == All(False)

    assert All(True).concat(Sum(100)) == All(True)
    assert All(True).concat(Sum(0)) == All(False)

    assert All(True).concat(First(100)) == All(True)
    assert All(True).concat(First(0)) == All(True)


# Generated at 2022-06-21 19:41:52.371893
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(2)}) == Map({'a': Sum(2)})
    assert Map({'b': Sum(6)}) == Map({'b': Sum(6)})
    assert Map({'b': Sum(6)}) != Map({'b': Sum(2)})
    assert Map({'b': Sum(2)}) != Map({'a': Sum(2)})
    assert Map({'a': Sum(2)}) != Map({'b': Sum(2)})



# Generated at 2022-06-21 19:41:56.190532
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x + 5) == 6
    assert Sum(5).fold(lambda x: x * 2) == 10
    assert All(True).fold(lambda x: x) is True
    assert All(False).fold(lambda x: x) is False
    assert One(False).fold(lambda x: x) is False
    assert One(True).fold(lambda x: x) is True
    assert First(True).fold(lambda x: x) is True
    assert First(False).fold(lambda x: x) is False
    assert Last(True).fold(lambda x: x) is True
    assert Last(False).fold(lambda x: x) is False

# Generated at 2022-06-21 19:41:57.502869
# Unit test for constructor of class All
def test_All():
    assert All(True).value is True
    assert All(False).value is False


# Generated at 2022-06-21 19:43:03.868514
# Unit test for method concat of class First
def test_First_concat():
    first_value = First('first')
    last_value = Last('last')

    first_value_concat_last_value = first_value.concat(last_value)

    expect(first_value_concat_last_value).to(be_an(First))
    expect(first_value_concat_last_value.value).to(be_equal_to('first'))


# Generated at 2022-06-21 19:43:06.001730
# Unit test for constructor of class Min
def test_Min():
    assert Min(1).value == 1
    assert Min(1).concat(Min(2)).value == 1
    assert Min.neutral().value == float("inf")



# Generated at 2022-06-21 19:43:08.009084
# Unit test for method __str__ of class First
def test_First___str__():
    i = First("a")
    assert str(i) == "Fist[value=a]"


# Generated at 2022-06-21 19:43:09.463343
# Unit test for constructor of class First
def test_First():
    assert First(5) == First(5)
    assert First(5) != First(6)



# Generated at 2022-06-21 19:43:19.802627
# Unit test for constructor of class Map
def test_Map():
    semigroup = Map({'a': First(1), 'b': First('b')})
    print(semigroup.value)
    assert semigroup == Map({'a': First(1), 'b': First('b')})

    semigroup2 = Map({'a': First(2), 'b': First('b')})
    result = semigroup.concat(semigroup2)
    # {'a': First[value=1], 'b': First[value=b]}
    # {'a': First[value=2], 'b': First[value=b]}
    print(semigroup.value)
    print(semigroup2.value)
    # {'a': First[value=1], 'b': First[value=b]}
    print(result.value)


# Generated at 2022-06-21 19:43:22.832182
# Unit test for method concat of class Sum
def test_Sum_concat():
    c = Sum(10)
    d = Sum(20)
    assert c.concat(d) == Sum(30)
    z = c.concat(Sum.neutral())
    assert c == z
    m = Sum.neutral().concat(c)
    assert c == m


# Generated at 2022-06-21 19:43:31.771442
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():  # pragma: no cover
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First('some text') == First('some text')
    assert Last('some text') == Last('some text')
    assert Map({'sum': Sum(1)}) == Map({'sum': Sum(1)})
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)



# Generated at 2022-06-21 19:43:34.489993
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)

    assert One(1).concat(One(2)) == One(3)
    assert One(1).concat(One(0)) == One(1)


# Generated at 2022-06-21 19:43:38.403855
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(0)) == First(1)
    assert First(1).concat(First(-1)) == First(1)
    assert First(1).concat(First(-100)) == First(1)
    assert First(1).concat(First(100)) == First(1)


# Generated at 2022-06-21 19:43:48.544942
# Unit test for method concat of class Map
def test_Map_concat():
    # Arrange
    m1 = Map({
        'a': Sum(1),
        'b': All(True),
        'c': First(3),
        'd': Last(4),
    })

    m2 = Map({
        'a': Sum(2),
        'b': All(False),
        'c': First(3),
        'd': Last(5),
    })

    # Act
    m = m1.concat(m2)

    # Assert
    assert m == Map({
        'a': Sum(3),
        'b': All(False),
        'c': First(3),
        'd': Last(5),
    })

