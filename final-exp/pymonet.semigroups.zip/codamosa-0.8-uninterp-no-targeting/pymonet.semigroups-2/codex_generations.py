

# Generated at 2022-06-21 19:34:27.662250
# Unit test for constructor of class Last
def test_Last():
    last = Last('Last')
    assert last.value == 'Last'



# Generated at 2022-06-21 19:34:37.539118
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(1) == First(True)
    assert First(1) == First({})
    assert First(1) != First(2)
    assert First(1) != First("1")
    assert First(1) != First([1])

    assert First("1") == First("1")
    assert First("1") == First(True)
    assert First("1") == First({})
    assert First("1") != First("2")
    assert First("1") != First(1)
    assert First("1") != First([1])

    assert First(True) == First(True)
    assert First(True) == First("1")
    assert First(True) == First({})
    assert First(True) != First(False)

# Generated at 2022-06-21 19:34:43.547289
# Unit test for method concat of class All
def test_All_concat():
    first_concat = All(True).concat(All(False))
    assert isinstance(first_concat, All)
    assert first_concat.value == False

    second_concat = All(False).concat(All(True))
    assert isinstance(second_concat, All)
    assert second_concat.value == False

    third_concat = All(True).concat(All(True))
    assert isinstance(third_concat, All)
    assert third_concat.value == True


# Generated at 2022-06-21 19:34:45.722970
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(1)) == Last(1)


# Generated at 2022-06-21 19:34:48.572186
# Unit test for method __str__ of class Map
def test_Map___str__():  # pragma: no cover
    assert str(Map({1: Last(2)})) == 'Map[value={1: Last[value=2]}]'



# Generated at 2022-06-21 19:34:54.736545
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(True)).value == True
    assert One(False).concat(One(False)).value == False
    assert One(False).concat(One(False)).concat(One(True)).value == True
    assert One(False).concat(One(False)).concat(One(True)).concat(One(True)).value == True
    assert One(One(False)).concat(One(True)).value == True
    assert One(One(False)).concat(One(False)).value == False
    assert One(One(False)).concat(One(False)).concat(One(True)).value == True

# Generated at 2022-06-21 19:35:01.846029
# Unit test for method concat of class All
def test_All_concat():
    assert All(True) == All(True).concat(All(True))
    assert not All(True).concat(All(False))
    assert not All(False).concat(All(True))
    assert not All(False).concat(All(False))


# Generated at 2022-06-21 19:35:04.984957
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == "Last[value=1]"
    assert str(Last("a")) == "Last[value=a]"


# Generated at 2022-06-21 19:35:06.822337
# Unit test for constructor of class All
def test_All():
    """ Unit test for constructor of class All """
    assert All(True).value



# Generated at 2022-06-21 19:35:10.030629
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(4).concat(Sum(5)) == Sum(9)
    assert Sum(100).concat(Sum(100)).concat(Sum(-1)) == Sum(199)
    assert Sum(0).concat(Sum(0)).concat(Sum(0)) == Sum(0)
    assert Sum(0).concat(Sum(0)).concat(Sum(-1)) == Sum(-1)


# Generated at 2022-06-21 19:35:14.263437
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():  # pragma: no cover
    assert Sum(4) == Sum(4)
    assert Sum(4) != Sum(5)


# Generated at 2022-06-21 19:35:22.236697
# Unit test for method concat of class Map
def test_Map_concat():
    a = Map({'a': Sum(1), 'b': First(2), 'c': Last(4)})
    b = Map({'a': Sum(2), 'b': First(1), 'c': Last(3)})
    c = Map({'a': Sum(3), 'b': First(3), 'c': Last(7)})

    expected = Map({'a': Sum(3), 'b': First(2), 'c': Last(7)})
    assert a.concat(b) == expected

    expected = Map({'a': Sum(6), 'b': First(3), 'c': Last(7)})
    assert a.concat(b).concat(c) == expected

# Generated at 2022-06-21 19:35:24.024866
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: Sum(1)})) == 'Map[value={1: Sum[value=1]}]'



# Generated at 2022-06-21 19:35:28.579709
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)
    assert not Semigroup(1) == None


# Generated at 2022-06-21 19:35:31.329233
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-21 19:35:40.396566
# Unit test for constructor of class Max
def test_Max():
    max_int = -2**31
    min_int = 2**31-1

    assert Max(max_int).value == max_int
    assert Max(min_int).value == min_int
    assert Max(1.1).value == 1.1
    assert Max(0).value == 0
    assert Max(0.0).value == 0.0
    assert Max(1).value == 1
    assert Max(1.1).value == 1.1
    assert Max(1.0).value == 1.0
    assert Max(1.1).value == 1.1
    assert Max("a").value == 'a'
    assert Max("a").value == 'a'
    assert Max("a").value == 'a'
    assert Max("a").value == 'a'
    assert Max("a").value == 'a'


# Generated at 2022-06-21 19:35:42.637927
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'



# Generated at 2022-06-21 19:35:46.059303
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(False) != All(True)
    assert All(True).fold(lambda val: val) == True
    assert All(False).fold(lambda val: val) == False


# Generated at 2022-06-21 19:35:49.554349
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(False)) == 'All[value=False]'
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-21 19:35:54.432944
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    :returns: Test all semigroups
    :rtype: None
    """
    Sum(10)
    All(True)
    One(False)
    First(0)
    Last(1)
    Max(1)
    Min(10)



# Generated at 2022-06-21 19:35:57.255627
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)


# Generated at 2022-06-21 19:36:01.710591
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert 'All[value=True]' == str(All(True))
    assert 'All[value=False]' == str(All(False))
    assert 'All[value=1]' == str(All(1))
    assert 'All[value=0]' == str(All(0))
    assert 'All[value="test"]' == str(All("test"))



# Generated at 2022-06-21 19:36:05.140519
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == "One[value=True]"
    assert str(One(False)) == "One[value=False]"
    assert str(One(None)) == "One[value=None]"


# Generated at 2022-06-21 19:36:12.905645
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)

    assert First(1) == First(1)
    assert First(1) != Last(1)

    assert Last(1) == Last(1)
    assert Last(1) != Max(1)

    assert Max(1) == Max(1)
    assert Max(1) != Min(1)

    assert Min(1) == Min(1)
    assert Min(1) != All(0)

    assert All(1) == All(1)
    assert All(1) != All(0)

    assert One(1) == One(1)
    assert One(1) != One(0)

    assert Map({'key': Sum(1)}) == Map({'key': Sum(1)})

test_Semigroup___eq

# Generated at 2022-06-21 19:36:23.017396
# Unit test for method concat of class Map
def test_Map_concat():
    values = {
        'numbers': {1: Sum(1), 2: Sum(2), 3: Sum(3)},
        'strings': {
            'foo': First('foo'),
            'bar': First('bar'),
            'baz': Last('baz'),
        },
        'bool': {True: All(True), False: One(True)},
        'numbers2': {1: Max(1), 2: Max(2), 3: Max(3)},
        'numbers3': {1: Min(1), 2: Min(2), 3: Min(3)},
    }

    res = Map(values).concat(Map(values))

    assert res.value['numbers'][1].value == Sum(2).value
    assert res.value['numbers'][2].value == Sum(4).value

# Generated at 2022-06-21 19:36:27.448616
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    s = Semigroup(1)
    s2 = Semigroup(1)
    s3 = Semigroup(2)
    assert s == s2 and s2 == s and not s == s3 and not s2 == s3 and s == s


# Generated at 2022-06-21 19:36:32.115473
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'key1': Sum(1), 'key2': Sum(2), 'key3': Sum(3)})) == \
        "Map[value={'key1': Sum[value=1], 'key2': Sum[value=2], 'key3': Sum[value=3]}]"



# Generated at 2022-06-21 19:36:34.323581
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'


# Generated at 2022-06-21 19:36:35.850555
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-21 19:36:37.240337
# Unit test for constructor of class First
def test_First():
    assert str(First(1)) == "Fist[value=1]"


# Generated at 2022-06-21 19:36:42.687956
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)


# Generated at 2022-06-21 19:36:45.877935
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(False)) == "One[value=False]"
    assert str(One(True)) == "One[value=True]"


# Generated at 2022-06-21 19:36:48.168148
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(0) == Semigroup(0)
    assert Semigroup(0).value == 0
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1).value == 1
    assert Semigroup(2) == Semigroup(2)
    assert Semigroup(2).value == 2


# Generated at 2022-06-21 19:36:50.147491
# Unit test for constructor of class Last
def test_Last():
    assert str(Last(1)) == 'Last[value=1]'
test_Last()


# Generated at 2022-06-21 19:36:56.232784
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({"x": Sum(1), "y": Sum(2)})
    m2 = Map({"z": Sum(3), "x": Sum(4)})
    result = m1.concat(m2)
    expected = Map({"x": Sum(5), "y": Sum(2), "z": Sum(3)})
    assert result == expected, "Result is expected"

test_Map_concat()

# Generated at 2022-06-21 19:36:57.897579
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(10)) == 'Last[value=10]'


# Generated at 2022-06-21 19:37:06.668142
# Unit test for method concat of class Last
def test_Last_concat():
    types = [
        # truthy
        (1, Last(1)),
        ("str", Last("str")),
        (True, Last(True)),
        (1.1, Last(1.1)),

        # falsy
        (0, Last()),
        ("", Last()),
        (False, Last()),
        (0.0, Last()),

        # list
        ([1, 2], Last([1, 2])),
        ([], Last()),
    ]

    for value, expected in types:
        actual = Last(value).concat(Last(value))

        assert actual.value == expected.value, \
            '\nFirst.concat({}).value == {} error, got {}'.format(value, expected.value, actual.value)



# Generated at 2022-06-21 19:37:11.074630
# Unit test for constructor of class Map
def test_Map():
    a_map = Map({"a": First(1), "b": Min(100)})
    assert a_map.value == {"a": First(1), "b": Min(100)}



# Generated at 2022-06-21 19:37:13.034711
# Unit test for method __str__ of class Min
def test_Min___str__():  # pragma: no cover
    assert str(Min(3)) == 'Min[value=3]'


# Generated at 2022-06-21 19:37:14.889284
# Unit test for constructor of class Max
def test_Max():
    assert Max(2) == Max(2)
    assert Max(3) != Max(2)


# Generated at 2022-06-21 19:37:20.249867
# Unit test for constructor of class All
def test_All():
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"



# Generated at 2022-06-21 19:37:22.416831
# Unit test for constructor of class Max
def test_Max():
    max_value = Max(5)
    assert max_value.value == 5
    assert max_value.neutral_element == -float("inf")


# Generated at 2022-06-21 19:37:24.730108
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(1) != Max(2)
    assert Max(1).value == 1



# Generated at 2022-06-21 19:37:26.297745
# Unit test for method concat of class Last
def test_Last_concat():
    last = Last(1)
    assert last.concat(Last(2)) == Last(2)



# Generated at 2022-06-21 19:37:28.554396
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Test fold method of class Semigroup
    """
    assert Sum(2).fold(lambda x: x + 2) == Sum(2).value + 2 == 4



# Generated at 2022-06-21 19:37:31.328277
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    Test for valid constructor of class Semigroup
    """

    semigroup = Semigroup(1)

    assert semigroup.value == 1



# Generated at 2022-06-21 19:37:34.313899
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True)
    assert One(False).concat(One(True)) == One(True)



# Generated at 2022-06-21 19:37:41.038841
# Unit test for method concat of class Map
def test_Map_concat():
    # assert Map({'a': Sum(1), 'b': Sum(1)}).concat(Map({'a': Sum(1), 'b': Sum(1)})).value == {'a': Sum(2), 'b': Sum(2)}
    assert Map({'a': Sum(1), 'b': Sum(1)}).concat(Map({'a': Sum(1), 'b': Sum(1)})) == Map({'a': Sum(2), 'b': Sum(2)})



# Generated at 2022-06-21 19:37:42.755621
# Unit test for method concat of class First
def test_First_concat():
    assert First('x').concat(First('y')) == First('x')



# Generated at 2022-06-21 19:37:44.168239
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-21 19:37:49.153364
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': First(1), 'b': Last(2)}).value == {'a': First(1), 'b': Last(2)}



# Generated at 2022-06-21 19:37:50.521257
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-21 19:37:54.300408
# Unit test for constructor of class Map
def test_Map():
    x = Map({'a': Sum(1), 'b': Sum(2)})
    assert x.value == {'a': Sum(1), 'b': Sum(2)}


# Generated at 2022-06-21 19:37:57.116153
# Unit test for method concat of class Sum
def test_Sum_concat():
    s1 = Sum(3)
    s2 = Sum(2)
    assert s1.concat(s2) == Sum(5)


# Generated at 2022-06-21 19:37:57.804309
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(10)) == "Max[value=10]"


# Generated at 2022-06-21 19:38:00.739433
# Unit test for method __str__ of class First
def test_First___str__():
    # Arrange
    c1 = First(1)
    # Act
    result = c1.__str__()
    # Assert
    assert result == 'Fist[value=1]'


# Generated at 2022-06-21 19:38:04.180868
# Unit test for constructor of class Last
def test_Last():
    """
    This is unit test for constructor of class Last.
    """
    last = Last(1)
    assert last.value == 1
    last = Last(2)
    assert last.value == 2
    last = Last(3)
    assert last.value == 3



# Generated at 2022-06-21 19:38:15.111403
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(2) == Sum(2)
    assert Sum(2) != Sum(3)
    assert All(2) == All(2)
    assert All(2) != All(3)
    assert One(2) == One(2)
    assert One(2) != One(3)
    assert First(2) == First(2)
    assert First(2) != First(3)
    assert Last(2) == Last(2)
    assert Last(2) != Last(3)
    assert Max(2) == Max(2)
    assert Max(2) != Max(3)
    assert Min(2) == Min(2)
    assert Min(2) != Min(3)


# Generated at 2022-06-21 19:38:16.960790
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({0: Sum(1)})) == 'Map[value={0: Sum[value=1]}]'



# Generated at 2022-06-21 19:38:22.195365
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert First(1) == First(1)
    assert Last(1) == Last(1)
    assert Map({'a': Sum(1)}) == Map({'a': Sum(1)})


# Generated at 2022-06-21 19:38:29.128332
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert Semigroup(1).value == 1



# Generated at 2022-06-21 19:38:31.133048
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(2)
    assert Min(2).concat(Min(1)) == Min(1)


# Generated at 2022-06-21 19:38:33.613377
# Unit test for constructor of class Last
def test_Last():
    # Given
    last = Last(1)

    # Then
    assert last.value == 1

# Test for string representation of class Last

# Generated at 2022-06-21 19:38:38.166310
# Unit test for constructor of class Min
def test_Min():
    min_1 = Min(1)
    min_2 = Min(2)
    min_3 = Min(3)
    min_4 = Min(4)
    assert min_3 == min_4.concat(min_1)
    assert min_1 == min_1.concat(min_2)
    assert min_1 == min_1.concat(min_1)
    assert min_3 == min_2.concat(min_3)


# Generated at 2022-06-21 19:38:42.063430
# Unit test for method concat of class First
def test_First_concat():
    m1 = First("A")
    m2 = First("B")
    m3 = m1.concat(m2)
    assert isinstance(m3, First)
    assert m3.value == "A"


# Generated at 2022-06-21 19:38:48.458665
# Unit test for method concat of class Map
def test_Map_concat():
    input = {
        "favorit": Min(3),
        "color": First("red"),
        "age": Max(33),
    }
    expected = {
        "favorit": Min(4),
        "color": First("black"),
        "age": Max(44),
    }
    m = Map(input)

    m.concat(Map({"favorit": Min(4)}))

    assert input == expected

# Generated at 2022-06-21 19:38:51.554652
# Unit test for constructor of class Min
def test_Min():  # pragma: no cover
    assert Min(1) == Min(1)
    assert Min(1) != Min(2)
    assert Min(1).fold(lambda x: x) == 1


# Generated at 2022-06-21 19:38:55.015452
# Unit test for constructor of class All
def test_All():
    """
    Test class All constructor.
    """
    assert All(True).value == True
    assert All(False).value == False
    assert All(0).value == False
    assert All(1).value == True
    assert All("").value == False
    assert All("text").value == True


# Generated at 2022-06-21 19:38:55.824277
# Unit test for constructor of class One
def test_One():
    assert One(1).value == 1


# Generated at 2022-06-21 19:38:59.353606
# Unit test for method concat of class All
def test_All_concat():
    assert All(1).concat(All(0)) == All(0)
    assert All(3).concat(All(-12)) == All(-12)
    assert All(2.22).concat(All("")) == All("")
    assert All([]).concat(All(None)) == All(None)
    assert All({}).concat(All(())) == All(())
    assert All(range(5)).concat(All(range(10))) == All(range(10))



# Generated at 2022-06-21 19:39:07.207456
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(2)) == 'Fist[value=2]'



# Generated at 2022-06-21 19:39:12.779150
# Unit test for constructor of class First
def test_First():
    val1 = First("one")
    val2 = First("two")
    assert isinstance(val1, Semigroup) is True
    assert isinstance(val2, Semigroup) is True
    assert isinstance(val1.concat(val2), First) is True
    assert val1.concat(val2).fold(lambda x: x * 2) == "oneone"



# Generated at 2022-06-21 19:39:14.379855
# Unit test for method concat of class Min
def test_Min_concat():
    semigroup_min = Min(7)
    assert semigroup_min.concat(Min(2)).value == 2



# Generated at 2022-06-21 19:39:20.306801
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({1: Sum(1)}).concat(Map({1: Sum(2)})).value == {1: Sum(3)}
    assert Map({1: Sum(1), 2: Sum(1)}).concat(Map({1: Sum(2), 3: Sum(2)})).value == {1: Sum(3), 2: Sum(1), 3: Sum(2)}



# Generated at 2022-06-21 19:39:24.150226
# Unit test for constructor of class Map
def test_Map():
    map_ = Map({
        1: First(1),
        2: Last(2)
    })

    assert map_.value[1].value == 1
    assert map_.value[2].value == 2



# Generated at 2022-06-21 19:39:28.032325
# Unit test for constructor of class All
def test_All():
    all = All(True)
    assert all == All(True)
    assert all == All(False)
    assert all == All(1)
    assert all == All([1, 2, 3])
    assert all != All(All(1))


# Generated at 2022-06-21 19:39:29.961233
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(3)) == Sum(4)



# Generated at 2022-06-21 19:39:32.583062
# Unit test for method concat of class All
def test_All_concat():
    True | All(True) == All(True)
    True | All(False) == All(False)
    False | All(False) == All(False)
    False | All(True) == All(False)



# Generated at 2022-06-21 19:39:33.724188
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(0) == Semigroup(0)

# Generated at 2022-06-21 19:39:40.167874
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True).value == True
    assert All(False).value == False
    assert All(True) != All(False)
    assert All(False) != All(True)
    assert All.neutral().value == True



# Generated at 2022-06-21 19:39:47.827937
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)).value == 3



# Generated at 2022-06-21 19:39:50.250193
# Unit test for method concat of class Last
def test_Last_concat():
    result = First(1).concat(First(2))
    expect = First(1)
    assert result == expect, 'First concat error'


# Generated at 2022-06-21 19:39:53.086465
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(2) == Last(2)
    assert Last(3) == Last(3)



# Generated at 2022-06-21 19:39:59.378820
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First('123') == First('123')
    assert Last('abc') == Last('abc')
    assert Map({1: Sum(1), 2: Sum(2)}) == Map({1: Sum(1), 2: Sum(2)})
    assert Max(100) == Max(100)
    assert Min(200) == Min(200)



# Generated at 2022-06-21 19:40:01.097177
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)


# Generated at 2022-06-21 19:40:03.956474
# Unit test for method __str__ of class Last
def test_Last___str__():
    """
    Generate input value and make assertion.
    """
    assert Last(0).__str__() == 'Last[value=0]'



# Generated at 2022-06-21 19:40:07.967930
# Unit test for method __str__ of class Map
def test_Map___str__():
    """
    :returns: True if test passed
    :rtype: bool
    """
    a = Map({'a': Sum(5), 'b': All(True)})
    assert str(a) == 'Map[value={\'a\': Sum[value=5], \'b\': All[value=True]}]'
    return True


# Generated at 2022-06-21 19:40:11.238058
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(5)) == 'Max[value=5]'



# Generated at 2022-06-21 19:40:14.684475
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({})) == 'Map[value={}]'
    assert str(Map({'k': 'v'})) == "Map[value={'k': 'v'}]"


# Generated at 2022-06-21 19:40:17.819575
# Unit test for method __str__ of class Map
def test_Map___str__():  # pragma: no cover
    """
    unit test for method __str__ of class Map
    """
    assert str(Map({1: Sum(10)})) == "Map[value={1: Sum[value=10]}]"



# Generated at 2022-06-21 19:40:32.467414
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(5).concat(Sum(1)) == Sum(6)
    assert Sum(5).concat(Sum(0)) == Sum(5)
    assert Sum(5).concat(Sum(0.0)) == Sum(5.0)
    assert Sum(0).concat(Sum(5)) == Sum(5)
    assert Sum(10.0).concat(Sum(0.001)) == Sum(10.001)
    assert Sum(10.0).concat(Sum(-4.2)) == Sum(5.8)
    assert Sum(10).concat(Sum(-4.2)) == Sum(5.8)
    assert Sum(1).concat(Sum(2)) != Sum(3.0)



# Generated at 2022-06-21 19:40:36.513717
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert Map({1: All(True), 2: All(True)}).__str__() == 'Map[value={1: All[value=True], 2: All[value=True]}]'

# Generated at 2022-06-21 19:40:49.035432
# Unit test for method concat of class One
def test_One_concat():
    one1 = One(True)
    one2 = One(False)
    one3 = One(0)
    one4 = One(1)
    one5 = One(2)
    one6 = One(-1)

    assert one1.concat(one2).value == True
    assert one1.concat(one3).value == True
    assert one1.concat(one4).value == True
    assert one1.concat(one5).value == True
    assert one1.concat(one6).value == True

    assert one2.concat(one1).value == True
    assert one2.concat(one3).value == 0
    assert one2.concat(one4).value == 1
    assert one2.concat(one5).value == 2

# Generated at 2022-06-21 19:40:50.278864
# Unit test for method __str__ of class Last
def test_Last___str__():
    res = Last(1)
    assert str(res) == 'Last[value=1]'

# Generated at 2022-06-21 19:40:51.529692
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-21 19:40:52.381117
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(2) == Sum(2)

# Generated at 2022-06-21 19:41:03.259726
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    Unit test for method concat of class Semigroup
    """

    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert All(True) == All(True)
    assert All(True) != All(False)
    assert One(True) == One(True)
    assert One(True) != One(False)
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert Map({1: Sum(1)}) == Map({1: Sum(1)})
    assert Map({1: Sum(1)})

# Generated at 2022-06-21 19:41:06.069981
# Unit test for constructor of class First
def test_First():
    # given 2 First instances
    f1 = First(1)
    f2 = First(2)

    # when
    f3 = f1.concat(f2)

    # then
    assert f3 == f1



# Generated at 2022-06-21 19:41:08.395120
# Unit test for method concat of class First
def test_First_concat():
    """
    Test should return True
    """
    first = First(1)
    second = First(2)
    result = first.concat(second)
    assert result.value == 1



# Generated at 2022-06-21 19:41:11.735289
# Unit test for constructor of class Map
def test_Map():
    t = Map({'a':First(2), 'b':Min(3), 'c':Sum(5), 'd':All(True)})
    assert t.value['a'].value == 2
    assert t.value['b'].value == 3
    assert t.value['c'].value == 5
    assert t.value['d'].value == True


# Generated at 2022-06-21 19:41:28.064315
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-21 19:41:32.090346
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(0)) == Sum(1)
    assert Sum(0).concat(Sum(1)) == Sum(1)
    assert Sum(0).concat(Sum(0)) == Sum(0)



# Generated at 2022-06-21 19:41:37.733371
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """Semigroup.fold should give the result applying a function to the wrapped value"""
    number_test_cases = [(1, 1), (2, 2), (3, 3), (4, 4), (5, 5)]
    for wrapped_value, expected in number_test_cases:
        assert Semigroup(wrapped_value).fold(lambda x: x) == expected



# Generated at 2022-06-21 19:41:38.953198
# Unit test for method __str__ of class One
def test_One___str__():
    assert 'One[value=False]' == str(One(False))

# Generated at 2022-06-21 19:41:41.505619
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)

# Generated at 2022-06-21 19:41:43.611332
# Unit test for constructor of class Semigroup
def test_Semigroup():
    try:
        # Case 1: Valid Case
        obj = Sum(1)
        assert isinstance(obj, Semigroup)

    except AssertionError:
        print('Unable to construct Semigroup')



# Generated at 2022-06-21 19:41:46.113771
# Unit test for method concat of class One
def test_One_concat():
    assert One(False).concat(One(True)) == One(True)

# Generated at 2022-06-21 19:41:47.583921
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Last(1).value == 1



# Generated at 2022-06-21 19:41:52.333227
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert Last(1).__str__() == 'Last[value=1]'
    assert Last(0).__str__() == 'Last[value=0]'
    assert Last(True).__str__() == 'Last[value=True]'
    assert Last(False).__str__() == 'Last[value=False]'


# Generated at 2022-06-21 19:41:55.629478
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(15).value == 15
    assert Sum(15).concat(Sum(10)).value == 25
    assert Sum(0).concat(Sum(10)).value == 10
    assert Sum(5).concat(Sum(0)).value == 5


# Generated at 2022-06-21 19:42:14.780694
# Unit test for method __str__ of class Last
def test_Last___str__():
    # arrange
    semigroup = Last(0)
    expected = 'Last[value=0]'
    # act
    actual = str(semigroup)
    # assert
    assert actual == expected



# Generated at 2022-06-21 19:42:18.386521
# Unit test for method concat of class All
def test_All_concat():
    assert_equal(All(True).concat(All(True)), All(True))
    assert_equal(All(True).concat(All(False)), All(False))
    assert_equal(All(False).concat(All(True)), All(False))
    assert_equal(All(False).concat(All(False)), All(False))



# Generated at 2022-06-21 19:42:21.080772
# Unit test for method concat of class Min
def test_Min_concat():
    from pyramda.private.asserts import assert_equal

    m = Min(2)
    assert_equal(m.concat(m), m)



# Generated at 2022-06-21 19:42:24.331350
# Unit test for constructor of class Min
def test_Min():
    m1 = Min(1)
    assert m1.value == 1
    assert m1.neutral_element == float("inf")
    m2 = Min.neutral()
    assert m2.value == float("inf")
    assert m2.neutral_element == float("inf")


# Generated at 2022-06-21 19:42:25.940602
# Unit test for constructor of class First
def test_First():
    """
    Test for First constructor
    """
    assert First(1) == First(1)
    assert First(1).value == 1


# Generated at 2022-06-21 19:42:26.688659
# Unit test for method __str__ of class Max
def test_Max___str__():
    Max(10).__str__()



# Generated at 2022-06-21 19:42:28.227710
# Unit test for method concat of class Min
def test_Min_concat():
    m1 = Min(2)
    m2 = Min(4)

    m = m1.concat(m2)

    assert m.value == 2



# Generated at 2022-06-21 19:42:28.981468
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-21 19:42:30.400625
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    first = Sum(1)
    assert first.__str__() == "Sum[value=1]"



# Generated at 2022-06-21 19:42:33.042289
# Unit test for method concat of class One
def test_One_concat():
    pass
    # one_1 = One(1)
    # one_2 = One(2)
    # assert one_1.concat(one_2) == One(1)
    # assert one_2.concat(one_1) == One(2)


# Generated at 2022-06-21 19:42:54.350897
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)

# Generated at 2022-06-21 19:43:02.828273
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    SumInst = Sum(1)
    AllInst = All(True)
    OneInst = One(False)
    FirstInst = First(1)
    LastInst = Last(1)
    MapInst = Map({'value': SumInst})
    MaxInst = Max(1)
    MinInst = Min(1)

    assert SumInst == Sum(1)
    assert AllInst == All(True)
    assert OneInst == One(False)
    assert FirstInst == First(1)
    assert LastInst == Last(1)
    assert MapInst == Map({'value': SumInst})
    assert MaxInst == Max(1)
    assert MinInst == Min(1)

    assert SumInst != Sum(2)
    assert AllInst != All(False)
    assert OneInst != One(True)
    assert FirstInst != First(2)

# Generated at 2022-06-21 19:43:03.546913
# Unit test for constructor of class All
def test_All():
    assert All(True).value


# Generated at 2022-06-21 19:43:05.894649
# Unit test for method __str__ of class One
def test_One___str__():
    """
    Check if method __str__ of class One is working properly

    """
    expected = 'One[value=1]'
    actual = str(One(1))
    assert expected == actual


# Generated at 2022-06-21 19:43:09.195660
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(Sum(1)).fold(lambda x: x) == 1
    assert Semigroup(All(True)).fold(lambda x: x) == True
    assert Semigroup(Max(1)).fold(lambda x: x) == 1


# Generated at 2022-06-21 19:43:10.345161
# Unit test for constructor of class Sum
def test_Sum():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-21 19:43:13.090221
# Unit test for method concat of class First
def test_First_concat():
    actual = First(3).concat(First(4))
    expect = First(3)
    assert_that(
        actual,
        equal_to(expect)
    )


# Generated at 2022-06-21 19:43:16.426355
# Unit test for constructor of class Semigroup
def test_Semigroup():
    sg = Semigroup(1)
    assert sg.value == 1  # pragma: no cover
    assert sg.fold(lambda x: x) == 1  # pragma: no cover



# Generated at 2022-06-21 19:43:23.176218
# Unit test for method __str__ of class One
def test_One___str__():
    assert eval(One(1).__str__()) == One(1)
    assert eval(One(0).__str__()) == One(0)
    assert eval(One('1').__str__()) == One('1')
    assert eval(One('').__str__()) == One('')
    assert eval(One(True).__str__()) == One(True)
    assert eval(One(False).__str__()) == One(False)
    assert eval(One(None).__str__()) == One(None)
    assert eval(One([]).__str__()) == One([])


# Generated at 2022-06-21 19:43:25.410943
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(10)) == "Max[value=10]"


# Generated at 2022-06-21 19:43:58.299359
# Unit test for constructor of class One
def test_One():
    assert One(10) == One(10)



# Generated at 2022-06-21 19:44:04.229493
# Unit test for method __str__ of class All
def test_All___str__():
    data = [
        (All, 'All[value=True]'),
        (All, 'All[value=True]'),
        (All, 'All[value=False]'),
        (All, 'All[value=False]')
    ]
    for monoid, value in data:
        assert str(monoid(value)) == value


# Generated at 2022-06-21 19:44:05.216921
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1


# Generated at 2022-06-21 19:44:08.664397
# Unit test for method concat of class Min
def test_Min_concat():
    """
    :returns: (Bool) True if the two arguments are equal, False otherwise
    :rtype: bool
    """
    return Min(1).concat(Min(3)) == Min(1)


# Generated at 2022-06-21 19:44:10.062690
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)

# Generated at 2022-06-21 19:44:17.346488
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"a": Sum(1), "b": Sum(0)}).concat(Map({"a": Sum(2), "b": Sum(0)})) == Map({"a": Sum(3), "b": Sum(0)})
    assert Map({"a": Sum(1), "b": Sum(0)}).concat(Map({"a": Sum(2), "c": Sum(0)})) == Map({"a": Sum(3), "b": Sum(0), "c": Sum(0)})

