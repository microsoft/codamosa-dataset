

# Generated at 2022-06-21 19:34:16.306983
# Unit test for method __str__ of class One
def test_One___str__():
    one = One(1)
    assert str(one) == 'One[value=1]'


# Generated at 2022-06-21 19:34:18.431187
# Unit test for constructor of class Map
def test_Map():
    assert Map({
        'a': All(True),
        'b': All(True),
        'c': All(False),
    }) == Map({
        'a': All(True),
        'b': All(True),
        'c': All(False),
    })

# Generated at 2022-06-21 19:34:22.580852
# Unit test for method concat of class Map
def test_Map_concat():
    first_map = Map({'a': Sum(1), 'b': Sum(2)})
    second_map = Map({'a': Sum(3), 'b': Sum(4)})
    assert first_map.concat(second_map) == Map({'a': Sum(4), 'b': Sum(6)})



# Generated at 2022-06-21 19:34:24.121278
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(2)) == 'Last[value=2]'



# Generated at 2022-06-21 19:34:27.824683
# Unit test for method __str__ of class Sum
def test_Sum___str__(): # pragma: no cover
    s = Sum(1)
    assert str(s) == "Sum[value=1]"


# Generated at 2022-06-21 19:34:32.716739
# Unit test for method concat of class One
def test_One_concat():
    assert One(False).concat(One(False)).value == False
    assert One(True).concat(One(False)).value == True
    assert One(True).concat(One(True)).value == True
    assert One(False).concat(One(True)).value == True

print(test_One_concat())


# Generated at 2022-06-21 19:34:34.721508
# Unit test for constructor of class Min
def test_Min():
    """
    Unit test for constructor of class Min
    """
    assert Min(10) == Min(10)

# Generated at 2022-06-21 19:34:43.347230
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max.neutral() == Max.neutral().concat(Max.neutral())
    assert Max.neutral() == Max.neutral().concat(Max(0))
    assert Max.neutral() == Max(0).concat(Max.neutral())
    assert Max(0) == Max(0).concat(Max(0))
    assert Max(1) == Max(0).concat(Max(1))
    assert Max(1) == Max(1).concat(Max(0))
    assert Max(2) == Max(1).concat(Max(2))
    assert Max(2) == Max(2).concat(Max(1))


# Generated at 2022-06-21 19:34:48.951039
# Unit test for method __str__ of class Last
def test_Last___str__(): # pragma: no cover
    last = Last(10)
    assert str(last) == 'Last[value=10]'
    last = Last(None)
    assert str(last) == 'Last[value=None]'
    last = Last('')
    assert str(last) == 'Last[value=]'


# Generated at 2022-06-21 19:34:52.155262
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last('a').concat(Last('b')).value == 'b'
    assert Last(1).concat(Last('x')).value == 'x'
    assert Last({}).concat(Last({})).value == {}


# Generated at 2022-06-21 19:34:56.812767
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)



# Generated at 2022-06-21 19:34:59.897954
# Unit test for method concat of class Max
def test_Max_concat():
    value_a = 2
    value_b = 3
    number_a = Max(value_a)
    number_b = Max(value_b)
    number = number_a.concat(number_b)
    print(number)
    assert number.value == value_b


# Generated at 2022-06-21 19:35:01.751783
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum = Sum(1)
    assert str(sum) == 'Sum[value=1]'


# Generated at 2022-06-21 19:35:04.833256
# Unit test for constructor of class Last
def test_Last():  # pragma: no cover
    assert Last(1) == Last(1)
    assert Last(1).value == 1


# Generated at 2022-06-21 19:35:05.761410
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)



# Generated at 2022-06-21 19:35:12.317238
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Sum(1).value == 1
    assert All(1).value is True
    assert All(0).value is False
    assert One(1).value is True
    assert One(0).value is False
    assert First(1).value == 1
    assert Last(1).value == 1
    assert Min(1).value == 1
    assert Max(1).value == 1
    assert Map({1: 1, 2: 2}).value == {1: 1, 2: 2}


# Generated at 2022-06-21 19:35:15.628371
# Unit test for method __str__ of class All
def test_All___str__():
    """
    :return:
    """
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"



# Generated at 2022-06-21 19:35:17.704488
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False
    assert All(True).value is True
    assert All(False).value is False


# Generated at 2022-06-21 19:35:20.153588
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1)})) == "Map[value={'a': Sum[value=1]}]"



# Generated at 2022-06-21 19:35:24.201365
# Unit test for method __str__ of class Map
def test_Map___str__():
    # Arrange
    map = {1: Min(2), 2: Min(3), 3: Min(4)}
    instance = Map(map)
    # Act
    result = instance.__str__()
    # Assert
    assert result == "Map[value={1: Min[value=2], 2: Min[value=3], 3: Min[value=4]}]"



# Generated at 2022-06-21 19:35:28.678476
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-21 19:35:30.873665
# Unit test for method concat of class First
def test_First_concat():
    assert First(5).concat(First(6)) == First(5)



# Generated at 2022-06-21 19:35:34.556867
# Unit test for constructor of class One
def test_One():
    test1 = One(True)
    test2 = One("hello")
    test3 = One(False)
    test4 = One("world")
    assert test1.value and test2.value and not test3.value and test4.value


# Generated at 2022-06-21 19:35:38.428974
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).value == 1
    assert Min(1).concat(Min(-1)).value == -1
    assert Min(-1).concat(Min(1)).value == -1



# Generated at 2022-06-21 19:35:43.888753
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(5).__eq__(Semigroup(5)) == True
    assert Semigroup("a").__eq__(Semigroup("a")) == True
    assert Semigroup("a").__eq__(Semigroup("b")) == False
    assert Semigroup("a").__eq__(Semigroup(5)) == False
    assert Semigroup(5).__eq__(Semigroup("a")) == False


# Generated at 2022-06-21 19:35:48.651880
# Unit test for method concat of class Map
def test_Map_concat():
    a = Map({"1": Sum(2), "2": Sum(5), "3": Sum(8)})
    b = Map({"1": Sum(1), "2": Sum(3), "3": Sum(10)})
    c = Map({"1": Sum(3), "2": Sum(8), "3": Sum(18)})
    assert(a.concat(b) == c)
    assert(b.concat(a) == c)

# Generated at 2022-06-21 19:35:50.776974
# Unit test for constructor of class Last
def test_Last():
    monoid = Last(3)
    assert str(monoid) == 'Last[value=3]'

# Generated at 2022-06-21 19:35:51.784307
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)

# Generated at 2022-06-21 19:35:54.974415
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-21 19:35:56.579825
# Unit test for method __str__ of class Max
def test_Max___str__():
    max = Max(10)
    assert str(max) == 'Max[value=10]'


# Generated at 2022-06-21 19:36:00.701725
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(None).concat(Last(False)) == Last(False)


# Generated at 2022-06-21 19:36:03.576554
# Unit test for method concat of class Min
def test_Min_concat():
    # given
    actual = Min(6).concat(Min(4))
    # when
    expected = Min(4)
    # then
    assert actual == expected

# Generated at 2022-06-21 19:36:05.454930
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1
    assert Max(-5).value == -5


# Generated at 2022-06-21 19:36:06.753894
# Unit test for constructor of class Last
def test_Last():
    assert Last(3) == Last(3)



# Generated at 2022-06-21 19:36:08.089631
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'

# Generated at 2022-06-21 19:36:12.146739
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'

# Generated at 2022-06-21 19:36:14.196638
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    a = First(1)
    assert str(a) == 'Fist[value=1]'



# Generated at 2022-06-21 19:36:19.553811
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map(
        {"a": Sum(1), "b": Sum(2), "c": Sum(3)}).concat(
        Map({"a": Sum(4), "b": Sum(5), "c": Sum(6)})).fold(lambda x: x) == {
        "a": Sum(5), "b": Sum(7), "c": Sum(9)
    }

# Generated at 2022-06-21 19:36:20.471553
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1


# Generated at 2022-06-21 19:36:22.155488
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-21 19:36:27.565656
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(1).concat(Max(5)) == Max(5)



# Generated at 2022-06-21 19:36:32.218058
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(8).fold(lambda x: x * 2) == 16
    assert All(True).fold(lambda x: x * 2) == True
    assert First("x").fold(lambda x: x * 2) == "x"
    assert Min(5).fold(lambda x: x * 2) == 5


# Generated at 2022-06-21 19:36:35.650186
# Unit test for constructor of class Last
def test_Last():
    """
    Test constructor of class Last.
    """
    assert Last(1).value == 1
    assert Last("string").value == "string"



# Generated at 2022-06-21 19:36:36.802590
# Unit test for method __str__ of class Last
def test_Last___str__():
    last = Last(1)

    assert str(last) == 'Last[value=1]'


# Generated at 2022-06-21 19:36:37.720241
# Unit test for constructor of class Last
def test_Last():
    assert Last(2).value == 2



# Generated at 2022-06-21 19:36:40.948986
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: Sum(1), 2: Sum(2)})) == "Map[value={1: Sum[value=1], 2: Sum[value=2]}]"


# Generated at 2022-06-21 19:36:46.315684
# Unit test for constructor of class Last
def test_Last():
    last_value_a = Last(1)
    last_value_b = Last(2)
    assert last_value_a.concat(last_value_b).value == 1


# Generated at 2022-06-21 19:36:47.834614
# Unit test for constructor of class Sum
def test_Sum():
    sum = Sum(1)
    assert sum.value == 1


# Generated at 2022-06-21 19:36:51.000546
# Unit test for constructor of class Map
def test_Map():
    map = Map({'a': Sum(1), 'b': Sum(9)})
    assert map.value == {'a': Sum(1), 'b': Sum(9)}



# Generated at 2022-06-21 19:36:56.068212
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-21 19:37:04.273935
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map({'a': Sum(1), 'b': Sum(2)})
    map2 = Map({'a': Sum(3), 'b': Sum(4)})
    map3 = Map({'a': Sum(4), 'b': Sum(6)})
    assert map1.concat(map2) == map3
    assert map1.concat(map2).value['a'] == map3.value['a']
    assert map1.concat(map2).value['b'] == map3.value['b']

# Generated at 2022-06-21 19:37:06.640625
# Unit test for method __str__ of class All
def test_All___str__():
    actual = All(True).__str__()
    assert actual == 'All[value=True]'

    actual = All(False).__str__()
    assert actual == 'All[value=False]'


# Generated at 2022-06-21 19:37:10.255690
# Unit test for method __str__ of class Min
def test_Min___str__():
    min_obj = Min(1)
    assert str(min_obj) == 'Min[value=1]'


# Generated at 2022-06-21 19:37:12.987254
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Unit test for method fold of class Semigroup
    """
    assert Semigroup(1).fold(lambda value: value + 1) == 2

# Generated at 2022-06-21 19:37:14.458787
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda a: a**2) == 1

# Generated at 2022-06-21 19:37:16.409171
# Unit test for method __str__ of class First
def test_First___str__():
    actual = str(First(42))
    expected = 'Fist[value=42]'
    assert actual == expected

# Generated at 2022-06-21 19:37:25.768184
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():  # pragma: no cover
    assert All(True).fold(lambda v: v) == True
    assert One(True).fold(lambda v: v) == True
    assert One(False).fold(lambda v: v) == False
    assert All(False).fold(lambda v: v) == False
    assert Sum(5).fold(lambda v: v) == 5
    assert Sum(5).concat(Sum(10)).fold(lambda v: v) == 15
    assert First('foo').fold(lambda v: v) == 'foo'
    assert First('foo').concat(First('bar')).fold(lambda v: v) == 'foo'
    assert Last('foo').fold(lambda v: v) == 'foo'
    assert Last('foo').concat(Last('bar')).fold(lambda v: v) == 'bar'
   

# Generated at 2022-06-21 19:37:27.362156
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-21 19:37:29.328190
# Unit test for method __str__ of class Last
def test_Last___str__(): 
    last = Last('banana')
    assert last.__str__() == "Last[value=banana]"



# Generated at 2022-06-21 19:37:32.821808
# Unit test for method __str__ of class Map
def test_Map___str__():
    print("Test __str__ of class Map")
    assert str(Map({"a": Sum(1)})) == "Map[value={'a': Sum[value=1]}]"


# Generated at 2022-06-21 19:37:37.082407
# Unit test for constructor of class Sum
def test_Sum():
    sum_ = Sum(2)
    assert sum_.value == 2


# Generated at 2022-06-21 19:37:38.922985
# Unit test for method concat of class First
def test_First_concat():
    assert First(2).concat(First(1)) == First(2)



# Generated at 2022-06-21 19:37:40.466090
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-21 19:37:42.266770
# Unit test for constructor of class Min
def test_Min():
    assert Min(5).value == 5
    assert Min("5").value == "5"


# Generated at 2022-06-21 19:37:43.727364
# Unit test for method __str__ of class First
def test_First___str__():
    assert First(1) == First(1)


# Generated at 2022-06-21 19:37:46.678960
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First({})) == 'Fist[value={}]'
    assert str(First("str")) == 'Fist[value=str]'
    assert str(First(123)) == 'Fist[value=123]'



# Generated at 2022-06-21 19:37:49.412330
# Unit test for constructor of class Semigroup
def test_Semigroup():
    semigroup = Semigroup(1)
    assert semigroup.value == 1
    assert semigroup == Semigroup(1)
    assert semigroup != Semigroup(2)
    assert not (semigroup != Semigroup(1))


# Generated at 2022-06-21 19:38:01.446538
# Unit test for method concat of class Map
def test_Map_concat():
    """
    Unit test for method concat of class Map
    """
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})) == Map({'a': Sum(4), 'b': Sum(6)}) # pragma: no cover

    assert Map({'a': Max(1), 'b': Max(2)}).concat(Map({'a': Max(3), 'b': Max(4)})) == Map({'a': Max(3), 'b': Max(4)}) # pragma: no cover


# Generated at 2022-06-21 19:38:03.090162
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"



# Generated at 2022-06-21 19:38:04.185902
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(0) == Sum(0)



# Generated at 2022-06-21 19:38:09.421634
# Unit test for constructor of class Max
def test_Max():
    try:
        assert Max(4)
    except Exception:
        raise  # pragma: no cover

# Generated at 2022-06-21 19:38:11.881815
# Unit test for constructor of class All
def test_All():
    """
    Test All constructor
    """
    assert All(True).value == True
    assert All(False).value == False


# Generated at 2022-06-21 19:38:14.235399
# Unit test for method __str__ of class Last
def test_Last___str__():
    result = str(Last(5))
    assert result == 'Last[value=5]'


# Generated at 2022-06-21 19:38:15.484689
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Min(4) == Min(4) == Min(4)



# Generated at 2022-06-21 19:38:18.216735
# Unit test for method concat of class Last
def test_Last_concat():
    last_a = Last(1)
    last_b = Last(2)
    last_c = last_a.concat(last_b)
    assert last_c.value == 2
    assert Last(2) == last_c


# Generated at 2022-06-21 19:38:22.477883
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First([1,2,3]) == First([1,2,3])
    assert First(1) == First(1.0)
    assert First(None) == First(None)


# Generated at 2022-06-21 19:38:24.716413
# Unit test for constructor of class Min
def test_Min():
    assert Min(0) == Min(0)
    assert Min(0).value == 0


# Generated at 2022-06-21 19:38:27.604672
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    Unit test for method __eq__ of class Semigroup
    """
    assert First(3) == First(3)
    assert First(3) != First(4)



# Generated at 2022-06-21 19:38:29.534457
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert (
        Sum(4).fold(lambda x: x * 2) ==
        Sum(4).value * 2
    )



# Generated at 2022-06-21 19:38:31.512508
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)


# Generated at 2022-06-21 19:38:40.889039
# Unit test for method concat of class One
def test_One_concat():
    """
    :return: bool passed
    :rtype: bool
    """
    assert One(True) == One.neutral().concat(One(True))
    assert One(True) == One(False).concat(One(True))
    assert One(False) == One(False).concat(One(False))



# Generated at 2022-06-21 19:38:46.122364
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)
    assert Min(1.4).concat(Min(1.4)) == Min(1.4)


# Generated at 2022-06-21 19:38:48.280067
# Unit test for method __str__ of class All
def test_All___str__():
    actual = str(All(True))
    expected = "All[value=True]"
    assert actual == expected


# Generated at 2022-06-21 19:38:50.693765
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    SUT = One(False)

    assert SUT.__str__() == 'One[value=False]'



# Generated at 2022-06-21 19:38:53.289582
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert repr(Map({1: Min(0), 2: Min(1)})) == 'Map[value={1: Min[value=0], 2: Min[value=1]}]'


# Generated at 2022-06-21 19:38:54.746956
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First(5)) == 'Fist[value=5]'


# Generated at 2022-06-21 19:38:58.624159
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(0).concat(Min(1)) == Min(0)
    assert Min(1).concat(Min(0)) == Min(0)
    assert Min(0).concat(Min(0)) == Min(0)
    assert Min(1).concat(Min(-1)) == Min(-1)
    assert Min(-1).concat(Min(1)) == Min(-1)
    assert Min(-1).concat(Min(-1)) == Min(-1)

# Generated at 2022-06-21 19:39:00.244061
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-21 19:39:02.197890
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1).value == 1



# Generated at 2022-06-21 19:39:07.002818
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(10)) == 'Last[value=10]'
    assert str(Last([1,2,3])) == 'Last[value=[1, 2, 3]]'
    assert str(Last(None)) == 'Last[value=None]'



# Generated at 2022-06-21 19:39:21.610663
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(42) == Semigroup(42)
    assert not Semigroup(42) == Semigroup(69)



# Generated at 2022-06-21 19:39:26.104076
# Unit test for method concat of class All
def test_All_concat():
    """
    Algebraic laws for class All
    """
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-21 19:39:28.166338
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-21 19:39:30.092462
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'  # pragma: no cover

# Generated at 2022-06-21 19:39:32.291428
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)



# Generated at 2022-06-21 19:39:37.843701
# Unit test for constructor of class Last
def test_Last():
    """
    Will assert that the constructor of the class Semigroup returns the correct values
    """
    assert Last(2) == Last(2)
    assert Last(2).value == 2
    assert Last(1) != Last(2)
    assert Last(2) != Last(2).concat(Last(2))
    assert Last(2).concat(Last(1)) == Last(1)
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(2).concat(Last(1)).value == 1
    assert Last(1).concat(Last(2)).value == 2
    assert Last(2).concat(Last(1)).concat(Last(3)) == Last(3)


# Generated at 2022-06-21 19:39:41.214537
# Unit test for method __str__ of class All
def test_All___str__():
    f = First('a')
    l = Last('z')
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'



# Generated at 2022-06-21 19:39:42.572411
# Unit test for constructor of class First
def test_First():
    a = First(1)
    assert True



# Generated at 2022-06-21 19:39:45.887055
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    assert str(Last(1)) == 'Last[value=1]'



# Generated at 2022-06-21 19:39:48.138117
# Unit test for method concat of class First
def test_First_concat():
    assert First("Hi").concat(First("Hello")).concat(First("Good Bye")) == First("Hi")


# Generated at 2022-06-21 19:40:18.333409
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda el: str(el)) == '1'
    assert Sum(1).fold(lambda el: el + 1) == 2
    assert Sum(1).fold(lambda el: el) == 1
    assert All(True).fold(lambda el: el) == True
    assert All(True).fold(lambda el: 1) == 1


# Generated at 2022-06-21 19:40:20.667798
# Unit test for constructor of class All
def test_All():  # pragma: no cover
    assert All(True) == All(True)
    assert All(True) != All(1)


# Generated at 2022-06-21 19:40:22.649793
# Unit test for method concat of class First
def test_First_concat():
    """
    Test method concat of class First
    """
    assert First(1).concat(First(2)).value == 1


# Generated at 2022-06-21 19:40:29.194905
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(True) == One(True)
    assert First("Peter") == First("Peter")
    assert Last("Pan") == Last("Pan")
    assert Last("Pan") == Last("Pan")
    assert Map({1: First("Peter"), 2: Last("Pan")}) == Map({1: First("Peter"), 2: Last("Pan")})
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)



# Generated at 2022-06-21 19:40:30.378509
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(10)) == "Min[value=10]"



# Generated at 2022-06-21 19:40:32.147941
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(4)
    b = Min(6)
    assert a.concat(b).value == 4



# Generated at 2022-06-21 19:40:33.584444
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-21 19:40:34.456101
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last('a')) == 'Last[value=a]'


# Generated at 2022-06-21 19:40:36.513523
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)



# Generated at 2022-06-21 19:40:40.396022
# Unit test for method __str__ of class Last
def test_Last___str__():
    obj = Last(1)
    result = str(obj)
    assert result == 'Last[value=1]'



# Generated at 2022-06-21 19:41:11.277759
# Unit test for method concat of class Last
def test_Last_concat():
    last = Last(10)
    last_one = Last(1)

    assert last.concat(last_one) == Last(1)

# Generated at 2022-06-21 19:41:15.571717
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1
    assert First(2).value == 2
    assert First([1, 2, 3]).value == [1, 2, 3]
    assert First({'a': 1, 'b': 2, 'c': 3}).value == {'a': 1, 'b': 2, 'c': 3}
    assert First(Max(1)).value == Max(1)
    assert First(Min(2)).value == Min(2)
    assert First(Sum(1)).value == Sum(1)
    assert First(All(True)).value == All(True)
    assert First(One(False)).value == One(False)


# Generated at 2022-06-21 19:41:17.173722
# Unit test for method __str__ of class Min
def test_Min___str__(): # pragma: no cover
    assert Min(1).__str__() == 'Min[value=1]'


# Generated at 2022-06-21 19:41:23.685150
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(
        Max(2)
    ) == Max(2), 'Should return the largest of the two'
    assert Max(10).concat(
        Max(2)
    ) == Max(10), 'Should return the largest of the two'
    assert Max(10).concat(
        Max(10)
    ) == Max(10), 'Should return the first of the two'
    assert Max.neutral().concat(
        Max(2)
    ) == Max(2), 'Should return the largest of the two'


# Generated at 2022-06-21 19:41:24.899924
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(10).concat(Last(5)).concat(Last(22)).concat(Last(5)) == Last(5)



# Generated at 2022-06-21 19:41:26.648602
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)).value == 2
    assert Max(1).concat(Max(1)).value == 1


# Generated at 2022-06-21 19:41:27.988830
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(123)) == 'Min[value=123]'


# Generated at 2022-06-21 19:41:30.617215
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == "Map[value={'a': Sum[value=1], 'b': Sum[value=2]}]"


# Generated at 2022-06-21 19:41:35.760173
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(10)) == Max(10)
    assert Max(5).concat(Max(4)) == Max(5)
    assert Max(-2).concat(Max(-10)) == Max(-2)
    assert Max(5).concat(Max(5)) == Max(5)


# Generated at 2022-06-21 19:41:36.698977
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert Max(0).__str__() == 'Max[value=0]'



# Generated at 2022-06-21 19:42:08.268762
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)


# Generated at 2022-06-21 19:42:12.930267
# Unit test for method __str__ of class Map
def test_Map___str__():
    map = Map({
        'a': Sum(1),
        'b': Sum(2),
        'c': Sum(3)
    })

    assert map.__str__() == 'Map[value={\'a\': Sum[value=1], \'b\': Sum[value=2], \'c\': Sum[value=3]}]'

# Generated at 2022-06-21 19:42:15.509850
# Unit test for method concat of class Last
def test_Last_concat():
    """
    Test concat method on class Last.
    """
    first = Last(4)
    second = Last(5)
    assert isinstance(first.concat(second), Last)
    assert first.concat(second) == Last(5)



# Generated at 2022-06-21 19:42:16.743142
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)



# Generated at 2022-06-21 19:42:17.999755
# Unit test for constructor of class First
def test_First():
    first = First("first")
    assert first.value == "first"


# Generated at 2022-06-21 19:42:21.901930
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(10)) == Min(2)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(10).concat(Min(10)) == Min(10)
    assert Min(10).concat(Min(20)) == Min(10)

# Generated at 2022-06-21 19:42:24.535843
# Unit test for constructor of class All
def test_All():
    """
    Unit test for constructor of class All
    """
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)


# Generated at 2022-06-21 19:42:26.958165
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == "Fist[value=1]"
    assert str(First(2)) == "Fist[value=2]"
    assert str(First(3)) == "Fist[value=3]"


# Generated at 2022-06-21 19:42:28.793892
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    result = First(True) == First(True)
    assert result is True
    result = First(False) == First(False)
    assert result is True
    result = First(True) == First(False)
    assert result is False



# Generated at 2022-06-21 19:42:29.523239
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(10)) == 'Max[value=10]'

# Generated at 2022-06-21 19:43:02.429957
# Unit test for method __str__ of class One
def test_One___str__():
    s = One(True)
    assert str(s) == "One[value=True]"

# Generated at 2022-06-21 19:43:03.710943
# Unit test for constructor of class First
def test_First():  # pragma: no cover
    assert First(1) == First(1)



# Generated at 2022-06-21 19:43:04.527667
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Sum(1)



# Generated at 2022-06-21 19:43:06.000837
# Unit test for constructor of class Semigroup
def test_Semigroup():
    semigroup = Semigroup(1)

    assert semigroup.value == 1



# Generated at 2022-06-21 19:43:08.648622
# Unit test for constructor of class Max
def test_Max():
    max1 = Max(1)
    max2 = Max(2)
    max3 = max1.concat(max2)
    assert max3 == Max(2)



# Generated at 2022-06-21 19:43:09.826388
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-21 19:43:11.073888
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)


# Generated at 2022-06-21 19:43:13.043866
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(False)) == 'All[value=False]'
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-21 19:43:14.838803
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    monoid = Semigroup(0)
    assert monoid == monoid



# Generated at 2022-06-21 19:43:16.154213
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(3)) == 'Sum[value=3]'


# Generated at 2022-06-21 19:43:50.771517
# Unit test for constructor of class First
def test_First():
    # Unit test for constructor of class First
    assert First('Pawel') == First('Pawel')



# Generated at 2022-06-21 19:43:52.250502
# Unit test for method __str__ of class One
def test_One___str__():
    one = One(True)
    assert str(one) == 'One[value=True]'


# Generated at 2022-06-21 19:43:53.923599
# Unit test for constructor of class All
def test_All():
    """
    Tester for All constructor.
    """
    new_All = All(True)
    assert new_All is not None


# Generated at 2022-06-21 19:43:55.573335
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First('a')) == 'Fist[value=a]'


# Generated at 2022-06-21 19:43:58.050751
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(10)) == 'Sum[value=10]'  # type: ignore


# Generated at 2022-06-21 19:44:04.814305
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():  # pragma: no cover
    two_keys_map = {
        "even": Min(2),
        "odd": Max(1)
    }
    assert Map(two_keys_map).fold(lambda result: {key: result[key].value for key in result}
                                  ) == two_keys_map
    assert Map({}).fold(lambda result: {}) == {}



# Generated at 2022-06-21 19:44:06.983064
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert (str(Max(5)) == 'Max[value=5]')


# Generated at 2022-06-21 19:44:09.985764
# Unit test for method concat of class First
def test_First_concat():
    assert First(2).concat(First(3)) == First(2)
    assert First(3).concat(First(3)) == First(3)
    assert First(3).concat(First(2)) == First(3)


# Generated at 2022-06-21 19:44:12.028371
# Unit test for constructor of class Max
def test_Max():
    assert Max(5) == Max(5)

