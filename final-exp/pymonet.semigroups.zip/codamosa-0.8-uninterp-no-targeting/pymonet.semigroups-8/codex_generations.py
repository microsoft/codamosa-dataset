

# Generated at 2022-06-21 19:34:14.320759
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert str(All(True)) == "All[value=True]"


# Generated at 2022-06-21 19:34:15.629041
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)


# Generated at 2022-06-21 19:34:16.760389
# Unit test for constructor of class Max
def test_Max():
    assert Max(10) == Max(10)


# Generated at 2022-06-21 19:34:18.435697
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(0)) == 'Max[value=0]'
    assert str(Max(-1)) == 'Max[value=-1]'


# Generated at 2022-06-21 19:34:20.878866
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1).value == 1
    assert Sum(1) != Sum(2)
    assert str(Sum(1)) == "Sum[value=1]"



# Generated at 2022-06-21 19:34:23.392191
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(20)) == "Min[value=20]"
    assert str(Min(Min(20))) == "Min[value=20]"
    assert str(Min(Min(Min(Min(Min(20)))))) == "Min[value=20]"


# Generated at 2022-06-21 19:34:26.185894
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    result = Semigroup(4).fold(lambda value: value)
    assert result == 4



# Generated at 2022-06-21 19:34:28.178702
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-21 19:34:32.669821
# Unit test for method concat of class Map
def test_Map_concat():
    a = Map({'a': Sum(1), 'b': Sum(2)})
    b = Map({'a': Sum(2), 'b': Sum(4)})
    assert a.concat(b) == Map({'a': Sum(3), 'b': Sum(6)})



# Generated at 2022-06-21 19:34:36.802381
# Unit test for constructor of class First
def test_First():
    assert First(5) == First(5)
    assert First(5).concat(First(7)) == First(5)
    assert First('a').concat(First('b')) == First('a')
    assert First(True).concat(First(False)) == First(True)



# Generated at 2022-06-21 19:34:42.220173
# Unit test for constructor of class Sum
def test_Sum():
    try:
        Sum(5)
        assert True
    except Exception as e:
        assert False, "Fail by creation new Sum instance: {}".format(e)


# Generated at 2022-06-21 19:34:45.133535
# Unit test for constructor of class One
def test_One():
    semigroup = One(True)
    assert semigroup.value == True


# Generated at 2022-06-21 19:34:48.443768
# Unit test for method __str__ of class All
def test_All___str__():
    """
    Method __str__ of class All returns string with value
    """
    result = str(All(False))
    assert result == 'All[value=False]'



# Generated at 2022-06-21 19:34:51.260673
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1)



# Generated at 2022-06-21 19:34:57.129101
# Unit test for method concat of class Min
def test_Min_concat():
    try:
        assert Min(1).concat(Min(3)).concat(Min(2)) == Min(1)
    except AssertionError:
        print(
            "test_Min_concat has been failed, please check method concat of class Min"
        )
    else:
        print(
            "test_Min_concat has been passed, method concat of class Min has been completed"
        )



# Generated at 2022-06-21 19:35:09.657004
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert (
        Semigroup._v_default_type(None) == Sum
    ), "when value is None and type is not provided it should return type=Sum"
    assert (
        Semigroup._v_default_type(None, "One") == One
    ), "when value is null and type provided it should return type=One"
    assert (
        Semigroup.factory(None, "One").value == One.neutral_element
    ), "when value is null and type provided it should return type=One with neutral value"
    assert (
        Semigroup.factory({}, "Map").value == {}
    ), "when value is null and type provided it should return type=Map with neutral value"

# Generated at 2022-06-21 19:35:11.052643
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-21 19:35:11.832262
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)).value == 1

# Generated at 2022-06-21 19:35:13.578490
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == "Min[value=1]"


# Unit tests for method fold of class Min

# Generated at 2022-06-21 19:35:21.810414
# Unit test for constructor of class Last
def test_Last():
    assert Last(1), 'Last(1) must be 1'
    assert Last(True), 'Last(True) must be True'
    assert Last(1.234), 'Last(1.234) must be 1.234'
    assert Last([1, 2, 3]), 'Last([1, 2, 3]) must be [1, 2, 3]'
    assert Last((1, 2, 3)), 'Last((1, 2, 3)) must be (1, 2, 3)'
    assert Last({'key': 'value'}), "Last({'key': 'value'}) must be {'key': 'value'}"


# Generated at 2022-06-21 19:35:24.304775
# Unit test for constructor of class One
def test_One():
    assert isinstance(One(True), One) is True


# Generated at 2022-06-21 19:35:27.937863
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)

# Generated at 2022-06-21 19:35:30.071737
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert Max(4).__str__() == 'Max[value=4]'



# Generated at 2022-06-21 19:35:31.884978
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-21 19:35:40.719150
# Unit test for method __str__ of class Map
def test_Map___str__():
    from hamcrest import assert_that
    from hamcrest.core.core.isequal import equal_to
    from hamcrest.library.collection.issequence_containinginanyorder import contains_inanyorder
    assert_that(Map({1: 1, 2: 2, 3: 3}).__str__() == Map({3: 3, 2: 2, 1: 1}).__str__(), equal_to(True))
    assert_that(Map({1: 1, 2: 2, 3: 3}).__str__(), equal_to('Map[value={1: Sum[value=1], 2: Sum[value=2], 3: Sum[value=3]}]'))

# Generated at 2022-06-21 19:35:42.122008
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-21 19:35:44.521374
# Unit test for method __str__ of class Last
def test_Last___str__(): # pragma: no cover
    assert str(Last(3)) == 'Last[value=3]'
    assert str(Last(True)) == 'Last[value=True]'


# Generated at 2022-06-21 19:35:49.899660
# Unit test for constructor of class Map
def test_Map():
    assert Map({0:Sum(4), 1:First("Boring")}) == Map({0: Sum(4), 1: First("Boring")})
    assert Map({0: Sum(4), 1: All(True), 2: One(False), 4: Last("Boring")}) == Map(
        {0: Sum(4), 1: All(True), 2: One(False), 4: Last("Boring")}
    )
    assert Map({0: Sum(4), 1: First("Boring")}) == Map(
        {0: Sum(4), 1: First("Boring"), 2: All(True)}
    )


# Generated at 2022-06-21 19:35:54.830354
# Unit test for constructor of class Last
def test_Last():
    last = Last(20)
    assert last.value == 20
    assert last.concat(Last(10)).value == 10
    assert last.concat(Last(20)).value == 20
    assert last.concat(Last(30)).value == 30


# Generated at 2022-06-21 19:35:57.155266
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False
    assert All(5).value == True
    assert All('abc').value == True


# Generated at 2022-06-21 19:36:00.828555
# Unit test for constructor of class Max
def test_Max():
    max1 = Max(1)
    max2 = Max(2)
    assert max1.concat(max2).value == 2


# Generated at 2022-06-21 19:36:02.138527
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1


# Generated at 2022-06-21 19:36:03.966640
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-21 19:36:06.576180
# Unit test for method __str__ of class Min
def test_Min___str__():
    min_str = Min(-5)
    assert isinstance(min_str, Min)
    assert min_str.__str__() == 'Min[value=-5]'



# Generated at 2022-06-21 19:36:12.421242
# Unit test for method concat of class Map
def test_Map_concat():
    """
    Unit test for method concat of class Map
    """
    assert Map(
        {"k0": Sum(5), "k1": Min(7), "k2": All(True), "k3": Last(0)}
    ).concat(
        Map({"k0": Sum(10), "k1": Min(2), "k2": All(False), "k3": Last(1)})
    ).value == {
        "k0": Sum(15),
        "k1": Min(2),
        "k2": All(False),
        "k3": Last(1),
    }

# Generated at 2022-06-21 19:36:22.531574
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)
    assert One(0).concat(One(False)) == One(False)
    assert One('').concat(One(False)) == One(False)
    assert One([]).concat(One(False)) == One(False)
    assert One(None).concat(One(False)) == One(False)
    assert One(False).concat(One(0)) == One(False)
    assert One(False).concat(One('')) == One(False)

# Generated at 2022-06-21 19:36:28.801877
# Unit test for constructor of class All
def test_All():
    assert All(0) == All(False) == All(False)
    assert All(1) == All(True) == All(True)
    assert All(0).concat(All(0) == All(1)) == All(0)
    assert All(1).concat(All(1) == All(1)) == All(1)
    assert All(0).concat(All(0) == All(1)) == All(0)
    assert All(1).concat(All(0) == All(1)) == All(0)
    assert All(1).concat(All(1) == All(1)) == All(1)
    assert All(1).concat(All(0) == All(1)) == All(0)

# Generated at 2022-06-21 19:36:31.082716
# Unit test for method __str__ of class Last
def test_Last___str__():
    actual = str(Last(4))
    expected = 'Last[value=4]'
    assert actual == expected


# Generated at 2022-06-21 19:36:33.871255
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert(str(Max(10)) == "Max[value=10]")



# Generated at 2022-06-21 19:36:37.044895
# Unit test for constructor of class One
def test_One():
    a = One(True)
    b = One(False)
    c = One(True)
    assert a.value == True
    assert b.value == False
    assert c.value == True


# Generated at 2022-06-21 19:36:40.417604
# Unit test for method __str__ of class First
def test_First___str__():
    first = First(1)
    assert first.__str__() == 'Fist[value=1]'


# Generated at 2022-06-21 19:36:45.354307
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(5)) == 'Sum[value=5]'
    assert str(Sum(6)) == 'Sum[value=6]'


# Generated at 2022-06-21 19:36:49.033495
# Unit test for method __str__ of class Map
def test_Map___str__():
  map = Map({'h': Sum(1), 'hello': Sum(2)})
  assert str(map) == 'Map[value={\'h\': Sum[value=1], \'hello\': Sum[value=2]}]'


# Generated at 2022-06-21 19:36:50.954024
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(0).concat(Max(5)) == Max(5)


# Generated at 2022-06-21 19:36:52.707513
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)



# Generated at 2022-06-21 19:36:53.661810
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    Sum(5).__str__()


# Generated at 2022-06-21 19:36:55.315105
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-21 19:36:58.215142
# Unit test for method concat of class First
def test_First_concat():
    a = First('data')
    b = a.concat(First('hello'))
    assert a == First('data')
    assert b == First('data')



# Generated at 2022-06-21 19:37:00.906781
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert Last(1) != 2


# Generated at 2022-06-21 19:37:02.080714
# Unit test for method __str__ of class All
def test_All___str__():
    all = All(True)
    assert all.__str__() == 'All[value=True]'



# Generated at 2022-06-21 19:37:06.016469
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)
    assert Min(1).value == 1
    assert Min(0).value == 0
    assert Min(-1).value == -1


# Generated at 2022-06-21 19:37:09.138107
# Unit test for constructor of class First
def test_First():
    first = First(6)
    assert isinstance(first, First)
    assert first.value == 6



# Generated at 2022-06-21 19:37:14.793222
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(4).concat(Min(5)).value == 4
    assert Min(5).concat(Min(4)).value == 4
    assert Min(7).concat(Min(7)).value == 7
    assert Min('Z').concat(Min('A')).value == 'A'
    assert Min('A').concat(Min('Z')).value == 'A'


# Generated at 2022-06-21 19:37:20.114284
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).concat(All(True)).value == True
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
    assert All(False).concat(All(False)).value == False
    assert All(True).concat(All(True)).concat(All(False)).value == False


# Generated at 2022-06-21 19:37:23.985697
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert List(1, 2, 3).fold(Sum).value == 6
    assert List(0, 0, 1, 1).fold(All).value is True
    assert List(0, 0, 1, 1).fold(lambda x: List(x)).value == List(0, 0, 1, 1)



# Generated at 2022-06-21 19:37:25.637569
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert Map({1:1}).__str__() == "Map[value={1: 1}]"



# Generated at 2022-06-21 19:37:36.036985
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x + 2) == 3
    assert Sum(1).fold(lambda x: x * 2) == 2
    assert All(True).fold(lambda x: x) == True
    assert All(True).fold(lambda x: x == False) == False
    assert First("first").fold(lambda x: x.upper()) == "FIRST"
    assert First("first").fold(lambda x: x[::-1]) == "first"
    assert Last("last").fold(lambda x: x.upper()) == "LAST"
    assert Last("last").fold(lambda x: x[::-1]) == "last"
    assert Max(42).fold(lambda x: x + 5) == 47
    assert Max(42).fold(lambda x: x - 5) == 42
    assert Min(42).fold

# Generated at 2022-06-21 19:37:37.399807
# Unit test for constructor of class All
def test_All():
    assert not All(True) == All(False)



# Generated at 2022-06-21 19:37:41.315434
# Unit test for method concat of class Map
def test_Map_concat():
    Map({"one": Sum(1), "ten": Sum(10)}).concat(
        Map({"one": Sum(2), "ten": Sum(100)})
    ) == Map({"one": Sum(3), "ten": Sum(110)})



# Generated at 2022-06-21 19:37:43.166733
# Unit test for constructor of class Min
def test_Min():
    assert Min(2) == Min(2)
    assert Min(1) != Min(2)



# Generated at 2022-06-21 19:37:45.957793
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(4) == Semigroup(4)



# Generated at 2022-06-21 19:37:49.637783
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(10)) == 'Max[value=10]'
    assert str(Max(-10)) == 'Max[value=-10]'

# Generated at 2022-06-21 19:37:52.958057
# Unit test for constructor of class Max
def test_Max():
    assert isinstance(Max(5), Max)
    assert isinstance(Max(5), Semigroup)



# Generated at 2022-06-21 19:37:54.887514
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)


# Generated at 2022-06-21 19:38:01.894049
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert Last(1).__str__() == 'Last[value=1]'
    assert Last('test').__str__() == 'Last[value=test]'
    assert Last({1, 2, 3}).__str__() == 'Last[value={1, 2, 3}]'
    assert Last(Last(1)).__str__() == 'Last[value=Last[value=1]]'
    assert Last(Last({1, 2, 3})).__str__() == 'Last[value=Last[value={1, 2, 3}]]'


# Generated at 2022-06-21 19:38:03.669647
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    semigroup = Semigroup(42)
    assert semigroup == Semigroup(42)



# Generated at 2022-06-21 19:38:06.307957
# Unit test for method __str__ of class First
def test_First___str__():
    expected = "Fist[value=1]"
    actual = First(1)
    assert str(actual) == expected



# Generated at 2022-06-21 19:38:09.772983
# Unit test for method concat of class First
def test_First_concat():
    f1 = First(10)
    f2 = First(5)
    assert f1.concat(f2) == First(10)


# Generated at 2022-06-21 19:38:11.882391
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert str(Max(value=1)) == "Max[value=1]"



# Generated at 2022-06-21 19:38:14.235201
# Unit test for method __str__ of class Min
def test_Min___str__():
    # Test First
    assert str(Min(2)) == 'Min[value=2]'



# Generated at 2022-06-21 19:38:19.088291
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Unit test for method fold of class Semigroup
    """
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    assert Semigroup(21).fold(lambda x: x + 1) == 22


# Generated at 2022-06-21 19:38:26.945034
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True
    assert One(None).value == False
    assert One(0).value == False
    assert One(1).value == True
    assert One('').value == False
    assert One('a').value == True
    assert One([]).value == False
    assert One([1]).value == True
    assert One(()).value == False
    assert One(('a',)).value == True
    assert One({}).value == False
    assert One({'a': 1}).value == True


# Generated at 2022-06-21 19:38:34.236992
# Unit test for constructor of class Last
def test_Last():  # pragma: no cover
    assert Last(0) == Last(0)
    assert Last(1) == Last(1)
    assert Last('a') == Last('a')
    assert Last(False) == Last(False)
    assert Last(0) == Last(0)
    assert Last({}) == Last({})
    assert Last({'a': 2}) == Last({'a': 2})
    assert Last([]) == Last([])
    assert Last([1, 2, 3]) == Last([1, 2, 3])

    assert Last(0) != Last(1)
    assert Last(1) != Last(0)
    assert Last('a') != Last(1)
    assert Last(True) != Last(False)
    assert Last(0) != Last(False)
    assert Last({}) != Last([])

# Generated at 2022-06-21 19:38:36.582551
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(4).concat(Max(5)).concat(Max(3)) == Max(5)


# Generated at 2022-06-21 19:38:41.079843
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(True) == One(True)
    assert First(True) == First(True)
    assert Last(True) == Last(True)
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)


# Generated at 2022-06-21 19:38:51.812379
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(False).concat(One(1)) == One(True)
    assert One(False).concat(One('1')) == One(True)
    assert One(False).concat(One('a')) == One(True)
    assert One(False).concat(One([])) == One(False)
    assert One(False).concat(One((1,))) == One(True)
    assert One(False).concat(One({1:1})) == One(True)
    assert One

# Generated at 2022-06-21 19:38:53.409764
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2



# Generated at 2022-06-21 19:38:57.507728
# Unit test for constructor of class Map
def test_Map():
    assert Map({}) == Map({})
    assert Map({'foo': 'bar'}) == Map({'foo': 'bar'})
    try:
        assert Map({'foo': 'bar'}) == {'foo': 'bar'}
    except AssertionError:
        assert True


# Generated at 2022-06-21 19:38:58.902981
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)


# Generated at 2022-06-21 19:39:04.400546
# Unit test for method concat of class One
def test_One_concat():
    assert One(False).concat(One(True)) == One(True)
    assert One(True).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(False)) == One(True)


# Generated at 2022-06-21 19:39:07.926620
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(100)) == "Max[value=100]"


# Generated at 2022-06-21 19:39:13.448911
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum.neutral_element == 0
    assert All.neutral_element == True
    assert First().fold(lambda x: x(1)) == 1
    assert Map().fold(lambda x: x + 2) == 2
    assert Last().fold(lambda x: x(1)) == 1
    assert Min.neutral_element == float("inf")
    assert One.neutral_element == False
    assert Max.neutral_element == -float("inf")


# Generated at 2022-06-21 19:39:18.427155
# Unit test for method concat of class First
def test_First_concat():
    first_value = 'first_value'
    first = First(first_value)
    second_value = 'second_value'
    second = First(second_value)
    result = first.concat(second)
    expected_result = First(first_value)
    assert result == expected_result


# Generated at 2022-06-21 19:39:20.306458
# Unit test for constructor of class First
def test_First():
    assert First(1)
    assert First(1).concat(1) == First(1)


# Generated at 2022-06-21 19:39:25.161878
# Unit test for method concat of class All
def test_All_concat():
    assert True == All(True).concat(All(True)).value
    assert False == All(False).concat(All(False)).value
    assert False == All(True).concat(All(False)).value
    assert False == All(False).concat(All(True)).value



# Generated at 2022-06-21 19:39:30.091305
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x + 1) == 2
    assert Semigroup(2).fold(lambda x: x + 1) == 3
    assert Semigroup(3).fold(lambda x: x + 1) == 4
    assert Semigroup(4).fold(lambda x: x + 1) == 5



# Generated at 2022-06-21 19:39:41.219512
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({1: Sum(1), 2: Min(1)})
    m2 = Map({1: Sum(2)})
    m3 = Map({2: Min(2)})
    m4 = Map({1: Sum(2), 2: Min(3)})
    m5 = Map({1: Sum(3), 2: Min(2)})
    assert m1.concat(m2) == Map({1: Sum(3), 2: Min(1)})
    assert m1.concat(m3) == Map({1: Sum(1), 2: Min(1)})
    assert m2.concat(m1) == Map({1: Sum(3), 2: Min(1)})
    assert m3.concat(m1) == Map({1: Sum(1), 2: Min(1)})

# Generated at 2022-06-21 19:39:48.186497
# Unit test for constructor of class Map
def test_Map():
    result = Map(
        {
            'name': First('Raphael'),
            'age': Max(90),
            'height': Sum(180),
            'is_alive': All(True)
        }
    )
    assert result.value == {
        'name': First('Raphael'),
        'age': Max(90),
        'height': Sum(180),
        'is_alive': All(True)
    }


# Generated at 2022-06-21 19:39:52.554884
# Unit test for method concat of class All
def test_All_concat():
    assert (
        All(True)
        .concat(All(True))
        .fold(lambda x: x)
    ) is True
    assert (
        All(True)
        .concat(All(False))
        .fold(lambda x: x)
    ) is False



# Generated at 2022-06-21 19:39:56.465501
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).concat(Min(3)).value == 1
    assert Min(9).concat(Min(2)).concat(Min(3)).value == 2
    assert Min(9).concat(Min(3)).concat(Min(3)).value == 3


# Generated at 2022-06-21 19:40:02.501370
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(0) == Sum(0)
    assert Sum(0) != Sum(1)
    assert str(Sum(0)) == 'Sum[value=0]'


# Generated at 2022-06-21 19:40:05.731402
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(2).concat(Max(2)) == Max(2)

# Generated at 2022-06-21 19:40:09.443691
# Unit test for method concat of class One
def test_One_concat():
    assert One(1) == One(1).concat(One(2))
    assert One(2) == One(2).concat(One(1))
    assert One(None) == One(None).concat(One(1))
    assert One(1) == One(1).concat(One(None))
    assert One(1) == One(1).concat(One(1))
    assert One(None) == One(None).concat(One(None))


# Generated at 2022-06-21 19:40:13.590837
# Unit test for method concat of class Min
def test_Min_concat():
    # given
    a = Min(1)
    b = Min(0.5)
    # when
    actual = a.concat(b)
    # then
    expected = Min(0.5)
    assert actual == expected

# Generated at 2022-06-21 19:40:15.544701
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert Map({'a': 1, 'b': 2}).__str__() == "Map[value={'a': 1, 'b': 2}]"



# Generated at 2022-06-21 19:40:17.171928
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)


# Unit tests for classes Sum

# Generated at 2022-06-21 19:40:18.375437
# Unit test for constructor of class Semigroup
def test_Semigroup():

    assert Semigroup(1) is not None



# Generated at 2022-06-21 19:40:21.367611
# Unit test for constructor of class Max
def test_Max():  # pragma: no cover
    assert Max(1).value == 1
    assert Max(-1).value == -1
    assert Max(1.1).value == 1.1
    assert Max(-1.1).value == -1.1



# Generated at 2022-06-21 19:40:30.725143
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    This function tests the constructor of class Semigroup.
    """
    # Test case that checks the value is set correct
    assert Semigroup('a').value == 'a'
    # Test case that checks the values are equal to each other
    assert Semigroup('b').value == Semigroup('b').value
    # Test case that checks the values are not equal to another value
    assert Semigroup('c').value != None
    # Test case that checks the fold function returns the correct value
    assert Semigroup('d').fold(str.upper) == 'D'
    # Test case that checks the fold function raises an error if the type of the value is not supported
    try:
        Semigroup([1, 2, 3]).fold(str.length)
    except TypeError:
        assert True
    else:
        assert False



# Generated at 2022-06-21 19:40:35.547015
# Unit test for method __str__ of class Last
def test_Last___str__():
    # Given
    instance = Last("Last Value")

    # When
    result = str(instance)

    # Then
    assert result == 'Last[value=Last Value]'


# Generated at 2022-06-21 19:40:41.613496
# Unit test for constructor of class Last
def test_Last():
    last = Last(5)
    assert last.value == 5
    assert last.concat(Last(2)) == Last(2)


# Generated at 2022-06-21 19:40:45.444219
# Unit test for constructor of class Max
def test_Max():
    max1 = Max(1)
    max2 = Max(2)
    result = max1.concat(max2)
    assert result.value == 2



# Generated at 2022-06-21 19:40:47.124621
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False


# Generated at 2022-06-21 19:40:50.068693
# Unit test for constructor of class Semigroup
def test_Semigroup():
    try:
        s = Semigroup(5)
        assert s.value == 5
    except Exception as e:
        print('test_Semigroup:', e)
        raise
    else:
        print('test_Semigroup: OK')



# Generated at 2022-06-21 19:40:54.909444
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    Unit test that checks that the __eq__ method on
    Semigroup behaves as expected
    """
    # Given
    semigroup_1 = Sum(1)
    semigroup_2 = Sum(1)
    semigroup_3 = Sum(2)

    # Then
    assert semigroup_1 == semigroup_2, 'Semigroups must be equal'
    assert semigroup_1 != semigroup_3, 'Semigroups must not be equal'



# Generated at 2022-06-21 19:40:56.733393
# Unit test for constructor of class Map
def test_Map():
    f = lambda a: a + 1
    arr = [1, 2, 3]
    a = Map(f).fold(arr)
    assert a == [2, 3, 4]


# Generated at 2022-06-21 19:40:59.691679
# Unit test for method concat of class Last
def test_Last_concat():
    """
    Testing method concat
    """
    last = Last(1)
    new_last = last.concat(Last(2))
    assert new_last == Last(2)



# Generated at 2022-06-21 19:41:02.064019
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)).value == 3
    assert Sum(5).concat(Sum(7)).value == 12



# Generated at 2022-06-21 19:41:04.046012
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert Semigroup(1)
    assert Semigroup('a')
    assert Semigroup(True)



# Generated at 2022-06-21 19:41:06.175572
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({'a': First(1)}) == Map({'a': First(1)}).concat(Map({'a': First(2)}))



# Generated at 2022-06-21 19:41:11.392607
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'key': First(1)})) == "Map[value={'key': Fist[value=1]}]"


# Generated at 2022-06-21 19:41:14.195719
# Unit test for constructor of class Min
def test_Min():
    assert Min(7) == Min(7)
    assert Min(7) != Min(5)
    assert Min(7).value == 7


# Generated at 2022-06-21 19:41:15.385736
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(2)) == 'Last[value=2]'

# Generated at 2022-06-21 19:41:21.822566
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({
        'first': Sum(5),
        'second': First('hello'),
        'third': Last('world')
    })
    m2 = Map({
        'first': Sum(3),
        'second': First('bla'),
        'third': Last('ha')
    })
    
    assert m1.concat(m2) == Map({
        'first': Sum(8),
        'second': First('hello'),
        'third': Last('ha')
    })

# Generated at 2022-06-21 19:41:31.847753
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True))   == 'All[value=True]'
    assert str(All(False))  == 'All[value=False]'
    assert str(All(None))   == 'All[value=None]'
    assert str(All(0))      == 'All[value=0]'
    assert str(All(1))      == 'All[value=1]'
    assert str(All([]))     == 'All[value=[]]'
    assert str(All(()))     == 'All[value=()]'
    assert str(All({}))     == 'All[value={}]'
    assert str(All(''))     == 'All[value=]'
    assert str(All('test')) == 'All[value=test]'
    assert str(All([]))     == 'All[value=[]]'

#

# Generated at 2022-06-21 19:41:37.081118
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-21 19:41:44.492956
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'key': Sum(5)})) == "Map[value={'key': Sum[value=5]}]"
    assert str(Map({'key': All(True)})) == "Map[value={'key': All[value=True]}]"
    assert str(Map({'key': One(False)})) == "Map[value={'key': One[value=False]}]"
    assert str(Map({'key': First(True)})) == "Map[value={'key': Fist[value=True]}]"
    assert str(Map({'key': Last(False)})) == "Map[value={'key': Last[value=False]}]"
    assert str(Map({'key': Max(100)})) == "Map[value={'key': Max[value=100]}]"

# Generated at 2022-06-21 19:41:46.587985
# Unit test for constructor of class Last
def test_Last():
    assert Last(4) == Last(4)


# Generated at 2022-06-21 19:41:51.067332
# Unit test for method concat of class One
def test_One_concat():
    # Given
    a_One = One(1)
    another_One = One(2)
    expect = One(1)

    # When
    actual = a_One.concat(another_One)

    # Then
    assert expect == actual



# Generated at 2022-06-21 19:41:56.105757
# Unit test for method concat of class All
def test_All_concat():
    result = All(True).concat(All(True))  # True
    assert result.value == True
    result = All(True).concat(All(False))  # False
    assert result.value == False
    result = All(False).concat(All(True))  # False
    assert result.value == False
    result = All(False).concat(All(False))  # False
    assert result.value == False


# Generated at 2022-06-21 19:42:06.779781
# Unit test for constructor of class Min
def test_Min():
    """
    :returns: test result
    :rtype: bool
    """
    min = Min(10)
    assert min.value == 10


# Generated at 2022-06-21 19:42:09.469764
# Unit test for method __str__ of class Last
def test_Last___str__():
    # Given
    last = Last(1)

    # When
    result = str(last)

    # Then
    assert result == 'Last[value=1]'



# Generated at 2022-06-21 19:42:12.557941
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup('str') == Semigroup('str')
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup('str') == Semigroup(1)



# Generated at 2022-06-21 19:42:14.134572
# Unit test for method __str__ of class Max
def test_Max___str__():
    result = Max(5).__str__()
    expected = 'Max[value=5]'

    assert result == result == expected


# Generated at 2022-06-21 19:42:16.852968
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == "Fist[value=1]"
    assert str(First(True)) == "Fist[value=True]"
    assert str(First("test")) == "Fist[value=test]"
    assert str(First(None)) == "Fist[value=None]"



# Generated at 2022-06-21 19:42:18.505960
# Unit test for method __str__ of class Max
def test_Max___str__(): # pragma: no cover
    assert str(Max(2)) == 'Max[value=2]'


# Generated at 2022-06-21 19:42:19.972662
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max.neutral()) == 'Max[value=-inf]'



# Generated at 2022-06-21 19:42:21.900569
# Unit test for constructor of class Semigroup
def test_Semigroup():

    # Test for zero value of neutral element
    assert Semigroup(0).value == 0


# Test for method __eq__ of class Semigroup

# Generated at 2022-06-21 19:42:23.658318
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-21 19:42:26.655002
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)
    assert Sum(1) == Sum(1).concat(Sum(0))
    assert Sum(10) == Sum(1).concat(Sum(9))
    assert Sum(2).concat(Sum(1)).fold(lambda x: x) == 3


# Generated at 2022-06-21 19:42:35.736845
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).fold((lambda x: x == 1))


# Generated at 2022-06-21 19:42:38.149912
# Unit test for constructor of class Min
def test_Min():
    min_a=Min(5)
    min_b=Min(10)
    min_c=Min(min_a.concat(min_b)) # 15
    assert min_c.value==5


# Generated at 2022-06-21 19:42:41.054513
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map({"a": Sum(1)})
    map2 = Map({"a": Sum(2)})

    assert map1.concat(map2) == Map({"a": Sum(3)})



# Generated at 2022-06-21 19:42:45.197891
# Unit test for method concat of class Last
def test_Last_concat():
    """
    :param semigroup: semigroup to test
    :type semigroup: Last[B]
    :returns: True if the test is successfully passed, otherwise False
    :rtype: bool
    """
    
    return Last("Hello").concat(Last("World")) == Last("World")



# Generated at 2022-06-21 19:42:46.528052
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(a) == Sum(a)
    assert Sum(a) != Sum(b)



# Generated at 2022-06-21 19:42:52.827936
# Unit test for method concat of class One
def test_One_concat():
    assert One(True) == One(True).concat(One(True))
    assert One(True) == One(False).concat(One(True))
    assert One(True) == One(True).concat(One(False))
    assert One(False) == One(False).concat(One(False))


# Generated at 2022-06-21 19:42:57.747416
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'
    assert str(One(1)) == 'One[value=1]'
    assert str(One('string')) == 'One[value=string]'


# Generated at 2022-06-21 19:43:00.323591
# Unit test for method concat of class Max
def test_Max_concat():
    """
    max1 = Max(1)
    max2 = Max(2)
    assert max1.concat(max2) == Max(2)
    """
    assert True


# Generated at 2022-06-21 19:43:05.357769
# Unit test for method concat of class One
def test_One_concat():
    """
    Case 1: test One.concat with first argument
    """
    assert One(False).concat(One(1)) == One(1)

    """
    Case 2: test One.concat with last argument
    """
    assert One(1).concat(One(False)) == One(1)

    """
    Case 3: test One.concat with first and last argument
    """
    assert One(1).concat(One(2)) == One(1)

# Generated at 2022-06-21 19:43:09.852541
# Unit test for method concat of class Map
def test_Map_concat():
    a = Map({
        2: Min(2),
        3: Min(3),
    })

    b = Map({
        2: Min(1),
        3: Min(2),
    })

    expected = Map({
        2: Min(1),
        3: Min(2),
    })

    actual = a.concat(b)

    assert actual == expected

# Generated at 2022-06-21 19:43:18.200861
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(2)) == 'Fist[value=2]'



# Generated at 2022-06-21 19:43:20.628067
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First('test')) == 'Fist[value=test]'


# Generated at 2022-06-21 19:43:25.938758
# Unit test for method concat of class First
def test_First_concat():
    first = First(1)
    second = First(2)
    third = First('a')
    assert first.concat(second) == first
    assert second.concat(first) == second
    assert third.concat(first) == third



# Generated at 2022-06-21 19:43:29.678805
# Unit test for method concat of class First
def test_First_concat():
    assert First(5).concat(First(4)) == First(5)
    assert First(4).concat(First(5)) == First(4)



# Generated at 2022-06-21 19:43:31.137285
# Unit test for constructor of class Min
def test_Min():
    assert Min(2) == Min(2)


# Generated at 2022-06-21 19:43:33.688845
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(1)
    b = Min(2)
    c = a.concat(b)
    return c.value == 1


# Generated at 2022-06-21 19:43:34.906316
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(5)) == 'Max[value=5]'



# Generated at 2022-06-21 19:43:36.805422
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(True).__str__() == 'One[value=True]'


# Generated at 2022-06-21 19:43:38.020338
# Unit test for method concat of class Last
def test_Last_concat(): # pragma: no cover
    assert Last(10).concat(Last(20)) == Last(20)



# Generated at 2022-06-21 19:43:41.833284
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'
    assert str(All(None)) == 'All[value=None]'



# Generated at 2022-06-21 19:43:57.896020
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)


# Generated at 2022-06-21 19:43:59.906066
# Unit test for method __str__ of class All
def test_All___str__():
    a = All(True)
    assert str(a) == 'All[value=True]'



# Generated at 2022-06-21 19:44:02.754622
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'  # pragma: no cover



# Generated at 2022-06-21 19:44:05.429069
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'1': 1, '2': 2})) == "Map[value={'1': 1, '2': 2}]"



# Generated at 2022-06-21 19:44:07.363387
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(2)) == 'Min[value=2]'
