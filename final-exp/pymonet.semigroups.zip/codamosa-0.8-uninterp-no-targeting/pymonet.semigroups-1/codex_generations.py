

# Generated at 2022-06-21 19:34:22.788051
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-21 19:34:27.824118
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).concat(One(0)) == One(True)
    assert One(0).concat(One(1)) == One(True)
    assert One(0).concat(One(0)) == One(False)


# Generated at 2022-06-21 19:34:29.199359
# Unit test for constructor of class One
def test_One():
    assert One(1)
    assert One(1).value == 1

# Generated at 2022-06-21 19:34:30.726067
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum = Sum(1)
    concat_result = sum.concat(Sum(2))
    assert concat_result == Sum(3)



# Generated at 2022-06-21 19:34:34.164471
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert All(False) == All(False)
    assert One(True) == One(True)
    assert Last(False) == Last(False)
    assert First(False) == First(False)
    assert Map({}) == Map({})
    assert Sum(2) == Sum(2)
    assert Max(4) == Max(4)
    assert Min(3) == Min(3)


# Generated at 2022-06-21 19:34:35.502611
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(15)) == 'Max[value=15]'


# Generated at 2022-06-21 19:34:38.491271
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    factorial = Semigroup.neutral(Sum).fold(lambda x: x * (x - 1))

    assert factorial == 0

# Generated at 2022-06-21 19:34:45.838923
# Unit test for method concat of class One
def test_One_concat():
    """
    Unit test for method concat of class One
    """
    one1 = One(2)
    one2 = One(2)
    one3 = One(True)
    one4 = One(False)
    one5 = One(False)
    one1_concat_one2_output = One(2)
    one3_concat_one4_output = One(True)
    one4_concat_one5_output = One(False)
    assert one1.concat(one2) == one1_concat_one2_output
    assert one3.concat(one4) == one3_concat_one4_output
    assert one4.concat(one5) == one4_concat_one5_output


# Generated at 2022-06-21 19:34:52.367127
# Unit test for method concat of class Min
def test_Min_concat():
    x = Min(25)
    y = Min(50)
    assert x.concat(y) == Min(25)
    x = Min(50)
    y = Min(25)
    assert x.concat(y) == Min(25)
    x = Min(25)
    y = Min(25)
    assert x.concat(y) == Min(25)


# Generated at 2022-06-21 19:34:54.180059
# Unit test for constructor of class Last
def test_Last():
    value = 3

    last = Last(value)
    assert last.value == value


# Generated at 2022-06-21 19:35:02.254252
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    Test Semigroup constructor.
    """
    for value in [1, 2.3, "string", None]:
        assert Semigroup(value).value == value


# Generated at 2022-06-21 19:35:04.936167
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(5.2)) == 'Fist[value=5.2]'


# Generated at 2022-06-21 19:35:08.372357
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == str('Sum[value=1]')
    assert str(Sum('a')) == str('Sum[value=a]')
    assert str(Sum([])) == str('Sum[value=[]]')



# Generated at 2022-06-21 19:35:10.162226
# Unit test for constructor of class Min
def test_Min():
    assert Min(10) == Min(10)
    assert Min(20) != Min(10)


# Generated at 2022-06-21 19:35:11.978918
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'foo': Sum(2)})) == "Map[value={'foo': Sum[value=2]}]"

# Generated at 2022-06-21 19:35:13.702901
# Unit test for constructor of class Max
def test_Max():
    """
    :return: void
    """
    assert Max(1) == Max(1)

# Generated at 2022-06-21 19:35:16.661240
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(4).concat(Min(2)) == Min(2)


# Generated at 2022-06-21 19:35:18.060965
# Unit test for constructor of class Max
def test_Max():
    assert Max(2) == Max(2)
    assert Max(2) != Max(3)


# Generated at 2022-06-21 19:35:19.419624
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert Max(1).__str__() == 'Max[value=1]'


# Generated at 2022-06-21 19:35:20.554302
# Unit test for constructor of class First
def test_First():
    assert First("A") == First("A")



# Generated at 2022-06-21 19:35:31.638386
# Unit test for constructor of class Map
def test_Map():
    a = Map({"a": Sum(1), "b": Sum(2)})
    b = Map({"a": Sum(2), "b": Sum(3)})
    assert a.concat(b) == Map({"a": Sum(3), "b": Sum(5)})

# Generated at 2022-06-21 19:35:33.024398
# Unit test for constructor of class Max
def test_Max():  # pragma: no cover
    assert Max(1) == Max(1)

# Generated at 2022-06-21 19:35:34.641083
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)



# Generated at 2022-06-21 19:35:37.685288
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(5).concat(Sum(2)) == Sum(7)
    assert Sum(0).concat(Sum(0)) == Sum(0)


# Generated at 2022-06-21 19:35:39.158998
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-21 19:35:41.436840
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One("test")) == "One[value=test]"

# Live test for method __str__ of class One

# Generated at 2022-06-21 19:35:42.829876
# Unit test for constructor of class Min
def test_Min():
    assert Min(4) == Min(4)



# Generated at 2022-06-21 19:35:45.277371
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': 1})) == 'Map[value={\'a\': 1}]'



# Generated at 2022-06-21 19:35:46.621414
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(True).value is True



# Generated at 2022-06-21 19:35:52.620469
# Unit test for constructor of class First
def test_First():
    assert First('Lorem').value == 'Lorem'
    assert First('Lorem').concat(First('Ipsum')).value == 'Lorem'
    assert First('Lorem').concat(First(123)).value == 'Lorem'
    assert First('Lorem').concat(First(True)).value == 'Lorem'


# Generated at 2022-06-21 19:35:56.456645
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)



# Generated at 2022-06-21 19:35:58.853601
# Unit test for method concat of class Max
def test_Max_concat():
    max_1 = Max(10)
    max_2 = Max(20)
    assert max_1.concat(max_2) == Max(20)


# Generated at 2022-06-21 19:36:07.470892
# Unit test for constructor of class Min
def test_Min():
    m1 = Min(1)
    # assert m1.concat(Min(2)).value == 1, "Min(1).concat(Min(2)).value -> {0}".format(m1.concat(Min(2)).value)
    # assert m1.concat(Min(0)).value == 0, "Min(1).concat(Min(0)).value -> {0}".format(m1.concat(Min(0)).value)
    assert m1.concat(Min(1)).value == 1, "Min(1).concat(Min(1)).value -> {0}".format(m1.concat(Min(1)).value)



# Generated at 2022-06-21 19:36:13.111681
# Unit test for method concat of class One
def test_One_concat():
    t = One(True)
    f = One(False)
    assert t.concat(f).value == True
    assert f.concat(t).value == True
    assert t.concat(t).value == True
    assert f.concat(f).value == False


# Generated at 2022-06-21 19:36:16.353896
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    :returns: True if constructors of class Semigroup works, otherwise raises AssertionError
    :rtype: bool
    """
    assert Semigroup(10).value == 10
    return True


# Generated at 2022-06-21 19:36:18.539758
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1
    assert First('1').value == '1'
    assert First(True).value is True



# Generated at 2022-06-21 19:36:20.878705
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False
    assert All(1).value == True


# Generated at 2022-06-21 19:36:24.947110
# Unit test for method __str__ of class One
def test_One___str__():
    a = One(10)
    assert str(a) == 'One[value=10]'

    b = One(None)
    assert str(b) == 'One[value=None]'

    c = One(True)
    assert str(c) == 'One[value=True]'

    d = One(False)
    assert str(d) == 'One[value=False]'



# Generated at 2022-06-21 19:36:26.374073
# Unit test for constructor of class Max
def test_Max():
    m = Max(8)
    assert m.value == 8

# Generated at 2022-06-21 19:36:28.254935
# Unit test for constructor of class Max
def test_Max():
    assert Max(5) == Max(5)


# Generated at 2022-06-21 19:36:34.640165
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({1: Sum(1), 2: Sum(2)}) \
        .concat(Map({1: Sum(1), 2: Sum(2)})) \
        .value == {1: Sum(2), 2: Sum(4)}


# Generated at 2022-06-21 19:36:38.164754
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    Unit test for method __eq__ of class Semigroup
    """
    value = 5
    semigroup = Sum(value)
    assert semigroup == Sum(value)
    assert semigroup != Sum(1)



# Generated at 2022-06-21 19:36:40.462390
# Unit test for method concat of class First
def test_First_concat():
    first = First(5)
    second = First('value')

    assert first.concat(second) == first


# Generated at 2022-06-21 19:36:45.816070
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(None)) == "Fist[value=None]"
    assert str(First(1)) == "Fist[value=1]"


# Generated at 2022-06-21 19:36:52.322498
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(3).concat(Sum(5)) == Sum(8)
    assert Sum(5).concat(Sum(4)) == Sum(9)
    assert Sum(0).concat(Sum(0)) == Sum(0)
    assert Sum(0).concat(Sum(1)) == Sum(1)
    assert Sum(1).concat(Sum(0)) == Sum(1)
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-21 19:36:53.324896
# Unit test for constructor of class Min
def test_Min():
    assert Min(0) == Min(0)

# Generated at 2022-06-21 19:36:56.569855
# Unit test for method concat of class Sum
def test_Sum_concat():
    s = Sum(100)
    assert Sum(100).concat(s) == Sum(200)
    assert Sum(100).concat(Sum(10)) == Sum(110)



# Generated at 2022-06-21 19:36:58.492816
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)


# Generated at 2022-06-21 19:37:01.061084
# Unit test for method __str__ of class First
def test_First___str__():
    expected_str = "Fist[value=1]"
    assert str(First(1)) == expected_str


# Generated at 2022-06-21 19:37:04.667431
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({"a": Sum(2), "b": Sum(3)})
    m2 = Map({"a": Sum(3), "b": Sum(4)})
    assert m1.concat(m2) == Map({"a": Sum(5), "b": Sum(7)})


# Generated at 2022-06-21 19:37:09.934820
# Unit test for constructor of class One
def test_One():
    one = One(True)
    one2 = One(False)
    assert bool(one)
    assert not bool(one2)


# Generated at 2022-06-21 19:37:19.801262
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': First(3), 'b': First(5)}) == Map({'a': First(3), 'b': First(5)})
    assert (
        Map({'a': First(3), 'b': First(5)}) != Map({'a': First(3), 'b': First(5), 'c': First(6)})
    )
    assert Map({'a': First(3), 'b': First(5), 'c': First(6)}) == Map({'a': First(3), 'b': First(5), 'c': First(6)})
    assert Map({'a': First(4), 'b': First(5), 'c': First(6)}) == Map({'a': First(4), 'b': First(5), 'c': First(6)})


# Generated at 2022-06-21 19:37:21.446673
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-21 19:37:22.629927
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-21 19:37:25.643846
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    actual = str(First(1))
    expected = 'First[value=1]'
    assert actual == expected, 'Test failed: {} != {}'.format(actual, expected)



# Generated at 2022-06-21 19:37:26.829180
# Unit test for constructor of class Max
def test_Max():
    assert Max(4) == Max(4)


# Generated at 2022-06-21 19:37:28.425242
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)


# Generated at 2022-06-21 19:37:29.373999
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1

# Generated at 2022-06-21 19:37:33.284176
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(5).concat(Min(6)) == Min(5)
    assert Min(7).concat(Min(6)) == Min(6)
    assert Min(6).concat(Min(6)) == Min(6)


# Generated at 2022-06-21 19:37:35.013184
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)


# Generated at 2022-06-21 19:37:39.924778
# Unit test for constructor of class Sum
def test_Sum():
    """
    Test Sum class constructor
    """
    assert Sum(10).value == 10


# Generated at 2022-06-21 19:37:43.119447
# Unit test for constructor of class Sum
def test_Sum():
    a = Sum(1)
    b = Sum(2)
    assert a.value == 1
    assert b.value == 2
    assert a.value == b.value
    assert a == b


# Generated at 2022-06-21 19:37:45.129935
# Unit test for constructor of class Max
def test_Max(): # pragma: no cover
    assert Max(10).value == 10
    assert Max(10).neutral().value == -float("inf")



# Generated at 2022-06-21 19:37:49.815427
# Unit test for constructor of class One
def test_One():
    """
    One has no neutral element so it can't be constructed with nothing passed in.
    """
    with pytest.raises(TypeError):
        One()  # pragma: no cover
    with pytest.raises(TypeError):
        One('x', 'y')  # pragma: no cover
    with pytest.raises(TypeError):
        One(None)  # pragma: no cover



# Generated at 2022-06-21 19:37:53.803436
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert (Last(1).__str__() is not None)
    assert (Last(1).__str__() == 'Last[value=1]')



# Generated at 2022-06-21 19:37:56.586158
# Unit test for method __str__ of class Map
def test_Map___str__():
    map = Map({'a': Min(1)})
    assert "Map[value={'a': Min[value=1]}]" == map.__str__()



# Generated at 2022-06-21 19:37:58.785061
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(1)
    b = Min(2)
    assert a.concat(b) == Min(1)



# Generated at 2022-06-21 19:38:00.591847
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    semigroup = Semigroup(10)
    assert semigroup.value == 10


# Generated at 2022-06-21 19:38:03.602240
# Unit test for constructor of class Min
def test_Min():
    # Test empty constructor
    result = Min()
    assert result.value == float("inf")

    # Test constructor with param
    result = Min(0)
    assert result.value == 0


# Generated at 2022-06-21 19:38:06.059366
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)).value == 2
    assert Max(2).concat(Max(1)).value == 2



# Generated at 2022-06-21 19:38:12.186756
# Unit test for constructor of class Map
def test_Map():
    print("\nTest Map constructor")
    m = Map({1: Sum(1), 2: Sum(2)})
    print(m)


# Generated at 2022-06-21 19:38:14.460271
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(True) != One(False)


# Generated at 2022-06-21 19:38:15.368733
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1


# Generated at 2022-06-21 19:38:18.146550
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(21).concat(Min(34)).value == 21
    assert Min(34).concat(Min(30)).value == 30
    assert Min(34).concat(Min(34)).value == 34

test_Min_concat()



# Generated at 2022-06-21 19:38:19.819074
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(2) == Sum(2)


# Generated at 2022-06-21 19:38:24.316276
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(3)) == Sum(5)
    assert Sum(5).concat(Sum(3)) == Sum(8)
    assert Sum(5).concat(Sum(0)) == Sum(5)


# Generated at 2022-06-21 19:38:25.666277
# Unit test for constructor of class Min
def test_Min():
    print(Min(4))
    assert Min(4).value == 4


# Generated at 2022-06-21 19:38:29.496847
# Unit test for constructor of class All
def test_All():
    assert All(True).concat(All(True)).value == True
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
#


# Generated at 2022-06-21 19:38:30.925475
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(2.2)) == 'Min[value=2.2]'



# Generated at 2022-06-21 19:38:33.839608
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert_that(
        str(
            Last(123)
        ),
        equal_to(
            "Last[value=123]"
        )
    )


# Generated at 2022-06-21 19:38:41.791746
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    assert str(One(1)) == 'One[value=1]'


# Generated at 2022-06-21 19:38:51.765809
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(-1).concat(Min(-2)).value == -2
    assert Min(-1).concat(Min(-1)).value == -1
    assert Min(-1).concat(Min(0)).value == -1
    assert Min(-1).concat(Min(1)).value == -1
    assert Min(0).concat(Min(-2)).value == -2
    assert Min(0).concat(Min(0)).value == 0
    assert Min(0).concat(Min(1)).value == 0
    assert Min(1).concat(Min(-2)).value == -2
    assert Min(1).concat(Min(0)).value == 0
    assert Min(1).concat(Min(1)).value == 1


# Generated at 2022-06-21 19:38:53.350214
# Unit test for constructor of class Last
def test_Last():
    assert Last(4) == Last(4)



# Generated at 2022-06-21 19:38:55.651618
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)



# Generated at 2022-06-21 19:38:57.431560
# Unit test for method __str__ of class First
def test_First___str__():
    actual = str(First(1))
    expected = 'Fist[value=1]'
    assert actual == expected


# Generated at 2022-06-21 19:39:00.150140
# Unit test for method __str__ of class All
def test_All___str__():
    all = All(True)
    assert str(all) == 'All[value=True]', 'str(all) != "All[value=True]"'



# Generated at 2022-06-21 19:39:02.594580
# Unit test for method __str__ of class First
def test_First___str__():
    a = First(10)
    assert str(a) == 'Fist[value=10]'


# Generated at 2022-06-21 19:39:06.466183
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(6)


# Generated at 2022-06-21 19:39:07.450514
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1
    assert Last(1).concat(Last(3)).value == 3


# Generated at 2022-06-21 19:39:11.897671
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value == True
    assert All(False).concat(All(True)).value == False
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(False)).value == False


# Generated at 2022-06-21 19:39:21.174109
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(5).concat(Min(2)).value == Min(2).value
    return 'OK'


# Generated at 2022-06-21 19:39:23.897622
# Unit test for constructor of class Max
def test_Max():
    assert Max(0).value == 0
    assert Max(1).value == 1
    assert Max(2).value == 2


# Generated at 2022-06-21 19:39:25.776898
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(10)) == "Sum[value=10]"
    assert str(Sum(10)) == str(Sum(10))


# Generated at 2022-06-21 19:39:27.885028
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({2: 3})) == "Map[value={2: 3}]"



# Generated at 2022-06-21 19:39:28.992133
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(10)) == 'Max[value=10]'


# Generated at 2022-06-21 19:39:31.135389
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    sum = Sum(1)
    assert Semigroup(1) == sum
    assert not Semigroup(2) == sum


# Generated at 2022-06-21 19:39:32.378922
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-21 19:39:35.373993
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1
    assert Sum(1) == Sum(1)



# Generated at 2022-06-21 19:39:37.456435
# Unit test for constructor of class Semigroup
def test_Semigroup():
    with pytest.raises(TypeError):
        Semigroup('test')



# Generated at 2022-06-21 19:39:39.177638
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-21 19:39:48.744739
# Unit test for method __str__ of class Map
def test_Map___str__():
    expected = "Map[value={'a': Sum(1), 'b': Sum(2)}]"
    result = str(Map({'a': Sum(1), 'b': Sum(2)}))
    assert result == expected



# Generated at 2022-06-21 19:39:57.235612
# Unit test for method concat of class Min
def test_Min_concat():
    s1 = Min(4)
    s2 = Min(5)
    assert s1.concat(s2).value == 4
    
    s1 = Min(5)
    s2 = Min(4)
    assert s1.concat(s2).value == 4
    
    s1 = Min(-float("inf"))
    s2 = Min(5)
    assert s1.concat(s2).value == -float("inf")
    
    s1 = Min(5)
    s2 = Min(-float("inf"))
    assert s1.concat(s2).value == -float("inf")
# Run the tests
test_Min_concat()



# Generated at 2022-06-21 19:40:00.544787
# Unit test for method concat of class Min
def test_Min_concat():
    """
    Unit test for method concat of class Min
    """
    assert Min(2).concat(Min(1)).value == 1
    assert Min(1).concat(Min(2)).value == 1



# Generated at 2022-06-21 19:40:02.933997
# Unit test for method __str__ of class One
def test_One___str__():
    """Test for method __str__ of class One."""
    assert str(One(1)) == 'One[value=1]'



# Generated at 2022-06-21 19:40:07.503310
# Unit test for method concat of class All
def test_All_concat():
    s = All(True).concat(All(True))
    assert s.value == True

    s = All(True).concat(All(False))
    assert s.value == False

    s = All(False).concat(All(True))
    assert s.value == False

    s = All(False).concat(All(False))
    assert s.value == False


# Generated at 2022-06-21 19:40:11.649049
# Unit test for method concat of class First
def test_First_concat():
    assert First('a').concat(First('b')).value == 'a'



# Generated at 2022-06-21 19:40:15.162547
# Unit test for method concat of class Max
def test_Max_concat():
    """
    Test method concat of the class Max
    """
    a = Max(1)
    b = Max(2)
    assert a.concat(b) == Max(2)


# Generated at 2022-06-21 19:40:16.227067
# Unit test for constructor of class Semigroup
def test_Semigroup():
    _ = Semigroup
    assert _(1) == Semigroup(1)


# Generated at 2022-06-21 19:40:18.488934
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(2) != Semigroup(1)
    assert Semigroup("a") != Semigroup("b")



# Generated at 2022-06-21 19:40:24.320006
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map(
        {
            'first': First(1),
            'last': Last(2),
            'sum': Sum(3),
            'all': All(True),
            'one': One(False),
            'min': Min(4),
            'max': Max(5),
        }
    )
    map2 = Map(
        {
            'first': First(10),
            'last': Last(20),
            'sum': Sum(30),
            'all': All(False),
            'one': One(True),
            'min': Min(40),
            'max': Max(50),
        }
    )
    map3 = map1.concat(map2)
    assert map3.value['first'] == First(1)

# Generated at 2022-06-21 19:40:34.884926
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(2)) == 'Min[value=2]'


# Generated at 2022-06-21 19:40:36.476390
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'key': 1})) == 'Map[value={\'key\': 1}]'


# Generated at 2022-06-21 19:40:41.519803
# Unit test for constructor of class Map
def test_Map():
    empty_map = Map({})
    assert empty_map.value == {}
    map_with_one_value = Map({1: Sum(1)})
    assert map_with_one_value.value == {1: Sum(1)}


# Generated at 2022-06-21 19:40:43.585044
# Unit test for constructor of class Min
def test_Min():
    min_number = Min(1)
    assert min_number.value == 1


# Generated at 2022-06-21 19:40:46.263311
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First("a")) == 'Fist[value=a]'



# Generated at 2022-06-21 19:40:47.825746
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert Sum(1).__str__() == 'Sum[value=1]'


# Generated at 2022-06-21 19:40:50.489031
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Test fold
    """
    sum = Sum(1).concat(Sum(2))
    assert sum.fold(lambda v: v) == 3


# Unit test class Sum

# Generated at 2022-06-21 19:40:54.939805
# Unit test for constructor of class Last
def test_Last():
    assert Last(None).value is None
    assert Last(1).value == 1
    assert Last('a').value == 'a'
    assert Last({'a': 1}).value == {'a': 1}
    assert isinstance(Last(None), Last)
    assert isinstance(Last(1), Last)
    assert isinstance(Last('a'), Last)
    assert isinstance(Last({'a': 1}), Last)



# Generated at 2022-06-21 19:41:00.035043
# Unit test for constructor of class Map
def test_Map():
  assert Map({"a": Sum(1), "b": Sum(2)}) == Map({"a": Sum(1), "b": Sum(2)})
  assert Map({"a": Sum(1), "b": Sum(2)}) is not Map({"a": Sum(1), "b": Sum(2)})


# Generated at 2022-06-21 19:41:05.063272
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(10).fold(lambda x: x) == 10
    assert All(True).fold(lambda x: x) == True
    assert All(False).fold(lambda x: x) == False
    assert First([1, 2, 3]).fold(lambda x: x[-1]) == 3
    assert Last([1, 2, 3]).fold(lambda x: x[0]) == 1



# Generated at 2022-06-21 19:41:13.802666
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-21 19:41:21.734041
# Unit test for method concat of class Map
def test_Map_concat():
    """
    :returns: True if all assertions passed, else raises AssertionError exception
    :rtype: bool
    """
    assert Map({"x": Last(1), "y": Last(2)}).concat(
        Map({"x": Last(3), "y": Last(4)})).value == {"x": Last(3), "y": Last(4)}
    assert Map({"x": Last(1), "y": Last(2)}).concat(
        Map({"x": Last(3), "y": Last(4)})).value != {"x": First(1), "y": First(2)}
    return True



# Generated at 2022-06-21 19:41:26.539073
# Unit test for constructor of class Map
def test_Map():
    map = Map({1: First(1), 2: Last("papa")})
    assert map.value == {1: First(1), 2: Last("papa")}
    assert map.concat(map).value == {1: First(1), 2: Last("papa")}


# Generated at 2022-06-21 19:41:27.910799
# Unit test for constructor of class First
def test_First():
    f = First(1)
    assert f.value == 1


# Generated at 2022-06-21 19:41:29.214360
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == "Fist[value=1]"


# Generated at 2022-06-21 19:41:31.763243
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) is 'All[value=True]'
    assert str(All(1)) is 'All[value=1]'
    assert str(All("")) is 'All[value=]'


# Generated at 2022-06-21 19:41:35.902176
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)



# Generated at 2022-06-21 19:41:37.897974
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'



# Generated at 2022-06-21 19:41:44.952035
# Unit test for method concat of class One
def test_One_concat():  # pragma: no cover
    assert str(One(5).concat(One('a'))), 'One[value=5]'
    assert str(One(1).concat(One(True))), 'One[value=True]'
    assert str(One(True).concat(One(None))), 'One[value=None]'
    assert str(One(1).concat(One(0.5))), 'One[value=1]'
    assert str(One('Text').concat(One('Text2'))), 'One[value=Text]'
    assert str(One([]).concat(One([1, 2]))), 'One[value=[1, 2]]'
    assert str(One({}).concat(One({'key': 'string'}))), 'One[value={\'key\': \'string\'}]'

# Generated at 2022-06-21 19:41:46.201955
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1


# Generated at 2022-06-21 19:41:55.956936
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    """
    Test case to verify that str method of First works correctly
    """
    assert str(First(5)) == "Fist[value=5]"


# Generated at 2022-06-21 19:41:57.710351
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(10) == Sum(10)
    assert not Sum(10) == Sum(11)
    assert not Sum(10) == All(True)



# Generated at 2022-06-21 19:41:59.502066
# Unit test for method __str__ of class Min
def test_Min___str__():
    min = Min(23)
    assert str(min) == "Min[value=23]"


# Generated at 2022-06-21 19:42:03.096079
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(10).concat(Max(5)).value == 10
    assert Max(5).concat(Max(10)).value == 10
    assert Max(10).concat(Max(10)).value == 10
    assert Max(10).concat(Max(-10)).value == 10


# Generated at 2022-06-21 19:42:07.211198
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-21 19:42:09.008758
# Unit test for constructor of class First
def test_First():
    value = "test"
    semigroup = First(value)
    assert semigroup.value == value


# Generated at 2022-06-21 19:42:12.149458
# Unit test for constructor of class Max
def test_Max():  # pragma: no cover
    assert Max(1).value == 1
    assert Max(2).value == 2
    assert Max(-1).value == -1
    assert Max(-2).value == -2


# Generated at 2022-06-21 19:42:13.428826
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-21 19:42:15.695712
# Unit test for method __str__ of class All
def test_All___str__():
    """
    Test for method __str__ of class All
    """
    assert(str(All(True)) == "All[value=True]")
    assert(str(All(False)) == "All[value=False]")



# Generated at 2022-06-21 19:42:16.868878
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)


# Generated at 2022-06-21 19:42:26.432614
# Unit test for constructor of class Max
def test_Max():
    assert Max(2) == Max(2)



# Generated at 2022-06-21 19:42:29.271457
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    # when
    actual = Semigroup(5) == Semigroup(5)
    expected = True

    # then
    assert actual == expected


test_Semigroup___eq__()



# Generated at 2022-06-21 19:42:32.587879
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-21 19:42:34.053775
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-21 19:42:37.867055
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(10).fold(lambda v: v + 10) == 20
    assert Semigroup('asdf').fold(lambda v: '{}{}'.format(v, v)) == 'asdfasdf'
    assert Semigroup({'a': 1, 'b': 2}).fold(lambda v: v.get('a')) == 1

# Generated at 2022-06-21 19:42:40.202259
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Test unit for fold method of class Semigroup
    :return:
    """
    assert Sum(1).fold(lambda x: x + 1) == 2



# Generated at 2022-06-21 19:42:51.014911
# Unit test for method concat of class Map
def test_Map_concat():
    assert_that(Map({'a': First(1), 'b': Min(2)}).concat(Map({'a': First(1), 'b': Min(3)})), equal_to(Map({'a': First(1), 'b': Min(2)})))
    assert_that(Map({'a': First(1), 'b': Min(2)}).concat(Map({'a': First(1), 'b': Min(1)})), equal_to(Map({'a': First(1), 'b': Min(1)})))
    assert_that(Map({'a': First(1), 'b': Min(1)}).concat(Map({'a': First(1), 'b': Min(2)})), equal_to(Map({'a': First(1), 'b': Min(1)})))

# Unit test

# Generated at 2022-06-21 19:42:54.780853
# Unit test for method concat of class Min
def test_Min_concat():
    instance_1 = Min(1)
    instance_2 = Min(2)
    actual = instance_1.concat(instance_2).value
    expected = 1
    assert actual == expected


# Generated at 2022-06-21 19:42:57.397555
# Unit test for method concat of class First
def test_First_concat():
    first = First(1)
    semigroup = First(2)
    result = first.concat(semigroup)
    assert result == First(1)


# Generated at 2022-06-21 19:42:59.325496
# Unit test for method __str__ of class Last
def test_Last___str__():
    result = str(Last(5))
    expected = 'Last[value=5]'
    assert result == expected


# Generated at 2022-06-21 19:43:17.029124
# Unit test for constructor of class Map
def test_Map():
    m1 = Map({'a': Sum(1), 'b': Sum(2)})
    m2 = Map({'a': Sum(2), 'b': Sum(1)})
    assert m1 == Map({'a': Sum(1), 'b': Sum(2)})
    assert m1.concat(m2) == Map({'a': Sum(3), 'b': Sum(3)})
    assert m2.concat(m2) == Map({'a': Sum(4), 'b': Sum(2)})
    assert m1.concat(m1) == Map({'a': Sum(2), 'b': Sum(4)})
    assert m2.concat(m1) == Map({'a': Sum(3), 'b': Sum(3)})


# Generated at 2022-06-21 19:43:19.877059
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(2).concat(Last(3)).value == 3
    assert Last(3).concat(Last(2)).value == 2


# Generated at 2022-06-21 19:43:22.374721
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    # Given
    first = All(True)
    second = All(True)
    # When
    result = first.concat(second)
    # Then
    assert result == All(True)



# Generated at 2022-06-21 19:43:32.897730
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True
    assert One(1).value == True
    assert One(False).value == False
    assert One(0).value == False
    assert One(None).value == False
    assert One('').value == False
    assert not One('').value
    assert One('1').value == True
    assert One('0').value == True
    assert One('-1').value == True
    assert One('True').value == True
    assert One('False').value == True
    assert One('None').value == True
    assert One('Satan').value == True


# Generated at 2022-06-21 19:43:35.484766
# Unit test for constructor of class One
def test_One():
    assert One(True).value == True
    assert One(False).value == False
    assert One(10).value == One(20).value
    assert One('').value == True



# Generated at 2022-06-21 19:43:37.030821
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)


# Generated at 2022-06-21 19:43:41.452763
# Unit test for constructor of class All
def test_All():
    a = All(True)
    assert a.value == True
    assert a.concat(All(True)).value == True
    assert a.concat(All(False)).value == False
    assert a.concat(All(None)).value == False
    assert a.concat(All(0)).value == False
    a1 = All(False)
    assert a.concat(a1).value == False
    a2 = a.concat(a1)
    assert a2.value == False
    assert a2.concat(a1).value == False
    a3 = All(None)
    assert a3.value == False
    assert a3.concat(a1).value == False


# Generated at 2022-06-21 19:43:42.962071
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1
    assert First(2).value == 2


# Generated at 2022-06-21 19:43:48.671335
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last("A").concat(Last("B")) == Last("B")
    assert Last("A").concat(Last("B")).value == "B"
    assert Last("A").concat(Last("B")).concat(Last("C")) == Last("C")



# Generated at 2022-06-21 19:43:51.399409
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(3).concat(Min(5)).value == 3
    assert Min(5).concat(Min(3)).value == 3



# Generated at 2022-06-21 19:44:08.596996
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-21 19:44:11.376397
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert Sum(1) != First(1)



# Generated at 2022-06-21 19:44:14.017098
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert All(True) != All(False)



# Generated at 2022-06-21 19:44:17.701638
# Unit test for method concat of class One
def test_One_concat():
    assert One("asdf").concat(One("qwerty")) == One("qwerty")
    assert One("asdf").concat(One(123)) == One("asdf")
    assert One("asdf").concat(One("")) == One("asdf")

