

# Generated at 2022-06-21 19:34:23.392851
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(8)) == 'Max[value=8]'


# Generated at 2022-06-21 19:34:29.151038
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum.neutral() == Sum(Sum.neutral_element)
    assert Sum(2).concat(Sum(2)) == Sum(4)
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(2).concat(Sum(1)) == Sum(3)



# Generated at 2022-06-21 19:34:31.699388
# Unit test for method concat of class One
def test_One_concat():
    f = One(True)
    g = One(False)
    assert f.concat(g).value



# Generated at 2022-06-21 19:34:34.490021
# Unit test for method concat of class Min
def test_Min_concat():
    min1 = Min(6)
    min2 = Min(1)
    assert min1.concat(min2).value == min2.value



# Generated at 2022-06-21 19:34:37.742147
# Unit test for constructor of class Last
def test_Last():  # pragma: no cover
    assert Last(1) == Last(1)


# Generated at 2022-06-21 19:34:41.327902
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(1) != Max(2)
    assert Max(1).value == 1



# Generated at 2022-06-21 19:34:48.078795
# Unit test for method concat of class All
def test_All_concat():
    a = All(True)
    b = All(True)
    assert a.concat(b) == All(True)
    a = All(False)
    b = All(True)
    assert a.concat(b) == All(False)
    a = All(True)
    b = All(False)
    assert a.concat(b) == All(False)
    a = All(False)
    b = All(False)
    assert a.concat(b) == All(False)


# Generated at 2022-06-21 19:34:52.155463
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda n: n + 1) == 2
    assert Max(1).fold(lambda n: n + 1) == 2
    assert Min(2).fold(lambda n: n + 1) == 3


# Generated at 2022-06-21 19:34:55.037014
# Unit test for method concat of class Sum
def test_Sum_concat():  # pragma: no cover
    print('- test method concat of class Sum')
    assert Sum(1).concat(Sum(2)).fold(lambda x: x) == 3


# Generated at 2022-06-21 19:35:00.441596
# Unit test for constructor of class Last
def test_Last():
    l = Last("foo")
    assert l.value == "foo"



# Generated at 2022-06-21 19:35:05.862701
# Unit test for method __str__ of class Map
def test_Map___str__():  # pragma: no cover
    assert str(Map({"a": First(1)})) == "Map[value={'a': Fist[value=1]}]"



# Generated at 2022-06-21 19:35:08.470159
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-21 19:35:09.579679
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(10) == Sum(10)
    assert Sum(5) != Sum(10)


# Generated at 2022-06-21 19:35:11.414668
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup.fold(Sum(5), lambda x: x + 3) == 8


# Generated at 2022-06-21 19:35:14.304013
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    # arrange
    semigroup = Max(1)

    # act
    result = semigroup.fold(lambda x: x * 2)

    # assert
    assert result == 2



# Generated at 2022-06-21 19:35:15.537914
# Unit test for constructor of class Last
def test_Last():
    l = Last(value=1)
    assert l.value == 1



# Generated at 2022-06-21 19:35:16.723252
# Unit test for constructor of class Max
def test_Max():
    assert Max(3) == Max(3)



# Generated at 2022-06-21 19:35:20.079634
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    semigroup_a = Sum(5)
    semigroup_b = Sum(5)
    semigroup_c = Sum(6)

    assert semigroup_a == semigroup_b
    assert semigroup_a != semigroup_c



# Generated at 2022-06-21 19:35:22.628128
# Unit test for method __str__ of class Min
def test_Min___str__():
    """
    Unit test for method __str__ of class Min
    """

    value = 0

    semigroup = Min(value)

    assert str(semigroup) == "Min[value=0]"


# Generated at 2022-06-21 19:35:24.063569
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-21 19:35:31.638225
# Unit test for method concat of class All
def test_All_concat():
    """
    :returns: True if test passes and False otherwise
    :rtype: bool
    """
    assert All(True).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)



# Generated at 2022-06-21 19:35:37.368790
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    assert All(True).concat(All(True)).value
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
    assert All(False).concat(All(False)).value == False


# Generated at 2022-06-21 19:35:40.980312
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(4).concat(Min(10)) == Min(4)
    assert Min(4).concat(Min(-20)) == Min(-20)
    assert Min(-20).concat(Min(10)) == Min(-20)

# Generated at 2022-06-21 19:35:44.247168
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    # GIVEN
    expected = 'Last[value=2]'
    last_instance = Last(2)

    # WHEN
    result = str(last_instance)

    # THEN
    assert expected == result


# Generated at 2022-06-21 19:35:46.215855
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: Sum(1)})) == "Map[value={1: Sum[value=1]}]"  # pragma: no cover

# Generated at 2022-06-21 19:35:56.853707
# Unit test for constructor of class Sum
def test_Sum():
    a = Sum(12)
    assert isinstance(a, Sum)
    assert a.value == 12
    assert Sum(0).value == 0
    assert Sum(-1).value == -1
    assert Sum(1.0).value == 1
    assert Sum(1.2).value == 1.2
    assert Sum(None).value == 0
    assert Sum(False).value == 0
    assert Sum(True).value == 1
    assert Sum('').value == 0
    assert Sum('123').value == 123
    assert Sum('123.4').value == 123
    assert Sum('-123.4').value == -123
    assert Sum([1]).value == 0


# Generated at 2022-06-21 19:35:59.337823
# Unit test for constructor of class Last
def test_Last():
    """
    Unit test for constructor of class Last
    """

    x = Last(5)
    assert x.value == 5


# Generated at 2022-06-21 19:36:03.627773
# Unit test for method concat of class Sum
def test_Sum_concat():
    a = Sum(3)
    b = Sum(4)

    assert (isinstance(a, object) and
            hasattr(a, 'concat') and
            hasattr(a, '__str__'))

    assert (
        a.concat(b) == Sum(7)
    )

# Generated at 2022-06-21 19:36:07.374793
# Unit test for method concat of class First
def test_First_concat():
    # GIVEN
    semigroup = First('a')
    another_semigroup = First('b')
    # WHEN
    result = First.concat(semigroup, another_semigroup)
    # THEN
    assert(First('a') == result)


# Generated at 2022-06-21 19:36:10.932535
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-21 19:36:18.153405
# Unit test for method __str__ of class Min
def test_Min___str__():
    """
    Should be 'Min[value=0]'
    """
    value = Min(0)
    assert str(value) == 'Min[value=0]'
    assert value.value.__class__.__name__ == 'int'


# Generated at 2022-06-21 19:36:19.732766
# Unit test for constructor of class First
def test_First():
    assert First(1), First(1)


# Generated at 2022-06-21 19:36:23.913460
# Unit test for method concat of class Map
def test_Map_concat():
    a = {
        "a": Sum(1),
        "b": Sum(2)
    }
    b = {
        "a": Sum(1),
        "b": Sum(12)
    }
    assert Map(a).concat(Map(b)).value == {
        "a": Sum(2),
        "b": Sum(14)
    }

# Generated at 2022-06-21 19:36:24.883852
# Unit test for constructor of class First
def test_First():
    first = First(1)
    assert first


# Generated at 2022-06-21 19:36:26.705796
# Unit test for constructor of class First
def test_First():
    x = First([1, 2, 3])
    assert x.value == [1, 2, 3]


# Generated at 2022-06-21 19:36:30.243093
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert isinstance(str(Sum(3)), str)
    assert str(Sum(3)) == 'Sum[value=3]'
    assert not isinstance(Sum(3), str)


# Generated at 2022-06-21 19:36:35.603241
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
    assert All(False).concat(All(False)).value == False
    assert All(True).concat(All(True)).value == True


# Generated at 2022-06-21 19:36:38.570059
# Unit test for method __str__ of class All
def test_All___str__():
    res = All(True).__str__()
    assert res == "All[value=True]", "Failed!"
    assert True, "Passed!"


# Generated at 2022-06-21 19:36:40.289548
# Unit test for method __str__ of class Min
def test_Min___str__():  # pragma: no cover
    assert str(Min(1)) == 'Min[value=1]'



# Generated at 2022-06-21 19:36:43.262288
# Unit test for constructor of class Max
def test_Max():
    """ Test for the constructor of Max, testing if the class is initialized correctly
    """
    m = Max(4)
    assert isinstance(m, Max)
    assert m.value == 4
    assert m.neutral_element == -float("inf")


# Generated at 2022-06-21 19:36:49.136402
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(False)) == 'One[value=False]'
    assert str(One(True)) == 'One[value=True]'



# Generated at 2022-06-21 19:36:52.611681
# Unit test for method concat of class Max
def test_Max_concat():
    max_1 = Max(1)
    max_2 = Max(2)

    assert max_1.concat(max_2).value == 2
    assert max_1.concat(max_1).value == 1


# Generated at 2022-06-21 19:37:02.464485
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(None)) == All(False)
    assert All(None).concat(All(True)) == All(False)
    assert All(False).concat(All(None)) == All(False)
    assert All(None).concat(All(False)) == All(False)
    assert All(None).concat(All(None)) == All(False)


# Generated at 2022-06-21 19:37:04.008760
# Unit test for constructor of class Max
def test_Max():
    assert Max(10) == Max(10)
    assert Max(2) != Max(10)


# Generated at 2022-06-21 19:37:05.505113
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(2).concat(Last(3)) == Last(3)



# Generated at 2022-06-21 19:37:07.174614
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-21 19:37:09.600675
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'



# Generated at 2022-06-21 19:37:12.289613
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    # Given
    instance = Semigroup(1)

    # When
    result = instance.fold(lambda x: x + 1)

    # Then
    assert result == 2



# Generated at 2022-06-21 19:37:14.560571
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(False)) == 'All[value=False]'
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-21 19:37:16.546809
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-21 19:37:21.714575
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(3)
    b = Min(2)
    assert a.concat(b) == Min(2)



# Generated at 2022-06-21 19:37:22.585760
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(2) == Sum(2)

# Generated at 2022-06-21 19:37:25.934741
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)).value == 2
    assert Max(1).concat(Max(1)).value == 1
    assert Max(2).concat(Max(1)).value == 2


# Generated at 2022-06-21 19:37:34.141378
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).concat(One(2)) == One(True)
    assert One(1).concat(One(None)) == One(1)
    assert One(False).concat(One(2)) == One(True)
    assert One(False).concat(One(None)) == One(False)
    assert One(False).concat(One(False)) == One(False)
    assert One(None).concat(One(2)) == One(True)
    assert One(None).concat(One(None)) == One(None)
    assert One(None).concat(One(False)) == One(False)


# Generated at 2022-06-21 19:37:44.356737
# Unit test for constructor of class Map
def test_Map():
    # Check empty map
    map_ = Map({})
    assert map_.concat(map_) == map_

    # Check simple contat of maps
    map_ = Map({1: Sum(1), 2: Sum(2)})
    map_ = map_.concat(Map({1: Sum(2)}))
    assert map_ == Map({1: Sum(3), 2: Sum(2)})

    # Check contat of map with 1 element
    map_ = map_.concat(Map({4: Sum(4)}))
    assert map_ == Map({1: Sum(3), 2: Sum(2), 4: Sum(4)})

    assert list(map_) == [Sum(3), Sum(2), Sum(4)]

# Generated at 2022-06-21 19:37:45.931525
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(5)) == 'Last[value=5]'


# Generated at 2022-06-21 19:37:47.179893
# Unit test for method __str__ of class Min
def test_Min___str__():
    pass # assert Min(3) == 'Min[value=3]'


# Generated at 2022-06-21 19:37:54.305240
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)



# Generated at 2022-06-21 19:37:56.287885
# Unit test for constructor of class Max
def test_Max():
    """
    >>> Max(1)
    Max[value=1]
    """
    pass



# Generated at 2022-06-21 19:37:58.123014
# Unit test for method __str__ of class Last
def test_Last___str__():
    last = Last(42)
    assert str(last) == 'Last[value=42]'


# Generated at 2022-06-21 19:38:04.411525
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    # Set up fixtures
    value = 'some value'
    concat_method = lambda x: x + '!1!'

    # Exercise
    result = Semigroup(value).fold(concat_method)

    # Verify
    assert result == value + '!1!'


# Generated at 2022-06-21 19:38:06.307694
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-21 19:38:13.025523
# Unit test for method concat of class Map
def test_Map_concat():
    map1 = Map({
        "a": Sum(1),
        "b": Sum(2)
    })
    map2 = Map({
        "a": Sum(3),
        "b": Sum(4)
    })
    assert map1.concat(map2) == Map({
        "a": Sum(4),
        "b": Sum(6)
    })



# Generated at 2022-06-21 19:38:15.406520
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1)})) == "Map[value={'a': Sum[value=1]}]"


# Generated at 2022-06-21 19:38:17.595728
# Unit test for constructor of class Map
def test_Map():
    x = Map({'a':Sum(1), 'b':Sum(2)})
    assert x.value == {'a':Sum(1), 'b':Sum(2)}

# Generated at 2022-06-21 19:38:20.088539
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-21 19:38:22.004939
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(5)) == "Max[value=5]"


# Generated at 2022-06-21 19:38:23.593257
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'



# Generated at 2022-06-21 19:38:25.576312
# Unit test for constructor of class Min
def test_Min():
    assert Min(1).concat(Min(2)) == Min(1)


# Generated at 2022-06-21 19:38:28.005593
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)


# Generated at 2022-06-21 19:38:35.794744
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum = Sum(1)
    assert str(sum) == 'Sum[value=1]'


# Generated at 2022-06-21 19:38:40.151866
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    from datatest import validate

    data = [
        (All(True), 'All[value=True]'),
        (All(False), 'All[value=False]'),
    ]

    @validate(data)
    def _(i, o):
        return str(i)


# Generated at 2022-06-21 19:38:45.348816
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(3)) == Max(5)
    assert Max(7).concat(Max(9)) == Max(9)
    assert Max(0).concat(Max(2)) == Max(2)
    assert Max(9).concat(Max(0)) == Max(9)


# Generated at 2022-06-21 19:38:46.813209
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert not (Sum(1) == Sum(2))



# Generated at 2022-06-21 19:38:48.154417
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(12).value == Sum(12).value



# Generated at 2022-06-21 19:38:50.541630
# Unit test for constructor of class Max
def test_Max():
    """
    constructor of class Max
    """
    value = 5
    result = Max(value)
    assert result.value == value


# Generated at 2022-06-21 19:38:51.764666
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(True)) == "Fist[value=True]"


# Generated at 2022-06-21 19:38:53.350269
# Unit test for method __str__ of class Last
def test_Last___str__(): 
   assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-21 19:38:55.651675
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False

# Generated at 2022-06-21 19:38:56.761660
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(5)) == 'Last[value=5]'



# Generated at 2022-06-21 19:39:09.329249
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First('a')) == 'Fist[value=a]'


# Generated at 2022-06-21 19:39:11.417152
# Unit test for constructor of class Sum
def test_Sum():
    """
    Ensure Sum class was initialized correct
    """
    sum_one = Sum(1)
    assert sum_one.value == 1



# Generated at 2022-06-21 19:39:13.112416
# Unit test for constructor of class Map
def test_Map():
    instance = Map({'key': 'value'})
    assert isinstance(instance, Map)
    assert instance.value == {'key': 'value'}


# Generated at 2022-06-21 19:39:14.315057
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(3).concat(Max(2)).value == 3



# Generated at 2022-06-21 19:39:15.252669
# Unit test for constructor of class Last
def test_Last():
    assert Last(value=16).value == 16


# Generated at 2022-06-21 19:39:16.334992
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)


# Generated at 2022-06-21 19:39:19.594382
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not (Semigroup(1) == Semigroup(2))
    assert not (Semigroup(1) == Semigroup(True))



# Generated at 2022-06-21 19:39:21.709093
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert Max(1).__str__() == 'Max[value=1]'


# Generated at 2022-06-21 19:39:28.463547
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max("a")) == Max("a")
    assert Max("a").concat(Max("b")) == Max("b")
    assert Max("a").concat(Max("b")) == Max("b")
    assert Max("a").concat(Max("b")) == Max("b")

# Generated at 2022-06-21 19:39:31.673857
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(-Infinity)) == 'Min[value=-∞]'
    assert str(Min(Infinity)) == 'Min[value=∞]'
    assert str(Min(E)) == 'Min[value=e]'


# Generated at 2022-06-21 19:40:03.628422
# Unit test for method __str__ of class One
def test_One___str__():
    one_instance_one = One(1)
    one_instance_two = One(2)
    one_instance_three = One(3)
    one_instance_true = One(True)
    one_instance_false = One(False)

    assert one_instance_one.__str__() == 'One[value=1]'
    assert one_instance_two.__str__() == 'One[value=2]'
    assert one_instance_three.__str__() == 'One[value=3]'
    assert one_instance_true.__str__() == 'One[value=True]'
    assert one_instance_false.__str__() == 'One[value=False]'



# Generated at 2022-06-21 19:40:07.473170
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-21 19:40:11.647935
# Unit test for constructor of class First
def test_First():
    x = First(5)
    y = First(6)
    assert (x.concat(y)).value == 5

# Generated at 2022-06-21 19:40:13.938915
# Unit test for constructor of class One
def test_One():
    # when
    res = One(True)

    # then
    assert(res.value == True)

# Generated at 2022-06-21 19:40:15.404056
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-21 19:40:16.649968
# Unit test for constructor of class First
def test_First():
    first = First(1)
    assert first.value == 1



# Generated at 2022-06-21 19:40:20.115758
# Unit test for constructor of class Map
def test_Map():
    map_value = Map({'a': Sum(1), 'b': Sum(2)})
    assert map_value.value == {'a': Sum(1), 'b': Sum(2)}

test_Map()


# Generated at 2022-06-21 19:40:21.140341
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == "First[value=1]"


# Generated at 2022-06-21 19:40:25.549247
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(2).concat(Max(3)) == Max(3)
    assert Max(3).concat(Max(2)) == Max(3)
    assert Max(3).concat(Max(3)) == Max(3)
    assert Max(-1).concat(Max(2)) == Max(2)


# Generated at 2022-06-21 19:40:28.489885
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: Sum(1), 2: Sum(2)})) == 'Map[value={1: Sum[value=1], 2: Sum[value=2]}]'


# Generated at 2022-06-21 19:41:27.948389
# Unit test for method concat of class All
def test_All_concat():
    """
    :returns: Test result True or False
    :rtype: bool
    """

    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(True).concat(All(True)) == All(True)


# Generated at 2022-06-21 19:41:29.584487
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(2).concat(Last(3)) == Last(3)


# Generated at 2022-06-21 19:41:30.779772
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(10)) == 'Min[value=10]'



# Generated at 2022-06-21 19:41:32.008453
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)).value == 2


# Generated at 2022-06-21 19:41:34.664487
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    Test case for Semigroup constructor
    """
    assert Sum(1).value == 1



# Generated at 2022-06-21 19:41:36.049883
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
test_One()


# Generated at 2022-06-21 19:41:37.688166
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(5).concat(Min(2)) == Min(2)


# Generated at 2022-06-21 19:41:40.133903
# Unit test for constructor of class Max
def test_Max():
    """
    Test constructor of class Max
    """
    max_1 = Max(1)
    max_2 = Max(2)
    assert max_1.value < max_2.value



# Generated at 2022-06-21 19:41:43.390612
# Unit test for method concat of class One
def test_One_concat():
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(False)) == One(True)
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-21 19:41:45.927145
# Unit test for method __str__ of class One
def test_One___str__():
    assert 'One[value=False]' == str(One(False))

# Generated at 2022-06-21 19:43:53.425956
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)).value == True
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(False)).value == False
    assert One(False).concat(One(True)).value == True
    assert One(True).concat(One(None)).value == True
    assert One(None).concat(One(None)).value == None
    assert One(False).concat(One(None)).value == False
    assert One(None).concat(One(True)).value == True

# Generated at 2022-06-21 19:43:59.145443
# Unit test for constructor of class Max
def test_Max(): # pragma: no cover
    assert Max(20) == Max(20)
    assert Max(20).value == 20
    assert Max(20).concat(Max(22)).value == 22
    assert Max(20).concat(Max(22)).value == Max(Max(22).value).value



# Generated at 2022-06-21 19:44:01.395253
# Unit test for constructor of class Max
def test_Max():  
    assert Max(5)==Max(5)
    


# Generated at 2022-06-21 19:44:12.530097
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(7).fold(lambda x: x) == 7
    assert Semigroup(7).fold(lambda x: x + 3) == 10
    assert Semigroup(True).fold(lambda x: x) == True
    assert Semigroup(True).fold(lambda x: x or False) == True
    assert Semigroup(['foo', 'bar']).fold(lambda x: x) == ['foo', 'bar']
    assert Semigroup(['foo', 'bar']).fold(lambda x: x + ['baz']) == ['foo', 'bar', 'baz']
    assert Semigroup({'foo': 3}).fold(lambda x: x) == {'foo': 3}
    assert Semigroup({'foo': 3}).fold(lambda x: {'bar': 7}) == {'bar': 7}
    assert Semigroup(7).fold

# Generated at 2022-06-21 19:44:15.582931
# Unit test for method __str__ of class Map
def test_Map___str__():
    # Assert
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == "Map[value={'a': Sum[value=1], 'b': Sum[value=2]}]"

