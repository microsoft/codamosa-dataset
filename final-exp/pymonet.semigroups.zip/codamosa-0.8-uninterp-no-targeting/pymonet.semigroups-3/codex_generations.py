

# Generated at 2022-06-21 19:34:21.072895
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == "Min[value=1]"

# Generated at 2022-06-21 19:34:24.641917
# Unit test for constructor of class Last
def test_Last():
    last_1 = Last(1)
    last_2 = Last(2)
    last_3 = last_1.concat(last_2)
    assert last_3.value == 2, "Error in test_Last"


# Generated at 2022-06-21 19:34:33.010108
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({
        'a': Sum(3),
        'b': First('b'),
        'c': All(True),
    }).concat(Map({
        'a': Sum(1),
        'b': First('c'),
        'c': All(False),
        'd': Last(3),
    })) == Map({
        'a': Sum(4),
        'b': First('b'),
        'c': All(False),
        'd': Last(3),
    })

# Generated at 2022-06-21 19:34:35.005707
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(7) == Sum(7)
    assert Sum(7) != Sum(8)


# Generated at 2022-06-21 19:34:37.386400
# Unit test for method concat of class Last
def test_Last_concat():
    """
    If we use this methods for all class Monoid, then we have 100% coverage
    """
    assert (Last(1).concat(Last(2))
            == Last(2))



# Generated at 2022-06-21 19:34:38.783467
# Unit test for method __str__ of class Max
def test_Max___str__():
    return str(Max(123)) == 'Max[value=123]'


# Generated at 2022-06-21 19:34:48.951583
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    semigroup1 = Sum(1)
    semigroup2 = Sum(1)
    semigroup3 = Sum(2)
    assert semigroup1 == semigroup2
    assert semigroup1 != semigroup3
    semigroup1 = All(True)
    semigroup2 = All(True)
    semigroup3 = All(False)
    assert semigroup1 == semigroup2
    assert semigroup1 != semigroup3
    semigroup1 = One(False)
    semigroup2 = One(False)
    semigroup3 = One(True)
    assert semigroup1 == semigroup2
    assert semigroup1 != semigroup3
    semigroup1 = First(1)
    semigroup2 = First(1)
    semigroup3 = First(2)
    assert semigroup1 == semigroup2
    assert semigroup1 != semigroup3

# Generated at 2022-06-21 19:34:51.969796
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1
    assert Last(1).fold(lambda x: x) == 1
    assert Last(2).concat(Last(1)).value == 1



# Generated at 2022-06-21 19:34:53.402176
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(5) != Semigroup(5)


# Generated at 2022-06-21 19:34:55.436895
# Unit test for constructor of class First
def test_First():
    """
    :returns: First object for test
    :rtype: First
    """
    return First(7)


# Generated at 2022-06-21 19:35:04.050021
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    semigroup = Semigroup(0)
    assert semigroup.value == 0, 'Semigroup.value should equals to 0'
    semigroup = Semigroup([])
    assert type(semigroup.value) == list, 'Semigroup.value should equals to []'


# Generated at 2022-06-21 19:35:11.667731
# Unit test for method concat of class Map
def test_Map_concat():
    map_1 = Map({'a': First(1), 'b': First(2), 'c': First(3)})
    map_2 = Map({'a': First(4), 'b': First(5), 'c': First(6)})
    map_3 = map_1.concat(map_2)
    assert Map({'a': First(1), 'b': First(2), 'c': First(3), 'd': First(7)}) == Map({'a': First(1), 'b': First(2), 'c': First(3), 'd': First(7)})

# Generated at 2022-06-21 19:35:17.143823
# Unit test for method concat of class Last
def test_Last_concat():
    print(Last(1).concat(Last(2))) # Last[value=2]
    print(Last('a').concat(Last('b'))) # Last[value=b]
    print(Last(1).concat(Last(2)).concat(Last(3))) # Last[value=3]
    print(Last('a').concat(Last('b')).concat(Last('c'))) # Last[value=c]

test_Last_concat()


# Generated at 2022-06-21 19:35:23.541954
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    Unit test for constructor of class Semigroup
    Tests:
        * create instance of Sum: value type should be of type Sum
        * create instance of Sum: value should be equal to passed value
        * create instance of Sum: value should be equal to another Sum instance with same value
    """

    # create instance of Sum: value type should be of type Sum
    assert isinstance(Sum(1), Sum)

    # create instance of Sum: value should be equal to passed value
    assert Sum(1).value == 1

    # create instance of Sum: value should be equal to another Sum instance with same value
    assert Sum(1) == Sum(1)
    

# Generated at 2022-06-21 19:35:27.844583
# Unit test for constructor of class Min
def test_Min():
    assert Min(2) == Min(2)
    assert Min(2).value == 2


# Generated at 2022-06-21 19:35:30.692771
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert True == Semigroup(3) == Semigroup(3)
    assert False == Semigroup(3) == Semigroup(2)



# Generated at 2022-06-21 19:35:32.655730
# Unit test for method __str__ of class Min
def test_Min___str__():  # pragma: no cover
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-21 19:35:34.644063
# Unit test for constructor of class Max
def test_Max():
    return (
        Max(5) is Max(5),
        Max(5) == Max(5)
    )


# Generated at 2022-06-21 19:35:37.265453
# Unit test for method concat of class First
def test_First_concat():
    x = First(3)
    y = First(5)
    assert x.concat(y) == First(3)


# Generated at 2022-06-21 19:35:46.660925
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    def add(a, b):
        return a + b

    def square(x):
        return x * x

    def double(x):
        return x * 2

    def fn(x):
        return x
    test_semigroup = Semigroup(5)
    assert test_semigroup.fold(fn) == fn(5)
    assert test_semigroup.fold(square) == square(5)
    assert test_semigroup.fold(double) == double(5)
    assert test_semigroup.fold(add) == add(5, 5)
    assert test_semigroup.fold(lambda x: x + 3) == (lambda x: x + 3)(5)
    assert test_semigroup.fold(lambda x: x * x) == (lambda x: x * x)(5)

# Generated at 2022-06-21 19:35:56.163875
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    >>> test_Semigroup_fold()
    >>>

    """

    def add(a: int, b: int) -> int:
        return a + b

    assert Sum(42).fold(add) == 42



# Generated at 2022-06-21 19:35:56.995848
# Unit test for constructor of class Sum
def test_Sum():
    sum = Sum(3)
    assert sum.value == 3



# Generated at 2022-06-21 19:36:00.858810
# Unit test for method concat of class Min
def test_Min_concat():
    min_a = Min(10)
    min_b = Min(7)

    min_a_concat = min_a.concat(min_b)
    assert isinstance(min_a_concat, Min)
    assert min_a_concat.value == 7



# Generated at 2022-06-21 19:36:02.117521
# Unit test for method __str__ of class First
def test_First___str__():
    a = First('a')
    assert str(a) == 'First[value=a]'


# Unit tests for method concat of class First

# Generated at 2022-06-21 19:36:03.265493
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    res = Semigroup(1).fold(lambda x: x)
    assert res == 1



# Generated at 2022-06-21 19:36:04.659882
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-21 19:36:12.685460
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(10) == Sum(10)
    assert All(1) == All(1)
    assert First(1) == First(1)
    assert Last(1) == Last(1)
    assert Map({1: Max(1)}) == Map({1: Max(1)})
    assert Min(1) == Min(1)
    assert Max(1) == Max(1)
    assert Last(1) == Last(1)
    assert Sum(10) != Sum(11)
    assert All(1) != All(2)
    assert First(1) != First(2)
    assert Last(1) != Last(2)
    assert Map({1: Max(1)}) != Map({1: Max(2)})
    assert Min(1) != Min(2)
    assert Max(1) != Max(2)

# Generated at 2022-06-21 19:36:18.631393
# Unit test for constructor of class Map
def test_Map():
    map1 = Map({'a': Sum(2), 'b': One(True), 'c': Max(2)})
    map2 = Map({'a': Sum(4), 'b': One(False), 'c': Max(4)})
    actual = map1.concat(map2)
    expected = Map({'a': Sum(6), 'b': One(True), 'c': Max(4)})
    assert actual == expected


# Generated at 2022-06-21 19:36:22.650398
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)).value == 2
    assert Last(1).concat(Last(0)).value == 0
    assert Last(1).concat(Last(None)).value is None
    assert Last(None).concat(Last(0)).value == 0


# Generated at 2022-06-21 19:36:28.991959
# Unit test for method concat of class First
def test_First_concat():
    assert First('a').concat(First('b')).concat(First('c')).value == 'a'
    assert First('a').concat(Last('b')).concat(First('c')).value == 'a'
    assert First('a').concat(First('b')).concat(Last('c')).value == 'a'


# Generated at 2022-06-21 19:36:35.319224
# Unit test for method concat of class First
def test_First_concat():
    assert First('a').concat(First('b')).concat(First('c')).value == 'a'



# Generated at 2022-06-21 19:36:37.143923
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-21 19:36:45.354494
# Unit test for method concat of class All
def test_All_concat():
    print("Test method concat in the class All")
    print("All(1).concat(All(0)) = ", All(1).concat(All(0)))
    print("All(1).concat(All(2)) = ", All(1).concat(All(2)))
    print("All(5).concat(All(0)) = ", All(5).concat(All(0)))
    print("All(5).concat(All(2)) = ", All(5).concat(All(2)))
    print("All(5).concat(All(4)) = ", All(5).concat(All(4)))
    print("All(0).concat(All(0)) = ", All(0).concat(All(0)))

# Generated at 2022-06-21 19:36:46.149677
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == "One[value=True]"


# Generated at 2022-06-21 19:36:48.104498
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False



# Generated at 2022-06-21 19:36:50.451177
# Unit test for method concat of class Last
def test_Last_concat():
    last = Last(10)
    last = last.concat(Last(11))
    assert last.value == 11



# Generated at 2022-06-21 19:36:52.612493
# Unit test for method concat of class Min
def test_Min_concat():
    one = Min(1)
    two = Min(2)
    result = one.concat(two)
    assert result.value == 1


# Generated at 2022-06-21 19:36:54.409341
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(3)) == Max(5)


# Generated at 2022-06-21 19:36:56.291002
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)


# Generated at 2022-06-21 19:37:01.470866
# Unit test for method concat of class Map
def test_Map_concat():
    a = Map({"foo": Sum(1), "bar": Sum(2)})
    b = Map({"foo": Sum(3), "bar": Sum(4)})
    c = Map({"foo": Sum(4), "bar": Sum(6)})
    assert a.concat(b) == c


# Generated at 2022-06-21 19:37:07.280262
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum1 = Sum(1)
    sum2 = Sum(2)

    assert sum1.concat(sum2) == Sum(3)


# Generated at 2022-06-21 19:37:14.192271
# Unit test for method concat of class First
def test_First_concat():
    assert First(10).concat(First("abc")).concat(First(20)) == First(10)
    assert First(False).concat(First("xyz")).concat(First([1, 2, 3])) == First(False)
    assert First(10).concat(First("xyz")).concat(First({'a':'x', 'b':'y'})) == First(10)



# Generated at 2022-06-21 19:37:16.597518
# Unit test for method concat of class Last
def test_Last_concat():
    a = Last(1)
    b = Last(2)
    assert(str(a.concat(b)) == "Last[value={}]".format(2))

# Generated at 2022-06-21 19:37:18.310624
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
  assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-21 19:37:22.337520
# Unit test for method concat of class Map
def test_Map_concat():
    map_a = Map({'a': Min(2), 'b': Max(3)})
    map_b = Map({'a': Min(4), 'b': Max(5)})
    assert {'a': Min(2), 'b': Max(5)} == map_a.concat(map_b).value

# Generated at 2022-06-21 19:37:26.661350
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-21 19:37:28.701650
# Unit test for method __str__ of class First
def test_First___str__():
    foo = First(10)
    assert foo.__str__() == "Fist[value=10]"


# Generated at 2022-06-21 19:37:30.561730
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(10)) == 'Sum[value=10]'



# Generated at 2022-06-21 19:37:32.228126
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(2)) == 'Min[value=2]'



# Generated at 2022-06-21 19:37:35.936038
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(1)) == Sum(2)
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(2).concat(Sum(1)) == Sum(3)


# Generated at 2022-06-21 19:37:44.962142
# Unit test for constructor of class Map
def test_Map():
    # create one Map
    Map_1 = Map({'a': Sum(1), 'b': All(False), 'c': Max(1)})
    # create another Map
    Map_2 = Map({'a': Sum(2), 'b': All(True), 'c': Min(2)})

    # test if
    assert Map_1.concat(Map_2) == Map({'a': Sum(3), 'b': All(False), 'c': Max(1)})

# Generated at 2022-06-21 19:37:49.069957
# Unit test for method concat of class Min
def test_Min_concat():
    semigroup = Min(1)
    semigroup1 = Min(1)
    semigroup2 = Min(2)
    semigroup3 = Min(3)
    assert semigroup.concat(semigroup1).value == 1
    assert semigroup1.concat(semigroup2).value == 1
    assert semigroup2.concat(semigroup3).value == 2


# Generated at 2022-06-21 19:37:55.020475
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)

# Unit test method concat of class All

# Generated at 2022-06-21 19:37:56.436954
# Unit test for constructor of class One
def test_One():
    one = One(False)
    assert not one.value


# Generated at 2022-06-21 19:37:57.472834
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1



# Generated at 2022-06-21 19:38:03.851709
# Unit test for method concat of class Map
def test_Map_concat():
    # Given
    a = Map({'a': All(True), 'b': All(False), 'c': All(True)})
    b = Map({'a': All(False), 'b': All(True), 'c': All(True)})

    # When
    c = a.concat(b)

    # Then
    assert c.value['a'] == All(False)
    assert c.value['b'] == All(True)
    assert c.value['c'] == All(True)



# Generated at 2022-06-21 19:38:09.228106
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert (
        Semigroup(1) == Semigroup(1)
    ), 'The method __eq__ of class Semigroup does not work properly'
    assert (
        Semigroup(1) != Semigroup(2)
    ), 'The method __eq__ of class Semigroup does not work properly'


# Generated at 2022-06-21 19:38:16.645277
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert_equal(Sum(1).value, 1)
    assert_equal(All(True).value, True)
    assert_equal(One(True).value, True)
    assert_equal(First(1).value, 1)
    assert_equal(Last(1).value, 1)
    assert_equal(Max(1).value, 1)
    assert_equal(Min(1).value, 1)
    assert_equal(Map({1: Sum(1)}).value, {1: Sum(1)})


# Generated at 2022-06-21 19:38:18.146455
# Unit test for constructor of class One
def test_One():
    assert One(1).value == 1
    assert One(1) != One(2)


# Generated at 2022-06-21 19:38:19.547225
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-21 19:38:24.764857
# Unit test for method __str__ of class Last
def test_Last___str__():
    _last = Last(1)
    assert str(_last) == 'Last[value=1]'


# Generated at 2022-06-21 19:38:31.171421
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert isinstance(All(True).fold(bool), bool)  # Result of fold method is bool
    assert All(False).fold(str) == 'False'  # Result of fold by method str is 'False'
    assert All(True).fold(Sum).value == 1  # Result of fold by class Sum is Sum[value=1]
    assert All(False).fold(Sum) == Sum(0)  # Result of fold by class Sum is Sum[value=0]
    assert All(False).fold(lambda x: x) is False  # Result of fold by lambda is False

# Generated at 2022-06-21 19:38:35.310849
# Unit test for constructor of class Map
def test_Map():
    assert Map({"a": 1}) == Map({"a": 1})
    assert Map({"a": 1}) != Map({"a": 1, "b": 2})
    assert Map({"a": 1}) != Sum(1)



# Generated at 2022-06-21 19:38:39.859854
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-21 19:38:41.791524
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x * 2) == 2


# Generated at 2022-06-21 19:38:43.148345
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last("string")) == 'Last[value=string]'


# Generated at 2022-06-21 19:38:45.713814
# Unit test for constructor of class Min
def test_Min():
    """
    Unit test for constructor of class Min
    """
    assert Min(2).value == 2


# Generated at 2022-06-21 19:38:47.869917
# Unit test for constructor of class Map
def test_Map():
    value = Map({1: Sum(1)})
    assert value == Map(value), "But the values are not equal"


# Generated at 2022-06-21 19:38:49.653330
# Unit test for constructor of class All
def test_All():
    assert(All(True).value == True)
    assert(All(False).value == False)


# Generated at 2022-06-21 19:38:51.166094
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First("foo")) == 'Fist[value=foo]'


# Generated at 2022-06-21 19:38:55.614585
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)



# Generated at 2022-06-21 19:38:58.785558
# Unit test for constructor of class All
def test_All():
    assert (All(True).value), "True should be true"
    assert not All(False).value, "False should be false"
    assert All(0).value, "0 should be true"
    assert not All(1).value, "1 should be false"
    assert All('').value, "'' should be true"
    assert not All('abc').value, "'abc' should be false"


# Generated at 2022-06-21 19:39:04.333932
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)

    assert All(False).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)



# Generated at 2022-06-21 19:39:06.238922
# Unit test for method concat of class Sum
def test_Sum_concat():  # pragma: no cover
    x = Sum(3)
    y = Sum(1)
    assert x.concat(y) == Sum(4)

# Generated at 2022-06-21 19:39:09.256222
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Sum([1, 2, 3]) == Sum([1, 2, 3])
    assert Sum([1, 2, 3]) != Sum([1, 2, 4])



# Generated at 2022-06-21 19:39:11.308734
# Unit test for method __str__ of class Max
def test_Max___str__():
    expected = 'Max[value=1]'
    actual = str(Max(1))
    assert actual == expected


# Generated at 2022-06-21 19:39:14.121253
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(7)) == Max(7)
    assert Max(5).concat(Max(5)) == Max(5)
    assert Max(5).concat(Max(2)) == Max(5)


# Generated at 2022-06-21 19:39:15.565594
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(5) == Sum(5)
    assert Sum(5) != Sum(6)


# Unit test of method fold in class Sum

# Generated at 2022-06-21 19:39:20.451502
# Unit test for method concat of class One
def test_One_concat():
    """
    concat will return first truly value or last falsy
    """
    assert One(True).concat(One(False)).value == True
    assert One(True).concat(One(True)).value == True
    assert One(False).concat(One(True)).value == True
    assert One(False).concat(One(False)).value == False

# Generated at 2022-06-21 19:39:22.593228
# Unit test for constructor of class One
def test_One():
    one = One(True)

    assert one.value == True
# Test of method fold()

# Generated at 2022-06-21 19:39:27.879379
# Unit test for method concat of class First
def test_First_concat():
    assert First('1').concat(First('2')) == First('1')


# Generated at 2022-06-21 19:39:29.600430
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)


# Generated at 2022-06-21 19:39:36.918945
# Unit test for method concat of class Sum
def test_Sum_concat():
    semigroup = Sum(1).concat(Sum(2))
    assert semigroup == Sum(3)
    # Unit test for method concat of class All
    semigroup = All(True).concat(All(True))
    assert semigroup == All(True)
    semigroup = All(True).concat(All(False))
    assert semigroup == All(False)
    semigroup = All(False).concat(All(True))
    assert semigroup == All(False)
    semigroup = All(False).concat(All(False))
    assert semigroup == All(False)
    # Unit test for method concat of class One
    semigroup = One(True).concat(One(True))
    assert semigroup == One(True)
    semigroup = One(True).concat(One(False))
    assert sem

# Generated at 2022-06-21 19:39:38.401143
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last("a")) == "Last[value=a]"

# Generated at 2022-06-21 19:39:40.525600
# Unit test for method __str__ of class All
def test_All___str__():
    s = All(True)
    assert str(s) == 'All[value=True]'


# Generated at 2022-06-21 19:39:42.601533
# Unit test for method concat of class Sum
def test_Sum_concat():
    a = Sum(1)
    b = Sum(2)
    c = a.concat(b)
    assert c == Sum(a.value + b.value)



# Generated at 2022-06-21 19:39:46.899109
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)
    assert Min(1) != Min(2)
    assert str(Min(1)) == "Min[value=1]"


# Generated at 2022-06-21 19:39:48.874519
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    Test class Semigroup constructor
    """
    semigroup = Semigroup(10)
    assert semigroup.value == 10

# Generated at 2022-06-21 19:39:49.925076
# Unit test for constructor of class Last
def test_Last(): assert str(Last(0)) == 'Last[value=0]'

# Generated at 2022-06-21 19:39:50.773891
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True


# Generated at 2022-06-21 19:39:56.853830
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-21 19:40:01.217451
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(str) == '1'
    assert All(True).fold(str) == 'True'
    assert First([1, 2, 3]).fold(str) == '[1, 2, 3]'
    assert Last(['a', 'b', 'c']).fold(str) == 'abc'


# Generated at 2022-06-21 19:40:03.664229
# Unit test for method concat of class Sum
def test_Sum_concat():
    x = Sum(3)
    y = Sum(6)
    assert x.concat(y) == Sum(9)



# Generated at 2022-06-21 19:40:06.367879
# Unit test for constructor of class First
def test_First():
    assert First(1) != First(2)
    assert First(1) != First(1, 1)
    assert First(1).concat(First(2)).value == 1



# Generated at 2022-06-21 19:40:07.444541
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-21 19:40:14.089228
# Unit test for method concat of class First
def test_First_concat():
    """
    Test for First concat method
    """
    first = First(1)
    second = First(2)
    assert isinstance(first.concat(second), First)
    assert first.concat(second) == First(1)



# Generated at 2022-06-21 19:40:16.609801
# Unit test for method __str__ of class First
def test_First___str__():
    first = First("value")
    assert str(first) == "Fist[value=value]"
    assert repr(first) == "Fist[value=value]"


# Generated at 2022-06-21 19:40:17.866544
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-21 19:40:24.016580
# Unit test for method concat of class All
def test_All_concat():
    a = All(True)
    b = All(True)
    assert a.concat(b) == All(True)
    a = All(True)
    b = All(False)
    assert a.concat(b) == All(False)
    a = All(False)
    b = All(False)
    assert a.concat(b) == All(False)
    a = All(False)
    b = All(True)
    assert a.concat(b) == All(False)
    a = All(True)
    b = All(None)
    assert a.concat(b) == All(False)
    a = All(None)
    b = All(True)
    assert a.concat(b) == All(False)
    a = All(None)

# Generated at 2022-06-21 19:40:24.985855
# Unit test for constructor of class Min
def test_Min():
    assert Min(7).value == 7

# Generated at 2022-06-21 19:40:33.469136
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    Sum_a = Sum(10)
    assert Sum_a.fold(lambda x: x * 2) == 20



# Generated at 2022-06-21 19:40:35.681058
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1).value == 1


# Generated at 2022-06-21 19:40:39.420742
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    eq_tests = [
        (Sum(1), Sum(1)),
        (Sum(2), Sum(1)),
        (All(True), All(True)),
        (All(False), All(True)),
        (One(1), One(1)),
        (One(0), One(1)),
        (Sum(2), 3),
        (All(True), False),
        (One(1), 2),
        (First(1), 1),
        (Last(1), 1),
        (Max(1), 1),
        (Min(1), 1),
    ]

    for left, right in eq_tests:
        assert left == right



# Generated at 2022-06-21 19:40:44.849490
# Unit test for method concat of class Last
def test_Last_concat():
    """
    Testing method concat for Last
    """
    semigroup_1 = Last(1)
    semigroup_2 = semigroup_1.concat(Last(2))
    assert semigroup_1 == Last(1)
    assert semigroup_2 == Last(2)


# Generated at 2022-06-21 19:40:46.917455
# Unit test for constructor of class First
def test_First():
    first = First(1)
    assert first.value == 1
    assert str(first) == 'First[value=1]'



# Generated at 2022-06-21 19:40:48.447816
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(2)) == 'Sum[value=2]'


# Generated at 2022-06-21 19:40:53.536902
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({1: Map({1: Sum(1), 2: Sum(2)}), 2: Map({1: Sum(3), 2: Sum(4)})}
        )
    ) == 'Map[value={1: Map[value={1: Sum[value=1], 2: Sum[value=2]}], 2: Map[value={1: Sum[value=3], 2: Sum[value=4]}]}]'



# Generated at 2022-06-21 19:40:57.816078
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(0)) == Last(0)
    assert Last(1).concat(Last(1)) == Last(1)

# Generated at 2022-06-21 19:41:04.402119
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    json_1 = {"id": 1, "name": "name_1", "age": 100}
    json_2 = {"id": 1, "name": "name_1", "age": 100}
    json_3 = {"id": 3, "name": "name_3", "age": 300}

    assert Semigroup(json_1) == Semigroup(json_2)
    assert Semigroup(json_1) != Semigroup(json_3)
    assert Semigroup(json_2) != Semigroup(json_3)

# Generated at 2022-06-21 19:41:05.918046
# Unit test for constructor of class All
def test_All():  # pragma: no cover
    assert All(True) == All(True)


# Generated at 2022-06-21 19:41:24.426687
# Unit test for constructor of class Max
def test_Max():
    assert Max(2).value == 2


# Generated at 2022-06-21 19:41:28.262375
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-21 19:41:31.188622
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert First(10).fold(lambda v: v + 10) == 20
    assert Last(20).fold(lambda v: v + 10) == 30
    assert Sum(1).fold(lambda v: v + 2) == 3

# Generated at 2022-06-21 19:41:34.908675
# Unit test for method concat of class All
def test_All_concat():
    all_1 = All(True)
    all_2 = All(True)
    all_result = All(True)
    assert all_1.concat(all_2) == all_result



# Generated at 2022-06-21 19:41:38.693515
# Unit test for method concat of class All
def test_All_concat():
    assert All(False).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
    assert All(True).concat(All(False)).value == False
    assert All(True).concat(All(True)).value == True


# Generated at 2022-06-21 19:41:39.897585
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    s = Sum(1)
    assert (s.__str__() == "Sum[value=1]")


# Generated at 2022-06-21 19:41:40.976135
# Unit test for constructor of class One
def test_One():
    one = One(True)
    assert one.value == True


# Generated at 2022-06-21 19:41:42.038977
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"


# Generated at 2022-06-21 19:41:45.592368
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)
    assert Min(1).fold(str) == '1'


# Generated at 2022-06-21 19:41:47.816404
# Unit test for constructor of class All
def test_All():
    all_one = All(True)
    assert all_one == All(True)



# Generated at 2022-06-21 19:42:07.954016
# Unit test for method concat of class First
def test_First_concat():
    assert First(3).concat(First(4)) == First(3)
    assert First(10).concat(First(0)) == First(10)
    assert First(0).concat(First(0)) == First(0)
    assert First(0).concat(First('')) == First(0)



# Generated at 2022-06-21 19:42:11.824158
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert str(All(True)) == 'All[value=True]'  # type: ignore
    assert str(All(False)) == 'All[value=False]'  # type: ignore



# Generated at 2022-06-21 19:42:14.940899
# Unit test for method concat of class One
def test_One_concat():
    one = One(True)
    assert one.concat(One(False)) == One(True)
    assert one.concat(One(True)) == One(True)
    assert one.concat(One(None)) == One(True)
    assert one.concat(One([])) == One(True)



# Generated at 2022-06-21 19:42:15.955234
# Unit test for constructor of class All
def test_All():
    assert All(True).value
    assert not All(False).value


# Generated at 2022-06-21 19:42:18.234121
# Unit test for constructor of class Min
def test_Min():
    assert Min(4).concat(Min(3)).concat(Min(5)).concat(Min(8)).concat(Min(2)).concat(Min(1)).value == 1


# Generated at 2022-06-21 19:42:23.732924
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert Last(1) != First(1)
    assert Last(1) != One(1)
    assert Last(1) != All(1)
    assert Last(1) != Sum(1)
    assert Last(1) != Min(1)
    assert Last(1) != Max(1)
    assert Last(1) != Map({'a': 1})


# Generated at 2022-06-21 19:42:25.092875
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)



# Generated at 2022-06-21 19:42:26.140913
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(5)) == "Fist[value=5]"



# Generated at 2022-06-21 19:42:27.152455
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(5)) == 'One[value=5]'


# Generated at 2022-06-21 19:42:32.083232
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False
    assert All('').value == False
    assert All([]).value == False
    assert All(0).value == False
    assert All(1).value == True
    assert All([1,2,3]).value == True
    assert All([0,1,2]).value == True
    assert All(['1',0,1,2]).value == False


# Generated at 2022-06-21 19:43:06.937680
# Unit test for method __str__ of class Min
def test_Min___str__():
    num = 4
    assert str(Min(num)) == 'Min[value=4]'


# Generated at 2022-06-21 19:43:08.054646
# Unit test for constructor of class Last
def test_Last():
    assert Last(3).value == 3


# Generated at 2022-06-21 19:43:11.172326
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(3).concat(Min(7)) == Min(3)
    assert Min(3).concat(Min(2)) == Min(2)
    assert Min(3).concat(Min(3)) == Min(3)

test_Min_concat()

# Generated at 2022-06-21 19:43:13.132528
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({"one": One(True)})) == 'Map[value={"one": One[value=True]}]'


# Generated at 2022-06-21 19:43:17.065680
# Unit test for method __str__ of class Map
def test_Map___str__():
    from nose.tools import assert_equal
    m = Map({'a': 1, 'b': 3, 'c': 9})
    assert_equal(str(m), 'Map[value={\'a\': 1, \'b\': 3, \'c\': 9}]')


# Generated at 2022-06-21 19:43:19.877128
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-21 19:43:21.957802
# Unit test for method __str__ of class Map
def test_Map___str__():
    """
    Unit test for method __str__ of class Map
    """
    map_instance = Map({'test': First(1)})

    assert str(map_instance) == "Map[value={'test': Fist[value=1]}]"

# Generated at 2022-06-21 19:43:30.088196
# Unit test for method concat of class Last
def test_Last_concat():
    last1 = Last(1)
    last2 = Last(2)
    last3 = Last(3)

    assert last1.concat(last2).concat(last3).value == 3
    assert last2.concat(last1).concat(last3).value == 3
    assert last3.concat(last1).concat(last2).value == 3

# Generated at 2022-06-21 19:43:32.718235
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(7).concat(Min(-8)) == Min(-8)
    assert Min(8).concat(Min(-8)) == Min(-8)


# Generated at 2022-06-21 19:43:33.990288
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == "Max[value=1]"


# Generated at 2022-06-21 19:44:07.411192
# Unit test for constructor of class First
def test_First():
    first = First(1)
    assert first.value == 1



# Generated at 2022-06-21 19:44:09.593224
# Unit test for constructor of class One
def test_One():
    assert isinstance(One(True), object)
    assert isinstance(One(1), object)
    assert isinstance(One(None), object)


# Generated at 2022-06-21 19:44:10.744956
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
