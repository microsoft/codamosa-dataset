

# Generated at 2022-06-21 19:34:17.097502
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(5).fold(lambda a: a) == 5

# Generated at 2022-06-21 19:34:19.208604
# Unit test for constructor of class Max
def test_Max():
    assert Max(5) == Max(5)
    assert Max(5) != Max(3)
    assert Max(5).fold(lambda x: x * x) == 25
    

# Generated at 2022-06-21 19:34:22.495077
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(15).concat(Min(30)).value == 15
    assert Min(10).concat(Min(5)).value == 5
    assert Min(5).concat(Min(10)).value == 5


# Generated at 2022-06-21 19:34:29.103445
# Unit test for method concat of class Min
def test_Min_concat():
    min1 = Min(1)
    min2 = Min(2)
    assert min1.concat(min2) == Min(min(min1.value, min2.value))
    min1 = Min(1)
    min2 = Min(-1)
    assert min1.concat(min2) == Min(min(min1.value, min2.value))



# Generated at 2022-06-21 19:34:30.311205
# Unit test for constructor of class One
def test_One():
    o = One(0)
    assert o == One(0)
    assert o.value == 0



# Generated at 2022-06-21 19:34:32.349566
# Unit test for method concat of class Last
def test_Last_concat():
    """
    Test concat method for Last class.
    """

    assert Last(1).concat(Last(2)).concat(Last(3)) == Last(3)



# Generated at 2022-06-21 19:34:39.743437
# Unit test for method concat of class All
def test_All_concat():
    """
    concat method of type All combines 2 instances of All using logical conjunction on their coerced Boolean values.

    Examples:
        >>> assert All(True).concat(All(True)) == All(True)
        >>> assert All(True).concat(All(False)) == All(False)
        >>> assert All(False).concat(All(True)) == All(False)
        >>> assert All(False).concat(All(False)) == All(False)
    """
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-21 19:34:42.663477
# Unit test for constructor of class First
def test_First():
	f = First(1)
	assert isinstance(f, First)
	assert isinstance(f, Semigroup)
	assert f == Semigroup(1)
	assert str(f) == 'Fist[value=1]'


# Generated at 2022-06-21 19:34:45.129804
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-21 19:34:49.427703
# Unit test for constructor of class First
def test_First():
    a = First(1)
    b = First(2)
    assert a.value == 1
    assert b.value == 2
    assert a is b
    assert a == b
    assert a.concat(b) == First(1)


# Generated at 2022-06-21 19:34:54.180702
# Unit test for constructor of class Map
def test_Map():
    assert Map({1: Sum(1), 2: Sum(2)}).value == {1: Sum(1), 2: Sum(2)}


# Generated at 2022-06-21 19:35:02.007032
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)

# Generated at 2022-06-21 19:35:04.101505
# Unit test for constructor of class One
def test_One():
    assert One(False) == One(False)



# Generated at 2022-06-21 19:35:06.164066
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-21 19:35:07.578362
# Unit test for constructor of class Last
def test_Last():
     assert Last(2) == Last(2)


# Generated at 2022-06-21 19:35:10.114377
# Unit test for constructor of class Max
def test_Max():
    assert Max(Max(Max(0).value).value).value == 0
    assert Max(Max(Max(1).value).value).value == 1


# Generated at 2022-06-21 19:35:11.563540
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == "One[value=True]"



# Generated at 2022-06-21 19:35:12.918046
# Unit test for method __str__ of class Max
def test_Max___str__():
    max = Max(10)
    print(max)


# Generated at 2022-06-21 19:35:15.484783
# Unit test for constructor of class One
def test_One():
    unit_one = One(33)
    assert unit_one.value == 33


# Generated at 2022-06-21 19:35:18.186586
# Unit test for method __str__ of class First
def test_First___str__():
    """Unit test for method __str__ of class First."""
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First('foo')) == 'Fist[value=foo]'



# Generated at 2022-06-21 19:35:23.704750
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1)})) == 'Map[value={"a": Sum[value=1]}]'


# Generated at 2022-06-21 19:35:27.502904
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(0)) == 'Max[value=0]'



# Generated at 2022-06-21 19:35:30.136300
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert 'Max[value=0]' == str(Max(0))
    assert 'Max[value=1]' == str(Max(1))



# Generated at 2022-06-21 19:35:32.315048
# Unit test for method __str__ of class Last
def test_Last___str__():
    last: Last = Last(5)
    assert str(last) == 'Last[value=5]'



# Generated at 2022-06-21 19:35:33.591947
# Unit test for method __str__ of class All
def test_All___str__(): 
    assert str(All(True)) == "All[value=True]"


# Generated at 2022-06-21 19:35:34.915790
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-21 19:35:36.546074
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(10)) == 'Min[value=10]'


# Generated at 2022-06-21 19:35:39.057973
# Unit test for method concat of class Last
def test_Last_concat():
    """
    Unit test for method concat of class Last
    """
    assert Last("Hello").concat(Last("World")).value == "World"

# Generated at 2022-06-21 19:35:40.567847
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-21 19:35:43.166179
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup("test").__eq__(Semigroup("test")) == True
    assert Semigroup("test").__eq__(Semigroup("test1")) == False


# Generated at 2022-06-21 19:35:49.275428
# Unit test for constructor of class First
def test_First():
    assert First(2) == First(2)  # pragma: no cover



# Generated at 2022-06-21 19:35:52.008047
# Unit test for method __str__ of class Max
def test_Max___str__():
    value = Max.neutral()
    assert str(value) == str(Max(value.neutral_element))
    assert str(value) == 'Max[value=-inf]'


# Generated at 2022-06-21 19:35:55.116690
# Unit test for constructor of class Max
def test_Max():
    try:
        assert Max(1) == Max(1)
    except AssertionError:
        print("AssertionError:")


# Generated at 2022-06-21 19:35:56.710381
# Unit test for method concat of class Sum
def test_Sum_concat():
    test = Sum(1).concat(Sum(2)).value == 3
    print(test)



# Generated at 2022-06-21 19:35:58.317767
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert isinstance(Sum(1).fold(lambda x: x + 1), int)



# Generated at 2022-06-21 19:35:59.960425
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-21 19:36:03.137778
# Unit test for method __str__ of class Last
def test_Last___str__():
    value = "test"
    expected = 'Last[value=test]'
    actual = Last(value)
    assert str(actual) == expected
    assert repr(actual) == expected



# Generated at 2022-06-21 19:36:04.471133
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last('test')) == "Last[value=test]"


# Generated at 2022-06-21 19:36:07.422887
# Unit test for method __str__ of class All
def test_All___str__():
    all_ = All(False)
    assert all_.__str__() == "All[value=False]"
    assert not all_.__str__() == "All[value=True]"


# Generated at 2022-06-21 19:36:15.236246
# Unit test for method concat of class Map
def test_Map_concat():
    """
    Test that the concat method of Map semigroups it be called only once at this monoid and
    the value will be concated only for 1 first key.
    """
    map = Map({'a': Sum(1), 'b': Sum(2)})
    map2 = Map({'a': Min(2)})

    value = map.concat(map2).value

    assert value == {'a': Sum(3), 'b': Sum(2)}



# Generated at 2022-06-21 19:36:21.738373
# Unit test for method __str__ of class Max
def test_Max___str__():
    actual = str(Max(1))
    assert actual == 'Max[value=1]'


# Generated at 2022-06-21 19:36:23.509249
# Unit test for method concat of class Last
def test_Last_concat():
    semigroup = Last(2)
    result = semigroup.concat(Last(3))
    assert result.value == 3



# Generated at 2022-06-21 19:36:28.644998
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First('A')) == 'Fist[value=A]'
    assert str(First([1, 2, 3])) == 'Fist[value=[1, 2, 3]]'
    assert str(First({1, 2, 3})) == 'Fist[value={1, 2, 3}]'
    assert str(First({'a': 1, 'b': 2})) == "Fist[value={'a': 1, 'b': 2}]"
    assert str(First({'a', 'b'})) == "Fist[value={'a', 'b'}]"


# Generated at 2022-06-21 19:36:34.324106
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(True).concat(One(True)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-21 19:36:35.898997
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert 'Last[value=6]' == str(Last(6))



# Generated at 2022-06-21 19:36:37.289991
# Unit test for constructor of class One
def test_One():
    one = One(True)
    assert one.value == True


# Generated at 2022-06-21 19:36:39.433300
# Unit test for method concat of class Sum
def test_Sum_concat():  # pragma: no cover
    assert Sum(1).concat(Sum(2)).value == 3


# Generated at 2022-06-21 19:36:41.457388
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-21 19:36:43.886695
# Unit test for constructor of class Max
def test_Max():
    assert Max(1).value == 1


# Generated at 2022-06-21 19:36:49.085325
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).concat(Min(3)) == Min(1)
    assert Min(100).concat(Min(2)).concat(Min(3)) == Min(2)
    assert Min(100).concat(Min(100)).concat(Min(100)) == Min(100)



# Generated at 2022-06-21 19:36:54.854863
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)
    assert One(1) != One(2)
    assert str(One(1).__str__()) == 'One[value=1]'


# Generated at 2022-06-21 19:36:56.855707
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert 'Fist[value=A]' == str(First('A'))



# Generated at 2022-06-21 19:37:00.131891
# Unit test for constructor of class Max
def test_Max():
    m1 = Max(4)
    m2 = Max(5)
    assert m1.concat(m2) == Max(5)


# Generated at 2022-06-21 19:37:00.889438
# Unit test for constructor of class Min
def test_Min():
    assert Min(3).value == 3


# Generated at 2022-06-21 19:37:02.161124
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)



# Generated at 2022-06-21 19:37:03.688780
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First('a')) == "Fist[value='a']"



# Generated at 2022-06-21 19:37:04.572580
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1


# Generated at 2022-06-21 19:37:08.595577
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup("1") == Semigroup("1")
    assert Semigroup("1") != Semigroup(1)
    assert Semigroup("1") != Semigroup(2)


# Generated at 2022-06-21 19:37:09.244183
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(2)) == 'Min[value=2]'


# Generated at 2022-06-21 19:37:12.469218
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True).value == True
    assert All(False).value == False

    assert All(True) != All(False)



# Generated at 2022-06-21 19:37:20.514873
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(True)).concat(All(False)) == All(False)


# Generated at 2022-06-21 19:37:29.278326
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({'a': Sum(5), 'b': Sum(10)})
    m2 = Map({'a': Sum(10), 'c': Sum(20)})

    assert Map({'a': Sum(15), 'b': Sum(10), 'c': Sum(20)}) == m1.concat(m2)

    m1 = Map({'a': All(True), 'b': All(False)})
    m2 = Map({'a': All(True), 'c': All(False)})

    assert Map({'a': All(True), 'b': All(False), 'c': All(False)}) == m1.concat(m2)

    m1 = Map({'a': One(True), 'b': One(False)})

# Generated at 2022-06-21 19:37:30.936743
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)



# Generated at 2022-06-21 19:37:33.837108
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'key': Sum(1)})) == 'Map[value={\'key\': Sum[value=1]}]'

test_Map___str__()



# Generated at 2022-06-21 19:37:38.256457
# Unit test for constructor of class Sum
def test_Sum():
    sum_1 = Sum(1)
    sum_2 = Sum(2)
    assert sum_1 == Sum(1)
    assert sum_1.value == 1
    assert sum_2 == Sum(2)
    assert sum_2.value == 2
    assert sum_1 != sum_2



# Generated at 2022-06-21 19:37:43.316971
# Unit test for method __str__ of class First
def test_First___str__():
    """
    Test __str__ method of class First.
    """
    assert str(First({})) == "Fist[value={}]"
    assert str(First(["Miguel de Cervantes Saavedra", "Oliver Twist"])) == "Fist[value=['Miguel de Cervantes Saavedra', 'Oliver Twist']]"



# Generated at 2022-06-21 19:37:48.872987
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Test fold method of class Semigroup
    """
    assert Sum(1).fold(lambda x: x + 1) == 2
    assert Sum(2).fold(lambda x: x * 5) == 10
    assert First(1).fold(lambda x: x + 1) == 1
    assert First(2).fold(lambda x: x * 5) == 2
    assert Last(10).fold(lambda x: x + 1) == 11
    assert Last(2).fold(lambda x: x * 5) == 10

# Generated at 2022-06-21 19:37:49.961533
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"



# Generated at 2022-06-21 19:37:51.245102
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(2) == Sum(2)
    assert not (Sum(2) == Sum(3))



# Generated at 2022-06-21 19:37:53.037992
# Unit test for method concat of class First
def test_First_concat():
    first_a = First(5)
    first_b = First(15)
    result = first_a.concat(first_b)
    assert result.value == 5



# Generated at 2022-06-21 19:38:00.121161
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum1 = Sum(1)
    sum2 = Sum(2)
    sum4 = Sum(4)
    assert sum1.concat(sum2) == Sum(3)
    assert sum1.concat(sum4) == Sum(5)

test_Sum_concat()


# Generated at 2022-06-21 19:38:01.943698
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-21 19:38:05.249715
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max.neutral().concat(Max(1)).value == 1
    assert Max(1).concat(Max.neutral()).value == 1
    assert Max(1).concat(Max(3)).value == 3
    assert Max(3).concat(Max(1)).value == 3



# Generated at 2022-06-21 19:38:07.978957
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum = Sum(1)
    assert str(sum) == 'Sum[value=1]'


# Generated at 2022-06-21 19:38:09.423566
# Unit test for constructor of class Max
def test_Max():
    assert Max(2) == Max(2)



# Generated at 2022-06-21 19:38:14.064033
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == True
    assert One(True).concat(One(False)) == True
    assert One(False).concat(One(True)) == True
    assert One(False).concat(One(False)) == False



# Generated at 2022-06-21 19:38:16.963224
# Unit test for method __str__ of class Min
def test_Min___str__():
    _id = uuid.uuid4().hex
    semigroup = Min(1)
    assert str(semigroup) == "Min[value=1]"
    assert repr(semigroup) == str(semigroup)



# Generated at 2022-06-21 19:38:19.899481
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert Sum(5) == Sum(5)
    assert Sum(5).fold(lambda x: x) == 5


# Generated at 2022-06-21 19:38:23.351603
# Unit test for constructor of class Semigroup
def test_Semigroup():
    try:
        Semigroup(1)
    except Exception as err:
        print(err)
        assert False
    else:
        assert True


# Generated at 2022-06-21 19:38:25.762949
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'map': Sum(10)})) == 'Map[value={map: Sum[value=10]}]'


# Generated at 2022-06-21 19:38:30.199855
# Unit test for constructor of class All
def test_All():
    semigroup = All(True)
    assert semigroup.value



# Generated at 2022-06-21 19:38:31.725093
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-21 19:38:35.416496
# Unit test for constructor of class Min
def test_Min():
    min1 = Min(1)
    min2 = Min(2)
    min3 = min1.concat(min2)
    assert(min3.value == 1)


# Generated at 2022-06-21 19:38:39.041175
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'
    assert str(Last(10)) == 'Last[value=10]'
    assert str(Last('hello')) == 'Last[value=hello]'



# Generated at 2022-06-21 19:38:41.315711
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)).value == False



# Generated at 2022-06-21 19:38:46.533784
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-21 19:38:51.167016
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)
    assert First(1).concat(First(None)) == First(1)
    assert First(None).concat(First(1)) == First(None)
    assert First(None).concat(First(None)) == First(None)



# Generated at 2022-06-21 19:38:52.391922
# Unit test for constructor of class Last
def test_Last():
    assert Last(5) == Last(5)


# Generated at 2022-06-21 19:38:56.923404
# Unit test for method concat of class Map
def test_Map_concat():
    a = Map({
        'a': First(0),
        'b': Max(1),
        'c': All(False)
    })
    b = Map({
        'a': First(1),
        'b': Max(3),
        'c': All(True)
    })
    assert a.concat(b) == Map({'a': First(0), 'b': Max(3), 'c': All(False)})

# Generated at 2022-06-21 19:38:59.968831
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert One(True) != One(False)
    assert One(False) != One(True)



# Generated at 2022-06-21 19:39:06.026557
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'



# Generated at 2022-06-21 19:39:08.578771
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup('a') == Semigroup('a')

# Generated at 2022-06-21 19:39:10.669955
# Unit test for method concat of class Min
def test_Min_concat():
    """
    >>> a = Min(1)
    >>> b = Min(2)
    >>> a.concat(b)
    Min[value=1]
    """



# Generated at 2022-06-21 19:39:13.076287
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(1) == One(1)
    assert One(True) != One(False)


# Generated at 2022-06-21 19:39:15.820317
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)).value == True
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(True)).value == True
    assert One(False).concat(One(False)).value == False


# Generated at 2022-06-21 19:39:17.198243
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(5).fold(lambda x: x ** 2) == 25

# Generated at 2022-06-21 19:39:21.125743
# Unit test for constructor of class First
def test_First():
    """
    test_First
    """
    test_first = First(1)
    assert isinstance(test_first, First)
    assert isinstance(test_first.value, int)
    assert test_first.value == 1


# Generated at 2022-06-21 19:39:24.237265
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)
    assert Min(2) == Min(2)
    assert Min(3) == Min(3)

test_Min()


# Generated at 2022-06-21 19:39:28.166890
# Unit test for constructor of class Map
def test_Map():
    m = Map({"a": Sum(5), "b": Sum(3)})
    assert m.value == {'a': Sum(5), 'b': Sum(3)}
    assert m.fold(lambda values: values) == {'a': Sum(5), 'b': Sum(3)}

# Generated at 2022-06-21 19:39:29.145565
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-21 19:39:33.586700
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1
    assert Sum(1).fold(lambda a: a) == 1



# Generated at 2022-06-21 19:39:36.979986
# Unit test for method __str__ of class Min
def test_Min___str__():
    obj = Min(10)
    assert str(obj) == 'Min[value=10]'


# Generated at 2022-06-21 19:39:38.454212
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-21 19:39:47.205896
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Sum(5) == Sum(5)
    assert Sum(5) != Sum(6)
    assert All(True) == All(True)
    assert All(True) != All(False)
    assert One(True) == One(True)
    assert One(True) != One(False)
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert Map({'a': Sum(1)}) == Map({'a': Sum(1)})
    assert Map({'a': Sum(1)}) != Map({'a': Sum(2)})
    assert Max(1) == Max(1)
    assert Max(1) != Max(2)

# Generated at 2022-06-21 19:39:48.479111
# Unit test for constructor of class First
def test_First():
    first = First('first')
    assert first.value == 'first'



# Generated at 2022-06-21 19:39:49.876307
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-21 19:39:54.326655
# Unit test for method __str__ of class Last
def test_Last___str__():
    print('\n<======= Unit Test =======>')
    print('<= Semigroup.Last.__str__ =')
    obj = Last(123)
    actual = str(obj)
    expected = 'Last[value=123]'
    print(actual)
    assert actual == expected

test_Last___str__()


# Generated at 2022-06-21 19:39:58.956582
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-21 19:40:02.548310
# Unit test for method __str__ of class Map
def test_Map___str__(): # pragma: no cover
    map = Map({1: Sum(1), 2: Sum(2)})
    assert str(map) == 'Map[value={1: Sum[value=1], 2: Sum[value=2]}]'


# Generated at 2022-06-21 19:40:03.909264
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(4)) == "Sum[value=4]"


# Generated at 2022-06-21 19:40:12.593574
# Unit test for constructor of class First
def test_First(): # pragma: no cover
    f = First(1)
    assert type(f) is First
    assert f.value == 1


# Generated at 2022-06-21 19:40:13.663802
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == "Min[value=1]"


# Generated at 2022-06-21 19:40:15.544009
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    def fn(x): return x + 1

    assert Semigroup(1).fold(fn) == fn(1), "Monoid want to concat"



# Generated at 2022-06-21 19:40:16.903829
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)


# Generated at 2022-06-21 19:40:20.312306
# Unit test for method __str__ of class One
def test_One___str__():
    assert (
        One('One').__str__()
    ) == 'One[value=One]', 'Should be One[value=One] but returned {}'.format(
        One('One').__str__()
    )



# Generated at 2022-06-21 19:40:22.979765
# Unit test for method concat of class One
def test_One_concat():  # pragma: no cover
    one_one = One(1)
    one_two = One(2)
    one_three = one_one.concat(one_two)
    assert one_three == One(1)

# Generated at 2022-06-21 19:40:25.833315
# Unit test for constructor of class Map
def test_Map():
    assert Map({
        'a': Sum(1),
        'b': Sum(2),
    }) == Map({
        'a': Sum(1),
        'b': Sum(2),
    })


# Generated at 2022-06-21 19:40:27.391959
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'



# Generated at 2022-06-21 19:40:30.806767
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)).value == True
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(True)).value == True
    assert One(False).concat(One(False)).value == False


# Generated at 2022-06-21 19:40:35.594282
# Unit test for method concat of class First
def test_First_concat():
    fn = lambda x: First(x)
    nums = [5, 1, 3, 2, 4]
    assert fold(nums, fn) == First(5)



# Generated at 2022-06-21 19:40:50.834871
# Unit test for method concat of class Sum
def test_Sum_concat():
    s = Sum(1)
    t = Sum(2)
    assert s.concat(t) == Sum(3)


# Generated at 2022-06-21 19:40:52.669840
# Unit test for method concat of class All
def test_All_concat():
    concat_result = All(True).concat(All(True))

    assert concat_result == All(True)



# Generated at 2022-06-21 19:40:53.930797
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-21 19:40:57.856062
# Unit test for method concat of class One
def test_One_concat():
    s = One(False)
    s1 = One(True)
    expected = One(True)
    actual = s.concat(s1)
    assert actual == expected


# Generated at 2022-06-21 19:40:58.990180
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)

# Generated at 2022-06-21 19:41:01.788569
# Unit test for method __str__ of class Min
def test_Min___str__():
    test_value1 = Min(1)
    assert str(test_value1) == 'Min[value=1]'


# Generated at 2022-06-21 19:41:03.140857
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(0) == Sum(0)



# Generated at 2022-06-21 19:41:06.509680
# Unit test for constructor of class Last
def test_Last():  # pragma: no cover
    w = Last('abc')
    x = Last(1)
    y = Last(True)
    z = Last(None)
    assert w.value == 'abc'
    assert x.value == 1
    assert y.value == True
    assert z.value == None


# Generated at 2022-06-21 19:41:09.126485
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Test for method fold of class Semigroup
    """
    expected = Max(5)
    result = Semigroup(5).fold(Max)

    assert result == expected


# Unit tests for method concat of class Sum

# Generated at 2022-06-21 19:41:14.319386
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({"a": Sum(1), "b": Sum(2)}).concat(Map({"a": Sum(2)})).value == {
        "a": Sum(3),
        "b": Sum(2),
    }


Eq.__instancecheck__ = lambda inst: isinstance(inst, Semigroup)

# Generated at 2022-06-21 19:41:47.817718
# Unit test for method concat of class Map
def test_Map_concat():
    # Given
    map_1 = Map({
        "a": Sum(2),
        "b": Sum(1),
        "c": Sum(4),
    })
    map_2 = Map({
        "a": Sum(5),
        "b": Sum(3),
        "c": Sum(6),
    })

    # When
    result = map_1.concat(map_2)

    # Then
    assert result.value["a"].value == 7
    assert result.value["b"].value == 4
    assert result.value["c"].value == 10

# Generated at 2022-06-21 19:41:49.252958
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'



# Generated at 2022-06-21 19:41:53.215342
# Unit test for method concat of class Map
def test_Map_concat():
    a = Map({'a': Last(1), 'b': Last(1)})
    b = Map({'a': Last(2), 'b': Last(2)})
    assert a.concat(b) == Map({'a': Last(2), 'b': Last(2)})

# Generated at 2022-06-21 19:41:55.166960
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert First('one').fold(lambda x: x) == "one"
    assert Last(5).fold(lambda x: x) == 5



# Generated at 2022-06-21 19:41:58.849767
# Unit test for constructor of class Last
def test_Last():  # pragma: no cover
    v = Last('abcdef')
    #
    assert type(v) == Last
    assert v.value == 'abcdef'



# Generated at 2022-06-21 19:42:00.893431
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(2)) == 'Fist[value=2]'
    assert str(First(False)) == 'Fist[value=False]'


# Generated at 2022-06-21 19:42:03.539595
# Unit test for constructor of class Map
def test_Map():
    x = Map({'a': Sum(1), 'b': Sum(4), 'c': Sum(9)})
    assert x.value == {'a': Sum(1), 'b': Sum(4), 'c': Sum(9)}


# Generated at 2022-06-21 19:42:04.890781
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(99)) == Min(1)


# Generated at 2022-06-21 19:42:08.399403
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    Tests Sum's concat method returns a new Sum with a value equal to the sum of the two Sum's values when called with another Sum instance
    """
    assert Sum(3).concat(Sum(4)) == Sum(7)


# Generated at 2022-06-21 19:42:10.255853
# Unit test for method __str__ of class First
def test_First___str__():
    first = First(10)
    assert str(first) == "Fist[value=10]"


# Generated at 2022-06-21 19:43:15.404806
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(False)) == 'All[value=False]'
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-21 19:43:18.819272
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)).value == True
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(True)).value == True
    assert One(False).concat(One(False)).value == False

# Generated at 2022-06-21 19:43:21.814019
# Unit test for method __str__ of class First
def test_First___str__():
    # Arrange
    x = First('value')

    # Act
    result = str(x)

    # Assert
    assert result == 'Fist[value=value]'



# Generated at 2022-06-21 19:43:25.461407
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    s = Sum(5)
    assert (str(s) == 'Sum[value=5]')



# Generated at 2022-06-21 19:43:31.508166
# Unit test for method concat of class One
def test_One_concat():
    assert One(False).concat(One(False)) == One(False)
    assert One(False).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(True).concat(One(True)) == One(True)


# Generated at 2022-06-21 19:43:38.541698
# Unit test for method concat of class Map
def test_Map_concat():  # pragma: no cover
    a_dict = {'a': 1, 'b': 2, 'c': 3}
    a_map = Map(a_dict)
    b_map = Map({'a': 10, 'b': 20})
    c_map = a_map.concat(b_map)
    assert c_map.value == {'a': 11, 'b': 22, 'c': 3}
    
if __name__ == '__main__':
    print(Map({"a": Sum(10), "c": Sum(20), "b": Sum(30)}).concat(Map({"a": Sum(20), "b": Sum(40)})).value)

# Generated at 2022-06-21 19:43:41.044806
# Unit test for method concat of class First
def test_First_concat():
    assert First('a').concat(First('b')) == First('a')


# Generated at 2022-06-21 19:43:42.651083
# Unit test for constructor of class Last
def test_Last():
    test = Last(True)
    assert test.value == True
    assert isinstance(test, Last)


# Generated at 2022-06-21 19:43:47.687764
# Unit test for constructor of class Min
def test_Min():

    assert Min(12) == Min(12)
    assert isinstance(Min.neutral(), Min)
    assert Min(12).value == 12
    assert Min(12) == Min(12)
    assert Min(5).value == 5
    assert Min(5) == Min(5)


# Generated at 2022-06-21 19:43:52.907929
# Unit test for method concat of class Min
def test_Min_concat():
    min_a = Min(1)
    min_b = Min(2)

    assert min_a.concat(min_a) == Min(1)
    assert min_a.concat(min_b) == Min(1)
    assert min_b.concat(min_b) == Min(2)
    assert min_b.concat(min_a) == Min(1)
