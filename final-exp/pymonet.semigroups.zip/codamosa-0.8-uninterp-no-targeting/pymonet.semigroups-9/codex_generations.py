

# Generated at 2022-06-21 19:34:17.346258
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(2).value == 2


# Generated at 2022-06-21 19:34:21.071834
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(5).concat(Max(6)) == Max(6)
    assert Max(6).concat(Max(5)) == Max(6)
    assert Max(5).concat(Max(5)) == Max(5)
    assert Max(5).concat(Semigroup(3)) == Max(5)


# Generated at 2022-06-21 19:34:23.883265
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    first_cls = First(True)
    assert str(first_cls) == 'Fist[value=True]'



# Generated at 2022-06-21 19:34:29.627063
# Unit test for method concat of class Max
def test_Max_concat():
    """
    Example usage of Max class
    """
    assert Max(10).concat(Max(9)) == Max(10)
    assert Max(1).concat(Max(3)) == Max(3)
    assert Max(5).concat(Max(5)) == Max(5)


# Generated at 2022-06-21 19:34:32.572642
# Unit test for method concat of class All
def test_All_concat():
    semigroup = All(True)
    assert semigroup.concat(All(False)).value == False
    assert semigroup.concat(All(True)).value == True

# Generated at 2022-06-21 19:34:34.201690
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == "One[value=True]"



# Generated at 2022-06-21 19:34:35.862607
# Unit test for constructor of class Max
def test_Max():
    assert Max.neutral().value == -float("inf")
    assert Max(10).value == 10



# Generated at 2022-06-21 19:34:38.490955
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)


# Generated at 2022-06-21 19:34:42.085372
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x) == 1
    assert Semigroup("test").fold(lambda x: len(x)) == 4


# Generated at 2022-06-21 19:34:46.167357
# Unit test for constructor of class Max
def test_Max():  # pragma: no cover
    assert Max(4) == Max(4)



# Generated at 2022-06-21 19:34:52.519795
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)


# Generated at 2022-06-21 19:34:54.320184
# Unit test for constructor of class First
def test_First():
    try:
        First(1)
    except:
        raise AssertionError('First test error')



# Generated at 2022-06-21 19:35:01.822791
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(5) == Sum(5)
    assert All(True) == All(True)
    assert One(True) == One(True)
    assert First("value") == First("value")
    assert Last("value") == Last("value")


# Generated at 2022-06-21 19:35:04.935939
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-21 19:35:06.788008
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    semigroup = Semigroup(value=7)

    # We intend to find out the double of the number 7
    assert semigroup.fold(lambda x: x * 2) == 14



# Generated at 2022-06-21 19:35:10.951451
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)).value == True
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(True)).value == True
    assert One(False).concat(One(False)).value == False



# Generated at 2022-06-21 19:35:13.527063
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(3).concat(Min(4)) == Min(3)
    assert Min(4).concat(Min(3)) == Min(3)


# Generated at 2022-06-21 19:35:18.151671
# Unit test for method concat of class One
def test_One_concat():
    assert One(False).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(True).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-21 19:35:20.542575
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'


# Generated at 2022-06-21 19:35:21.410538
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(9))

# Generated at 2022-06-21 19:35:25.858690
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert 'Last[value=1]' == str(Last(1))
    assert 'Last[value="asd"]' == str(Last('asd'))
    assert 'Last[value=True]' == str(Last(True))
    assert 'Last[value=[]]' == str(Last([]))


# Generated at 2022-06-21 19:35:36.751079
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({}).concat(Map({'a': Sum(1), 'b': Sum(2)})) == Map({'a': Sum(1), 'b': Sum(2)})
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({})) == Map({'a': Sum(1), 'b': Sum(2)})
    assert Map({'a': Sum(1)}).concat(Map({'a': Sum(2), 'b': Sum(2)})) == Map({'a': Sum(3), 'b': Sum(2)})
    assert Map({'a': Sum(1)}).concat(Map({'a': Sum(2), 'b': Sum(2)})) == Map({'a': Sum(3), 'b': Sum(2)})

# Generated at 2022-06-21 19:35:43.590161
# Unit test for constructor of class Max
def test_Max():
    assert Max(5).concat(Max(10)).concat(Max(1)).value == 10
    assert Max(5).concat(Max(10)).concat(Max(10)).value == 10
    assert Max(1).concat(Max(10)).concat(Max(10)).value == 10
    assert Max(1).concat(Max(1)).concat(Max(10)).value == 10
    assert Max(1).concat(Max(1)).concat(Max(1)).value == 1

test_Max()

# Generated at 2022-06-21 19:35:45.192051
# Unit test for constructor of class Last
def test_Last():
    l = Last(1)
    assert l.value == 1



# Generated at 2022-06-21 19:35:46.518057
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).value == 1, "Min value must be one"


# Generated at 2022-06-21 19:35:54.094889
# Unit test for constructor of class Map
def test_Map():
    value = Map({1: Sum(1), 2: Sum(2), 3: Sum(3)})
    assert value.value == {1: Sum(1), 2: Sum(2), 3: Sum(3)}
    assert value.__str__() == 'Map[value={1: Sum[value=1], 2: Sum[value=2], 3: Sum[value=3]}]'



# Generated at 2022-06-21 19:35:55.826459
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)


# Generated at 2022-06-21 19:35:59.698359
# Unit test for constructor of class All
def test_All():
    class AlwaysTrue(All): pass
    class AlwaysFalse(All): neutral_element = False

    assert AlwaysTrue(False)
    assert AlwaysTrue(True)
    assert All(True)
    assert All(False)
    assert not All.neutral()
    assert not AlwaysFalse.neutral()


# Generated at 2022-06-21 19:36:01.633729
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():  # pragma: no cover
    assert Semigroup(1).fold(lambda x: x) == 1


# Generated at 2022-06-21 19:36:02.532803
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-21 19:36:05.895057
# Unit test for constructor of class Max
def test_Max():
    max_instance = Max(1)
    assert max_instance.value == 1



# Generated at 2022-06-21 19:36:13.328346
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert All(False) == All(False)
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert First(1) == First(1)
    assert Last(1) == Last(1)
    assert Map({1: Sum(1)}) == Map({1: Sum(1)})
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)
    assert Sum(1) != Sum(2)
    assert All(True) != All(False)
    assert One(True) != One(False)
    assert First(1) != First(2)
    assert Last(1) != Last(2)

# Generated at 2022-06-21 19:36:18.201753
# Unit test for method concat of class All
def test_All_concat():
    assert All(False).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(True).concat(All(False)) == All(False)
    assert All(True).concat(All(True)) == All(True)



# Generated at 2022-06-21 19:36:20.925514
# Unit test for constructor of class One
def test_One():
    assert One(False) == One(False)
    assert One(True) == One(True)
    assert str(One(1)) == 'One[value=1]'

# Generated at 2022-06-21 19:36:23.193402
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == 'Map[value={\'a\': Sum[value=1], \'b\': Sum[value=2]}]'


# Generated at 2022-06-21 19:36:24.976498
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    # empty
    assert str(Sum(100)) == 'Sum[value=100]'
    assert str(Sum(1.5)) == 'Sum[value=1.5]'



# Generated at 2022-06-21 19:36:36.793723
# Unit test for method concat of class Map
def test_Map_concat():
    from pymonet.monoid import Map
    m1 = Map({1: All(True)})
    m2 = Map({2: All(True)})
    assert Map({1: All(True), 2: All(True)}).fold(dict) == m1.concat(m2).fold(dict)
    m1 = Map({1: All(False), 3: All(True)})
    m2 = Map({1: All(True), 2: All(False)})
    assert Map({1: All(False), 3: All(True), 2: All(False)}).fold(dict) == m1.concat(m2).fold(dict)
    m1 = Map({1: All(True), 2: All(True)})
    m2 = Map({1: All(False), 2: All(False)})

# Generated at 2022-06-21 19:36:40.867364
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value == True
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False


# Generated at 2022-06-21 19:36:44.318209
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)


# Generated at 2022-06-21 19:36:49.085487
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1
    assert Sum(3).value == 3
    assert Sum(1) == Sum(3)
    assert Sum(1).concat(Sum(3)) == Sum(4)
    assert Sum(1).fold(lambda x: x+1) == 2


# Generated at 2022-06-21 19:37:01.471114
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)
    assert Semigroup('test') == Semigroup('test')
    assert not Semigroup('test') == Semigroup(2)
    assert Semigroup([]) == Semigroup([])
    assert Semigroup([1, 2, 3]) == Semigroup([1, 2, 3])
    assert not Semigroup([1, 2, 3]) == Semigroup([1, 2])
    assert Semigroup((1, 2, 3)) == Semigroup((1, 2, 3))
    assert not Semigroup((1, 2, 3)) == Semigroup((1, 2))
    assert Semigroup({'a': 1, 'b': 2}) == Semigroup({'a': 1, 'b': 2})

# Generated at 2022-06-21 19:37:05.008287
# Unit test for method concat of class First
def test_First_concat():
    test_semigroup = First("test_value")
    test_semigroup_concat = First("test_value_concat")
    result = test_semigroup_concat.concat(test_semigroup)
    assert result.value == "test_value_concat"


# Generated at 2022-06-21 19:37:09.026319
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(5)
    b = Min(2)
    assert a.concat(b) == Min(2)
    assert b.concat(a) == Min(2)



# Generated at 2022-06-21 19:37:11.784899
# Unit test for method concat of class Min
def test_Min_concat():
    s = Min(8)
    s1 = Min(5)
    s2 = s.concat(s1)
    assert s2 == Min(5)



# Generated at 2022-06-21 19:37:16.270398
# Unit test for constructor of class All
def test_All():  # pragma: no cover
    assert All(True) == All(True)
    assert All(True) != All(False)
    assert All(True).value == True

    assert All(False) == All(False)
    assert All(False) != All(True)
    assert All(False).value == False



# Generated at 2022-06-21 19:37:17.359250
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum_ = Sum(1)
    assert str(sum_) == "Sum[value=1]"

# Generated at 2022-06-21 19:37:19.397547
# Unit test for method __str__ of class All
def test_All___str__():
    m1 = All(True)
    assert __str__(m1) == 'All[value=True]'



# Generated at 2022-06-21 19:37:24.368795
# Unit test for constructor of class One
def test_One():
    """
    Unit testing for class One.
    """
    test_value = One(True)
    assert test_value.value == True
    print('Test constructor of class One')
    print('Input value: ', True)
    print('Expectation: True')
    print('Output value: ', test_value.value)
    assert test_value.value == True
    print('Pass')


# Generated at 2022-06-21 19:37:26.300021
# Unit test for constructor of class Min
def test_Min(): # pragma: no cover
    assert Min(10) == Min(10)
    assert not Min(10) == Min(20)


# Generated at 2022-06-21 19:37:27.531695
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'



# Generated at 2022-06-21 19:37:30.982554
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(1).value == 1


# Generated at 2022-06-21 19:37:33.887611
# Unit test for method concat of class Max
def test_Max_concat():
    val1 = Max(1).concat(Max(2))
    assert val1.value == 2
    assert str(val1) == 'Max[value=2]'



# Generated at 2022-06-21 19:37:35.553258
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-21 19:37:38.922725
# Unit test for method concat of class Last
def test_Last_concat():
    """
    Checks if method concat of class Last returns last value in instances
    """
    first = Last(2)
    second = Last(3)
    expected = Last(3)
    assert first.concat(second) == expected



# Generated at 2022-06-21 19:37:40.911490
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(10).concat(Max(3)) == Max(10)



# Generated at 2022-06-21 19:37:43.067009
# Unit test for constructor of class Max
def test_Max():
    a1 = Max(10)
    assert a1.value == 10
    assert str(a1) == "Max[value=10]"


# Generated at 2022-06-21 19:37:51.042645
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    :returns: bool if test pass
    :rtype: bool
    """

    return (
        Sum(5).fold(lambda x: x + 1) == 6 and
        Max(5).fold(lambda x: x + 1) == 6 and
        Min(5).fold(lambda x: x + 1) == 6 and
        All(True).fold(lambda x: not x) == False and
        One(False).fold(lambda x: not x) == True and
        First(True).fold(lambda x: not x) == True and
        Last(True).fold(lambda x: not x) == True and
        Map({'value': Sum(5)}).fold(lambda x: x['value'] + 1) == {'value': 6}
    )



# Generated at 2022-06-21 19:38:01.994536
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert Map({'a': Sum(1), 'b': Sum(2), }).__str__() == "Map[value={'a': Sum[value=1], 'b': Sum[value=2]}]"
    assert Map({'a': All(True), 'b': All(False)}).__str__() == "Map[value={'a': All[value=True], 'b': All[value=False]}]"
    assert Map({'a': Last(1), 'b': Last(2)}).__str__() == "Map[value={'a': Fist[value=1], 'b': Fist[value=2]}]"
    assert Map({'a': First(1), 'b': First(2)}).__str__() == "Map[value={'a': Fist[value=1], 'b': Fist[value=2]}]"

# Generated at 2022-06-21 19:38:03.589600
# Unit test for constructor of class Map
def test_Map():
    assert Map({'1': First(1), '2': First(2)}).value == {'1': First(1), '2': First(2)}


# Generated at 2022-06-21 19:38:05.295079
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(42)) == 'Min[value=42]'

# Generated at 2022-06-21 19:38:11.087952
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'



# Generated at 2022-06-21 19:38:13.546962
# Unit test for constructor of class Max
def test_Max():
    """
    Unit test for constructor of class Max
    """
    assert Max(4).value == 4



# Generated at 2022-06-21 19:38:16.162336
# Unit test for method concat of class First
def test_First_concat():
    s1 = First(3)
    s2 = First(1)
    assert (s1.concat(s2).value == 1)



# Generated at 2022-06-21 19:38:17.669657
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)


# Generated at 2022-06-21 19:38:21.019840
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"


# Generated at 2022-06-21 19:38:23.892721
# Unit test for constructor of class Last
def test_Last():
    """
    Last constructor must accept any value and has no compulsory parameters
    """
    Last('papis')
    Last(Sum(5))



# Generated at 2022-06-21 19:38:32.519317
# Unit test for constructor of class All
def test_All():
    # Equality check
    assert All(True) == All(True)
    assert All(True) == All(False)
    assert All(False) == All(True)
    assert All(False) == All(False)
    # Identity element
    assert All(True).concat(All.neutral()).value == True
    assert All(True).concat(All(False)).concat(All.neutral()).value == False
    assert All(False).concat(All.neutral()).value == False
    # Associative
    assert All(True).concat(All(False)).concat(All(True)).value == False
    assert (
        All(True).concat(All(False)).concat(All(True)).value
        == All(True).concat(All(False).concat(All(True))).value
    )


# Generated at 2022-06-21 19:38:35.421303
# Unit test for method __str__ of class First
def test_First___str__():
    value = 10
    assert str(First(value)) == 'Fist[value={}]'.format(value)



# Generated at 2022-06-21 19:38:36.809358
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Test fold method of Semigroup class
    """
    assert Semigroup.neutral().value == Semigroup.neutral_element



# Generated at 2022-06-21 19:38:38.000792
# Unit test for method __str__ of class First
def test_First___str__():
    a = First(1)
    assert str(a) == 'Fist[value=1]'


# Generated at 2022-06-21 19:38:47.548131
# Unit test for method __str__ of class Map
def test_Map___str__():
    m = Map({
    "key1": Sum(2),
    "key2": One(False),
    "key3": Sum(3),
    "key4": All(True)
    })
    assert str(m) == 'Map[value={\'key1\': Sum[value=2], \'key2\': One[value=False], \'key3\': Sum[value=3], \'key4\': All[value=True]}]'


# Generated at 2022-06-21 19:38:49.700506
# Unit test for constructor of class First
def test_First():
    """
    Unit test for constructor class First
    """
    result = First(2)
    assert result.value == 2


# Generated at 2022-06-21 19:38:51.129776
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    result = All(False)
    assert str(result) == 'All[value=False]'



# Generated at 2022-06-21 19:38:52.305109
# Unit test for method concat of class Sum
def test_Sum_concat():
    a = Sum(1)
    b = Sum(2)
    c = a.concat(b)
    assert c.value == 3



# Generated at 2022-06-21 19:38:54.783091
# Unit test for constructor of class Map
def test_Map():
    map_ = Map({'a': Sum(1), 'b': First(2)})
    assert map_.value == {'a': Sum(1), 'b': First(2)}


# Generated at 2022-06-21 19:38:57.478432
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    :return: True if test passed
    :raises: AssertionError if test don't passed
    """
    assert Semigroup(2).value == 2
    assert Semigroup([2, 3]).value == [2, 3]
    return True



# Generated at 2022-06-21 19:38:59.870947
# Unit test for constructor of class One
def test_One():
    """
    >>> test_One()
    One[value=True]
    """
    return One(True)


# Generated at 2022-06-21 19:39:02.312908
# Unit test for method __str__ of class First
def test_First___str__():
    first = First(1)
    assert str(first) == 'Fist[value=1]'


# Generated at 2022-06-21 19:39:04.336149
# Unit test for method __str__ of class Min
def test_Min___str__():
    obj = Min(1)
    assert str(obj) == 'Min[value=1]'


# Generated at 2022-06-21 19:39:09.655574
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    sum_ = Sum(6)
    assert str(sum_) == 'Sum[value=6]'
    assert sum_.concat(Sum(1)) == Sum(7)
    assert sum_.concat(Sum(1)).neutral() == Sum(0)



# Generated at 2022-06-21 19:39:19.690135
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)).value == 2
    assert Max(2).concat(Max(1)).value == 2
    assert Max(10).concat(Max(10)).value == 10


# Generated at 2022-06-21 19:39:21.798498
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1
    assert Last(3.14).value == 3.14


# Generated at 2022-06-21 19:39:25.118663
# Unit test for constructor of class Min
def test_Min():
    # The goal of this unit test is to check that the value in the instance of Min is equal to the  sent value.
    a: Min = Min(3)
    assert a.value == 3



# Generated at 2022-06-21 19:39:34.591329
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert First(1) == First(1)
    assert Last(1) == Last(1)
    assert All(True) == All(True)
    assert One(True) == One(True)
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)
    assert Map({1: Sum(1)}) == Map({1: Sum(1)})
    assert Map({1: First(1)}) == Map({1: First(1)})
    assert Map({1: Last(1)}) == Map({1: Last(1)})
    assert Map({1: All(True)}) == Map({1: All(True)})
    assert Map({1: One(True)}) == Map({1: One(True)})

# Generated at 2022-06-21 19:39:36.644437
# Unit test for constructor of class First
def test_First():
    assert First('foo') == First('foo')


# Generated at 2022-06-21 19:39:38.557966
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert isinstance(Sum(3).fold(lambda x: x).value, int)


# Generated at 2022-06-21 19:39:46.407476
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert All(False) == All(False)
    assert First(1) == First(1)
    assert Last(2) == Last(2)
    assert Max(2) == Max(2)
    assert Min(1) == Min(1)
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert Sum(2) == Sum(2)
    assert Map({1: First(1), 2: First(2)}) == Map({1: First(1), 2: First(2)})



# Generated at 2022-06-21 19:39:49.266019
# Unit test for method __str__ of class Max
def test_Max___str__():
    m = Max(3)
    assert str(m) == 'Max[value=3]'
    assert str(m.concat(Max(4))) == 'Max[value=4]'



# Generated at 2022-06-21 19:39:53.775548
# Unit test for constructor of class First
def test_First():
    assert First(1).concat(First(2)) == First(1)
    assert First(None).concat(First(2)) == First(None)
    assert First(1).concat(First('2')) == First(1)
    assert First(1).concat(First(True)) == First(1)


# Generated at 2022-06-21 19:39:55.748585
# Unit test for constructor of class Last
def test_Last():
    """
    Unit test for Last constructor that initialize the Last with value.
    """
    assert Last(1).value == 1



# Generated at 2022-06-21 19:40:11.647499
# Unit test for constructor of class Map
def test_Map():
    assert Map({"name": Sum(1)}) == Map({"name": Sum(1)})


# Generated at 2022-06-21 19:40:15.936568
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(3)).value == 1
    assert Min(3).concat(Min(1)).value == 1
    assert Min(1).concat(Min(4)).value == 1
    assert Min(4).concat(Min(1)).value == 1

# Generated at 2022-06-21 19:40:18.526802
# Unit test for method __str__ of class All
def test_All___str__():
    instance = All(True)
    assert str(instance) == 'All[value=True]'
    instance = All(False)
    assert str(instance) == 'All[value=False]'


# Generated at 2022-06-21 19:40:20.546639
# Unit test for method __str__ of class First
def test_First___str__():
    assert "\n".join(str(First(3)).split()) == "Fist[value=3]"


# Generated at 2022-06-21 19:40:21.658753
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(2)) == 'Max[value=2]'


# Generated at 2022-06-21 19:40:23.957144
# Unit test for method __str__ of class Last
def test_Last___str__():
    result = Last(1)
    expected = 'Last[value=1]'
    assert str(result) == expected



# Generated at 2022-06-21 19:40:25.314545
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(2).fold(lambda x: x) == 2

# Generated at 2022-06-21 19:40:29.547525
# Unit test for method concat of class Max
def test_Max_concat(): # pragma: no cover
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(2).concat(Max(2)) == Max(2)
    assert Max(0).concat(Max(9)) == Max(9)


# Generated at 2022-06-21 19:40:31.025143
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert 'Sum[value=1]' == str(Sum(1))


# Generated at 2022-06-21 19:40:36.986327
# Unit test for constructor of class One
def test_One():
    assert One(True).value is True
    assert One(False).value is False
    assert One(1).value is True
    assert One(0).value is False
    assert One(None).value is False
    assert One({}).value is False
    assert One((None,)).value is False



# Generated at 2022-06-21 19:41:06.910438
# Unit test for method __str__ of class Map
def test_Map___str__():
    """
    Method __str__ should return value with string format
    """
    assert str(Map(
        {
            'foo': Sum(1),
            'bar': Sum(2),
        }
    )) == "Map[value={'foo': Sum[value=1], 'bar': Sum[value=2]}]"

# Generated at 2022-06-21 19:41:08.652247
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    sum_instance = Sum(2)
    assert str(sum_instance) == 'Sum[value=2]'



# Generated at 2022-06-21 19:41:09.724631
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(5).concat(Min(8)) == Min(5)


# Generated at 2022-06-21 19:41:10.946694
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert str(Max(0)) == 'Max[value=0]'



# Generated at 2022-06-21 19:41:12.313940
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(2)) == 'Sum[value=2]'
    assert str(Sum(10)) == 'Sum[value=10]'


# Generated at 2022-06-21 19:41:14.105823
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)



# Generated at 2022-06-21 19:41:17.942935
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)).value == 1
    assert First(0.5).concat(First(2)).value == 0.5
    assert First('a').concat(First('b')).value == 'a'
    assert First(None).concat(First(None)).value == None
    assert First(None).concat(First(2)).value == None
    assert First('a').concat(First(2)).value == 'a'
    assert First('a').concat(First([1, 2])).value == 'a'
    assert First('a').concat(First({'a': 'b'})).value == 'a'



# Generated at 2022-06-21 19:41:27.241654
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)

    assert One(True).concat(All(True)) == All(True)
    assert One(True).concat(All(False)) == One(True)
    assert One(False).concat(All(True)) == All(True)
    assert One(False).concat(All(False)) == One(False)

    assert One(True).concat(Last(True)) == Last(True)
    assert One(True).concat(Last(False)) == Last(False)

# Generated at 2022-06-21 19:41:29.144033
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(3).concat(Sum(4)) == Sum(7)


# Generated at 2022-06-21 19:41:30.987990
# Unit test for constructor of class One
def test_One():
    assert One("Test").value == "Test"
    assert One(123).value == 123
    assert One(False).value == False


# Generated at 2022-06-21 19:42:30.671024
# Unit test for constructor of class Map
def test_Map():

    assert Map({'a': 1, 'b': 2}).value == {'a': 1, 'b': 2}



# Generated at 2022-06-21 19:42:32.781805
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)
    assert bool(One(True))
    assert not bool(One(False))


# Generated at 2022-06-21 19:42:35.825659
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({
        'string': First('initial value'),
    })) == "Map[value={'string': Fist[value='initial value']}]"



# Generated at 2022-06-21 19:42:36.893483
# Unit test for constructor of class First
def test_First():
    first = First(1)
    assert first.value == 1

# Generated at 2022-06-21 19:42:45.686622
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(3) == Sum(3)
    assert not Sum(3) == Sum(0)
    assert Sum(3) != Sum(0)

    assert All(True) == All(True)
    assert not All(True) == All(False)
    assert All(True) != All(False)

    assert First(3) == First(3)
    assert First(3) == First(0)
    assert not First(3) != First(3)
    assert not First(3) != First(0)

    assert Last(3) == Last(3)
    assert Last(3) == Last(0)

    assert Map({1: 1, 2: 2}) == Map({1: 1, 2: 2})
    assert not Map({1: 1, 2: 2}) == Map({1: 1, 2: 1})

# Generated at 2022-06-21 19:42:46.728196
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-21 19:42:50.653715
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({"1": Sum(1)})) == "Map[value={'1': Sum[value=1]}]"


# Generated at 2022-06-21 19:42:57.965574
# Unit test for constructor of class All
def test_All():
    """
    all_a = All(a), all_b = All(b), all_ab = all_a.concat(all_b)
    """
    a = True
    b = False

    all_a = All(a)
    all_b = All(b)
    all_ab = all_a.concat(all_b)

    assert a == all_a.value
    assert b == all_b.value
    assert all_ab.value == False


# Generated at 2022-06-21 19:43:02.178973
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-21 19:43:04.241720
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True) != All(False)
    assert All(True) != All(None)
    assert All(None) != All(False)
