

# Generated at 2022-06-21 19:34:17.894062
# Unit test for method concat of class Last
def test_Last_concat():
    last = Last(3)
    assert last.concat(Last(4)) == Last(4)



# Generated at 2022-06-21 19:34:18.964985
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)).value == 2

# Generated at 2022-06-21 19:34:20.576022
# Unit test for method concat of class Sum
def test_Sum_concat():
    sum_instance = Sum(1)
    assert sum_instance.concat(Sum(2)) == Sum(3)



# Generated at 2022-06-21 19:34:27.420084
# Unit test for method concat of class One
def test_One_concat():
    """
    Test for method concat of class One
    """

    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-21 19:34:30.281081
# Unit test for constructor of class Max
def test_Max():  # pragma: no cover
    max = Max(3)
    assert max.value == 3
    assert max.neutral_element == -float("inf")


# Generated at 2022-06-21 19:34:35.096253
# Unit test for method concat of class Min
def test_Min_concat():
    """
    Assert that concat method of Monoid Min is correct.
    """
    eq_((Min(1).concat(Min(2)).value), 1)
    eq_((Min(5).concat(Min(1)).value), 1)
    eq_((Min(5).concat(Min(5)).value), 5)


# Generated at 2022-06-21 19:34:39.348879
# Unit test for method concat of class All
def test_All_concat():
    a = All(True)
    b = All(True)
    assert a.concat(b) == All(True)
    a = All(True)
    b = All(False)
    assert a.concat(b) == All(False)
    a = All(False)
    b = All(True)
    assert a.concat(b) == All(False)
    a = All(False)
    b = All(False)
    assert a.concat(b) == All(False)



# Generated at 2022-06-21 19:34:43.456348
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    unit = Sum(2)

    assert unit.fold(lambda x: x * 2) == 4
    assert unit.fold(lambda x: x + 2) == 4
    assert unit.fold(lambda x: x // 2) == 1
    assert unit.fold(lambda x: x * x) == 4
    assert unit.fold(lambda x: x / 2) == 1



# Generated at 2022-06-21 19:34:45.127981
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(5).concat(Last(10)) == Last(10)

# Generated at 2022-06-21 19:34:48.082824
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(0) == Semigroup(0)
    assert not Semigroup(0) == Semigroup(1)



# Generated at 2022-06-21 19:34:53.899416
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'



# Generated at 2022-06-21 19:35:00.072211
# Unit test for constructor of class First
def test_First():
    assert First(None) == First(None)

# Generated at 2022-06-21 19:35:04.153456
# Unit test for method concat of class First
def test_First_concat():
    """
    :returns: result of unit testing for concat method
    :rtype: bool
    """
    first = First('a')
    other = First('b')
    assert first.concat(other) == First('a')


# Generated at 2022-06-21 19:35:07.025006
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2).concat(Min(3)) == Min(2)
    assert Min(3).concat(Min(2)) == Min(2)


# Generated at 2022-06-21 19:35:09.796980
# Unit test for constructor of class One
def test_One():
    assert One(1).value == 1
    assert One(False).value == False
    assert One(True).value == True
    assert One('').value == ''
    assert One([]).value == []
    assert One(()).value == ()
    assert One(0.1).value == 0.1

# Unit tests for constructor of class All

# Generated at 2022-06-21 19:35:12.406903
# Unit test for constructor of class Max
def test_Max():
    assert Max(5).value == 5
    assert Max(5).neutral().value == -float(inf)
    assert Max(5).fold(lambda x: x) == 5


# Generated at 2022-06-21 19:35:15.539088
# Unit test for method concat of class Max
def test_Max_concat():
    max_a = Max(1)
    max_b = Max(2)
    max_c = Max(3)
    assert max_a.concat(max_b).concat(max_c) == Max(3)


# Generated at 2022-06-21 19:35:18.220860
# Unit test for constructor of class Max
def test_Max():
    assert Max(3).value == 3
    assert Max(3).concat(Max(5)).value == 5
    assert Max(3).concat(Max(5)).fold(lambda x: x ** 2) == 25


# Generated at 2022-06-21 19:35:20.005998
# Unit test for constructor of class Min
def test_Min():
    assert Min(3).value == 3
# Unit test method concat of class Min

# Generated at 2022-06-21 19:35:22.191796
# Unit test for constructor of class Sum
def test_Sum():
    a = Sum(3)
    b = Sum(9)

    assert (
        a.concat(b)
        == b.concat(a)
    )



# Generated at 2022-06-21 19:35:30.260556
# Unit test for method __str__ of class Map
def test_Map___str__():
    # Arrange
    obj = Map({'a': Sum(1), 'b': Sum(2)})

    # Act
    actual = str(obj)

    # Assert
    assert 'Map[value={{' in actual
    assert 'a: Sum[value=1]' in actual
    assert 'b: Sum[value=2]' in actual
    assert '}]' in actual



# Generated at 2022-06-21 19:35:31.985551
# Unit test for constructor of class Sum
def test_Sum():
    sum = Sum(1)
    assert sum == Sum(1)


# Generated at 2022-06-21 19:35:37.374935
# Unit test for method concat of class Map
def test_Map_concat():  # pragma: no cover
    # Given
    first_Map = Map({'a': Sum(1), 'b': All(True)})
    second_Map = Map({'a': Sum(1), 'b': All(False)})
    expected_Map = Map({'a': Sum(2), 'b': All(False)})

    # When
    result_Map = first_Map.concat(second_Map)

    # Then
    assert str(expected_Map) == str(result_Map)
    assert expected_Map == result_Map

# Generated at 2022-06-21 19:35:39.791534
# Unit test for constructor of class All
def test_All():  # pragma: no cover
    assert All(False) == All(False)
    assert All(True) == All(True)



# Generated at 2022-06-21 19:35:41.232036
# Unit test for method concat of class First
def test_First_concat():
    assert First(2).concat(First(3)) == First(2)

# Generated at 2022-06-21 19:35:43.458393
# Unit test for method __str__ of class Min
def test_Min___str__():
    min_str = Min(2).__str__()
    assert 'Min[value=2]' == min_str


# Generated at 2022-06-21 19:35:46.095197
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert Semigroup(1) == Semigroup(1)
    assert not(Semigroup(1) == Semigroup(2))



# Generated at 2022-06-21 19:35:48.064651
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).value == 1

# Generated at 2022-06-21 19:35:50.722859
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(23)) == 'Sum[value=23]'



# Generated at 2022-06-21 19:35:57.482301
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(None) == Semigroup(None)
    assert not Semigroup('str') == Semigroup(None)
    assert not Semigroup(True) == Semigroup(False)
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(2) == Semigroup(2)
    assert Semigroup(1.1) == Semigroup(1.1)
    assert Semigroup(2.2) == Semigroup(2.2)


# Generated at 2022-06-21 19:36:01.586672
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)).value is False
    assert All(True).concat(All(True)).value is True



# Generated at 2022-06-21 19:36:05.848707
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value is True
    assert All(True).concat(All(False)).value is False
    assert All(False).concat(All(False)).value is False
    assert All(False).concat(All(True)).value is False


# Generated at 2022-06-21 19:36:08.245358
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)  # pragma: no cover
    assert Max(2) == Max(2)  # pragma: no cover



# Generated at 2022-06-21 19:36:20.309702
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert (Sum(1) == Sum(1))
    assert (All(False) == All(False))
    assert (One(True) == One(True))
    assert (First(3) == First(3))
    assert (Last(2) == Last(2))
    assert (Max(3) == Max(3))
    assert (Min(2) == Min(2))
    assert (Map([1]) == Map([1]))
    assert (Sum(1) != Sum(0))
    assert (All(False) != All(True))
    assert (One(True) != One(False))
    assert (First(3) != First(2))
    assert (Last(2) != Last(1))
    assert (Max(3) != Max(2))
    assert (Min(2) != Min(1))

# Generated at 2022-06-21 19:36:22.690804
# Unit test for constructor of class Map
def test_Map():
    m = Map({1: Sum(1), 2: Sum(2)})
    assert m.value[1] == Sum(1)
    assert m.value[2] == Sum(2)

# Generated at 2022-06-21 19:36:25.694403
# Unit test for constructor of class Last
def test_Last():
    m = Last(1)
    n = Last(2)
    assert m.value == 1
    assert n.value == 2
    assert m != n
    assert m.concat(m) == m
    assert m.fold(lambda x: x) == 1
    assert n.fold(lambda x: x) == 2


# Generated at 2022-06-21 19:36:29.204630
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True), 'All constructor should create All instance with value'
    assert All(True) != All(False), 'All constructor should create All instance with value'


# Generated at 2022-06-21 19:36:30.639035
# Unit test for constructor of class Last
def test_Last():
    last = Last(2)
    assert last.value == 2


# Generated at 2022-06-21 19:36:33.362328
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    assert str(Last('hello')) == 'Last[value=hello]'


# Generated at 2022-06-21 19:36:35.748527
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-21 19:36:40.868144
# Unit test for method concat of class Sum
def test_Sum_concat():
    s1 = Sum(1)
    s2 = Sum(2)
    s3 = s1.concat(s2)
    assert s3.value == 3
    assert type(s3) is Sum


# Generated at 2022-06-21 19:36:47.624451
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)).value is False
    assert All(True).concat(All(True)).value is True
    assert All(False).concat(All(True)).value is False
    assert All(False).concat(All(False)).value is False


# Generated at 2022-06-21 19:36:49.567254
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(4).concat(Last(5)).value == 5
    assert Last(5).concat(Last(4)).value == 4


# Generated at 2022-06-21 19:36:51.006968
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert 'Min[value=10]' == str(Min(10))


# Generated at 2022-06-21 19:36:53.639415
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(7)) == Min(1).concat(Min(3))



# Generated at 2022-06-21 19:37:01.685176
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value is True
    assert All(False).concat(All(False)).value is False
    assert All(True).concat(All(False)).value is False
    assert All(False).concat(All(True)).value is False
    assert All(None).concat(All(True)).value is False
    assert All(None).concat(All(False)).value is False
    assert All(True).concat(All(None)).value is False
    assert All(False).concat(All(None)).value is False

# Generated at 2022-06-21 19:37:05.201525
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({})) == "Map[value={}]"
    d = {'a':1, 'b':2, 'c':3}
    assert str(Map(d)) == "Map[value={'a': 1, 'b': 2, 'c': 3}]"


# Generated at 2022-06-21 19:37:10.255751
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({1: Sum(1), 2: Sum(2)}).concat(
        Map({1: Sum(1), 2: Sum(2)})
    ).value == {
        1: Sum(2),
        2: Sum(4)
    }



# Generated at 2022-06-21 19:37:11.686146
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup(1).fold(lambda x: x) == 1



# Generated at 2022-06-21 19:37:13.548272
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-21 19:37:18.584238
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({"val": Sum(1)})) == "Map[value={'val': Sum[value=1]}]"


# Generated at 2022-06-21 19:37:21.243967
# Unit test for method __str__ of class Map
def test_Map___str__():
    # Arrange
    actual = Map({'sum': Sum(2)})
    # Act
    # Assert
    assert str(actual) == 'Map[value={sum: Sum[value=2]}]'

# Generated at 2022-06-21 19:37:23.770777
# Unit test for constructor of class One
def test_One():
    o = One(1)
    assert o.value == 1
    assert o.neutral_element == False
    assert o.fold(lambda v: v * 2) == 2


# Generated at 2022-06-21 19:37:25.440518
# Unit test for constructor of class Map
def test_Map():
    assert Map({"q": Sum(10)}).value['q'].value == 10


# Generated at 2022-06-21 19:37:26.621236
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(42)) == 'Fist[value=42]'



# Generated at 2022-06-21 19:37:27.909421
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(10)) == 'Fist[value=10]'


# Generated at 2022-06-21 19:37:31.935206
# Unit test for method __str__ of class Map
def test_Map___str__():  # pragma: no cover
    value = {1: Sum(1), 2: Sum(2)}
    A = Map(value)
    assert A.__str__() == 'Map[value={1: Sum[value=1], 2: Sum[value=2]}]'



# Generated at 2022-06-21 19:37:35.309828
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)
    assert Semigroup(1).fold(lambda x: x + 1) == 2


# Generated at 2022-06-21 19:37:38.687329
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(bool())) == 'One[value=False]'
    assert str(One(1)) == 'One[value=1]'
    assert str(One('')) == 'One[value=]'


# Generated at 2022-06-21 19:37:40.671578
# Unit test for constructor of class All
def test_All():
    """
    Unit test for constructor of class All
    """
    all = All(True).fold(bool)
    assert all is True


# Generated at 2022-06-21 19:37:51.435125
# Unit test for method __str__ of class Min
def test_Min___str__():  # pragma: no cover
    assert str(Min(3.4)) == 'Min[value=3.4]'


# Generated at 2022-06-21 19:38:02.496121
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert All(True).fold(bool) is True
    assert All(False).fold(bool) is False
    assert First(1).fold(int) is 1
    assert First(0).fold(int) is 0
    assert Last(1).fold(int) is 1
    assert Last(0).fold(int) is 0
    assert Map({1: First(1), 2: First(2)}).fold(dict) == {1: 1, 2: 2}
    assert Map({1: First(0), 2: First(0)}).fold(dict) == {1: 0, 2: 0}
    assert Max(1).fold(int) is 1
    assert Max(0).fold(int) is 0
    assert Min(1).fold(int) is 1
    assert Min(0).fold(int) is 0

# Generated at 2022-06-21 19:38:04.351834
# Unit test for method __str__ of class One
def test_One___str__():
    value = 1
    one = One(value)
    expected = "One[value=1]"
    assert one.__str__() == expected


# Generated at 2022-06-21 19:38:06.059717
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-21 19:38:08.774076
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(True).__str__() == 'One[value=True]'


# Generated at 2022-06-21 19:38:11.244238
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(0) == Semigroup(0)
    assert not Semigroup(0) == Semigroup(1)
    assert not Semigroup(0) == None



# Generated at 2022-06-21 19:38:12.523148
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'



# Generated at 2022-06-21 19:38:15.067131
# Unit test for method concat of class First
def test_First_concat():
    f1 = First(10)
    f2 = First(9)

    assert f1.concat(f2) == f1


# Generated at 2022-06-21 19:38:16.606124
# Unit test for method __str__ of class All
def test_All___str__():
    assert(str(All(True)) == 'All[value=True]')


# Generated at 2022-06-21 19:38:18.359543
# Unit test for method __str__ of class One
def test_One___str__():
    assert repr(One(True)) == "One[value=True]"
    assert repr(One(False)) == "One[value=False]"



# Generated at 2022-06-21 19:38:26.281856
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)



# Generated at 2022-06-21 19:38:32.457863
# Unit test for method concat of class Map
def test_Map_concat():
    monoid_map_1 = Map({'key_1': Sum(1), 'key_2': Sum(2), 'key_3': Sum(3)})
    monoid_map_2 = Map({'key_1': Sum(1), 'key_2': Sum(2), 'key_3': Sum(3)})
    monoid_map_3 = Map({'key_1': Sum(2), 'key_2': Sum(4), 'key_3': Sum(6)})
    assert monoid_map_1.concat(monoid_map_2) == monoid_map_3

# Generated at 2022-06-21 19:38:33.611620
# Unit test for constructor of class All
def test_All():
    assert All(1)



# Generated at 2022-06-21 19:38:38.960374
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    Unit test for methods concat of class Sum
    """

    assert Sum(1).concat(Sum(2)).value == Sum(3).value
    assert Sum(9).concat(Sum(-2)).value == Sum(7).value
    assert Sum(1).concat(Sum(-2)).value == Sum(-1).value



# Generated at 2022-06-21 19:38:43.195125
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'
    assert str(One(None)) == 'One[value=None]'


# Generated at 2022-06-21 19:38:45.349395
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-21 19:38:48.281950
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'a': Sum(1), 'b': Sum(2)})) == "Map[value={'a': Sum[value=1], 'b': Sum[value=2]}]"


# Generated at 2022-06-21 19:38:57.017310
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1, 'First return value 1 for semigroup value 1 with Last'
    assert Last(1).value == 1, 'First return value 1 for semigroup value 1 with Last'
    assert Last('test').value == 'test', 'First return value test for semigroup value test with Last'
    assert Last(True).value == True, 'First return value True for semigroup value True with Last'
    assert Last(False).value == False, 'First return value False for semigroup value False with Last'
    assert Last(None).value == None, 'First return value None for semigroup value None with Last'
    assert Last(1 == 1).value == True, 'First return value True for semigroup value 1 == 1 with Last'

# Generated at 2022-06-21 19:39:00.430095
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(10).concat(Max(20)) == Max(20)
    assert Max(20).concat(Max(10)) == Max(20)
    assert Max(10).concat(Max(10)) == Max(10)


# Generated at 2022-06-21 19:39:02.460189
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-21 19:39:10.437760
# Unit test for method __str__ of class Last
def test_Last___str__():
    last = Last(1)
    assert str(last) == 'Last[value=1]'

# Generated at 2022-06-21 19:39:12.908189
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(3), 'b':Sum(4)}) == Map({'a': Sum(3), 'b':Sum(4)})

# Generated at 2022-06-21 19:39:14.483266
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    assert str(One(1)) == "One[value=1]"


# Generated at 2022-06-21 19:39:19.179981
# Unit test for constructor of class Map
def test_Map():
    m1 = Map({1: Sum(1)})
    m2 = Map({1: Sum(2)})
    m3 = m1.concat(m2)
    m4 = m2.concat(m1)
    assert m3 == m4

# Generated at 2022-06-21 19:39:23.538999
# Unit test for method __str__ of class Map
def test_Map___str__():  # pragma: no cover
    assert str(Map({'a': Sum(2), 'b': Sum(3)})) == "Map[value={'a': Sum[value=2], 'b': Sum[value=3]}]"



# Generated at 2022-06-21 19:39:25.447050
# Unit test for constructor of class Sum
def test_Sum():
    for _ in range(10000):
        x = random.randint(-1000, 1000)
        assert Sum(x).value == x


# Generated at 2022-06-21 19:39:31.053180
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Unit test for method fold of class Semigroup

    :return: True if test passed, False otherwise
    :rtype: bool
    """
    my_sum = Sum(2)
    my_mul = Semigroup()

    assert my_sum.fold(lambda x: x * 3) == 6
    assert my_mul.fold(lambda x: x * 3) == 3

    return True



# Generated at 2022-06-21 19:39:35.220281
# Unit test for method concat of class Map
def test_Map_concat():
    assert Map({
        'key_first': First('first'),
        'key_last': Last('last')
    }).concat(Map({
        'key_first': First('new_first'),
        'key_last': Last('new_last')
    })) == Map({
        'key_first': First('first'),
        'key_last': Last('new_last')
    })



# Generated at 2022-06-21 19:39:44.068883
# Unit test for constructor of class All
def test_All():
    assert All(True).concat(All(False)).fold(bool) == False
    assert All(False).concat(All(True)).fold(bool) == False
    assert All(0).concat(All(1)).fold(bool) == False
    assert All('').concat(All('foobar')).fold(bool) == False
    assert All('foobar').concat(All('')).fold(bool) == False
    assert All([]).concat(All(['foobar'])).fold(bool) == False
    assert All({}).concat(All({'foo': 'bar'})).fold(bool) == False

# Unit tests for concat() of class All

# Generated at 2022-06-21 19:39:49.181778
# Unit test for constructor of class Min
def test_Min():
    min1 = Min(1)
    min2 = Min(2)
    min3 = Min(3)
    min4 = Min(4)

    assert min1.value == 1
    assert min2.value == 2
    assert min3.value == 3
    assert min4.value == 4

test_Min()

# Generated at 2022-06-21 19:40:01.607593
# Unit test for constructor of class All
def test_All():  # pragma: no cover
    assert All(True).value is True
    assert All(False).value is False
    assert All(1).value is True
    assert All(0).value is False
    assert All('').value is False
    assert All('string').value is True
    assert All([]).value is False
    assert All([1]).value is True
    assert All((1, 2)).value is True


# Generated at 2022-06-21 19:40:03.499037
# Unit test for constructor of class Min
def test_Min():
    actual = Min(1) # ctor
    expected = 1
    assert actual.value == expected


# Generated at 2022-06-21 19:40:05.245152
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False


# Generated at 2022-06-21 19:40:06.695342
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True) != All(False)


# Generated at 2022-06-21 19:40:07.766701
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)


# Generated at 2022-06-21 19:40:12.539935
# Unit test for constructor of class Map
def test_Map():  # pragma: no cover
    """
    Unit test for constructor of Map
    """

    assert Map(dict(a=1)) == Map(dict(a=1))

# Generated at 2022-06-21 19:40:16.572669
# Unit test for method concat of class One
def test_One_concat():
    one = One(3)
    other_one = One(4)
    assert one.concat(other_one).value == 3
    one = One(False)
    other_one = One(True)
    assert one.concat(other_one).value == True


# Generated at 2022-06-21 19:40:18.141836
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(5)) == Sum(7)



# Generated at 2022-06-21 19:40:21.196496
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(2) == Semigroup(2)
    assert Semigroup('1') == Semigroup('1')
    assert not Semigroup(1) == Semigroup(2)


# Generated at 2022-06-21 19:40:22.605817
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == "Max[value=1]"


# Generated at 2022-06-21 19:40:31.111128
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-21 19:40:36.790988
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    assert str(Last(1)) == 'Last[value=1]'
    assert str(Last(2)) == 'Last[value=2]'
    assert str(Last('3')) == 'Last[value=3]'
    
    

# Generated at 2022-06-21 19:40:40.730835
# Unit test for method __str__ of class Min
def test_Min___str__():  # pragma: no cover
    actual = str(Min(3))
    assert actual == 'Min[value=3]'


# Generated at 2022-06-21 19:40:42.115730
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == "Min[value=1]"


# Generated at 2022-06-21 19:40:45.199179
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(2).concat(Max(3)) == Max(3)


# Generated at 2022-06-21 19:40:49.985277
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    Test fold method of Semigroup class
    """
    assert Sum(1).fold(lambda x: x + 1) == 2
    assert All(True).fold(lambda x: not x) is False
    assert All(False).fold(lambda x: not x) is True
    assert First(1).fold(lambda x: x + 1) == 1
    assert Min(9).fold(lambda x: x + 1) == 10

# Generated at 2022-06-21 19:40:51.960698
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    """
    Unit test for Semigroup constructor
    """

    assert Semigroup(10) == Semigroup(10)

# Generated at 2022-06-21 19:40:52.982326
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)

# Generated at 2022-06-21 19:40:59.692378
# Unit test for constructor of class All
def test_All():
    all_int = All(1)
    all_float = All(1.1)
    all_bool = All(True)
    all_string = All('hello')
    all_none = All(None)

    assert all_int.value == 1
    assert all_float.value == 1.1
    assert all_bool.value == True
    assert all_string.value == 'hello'
    assert all_none.value == None


# Generated at 2022-06-21 19:41:01.789286
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(False) == One(False)



# Generated at 2022-06-21 19:41:20.136930
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1).value == 1
    assert isinstance(Semigroup(1), Semigroup)



# Generated at 2022-06-21 19:41:21.977227
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'


# Generated at 2022-06-21 19:41:26.463751
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({"a": Max(1), "b": Sum(2), "c": All(True)})) == "Map[value={'a': Max[value=1], 'b': Sum[value=2], 'c': All[value=True]}]"


# Generated at 2022-06-21 19:41:27.834822
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'


# Generated at 2022-06-21 19:41:29.797500
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).value == 1
    assert Min(1).concat(Min(1)).value == 1


# Generated at 2022-06-21 19:41:34.823174
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)


# Generated at 2022-06-21 19:41:37.599499
# Unit test for method concat of class One
def test_One_concat():
    one = One(True)
    other = One(False)
    assert one.concat(other).value == True
    assert one.value == True
    assert other.value == False


# Generated at 2022-06-21 19:41:39.751206
# Unit test for constructor of class First
def test_First():
    assert First(3).value == 3
    assert First('a').value == 'a'
    assert First([1, 2, 3]).value == [1, 2, 3]



# Generated at 2022-06-21 19:41:42.015827
# Unit test for method concat of class Sum
def test_Sum_concat():
    a = Sum(2)
    b = Sum(3)
    assert a.concat(b) == Sum(5)
    assert b.concat(a) == Sum(5)



# Generated at 2022-06-21 19:41:43.783709
# Unit test for method concat of class First
def test_First_concat():
    first1 = First(1)
    first2 = First(2)
    assert first1.concat(first2) == First(1)



# Generated at 2022-06-21 19:42:18.270993
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1), 'Function Sum failed'


# Generated at 2022-06-21 19:42:19.377823
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)


# Generated at 2022-06-21 19:42:22.357831
# Unit test for method concat of class One
def test_One_concat():
    x = One(True)
    y = One(False)
    assert x.concat(y) == One(True)
    assert y.concat(x) == One(True)



# Generated at 2022-06-21 19:42:26.891271
# Unit test for method concat of class Map
def test_Map_concat():
    a = Map({1: All(True), 2: All(True), 3: All(False)})
    b = Map({1: All(False), 2: All(True)})
    res = a.concat(b)
    assert isinstance(res, Map)
    assert isinstance(res.value, dict)
    assert res.value[1] == All(False)
    assert res.value[2] == All(True)
    assert res.value[3] == All(False)

# Generated at 2022-06-21 19:42:27.768462
# Unit test for constructor of class Max
def test_Max():  
    assert Max(3) == Max(3)


# Generated at 2022-06-21 19:42:30.082035
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(3)) == Sum(5)



# Generated at 2022-06-21 19:42:33.075057
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)
    assert Semigroup("a") == Semigroup("a")
    assert not Semigroup("a") == Semigroup("b")
    assert not Semigroup(1) == Semigroup("a")



# Generated at 2022-06-21 19:42:35.560446
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert(Min(12).__str__() == 'Min[value=12]')


# Generated at 2022-06-21 19:42:39.464627
# Unit test for method concat of class One
def test_One_concat():
    a = One(True)
    b = One(False)
    c = One(False)

    assert a.concat(b).concat(c) == One(True)
    assert b.concat(c).concat(a) == One(True)
    assert c.concat(a).concat(b) == One(True)


# Generated at 2022-06-21 19:42:45.884518
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert First(10).__str__() == 'Fist[value=10]'
    assert Last(10).__str__() == 'Last[value=10]'
    assert Sum(10).__str__() == 'Sum[value=10]'
    assert All(10).__str__() == 'All[value=10]'
    assert One(10).__str__() == 'One[value=10]'
    assert Min(10).__str__() == 'Min[value=10]'
    assert Max(10).__str__() == 'Max[value=10]'


# Generated at 2022-06-21 19:43:20.272944
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First(1)) == 'Fist[value=1]'



# Generated at 2022-06-21 19:43:22.710703
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({0: First(1)})
    m2 = Map({0: First(2)})
    assert m1.concat(m2).value.get(0).value == m1.value.get(0).value

# Generated at 2022-06-21 19:43:25.065489
# Unit test for constructor of class One
def test_One():
    one = One(True)
    assert one.value is True



# Generated at 2022-06-21 19:43:26.659487
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert Min(0).__str__() == 'Min[value=0]'


# Generated at 2022-06-21 19:43:30.550036
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(True) == Semigroup(True)
    assert Semigroup(True).value == True
    assert Semigroup(False).value == False


# Generated at 2022-06-21 19:43:33.858199
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True,)) == 'One[value=True]'
    assert str(One(None,)) == 'One[value=None]'
    assert str(One(False,)) == 'One[value=False]'


# Generated at 2022-06-21 19:43:36.127324
# Unit test for constructor of class Max
def test_Max():
    m = Max(1)
    print(m)
    m = Max(2)
    print(m)
    m = Max(1)
    print(m)



# Generated at 2022-06-21 19:43:37.915910
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last('c').concat(Last('a')).value == 'c'
    assert Last('c').concat(Last('d')).value == 'd'


# Generated at 2022-06-21 19:43:39.778445
# Unit test for constructor of class One
def test_One():
    X = One([1,2,3,4])
    Y = First([1,2,3,4])
    print(One)
    print(First)
    print(X)
    print(Y)

test_One()

# Generated at 2022-06-21 19:43:41.705475
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(5)) == 'Fist[value=5]'

