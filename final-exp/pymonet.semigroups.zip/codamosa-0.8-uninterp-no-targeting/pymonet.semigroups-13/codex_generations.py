

# Generated at 2022-06-21 19:34:22.701833
# Unit test for constructor of class Last
def test_Last():
    assert Last(3).value == 3


# Generated at 2022-06-21 19:34:28.522272
# Unit test for method concat of class Max
def test_Max_concat():
    s_1 = Max(1)
    s_2 = Max(2)
    s_3 = s_1.concat(s_2)
    assert s_3.value == 2

    s_4 = Max(2).concat(Max(1))
    assert s_4.value == 2


# Generated at 2022-06-21 19:34:31.868918
# Unit test for method __str__ of class One
def test_One___str__():
    """
    Hint:
        >>> str(One(1))
        'One[value={}]'
    """
    assert str(One(1)) == 'One[value=1]'



# Generated at 2022-06-21 19:34:33.265378
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(10)) == "Max[value=10]"


# Generated at 2022-06-21 19:34:37.320658
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(2).fold(str) == Sum(3).fold(str)
    assert Sum(2).fold(str) == '2'
    assert Sum(2).fold(int) == 2
    assert Sum(2).fold(float) == 2.0
    assert Sum(2).fold(lambda x: x + 3) == 5



# Generated at 2022-06-21 19:34:40.294417
# Unit test for constructor of class One
def test_One():
    """
    Test the constructor of class One
    """
    one = One(True)
    assert one == One(True)

    one = One(False)
    assert one == One(False)


# Generated at 2022-06-21 19:34:41.544833
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(2).concat(Last(3)) == Last(3)



# Generated at 2022-06-21 19:34:43.943611
# Unit test for constructor of class All
def test_All():
    """
    Test for constructor of class All
    """

    a = All(5)
    assert a.value == 5

    a = All(False)
    assert a.value is False


# Generated at 2022-06-21 19:34:48.530143
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    Unit test for constructor of class Semigroup
    """

    semigroup = Semigroup(ImmutableList(1, 2, 3))
    assert semigroup.value == ImmutableList(1, 2, 3), 'semigroup value should be [1, 2, 3]'



# Generated at 2022-06-21 19:34:54.955782
# Unit test for method concat of class All
def test_All_concat():
    All(True).concat(All(True)) == All(True)
    All(True).concat(All(False)) == All(False)
    All(False).concat(All(True)) == All(False)
    All(False).concat(All(False)) == All(False)


# Generated at 2022-06-21 19:35:03.942531
# Unit test for constructor of class Min
def test_Min():
    assert Min(15) == Min(15)
    assert Min(15) != Min(16)



# Generated at 2022-06-21 19:35:07.226744
# Unit test for method __str__ of class Last
def test_Last___str__():
    value = random.choice([0, True, False, "", "Hello"])
    result = Last(value)
    assert result.__str__() == "Last[value={}]".format(value)


# Generated at 2022-06-21 19:35:08.055957
# Unit test for method __str__ of class All
def test_All___str__():
    assert All(True).__str__() == "All[value=True]"


# Generated at 2022-06-21 19:35:12.306612
# Unit test for method __str__ of class Min
def test_Min___str__():
    # Case 1
    x = Min(1)
    assert x.__str__() == 'Min[value=1]'
    # Case 2
    x = Min(1.1)
    assert x.__str__() == 'Min[value=1.1]'
    # Case 3
    x = Min('foo')
    assert x.__str__() == 'Min[value=foo]'



# Generated at 2022-06-21 19:35:15.072180
# Unit test for method concat of class Max
def test_Max_concat():
    s1 = Max(1)
    s2 = Max(2)
    assert s1.concat(s2) == Max(2)
    assert s2.concat(s1) == Max(2)



# Generated at 2022-06-21 19:35:16.290653
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(5)) == 'Fist[value=5]'


# Generated at 2022-06-21 19:35:17.704320
# Unit test for method __str__ of class Min
def test_Min___str__(): # pragma: no cover
    assert str(Min(value=200)) == "Min[value=200]"


# Generated at 2022-06-21 19:35:22.004267
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(True)) == One(True)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)


# Generated at 2022-06-21 19:35:24.620420
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'
    assert str(Sum(1.1)) == 'Sum[value=1.1]'
    assert str(Sum('a')) == 'Sum[value=a]'
    assert str(Sum(True)) == 'Sum[value=True]'
    assert str(Sum(None)) == 'Sum[value=None]'



# Generated at 2022-06-21 19:35:31.035294
# Unit test for constructor of class Map
def test_Map():
    dict1 = {"key1": "value1", "key2": "value2"}
    dict2 = {"key3": "value3", "key4": "value4"}
    dict_result = {"key1": "value1", "key2": "value2", "key3": "value3", "key4": "value4"}
    mapp = Map(dict1)
    mapp2 = Map(dict2)
    result = mapp.concat(mapp2)
    assert result.value == dict_result


# Generated at 2022-06-21 19:35:39.053389
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(2).concat(Sum(3)) == Sum(5)
    assert Sum(4).concat(Sum(4)) == Sum(8)



# Generated at 2022-06-21 19:35:42.170893
# Unit test for constructor of class Last
def test_Last():

    l = [1, 2, 3]
    last = Last(l)

    assert last.value == l
    assert last.__str__() == "Last[value=[1, 2, 3]]"


# Generated at 2022-06-21 19:35:44.247867
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'



# Generated at 2022-06-21 19:35:47.486820
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Sum(1) != All(1)
    assert Min(1) != Last(1)
    assert Max(1) != First(1)
    assert Map({'name': 'dmitry'}) != Map({'name': 'marina'})


# Generated at 2022-06-21 19:35:49.684473
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-21 19:35:55.338686
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(2).concat(Max(1)) == Max(2)
    assert Max(1).concat(Max(1)) == Max(1)
    assert Max(1).concat(Max(-1)) == Max(1)


# Generated at 2022-06-21 19:35:57.602801
# Unit test for method concat of class Sum
def test_Sum_concat():
    a = Sum(1)
    b = Sum(2)
    assert str(a.concat(b)) == 'Sum[value=3]'



# Generated at 2022-06-21 19:36:00.139228
# Unit test for method __str__ of class Last
def test_Last___str__():
    """
    Test method __str__ of class Last.
    """
    assert str(Last(value=True)) == 'Last[value=True]'


# Generated at 2022-06-21 19:36:02.532593
# Unit test for constructor of class Last
def test_Last():  # pragma: no cover
    assert Last(1).value == 1
    assert Last(2).value == 2



# Generated at 2022-06-21 19:36:04.707921
# Unit test for method __str__ of class First
def test_First___str__():
    value1 = First("test_value")
    assert str(value1) == 'Fist[value=test_value]'


# Generated at 2022-06-21 19:36:12.945326
# Unit test for method __str__ of class Last
def test_Last___str__():
    val = Last(1)
    rep = 'Last[value=1]'
    assert str(val) == rep


# Generated at 2022-06-21 19:36:23.019491
# Unit test for method __str__ of class Map
def test_Map___str__():
    test_Map = Map(
        {
            'key_1': Sum(1),
            'key_2': All(True),
            'key_3': One(True),
            'key_4': First('first'),
            'key_5': Last('last'),
            'key_6': Max(20),
            'key_7': Min(10),
        }
    )
    assert str(test_Map) == 'Map[value={\'key_1\': Sum[value=1], \'key_2\': All[value=True], \'key_3\': One[value=True], \'key_4\': Fist[value=first], \'key_5\': Last[value=last], \'key_6\': Max[value=20], \'key_7\': Min[value=10]}]'

# Unit test

# Generated at 2022-06-21 19:36:27.961527
# Unit test for method __str__ of class Map
def test_Map___str__(): # pragma: no cover
    """
    :return: if str representation not equals string
    :rtype: bool
    """
    return str(Map({'foo': First('bar')})) != 'Map[value={foo: Fist[value=bar]}]'



# Generated at 2022-06-21 19:36:29.888341
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert (str(Sum(1)) == 'Sum[value=1]')


# Generated at 2022-06-21 19:36:31.330442
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-21 19:36:34.835955
# Unit test for method concat of class First
def test_First_concat():
    assert First("hello").concat(First("world")) == First("hello")
    assert First("hello").concat(First("world")).value == "hello"



# Generated at 2022-06-21 19:36:37.580239
# Unit test for method concat of class Min
def test_Min_concat():
    x = Min(1)
    y = Min(2)
    expected = Min(1)
    result = x.concat(y)
    assert result == expected

# Generated at 2022-06-21 19:36:39.339688
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(True)) == 'First[value=True]'



# Generated at 2022-06-21 19:36:41.381272
# Unit test for constructor of class Sum
def test_Sum():
    init_val = 1
    after_init = Sum(init_val)
    assert after_init.value == init_val


# Generated at 2022-06-21 19:36:50.602099
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda x: x + 1) == 2
    assert All(True).fold(lambda x: x and False) == False
    assert One(True).fold(lambda x: x or False) == True
    assert First("first").fold(lambda x: "second") == "first"
    assert Last("first").fold(lambda x: "second") == "second"
    assert Max(1).fold(lambda x: 2) == 2
    assert Min(1).fold(lambda x: 2) == 1
test_Semigroup_fold()



# Generated at 2022-06-21 19:36:55.750984
# Unit test for constructor of class Last
def test_Last():
    try:
        Last(Last(Last("hello")))
    except Exception:
        pytest.fail("Should not fail")



# Generated at 2022-06-21 19:37:05.677996
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'
    assert str(One(0)) == 'One[value=0]'
    assert str(One(1)) == 'One[value=1]'
    assert str(One('a')) == 'One[value=a]'
    assert str(One('b')) == 'One[value=b]'
    assert str(One([1, 2, 3])) == 'One[value=[1, 2, 3]]'
    assert str(One([4, 5, 6])) == 'One[value=[4, 5, 6]]'
    assert str(One({5, 4, 3})) == 'One[value={3, 4, 5}]'

# Generated at 2022-06-21 19:37:07.400914
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({})) == 'Map[value={}]'



# Generated at 2022-06-21 19:37:09.770150
# Unit test for constructor of class Map
def test_Map():
    assert type(Map({"key": Sum(1)}).value) == dict

# Generated at 2022-06-21 19:37:12.529971
# Unit test for method __str__ of class First
def test_First___str__():
    assert First("1").__str__() == 'Fist[value=1]'
    assert First(1).__str__() == 'Fist[value=1]'



# Generated at 2022-06-21 19:37:15.794752
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last('1')) == 'Last[value=1]'
    assert str(Last(1)) == 'Last[value=1]'
    assert str(Last(True)) == 'Last[value=True]'


# Generated at 2022-06-21 19:37:17.507758
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(3.14)) == "Sum[value=3.14]"


# Generated at 2022-06-21 19:37:18.492569
# Unit test for constructor of class Min
def test_Min():
    assert Min(3)


# Generated at 2022-06-21 19:37:21.164260
# Unit test for method concat of class First
def test_First_concat():
    f = First(10)
    g = First(20)
    assert f.concat(g).value == 10
    assert str(f) == "Fist[value=10]"



# Generated at 2022-06-21 19:37:22.378646
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)


# Generated at 2022-06-21 19:37:35.991041
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    import pytest
    assert str(Sum(5)) == 'Sum[value=5]'
    assert str(Sum(0)) == 'Sum[value=0]'
    assert str(Sum(-5)) == 'Sum[value=-5]'
    assert str(Sum(5.5)) == 'Sum[value=5.5]'
    assert str(Sum(0.0)) == 'Sum[value=0.0]'
    assert str(Sum(-5.5)) == 'Sum[value=-5.5]'
    assert not str(Sum(5)) != 'Sum[value=5]'
    assert not str(Sum(0)) != 'Sum[value=0]'
    assert not str(Sum(-5)) != 'Sum[value=-5]'
    assert not str(Sum(5.5)) != 'Sum[value=5.5]'
    assert not str

# Generated at 2022-06-21 19:37:38.591289
# Unit test for method __str__ of class One
def test_One___str__():
    # given
    one = One(False)

    # when
    result = one.__str__()

    # then
    assert result == 'One[value=False]'



# Generated at 2022-06-21 19:37:40.276332
# Unit test for method __str__ of class Max
def test_Max___str__():  # pragma: no cover
    assert str(Max(1)) == 'Max[value=1]'


# Generated at 2022-06-21 19:37:41.894733
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(0) + Last(1) == Last(1)

# Generated at 2022-06-21 19:37:44.078054
# Unit test for constructor of class Min
def test_Min():
    semigroup = Min(1)
    assert semigroup.value == 1
    assert semigroup.neutral_element == float('inf')



# Generated at 2022-06-21 19:37:49.121762
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    >>> Semigroup(1).fold(math.sqrt)
    1.0
    >>> Semigroup([1, 2, 3]).fold(lambda x: x[0] + x[-1])
    4
    """
    pass


# Generated at 2022-06-21 19:37:57.867475
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    sum_10 = Sum(10)
    sum_20 = Sum(20)
    sum_10_duplicate = Sum(10)
    assert(sum_10 == sum_10)
    assert(sum_10 == sum_10_duplicate)
    assert(sum_20 == sum_20)
    assert(sum_10 != sum_20)
    assert(sum_10_duplicate != sum_20)
    assert(sum_20 != sum_10_duplicate)


# Generated at 2022-06-21 19:38:00.023680
# Unit test for constructor of class One
def test_One():
    assert One(True)
    assert One(False)
    assert One(1)
    assert One("")



# Generated at 2022-06-21 19:38:03.208487
# Unit test for method concat of class Sum
def test_Sum_concat():
    a = Sum(1)
    b = Sum(2)
    assert a.concat(b) == Sum(3)  # pragma: no cover
    assert a + b == Sum(3)


# Generated at 2022-06-21 19:38:05.437571
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert Last(1) != 1



# Generated at 2022-06-21 19:38:11.244829
# Unit test for method __str__ of class Map

# Generated at 2022-06-21 19:38:16.360588
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    assert All(True).concat(All(True)).value == True
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
    assert All(False).concat(All(False)).value == False


# Generated at 2022-06-21 19:38:23.352657
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)).concat(Max(3)) == Max(3)
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(3).concat(Max(2)) == Max(3)
    assert Max.neutral().concat(Max(2)) == Max(2)
    assert Max(3).concat(Max.neutral()).concat(Max(4)) == Max(4)


# Generated at 2022-06-21 19:38:25.389568
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert Sum(1).__str__() == 'Sum[value=1]'


# Generated at 2022-06-21 19:38:27.850953
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)
    assert Sum(1).concat(Sum(Sum.neutral_element)) == Sum(1)



# Generated at 2022-06-21 19:38:29.776319
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).value == 1
    assert Min(2).concat(Min(1)).value == 1


# Generated at 2022-06-21 19:38:34.433772
# Unit test for method concat of class All
def test_All_concat():
    """
    test concat method on class All
    """

    assert(All(True).concat(All(True)).value == True)
    assert(All(False).concat(All(False)).value == False)
    assert(All(True).concat(All(0)).value == False)



# Generated at 2022-06-21 19:38:35.902914
# Unit test for constructor of class Last
def test_Last():
    assert Last(0).value == 0



# Generated at 2022-06-21 19:38:38.070048
# Unit test for method __str__ of class Sum
def test_Sum___str__():  # pragma: no cover
    assert str(Sum(2)) == 'Sum[value=2]'


# Generated at 2022-06-21 19:38:39.459692
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)


# Generated at 2022-06-21 19:38:47.231667
# Unit test for constructor of class First
def test_First():
    assert First(0) is not None


# Generated at 2022-06-21 19:38:52.429609
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    a = Semigroup(value=1)
    b = Semigroup(value=1)
    c = Semigroup(value=2)

    assert a == a
    assert b == b
    assert c == c
    assert a == b
    assert b == a
    assert a is not b
    assert not a == c
    assert not b == c
    assert not c == a
    assert not c == b



# Generated at 2022-06-21 19:38:53.655302
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'



# Generated at 2022-06-21 19:38:55.705700
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    s0 = Sum(0)
    s1 = Sum(1)

    assert s0 == s0
    assert s1 == s1
    assert s0 != s1



# Generated at 2022-06-21 19:38:58.631192
# Unit test for method concat of class One
def test_One_concat():
    assert One(0).concat(One(1)) == One(1)
    assert One(1).concat(One(0)) == One(1)
    assert One(1).concat(One(1)) == One(1)


# Generated at 2022-06-21 19:38:59.871533
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True

# Generated at 2022-06-21 19:39:03.997715
# Unit test for method concat of class One
def test_One_concat():
    assert One(1).concat(One(0)) == One.neutral()
    assert One(1).concat(One(1)) == One(1)
    assert One(1).concat(One(100)) == One(1)



# Generated at 2022-06-21 19:39:07.052847
# Unit test for constructor of class Max
def test_Max():                                                 # pragma: no cover
    max_res = Max(13)
    assert max_res.value == 13



# Generated at 2022-06-21 19:39:08.341338
# Unit test for constructor of class Max
def test_Max():
    assert Max(2).value == 2


# Generated at 2022-06-21 19:39:10.241329
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    assert str(One(False)) == 'One[value=False]'



# Generated at 2022-06-21 19:39:25.693783
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-21 19:39:34.992512
# Unit test for constructor of class Last
def test_Last():
    assert Last(1) == Last(1)
    assert Last(1) != Last(2)
    assert First(1) == First(1)
    assert First(1) != First(2)
    assert All(True) == All(True)
    assert All(True) != All(False)
    assert One(False) == One(False)
    assert One(False) != One(True)
    assert One(True) == One(True)
    assert One(True) != One(False)
    assert Map({'a': First(2), 'b': Sum(2)}) == Map({'a': First(2), 'b': Sum(2)})
    assert Map({'a': First(1)}) != Map({'a': First(2)})
    assert Sum(2) == Sum(2)

# Generated at 2022-06-21 19:39:40.725220
# Unit test for method concat of class Min
def test_Min_concat():
    """
    In mathematics, concat is a binary operation that takes two elements and combines them into a third element.
    """
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(1).concat(Min(1)) == Min(1)


# Generated at 2022-06-21 19:39:42.478925
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(4).concat(Min(5)) == Min(4)



# Generated at 2022-06-21 19:39:49.999494
# Unit test for method concat of class All
def test_All_concat():
    case_1 = All(True).concat(All(False))
    case_2 = All(False).concat(All(True))
    case_3 = All(True).concat(All(True))
    case_4 = All(False).concat(All(False))
    assert case_1.value == False
    assert case_2.value == False
    assert case_3.value == True
    assert case_4.value == False


# Generated at 2022-06-21 19:39:52.180118
# Unit test for constructor of class Last
def test_Last():
    last = Last("Ciao")
    assert last.value == "Ciao"


# Generated at 2022-06-21 19:39:53.375684
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-21 19:39:54.522069
# Unit test for constructor of class Last
def test_Last():
    assert Last('a').value == 'a'


# Generated at 2022-06-21 19:39:56.464410
# Unit test for method __str__ of class One
def test_One___str__():
    assert(str(One(False)) == 'One[value=False]')



# Generated at 2022-06-21 19:39:58.233730
# Unit test for constructor of class One
def test_One():
    one_value = One(True)
    assert one_value.value == True


# Generated at 2022-06-21 19:40:35.756917
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)).value == 1
    assert First(1).concat(First(0)).value == 1
    assert First(0).concat(First(1)).value == 0
    assert First(0).concat(First(0)).value == 0
    assert First(None).concat(First(1)).value is None
    assert First(1).concat(First(None)).value == 1
    assert First('hello').concat(First('world')).value == 'hello'
    assert First('hello').concat(First('world')).value == 'hello'
    assert First({'hello': 'world'}).concat(First({'world': 'hello'})).value == {'hello': 'world'}

test_First_concat()


# Generated at 2022-06-21 19:40:38.119414
# Unit test for method concat of class One
def test_One_concat():
    """
    Test for method concat
    """
    assert One(True).concat(One(True)) == One(True)
    assert One(False).concat(One(False)) == One(False)
    assert One(True).concat(One(False)) == One(True)
    assert One(False).concat(One(True)) == One(True)


# Generated at 2022-06-21 19:40:48.240331
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    # fold will return the value
    assert Sum(1).fold(lambda x: x) == 1
    assert All(True).fold(lambda x: x) == True
    assert One(False).fold(lambda x: x) == False
    assert First(1).fold(lambda x: x) == 1
    assert Last(1).fold(lambda x: x) == 1
    assert Map({1: Sum(2)}).fold(lambda x: x) == {1: Sum(2)}
    assert Max(-2).fold(lambda x: x) == -2
    assert Min(-2).fold(lambda x: x) == -2


# Generated at 2022-06-21 19:40:49.563528
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(10)) == 'Max[value=10]'



# Generated at 2022-06-21 19:40:54.801593
# Unit test for method concat of class One
def test_One_concat():
    """
    >>> a = One(True)
    >>> b = One(False)
    >>> a.concat(b)
    One[value=True]
    >>> a = One(False)
    >>> b = One(True)
    >>> a.concat(b)
    One[value=True]
    >>> a = One(False)
    >>> b = One(False)
    >>> a.concat(b)
    One[value=False]
    """
    pass


# Generated at 2022-06-21 19:40:58.841102
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    :param semigroup: semigroup
    :type semigroup: Semigroup
    :returns: semigroup value
    :rtype: Semigroup
    """
    semigroup = Semigroup(1)
    assert semigroup.value == 1



# Generated at 2022-06-21 19:41:02.391457
# Unit test for constructor of class First
def test_First():
    with pytest.raises(TypeError) as error:
        First()
    assert '__init__()' in str(error.value)
    assert 'missing' in str(error.value)


# Generated at 2022-06-21 19:41:06.208077
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)



# Generated at 2022-06-21 19:41:10.978805
# Unit test for method concat of class All
def test_All_concat():
    result = All(True).concat(All(True))
    assert result.value == True, "Should be True."
    result = All(True).concat(All(False))
    assert result.value == False, "Should be False."
    result = All(False).concat(All(False))
    assert result.value == False, "Should be False."
    result = All(False).concat(All(False))
    assert result.value == False, "Should be False."

# Generated at 2022-06-21 19:41:21.383193
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    # test if method fold of class Semigroup return value
    assert Sum(1).fold(lambda a: a) == 1
    assert First(1).fold(lambda a: a) == 1
    assert Last(1).fold(lambda a: a) == 1
    assert Map({'a': Sum(1)}).fold(lambda a: a) == {'a': Sum(1)}
    assert All(True).fold(lambda a: a) is True
    assert One(True).fold(lambda a: a) is True
    assert Max(1).fold(lambda a: a) == 1
    assert Min(1).fold(lambda a: a) == 1
    # test if method fold of class Semigroup return different type
    assert type(Sum(1).fold(lambda a: a)) == int

# Generated at 2022-06-21 19:41:54.348243
# Unit test for method concat of class Max
def test_Max_concat():
    max_one = Max(1)
    max_zero = Max(0)
    max_result = max_one.concat(max_zero)
    assert max_result.value == 1


# Generated at 2022-06-21 19:42:00.174838
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert (
        Semigroup(4).fold(lambda v: v + 1)
        == Last(1).fold(lambda v: v + 1)
        == First(4).fold(lambda v: v + 1)
        == Sum(4).fold(lambda v: v + 1)
        == All(True).fold(lambda v: v + 1)
        == One(False).fold(lambda v: v + 1)
        == Max(5).fold(lambda v: v + 1)
        == Min(5).fold(lambda v: v + 1)
    )
    assert (
        Map({1: First(2), 3: First(5)}).concat(Map({1: First(5), 3: First(5)}))
        == Map({1: First(5), 3: First(5)})
    )

# Unit test

# Generated at 2022-06-21 19:42:01.590960
# Unit test for constructor of class All
def test_All():
    assert All.neutral() == All(True)



# Generated at 2022-06-21 19:42:02.856003
# Unit test for constructor of class Last
def test_Last():
    last = Last(1)
    assert last.value == 1



# Generated at 2022-06-21 19:42:04.097789
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First(2)) == 'Fist[value=2]'


# Generated at 2022-06-21 19:42:09.630467
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert Map({}).__str__() == 'Map[value={}]'
    assert Map({1: Sum(1)}).__str__() == 'Map[value={1: Sum[value=1]}]'
    assert Map({1: Sum(1), 2: Sum(2)}).__str__() == 'Map[value={1: Sum[value=1], 2: Sum[value=2]}]'



# Generated at 2022-06-21 19:42:11.291530
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(2)) == 'Max[value=2]'


# Generated at 2022-06-21 19:42:15.159046
# Unit test for constructor of class Map
def test_Map():
    assert Map({'a': Sum(1), 'b': Sum(2)}).value == {'a': Sum(1), 'b': Sum(2)}
    assert Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(3), 'b': Sum(4)})).value == {'a': Sum(4), 'b': Sum(6)}


# Generated at 2022-06-21 19:42:16.425990
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)) == Max(2)



# Generated at 2022-06-21 19:42:21.633714
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert Semigroup(0) == Semigroup(0)
    assert Semigroup(0).fold(lambda x: 1) == 1
    assert Semigroup.neutral(Semigroup(0)) == Semigroup.neutral()
    assert Semigroup.neutral(Semigroup(0)).fold(lambda x: 1) == 1
    assert Semigroup.neutral(Semigroup(0)) == Semigroup.neutral(Semigroup(0))



# Generated at 2022-06-21 19:43:35.875440
# Unit test for constructor of class Max
def test_Max():
    x = Max(3)
    assert type(x) == Max
    assert x.value == 3


# Generated at 2022-06-21 19:43:37.056298
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == "Fist[value=1]"


# Generated at 2022-06-21 19:43:38.805161
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    """
    Test if return value of method __eq__ equals expected one.
    """

    expected = False
    actual = First(1) != Last(2)
    assert actual == expected



# Generated at 2022-06-21 19:43:40.163173
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(3).concat(Min(2)) == Min(2)


# Generated at 2022-06-21 19:43:42.389556
# Unit test for method __str__ of class Max
def test_Max___str__():
    max_ = Max(10)
    assert max_ == Max(10)
    assert str(max_) == 'Max[value=10]'



# Generated at 2022-06-21 19:43:53.051632
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)
    assert Max(1) == Sum(1)
    assert Max(1) == All(1)
    assert Max(1) == One(1)
    assert Max(1) == First(1)
    assert Max(1) == Last(1)
    assert Max(1) == Map({})
    assert Max(1).concat(Max(2)) == Max(2)
    assert Max(1).concat(Sum(2)) == Max(2)
    assert Max(1).concat(All(2)) == Max(2)
    assert Max(1).concat(One(2)) == Max(2)
    assert Max(1).concat(First(2)) == Max(2)
    assert Max(1).concat(Last(2)) == Max(2)

# Generated at 2022-06-21 19:43:54.393393
# Unit test for method __str__ of class First
def test_First___str__():  # pragma: no cover
    assert str(First(1)) == 'Fist[value=1]'


# Generated at 2022-06-21 19:43:59.485328
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'
    assert str(Last(None)) == 'Last[value=None]'
    assert str(Last('test')) == 'Last[value=test]'


# Generated at 2022-06-21 19:44:07.746402
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Monoid.empty(Map)
    m1 = m1.concat(Map({1: Sum(1), 2: Sum(2)}))
    m2 = Monoid.empty(Map)
    m2 = m2.concat(Map({3: Sum(3), 4: Sum(4)}))
    m = m1.concat(m2)
    assert m.value == {1: Sum(1), 2: Sum(2), 3: Sum(3), 4: Sum(4)}


# Generated at 2022-06-21 19:44:13.105413
# Unit test for constructor of class Map
def test_Map():
    obj1 = Map({
        'name': Sum(1),
        'age': Sum(10)
    })

    obj2 = Map({
        'name': Sum(2),
        'age': Sum(20)
    })

    assert obj1.concat(obj2) == Map({
        'name': Sum(3),
        'age': Sum(30)
    })