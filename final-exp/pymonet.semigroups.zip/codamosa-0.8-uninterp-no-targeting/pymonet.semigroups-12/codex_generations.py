

# Generated at 2022-06-21 19:34:21.179609
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)) == First(1)



# Generated at 2022-06-21 19:34:23.490214
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)
    assert not Semigroup(1) == Semigroup(2)



# Generated at 2022-06-21 19:34:26.858109
# Unit test for method __str__ of class First
def test_First___str__():
    first: First = First(1)
    assert first.__str__() == "Fist[value=1]"


# Generated at 2022-06-21 19:34:32.172835
# Unit test for constructor of class Last
def test_Last():
    initial_value = 3

    t = Last(initial_value)
    assert t.value == initial_value

    initial_value = 0
    t = Last(initial_value)
    assert t.value == initial_value

    initial_value = -10
    t = Last(initial_value)
    assert t.value == initial_value


# Generated at 2022-06-21 19:34:36.886557
# Unit test for constructor of class All
def test_All():
    assert All(True) == All(True)
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(True)) == All(False)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-21 19:34:40.414514
# Unit test for method __str__ of class First
def test_First___str__():
    # Given
    first_string = First('I am the first')

    # When
    string = str(first_string)

    # Then
    assert string == "Fist[value=I am the first]"



# Generated at 2022-06-21 19:34:41.389883
# Unit test for constructor of class Last
def test_Last():
    last = Last(5)
    assert 5 == last.value


# Generated at 2022-06-21 19:34:45.755848
# Unit test for method concat of class Map
def test_Map_concat():
    a = Map({"a": Sum(1), "b": Sum(2), "c": Sum(3)})
    b = Map({"a": Sum(2), "b": Sum(3), "d": Sum(4)})
    a.concat(b) == Map({"a": Sum(3), "b": Sum(5), "c": Sum(3), "d": Sum(4)})




# Generated at 2022-06-21 19:34:53.552400
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)  # both are All(True)
    assert All(True).concat(All(False)) == All(False)  # first is All(True) and other is All(False)
    assert All(False).concat(All(True)) == All(False)  # first is All(False) and other is All(True)
    assert All(False).concat(All(False)) == All(False)  # both are All(False)


# Generated at 2022-06-21 19:35:01.181518
# Unit test for method __str__ of class Last
def test_Last___str__():
    """
    Unit test method Last.__str__()
    """
    last = Last(1)

    assert str(last) == "Last[value=1]"


# Generated at 2022-06-21 19:35:07.581771
# Unit test for constructor of class Min
def test_Min():
    """
    Unit test for constructor of class Min
    """
    assert Min(3).concat(Min(5)) == Min(3)
    assert Min(5).concat(Min(3)) == Min(3)
    assert Min(3).concat(Min(3)) == Min(3)
    assert Min(6).concat(Min(5)).concat(Min(7)) == Min(5)
    if __name__ == "__main__":
        print("Test for Min success!")



# Generated at 2022-06-21 19:35:09.217755
# Unit test for method __str__ of class Min
def test_Min___str__():
    """
    :returns: test method result
    :rtype: bool
    """

    return str(Min(1)) == 'Min[value=1]'


# Generated at 2022-06-21 19:35:10.994616
# Unit test for constructor of class All
def test_All():
    x = All(True)
    assert x.value == True
    assert x == All(True)


# Generated at 2022-06-21 19:35:12.770382
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():  # pragma: no cover
    assert Semigroup(4).fold(lambda x: x * x) == 16

# Generated at 2022-06-21 19:35:14.137295
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(3)) == 'One[value=3]'



# Generated at 2022-06-21 19:35:17.595498
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(True)).value == True
    assert One(False).concat(One(False)).value == False
    assert One(True).concat(One(True)).value == True



# Generated at 2022-06-21 19:35:18.375376
# Unit test for constructor of class All
def test_All():
    assert All(1).value == True


# Generated at 2022-06-21 19:35:19.457740
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)).value == 1


# Generated at 2022-06-21 19:35:21.255432
# Unit test for constructor of class First
def test_First():
    assert First(1).value == 1
    assert First(None).value == None
    assert First([]).value == []


# Generated at 2022-06-21 19:35:23.462915
# Unit test for method concat of class Min
def test_Min_concat():
    s = Min(5)
    z = Min(6)
    assert s.concat(z).value == 5

# Generated at 2022-06-21 19:35:28.069298
# Unit test for constructor of class Semigroup
def test_Semigroup():
    semigroup = Semigroup(1)
    assert isinstance(semigroup, Semigroup)


# Generated at 2022-06-21 19:35:29.626832
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)


# Generated at 2022-06-21 19:35:31.176223
# Unit test for constructor of class Min
def test_Min():
    assert Min(2).value == 2


# Generated at 2022-06-21 19:35:33.284264
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == "Sum[value=1]"
    assert str(Sum(10)) == "Sum[value=10]"


# Generated at 2022-06-21 19:35:34.887377
# Unit test for method concat of class First
def test_First_concat():
    assert First(True).concat(First(False)) == First(True)



# Generated at 2022-06-21 19:35:39.638447
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """
    :returns: nothing
    :rtype: None
    """
    def test_fn(value):
        return value * 2

    assert Semigroup(1).fold(test_fn) == test_fn(1)
    assert Semigroup(1).fold(test_fn) == 2


# Generated at 2022-06-21 19:35:41.131626
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(10).fold(lambda x: x * 2) == 20

# Generated at 2022-06-21 19:35:42.129283
# Unit test for method __str__ of class One
def test_One___str__():
    return str(One(True))



# Generated at 2022-06-21 19:35:46.916373
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)).value == True
    assert One(True).concat(One(True)).value == True
    assert One(False).concat(One(True)).value == True
    assert One(False).concat(One(False)).value == False


# Generated at 2022-06-21 19:35:50.160801
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == 'Last[value=1]'
    assert str(Last({})) == 'Last[value={}]'


# Generated at 2022-06-21 19:35:55.564278
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Sum(2).value == 2
    assert All(True).value is True
    assert One(False).value is False
    assert First('first').value == 'first'
    assert Last('last').value == 'last'
    assert Map({'a': First(1), 'b': Last('b')}).value == {'a': First(1), 'b': Last('b')}
    assert Max(2).value == 2
    assert Min(1).value == 1


# Generated at 2022-06-21 19:35:56.807598
# Unit test for constructor of class Max
def test_Max():
    assert Max(2) == Max(2)


# Generated at 2022-06-21 19:35:58.136168
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(-1)) == 'Max[value=-1]'


# Generated at 2022-06-21 19:36:01.084001
# Unit test for constructor of class Map
def test_Map():
    assert Map({1: Min(1), 2: First(2), 3: Last(3)}) == Map({1: Min(1), 2: First(2), 3: Last(3)})


# Generated at 2022-06-21 19:36:03.520205
# Unit test for method concat of class Map
def test_Map_concat():
    map_a = Map({'sum': Sum(1)})
    map_b = Map({'sum': Sum(2)})
    map_c = map_a.concat(map_b)
    assert isinstance(map_c, Map)
    assert map_c.value['sum'] == Sum(3)

# Generated at 2022-06-21 19:36:04.888675
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(100)) == 'Last[value=100]'



# Generated at 2022-06-21 19:36:08.490692
# Unit test for constructor of class All
def test_All():
    assert All(True).value == True
    assert All(False).value == False
    assert All(0).value == False
    assert All(1).value == True
    assert All("").value == False
    assert All("False").value == True


# Generated at 2022-06-21 19:36:13.295955
# Unit test for constructor of class All
def test_All():  # pragma: no cover
    assert All(True).value == True
    assert All(False).value == False
    assert All(None).value == False
    assert All(None).fold(lambda x: True) == False


# Generated at 2022-06-21 19:36:15.387539
# Unit test for method __str__ of class One
def test_One___str__():
    assert One(True).__str__() == 'One[value=True]'



# Generated at 2022-06-21 19:36:17.608915
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({"a": Sum(1)})) == "Map[value={'a': Sum[value=1]}]"


# Generated at 2022-06-21 19:36:20.760060
# Unit test for constructor of class Max
def test_Max():
    result = Max(3)
    assert result.value == 3



# Generated at 2022-06-21 19:36:22.978192
# Unit test for method __str__ of class Map
def test_Map___str__():
    m = Map({'test': Sum(1)})

    assert m.__str__() == 'Map[value={"test": Sum[value=1]}]'



# Generated at 2022-06-21 19:36:24.755120
# Unit test for constructor of class Last
def test_Last():

    assert Last(1)



# Generated at 2022-06-21 19:36:33.214174
# Unit test for method concat of class All
def test_All_concat():
    all = All(True)
    concated = all.concat(All(True))
    assert concated == All(True)

    all = All(True)
    concated = all.concat(All(False))
    assert concated == All(False)

    all = All(False)
    concated = all.concat(All(True))
    assert concated == All(False)

    all = All(False)
    concated = all.concat(All(False))
    assert concated == All(False)


# Generated at 2022-06-21 19:36:36.046256
# Unit test for method __str__ of class Max
def test_Max___str__():
    print('test_Max___str__')

    max_semigroup = Max(2)
    assert str(max_semigroup) == 'Max[value=2]'



# Generated at 2022-06-21 19:36:38.576385
# Unit test for method __str__ of class All
def test_All___str__():  # pragma: no cover
    all = All(True)
    assert all.__str__() == 'All[value=True]'


# Generated at 2022-06-21 19:36:50.552398
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    sum_ = Sum(1)
    assert(sum_ == Sum(1.0))
    assert(not sum_ == Sum(2))
    assert(All(True) == All(True))
    assert(not All(False) == All(True))
    assert(One(True) == One(True))
    assert(not One(False) == One(True))
    assert(First(1) == First(1))
    assert(not First(1) == First(2))
    assert(Last(1) == Last(1))
    assert(not Last(1) == Last(2))
    assert(Map({"a": Max(4)}) == Map({"a": Max(4.0)}))
    assert(not Map({"a": Max(4)}) == Map({"a": Max(5)}))

# Generated at 2022-06-21 19:36:51.985840
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)



# Generated at 2022-06-21 19:37:00.022589
# Unit test for method concat of class Map
def test_Map_concat():
    values = {
        "one": Sum(1),
        "colors": Map({
            "red": Sum(3),
            "blue": Sum(4),
            "green": Sum(5),
        }),
        "two": Sum(2),
    }
    assert values["one"].concat(values["two"]) == Sum(3)
    assert values["colors"]["red"].concat(values["colors"]["green"]) == Sum(8)

    expected = Map({
        "one": Sum(1),
        "two": Sum(2),
        "colors": Map({
            "red": Sum(3),
            "blue": Sum(4),
            "green": Sum(5),
        }),
    })
    result = Map(values)
    assert result == expected

# Generated at 2022-06-21 19:37:04.302358
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(2) == Min.neutral().concat(Min(2))
    assert Min(2) == Min(2).concat(Min.neutral())
    assert Min(2) == Min(1).concat(Min(2))
    assert Min(2) == Min(2).concat(Min(1))
    assert Min(1) == Min(1).concat(Min(1))



# Generated at 2022-06-21 19:37:12.129805
# Unit test for method concat of class Map
def test_Map_concat():  # pragma: no cover
    dict_one = {1: 1, 2: 2, 3: 3}
    dict_two = {3: 3, 4: 4, 5: 5}
    assert Map(dict_one).concat(Map(dict_two)).value == {3: 6, 4: 4, 5: 5}

# Generated at 2022-06-21 19:37:16.596223
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    """ Semigroup fold method return semigroup value"""
    assert Semigroup(4).fold(lambda x: x * 10) == 40
    assert Semigroup("A string").fold(lambda s: s + s) == "A string" + "A string"
    assert Sum(4).fold(lambda x: x * 10) == 40


# Generated at 2022-06-21 19:37:18.719520
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)  # True
    assert One(False) == One(False)  # False


# Generated at 2022-06-21 19:37:21.046856
# Unit test for method __str__ of class One
def test_One___str__():
    """
    Unit test for method __str__ of class One
    """
    one = One(True)
    assert __str__(one) == 'One[value=True]'

# Generated at 2022-06-21 19:37:22.262683
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(1)) == "Max[value=1]"


# Generated at 2022-06-21 19:37:23.300685
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == 1


# Generated at 2022-06-21 19:37:24.344502
# Unit test for constructor of class Min
def test_Min():
    assert Min(1).value == 1

# Generated at 2022-06-21 19:37:26.583714
# Unit test for method __str__ of class Min
def test_Min___str__():
    """
    Unit test for method __str__ of class Min
    """
    assert str(Min(Min.neutral_element)) == "Min[value=inf]"


# Generated at 2022-06-21 19:37:28.887185
# Unit test for constructor of class First
def test_First():
    assert First(1) == First(1)
    assert First(2) == First(2)
    assert First(1) != First(2)


# Generated at 2022-06-21 19:37:39.703449
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert(Sum(1) == Sum(1))
    assert(Sum(1) != Sum(2))
    assert(All(1) == All(1))
    assert(All(2) != All(2))
    assert(All(False) == All(False))
    assert(All(1) != All(True))
    assert(One(True) == One(True))
    assert(One(1) == One(1))
    #assert(One(False) != One(False))
    assert(One(False) == One(0))
    assert(First(1) == First(1))
    assert(First(1) != First(2))
    assert(Last(2) == Last(2))
    assert(Last(1) != Last(2))
    assert(Max(10) == Max(10))

# Generated at 2022-06-21 19:37:43.170875
# Unit test for constructor of class Sum
def test_Sum():
    s = Sum(12)
    assert s.value == 12


# Generated at 2022-06-21 19:37:44.458086
# Unit test for constructor of class Min
def test_Min():
    a = Min(3)
    assert a.value == 3
    assert a.fold(lambda x: x * x) == 9


# Generated at 2022-06-21 19:37:45.673239
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'



# Generated at 2022-06-21 19:37:46.886381
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-21 19:37:50.179091
# Unit test for constructor of class One
def test_One():
    assert One(True) == One(True)
    assert One(True) != One(False)
    assert One(False) != One(True)
    assert One(False) == One(False)

if __name__ == "__main__":
    test_One()
    print("Everything passed")

# Generated at 2022-06-21 19:37:56.870249
# Unit test for method concat of class All
def test_All_concat():
    assert str(All(True).concat(All(True))) == "All[value=True]"
    assert str(All(True).concat(All(False))) == "All[value=False]"
    assert str(All(False).concat(All(False))) == "All[value=False]"
    assert str(All(False).concat(All(True))) == "All[value=False]"


# Generated at 2022-06-21 19:38:00.645903
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    class SemigroupTest(Semigroup):
        def __init__(self, value):
            super().__init__(value)

    assert SemigroupTest(2).fold(lambda x: x * x * x) == 8

test_Semigroup_fold()



# Generated at 2022-06-21 19:38:02.398569
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)



# Generated at 2022-06-21 19:38:03.273690
# Unit test for constructor of class First
def test_First():
    assert First("a").value == "a"

# Generated at 2022-06-21 19:38:10.441722
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True), "All(True).concat(All(True)) should be equal All(True)"
    assert All(True).concat(All(False)) == All(False), "All(True).concat(All(True)) should be equal All(False)"
    assert All(False).concat(All(False)) == All(False), "All(True).concat(All(True)) should be equal All(False)"


# Generated at 2022-06-21 19:38:16.360396
# Unit test for method concat of class One
def test_One_concat():
    assert One(True).concat(One(False)) == One(True)


# Generated at 2022-06-21 19:38:17.851638
# Unit test for method __str__ of class One
def test_One___str__():
    b = One(False)
    assert str(b) == "One[value=False]"


# Generated at 2022-06-21 19:38:18.999829
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(3)) == "All[value=3]"



# Generated at 2022-06-21 19:38:20.237919
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)


# Generated at 2022-06-21 19:38:24.373002
# Unit test for constructor of class All
def test_All():  # pragma: no cover
    assert All(True) is not None
    assert All(True).value is True
    assert All(True) == All(True)
    assert All(True) != All(False)


# Generated at 2022-06-21 19:38:27.276050
# Unit test for constructor of class Sum
def test_Sum():
    """
    unit test for constructor of class Sum
    """

    assert Sum(5).value == 5
    assert Sum(5) == Sum(5)
    assert Sum(5) != Sum(6)


# Generated at 2022-06-21 19:38:31.672828
# Unit test for constructor of class Min
def test_Min():
    assert Min(1).value == 1
    assert Min(2).value == 2
    assert Min("1").value == "1"
    assert Min("2").value == "2"


# Generated at 2022-06-21 19:38:33.723331
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-21 19:38:36.476974
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(1)) == "Last[value=1]"
    assert str(Last(None)) == "Last[value=None]"


# Generated at 2022-06-21 19:38:37.542015
# Unit test for constructor of class Last
def test_Last():
    assert Last(1).value == 1


# Generated at 2022-06-21 19:38:47.411359
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(1)) == 'Sum[value=1]'


# Generated at 2022-06-21 19:38:49.161479
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert (str(Min(1)) == 'Min[value=1]')


# Generated at 2022-06-21 19:38:52.429863
# Unit test for method concat of class Last
def test_Last_concat():
    """
    Test of concat method of class Last
    """
    last1 = Last(1)
    last2 = Last(2)
    last12 = last1.concat(last2)
    assert last12 == Last(2)


# Generated at 2022-06-21 19:38:55.729243
# Unit test for method concat of class Sum
def test_Sum_concat():
    """
    Assert that concat of 2 Sum instances results in a Sum instance with each Sum's values added together.
    """
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-21 19:38:56.870593
# Unit test for constructor of class First
def test_First():
    with pytest.raises(TypeError):
        First()



# Generated at 2022-06-21 19:38:58.246467
# Unit test for constructor of class Min
def test_Min():
    assert Min.neutral() == Min(float("inf"))


# Generated at 2022-06-21 19:39:04.473970
# Unit test for constructor of class Map
def test_Map():
    dict1 = {1: First(1), 2: First(2)}
    dict2 = {3: First(3), 4: First(4)}
    map1 = Map(dict1)
    map2 = Map(dict2)
    assert map1.concat(map2) == Map({1: First(1), 2: First(2), 3: First(3), 4: First(4)})


# Generated at 2022-06-21 19:39:06.631371
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)).value == 2


# Generated at 2022-06-21 19:39:09.204355
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)).value == 3
    assert Sum(2).concat(Sum(2)).value == 4



# Generated at 2022-06-21 19:39:11.022707
# Unit test for method __str__ of class All
def test_All___str__():
    assert All(True).__str__() == 'All[value=True]'



# Generated at 2022-06-21 19:39:22.357833
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(10) == Sum(10)
    assert Sum(10) != Sum(5)



# Generated at 2022-06-21 19:39:25.571672
# Unit test for method concat of class All
def test_All_concat():  # pragma: no cover
    for (x, y, c) in [
        (True, True, True),
        (True, False, False),
        (False, True, False),
        (False, False, False)
    ]:
        assert (
            All(x).concat(All(y)) == All(c)
        ), f"All({repr(x)}).concat(All({repr(y)})) == All({repr(c)}) is False"



# Generated at 2022-06-21 19:39:27.729391
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last('b').concat(
        Last('a')
    ) == Last('a')



# Generated at 2022-06-21 19:39:30.374298
# Unit test for constructor of class All
def test_All():
    # Given
    value = True

    # When
    semigroup = All(value)

    # Then
    assert semigroup.value == value


# Generated at 2022-06-21 19:39:33.550364
# Unit test for constructor of class Map
def test_Map():
    test_dict = {'key1': Sum(1), 'key2': Sum(2)}
    semigroup = Map(test_dict)
    assert semigroup.__dict__ == {'value': test_dict}
    assert semigroup.value == test_dict


# Generated at 2022-06-21 19:39:42.480647
# Unit test for method concat of class One
def test_One_concat():
    assert One(False).concat(One(True)) == One(True), 'concat One(False) with One(True)'
    assert One(True).concat(One(False)) == One(True), 'concat One(True) with One(False)'
    assert One(False).concat(One(False)) == One(False), 'concat One(False) with One(False)'
    assert One(True).concat(One(True)) == One(True), 'concat One(True) with One(True)'


# Generated at 2022-06-21 19:39:46.111794
# Unit test for constructor of class One
def test_One():
    print("Unit test for constructor of class One")
    a = One(1)
    assert a.value == 1


# Generated at 2022-06-21 19:39:48.354051
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'

    assert str(All(False)) == 'All[value=False]'



# Generated at 2022-06-21 19:39:52.717868
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)).value == True
    assert All(True).concat(All(False)).value == False
    assert All(False).concat(All(True)).value == False
    assert All(False).concat(All(False)).value == False


# Generated at 2022-06-21 19:39:59.721261
# Unit test for constructor of class Min
def test_Min():
    """
    Function that tests the parameters passed on the Min constructor and see if it assigns the given values to the
    variables, it also tests it using different data types
    """

    min1 = Min(1)
    assert min1.value == 1
    min2 = Min(1.0)
    assert min2.value == 1.0
    min3 = Min(None)
    assert min3.value == None
    min4 = Min(True)
    assert min4.value == True
    min5 = Min('C')
    assert min5.value == 'C'


# Generated at 2022-06-21 19:40:19.877011
# Unit test for constructor of class Map
def test_Map():
    dictionary: dict = {
        1: Sum(2),
        2: One(True),
    }
    assert Map(dictionary).value == dictionary


# Generated at 2022-06-21 19:40:21.174981
# Unit test for method concat of class Min
def test_Min_concat(): 
    a = Min(1)
    b = Min(2)
    assert Min(1).concat(b) == a

# Generated at 2022-06-21 19:40:23.724578
# Unit test for method __str__ of class Last
def test_Last___str__():
    # Given
    value = 100

    # When
    last = Last(value)

    # Then
    assert str(last) == 'Last[value=100]'



# Generated at 2022-06-21 19:40:26.515537
# Unit test for method concat of class First
def test_First_concat():
    # given
    first = First(4)
    second = First(8)

    # when
    result = first.concat(second)

    # then
    assert result.value == 4


# Generated at 2022-06-21 19:40:28.409596
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(3).concat(Sum(4)) == Sum(7)



# Generated at 2022-06-21 19:40:30.494909
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(0) == Sum(0)
    assert Sum(1) == Sum(1)
    assert Sum(1) != Sum(2)


# Generated at 2022-06-21 19:40:32.254584
# Unit test for method concat of class All
def test_All_concat():
    concat = All(False).concat(All(True))
    assert (concat == All(False)) is True


# Generated at 2022-06-21 19:40:37.605432
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(First(2)) == First(2)
    assert Last(1).concat(Sum(2)) == Sum(2)
    assert Last(1).concat(All(True)) == All(True)
    assert Last(1).concat(All(False)) == All(False)
    assert Last(1).concat(One(True)) == One(True)
    assert Last(1).concat(One(False)) == One(False)
    assert Last(1).concat(Max(1)) == Max(1)
    assert Last(1).concat(Max(2)) == Max(2)
    assert Last(1).concat(Min(1)) == Min(1)

# Generated at 2022-06-21 19:40:43.031869
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First('qwerty')) == 'Fist[value=qwerty]'
    assert str(First(0)) == 'Fist[value=0]'
    assert str(First(True)) == 'Fist[value=True]'



# Generated at 2022-06-21 19:40:46.441908
# Unit test for method concat of class Last
def test_Last_concat():
    last = Last(1)
    result = last.concat(Last(2))
    assert result == Last(2)


# Generated at 2022-06-21 19:41:29.295142
# Unit test for method __str__ of class First
def test_First___str__():
    # Arrange
    value = 123
    expected = 'Fist[value=123]'
    first = First(value)

    # Act
    actual = first.__str__()

    # Assert
    assert actual == expected


# Generated at 2022-06-21 19:41:33.305842
# Unit test for constructor of class Sum
def test_Sum():   # pragma: no cover
    print("\n" + "#" * 3 + " Sum " + "#" * 3)
    a = Sum(1)
    b = Sum(2)
    c = Sum("1")
    print("a: {}, b: {}, c: {}".format(a, b, c))



# Generated at 2022-06-21 19:41:35.476443
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1) == Sum(1)



# Generated at 2022-06-21 19:41:37.864985
# Unit test for constructor of class First
def test_First():
    semigroup = First(1)
    assert semigroup.value == 1
    semigroup = First(2)
    assert semigroup.value == 2



# Generated at 2022-06-21 19:41:38.733246
# Unit test for constructor of class Last
def test_Last():
    assert Last(8) == Last(8)

# Generated at 2022-06-21 19:41:42.458950
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'
    assert str(One(3)) == 'One[value=3]'
    assert str(One('a')) == 'One[value=a]'
    assert str(One(lambda x: x)) == 'One[value=<function test_One___str__.<locals>.<lambda> at 0x10a3f3b90>]'


# Generated at 2022-06-21 19:41:46.865604
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Sum(1).fold(lambda a: a + 100) == 101
    assert All(True).fold(lambda a: a and True) == True
    assert One(False).fold(lambda a: a or True) == True
    assert First('hello').fold(lambda a: a + ' you') == 'hello'
    assert Last('hello').fold(lambda a: a + ' you') == 'you'
    assert Map({'a': Sum(1), 'b': Sum(2)}).fold(lambda a: sum(a.values())) == 3
    assert Max(1).fold(lambda a: a + 100) == 101
    assert Min(100).fold(lambda a: a - 1) == 99


# Generated at 2022-06-21 19:41:53.366143
# Unit test for method concat of class Max
def test_Max_concat():
    test_data = [
        (Max(1), Max(2), Max(2)),
        (Max(1), Max(2), Max(1)),
        (Max(-1), Max(-2), Max(-2)),
        (Max(-1), Max(-2), Max(-1)),
        (Max(-1), Max(0), Max(0)),
    ]
    for first, second, expected in test_data:
        assert first.concat(second) == expected


# Generated at 2022-06-21 19:41:55.003015
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]", "Fail test"
    assert str(All(False)) == "All[value=False]", "Fail test"

# Generated at 2022-06-21 19:42:01.423217
# Unit test for method concat of class Min
def test_Min_concat():
    """
    :returns: None
    :rtype: None
    """
    min1 = Min(1)
    min2 = Min(2)
    min12 = Min(3)
    assert min1.concat(min2).value == min2.concat(min1).value == 1
    assert min12.concat(min2).value == min2.concat(min12).value == 2


# Generated at 2022-06-21 19:43:34.030826
# Unit test for constructor of class Map
def test_Map():

    m = Map({'a': Sum(1), 'b': Sum(2)})

    assert m.value == {'a': Sum(1), 'b': Sum(2)}
    assert m == Map({'a': Sum(1), 'b': Sum(2)})


# Generated at 2022-06-21 19:43:35.957997
# Unit test for method __str__ of class First
def test_First___str__():
    my_first = First(1)
    assert str(my_first) == 'Fist[value=1]'



# Generated at 2022-06-21 19:43:37.115725
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(5)) == 'Sum[value=5]'


# Generated at 2022-06-21 19:43:37.966826
# Unit test for constructor of class Max
def test_Max():
    assert Max(1) == Max(1)


# Generated at 2022-06-21 19:43:38.804104
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(1)) == "One[value=1]"


# Generated at 2022-06-21 19:43:39.778399
# Unit test for method concat of class Last
def test_Last_concat():  # pragma: no cover
    assert Last(1).concat(Last(2)) == Last(2)


# Generated at 2022-06-21 19:43:40.507370
# Unit test for constructor of class First
def test_First():
    assert First(123) == First(123)



# Generated at 2022-06-21 19:43:42.503971
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'



# Generated at 2022-06-21 19:43:47.255428
# Unit test for constructor of class Min
def test_Min():
    data= [[1,2,3,4,5],['ab','cd','ef','gh'],[(2,9),(3,0),(6,8),(1,0),(4,3)]]
    for i in data:
        assert Min(i).value==min(i)

# Generated at 2022-06-21 19:43:48.548977
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(2)) == "First[value=2]"
