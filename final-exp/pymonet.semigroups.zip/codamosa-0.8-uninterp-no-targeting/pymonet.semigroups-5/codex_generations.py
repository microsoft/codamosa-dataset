

# Generated at 2022-06-21 19:34:18.329964
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-21 19:34:19.346795
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(10)) == 'Fist[value=10]'


# Generated at 2022-06-21 19:34:20.776207
# Unit test for constructor of class Map
def test_Map():
    assert Map(dict()) == Map(dict())



# Generated at 2022-06-21 19:34:22.240140
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)


# Generated at 2022-06-21 19:34:28.027906
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)).value == False, "Should return false"
    assert All(True).concat(All(True)).value == True, "Should return true"
    assert All(False).concat(All(False)).value == False, "Should return false"



# Generated at 2022-06-21 19:34:32.912825
# Unit test for method concat of class Map
def test_Map_concat():
    one = Map({1: Sum(1), 2: Sum(2)})
    two = Map({2: Sum(2), 3: Sum(3)})
    assert one.concat(two).value == {1: Sum(1), 2: Sum(4), 3: Sum(3)}


# Unit tests for method concat of class Max

# Generated at 2022-06-21 19:34:34.488844
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(2)).value == 2



# Generated at 2022-06-21 19:34:36.094107
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1
    assert Sum(2).value == 2



# Generated at 2022-06-21 19:34:37.745496
# Unit test for method __str__ of class Last
def test_Last___str__():
    expected = 'Last[value=y]'
    actual = str(Last('y'))
    assert(expected == actual)



# Generated at 2022-06-21 19:34:43.430376
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({'a': First(1), 'b': First(2)})
    m2 = Map({'a': Last(4), 'b': Last(5)})
    m = m1.concat(m2)
    assert m.value['a'].value == 4
    assert m.value['b'].value == 5


# Generated at 2022-06-21 19:34:48.614466
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1).__eq__(Sum(1))
    assert not Sum(1).__eq__(Sum(2))


# Generated at 2022-06-21 19:34:51.179843
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(4)) == 'Sum[value=4]'



# Generated at 2022-06-21 19:34:53.602473
# Unit test for constructor of class Map
def test_Map():
    assert Map({"a": Sum(1), "b": Sum(2)})


# Generated at 2022-06-21 19:35:01.152817
# Unit test for constructor of class One
def test_One():
    x = One(False)
    y = One(True)
    assert str(x) == "One[value=False]"
    assert str(y) == "One[value=True]"

# Generated at 2022-06-21 19:35:05.457514
# Unit test for method __str__ of class Map
def test_Map___str__():
    assert str(Map({'foo': First('bar'), 'baz': Last('qux')})) == "Map[value={'foo': Fist[value=bar], 'baz': Last[value=qux]}]"


# Generated at 2022-06-21 19:35:07.274757
# Unit test for method concat of class First
def test_First_concat():
    assert First(3).concat(First(2)) == First(3)


# Generated at 2022-06-21 19:35:13.805502
# Unit test for method concat of class All
def test_All_concat():
    semigroup_first = All(True)
    semigroup_second = All(False)
    assert semigroup_first.concat(semigroup_second).value == False
    semigroup_first = All(False)
    semigroup_second = All(False)
    assert semigroup_first.concat(semigroup_second).value == False
    semigroup_first = All(True)
    semigroup_second = All(True)
    assert semigroup_first.concat(semigroup_second).value == True


# Generated at 2022-06-21 19:35:15.715116
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == "One[value=True]"
    assert str(One(False)) == "One[value=False]"



# Generated at 2022-06-21 19:35:18.633144
# Unit test for method concat of class Max
def test_Max_concat():  # pragma: no cover
    assert Max(10).concat(Max(20)) == Max(20)
    assert Max(10).concat(Max(3)) == Max(10)
    assert Max(10).concat(Max(10)) == Max(10)



# Generated at 2022-06-21 19:35:20.314311
# Unit test for constructor of class Semigroup
def test_Semigroup():
    assert Semigroup(1) == Semigroup(1)
    assert Semigroup(1) != Semigroup(2)


# Generated at 2022-06-21 19:35:24.504329
# Unit test for method concat of class Last
def test_Last_concat():
    expected = Last(7)
    actual = Last(4).concat(Last(7))
    assert expected == actual, "Expected: {}, Actual: {}".format(expected, actual)


# Generated at 2022-06-21 19:35:27.986476
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(2)) == Sum(3)



# Generated at 2022-06-21 19:35:29.185066
# Unit test for constructor of class Last
def test_Last():
    assert Last(12) is not None


# Generated at 2022-06-21 19:35:31.884724
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert not Semigroup(1) == Semigroup(2)
    assert Semigroup(2) == Semigroup(2)


# Generated at 2022-06-21 19:35:34.225302
# Unit test for constructor of class All
def test_All():
    assert All(123) == All(True)


# Generated at 2022-06-21 19:35:36.230762
# Unit test for constructor of class One
def test_One():
    assert One(1) == One(1)
    assert One(1) != One(2)


# Generated at 2022-06-21 19:35:39.104208
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(True)) == All(False)


# Generated at 2022-06-21 19:35:43.855677
# Unit test for method concat of class All
def test_All_concat():
    assert All(True)  .concat(All(True))  .value == True
    assert All(True)  .concat(All(False)) .value == False
    assert All(False) .concat(All(True))  .value == False
    assert All(False) .concat(All(False)) .value == False


# Generated at 2022-06-21 19:35:46.054061
# Unit test for method __str__ of class One
def test_One___str__():
    assert str(One(True)) == 'One[value=True]'
    assert str(One(False)) == 'One[value=False]'

# Generated at 2022-06-21 19:35:49.306578
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(True) == One(True)
    assert First('A') == First('A')
    assert Last('A') == Last('A')
    assert Map({'A': Sum(1)}) == Map({'A': Sum(1)})
    assert Max(1) == Max(1)
    assert Min(1) == Min(1)

# Generated at 2022-06-21 19:36:02.784503
# Unit test for constructor of class Sum
def test_Sum():  # pragma: no cover
    assert Sum(1) == Sum(1)
    assert Sum(1) == Sum.neutral().concat(Sum(1))  # neutral element
    assert Sum(1).concat(Sum(2)) == Sum(2).concat(Sum(1))  # associativity
    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(1).concat(Sum(2).concat(Sum(3)))

    assert Sum(1).concat(Sum(2)).concat(Sum(3)) == Sum(1).concat(Sum(2).concat(Sum(3)))

# Generated at 2022-06-21 19:36:04.984740
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    """
    :return: None
    """
    assert str(One(1)) == "One[value=1]"

# Generated at 2022-06-21 19:36:09.330036
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    assert Semigroup.fold(Sum(2), lambda x: x + 1) == 3
    assert Semigroup.fold(All(True), lambda x: not x) == False
    assert Semigroup.fold(One(False), lambda x: not x) == True
    assert Semigroup.fold(First(2), lambda x: x + 1) == 2  # pragma: no cover
    assert Semigroup.fold(Last(2), lambda x: x + 1) == 3  # pragma: no cover
    assert Semigroup.fold(Map({'a': Sum(1)}), lambda x: 2 * x) == {'a': 2}  # pragma: no cover
    assert Semigroup.fold(Max(2), lambda x: x + 1) == 3  # pragma: no cover

# Generated at 2022-06-21 19:36:15.334246
# Unit test for constructor of class First
def test_First():
    first = First(1)
    semigroup_1 = first.concat(First(2))
    semigroup_2 = first.concat(First(100))
    semigroup_3 = first.concat(First(1000))

    assert semigroup_1.value == 1
    assert semigroup_2.value == 1
    assert semigroup_3.value == 1



# Generated at 2022-06-21 19:36:17.560786
# Unit test for constructor of class Min
def test_Min():
    x = Min(5)
    y = Min(6)
    assert x + y == Min(5)


# Generated at 2022-06-21 19:36:22.691294
# Unit test for method concat of class First
def test_First_concat():
    # create 2 instances of class First
    t = First(1)
    t1 = First(2)

    # concat the 2 instances
    t2 = t.concat(t1)

    # assert if t2 is a class of First and if t2 value equal to t1 value
    assert isinstance(t2, First)
    assert t2.value == t1.value



# Generated at 2022-06-21 19:36:25.091067
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'

# Generated at 2022-06-21 19:36:30.588541
# Unit test for method concat of class All
def test_All_concat():
    assert All.neutral() == All(True)
    assert All(True).concat(All(True)) == All(True)
    assert All(True).concat(All(False)) == All(False)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)



# Generated at 2022-06-21 19:36:32.278793
# Unit test for constructor of class Semigroup
def test_Semigroup():  # pragma: no cover
    assert Semigroup(5).value == 5



# Generated at 2022-06-21 19:36:37.628102
# Unit test for method fold of class Semigroup
def test_Semigroup_fold():
    identity_fn = lambda x: x
    fn = lambda x: x + 1

    assert Semigroup(0).fold(identity_fn) == 0
    assert Semigroup(1).fold(identity_fn) == 1

    assert Semigroup(0).fold(fn) == 1
    assert Semigroup(1).fold(fn) == 2


# Generated at 2022-06-21 19:36:45.355031
# Unit test for constructor of class Map
def test_Map():
    expected = {'a': 1, 'b': 2}
    actual = Map(expected)
    assert actual.value == expected


# Generated at 2022-06-21 19:36:48.211024
# Unit test for constructor of class Map
def test_Map():
    semigroup = Map({'a': Sum(1),'b': Sum(2)})
    assert semigroup.value == {'a': Sum(1),'b': Sum(2)}

# Generated at 2022-06-21 19:36:49.790789
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-21 19:36:51.815119
# Unit test for constructor of class Min
def test_Min():
    assert Min(1) == Min(1)
    assert Min(1).value == 1
    assert Min(2).value == 2


# Generated at 2022-06-21 19:36:55.958405
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(False)).value == False
    assert All(True).concat(All(True)).value == True
    assert All(False).concat(All(False)).value == False


# Generated at 2022-06-21 19:37:00.821781
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(5)) == 'Max[value=5]'
    assert str(Max(1)) == 'Max[value=1]'
    assert str(Max(15)) == 'Max[value=15]'
    assert str(Max(-23)) == 'Max[value=-23]'


# Generated at 2022-06-21 19:37:03.443970
# Unit test for method concat of class Min
def test_Min_concat():
    # If a contains a list of types B, return a new Min of type B
    a = Min(3)
    b = Min(4)
    assert a.concat(b) == Min(3)


# Generated at 2022-06-21 19:37:04.968053
# Unit test for method concat of class Max
def test_Max_concat():
    assert Max(1).concat(Max(5)) == Max(5)


# Generated at 2022-06-21 19:37:06.640293
# Unit test for method concat of class Last
def test_Last_concat():
    s = Last(1)
    assert s.concat(Last(2)) == Last(2)


# Generated at 2022-06-21 19:37:11.883978
# Unit test for method __str__ of class One
def test_One___str__():
    instance = One(True)
    expected = 'One[value=True]'
    actual = instance.__str__()
    assert actual == expected, "Error on 'One___str__', expected: {}, got: {}".format(
        expected, actual
    )


# Generated at 2022-06-21 19:37:21.895891
# Unit test for constructor of class Max
def test_Max():  # pragma: no cover
    """
    :return: Result of unit test
    :rtype: bool
    """
    assert Max(12) == Max(12)
    assert not Max(12) == Max(10)
    assert not Max(12) == Sum(12)
    assert Max(12).fold(lambda v: v) == 12
    return True


# Generated at 2022-06-21 19:37:23.300178
# Unit test for constructor of class All
def test_All():
    assert (All(True).value) == True

# Generated at 2022-06-21 19:37:24.649789
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(First(2)) == Last(2)

# Generated at 2022-06-21 19:37:28.258274
# Unit test for method concat of class One
def test_One_concat():
    """
        Unite test to check method concat of class One
    """

    assert One(True).concat(
        One(False)
    ) == One(True)

    assert One(False).concat(
        One(True)
    ) == One(True)


# Generated at 2022-06-21 19:37:32.875438
# Unit test for method concat of class Last
def test_Last_concat():
    assert Last(1).concat(Last(2)).concat(Last(3)) == Last(3)
    assert Last(1).concat(Last(2)) == Last(2)
    assert Last(1).concat(Last(2)).concat(Last(1)) == Last(1)


# Generated at 2022-06-21 19:37:35.359879
# Unit test for method concat of class First
def test_First_concat():
    """
    First concat sample

    # >>> First('any') concat First('value')
    First('any')
    """



# Generated at 2022-06-21 19:37:39.482543
# Unit test for method concat of class All
def test_All_concat():
    assert All(True).concat(All(True)) == All(True)
    assert All(False).concat(All(True)) == All(False)
    assert All(False).concat(All(False)) == All(False)
    assert All(True).concat(All(False)) == All(False)


# Generated at 2022-06-21 19:37:40.876814
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    assert str(Last(1)) == str(Last(1))



# Generated at 2022-06-21 19:37:43.406225
# Unit test for method concat of class Min
def test_Min_concat():
    a = Min(5)
    b = Min(-5)
    assert a.concat(b).value == b.concat(a).value == -5


# Generated at 2022-06-21 19:37:47.053058
# Unit test for constructor of class First
def test_First():
    # Arrange
    value = 'test'

    # Act
    instance = First(value)

    # Assert - in first
    assert instance
    assert instance.value == 'test'

    # Assert - not in first
    assert not First(None)
    assert not First(False)


# Generated at 2022-06-21 19:37:54.838520
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == "All[value=True]"
    assert str(All(False)) == "All[value=False]"


# Generated at 2022-06-21 19:37:59.488674
# Unit test for method __str__ of class Map
def test_Map___str__():  # pragma: no cover
    map_instance = Map({
        'key_one': First(1),
        'key_two': Last(2)
    })

    assert str(map_instance) == 'Map[value={\'key_one\': Fist[value=1], \'key_two\': Last[value=2]}]'


# Generated at 2022-06-21 19:38:01.693095
# Unit test for constructor of class Last
def test_Last():
    last = Last(10)
    assert last.value == 10
    assert last.concat(Last(5)) == Last(5)


# Generated at 2022-06-21 19:38:03.244589
# Unit test for method concat of class First
def test_First_concat():
    assert First(1).concat(First(2)).value == 1


# Generated at 2022-06-21 19:38:05.490021
# Unit test for constructor of class Map
def test_Map():
    a = Map({'a': 1, 'b': 2})
    assert a.value == {'a': 1, 'b': 2}


# Generated at 2022-06-21 19:38:08.674843
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    value = randint(0, 100)
    assert str(Sum(value)) == 'Sum[value={}]'.format(value)



# Generated at 2022-06-21 19:38:10.111242
# Unit test for constructor of class One
def test_One():
    assert One("Juan").value is "Juan"


# Generated at 2022-06-21 19:38:14.373467
# Unit test for method __str__ of class Max
def test_Max___str__():
    assert str(Max(10)) == "Max[value=10]"
    assert str(Max(5)) == "Max[value=5]"
    assert str(Max(-1)) == "Max[value=-1]"


# Generated at 2022-06-21 19:38:16.923988
# Unit test for constructor of class Map
def test_Map():
    map = Map({'a': All(True), 'b': Last(1)})
    assert map.value == {'a': All(True), 'b': Last(1)}


# Generated at 2022-06-21 19:38:18.109977
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(4)) == "Min[value=4]"



# Generated at 2022-06-21 19:38:30.528751
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'



# Generated at 2022-06-21 19:38:32.096860
# Unit test for constructor of class Max
def test_Max():
    m = Max(1)
    assert 1 == m.value


# Generated at 2022-06-21 19:38:34.549627
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(5).value == 5
    assert Sum(5) == Sum(5)
    assert Sum(5) != Sum(6)



# Generated at 2022-06-21 19:38:36.781851
# Unit test for method concat of class Sum
def test_Sum_concat():
    assert Sum(1).concat(Sum(1)) == Sum(2)
    assert Sum(3).concat(Sum(5)) == Sum(8)


# Generated at 2022-06-21 19:38:39.423219
# Unit test for method concat of class Min
def test_Min_concat():
    x = Min(1)
    y = Min(2)
    print(x)
    print(y)
    print(x.concat(y))


# Generated at 2022-06-21 19:38:43.241716
# Unit test for method __str__ of class Sum
def test_Sum___str__():
    assert str(Sum(0)) == 'Sum[value=0]'
    assert str(Sum(1)) == 'Sum[value=1]'
    assert str(Sum(2)) == 'Sum[value=2]'



# Generated at 2022-06-21 19:38:47.050023
# Unit test for method concat of class Map
def test_Map_concat():
    result = Map({'a': Sum(1), 'b': Sum(2)}).concat(Map({'a': Sum(4), 'b': Sum(5)}))
    print(result)



# Generated at 2022-06-21 19:38:49.161813
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1
    assert Sum(1) == Sum(1)
    assert Sum(2).value == 2



# Generated at 2022-06-21 19:38:51.129986
# Unit test for method __str__ of class Max
def test_Max___str__():
    """
    Tests for method test_Max___str__ of Max
    """
    max_ = Max(1)
    assert str(max_) == "Max[value=1]"


# Unit tests for method concat of class Max

# Generated at 2022-06-21 19:38:56.724907
# Unit test for method concat of class One
def test_One_concat():  # pragma: no cover
    # None
    assert One(False).concat(One(True)).value == True
    assert One(None).concat(One(True)).value == True
    assert One(False).concat(One(None)).value == None
    assert One(None).concat(One(None)).value == None
    # Boolean
    assert One(True).concat(One(True)).value == True
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(False)).value == False

# Generated at 2022-06-21 19:39:25.282826
# Unit test for constructor of class One
def test_One():
    assert One(True).concat(One(True)).value == True
    assert One(False).concat(One(True)).value == True
    assert One(True).concat(One(False)).value == True
    assert One(False).concat(One(False)).value == False


# Generated at 2022-06-21 19:39:28.605339
# Unit test for method concat of class Min
def test_Min_concat():
    semigroup = Min(10)
    semigroup.concat(Min(20))  
    assert semigroup.concat(Min(20)).fold(lambda x: x) == 10



# Generated at 2022-06-21 19:39:30.134856
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(5) == Sum(5)



# Generated at 2022-06-21 19:39:32.707375
# Unit test for constructor of class Map
def test_Map():
    assert Map({
        'a': Sum(1),
        'b': Sum(-1)
    }) == Map({
        'a': Sum(1),
        'b': Sum(-1)
    })


# Generated at 2022-06-21 19:39:36.532400
# Unit test for method __str__ of class One
def test_One___str__():  # pragma: no cover
    assert str(One([1, 2, 3])) == "One[value=[1, 2, 3]]"



# Generated at 2022-06-21 19:39:38.026032
# Unit test for constructor of class Last
def test_Last():
    assert  Last(2) == Last(2)


# Generated at 2022-06-21 19:39:41.355022
# Unit test for constructor of class Map
def test_Map():
    my_map = Map({1: Sum(3), 2: Sum(5)})
    assert my_map.value == {1: Sum(3), 2: Sum(5)}



# Generated at 2022-06-21 19:39:42.753197
# Unit test for method __str__ of class All
def test_All___str__():
    assert str(All(True)) == 'All[value=True]'


# Generated at 2022-06-21 19:39:47.025229
# Unit test for constructor of class Sum
def test_Sum():
    assert Sum(1).value == 1
    assert Sum(10).value == 10
    assert Sum(100).value == 100
    assert Sum(1000).value == 1000


# Generated at 2022-06-21 19:39:56.843046
# Unit test for method __str__ of class First
def test_First___str__():
    assert str(First(1)) == 'Fist[value=1]'
    assert str(First((1, 2, 3))) == 'Fist[value=(1, 2, 3)]'
    assert str(First([1, 2, 3])) == 'Fist[value=[1, 2, 3]]'
    assert str(First({'a': 1, 'b': 2})) == "Fist[value={'a': 1, 'b': 2}]"
    assert str(First({'a': 1, 'b': 2}.items())) == "Fist[value=dict_items([('a', 1), ('b', 2)])]"
    assert str(First(True)) == 'Fist[value=True]'
    assert str(First(False)) == 'Fist[value=False]'


# Generated at 2022-06-21 19:40:45.884363
# Unit test for constructor of class Max
def test_Max():
    max = Max(1)
    assert max.value == 1


# Generated at 2022-06-21 19:40:48.859332
# Unit test for method __str__ of class Map
def test_Map___str__():
    value = Map({1: Min(4), 0: Max(4)})
    assert str(value) == 'Map[value={0: Max[value=4], 1: Min[value=4]}]'

test_Map___str__()

# Generated at 2022-06-21 19:40:51.070630
# Unit test for method __str__ of class Last
def test_Last___str__():
    assert str(Last(2)) == 'Last[value=2]'



# Generated at 2022-06-21 19:40:52.562720
# Unit test for method __str__ of class First
def test_First___str__():
    assert First(1).__str__() == 'Fist[value=1]'



# Generated at 2022-06-21 19:40:54.043047
# Unit test for constructor of class One
def test_One():
    assert One(True).value==True
    assert One(False).value==False


# Generated at 2022-06-21 19:40:57.329324
# Unit test for method __str__ of class Max
def test_Max___str__():
    test_value = 1

    assert str(Max(test_value)) == "Max[value={}]".format(test_value)


# Generated at 2022-06-21 19:40:58.797222
# Unit test for constructor of class Last
def test_Last():
    l = Last(2)  # Pass
    assert l.value == l.value


# Generated at 2022-06-21 19:41:05.635723
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    Unit test for constructor of class Semigroup
    """
    assert isinstance(Sum(1), Semigroup)
    assert isinstance(All(True), Semigroup)
    assert isinstance(One(False), Semigroup)
    assert isinstance(First(1), Semigroup)
    assert isinstance(Last(1), Semigroup)
    assert isinstance(Map({'a': Last(1)}), Semigroup)
    assert isinstance(Max(1), Semigroup)
    assert isinstance(Min(1), Semigroup)



# Generated at 2022-06-21 19:41:07.661577
# Unit test for method concat of class All
def test_All_concat():
    val1 = All(True)
    val2 = All(False)
    val3 = val1.concat(val2)
    assert val3 == All(False)


# Generated at 2022-06-21 19:41:09.334265
# Unit test for method __str__ of class Last
def test_Last___str__():  # pragma: no cover
    last = Last('last')
    assert str(last) == 'Last[value=last]'



# Generated at 2022-06-21 19:43:06.641201
# Unit test for method concat of class Map
def test_Map_concat():
    m1 = Map({"a": Sum(1), "b": Sum(2), "c": Sum(3)})
    m2 = Map({"b": Sum(4), "c": Sum(5), "d": Sum(6)})
    assert m1.concat(m2) == Map({"a": Sum(1), "b": Sum(6), "c": Sum(8), "d": Sum(6)})

# Generated at 2022-06-21 19:43:11.754047
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Sum(1) == Sum(1)
    assert All(True) == All(True)
    assert One(False) == One(False)
    assert First(1) == First(1)
    assert Last(2) == Last(2)
    assert Map({1: One(False)}) == Map({1: One(False)})
    assert Max(1) == Max(1)
    assert Min(2) == Min(2)



# Generated at 2022-06-21 19:43:15.440240
# Unit test for method concat of class Min
def test_Min_concat():
    assert Min(1).concat(Min(2)) == Min(1)
    assert Min(2).concat(Min(1)) == Min(1)
    assert Min(3).concat(Min(3)) == Min(3)



# Generated at 2022-06-21 19:43:17.977771
# Unit test for constructor of class Semigroup
def test_Semigroup():
    """
    :returns: assertion if semigroup constructed properly
    :rtype: None
    """
    semigroup = Semigroup(1)
    assert semigroup.value == 1



# Generated at 2022-06-21 19:43:21.358067
# Unit test for method concat of class Last
def test_Last_concat():
    semigroup_a = Last('a')
    semigroup_b = Last('b')
    assert semigroup_a.concat(semigroup_b) == Last('b')


# Generated at 2022-06-21 19:43:26.043967
# Unit test for method concat of class First
def test_First_concat():
    first1 = First(1)
    first2 = First(2)
    assert first1.concat(first2) == first1
    assert first2.concat(first1) == first1



# Generated at 2022-06-21 19:43:29.893645
# Unit test for method concat of class Sum
def test_Sum_concat():
    s1 = Sum(1)
    s2 = Sum(2)
    assert s1.concat(s2) == Sum(3)


# Generated at 2022-06-21 19:43:31.822578
# Unit test for method concat of class First
def test_First_concat():
    assert First("a").concat(First("b")).value == "a"


# Generated at 2022-06-21 19:43:33.163802
# Unit test for method __str__ of class Min
def test_Min___str__():
    assert str(Min(1)) == 'Min[value=1]'



# Generated at 2022-06-21 19:43:34.406414
# Unit test for method __eq__ of class Semigroup
def test_Semigroup___eq__():
    assert Semigroup(1) == Semigroup(1)

