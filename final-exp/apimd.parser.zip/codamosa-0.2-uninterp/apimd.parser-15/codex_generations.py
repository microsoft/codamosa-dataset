

# Generated at 2022-06-17 16:30:43.888790
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    r = Resolver('', {})
    assert r.visit(Constant('int')) == Name('int', Load())
    assert r.visit(Constant('int[]')) == Subscript(Name('int', Load),
                                                   Tuple(elts=[], ctx=Load()),
                                                   Load())
    assert r.visit(Constant('int[int]')) == Subscript(Name('int', Load),
                                                      Tuple(elts=[Name('int', Load)], ctx=Load()),
                                                      Load())
    assert r.visit(Constant('int[int, int]')) == Subscript(Name('int', Load),
                                                           Tuple(elts=[Name('int', Load), Name('int', Load)], ctx=Load()),
                                                           Load())


# Generated at 2022-06-17 16:30:52.908562
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from importlib import import_module
    from pathlib import Path
    from typing import Dict, List, Optional, Tuple
    from typing_extensions import Literal
    from . import Parser
    from . import _I, _G, _API
    from . import _attr, _m, _parse
    from . import get_docstring, walk_body
    from . import Import, ImportFrom, Module, Name, FunctionDef, ClassDef
    from . import AnnAssign, Assign, Delete, Constant, arguments, arg
    from . import expr, stmt
    from . import ANY, const_type, is_public_family, is_magic
    from . import esc_underscore, doctest, table, code
    from . import parent, _defaults
    from . import Resolver
    from . import unparse
    from . import logger


# Generated at 2022-06-17 16:30:57.442770
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert unparse(Resolver("", {}).visit_Subscript(
        Subscript(Name("Union", Load()), Tuple(
            [Name("int", Load()), Name("str", Load())], Load()), Load()
        )
    )) == "Union[int, str]"
    assert unparse(Resolver("", {}).visit_Subscript(
        Subscript(Name("Optional", Load()), Name("int", Load()), Load())
    )) == "Optional[int]"
    assert unparse(Resolver("", {}).visit_Subscript(
        Subscript(Name("List", Load()), Tuple(
            [Name("int", Load())], Load()), Load()
        )
    )) == "List[int]"

# Generated at 2022-06-17 16:31:01.805217
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()

# Generated at 2022-06-17 16:31:06.899509
# Unit test for method compile of class Parser
def test_Parser_compile():
    from . import test_data
    from .test_data import *
    from .test_data import __all__ as _all
    from .test_data import __version__ as _version
    from .test_data import __author__ as _author
    from .test_data import __license__ as _license
    from .test_data import __email__ as _email
    from .test_data import __url__ as _url
    from .test_data import __doc__ as _doc
    from .test_data import __package__ as _package
    from .test_data import __file__ as _file
    from .test_data import __cached__ as _cached
    from .test_data import __loader__ as _loader
    from .test_data import __spec__ as _spec

# Generated at 2022-06-17 16:31:11.230312
# Unit test for method api of class Parser
def test_Parser_api():
    from typing import List, Tuple
    from ast import parse, FunctionDef, ClassDef, arguments, expr, stmt, arg
    from ast import Name, Constant, Tuple, List, Import, ImportFrom, Assign
    from ast import AnnAssign, Delete, AsyncFunctionDef
    from ast import Module
    from ast import parse as parse_ast
    from asttokens import ASTTokens
    from asttokens.util import get_docstring
    from asttokens.util import walk_body
    from asttokens.util import get_docstring
    from asttokens.util import walk_body
    from asttokens.util import get_docstring
    from asttokens.util import walk_body
    from asttokens.util import get_docstring
    from asttokens.util import walk_body

# Generated at 2022-06-17 16:31:21.240147
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    assert Resolver('', {}).visit_Constant(Constant('a')) == Name('a', Load())
    assert Resolver('', {}).visit_Constant(Constant('a.b')) == Name('a.b', Load())
    assert Resolver('', {}).visit_Constant(Constant('a.b.c')) == Name('a.b.c', Load())
    assert Resolver('', {}).visit_Constant(Constant('a.b.c.d')) == Name('a.b.c.d', Load())
    assert Resolver('', {}).visit_Constant(Constant('a.b.c.d.e')) == Name('a.b.c.d.e', Load())

# Generated at 2022-06-17 16:31:30.949213
# Unit test for function doctest
def test_doctest():
    assert doctest("") == ""
    assert doctest(">>> a") == "```python\n>>> a\n```"
    assert doctest(">>> a\n>>> b") == "```python\n>>> a\n>>> b\n```"
    assert doctest(">>> a\nb") == "```python\n>>> a\n```\nb"
    assert doctest(">>> a\n>>> b\nc") == "```python\n>>> a\n>>> b\n```\nc"
    assert doctest(">>> a\n>>> b\n>>> c") == "```python\n>>> a\n>>> b\n>>> c\n```"

# Generated at 2022-06-17 16:31:38.557996
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser()
    p.func_api('', '', arguments(args=[arg('a', None)], vararg=arg('*b', None)), None)
    assert p.doc[''] == '#  a()\n\n*Full name:* `a`\n\n' + table('a', '*b', 'return', items=[['', '', '']])
    p.func_api('', '', arguments(args=[arg('a', None)], vararg=arg('*b', None)), None, has_self=True)
    assert p.doc[''] == '#  a()\n\n*Full name:* `a`\n\n' + table('Self', 'a', '*b', 'return', items=[['', '', '', '']])

# Generated at 2022-06-17 16:31:50.009311
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) == Name('List', Load())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', Store())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', Del())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', Param())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', AugLoad())

# Generated at 2022-06-17 16:34:54.711466
# Unit test for function walk_body
def test_walk_body():
    """Test for function walk_body."""
    from ast import parse
    from astunparse import unparse
    from .logger import logger
    logger.setLevel('DEBUG')
    code = """
if True:
    def f():
        pass
    def g():
        pass
else:
    def h():
        pass
    def i():
        pass
    if True:
        def j():
            pass
        def k():
            pass
    else:
        def l():
            pass
        def m():
            pass
"""
    body = cast(List[FunctionDef], parse(code).body)
    logger.debug(f"{unparse(body)}")
    logger.debug(f"{[unparse(n) for n in walk_body(body)]}")

# Generated at 2022-06-17 16:35:02.223112
# Unit test for function const_type
def test_const_type():
    assert const_type(parse("1").body[0].value) == 'int'
    assert const_type(parse("1.0").body[0].value) == 'float'
    assert const_type(parse("1j").body[0].value) == 'complex'
    assert const_type(parse("'1'").body[0].value) == 'str'
    assert const_type(parse("True").body[0].value) == 'bool'
    assert const_type(parse("[1, 2, 3]").body[0].value) == 'list[int]'
    assert const_type(parse("(1, 2, 3)").body[0].value) == 'tuple[int]'
    assert const_type(parse("{1, 2, 3}").body[0].value) == 'set[int]'
   

# Generated at 2022-06-17 16:35:12.645305
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    assert list(p.func_ann('', [arg('a', None), arg('b', None)],
                           has_self=False, cls_method=False)) == [ANY, ANY]
    assert list(p.func_ann('', [arg('a', None), arg('b', None)],
                           has_self=True, cls_method=False)) == ['Self', ANY]
    assert list(p.func_ann('', [arg('a', None), arg('b', None)],
                           has_self=True, cls_method=True)) == ['type[Self]', ANY]

# Generated at 2022-06-17 16:35:23.779820
# Unit test for method api of class Parser
def test_Parser_api():
    import ast
    from typing import List, Tuple
    from .parser import Parser
    from . import _ast
    from . import _parser
    from . import _typing
    from . import _unparse
    from . import _utils
    from . import _visitor
    from . import _walk
    from . import _writer
    from . import _yaml
    from . import _yaml_writer
    from . import _yaml_writer_test
    from . import _yaml_writer_test_data
    from . import _yaml_writer_test_data_test
    from . import _yaml_writer_test_data_test_data
    from . import _yaml_writer_test_data_test_data_test
    from . import _yaml_writer_test_data_test_data_test_data

# Generated at 2022-06-17 16:35:29.806200
# Unit test for method compile of class Parser
def test_Parser_compile():
    """Unit test for method compile of class Parser."""
    from . import test_parser
    p = Parser(test_parser.__file__)
    p.parse()

# Generated at 2022-06-17 16:35:39.372705
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert unparse(Resolver('', {}).visit_Subscript(
        Subscript(Name('typing', Load()),
                  Tuple(elts=[Name('int', Load()), Name('str', Load())],
                        ctx=Load()),
                  Load())
    )) == 'Union[int, str]'
    assert unparse(Resolver('', {}).visit_Subscript(
        Subscript(Name('typing', Load()), Name('int', Load()), Load())
    )) == 'Optional[int]'

# Generated at 2022-06-17 16:35:51.175701
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('a')
    assert is_public_family('a.b')
    assert is_public_family('a.b.c')
    assert not is_public_family('_a')
    assert not is_public_family('_a.b')
    assert not is_public_family('a._b')
    assert not is_public_family('a._b.c')
    assert not is_public_family('a.b._c')
    assert is_public_family('a.__b')
    assert is_public_family('a.__b.c')
    assert is_public_family('a.b.__c')



# Generated at 2022-06-17 16:36:01.959030
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser()
    p.func_api('', '', arguments(args=[arg('a', None), arg('b', None)],
                                 vararg=arg('*c', None),
                                 kwonlyargs=[arg('d', None)],
                                 kw_defaults=[None],
                                 kwarg=arg('**e', None)),
               None, has_self=False, cls_method=False)
    assert p.doc[''] == '# a()\n\n*Full name:* `a`\n\n' + table(
        'a', 'b', '*c', 'd', '**e', 'return',
        items=[('', '', '', '', '', '')])

# Generated at 2022-06-17 16:36:09.890819
# Unit test for method globals of class Parser
def test_Parser_globals():
    import ast
    from ast import Assign, Name, Constant
    from typing import List
    from typing import Tuple
    from typing import Dict
    from typing import Any
    from typing import Optional
    from typing import Union
    from typing import overload
    from typing import cast
    from typing import TYPE_CHECKING
    from typing import Callable
    from typing import TypeVar
    from typing import Generic
    from typing import Iterator
    from typing import Sequence
    from typing import Set
    from typing import Mapping
    from typing import Type
    from typing import ClassVar
    from typing import get_type_hints
    from typing import get_origin
    from typing import get_args
    from typing import get_generic_type
    from typing import get_generic_bases
    from typing import get_args
    from typing import get_origin

# Generated at 2022-06-17 16:36:18.251522
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser()
    p.func_api('', '', arguments(args=[arg('a', None)], vararg=arg('*args', None)), None, has_self=False, cls_method=False)
    assert p.doc[''] == 'Args:\n\n+ a: `Any`\n+ *args: `Any`\n+ return: `Any`\n'
    p = Parser()
    p.func_api('', '', arguments(args=[arg('a', None)], vararg=arg('*args', None)), None, has_self=True, cls_method=False)
    assert p.doc[''] == 'Args:\n\n+ self: `Self`\n+ a: `Any`\n+ *args: `Any`\n+ return: `Any`\n'