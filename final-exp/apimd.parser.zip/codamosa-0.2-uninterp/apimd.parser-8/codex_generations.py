

# Generated at 2022-06-17 16:34:30.353748
# Unit test for method imports of class Parser
def test_Parser_imports():
    """Test method imports of class Parser."""
    from . import parser
    from .parser import Parser
    from .parser import _I
    from .parser import _m
    from .parser import parent
    from .parser import Import
    from .parser import ImportFrom
    from .parser import alias
    from .parser import alias_
    from .parser import alias_from
    from .parser import alias_from_
    from .parser import alias_from_as
    from .parser import alias_from_as_
    from .parser import alias_from_as_as
    from .parser import alias_from_as_as_
    from .parser import alias_from_as_as_as
    from .parser import alias_from_as_as_as_
    from .parser import alias_from_as_as_as_as

# Generated at 2022-06-17 16:34:31.418586
# Unit test for method compile of class Parser
def test_Parser_compile():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-17 16:34:37.614420
# Unit test for method imports of class Parser
def test_Parser_imports():
    import ast
    from ast import Import, ImportFrom
    from typing import List, Tuple
    from typing_extensions import Literal
    from . import _ast_util
    from . import _ast_util
    from . import _ast_util
    from . import _ast_util
    from . import _ast_util
    from . import _ast_util
    from . import _ast_util
    from . import _ast_util
    from . import _ast_util
    from . import _ast_util
    from . import _ast_util
    from . import _ast_util
    from . import _ast_util
    from . import _ast_util
    from . import _ast_util
    from . import _ast_util
    from . import _ast_util
    from . import _ast_util
    from . import _

# Generated at 2022-06-17 16:34:50.879324
# Unit test for method api of class Parser
def test_Parser_api():
    """Test for Parser.api."""
    from ast import parse
    from typing import List, Tuple, Union
    from typing_extensions import Literal
    from typing_inspect import is_generic_type
    from . import _ast_to_source
    from . import _source_to_ast
    from . import _ast_to_source_to_ast
    from . import _source_to_ast_to_source
    from . import _ast_to_source_to_ast_to_source
    from . import _source_to_ast_to_source_to_ast
    from . import _ast_to_source_to_ast_to_source_to_ast
    from . import _source_to_ast_to_source_to_ast_to_source
    from . import _ast_to_source_to

# Generated at 2022-06-17 16:34:59.718455
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    """Test method visit_Subscript of class Resolver."""
    resolver = Resolver('', {})
    assert resolver.visit_Subscript(parse('Union[int, str]').body[0].value) == \
        parse('int | str').body[0].value
    assert resolver.visit_Subscript(parse('Optional[int]').body[0].value) == \
        parse('int | None').body[0].value
    assert resolver.visit_Subscript(parse('List[int]').body[0].value) == \
        parse('List[int]').body[0].value
    assert resolver.visit_Subscript(parse('Dict[int, str]').body[0].value) == \
        parse('Dict[int, str]').body[0].value
    assert res

# Generated at 2022-06-17 16:35:09.602253
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    """Test method visit_Subscript of class Resolver."""
    resolver = Resolver('', {})
    assert resolver.visit_Subscript(Subscript(Name('a', Load()),
                                              Tuple(elts=[Name('b', Load()),
                                                          Name('c', Load())],
                                                    ctx=Load()),
                                              Load())) == \
        BinOp(Name('b', Load()), BitOr(), Name('c', Load()))
    assert resolver.visit_Subscript(Subscript(Name('a', Load()),
                                              Name('b', Load()),
                                              Load())) == \
        Name('b', Load())

# Generated at 2022-06-17 16:35:20.532132
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    assert list(p.func_ann('root', [arg('a', None), arg('b', None)],
                           has_self=False, cls_method=False)) == [ANY, ANY]
    assert list(p.func_ann('root', [arg('a', None), arg('b', None)],
                           has_self=True, cls_method=False)) == ['Self', ANY]
    assert list(p.func_ann('root', [arg('a', None), arg('b', None)],
                           has_self=True, cls_method=True)) == ['type[Self]', ANY]

# Generated at 2022-06-17 16:35:28.264165
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser()
    p.func_api('', '', arguments(args=[arg('a', None)], vararg=arg('*b', None)), None, has_self=False, cls_method=False)
    assert p.doc[''] == 'Args:\n\n+ a\n+ *b\n+ return\n\n'
    p.func_api('', '', arguments(args=[arg('a', None)], vararg=arg('*b', None)), None, has_self=True, cls_method=False)
    assert p.doc[''] == 'Args:\n\n+ Self\n+ a\n+ *b\n+ return\n\n'

# Generated at 2022-06-17 16:35:38.471428
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    assert Resolver("", {}).visit_Constant(Constant("int")) == Name("int", Load())
    assert Resolver("", {}).visit_Constant(Constant("int()")) == Call(Name("int", Load()), [], [], None, None)
    assert Resolver("", {}).visit_Constant(Constant("int(1)")) == Call(Name("int", Load()), [Constant(1)], [], None, None)
    assert Resolver("", {}).visit_Constant(Constant("int(1, 2)")) == Call(Name("int", Load()), [Constant(1), Constant(2)], [], None, None)

# Generated at 2022-06-17 16:35:52.175576
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert Resolver('', {}).visit_Name(Name('a', Load())) == Name('a', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a', Load())) == Name('b', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('c', Load())) == Name('c', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a.b', Load())) == Name('b', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('c.d', Load())) == Name('c.d', Load())