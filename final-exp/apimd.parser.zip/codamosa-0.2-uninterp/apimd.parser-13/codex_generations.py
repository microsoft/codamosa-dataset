

# Generated at 2022-06-17 16:34:51.685702
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert Resolver("", {}).visit(Name("a", Load())) == Name("a", Load())
    assert Resolver("", {"a": "b"}).visit(Name("a", Load())) == Name("b", Load())
    assert Resolver("", {"a": "b"}).visit(Name("b", Load())) == Name("b", Load())
    assert Resolver("", {"a": "b"}).visit(Name("c", Load())) == Name("c", Load())
    assert Resolver("", {"a": "b"}).visit(Name("a.b", Load())) == Name("b.b", Load())
    assert Resolver("", {"a": "b"}).visit(Name("a.c", Load())) == Name("b.c", Load())

# Generated at 2022-06-17 16:35:00.816569
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    p.imp['a'] = set()
    p.root['a.b'] = 'a'
    assert p.is_public('a.b')
    p.imp['a'] = {'a.b'}
    assert p.is_public('a.b')
    p.imp['a'] = {'a.c'}
    assert not p.is_public('a.b')
    p.imp['a'] = set()
    p.root['a.b'] = 'a'
    assert p.is_public('a.b.c')
    p.imp['a'] = {'a.b'}
    assert p.is_public('a.b.c')
    p.imp['a'] = {'a.c'}
    assert not p.is_public

# Generated at 2022-06-17 16:35:10.667096
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    """Test method visit_Name of class Resolver."""
    assert Resolver('', {}).visit_Name(Name('a', Load())) == Name('a', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a', Load())) == Name('b', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('c', Load())) == Name('c', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a.c', Load())) == Name('a.c', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a.c.d', Load())) == Name('a.c.d', Load())

# Generated at 2022-06-17 16:35:14.652495
# Unit test for function table
def test_table():
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == \
        '| a | b |\n|:---:|:---:|\n| c | d |\n| e | f |\n\n'



# Generated at 2022-06-17 16:35:25.238089
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    p.imp['a'] = {'a', 'a.b', 'a.b.c'}
    p.root['a'] = 'a'
    p.root['a.b'] = 'a'
    p.root['a.b.c'] = 'a'
    p.root['a.b.c.d'] = 'a'
    p.root['a.b.c.d.e'] = 'a'
    p.root['a.b.c.d.e.f'] = 'a'
    p.root['a.b.c.d.e.f.g'] = 'a'
    p.root['a.b.c.d.e.f.g.h'] = 'a'

# Generated at 2022-06-17 16:35:30.624192
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    from ast import ClassDef, Name, arguments, arg, Assign, Name as N, Constant
    from ast import FunctionDef, arguments as a, arg as a_, Return
    from ast import parse, Module, Expr, Str, Load, Store, Del, Attribute
    from ast import Subscript, Index, List, Tuple, Call, keyword, alias
    from ast import parse as p, Module as M, Expr as E, Str as S, Load as L
    from ast import Store as St, Del as D, Attribute as A, Subscript as Su
    from ast import Index as I, List as Li, Tuple as T, Call as C, keyword as k
    from ast import alias as al, parse as pa, Module as Mo, Expr as Ex, Str as S
    from ast import Load as Lo, Store as St, Del as D, Attribute as A

# Generated at 2022-06-17 16:35:39.844993
# Unit test for method compile of class Parser
def test_Parser_compile():
    from . import parser
    from . import resolver
    from . import visitor
    from . import unparse
    from . import get_docstring
    from . import getdoc
    from . import _attr
    from . import doctest
    from . import walk_body
    from . import is_public_family
    from . import is_magic
    from . import logger
    from . import code
    from . import table
    from . import parent
    from . import esc_underscore
    from . import ANY
    from . import const_type
    from . import _m
    from . import _I
    from . import _G
    from . import _API
    from . import _defaults
    from . import chain
    from . import ModuleType
    from . import Sequence
    from . import Iterator
    from . import tuple

# Generated at 2022-06-17 16:35:52.565599
# Unit test for function const_type
def test_const_type():
    assert const_type(Constant(1)) == 'int'
    assert const_type(Constant(1.0)) == 'float'
    assert const_type(Constant(1.0j)) == 'complex'
    assert const_type(Constant(True)) == 'bool'
    assert const_type(Constant('a')) == 'str'
    assert const_type(Constant(None)) == 'NoneType'
    assert const_type(Constant(Ellipsis)) == 'ellipsis'
    assert const_type(Constant(NotImplemented)) == 'NotImplementedType'
    assert const_type(Constant(...)) == '...'
    assert const_type(Constant(1, kind='annotation')) == 'int'

# Generated at 2022-06-17 16:36:03.244259
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser()
    p.func_api('a', 'a.b', arguments(args=[arg('a', None)],
                                     kwonlyargs=[arg('b', None)],
                                     kw_defaults=[None]),
               None, has_self=False, cls_method=False)
    assert p.doc['a.b'] == '# b()\n\n*Full name:* `a.b`\n\n' + \
        '| Argument | Type |\n' + \
        '| --- | --- |\n' + \
        '| a | Any |\n' + \
        '| b | Any |\n' + \
        '| return | Any |\n'

# Generated at 2022-06-17 16:36:06.386360
# Unit test for method compile of class Parser
def test_Parser_compile():
    """Unit test for method compile of class Parser."""
    from . import parser
    from . import __main__
    p = parser.Parser(__main__.__file__)
    p.parse()
    assert p.compile()