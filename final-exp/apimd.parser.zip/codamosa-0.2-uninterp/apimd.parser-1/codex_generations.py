

# Generated at 2022-06-17 16:32:39.403398
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser()
    p.func_api('', '', arguments(args=[arg('a', None)], vararg=arg('*args', None)), None, has_self=False, cls_method=False)
    assert p.doc[''] == 'Args:\n\n+ a: Any\n+ *args: Any\n+ return: Any\n\n'
    p.func_api('', '', arguments(args=[arg('a', None)], vararg=arg('*args', None)), None, has_self=True, cls_method=False)
    assert p.doc[''] == 'Args:\n\n+ Self\n+ a: Any\n+ *args: Any\n+ return: Any\n\n'

# Generated at 2022-06-17 16:32:44.236688
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    from ast import ClassDef, FunctionDef, Assign, Name, Constant, Delete, parse
    from ast import parse as ast_parse
    from typing import List, Tuple, Dict, Any
    from typing import cast
    from typing import TYPE_CHECKING
    if TYPE_CHECKING:
        from typing import Type
    class Parser:
        def __init__(self, *, link: bool = False, toc: bool = False) -> None:
            self.link = link
            self.toc = toc
            self.alias: Dict[str, str] = {}
            self.doc: Dict[str, str] = {}
            self.docstring: Dict[str, str] = {}
            self.root: Dict[str, str] = {}
            self.level: Dict[str, int] = {}
           

# Generated at 2022-06-17 16:32:49.623826
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    """Unit test for method func_ann of class Parser."""
    from ast import parse, arguments, arg, Name, Call, Attribute, Subscript
    from ast import Load, NameConstant, Tuple, List, Index, Constant
    from ast import parse, arguments, arg, Name, Call, Attribute, Subscript
    from ast import Load, NameConstant, Tuple, List, Index, Constant
    from ast import parse, arguments, arg, Name, Call, Attribute, Subscript
    from ast import Load, NameConstant, Tuple, List, Index, Constant
    from ast import parse, arguments, arg, Name, Call, Attribute, Subscript
    from ast import Load, NameConstant, Tuple, List, Index, Constant
    from ast import parse, arguments, arg, Name, Call, Attribute, Subscript
    from ast import Load, Name

# Generated at 2022-06-17 16:32:54.026252
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    import typing
    from typing import List
    from typing import List as L
    from typing import List as L, Dict as D
    from typing import List as L, Dict as D, Tuple as T
    from typing import List as L, Dict as D, Tuple as T, Set as S
    from typing import List as L, Dict as D, Tuple as T, Set as S, Union as U
    from typing import List as L, Dict as D, Tuple as T, Set as S, Union as U, Optional as O
    from typing import List as L, Dict as D, Tuple as T, Set as S, Union as U, Optional as O, Any as A
    from typing import List as L, Dict as D, Tuple as T, Set as S, Union as U, Optional as O, Any as A, Callable as C

# Generated at 2022-06-17 16:33:04.792738
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    parser = Parser()
    parser.imp['a'] = {'a.b', 'a.c'}
    parser.imp['a.b'] = {'a.b.c'}
    parser.imp['a.b.c'] = {'a.b.c.d'}
    parser.imp['a.b.c.d'] = set()
    parser.imp['a.b.c.d.e'] = set()
    parser.imp['a.b.c.d.e.f'] = set()
    parser.imp['a.b.c.d.e.f.g'] = set()
    parser.imp['a.b.c.d.e.f.g.h'] = set()

# Generated at 2022-06-17 16:33:09.971942
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert Resolver('', {}).visit(parse('typing.List').body[0].value) == Name('List', Load())
    assert Resolver('', {}).visit(parse('typing.List[int]').body[0].value) == Subscript(Name('List', Load), Tuple(elts=[Constant(int, kind=None)], ctx=Load()), Load())
    assert Resolver('', {}).visit(parse('typing.List[int, str]').body[0].value) == Subscript(Name('List', Load), Tuple(elts=[Constant(int, kind=None), Constant(str, kind=None)], ctx=Load()), Load())

# Generated at 2022-06-17 16:33:16.210680
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert Resolver('', {}).visit_Name(Name('a', Load())) == Name('a', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a', Load())) == Name('b', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('c', Load())) == Name('c', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a.c', Load())) == Name('a.c', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a.c.d', Load())) == Name('a.c.d', Load())
    assert Resolver('', {'a.c': 'b'}).visit

# Generated at 2022-06-17 16:33:26.310627
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    assert list(p.func_ann('a', [arg('a', None), arg('b', None)])) == [ANY, ANY]
    assert list(p.func_ann('a', [arg('a', None), arg('b', None)], has_self=True)) == ['Self', ANY]
    assert list(p.func_ann('a', [arg('a', None), arg('b', None)], cls_method=True)) == ['type[Self]', ANY]
    assert list(p.func_ann('a', [arg('a', None), arg('b', None)], has_self=True, cls_method=True)) == ['type[Self]', ANY]

# Generated at 2022-06-17 16:33:32.185343
# Unit test for method imports of class Parser
def test_Parser_imports():
    from . import ast_
    from . import parse
    from . import unparse
    from . import _m
    from . import _I
    from . import _G
    from . import _API
    from . import ANY
    from . import Resolver
    from . import code
    from . import walk_body
    from . import get_docstring
    from . import doctest
    from . import const_type
    from . import table
    from . import _defaults
    from . import _attr
    from . import getdoc
    from . import is_public_family
    from . import is_magic
    from . import esc_underscore
    from . import parent
    from . import logger
    from . import chain
    from . import ModuleType
    from . import arg
    from . import expr
    from . import stmt
   

# Generated at 2022-06-17 16:33:37.238481
# Unit test for method compile of class Parser
def test_Parser_compile():
    from . import __main__
    from . import __version__
    from . import __author__
    from . import __license__
    from . import __doc__
    from . import __all__
    from . import __url__
    from . import __email__
    from . import __copyright__
    from . import __credits__
    from . import __status__
    from . import __package__
    from . import __file__
    from . import __loader__
    from . import __builtins__
    from . import __spec__
    from . import __name__
    from . import __path__
    from . import __docformat__
    from . import __cached__
    from . import __initializing__
    from . import __config__
    from . import __main__
    from . import __version__
   