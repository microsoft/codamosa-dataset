

# Generated at 2022-06-17 16:34:29.961925
# Unit test for function walk_body

# Generated at 2022-06-17 16:34:36.361484
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert Resolver('', {}).visit_Name(Name('a', Load())) == Name('a', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a', Load())) == Name('b', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('c', Load())) == Name('c', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a.c', Load())) == Name('a.c', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a.c.d', Load())) == Name('a.c.d', Load())
    assert Resolver('', {'a.c': 'b'}).visit

# Generated at 2022-06-17 16:34:50.643255
# Unit test for method api of class Parser
def test_Parser_api():
    from ast import parse
    from typing import List
    from typing import Tuple
    from typing import Union
    from typing import overload
    from typing import cast
    from typing import TYPE_CHECKING
    from typing import Any
    from typing import Callable
    from typing import Optional
    from typing import TypeVar
    from typing import Generic
    from typing import Type
    from typing import cast
    from typing import get_type_hints
    from typing import get_origin
    from typing import get_args
    from typing import NewType
    from typing import Literal
    from typing import NamedTuple
    from typing import Union
    from typing import Tuple
    from typing import List
    from typing import Dict
    from typing import Set
    from typing import FrozenSet
    from typing import Deque
    from typing import DefaultDict
    from typing import Counter


# Generated at 2022-06-17 16:34:59.628326
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser()
    p.func_api('root', 'root.func', arguments(
        args=[arg('a', None), arg('b', None)],
        vararg=arg('*args', None),
        kwonlyargs=[arg('c', None), arg('d', None)],
        kwarg=arg('**kwargs', None),
        defaults=[None, None],
        kw_defaults=[None, None],
    ), None, has_self=False, cls_method=False)

# Generated at 2022-06-17 16:35:09.533439
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from typing import List
    from ast import parse, arguments, arg, Name, Constant, Str, Num, Tuple, \
        List as List_, Dict, Call, Attribute, Subscript, Index, \
        Ellipsis, NameConstant, keyword, expr, expr_context
    from astor import unparse
    from ast_toolbox import get_docstring, walk_body, get_args
    from ast_toolbox.ast_toolbox import get_annotation
    from ast_toolbox.ast_toolbox import get_defaults
    from ast_toolbox.ast_toolbox import get_kwonlyargs
    from ast_toolbox.ast_toolbox import get_kw_defaults
    from ast_toolbox.ast_toolbox import get_vararg
    from ast_toolbox.ast_toolbox import get_kwarg

# Generated at 2022-06-17 16:35:20.201095
# Unit test for function walk_body
def test_walk_body():
    def test(body: Sequence[stmt]) -> Sequence[stmt]:
        return list(walk_body(body))
    assert test([]) == []
    assert test([arg(arg='a', annotation=None)]) == [arg(arg='a', annotation=None)]
    assert test([arg(arg='a', annotation=None), arg(arg='b', annotation=None)]) == [
        arg(arg='a', annotation=None), arg(arg='b', annotation=None)
    ]
    assert test([
        arg(arg='a', annotation=None),
        If(test=Constant(value=True), body=[arg(arg='b', annotation=None)], orelse=[]),
    ]) == [
        arg(arg='a', annotation=None),
        arg(arg='b', annotation=None),
    ]


# Generated at 2022-06-17 16:35:28.081935
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) == Name('List', Load())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', Store())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', Del())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', Param())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', AugLoad())

# Generated at 2022-06-17 16:35:38.470862
# Unit test for method api of class Parser
def test_Parser_api():
    """Test Parser.api."""
    from . import ast_
    from .ast_ import parse
    from .parser import Parser
    from .utils import unparse
    from .visitor import Visitor
    from .visitor import visit
    from .visitor import generic_visit
    from .visitor import visit_children
    from .visitor import visit_children_with_name
    from .visitor import visit_children_with_type
    from .visitor import visit_children_with_type_and_name
    from .visitor import visit_children_with_type_and_name_and_value
    from .visitor import visit_children_with_type_and_value
    from .visitor import visit_children_with_value
    from .visitor import visit_children_with_value_and_name

# Generated at 2022-06-17 16:35:52.143039
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    p.imp['a'] = {'a', 'a.b', 'a.c'}
    p.root['a'] = 'a'
    p.root['a.b'] = 'a'
    p.root['a.c'] = 'a'
    p.root['a.d'] = 'a'
    p.root['a.e'] = 'a'
    p.root['a.f'] = 'a'
    p.root['a.g'] = 'a'
    p.root['a.h'] = 'a'
    p.root['a.i'] = 'a'
    p.root['a.j'] = 'a'
    p.root['a.k'] = 'a'
    p.root['a.l'] = 'a'
    p

# Generated at 2022-06-17 16:36:02.764044
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    assert Resolver("", {}).visit_Constant(Constant("str")) == Name("str", Load())
    assert Resolver("", {}).visit_Constant(Constant(1)) == Constant(1)
    assert Resolver("", {}).visit_Constant(Constant("1")) == Constant("1")
    assert Resolver("", {}).visit_Constant(Constant("a.b")) == Name("a.b", Load())
    assert Resolver("", {}).visit_Constant(Constant("a.b.c")) == Name("a.b.c", Load())
    assert Resolver("", {}).visit_Constant(Constant("a.b.c.d")) == Name("a.b.c.d", Load())

# Generated at 2022-06-17 16:37:16.206855
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser(None, None)
    args = [
        arg('a', Name(id='int', ctx=Load())),
        arg('b', Name(id='str', ctx=Load())),
        arg('c', Name(id='float', ctx=Load())),
        arg('return', Name(id='bool', ctx=Load())),
    ]
    assert list(p.func_ann('', args, has_self=False, cls_method=False)) == [
        'int', 'str', 'float', 'bool',
    ]
    assert list(p.func_ann('', args, has_self=True, cls_method=False)) == [
        'Self', 'int', 'str', 'float', 'bool',
    ]

# Generated at 2022-06-17 16:37:26.554964
# Unit test for method compile of class Parser
def test_Parser_compile():
    from . import __main__
    from . import __init__
    from . import __version__
    from . import _ast
    from . import _builtin
    from . import _const
    from . import _doc
    from . import _func
    from . import _type
    from . import _util
    from . import _walk
    from . import _writer
    from . import _writer_ast
    from . import _writer_builtin
    from . import _writer_const
    from . import _writer_doc
    from . import _writer_func
    from . import _writer_type
    from . import _writer_util
    from . import _writer_walk
    from . import _writer_writer
    from . import _writer_writer_ast
    from . import _writer_writer_builtin
    from . import _writer