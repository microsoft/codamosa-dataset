

# Generated at 2022-06-17 16:33:27.206258
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    p.func_ann('root', [arg('a', Name(id='int', ctx=Load()))])
    p.func_ann('root', [arg('a', Name(id='int', ctx=Load()))], has_self=True)
    p.func_ann('root', [arg('a', Name(id='int', ctx=Load()))], cls_method=True)
    p.func_ann('root', [arg('a', Name(id='int', ctx=Load()))], has_self=True, cls_method=True)
    p.func_ann('root', [arg('a', Name(id='int', ctx=Load()))], has_self=True, cls_method=False)

# Generated at 2022-06-17 16:33:32.837420
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    assert list(p.func_ann('', [], has_self=False, cls_method=False)) == []
    assert list(p.func_ann('', [arg('', None)], has_self=False, cls_method=False)) == ['ANY']
    assert list(p.func_ann('', [arg('', None)], has_self=True, cls_method=False)) == ['Self']
    assert list(p.func_ann('', [arg('', None)], has_self=True, cls_method=True)) == ['type[Self]']
    assert list(p.func_ann('', [arg('', None), arg('', None)], has_self=True, cls_method=False)) == ['Self', 'ANY']

# Generated at 2022-06-17 16:33:37.858991
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    assert list(p.func_ann('', [arg('a', None)], has_self=False, cls_method=False)) == ['Any']
    assert list(p.func_ann('', [arg('a', None)], has_self=True, cls_method=False)) == ['Self', 'Any']
    assert list(p.func_ann('', [arg('a', None)], has_self=True, cls_method=True)) == ['type[Self]', 'Any']
    assert list(p.func_ann('', [arg('a', None)], has_self=False, cls_method=True)) == ['Any']

# Generated at 2022-06-17 16:33:50.828571
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    from ast import parse
    from .data_structures import Resolver
    from .pep585 import PEP585
    for k, v in PEP585.items():
        assert isinstance(parse(k).body[0], Subscript)
        assert isinstance(parse(v).body[0], Name)
        assert Resolver('', {}).visit(parse(k).body[0]) == parse(v).body[0]
    assert isinstance(parse('typing.Optional[int]').body[0], Subscript)
    assert isinstance(parse('typing.Optional[int]').body[0].slice, Tuple)
    assert isinstance(parse('typing.Optional[int]').body[0].slice.elts[0], Name)

# Generated at 2022-06-17 16:33:58.769816
# Unit test for function doctest
def test_doctest():
    assert doctest("""
    >>> a = 1
    >>> b = 2
    """) == """
    ```python
    >>> a = 1
    >>> b = 2
    ```
    """
    assert doctest("""
    >>> a = 1
    >>> b = 2
    >>> c = 3
    """) == """
    ```python
    >>> a = 1
    >>> b = 2
    >>> c = 3
    ```
    """
    assert doctest("""
    >>> a = 1
    >>> b = 2
    >>> c = 3
    >>> d = 4
    """) == """
    ```python
    >>> a = 1
    >>> b = 2
    >>> c = 3
    >>> d = 4
    ```
    """

# Generated at 2022-06-17 16:34:03.451585
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    import ast
    from typing import List, Tuple
    from . import Parser
    from . import _I, _G, _API
    from . import Import, ImportFrom, Global, FunctionDef, ClassDef, arguments
    from . import arg, Name, Constant, Tuple, List, expr, stmt
    from . import Resolver
    from . import unparse
    from . import ANY
    from . import code
    from . import _m
    from . import _attr
    from . import get_docstring
    from . import doctest
    from . import walk_body
    from . import parent
    from . import is_public_family
    from . import is_magic
    from . import esc_underscore
    from . import const_type
    from . import table
    from . import _defaults
    from . import logger

# Generated at 2022-06-17 16:34:12.913605
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser()
    p.func_api('', '', arguments(args=[arg('a', None), arg('b', None)],
                                 vararg=arg('*c', None),
                                 kwonlyargs=[arg('d', None)],
                                 kw_defaults=[None, None]),
               None, has_self=False, cls_method=False)
    assert p.doc[''] == '# a()\n\n*Full name:* `a`\n\n' + table(
        'a', 'b', '*c', 'd', 'return',
        items=[('Any', 'Any', 'Any', 'Any', 'Any')])
    p.doc.clear()

# Generated at 2022-06-17 16:34:17.879518
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    alias = {'a': 'b', 'c': 'd'}
    resolver = Resolver('', alias)
    assert resolver.visit(Name('a', Load())) == Name('b', Load())
    assert resolver.visit(Name('c', Load())) == Name('d', Load())
    assert resolver.visit(Name('e', Load())) == Name('e', Load())

# Generated at 2022-06-17 16:34:28.230956
# Unit test for method globals of class Parser
def test_Parser_globals():
    from typing import Any, List, Tuple
    from typing_extensions import Literal
    from mypy_extensions import TypedDict
    from ast import Module, Assign, Name, Constant, Tuple, List, Import, ImportFrom
    from ast import alias, arguments, arg, expr, stmt, expr_context, slice
    from ast import ClassDef, FunctionDef, AsyncFunctionDef, AnnAssign, Delete
    from ast import keyword, arguments, arg, expr, stmt, expr_context, slice
    from ast import ClassDef, FunctionDef, AsyncFunctionDef, AnnAssign, Delete
    from ast import keyword, arguments, arg, expr, stmt, expr_context, slice
    from ast import ClassDef, FunctionDef, AsyncFunctionDef, AnnAssign, Delete
    from ast import keyword, arguments, arg, expr, stmt, expr

# Generated at 2022-06-17 16:34:34.870291
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    """Test method visit_Subscript of class Resolver."""
    resolver = Resolver('', {})
    assert resolver.visit_Subscript(Subscript(Name('a', Load()),
                                              Tuple(elts=[Name('b', Load()),
                                                          Name('c', Load())],
                                                    ctx=Load()),
                                              Load())) == BinOp(Name('b', Load()),
                                                                BitOr(),
                                                                Name('c', Load()))
    assert resolver.visit_Subscript(Subscript(Name('a', Load()),
                                              Name('b', Load()),
                                              Load())) == Name('b', Load())

# Generated at 2022-06-17 16:37:16.982818
# Unit test for function walk_body
def test_walk_body():
    from ast import parse, If, Try
    from ast import parse, If, Try
    from ast import parse, If, Try
    from ast import parse, If, Try
    from ast import parse, If, Try
    from ast import parse, If, Try
    from ast import parse, If, Try
    from ast import parse, If, Try
    from ast import parse, If, Try
    from ast import parse, If, Try
    from ast import parse, If, Try
    from ast import parse, If, Try
    from ast import parse, If, Try
    from ast import parse, If, Try
    from ast import parse, If, Try
    from ast import parse, If, Try
    from ast import parse, If, Try
    from ast import parse, If, Try
    from ast import parse, If, Try
    from ast import parse, If, Try

# Generated at 2022-06-17 16:37:26.723187
# Unit test for method parse of class Parser
def test_Parser_parse():
    """Test for method parse of class Parser."""
    from . import test_parser
    p = Parser()
    p.parse(test_parser.__file__)
    assert p.doc['test_parser.A'] == '# class A\n\n*Full name:* `test_parser.A`\n\n'
    assert p.doc['test_parser.A.a'] == '## a()\n\n*Full name:* `test_parser.A.a`\n\n'
    assert p.doc['test_parser.A.b'] == '## b()\n\n*Full name:* `test_parser.A.b`\n\n'