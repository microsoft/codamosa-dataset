

# Generated at 2022-06-17 16:34:52.646548
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    import sys
    import io
    import unittest
    from importlib import import_module
    from contextlib import redirect_stdout
    from typing import List, Tuple

    class TestParser(unittest.TestCase):
        def test_load_docstring(self):
            # type: () -> None
            """Test load_docstring()."""
            for m in ('typing', 'typing_extensions', 'typing_inspect'):
                with redirect_stdout(io.StringIO()) as f:
                    p = Parser(m)
                    p.load_docstring(m, import_module(m))
                    self.assertEqual(f.getvalue(), '')
                    self.assertTrue(all(p.docstring.values()))
                    self.assertTrue(all(p.doc.values()))

# Generated at 2022-06-17 16:35:01.462517
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert unparse(Resolver('', {}).visit_Subscript(
        Subscript(Name('a', Load()), Tuple(
            [Name('b', Load()), Name('c', Load())], Load()), Load())
    )) == 'a[b, c]'
    assert unparse(Resolver('', {}).visit_Subscript(
        Subscript(Name('typing', Load()), Tuple(
            [Name('b', Load()), Name('c', Load())], Load()), Load())
    )) == 'Union[b, c]'
    assert unparse(Resolver('', {}).visit_Subscript(
        Subscript(Name('typing', Load()), Name('b', Load()), Load())
    )) == 'Optional[b]'

# Generated at 2022-06-17 16:35:11.689443
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from importlib import import_module
    from os import path
    from sys import path as sys_path
    from typing import cast
    from types import ModuleType
    from unittest import TestCase
    from . import __file__ as root
    from . import Parser
    from . import _attr
    from . import _m
    from . import _test_data
    from . import get_docstring
    from . import is_public_family
    from . import parent
    from . import walk_body
    from . import walk_tree
    from . import _test_data
    from . import _test_data_path
    from . import _test_data_path_root
    from . import _test_data_path_root_name
    from . import _test_data_path_root_name_name
    from . import _test

# Generated at 2022-06-17 16:35:23.107710
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert Resolver('', {}).visit_Name(Name('int', Load())) == Name('int', Load())
    assert Resolver('', {'int': 'int'}).visit_Name(Name('int', Load())) == Name('int', Load())
    assert Resolver('', {'int': 'float'}).visit_Name(Name('int', Load())) == Name('float', Load())
    assert Resolver('', {'int': 'float'}).visit_Name(Name('float', Load())) == Name('float', Load())
    assert Resolver('', {'int': 'float'}).visit_Name(Name('int', Load())) == Name('float', Load())

# Generated at 2022-06-17 16:35:34.071731
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from ast import parse, Name, arguments, arg, Subscript, Index, Constant
    from typing import List, Tuple, Dict, Union, Optional, Any
    from typing import cast
    from typing_extensions import Literal
    from typing import TYPE_CHECKING
    if TYPE_CHECKING:
        from typing import Type
    class Parser:
        def __init__(self, root: str, alias: Dict[str, str], self_ty: str = "") -> None:
            self.root = root
            self.alias = alias
            self.self_ty = self_ty
        def func_ann(self, root: str, args: Sequence[arg], *,
                     has_self: bool, cls_method: bool) -> Iterator[str]:
            self_ty = ""

# Generated at 2022-06-17 16:35:41.258987
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    """Test for method visit_Name of class Resolver."""
    assert Resolver('', {}).visit_Name(Name('a', Load())) == Name('a', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a', Load())) == Name('b', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('c', Load())) == Name('c', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('b', Load())) == Name('b', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a.b', Load())) == Name('b', Load())

# Generated at 2022-06-17 16:35:53.610184
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    assert Resolver("", {}).visit_Constant(Constant("1")) == Constant("1")
    assert Resolver("", {}).visit_Constant(Constant("int")) == Constant("int")
    assert Resolver("", {}).visit_Constant(Constant("int(1)")) == Constant("int(1)")
    assert Resolver("", {}).visit_Constant(Constant("int(1, 2)")) == Constant("int(1, 2)")
    assert Resolver("", {}).visit_Constant(Constant("int[1]")) == Constant("int[1]")
    assert Resolver("", {}).visit_Constant(Constant("int[1, 2]")) == Constant("int[1, 2]")

# Generated at 2022-06-17 16:36:03.863458
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
                                                      Tuple([]), Load())) == Name('a', Load())
    assert Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
                                                      Tuple([Constant(1), Constant(2)]), Load())) == BinOp(Constant(1), BitOr(), Constant(2))
    assert Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
                                                      Constant(1), Load())) == Constant(1)

# Generated at 2022-06-17 16:36:10.809475
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert Resolver('', {}).visit_Name(Name('a', Load())) == Name('a', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a', Load())) == Name('b', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('c', Load())) == Name('c', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a', Store())) == Name('a', Store())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a', Del())) == Name('a', Del())

# Generated at 2022-06-17 16:36:19.483706
# Unit test for method api of class Parser
def test_Parser_api():
    from ast import parse
    from typing import List, Tuple
    from typing_extensions import Literal
    from typing_inspect import is_generic_type, get_origin
    from . import Parser
    from .utils import unparse
    from .utils import get_docstring
    from .utils import doctest
    from .utils import code
    from .utils import table
    from .utils import esc_underscore
    from .utils import parent
    from .utils import _m
    from .utils import _attr
    from .utils import is_public_family
    from .utils import is_magic
    from .utils import const_type
    from .utils import walk_body
    from .utils import Resolver
    from .utils import ANY
    from .utils import logger
    from .utils import _I
    from .utils import _G
   