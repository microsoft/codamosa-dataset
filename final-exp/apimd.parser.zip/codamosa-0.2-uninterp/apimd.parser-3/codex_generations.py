

# Generated at 2022-06-17 16:35:34.389114
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser()
    p.func_api('', '', arguments(args=[arg('a', None), arg('b', None)],
                                 vararg=arg('*c', None),
                                 kwonlyargs=[arg('d', None)],
                                 kw_defaults=[None, Name(id='e', ctx=Load())],
                                 kwarg=arg('**f', None)),
               None, has_self=False, cls_method=False)

# Generated at 2022-06-17 16:35:41.565096
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from inspect import Signature, Parameter
    from typing import List, Dict, Optional, Any
    from ast import parse, Name, Load, Constant, Str, Tuple, Subscript, Index, \
        Attribute, Call, arguments, arg, expr, stmt, FunctionDef, ClassDef
    from astor import unparse
    from .utils import get_docstring, getdoc
    from .parser import Parser
    from .resolver import Resolver
    from .const import ANY
    from .log import logger
    from . import __version__
    from . import __author__
    from . import __license__
    from . import __url__
    from . import __doc__
    from . import __all__
    from . import __name__
    from . import __file__
    from . import __package__
    from . import __cached__

# Generated at 2022-06-17 16:35:43.174695
# Unit test for method compile of class Parser
def test_Parser_compile():
    from . import test_parser
    p = test_parser.Parser()
    p.compile()


# Generated at 2022-06-17 16:35:54.587789
# Unit test for method globals of class Parser
def test_Parser_globals():
    from ast import parse
    from typing import TYPE_CHECKING
    if TYPE_CHECKING:
        from _pytest.monkeypatch import MonkeyPatch
    p = Parser()
    p.globals('', parse('a: int = 1').body[0])
    p.globals('', parse('a = 1').body[0])
    p.globals('', parse('a: int = 1').body[0])
    p.globals('', parse('a = 1').body[0])
    p.globals('', parse('__all__ = [1, 2]').body[0])
    p.globals('', parse('__all__ = (1, 2)').body[0])
    p.globals('', parse('__all__ = [1, 2]').body[0])
    p

# Generated at 2022-06-17 16:36:04.727898
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert Resolver("", {}).visit_Name(Name("a", Load())) == Name("a", Load())
    assert Resolver("", {"a": "b"}).visit_Name(Name("a", Load())) == Name("b", Load())
    assert Resolver("", {"a": "b"}).visit_Name(Name("c", Load())) == Name("c", Load())
    assert Resolver("", {"a": "b"}).visit_Name(Name("b", Load())) == Name("b", Load())
    assert Resolver("", {"a": "b"}).visit_Name(Name("b.c", Load())) == Name("b.c", Load())

# Generated at 2022-06-17 16:36:12.233102
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) == Name('List', Load())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', Store())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', Del())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', Param())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', AugLoad())

# Generated at 2022-06-17 16:36:20.660821
# Unit test for function const_type
def test_const_type():
    assert const_type(parse("1").body[0].value) == 'int'
    assert const_type(parse("1.0").body[0].value) == 'float'
    assert const_type(parse("1j").body[0].value) == 'complex'
    assert const_type(parse("'1'").body[0].value) == 'str'
    assert const_type(parse("True").body[0].value) == 'bool'
    assert const_type(parse("(1, 2)").body[0].value) == 'tuple[int, int]'
    assert const_type(parse("[1, 2]").body[0].value) == 'list[int, int]'
    assert const_type(parse("{1, 2}").body[0].value) == 'set[int, int]'
   

# Generated at 2022-06-17 16:36:26.771006
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert Resolver('', {}).visit_Name(Name('a', Load())) == Name('a', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a', Load())) == Name('b', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('b', Load())) == Name('b', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('c', Load())) == Name('c', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a.b', Load())) == Name('a.b', Load())

# Generated at 2022-06-17 16:36:37.301727
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    assert list(p.func_ann('', [arg('a', None), arg('b', None)],
                           has_self=True, cls_method=False)) == ['Self', ANY]
    assert list(p.func_ann('', [arg('a', None), arg('b', None)],
                           has_self=False, cls_method=False)) == [ANY, ANY]
    assert list(p.func_ann('', [arg('a', None), arg('b', None)],
                           has_self=True, cls_method=True)) == ['type[Self]', ANY]

# Generated at 2022-06-17 16:36:50.400634
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert Resolver('', {}).visit_Name(Name('a', Load())) == Name('a', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a', Load())) == Name('b', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('c', Load())) == Name('c', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a', Store())) == Name('a', Store())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('c', Store())) == Name('c', Store())