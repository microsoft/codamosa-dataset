

# Generated at 2022-06-17 16:34:25.617693
# Unit test for method parse of class Parser
def test_Parser_parse():
    from . import parser
    from . import parser_test
    from . import parser_test_data
    from . import parser_test_data_test_Parser_parse
    from . import parser_test_data_test_Parser_parse_test_data
    from . import parser_test_data_test_Parser_parse_test_data_test_data
    from . import parser_test_data_test_Parser_parse_test_data_test_data_test_data
    from . import parser_test_data_test_Parser_parse_test_data_test_data_test_data_test_data
    from . import parser_test_data_test_Parser_parse_test_data_test_data_test_data_test_data_test_data
    from . import parser_test_data_test_Parser_parse_test_data

# Generated at 2022-06-17 16:34:32.895201
# Unit test for method api of class Parser
def test_Parser_api():
    """Test method api of class Parser."""
    from ast import parse, FunctionDef, ClassDef, arguments, expr, stmt
    from typing import List, Optional, Tuple
    from typing_extensions import Literal
    from . import _I, _G, _API
    from .parser import Parser
    from .resolver import Resolver
    from .utils import unparse
    from .visitor import Visitor
    from .walk import walk_body
    from . import _attr
    from . import _m
    from . import _defaults
    from . import code
    from . import table
    from . import doctest
    from . import get_docstring
    from . import getdoc
    from . import is_public_family
    from . import is_magic
    from . import parent
    from . import esc_underscore
   

# Generated at 2022-06-17 16:34:38.624371
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser()
    p.func_api('', '', arguments([arg('a', None), arg('b', None)], None, [], [], None, []), None, has_self=False, cls_method=False)
    assert p.doc[''] == '# a()\n\n*Full name:* `a`\n\n' + table('a', 'b', items=[['Any', 'Any']])
    p.func_api('', '', arguments([arg('a', None), arg('b', None)], None, [], [], None, []), None, has_self=True, cls_method=False)

# Generated at 2022-06-17 16:34:51.379079
# Unit test for function const_type
def test_const_type():
    assert const_type(parse("True").body[0].value) == 'bool'
    assert const_type(parse("1").body[0].value) == 'int'
    assert const_type(parse("1.0").body[0].value) == 'float'
    assert const_type(parse("1j").body[0].value) == 'complex'
    assert const_type(parse("'1'").body[0].value) == 'str'
    assert const_type(parse("(1, 2)").body[0].value) == 'tuple[int, int]'
    assert const_type(parse("[1, 2]").body[0].value) == 'list[int, int]'
    assert const_type(parse("{1, 2}").body[0].value) == 'set[int, int]'
   

# Generated at 2022-06-17 16:35:01.354978
# Unit test for function const_type
def test_const_type():
    assert const_type(parse('True').body[0].value) == 'bool'
    assert const_type(parse('1').body[0].value) == 'int'
    assert const_type(parse('1.0').body[0].value) == 'float'
    assert const_type(parse('1j').body[0].value) == 'complex'
    assert const_type(parse('"1"').body[0].value) == 'str'
    assert const_type(parse('(1, 2)').body[0].value) == 'tuple[int, int]'
    assert const_type(parse('[1, 2]').body[0].value) == 'list[int, int]'
    assert const_type(parse('{1, 2}').body[0].value) == 'set[int, int]'
   

# Generated at 2022-06-17 16:35:11.469572
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    p = Parser()
    p.class_api('a', 'a.A', [], [])
    assert p.doc['a.A'] == '# class A\n\n'

# Generated at 2022-06-17 16:35:22.994478
# Unit test for method api of class Parser
def test_Parser_api():
    from inspect import Signature, Parameter
    from typing import Any, List, Tuple, Union, Optional, Callable
    from typing import cast
    from typing import TYPE_CHECKING
    from typing_extensions import Literal
    from typing_extensions import Final
    from typing_extensions import ClassVar
    from typing_extensions import Protocol
    from typing_extensions import TypedDict
    from typing_extensions import Annotated
    from typing_extensions import NoReturn
    from typing_extensions import ForwardRef
    from typing_extensions import get_type_hints
    from typing_extensions import get_origin
    from typing_extensions import get_args
    from typing_extensions import get_generic_type
    from typing_extensions import get_generic_bases
    from typing_extensions import get_parameters
   

# Generated at 2022-06-17 16:35:33.574669
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser()
    p.func_api('', '', arguments(args=[arg('a', None)], vararg=arg('*b', None)),
               None, has_self=False, cls_method=False)
    assert p.doc[''] == 'a\n\n'
    p.func_api('', '', arguments(args=[arg('a', None)], vararg=arg('*b', None)),
               None, has_self=True, cls_method=False)
    assert p.doc[''] == 'Self\na\n\n'
    p.func_api('', '', arguments(args=[arg('a', None)], vararg=arg('*b', None)),
               None, has_self=True, cls_method=True)

# Generated at 2022-06-17 16:35:41.044610
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert unparse(Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
                                                              Tuple([]),
                                                              Load()))) == 'a'
    assert unparse(Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
                                                              Tuple([Name('b', Load())]),
                                                              Load()))) == 'a[b]'
    assert unparse(Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
                                                              Tuple([Name('b', Load()),
                                                                     Name('c', Load())]),
                                                              Load()))) == 'a[b | c]'

# Generated at 2022-06-17 16:35:53.569963
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from typing import Callable, List, Optional, Tuple
    from typing_extensions import Final
    from mypy_extensions import TypedDict
    from ast import arguments, arg, Name, Constant, expr, parse, Module
    from ast import FunctionDef, ClassDef, Assign, AnnAssign, Delete
    from ast import stmt, parse, Module, Tuple, List, Constant
    from ast import Assign, AnnAssign, Delete, Name, arguments, arg
    from ast import FunctionDef, AsyncFunctionDef, ClassDef
    from ast import expr, stmt, parse, Module, Tuple, List, Constant
    from ast import Assign, AnnAssign, Delete, Name, arguments, arg
    from ast import FunctionDef, AsyncFunctionDef, ClassDef
    from ast import expr, stmt, parse, Module, Tuple, List, Constant
