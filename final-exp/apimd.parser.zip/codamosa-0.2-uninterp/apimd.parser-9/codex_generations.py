

# Generated at 2022-06-17 16:37:16.431581
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
                                                      Tuple([]), Load())) == Name('a', Load())
    assert Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
                                                      Tuple([Name('b', Load())]), Load())) == Name('b', Load())
    assert Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
                                                      Tuple([Name('b', Load()), Name('c', Load())]), Load())) == BinOp(Name('b', Load()), BitOr(), Name('c', Load()))

# Generated at 2022-06-17 16:37:26.627519
# Unit test for function const_type
def test_const_type():
    assert const_type(parse('True').body[0].value) == 'bool'
    assert const_type(parse('1').body[0].value) == 'int'
    assert const_type(parse('1.0').body[0].value) == 'float'
    assert const_type(parse('1+1j').body[0].value) == 'complex'
    assert const_type(parse('"1"').body[0].value) == 'str'
    assert const_type(parse('(1, 2)').body[0].value) == 'tuple[int, int]'
    assert const_type(parse('[1, 2]').body[0].value) == 'list[int, int]'
    assert const_type(parse('{1, 2}').body[0].value) == 'set[int, int]'