

# Generated at 2022-06-17 16:32:10.949510
# Unit test for method globals of class Parser
def test_Parser_globals():
    import ast
    import sys
    import types
    import unittest
    from typing import Any, Dict, List, Optional, Tuple
    from typing import cast
    from typing import TYPE_CHECKING
    from typing_extensions import Literal
    from . import ast_util
    from . import parser
    from . import util
    from . import walker
    from .ast_util import _G, _I, _API
    from .parser import Parser
    from .util import _m
    if TYPE_CHECKING:
        from typing import Type
        from . import ast_util
        from . import parser
        from . import util
        from .ast_util import _G, _I, _API
        from .parser import Parser
        from .util import _m

# Generated at 2022-06-17 16:32:19.402225
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    import ast
    from ast import parse
    from typing import List, Tuple
    from typing import cast
    from typing import TYPE_CHECKING
    if TYPE_CHECKING:
        from typing import Dict, Optional
    from .parser import Parser
    from .parser import _API, _G, _I
    from .parser import arg, arg_type, arg_default
    from .parser import expr, stmt
    from .parser import walk_body
    from .parser import get_docstring
    from .parser import unparse
    from .parser import code
    from .parser import table
    from .parser import doctest
    from .parser import _defaults
    from .parser import Resolver
    from .parser import ANY
    from .parser import const_type
    from .parser import is_public_family
    from .parser import is_magic

# Generated at 2022-06-17 16:32:22.936389
# Unit test for function doctest
def test_doctest():
    assert doctest(">>> 1") == "```python\n>>> 1\n```"
    assert doctest(">>> 1\n>>> 2") == "```python\n>>> 1\n>>> 2\n```"
    assert doctest(">>> 1\n2") == "```python\n>>> 1\n```\n2"
    assert doctest(">>> 1\n2\n>>> 3") == "```python\n>>> 1\n```\n2\n```python\n>>> 3\n```"
    assert doctest(">>> 1\n2\n3") == "```python\n>>> 1\n```\n2\n3"

# Generated at 2022-06-17 16:32:34.112880
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser(None, None)
    assert list(p.func_ann('', [arg('a', None)], has_self=False, cls_method=False)) == ['ANY']
    assert list(p.func_ann('', [arg('a', None)], has_self=True, cls_method=False)) == ['type[Self]', 'ANY']
    assert list(p.func_ann('', [arg('a', None)], has_self=True, cls_method=True)) == ['Self', 'ANY']
    assert list(p.func_ann('', [arg('a', None), arg('b', None)], has_self=False, cls_method=False)) == ['ANY', 'ANY']

# Generated at 2022-06-17 16:32:40.376819
# Unit test for function const_type
def test_const_type():
    assert const_type(parse('1').body[0].value) == 'int'
    assert const_type(parse('1.0').body[0].value) == 'float'
    assert const_type(parse('1j').body[0].value) == 'complex'
    assert const_type(parse('"1"').body[0].value) == 'str'
    assert const_type(parse('True').body[0].value) == 'bool'
    assert const_type(parse('(1, 2)').body[0].value) == 'tuple[int, int]'
    assert const_type(parse('[1, 2]').body[0].value) == 'list[int, int]'
    assert const_type(parse('{1, 2}').body[0].value) == 'set[int, int]'
   

# Generated at 2022-06-17 16:32:50.961536
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert Resolver("", {}).visit_Name(Name("a", Load())) == Name("a", Load())
    assert Resolver("", {"a": "b"}).visit_Name(Name("a", Load())) == Name("b", Load())
    assert Resolver("", {"a": "b"}).visit_Name(Name("c", Load())) == Name("c", Load())
    assert Resolver("", {"a": "b"}).visit_Name(Name("a", Load())) == Name("b", Load())
    assert Resolver("", {"a": "b"}).visit_Name(Name("c", Load())) == Name("c", Load())
    assert Resolver("", {"a": "b"}).visit_Name(Name("a", Load())) == Name("b", Load())

# Generated at 2022-06-17 16:32:55.424074
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    p.func_ann('root', [arg('a', Name(id='int', ctx=Load())),
                        arg('b', Name(id='str', ctx=Load()))],
               has_self=False, cls_method=False)
    assert list(p.func_ann('root', [arg('a', Name(id='int', ctx=Load())),
                                    arg('b', Name(id='str', ctx=Load()))],
                           has_self=False, cls_method=False)) == ['int', 'str']

# Generated at 2022-06-17 16:33:05.610001
# Unit test for method imports of class Parser
def test_Parser_imports():
    p = Parser()
    p.imports('', Import(names=[alias('a', 'b')]))
    assert p.alias == {'a': 'b'}
    p.imports('', ImportFrom('c', [alias('d', 'e')], 1))
    assert p.alias == {'a': 'b', 'c.d': 'c.e'}
    p.imports('', ImportFrom('f', [alias('g', 'h')], 0))
    assert p.alias == {'a': 'b', 'c.d': 'c.e', 'f.g': 'g'}
    p.imports('', ImportFrom('i', [alias('j', 'k')], 2))

# Generated at 2022-06-17 16:33:14.899485
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    """Test method visit_Subscript of class Resolver."""
    resolver = Resolver("", {})
    assert resolver.visit_Subscript(Subscript(Name("Union", Load),
                                              Tuple(elts=[Name("int", Load),
                                                          Name("float", Load)],
                                                    ctx=Load()),
                                              Load())) == \
        BinOp(Name("int", Load), BitOr(), Name("float", Load))
    assert resolver.visit_Subscript(Subscript(Name("Optional", Load),
                                              Name("int", Load),
                                              Load())) == \
        BinOp(Name("int", Load), BitOr(), Constant(None))

# Generated at 2022-06-17 16:33:25.562718
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    assert Resolver('', {}).visit_Constant(Constant(1)) == Constant(1)
    assert Resolver('', {}).visit_Constant(Constant('a')) == Name('a', Load())
    assert Resolver('', {}).visit_Constant(Constant('a.b')) == Name('a.b', Load())
    assert Resolver('', {}).visit_Constant(Constant('a.b.c')) == Name('a.b.c', Load())
    assert Resolver('', {}).visit_Constant(Constant('a.b.c.d')) == Name('a.b.c.d', Load())