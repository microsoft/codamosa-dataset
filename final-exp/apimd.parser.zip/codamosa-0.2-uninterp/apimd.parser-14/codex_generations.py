

# Generated at 2022-06-17 16:32:52.026711
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('a')
    assert is_public_family('a.b')
    assert is_public_family('a.b.c')
    assert not is_public_family('_a')
    assert not is_public_family('a._b')
    assert not is_public_family('a.b._c')
    assert is_public_family('__a__')
    assert is_public_family('a.__b__')
    assert is_public_family('a.b.__c__')
    assert is_public_family('a.b.__c__.d')
    assert is_public_family('a.b.__c__.d.__e__')
    assert not is_public_family('a.b.__c__.d._e')
    assert not is_public_family

# Generated at 2022-06-17 16:33:04.714236
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    p = Parser()
    p.class_api('root', 'name', [], [])
    assert p.doc['name'] == '# class name\n\n'
    p.class_api('root', 'name', [Name(id='A', ctx=Load())], [])
    assert p.doc['name'] == '# class name\n\n' + table('Bases', items=['A'])

# Generated at 2022-06-17 16:33:14.415557
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    from ast import parse
    from typing import List, Optional
    from typing_extensions import Literal
    from pytest import raises
    from . import Parser, _API, _I, _G
    from .ast_ import ClassDef, FunctionDef, arguments, arg, expr, stmt
    from .ast_ import Name, Constant, Tuple, List, Import, ImportFrom
    from .ast_ import Assign, AnnAssign, Delete
    from .ast_ import get_docstring, doctest
    from .ast_ import walk_body, is_public_family, is_magic
    from .ast_ import parent, _m, esc_underscore, code, ANY
    from .ast_ import const_type
    from .ast_ import _attr
    from .ast_ import Resolver
    from .ast_ import unparse

# Generated at 2022-06-17 16:33:25.344806
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from .parser import Parser
    from .parser import Resolver
    from .parser import arg
    from .parser import arguments
    from .parser import expr
    from .parser import parse
    from .parser import unparse
    from .parser import walk_body
    from .parser import Module
    from .parser import FunctionDef
    from .parser import arguments
    from .parser import arg
    from .parser import Name
    from .parser import parse
    from .parser import unparse
    from .parser import walk_body
    from .parser import Module
    from .parser import FunctionDef
    from .parser import arguments
    from .parser import arg
    from .parser import Name
    from .parser import parse
    from .parser import unparse
    from .parser import walk_body
    from .parser import Module
    from .parser import FunctionDef

# Generated at 2022-06-17 16:33:31.211545
# Unit test for function const_type
def test_const_type():
    assert const_type(parse('True').body[0].value) == 'bool'
    assert const_type(parse('1').body[0].value) == 'int'
    assert const_type(parse('1.0').body[0].value) == 'float'
    assert const_type(parse('1j').body[0].value) == 'complex'
    assert const_type(parse('"1"').body[0].value) == 'str'
    assert const_type(parse('(1, 2)').body[0].value) == 'tuple[int, int]'
    assert const_type(parse('[1, 2]').body[0].value) == 'list[int, int]'
    assert const_type(parse('{1, 2}').body[0].value) == 'set[int, int]'
   

# Generated at 2022-06-17 16:33:36.393595
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'Any', Load())) == Name('Any', Load())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'Union', Load())) == Name('Union', Load())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'Optional', Load())) == Name('Optional', Load())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'Tuple', Load())) == Name('Tuple', Load())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) == Name('List', Load())
    assert Resolver('', {}).visit_Attribute

# Generated at 2022-06-17 16:33:50.691963
# Unit test for method globals of class Parser
def test_Parser_globals():
    from typing import List, Tuple, Dict
    from ast import Module, Assign, Name, Constant, Tuple, List
    from ast import parse
    from . import Parser
    from . import _I, _G, _API
    from . import _m, _attr
    from . import is_public_family
    from . import const_type
    from . import get_docstring
    from . import walk_body
    from . import FunctionDef, ClassDef, AsyncFunctionDef
    from . import AnnAssign, arg, arguments, expr, stmt
    from . import Resolver
    from . import unparse
    from . import code
    from . import table
    from . import doctest
    from . import getdoc
    from . import is_magic
    from . import logger
    from . import parent
    from . import ANY


# Generated at 2022-06-17 16:33:55.720976
# Unit test for method globals of class Parser
def test_Parser_globals():
    import ast
    import sys
    import types
    import unittest
    from typing import Any, Dict, List, Optional, Tuple, Union
    from typing_extensions import Literal
    from . import Parser
    from . import _ast as _I
    from . import _ast as _G
    from . import _ast as _API
    from . import _ast as _T
    from . import _ast as _E
    from . import _ast as _S
    from . import _ast as _M
    from . import _ast as _B
    from . import _ast as _C
    from . import _ast as _R
    from . import _ast as _U
    from . import _ast as _F
    from . import _ast as _L
    from . import _ast as _A
    from . import _ast

# Generated at 2022-06-17 16:34:00.352331
# Unit test for method api of class Parser
def test_Parser_api():
    from ast import parse
    from typing import List
    from typing import Optional
    from typing import Union
    from typing import overload
    from typing import cast
    from typing import TYPE_CHECKING
    if TYPE_CHECKING:
        from typing import Type
        from typing import TypeVar
        from typing import Generic
        from typing import Callable
        from typing import Any
        from typing import Tuple
        from typing import Dict
        from typing import Iterator
        from typing import Set
        from typing import Sequence
        from typing import Mapping
        from typing import TypeVar
        from typing import Generic
        from typing import Callable
        from typing import Any
        from typing import Tuple
        from typing import Dict
        from typing import Iterator
        from typing import Set
        from typing import Sequence
        from typing import Mapping
        from typing import TypeVar
       

# Generated at 2022-06-17 16:34:11.511296
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    """Test method visit_Subscript of class Resolver."""
    resolver = Resolver("", {})
    # Union
    assert unparse(resolver.visit_Subscript(Subscript(Name("Union", Load()),
                                                      Tuple(elts=[Name("int", Load()),
                                                                  Name("str", Load())],
                                                            ctx=Load()),
                                                      Load()))) == "Union[int, str]"
    # Optional
    assert unparse(resolver.visit_Subscript(Subscript(Name("Optional", Load()),
                                                      Name("int", Load()),
                                                      Load()))) == "Optional[int]"
    # Tuple

# Generated at 2022-06-17 16:35:49.975318
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    assert Resolver("", {}).visit_Constant(Constant("int")) == Name("int", Load())
    assert Resolver("", {}).visit_Constant(Constant("int[int]")) == Subscript(Name("int", Load()), Tuple(elts=[Name("int", Load())], ctx=Load()), Load())
    assert Resolver("", {}).visit_Constant(Constant("int[int, int]")) == Subscript(Name("int", Load()), Tuple(elts=[Name("int", Load()), Name("int", Load())], ctx=Load()), Load())

# Generated at 2022-06-17 16:36:00.613253
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser()
    p.func_api('', '', arguments(args=[arg('a', None)], vararg=arg('*b', None)),
               None, has_self=False, cls_method=False)
    assert p.doc[''] == '# a()\n\n*Full name:* `a`\n\n' + table(
        'a', '*b', 'return',
        items=[['Any', 'Any', 'Any']])
    p.doc.clear()
    p.func_api('', '', arguments(args=[arg('a', None)], vararg=arg('*b', None)),
               None, has_self=True, cls_method=False)

# Generated at 2022-06-17 16:36:08.901137
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    p.imp['a'] = {'a.b', 'a.c'}
    p.imp['a.b'] = {'a.b.c', 'a.b.d'}
    p.imp['a.b.c'] = {'a.b.c.d', 'a.b.c.e'}
    p.imp['a.b.c.d'] = {'a.b.c.d.e'}
    p.imp['a.b.c.d.e'] = set()
    p.imp['a.b.c.e'] = set()
    p.imp['a.b.d'] = set()
    p.imp['a.c'] = set()
    assert p.is_public('a')

# Generated at 2022-06-17 16:36:16.666213
# Unit test for function walk_body
def test_walk_body():
    def _test(body: Sequence[stmt]) -> Sequence[stmt]:
        return list(walk_body(body))
    assert _test([]) == []
    assert _test([stmt(body=[])]) == [stmt(body=[])]
    assert _test([stmt(body=[stmt(body=[])])]) == [stmt(body=[stmt(body=[])])]
    assert _test([stmt(body=[stmt(body=[stmt(body=[])])])]) == [stmt(body=[stmt(body=[stmt(body=[])])])]
    assert _test([stmt(body=[stmt(body=[stmt(body=[])]), stmt(body=[])])]) == [stmt(body=[stmt(body=[stmt(body=[])]), stmt(body=[])])]


# Generated at 2022-06-17 16:36:23.990100
# Unit test for method globals of class Parser
def test_Parser_globals():
    from ast import parse
    from typing import Dict, List, Tuple
    from .parser import Parser
    from .utils import _m
    from .visitor import _G
    p = Parser()
    p.globals('', parse('a = 1').body[0])
    assert p.alias == {'a': '1'}
    p.globals('', parse('a: int = 1').body[0])
    assert p.alias == {'a': '1'}
    p.globals('', parse('a: int').body[0])
    assert p.alias == {'a': 'int'}
    p.globals('', parse('A = 1').body[0])
    assert p.alias == {'a': 'int', 'A': '1'}
    p.glob

# Generated at 2022-06-17 16:36:34.291184
# Unit test for function doctest
def test_doctest():
    doc = """
    >>> print("Hello")
    Hello
    """
    assert doctest(doc) == """
    ```python
    >>> print("Hello")
    Hello
    ```
    """
    doc = """
    >>> print("Hello")
    Hello
    >>> print("World")
    World
    """
    assert doctest(doc) == """
    ```python
    >>> print("Hello")
    Hello
    >>> print("World")
    World
    ```
    """
    doc = """
    >>> print("Hello")
    Hello
    >>> print("World")
    World
    >>> print("!")
    !"""

# Generated at 2022-06-17 16:36:43.657723
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from importlib import import_module
    from os.path import dirname, join
    from typing import List
    from . import Parser
    from . import _attr
    from . import _m
    from . import _I
    from . import _G
    from . import _API
    from . import _defaults
    from . import _walk_body
    from . import _code
    from . import _doctest
    from . import _is_public_family
    from . import _is_magic
    from . import _esc_underscore
    from . import _get_docstring
    from . import _getdoc
    from . import _unparse
    from . import _parent
    from . import _const_type
    from . import _Resolver
    from . import _logger
    from . import _import_module
   

# Generated at 2022-06-17 16:36:51.852080
# Unit test for function walk_body
def test_walk_body():
    @dataclass
    class Node:
        body: Sequence[stmt]

    @dataclass
    class IfNode(Node):
        orelse: Sequence[stmt]

    @dataclass
    class TryNode(Node):
        handlers: Sequence[Node]
        orelse: Sequence[stmt]
        finalbody: Sequence[stmt]

    @dataclass
    class HandlerNode(Node):
        pass

    @dataclass
    class ClassNode(Node):
        pass

    @dataclass
    class FunctionNode(Node):
        pass

    @dataclass
    class AssignNode(Node):
        pass

    @dataclass
    class AnnAssignNode(Node):
        pass

    @dataclass
    class DeleteNode(Node):
        pass


# Generated at 2022-06-17 16:37:02.609674
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
        Tuple(elts=[Constant(1), Constant(2)], ctx=Load()), Load())) == \
        BinOp(Constant(1), BitOr(), Constant(2))
    assert Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
        Constant(1), Load())) == Constant(1)
    assert Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
        Constant(None), Load())) == BinOp(Constant(None), BitOr(), Constant(None))
    assert Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
        Constant(1), Load())) == Constant(1)


# Generated at 2022-06-17 16:37:13.551672
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    """Test for method visit_Name of class Resolver."""
    r = Resolver('', {})
    assert r.visit(Name('a', Load())) == Name('a', Load())
    assert r.visit(Name('Self', Load())) == Name('Self', Load())
    assert r.visit(Name('a', Load())) == Name('a', Load())
    assert r.visit(Name('b', Load())) == Name('b', Load())
    assert r.visit(Name('c', Load())) == Name('c', Load())
    assert r.visit(Name('d', Load())) == Name('d', Load())
    assert r.visit(Name('e', Load())) == Name('e', Load())