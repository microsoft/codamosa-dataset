

# Generated at 2022-06-17 16:33:52.369095
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    """Test method visit_Subscript of class Resolver."""
    r = Resolver('', {})
    assert r.visit_Subscript(Subscript(Name('a', Load()),
                                       Tuple(elts=[Name('b', Load()),
                                                   Name('c', Load())],
                                             ctx=Load()),
                                       Load())) == BinOp(Name('b', Load()),
                                                         BitOr(),
                                                         Name('c', Load()))
    assert r.visit_Subscript(Subscript(Name('a', Load()),
                                       Name('b', Load()),
                                       Load())) == Name('b', Load())

# Generated at 2022-06-17 16:33:57.353054
# Unit test for method compile of class Parser
def test_Parser_compile():
    from .parser import Parser
    from .parser import _I, _G, _API
    from .parser import Import, ImportFrom, Global, AnnAssign, Assign, Delete
    from .parser import FunctionDef, AsyncFunctionDef, ClassDef
    from .parser import arguments, arg, expr, stmt, Module
    from .parser import Constant, Name, Tuple, List
    from .parser import unparse
    from .parser import get_docstring
    from .parser import walk_body
    from .parser import ANY
    from .parser import _m
    from .parser import parent
    from .parser import esc_underscore
    from .parser import is_public_family
    from .parser import is_magic
    from .parser import code
    from .parser import doctest
    from .parser import table
    from .parser import const_type


# Generated at 2022-06-17 16:34:02.291101
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert Resolver("", {}).visit_Name(Name("a", Load())) == Name("a", Load())
    assert Resolver("", {"a": "b"}).visit_Name(Name("a", Load())) == Name("b", Load())
    assert Resolver("", {"a": "b"}).visit_Name(Name("c", Load())) == Name("c", Load())
    assert Resolver("", {"a": "b"}).visit_Name(Name("a", Load())) == Name("b", Load())
    assert Resolver("", {"a": "b"}).visit_Name(Name("c", Load())) == Name("c", Load())
    assert Resolver("", {"a": "b"}).visit_Name(Name("a", Load())) == Name("b", Load())

# Generated at 2022-06-17 16:34:11.993682
# Unit test for function doctest
def test_doctest():
    assert doctest("") == ""
    assert doctest(">>> 1") == "```python\n>>> 1\n```"
    assert doctest(">>> 1\n>>> 2") == "```python\n>>> 1\n>>> 2\n```"
    assert doctest(">>> 1\n2") == "```python\n>>> 1\n```\n2"
    assert doctest(">>> 1\n2\n>>> 3") == "```python\n>>> 1\n```\n2\n```python\n>>> 3\n```"
    assert doctest(">>> 1\n2\n>>> 3\n4") == "```python\n>>> 1\n>>> 3\n```\n2\n4"

# Generated at 2022-06-17 16:34:21.437395
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    p.imp['a'] = set()
    p.root['a.b'] = 'a'
    p.root['a.c'] = 'a'
    p.root['a.d'] = 'a'
    p.root['a.e'] = 'a'
    p.root['a.f'] = 'a'
    p.root['a.g'] = 'a'
    p.root['a.h'] = 'a'
    p.root['a.i'] = 'a'
    p.root['a.j'] = 'a'
    p.root['a.k'] = 'a'
    p.root['a.l'] = 'a'
    p.root['a.m'] = 'a'
    p.root['a.n'] = 'a'

# Generated at 2022-06-17 16:34:30.775857
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser()
    p.func_api('', '', arguments(args=[arg('a', None)], vararg=arg('*b', None)),
               None, has_self=False, cls_method=False)
    assert p.doc[''] == '# a()\n\n*Full name:* `a`\n\n' + table('a', 'b', 'return',
                                                                items=[('a', '*b', 'Any')])
    p.func_api('', '', arguments(args=[arg('a', None)], vararg=arg('*b', None)),
               None, has_self=True, cls_method=False)

# Generated at 2022-06-17 16:34:37.099326
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    p.alias['a.b'] = 'a.b'
    p.alias['a.c'] = 'a.c'
    p.alias['a.d'] = 'a.d'
    p.alias['a.e'] = 'a.e'
    p.alias['a.f'] = 'a.f'
    p.alias['a.g'] = 'a.g'
    p.alias['a.h'] = 'a.h'
    p.alias['a.i'] = 'a.i'
    p.alias['a.j'] = 'a.j'
    p.alias['a.k'] = 'a.k'
    p.alias['a.l'] = 'a.l'
    p.alias['a.m'] = 'a.m'


# Generated at 2022-06-17 16:34:50.840652
# Unit test for function walk_body
def test_walk_body():
    """Test for function walk_body."""

# Generated at 2022-06-17 16:34:59.718530
# Unit test for function doctest
def test_doctest():
    assert doctest("") == ""
    assert doctest(">>> 1") == "```python\n>>> 1\n```"
    assert doctest(">>> 1\n>>> 2") == "```python\n>>> 1\n>>> 2\n```"
    assert doctest(">>> 1\n2") == "```python\n>>> 1\n```\n2"
    assert doctest(">>> 1\n2\n>>> 3") == "```python\n>>> 1\n```\n2\n```python\n>>> 3\n```"
    assert doctest(">>> 1\n2\n3") == "```python\n>>> 1\n```\n2\n3"

# Generated at 2022-06-17 16:35:09.634714
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    from ast import parse
    from asttokens import ASTTokens
    from types import ModuleType
    from typing import List, Optional
    from typing_extensions import Literal
    from unittest.mock import Mock
    from . import Parser
    from .ast import ClassDef, FunctionDef, stmt
    from .parser import arg, expr, arguments
    from .utils import get_docstring
    #
    def test(code: str, *,
             bases: Optional[List[str]] = None,
             members: Optional[List[str]] = None,
             enums: Optional[List[str]] = None,
             doc: Optional[str] = None) -> None:
        """Test for method class_api of class Parser."""
        ast = parse(code)
        atok = ASTTokens(code, parse=False)
