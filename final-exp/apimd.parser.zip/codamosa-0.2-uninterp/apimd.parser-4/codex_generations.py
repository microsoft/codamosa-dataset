

# Generated at 2022-06-17 16:31:43.026657
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    """Test method func_ann of class Parser."""
    p = Parser()
    p.alias['a'] = 'b'
    p.alias['b'] = 'c'
    p.alias['c'] = 'd'
    p.alias['d'] = 'e'
    p.alias['e'] = 'f'
    p.alias['f'] = 'g'
    p.alias['g'] = 'h'
    p.alias['h'] = 'i'
    p.alias['i'] = 'j'
    p.alias['j'] = 'k'
    p.alias['k'] = 'l'
    p.alias['l'] = 'm'
    p.alias['m'] = 'n'
    p.alias['n'] = 'o'

# Generated at 2022-06-17 16:31:47.256239
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser()
    p.func_api('root', 'root.name', arguments(
        args=[arg('a', None)],
        vararg=arg('*args', None),
        kwonlyargs=[arg('b', None)],
        kwarg=arg('**kwargs', None),
        defaults=[None, None],
        kw_defaults=[None],
    ), None, has_self=False, cls_method=False)

# Generated at 2022-06-17 16:31:51.627216
# Unit test for method compile of class Parser
def test_Parser_compile():
    from .parser import Parser
    from .parser import _I, _G, _API
    from .parser import Import, ImportFrom, Global, AnnAssign, Assign
    from .parser import FunctionDef, AsyncFunctionDef, ClassDef
    from .parser import arguments, arg, expr, stmt, Tuple, List, Constant
    from .parser import Name, Module, Expr, Delete
    from .parser import get_docstring, getdoc, _attr
    from .parser import walk_body
    from .parser import doctest
    from .parser import esc_underscore
    from .parser import is_public_family
    from .parser import is_magic
    from .parser import ANY
    from .parser import parent
    from .parser import const_type
    from .parser import unparse
    from .parser import Resolver

# Generated at 2022-06-17 16:31:57.965323
# Unit test for method compile of class Parser
def test_Parser_compile():
    from typing import List, Tuple
    from . import Parser
    from . import ModuleType
    from . import FunctionDef
    from . import arguments
    from . import arg
    from . import Name
    from . import Constant
    from . import ClassDef
    from . import Assign
    from . import AnnAssign
    from . import expr
    from . import stmt
    from . import parse
    from . import unparse
    from . import get_docstring
    from . import walk_body
    from . import is_public_family
    from . import is_magic
    from . import esc_underscore
    from . import code
    from . import doctest
    from . import table
    from . import ANY
    from . import const_type
    from . import _attr
    from . import getdoc
    from . import parent


# Generated at 2022-06-17 16:32:06.962989
# Unit test for method parse of class Parser
def test_Parser_parse():
    import os
    import sys
    import tempfile
    import unittest
    from importlib import import_module
    from pathlib import Path
    from types import ModuleType
    from typing import Any, Dict, List, Optional, Tuple, Union
    from typing_extensions import Literal
    from unittest.mock import patch
    from . import Parser
    from . import _ast as ast
    from . import _ast_util as ast_util
    from . import _ast_visitor as ast_visitor
    from . import _ast_visitor_generic as ast_visitor_generic
    from . import _ast_visitor_recursive as ast_visitor_recursive
    from . import _ast_visitor_resolver as ast_visitor_resolver
    from . import _ast_visitor_resolver_

# Generated at 2022-06-17 16:32:16.339667
# Unit test for method api of class Parser
def test_Parser_api():
    from . import ast_
    from . import parser
    from . import unparse
    from . import walk_body
    from . import walk_expr
    from . import walk_stmt
    from . import walk_tree
    from . import walk_visit
    from . import walk_visit_expr
    from . import walk_visit_stmt
    from . import walk_visit_tree
    from . import walk_visit_visit
    from . import walk_visit_visit_expr
    from . import walk_visit_visit_stmt
    from . import walk_visit_visit_tree
    from . import walk_visit_visit_visit
    from . import walk_visit_visit_visit_expr
    from . import walk_visit_visit_visit_st

# Generated at 2022-06-17 16:32:23.138144
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    assert list(p.func_ann('', [arg('', None)], has_self=True, cls_method=False)) == ['type[Self]']
    assert list(p.func_ann('', [arg('', None)], has_self=False, cls_method=False)) == ['ANY']
    assert list(p.func_ann('', [arg('', None)], has_self=True, cls_method=True)) == ['type[Self]']
    assert list(p.func_ann('', [arg('', None)], has_self=False, cls_method=True)) == ['ANY']

# Generated at 2022-06-17 16:32:34.450469
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) == Name('List', Load())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', Store())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', Del())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', Param())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', AugLoad())

# Generated at 2022-06-17 16:32:40.683734
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    from .parser import Parser
    from .parser import _API
    from .parser import _I
    from .parser import _G
    from .parser import _B
    from .parser import _S
    from .parser import _C
    from .parser import _D
    from .parser import _R
    from .parser import _A
    from .parser import _E
    from .parser import _T
    from .parser import _F
    from .parser import _O
    from .parser import _L
    from .parser import _Y
    from .parser import _M
    from .parser import _N
    from .parser import _P
    from .parser import _Q
    from .parser import _U
    from .parser import _V
    from .parser import _W
    from .parser import _X
    from .parser import _Z

# Generated at 2022-06-17 16:32:51.039796
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) == Name('List', Load())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', Store())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', Del())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', Param())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', AugLoad())

# Generated at 2022-06-17 16:34:26.758335
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    from typing import List
    from ast import arguments, arg, Name, Constant, Str, Num, Tuple, List, Call
    from ast import parse, unparse
    from ast_tools.unparse import unparse
    from ast_tools.walk import walk_body
    from ast_tools.visitor import GenericVisitor
    from ast_tools.visitor import visit, generic_visit
    from ast_tools.visitor import visit_arguments, visit_arg
    from ast_tools.visitor import visit_expr, visit_expr_context
    from ast_tools.visitor import visit_slice, visit_boolop, visit_operator
    from ast_tools.visitor import visit_unaryop, visit_lambda, visit_ifexp
    from ast_tools.visitor import visit_dict, visit_set, visit_list_comp

# Generated at 2022-06-17 16:34:36.763400
# Unit test for function const_type
def test_const_type():
    assert const_type(parse("1").body[0].value) == 'int'
    assert const_type(parse("1.0").body[0].value) == 'float'
    assert const_type(parse("1j").body[0].value) == 'complex'
    assert const_type(parse("'1'").body[0].value) == 'str'
    assert const_type(parse("True").body[0].value) == 'bool'
    assert const_type(parse("(1, 2)").body[0].value) == 'tuple[int, int]'
    assert const_type(parse("[1, 2]").body[0].value) == 'list[int, int]'
    assert const_type(parse("{1, 2}").body[0].value) == 'set[int, int]'
   

# Generated at 2022-06-17 16:34:50.733858
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    from ast import parse
    from .pep585 import PEP585
    from .pep604 import PEP604
    from .pep484 import PEP484
    from .pep561 import PEP561
    from .pep563 import PEP563
    from .pep570 import PEP570
    from .pep585 import PEP585
    from .pep590 import PEP590
    from .pep592 import PEP592
    from .pep593 import PEP593
    from .pep594 import PEP594
    from .pep595 import PEP595
    from .pep596 import PEP596
    from .pep598 import PEP598
    from .pep599 import PEP599
    from .pep600 import PEP600
    from .pep601 import PEP601

# Generated at 2022-06-17 16:34:59.718606
# Unit test for method api of class Parser
def test_Parser_api():
    from ast import parse
    from typing import List, Tuple
    from typing_extensions import Literal
    from pytest import raises
    from . import Parser
    from . import _I, _G, _API
    from . import Import, ImportFrom, Assign, AnnAssign, Delete
    from . import FunctionDef, AsyncFunctionDef, ClassDef
    from . import arguments, arg, expr, stmt, Name, Constant, Tuple, List
    from . import get_docstring, doctest, getdoc
    from . import is_public_family, is_magic
    from . import parent, _m, esc_underscore
    from . import ANY, const_type
    from . import walk_body
    from . import Resolver
    from . import unparse
    from . import code
    from . import table
    from . import _

# Generated at 2022-06-17 16:35:09.568501
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert unparse(Resolver('', {}).visit_Subscript(
        Subscript(Name('Union', Load()), Tuple(
            [Name('int', Load()), Name('str', Load())], Load()), Load()
        )
    )) == 'Union[int, str]'
    assert unparse(Resolver('', {}).visit_Subscript(
        Subscript(Name('Optional', Load()), Name('int', Load()), Load())
    )) == 'Optional[int]'
    assert unparse(Resolver('', {}).visit_Subscript(
        Subscript(Name('List', Load()), Tuple(
            [Name('int', Load())], Load()), Load()
        )
    )) == 'List[int]'

# Generated at 2022-06-17 16:35:20.452530
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('a')
    assert is_public_family('a.b')
    assert is_public_family('a.b.c')
    assert not is_public_family('_a')
    assert not is_public_family('_a.b')
    assert not is_public_family('a._b')
    assert not is_public_family('a.b._c')
    assert is_public_family('a.__b')
    assert is_public_family('a.b.__c')
    assert is_public_family('__a')
    assert is_public_family('__a.b')
    assert is_public_family('a.__b')
    assert is_public_family('a.b.__c')
    assert is_public_family('__a__')

# Generated at 2022-06-17 16:35:28.187561
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
                                                      Constant(1), Load())) == Subscript(Name('a', Load()),
                                                                                         Constant(1), Load())
    assert Resolver('', {'a': 'Union[int, str]'}).visit_Subscript(Subscript(Name('a', Load()),
                                                                           Constant(1), Load())) == BinOp(Constant(1), BitOr(), Constant('1'))
    assert Resolver('', {'a': 'Optional[int]'}).visit_Subscript(Subscript(Name('a', Load()),
                                                                          Constant(1), Load())) == BinOp(Constant(1), BitOr(), Constant(None))

# Generated at 2022-06-17 16:35:38.500293
# Unit test for method compile of class Parser
def test_Parser_compile():
    """Test for method compile of class Parser."""
    from . import parser
    from . import utils
    from . import __main__
    from . import __init__
    from . import __version__
    from . import __about__
    from . import __license__
    from . import __copyright__
    from . import __author__
    from . import __email__
    from . import __url__
    from . import __doc__
    from . import __all__
    from . import __title__
    from . import __summary__
    from . import __uri__
    from . import __keywords__
    from . import __requires__
    from . import __provides__
    from . import __obsoletes__
    from . import __project_urls__
    from . import __classifiers__

# Generated at 2022-06-17 16:35:52.175475
# Unit test for method compile of class Parser
def test_Parser_compile():
    from . import parse
    from . import parse_module
    from . import parse_string
    from . import parse_file
    from . import parse_path
    from . import parse_url
    from . import parse_stdin
    from . import parse_stdout
    from . import parse_stderr
    from . import parse_stdlib
    from . import parse_builtins
    from . import parse_sys
    from . import parse_os
    from . import parse_io
    from . import parse_time
    from . import parse_datetime
    from . import parse_random
    from . import parse_math
    from . import parse_cmath
    from . import parse_decimal
    from . import parse_fractions
    from . import parse_numbers
    from . import parse_itertools

# Generated at 2022-06-17 16:36:02.812309
# Unit test for function const_type
def test_const_type():
    assert const_type(parse("True").body[0].value) == 'bool'
    assert const_type(parse("1").body[0].value) == 'int'
    assert const_type(parse("1.0").body[0].value) == 'float'
    assert const_type(parse("1j").body[0].value) == 'complex'
    assert const_type(parse("'a'").body[0].value) == 'str'
    assert const_type(parse("(1, 2)").body[0].value) == 'tuple[int, int]'
    assert const_type(parse("[1, 2]").body[0].value) == 'list[int, int]'
    assert const_type(parse("{1, 2}").body[0].value) == 'set[int, int]'
   

# Generated at 2022-06-17 16:37:13.142018
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore('_') == '_'
    assert esc_underscore('__') == '__'
    assert esc_underscore('_a') == '_a'
    assert esc_underscore('a_') == 'a_'
    assert esc_underscore('a_b') == 'a_b'
    assert esc_underscore('a__b') == 'a\\_\\_b'
    assert esc_underscore('a_b_c') == 'a\\_b\\_c'
    assert esc_underscore('a_b_c_') == 'a\\_b\\_c\\_'
    assert esc_underscore('_a_b_c_') == '\\_a\\_b\\_c\\_'

# Generated at 2022-06-17 16:37:22.463398
# Unit test for function walk_body
def test_walk_body():
    """Test for function walk_body."""
    assert list(walk_body([
        If(Constant(True), [
            If(Constant(False), [
                Expr(Constant(1))
            ], [
                Expr(Constant(2))
            ])
        ], [
            Expr(Constant(3))
        ])
    ])) == [
        Expr(Constant(1)),
        Expr(Constant(2)),
        Expr(Constant(3)),
    ]



# Generated at 2022-06-17 16:37:29.952543
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    """Test method visit_Subscript of class Resolver."""
    r = Resolver('', {})
    assert r.visit_Subscript(Subscript(Name('Union', Load),
                                       Tuple(elts=[Name('int', Load),
                                                   Name('str', Load)],
                                             ctx=Load()),
                                       Load())) == BinOp(Name('int', Load),
                                                         BitOr(),
                                                         Name('str', Load))
    assert r.visit_Subscript(Subscript(Name('Optional', Load),
                                       Name('int', Load),
                                       Load())) == BinOp(Name('int', Load),
                                                         BitOr(),
                                                         Constant(None))