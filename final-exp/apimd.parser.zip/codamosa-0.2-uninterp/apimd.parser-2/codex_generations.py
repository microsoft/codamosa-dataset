

# Generated at 2022-06-17 16:33:03.674941
# Unit test for function doctest
def test_doctest():
    assert doctest("") == ""
    assert doctest(">>> 1") == "```python\n>>> 1\n```"
    assert doctest(">>> 1\n>>> 2") == "```python\n>>> 1\n>>> 2\n```"
    assert doctest(">>> 1\n2") == "```python\n>>> 1\n```\n2"
    assert doctest(">>> 1\n2\n>>> 3") == "```python\n>>> 1\n```\n2\n```python\n>>> 3\n```"
    assert doctest(">>> 1\n2\n3\n>>> 4") == "```python\n>>> 1\n>>> 2\n>>> 3\n>>> 4\n```"

# Generated at 2022-06-17 16:33:14.091904
# Unit test for function doctest
def test_doctest():
    assert doctest("") == ""
    assert doctest(">>> 1") == "```python\n>>> 1\n```"
    assert doctest(">>> 1\n>>> 2") == "```python\n>>> 1\n>>> 2\n```"
    assert doctest(">>> 1\n>>> 2\n>>> 3\n4") == "```python\n>>> 1\n>>> 2\n>>> 3\n```\n4"
    assert doctest(">>> 1\n>>> 2\n>>> 3\n4\n>>> 5") == "```python\n>>> 1\n>>> 2\n>>> 3\n```\n4\n```python\n>>> 5\n```"

# Generated at 2022-06-17 16:33:25.087611
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) == Name('List', Load())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) == Name('List', Load())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) == Name('List', Load())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) == Name('List', Load())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) == Name('List', Load())

# Generated at 2022-06-17 16:33:26.280409
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-17 16:33:32.032748
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    from ast import parse
    from typing import List
    from typing import Union
    from typing import Optional
    from typing import Tuple
    from typing import Any
    from typing import TypeVar
    from typing import Type
    from typing import Callable
    from typing import overload
    from typing import cast
    from typing import Generic
    from typing import get_type_hints
    from typing import Dict
    from typing import Set
    from typing import Iterable
    from typing import Iterator
    from typing import Sequence
    from typing import Mapping
    from typing import Container
    from typing import SupportsInt
    from typing import SupportsFloat
    from typing import SupportsComplex
    from typing import SupportsAbs
    from typing import SupportsRound
    from typing import Reversible
    from typing import Sized
    from typing import Collection
    from typing import Hashable

# Generated at 2022-06-17 16:33:37.044921
# Unit test for function const_type
def test_const_type():
    assert const_type(parse("True").body[0].value) == 'bool'
    assert const_type(parse("False").body[0].value) == 'bool'
    assert const_type(parse("1").body[0].value) == 'int'
    assert const_type(parse("1.0").body[0].value) == 'float'
    assert const_type(parse("1j").body[0].value) == 'complex'
    assert const_type(parse("'a'").body[0].value) == 'str'
    assert const_type(parse("(1, 2)").body[0].value) == 'tuple[int, int]'
    assert const_type(parse("[1, 2]").body[0].value) == 'list[int, int]'

# Generated at 2022-06-17 16:33:50.719011
# Unit test for function walk_body

# Generated at 2022-06-17 16:33:58.770323
# Unit test for function doctest
def test_doctest():
    assert doctest("") == ""
    assert doctest(">>> 1") == "```python\n>>> 1\n```"
    assert doctest(">>> 1\n>>> 2") == "```python\n>>> 1\n>>> 2\n```"
    assert doctest(">>> 1\n2") == "```python\n>>> 1\n```\n2"
    assert doctest(">>> 1\n2\n>>> 3") == "```python\n>>> 1\n```\n2\n```python\n>>> 3\n```"
    assert doctest(">>> 1\n2\n3\n>>> 4") == "```python\n>>> 1\n>>> 2\n>>> 3\n>>> 4\n```"

# Generated at 2022-06-17 16:34:03.258434
# Unit test for function walk_body
def test_walk_body():
    """Test for function walk_body."""
    from ast import parse
    from .logger import logger
    logger.setLevel('DEBUG')

# Generated at 2022-06-17 16:34:13.366604
# Unit test for method api of class Parser
def test_Parser_api():
    import ast
    from typing import List
    from typing import Tuple
    from typing import Union
    from typing import Optional
    from typing import overload
    from typing import Any
    from typing import Callable
    from typing import TypeVar
    from typing import Generic
    from typing import cast
    from typing import Type
    from typing import Dict
    from typing import Set
    from typing import Iterator
    from typing import Sequence
    from typing import Mapping
    from typing import get_type_hints
    from typing import get_origin
    from typing import get_args
    from typing import get_generic_type
    from typing import get_generic_bases
    from typing import get_args
    from typing import get_origin
    from typing import get_type_hints
    from typing import get_origin
    from typing import get_args

# Generated at 2022-06-17 16:36:43.720183
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert Resolver('', {}).visit_Name(Name('a', Load())) == Name('a', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a', Load())) == Name('b', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('c', Load())) == Name('c', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('b', Load())) == Name('b', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a.b', Load())) == Name('a.b', Load())

# Generated at 2022-06-17 16:36:50.255721
# Unit test for method imports of class Parser
def test_Parser_imports():
    from . import ast_
    from . import parser
    from . import unparse
    from . import _m
    from . import _I
    from . import Import
    from . import alias
    from . import root
    from . import imp
    from . import level
    from . import doc
    from . import docstring
    from . import const
    from . import link
    from . import b_level
    from . import toc
    from . import logger
    from . import _G
    from . import AnnAssign
    from . import Assign
    from . import Name
    from . import unparse
    from . import ANY
    from . import const_type
    from . import Tuple
    from . import List
    from . import Constant
    from . import _API
    from . import FunctionDef
    from . import AsyncFunction

# Generated at 2022-06-17 16:37:01.915317
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from importlib import import_module
    from pathlib import Path
    from typing import Any, Dict, List, Optional, Tuple, Union
    from typing_extensions import Literal
    from . import __version__
    from .parser import Parser
    from .utils import get_docstring
    from .utils import get_docstring as getdoc
    from .utils import get_docstring as get_doc
    from .utils import get_docstring as get_doc_string
    from .utils import get_docstring as get_doc_string_
    from .utils import get_docstring as get_doc_string__
    from .utils import get_docstring as get_doc_string___
    from .utils import get_docstring as get_doc_string____
    from .utils import get_docstring as get_doc_string_____
   

# Generated at 2022-06-17 16:37:12.775689
# Unit test for function const_type
def test_const_type():
    assert const_type(parse('1').body[0].value) == 'int'
    assert const_type(parse('1.0').body[0].value) == 'float'
    assert const_type(parse('1j').body[0].value) == 'complex'
    assert const_type(parse('"a"').body[0].value) == 'str'
    assert const_type(parse('True').body[0].value) == 'bool'
    assert const_type(parse('[1, 2, 3]').body[0].value) == 'list[int]'
    assert const_type(parse('(1, 2, 3)').body[0].value) == 'tuple[int]'
    assert const_type(parse('{1, 2, 3}').body[0].value) == 'set[int]'
   

# Generated at 2022-06-17 16:37:25.458529
# Unit test for method api of class Parser
def test_Parser_api():
    from ast import parse
    from typing import List
    from . import Parser
    from . import _I, _G, _API
    from . import Module, FunctionDef, ClassDef, arguments, arg, expr, stmt
    from . import Name, Constant, Tuple, List, Import, ImportFrom, Assign
    from . import AnnAssign, Delete, arg
    from . import parse_docstring
    from . import get_docstring
    from . import walk_body
    from . import ANY
    from . import code
    from . import table
    from . import doctest
    from . import esc_underscore
    from . import is_public_family
    from . import is_magic
    from . import parent
    from . import _m
    from . import _attr
    from . import Resolver
    from . import unparse
   