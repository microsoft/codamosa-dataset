

# Generated at 2022-06-17 16:31:29.336613
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from typing import List, Optional
    from ast import parse, arguments, arg, Name, Constant, expr, Tuple, List as List_
    from ast import Assign, Subscript, Index, Load, Store, Name as Name_
    from ast import Attribute, Call, keyword, FunctionDef, ClassDef, Module
    from ast import parse as parse_
    from ast import Module as Module_
    from ast import FunctionDef as FunctionDef_
    from ast import ClassDef as ClassDef_
    from ast import arguments as arguments_
    from ast import arg as arg_
    from ast import Name as Name__
    from ast import Constant as Constant_
    from ast import expr as expr_
    from ast import Tuple as Tuple_
    from ast import List as List__
    from ast import Assign as Assign_
    from ast import Subscript as Subscript_


# Generated at 2022-06-17 16:31:37.901948
# Unit test for method api of class Parser
def test_Parser_api():
    from ast import parse, FunctionDef, ClassDef, arguments, arg, Name, Constant, \
        Str, Num, Tuple, List, Assign, AnnAssign, expr, stmt, Module, \
        AsyncFunctionDef, Delete
    from typing import List as _List, Optional as _Optional
    from typing import Union as _Union
    from typing import Tuple as _Tuple
    from typing import Dict as _Dict
    from typing import Any as _Any
    from typing import Type as _Type
    from typing import overload as _overload
    from typing import cast as _cast
    from typing import TypeVar as _TypeVar
    from typing import Generic as _Generic
    from typing import Callable as _Callable
    from typing import Iterator as _Iterator
    from typing import List as _List
    from typing import Optional as _Optional

# Generated at 2022-06-17 16:31:43.456296
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    parser = Parser(None)
    parser.imp['a'] = {'a', 'a.b'}
    parser.imp['a.b'] = {'a.b.c', 'a.b.d'}
    parser.imp['a.b.c'] = {'a.b.c.d'}
    parser.imp['a.b.c.d'] = set()
    parser.root['a'] = 'a'
    parser.root['a.b'] = 'a.b'
    parser.root['a.b.c'] = 'a.b.c'
    parser.root['a.b.c.d'] = 'a.b.c.d'
    assert parser.is_public('a')
    assert parser.is_public('a.b')
    assert parser.is_public

# Generated at 2022-06-17 16:31:52.589497
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert Resolver("", {}).visit_Name(Name("int", Load())).id == "int"
    assert Resolver("", {}).visit_Name(Name("str", Load())).id == "str"
    assert Resolver("", {}).visit_Name(Name("bool", Load())).id == "bool"
    assert Resolver("", {}).visit_Name(Name("float", Load())).id == "float"
    assert Resolver("", {}).visit_Name(Name("complex", Load())).id == "complex"
    assert Resolver("", {}).visit_Name(Name("Self", Load())).id == "Self"
    assert Resolver("", {}).visit_Name(Name("List", Load())).id == "List"

# Generated at 2022-06-17 16:31:59.454872
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    p.alias['a.b'] = 'c'
    p.alias['a.d'] = 'e'
    p.alias['a.f'] = 'g'
    p.alias['a.h'] = 'i'
    p.alias['a.j'] = 'k'
    p.alias['a.l'] = 'm'
    p.alias['a.n'] = 'o'
    p.alias['a.p'] = 'q'
    p.alias['a.r'] = 's'
    p.alias['a.t'] = 'u'
    p.alias['a.v'] = 'w'
    p.alias['a.x'] = 'y'
    p.alias['a.z'] = 'aa'

# Generated at 2022-06-17 16:32:09.524205
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from . import Parser
    from . import Resolver
    from . import arg
    from . import expr
    from . import Name
    from . import Constant
    from . import Num
    from . import Str
    from . import Tuple
    from . import List
    from . import Dict
    from . import Set
    from . import Call
    from . import Attribute
    from . import Subscript
    from . import Index
    from . import Slice
    from . import ExtSlice
    from . import Starred
    from . import NameConstant
    from . import Ellipsis
    from . import Yield
    from . import YieldFrom
    from . import Await
    from . import Compare
    from . import BoolOp
    from . import BinOp
    from . import UnaryOp
    from . import Lambda
   

# Generated at 2022-06-17 16:32:18.467921
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert Resolver("", {}).visit_Subscript(Subscript(Name("a", Load()),
                                                      Tuple([]), Load())) == Name("a", Load())
    assert Resolver("", {}).visit_Subscript(Subscript(Name("a", Load()),
                                                      Tuple([Name("b", Load())]), Load())) == Name("b", Load())
    assert Resolver("", {}).visit_Subscript(Subscript(Name("a", Load()),
                                                      Tuple([Name("b", Load()), Name("c", Load())]), Load())) == BinOp(Name("b", Load()), BitOr(), Name("c", Load()))

# Generated at 2022-06-17 16:32:24.904021
# Unit test for function const_type
def test_const_type():
    assert const_type(parse('True').body[0].value) == 'bool'
    assert const_type(parse('1').body[0].value) == 'int'
    assert const_type(parse('1.0').body[0].value) == 'float'
    assert const_type(parse('1j').body[0].value) == 'complex'
    assert const_type(parse('"1"').body[0].value) == 'str'
    assert const_type(parse('(1, 2)').body[0].value) == 'tuple[int, int]'
    assert const_type(parse('[1, 2]').body[0].value) == 'list[int, int]'
    assert const_type(parse('{1, 2}').body[0].value) == 'set[int, int]'
   

# Generated at 2022-06-17 16:32:36.652540
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    from ast import parse
    from typing import List, Tuple
    from typing import cast
    from typing_extensions import Literal
    from typing_inspect import is_generic_type
    from typing_inspect import get_args
    from typing_inspect import get_origin
    from typing_inspect import get_last_args
    from typing_inspect import get_last_origin
    from typing_inspect import get_last_origin_name
    from typing_inspect import get_last_args_name
    from typing_inspect import get_last_parameters
    from typing_inspect import get_last_parameters_name
    from typing_inspect import get_last_parameters_default
    from typing_inspect import get_last_parameters_annotation
    from typing_inspect import get_last_parameters_

# Generated at 2022-06-17 16:32:49.990040
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    """Test method visit_Subscript of class Resolver."""
    resolver = Resolver('', {})
    assert resolver.visit_Subscript(Subscript(Name('Union', Load()),
                                              Tuple(elts=[Constant(1),
                                                          Constant(2)],
                                                    ctx=Load()),
                                              Load())) == BinOp(Constant(1),
                                                                BitOr(),
                                                                Constant(2))
    assert resolver.visit_Subscript(Subscript(Name('Optional', Load()),
                                              Constant(1),
                                              Load())) == BinOp(Constant(1),
                                                                BitOr(),
                                                                Constant(None))

# Generated at 2022-06-17 16:33:58.659006
# Unit test for function const_type
def test_const_type():
    assert const_type(Constant(1)) == 'int'
    assert const_type(Constant(1.0)) == 'float'
    assert const_type(Constant(1 + 1j)) == 'complex'
    assert const_type(Constant(True)) == 'bool'
    assert const_type(Constant('1')) == 'str'
    assert const_type(Constant(None)) == 'NoneType'
    assert const_type(Constant(b'1')) == 'bytes'
    assert const_type(Constant(bytearray(b'1'))) == 'bytearray'
    assert const_type(Constant(memoryview(b'1'))) == 'memoryview'
    assert const_type(Constant(range(1))) == 'range'

# Generated at 2022-06-17 16:34:03.490311
# Unit test for method imports of class Parser
def test_Parser_imports():
    p = Parser(None, None, None)
    p.imports('', Import(names=[alias(name='a', asname='b')]))
    assert p.alias == {'b': 'a'}
    p.imports('', ImportFrom(module='a', names=[alias(name='b', asname='c')],
                             level=1))
    assert p.alias == {'b': 'a.b', 'c': 'a.b'}
    p.imports('', ImportFrom(module='a', names=[alias(name='b', asname='c')],
                             level=2))
    assert p.alias == {'b': 'a.b', 'c': 'a.b'}

# Generated at 2022-06-17 16:34:12.875510
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert unparse(Resolver("", {}).visit_Attribute(Attribute(Name("typing", Load()), "List", Load()))) == "List"
    assert unparse(Resolver("", {}).visit_Attribute(Attribute(Name("typing", Load()), "List", Load()))) == "List"
    assert unparse(Resolver("", {}).visit_Attribute(Attribute(Name("typing", Load()), "List", Load()))) == "List"
    assert unparse(Resolver("", {}).visit_Attribute(Attribute(Name("typing", Load()), "List", Load()))) == "List"
    assert unparse(Resolver("", {}).visit_Attribute(Attribute(Name("typing", Load()), "List", Load()))) == "List"

# Generated at 2022-06-17 16:34:23.166357
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
                                                      Tuple([]), Load())) == Name('a', Load())
    assert Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
                                                      Tuple([Constant(1)]), Load())) == Constant(1)
    assert Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
                                                      Tuple([Constant(1), Constant(2)]), Load())) == BinOp(Constant(1), BitOr(), Constant(2))
    assert Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
                                                      Tuple([Constant(1), Constant(2), Constant(3)]), Load()))

# Generated at 2022-06-17 16:34:31.579616
# Unit test for method globals of class Parser
def test_Parser_globals():
    from ast import parse, Assign, Name, Constant, Tuple, List
    from typing import Any
    from . import Parser
    from . import _I, _G, _API
    from . import ModuleType
    from . import _attr
    from . import get_docstring
    from . import walk_body
    from . import FunctionDef, AsyncFunctionDef, ClassDef
    from . import arguments, arg, expr, stmt
    from . import unparse
    from . import Resolver
    from . import doctest
    from . import code
    from . import table
    from . import const_type
    from . import is_public_family
    from . import esc_underscore
    from . import parent
    from . import ANY
    from . import _m
    from . import is_magic
    from . import logger

# Generated at 2022-06-17 16:34:37.660671
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    r = Resolver("", {})
    assert r.visit(Name("a", Load())) == Name("a", Load())
    assert r.visit(Name("a", Load())).__repr__() == "Name(id='a', ctx=Load())"
    assert r.visit(Name("a", Load())).__repr__() == "Name(id='a', ctx=Load())"
    assert r.visit(Name("a", Load())).__repr__() == "Name(id='a', ctx=Load())"
    assert r.visit(Name("a", Load())).__repr__() == "Name(id='a', ctx=Load())"

# Generated at 2022-06-17 16:34:50.907187
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    p.imp['a'] = set()
    assert p.is_public('a')
    p.imp['a'] = {'a'}
    assert p.is_public('a')
    assert not p.is_public('a.b')
    p.imp['a'] = {'a', 'a.b'}
    assert p.is_public('a.b')
    assert not p.is_public('a.c')
    p.imp['a'] = {'a', 'a.b', 'a.b.c'}
    assert p.is_public('a.b.c')
    assert not p.is_public('a.b.d')

# Generated at 2022-06-17 16:34:59.790451
# Unit test for method imports of class Parser
def test_Parser_imports():
    """Test method imports of class Parser."""
    from ast import parse
    from io import StringIO
    from typing import List
    from typing import Optional
    from typing import Tuple
    from typing import Union
    from typing import cast
    from typing import overload
    from typing import TYPE_CHECKING
    from typing import _SpecialForm
    from typing import _TypeAlias
    from typing import _TypingBase
    from typing import _Union
    from typing import _Final
    from typing import _ForwardRef
    from typing import _TypeVar
    from typing import _GenericAlias
    from typing import _ClassVar
    from typing import _NewType
    from typing import _Literal
    from typing import _Callable
    from typing import _Tuple
    from typing import _Type
    from typing import _Any
    from typing import _Union as _T_

# Generated at 2022-06-17 16:35:09.602652
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('a')
    assert is_public_family('_a') is False
    assert is_public_family('__a') is False
    assert is_public_family('a.b')
    assert is_public_family('a._b') is False
    assert is_public_family('a.__b') is False
    assert is_public_family('a.b.c')
    assert is_public_family('a.b._c') is False
    assert is_public_family('a.b.__c') is False
    assert is_public_family('a.b.__c__')
    assert is_public_family('a.b.__c__.d')
    assert is_public_family('a.b.__c__.d.__e__')
    assert is_public_family

# Generated at 2022-06-17 16:35:20.503657
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from ast import parse, arguments, arg, Name, Constant, Str, Num, Tuple, List
    from typing import Union, Optional, Any, Callable, List as _List, Tuple as _Tuple
    from typing import Dict as _Dict, Set as _Set, Iterator as _Iterator
    from typing import cast as _cast
    from typing import overload as _overload
    from typing import TypeVar as _TypeVar
    from typing import Generic as _Generic
    from typing import AnyStr as _AnyStr
    from typing import NewType as _NewType
    from typing import Literal as _Literal
    from typing import ForwardRef as _ForwardRef
    from typing import Type as _Type
    from typing import ClassVar as _ClassVar
    from typing import Final as _Final
    from typing import TYPE_CHECKING as _TYPE_CHECKING
   

# Generated at 2022-06-17 16:36:42.218724
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    p.imp['a'] = {'a', 'a.b', 'a.c', 'a.d'}
    p.root['a'] = 'a'
    p.root['a.b'] = 'a'
    p.root['a.c'] = 'a'
    p.root['a.d'] = 'a'
    assert p.is_public('a')
    assert p.is_public('a.b')
    assert p.is_public('a.c')
    assert p.is_public('a.d')
    assert not p.is_public('a.e')
    p.imp['a'] = set()
    assert p.is_public('a')
    assert p.is_public('a.b')

# Generated at 2022-06-17 16:36:49.569867
# Unit test for method globals of class Parser
def test_Parser_globals():
    from typing import Any, Dict, List, Optional, Tuple, Union
    from types import ModuleType
    from ast import AST, ClassDef, FunctionDef, Module, Name, parse
    from ast import Assign, Constant, Delete, Expr, Import, ImportFrom
    from ast import Tuple, List, Subscript, Index, Attribute, Call
    from ast import keyword, arg, arguments, expr, stmt
    from ast import AnnAssign, AsyncFunctionDef, ClassDef, FunctionDef
    from ast import Module, Name, parse
    from ast import Assign, Constant, Delete, Expr, Import, ImportFrom
    from ast import Tuple, List, Subscript, Index, Attribute, Call
    from ast import keyword, arg, arguments, expr, stmt
    from ast import AnnAssign, AsyncFunctionDef, ClassDef, FunctionDef

# Generated at 2022-06-17 16:37:01.574368
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) == Name('List', Load())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', Store())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', Del())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', Param())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) != Name('List', AugLoad())

# Generated at 2022-06-17 16:37:07.869988
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from ast import parse, Name, Load, Store, Param, arguments, arg
    from typing import List, Tuple
    from .parser import Parser
    from .resolver import Resolver
    from .utils import unparse
    from .visitor import Visitor
    from .visitor import GenericVisitor as _GenericVisitor
    from .visitor import GenericVisitor as _GenericVisitor
    from .visitor import GenericVisitor as _GenericVisitor
    from .visitor import GenericVisitor as _GenericVisitor
    from .visitor import GenericVisitor as _GenericVisitor
    from .visitor import GenericVisitor as _GenericVisitor
    from .visitor import GenericVisitor as _GenericVisitor
    from .visitor import GenericVisitor as _GenericVisitor
    from .visitor import GenericVisitor as _GenericVisitor

# Generated at 2022-06-17 16:37:16.283346
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    assert Resolver("", {}).visit_Constant(Constant("int")) == Name("int", Load())
    assert Resolver("", {}).visit_Constant(Constant("int()")) == Call(Name("int", Load()), [], [], None, None)
    assert Resolver("", {}).visit_Constant(Constant("int(1)")) == Call(Name("int", Load()), [Constant(1)], [], None, None)
    assert Resolver("", {}).visit_Constant(Constant("int(1, 2)")) == Call(Name("int", Load()), [Constant(1), Constant(2)], [], None, None)

# Generated at 2022-06-17 16:37:26.565162
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
                                                      Tuple([]), Load())) == Name('a', Load())
    assert Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
                                                      Tuple([Constant(1)]), Load())) == Constant(1)
    assert Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
                                                      Tuple([Constant(1), Constant(2)]), Load())) == BinOp(Constant(1), BitOr(), Constant(2))
    assert Resolver('', {}).visit_Subscript(Subscript(Name('a', Load()),
                                                      Tuple([Constant(1), Constant(2), Constant(3)]), Load()))