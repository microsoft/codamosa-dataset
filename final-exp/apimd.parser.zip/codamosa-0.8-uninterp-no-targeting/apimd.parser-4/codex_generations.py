

# Generated at 2022-06-21 10:03:18.956370
# Unit test for method is_public of class Parser

# Generated at 2022-06-21 10:03:20.176633
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-21 10:03:25.902977
# Unit test for method globals of class Parser
def test_Parser_globals():
    """Test case for Parser.globals"""
    parser = Parser()
    parser.globals('.', Assign(targets=[Name(id='__all__', ctx=Store())], value=List(elts=[])))
    parser.globals('.', Assign(targets=[Name(id='a', ctx=Store())], value=Constant(value=1)))
    parser.globals('.', AnnAssign(target=Name(id='A', ctx=Store()), annotation=Constant(value='int'), value=None))
    parser.globals('.', Assign(targets=[Name(id='__all__', ctx=Store())], value=Tuple(elts=[Constant(value='a'), Constant(value='b')])))

# Generated at 2022-06-21 10:03:36.660242
# Unit test for constructor of class Parser
def test_Parser():
    from .tokenizer import Tokenizer
    from .parser import Parser
    from .ast import Module
    from .context import Context
    from .token import TokenStream
    from .symbol import SymbolTable
    from .lexer import Lexer
    from .resolver import Resolver
    from .utils import DummyType, Dict, DictType
    import sys
    import io
    import ast
    import types

    ctx = Context()
    lexer = Lexer(ctx)
    stream = TokenStream(DummyType(Tokenizer, 'token'), ctx)
    symbol = SymbolTable(ctx)
    parser = Parser(ctx)
    resolver = Resolver(symbol)

    p = Parser.__new__(Parser)
    p.resolver = resolver
    p.symbol = symbol

# Generated at 2022-06-21 10:03:43.945781
# Unit test for function doctest
def test_doctest():
    """Test doctest."""
    import unittest
    unittest.TestCase().assertEqual(doctest("xxxx"), "xxxx")
    unittest.TestCase().assertEqual(doctest(">>> 1\n>>> 2"), "```python\n>>> 1\n>>> 2\n```")
    unittest.TestCase().assertEqual(doctest(">>> 1\n2"), "```python\n>>> 1\n```\n2")



# Generated at 2022-06-21 10:03:51.109047
# Unit test for function walk_body
def test_walk_body():
    import ast
    from astunparse import unparse
    def walker(node):
        for n in node.body:
            if isinstance(n, ast.If):
                for a in walker(n):
                    yield a
            else:
                yield n
    body = [
        ast.If(ast.Constant(True), body=[ast.If(ast.Constant(True), body=[ast.If(ast.Constant(True), body=[ast.If(ast.Constant(True), body=[ast.Pass()])])])]),
        ast.If(ast.Constant(True), body=[ast.If(ast.Constant(True), body=[ast.If(ast.Constant(True), body=[ast.If(ast.Constant(True), body=[ast.Pass()])])])])
    ]

# Generated at 2022-06-21 10:03:55.701021
# Unit test for function table
def test_table():
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == '''\
| a | b |
|:---:|:---:|
| c | d |
| e | f |

'''



# Generated at 2022-06-21 10:03:59.928032
# Unit test for function table
def test_table():
    out = table('a', 'b', [['c', 'd'], ['e', 'f']])
    assert out == "| a | b |\n|:---:|:---:|\n| c | d |\n| e | f |\n\n"



# Generated at 2022-06-21 10:04:05.248236
# Unit test for function walk_body
def test_walk_body():
    def bar():
        if True:
            def baz():
                def qux():
                    pass
            pass
        else:
            def foo2():
                pass
        pass
    node = parse(getdoc(bar)).body[0]
    foo1_name = 'foo1'
    foo2_name = 'foo2'
    _func_to_test_walk_body(node, foo1_name, foo2_name)



# Generated at 2022-06-21 10:04:17.168265
# Unit test for method globals of class Parser
def test_Parser_globals():
    p = Parser()
    class _Module(NamedTuple):
        module: str
        level: int
        names: List[alias]
    def _Node(name: str, type_comment: str = None, value: Optional[expr] = None):
        return Assign(targets=[Name(id=name, ctx=Store())], type_comment=type_comment, value=value)
    class _Name(NamedTuple):
        id: str
        ctx: Context
    p.globals(root='', node=_Node('__all__', value=List(elts=[Constant(value='a'), Constant(value='b')])))
    p.globals(root='', node=_Node('__package__', value=Constant(value='a.b')))
    p.globals