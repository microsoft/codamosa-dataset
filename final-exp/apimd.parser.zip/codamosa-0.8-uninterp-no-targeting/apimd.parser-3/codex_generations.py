

# Generated at 2022-06-21 10:03:21.228721
# Unit test for method compile of class Parser
def test_Parser_compile():
    from . import Package
    pkg = Package('test', '..')
    mod = pkg.parse('test_pkg')
    doc = Parser(mod).compile()

    assert doc

# Generated at 2022-06-21 10:03:24.200529
# Unit test for function code
def test_code():
    assert code("a|b&c") == "<code>a&#124;b&amp;c</code>"



# Generated at 2022-06-21 10:03:34.936016
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    assert Parser.func_ann(Parser(), '', [
        arg('a', None),
        arg('b', Name(id='int', ctx=Load())),
        arg('', None),
        arg('x', Name(id='int', ctx=Load())),
        arg('y', Name(id='int', ctx=Load())),
        arg('return', Name(id='bool', ctx=Load()))]) == [
            '', code('int'), '', code('int'), code('int'), code('bool')]


# Generated at 2022-06-21 10:03:41.418237
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('module') is True
    assert is_public_family('module.func') is True
    assert is_public_family('module.func.__func__') is True
    assert is_public_family('module.var') is True
    assert is_public_family('module.var.__var__') is True
    assert is_public_family('module.class') is True
    assert is_public_family('module.class.__class__') is True
    assert is_public_family('module.class.__class__.__func__') is True
    assert is_public_family('module.class.__class__.__func__.__func__') is True
    assert is_public_family('module.class.__class__.__func__.__func__.__var__') is True

# Generated at 2022-06-21 10:03:49.932014
# Unit test for method globals of class Parser

# Generated at 2022-06-21 10:03:56.740910
# Unit test for function code
def test_code():
    assert code('') == ' '
    assert code('|') == '<code>&#124;</code>'
    assert code('a|b') == '<code>a&#124;b</code>'
    assert code('abc&def') == '<code>abc&def</code>'
    assert code('abc') == '`abc`'
    return True
assert test_code()



# Generated at 2022-06-21 10:04:05.768136
# Unit test for function is_public_family
def test_is_public_family():
    assert not is_public_family('')
    assert is_public_family('a')
    assert is_public_family('a.b')
    assert not is_public_family('_a')
    assert not is_public_family('a._b')
    assert not is_public_family('_a.b')
    assert not is_public_family('a._b.c')
    assert not is_public_family('_a._b.c')
    assert not is_public_family('_a.b._c')
    assert not is_public_family('_a._b._c')
    assert not is_public_family('a.__b')
    assert not is_public_family('a.b.__c')



# Generated at 2022-06-21 10:04:16.637510
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser(
        toc = True,
        link = True,
        hide = False,
        b_level = 3)
    p.parse(
        '../sopel/tests/__init__.py',
        '../sopel/tests/__init__.py',
        '../sopel/tests/__init__.py')
    assert type(p.doc) is dict
    assert type(p.root) is dict
    assert type(p.alias) is dict
    assert type(p.const) is dict
    assert type(p.level) is dict
    assert type(p.imp) is dict
    assert type(p.docstring) is dict

# Generated at 2022-06-21 10:04:22.996977
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    config = {'root': 'pyslvs', 'alias': {}}
    resolver = Resolver(**config)
    node1 = Constant('str')
    node2 = Constant([2,3,4])
    assert resolver.visit_Constant(node1) == node1
    assert resolver.visit_Constant(node2) == node2


# Generated at 2022-06-21 10:04:27.520874
# Unit test for function table
def test_table():
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == (
        "| a | b |\n"
        "|:---:|:---:|\n"
        "| c | d |\n"
        "| e | f |\n\n"
        )



# Generated at 2022-06-21 10:05:19.519515
# Unit test for function doctest
def test_doctest():
    """
    >>> print(doctest("""

# Generated at 2022-06-21 10:05:25.707975
# Unit test for function is_public_family
def test_is_public_family():
    assert not is_public_family('foo.bar.__init__.__bar')
    assert is_public_family('foo.bar.__init__.bar')
    assert not is_public_family('foo.bar.__init__._bar')
    assert is_public_family('foo.bar.__init__.bar')
    assert not is_public_family('foo.bar.__bar')
    assert is_public_family('foo.bar.bar')
    assert not is_public_family('foo.bar._bar')
    assert is_public_family('foo.bar.bar')



# Generated at 2022-06-21 10:05:31.951748
# Unit test for function esc_underscore
def test_esc_underscore():
    from .docs import RE_UNDERSCORE
    for doc in [
        "",
        "abc",
        "abc_abc",
        "abc_abc_abc",
        "abc_abc_abc_abc",
        "abc_abc_abc_abc_abc",
    ]:
        assert len(RE_UNDERSCORE.findall(esc_underscore(doc))) == 0



# Generated at 2022-06-21 10:05:40.605118
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    """Unit test for method __post_init__ of class Parser."""
    parser = Parser()
    parser.__post_init__(recursive='', toc=True, link=False, level=0)
    assert parser.level == 0
    assert parser.b_level == 0
    assert parser.s_level == 0
    assert parser.doc_level == 0
    assert parser.toc is True
    assert parser.recursive == {}
    assert parser.doc == {}
    assert parser.imp == {}
    assert parser.alias == {}
    assert parser.level == {}
    assert parser.root == {}
    assert parser.const == {}
    assert parser.docstring == {}


# Generated at 2022-06-21 10:05:50.540430
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    parser = Parser()
    parser.func_api(
        "root",
        "name",
        arguments(
            args=[arg('self', Name('str'))],
            kwonlyargs=[arg('p1', Name('str'))]
        ),
        None
    )

# Generated at 2022-06-21 10:05:57.227194
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    """Test function of method visit_Name of class Resolver."""
    from .docstr2json import DocStr2Json
    docstr2json = DocStr2Json(ModuleType('test_Resolver_visit_Name'),
                              [('', '')])
    resolver = Resolver('test_Resolver_visit_Name', docstr2json.alias)
    assert resolver.visit_Name(Name('AliasLiteral', Load())) == Name('int', Load())
    assert resolver.visit_Name(Name('AliasName', Load())) == Name('int', Load())

# Generated at 2022-06-21 10:06:02.429673
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    from .base import Parser
    from .util import m
    from .formatter import Formatter
    from .reader import Reader

    from typing import Optional, List, Callable

    file = Formatter(
        Reader('test/test_parser.py').read(),
        None,
        '',
        '',
        [],
        '',
        '',
        [],
        None,
        '',
        '',
        '')
    p = Parser(file)
    p.resolve(m('root'), '')
    p.is_public(m('root'))
    p.is_public(m('root.bull'))
    p.is_public(m('root.A'))
    p.is_public(m('root.A.test'))

# Generated at 2022-06-21 10:06:09.695475
# Unit test for constructor of class Resolver
def test_Resolver():
    resolver = Resolver('__main__', {
        '__main__.Foo': '__main__.List[__main__.int]',
        '__main__.List': 'typing.List',
        '__main__.int': 'int',
    }, 'Foo')
    resolver.visit(parse("__main__.List[__main__.int]").body[0].value)
    resolver.visit(parse("__main__.Foo").body[0].value)



# Generated at 2022-06-21 10:06:13.621983
# Unit test for function table
def test_table():
    assert(table('a', 'b', [['c', 'd'], ['e', 'f']]) ==
           '| a | b |\n'
           '|:---:|:---:|\n'
           '| c | d |\n'
           '| e | f |\n\n')



# Generated at 2022-06-21 10:06:25.380030
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    resolver = Resolver("__main__", {
        "__main__.T": "typing.TypeVar('T')",
        "__main__.A": "typing.Union[A, int]",
        "__main__.B": "typing.Optional[float]",
        "__main__.C": "typing.List[int]"
        })
    assert str(resolver.visit(parse("T").body[0].value)) == "Name(id='T', ctx=Load())"
    assert str(resolver.visit(parse("A").body[0].value)) == "BinOp(left=Name(id='A', ctx=Load()), op=BitOr(), right=Constant(value=1))"

# Generated at 2022-06-21 10:08:14.977621
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    m = Module()
    m.body.append(ClassDef(
        name='A',
        bases=[Name("object")],
        body=[
            Assign(
                targets=[Name("a")],
                value=Constant(1),
            ),
            Assign(
                targets=[Name("b")],
                value=Constant(2),
            ),
            AnnAssign(
                target=Name("c"),
                annotation=Name("int"),
                value=Constant(3),
            ),
        ]
    ))

# Generated at 2022-06-21 10:08:21.696976
# Unit test for method imports of class Parser
def test_Parser_imports():
    import ast
    import typing
    from pprint import pprint as pp
    from typing import Sequence
    from argparse import Namespace
    from typing import Dict, Any, List
    from datetime import datetime, timedelta
    from typing import Optional, Union
    from typing import TypeVar, Callable, Generic, GenericMeta
    from typing import Literal, Protocol, AnyMeta
    from dataclasses import dataclass, field, asdict
    from typing import Type, Protocol, abstractmethod
    from inspect import signature
    from typing import Protocol as P


# Generated at 2022-06-21 10:08:25.258547
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'List', Load())) == Name('List', Load())
    assert Resolver('', {}).visit_Attribute(Attribute(Name('a', Load()), 'b', Load())) == Attribute(Name('a', Load()), 'b', Load())
