

# Generated at 2022-06-21 10:01:09.309779
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    f = Parser
    a = Parser(None, None, None, None, None)
    del a
    del f
    f = Parser(None, None, None, None, None)
    del f

# Generated at 2022-06-21 10:01:11.817631
# Unit test for method imports of class Parser
def test_Parser_imports():
    Parser('', {}).imports('foo.boo', ast.parse("import a"))


# Generated at 2022-06-21 10:01:22.650323
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    from .parser import Parser
    from .parser import _root__doc__
    from .parser import _root__all__
    import types
    root = Parser(toc=True, link=True)
    assert root.toc == True
    assert root.link == True
    assert root.b_level == 0
    assert root.all == _root__all__
    assert root.doc == _root__doc__
    assert not root.alias
    assert not root.const
    assert not root.imp
    assert not root.docstring
    assert not root.level
    assert not root.root
    # No code coverage
    # Unit test for method __init__ of class Parser
    def test_Parser___init__():
        from .parser import Parser
        from .parser import _root__doc__
        from .parser import _root__

# Generated at 2022-06-21 10:01:31.052788
# Unit test for method compile of class Parser

# Generated at 2022-06-21 10:01:36.036302
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser(link=True)
    p.parse(r"tests\test_pake.py", r"tests\test_unit.py")

# Generated at 2022-06-21 10:01:38.681359
# Unit test for function walk_body
def test_walk_body():
    class Noop(NodeTransformer):
        def visit_Module(self, node: AST):
            return node

# Generated at 2022-06-21 10:01:49.699637
# Unit test for function const_type
def test_const_type():
    gc = globals()
    for t in (int, float, complex, str, list, set, tuple, dict):
        assert const_type(Constant(t() if t is not str else "")) == _type_name(t())
    for k, v in PEP585.items():
        assert const_type(Name(k, Load())) == v
    assert const_type(Constant(None)) == "_ast.Name(id='None')"
    assert const_type(List(elts=[Constant(0), Constant(1)])) == 'list[int]'
    assert const_type(Tuple(elts=[Constant(0.0), Constant(1.0)])) == 'tuple[float]'

# Generated at 2022-06-21 10:01:51.639232
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    correct = "Constant(value='int')"
    assert correct == unparse(Resolver("test", {}).visit(parse("int").body[0]))
    assert correct == unparse(Resolver("test", {}).visit(parse("'int'").body[0]))

# Generated at 2022-06-21 10:02:02.809334
# Unit test for constructor of class Parser
def test_Parser():
    """Parser constructor."""
    Parser(['a.b', 'a.c'])
    Parser(['a.b', 'a.b'])
    with pytest.raises(ValueError):
        Parser(['a.b', 'a.c', 'a.d'])
    Parser(['a.b', 'a.c', 'a.c.d'])
    with pytest.raises(ValueError):
        Parser(['a.b', 'a.c', 'a.c.d', 'a.c.e'])
    Parser(['a.b', 'a.c', 'a.c.d', 'a.c.d.e'])


# Generated at 2022-06-21 10:02:11.336898
# Unit test for function doctest
def test_doctest():
    assert doctest(">>> 123") == '''```python
>>> 123
```'''
    assert doctest(">>> 123\n456\n>>> 123") == '''```python
>>> 123
456
>>> 123
```'''
    assert doctest(">>> 123\n456\n>>> 123\n") == '''```python
>>> 123
456
>>> 123
```'''
    assert doctest("123") == '123'
    assert doctest("123\n>>> 123") == '''123
```python
>>> 123
```'''



# Generated at 2022-06-21 10:04:19.159719
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    import os
    import sys
    string = """class TestClass:
    __all__ = ['c', 'a']
    _a = 0
    b = 1
    c = 2
    def __init__(self):
        c = 0"""
    p = Parser(string)
    p.imp['TestClass'] = set()
    assert p.is_public('TestClass') == True
    assert p.is_public('TestClass._a') == False
    assert p.is_public('TestClass.b') == True
    assert p.is_public('TestClass.c') == True
    assert p.is_public('TestClass.c') == True

# Generated at 2022-06-21 10:04:21.617974
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    parser = Parser(toc=True, link=True)
    assert parser.toc
    assert parser.link

# Generated at 2022-06-21 10:04:25.549829
# Unit test for function parent
def test_parent():
    assert parent('PEP585') == 'PEP585'
    assert parent('PEP585') == 'PEP585'
    assert parent('PEP585.abc') == 'PEP585'
    assert parent('PEP585.abc.efg') == 'PEP585.abc'
    assert parent('PEP585.abc.efg', level=2) == 'PEP585'
    assert parent('PEP585.abc.efg', level=3) == ''
    assert parent('PEP585.abc.efg', level=4) == ''
test_parent()
del test_parent



# Generated at 2022-06-21 10:04:38.989461
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from os.path import dirname
    from time import time
    from .pdoc import Doc, Program
    from .main import parse_args
    import doctest
    import argparse
    import sys
    import tempfile
    import shutil
    import pathlib
    import types
    import io
    import pkgutil
    import unittest
    test_dir = pathlib.Path(dirname(__file__))
    tmp_dir = pathlib.Path(tempfile.mkdtemp())

# Generated at 2022-06-21 10:04:49.968701
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()

# Generated at 2022-06-21 10:04:54.589003
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore('Test_name') == 'Test_name'
    assert esc_underscore('Test_name_') == r'Test\_name_'
    assert esc_underscore('Test__name') == r'Test\_\_name'


# Generated at 2022-06-21 10:04:58.106044
# Unit test for function parent
def test_parent():
    assert parent('abc.def.ghi') == 'abc.def'
    assert parent('abc.def.ghi', level=2) == 'abc'
    assert parent('abc.def.ghi', level=3) == ''



# Generated at 2022-06-21 10:05:00.491673
# Unit test for function is_magic
def test_is_magic():
    assert not is_magic('test')
    assert not is_magic('test.test')
    assert is_magic('__test__')
    assert is_magic('test.__test__')



# Generated at 2022-06-21 10:05:05.324210
# Unit test for function parent
def test_parent():
    assert parent('a.b') == 'a'
    assert parent('a.b.c.d') == 'a.b.c'
    assert parent('a.b.c.d', level=2) == 'a.b'
    assert parent('a') == ''
    assert parent('a', level=2) == ''

# Generated at 2022-06-21 10:05:17.924050
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    """Test for method visit_Subscript of class Resolver

    Test for every item in `PEP585`
    """
    resolver = Resolver('root_module_name', {})
    for k, v in PEP585.items():
        module_name, func_name = k.rsplit('.', maxsplit=1)
        alias: dict[str, str] = {
            module_name: f"{module_name} = typing",
            k: f"{func_name} = typing.{func_name}",
        }
        resolver.alias = alias
        target = f"{k}['str_arg']"
        wanted = f"typing.{func_name}['str_arg']"
        got = code(unparse(resolver.visit(parse(target).body[0])))
