

# Generated at 2022-06-21 10:02:39.841840
# Unit test for method parse of class Parser
def test_Parser_parse():
    import ast
    import types
    import os
    from astor import codegen
    
    try:
        # Unit test line 0
        assert False, "from ast import parse"
    except AssertionError as e:
        print(str(e) + " --- test at line 0")
    
    try:
        # Unit test line 1
        assert False, "from astor.code_gen import to_source"
    except AssertionError as e:
        print(str(e) + " --- test at line 1")
    
    try:
        # Unit test line 2
        assert False, "from typing import Any, Dict, Iterator, List, Mapping, NamedTuple"
    except AssertionError as e:
        print(str(e) + " --- test at line 2")
    

# Generated at 2022-06-21 10:02:43.168612
# Unit test for function is_public_family
def test_is_public_family():
    assert not is_public_family('_test')
    assert not is_public_family('test')
    assert not is_public_family('test.test')
    assert not is_public_family('test.test.test')
    assert is_public_family('test')
    assert is_public_family('test.test')
    assert is_public_family('test.test.bla')
    assert is_public_family('__init__.test')
    assert is_public_family('test.__bla__.test')
    assert is_public_family('test.__bla__.__bla__')
    assert is_public_family('test.bla.__bla__')
    assert not is_public_family('__init__.__init__')

# Generated at 2022-06-21 10:02:53.881322
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('a')
    assert is_public_family('__a')
    assert is_public_family('__a__')
    assert is_public_family('a.b')
    assert is_public_family('__a.b')
    assert is_public_family('__a__.b')
    assert is_public_family('a.__b')
    assert not is_public_family('a._b')
    assert not is_public_family('a.b._c')
    assert is_public_family('a._2')
    assert not is_public_family('a._2.b')
    assert not is_public_family('a._2.b.c')
    assert not is_public_family('a.b._2')

# Generated at 2022-06-21 10:03:04.502374
# Unit test for method api of class Parser
def test_Parser_api():
    from ast import parse, FunctionDef, arguments, arg, Name, Constant, Num
    from types import ModuleType
    from types import MappingProxyType as Map
    from inspect import signature
    parsed = parse(textwrap.dedent('''
    def func(a: int, b, *args, c: int = 0, d, e, f = 1, **kwargs) -> str:
        """func docstring."""
        pass
    '''))
    func = parsed.body[0]
    assert isinstance(func, FunctionDef)
    assert func.name == "func"
    assert isinstance(func.args, arguments)

# Generated at 2022-06-21 10:03:16.686813
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    parser = Parser()
    parser.doc['a'] = ''
    parser.doc['a.a'] = ''
    parser.doc['a.b'] = ''
    parser.doc['a.c.d'] = ''
    parser.load_docstring('a', globals())
    assert parser.docstring['a'] == doctest(getdoc(test_Parser_load_docstring))
    assert parser.docstring['a.a'] == doctest(getdoc(parser.load_docstring))
    assert parser.docstring['a.b'] == doctest(getdoc(parser.doc))
    for ch in parser.docstring['a.c.d']:
        assert ch.isspace()

## Resolve the full name of object
# A helper to recursively resolve the full name of object
# with alias and class first

# Generated at 2022-06-21 10:03:17.929953
# Unit test for method api of class Parser

# Generated at 2022-06-21 10:03:30.472438
# Unit test for function doctest
def test_doctest():
    assert doctest(
        """
        >>> a
        1
        >>> b
        2
        """
    ) == "```python\n>>> a\n1\n>>> b\n2\n```"
    assert doctest(
        """
        >>> a
        1
        """
        """
        >>> b
        2
        """
    ) == "```python\n>>> a\n1\n>>> b\n2\n```"
    assert doctest(
        """
        >>> a
        1
        >>> b
        2
        """
        """
        >>> c
        3
        """
    ) == "```python\n>>> a\n1\n>>> b\n2\n```\n>>> c\n3\n```"

# Generated at 2022-06-21 10:03:41.223587
# Unit test for method api of class Parser
def test_Parser_api():
    # Test with function.
    def test1(args):
        """Just a unit test."""
        if isinstance(args, tuple):
            return args[0]
        return args

    same(Parser(Parser.FUNCTION + Parser.TYPE).api(test1),
         (r'# test1()',
          r'''*Full name:* `test1`

*Decorators:* `()`

*Arguments:*

* `args`: `Any`

*Returns:*

* `Any`

'''))

    def test2(a: str, *, x: int = 1) -> str:
        """Just a unit test."""
        return x


# Generated at 2022-06-21 10:03:44.193122
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    x = Parser()
    name = repr(x)
    assert name == 'Parser()', name
# Unit tests for method __init__ of class Parser

# Generated at 2022-06-21 10:03:51.232133
# Unit test for method imports of class Parser
def test_Parser_imports():
    p = Parser()
    p.imports("", Import([Name("a1", Load())], None))
    p.imports("", Import([Name("a2", Load())], None))
    p.imports("", Import([Name("b1", Load())], None))
    p.imports("", Import([Name("b2", Load())], None))
    p.imports("", ImportFrom("__future__", [
        alias("async_generators", "async_generators")], 0))
    p.imports("", ImportFrom("os", [
        alias("chdir", "chdir"), alias("cpu_count", "cpu_count"),
        alias("environ", "environ")], 0))

# Generated at 2022-06-21 10:06:49.824664
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    parser = Parser(['--docx-path', 'tests/fixtures/docx/First_document.docx'])
    parser.__eq__()

# Generated at 2022-06-21 10:06:55.485256
# Unit test for function walk_body
def test_walk_body():
    def a(x: int) -> int:
        if x > 0:
            b = x - 1
            if b > 0:
                return a(b)
            return x
        return 0
    assert [x.lineno for x in walk_body(a.__code__.co_consts[0])] == [1, 3, 4, 6, 7]



# Generated at 2022-06-21 10:07:04.233641
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    parser = Parser(b_level=1, link=False)
    assert list(parser.func_ann('a', [], has_self=True, cls_method=False)) == [
        'type[Self]']
    assert unparse(parser.resolve(
        'a', parse('(a, b, *args, c, d, **kwargs) -> r'), 'Self')) == (
        '(a, b, *args, c, d, **kwargs) -> r')


# Generated at 2022-06-21 10:07:13.557430
# Unit test for method parse of class Parser
def test_Parser_parse():
    from typing import Callable
    from functools import partial
    from pathlib import Path
    import json
    import os
    
    print = partial(print, flush=True)
    
    def _factory(path: str, name: str, ver: str) -> Callable[[str], None]:
        """Test factory."""
        def _test(data: str) -> None:
            with Path(path).open() as f:
                src = f.read()
            p = Parser(src, link=True, toc=True)
            p.parse(name)
            assert p.compile() == data
        _test.__name__ = f"test_{name}"
        return _test
    
    def _tests_gen(version: str) -> None:
        """Generate tests for the specific version of Python."""

# Generated at 2022-06-21 10:07:21.836115
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    parser = Parser()
    # Initialize.
    root = 'foo'
    name = 'foo.bar'
    returns = None
    has_self = True
    cls_method = True
    node = None
    # Assign values.
    parser.doc[name] = ''
    try:
        parser.func_api(root, name, node, returns, has_self=has_self,
                        cls_method=cls_method)
        # Expect no error.
    except Exception:
        # Expect no error.
        assert False

# Generated at 2022-06-21 10:07:26.533696
# Unit test for function table
def test_table():
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == textwrap.dedent("""\
    | a | b |
    |:---:|:---:|
    | c | d |
    | e | f |

    """)

# Generated at 2022-06-21 10:07:28.742064
# Unit test for function code
def test_code(): assert code("1 + 2") == "`1 + 2`"

# Generated at 2022-06-21 10:07:36.102829
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    from ast import arg, Name, arguments
    from typing import Optional
    from pdocs.doc import code
    from pdocs.docstring import get_docstring
    from pdocs.config import Config
    from pdocs.parser import Parser
    from pdocs.visitor import NodeVisitor
    def f(x: int, ) -> None:
        pass
    args = arguments(
        [arg('x', Name(id='int', ctx=Load()), None)],
        None, None, [], [], None, [])

# Generated at 2022-06-21 10:07:46.500670
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    """Test method visit_Subscript of class Resolver"""
    node = Subscript(
        value=Name(id='typing', ctx=Load()),
        slice=Tuple(elts=[Name(id='int', ctx=Load()), Name(id='str', ctx=Load())], ctx=Load()),
        ctx=Load()
    )
    assert str(Resolver("test", {}).visit_Subscript(node)) == 'Union[int, str]'
    assert str(Resolver("test", {}).visit_Subscript(node.slice.elts[0])) == 'int'



# Generated at 2022-06-21 10:07:49.472631
# Unit test for function table
def test_table():
    assert table("a", "b", [["c", "d"], ["e", "f"]]) == \
        "| a | b |\n|:---:|:---:|\n| c | d |\n| e | f |\n\n"
