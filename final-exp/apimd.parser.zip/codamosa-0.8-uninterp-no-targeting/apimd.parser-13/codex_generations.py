

# Generated at 2022-06-21 10:03:30.426583
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from io import StringIO
    from contextlib import redirect_stdout
    import ast
    import re

    source = """\
"""
    p = Parser()
    p.load_docstring('test', ast.parse(source))
    text = StringIO()
    with redirect_stdout(text):
        p.compile()
    assert text.getvalue().strip() == """\
"""

# Generated at 2022-06-21 10:03:33.129362
# Unit test for function code
def test_code():
    assert code("test") == "`test`"
    assert code("test|test") == '<code>test&#124;test</code>'



# Generated at 2022-06-21 10:03:44.071151
# Unit test for constructor of class Parser
def test_Parser():
    # `Result` function test
    def test_Result(doc: str, mod: dict, m: dict, imp: dict,
                    c: dict, n: dict, d: dict, ds: dict,
                    a: dict, l: dict):
        assert isinstance(doc, str)
        for i in mod:
            assert i in m
            assert m[i] == mod[i]
        for i in imp:
            assert i in m
            assert i in imp
            for j in imp[i]:
                assert j in m
        for i in c:
            assert i in m
            assert i in c
            assert isinstance(c[i], str)
        for i in n:
            assert i in m
            assert i in n
            assert isinstance(n[i], str)

# Generated at 2022-06-21 10:03:46.876046
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    r = Resolver("pyslvs", {})
    assert code(unparse(r.visit_Constant(Constant(1)))) == '1'
    e = Expr(Call(Name('int', Load()), [Constant(1)], []))
    assert code(unparse(r.visit_Constant(Constant('int(1)')))) == code(unparse(e))


# Generated at 2022-06-21 10:03:52.891610
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    mod = Module(body=[
        Assign(targets=[Name(id='A', ctx=Store())], value=Constant('A')),
        Assign(targets=[Name(id='B', ctx=Store())], value=Constant('B')),
    ])
    root = 'str.replace'
    parser = Parser()
    parser.alias[_m(root, 'A')] = 'A'
    parser.alias[_m(root, 'B')] = 'B'
    parser.alias[_m(root, 'B', 'A')] = 'B.A'
    parser.alias[_m(root, 'B', 'B')] = 'B.B'
    parser.alias[_m(root, 'C')] = 'C'

# Generated at 2022-06-21 10:04:03.535466
# Unit test for function const_type
def test_const_type():
    assert const_type(Constant(1, kind=None)) == 'int'
    assert const_type(Constant(1.0, kind=None)) == 'float'
    assert const_type(Constant('a', kind=None)) == 'str'
    assert const_type(Constant(('a', ), kind=None)) == 'tuple[str]'
    assert const_type(Constant([1], kind=None)) == 'list[int]'
    assert const_type(Constant({1}, kind=None)) == 'set[int]'
    assert const_type(Constant({1: 1}, kind=None)) == 'dict[int, int]'
    assert const_type(Constant(complex(1, 0), kind=None)) == 'complex'

# Generated at 2022-06-21 10:04:15.143625
# Unit test for function doctest
def test_doctest():
    doc = """
    >>> import pyslvs
    >>> pyslvs.__version__
    '1.0'
    """
    assert doctest(doc) == """
    ```python
    >>> import pyslvs
    >>> pyslvs.__version__
    '1.0'
    ```
    """

# Generated at 2022-06-21 10:04:23.211067
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('pyslvs_ui.__init__')
    assert is_public_family('pyslvs_ui.__main__')
    assert is_public_family('pyslvs_ui._ui.__main__')
    assert is_public_family('pyslvs_ui.info')
    assert is_public_family('pyslvs_ui.structures.Point')
    assert not is_public_family('_pyslvs_ui.info')



# Generated at 2022-06-21 10:04:25.245478
# Unit test for function parent
def test_parent():
    assert parent("a") == ""
    assert parent("a.b") == "a"
    assert parent("a.b.c") == "a.b"
    assert parent("a.b.c", level=2) == "a"



# Generated at 2022-06-21 10:04:31.925644
# Unit test for constructor of class Resolver
def test_Resolver():
    c = Resolver('dummy', {})
    e = Expr(Name('name', Load()))
    assert isinstance(c.visit(e), Name)
    e = Expr(Name('dummy', Load()))
    assert isinstance(c.visit(e), Name)
    c = Resolver('dummy', {'dummy': 'module.ClassName'})
    assert isinstance(c.visit(e), Attribute)
    e = Expr(Tuple([]))
    a = BinOp(e, BitOr(), Name('NoneType', Load()))
    assert isinstance(c.visit(a), BinOp)
    a = BinOp(e, BitOr(), Name('None', Load()))
    assert isinstance(c.visit(a), BinOp)

# Generated at 2022-06-21 10:05:57.050740
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    import sys
    m = __import__('typing')
    p = Parser([m.__file__])
    with catch_redirect_stdout() as _:
        p.__post_init__()
    assert "builtins" in sys.modules
    assert p.alias["typing.ABCMeta"] == "ABCMeta"

# Generated at 2022-06-21 10:05:59.201843
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    data_path = os.path.join(os.path.dirname(__file__), 'data')
    m = import_module(data_path)
    root = 'Data'
    parser = Parser({root: _attr(m, root)}, link=True)
    parser.__repr__()

# Generated at 2022-06-21 10:06:03.935573
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    """Unit test for method visit_Constant(self, node: Constant) -> AST."""
    res = Resolver('abc', {}).visit_Constant(Constant('Union[str, int]'))
    wtf = cast(AST, parse('Union[str, int]').body[0])
    assert unparse(res) == unparse(wtf)

# Generated at 2022-06-21 10:06:12.620749
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    """Test for method visit_Subscript of class Resolver."""
    r = Resolver('generic_typing', {})
    assert r.visit_Subscript(Subscript(Name('Optional', Load),
                                       Constant(1), Load())) == \
        BinOp(Constant(1), BitOr(), Constant(None))
    assert r.visit_Subscript(Subscript(Name('Union', Load),
                                       Tuple([Constant(1), Constant(2)], Load()), Load())) == \
        BinOp(BinOp(Constant(1), BitOr(), Constant(2)), BitOr(), Constant(None))
    r = Resolver('generic_typing_deprecated', {})

# Generated at 2022-06-21 10:06:13.331292
# Unit test for method parse of class Parser

# Generated at 2022-06-21 10:06:14.465536
# Unit test for method parse of class Parser
def test_Parser_parse():
  assert True

# Generated at 2022-06-21 10:06:25.102420
# Unit test for function doctest
def test_doctest():
    assert doctest("") == ""
    assert doctest(">>> 1\n2") == "```python\n>>> 1\n2\n```"
    assert doctest(">>> 1\n#\n2") == "```python\n>>> 1\n#\n2\n```"
    assert doctest(">>> 1\n2\n3") == "```python\n>>> 1\n2\n3\n```"
    assert doctest("1\n2\n3") == "1\n2\n3"
    assert doctest("1\n>>> 2\n3") == "1\n```python\n>>> 2\n3\n```"



# Generated at 2022-06-21 10:06:37.372794
# Unit test for function walk_body

# Generated at 2022-06-21 10:06:43.592569
# Unit test for constructor of class Parser
def test_Parser():
    from pathlib import Path
    from pyforest import _example
    from .. import _test

    # Unit test for construction
    with _test.capture_output() as (out, err):
        parser = Parser(TOC=True)
    assert out.getvalue() == "No documentation found in source code:\n\n"
    assert not err.getvalue()
    assert parser.alias == {}
    assert parser.root == {}
    assert parser.level == {}
    assert parser.imp == {}
    assert parser.doc == {}
    assert parser.docstring == {}
    assert parser.const == {}
    assert parser.toc == True

    # Unit test for parsing a file
    with _test.capture_output() as (out, err):
        parser.parse(_example)
    assert not out.getvalue()

# Generated at 2022-06-21 10:06:54.718839
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    p = parse('1')
    assert isinstance(p.body[0].value, Constant)
    p = parse('"typing.Tuple[int, float]"')
    assert isinstance(p.body[0].value, Constant)
    assert code(unparse(p.body[0].value)) == '"typing.Tuple[int, float]"'
    p = parse('"typing.Tuple[int, float]".split()')
    assert isinstance(p.body[0].value, Call)
    p = parse('"typing.Tuple"[int]')
    assert isinstance(p.body[0].value, Subscript)
    n = Resolver('', {}).visit(p.body[0].value.value)
    assert isinstance(n, Name)

# Generated at 2022-06-21 10:07:47.707528
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    import datetime
    parser = Parser()

    assert parser.load_docstring('datetime', datetime) is None
    assert parser.docstring['datetime.date.today'] == '''
        ```python
        >>> today = datetime.date.today()
        >>> today   # doctest: +ELLIPSIS
        datetime.date(...
        ```
    '''

    assert parser.load_docstring('datetime.datetime', datetime.datetime) is None
    assert parser.docstring['datetime.datetime.now'] == '''
        ```python
        >>> now = datetime.datetime.now()
        >>> now   # doctest: +ELLIPSIS
        datetime.datetime(...
        ```
    '''

# Generated at 2022-06-21 10:07:58.866317
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    a, b, c, d, e, f, g, h, i, j, k, l, m, n, *_ = symbols('a, b, c, d, e, f, g, h, i, j, k, l, m, n, *_')
    x = symbols('x')
    root = 'module.submodule'
    t = Parser()
    arg = namedtuple('arg', 'arg annotation')
    def test(args, returns, has_self, cls_method, expected):
        if args is None:
            args = []
        if returns is None:
            returns = None
        if has_self is None:
            has_self = False
        if cls_method is None:
            cls_method = False
        if expected is None:
            expected = []
        res = list

# Generated at 2022-06-21 10:08:06.122639
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    root="tests"
    p=Parser(root, "", False, False, False, False)
    class CM:
        def load(self, name):
            return '"""Comment"""\nx = 42'
    class CM2:
        def load(self, name):
            return '"""Comment"""\n@x\ndef f():\n    pass'
    p.load_docstring(root, CM())
    assert p.docstring[root+".x"]==">>> x\n42"
    p.load_docstring(root, CM2())
    assert p.docstring[root+".f"]==">>> x\n42"


# Generated at 2022-06-21 10:08:11.858038
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():

    # Test ast_eq, is_equal and walk_body
    parser = Parser()
    # Test ast_eq
    ast1 = parse("""
        def foo():
            pass
    """)
    ast2 = parse("""
        def foo():
            pass
    """)
    result = parser.ast_eq(ast1, ast2)
    assert result == True
    # Test is_equal
    ast1 = parse("""
        def foo():
            pass
    """)
    ast2 = parse("""
        def foo():
            pass
    """)
    result = parser.is_equal(ast1, ast2)
    assert result == True
    # Test walk_body
    code = """
        def foo():
            pass
    """

# Generated at 2022-06-21 10:08:14.417392
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    path = 'test.py'
    b_level = 3
    parsed = Parser(path, b_level)
    assert repr(parsed) == f"Parser({path!r}, {b_level!r})"



# Generated at 2022-06-21 10:08:18.831789
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    node = Subscript(Name("a", Load()), Tuple([]), Load())
    r = Resolver("", {})
    assert r.visit_Subscript(node) == node
    b = Subscript(Name("typing", Load()), Tuple([Constant("a"), Constant("b")]), Load())
    r = Resolver("", {"typing": "typing"})
    assert r.visit_Subscript(b) == BinOp(Constant("a"), BitOr(), Constant("b"))


# Generated at 2022-06-21 10:08:26.383428
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    p = Parser()
    root = 'root'
    p.alias[root] = 'alias'
    p.b_level = 3
    assert_eq(p.resolve(root, Name(id='alias', ctx=Load())), 'alias')
    assert_eq(p.resolve(root, Name(id='root', ctx=Load())), 'root')

    assert_eq(p.resolve(root, Name(id='alias', ctx=Store())), 'alias')
    assert_eq(p.resolve(root, Name(id='root', ctx=Store())), 'root')

    assert_eq(p.resolve(root, Name(id='alias', ctx=Del())), 'alias')

# Generated at 2022-06-21 10:08:34.550161
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family("one")
    assert is_public_family("_one") is False
    assert is_public_family("__one__")
    assert is_public_family("__one") is False
    assert is_public_family("one__") is False
    assert is_public_family("one.__two") is False
    assert is_public_family("one.__two__")
    assert is_public_family("one.two")
    assert is_public_family("one._two") is False
    assert is_public_family("one._two.three.__four__") is False

