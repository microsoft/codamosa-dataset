

# Generated at 2022-06-21 10:01:26.254221
# Unit test for function doctest
def test_doctest():
    doc = """
    >>> test = 'this is a test.'
    >>> print(test)
    """
    assert doctest(doc) == """
    ```python
    >>> test = 'this is a test.'
    >>> print(test)
    ```
    """



# Generated at 2022-06-21 10:01:29.034421
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    resolver = Resolver("", {})
    assert isinstance(resolver.visit(Name("a", Load())), Name)
    assert isinstance(resolver.visit(Attribute(Name("a", Load()), "b", Load())), Attribute)
    assert isinstance(resolver.visit(Attribute(Name("typing", Load()), "Union", Load())), Name)
    assert (resolver.visit(Attribute(Name("typing", Load()), "Union", Load()))).id == "Union"

# Generated at 2022-06-21 10:01:41.008158
# Unit test for function const_type
def test_const_type():
    assert const_type(Constant(1)) == 'int'
    assert const_type(Constant(1.0)) == 'float'
    assert const_type(Constant(1+1j)) == 'complex'
    assert const_type(Constant('hello')) == 'str'
    assert const_type(Constant(True)) == 'bool'
    assert const_type(Constant(b'hello')) == 'bytes'
    assert const_type(Tuple([Constant(1), Constant(2.0)], Load())) == 'tuple[int, float]'
    assert const_type(List([Constant(1), Constant(2.0)], Load())) == 'list[int, float]'

# Generated at 2022-06-21 10:01:45.373926
# Unit test for method parse of class Parser
def test_Parser_parse():
    from . import pyinit
    from . import pyparse
    from . import pyreject
    from . import pyskip
    from . import pystub
    p = Parser()
    p.parse(pystub.__file__)
    p.parse(pyparse.__file__)
    p.parse(pyinit.__file__)
    p.parse(pyskip.__file__)
    p.parse(pyreject.__file__)
    p.parse(pyinit.__file__)
    assert p.doc
    assert p.docstring
    assert p.root
    assert p.level
    assert p.alias


# Generated at 2022-06-21 10:01:48.053020
# Unit test for constructor of class Parser
def test_Parser():
    """Test for `Parser`'s constructor."""
    parser = Parser()
    assert len(parser.doc) == 0
    assert len(parser.alias) == 0
    assert len(parser.imp) == 0
    assert len(parser.const) == 0
    assert len(parser.level) == 0
    assert parser.b_level == 0
    assert parser.link == False
    assert parser.toc == False



# Generated at 2022-06-21 10:01:52.184980
# Unit test for constructor of class Resolver
def test_Resolver():
    """Test for Resolver."""
    # type: () -> None
    assert Resolver('test', {}).visit(Name('Tuple', Load()))
    assert Resolver('test', {}).visit(parse('test.Union[test.A, test.B]').body[0].value)
    assert Resolver('test', {}).visit(parse('test.Optional[test.A]').body[0].value)
    Resolver('test', {'test.Mapping': 'typing.Mapping'}).visit(parse('test.Mapping').body[0])
    Resolver('test', {'test.Union': 'typing.Union'}).visit(parse('test.Union').body[0])

# Generated at 2022-06-21 10:01:59.739071
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("_") == r"\_"
    assert esc_underscore("_x") == r"\_x"
    assert esc_underscore("x_y") == r"x\_y"
    assert esc_underscore("x_") == r"x\_"
    assert esc_underscore("_x_") == r"\_x\_"
    assert esc_underscore("__") == r"\_\_"



# Generated at 2022-06-21 10:02:11.138287
# Unit test for function walk_body
def test_walk_body():
    from .utils import code_to_ast

    def f(a: int) -> int:
        """This is a test for walker."""
        if a == 1:
            yield 1
        try:
            return a
        except:
            for i in range(a):
                yield i
        else:
            return a + 1
        finally:
            yield a

    c = code_to_ast(f)
    names = {node.name for node in walk_body(c.body)}
    assert names == {
        'test_walk_body',
        'If',
        'Try',
        'Return',
        'Yield',
        'For',
        'Return',
        'Yield',
    }



# Generated at 2022-06-21 10:02:15.365008
# Unit test for method api of class Parser
def test_Parser_api():
    """Test method api of class Parser."""
    with freeze_time("2020-04-15T13:20:00+09:00"):
        p = Parser(link=False, toc=False)
        from .test_test_utils import test
        p.api("test", test)
        p.load_docstring("test", test)

# Generated at 2022-06-21 10:02:24.491167
# Unit test for function parent
def test_parent():
    assert parent('pyslvs_ui.data', level=0) == 'pyslvs_ui.data'
    assert parent('pyslvs_ui.data', level=1) == 'pyslvs_ui.data'
    assert parent('pyslvs_ui.data', level=2) == 'pyslvs_ui.data'
    assert parent('pyslvs_ui.data', level=3) == 'pyslvs_ui'
    assert parent('pyslvs_ui.data', level=4) == 'pyslvs_ui'
    assert parent('pyslvs_ui.data', level=5) == 'pyslvs_ui'
    assert parent('pyslvs_ui.data', level=6) == 'pyslvs_ui'



# Generated at 2022-06-21 10:04:33.196468
# Unit test for method imports of class Parser
def test_Parser_imports():
    s = 'from os import path'
    m = 'os'
    parser = Parser()
    parser.imports(m, parse(s).body[0])
    parser.alias['os.path'] == 'path'


# Generated at 2022-06-21 10:04:38.434324
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    p1 = Parser(True, {})
    p2 = Parser(False, {})
    p3 = Parser(True, {})
    assert p1 != p2
    assert not p1 == p2
    assert p1 == p3
    assert not p1 != p3

# Generated at 2022-06-21 10:04:49.512754
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    r = Resolver("__main__", {}, "")
    assert r.visit(Constant("T")) == Constant("T")
    assert r.visit(Constant("int")) == Constant("int")
    assert r.visit(Constant("1")) == Constant("1")
    assert r.visit(Constant("int(1)")) == Constant("int(1)")
    assert r.visit(Constant("a")) == Name("a", Load())
    assert r.visit(Constant("a(b, c)")) == Call(Name("a", Load()), [Name("b", Load()), Name("c", Load())], [])
    assert r.visit(Constant("a.b")) == Attribute(Name("a", Load()), "b", Load())

# Generated at 2022-06-21 10:04:59.899596
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    """Test case for method load_docstring of class Parser."""
    parser = Parser(lambda s: s)
    m = types.ModuleType('mymath')
    m.add = lambda a, b: a + b
    m.__doc__ = 'Hello!'
    parser.doc['mymath'] = '*{}*\n\n'
    parser.load_docstring('mymath', m)
    assert parser.docstring['mymath'] == doctest('Hello!')
    parser = Parser(lambda s: s)
    m = types.ModuleType('mymath')
    m.__doc__ = 'Hello!'
    parser.doc['mymath'] = '# Hello\n\n*{}*\n\n'
    parser.load_docstring('mymath', m)
    assert parser.docstring

# Generated at 2022-06-21 10:05:11.354515
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():

    p1 = Parser([])
    p2 = Parser([])
    assert not p1 == p2

    p1 = Parser([])
    p2 = Parser([('a', 1)])
    assert not p1 == p2

    p1 = Parser([('a', 1)])
    p2 = Parser([])
    assert not p1 == p2

    p1 = Parser([('a', 1)])
    p2 = Parser([('a', 1)])
    assert p1 == p2

    p1 = Parser([('a', 1)])
    p2 = Parser([('a', 2)])
    assert not p1 == p2

    p1 = Parser([('a', 1)])
    p2 = Parser([('b', 1)])
    assert not p1 == p

# Generated at 2022-06-21 10:05:15.880293
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    parser = Parser()
    parser.func_api('test', 'test', arguments(args=[arg('a', Num(1))]), returns=Name('str', Load()))
    assert parser.compile().strip() == "* a: `int`"

# Generated at 2022-06-21 10:05:18.940687
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__init__')
    assert is_magic('__all__')
    assert is_magic('__new__')
    assert not is_magic('hello')

# Generated at 2022-06-21 10:05:23.408038
# Unit test for function walk_body
def test_walk_body():
    if_try_if = parse("""
if True:
    if False:
        pass
else:
    try:
        pass
    except:
        pass
    else:
        pass
    finally:
        pass
    """).body
    assert len(list(walk_body(if_try_if))) == 9



# Generated at 2022-06-21 10:05:35.163460
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    text = "def foo():\n    a: int = 1"
    parser = Parser(text, link=False, toc=False)
    assert parser.alias == {'foo': 'foo', 'foo.foo': 'foo.foo'}
    assert parser.doc == {
        'foo': '## foo()\n\n*Full name:* `foo`\n\n',
        'foo.foo': '### foo()\n\n*Full name:* `foo.foo`\n\n'}
    assert parser.level == {'foo': 1, 'foo.foo': 1}
    assert parser.root == {'foo': 'foo', 'foo.foo': 'foo'}
    assert parser.const == {}
    assert parser.docstring == {}
    assert parser.imp == {'foo': set()}


# Generated at 2022-06-21 10:05:36.492802
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    assert not Parser.class_api.__annotations__



# Generated at 2022-06-21 10:07:34.476676
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('_foo') is False
    assert is_public_family('__foo') is True
    assert is_public_family('_foo.__bar') is False
    assert is_public_family('foo.__bar') is True
    assert is_public_family('foo.__bar.foo') is True
    assert is_public_family('__foo.bar.__bar') is True



# Generated at 2022-06-21 10:07:47.031635
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser(None)
    assert p.func_ann('', []) == []
    f = FunctionDef(arguments(args=[arg(arg='a', annotation=Name(id='int')),
                                    arg(arg='b', annotation=Name(id='float'))],
                             kwonlyargs=[arg(arg='c',
                                             annotation=Name(id='bool'))]),
                    [], None)
    args = [arg(arg='a', annotation=None),
            arg(arg='b', annotation=None),
            arg(arg='*', annotation=None),
            arg(arg='c', annotation=None),
            arg(arg='d', annotation=None),
            arg(arg='**e', annotation=None),
            arg(arg='return', annotation=None)]

# Generated at 2022-06-21 10:07:58.360107
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    import inspect
    import ast
    import astor
    Parser._DEBUG_MODE = True
    class Ann(ast.AST):
        def __init__(self, name: str) -> None:
            self.name = name
        
        def __repr__(self) -> str:
            return f'Custom({self.name})'
        
        _fields = ['name']
    class Resolver(ast.NodeTransformer):
        alias: Dict[str, str]
        self_ty: str
        root: str
        def __init__(self, root: str, alias: Dict[str, str], self_ty: str) -> None:
            self.root = root
            self.alias = alias
            self.self_ty = self_ty
        

# Generated at 2022-06-21 10:08:02.068523
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('os.path.basename')
    assert not is_public_family('_os.path.basename')
    assert not is_public_family('os.path._basename')
    assert is_public_family('_os.path._basename')



# Generated at 2022-06-21 10:08:06.734115
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    """Unit test for method visit_Name of class Resolver"""
    assert unparse(Resolver("os.path", {}).visit(parse("sys.path").body[0].value)) == "sys.path"
    assert unparse(Resolver("os.path", {"os.path.List": "typing.List[str]"}).visit(parse("List").body[0].value)) == "typing.List[str]"

# Generated at 2022-06-21 10:08:16.435271
# Unit test for function parent
def test_parent():
    assert parent('pyslvs') == ''
    assert parent('pyslvs.') == 'pyslvs'
    assert parent('pyslvs.core') == 'pyslvs'
    assert parent('pyslvs.core.data_struct') == 'pyslvs.core'
    assert parent('pyslvs.core.data_struct', level=2) == 'pyslvs'
    assert parent('pyslvs.core.data_struct', level=3) == 'pyslvs'
    assert parent('pyslvs.core.data_struct', level=4) == 'pyslvs'



# Generated at 2022-06-21 10:08:22.034841
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    """Test for method load_docstring of class Parser"""
    from .test_mock import Docstring

    parser = Parser()
    parser.load_docstring('test', Docstring)
    assert 'test.x' in parser.docstring
    assert 'test.y' in parser.docstring
    assert 'test.C' not in parser.docstring
    parser.load_docstring('test.C', Docstring.C)
    assert 'test.C' in parser.docstring
    assert 'test.C.m' in parser.docstring



# Generated at 2022-06-21 10:08:28.729533
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    p = Parser()
    p.alias = {
        'pretty.b': 'pretty.a',
        'pretty.a': 'pretty.a.c',
        'pretty.a.c': 'str',
    }
    p.root = {
        'pretty.a': 'pretty',
        'pretty.a.c': 'pretty.a',
        'pretty.b': 'pretty',
        'pretty.c': 'pretty',
    }

    def check(node: str, expected: str) -> None:
        assert p.resolve('pretty', parse_expr(node), 'Self') == expected

    check('a', 'a')
    check('a.b', 'a.b')
    check('a[b]', 'a[b]')
    check('a.B', 'a.B')