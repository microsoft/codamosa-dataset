

# Generated at 2022-06-21 10:02:37.719777
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    class Test:
        class typing:
            pass
    r = Resolver('Test', {})
    n = Attribute(Name('typing', Load()), 'Union', Load())
    r.visit(n)
    # type: ignore
    assert n.value.id == 'typing'
    assert n.attr == 'Union'
    n = Attribute(Name('not_typing', Load()), 'Union', Load())
    r.visit(n)
    # type: ignore
    assert n.value.id == 'not_typing'
    assert n.attr == 'Union'


# Generated at 2022-06-21 10:02:40.541221
# Unit test for function parent
def test_parent():
    name = "pyslvs"
    assert name == parent(name, level=0)
    assert "" == parent(name, level=1)
    assert "pyslvs" == parent(name, level=2)



# Generated at 2022-06-21 10:02:41.777092
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert parse('typing.List').body[0].value.value == 'typing'



# Generated at 2022-06-21 10:02:45.627503
# Unit test for method imports of class Parser
def test_Parser_imports():
    f = "import foo, bar as baz\nfrom foo.bar.baz import bar as foo\n"
    t = {
        ".": {"foo": "foo", "baz": "bar"},
        ".foo.bar.baz": {"foo": "foo.bar.baz.bar"},
        ".foo": {"bar": "foo.bar"},
        ".foo.bar": {"baz": "foo.bar.baz"},
        }
    p = Parser().visit_Module(parse(f))
    assert p.alias == t

# Generated at 2022-06-21 10:02:55.099685
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    @dataclass
    class _Node: pass
    class _AST: pass
    setattr(_AST, 'Collections', ModuleType('Collections'))
    setattr(_AST, 'Deque', _Node())
    setattr(_AST, 'NRectangle', _Node())
    setattr(_AST, 'List', _Node())
    setattr(_AST, 'Set', _Node())
    setattr(_AST, 'Dict', _Node())
    setattr(_AST, 'Union', _Node())
    setattr(_AST, 'Optional', _Node())
    setattr(_AST, 'typing', ModuleType('typing'))
    setattr(_AST.typing, 'Tuple', _Node())
    setattr(_AST.typing, 'TypeVar', _Node())

# Generated at 2022-06-21 10:03:06.920849
# Unit test for method api of class Parser
def test_Parser_api():
    """Unit test for method api of class Parser."""
    test_path = "tests/examples"
    logger.debug("Loading API")
    parser = Parser()
    modules = parser.load(test_path, filter_=lambda f: f.endswith(".py"))
    # pylint: disable=W0631
    import tests.examples.alias
    import tests.examples.decs
    import tests.examples.module_docstring
    import tests.examples.module_fmt
    import tests.examples.module_no_doc
    import tests.examples.no_doc

# Generated at 2022-06-21 10:03:18.238145
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    e = parse('typing.Union[str, int]').body[0]
    assert unparse(cast(expr, Resolver('', {'typing': '', 'Union': 'Union'}).visit(e))) == 'Union[str, int]'
    assert unparse(cast(expr, Resolver('', {'typing': '', 'Union': 'typing.Union'}).visit(e))) == 'typing.Union[str, int]'
    assert unparse(cast(expr, Resolver('', {'typing': '', 'Union': 'typing.Union[int]'}).visit(e))) == 'Union[int]'

# Generated at 2022-06-21 10:03:22.297943
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__magic__') is True
    assert is_magic('__magic__.a') is False
    assert is_magic('a.__magic__') is True
    assert is_magic('a.b.__magic__') is True



# Generated at 2022-06-21 10:03:34.249135
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    f = Parser([], False, False)
    assert (f == Parser([], False, False)) is True
    assert (f == Parser([], False, True)) is False
    assert (f == Parser([], True, False)) is False
    assert (f == Parser([], True, True)) is False
    names = {'a.b': 'c', 'd.e': 'f', 'g.h': 'i'}
    p = Parser(names, False, False)
    assert (p == Parser(names, False, False)) is True
    assert (p == Parser(names, False, True)) is False
    assert (p == Parser(names, True, False)) is False
    assert (p == Parser(names, True, True)) is False

# Generated at 2022-06-21 10:03:39.609946
# Unit test for function parent
def test_parent():
    assert parent("xx.xxx") == "xx"
    assert parent("xx.xxx", level=3) == "xx"
    assert parent("xx.xxx", level=2) == ""
    assert parent("xx.xxx", level=1) == "xx.xxx"
    assert parent("xx.xxx", level=0) == "xx.xxx"



# Generated at 2022-06-21 10:08:23.247723
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    """Test whether the method is_public works properly"""
    res = Parser()
    res.imp = {'pathlib.Path': {'pathlib', 'pathlib.Path.__init__'}}
    assert res.is_public('pathlib.Path') == False
    assert res.is_public('pathlib.Path.__init__') == True


# Generated at 2022-06-21 10:08:32.659726
# Unit test for constructor of class Resolver
def test_Resolver():
    """Generic style data."""

    @dataclass
    class Generic(Resolver):
        """Generic control."""

        ty: str

        def visit_Name(self, node: Name) -> AST:
            """Replace the name with self type."""
            if node.id in (self.ty, "TypeVar"):
                return Name("Self", Load())
            else:
                return super(Generic, self).visit_Name(node)

    assert Generic("K", {}, "TypeVar").visit(parse("K[TypeVar]").body[0].value) \
        == Name("Self", Load())
    assert Generic("K", {}, "TypeVar").visit(parse("K[K]").body[0].value) \
        == Name("Self", Load())