

# Generated at 2022-06-21 10:01:13.303140
# Unit test for constructor of class Resolver
def test_Resolver():
    """Test constructor of class Resolver."""
    # unit test I
    s = ['t[List[tuple]]', 't[List[optional[str]]]', 't[Union[int, str]]']
    r = Resolver('test', {})
    for i in s:
        n = parse(f"({i})").body[0].annotations['t']
        assert n.__repr__() == r.visit(n).__repr__()
    # unit test II
    a = parse(f"({ANY})").body[0].annotations['t']
    c = parse(f"({ANY})").body[0].annotations['c']
    s3 = ['t.a[t]', 't.a[c]', 't.a[tuple[t, c]]']

# Generated at 2022-06-21 10:01:19.989053
# Unit test for function walk_body
def test_walk_body():
    assert code(unparse(walk_body(parse('''
    a = 0
    if True:
        a = 1
    else:
        a = 2
    try:
        a = 3
    except ValueError:
        a = 4
    finally:
        a = 5
    ''').body))).strip() == '''
    a = 0
    a = 1
    a = 2
    a = 3
    a = 4
    a = 5
    '''



# Generated at 2022-06-21 10:01:25.478932
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("_") == "_"
    assert esc_underscore("_a") == "_a"
    assert esc_underscore("a_") == "a_"
    assert esc_underscore("a") == "a"
    assert esc_underscore("_a_") == "\\_a_"
    assert esc_underscore("_a_b_") == "\\_a\\_b_"



# Generated at 2022-06-21 10:01:29.586527
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    from scraper.parsers import __p
    from scraper.parsers import __g
    from pprint import pprint
    p = Parser(__p, __g, False)
    pprint(__import__('pprint').pformat(
        p.__repr__(__dict__, 0, '__builtins__')))

# Generated at 2022-06-21 10:01:35.087179
# Unit test for method globals of class Parser
def test_Parser_globals():
    from queue import Queue
    from collections import Counter

    from . import parse, unparse

    from .eval import TypeEvaluator, VarEvaluator, ConstEvaluator, AsyncEvaluator
    from .visitor import Visitor, GenericVisitor

    from .stub import ModuleStub, ClassStub, TypeAnnotator

    p = Parser()

    def finalize(ns: Any, q: Queue, name: str) -> None:
        ns['__name__'] = name
        p.parse(ns)
        q.put(p.alias)
        q.put(p.root)
        q.put(p.level)
        q.put(p.const)
        q.put(p.doc)
        q.put(p.imp)
    # Test valid case

# Generated at 2022-06-21 10:01:40.081060
# Unit test for method compile of class Parser
def test_Parser_compile():
    logger.info("Test Parser.compile().")
    for n, (text, out) in enumerate(tests_compile):
        p = Parser(text)
        assert ''.join(p.compile().split()).replace('.#', '.#') == \
               ''.join(out.split()).replace('.#', '.#')
        if logger.isEnabledFor(DEBUG):
            logger.debug(f"Compile test{n} passed.")
    logger.info("All compile tests passed.")

# Tests of Parser.__init__(self, text: str, *, link: bool = False,
#                          b_level: int = 0, toc: bool = True)

# Generated at 2022-06-21 10:01:45.184730
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser(b_level=0, link=False, toc=False)
    p.func_ann('root', [
        arg('*', None),
        arg('x', parse('List[str]')),
        arg('y', parse('List[int]'))
    ], has_self=True, cls_method=False)
    assert list(p.doc['root']) == ['type[Self]', '', 'List[str]', 'List[int]', '']
    p.func_ann('root', [
        arg('*', None),
        arg('x', parse('List[str]')),
        arg('y', parse('List[int]'))
    ], has_self=True, cls_method=True)

# Generated at 2022-06-21 10:01:50.264348
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    p.imp['a'] = {'a', 'a.b', 'a.b.c', 'a.b.d'}
    p.root['a'] = 'a'
    p.root['a.b'] = 'a'
    p.root['a.b.c'] = 'a.b'
    p.root['a.b.d'] = 'a.b'
    p.level['a'] = 0
    p.level['a.b'] = 1
    p.level['a.b.c'] = 2
    p.level['a.b.d'] = 2
    assert p.is_public('a')
    assert p.is_public('a.b')
    assert p.is_public('a.b.c')

# Generated at 2022-06-21 10:02:01.856326
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    p = Parser('')
    p.alias = {'test.test': 'test.test'}
    p.root = {'test.test': 'test.test'}
    p.doc = {'test.test': 'test.test'}
    p.toc = {'test.test': 'test.test'}
    p.level = {'test.test': 1}
    p.docstring = {'test.test': 'test.test'}
    p.const = {'test.test': 'test.test'}
    p.imp = {'test.test': 'test.test'}
    p.b_level = 1
    p.link = {'test.test': 'test.test'}
    assert p.alias == {'test.test': 'test.test'}
    assert p

# Generated at 2022-06-21 10:02:03.018871
# Unit test for function is_magic
def test_is_magic(): assert not is_magic('pyslvs_ui')

# Generated at 2022-06-21 10:03:41.510770
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    o = Parser(5, 2)
    assert o.b_level == 2
    assert o.doc == {}

# Generated at 2022-06-21 10:03:48.937771
# Unit test for function walk_body
def test_walk_body():
    _if = """
if x > 0:
    if y > 0:
        a = 1
    else:
        a = 2
else:
    if y > 0:
        a = 3
    else:
        a = 4
"""
    _try = """
try:
    if x > 0:
        a = 1
except ValueError:
    a = 2
else:
    a = 3
finally:
    a = 4
"""
    assert list(walk_body(parse(_if).body)) == list(parse(_if).body)
    assert list(walk_body(parse(_try).body)) == list(parse(_try).body)


# Generated at 2022-06-21 10:03:52.861936
# Unit test for method api of class Parser
def test_Parser_api():
    from os.path import expanduser, dirname, abspath
    from . import parser_test
    from .parser_test import test_files

    def check(parser: Parser, path: str, *, module: str = '') -> None:
        parser.parse(abspath(expanduser(path)))
        assert parser.compile() == parser_test.get_doc(module or path)

    parser = Parser()
    for m, p, f in test_files:
        check(parser, f, module=m)

# Generated at 2022-06-21 10:03:59.017799
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    assert str(Resolver('math', {}).visit(parse('a ** 3').body[0].value)) == 'a ** 3'
    assert str(Resolver('math', {}).visit(parse('math.pi').body[0].value)) == 'pi'
    assert str(Resolver('math', {'math': 'typing'}).visit(parse('math.a').body[0].value)) == 'a'
    assert str(Resolver('math', {'math.a': 'math.b'}).visit(parse('math.a').body[0].value)) == 'b'
    assert str(Resolver('math', {'math.a': 'typing.Union'}).visit(parse('math.a').body[0].value)) == 'Union'

# Generated at 2022-06-21 10:04:07.074105
# Unit test for method globals of class Parser

# Generated at 2022-06-21 10:04:10.167572
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    p = Parser()
    p.load_docstring("math", math)
    p.load_docstring("math", math)
    assert p.docstring['math.factorial'] == ''



# Generated at 2022-06-21 10:04:23.470472
# Unit test for method compile of class Parser
def test_Parser_compile():
    from typing import List
    from doctest import testmod
    from doc import compose, get_parser

# Generated at 2022-06-21 10:04:27.036117
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("a_b") == r"a\_b"
    assert esc_underscore("a_") == r"a_"
    assert esc_underscore("_b") == r"_b"
    assert esc_underscore("a") == r"a"

# Generated at 2022-06-21 10:04:33.915345
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    resolve = Resolver("pyslvs_ui", {})
    ast = resolve.visit(Name("int", Load()))
    assert isinstance(ast, Name)
    assert ast.id == "int"
    # Query for a name
    ast = resolve.visit(Name("None", Load()))
    assert isinstance(ast, Name)
    assert ast.id == "None"

# Generated at 2022-06-21 10:04:46.345313
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    # Union[a, b, ...]
    assert Resolver('', {}).visit_Subscript(Subscript(Name('Union', Load()),
                                                      Tuple([]), Load()))\
                            .left\
                            .left == None
    assert Resolver('', {}).visit_Subscript(Subscript(Name('Union', Load()),
                                                      Tuple([Name('a', Load()),
                                                             Name('b', Load())]),
                                                      Load()))\
                            .left\
                            .left\
                            .left\
                            .left\
                            .left\
                            .left == None

# Generated at 2022-06-21 10:06:05.900958
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    with TemporaryDirectory() as d:
        import_name = os.path.join(d, 'import.py')
        with open(import_name, 'w') as f:
            f.write("def f():\n  def g():\n    class C: pass\n")

# Generated at 2022-06-21 10:06:12.901366
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family("itertools")
    assert is_public_family("itertools.chain")
    assert is_public_family("itertools.chain.from_iterable")
    assert is_public_family("itertools.__chain")
    assert is_public_family("itertools.__chain.from_iterable")
    assert not is_public_family("_itertools")
    assert not is_public_family("itertools._chain")
    assert not is_public_family("itertools._chain.from_iterable")
    assert not is_public_family("itertools._chain._from_iterable")



# Generated at 2022-06-21 10:06:21.503821
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore('_') == '_'
    assert esc_underscore('_a_') == '\_a\_'
    assert esc_underscore('_a') == '\_a'
    assert esc_underscore('a_') == 'a\_'
    assert esc_underscore('_a__b_c_') == '\_a\_\_b\_c\_'
    assert esc_underscore('a_a_aa_') == 'a\_a\_aa\_'



# Generated at 2022-06-21 10:06:23.689427
# Unit test for function doctest
def test_doctest():
    assert doctest(
        """
This is the long description.

>>> print('hello')
hello

>>> from test import hello
>>> hello()
""") == """
This is the long description.

```python
>>> print('hello')
hello

>>> from test import hello
>>> hello()
```
"""[1:]



# Generated at 2022-06-21 10:06:29.949641
# Unit test for method imports of class Parser

# Generated at 2022-06-21 10:06:40.559327
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    p.imp['foo.bar'] = frozenset()
    p.root['foo'] = 'foo'
    p.root['foo.bar'] = 'foo.bar'
    p.root['foo.bar.baz'] = 'foo.bar.baz'
    p.root['foo.qux'] = 'foo.qux'
    p.root['foo.quux'] = 'foo.quux'
    p.root['foo.bar.qux'] = 'foo.bar.qux'
    p.root['foo.bar.quux'] = 'foo.bar.quux'

    # All names are public
    assert p.is_public('foo')
    assert p.is_public('foo.bar')
    assert p.is_public('foo.bar.baz')


# Generated at 2022-06-21 10:06:51.355227
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    assert (Parser(args=['--private'], name='docs') ==
            Parser(args=['--private'], name='docs'))
    assert (Parser(args=['--private'], name='docs') !=
            Parser(args=[''], name='docs'))
    assert (Parser(args=['--private'], name='docs') !=
            Parser(args=[''], name='name'))
    assert (Parser(args=['--private'], name='docs') !=
            Parser(args=['--private'], name='name'))
    assert (Parser(args=['--private'], name='docs') !=
            Parser(args=['--merge', 'a'], name='docs'))

# Generated at 2022-06-21 10:07:00.718477
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    assert Parser(path.join(Path(__file__).parent, 'test.py')) == Parser(path.join(Path(__file__).parent, 'test.py'))
    assert Parser('test.py') == Parser('test.py')
    assert Parser('a.py') != Parser('b.py')
    assert Parser('a.py') != 'b.py'
    assert Parser('a.py') == eval(repr(Parser('a.py')))


# Generated at 2022-06-21 10:07:06.079091
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    from importlib import import_module
    p = Parser()
    q = Parser()
    m = import_module(__name__)
    n = import_module(__name__)
    assert p == q
    assert p != m
    assert q != n
    assert p != m
    assert q != n

if __name__ == '__main__':
    test_Parser___eq__()

# Generated at 2022-06-21 10:07:16.223808
# Unit test for constructor of class Resolver
def test_Resolver():
    p = 'pyslvs_ui.widgets.dock_widget.dock_draw_page'
    r = Resolver(p, {})
    assert r.root == p
    assert r.alias == {}
    assert r.self_ty == ''
    assert isinstance(r.visit(parse('__PyQt5.QtWidgets.QListWidget').body[0]),
                      Name)
    assert isinstance(r.visit(parse('123').body[0]), Constant)
    assert isinstance(
        r.visit(
            parse(
                'typing.Optional[__PyQt5.QtWidgets.QListWidget]')
                .body[0]
        ),
        BinOp
    )

# Generated at 2022-06-21 10:08:08.835274
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert 'typing.Union[int, str]' == unparse(Resolver('', {})
                                               .visit(parse('typing.Union[int, str]').body[0]))
    assert 'typing.Optional[int]' == unparse(Resolver('', {})
                                             .visit(parse('typing.Optional[int]').body[0]))
    assert 'int | str' == unparse(Resolver('', {'typing.Union': 'typing.Union'})
                                  .visit(parse('typing.Union[int, str]').body[0]))
    assert 'List[int]' == unparse(Resolver('', {'typing.List': 'typing.List'})
                                  .visit(parse('typing.List[int]').body[0]))
#

# Generated at 2022-06-21 10:08:18.226267
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    # Remove self.alias by test
    self_ty = 'a'
    root = 'b'
    alias = {f'{root}.{self_ty}': self_ty}
    resolver = Resolver(root, alias, self_ty)

    # self_ty
    node = Name(self_ty, Load())
    assertResolver(resolver, node, Name('Self', Load()))

    # alias
    node = Name('c', Load())
    assertResolver(resolver, node, parse(self_ty).body[0].value)

    # non alias
    node = Name('d', Load())
    assertResolver(resolver, node, node)



# Generated at 2022-06-21 10:08:25.512847
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    """Test method is_public of class Parser."""
    parser = Parser(True)
    parser.imp['a.b.c'].add('a.b.c.bar')
    parser.imp['a.b'].add('a.b.foo')
    parser.level['a.b.c'] = 3
    parser.level['a.b.c.bar'] = 4
    parser.level['a.b.c.baz'] = 4
    parser.level['a.b.c.Spam'] = 4
    parser.level['a.b.c.Spam.egg'] = 5
    parser.level['a.b.c.Spam2'] = 4
    parser.root['a.b.c.bar'] = 'a.b.c'