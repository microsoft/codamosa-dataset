

# Generated at 2022-06-21 10:03:55.039955
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    code = '''def f():
    """A function."""
    raise ValueError
'''
    module = Module(parse_typing(code), type_comments={})
    assert Parser('').load_docstring('', module)
    assert Parser('').doc['f'].endswith('\n\n*Full name:* `f`')


# Generated at 2022-06-21 10:03:57.262409
# Unit test for function doctest
def test_doctest():
    """
    >>> a = 1
    >>> b = 2
    >>> a + b
    3
    >>> c = 3
    """



# Generated at 2022-06-21 10:04:01.701037
# Unit test for function walk_body
def test_walk_body():
    from .pep585 import PEP585
    assert PEP585.__name__ in '.'.join(s.id for s in walk_body(parse('''
        if False:
            a = b
            try:
                a = b
            except:
                c = d
            else:
                e = f
            finally:
                g = h
        else:
            i = j
            try:
                i = j
            except:
                k = l
            else:
                m = n
            finally:
                o = p
        ''').body))



# Generated at 2022-06-21 10:04:12.022223
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    the = Parser()

    the.func_api('',
                 '',
                 arguments(args=[arg('a', Name('String', Load()))],
                           vararg=None,
                           kwonlyargs=[],
                           kw_defaults=[],
                           defaults=[]),
                 None,
                 has_self=False,
                 cls_method=False
                )
    assert the.doc == {}


# Generated at 2022-06-21 10:04:23.085171
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    n = Attribute(Name('n', Load()), 'attr1', Load())
    assert n == Resolver('m', {}).visit(n)
    n = Attribute(Attribute(Name('n', Load()), 'attr1', Load()), 'attr2', Load())
    assert n == Resolver('m', {}).visit(n)
    n = Attribute(Name('typing', Load()), 'attr', Load())
    assert Name('attr', Load()) == Resolver('m', {}).visit(n)
    n = Attribute(Name('n', Load()), 'attr', Load())
    assert n == Resolver('m', {}).visit(n)


# Generated at 2022-06-21 10:04:30.741404
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    r = Resolver('parent.name', {}, "")
    r_ann = lambda a: unparse(r.generic_visit(r.visit(a)))

    def c(ann: expr) -> str:
        return p.func_ann('parent.name', [arg('', ann)], has_self=False,
                          cls_method=False)

    assert c(Name('int', Load())) == ['int']
    assert c(Name('List', Load())) == ['List']
    assert c(Call(Name('List', Load()), [], [])) == ['List']
    assert c(Call(Name('List', Load()), [], [Name('str', Load())])) == ['str']

# Generated at 2022-06-21 10:04:43.090995
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser.parse(textwrap.dedent("""\
        import os

        import a as b""")).strip() == textwrap.dedent("""\
        **Table of contents:**

        + [os](#os)""")


# Generated at 2022-06-21 10:04:52.136751
# Unit test for function walk_body
def test_walk_body():
    import ast
    import astor
    def _test(node: stmt) -> stmt:
        source = astor.to_source(node)
        new_node = parse(source)
        assert node == new_node.body[0]
        for n in walk_body([new_node.body[0]]):
            assert isinstance(n, stmt)
            astor.to_source(n)
        return new_node
    _test(ast.parse("if True: print('Yes')").body[0])
    _test(ast.parse("if True: print('Yes')").body[0])
    _test(ast.parse("if True: print('Yes')\nelse: print('Fail')").body[0])

# Generated at 2022-06-21 10:04:57.812080
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore('_') == '_'
    assert esc_underscore('__') == '__'
    assert esc_underscore('___') == r'\_\_\_'
    assert esc_underscore('____') == r'\_\_\_\_'
    assert esc_underscore('____ _') == r'\_\_\_\_\_ \_'



# Generated at 2022-06-21 10:05:04.548095
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    """Assert the parser of function docstring."""
    parser = Parser()
    name = "test"
    lineno = 1
    col_offset = 1
    docstring = "Foo\n"
    args = arguments(
        [arg('a', None)],
        None,
        [arg('b', None)],
        [arg('c', None)],
        arg('*', None),
        [arg('d', None)],
        [arg('e', None)],
        arg('**', None),
    )
    def_node = FunctionDef(
        name, args, [], [],
        returns=Name('str', Load()),
        docstring=docstring,
    )

# Generated at 2022-06-21 10:05:56.894942
# Unit test for method imports of class Parser
def test_Parser_imports():
    import unittest

    class TestParser(unittest.TestCase):
        """Test doc-py's Parser class."""

        def test_imports(self) -> None:
            """Test imports."""
            p = Parser()

# Generated at 2022-06-21 10:06:03.466502
# Unit test for constructor of class Resolver
def test_Resolver():
    assert Resolver("", {}).root == ""
    assert Resolver("root", {}).root == "root"
    assert Resolver("root", {}).alias == {}
    assert Resolver("root", {'a': 'int'}).alias == {'root.a': 'int'}
    assert Resolver("root", {'a': 'int'}, "self").self_ty == "self"



# Generated at 2022-06-21 10:06:08.180089
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    p = Parser()
    p.encoding = 'utf-8'
    p.toc = True
    p.root = {'a': 'a'}
    p.level = {'b': 0}
    p.imp = {'c': {'d'}}
    p.alias = {'e': 'e'}
    p.doc = {'f': 'f'}
    p.docstring = {'g': 'g'}
    p.const = {'h': 'h'}
    p.b_level = 1
    # Test

# Generated at 2022-06-21 10:06:16.361683
# Unit test for function walk_body

# Generated at 2022-06-21 10:06:22.087051
# Unit test for function parent
def test_parent():
    from .api2 import __name__ as mod_name
    assert parent(mod_name) == mod_name.rsplit('.', maxsplit=1)[0]
    assert parent(mod_name, level=2) == mod_name.rsplit('.', maxsplit=2)[0]



# Generated at 2022-06-21 10:06:26.210028
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    def f(a: str, *, b: int = 0) -> dict:
        pass
    p = Parser()
    res = list(p.func_ann('', f.__annotations__['return'], args=(),
                          has_self=False, cls_method=False))
    assert 'dict' in res



# Generated at 2022-06-21 10:06:36.890470
# Unit test for method globals of class Parser
def test_Parser_globals():
    p: Parser = Parser()
    t: Tuple[str, _G] = ('root', node)
    ali: Dict[str, str] = {}
    p.globals(*t)
    assert p.const['root.c'] == 'int'
    assert p.root['root.c'] == 'root'
    assert p.root['root.a'] == 'root'
    p.globals(t[0], node)
    assert p.doc['root.a'] == '# a()\n\n*Full name:* `root.a`\n\n'
    assert not p.imp['root']

# Generated at 2022-06-21 10:06:38.935722
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    p = Parser()
    d = p.doc
    p.load_docstring('a', 'b')
    assert d == p.doc, 'Nothing to check'

# Generated at 2022-06-21 10:06:51.534836
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    node = Attribute(Name("typing", Load()), "Union", Load())
    expect = Name("Union", Load())
    assert Resolver("", {}).visit(node) == expect
    node = Attribute(Name("typing", Load()), "Optional", Load())
    expect = Name("Optional", Load())
    assert Resolver("", {}).visit(node) == expect
    node = Attribute(Name("typing", Load()), "Callable", Load())
    expect = Name("Callable", Load())
    assert Resolver("", {}).visit(node) == expect

    node = Name("Union", Load())
    expect = Name("Union", Load())
    assert Resolver("", {}).visit(node) == expect
    node = Name("Optional", Load())
    expect = Name("Optional", Load())
    assert Res

# Generated at 2022-06-21 10:07:04.624821
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser(['a.b', 'a.c'])
    p.doc['a'] = ''
    p.doc['a.c'] = ''
    p.doc['a.b.d'] = ''
    p.doc['a.b.e'] = ''
    p.level['a'] = 0
    p.level['a.c'] = 1
    p.level['a.b.d'] = 2
    p.level['a.b.e'] = 2
    p.root['a'] = 'a'
    p.root['a.c'] = 'a'
    p.root['a.b.d'] = 'a.b'
    p.root['a.b.e'] = 'a.b'

    assert p.is_public("a")