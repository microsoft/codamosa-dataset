

# Generated at 2022-06-21 10:01:43.590489
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    from importlib import import_module
    from pathlib import Path
    from pathlib import PurePath
    from types import ModuleType
    from typing import Optional
    from typing import Tuple
    from _pytest.monkeypatch import MonkeyPatch
    from docraft import Parser
    from docraft import PathLoader
    from docraft import TextLoader
    from mock_document import mock_buffer
    from mock_document import mock_file
    from mock_document import mock_module
    from mock_document import mock_path
    from mock_document import mock_text
    from test.mock_document import mock_module
    from test.mock_document import mock_path
    from test.mock_document import mock_text
    pars = Parser()
    pars.__post_init__('tests.mock')

# Generated at 2022-06-21 10:01:50.637551
# Unit test for function doctest
def test_doctest():
    assert doctest('''Hi Ho
>>> print('Hello World!')
Hello World!''') == '''Hi Ho
```python
>>> print('Hello World!')
Hello World!
```'''

# Generated at 2022-06-21 10:01:57.877927
# Unit test for function doctest
def test_doctest():
    from textwrap import dedent
    doc = '''
    >>> import ast
    >>> ast.parse('')
    Module(body=[])
    >>> ast.dump(ast.parse(''))
    Module(body=[])
    '''
    doc = doctest(dedent(doc).strip())
    doc1 = '''
    ```python
    >>> import ast
    >>> ast.parse('')
    Module(body=[])
    ```
    >>> ast.dump(ast.parse(''))
    Module(body=[])
    '''
    assert doc == dedent(doc1).strip()

    doc = '''
    >>> from ast import parse
    >>> parse('')
    Module(body=[])
    '''
    doc = doctest(dedent(doc).strip())

# Generated at 2022-06-21 10:02:06.380885
# Unit test for method parse of class Parser
def test_Parser_parse():
    text = 'def f(a: int) -> str: ...'
    with tempfile.NamedTemporaryFile(mode='w') as fout:
        fout.write(text)
        fout.flush()
        p = Parser()
        p.parse(fout.name, '', 0, '')
    assert p.doc['f'] == '# f()\n\n*Full name:* `f`\n<a id="f"></a>\n\n'



# Generated at 2022-06-21 10:02:13.386868
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser('', external_link=True)
    assert parser.link == 'http://sphinx-doc.org'
    assert parser.b_level == 1
    with pytest.raises(ValueError):
        Parser('', external_link='invalid')

    parser = Parser('', link='http://sphinx-doc.org')
    assert parser.link == '#'
    assert parser.b_level == 1


# Generated at 2022-06-21 10:02:20.398958
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    from io import StringIO
    from typing import Any
    from typing import Dict
    from typing import Tuple
    from typing import TypeVar
    from typing_inspect import is_generic_type
    from typing_inspect import get_args
    from typing_inspect import get_origin
    from typing_inspect import is_typevar
    from typing_inspect import is_union_type
    from typing_inspect import is_tuple_type
    from typing_inspect import is_callable_type
    from typing_inspect import is_literal_type
    from typing_inspect import get_generic_args
    from typing_inspect import get_generic_origin
    from typing_inspect import get_generic_type
    from typing_inspect import get_bound
    from typing_inspect import get_parameters
   

# Generated at 2022-06-21 10:02:28.686847
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('abc.def')
    assert is_public_family('abc._def')
    assert not is_public_family('abc._Def')
    assert not is_public_family('abc.__Def')
    assert is_public_family('abc.__Def__')
    assert not is_public_family('abc.def_')
    assert not is_public_family('__abc.def')
    assert is_public_family('__abc__.def')



# Generated at 2022-06-21 10:02:38.690027
# Unit test for method compile of class Parser
def test_Parser_compile():
    p = Parser(link=True)
    p.visit(Module(body=[
        FunctionDef(name='name',
                    args=arguments([arg('a', Name(id='int', ctx=Load()))],
                                   None, None, []),
                    body=[Return(Constant(value=123))]),
        ClassDef(name='Name',
                 bases=[Attribute(value=Name(id='Abc', ctx=Load()),
                                  attr='abc', ctx=Load())],
                 keywords=[],
                 body=[Expr(value=Constant(value=None))])]))

# Generated at 2022-06-21 10:02:41.659074
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    p = Parser()
    assert p.const == {'__file__': 'str', '__package__': 'str',
                       '__doc__': 'str', '__name__': 'str',
                       '__cached__': 'str'}



# Generated at 2022-06-21 10:02:47.280632
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():

    m = ModuleType('test')
    m.__annotations__ = {'a': 'b'}

    n = Resolver('test', {'test.a': 'b'}).visit(Name('a', Load()))
    assert n.id == 'b'


# Generated at 2022-06-21 10:06:58.048440
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('abc') is True
    assert is_public_family('abc.efg') is True
    assert is_public_family('abc._efg') is False
    assert is_public_family('abc.efg._hij._jkl') is False
    assert is_public_family('abc.__efg') is True
    assert is_public_family('abc.efg._hij.__jkl') is True
test_is_public_family()



# Generated at 2022-06-21 10:07:06.656789
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    from .meta import annotate2
    from . import data

    @annotate2('self', int, str)
    def foo(self, num, *args: int) -> str:
        """foo."""

    result = Resolver('a', data.ANNOTATIONS, 'self').visit_arguments(
        foo.__annotations__, None, None
    )
    assert result == arguments(
        [arg('self', ANY, None)], None, [arg('num', int, None)],
        [arg('args', List[int], None)], None, [arg(None, str, None)]
    )

# Generated at 2022-06-21 10:07:12.979564
# Unit test for method compile of class Parser
def test_Parser_compile():
    p = Parser(link=False, toc=False)
    p.doc["__init__"] = "*Full name:* `{}`\n\n"
    p.doc["__init__"] += table("Bases", items=["type[Expected]", "type[Unexpected]"])
    p.doc["__init__"] += table("Members", "Type", items=[("__init__", "Expected")])
    p.docstring["__init__"] = "\n        Constructor.\n\n        """
    s = p.compile()

# Generated at 2022-06-21 10:07:15.342461
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    parser = Parser()
    parser.__repr__()
    # TODO
    pass

# Generated at 2022-06-21 10:07:22.061087
# Unit test for method globals of class Parser
def test_Parser_globals():
    parser = Parser()
    parser.globals('main', ast.parse('''
        a = 1
        b = 'a'
        c = [1, 2]
        d = (1, 2, ('a', 'b'))
        e = None
        f = ...
        g = False
        h = True
        ''').body[0])
assert parser.alias[Parser.__name__] == Parser.__name__

# Generated at 2022-06-21 10:07:32.282411
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family("abc") is True
    assert is_public_family("abc.def") is True
    assert is_public_family("abc._def") is False
    assert is_public_family("abc.__def") is True
    assert is_public_family("abc.__def__") is True
    assert is_public_family("_abc") is False
    assert is_public_family("__abc") is True
    assert is_public_family("__abc__") is True
    assert is_public_family("_abc.def") is False
    assert is_public_family("abc._def") is False
    assert is_public_family("abc.__def") is True
    assert is_public_family("abc.__def__") is True
test_is_public_family()



# Generated at 2022-06-21 10:07:44.294563
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    parser = Parser()
    class_name = 'test_class'


# Generated at 2022-06-21 10:07:50.925608
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    name = "test_Parser_load_docstring"
    if name in sys.modules: del sys.modules[name]
    source = inspect.getsource(test_Parser_load_docstring).lstrip() + '\n'
    source += 'def test_doc():\n    """Test doc."""\n\n'
    exec(source, {'__name__': name})
    p = Parser(name)
    p.load_docstring(name, sys.modules[name])
    assert p.docstring[name + '.test_doc'] == inspect.cleandoc("""
    >>> test_doc()
    """)

# Generated at 2022-06-21 10:08:07.506681
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    def insert_tree(a:AST, b:AST) -> AST:
        a.body.append(b)
        return a
    def insert_tree_itr(a:AST, tree:Iterator[AST]) -> AST:
        a.body.extend(tree)
        return a
    a = Subscript(Name('typing', Load()), Tuple([Name('int', Load()), Name('str', Load())], Load()), Load())  # type:ignore
    r = Resolver('test', {})
    assert r.visit_Subscript(a) == BinOp(Name('int', Load()), BitOr(), Name('str', Load()))
    assert insert_tree(Module(body=[]), a).body[0] == BinOp(Name('int', Load()), BitOr(), Name('str', Load()))

# Generated at 2022-06-21 10:08:11.644818
# Unit test for function is_magic
def test_is_magic():
    assert not is_magic('a')
    assert not is_magic('__a')
    assert not is_magic('a__')
    assert not is_magic('_a__')
    assert is_magic('__a__')

