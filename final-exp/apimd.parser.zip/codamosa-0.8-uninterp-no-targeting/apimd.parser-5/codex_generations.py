

# Generated at 2022-06-21 10:02:01.820879
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    d_info = None
    for root in pkg_resources.resource_listdir(__name__, 'data'):
        if not root.endswith('.py'):
            continue
        path = pkg_resources.resource_filename(__name__, 'data/' + root)
        with open(path) as f:
            source = f.read()
        tree = parse(source, mode='exec').body
        doc = Parser(link=False).parse(tree)
        if d_info is None:
            d_info = doc
        else:
            assert d_info == doc

# Generated at 2022-06-21 10:02:13.518128
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    """test_Parser_func_api
    """
    from .parser import Parser
    from .parser import _arguments, _expr
    from .parser import FunctionDef, arguments
    from .unparse import unparse
    p = Parser(None)
    root = "Root"
    name = "Root.func"

# Generated at 2022-06-21 10:02:22.362412
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    # Case 1
    node = Subscript(Name("a", Load()), Tuple([Constant("1")], Load()), Load())
    assert Resolver("", {}).visit(node).elts == node.elts

    # Case 2
    node = Subscript(Name("a", Load()), Tuple([Constant("1"), Constant("2")], Load()), Load())
    assert Resolver("", {"a": "typing.Union"}).visit(
        node).elts == [Constant("1"), Constant("2")]

    # Case 3
    node = Subscript(Name("a", Load()), Tuple([Constant("1")], Load()), Load())
    assert Resolver("", {"a": "typing.Optional"}).visit(
        node).right == Constant(None)

    # Case 4
    node

# Generated at 2022-06-21 10:02:26.680069
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__self__')
    assert not is_magic('_self__')
    assert not is_magic('__self_')
    assert not is_magic('_self_')
    assert not is_magic('_self')
    assert not is_magic('self')



# Generated at 2022-06-21 10:02:33.258936
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    p1, p2, p3 = Parser(), Parser(), Parser()
    assert p1 == p2 == p3
    p2.load('t1')
    assert p2 != p3 and p2 != p1 and p3 != p1
    p3.load('t1')
    assert p3 == p2 and p3 != p1

# Generated at 2022-06-21 10:02:41.779957
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser({'a': 0, 'b': 1}, 'path') == \
           Parser({'a': 0, 'b': 1}, {'path': 'path'}, 'path')

    assert Parser({'a': 0, 'b': 1}, {'path': 'path'}, 'path') == \
           Parser({'a': 0, 'b': 1}, {'path': 'path'}, {'path': 'path'})

    assert Parser({'a': 0, 'b': 1}, [], 'path') == \
           Parser({'a': 0, 'b': 1}, 'path')

    assert Parser({'a': 0, 'b': 1}, {'path': 'path'}, []) == \
           Parser({'a': 0, 'b': 1}, 'path')


# Generated at 2022-06-21 10:02:46.787393
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    from importlib import import_module
    from pathlib import Path
    import docformatter
    import pytest

    def _indent(s: str, level: int = 0) -> str:
        return '\n'.join((' ' * 4 * level + shell_escape(i))
                        for i in s.splitlines())

    def _resolve_all(p: Parser) -> None:
        for n in list(p.alias):
            p.alias[n] = p.resolve('', p.alias[n])

    def _test(m: str,
              r: Optional[str] = None,
              *, toc: bool = False, format: bool = False) -> str:
        """
        :param toc: include ``Table of contents`` at the beginning
        """
        logger.setLevel('ERROR')

# Generated at 2022-06-21 10:02:49.438413
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    node = Constant('List[int]')
    resolver = Resolver('', {})
    assert isinstance(resolver.visit_Constant(node), List)


# Generated at 2022-06-21 10:02:58.703537
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    """Parser.func_ann"""
    class A:
        """Type"""
    parser = Parser()
    parser.alias['root'] = 'root'
    assert list(parser.func_ann('root', [], 0, False)) == [""]
    assert list(parser.func_ann('root', [arg("arg", "a")], 1, False)) == ["a"]
    assert list(parser.func_ann('root', [arg("/", "A")], 0, False)) == ["A"]
    assert list(parser.func_ann('root', [arg("*", "A")], 0, False)) == [""]
    assert list(parser.func_ann('root', [arg("**", "A")], 0, False)) == [""]

# Generated at 2022-06-21 10:03:10.361076
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    a = Constant('typing.Optional[int]')
    b = Resolver('', {}).visit(a.value)
    assert b.id == 'Optional'
    a = Constant('typing.Union[int, str]')
    b = Resolver('', {}).visit(a.value)
    assert b.left.n == 'int'
    assert b.op == '|'
    assert b.right.s == 'str'
    a = Constant('typing.Union[int, typing.Optional[int]]')
    b = Resolver('', {}).visit(a.value)
    assert b.left.n == 'int'
    assert b.op == '|'
    assert b.right.left.n == 'int'
    assert b.right.op == '|'

# Generated at 2022-06-21 10:04:51.809802
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    p.imp['mymod'] = set()
    p.root['mymod.a'] = 'mymod'
    p.root['mymod.a.b'] = 'mymod'
    p.level['mymod.a.b'] = 1
    p.level['mymod.a'] = 0
    assert p.is_public('mymod.a')
    assert p.is_public('mymod.a.b')
    p.imp['mymod'] = {'mymod.a'}
    assert p.is_public('mymod.a')
    assert p.is_public('mymod.a.b')
    p.imp['mymod'] = {'mymod.a', 'mymod.a.b'}
    assert p.is_public('mymod.a')


# Generated at 2022-06-21 10:04:55.548643
# Unit test for function is_public_family
def test_is_public_family():
    assert not is_public_family('_local_name')
    assert is_public_family('__magic_name')
    assert is_public_family('_local_name.__magic_name')



# Generated at 2022-06-21 10:05:03.162851
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore('') == ''
    assert esc_underscore('_') == '_'
    assert esc_underscore('_x') == '\\_x'
    assert esc_underscore('_x_') == '\\_x\\_'
    assert esc_underscore('_x_y') == '\\_x\\_y'
    assert esc_underscore('x_') == 'x\\_'
    assert esc_underscore('x_y') == 'x\\_y'
    assert esc_underscore('x__') == 'x__'
    assert esc_underscore('x__y') == 'x__y'
    assert esc_underscore('x_y_') == 'x\\_y\\_'

# Generated at 2022-06-21 10:05:04.127749
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring(): ...

# Generated at 2022-06-21 10:05:10.919135
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore('A') == 'A'
    assert esc_underscore('A_B') == 'A_B'
    assert esc_underscore('A__B') == 'A\\__B'
    assert esc_underscore('A_B_C') == 'A\\_B\\_C'
    assert esc_underscore('A_B__C') == 'A\\_B\\_\\_C'



# Generated at 2022-06-21 10:05:22.622724
# Unit test for method globals of class Parser
def test_Parser_globals():
    from kernel.type.token import Token
    from kernel.type.global_ import Global
    from kernel.type.tuple import Tuple
    from kernel.type.list import List
    from kernel.type.ident import Ident
    from kernel.type.const import Const
    from kernel.type.unary import Unary
    from kernel.type.binary import Binary
    from kernel.type.assign import Assign
    from kernel.type.assign_target import AssignTarget
    from kernel.type.name import Name
    from kernel.type.ann_assign import AnnAssign
    from kernel.type.func_def import FuncDef
    from kernel.type.async_func_def import AsyncFuncDef
    from kernel.type.class_def import ClassDef
    from kernel.type.function_type import FunctionType

# Generated at 2022-06-21 10:05:31.952108
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__name__')
    assert is_magic('__init__')
    assert is_magic('_abc___abc_')
    assert not is_magic('__name')
    assert not is_magic('__name_')
    assert not is_magic('__name___')
    assert not is_magic('__name')
    assert not is_magic('_name_')
    assert not is_magic('_name____')
    assert not is_magic('_name')
    assert not is_magic('name__')
    assert not is_magic('name')
    assert not is_magic('name____')



# Generated at 2022-06-21 10:05:41.533123
# Unit test for function walk_body
def test_walk_body():
    from . import dcc as de

    class tt(de.NodeVisitor):

        def __init__(self):
            self.stack = []

        def visit_FunctionDef(self, node):
            name = '.'.join(self.stack + [node.name])
            a = node.args
            assert name == "de.test_walk_body.f"
            assert len(a.args) == 1 and a.args[0].arg == "x" and a.vararg is None
            self.stack.append(node.name)

        def depart_FunctionDef(self, _):
            self.stack.pop()

        def visit_If(self, node):
            assert node.test.func.attr == "eq"
            assert len(node.test.args) == 2 and node.test.args[0].id

# Generated at 2022-06-21 10:05:48.896135
# Unit test for function code
def test_code():
    assert code('abcd') == '<code>abcd</code>'
    assert code('ab|cd') == '<code>ab&#124;cd</code>'
    assert code('ab&cd') == '<code>ab&amp;cd</code>'
    assert code('ab&cd|') == '<code>ab&amp;cd&#124;</code>'
    assert code('|ab&cd') == '<code>&#124;ab&amp;cd</code>'
    assert code('') == ' '
test_code()



# Generated at 2022-06-21 10:05:51.239814
# Unit test for function parent
def test_parent():
    assert parent('pyslvs_ui.dockwidgets.solvespace.solvespace') == 'pyslvs_ui.dockwidgets.solvespace'



# Generated at 2022-06-21 10:08:26.866326
# Unit test for function walk_body
def test_walk_body():
    tree = parse('def f():\n    if 1:\n        x = 1\n    if x:\n        x += 1\nelse:\n    x = 2')
    assert [code(unparse(node)) for node in walk_body(tree.body[0].body)] == [
        'x = 1',
        'x += 1'
    ]
    tree = parse('def f():\n    if 1:\n        x = 1\n    try:\n        x += 1\n    except:\n        x += 2\nelse:\n    x = 2')
    assert [code(unparse(node)) for node in walk_body(tree.body[0].body)] == [
        'x = 1',
        'x += 1',
        'x += 2',
    ]



# Generated at 2022-06-21 10:08:31.995621
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    p = Parser()
    assert (p == Parser(p.alias, p.level, p.root, p.imp, p.doc, p.docstring, p.const, p.link))
    assert not (p == Parser(dict(p.alias), p.level, p.root, p.imp, p.doc, p.docstring, p.const, p.link))
    assert not (p == Parser(p.alias, dict(p.level), p.root, p.imp, p.doc, p.docstring, p.const, p.link))
    assert not (p == Parser(p.alias, p.level, dict(p.root), p.imp, p.doc, p.docstring, p.const, p.link))