

# Generated at 2022-06-21 10:03:56.235791
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    """Test for is_public method of class Parser"""

# Generated at 2022-06-21 10:04:02.360391
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser()
    f = FunctionDef(arguments(posonlyargs=[arg('a1', None)],
                              args=[arg('a2', None)],
                              vararg=arg('a3', None),
                              kwonlyargs=[arg('a4', None)],
                              kw_defaults=[None],
                              kwarg=arg('a5', None)),
                    returns=None,
                    body=[],
                    decorator_list=[],
                    name='f')
    p.func_api('a', 'a.f', f.args, f.returns, has_self=False, cls_method=False)

# Generated at 2022-06-21 10:04:13.886639
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("_") == r"\_"
    assert esc_underscore("__") == r"\__"
    assert esc_underscore("___") == r"\___"
    assert esc_underscore("____") == r"\____"
    assert esc_underscore("_____") == r"\_____"
    assert esc_underscore("____a") == r"\____a"
    assert esc_underscore("a_a") == r"a\_a"
    assert esc_underscore("__a") == r"\__a"
    assert esc_underscore("a__a") == r"a\__a"
    assert esc_underscore("a__") == r"a\__"
    assert esc_underscore("a_a_a") == r"a\_a\_a"


# Generated at 2022-06-21 10:04:20.367286
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    tree = parse('from typing import List').body[0]  # type: ignore
    n = Resolver('__main__', {}).visit(tree)
    assert str(n) == 'from typing import List'
    n = Resolver('__main__', {'__main__.List': 'List'}).visit(tree)
    assert str(n) == 'from typing import List'

# Generated at 2022-06-21 10:04:29.411411
# Unit test for method imports of class Parser
def test_Parser_imports():
    """Test for method imports of class Parser."""
    p = Parser()
    p.imports("a", Import([alias("b", "c")]))
    p.imports("a", Import([alias("b", "d")]))
    assert p.alias == {"a.b": "c"}
    assert p.alias["a.b"] == p.alias.get("a.d")
    p.imports("a", ImportFrom("b", [alias("c", "d")], 0))
    assert p.alias == {"a.b": "c", "a.c": "b.c"}
    p.imports("a", ImportFrom("b", [alias("c", "f", "e")], 0))

# Generated at 2022-06-21 10:04:41.407116
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    p1 = Parser(set())
    p2 = Parser(set())
    assert p1 == p2
    p3 = Parser({1, 2, 3})
    p4 = Parser({1, 2, 3})
    assert p3 == p4
    p4.root = {1: 2}
    assert p3 != p4
    p4.root = {}
    p4.alias = {1: 2}
    assert p3 != p4
    p4.alias = {}
    p4.imp = {1: {2, 3}}
    assert p3 != p4
    p4.imp = {}
    p4.const = {1: 2}
    assert p3 != p4
    p4.const = {}
    p4.doc = {1: 2}
    assert p3 != p4


# Generated at 2022-06-21 10:04:51.539437
# Unit test for method visit_Attribute of class Resolver

# Generated at 2022-06-21 10:04:57.426168
# Unit test for function is_magic
def test_is_magic():
    assert is_magic("abc") is False
    assert is_magic("__abc") is False
    assert is_magic("abc__") is False
    assert is_magic("__abc__") is True
    assert is_magic("__abc__.__def__") is False
    assert is_magic("__abc__.__def__.__ghi__") is False



# Generated at 2022-06-21 10:05:08.679571
# Unit test for method compile of class Parser
def test_Parser_compile():
    from .parser import Parser
    from .cache import Cache
    from . import ParserRes
    from . import CacheRes
    from . import temp_file
    from . import rm_file
    import os.path
    import io
    import sys
    import shutil
    import unittest
    import warnings
    class TestParserCompile(unittest.TestCase):
        """Unit test for method compile of class Parser.
        """
        def setUp(self) -> None:
            """Initialize the test environment.
            """
            self.file_name = 'test_file_for_Parser.py'
            self.cache_dir = 'test_cache'
            self.maxDiff = None
            warnings.simplefilter('ignore', ResourceWarning)
            self.test_files = []
            self.test_caches = []

# Generated at 2022-06-21 10:05:20.663025
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('pyslvs_ui')
    assert is_public_family('pyslvs_ui.pyslvs')
    assert is_public_family('pyslvs_ui.QtCore')
    assert is_public_family('pyslvs_ui.QtCore.Qt')
    assert is_public_family('pyslvs_ui.QtCore.Qt.__init__')
    assert is_public_family('pyslvs_ui.pyslvs.collections.abc')
    assert not is_public_family('pyslvs')
    assert not is_public_family('pyslvs.designer')
    assert not is_public_family('pyslvs.util.__init__')

# Generated at 2022-06-21 10:07:20.351420
# Unit test for function walk_body

# Generated at 2022-06-21 10:07:27.411727
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore('foo') == 'foo'
    assert esc_underscore('foo_bar') == 'foo\_bar'
    assert esc_underscore('foo_bar_baz') == 'foo\_bar\_baz'
    assert esc_underscore('foo_bar_baz_') == 'foo\_bar\_baz\_'
    assert esc_underscore('_foo_bar_baz_') == '\_foo\_bar\_baz\_'



# Generated at 2022-06-21 10:07:32.400939
# Unit test for constructor of class Parser
def test_Parser():
    ast = parse("""
        class A:
            def foo(self, a: str, *b, c, d=1, e=2, **f) -> List[Tuple[int, str]]: ...
    """)
    root = ast.body[0].name
    doc = Parser(ast).compile()
    assert "[Function]" not in doc
    assert "*Full name:*" not in doc



# Generated at 2022-06-21 10:07:44.398750
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    target = __file__.replace('.py', '_test.py')
    d = {i: j for i, j in globals().items() if hasattr(j, '__annotations__')}
    with patch.dict(globals(), d, clear=True):
        s = Parser().parse(target)
    doc = s.compile()
    assert search(r'^class Test\s*\n+^\s*\*Full name:\*\s+`testt.Test`', doc, I)
    assert search(r'^\s*@staticmethod', doc, I)
    assert search(r'^\s*def aa\((.*)\) -> int\s*\n+.*\n+\s*\*Full name:\*', doc, I)

# Generated at 2022-06-21 10:07:47.580169
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__builtin__.__doc__')
    assert is_magic('__builtin__') == False
    assert is_magic('__builtin__.__all__') == False


# Generated at 2022-06-21 10:07:58.769008
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    """Test method resolve of class Parser."""
    class Local:
        """Local class."""
        pass
    p = Parser()
    p.alias['test'] = 'test'
    p.alias['test.n'] = 'test.n'
    p.alias['test.n.n'] = 'test.n.n'
    p.alias['test.n.n.n'] = 'test.n.n.n'
    p.alias['test.n.n.n.n'] = 'test.n.n.n.n'
    ast.parse('test.n.n.n.n = 2')
    locals()['Local'] = Local
    eq_(p.resolve("test", ast.parse("n")), "test.n")

# Generated at 2022-06-21 10:08:07.144887
# Unit test for method resolve of class Parser

# Generated at 2022-06-21 10:08:13.465461
# Unit test for function const_type

# Generated at 2022-06-21 10:08:19.681958
# Unit test for method __post_init__ of class Parser

# Generated at 2022-06-21 10:08:22.233286
# Unit test for function table
def test_table():
    print("Test function table")
    print(table("hello", "world", [("1.0", "2.0"), ("3.0", "4.0")]))
test_table()

