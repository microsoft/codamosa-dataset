

# Generated at 2022-06-21 10:03:31.879314
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    p = Parser()
    assert p == Parser()
    assert not (p != Parser())
    p1 = Parser(link=True)
    assert p1 != Parser()
    assert not (p1 == Parser())
    p2 = Parser(lang=Lang.PYTHON)
    assert p2 != Parser()
    assert not (p2 == Parser())

# Generated at 2022-06-21 10:03:43.050229
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    p = Parser(None)
    assert p.class_api('', ClassDef(
        name='Test',
        args=arguments([
            arg('a', Name(id='int')),
            arg('b', Name(id='str'))
        ]),
        body=[
            Pass()],
        decorator_list=[
            Name(id='staticmethod')]
    ), [], []) == '#### class Test\n\n*Full name:* `Test`\n\n' + \
        table('Bases', items=['int', 'str']) + \
        table('Decorators', items=['@staticmethod']) + \
        table('Members', 'Type', items=[('a', ANY), ('b', ANY)]) + \
        '\n\n'

# Generated at 2022-06-21 10:03:47.500211
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    doc = '''
from typing import Union, Optional

a: Union[int, str]
b: Optional[str]
    '''
    assert Resolver("", dict()).visit(parse(doc)) == parse("""
from typing import Union, Optional

a: Union[int, str]
b: Union[str, None]
    """)

    assert Resolver("", dict()).visit(parse("""
import typing
a: typing.Union[int, str]
b: typing.Optional[str]
    """)).body[2:] == parse("""
a: Union[int, str]
b: Union[str, None]
    """)



# Generated at 2022-06-21 10:03:53.375029
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    r = Resolver("test", {})
    assert(r.visit(Constant("test")) == Name("test", Load()))
    assert(r.visit(Constant("test.test")) == Name("test.test", Load()))
    assert(r.visit(Constant("test.test.test")) ==
           Attribute(Name("test.test", Load()), "test", Load()))
    assert(r.visit(Constant("int")) == Name("int", Load()))
    assert(r.visit(Constant("Union")) == Name("Union", Load()))
    assert(r.visit(Constant("Union[int, str]")) == Constant("Union[int, str]"))
    assert(r.visit(Constant("int or str")) == Constant("int or str"))

# Generated at 2022-06-21 10:03:56.395976
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert Resolver('test', dict()).visit_Attribute(
        parse('typing.Dict').body[0].value
    ).id == 'Dict'



# Generated at 2022-06-21 10:04:00.418734
# Unit test for function code
def test_code():
    assert code('a') == '`a`'
    assert code('a|b') == '`a&#124;b`'
    assert code('a&b') == '<code>a&amp;b</code>'
    assert code('') == ' '



# Generated at 2022-06-21 10:04:09.297499
# Unit test for method globals of class Parser
def test_Parser_globals():
    import ast
    import doctest
    import sys
    import unittest
    import importlib
    import pathlib
    import typing_extensions


    class Visitor(ast.NodeVisitor):

        def __init__(s):
            s.root = []
            s.alias = {}

        def visit_Call(s, node):
            s.root.append(s.alias[node.func.id])


    ns = {}
    c = """\
        import typing_extensions
        def f(): pass
        """
    t = ast.parse(c)
    p = Parser(t, link=False)
    _m = namespace_map(t)
    ns['p'] = p
    ns['_m'] = _m
    ns['Visitor'] = Visitor


# Generated at 2022-06-21 10:04:15.393499
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('a')
    assert not is_public_family('a._b')
    assert not is_public_family('_a')
    assert not is_public_family('_a._b')
    assert is_public_family('a.__b__')
    assert is_public_family('__a__.b')



# Generated at 2022-06-21 10:04:26.195025
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    data = """from typing import Union
typing.Union[int, Union[bool, str, int]]
typing.Optional[typing.Union[str, float]]
typing.Tuple[int, ...]
typing.List[int]
typing.Set[int]
typing.Dict[str, float]
typing.Optional[int]
typing.Optional[typing.Union[int, None]]
typing.Optional[typing.Optional[int]]
typing.List[typing.Optional[typing.Union[int, None]]]
"""
    tree = parse(data)
    new_tree = Resolver("test", {}).visit(tree)
    assert unparse(new_tree).strip() == data.strip()



# Generated at 2022-06-21 10:04:39.352906
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    import doctest

# Generated at 2022-06-21 10:06:07.978746
# Unit test for function doctest
def test_doctest():
    s = """
    >>> a = 40 + 2
    >>> a
    42
    """
    assert doctest(s) == "\n".join((
        "```python",
        ">>> a = 40 + 2",
        ">>> a",
        "42",
        "```",
    ))
    assert doctest("") == ""
    s = """
    >>> print("hello world")
    hello world
    >>> b = 2
    >>> b + 1
    3
    """
    assert doctest(s) == "\n".join((
        "```python",
        ">>> print(\"hello world\")",
        "hello world",
        ">>> b = 2",
        ">>> b + 1",
        "3",
        "```",
    ))



# Generated at 2022-06-21 10:06:13.193759
# Unit test for function doctest
def test_doctest():
    test_doc = '''
    >>> a = 1
    >>> a == 1
    True
    >>> b = False
    >>> b
    False
    '''
    # Remove the blank lines to compare doctest with string.
    test_result = '''
```python
>>> a = 1
>>> a == 1
True
>>> b = False
>>> b
False
```
'''
    assert doctest(test_doc) == test_result
    assert doctest(test_doc + '\n') == test_result
    assert doctest(test_doc[1:]) == test_result[1:]


# Generated at 2022-06-21 10:06:25.146409
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    assert p.parse('', 'a = 1') == 'const a: int = ...'
    assert p.parse('', 'a: int = ...') == 'const a: int = ...'
    assert p.parse('', 'a: int = 1') == 'const a: int = 1'
    assert p.parse('', 'a: int') == 'const a: int = ...'
    assert p.parse('', 'def a() -> None: ...') == \
        'def a() -> None:\n    ...'
    assert p.parse('', 'class A(object):\n    b: int = 1') == \
        'class A:\n    b: int = 1'
    assert p.parse('', 'from typing import List\nList') == 'List'

# Generated at 2022-06-21 10:06:37.565606
# Unit test for method globals of class Parser
def test_Parser_globals():
    from inspect import Signature, Parameter
    from types import ModuleType
    from typing import cast

    def test(m: ModuleType, name: str, annotation: Optional[str],
             *, const: Optional[str] = None):
        node = cast(Assign, getattr(m, name))
        with freeze_time("1999-12-31 23:59:59"):
            p = Parser()
            p.globals("", node)
        assert p.alias[name] == "=".join(list(map(str, node.value.elts)))
        assert p.root[name] == ""
        if const is not None:
            assert p.const[name] == const
        else:
            assert name not in p.const

# Generated at 2022-06-21 10:06:46.405852
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from .test import test_parser
    from .main import get_ast
    from .resolver import Resolver

    p = Parser()
    test_parser(p)
    doc = p.compile()
    assert doc == ""
    p.load_docstring('test.parser', get_ast(__file__, Resolver))
    doc = p.compile()
    assert doc.startswith('## Parser()')
    assert 'Documentation will be inserted here' in doc

# Generated at 2022-06-21 10:06:56.132710
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    """
    >>> from typing import Optional, Union
    >>> code = parse('@a\\ndef f(a: int, b: Optional[float]) -> Union[int, float]: ...')
    >>> name, value = code.body[0].targets[0].id, code.body[0].value
    >>> Resolver(__name__, {}).visit_Attribute(value.args[1].annotation)
    Name(id='Optional', ctx=Load())
    """
    pass

    def visit_arg(self, node: arg) -> arg:
        """Visit argument."""
        node.annotation = self.visit(node.annotation)
        return node



# Generated at 2022-06-21 10:07:05.403147
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    def t(expected: str, *args, **kwargs):
        result = Parser.func_ann(None, args, **kwargs).__next__()
        assert result == expected, f'{result!r} != {expected!r}'
    t('Self', arg('self', None))
    t('type[Self]', arg('self', None), has_self=False, cls_method=True)
    t('str', arg('a: str', None), arg('self', None))
    return 'ok'

print(test_Parser_func_ann())


# Generated at 2022-06-21 10:07:11.248486
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    root = 'stats_arrays'
    file = Path(__file__)
    path = file.parent / '..' / 'stats_arrays' / 'special.py'
    p = Parser()
    p.run([f"-m{root}", str(path)])
    r = eval(repr(p))
    assert r == p
    root = 'stats_arrays.special'
    p = Parser()
    p.run([f"-m{root}", '-', 'def __call__(self, x): ...'])
    r = eval(repr(p))
    assert r == p



# Generated at 2022-06-21 10:07:20.352269
# Unit test for function table
def test_table():
    table_title, table_args = ['a', 'b'], [['c', 'd'], ['e', 'f']]
    table_str = table(*table_title, items=table_args)
    assert table_str.count('|') == 9
    assert table_str.startswith('|') and table_str.endswith('|\n\n')
    assert table_title[0] in table_str
    assert table_title[1] in table_str
    for args in table_args:
        assert table_args[0][0] in table_str
        assert table_args[0][1] in table_str



# Generated at 2022-06-21 10:07:23.808449
# Unit test for function parent
def test_parent():
    assert "Foo" == parent("Foo.bar")
    assert "Foo.bar" == parent("Foo.bar.baz", level=2)
    assert "" == parent("Foo", level=3)

