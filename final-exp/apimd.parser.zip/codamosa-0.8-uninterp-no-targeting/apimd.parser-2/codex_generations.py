

# Generated at 2022-06-21 10:03:24.567234
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__builtin__')
    assert not is_magic('__test')
    assert is_magic('__test__')

# Generated at 2022-06-21 10:03:28.188142
# Unit test for constructor of class Resolver
def test_Resolver():
    """Unit test for constructor of class Resolver."""
    assert Resolver.__name__ == 'Resolver'
    assert Resolver.__doc__
    assert Resolver.__module__ == __name__



# Generated at 2022-06-21 10:03:36.684647
# Unit test for function is_public_family
def test_is_public_family():
    logger.info(is_public_family('_'))
    logger.info(is_public_family('_.'))
    logger.info(is_public_family('_a'))
    logger.info(is_public_family('_abc'))
    logger.info(is_public_family('_abc.b'))
    logger.info(is_public_family('.a'))
    logger.info(is_public_family('a'))
    logger.info(is_public_family('a.b'))
    logger.info(is_public_family('a.__b'))
    logger.info(is_public_family('a.b.__c'))
    logger.info(is_public_family('a.b.c__'))

# Generated at 2022-06-21 10:03:42.862252
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    # root = 'a'
    # alias = {'a.b': 'None'}
    # self_ty = 'self'
    # node = ast.parse('typing.Bool').body[0]
    # resolver = Resolver(root, alias, self_ty)
    # resolver.visit_Attribute(node)
    assert True


# Generated at 2022-06-21 10:03:50.494774
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    from . import name_func_api_case
    from . import name_func_api_expected
    import shutil
    from pathlib import Path
    from . import name_func_api_mod
    mod = name_func_api_mod()
    gen = Parser([str(mod)])
    gen.load_docstring(str(mod), mod)
    res = gen.docstring[str(mod) + '.name_func_api'].strip()
    exp = name_func_api_expected()
    if res != exp:
        datadir = Path('data')
        if not datadir.exists():
            datadir.mkdir()

# Generated at 2022-06-21 10:03:53.692600
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert(Resolver("", {}).visit_Attribute(Attribute(Name("typing", Load()), "List", Load())))



# Generated at 2022-06-21 10:03:57.655017
# Unit test for function code
def test_code():
    assert code('|') == '<code>&#124;</code>'
    assert code('&') == '<code>&amp;</code>'
    assert code('*') == '<code>*</code>'
    assert code('') == ' '



# Generated at 2022-06-21 10:04:00.277977
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert Resolver("", {}).visit(parse("typing.List").body[0]).body[0].value == "List"


# Generated at 2022-06-21 10:04:01.430259
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    assert Parser(False).is_public("great.guild.is_public")

# Generated at 2022-06-21 10:04:09.119794
# Unit test for constructor of class Parser
def test_Parser():
    """Test constructor of class Parser."""
    logger.info('Test Parser ...')
    import test_block
    p = Parser()
    p.parse(test_block)
    for a in p.alias:
        print(a, p.alias[a])
    for d in p.doc:
        print(d, p.doc[d])
    for d in p.docstring:
        print(d, p.docstring[d])
    for c in p.const:
        print(c, p.const[c])
    for i in p.imp:
        print(i, p.imp[i])


# Generated at 2022-06-21 10:05:11.138956
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    testcases = [
        ("typing.Optional[self.type]", "Optional[self.type]"),
        ("typing.typing.List[int]", "List[int]"),
        ("typing.__all__[0]", "__all__[0]")
    ]
    for src, dst in testcases:
        assert unparse(Resolver('self.module', {'typing.Optional': 'Optional'}).visit(parse(src).body[0])).strip() == dst



# Generated at 2022-06-21 10:05:22.742649
# Unit test for function const_type
def test_const_type():
    assert const_type(Constant(value=True)) == "bool"
    assert const_type(Constant(value=0)) == "int"
    assert const_type(Constant(value=0.0)) == "float"
    assert const_type(Constant(value=0j)) == "complex"
    assert const_type(Constant(value="")) == "str"
    assert const_type(Constant(value=Exception())) == "Exception"
    assert const_type(List(elts=[Constant(value=0)])) == "list[int]"
    assert const_type(List(elts=[Constant(value=0), Constant(value="")])) == ANY

# Generated at 2022-06-21 10:05:28.678403
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert parse("x: str").body[0].type.value.id == 'str'
    assert parse("x: typing.str").body[0].type.value.attr == 'str'
    assert parse("x: typing.Union[int, str]").body[0].type.value.value.func.id == 'Union'



# Generated at 2022-06-21 10:05:36.800938
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    o = Parser(toc=True)
    o.doc['m1'] = ''
    o.doc['m2.__doc__'] = ''
    assert o.load_docstring('m1', None) == None
    assert o.load_docstring('m2', None) == None
    assert o.load_docstring('_', None) == None
    def __doc__(): ...
    o.load_docstring('m1', __doc__)
    assert o.doc['m1'] != ''
    assert o.doc['m2.__doc__'] != ''
    del __doc__

# Generated at 2022-06-21 10:05:40.344587
# Unit test for function code
def test_code():
    assert code("x") == "`x`"
    assert code("x|y") == "`x&#124;y`"
    assert code("x&y") == "<code>x&y</code>"
    assert code("") == " "

# Generated at 2022-06-21 10:05:50.281906
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    my_parser = Parser(auxi.Module('test_samples/test_is_public'))
    my_parser.parse_module()
    assert my_parser.is_public('test_samples.test_is_public.Class1')
    assert my_parser.is_public('test_samples.test_is_public.Class1.__init__')
    assert my_parser.is_public('test_samples.test_is_public.Class1.method1')
    assert my_parser.is_public('test_samples.test_is_public.Class1.method2')
    assert my_parser.is_public('test_samples.test_is_public.Class1.method3')

# Generated at 2022-06-21 10:05:54.332080
# Unit test for function is_magic
def test_is_magic():
    assert not is_magic('asdf')
    assert not is_magic('asdf__')
    assert not is_magic('__asdf')
    assert not is_magic('__asd__f')
    assert not is_magic('asdf__asdf__')
    assert is_magic('__asdf__')
    assert is_magic('__asdf')
    assert is_magic('__')

# Generated at 2022-06-21 10:05:55.627554
# Unit test for method globals of class Parser
def test_Parser_globals():
    p = Parser(...)
    assert p.globals(...) == ...

# Generated at 2022-06-21 10:06:02.460066
# Unit test for function table
def test_table():
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == \
        '| a | b |\n|:---:|:---:|\n| c | d |\n| e | f |\n\n'



# Generated at 2022-06-21 10:06:09.026412
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    import ast
    import typing
    t = typing.List[int]
    n = ast.parse(str(t))
    assert isinstance(n.body[0].value, ast.Call)
    n = Resolver('test_Resolver_visit_Constant', {'typing.List': 'list'}).visit(n)
    assert n.body[0].value == ast.List(elts=[ast.Constant(None, kind=None)], ctx=ast.Load())


# Generated at 2022-06-21 10:07:48.032471
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__name__')
    assert is_magic('__init__')
    assert not is_magic('__version__')
    assert not is_magic('__add__')
    assert not is_magic('name')



# Generated at 2022-06-21 10:07:59.229839
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    doc = Parser()
    args = arguments(args=[arg(arg='x', annotation=Name(id='int', ctx=None))],
                     vararg=arg(arg='*xyz', annotation=Name(id='str', ctx=None)),
                     kwonlyargs=[arg(arg='y',
                                     annotation=Name(id='float', ctx=None))],
                     kwarg=arg(arg='**abc', annotation=Name(id='float', ctx=None)))
    doc.imp['.'] = set()
    doc.func_api('.', '.', args, None, has_self=False, cls_method=False)

# Generated at 2022-06-21 10:08:01.776246
# Unit test for function parent
def test_parent(): assert parent('a.b.c.d', level=2) == 'a.b'



# Generated at 2022-06-21 10:08:04.814635
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    import doctest
    parser = Parser(ignore=None, link=None)
    parser.b_level = None
    parser.alias = {}
    parser.doc = {}
    parser.docstring = None
    parser.level = {}
    parser.root = {}
    parser.const = {}
    parser.imp = {}
    node = None
    result = parser.resolve('', node)
    assert result == 'None'

# Generated at 2022-06-21 10:08:11.000290
# Unit test for method globals of class Parser
def test_Parser_globals():
    b = block()
    b.append(
        AnnAssign(
            target=Name(id='__dr__', ctx=Store()),
            annotation=Name(id='draco.flags', ctx=Load()),
            value=Constant(value='__version__', kind=None),
            simple=1))
    b.append(
        AnnAssign(
            target=Name(id='__title__', ctx=Store()),
            annotation=Name(id='str', ctx=Load()),
            value=Constant(value='"Test"', kind=None),
            simple=1))

# Generated at 2022-06-21 10:08:21.578982
# Unit test for function const_type
def test_const_type():
    assert const_type(parse('''1''').body[0]) == 'int'
    assert const_type(parse('''[1]''').body[0]) == 'List[int]'
    assert const_type(parse('''[True]''').body[0]) == 'List[bool]'
    assert const_type(parse('''[True, float]''').body[0]) == 'List[Any]'
    assert const_type(parse('''{1: 2}''').body[0]) == 'dict[int, int]'
    assert const_type(parse('''{1: True}''').body[0]) == 'dict[int, bool]'
    assert const_type(parse('''{1: True, 2: False}''').body[0]) == 'dict[int, Any]'
    assert const

# Generated at 2022-06-21 10:08:28.465061
# Unit test for method imports of class Parser
def test_Parser_imports():
    from . import ast as ast_mod
    from . import _parser as _parser_mod
    from . import tag as tag_mod
    from . import _symbol as _symbol_mod
    from . import _util as _util_mod
    from . import _alias as _alias_mod
    from . import _docstring as _docstring_mod
    from ._alias import Replacement
    root = _alias_mod.Name('__main__', 1)
    alias = _alias_mod.AliasMap()
    alias[root] = _alias_mod.Name('_mod', 1)
    alias[_util_mod.m(root, 'a')] = _alias_mod.Literal('1', 1)
    alias[_util_mod.m(root, 'b')] = _alias_mod.Literal('2', 1)


# Generated at 2022-06-21 10:08:33.078479
# Unit test for function code
def test_code():
    assert code("abc") == r"`abc`"
    assert code("a|bc") == r"`a&#124;bc`"
    assert code("a&bc") == r"<code>a&bc</code>"
    assert code("") == " "

