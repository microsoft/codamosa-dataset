

# Generated at 2022-06-21 10:03:37.561433
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    from .__about__ import __version__
    assert unparse(Resolver(*__version__.partition('-')).visit_Constant(Constant('__version__'))).strip() == '"__version__"'
    assert unparse(Resolver(*__version__.partition('-')).visit_Constant(Constant('__version__[:-9]'))).strip() == '"__version__[:-9]"'
    assert unparse(Resolver(*__version__.partition('-')).visit_Constant(Constant('__version__[:-9].split(".dev")[0] + ".dev"'))).strip() == '"__version__[:-9].split(\\".dev\\")[0] + \\"dev\\""'


# Generated at 2022-06-21 10:03:46.886759
# Unit test for method imports of class Parser
def test_Parser_imports():
    import unittest
    import asttokens
    from asttokens import asttokens
    from ._test_utils import Module
    object: object
    module = asttokens.ASTTokens(Module(), parse=True)
    p = Parser(module)
    node = module.module.body[0]
    p.imports('', node)
    assert p.alias == {'asttokens': 'asttokens', 'asttokens.ASTTokens': 'ASTTokens', 'unittest.TestCase': 'TestCase', 'Module': 'Module', 'asttokens.Module': 'asttokens.Module', 'object': 'object'}

# Generated at 2022-06-21 10:03:49.244493
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__init__')
    assert is_magic('__abc__')
    assert not is_magic('abc')
    assert not is_magic('abc__')
    assert not is_magic('__abc')



# Generated at 2022-06-21 10:03:51.500341
# Unit test for method compile of class Parser
def test_Parser_compile():
    from . import _test_doc
    from .parser import Parser

    parser = Parser()
    for root, name, m in _test_doc():
        parser.parse(root, name, m)
    return parser.compile().strip()


# Generated at 2022-06-21 10:03:52.190172
# Unit test for method globals of class Parser
def test_Parser_globals():
    assert True

# Generated at 2022-06-21 10:03:55.702117
# Unit test for function doctest
def test_doctest():
    """
    >>> doctest("hello")
    'hello'
    """
    assert doctest(getdoc(test_doctest)) == """
    >>> doctest("hello")
    'hello'
    """


# Generated at 2022-06-21 10:04:01.835099
# Unit test for function doctest
def test_doctest():
    r"""
    >>> doctest(r'')
    ''
    >>> doctest(r'>>> test')
    '```python\n>>> test\n```'
    >>> doctest(r'>>> test\n>>> test')
    '```python\n>>> test\n>>> test\n```'
    >>> doctest(r'help(test)\n>>> test')
    'help(test)\n```python\n>>> test\n```'
    >>> doctest(r'>>> test\nhelp(test)')
    '```python\n>>> test\n```\nhelp(test)'
    >>> doctest(r'>>> test\nhelp(test)\n')
    '```python\n>>> test\n```\nhelp(test)\n'
    """



# Generated at 2022-06-21 10:04:09.460793
# Unit test for function walk_body
def test_walk_body():
    t = parse("""
    a = 1
    if True:
        b = 2
        if True:
            c = 3
    else:
        d = 4
    try:
        e = 5
    except:
        f = 6
    finally:
        g = 7
    """)
    name = t.body[-1]
    assert isinstance(name, FunctionDef)
    assert name.name == 'test_walk_body'

# Generated at 2022-06-21 10:04:11.571371
# Unit test for function doctest
def test_doctest():
    assert '```' in doctest("""
>>> print("Hello World")
Hello World
""")



# Generated at 2022-06-21 10:04:24.310723
# Unit test for constructor of class Resolver

# Generated at 2022-06-21 10:06:53.848880
# Unit test for method visit_Name of class Resolver

# Generated at 2022-06-21 10:07:00.619900
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    a = Resolver('a', {})
    assert isinstance(a.visit_Constant(Constant(4)), Constant)
    e = a.visit_Constant(Constant('b.c'))
    assert isinstance(e, Name)
    assert e.id == 'c'


# Generated at 2022-06-21 10:07:04.086258
# Unit test for function code
def test_code():
    assert code('foo') == '`foo`'
    assert code('foo|bar') == '`foo&#124;bar`'
    assert code('foo&bar') == '<code>foo&bar</code>'



# Generated at 2022-06-21 10:07:12.350315
# Unit test for function is_public_family
def test_is_public_family():
    assert not is_public_family('_Test')
    assert not is_public_family('Test._test')
    assert not is_public_family('os._test')
    assert not is_public_family('test_test')
    assert is_public_family('Test')
    assert is_public_family('test')
    assert is_public_family('Test.test')
    assert is_public_family('os.test')
    assert is_public_family('Test.__test__')
    assert is_public_family('os.__test__')
    assert is_public_family('_Test.test')
    assert is_public_family('_Test._Test.test')
    assert is_public_family('_Test._test')



# Generated at 2022-06-21 10:07:23.763873
# Unit test for method globals of class Parser
def test_Parser_globals():
    root = 'some.root'
    alias = {}
    parser = Parser(root, alias)
    root = 'some.root'
    node = Assign(
        targets=[Name(id='__all__', ctx=Store())],
        value=List(elts=[Constant(value=i, kind=None) for i in range(20)])
    )
    parser.globals(root, node)

# Generated at 2022-06-21 10:07:24.976418
# Unit test for method imports of class Parser
def test_Parser_imports():
    pass

# Generated at 2022-06-21 10:07:33.954596
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from _ast import parse
    from textwrap import dedent
    from os import path
    from types import ModuleType
    from importlib.machinery import SourceFileLoader
    m = SourceFileLoader('helpers', path.join(
        path.dirname(path.abspath(__file__)), "helpers.py")).load_module()

# Generated at 2022-06-21 10:07:46.264824
# Unit test for constructor of class Resolver
def test_Resolver():
    @dataclass
    class M:
        alias: dict[str, str]
        root_name: str
        self_ty: str


# Generated at 2022-06-21 10:07:53.271752
# Unit test for method globals of class Parser
def test_Parser_globals():
    assert const_type(Constant(1, kind=None)) == '1'
    assert const_type(NameConstant(True, kind=None)) == 'bool'
    assert const_type(Constant(None, kind=None)) == 'None'
    assert const_type(Tuple(())) == '()'
    assert const_type(Tuple((Constant(1, kind=None),))) == '(1)'
    assert const_type(List(())) == '[]'
    assert const_type(List((Constant(1, kind=None),))) == '[1]'
    assert const_type(Set(())) == '{}'
    assert const_type(Set((Constant(1, kind=None),))) == '{1}'
    assert const_type(Dict(())) == '{}'

# Generated at 2022-06-21 10:07:59.271978
# Unit test for function walk_body
def test_walk_body():
    tree = parse("""
if 1:
    a = 1
    if 2:
        b = 2
        if 3:
            c = 3

if 4:
    d = 4

if 5:
    e = 5
""")
    assert ''.join(unparse(n) for n in walk_body(tree.body)) == (
        "a = 1\nb = 2\nc = 3\nd = 4\ne = 5\n"
    )
