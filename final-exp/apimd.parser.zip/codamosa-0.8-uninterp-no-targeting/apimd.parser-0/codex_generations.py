

# Generated at 2022-06-21 10:04:03.535166
# Unit test for function walk_body
def test_walk_body():
    @dataclass
    class Node:
        lines: str

    @dataclass
    class NodeArgs:
        args: Sequence[arg]


# Generated at 2022-06-21 10:04:15.142675
# Unit test for constructor of class Parser
def test_Parser():
    with open('test.py') as f:
        p = Parser(f)
    assert p.imp['m'] == {'A'}
    assert p.imp['m.x'] == {'B', 'C', 'D'}
    # print(p.alias)
    assert p.alias['m.predefined'] == 'int'
    assert p.alias['m.X.CONST'] == '1'
    # print(p.doc)
    assert p.doc['m.A'].startswith('## A()')
    assert p.doc['m.x.C'].startswith('### class C')
    assert p.doc['m.x.C.D.__init__'].startswith('#### __init__(self')
    # print(p.docstring)
    assert p.doc

# Generated at 2022-06-21 10:04:26.407827
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    # 1.
    _imp = {}
    const = {}
    res = Parser(imp=_imp, const=const)
    res.root["a"] = "a"
    assert res.is_public("a") is True
    # 2.
    res.imp["b"] = set()
    res.root["b"] = "b"
    assert res.is_public("b") is True
    # 3.
    res.imp["b"] = {"c"}
    res.root["c"] = "c"
    assert res.is_public("c") is False
    # 4.
    res.imp["b"] = {"b.c"}
    res.root["b.c"] = "b.c"
    assert res.is_public("b.c") is True
    # 5.
    res.imp

# Generated at 2022-06-21 10:04:39.397091
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    """Test for method func_ann of class Parser."""
    from types import MappingProxyType
    from inspect import Signature
    from typing import get_type_hints
    from .printer import SemaPrinter

    def merge_signature(s: Signature, s2: Signature) -> Signature:
        return Signature(parameters=tuple(s.parameters.values()) +
                         tuple(s2.parameters.values()))

    def get_args(sig: Signature) -> Sequence[arg]:

        def get_arg(param: Parameter) -> arg:
            return arg(param.name, get_type_hints(param.annotation)['return'])

        self_ty = ""
        args: Sequence[arg] = []

# Generated at 2022-06-21 10:04:50.261433
# Unit test for function const_type
def test_const_type():
    assert const_type(Constant(True)) == 'bool'
    assert const_type(Constant(1)) == 'int'
    assert const_type(Constant(1.0)) == 'float'
    assert const_type(Constant(complex(1.0))) == 'complex'
    assert const_type(Constant("")) == 'str'
    assert const_type(Tuple([])) == 'tuple[]'
    assert const_type(Tuple([Constant(1)])) == 'tuple[int]'
    assert const_type(Tuple([Constant(1), Constant(2.0), Constant("")])) == 'tuple[Any]'
    assert const_type(List([Constant(1), Constant(2.0), Constant("")])) == 'list[Any]'

# Generated at 2022-06-21 10:04:58.980941
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from importlib import import_module
    import os
    import tempfile
    for name in ('datetime', 'enum', 'functools', 'math', 'operator',
                 'random', 're', 'string', 'threading', 'time', 'weakref'):
        m = import_module(name)
        if name == 'datetime' or name == 'math':
            continue
        src = Path(m.__file__).parent / f'{name}.py'
        if not src.exists():
            continue
        p = Parser(src, doc_link='')
        p.load_docstring(name, m)



# Generated at 2022-06-21 10:05:10.632008
# Unit test for method imports of class Parser
def test_Parser_imports():
    from ast_toolbox import ast, parse, copy_node
    from ast_toolbox import Module, WildImport, AsName, Name, Import

    m = parse("from foo import *")
    p = Parser(helpers=[])

    p.imports("", m)
    assert p.alias == {"" : "foo"}

    m = parse("from foo import bar as xyz")
    p = Parser(helpers=[])

    p.imports("", m)
    assert p.alias == {"xyz" : "bar"}

    m = parse("import foo.bar")
    p = Parser(helpers=[])

    p.imports("", m)
    assert p.alias == {"" : "foo.bar"}

    m = parse("import foo.bar as xyz")

# Generated at 2022-06-21 10:05:11.995570
# Unit test for function walk_body

# Generated at 2022-06-21 10:05:23.227882
# Unit test for method parse of class Parser
def test_Parser_parse():
    class TestParser(Parser):
        __slots__ = ()
        doc: Dict[str, str]
        __alias: Dict[str, str]
    t = TestParser()

# Generated at 2022-06-21 10:05:26.629861
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    _ast = Attribute(Name('typing', Load()), 'List', Load())
    assert Resolver('', {}).visit(_ast) == Name('List', Load())



# Generated at 2022-06-21 10:06:35.276276
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    """Tests for method load_docstring of class Parser"""
    tmp = 'def func():\n    """docstring"""\nclass cls:\n    pass\n'
    m = ModuleType('m', tmp)

    p = Parser()
    assert p.docstring == {}
    p.load_docstring('m', m)
    assert p.docstring == {'m.func': 'docstring'}

# Generated at 2022-06-21 10:06:45.641514
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    classes = ['A', 'B']
    constants = [1, 2]
    methods = ['__init__', '__repr__']
    attributes = ['x', 'y']
    parser = Parser()
    parser.doc['tests.classes'] = '\n'
    parser.docstring['tests.classes'] = '\n'
    parser.doc['tests.classes.A'] = '\n'
    parser.docstring['tests.classes.A'] = '\n'
    parser.doc['tests.classes.A.__init__'] = '\n'
    parser.docstring['tests.classes.A.__init__'] = '\n'
    parser.doc['tests.classes.A.__repr__'] = '\n'
    parser.docstring['tests.classes.A.__repr__']

# Generated at 2022-06-21 10:06:58.262460
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    """Test method func_ann of class Parser."""
    from typing import List

    from ast import Name, Load, Call, copy_location, parse, dump, Expr
    from ast import arguments, arg, FunctionDef, AnnAssign, type_comment

    from mypy.nodes import ARG_POS, ARG_OPT, ARG_STAR, ARG_STAR2
    from mypy.nodes import ARG_NAMED, ARG_NAMED_OPT
    from mypy.types import Type, Instance, AnyType, TypeOfAny, TypeVisitor
    from mypy.types import CallableType, TupleType, NoneTyp, UnboundType
    from mypy.types import Overloaded, UnionType, TypeVarType, TypeList

    from mypy.plugin import Callable

# Generated at 2022-06-21 10:07:08.249792
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    import ast
    from typing import Union

    class Resolver:
        def __init__(self, root, alias, self_ty):
            self.root = root
            self.alias = alias
            self.self_ty = self_ty
        def visit(self, node):
            return node
    def parse(ann):
        return ast.parse(ann, mode='eval')
    def visit(node):
        return node
    d = Parser()
    d.alias['x'] = ''
    d.alias['y'] = ''
    d.alias['Enum'] = ''
    d.root['x'] = 'x'
    d.root['y'] = 'y'
    d.root['Enum'] = 'enum'
    d.__names_cmp = None
    d.__get_const = None
    d

# Generated at 2022-06-21 10:07:10.887186
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    e = parse("typing.int").body[0]
    r = Resolver("module", {})
    assert isinstance(r.visit(e), Name)


# Generated at 2022-06-21 10:07:20.306657
# Unit test for function walk_body
def test_walk_body():
    """Test case for `walk_body`."""
    b = parse('''
a = 1
if 1:
    if 2:
        a = a + 1
    else:
        a = a + 3
try:
    a = a + 4
except:
    a = a + 5
finally:
    a = a + 6
a = a + 7
    ''').body
    assert [code(unparse(i)) for i in walk_body(b)] == [
        "a = 1", "a = a + 1", "a = a + 4", "a = a + 5", "a = a + 6", "a = a + 7"
    ]



# Generated at 2022-06-21 10:07:25.055436
# Unit test for function table
def test_table():
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == \
        '| a | b |\n|:---:|:---:|\n| c | d |\n| e | f |\n\n'



# Generated at 2022-06-21 10:07:27.764137
# Unit test for function table
def test_table():
    """Create table to check the result."""
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == \
        "| a | b |\n|:---:|:---:|\n| c | d |\n| e | f |\n\n"
    return table



# Generated at 2022-06-21 10:07:33.497828
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    r = Resolver('__main__', {})
    with open(__file__) as f:
        body = f.read()
    doc = cast(str, getdoc(r.visit_Constant))
    e = cast(Expr, parse(doc).body[0])
    assert body.count(doc) == 1
    assert code(doc) in body
    assert code(unparse(e.value)) == code(unparse(r.visit_Constant(e.value)))



# Generated at 2022-06-21 10:07:45.690674
# Unit test for function walk_body