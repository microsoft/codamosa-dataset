

# Generated at 2022-06-23 15:30:12.214845
# Unit test for method imports of class Parser
def test_Parser_imports():
    import pytest
    from importlib import import_module, reload
    from os import listdir
    from os.path import splitext
    from unittest import TestCase
    from unittest.mock import MagicMock
    from typing import Union
    from collections import UserDict

    test_dir = 'test_unit'
    test_data = {
        splitext(f)[0]: import_module(f'.{splitext(f)[0]}', test_dir)
        for f in listdir(test_dir) if f.endswith('.py')
    }
    config = MagicMock(spec=UserDict)
    config.__getitem__.side_effect = lambda k: getattr(
        import_module('docblock.config'), f'{k.upper()}_DEFAULT')

   

# Generated at 2022-06-23 15:30:19.868825
# Unit test for function doctest
def test_doctest():
    doc = """
    >>> def f(x):
    ...     return x + 1
    >>> f(1)
    2
    """
    assert doctest(doc) == """
```python
>>> def f(x):
...     return x + 1
>>> f(1)
2
```
    """.lstrip()
    doc = """
    >>> def f(x):
    ...     return x + 1
    >>> f(1)
    2
    >>>
    >>> import numpy as np
    >>> np.zeros(3, dtype=int)
    array([0, 0, 0])
    """

# Generated at 2022-06-23 15:30:29.641386
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    p = Parser(None)
    p.alias = {'a': 'c', 'c.b': 'd.e'}
    p.root = {'a': 'a', 'c.b': 'c'}
    assert p.resolve('a', parse.expr("_a")) == '_a'
    assert p.resolve('a', parse.expr("a")) == 'c'
    assert p.resolve('b', parse.expr("_a")) == '_a'
    assert p.resolve('b', parse.expr("a")) == 'a'
    assert p.resolve('c', parse.expr("_b")) == '_b'
    assert p.resolve('c', parse.expr("b")) == 'd.e'

# Generated at 2022-06-23 15:30:39.128009
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    r = Parser()
    r.level['test_module'] = 0
    r.root['test_module'] = 'test_module'
    r.func_api('test_module', 'test_module.f', arguments(
        [arg('a', Name("A", Load())), arg('b', Name("B", Load())), arg("c", None)],
        [None, None, Name("B", Load())],
        None,
        [arg("d", Name("D", Load())), arg("e", Name("E", Load()))],
        [Name("D", Load()), Name("E", Load())],
        None,
        None
    ), None, has_self=False, cls_method=False)

# Generated at 2022-06-23 15:30:49.289283
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    import subprocess
    import ast
    from typing import Optional
    from .utils import get_ditaa, code
    from .exceptions import DitaaError
    from .parser import Parser, __name__ as package_name
    if not get_ditaa():
        logger.warning("Skipping ditaa tests")
        return
    s = """
    def foo(a: int, b: str = 'str', *xs: float, c: bool = False,
            **kwargs: dict) -> None:
        pass
    """
    p = Parser()
    p.parse(s, [])
    assert p.toc is False
    assert not p.indent
    assert p.alias == {}
    assert p.const == {}
    assert p.docstring == {}

# Generated at 2022-06-23 15:30:56.164172
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    p = Parser(link=True, toc=True, b_level=1)
    # === pyclbr_Parser ===
    assert p == Parser(link=True, toc=True, b_level=1)
    assert p != Parser(link=False, toc=True, b_level=1)
    assert p != Parser(link=True, toc=False, b_level=1)
    assert p != Parser(link=True, toc=True, b_level=2)
    # === pyclbr_MockFile ===
    assert p != MockFile(link=True, toc=True, b_level=1)

# Generated at 2022-06-23 15:31:02.807911
# Unit test for function table
def test_table():
    """Test function table."""
    assert '| a | b |' in table('a', 'b', [['c', 'd'], ['e', 'f']])
    assert '| c | d |' in table('a', 'b', [['c', 'd'], ['e', 'f']])
    assert '| e | f |' in table('a', 'b', [['c', 'd'], ['e', 'f']])



# Generated at 2022-06-23 15:31:09.264273
# Unit test for method imports of class Parser
def test_Parser_imports():
    from shutil import copytree, Error, rmtree
    from os import listdir, getcwd
    from tempfile import mkdtemp
    from py_docstring.test_file import test_file
    # Write the test file and import
    base = mkdtemp('', 'test-')
    # Create a folder
    def mkdir(dir: list[str]) -> None:
        """Creates a hierarchical directory structure."""
        for d in dir:
            if not d:
                continue
            try:
                mkdir(dir[1:])
                copytree(getcwd() + '/package', base + '/' + '/'.join(dir))
                break
            except Error:
                pass
    mkdir(['foo', 'bar', 'baz'])
    # Create files

# Generated at 2022-06-23 15:31:12.462849
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    node = Constant("float", None, None)
    res = Resolver("", {}).visit_Constant(node)
    assert res == node


# Generated at 2022-06-23 15:31:18.779931
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    import astor
    p = Parser()
    m = Module(
        body=[
            Assign(
                targets=[Name(id='X', ctx=Store())],
                value=Constant(value='abc', kind=None)
            ),
            AnnAssign(
                target=Name(id='Y', ctx=Store()),
                annotation=Name(id='int', ctx=Load()),
                value=Constant(value=1, kind=None)
            ),
            AnnAssign(
                target=Name(id='Z', ctx=Store()),
                annotation=Str(s='type[Z]', kind=None),
                value=Constant(value=1, kind=None)
            )
        ]
    )
    p.imports('', m)

# Generated at 2022-06-23 15:31:19.752968
# Unit test for method func_api of class Parser

# Generated at 2022-06-23 15:31:21.303084
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Test for function parse is True
    assert Parser.parse(__file__, {})  # False

# Generated at 2022-06-23 15:31:32.903012
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    p = Parser()
    p.alias[''] = ''
    p.alias['list'] = 'list'
    p.alias['list.t'] = 'tuple'
    p.alias['list.x'] = 'dict'
    p.alias['x.y'] = 'y'
    assert p.resolve('', Name('list', None, None), '') == 'list'
    assert p.resolve('', Subscript(Name('list', None, None),
                                   Index(Name('t', None, None)), None, None),
                    '') == 'tuple'
    assert p.resolve('', Subscript(Name('list', None, None),
                                   Index(Name('y', None, None)), None, None),
                    '') == 'dict'

# Generated at 2022-06-23 15:31:44.861355
# Unit test for method compile of class Parser
def test_Parser_compile():
    import os, shutil
    from . import name_mangle
    from . import sample3
    from . import __doc__ as d
    p = Parser(link=True, toc=True)
    p.parse(sample3)
    with open(name_mangle('sample3.rst'), 'w') as f:
        f.write(p.compile())
    p = Parser(link=True, toc=True)
    p.parse(name_mangle('sample3.rst'))
    assert p.compile() == d
    assert all(
        c.startswith('module.') and c.endswith('.__name__')
        for c in p.const
    )

# Generated at 2022-06-23 15:31:55.106418
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    parser = Parser()
    parser.alias = {'a.b': 'b', 'a.c': 'c'}
    parser.root = {'a.b.d': 'a.b', 'a.c': 'a.c'}
    parser.imp = {'a.b': {'a.b.d'}}
    # case a.b.d
    assert parser.is_public('a.b.d')
    # case a.c
    assert parser.is_public('a.c')
    # case a.b.f
    assert not parser.is_public('a.b.f')
    # case a.c.d
    assert not parser.is_public('a.c.d')


# Generated at 2022-06-23 15:32:00.083166
# Unit test for method compile of class Parser
def test_Parser_compile():
    Parser.compile = lambda self: self.doc[max(self.doc, key=self.__names_cmp)]
    d, = Parser(dir=dirname(dirname(abspath(__file__)))).compile().split('*')
    assert d.startswith('#')
    assert d.endswith('()\n')
test_Parser_compile()
# end



# Generated at 2022-06-23 15:32:06.800372
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    import inspect
    import io
    import sys

    import __main__
    from inspect import isclass, isfunction, ismodule
    from typing import List, Dict
    from typing import get_type_hints
    from typing_extensions import TYPE_CHECKING

    from . import ast
    from . import parser

    class TestModule:
        """Test module"""
        CONSTANT = 1
        _private = 2
        __private = 3
        #: Test attribute
        attr = None
        #: Test property
        @property
        def prop(self):
            """Property test"""

    class TestClass:
        """Test class"""
        #: Test class attribute
        attr = None
        #: Class property test
        @property
        def prop(self):
            """Class property test"""


# Generated at 2022-06-23 15:32:08.553811
# Unit test for method func_ann of class Parser

# Generated at 2022-06-23 15:32:10.842511
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    a = Parser(False)
    b = Parser(False)
    assert a == b



# Generated at 2022-06-23 15:32:21.296639
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    # Test case 1
    r = Resolver('pyslvs', {'pyslvs.chain': 'Iterable[int]'})
    node = parse('a', mode='eval').body
    assert r.visit(node) == Name(id='Iterable', ctx=Load())

    # Test case 2
    r = Resolver('pyslvs', {'pyslvs.chain': ''})
    node = parse('a', mode='eval').body
    assert r.visit(node) == Name(id='a', ctx=Load())

    # Test case 3
    r = Resolver('pyslvs', {'pyslvs.chain': 'TypeVar("T")'})
    node = parse('T', mode='eval').body

# Generated at 2022-06-23 15:32:26.246023
# Unit test for function parent
def test_parent():
    a = "a.b.c"
    assert parent(a, level=0) == a
    assert parent(a, level=1) == "a.b"
    assert parent(a, level=2) == "a"
    assert parent(a, level=3) == ""



# Generated at 2022-06-23 15:32:34.440813
# Unit test for function const_type
def test_const_type():
    """Definition in https://docs.python.org/3/reference/expressions.html\
        #atom-identifiers."""
    assert const_type(Constant(1)) == 'int'
    assert const_type(Constant(1.0)) == 'float'
    assert const_type(Constant(1 + 1j)) == 'complex'
    assert const_type(Constant('1')) == 'str'
    assert const_type(Constant(b'1')) == 'bytes'
    assert const_type(Constant(True)) == 'bool'
    assert const_type(Constant(None)) == 'NoneType'
    assert const_type(Constant((1, 2))) == 'tuple[int, int]'
    assert const_type(Constant([1, 2])) == 'list[int, int]'


# Generated at 2022-06-23 15:32:37.688484
# Unit test for function table
def test_table():
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == \
        "| a | b |\n" + \
        "|:---:|:---:|\n" + \
        "| c | d |\n" + \
        "| e | f |\n\n"



# Generated at 2022-06-23 15:32:47.320018
# Unit test for constructor of class Parser
def test_Parser():
    from .tree import Module
    from .util import parse
    p = Parser()
    root = "name"
    tree = Module(body=[])
    p.visit(root, tree, **{'a': 1, 'b': 2})
    assert p.imp == {}
    assert p.alias == {}
    assert p.doc == {}
    assert p.docstring == {}
    assert p.root == {}
    assert p.level == {root: 0}
    assert p.const == {}
    p = Parser()
    root = "name"
    tree = Module(body=[parse("from _abc import ABC")])
    p.visit(root, tree, **{'a': 1, 'b': 2})
    assert p.imp == {}

# Generated at 2022-06-23 15:32:58.630576
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert unparse(Resolver('foo', {}).visit_Attribute(Name('typing.Dict', Load()))) == 'Dict'
    assert unparse(Resolver('foo', {}).visit_Attribute(Name('dataclasses.dataclass', Load()))) == 'dataclasses.dataclass'
    assert unparse(Resolver('foo', {}).visit_Attribute(Name('foo.typing.Dict', Load()))) == 'foo.typing.Dict'
    assert unparse(Resolver('foo', {'foo.typing': 'typing'}).visit_Attribute(Name('foo.typing.Dict', Load()))) == 'Dict'

# Generated at 2022-06-23 15:33:03.031838
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert unparse(Resolver("a", {}, "self").visit(
        Attribute(Name("typing", Load()), "List", Load()))) == "List"
    assert unparse(Resolver("a", {}, "self").visit(
        Attribute(Name("ast", Load()), "List", Load()))) == "ast.List"

# Generated at 2022-06-23 15:33:03.749439
# Unit test for function parent
def test_parent():
    assert parent("abc") == ""



# Generated at 2022-06-23 15:33:09.204121
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    parser = Parser(link=False, toc=False)
    args = [arg('self', Name(id='Class', ctx=Param())),
            arg('a', Name(id='int', ctx=Param())),
            arg('b', Name(id='float', ctx=Param())),
            arg('*', None),
            arg('c', Name(id='str', ctx=Param())),
            arg('d', Name(id='T', ctx=Param())),
            arg('**', None),
            arg('return', Name(id='Class', ctx=Param()))]

# Generated at 2022-06-23 15:33:11.464982
# Unit test for function is_magic
def test_is_magic():
    assert not is_magic('__')
    assert not is_magic('___')
    assert is_magic('__init__')
    assert not is_magic('___init__')
    assert not is_magic('__init____')



# Generated at 2022-06-23 15:33:16.710716
# Unit test for function code
def test_code():
    assert code('var | test') == '<code>var &#124; test</code>'
    assert code('var & test') == '<code>var &amp; test</code>'
    assert code('var   test') == '<code>var   test</code>'
    assert code('var test') == '<code>var test</code>'
    assert code('') == ' '
    assert code(None) == ' '


# Generated at 2022-06-23 15:33:19.818683
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    doc: str = "type: typing.str"
    resolved = cast(str, unparse(Resolver(__name__, {"typing.str": "str"})
                                 .visit(parse(doc).body[0].value)))
    assert resolved == "str"



# Generated at 2022-06-23 15:33:30.678547
# Unit test for function const_type
def test_const_type():
    def tc(expr: Union[expr, AST]) -> str:
        return const_type(expr if isinstance(expr, expr) else parse(expr))

    assert tc('True') == 'bool'
    assert tc('10') == 'int'
    assert tc('10.0') == 'float'
    assert tc('10j') == 'complex'
    assert tc('"10"') == 'str'
    assert tc('(10,)') == 'tuple[int]'
    assert tc('[10, True]') == 'list[Any]'
    assert tc('{10, True}') == 'set[Any]'
    assert tc('[]') == 'list[Any]'
    assert tc('{}') == 'dict[Any, Any]'
    assert tc('{"a": "b"}') == 'dict[str, str]'
    assert tc

# Generated at 2022-06-23 15:33:34.659729
# Unit test for function code
def test_code():
    assert code('a') == '`a`'
    assert code(' | ') == '<code>&#124;</code>'
    assert code('A&B') == '<code>A&amp;B</code>'
    assert code('') == ' '



# Generated at 2022-06-23 15:33:38.728440
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('abc')
    assert not is_public_family('.abc')
    assert is_public_family('abc.bcd')
    assert not is_public_family('abc._bcd')
    assert not is_public_family('abc.__bcd')

# Generated at 2022-06-23 15:33:42.708324
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    try:
        node = ast.parse("typing.Optional[int]").body[0].value
        visit_Attribute(Resolver("", {}), node)
    except Exception as e:
        raise e
    else:
        assert isinstance(node, ast.Name)


# Generated at 2022-06-23 15:33:46.477022
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    """Test of `test_Resolver_visit_Name`."""
    resolver = Resolver("test", {})
    node = Name("test_method", Load())
    new_node = resolver.visit_Name(node)
    assert new_node.id == "test_method"

# Generated at 2022-06-23 15:33:57.392136
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    import binascii
    from .literal import literal
    from .typing import get_properties, PEP585
    from .pythontypes import PythonType, python_types

    class Dummy:
        """This is dummy class for litpath of class PythonType.

        It just provide one property for test.
        """

    class Dummy2:
        """This is dummy class for litpath of class PythonType.

        It just provide one property for test.
        """

    dummy_obj = Dummy()
    dummy_obj.dummy_src = dummy_obj
    dummy_src = dummy_obj.dummy_src


# Generated at 2022-06-23 15:34:00.214721
# Unit test for method compile of class Parser
def test_Parser_compile():
    import doctest
    doctest.testmod()
# Example of how to use class Parser

# Generated at 2022-06-23 15:34:01.732523
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser(TOC=True, link=True)

# Generated at 2022-06-23 15:34:11.400629
# Unit test for function const_type
def test_const_type():
    assert const_type(parse(
        "bool(True)",
        mode='eval'
    ).body) == 'bool'
    assert const_type(parse(
        "int(1)",
        mode='eval'
    ).body) == 'int'
    assert const_type(parse(
        "float(1.0)",
        mode='eval'
    ).body) == 'float'
    assert const_type(parse(
        "complex(1+1j)",
        mode='eval'
    ).body) == 'complex'
    assert const_type(parse(
        "str('1')",
        mode='eval'
    ).body) == 'str'
    assert const_type(parse(
        "bool()",
        mode='eval'
    ).body) == ANY

# Generated at 2022-06-23 15:34:21.167219
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    p.root = {"test.test": "test.test"}
    p.alias = {
        "test.test": "test",
        "test.a": "a",
        "test.api": "api",
        "test.sub": "sub",
        "test.sub.sub": "sub.sub",
        "test.sub.subsub": "sub.subsub",
        "test.sub.subsub.subsubsub": "sub.subsub.subsubsub",
    }

# Generated at 2022-06-23 15:34:28.311873
# Unit test for function doctest
def test_doctest():
    """Test for function doctest."""
    assert doctest('''
    >>> a()
    'a'
    ''') == '''
    ```python
    >>> a()
    'a'
    ```
    '''
    assert doctest('''
    >>> a()
    'a'
    >>> b()
    'b'
    ''') == '''
    ```python
    >>> a()
    'a'
    ```
    >>> b()
    'b'
    '''



# Generated at 2022-06-23 15:34:38.795610
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    root = 'abc'

# Generated at 2022-06-23 15:34:41.416423
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    assert(Parser().resolve('tests', ast.parse('typing.Callable'), 'Callable') == 
           'Callable[..., Any]')


# Generated at 2022-06-23 15:34:45.209092
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('distutil.__config__')
    assert not is_public_family('sys._getframe')
    assert not is_public_family('_abc.abstractclassmethod')
    assert is_public_family('abc.abstractclassmethod')
# Run the test
test_is_public_family()



# Generated at 2022-06-23 15:34:49.498229
# Unit test for function doctest
def test_doctest():
    with open('sample.py') as f:
        m = parse(f.read(), 'sample.py')
        for n in m.body:
            if isinstance(n, FunctionDef):
                print(doctest(getdoc(n)))
                break



# Generated at 2022-06-23 15:34:57.126121
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    p.imp['test_mod'] = {'test_mod.foo', 'test_mod.Class', 'test_mod.bar'}
    p.doc['test_mod'] = p.doc['test_mod.foo'] = p.doc['test_mod.Class'] = ''
    p.doc['test_mod.foo.baz'] = p.doc['test_mod.Class.method'] = ''
    p.level['test_mod'] = 0
    p.level['test_mod.foo'] = p.level['test_mod.Class'] = 1
    p.level['test_mod.foo.baz'] = p.level['test_mod.Class.method'] = 2

# Generated at 2022-06-23 15:35:01.200541
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore('a1') == 'a1'
    assert esc_underscore('a_1') == r'a\_1'
    assert esc_underscore('a_1_') == r'a\_1\_'
    assert esc_underscore('_a1_') == r'\_a1\_'



# Generated at 2022-06-23 15:35:13.180863
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from urllib.parse import urlparse
    from .extract import Loader
    from . import __main__ as main

    src = """
    '''module doc'''

    # class doc
    class A:
        '''class doc'''

        def func(self) -> None:
            '''func doc'''

        @classmethod
        def cls(cls) -> None:
            '''cls doc'''

        def __new__(cls, *args, **kwargs) -> 'A':
            '''new doc'''

    def func():
        '''func doc'''

    func.__doc__ = '''attr doc'''
    """
    with tempfile.NamedTemporaryFile(mode='w+t', suffix='.py',
                                     delete=False) as file:
        file

# Generated at 2022-06-23 15:35:23.898158
# Unit test for function walk_body
def test_walk_body():
    n1 = parse(
        "if True:\n"
        "    pass\n"
        "else:\n"
        "    pass\n"
    )
    assert list(walk_body(n1.body)) == n1.body
    n2 = parse(
        "try:\n"
        "    pass\n"
        "finally:\n"
        "    pass"
    )
    assert list(walk_body(n2.body)) == n2.body
    n3 = parse(
        "try:\n"
        "    pass\n"
        "except:\n"
        "    pass\n"
        "else:\n"
        "    pass\n"
        "finally:\n"
        "    pass\n"
    )

# Generated at 2022-06-23 15:35:29.864762
# Unit test for method imports of class Parser
def test_Parser_imports():
    """Unit test for method imports of class Parser."""
    parser = Parser()
    node = Import(names=[alias(name='a', asname='b'), alias(name='c')], level=1)
    parser.imports(root='root', node=node)
    assert parser.alias == {
        'root.b': 'a',
        'root.c': 'c'
    }

# Generated at 2022-06-23 15:35:31.002922
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__magic__')



# Generated at 2022-06-23 15:35:37.027862
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('a')
    assert is_public_family('a.b')
    assert is_public_family('a.__b')
    assert is_public_family('a.__b__')
    assert not is_public_family('_a')
    assert not is_public_family('a._b')
test_is_public_family()



# Generated at 2022-06-23 15:35:39.328680
# Unit test for function parent
def test_parent():
    assert parent('this.is.test') == 'test'
    assert parent('name.of.x', level=2) == 'x'



# Generated at 2022-06-23 15:35:42.759859
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert unparse(Resolver('.', {'typing': ''}, 'self').visit(
        parse('typing.Union[str, int, float]').body[0].value
    )) == 'str | int | float'



# Generated at 2022-06-23 15:35:54.386306
# Unit test for constructor of class Parser
def test_Parser():
    """Test the constructor of Parser."""
    with pytest.raises(TypeError, match=r"'bool' object is not iterable"):
        Parser(True, link=True)
    with pytest.raises(TypeError, match=r"'int' object is not iterable"):
        Parser(3, link=True)
    with pytest.raises(TypeError, match=r"invalid module name '\.': "):
        Parser(".", link=True)
    with pytest.raises(TypeError, match=r"invalid module name 'a\.': "):
        Parser("a.", link=True)
    with pytest.raises(TypeError, match=r"invalid module name 'a\.': "):
        Parser("a.b", link=True)

# Generated at 2022-06-23 15:35:57.746714
# Unit test for constructor of class Parser
def test_Parser():
    # Check the basic operation of the constructor
    try:
        Parser(link=False)
    except:
        # The constructor should not thrown any exceptions
        assert False

# Function to test the parser

# Generated at 2022-06-23 15:36:02.458930
# Unit test for function table
def test_table():
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == """
| a | b |
|:---:|:---:|
| c | d |
| e | f |
"""

# Generated at 2022-06-23 15:36:13.670515
# Unit test for function walk_body
def test_walk_body():
    body = [
        If(const('True'), [
            If(const('True'), [
                FunctionDef(name('y'), args(), [], None, None),
                FunctionDef(name('z'), args(), [], None, None)
            ], [
                Assign([name('x')], const('False'))
            ])
        ], [
            Assign([name('x')], const('False'))
        ])
    ]
    assert list(walk_body(body)) == [
        FunctionDef(name('y'), args(), [], None, None),
        FunctionDef(name('z'), args(), [], None, None),
        Assign([name('x')], const('False')),
        Assign([name('x')], const('False'))
    ]

# Generated at 2022-06-23 15:36:17.743146
# Unit test for function parent
def test_parent():
    if parent('a.b.c', level=1) == 'a.b' and parent('a.b.c', level=2) == 'a':
        return True
    return False



# Generated at 2022-06-23 15:36:28.800798
# Unit test for function const_type
def test_const_type():
    """Function for unit test."""
    assert const_type(Constant(None)) == 'NoneType'
    assert const_type(Constant(True)) == 'bool'
    assert const_type(Constant(1)) == 'int'
    assert const_type(Constant(1.0)) == 'float'
    assert const_type(Constant(1 + 1j)) == 'complex'
    assert const_type(Constant('a')) == 'str'
    assert const_type(Constant('a'.encode('utf-8'))) == 'bytes'
    assert const_type(List([])) == 'list[]'
    assert const_type(List([Constant(1), Constant(2)])) == 'list[int]'

# Generated at 2022-06-23 15:36:33.005390
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__init__')
    assert not is_magic('__main__')
    assert not is_magic('__import__')
    assert not is_magic('__name__')
    assert not is_magic('__file__')
    assert not is_magic('__path__')



# Generated at 2022-06-23 15:36:38.183081
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    """Test func_api."""
    # Unit test for method file_api of class Parser
    p = Parser()
    p.func_api(None, None, None, None, has_self=True, cls_method=False)
    p.func_api(None, None, None, None, has_self=False, cls_method=True)
    p.func_api(None, None, None, None, has_self=False, cls_method=False)

# Generated at 2022-06-23 15:36:49.573076
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    import ast
    mock_scope = {}

    def mock_eval(*_, **__):
        return 42

    def mock_getattr(obj, name):
        return mock_scope[name]

    def mock_getitem(obj, name):
        return mock_scope[name]

    def mock_hasattr(obj, name):
        return name in mock_scope

    def mock_call(*args, **kwargs):
        return None

    parser = Parser(level=2)
    parser.alias['mock.attr'] = 'mock_attr'
    parser.alias['mock.item'] = 'mock_item'
    parser.alias['mock.eval'] = 'mock_eval'
    parser.alias['mock.call'] = 'mock_call'

# Generated at 2022-06-23 15:36:54.032172
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(
        '/test/test_test.py', 'def test_test(): ...') == (
        '@staticmethod\n'
        'def test_test() -> None:\n'
        '    ...')

# Generated at 2022-06-23 15:37:01.411102
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    assert Parser(['a','c', 'd','b'], 45) == Parser(['a','c', 'd','b'], 45)
    assert (Parser(['a','c', 'd','b'], 45) != Parser(['a','c', 'd','b'], 46))
    assert Parser(['a','c', 'd','b'], 45) != Parser(['a','c', 'd'], 45)
    assert Parser(['a','c', 'd','b'], 45) != Parser(['a','c', 'd','b', 'e'], 45)
    assert Parser(['a','c', 'd','b'], 45) != Parser(['b','c', 'd', 'a'], 45)

# Generated at 2022-06-23 15:37:03.751462
# Unit test for function code
def test_code():
    assert code("| @bark.").startswith("<code>")
    assert code("with a dog").startswith("`")



# Generated at 2022-06-23 15:37:13.665883
# Unit test for constructor of class Resolver
def test_Resolver():
    """Unit test of Resolver."""

# Generated at 2022-06-23 15:37:22.910744
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore('_') == '\\_'
    assert esc_underscore('__') == '\\_\\_'
    assert esc_underscore('___') == '\\_\\_\\_'
    assert esc_underscore('_abc_') == '\\_abc\\_'
    assert esc_underscore('_abc_def_') == '\\_abc\\_def\\_'
    assert esc_underscore('_abc_def_ghi_') == '\\_abc\\_def\\_ghi\\_'
    assert esc_underscore('abc') == 'abc'
    assert esc_underscore('abc_def') == 'abc_def'
    assert esc_underscore('abc_def_') == 'abc_def\\_'

# Generated at 2022-06-23 15:37:30.567628
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    p = Parser()
    assert p.resolve('a', Name(id='b', ctx=Load())) == 'b'
    assert p.resolve('a.b', Name(id='a', ctx=Load())) == 'b.a'
    assert p.resolve('a', Call(func=Name(id='b', ctx=Load()), args=[],
                               keywords=[])) == 'b()'
    assert p.resolve('a', Attribute(value=Name(id='b', ctx=Load()), attr='c',
                                    ctx=Load())) == 'b.c'

# Generated at 2022-06-23 15:37:36.945957
# Unit test for method imports of class Parser
def test_Parser_imports():
    """Test for method imports of class Parser."""
    from .. import Parser, Module

    p = Parser()
    m = Module(
        body=[
            Import(
                names=[alias('a')]),
            ImportFrom(
                module='pp.a', names=[alias('b', asname='c')], level=1),
        ])
    p.imports('', m)
    assert p.alias == {
        'a': 'a',
        'c': 'pp.a.b',
    }



# Generated at 2022-06-23 15:37:49.334342
# Unit test for method imports of class Parser
def test_Parser_imports():
    """Unit test for method imports of class Parser."""


# Generated at 2022-06-23 15:38:01.712975
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    """Test parser class API generation."""
    parser = Parser(b_level=1, link=True)
    parser.class_api("foo.bar",
                     "foo.bar.Baz",
                     [parse("")],
                     (parse(""), parse(""),
                      parse("def _get_baz(self): ...\n"),
                      parse("def get_baz(self) -> int: ...\n"),
                     parse("async def get_baz(self, bz: str) -> None: ...\n"),
                     parse("def __init__(self, bz: str, *, x=31, **kwargs): ...\n"),
                     parse("@classmethod\ndef get_baz(cls, bz: int) -> str: ...\n")))

# Generated at 2022-06-23 15:38:04.663970
# Unit test for function is_magic
def test_is_magic():
    assert is_magic("__init__")
    assert is_magic("__enter__")
    assert is_magic("__exit__")
    assert is_magic("__call__")
    assert is_magic("__iter__")
    assert not is_magic("abc")

# Generated at 2022-06-23 15:38:09.586804
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    parser = Parser()
    assert_equals(parser.level, {})
    assert_equals(parser.root, {})
    assert_equals(parser.alias, {})
    assert_equals(parser.imp, defaultdict(set))
    assert_equals(parser.const, {})
    assert_equals(parser.doc, {})
    assert_equals(parser.docstring, {})
    assert_equals(parser.link, False)
    assert_equals(parser.b_level, 0)
    assert_equals(parser.toc, True)


# Generated at 2022-06-23 15:38:21.555829
# Unit test for method imports of class Parser
def test_Parser_imports():
    def _test(root: str, node: _I, alias: dict):
        p = Parser()
        p.imports(root, node)
        assert alias == p.alias

    def _m(root: str, *names: str) -> str:
        return f"{root}.{'.'.join(names)}"

    _test('a.b', Import(names=[alias(name='n1', asname=None)]), {
        _m('a.b', 'n1'): 'n1'})
    _test('a.b', Import(names=[alias(name='n1', asname='a')]), {
        _m('a.b', 'a'): 'n1'})

# Generated at 2022-06-23 15:38:30.051981
# Unit test for method globals of class Parser
def test_Parser_globals():
    import os
    import sys
    import ast
    import astroid
    import pylint
    import pylint_pyreverse
    code = (
        'import os\n'
        'a: int = 1\n'
        'b = 1\n'
        '__all__ = []\n'
        'class B: ...'
        '__all__ = []\n'
        'i = 1'
    )
    tree = astroid.parse(code)
    fname = 'x.py'
    node = tree.body[-1]
    mod = ModuleType(fname)
    mod.os = os
    mod.sys = sys
    mod.ast = ast
    mod.astroid = astroid
    mod.pylint = pylint
    mod.pylint_pyreverse = p

# Generated at 2022-06-23 15:38:40.704834
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    resolver = Resolver('test', {'test.Optional': 'typing.Optional',
                                 'test.Union': 'typing.Union'})
    name = Name('A', Load())
    sb = Subscript(Name('Optional', Load()), value=name, ctx=Load())
    assert isinstance(resolver.visit(sb), BinOp)
    sb = Subscript(Name('Union', Load()), value=Tuple(elts=[name, name],
                                                      ctx=Load()), ctx=Load())
    assert isinstance(resolver.visit(sb), BinOp)
test_Resolver_visit_Subscript()



# Generated at 2022-06-23 15:38:50.703872
# Unit test for function doctest
def test_doctest():
    from random import choice, randint
    from re import search

    def _gen_doc(num: int, mark: str) -> str:
        for _ in range(num):
            yield f"{mark} {''.join(choice('abcdefghijklmnopqrstuvwxyz') for _ in range(randint(1, 10)))}"
        yield f"{mark} {''.join(choice('abcdefghijklmnopqrstuvwxyz') for _ in range(randint(1, 10)) + 1)}"

    doc = '\n'.join(_gen_doc(randint(5, 15), '>>>'))

    assert search(r'```python\n\n>>>', doctest(doc)) is not None

# Generated at 2022-06-23 15:38:53.595542
# Unit test for function parent
def test_parent():
    assert parent('a') == ''
    assert parent('a.b') == 'a'
    assert parent('a.b', level=2) == ''
    assert parent('a.b', level=3) == ''



# Generated at 2022-06-23 15:39:04.862532
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    class _stmt(AST):
        _fields = ()
    class FunctionDef(_stmt):
        _fields = ('name', 'args', 'body', 'decorator_list', 'returns',
                   'type_comment')
    class arg(_stmt):
        _fields = ('arg', 'annotation')
    class arguments(_stmt):
        _fields = ('args', 'vararg', 'kwonlyargs', 'kw_defaults', 'kwarg',
                   'defaults')
    from .core import Parser
    p = Parser(doc='', toc=False, link=False)

# Generated at 2022-06-23 15:39:10.805544
# Unit test for function table
def test_table():
    """Docstring test for table."""
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == \
        '''| a | b |
|:---:|:---:|
| c | d |
| e | f |

'''



# Generated at 2022-06-23 15:39:11.850612
# Unit test for method func_api of class Parser

# Generated at 2022-06-23 15:39:23.332190
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    parser = Parser()
    root = 'root'
    name = 'a.b'
    bases = [1, 2]
    body = []
    doc = {}
    parser.doc = doc
    parser.class_api(root, name, bases, body)

    assert(doc[name] == '#### class b\n\n' +
        '*Full name:* `a.b`\n\n' +
        'Bases\n\n' +
        '- `1`\n\n' +
        '- `2`\n\n' +
        'Members\n\n' +
        '- `Type`\n\n'
    )

# Generated at 2022-06-23 15:39:28.608542
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    from inspect import getmembers
    from rswail.parser import Parser
    parser: Parser = Parser(
        name="parser",
        alias={},
        level={},
        root={},
        const={},
        imp={},
        doc={},
        docstring={},
        toc=True,
        link=True,
    )

# Generated at 2022-06-23 15:39:37.364077
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    import ast
    import _ast
    from contextlib import contextmanager
    class Resolver(ast.NodeVisitor):
        """Resolver."""
        def __init__(self, root: str, alias: dict[str, str], self_ty: str = '',
                     **kw: Any) -> None:
            """Initialize."""
            super().__init__(**kw)
            self.root = root
            self.alias = alias
            self.self_ty = self_ty

        def __enter__(self) -> 'Resolver':
            """Enter context manager."""
            return self

        def __exit__(self, exc_type, exc_value, traceback) -> None:
            """Exit context manager."""
            pass


# Generated at 2022-06-23 15:39:48.071275
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    # Test public name of module
    assert Parser().is_public('')

    # Test public name of class
    assert Parser().is_public('t.A')

    # Test public name of class method
    assert Parser().is_public('t.A.a')

    # Test public name of module function
    assert Parser().is_public('t.a')

    # Test magic name
    assert not Parser().is_public('t.__all__')

    # Test name of magic function
    assert Parser().is_public('t.__magic__')

    # Test common name
    assert not Parser().is_public('t.__a__')

    # Test private name of module function
    assert not Parser().is_public('t._a')

    # Test private name of class

# Generated at 2022-06-23 15:39:55.635661
# Unit test for method globals of class Parser
def test_Parser_globals():
    from . import ast, token
    from .ast import Assign, Constant, Expr, ImportFrom, Name, Store
    from .token import DEDENT, INDENT, OP, STRING

    parser = Parser()
    parser.doc = {}
    parser.alias = {}
    root = 'module_name'

# Generated at 2022-06-23 15:40:07.644000
# Unit test for method api of class Parser