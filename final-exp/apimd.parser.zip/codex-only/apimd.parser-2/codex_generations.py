

# Generated at 2022-06-23 15:30:05.503481
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from script import Parser
    from typing import Any, Dict
    p = Parser.Parser(link=True)
    p.docstring = Dict[str, Any]()
    p.doc = Dict[str, Any]()
    p.imp = Dict[str, Any]()
    p.const = Dict[str, Any]()
    p.alias = Dict[str, Any]()
    p.level = Dict[str, Any]()
    p.root = Dict[str, Any]()
    p.b_level = int()
    p.level['root'] = 0
    p.root['root'] = 'root'
    p.alias['root'] = 'root'

# Generated at 2022-06-23 15:30:15.509304
# Unit test for method api of class Parser
def test_Parser_api():
    test = Parser()
    root = 'user.name'
    test.api(root, FunctionDef(
        name='func',
        args=arguments(args=[], vararg=None, kwonlyargs=[],
                       kw_defaults=[], kwarg=None, defaults=[]),
        body=[], decorator_list=[], returns=None))
    assert test.doc[root + '.func'] == \
        '## func()\n\n*Full name:* `user.name.func`\n\n' \
        '<table><tr><th>Arguments</th></tr><tr><td><pre>None</pre></td></tr></table>'
    test.api(root, ClassDef(
        name='class',
        bases=[], body=[], decorator_list=[]))
    assert test

# Generated at 2022-06-23 15:30:26.867477
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    p = Parser()
    assert p.resolve("root", Num(n=1)) == "1"
    assert p.resolve("root", Name(id="t", ctx=Load())) == "'t'"
    assert p.resolve("root", Subscript(value=Name(id="t", ctx=Load()),
                                       slice=Index(value=Num(n=1)),
                                       ctx=Load())) == "'t'[1]"
    assert p.resolve("root", Tuple(elts=[Name(id="a", ctx=Load()),
                                         Name(id="b", ctx=Load())])) == "(a, b)"

# Generated at 2022-06-23 15:30:35.461025
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    assert p.is_public('test.test') is False
    p.imp['test'] = {'test'}
    assert p.is_public('test.test') is True
    assert p.is_public('test.test2') is False
    p.imp['test'] = {'test', 'test.test2'}
    assert p.is_public('test.test2') is True
    p.imp['test'] = {'test', 'test.test2', 'test.test3'}
    assert p.is_public('test') is True
    assert p.is_public('test.test') is True
    assert p.is_public('test.test2') is True
    assert p.is_public('test.test3') is True

# Generated at 2022-06-23 15:30:39.783945
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    p = Parser()
    assert p.alias == {}
    assert list(p.doc.keys()) == []
    assert list(p.docstring.keys()) == []
    assert p.imp == {'': set()}
    assert p.root == {}
    assert list(p.level.keys()) == []


# Generated at 2022-06-23 15:30:43.965817
# Unit test for function table
def test_table():
    items = [['a', 'b'], ['c', 'd']]
    output = table('a', 'b', items)
    assert output == '| a | b |\n|:---:|:---:|\n| a | b |\n| c | d |\n\n'



# Generated at 2022-06-23 15:30:53.454839
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    import inspect
    from examples import empty_class, name_asname
    from examples.mypy_typing import Point
    from examples.typing import Point as TPoint
    from examples.deprecated import deprecated


    __name__ = 'examples'


    p = Parser()
    m = p.parse(inspect.getsource(empty_class))
    assert p.resolve('examples.empty_class', m.body[0].annotations['x']) == 'int'
    assert p.resolve('examples.empty_class', m.body[0].annotations['y']) == 'int'
    m = p.parse(inspect.getsource(name_asname))
    assert p.resolve('examples.name_asname', m.body[0].value) == 'empty_class'
   

# Generated at 2022-06-23 15:31:04.422120
# Unit test for method globals of class Parser
def test_Parser_globals():
    alias = {}
    root = {}
    const = {}
    imp = defaultdict(set)
    doc = {}

    parser = Parser(0, alias, root, const, imp, doc)

    root = 'root'


    # Test case 3
    # 
    # Unsupported node: <_ast.Lambda object at 0x7fc22a740820>
    # 
    # With the following code:
    # node = ast.parse("""
    #     x = lambda: None
    # """)
    # 
    # Expect:
    # #
    # 
    # Actual:
    # #
    assert False



# Generated at 2022-06-23 15:31:15.350975
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    attribute_name = 'typing.NoReturn'
    # parse attribute_name to AST
    node = cast(Attribute, parse(attribute_name).body[0].value)
    # resolve attribute_name to AST of Name
    node = Resolver("", {}).visit(node)
    # check to see if the node is an AST of Name
    assert isinstance(node, Name)
    # check to see if the attribute_name is the name of the new AST
    assert node.id == 'NoReturn'
    # check to see if the attribute_name is a valid SyntaxError
    assert isinstance(parse(node.id).body[0].value, Name)

# Generated at 2022-06-23 15:31:24.005022
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    from argparse import Namespace
    from typing import Any, cast
    from .test.utils import make_test_suite, TestCase
    class Parser___post_init__Test(TestCase):
        def test__post_init__(self):
            p = Parser(Namespace())
            p.imp[''] = set()
            p.b_level = 1
            p.alias[''] = ''
            p.root[''] = ''
            p.level[''] = 0
            p.const[''] = ''
            p.doc[''] = ''
            p.docstring[''] = ''
            self.assertIsInstance(p.__post_init__(), None)
            self.assertIsInstance(cast(Any, p).__post_init__(), None)

# Generated at 2022-06-23 15:31:34.504452
# Unit test for constructor of class Resolver

# Generated at 2022-06-23 15:31:46.982331
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    import inspect
    import types
    import aiocontext
    doc = Parser()
    doc.level['test'] = 0
    doc.root['test'] = 'test'
    doc.api('test', inspect.signature(types.coroutine), prefix='aiocontext')
    assert doc.doc['aiocontext.coroutine'] == (
        '## coroutine()\n\n' +
        '*Full name:* `aiocontext.coroutine`\n\n' +
        '| Argument | Type |\n| --- | --- |\n' +
        '| **self** | `Self` |\n| **func** | `func` |\n' +
        '| **return** | `coro` |\n')

# Generated at 2022-06-23 15:31:56.794620
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    root = '__main__'
    alias = {'__main__': 'T', 'typing': 'T'}
    self_ty = 'T'
    node = Constant('T')
    assert Resolver(root, alias, self_ty).visit_Constant(node).id == 'T'
    node = Constant('int')
    assert Resolver(root, alias, self_ty).visit_Constant(node).n == 'int'
    node = Constant('str')
    assert Resolver(root, alias, self_ty).visit_Constant(node).s == 'str'
    node = Constant('float')
    assert Resolver(root, alias, self_ty).visit_Constant(node).n == 'float'
    node = Constant('complex')

# Generated at 2022-06-23 15:32:04.318405
# Unit test for function const_type
def test_const_type():
    _const_type = const_type
    assert _const_type(parse("1")) == 'int'
    assert _const_type(parse("[1, 2]")) == 'list[int]'
    assert _const_type(parse("()")) == 'tuple[]'
    assert _const_type(parse("{1: 2}")) == 'dict[int, int]'
    assert _const_type(parse("bool(1)")) == 'bool'
    assert _const_type(parse("int(1)")) == 'int'
    assert _const_type(parse("float(1)")) == 'float'
    assert _const_type(parse("complex(1)")) == 'complex'
    assert _const_type(parse("str(1)")) == 'str'
    assert _const_type(parse("bool(1)"))

# Generated at 2022-06-23 15:32:12.266144
# Unit test for method parse of class Parser
def test_Parser_parse():
    files = ['./test/module.py']
    ans_doc = '\n**Table of contents:**\n    + [module](#module)\n\n'
    ans_doc += '# module\n\n*Full name:* `module`\n<a id="module"></a>\n\n'
    ans_doc += 'Constants\n+---------+--------+\n|  Name   |  Type  |\n'
    ans_doc += '+=========+========+\n| `CONST` | `str`  |\n+---------+--------+\n\n'
    ans_doc += '## class Class\n\n*Full name:* `module.Class`\n'

# Generated at 2022-06-23 15:32:17.162219
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    assert Resolver("a.b.c", {}).visit_Constant(Constant("a")).id == "a"
    assert Resolver("a.b.c", {}).visit_Constant(Constant(1)).n == 1
    assert Resolver("a.b.c", {}).visit_Constant(Constant(None)).value is None

# Generated at 2022-06-23 15:32:20.062065
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    x = Subscript(Name('x', Load()), Slice(None, None, None), Load())
    assert Resolver('', {}).visit(x) == x



# Generated at 2022-06-23 15:32:25.269612
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family("math.acos") == True
    assert is_public_family("_math.acos") == False
    assert is_public_family("math._acos") == False
    assert is_public_family("_math._acos") == False
    assert is_public_family("__a.__b") == False
test_is_public_family()


# Generated at 2022-06-23 15:32:28.699278
# Unit test for function parent
def test_parent():
    assert parent('a.b.c') == 'a.b'
    assert parent('a.b.c', level=2) == 'a'
    assert parent('a.b.c', level=3) == ''
    assert parent('a.b.c', level=4) == ''



# Generated at 2022-06-23 15:32:39.767535
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family("math.sqrt")
    assert is_public_family("math.__dict__")
    assert is_public_family("math._test_sqrt")
    assert not is_public_family("math._test_sqrt._test_sqrt")
    assert is_public_family("math._test_sqrt.__dict__")
    assert not is_public_family("math._test_sqrt._test_sqrt.__dict__")
    assert not is_public_family("math._test_sqrt._test_sqrt._test_sqrt")
    assert not is_public_family("_math._test_sqrt._test_sqrt")
    assert not is_public_family("math.__dict__._test_sqrt")



# Generated at 2022-06-23 15:32:41.560948
# Unit test for function doctest
def test_doctest():
    doc = getdoc(doctest)
    assert doctest(doc) == doc


# Generated at 2022-06-23 15:32:50.083464
# Unit test for constructor of class Parser
def test_Parser():
    # Test with empty input
    p = Parser(None, None, None, None, None)
    assert p.toc is None
    assert p.link is None
    assert p.b_level == 0
    assert p.doc == {}
    assert p.docstring == {}
    assert p.alias == {}
    assert p.imp == {}
    assert p.level == {}
    assert p.root == {}
    assert p.const == {}
    # Test with input
    p = Parser(True, True, 1, {}, {})
    assert p.toc is True
    assert p.link is True
    assert p.b_level == 1
    assert p.doc == {}
    assert p.docstring == {}
    assert p.alias == {}
    assert p.imp == {}
    assert p.level == {}

# Generated at 2022-06-23 15:32:59.838381
# Unit test for method parse of class Parser
def test_Parser_parse():
    from annodoc.doc import Parser
    import ast

    parser = Parser()

    parser.parse(ast.parse("""
        """))

    parser.parse(ast.parse("""
        import os
        """))
    parser.parse(ast.parse("""
        from os import path
        """))
    parser.parse(ast.parse("""
        from os.path import abspath as p
        """))
    parser.parse(ast.parse("""
        from .os.path import abspath
        """))

    parser.parse(ast.parse("""
        import os as o
        """))
    parser.parse(ast.parse("""
        from os import path as p
        """))
    parser.parse(ast.parse("""
        from os.path import abspath as p
        """))
   

# Generated at 2022-06-23 15:33:07.185728
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from argparse import Namespace
    p = Parser(Namespace(toc=False))

# Generated at 2022-06-23 15:33:08.291117
# Unit test for method compile of class Parser
def test_Parser_compile():
    Parser().compile()

# Generated at 2022-06-23 15:33:12.160586
# Unit test for method parse of class Parser
def test_Parser_parse():
  p = Parser()
  @p.parse
  def _():
    return {'a': 'b'}
  assert p.doc == {'_': 'b'}


# Generated at 2022-06-23 15:33:23.237505
# Unit test for function const_type
def test_const_type():
    assert const_type(parse("True", mode='eval').body) == 'bool'
    assert const_type(parse("1", mode='eval').body) == 'int'
    assert const_type(parse("1.0", mode='eval').body) == 'float'
    assert const_type(parse("1j", mode='eval').body) == 'complex'
    assert const_type(parse("'a'", mode='eval').body) == 'str'
    assert const_type(parse("(1, 2)", mode='eval').body) == 'tuple[int, int]'
    assert const_type(parse("[1, 2]", mode='eval').body) == 'list[int, int]'
    assert const_type(parse("{1, 2}", mode='eval').body) == 'set[int, int]'

# Generated at 2022-06-23 15:33:28.918007
# Unit test for function is_magic
def test_is_magic():
    assert not is_magic("this is not a magic")
    assert not is_magic("this.is.not.a.magic")
    assert is_magic("__this_is_a_magic__")
    assert is_magic("this.is.a.__magic__")
    assert not is_magic("__this.is.not.a.magic__")



# Generated at 2022-06-23 15:33:37.590433
# Unit test for function code
def test_code():
    """Test function `code`."""
    assert code('\xa0') == ' '
    assert code('\xa0>>') == ' '
    assert code('\xa0>>=') == ' '
    assert code('\xa0|') == '&#124;'
    assert code('&amp;') == '<code>&amp;amp;</code>'
    assert code('&') == '<code>&amp;</code>'
    assert code('') == ' '
    assert code('\xa0>>') == ' '
    assert code('1') == '`1`'
    assert code('s') == '`s`'



# Generated at 2022-06-23 15:33:43.624961
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    m = Parser()
    assert m.const == {}
    assert m.doc == {}
    assert m.imp == {}
    assert m.root == {}
    assert m.alias == {}
    assert m.head == {}
    assert m.level == {}
    assert m.b_level == 0
    assert m.total == 0
    assert m.toc == True
    assert m.link == False
    assert m.docstring == {}

# Generated at 2022-06-23 15:33:48.540900
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    m = ModuleType('a.b')
    f = FunctionType(m, 'c', [], {"v": 42})
    e1 = Constant(42, None, None)
    e2 = Constant(42, None, None)
    assert repr(m) == "a.b"
    assert repr(f) == "a.b.c()"
    assert repr(e1) == "42"
    assert repr(e1) == repr(e2)

# Generated at 2022-06-23 15:33:58.910760
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    import sys
    import os
    import time
    import random
    import string
    import contextlib
    import tempfile
    import importlib.util
    import importlib.machinery
    import functools
    import itertools
    import shutil

    here = os.path.dirname(__file__)

    @contextlib.contextmanager
    def _tmpdir():
        with tempfile.TemporaryDirectory() as tmp:
            yield tmp, os.path.join(tmp, '__init__.py')

    def _tmpfile(src: str, name: str = '', suffix: str = SUFFIX,
                 encoding: str = ENCODING) -> str:
        with open(os.path.join(here, src), encoding=encoding) as f:
            body = f.read()

# Generated at 2022-06-23 15:34:04.273942
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    import enum
    class Enum(enum.Enum):
        AAA = enum.auto()
    parser = yield 0
    parser.globals('', Assign(targets=[Name(id='AAA', ctx=Store())], value=Constant(value=Enum)))
    yield parser.resolve('', Name(id='AAA', ctx=Load()))

# Generated at 2022-06-23 15:34:13.026718
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    p.imp[""] = set()
    p.root[""] = ""
    assert p.is_public("")
    p.imp[""] = set(["__all__"])
    assert p.is_public("")
    p.imp[""] = set()
    with pytest.raises(KeyError):
        p.is_public("a")
    p.root["a"] = ""
    assert p.is_public("a")
    p.imp[""] = set(["a"])
    assert p.is_public("a")
    p.imp[""] = set()
    assert not p.is_public("a.b")
    p.imp[""] = set(["a"])
    assert p.is_public("a.b")
    p.imp[""] = set

# Generated at 2022-06-23 15:34:22.154882
# Unit test for method imports of class Parser
def test_Parser_imports():
    assert Parser([]).imports("root", Import("six.moves")) == None
    assert Parser([]).imports("root", Import("six.moves", [alias("pathlib", None)]) ) == None
    assert Parser([]).imports("root", Import("six.moves", [alias("pathlib", "Path")]) ) == None
    assert Parser([]).imports("root", Import("six.moves", [alias("pathlib", "Path")]) ) == None
    assert Parser([]).imports("root", ImportFrom("six.moves", [alias("pathlib", "Path")], 0) ) == None
    assert Parser([]).imports("root", ImportFrom("six.moves", [alias("pathlib", "Path")], 1) ) == None

# Generated at 2022-06-23 15:34:28.293911
# Unit test for function const_type
def test_const_type():
    assert const_type(Subscript(value=parse(
        '["a", "b"]', mode='eval').body, slice=Index(value=parse(
            '0', mode='eval').body), ctx=Load())) == 'str'
    assert const_type(Tuple(elts=[])) == 'tuple'
    assert const_type(Tuple(elts=[Constant(value=1, kind=None),
                                  Constant(value=3, kind=None)])) == 'tuple[int, int]'
    assert const_type(List(elts=[])) == 'list'
    assert const_type(List(elts=[Constant(value=1, kind=None),
                                 Constant(value=3, kind=None)])) == 'list[int, int]'

# Generated at 2022-06-23 15:34:32.166197
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert Resolver(
        MY_GLOBAL, {_m(MY_GLOBAL, 'b'): 'a'}
    ).visit(Name('b', Load())) == Name('a', Load())



# Generated at 2022-06-23 15:34:40.692871
# Unit test for method globals of class Parser
def test_Parser_globals():
    p = Parser()
    root = 'A.B'
    node = _G('__all__ = []')
    p.globals(root, node)
    assert p.imp[root] == set()
    root = 'C'
    node = _G('__all__ = ["a", "b"]')
    p.globals(root, node)
    assert p.imp[root] == {'C.a', 'C.b'}
    root = 'C'
    node = _G('__all__ = ()')
    p.globals(root, node)
    assert p.imp[root] == set()

# Generated at 2022-06-23 15:34:46.404697
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    from io import StringIO
    from flake8.main import main as flake8_main
    from itertools import chain
    from typing import List, Tuple
    from typing_extensions import Literal
    from doc8.cli import main as cli_main
    from tests.utils import (
        assert_lines,
        assert_stderr,
        get_lines,
        should_raise,
    )

# Generated at 2022-06-23 15:34:54.639778
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    with open('test/test_parser.py') as f:
        p.parse(f.readlines())
    assert p.alias == {
        'test.A': 'test.B',
        'test.C': 'test.D',
        'test.func0': 'test.func1',
        'test.func2': 'test.func3',
        'test.Class0.F': 'test.Class1.G',
        'test.Class0.func4': 'test.Class1.func5'
    }

# Generated at 2022-06-23 15:34:58.674108
# Unit test for function walk_body
def test_walk_body():
    """Test body visit."""
    tree = parse(
        "def foo():\n"
        "    if True:\n"
        "        pass\n"
        "    elif 3:\n"
        "        if False:\n"
        "            return\n"
        "    else:\n"
        "        pass\n"
        "    pass\n",
        mode='exec',
    )
    body = cast(FunctionDef, tree.body[0]).body
    assert len(list(walk_body(body))) == 12



# Generated at 2022-06-23 15:35:11.457171
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    """Unit test for method func_ann of class Parser."""
    from ..parser import resolve
    from ..parser import F_SELF
    from ..parser import F_CLASS
    from ..parser import F_FLAGS

    def f(root, args, has_self=False, cls_method=False) -> List[str]:
        """Helper function."""
        p = Parser(link=False, toc=False)
        return list(p.func_ann(root, args, has_self=has_self, cls_method=cls_method))

    assert f('a', [arg('a', None)]) == [ANY]
    assert f('a', [arg('a', None)], has_self=False, cls_method=False) == [ANY]

# Generated at 2022-06-23 15:35:17.383345
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    """A simple unit test for method visit_Attribute of class Resolver.

    >>> import ast
    >>> r = Resolver("a", {})
    >>> ast.dump(r.visit_Attribute(ast.parse("typing.Dict[str, str]").body[0].value))
    'Name(id="Dict", ctx=Load())'
    """
    pass



# Generated at 2022-06-23 15:35:28.312763
# Unit test for function const_type
def test_const_type():
    assert const_type(Constant(1.0)) == 'float'
    assert const_type(Constant("str")) == 'str'
    assert const_type(Constant(False)) == 'bool'
    assert const_type(Constant(1)) == 'int'
    assert const_type(Constant(1j)) == 'complex'
    assert const_type(List(elts=[Constant(1.0), Constant(2.0)])) == 'list[float]'
    assert const_type(List(elts=[Constant(1.0), Constant(2j)])) == 'list[Any]'
    assert const_type(Tuple(elts=[Constant(1.0), Constant(2.0)])) == 'tuple[float]'

# Generated at 2022-06-23 15:35:39.681950
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser(name=None, link=False, toc=False)
    assert p.is_public('a.b')
    assert p.is_public('a.b.c')
    p.imp['a'] = {'b'}
    assert p.is_public('a.b')
    assert not p.is_public('a.b.c')
    assert not p.is_public('a.x')
    p.imp['a'].update({'b.c', 'b.d'})
    assert p.is_public('a.b')
    assert p.is_public('a.b.c')
    assert p.is_public('a.b.d')
    assert not p.is_public('a.b.d.e')

# Generated at 2022-06-23 15:35:46.519198
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    name = "Test"
    link = True
    toc = True
    level = 0
    self = Parser(name, link, toc, level)
    self.init_root(name)
    assert self.doc == {'Test': '**Table of contents:**', '__main__': ''}
    assert self.level == {'Test': 0}
    assert self.root == {'Test': 'Test', '__main__': '__main__'}
    assert self.imp == {'Test': set()}
    assert self.const == {}
    assert self.alias == {'Test': 'Test', '__main__': '__main__'}
    assert self.docstring == {}

# Generated at 2022-06-23 15:35:54.486508
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    """Test Resolver.visit_Constant

    >>> node = parse("3.14").body[0].value
    >>> assert Resolver("", dict()).visit_Constant(node) == node
    >>> node = parse("'3.14'").body[0].value
    >>> assert not isinstance(Resolver("", dict()).visit_Constant(node), str)
    >>> node = parse("'int'").body[0].value
    >>> assert isinstance(Resolver("", dict()).visit_Constant(node), Name)
    """
    pass

# Generated at 2022-06-23 15:36:06.828792
# Unit test for method compile of class Parser
def test_Parser_compile():
    """Test method compile of class Parser."""
    p = Parser(doc_link='/path/to/{name}.py')
    p.api('root', FunctionDef(arguments(args=[arg('a'), arg('b')], vararg='*c',
                                        kwonlyargs=[arg('d'), arg('e')],
                                        kwarg='**f'), 'func', [], [], []))
    p.docstring['root.func'] = "Test function."

# Generated at 2022-06-23 15:36:15.543902
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    from astroid import MANAGER
    from astroid.builder import AstroidBuilder
    from astroid.exceptions import AstroidBuildingError
    from pylint.pyreverse.utils import parse_python

    ast = parse_python('''
    # foo
    bar = 1
    class Foo:
        'foo'
        pass
    ''')
    ast2 = AstroidBuilder(MANAGER).string_build('''
    # foo
    bar = 1
    class Foo:
        'foo'
        pass
    ''')
    parser = Parser()
    parser.parse(ast)
    assert parser.parse(ast2) == parser



# Generated at 2022-06-23 15:36:27.414244
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    import sys
    from io import StringIO
    from typing import cast

    stream = StringIO()
    logger.add(stream, level='TRACE')

    def f(*a, **kw):
        return cast(FunctionDef, parse_expr(f.__name__ + str(a) + str(kw)))

    def t(*args):
        return [code(self.resolve('root', *a)) for a in args]

    p = Parser(link=True, toc=True)

# Generated at 2022-06-23 15:36:32.391150
# Unit test for method imports of class Parser
def test_Parser_imports():
    with open('./parser.py', 'r') as f:
        content = f.read()
    f = io.StringIO(content)
    tree = parse(f.read())
    root = ""
    node = tree.body[0]
    
    parser = Parser()
    parser.imports(root, node)
    assert parser.alias == {""}

# Generated at 2022-06-23 15:36:38.356857
# Unit test for function is_public_family
def test_is_public_family():  # noqa: D103
    assert is_public_family('python')
    assert not is_public_family('_python')
    assert not is_public_family('python._module')
    assert not is_public_family('python.__main__')
    assert not is_public_family('python.__main__._main')
    assert not is_public_family('python.module._main')
    assert not is_public_family('_python.module._main')
    assert not is_public_family('python._module._main')
    assert not is_public_family('python.module._main')



# Generated at 2022-06-23 15:36:43.899047
# Unit test for function parent
def test_parent():
    assert parent('a.b.c', level=1) == 'a.b'
    assert parent('a.b.c', level=2) == 'a'
    assert parent('a.b.c', level=3) == ''
    assert parent('a.b.c', level=4) == ''



# Generated at 2022-06-23 15:36:51.222888
# Unit test for function table
def test_table():
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == (
        '| a | b |\n'
        '|:---:|:---:|\n'
        '| c | d |\n'
        '| e | f |\n\n'
    )
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == (
        '| a | b |\n'
        '|:---:|:---:|\n'
        '| c | d |\n'
        '| e | f |\n\n'
    )



# Generated at 2022-06-23 15:36:52.989355
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    x = Parser()
    assert_eq(x == x, True)

# Generated at 2022-06-23 15:37:00.853937
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    """Test method load_docstring of class Parser"""
    with_docstring = dedent('''\
    # Module docstring
    ''')
    src_with_docstring = dedent('''\
    def foo():
        """Function docstring"""
    ''')

    without_docstring = dedent('''\
    def foo(): ...
    ''')

    load_src_without_docstring = dedent('''\
    class Foo:
        def foo(self):
            """Function docstring"""
    ''')
    src_without_docstring_load_with_docstring = dedent('''\
    class Foo:
        def bar(self):
            """Function docstring"""
    ''')

# Generated at 2022-06-23 15:37:05.727184
# Unit test for function const_type
def test_const_type():
    assert const_type(parse("5").body[0].value) == 'int'
    assert const_type(parse("5.5").body[0].value) == 'float'
    assert const_type(parse("5j").body[0].value) == 'complex'
    assert const_type(parse("'s'")
                      .body[0].value) == 'str'
    assert const_type(parse("True").body[0].value) == 'bool'
    assert const_type(parse("[5, 5.5]").body[0].value) == 'List[int, float]'
    assert const_type(parse("(5, 5.5)").body[0].value) == 'Tuple[int, float]'

# Generated at 2022-06-23 15:37:16.302699
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from ast import parse
    from ._compat import unicode

    p = Parser()
    parser = p.func_ann
    root = "m"
    s = unicode
    assert parser(root, [], has_self=False, cls_method=False) == (
        "int", "float")
    assert parser(root, [arg(self.arg, a.annotation)]) == ("int", "float")
    assert parser(root, [arg(".arg", a.annotation)]) == ("int", "float")
    assert parser(root, [arg("arg", a.annotation)]) == ("Self", "int", "float")
    assert parser(root, [arg("arg", a.annotation)], cls_method=True) == (
        "type[Self]", "int", "float")
   

# Generated at 2022-06-23 15:37:20.109730
# Unit test for constructor of class Parser
def test_Parser():
    """Test parser."""
    p = Parser()
    p.parse_file('tests/package/__init__.py')
    assert p.alias
    assert p.doc
    assert p.docstring
    assert p.const
    assert p.level


# Generated at 2022-06-23 15:37:28.200026
# Unit test for method visit_Subscript of class Resolver

# Generated at 2022-06-23 15:37:38.063219
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    class A:
        def f(self, i: int) -> int: pass
    a = A()
    assert Resolver('typing', {}, 'a').visit_Name(Name('a', Load())).id == 'Self'
    assert Resolver('typing', {}, 'a').visit_Name(Name('int', Load())).id == 'int'
    assert Resolver('typing', {}, 'a').visit_Name(Name('A', Load())).id == 'A'
    assert Resolver('typing', {}, 'a').visit_Name(Name('str', Load())).id == 'str'
    assert Resolver('typing', {}, 'a').visit_Name(Name('f', Load())).id == 'f'

# Generated at 2022-06-23 15:37:38.809642
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    pass

# Generated at 2022-06-23 15:37:42.166705
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    r = Resolver('test', {'test.self': 'Self'})
    assert(r.visit(Name('self', Load())) == Name('Self', Load()))

# Generated at 2022-06-23 15:37:52.818148
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    # Test code
    class C:
        a: int
        def b() -> None: ...
        def __init__(self) -> None: ...
    p = Parser()
    p.class_api(name=__name__ + '.C', root='', bases=[], body=ast(C))
    r = p.doc[__name__ + '.C']
    assert r.startswith('## class C\n\n*Full name:* `{}.C`'.format(__name__))
    assert "Members" in r
    assert "Enums" in r
    assert "a" in r
    assert "b" in r
    assert "__init__" in r
    assert "return" in r
    assert "Type" in r

# Generated at 2022-06-23 15:37:55.912265
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    a = ast.parse("typing.Optional[int]").body[0]
    ast.fix_missing_locations(a)
    visitor = Resolver('', {})
    assert "Optional[int]" == code(unparse(visitor.visit(a)))

# Generated at 2022-06-23 15:38:04.888083
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    from astor.code_gen import to_source
    from astor.codegen import Codegen
    import ast
    import inspect
    def check(args_src, returns_src, ann):
        args = ast.parse(to_source(args_src))
        returns = None if returns_src == "None" else ast.parse(to_source(returns_src))
        parser = Parser()
        parser.func_api("__main__", "__main__.foobar", args, returns, True, False)
        equ = __builtin__.all if ann == "" else __builtin__.assert_equal
        test_name = '' if ann == "" else '_' + ann

# Generated at 2022-06-23 15:38:17.668563
# Unit test for function walk_body
def test_walk_body():
    from .pep585 import PEP585
    from ast import parse
    from .logger import logger
    from .source import code

    @dataclass
    class ClassA:

        def fn_a(self) -> int:
            return 1

        def fn_b(self) -> int:
            if self.fn_a():
                return 0

        def fn_c(self) -> int:
            try:
                return 0
            except Exception:
                return 0
            finally:
                return 0

    @dataclass
    class SubClassA(ClassA):

        def fn_c(self) -> int:
            return super().fn_c()

        def fn_d(self):
            return 0

    def fn_d() -> int:
        if 1:
            return 0


# Generated at 2022-06-23 15:38:26.551035
# Unit test for method imports of class Parser
def test_Parser_imports():
    p = Parser()
    assert p.imp['__main__'] == {'print'}
    p.imports('__main__', Import(names=[alias('print', 'print')]))
    p.imports('__main__', ImportFrom('sys', names=[alias('exit', 'exit')],
                                     level=1))
    p.imports('__main__', ImportFrom('builtins', names=[alias('print', 'print')],
                                     level=1))
    assert p.alias['__main__.print'] == 'print'
    assert p.alias['__main__.exit'] == 'sys.exit'
    assert p.imp['__main__'] == {'print', 'exit'}
    assert p.imp['builtins'] == {'print'}

# Generated at 2022-06-23 15:38:32.650794
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    for n, c in p.imp.items():
        assert p.is_public(n)
    for n, c in p.const.items():
        assert p.is_public(n)
    for n, c in p.doc.items():
        assert p.is_public(n)



# Generated at 2022-06-23 15:38:45.253533
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    """Test for method load_docstring of class Parser"""
    import ast
    import doctest
    from types import ModuleType
    from typing import List, NoReturn
    from . import ast_

    _m = lambda n: n.replace('.', '_')
    _name = lambda n: ast.Name(id=n.replace('.', '_'), ctx=ast.Load())

    __all__ = ['Parent', 'Child']
    class Parent:
        """Parent class."""

        __all__ = ['ko']

        def one(self):
            """One"""

    def two() -> NoReturn:
        """Two"""

    class Child(Parent):
        """Child class."""

        def three(self) -> NoReturn:
            """Three"""

    p = ModuleType('p')
    p.Parent = Parent


# Generated at 2022-06-23 15:38:54.660992
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    import ast
    from . import doctest

    doctest.testmod()

    alias = {'a': 'b'}
    root = {'a': 'c'}
    level = {'a': 0}
    doc = {'a': 'd'}
    docstring = {'a': 'e'}
    const = {'a': 'f'}
    imp = {'a': {'a'}}
    self = Parser(ast, alias=alias, root=root, level=level, doc=doc,
                  docstring=docstring, const=const, imp=imp, toc=True,
                  link=False)

# Generated at 2022-06-23 15:39:05.061176
# Unit test for constructor of class Parser
def test_Parser():
    """Test for constructing Parser object."""
    import inspect
    from .canned_code import canned_code, canned_code_link
    parser = Parser(
        canned_code_link, link=True, toc=True, level=1, b_level=1)
    assert parser.link
    assert parser.toc
    assert parser.level == 1
    assert parser.b_level == 1
    assert parser.alias == {}
    assert parser.doc == {}
    assert parser.docstring == {}
    assert parser.root == {}
    assert parser.level == {}
    assert parser.imp == {}
    assert parser.const == {}
    parser = Parser(inspect.getmodule(test_Parser).__doc__)
    assert not parser.link
    assert not parser.toc
    assert parser.level == 0

# Generated at 2022-06-23 15:39:07.753543
# Unit test for function doctest
def test_doctest():
    assert doctest(">>> print('test')") == "```python\n>>> print('test')\n```"
    assert doctest(">>> print('test')\ntest") == "```python\n>>> print('test')\n```\ntest"



# Generated at 2022-06-23 15:39:16.623444
# Unit test for method api of class Parser
def test_Parser_api():
    from dataclasses import dataclass
    from typing import List, Dict, Callable
    from typing import cast as type_cast
    from typing_inspect import get_origin
    import pytest
    from asttools import get_ast, ast_equal
    
    class ClassFromTyping(Callable):
        """A class defined with typing."""
    
    
    def func(a, *args, kw1=None, kw2=None, **kwargs) -> bool:
        """A function defined with typing."""
        return True
    
    
    def test_func(parser: Parser) -> None:
        """Test for function."""
        node = type_cast(FunctionDef, get_ast(func).body[0])
        parser.api('', node)
        result = parser.doc['']
       

# Generated at 2022-06-23 15:39:26.963898
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    n = Subscript(Name('Union', Load()), Tuple(elts=[
        Name('int', Load()), Name('float', Load())],
        ctx=Load()), Load())
    assert unparse(Resolver('', {}).visit(n)) == \
           'Union[int, float]'

    n = Subscript(Name('Union', Load()),
                  Tuple(elts=[Name('int', Load())], ctx=Load()), Load())
    assert unparse(Resolver('', {}).visit(n)) == \
           'int'

    n = Subscript(Name('Optional', Load()), Name('int', Load()), Load())
    assert unparse(Resolver('', {}).visit(n)) == \
           'Union[int, None]'


# Generated at 2022-06-23 15:39:28.128081
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    obj = Parser()
    repr(obj)


# Generated at 2022-06-23 15:39:30.429618
# Unit test for function table
def test_table():
    """Test for table function."""
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == table(
        'a', 'b', ['c', 'd'], ['e', 'f']
    )



# Generated at 2022-06-23 15:39:42.163635
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from . import _test as test
    from . import _api as api

    pr = Parser(True, False, False)
    pr.doc[test.__name__] = "*Full name:* `{}`\n\nFOO\n"
    pr.load_docstring(test.__name__, test)
    assert 'FOO' in pr.doc[test.__name__]
    assert 'BAR' in pr.doc[test.__name__]

    pr = Parser(True, False, False)
    pr.load_docstring(api.__name__, api)
    assert 'FOO' in pr.doc[api.__name__]
    assert 'API' in pr.doc[api.__name__]



# Generated at 2022-06-23 15:39:52.830251
# Unit test for method func_ann of class Parser

# Generated at 2022-06-23 15:39:57.525039
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    if not os.path.exists(os.path.join(os.path.dirname(__file__), 'typing.py')):
        pytest.skip()
    root = "typing"
    m = importlib.import_module(root)
    p = Parser(f"../typeshed/stdlib/{root}/",
               link="https://github.com/python/typeshed/blob/master/stdlib/",
               out=None)
    p.doc[root] = 'root = {}\n\n'.format(root)
    p.docstring[root] = 'docstring = {}\n\n'.format(root)
    p.load_docstring(root, m)
    assert p.docstring[root].strip() == 'This module exports Type.get_origin(): type.'  #

# Generated at 2022-06-23 15:40:08.464755
# Unit test for method api of class Parser
def test_Parser_api():
    from typing import Tuple, List

    from py_gql.lang import ast as _ast
    from py_gql.validation.rules import NoUnusedFragmentsChecker
    from py_gql.validation import validate_ast, ValidationResult
    from py_gql.utils import Source
    from py_gql.schema import (
        Schema,
        EnumType,
        Field,
        Argument,
        ObjectType,
        InputObjectType,
        InputField,
        SchemaMetaField,
        TypeMetaField,
        TypeNameMetaField,
    )

    ASTNode = _ast.ASTNode
    SelectionSet = _ast.SelectionSet


    class Query(ObjectType):

        foo = Field(bool)

        bar = Field(bool, resolver=lambda obj, info: None)  #