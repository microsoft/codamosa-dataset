

# Generated at 2022-06-23 15:30:13.224299
# Unit test for function walk_body
def test_walk_body():
    """Test walk_body function."""

# Generated at 2022-06-23 15:30:20.330779
# Unit test for function doctest
def test_doctest():
    doc = """Python test.

    >>> import sys
    >>> print(sys.version)
    """
    assert unparse(parse(doc.replace('>>> ', ''))).replace('\n', ' ').strip() == \
        "import sys print ( sys.version )"
    assert doctest(doc).replace('\n', ' ').strip() == \
        "Python test. ```python import sys print(sys.version) ```"
test_doctest()



# Generated at 2022-06-23 15:30:29.940164
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    root = 'tests.test_doc'
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), root.replace('.', os.sep), '__init__.py')
    m = ModuleSpec('tests.test_doc', loader=spec_from_file_location('tests.test_doc', path))
    Parser.load_docstring(root, m.loader.load_module())
## Parse dot file for tree visualization
dot_tree: Callable[[str, AST], Dict[int, Tuple[str, List[int]]]] = partial(
    parse_dotfile, node_name=lambda n: f"{n.__class__.__module__}.{n.__class__.__qualname__}")

## Generate the dot file

# Generated at 2022-06-23 15:30:34.608987
# Unit test for function parent
def test_parent():
    assert parent('name') == ''
    assert parent('name.a') == 'name'
    assert parent('name.a.b') == 'name.a'
    assert parent('name.a.b', level=2) == 'name'
test_parent()



# Generated at 2022-06-23 15:30:45.310274
# Unit test for function doctest
def test_doctest():
    assert doctest("") == ""
    assert doctest(">>> test") == "```python\n>>> test\n```"
    assert doctest(">>> test\n>>> test") == "```python\n>>> test\n>>> test\n```"
    assert doctest(">>> test\n\n>>> test") == "```python\n>>> test\n```\n\n```python\n>>> test\n```"
    assert doctest(">>> test\n\n>>> test\n\n>>> test") == "```python\n>>> test\n>>> test\n>>> test\n```"

# Generated at 2022-06-23 15:30:50.524642
# Unit test for function walk_body
def test_walk_body():
    b = parse("""
if foo:
    def bar(a):
        try:
            baz()
        except FooError:
            b
except BarError:
    c
else:
    d
finally:
    e
""").body[0].body
    assert len(list(b)) == 6
    assert len(list(walk_body(b))) == 9



# Generated at 2022-06-23 15:30:57.958539
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    cp = Parser(link=False)

# Generated at 2022-06-23 15:31:01.710399
# Unit test for function is_magic
def test_is_magic():
    """Test for checking magic name."""
    assert is_magic('__magic__') is True
    assert is_magic('__magic_') is False
    assert is_magic('_magic__') is False
    assert is_magic('_magic_') is False
    assert is_magic('hello') is False
    assert is_magic('hello.hello') is False
    assert is_magic('hello.__magic__') is True
    assert is_magic('hello.__magic_') is False
    assert is_magic('hello._magic__') is False
    assert is_magic('hello._magic_') is False



# Generated at 2022-06-23 15:31:13.903189
# Unit test for function walk_body
def test_walk_body():
    @dataclass(frozen=True)
    class Node:
        body: Sequence[stmt] = field(default_factory=list)

    expr1 = parse("a = 1\na = 2")
    expr2 = parse("a = 1\npass")
    assert list(expr1.body) == [Assign([Name(id="a", ctx=Store())], Constant(value=1, kind=None), lineno=1, col_offset=0), Assign([Name(id="a", ctx=Store())], Constant(value=2, kind=None), lineno=2, col_offset=0)]

# Generated at 2022-06-23 15:31:17.319086
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    assert p.is_public('a.__b') == False
    assert p.is_public('a.__b__') == True



# Generated at 2022-06-23 15:31:20.820038
# Unit test for constructor of class Resolver
def test_Resolver():
    """Test for constructor of class Resolver."""
    _ = Resolver("test", {})
    assert _m("test", "a") == "test.a"
    assert _attr(_, "_visit_Constant")



# Generated at 2022-06-23 15:31:26.196294
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    root = "test"
    alias = {"typing": "typing"}
    self_ty = "self"
    node = Attribute(Name("typing", Load()), "Any", Load())
    resolver = Resolver(root, alias, self_ty)
    resolver.visit_Attribute(node)



# Generated at 2022-06-23 15:31:32.008305
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
  """Test for Resolver.visit_Name"""
  import sys
  import ast
  import os
  directory = os.path.dirname(os.path.abspath(__file__))
  sys.path.insert(0, directory + '/../')
  TestResolver = __import__('test_markdown').TestResolver
  TestResolver.test_Resolver_visit_Name()


# Generated at 2022-06-23 15:31:33.682017
# Unit test for constructor of class Resolver
def test_Resolver():
    """Constructor of class Resolver."""
    assert str(Resolver("", {}).visit(parse("import typing"))) == "import typing"



# Generated at 2022-06-23 15:31:40.657095
# Unit test for function walk_body
def test_walk_body():
    def _test(text: str, *result: str) -> None:
        print(text)
        n = parse(text).body
        assert all(code(unparse(i)) == r for i, r in zip(walk_body(n), result))
    _test("""
            if True:
                a = 0
            else:
                a = 1
        """, "a = 0", "a = 1")
    _test("""
            if True:
                if True:
                    a = 0
                else:
                    a = 1
            else:
                if True:
                    a = 2
                else:
                    a = 3
        """, "a = 0", "a = 1", "a = 2", "a = 3")

# Generated at 2022-06-23 15:31:48.771142
# Unit test for method compile of class Parser
def test_Parser_compile():
    s = """import typing
from typing import Type, Any, Union, Sequence, Iterable, Iterator
from typing import Tuple, List, Dict, Set

import types
from types import MappingProxyType, SimpleNamespace

"""

# Generated at 2022-06-23 15:31:52.537670
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__a__')
    assert is_magic('__a__.b')
    assert is_magic('a.__b__')
    assert not is_magic('a__b')
    assert not is_magic('a.b')
test_is_magic()



# Generated at 2022-06-23 15:31:56.574146
# Unit test for function code
def test_code():
    assert code("|") == "&#124;"
    assert code("example") == "&#96;example&#96;"
    assert code("") == " "
    assert code("&") == "&lt;code&gt;&amp;&lt;/code&gt;"

# Generated at 2022-06-23 15:32:03.542851
# Unit test for function doctest
def test_doctest():
    doc = """
    hello world

    >>> 4 + 5
    9
    >>> 6 + 2
    8
    """
    expect = """
    hello world

    ```python
    >>> 4 + 5
    9
    ```python
    >>> 6 + 2
    8
    """
    assert doctest(doc) == expect
    doc = """
    hello world

    >>> 4 + 5
    9
    >>> 9 - 2
    7
    """
    expect = """
    hello world

    ```python
    >>> 4 + 5
    9
    >>> 9 - 2
    7
    ```
    """
    assert doctest(doc) == expect



# Generated at 2022-06-23 15:32:15.695843
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    if __name__ != '__main__':
        import pytest
        pytest.skip()
    from .test_docs import get_data
    from .lang import parse_doc
    from .pycharm_api import PycharmApi

    def make_method(text: str, *, lineno: int):
        node = parse(text).body[0]
        assert isinstance(node, FunctionDef)
        return Method(node, Resolver(
            get_data('root.py'),
            PycharmApi(get_data('root.py')).get_alias(),
            self_ty=""
        ), False, lineno)

    u = make_method("def union(a: typing.Union[int, float]): pass",
                    lineno=1).annotation

# Generated at 2022-06-23 15:32:18.535879
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__init__')
    assert not is_magic('_init')
    assert not is_magic('__init')
    assert not is_magic('foo')



# Generated at 2022-06-23 15:32:19.564846
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    assert True



# Generated at 2022-06-23 15:32:29.700020
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    """Test for func_ann."""
    p = Parser(0, (), "", (), (), (), (), None)
    assert (list(p.func_ann("root", [
        arg("", None),
        arg("*args", argument(None, None)),
        arg("**kwargs", argument(None, None)),
        arg("return", None),
        ])) == [
        ANY,
        "",
        "",
        ANY,
        ])
    assert (list(p.func_ann("root", [
        arg("*args", argument(None, None)),
        arg("*", None),
        arg("**kwargs", argument(None, None)),
        arg("return", None),
        ])) == [
        "",
        "",
        "",
        ANY,
        ])

# Generated at 2022-06-23 15:32:37.865027
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    r = Resolver("", {})
    assert str(r.visit_Constant(Constant("a", None))) == "a"
    assert str(r.visit_Constant(Constant("int", None))) == "int"
    assert str(r.visit_Constant(Constant("int(1)", None))) == "int"
    assert str(r.visit_Constant(Constant("str.strip", None))) == "str.strip"
    assert str(r.visit_Constant(Constant("a.b", None))) == "a.b"
    assert str(r.visit_Constant(Constant("a[1]", None))) == "a[1]"
    assert str(r.visit_Constant(Constant("a(1)", None))) == "a(1)"
# Unit

# Generated at 2022-06-23 15:32:47.463835
# Unit test for method api of class Parser
def test_Parser_api():
    parser = Parser()

# Generated at 2022-06-23 15:32:52.813231
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    parser = Parser()
    parser.doc = {'ns1.ns2.a': '', 'ns1.a': '', 'a': ''}
    parser.root = {'ns1.ns2.a': 'ns1.ns2', 'ns1.a': 'ns1', 'a': ''}
    parser.level = {'ns1.ns2.a': 3, 'ns1.a': 2, 'a': 1}
    parser.imp = {'ns1': {'ns1.a'}, '': {'a'}}
    parser.alias = {'ns1.a': 'ns1.ns2.a', 'a': 'ns1.ns2.a'}
    parser.const = {'ns1.ns2.a': ''}
    parser.__post_init__(1, True)

# Generated at 2022-06-23 15:32:53.339700
# Unit test for method resolve of class Parser

# Generated at 2022-06-23 15:33:03.282404
# Unit test for function const_type
def test_const_type():
    assert const_type(Constant(None)) == "NoneType"
    assert const_type(Constant(bool)) == "bool"
    assert const_type(Constant(int)) == "int"
    assert const_type(Constant(float)) == "float"
    assert const_type(Constant(complex)) == "complex"
    assert const_type(Constant(str)) == "str"
    assert const_type(Constant(list)) == "list"
    assert const_type(Constant(tuple)) == "tuple"
    assert const_type(Constant(set)) == "set"
    assert const_type(Constant(dict)) == "dict"
    assert const_type(Name(id='bytes', ctx=Load())) == 'bytes'



# Generated at 2022-06-23 15:33:08.850735
# Unit test for function const_type
def test_const_type():
    const_type(Constant(type=None, value=True))
    const_type(Constant(type=None, value=''))
    const_type(Constant(type=None, value=[]))
    const_type(Constant(type=None, value={}))
    const_type(Constant(type=None, value=(1, 2)))
    const_type(Constant(type=None, value=([])))
    const_type(Call(func=Name(id='bool', ctx=Load()), args=[], keywords=[], starargs=None, kwargs=None))
    const_type(Call(func=Name(id='bool', ctx=Load()), args=[Constant(type=None, value='')], keywords=[], starargs=None, kwargs=None))

# Generated at 2022-06-23 15:33:15.418659
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert Resolver('', {}).visit_Attribute(
        Attribute(Name('typing', Load()),'Optional', Load()),
    ) == Name('Optional', Load())


NAMED_TYPES = {
    'int': 'int',
    'str': 'str',
    'bool': 'bool',
    'Any': 'Any',
}

_S = TypeVar("_S", bound="Scope")


# Generated at 2022-06-23 15:33:18.127976
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    with catch:
        f = StringIO()
        with redirect_stdout(f):
            print(Parser())
        assert f.getvalue() == 'Parser(alias={}, toc=True)\n'

# Generated at 2022-06-23 15:33:21.844793
# Unit test for function doctest
def test_doctest():
    doc = '''
    >>> print(1)
    1
    '''
    assert doctest(doc) == '''
    ```python
    >>> print(1)
    1
    ```
    '''



# Generated at 2022-06-23 15:33:32.194358
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    parser = Parser()
    parser.alias['A.B'] = 'T.T'
    parser.alias['B.T'] = 'T.T'
    assert parser.resolve('', parse('A.B')) == 'T.T'
    assert parser.resolve('', parse('B.T')) == 'T.T'
    assert parser.resolve('', parse('T.T')) == 'T.T'
    assert parser.resolve('', parse('T.T.T')) == 'T.T.T'
    assert parser.resolve('', parse('T')) == 'T'
    assert parser.resolve('', parse('A.B[C.D]')) == 'T.T[C.D]'

# Generated at 2022-06-23 15:33:42.434333
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(pathlib.Path('test') / 'test_Parser.py')
    assert parser.alias == {
        'utils.pathlib.Path': 'pathlib.Path'
    }
    assert parser.const == {
        'test_Parser.A': 'int',
        'test_Parser.B': 'str'
    }

# Generated at 2022-06-23 15:33:50.563067
# Unit test for constructor of class Parser
def test_Parser():
    """Test Parser."""
    assert Parser([Path('test1.py')], False)
    assert Parser(['test1.py'], False)
    assert Parser(Path('test1.py'), False)
    assert Parser('test1.py', False)
    assert Parser([Path('test1.py'), Path('test2.py')], False)
    assert Parser(['test1.py', 'test2.py'], False)
    assert Parser(['test1.py', 'test2.py', 'test3.py'], True)
    assert Parser(['test1.py', 'test2.py', 'test3.py'], False)
    with pytest.raises(ValueError):
        Parser(Path('test1.py'), True)

# Generated at 2022-06-23 15:34:00.305237
# Unit test for function walk_body

# Generated at 2022-06-23 15:34:08.845677
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    """test_Parser_resolve"""
    parser = Parser()
    parser.alias = {
        'a.b': 'b.c',
        'b.c': 'int',
        'b': 'a.b.c',
        'a.b.c': 'b.c'
    }
    ast_node = parse('a.b.c + b + d[int] + e', filename='<test>')
    result = parser.resolve('', ast_node.body[0].value)
    assert result == 'a.b.c.c + b.c + d[int] + e'



# Generated at 2022-06-23 15:34:09.538366
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    pass



# Generated at 2022-06-23 15:34:14.535568
# Unit test for constructor of class Parser
def test_Parser():
    @dataclass
    class Parser_Test(Parser):
        link: bool = False
        b_level: int = -1
        toc: bool = False
    test_expect = Parser_Test()
    assert test_expect.link == False
    assert test_expect.b_level == -1
    assert test_expect.toc == False


# Generated at 2022-06-23 15:34:15.876302
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    assert Parser() == Parser()


# Generated at 2022-06-23 15:34:23.654014
# Unit test for method resolve of class Parser

# Generated at 2022-06-23 15:34:31.604610
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore('_') == r'\_'
    assert esc_underscore('__') == r'\_\_'
    assert esc_underscore('_apple') == r'\_apple'
    assert esc_underscore('apple_') == r'apple\_'
    assert esc_underscore('apple_banana') == r'apple\_banana'
    assert esc_underscore('_apple_banana_') == r'\_apple\_banana\_'
    assert esc_underscore('apple') == r'apple'



# Generated at 2022-06-23 15:34:33.370080
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__init__.py')
    assert not is_magic('__version__')



# Generated at 2022-06-23 15:34:43.305751
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    """Unit test for method is_public of class Parser"""
    import builtins

    with patch('builtins.__import__', create=True) as mock_module:
        with patch.object(Parser, 'load_docstring') as mock_load:
            mock_module.return_value = mock_load
            p = Parser(['mymodule'])
            assert p.is_public("mymodule") is True
            assert p.is_public("mymodule.a") is False
            assert p.is_public("mymodule.b") is True
            assert p.is_public("mymodule.c") is False
            assert p.is_public("mymodule.d.e") is True
            assert p.is_public("mymodule.d.f") is False
            assert p.is_public("mymodule.g.h")

# Generated at 2022-06-23 15:34:46.445871
# Unit test for function parent
def test_parent():
    assert parent('a.b.c') == 'a.b'
    assert parent('a.b.c', level=2) == 'a'
    assert parent('a.b.c', level=3) == 'a.b.c'



# Generated at 2022-06-23 15:34:54.491368
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    from ast import Module

    from . import parse_code

    p = Parser()
    r = parse_code("""
        def g(x: int) -> int:
            return x
        def f(x: IO[int]) -> IO[int]:
            return g(x)
        """).body
    assert p.resolve('', r[1].args.args[0].annotation) == 'IO[int]'
    root = 'a.b'
    m = parse_code("""
        import typing
        class A:
            b: int
            def f(self, x: int) -> int:
                return x
        def f(self, x: A) -> A:
            return x
        def g(self, x: typing.List[int]) -> typing.List[int]:
            return x
        """)

# Generated at 2022-06-23 15:34:58.526073
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    p = Parser()
    assert p.b_level == 0
    assert p.link is False
    assert p.toc is True
    assert p.docstring == {}
    assert p.doc == {}
    assert p.const == {}
    assert p.imp == {}
    assert p.alias == {}
    assert p.root == {}
    assert p.level == {}
test_Parser___post_init__()

# Generated at 2022-06-23 15:35:03.105906
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser(None, None, None)
    p.doc = {'a.b': "", 'a.c': ""}
    assert p.doc['a.b'] == ""
    assert p.doc['a.c'] == ""
    p.alias['a.b'] = 'aaa'
    p.func_ann('aaa', [arg('arg', None), arg('return', NameConstant(True))], has_self=True, cls_method=True)
    assert p.doc['a.b'] == "type[Self], str\n"
    assert p.doc['a.c'] == ""

# Generated at 2022-06-23 15:35:07.649833
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert Resolver('', {'a': 'b'}).visit_Name(Name('a', Load())) == Name('b', Load())
    assert Resolver('', {'a': 'b'}).visit_Name(Name('c', Load())) == Name('c', Load())

# Generated at 2022-06-23 15:35:17.017226
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    @dataclass
    class Dummy:
        root: str = ''
        alias: dict[str, str] = field(default_factory=dict)
        self_ty: str = ''


# Generated at 2022-06-23 15:35:28.040988
# Unit test for method parse of class Parser
def test_Parser_parse():
    """Test method parse of class Parser."""
    source = ""
    parser = Parser()
    parser.parse(source, code=True) == ''
    source = "a"
    parser = Parser()
    parser.parse(source, code=True) == '`a`'
    source = "a()"
    parser = Parser()
    parser.parse(source, code=True) == '`a()`'
    source = "a[1]"
    parser = Parser()
    parser.parse(source, code=True) == '`a[1]`'
    source = "a().b"
    parser = Parser()
    parser.parse(source, code=True) == '`a().b`'
    source = "a()[b][c.d]"
    parser = Parser()
   

# Generated at 2022-06-23 15:35:33.832228
# Unit test for function table
def test_table():
    test = table('a', 'b', [
        ['c', 'd'],
        ['e', 'f']
    ])
    assert test == '''| a | b |
|:---:|:---:|
| c | d |
| e | f |

'''



# Generated at 2022-06-23 15:35:39.334583
# Unit test for function walk_body
def test_walk_body():
    source = """
if 1:
    a = b
    if 2:
        c = d
else:
    e = f
try:
    g = h
except I:
    i = j
else:
    k = l
    try:
        m = n
    finally:
        o = p
"""
    assert len(tuple(walk_body(parse(source).body))) == 14

# Generated at 2022-06-23 15:35:47.384046
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("abc_xyz") == "abc_xyz"
    assert esc_underscore("_xyz") == "_xyz"
    assert esc_underscore("xyz_") == "xyz_"
    assert esc_underscore("xyz_123") == r"xyz\_123"
    assert esc_underscore("xyz_123_abc") == r"xyz\_123\_abc"
    assert esc_underscore("a") == "a"
    assert esc_underscore("") == ""



# Generated at 2022-06-23 15:35:58.508191
# Unit test for function walk_body
def test_walk_body():
    ast: AST = parse("""
if True:
    a = 1
    if False:
        a = 2
else:
    a = 3
try:
    a = 4
except Exception as e:
    a = 5
    pass
    if False:
        pass
    else:
        a = 6
finally:
    a = 7
if True:
    pass
    if False:
        pass
    else:
        a = 8
    if False:
        pass
    else:
        a = 9
else:
    a = 10
    if False:
        pass
    else:
        a = 11
    pass
    if False:
        pass
    else:
        a = 12
""")
    walk = list(walk_body(ast.body))

# Generated at 2022-06-23 15:36:06.330441
# Unit test for function doctest
def test_doctest():
    d = """
    >>> test_doctest() == "\\\n    >>> test_doctest() == ''\\\n    True\\\n    ''"
    True
    """
    assert doctest(d) == '''
    ```python
    >>> test_doctest() == "\\\n    >>> test_doctest() == ''\\\n    True\\\n    ''"
    True
    ```
    '''
test_doctest()



# Generated at 2022-06-23 15:36:16.204071
# Unit test for method api of class Parser
def test_Parser_api():
    from typing import List, Tuple
    from mypy.node import Node
    from mypy.parser import parse
    from mypy.traverser import Traverser
    def get_node(module: str) -> Node:
        node = parse(module, "test_Parser_api")
        assert node is not None, "unable to parse mypy.parser itself"
        return node
    def get_body(node: Node) -> List[Node]:
        class GetBodyTraverser(Traverser):
            def __init__(self):
                self.body: List[Node] = []
            def visit_func_def(self, node: Node) -> None:
                self.body.extend(node.body)

# Generated at 2022-06-23 15:36:20.026208
# Unit test for constructor of class Parser
def test_Parser():
    """pdoc.Parser"""
    p = Parser(b_level=3)
    assert p._b_level == 3

    p = Parser()
    assert p._b_level == 2


# Generated at 2022-06-23 15:36:25.808630
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    from importlib import reload
    from pathlib import Path
    from typing import IO
    from io import StringIO
    from typing import Type
    from dendroid import Parser
    Parser1 = Parser
    reload(Parser)
    p = Parser([])
    assert p.__repr__() == 'Parser([] : List[str])'

# Generated at 2022-06-23 15:36:35.735862
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    from typing import Optional, Callable, List
    from astroid import parse
    code = inspect.cleandoc("""
    class A:
        a: int
        def __init__(self, x: int):
            self.x: int = x
        def a(self) -> str:
            return 'A'
        def b(self) -> str:
            return self.a()
        def c(self) -> str:
            return A.a(self)
        @classmethod
        def d(cls) -> str:
            return cls.a(cls())
        @staticmethod
        def e() -> str:
            return 'static'
        @staticmethod
        def f(x: int) -> str:
            return 'static'
    """)
    module = parse(code)

# Generated at 2022-06-23 15:36:48.685517
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from pathlib import Path
    import inspect
    import doctest
    import importlib
    import builtins
    path = Path(__file__).parent
    path = path.joinpath(path.relative_to(Path.cwd()))
    doc = []
    for root, dirs, files in os.walk(path):
        if '__pycache__' in dirs:
            dirs.remove('__pycache__')
        for f in files:
            if not f.endswith('.py'):
                continue
            m = importlib.import_module('.'.join(
                path.relative_to(path.parent).parts + [f.rsplit('.', 1)[0]]))
            for n in dir(m):
                if n.startswith('_'):
                    continue
                ty = _

# Generated at 2022-06-23 15:36:59.104636
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    import ast

    parser = Parser(None)
    assert parser.class_api(
        "Root", "", [ast.parse("Base()").body[0].value],
        [ast.parse("def func(self): ...").body[0]]
    ) == """
    ## class_api-1
    .. table:: Summary
        :header-rows: 1

        * Bases
        * Base()

        * Members
        * func()
        * type[:func:`~Root.class_api-1.func`]
    """.strip().lstrip("\n")

# Generated at 2022-06-23 15:37:06.658509
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("_") == r"\_"
    assert esc_underscore("__") == r"\_\_"
    assert esc_underscore("_a_") == r"\_a\_"
    assert esc_underscore("__a__") == r"\_\_a\_\_"
    assert esc_underscore("_a") == r"\_a"
    assert esc_underscore("a_") == r"a\_"
    assert esc_underscore("a") == r"a"
    assert esc_underscore("a_b") == r"a\_b"



# Generated at 2022-06-23 15:37:09.389124
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'Callable', Load())).id == 'Callable'


# Generated at 2022-06-23 15:37:15.948719
# Unit test for function parent
def test_parent():
    assert parent('') == ''
    assert parent('a') == ''
    assert parent('a.b') == 'a'
    assert parent('a.b', level=2) == ''
    assert parent('a.b.c', level=2) == 'a.b'
    assert parent('a.b.c', level=3) == ''
    assert parent('a.b.c', level=4) == ''
test_parent()



# Generated at 2022-06-23 15:37:25.787019
# Unit test for method api of class Parser
def test_Parser_api():
    parser = Parser()
    parser.api('', _G(FunctionDef('f', _I(arguments(args=[arg('a', None)])), [], [], [])))
    assert parser.doc['f'] == '# f()\n\n*Full name:* `f`\n\n**Parameters:**\n\n|a|\n|-|\n|`Any`|\n\n**Returns:**\n\n|None|\n|-|\n|`None`|\n'
    parser = Parser()
    parser.api('', _G(FunctionDef('f', _I(arguments(args=[arg('a', None)], vararg=arg('*b', None))), [], [], [])))

# Generated at 2022-06-23 15:37:33.096316
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    """Unit test for method load_docstring of class Parser"""
    m = _mock_module(__name__)
    p = Parser(m)
    p.load_docstring(__name__, m)
    assert p.docstring[__name__] == "This module is a mock module."
    assert p.docstring[f'{__name__}.Foo'] == "A class."



# Generated at 2022-06-23 15:37:40.577664
# Unit test for method api of class Parser
def test_Parser_api():
    parser = Parser()
    root = "a.b"
    parser.api(root, FunctionDef(name="f", args=arguments(args=[])))
    assert parser.doc['a.b.f'] == '''# f()

*Full name:* `a.b.f`

Arguments \\| Type
--- | ---
return | Any
'''
    parser.api(root, ClassDef(name='C', bases=[]))
    assert parser.doc['a.b.C'] == '''# class C

*Full name:* `a.b.C`

Members \\| Type
--- | ---
'''
    parser.api(root, AsyncFunctionDef(name="f", args=arguments(args=[])))

# Generated at 2022-06-23 15:37:45.543780
# Unit test for function code
def test_code():
    assert code('') == ' '
    assert code('|') == '&#124;'
    assert code('<>') == '<code>&lt;&gt;</code>'
    assert code('<>') == '<code>&lt;&gt;</code>'



# Generated at 2022-06-23 15:37:55.529371
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    items = [
        ('_a', False),
        ('A', True),
        ('A.B', True),
        ('A.B.C', True),
        ('a', True),
        ('a.B', False),
        ('A.b', True),
        ('A.B.c', True),
        ('a.b', True),
        ('a.B.C', False),
        ('A.b.C', False),
        ('a.b.c', False),
        ('a.b.C', False)
    ]
    Parser = type('Parser', (Parser,), {})
    parser = Parser(root=Path(), found=set(), link=True, toc=True, b_level=0)

# Generated at 2022-06-23 15:38:04.710568
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    """Run a unit test for method is_public of class Parser."""
    def key(s: str = "") -> str:
        """Hashing key."""
        return "".join(sorted(s))
    p = Parser()
    p.imp = {'alias': {'alias.__all__': {'alias.foo', 'alias.bar'}},
             'alias.foo': {'alias.foo.__all__': {'alias.foo.foo', 'alias.foo.bar'}},
             'alias.foo.foo': set(),
             'alias.foo.bar': set(),
             'alias.bar': set()}

# Generated at 2022-06-23 15:38:11.786620
# Unit test for function const_type
def test_const_type():
    module_path = 'sisl.api'
    module_name = module_path.split('.')[-1]
    source = getdoc(cast(ModuleType, __import__(module_path, fromlist=module_name)))
    source = source[:source.find('\n\nAPI\n===')]
    exec(source, globals())
test_const_type()



# Generated at 2022-06-23 15:38:15.073693
# Unit test for function table
def test_table():
    """Table test."""
    if len(table('a', 'b', ['c', 'd'], ['e', 'f'])) < 100:
        raise ValueError()



# Generated at 2022-06-23 15:38:25.318777
# Unit test for method compile of class Parser
def test_Parser_compile():
    """
    Test if Parser method compile work well
    """

# Generated at 2022-06-23 15:38:28.305226
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    # Literal node
    node = Constant('test')
    assert Resolver(root='test',alias={}).visit(node) is node


# Generated at 2022-06-23 15:38:40.597548
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    m = "def _private(): pass\n"
    m += "def __special(): pass\n"
    m += "class _C: pass\n"
    m += "class __D: pass\n"
    m += "def public(): pass\n"
    m += "class E: pass\n"

    p = Parser(alias="_", constants=True)
    for node in parse(m).body:
        if isinstance(node, (FunctionDef, ClassDef)):
            p.api('', node)
    assert p.is_public('E')
    assert not p.is_public('_C')
    assert not p.is_public('__D')
    assert p.is_public('public')
    assert not p.is_public('_private')

# Generated at 2022-06-23 15:38:45.617135
# Unit test for function code
def test_code():
    assert code("a<b") == "<code>a&lt;b</code>"
    assert code("a|b") == "<code>a&#124;b</code>"
    assert code("a>b") == "`a>b`"
    assert code("") == " "



# Generated at 2022-06-23 15:38:54.950261
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    # Test method with quickdocs-test/test/test_function.py
    with pathlib.Path('quickdocs-test/test/test_function.py').open(encoding='utf-8') as f:
        test_function = f.read()
    # Evaluate test_function, so the code is not executed
    test_function = ast.parse(test_function, filename='quickdocs-test/test/test_function.py')
    # Execute test_function
    exec(compile(test_function, filename='quickdocs-test/test/test_function.py', mode='exec'), globals())
    # Get test_function scope
    scope = test_function.body[0].value.elts[1].value.elts[1].value.body[1].value.args.args[2].ctx.name
    #

# Generated at 2022-06-23 15:39:05.099288
# Unit test for method imports of class Parser
def test_Parser_imports():
    with capture_out() as out:
        p = Parser()
        module = ast.parse('''
        import os, sys
        from io import StringIO
        ''')
        p.imports('', module)
        assert p.alias['os'] == 'os'
        assert p.alias['sys'] == 'sys'
        assert p.alias['StringIO'] == 'StringIO'

        module = ast.parse('''
        from typing import *
        ''')
        p.imports('', module)
        assert p.alias['List'] == p.alias['Union'] == 'typing.List'
        assert p.alias['Tuple'] == p.alias['Callable'] == 'typing.Tuple'
        assert p.alias['Optional'] == p.alias['TypeVar'] == 'typing.Optional'

# Generated at 2022-06-23 15:39:16.013393
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    import logging
    import sys
    import unittest
    
    
    class TestParser(unittest.TestCase):
        
        def setUp(self):
            logger.setLevel(logging.CRITICAL)
            sys.argv = sys.argv[:1]
        
        def tearDown(self):
            logger.setLevel(logging.INFO)
            sys.argv = sys.argv[:1]
        

# Generated at 2022-06-23 15:39:21.422971
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    """Unit tests for method visit_Subscript of class Resolver."""    
    node = parse('(int, float)')
    expected = parse('(int | float)')
    result = Resolver('', {}).visit_Subscript(node.body[0].value)
    assert expected.body[0].value == result

# Generated at 2022-06-23 15:39:23.559038
# Unit test for function parent
def test_parent():
    assert parent('a.b.c') == 'a.b'
    assert parent('a.b.c', level=2) == 'a'



# Generated at 2022-06-23 15:39:26.661476
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__aa__')
    assert not is_magic('a')
    assert not is_magic('__a')
    assert not is_magic('_a__')
    assert not is_magic('_a_')
    assert not is_magic('_a')
    assert not is_magic('aa__')
    assert not is_magic('__aa')
    assert not is_magic('a__a')
test_is_magic()



# Generated at 2022-06-23 15:39:29.929613
# Unit test for function parent
def test_parent():
    assert parent("a.b.c") == "a.b"
    assert parent("a.b.c", level=2) == "a"
    assert parent("a.b.c", level=3) == ""
    assert parent("a.b.c", level=4) == ""
    assert parent("a") == ""
    assert parent("") == ""



# Generated at 2022-06-23 15:39:39.925984
# Unit test for function esc_underscore
def test_esc_underscore():
    doc = "a_bcd_ef"
    assert doc == esc_underscore(doc)
    doc = r"a_b\_c\_d_ef"
    assert "a_b\\_c\\_d_ef" == esc_underscore(doc)
    doc = "a_bcd_e\\_f"
    assert "a_bcd_e\\_f" == esc_underscore(doc)
    doc = "a_bcd_e\\_f_"
    assert "a_bcd_e\\_f\\_" == esc_underscore(doc)



# Generated at 2022-06-23 15:39:51.712740
# Unit test for method globals of class Parser
def test_Parser_globals():
    a = Parser('a.b')
    f = a.globals

    assert f('a.b', Assign([Name('a', Store())], Constant(1))) == None
    assert a.alias['a.b.a'] == '1'
    assert not a.const

    assert f('a.b', AnnAssign(Name('a', Store()), None, Constant(1))) == None
    assert a.alias['a.b.a'] == '1'
    assert not a.const

    assert f('a.b', AnnAssign(Name('a', Store()), Constant('int'), Constant(1))) == None
    assert a.alias['a.b.a'] == 'int'
    assert not a.const


# Generated at 2022-06-23 15:39:54.028238
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    s = 'Parser(alias={}, doc={}, docstring={}, level={}, root={})'
    assert repr(Parser()) == s
test_Parser___repr__()

# Generated at 2022-06-23 15:40:06.823532
# Unit test for method api of class Parser
def test_Parser_api():
    p = Parser()
    p.s = Parser.api
    p.imp = {'': set()}
    p.doc = {}
    p.level = {}
    p.alias = {}
    p.root = {}
    p.docstring = {}
    p.const = {}
    p.link = True
    root = 'root'
    from functools import partial
    from ast import parse, FunctionDef
    from ast import arguments, Name, arg, expr
    from ast import ClassDef, ImportFrom, Module
    from ast import Num, assign, Constant, Attribute, NameConstant
    from ast import alias, Store, Del
    from ast import Call, keyword, Str, Dict, List, Tuple, Assign
    from ast import arg_elts, Name as LName, keyword as LKeyword