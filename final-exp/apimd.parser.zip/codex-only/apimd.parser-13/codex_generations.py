

# Generated at 2022-06-23 15:30:02.968587
# Unit test for function is_public_family
def test_is_public_family():
    assert not is_public_family('is_public_family')
    assert is_public_family('dataclasses')
    assert is_public_family('collections.abc')
    assert not is_public_family('_pep585')
    assert is_public_family('pep585')



# Generated at 2022-06-23 15:30:13.645462
# Unit test for method class_api of class Parser
def test_Parser_class_api():
  p = Parser()
  def walk_body(body: list[stmt]) -> Iterator[stmt]:
    for e in body:
      yield e
      if isinstance(e, (FunctionDef, AsyncFunctionDef, ClassDef)):
        yield from walk_body(e.body)
  root = 'test_module'
  name = 'test_module.Class'
  class_def = ClassDef(name='Class',
                       bases=[],
                       keywords=[],
                       body=[Expr(value=Constant(value=1)),
                             Expr(value=Constant(value=2))],
                       decorator_list=[])
  p.class_api(root, name, class_def.bases, class_def.body)

# Generated at 2022-06-23 15:30:22.747957
# Unit test for function const_type
def test_const_type():
    assert const_type(Constant(3)) == "int"
    assert const_type(Constant(3.14)) == "float"
    assert const_type(Constant(True)) == "bool"
    assert const_type(Constant("hello")) == "str"
    assert const_type(Constant((3,))) == "tuple[int]"
    assert const_type(Constant([3])) == "list[int]"
    assert const_type(Constant({3})) == "set[int]"
    assert const_type(Constant({3: 4})) == "dict[int, int]"
    assert const_type(Constant({3: 4, 5: 6})) == "dict[int, int]"
    assert const_type(Constant({3, 4})) == "set[int]"
    assert const_

# Generated at 2022-06-23 15:30:31.209093
# Unit test for method compile of class Parser
def test_Parser_compile():
    """Test compile.

    + Parse a module named `a.b.c`
    + Add some documentation
    + Compile the markdown string
    """
    p = Parser(['a'])
    p.doc["a.b.c"] = "Hello"
    p.docstring["a.b.c"] = "world"
    p.root["a.b.c"] = "a.b.c"
    p.level["a.b.c"] = 3
    p.const["a.b.c"] = "str"
    p.alias["a"] = "a.b.c"
    p.alias["a.b.c"] = "a.b.c"
    p.name_length = 3
    p.b_level = 3

# Generated at 2022-06-23 15:30:40.960758
# Unit test for method api of class Parser
def test_Parser_api():
    """Test the method api of class Parser."""

# Generated at 2022-06-23 15:30:44.230609
# Unit test for function table
def test_table():
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == '''| a | b |
|:---:|:---:|
| c | d |
| e | f |

'''


# Generated at 2022-06-23 15:30:52.082489
# Unit test for constructor of class Resolver
def test_Resolver():
    t = Resolver('', {})
    assert t.visit(Subscript(Name('int', Load()), Constant('X'), Load())) == \
           Subscript(Name('int', Load()), Constant('X'), Load())
    assert t.visit(Subscript(Name('Union', Load()), Constant('X'), Load())) == \
           Name('X', Load())
    assert t.visit(Subscript(Name('Optional', Load()), Constant('X'), Load())) == \
           BinOp(Name('X', Load()), BitOr(), Constant(None))


_T = TypeVar('T')



# Generated at 2022-06-23 15:31:04.466625
# Unit test for method compile of class Parser
def test_Parser_compile():
    """Test Parser.compile()"""
    parser = Parser(link=True, toc=True)

# Generated at 2022-06-23 15:31:17.319507
# Unit test for method compile of class Parser
def test_Parser_compile():
    p = Parser(link=False, toc=False)
    p.alias['a.a'] = 'b'
    p.alias['a.c'] = 'd.c'
    p.alias['a.e'] = 'f.e'
    p.alias['a.g'] = 'h.g'
    p.alias['a.i'] = 'j.i'
    p.alias['a.k'] = 'l.k'
    p.alias['a.m'] = 'n.m'
    p.alias['a.o'] = 'p.o'
    p.alias['a.q'] = 'r.q'
    p.alias['a.s'] = 't.s'
    p.alias['a.u'] = 'v.u'
    p.alias['a.w']

# Generated at 2022-06-23 15:31:28.453596
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    @dataclass
    class Test:
        attr1: typing.Dict[str, str]
        attr2: typing.List[int]
        attr3: int
    assert Test.__annotations__['attr1'] == typing.Dict[str, str]
    assert Test.__annotations__['attr2'] == typing.List[int]
    assert Test.__annotations__['attr3'] == int
    Test.__annotations__ = Resolver('', {}).visit(Test.__annotations__)
    assert Test.__annotations__['attr1'] == dict[str, str]
    assert Test.__annotations__['attr2'] == list[int]
    assert Test.__annotations__['attr3'] == int


# Generated at 2022-06-23 15:31:37.667070
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    r = Resolver('', {})
    assert isinstance(r.visit_Subscript(Subscript(Name('abc', Load()),
                                                  Constant('abc', Load()),
                                                  Load())),
                      Subscript)
    assert isinstance(r.visit_Subscript(Subscript(Name('Optional', Load()),
                                                  Constant('abc', Load()),
                                                  Load())),
                      BinOp)
    assert isinstance(r.visit_Subscript(Subscript(Name('Union', Load()),
                                                  Tuple([Constant('abc', Load()),
                                                         Constant('def', Load())],
                                                        Load()),
                                                  Load())),
                      BinOp)

# Generated at 2022-06-23 15:31:49.061486
# Unit test for constructor of class Resolver
def test_Resolver():
    """Testing for resolver."""
    from pyslvs import T
    r = Resolver('typing', {'typing.T': 'T'})
    assert isinstance(r.visit(parse('typing.List[int]').body[0].value.value),
                      List)
    assert isinstance(r.visit(parse('typing.Optional[int]').body[0].value.value),
                      BinOp)
    assert isinstance(r.visit(parse('typing.Union[int, float]').body[0].value.value),
                      BinOp)
    assert isinstance(r.visit(parse('typing.Type[int]').body[0].value.value),
                      Subscript)

# Generated at 2022-06-23 15:31:53.599138
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__init__')
    assert not is_magic('__hello__')
    assert not is_magic('hello__')
    assert not is_magic('helllo')
    assert is_magic('__name__')
    assert is_magic('__getattr__')

# endregion



# Generated at 2022-06-23 15:32:02.443497
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    import uuid
    import importlib
    import inspect
    p = Parser()
    p.b_level = 10
    name = f'test_{uuid.uuid1().hex}'
    p.root[name] = name
    p.level[name] = 0

# Generated at 2022-06-23 15:32:08.706158
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    p = Parser(pathlib.Path('.'), link=False, toc=True, sep=True)
    p.alias = {'a': '1', 'b': '2'}
    p.doc = {'a': 'a', 'b': 'b'}
    p.docstring = {'c': 'c', 'd': 'd'}
    p.root = {'a': 'a', 'b': 'b'}
    p.const = {'c': 'c', 'd': 'd'}
    p.level = {'a': 1, 'b': 2}
    p.imp = {'a': {'a', 'b'}, 'b': {'c', 'd'}}

# Generated at 2022-06-23 15:32:18.801085
# Unit test for function const_type
def test_const_type():
    assert const_type(parse(repr(True), mode='eval').body) == 'bool'
    assert const_type(parse(repr(4), mode='eval').body) == 'int'
    assert const_type(parse(repr(4.5), mode='eval').body) == 'float'
    assert const_type(parse(repr(3.5 + 3.5j), mode='eval').body) == 'complex'
    assert const_type(parse(repr('456'), mode='eval').body) == 'str'
    assert (const_type(parse('{}', mode='eval').body) ==
            const_type(parse(' dict() ', mode='eval').body))

# Generated at 2022-06-23 15:32:29.110899
# Unit test for method api of class Parser
def test_Parser_api():
    from .logging import logger
    from .package import Package
    from .test_parser import test_const_type

    def doc_test(code: str, expected: str, **kwargs):
        logger.info(code)
        parser = Parser(**kwargs)
        root = 'test'
        parser.parse(ast.parse(code), root)
        assert parser.compile() == expected
        logger.info(parser.compile())

    doc_test(
        """
        # Package
        """,
        """
        # Package

        *Full name:* `test`
        <a id="test"></a>
        """)


# Generated at 2022-06-23 15:32:39.815293
# Unit test for function const_type
def test_const_type():
    T = TypeVar('T')
    passes = [
        (parse(f'{name}(7)').body[0].value, name)
        for name in [
            'bool', 'int', 'float', 'complex', 'str', 'bytes',
            'bytearray', 'memoryview', 'tuple', 'range', 'list',
            'set', 'frozenset', 'dict'
        ]
    ] + [
        (parse(f'{PEP585[name]}(7)').body[0].value, name)
        for name in PEP585
    ]

# Generated at 2022-06-23 15:32:48.835830
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    """Test method resolve."""
    parser = Parser()
    r = Resolver('__main__', parser.alias)
    p = parser.resolve
    assert p('__main__', ast.parse('int').body[0].value) == 'int'
    assert p('__main__', ast.parse('Dict').body[0].value) == 'Dict'
    assert p('__main__', ast.parse('"".upper').body[0].value) == 'str.upper'
    assert p('__main__', ast.parse('math.floor').body[0].value) == 'math.floor'
    assert p('__main__', ast.parse('any').body[0].value) == 'Any'
    assert p('__main__', ast.parse('foo').body[0].value) == 'Any'
   

# Generated at 2022-06-23 15:32:59.091837
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    parser = Parser('')
    root = '__test__'
    name = '__test__.Test'
    bases = [Name(id='str', ctx=Load())]

# Generated at 2022-06-23 15:33:06.633481
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    a = arguments([arg('a', None)], ['b'], None, [arg('c', None)], None, None)
    p = Parser()
    assert list(p.func_ann('', a, has_self=False, cls_method=False)) == ['a', 'b', 'Any']
    assert list(p.func_ann('', a, has_self=True, cls_method=False)) == ['type[Self]', 'a', 'b', 'Any']
    assert list(p.func_ann('', a, has_self=True, cls_method=True)) == ['Self', 'a', 'b', 'Any']
    a = arguments([arg('a', None)], ['b'], None, [arg('c', Name('x', Load()))], None, None)

# Generated at 2022-06-23 15:33:17.306443
# Unit test for function const_type
def test_const_type():
    from ast import parse
    assert const_type(parse('1').body[0].value) == 'int'
    assert const_type(parse('"a"').body[0].value) == 'str'
    assert const_type(parse('[1, "a", False]').body[0].value) == \
        'List[int, str, bool]'
    assert const_type(parse('{"a": 1, "b": True}').body[0].value) == \
        'dict[str, int, bool]'
    assert const_type(parse('True').body[0].value) == 'bool'
    assert const_type(parse('(0,0)').body[0].value) == 'Tuple[int, int]'

# Generated at 2022-06-23 15:33:28.806332
# Unit test for method parse of class Parser
def test_Parser_parse():
    modules = [
        "aiohttp.client_exceptions",
        "aiohttp.client",
        "aiohttp.helpers",
        "aiohttp.multipart",
        "aiohttp.streams",
        "aiohttp.web_exceptions",
        "aiohttp.web",
        "aiohttp.web_reqrep",
        "aiohttp.web_routedef"
    ]
    for module in modules:
        m = importlib.import_module(module)
        p = Parser()
        p.parse(m)
        doc = p.compile()
        dst = os.path.join(os.path.dirname(__file__), '../../api_aiohttp/',
                           module.replace('.', '/') + '.md')

# Generated at 2022-06-23 15:33:39.183730
# Unit test for method compile of class Parser
def test_Parser_compile():
    _a = 'module'
    _b = 'module.class'
    _c = 'module.class.method'
    _d = 'module.method'
    _e = 'module.class.other_method'
    _u = {_a: set(), _b: set(), _c: set(), _d: set(), _e: set()}
    _a_ = {_a: 'module', _b: 'module', _c: 'module', _d: 'module', _e: 'module'}
    _l = {_a: 0, _b: 1, _c: 2, _d: 1, _e: 2}

# Generated at 2022-06-23 15:33:44.697836
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('public.name')
    assert not is_public_family('_private.name')
    assert not is_public_family('_private._private.name')
    assert is_public_family('__private.name')
    assert not is_public_family('private.__private.name')
    assert not is_public_family('private.__private._private.name')



# Generated at 2022-06-23 15:33:48.786385
# Unit test for method imports of class Parser
def test_Parser_imports():
    root = 'root'
    parser = Parser()
    node = Import(
        [alias(Name('a'), None), alias(Name('b'), None)], None)
    parser.imports(root, node)
    assert parser.alias == {'root.a': 'a', 'root.b': 'b'}

# Generated at 2022-06-23 15:33:59.065908
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Line 0
    from .otool import Parser, FunctionDef, arg, arg, arg, arg
    import __main__
    import sys
    # Line 3
    
    
    
    
    
    
    
    import shutil
    import pathlib
    import dbm
    import enum
    import time
    import re
    import struct
    import random
    import datetime
    import collections
    import math
    import os
    import base64
    import tempfile
    import typing
    import logging
    import functools
    import io
    import inspect
    import json
    # Line 33
    import builtins
    # Line 35
    import pkgutil
    # Line 37
    import sysconfig
    # Line 39
    import itertools
    # Line 41
    import importlib
    # Line 43


# Generated at 2022-06-23 15:34:09.341127
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    import ast
    from . import csv_ast
    from .csv_ast import Call
    from .parser import Parser
    p = Parser()
    a = p.class_api('csv', 'csv.Dialect', [], csv_ast.DIALECT_BODY)
    b = p.class_api('csv', 'csv.Dialect', [], csv_ast.DIALECT_BODY)
    assert a == b
    p = Parser(level=1)
    assert not p.level.values()
    p.class_api('csv', 'csv.Dialect', [], csv_ast.DIALECT_BODY)
    assert all(p.level.values())
    p = Parser()

# Generated at 2022-06-23 15:34:19.408953
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    m = Module(body=[FunctionDef(name='f', args=arguments(
        posonlyargs=[arg('a', Name(id='int'))],
        args=[arg('b', Name(id='float'))],
        defaults=[Constant(value=0j), Constant(value=True)],
        kwonlyargs=[arg('c', Name(id='bool'))],
        kw_defaults=[Name(id='None')],
        vararg=Name(id='d'),
        kwarg=Name(id='e')), body=[], returns=Name(id='str'))])
    root = 'tests'
    node = m.body[0]
    parser = Parser(b_level=0, link=False, toc=False, no_docstring=False)
    parser.api(root, node)

# Generated at 2022-06-23 15:34:23.652296
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    r = Resolver("typing", {"typing.Foo": "Union[Bar, Baz]"})
    assert unparse(r.visit_Name(parse("Foo").body[0].value)).strip() == "Union[Bar, Baz]"

# Generated at 2022-06-23 15:34:27.401534
# Unit test for function code
def test_code():
    assert code('') == " "
    assert code('A') == "`A`"
    assert code('A. ') == "<code>A. </code>"
    assert code('A. |') == "<code>A. &#124;</code>"



# Generated at 2022-06-23 15:34:31.587564
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    node = Attribute(Name("typing", Load()), "Type", Load())
    r = Resolver("a", {})
    assert r.visit(node) == Name("Type", Load())



# Generated at 2022-06-23 15:34:36.948086
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    r = Resolver("root", {})
    print(node_code(r.visit(parse("typing.List").body[0])))
    print(node_code(r.visit(parse("typing.Optional[List]").body[0])))
    print(node_code(r.visit(parse("typing.Union[List, Set]").body[0])))


T = TypeVar('T')



# Generated at 2022-06-23 15:34:42.938355
# Unit test for constructor of class Parser
def test_Parser():
    """Unit test for constructor of class Parser."""
    p = Parser()
    assert p.alias == {}
    assert p.doc == {}
    assert p.docstring == {}
    assert p.const == {}
    assert p.imp == defaultdict(set)
    assert p.root == {}
    assert p.level == {}
    assert p.b_level == 0
    assert p.link is False
    assert p.toc is True


# Generated at 2022-06-23 15:34:45.819474
# Unit test for method api of class Parser
def test_Parser_api():
  assert doctest("A", table("B", items=[("c", "d")])) == "``A``\n\nB\n---\n\n* c: ``d``\n"


# Generated at 2022-06-23 15:34:51.837505
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    assert Resolver("_", {}).visit_Constant(Constant("3")) == Constant("3")
    assert Resolver("_", {}).visit_Constant(
        Constant("type('str')")).value == str
    assert Resolver("_", {"A": "'B'"}).visit_Constant(
        Constant("A")).value == "B"
    assert Resolver("_", {"A": "1"}).visit_Constant(
        Constant("A + 2")).value == 3


# Generated at 2022-06-23 15:34:55.726607
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    class A:
        def m(self):
            """A.m()"""

    m = types.ModuleType("m")
    m.m = A.m
    p = Parser()
    p.load_docstring("m", m)
    assert p.docstring["m.m"] == '```example\n{asctime}\n```\n'



# Generated at 2022-06-23 15:34:58.442844
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__dunder__')
    assert not is_magic('__init__')
    assert not is_magic('lmao__')
    assert not is_magic('__lmao')



# Generated at 2022-06-23 15:35:04.082886
# Unit test for method api of class Parser
def test_Parser_api():
    import os.path as path
    from types import MappingProxyType
    from sys import modules
    from doc_of import load_module, load_package
    from doc_of.compile import compile
    from doc_of.parser import _Parsed
    def test_func(a: int, b: str, *args, c: dict, d: float = 1.0,
                  e: str = '', **kwargs) -> bool:
        """Function docstring.

        >>> test_func(1, '2', c='C', d=3.14, f='F')
        True
        """
        return True

# Generated at 2022-06-23 15:35:09.809362
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__doc__') and is_magic('__name__')
    assert is_magic('__add__') and is_magic('__setitem__')
    assert not is_magic('__add__') == is_magic('__setitem__')
    assert not is_magic('__doc__') == is_magic('__name__')
    assert not is_magic('abs')



# Generated at 2022-06-23 15:35:19.701965
# Unit test for function walk_body

# Generated at 2022-06-23 15:35:20.582669
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    pass



# Generated at 2022-06-23 15:35:30.392484
# Unit test for method compile of class Parser
def test_Parser_compile():
    from export_code import func_1
    from export_code import func_2
    from export_code import func_3
    p = Parser()

# Generated at 2022-06-23 15:35:41.500029
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    f = parser.parse_function(dedent('''
    def f(x: List[int], y: int = 1, *, z: int, **kwargs) -> Dict[str, int]:
        pass
    '''))
    args = f.args
    assert args.vararg is None
    assert args.kwarg is None
    assert isinstance(args.kwonlyargs[0].annotation, Name)
    args.kwonlyargs[0].annotation.ctx = Load()
    parser.func_api('', '', args, None, has_self=False, cls_method=False)
    parser.func_ann('', args, has_self=False, cls_method=False)
    

# Generated at 2022-06-23 15:35:53.776965
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Pytest doesn't allow one to override __file__ globals
    # So have to have some mixed type of class and function test style here ..
    from os import path
    from pprint import pprint
    from . import tests

    def check(dirname: str, encoding: str = 'utf-8') -> None:
        a = Parser(dirname, os.path.getmtime)
        f = os.path.join(dirname, 'api.rst')
        with open(f, 'rb') as file:
            api = file.read().decode(encoding)
        dm = ModuleType("")
        exec(compile(a.compile(), filename=f, mode='exec'), dm.__dict__)
        assert a.compile() == api

# Generated at 2022-06-23 15:36:06.033301
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser('', {})
    args = arg('a', None), arg('b', None)
    p.func_ann('', args, has_self=True, cls_method=False) == ['None', 'None']

    args = arg('a', None), arg('b', None)
    p.func_ann('', args, has_self=True, cls_method=True) == ['type[Self]', 'None']

    args = arg('a', Name('None', Load())), arg('b', None)
    p.func_ann('', args, has_self=True, cls_method=False) == ['None', 'None']

    args = arg('a', Name('None', Load())), arg('b', None)

# Generated at 2022-06-23 15:36:13.014636
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    u = Union[int, str]
    o = Optional[int]
    @dataclass
    class C:
        a: Union[int, float]
        c: Optional[str]
    c = C(1, None)
    Resolver('__main__', {}).visit(Constant(u))
    Resolver('__main__', {}).visit(Constant(o))
    Resolver('__main__', {}).visit(Constant(c.c))



# Generated at 2022-06-23 15:36:25.531620
# Unit test for method compile of class Parser
def test_Parser_compile():
    import unittest
    import tempfile
    import shutil
    import os
    import pathlib

    class TestCompile(unittest.TestCase):
        dir = None
        name = ""

        @classmethod
        def create_module(cls, name, content=""):
            with open(os.path.join(cls.dir, name + ".py"), "w") as f:
                f.write(content)

        @classmethod
        def setUpClass(cls):
            cls.dir = tempfile.mkdtemp()
            cls.name = os.path.basename(cls.dir)

        @classmethod
        def tearDownClass(cls):
            shutil.rmtree(cls.dir)

        def assertListEqual(self, l1, l2):
            self

# Generated at 2022-06-23 15:36:28.394584
# Unit test for function code
def test_code():
    assert code("a | b") == "`a &#124; b`"
    assert code("a&b") == "<code>a&b</code>"
    assert code("") == " "



# Generated at 2022-06-23 15:36:37.585933
# Unit test for method globals of class Parser
def test_Parser_globals():
    from types import SimpleNamespace
    from typing import List
    
    from anypytools.abcutils import parse_anybody_config

    from pygiftgrab.parser import BaseParser

    class Parser(BaseParser):
        def imports(self, root: str, node: _I) -> None:
            pass

        def globals(self, root: str, node: _G) -> None:
            pass

        def api(self, root: str, node: _API, *, prefix: str = '') -> None:
            pass

    class Test:
        pass

    one = Test()
    one.two = Test()
    one.two.three = Test()

    one.two.six = (1, 2, 3)
    one.four = Test()
    one.four.five = Test()

# Generated at 2022-06-23 15:36:49.155104
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    p.alias = {'test.abc': 'abc', 'test.def': 'def', 'test.ghi': 'ghi'}
    assert list(p.func_ann('test', [arg('*', None), arg('a', None)],
                           has_self=False, cls_method=False)) == ['', ANY]
    assert list(p.func_ann('test', [arg('*', None), arg('a', None)],
                           has_self=True, cls_method=False)) == [
        'Self', ANY]
    assert list(p.func_ann('test', [arg('a', None), arg('b', None)],
                           has_self=True, cls_method=False)) == [
        'Self', 'Self']

# Generated at 2022-06-23 15:36:59.320246
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    """Unit test for method __repr__ of class Parser"""
    from pprint import pformat
    from .base import Options
    from .api import api
    from .doctest import doctest
    from . import tostring
    from . import parser
    from . import normalize
    from . import link
    from . import toc
    from . import _link
    from . import _toc
    from . import _normalize
    from . import _parser
    from . import _tostring
    from . import _doctest
    options = Options()
    doc = api(options)
    doctest(options)
    tostring(options)
    parser(options, name='argparse')
    normalize(options)
    link(options)
    toc(options)
    _link(options)

# Generated at 2022-06-23 15:37:10.537096
# Unit test for constructor of class Resolver
def test_Resolver():
    import_alias = {
        'typing': 'typing'
    }
    code = """class Set(Generic[T_co], Sized):
    def __init__(self, iterable: Iterable[T_co] = None):
        ...
    def add(self, value: T_co) -> None:
        ...
    def discard(self, value: T_co) -> None:
        ...
"""
    n = cast(ClassDef, parse(code).body[0])
    Resolver('__main__', import_alias).visit(n)

# Generated at 2022-06-23 15:37:20.279073
# Unit test for method compile of class Parser
def test_Parser_compile():
    import pylint_md.pylint_md as M
    import sys
    import os
    # Path to this run file
    path = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(path + '/../')
    from pylint_md.test.test_pylint_md import TestPylintMd
    TestPylintMd.__test_target_base__ = path
    tpm = TestPylintMd()
    tpm.setUpTestData(None)
    fs_list = [
        'sample.py',
        'sample_ast.py',
        'sample_doc.py',
        'sample_tuple.py'
    ]

# Generated at 2022-06-23 15:37:23.302978
# Unit test for method api of class Parser
def test_Parser_api():
    test_root = 'tests'
    test_parser = Parser(root=test_root, toc=True, link=True)
    test_parser.alias['tests.a'] = 'tests.a'


# Generated at 2022-06-23 15:37:30.691209
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    def test(p: Parser, root: str, name: str, node: arguments,
             returns: Optional[expr], *, has_self: bool,
             cls_method: bool, expect: str) -> None:
        p.func_api(root, name, node, returns, has_self=has_self,
                   cls_method=cls_method)
        assert p.doc[name] == expect

    p = Parser(False, True)
    def_ = lambda *args, **kwargs: FunctionDef('f', *args, **kwargs)
    args = lambda *it: arguments(*it, vararg=None, kwonlyargs=[],
                                 kw_defaults=[], kwarg=None)

# Generated at 2022-06-23 15:37:33.171199
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert str(Resolver("a.b", {}).visit(Name("c", Load()))) == "c"
    assert str(Resolver("a.b", {_m("a.b", "c"): "d"}).visit(Name("c", Load()))) == ("d")

# Generated at 2022-06-23 15:37:38.877861
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser(Parser.defaults)

# Generated at 2022-06-23 15:37:42.351552
# Unit test for function code
def test_code():
    assert code("") == " "
    assert code("A") == "`A`"
    assert code("A & B") == "<code>A &amp; B</code>"



# Generated at 2022-06-23 15:37:45.720234
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('public')
    assert is_public_family('Public')
    assert is_public_family('_public')
    assert is_public_family('__public')
    assert is_public_family('public_')
    assert is_public_family('public.__')
    assert is_public_family('public.__init__')
    assert not is_public_family('_public.__')
    assert not is_public_family('__public.__')
    assert not is_public_family('public.__init__.__')



# Generated at 2022-06-23 15:37:55.680921
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    import ast
    from types import ModuleType
    from dockit.compiler import Parser, Resolver
    from dockit.parser import Parser as P
    class TestModule:
        def __init__(self, name: str, doc: str = None) -> None:
            self.name = name
            self.const: list[str] = []
            self.doc = doc
            self.m = ModuleType(name)
        def generate_doc(self) -> str:
            """Generate documentation."""
            if self.doc is not None:
                return self.doc
            doc = f"# Module {self.name}\n\n"

# Generated at 2022-06-23 15:38:00.052779
# Unit test for function code
def test_code():
    assert code("") == " "
    assert code("foo") == "`foo`"
    assert code("*") == "&#124;*&#124;"
    assert code("a & b") == "<code>a & b</code>"



# Generated at 2022-06-23 15:38:12.222231
# Unit test for method api of class Parser
def test_Parser_api():
    """Test class `Parser` method `api`."""
    parser = Parser()
    assert parser.api('', Name('x', Load()), prefix='') is None
    parser = Parser()
    assert parser.api('', FunctionDef(
        name='x', args=arguments(
            posonlyargs=[Name(arg='arg', ctx=Param())],
            args=[Name(arg='*', ctx=Param())],
            defaults=[], vararg=None, kwonlyargs=[],
            kw_defaults=[], kwarg=None), body=[Return(value=None)],
        decorator_list=[], returns=None, type_comment=None), prefix='') is None
    parser = Parser()

# Generated at 2022-06-23 15:38:15.510929
# Unit test for function code
def test_code():
    assert code("*hello*") == "`*hello*`"
    assert code("&") == "<code>&amp;</code>"
    assert code("") == " "



# Generated at 2022-06-23 15:38:25.590500
# Unit test for method resolve of class Parser
def test_Parser_resolve():

    # Test cases
    TESTCASES = [
        """
        # Test case 1
        def f(n: int): return n
        f.__annotations__
        """,
        """
        # Test case 2
        def f(n: int): return n
        n = n + 1
        f.__annotations__
        """,
        """
        # Test case 3
        def f(n: int): return n
        def g(m: 'f'): return m
        g.__annotations__
        """
    ]
    for testcase in TESTCASES:
        print(testcase)
        m = ast.parse(testcase)
        t = Parser()
        t.visit(m)
        print(t.alias)
    print("Test complete!")


# Generated at 2022-06-23 15:38:29.885229
# Unit test for function code
def test_code():
    assert code('python test') == "`python test`"
    assert code('python|test') == "<code>python&#124;test</code>"
    assert code('&python test') == "<code>&amp;python test</code>"



# Generated at 2022-06-23 15:38:42.651746
# Unit test for method imports of class Parser
def test_Parser_imports():
    parser = Parser()
    parser.alias = dict()
    parser.imp = {}
    node = Import('foo')
    with pytest.raises(NotImplementedError):
        parser.imports('name', node)
    node = ImportFrom('foo', [alias('bar', 'baz')], 1)
    with pytest.raises(NotImplementedError):
        parser.imports('name', node)
    node = Import('foo')
    with pytest.raises(NotImplementedError):
        parser.globals('name', node)
    node = AnnAssign(arg('foo', None), None, Name('a', Load()))
    with pytest.raises(NotImplementedError):
        parser.globals('name', node)

# Generated at 2022-06-23 15:38:51.650691
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__init__')
    assert not is_magic('__init_')
    assert is_magic('__init___')
    assert not is_magic('_init__')
    assert not is_magic('init__')
    assert not is_magic('__init')
    assert not is_magic('__init')
    assert is_magic('pyslvs.__init__.test')
    assert not is_magic('pyslvs.__init_.test')
    assert is_magic('pyslvs.__init___.test')
    assert not is_magic('pyslvs._init__.test')
    assert not is_magic('pyslvs.init__.test')
    assert not is_magic('pyslvs.__init.test')

# Generated at 2022-06-23 15:38:59.722052
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert Resolver('abc', {}).visit(Name('T', Load())) == Name('T', Load())
    assert Resolver('abc', {}).visit(parse('[T]').body[0].value) == List(
        [Name('T', Load())], Load())
    assert Resolver('abc', {}).visit(parse('[T]').body[0].value) == List(
        [Name('T', Load())], Load())
    assert Resolver('abc', {'abc.T': 'List[A]'}).visit(
        parse('[T]').body[0].value) == List([Name('A', Load())], Load())

# Generated at 2022-06-23 15:39:05.359849
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert parse(Resolver('math', {}).visit(parse('math.zero').body[0]).value).body[0] == parse('math.zero').body[0]
    assert parse(Resolver('math', {'math.zero': 'int'}).visit(parse('math.zero').body[0]).value).body[0] == parse('int()').body[0]
    assert parse(Resolver('math', {'math.zero': 'int'}).visit(parse('zero').body[0]).value).body[0] == parse('int()').body[0]
    assert parse(Resolver('math', {'math.zero': 'int'}).visit(parse('math.zero').body[0]).value).body[0] == parse('int()').body[0]

# Generated at 2022-06-23 15:39:08.311449
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    @dataclass
    class TT:
        """Test type"""
        t: Optional[str] = None
        p: Optional[str] = None

    test = TT(t="Dict[str, int]", p="int")
    assert Resolver("typing", {"typing.Dict": "dict"}).visit_Name(test.t) == "dict[str, int]"
    assert Resolver("typing", {"typing.Dict": "dict"}).visit_Name(test.p) == "int"



# Generated at 2022-06-23 15:39:17.222407
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    p1 = Parser(
        link=False,
        toc=False,
        no_private=False,
    )
    p2 = Parser(
        link=False,
        toc=False,
        no_private=False,
    )
    assert p1 == p2
    p1 = Parser(
        link=False,
        toc=True,
        no_private=False,
    )
    p2 = Parser(
        link=False,
        toc=False,
        no_private=False,
    )
    assert p1 != p2
    p1 = Parser(
        link=False,
        toc=False,
        no_private=False,
    )

# Generated at 2022-06-23 15:39:27.240896
# Unit test for method parse of class Parser
def test_Parser_parse():
    m = inspect.getfile(inspect.currentframe())
    d = os.path.split(os.path.abspath(m))[0]
    p = Parser(recursive=True, link=True)
    r = p.parse(d, 'briefmarkup')

# Generated at 2022-06-23 15:39:29.090581
# Unit test for method parse of class Parser
def test_Parser_parse():
    pass
    # setup
    # test
    # assert

# Generated at 2022-06-23 15:39:33.304587
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    with tempfile.TemporaryDirectory() as temp_dir:
        src = os.path.join(temp_dir, 'test_module.py')

# Generated at 2022-06-23 15:39:43.851310
# Unit test for constructor of class Resolver
def test_Resolver():
    """Unit test for constructor of class Resolver."""
    alias: dict[str, str] = {
        "typing": "typing",
        "typing.Union": "typing.Union",
        "typing.Optional": "typing.Optional",
        "typing.Callable": "typing.Callable",
        "typing.Sequence": "typing.Sequence",
        "typing.Tuple": "typing.Tuple",
        "typing.List": "typing.List",
        "typing.Dict": "typing.Dict",
        "typing.ClassVar": "typing.ClassVar",
    }
    keys = PEP585.keys() | PEP585.values()
    for k in keys:
        alias[k] = 'typing.' + k

# Generated at 2022-06-23 15:39:45.765958
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__call__')
    assert is_magic('__name__')
    assert is_magic('__init__')
    assert not is_magic('__asd__')
    assert not is_magic('asdf')



# Generated at 2022-06-23 15:39:47.845084
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    obj = Parser()
    assert not (Parser() == obj)
    assert obj == obj


# Generated at 2022-06-23 15:39:54.832789
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    m = Module(body = [
        Assign(targets = [Name(id = 'a', ctx = Store())], value = Constant(
            value = 1)),
        Assign(targets = [Name(id = 'b', ctx = Store())], value = Constant(
            value = 2))])
    n = Module(body = [
        Assign(targets = [Name(id = 'b', ctx = Store())], value = Constant(
            value = 2)),
        Assign(targets = [Name(id = 'a', ctx = Store())], value = Constant(
            value = 1))])
    assert Parser().__eq__(m, n) is True

# Generated at 2022-06-23 15:40:03.765948
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert unparse(Resolver("", {}).visit(Subscript(Name('x', Load()),
            Tuple(elts=[Constant(True), Constant(False)], ctx=Load()),
            Load()))) == "x | True | False"
    assert unparse(Resolver("", {}).visit(Subscript(Name('x', Load()),
            Tuple(elts=[Constant(True), Constant(False)], ctx=Load()),
            Load()))) == "x | True | False"