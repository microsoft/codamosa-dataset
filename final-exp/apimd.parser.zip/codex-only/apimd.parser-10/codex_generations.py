

# Generated at 2022-06-23 15:30:14.049920
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    from pathlib import Path
    from importlib.util import spec_from_file_location, module_from_spec
    from typing_extensions import Literal
    from ast import parse
    path = Path(__file__).parent / ".." / ".." / ".." / ".." / ".." / ".."
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))
    spec = spec_from_file_location("gato", path / "src" / "gato" / "gato.py")
    m = module_from_spec(spec)
    spec.loader.exec_module(m)  # type: ignore

# Generated at 2022-06-23 15:30:25.473823
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from . import builtins
    from . import types
    from . import unittest
    parser = Parser(link=False)
    parser.load_docstring('builtins', builtins)
    parser.load_docstring('types', types)

    # Check the __doc__ is appending.
    assert parser.docstring['builtins.objects.object']
    assert parser.docstring['types.objects.object']
    assert parser.docstring['builtins.objects.object'] != parser.docstring['types.objects.object']

    # Check the docstring table format.

# Generated at 2022-06-23 15:30:27.111552
# Unit test for constructor of class Parser
def test_Parser():
    with pytest.raises(TypeError):
        Parser(1)



# Generated at 2022-06-23 15:30:38.791928
# Unit test for function walk_body
def test_walk_body():
    from .tests import env
    with env() as e:
        e.assert_code(unparse(parse(
            'if 1:\n'
            '  def a():\n'
            '    pass\n'
            'else:\n'
            '  def b():\n'
            '    pass\n'
        ).body), '', '', [i.name for i in walk_body(parse(
            'if 1:\n'
            '  def a():\n'
            '    pass\n'
            'else:\n'
            '  def b():\n'
            '    pass\n'
        ).body)])

# Generated at 2022-06-23 15:30:45.184517
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('a')
    assert not is_public_family('_a')
    assert is_public_family('a.b')
    assert not is_public_family('_a.b')
    assert is_public_family('a.b._c')
    assert not is_public_family('_a.b.c')
    assert is_public_family('a.b.__c')
test_is_public_family()



# Generated at 2022-06-23 15:30:51.265757
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    p = Parser(None)
    p.doc[1] = '1'
    p.doc[1.1] = '1.1'
    p.docstring['-1'] = '-1'
    assert p.load_docstring(1, None) is None
    assert p.doc == {1: '1', 1.1: '1.1'}
    assert p.docstring == {'-1': '-1'}

# Generated at 2022-06-23 15:30:55.018958
# Unit test for method api of class Parser
def test_Parser_api():
    p = Parser()

    class _test(Parser):
        def __init__(self):
            self.doc = {}
            self.docstring = {}
            self.level = {}
            self.root = {}
            self.alias = {}
            self.imp = {}
            self.const = {}

    p.doc = {}
    p.docstring = {}
    p.level = {}
    p.root = {}
    p.alias = {}
    p.imp = {}
    p.const = {}

# Generated at 2022-06-23 15:31:06.834379
# Unit test for function const_type
def test_const_type():

    def a():
        """
        >>> a().b
        """

    @dataclass
    class B:
        """
        >>> B().c
        """

        def c(self):
            """
            >>> B().c()
            """


# Generated at 2022-06-23 15:31:19.016046
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    parser = Parser(True)
    # test docstring
    parser.docstring['t.d.t0'] = "docstring of t.d.t0"
    # test module
    class m:
        '''
        docstring of m
        '''
        x = '''
            docstring of m.x
        '''
        y = '''
            docstring of m.y
        '''
    # test class
    class m:
        class c:
            '''
            docstring of m.c
            '''
            z = '''
                docstring of m.c.z
            '''
            x = '''
                docstring of m.c.x
            '''
        class d:
            '''
            docstring of m.d
            '''

# Generated at 2022-06-23 15:31:30.111028
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert str(Resolver("", {}).visit(parse(r"typing.Union[A, B]").body[0])) == "(A | B)"
    assert str(Resolver("", {}).visit(parse(r"typing.Optional[A]").body[0])) == "(A | None)"
    assert str(Resolver("", {}).visit(parse(r"typing.Sequence[A]").body[0])) == "Sequence[A]"
    assert str(Resolver("", {}).visit(parse(r"typing.Mapping[A, B]").body[0])) == "Mapping[A, B]"
    assert str(Resolver("", {}).visit(parse(r"typing.Tuple[A]").body[0])) == "Tuple[A]"

# Generated at 2022-06-23 15:31:36.160059
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    with suppress(AttributeError):
        Parser(None, None, None, None, None).__eq__(None)
        Parser(None, None, None, None, None).__eq__([])
        Parser(None, None, None, None, None).__eq__(1)
        Parser(None, None, None, None, None).__eq__("")
        Parser(None, None, None, None, None).__eq__(Parser(None, None, None, None, None))


# Generated at 2022-06-23 15:31:42.355711
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser()
    p.func_api('module.Class', 'module.Class.method',
               arguments(
                   args=[arg('self', None), arg('p', Name('int', Load()))],
                   kwonlyargs=[],
                   vararg=None,
                   kwarg=None,
                   defaults=[],
                   kw_defaults=[]),
               None,
               has_self=True,
               cls_method=True)

# Generated at 2022-06-23 15:31:44.322118
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    p = Parser()
    assert p != 10
    assert not (p != p)

# Generated at 2022-06-23 15:31:51.870837
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore('_') == '_'
    assert esc_underscore('') == ''
    assert esc_underscore('abcd') == 'abcd'
    assert esc_underscore('a_bcd') == 'a_bcd'
    assert esc_underscore('ab_cd') == 'ab\\_cd'
    assert esc_underscore('ab_c_d') == 'ab\\_c\\_d'
# End of unit test



# Generated at 2022-06-23 15:31:57.427344
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('_module_')
    assert is_public_family('module_')
    assert is_public_family('module.func')
    assert is_public_family('module.__special__')
    assert is_public_family('module.__special__.func')
    assert not is_public_family('_module._func')
    assert not is_public_family('module._func')
    assert not is_public_family('_module.func')



# Generated at 2022-06-23 15:32:05.188569
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    p = Parser()
    a = p.resolve('', parse5('type[a.b.c.d]'))
    assert a=='a.b.c.d'
    a = p.resolve('', parse5('type[a.b.c.d]'))
    assert a == 'a.b.c.d'
    a = p.resolve('a', parse5('type[a.b.c.d]'))
    assert a == 'a.b.c.d'
    a = p.resolve('a.b', parse5('type[a.b.c.d]'))
    assert a == 'c.d'
    a = p.resolve('a', parse5('type[b.c.d]'))
    assert a == 'b.c.d'

# Generated at 2022-06-23 15:32:13.109222
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("_") == "_"
    assert esc_underscore("__") == "__"
    assert esc_underscore("_a__b_") == r"\_a\_\_b\_"
    assert esc_underscore("a_b") == r"a\_b"
    assert esc_underscore("a__b") == r"a\_\_b"
    assert esc_underscore("a_b_c") == r"a\_b\_c"



# Generated at 2022-06-23 15:32:17.829605
# Unit test for function code
def test_code():
    assert code("m+2|2") == "`m+2&#124;2`"
    assert code("""alignment-baseline="central" """) == """<code>alignment-baseline="central"</code>"""
    assert code("m2") == "`m2`"
    assert code("") == " "
    assert code(" ") == " "



# Generated at 2022-06-23 15:32:24.586996
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    n = Constant("List")
    assert Resolver("a", {}).generic_visit(n) == n
    assert Resolver("a", {}).visit(n) == Name("List", Load())
    assert Resolver("a", {"List": "List"}).visit(n) == n
    assert Resolver("a", {"List": "typing.List[Any]"}).visit(n) ==\
        Subscript(Name("List", Load), Tuple([Any()], Load()), Load())



# Generated at 2022-06-23 15:32:27.174774
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__init__')
    assert is_magic('__call__')
    assert not is_magic('__not__')
    assert not is_magic('init')



# Generated at 2022-06-23 15:32:36.378265
# Unit test for method globals of class Parser
def test_Parser_globals():
    parser = Parser()
    code = compile(parse(dedent("""
        if True:
            CONST1 = 1
        else:
            CONST2 = 2
        CONST3 = 3
        __all__ = ['CONST1']
        """)))
    assert parser.globals(root='ROOT', node=code) is None
    assert parser.const == {'ROOT.CONST1': 'int', 'ROOT.CONST3': 'int'}
    assert parser.alias == {}
    assert parser.imp == {'ROOT': {'ROOT.CONST1'}}
    assert parser.level == {}

# Generated at 2022-06-23 15:32:42.127581
# Unit test for method visit_Subscript of class Resolver

# Generated at 2022-06-23 15:32:50.474991
# Unit test for method compile of class Parser
def test_Parser_compile():
    import unittest
    import sys
    import os

    class Parser_compile(unittest.TestCase):
        """Test case for Parser.compile."""
        def setUp(self):
            self.root = os.path.dirname(__file__)

        def test_a(self):
            """Test for Parser.compile."""
            with open(os.path.join(self.root, 'test_a.py')) as f:
                code = f.read()
            with open(os.path.join(self.root, 'test_a.md')) as f:
                exp = f.read()
            p = Parser()
            p.parse(sys.modules[__name__], code)
            doc = p.compile()

# Generated at 2022-06-23 15:32:53.853309
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    result = Parser(TOMLConfig("py: {version: '3.6'}"))
    expected = Parser(TOMLConfig("py: {version: '3.6'}"))
    assert result == expected

# Generated at 2022-06-23 15:33:02.229117
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    r = Resolver("", {})
    assert isinstance(r.visit(Constant("123")), Constant)
    assert isinstance(r.visit(Constant("str")), Name)
    assert isinstance(r.visit(Constant("123.0")), Constant)
    assert isinstance(r.visit(Constant("None")), Name)
    assert isinstance(r.visit(Constant("()")), Tuple)
    assert isinstance(r.visit(Constant("[]")), List)
    assert isinstance(r.visit(Constant("{}")), Dict)

# Generated at 2022-06-23 15:33:04.718182
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    node = Constant("ast.interpreted")
    a1 = Resolver("", {}).visit(node)
    assert a1.id == "ast"
    assert a1.value.id == "interpreted"
    assert not isinstance(a1.value, Name)

# Generated at 2022-06-23 15:33:16.710481
# Unit test for function doctest
def test_doctest():
    """Unit test for function doctest."""
    assert doctest(r"""Docstring.
    >>> code line.
    >>> another code line.
    End.""") == ("Docstring.\n"
                 "```python\n"
                 ">>> code line.\n"
                 "```\n"
                 ">>> another code line.\n"
                 "```\n"
                 "End.")
    assert doctest(r"""Docstring.
    >>> code line.
    End.""") == ("Docstring.\n"
                 "```python\n"
                 ">>> code line.\n"
                 "End.\n"
                 "```")

# Generated at 2022-06-23 15:33:26.767078
# Unit test for function table
def test_table():
    from random import random
    rows = int(random() * 10 + 10)
    cols = int(random() * 5 + 5)
    col_names = [f"Column {i}" for i in range(cols)]
    chr_code = []
    for j in range(rows):
        a = []
        for i in range(cols):
            _c = ''
            for _ in range(i+1):
                _c += chr(65 + (i % 26))
            a.append(_c)
        chr_code.append(a)
    print(table(*col_names, chr_code))



# Generated at 2022-06-23 15:33:36.970052
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    from .visitor import parse
    from .sphinx import make_sphinx
    from .typing import List
    from importlib import import_module
    module = import_module('unittest')
    b = module.TestCase
    b.assertIsInstance = b.assertIs
    p = Parser(r"C:\Users\jinx\Desktop\Python\pytypes\pytypes", True)
    p.api(p.module, parse(module.TestCase.__init__.__code__))

# Generated at 2022-06-23 15:33:46.787134
# Unit test for constructor of class Parser
def test_Parser():
    """Test the constructor of Parser."""
    file1, code1 = build('''
        def func(a: int, b: str) -> float:
            "This is summary, a is b."
            return float(a)
        class C:
            def __init__(self):
                self.a = 1
            def func(self, b: str) -> str:
                "This is summary, b is self.a."
                return str(self.a)
        class C:
            pass
        i = 1
        d = 1.0
        f = {i: d}
    ''')
    file2, code2 = build('''
        def func(a: int, b: str) -> float:
            "This is summary, a is b."
            return float(a)
    ''')


# Generated at 2022-06-23 15:33:57.760858
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    code = """
    class Foo:
        x = 1
        
        def f(self):
            pass
        
        class Bar:
            pass
    """
    parser = Parser(code)
    parser.parse()
    parser.level = {'Foo': 0, 'Foo.f': 1, 'Foo.Bar': 1}
    parser.root = {'Foo': 'Foo', 'Foo.f': 'Foo', 'Foo.Bar': 'Foo'}
    parser.imp = {'Foo': {'Foo'}}
    parser.api('Foo', parser.ast.body[0])

# Generated at 2022-06-23 15:34:02.404469
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('foo.bar')
    assert not is_public_family('foo.bar._qux')
    assert not is_public_family('foo.bar._qux.__')
    assert is_public_family('foo.bar.__qux')



# Generated at 2022-06-23 15:34:11.923908
# Unit test for constructor of class Resolver
def test_Resolver():
    tree = parse("arg1: typing.Union[int, float]")
    Resolver("root", {'root.typing': 'typing'}).visit(tree)
    assert unparse(tree).endswith("int | float")
    tree = parse("arg1: typing.Optional[str]")
    Resolver("root", {'root.typing': 'typing'}).visit(tree)
    assert unparse(tree).endswith("str | None")
    tree = parse("arg1: typing.Union[typing.T, typing.S]")
    Resolver("root", {'root.typing': 'typing'}).visit(tree)
    assert unparse(tree).endswith("T | S")

# Generated at 2022-06-23 15:34:21.503831
# Unit test for method compile of class Parser
def test_Parser_compile():
    #
    p = Parser()

# Generated at 2022-06-23 15:34:32.142336
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    target = Parser([], {}, link_source='')

# Generated at 2022-06-23 15:34:42.091429
# Unit test for method api of class Parser
def test_Parser_api():
    global __name__
    __name__ = '__doc__'
    parser = Parser(link=True, toc=True)

# Generated at 2022-06-23 15:34:47.066875
# Unit test for constructor of class Parser
def test_Parser():
    # Get Parser and create an instance
    parser = Parser(link=True)
    assert parser is not None
    parser = Parser(docstring=True, toc=False, link=False)
    assert parser is not None
    # Get docstring and test
    assert parser.__doc__ is not None
    assert parser.__doc__.startswith("Parse module") and \
           parser.__doc__.endswith("`__all__` filter\n")

# Generated at 2022-06-23 15:34:55.359275
# Unit test for constructor of class Resolver
def test_Resolver():
    """Unit test for constructor of class Resolver."""
    # a = x.y
    # b = [1, 2]
    # c = (1, 2)
    # d = {"a": 1, "b": 2}
    # e = 1 | 2
    # f = int(1)
    # g = float(1)
    # h = bool(1)
    # i = complex(1)
    # j = str(1)
    # k = typing.Optional[int]
    # l = typing.Union[int, str]
    # m = x.A
    # n = self.A
    # o = typing.Optional[self.A]
    # p = typing.Optional[A]
    # q = typing.Optional[typing.Union[int, str]]
    # r = typing.Optional[

# Generated at 2022-06-23 15:35:03.491006
# Unit test for method compile of class Parser
def test_Parser_compile():
    # For the method compile of class Parser
    # the generated documentation
    # should be the expected one
    m = parse_string('''
        a = 0
        ALL = [a]
        ''')
    md = Parser().parse(m)

# Generated at 2022-06-23 15:35:06.813094
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    assert Parser() == Parser()
    assert Parser() == Parser(link=True)
    assert Parser() != Parser(link=True)
    assert Parser(link=True) == None

# Generated at 2022-06-23 15:35:10.785835
# Unit test for function code
def test_code():
    assert code("") == ' '
    assert code("abc") == '`abc`'
    assert code("a`b") == '`a`b`'
    assert code("a|b") == '<code>a&#124;b</code>'



# Generated at 2022-06-23 15:35:16.168981
# Unit test for function code
def test_code():
    """Tests for function code."""
    assert code("a") == "`a`"
    assert code("a|b") == "<code>a&#124;b</code>"
    assert code("a&b") == "<code>a&b</code>"
    assert code("") == " "



# Generated at 2022-06-23 15:35:21.998423
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    """Test Resolver.visit_Subscript"""
    dic = {'example': 'typing', 'typing': 'typing'}
    r = Resolver('', dic)
    e = parse('example.Union[int, str]').body[0].value
    assert unparse(r.visit_Subscript(e)) == '(int | str)'
    e = parse('example.Optional[int]').body[0].value
    assert unparse(r.visit_Subscript(e)) == '(int | None)'
    e = parse('typing.Tuple[str, int]').body[0].value
    assert unparse(r.visit_Subscript(e)) == 'Tuple[str, int]'
    e = parse('typing.List[int]').body[0].value

# Generated at 2022-06-23 15:35:33.627282
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    # PEP585 and PEP604
    assert code(unparse(Resolver('typing', {})
                        .visit_Subscript(Subscript(Name('Union', Load),
                                                   Tuple([Name('str', Load),
                                                          Name('int', Load)],
                                                         Load),
                                                   Load)))) == "Union[str, int]"
    assert code(unparse(Resolver('typing', {})
                        .visit_Subscript(Subscript(Name('Optional', Load),
                                                   Name('str', Load),
                                                   Load)))) == "Optional[str]"
    assert code(unparse(Resolver('typing', {})
                        .visit_Subscript(Subscript(Name('TypeVar', Load),
                                                   Constant('T'),
                                                   Load)))) == "T"
   

# Generated at 2022-06-23 15:35:43.367036
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    import typing
    if Resolver("", {}).visit(parse("typing.MyType").body[0].value) != \
            parse("MyType").body[0].value:
        raise RuntimeError("error visit_Attribute")
    if Resolver("", {}).visit(parse("typing.Type[int]").body[0].value) != \
            parse("Type[int]").body[0].value:
        raise RuntimeError("error visit_Attribute")
    if Resolver("", {}).visit(parse("typing.List[int]").body[0].value) != \
            parse("List[int]").body[0].value:
        raise RuntimeError("error visit_Attribute")

# Generated at 2022-06-23 15:35:54.875701
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    import ast
    import inspect
    import importlib

    import_from = ImportFrom(
        module='time',
        names=[alias('asctime', 'time_asctime')],
        level=0,
    )
    module = Module(body=[import_from])
    m = parse_ast(module)

    class Dummy:
        def __init__(self):
            self.alias = {}
            self.doc = {}
            self.docstring = {}
            self.root = {}
            self.level = {}
            self.imp = {'.': {'time', 'time_asctime'}}

        def parse(self, m: ModuleType) -> None:
            self.alias['time_asctime'] = 'time.asctime'

# Generated at 2022-06-23 15:36:07.182348
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    import tempfile
    import importlib
    import sys
    import inspect

    tmp_dir = tempfile.TemporaryDirectory()
    sys.path.insert(0, tmp_dir.name)
    p = Parser()

    def _test_resolve(p: Parser, m: ModuleType, e: str, a: expr, s: str = '') -> None:
        assert p.resolve(m.__name__, a, self_ty=s) == e
        for f, v in inspect.getmembers(m):
            if isinstance(v, type):
                for c, a in inspect.getmembers(v):
                    if isinstance(a, type):
                        _test_resolve(
                            p, m, e, a, s=_m(m.__name__, v.__name__))

   

# Generated at 2022-06-23 15:36:11.656380
# Unit test for function esc_underscore
def test_esc_underscore():
    assert "foo" == esc_underscore("foo")
    assert r"foo\_bar" == esc_underscore("foo_bar")
    assert r"foo\_bar\_baz" == esc_underscore("foo_bar_baz")



# Generated at 2022-06-23 15:36:22.781737
# Unit test for function doctest
def test_doctest():
    doc = (
        "Blah\n"
        "    Blah\n"
        "    >>> print(1)\n"
        "    1\n"
        "    >>> print(2)\n"
        "    2\n"
    )
    out = (
        "Blah\n"
        "    Blah\n"
        "    ```python\n"
        "    >>> print(1)\n"
        "    1\n"
        "    >>> print(2)\n"
        "    2\n"
        "    ```\n"
    )
    assert doctest(doc) == out

# Generated at 2022-06-23 15:36:33.430300
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    class MockNode1(object):
        def __init__(self,a,b,c,d):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
    class MockNode2(object):
        def __init__(self,a,b):
            self.a = a
            self.b = b
    class MockNode3(object):
        def __init__(self,a):
            self.a = a
        def __repr__(self):
            return "MockNode3({})".format(self.a)

# Generated at 2022-06-23 15:36:40.577708
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    assert Resolver("mod", {}).visit_Constant(Constant(0)).value == 0
    assert Resolver("mod", {}).visit_Constant(Constant(None)).value is None
    assert Resolver("mod", {}).visit_Constant(Constant(0.0)).value == 0.0
    assert Resolver("mod", {}).visit_Constant(Constant(0j)).value == 0j
    assert Resolver("mod", {}).visit_Constant(Constant('"')).value == '"'
    assert Resolver("mod", {}).visit_Constant(Constant("")).value == ""
    assert Resolver("mod", {}).visit_Constant(Constant(())).value == ()

# Generated at 2022-06-23 15:36:47.238875
# Unit test for function is_public_family
def test_is_public_family():
    assert not is_public_family("os.path._response_")
    assert not is_public_family("os._response_")
    assert not is_public_family("_response_")
    assert is_public_family("os.path.response")
    assert is_public_family("os.response")
    assert is_public_family("response")
    assert is_public_family("os.path.__name__")



# Generated at 2022-06-23 15:36:56.214314
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    def func(a, b=3, *args, kwonly=True, kwargs=None, **kwds):
        return 0
    p = Parser()
    name = 'root.func'
    args = inspect.signature(func).parameters
    has_self = False
    cls_method = False
    p_func_api = p.func_ann(p, name, args, has_self=has_self, cls_method=cls_method)
    param_string = str(next(p_func_api))
    assert(param_string == 'a: Any')

# Generated at 2022-06-23 15:37:05.966056
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    r = Resolver("", {})

# Generated at 2022-06-23 15:37:12.345845
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert Resolver('a', {}).visit(parse('Union[int, float]').body[0]).body[0].value == 'typing.Union[int, float]'
    assert Resolver('a', {}).visit(parse('Optional[int]').body[0]).body[0].value == 'typing.Optional[int]'
    assert Resolver('a', {}).visit(parse('List[int]').body[0]).body[0].value == 'typing.List[int]'


# Generated at 2022-06-23 15:37:15.667675
# Unit test for method globals of class Parser

# Generated at 2022-06-23 15:37:17.112339
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__hello__')
    assert not is_magic('hello')



# Generated at 2022-06-23 15:37:27.091910
# Unit test for method __eq__ of class Parser

# Generated at 2022-06-23 15:37:37.512145
# Unit test for method globals of class Parser
def test_Parser_globals():
    from ast import Assign, Name, Constant

    class Dummy:
        """Dummy class for testing."""

    p = Parser()
    p.globals('module', Assign(
        [Name('name', None)], Constant('value', None)))
    assert p.alias['module.name'] == 'value'
    assert p.const['module.name'] == 'str'
    assert p.root['module.name'] == 'module'

    p.globals('module', Assign(
        [Name('name', None)], Constant(10, None)))
    assert p.alias['module.name'] == '10'
    assert p.const['module.name'] == 'int'
    assert p.root['module.name'] == 'module'


# Generated at 2022-06-23 15:37:49.721064
# Unit test for function walk_body
def test_walk_body():
    ast = parse(u"""\
if a == 1: print('a')
if a == 2:
    print('b')
else:
    print('c')
try:
    print('d')
except:
    print('e')
    print('f')
else:
    print('g')
    print('h')
finally:
    print('i')
    print('j')
print('k')
""")
    assert len(ast.body) == 1
    assert len(ast.body[0].body) == 1
    assert len(ast.body[0].body[0].body) == 1
    assert len(ast.body[0].body[0].orelse) == 1
    assert len(ast.body[0].body[0].body[0].body) == 10

# Generated at 2022-06-23 15:38:01.791186
# Unit test for function const_type
def test_const_type():
    assert const_type(parse('True').body[0].value) == 'bool'
    assert const_type(parse('"hello"').body[0].value) == 'str'
    assert const_type(parse('1').body[0].value) == 'int'
    assert const_type(parse('1.0').body[0].value) == 'float'
    assert const_type(parse('(1, 2)').body[0].value) == 'tuple[int, int]'
    assert const_type(parse('[1, 2]').body[0].value) == 'list[int, int]'
    assert const_type(parse('{1, 2}').body[0].value) == 'set[int, int]'

# Generated at 2022-06-23 15:38:14.365769
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    import json
    from . import parse_importdoc, parse_docstring, parse_functiondoc
    from .parse_importdoc import Parser
    from .settings import LANG
    from .utils import esc_underscore, get_docstring, is_magic, parent
    from doctools import parse_doctest
    from inspect import getdoc
    from types import ModuleType
    LANG_aliases = {}
    LANG_aliases['python'] = {
        '': '.py',
        'py': '.py',
        'pyi': '.pyi',
    }
    LANG_aliases['rust'] = {
        'rs': '.rs',
        'rsi': '.rsi',
    }
    LANG_aliases['julia'] = {
        'jl': '.jl',
    }

# Generated at 2022-06-23 15:38:24.822027
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser(None)
    def func(a, *args, b, c=None, **kwargs): ...
    arg = argparse.Namespace()
    arg.args = [argparse.Namespace(annotation=None, arg='a'),
                argparse.Namespace(annotation=ast.Name(id='int', ctx=LOAD),
                                   arg='*args'),
                argparse.Namespace(annotation=None, arg='b'),
                argparse.Namespace(annotation=None, arg='c'),
                argparse.Namespace(annotation=ast.Name(id='str', ctx=LOAD),
                                   arg='**kwargs')]
    arg.defaults = [None, None, None]

# Generated at 2022-06-23 15:38:31.448422
# Unit test for function walk_body
def test_walk_body():
    example = """if i == 100:
    return True
else:
    return False
return True"""
    API = parse(example).body[0]
    body = API.body
    if API.orelse:
        body += API.orelse
    assert len(body) == 3
    for b in walk_body(body):
        assert isinstance(b, Return)
    example = """if i == 100:
    if i == 200:
        return True
    else:
        return False
return True"""
    API = parse(example).body[0]
    body = API.body
    if API.orelse:
        body += API.orelse
    with logging.capture(logger) as log_capture:
        for b in walk_body(body):
            assert isinstance(b, Return)

# Generated at 2022-06-23 15:38:35.382128
# Unit test for function parent
def test_parent():
    assert parent('a.b.c') == 'a.b'
    assert parent('a.b.c.d.e', level=2) == 'a.b.c'
    assert parent('a', level=2) == ''



# Generated at 2022-06-23 15:38:39.873602
# Unit test for function parent
def test_parent():
    assert parent('a') == ''
    assert parent('a.b') == 'a'
    assert parent('a.b.c') == 'a.b'
    assert parent('a.b.c', level=2) == 'a'



# Generated at 2022-06-23 15:38:50.159053
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from . import parse_ast
    from . import parse_type
    from . import type_mapping
    from . import const_type
    from . import skip_visitor_t
    class _R(skip_visitor_t):
        def __init__(self, root: str, alias: Mapping[str, str], self_ty: str):
            super().__init__()
            self.root = root
            self.alias = alias
            self.self_ty = self_ty

        def visit_Name(self, node: Name) -> Name:
            n = self.alias.get(node.id, node.id)
            return Name(n, Load()) if node.id == n else Name(n, node.ctx)


# Generated at 2022-06-23 15:38:58.710814
# Unit test for method compile of class Parser
def test_Parser_compile():
    parser = Parser(
        doc={'x': "a"},
        docstring={'x': "b"},
        root={'x': 'x'},
        level={'x': 0},
        alias={'x': 'x'},
        imp={'': set()},
        const={'x': 'x'},
        toc=True,
        link=False,
    )
    assert parser.compile() == "a\n\n**Table of contents:**\n\n+ [`x`](#x)\n\nb\n"


# Generated at 2022-06-23 15:39:07.408970
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    """Unit test for method func_api of class Parser.
    This function is called by pytest.
    """
    def test(funcdef: str, has_self: bool, cls_method: bool, expected: str) -> None:
        """Test with the sample function.
        :param func_def: a sample function definition string.
        :param has_self: If a function is a method, has_self is True
        :param cls_method: If a function is a class method, cls_method is True
        :param expected: expected function annotation table
        """
        m = ast.parse(funcdef)
        parser = Parser('root')
        node: _I = next(iter(m.body))
        assert isinstance(node, (FunctionDef, AsyncFunctionDef))

# Generated at 2022-06-23 15:39:15.762600
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    root = 'A'
    alias = {"B": "C"}
    imp = {root: [root, "A.E"]}
    b_level = 1
    link = True
    const = {"A.D": "str"}
    doc = {"A.C": "AAA"}
    docstring = {"A": "BBB"}
    level = {"A": 1, "A.C": 2}

    p1 = Parser(
        alias, imp, b_level, link, const, doc, docstring, level)
    p2 = Parser(
        alias, imp, b_level, link, const, doc, docstring, level)
    assert p1 == p2


# Generated at 2022-06-23 15:39:26.328300
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    from ast import parse
    from .data.test_functions import test_Resolver_visit_Constant
    root = 'test_functions'
    doc, alias = getdoc(test_Resolver_visit_Constant), {
        'test_functions': 'aiohttp.web',
    }
    node = parse(doc).body[0]
    resolver = Resolver(root, alias)
    e = resolver.visit(node.body[0].value)
    assert isinstance(e, Call)
    assert e.func.id == 'ClientSession'
    e = resolver.visit(e.args[0])
    assert isinstance(e, Call)
    assert e.func.id == 'ClientResponse'
    assert e.args[0].id == 'request'



# Generated at 2022-06-23 15:39:28.437284
# Unit test for function parent
def test_parent():
    assert parent('sympy.geometry.point.Point', level=1) == 'sympy.geometry.point'
    assert parent('sympy.geometry.point.Point', level=2) == 'sympy.geometry'



# Generated at 2022-06-23 15:39:37.192140
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    n = Attribute(Name('typing', Load()), 'Literal', Load())
    assert Resolver("", {}).visit(n).__dict__ == Name('Literal', Load()).__dict__
    assert Resolver("", {}).visit(n).__dict__ == Name('Literal', Load()).__dict__
    n = Attribute(Name('typing', Load()), 'Optional', Load())
    assert Resolver("", {}).visit(n).__dict__ == Name('Optional', Load()).__dict__
    assert Resolver("", {}).visit(n).__dict__ == Name('Optional', Load()).__dict__
    n = Attribute(Name('typing', Load()), 'ClassVar', Load())

# Generated at 2022-06-23 15:39:42.870911
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('_local') == False
    assert is_public_family('_local.abc') == False
    assert is_public_family('abc._local') == False
    assert is_public_family('__magic.__mro__') == True
    assert is_public_family('__magic__') == True
    assert is_public_family('__mro__.__magic__') == True



# Generated at 2022-06-23 15:39:43.815479
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    parser = Parser(1)
    assert parser.b_level == 1

# Generated at 2022-06-23 15:39:49.115577
# Unit test for method globals of class Parser
def test_Parser_globals():
    code = """
from typing import Optional

from yapic.di import Injector
from yapic.server import Server, run_server


__version__ = '0.1.0'
"""
    pl = Parser()
    m = Pluggable()
    m.code = code
    root = 'app.__init__'
    pl.parse(code, root)

# Generated at 2022-06-23 15:39:52.518700
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    alias = {
        'foo.bar.x': 'Union[int, str]'
    }
    node = Name('x', Load())
    node = Resolver('foo.bar', alias).visit(node)
    assert unparse(node) == 'Union[int, str]'

# Generated at 2022-06-23 15:40:04.670322
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    """test method __repr__"""
    t = _Parser()
    import ast
    t.walk(ast.parse('def f() -> int:\n    pass'))
    assert t.alias["f"] == "int"
    assert t.doc["f"] == "## f()\n\n*Full name:* `f`\n\n" + \
        table("Type", items=["int"]) + "\n\n"
    assert t.docstring["f"] is None
    t = _Parser(link=True)
    t.walk(ast.parse('def f() -> int:\n    pass'))
    assert t.alias["f"] == "int"