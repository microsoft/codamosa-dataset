

# Generated at 2022-06-23 15:30:06.358773
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    alias = cast('', dict[str, str])
    root = ''
    self_ty = ''
    node = Name('Name', Load())
    assert isinstance(Resolver(root, alias, self_ty).visit_Name(node), Name)


# Generated at 2022-06-23 15:30:16.087278
# Unit test for constructor of class Resolver
def test_Resolver():
    """Test the Resolver class."""
    from typing import Optional, List
    from .attractors import Attractor
    from .composites import Linkage
    from .solver import Solver
    from pyslvs import AbstractSolver

    @dataclass(repr=False)
    class TestResolver(Resolver):
        """A subclass for unit test."""

    assert TestResolver('a.b.c', {'a.b.c': ""}, "ABC").root == 'a.b.c'
    alias = {'pyslvs.AbstractSolver': AbstractSolver, 'pyslvs.Attractor': Attractor,
             'pyslvs.Linkage': Linkage, 'pyslvs.Solver': Solver}

# Generated at 2022-06-23 15:30:21.872536
# Unit test for function walk_body
def test_walk_body():
    source = """
if a > 0:
    if b > 0:
        pass
else:
    try:
        if c > 0:
            pass
    except Exception:
        pass
    except:
        pass
    else:
        pass
    finally:
        pass
    """
    node = parse(source, mode='exec').body[0]
    assert len(list(walk_body(node.body))) == 3
    assert len(list(walk_body(node.orelse))) == 9



# Generated at 2022-06-23 15:30:30.633278
# Unit test for method api of class Parser
def test_Parser_api():
    import ast
    import astor
    import enum
    import inspect
    import io
    import sys

    class MemoryIO(io.IOBase):
        def __init__(self):
            self.buffer = []
            super().__init__()

        def readable(self):
            return True

        def writable(self):
            return True

        def seekable(self):
            return False

        def read(self, size: int = -1) -> bytes:
            return b''.join(self.buffer)

        def write(self, b: bytes) -> int:
            self.buffer.append(b)
            return len(b)

        def getvalue(self):
            return b''.join(self.buffer)


    sys.stdout = sys.stderr = MemoryIO()


# Generated at 2022-06-23 15:30:36.158362
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    from pprint import pformat
    from .pdoc import Parser
    import ast

    class Test(ast.NodeVisitor):
        def visit_Module(self, node):
            return Parser(node)

    p = Test().visit(ast.parse('x: int'))
    assert repr(p) == '<Parser: {' + pformat(p.__dict__) + '}>'

# Generated at 2022-06-23 15:30:46.439673
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    m = 'model.typing'
    p.alias[_m('')] = 'model'
    p.alias[_m(m)] = m
    p.alias[_m(m, 'List')] = 'model.typing.List'
    p.alias[_m(m, 'Dict')] = 'model.typing.Dict'
    p.alias[_m(m, 'Tuple')] = 'model.typing.Tuple'
    p.alias[_m(m, 'Union')] = 'model.typing.Union'
    p.alias[_m(m, 'Callable')] = 'model.typing.Callable'
    p.alias[_m(m, 'Literal')] = 'model.typing.Literal'

# Generated at 2022-06-23 15:30:47.217088
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    assert Parser() != None # Exception raise in assert statement

# Generated at 2022-06-23 15:30:52.471669
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    resolver = Resolver('root', {})
    expr = parse('(int, 12)').body[0].value
    assert expr.elts[0].s == 'int'
    node = resolver.visit(expr)
    assert isinstance(node, Tuple)
    assert node.elts[0].s == 'int'


# Generated at 2022-06-23 15:30:54.048216
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert Resolver('', {}).visit_Attribute(parse('typing.typing').body[0]) == Name('typing', Load())


# Generated at 2022-06-23 15:31:02.856840
# Unit test for function walk_body
def test_walk_body():
    class A:
        def __init__(self):
            self.a = 1
            if self.a > 0:
                self.b = 2
            else:
                self.b = 3
            try:
                self.c = 3
            except:
                self.c = 4
            finally:
                self.d = 9
        def abc(self):
            pass
    assert all(isinstance(a, Assign) for a in walk_body(A.__init__.__code__.co_consts[0]))



# Generated at 2022-06-23 15:31:15.465503
# Unit test for function code
def test_code():
    assert code('1') == '`1`'
    assert code('a') == '`a`'
    assert code('1a1') == '`1a1`'
    assert code('a&b') == '<code>a&amp;b</code>'
    assert code('&a') == '<code>&amp;a</code>'
    assert code('&ab') == '<code>&amp;ab</code>'
    assert code('a&bc') == '<code>a&amp;bc</code>'
    assert code('a|b') == '<code>a&#124;b</code>'
    assert code('|a') == '<code>&#124;a</code>'
    assert code('|ab') == '<code>&#124;ab</code>'


# Generated at 2022-06-23 15:31:20.100647
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert isinstance(Resolver('', {}).visit_Attribute(Attribute(Name('typing', Load()), 'Type', Load())), Name)
    assert isinstance(Resolver('', {}).visit_Attribute(Attribute(Attribute(Name('typing', Load()), 'Type', Load()), 'Type', Load())), Attribute)


# Generated at 2022-06-23 15:31:28.665138
# Unit test for function table
def test_table():
    t = table
    e = lambda s: s.replace(' ', '')
    assert e(t('a', 'b', 'c', [['d', 'e', 'f'], ['g', 'h', 'i']])) == \
        e("a | b | c |\n:---:|:---:|:---:|\nd|e|f|\ng|h|i|")
    assert e(t('a', [['b'], ['c']])) == \
        e("a |\n:---:|\nb|\nc|")



# Generated at 2022-06-23 15:31:35.429705
# Unit test for method imports of class Parser
def test_Parser_imports():
    import typing as py_typing
    import tempfile
    from importlib import util, reload


# Generated at 2022-06-23 15:31:38.819863
# Unit test for constructor of class Resolver
def test_Resolver():
    root, alias, self_ty = 'root', {}, ''
    tree = parse('value: Union[int, float, None] = 0')
    r = Resolver(root, alias, self_ty)
    node = cast(Assign, tree.body[0])
    node.value = r.visit(node.value)
    assert node.value.left.id == 'int'
    assert node.value.comparators[0].id == 'float'
    assert node.value.comparators[1].value is None



# Generated at 2022-06-23 15:31:49.701814
# Unit test for method compile of class Parser
def test_Parser_compile():
    cache = {
        'abc.abc.abc.abc': Module(),
        'abc.abc.abc.def': Module(),
        'abc.abc.def': Module(),
        'abc.def': Module(),
        'def': Module(),
    }
    cache['root'] = cache['abc'] = Module('abc.py')
    cache['root'].__dict__['__all__'] = ('abc', )
    cache['abc.py'].__dict__['__doc__'] = '''
    ABC module.
    '''
    cache['abc'].__dict__['__doc__'] = '''
    ABC class doc.
    '''
    cache['abc'].__dict__['def'] = '''
    def function.
    '''

# Generated at 2022-06-23 15:31:54.487287
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    root = 'b'
    name = 'b.c'
    bases = [ast.parse('tuple').body[0].value.elts[0], ast.parse('b.Y').body[0].value]
    body = ast.parse('def __init__(): pass').body
    p = Parser()
    p.class_api(root, name, bases, body)
    assert p.doc == {'b.c': '### class c\n\n*Full name:* `b.c`\n\n' + '```\ntuple\n' + '```\n\n' + '*Full name:* `b.Y`\n\n'}, \
        "Docstring added incorrectly"

# Generated at 2022-06-23 15:32:01.344121
# Unit test for function is_public_family
def test_is_public_family():
    assert not is_public_family('___s')
    assert not is_public_family('_m')
    assert is_public_family('s')
    assert is_public_family('pyslvs_ui.__main__.s')
    assert is_public_family('something')
    assert not is_public_family('_something')
    assert not is_public_family('pyslvs_ui.something')
    assert not is_public_family('pyslvs_ui._something')
    assert not is_public_family('pyslvs_ui.__main__._something')



# Generated at 2022-06-23 15:32:08.897286
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    rl = Resolver
    assert rl('a', {'a': ''}).visit(Subscript(Name('a', Load()),
                                              Subscript(Constant(0),
                                                        Constant(0),
                                                        Load()),
                                              Load())
                                    ) == BinOp(BinOp(Name('a', Load()),
                                                     BitOr(),
                                                     Constant(None)),
                                               BitOr(),
                                               Constant(None))
    assert rl('a', {'a': ''}).visit_Subscript(Subscript(
        Name('a', Load()), Constant(1), Load())) == BinOp(
        BinOp(Constant(1), BitOr(), Constant(None)), BitOr(), Constant(None))
test_Resolver_visit_Subscript()
# Unit

# Generated at 2022-06-23 15:32:19.580165
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    def method0(self, node):
        """Caller of self.visit(node)"""
        return self.visit(node)
    test = Resolver('root', {})
    node = Constant(1)
    assert method0(test, node) == Constant(1)
    node = Constant('1')
    assert method0(test, node) == Constant('1')
    node = Constant('let i = 1')
    assert method0(test, node) == Constant('let i = 1')
    node = Constant('2.0')
    assert method0(test, node) == Constant('2.0')
    node = Constant('3j')
    assert method0(test, node) == Constant('3j')
    node = Constant('"4"')
    assert method0(test, node) == Constant('"4"')


# Generated at 2022-06-23 15:32:21.603709
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    p = Parser()
    assert repr(p) == '<Parser>'

# Generated at 2022-06-23 15:32:31.455094
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    p.imp['A'] = set(['A'])
    # A -> A
    p.imp['A.B'] = set(['A.B'])
    # A.B -> A.B, A
    p.imp['A.C'] = set(['A.C'])
    # A.C -> A.C, A
    p.imp['A.D'] = set(['A'])
    # A.B -> A
    p.imp['A.E'] = set()
    # A.E -> A
    assert p.is_public('A')
    assert p.is_public('A.B')
    assert p.is_public('A.C')
    assert p.is_public('A.D')
    assert not p.is_public('A.E')

# Generated at 2022-06-23 15:32:38.725855
# Unit test for method api of class Parser
def test_Parser_api():
    from ..ast import parse
    from ..lexer import Lexer
    from ..parser import Parser
    from .test_test_type import TestType
    class MyTestType(TestType):
        def __init__(self, *args, **kwargs):
            self.__args = args
            self.__kwargs = kwargs
        @property
        def type(self):
            return self.__args, self.__kwargs
    _m = 'foo.bar'
    l = Lexer('')
    p = Parser(l)
    p.api(_m, parse(MyTestType(1, b=2), mode='eval'))
    assert p.doc[_m].startswith('# MyTestType()\n\n')
    assert p.doc[_m].endswith('```\n')


# Generated at 2022-06-23 15:32:43.382537
# Unit test for function is_magic
def test_is_magic():
    assert not is_magic("")
    assert not is_magic("test")
    assert not is_magic("test_test")
    assert is_magic("__test__")
    assert is_magic("__Test__")
    assert is_magic("__t_e_s_t__")
    assert is_magic("__")



# Generated at 2022-06-23 15:32:47.536613
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert parse("int").body[0].value == Name("int", Load)
    assert parse("typing.int").body[0].value == \
        Attribute(Name("typing", Load), "int", Load)
    assert cast(Resolver("", {}).visit_Attribute, Attribute)(
        parse("typing.int").body[0].value
    ).attr == "int"


# Generated at 2022-06-23 15:32:48.661256
# Unit test for constructor of class Parser
def test_Parser():
    import doctest
    doctest.testmod()

if __name__ == "__main__":
    test_Parser()

# Generated at 2022-06-23 15:32:53.328919
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p.alias == {}
    assert p.doc == {}
    assert p.level == {}
    assert p.imp == {}
    assert p.root == {}
    assert p.const == {}
    assert p.docstring == {}
    assert p.b_level == 2


# Generated at 2022-06-23 15:32:54.802412
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    p: Parser = Parser(link=True, toc=True)
    assert repr(p) == 'Parser(link=True, toc=True, verbose=False)'


# Generated at 2022-06-23 15:33:01.216083
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    import ast
    import textwrap
    from typing import Dict, List, Tuple

    from . import reader
    from .reader import reader
    from .parser import Parser

    # region Constant
    READER_INPUT = Dict[str, bytes]
    # endregion

    def test_case(
            reader_input: READER_INPUT,
            *,
            file_name: str,
            code: str,
            expected: List[Tuple[str, str]]
    ) -> None:
        # region Arrange
        parser = Parser(link=False)
        # endregion

        # region Act
        root = parser.read(**reader_input)
        parser.parse(root, ast.parse(textwrap.dedent(code)))

# Generated at 2022-06-23 15:33:03.892364
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('os.path')
    assert not is_public_family('abc._abc')
    assert is_public_family('abc.abc_name')
    assert not is_public_family('sys._name')



# Generated at 2022-06-23 15:33:05.203999
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    ast_node = parse("")
    p = Parser()
    assert p.func_ann("", []) == []


# Generated at 2022-06-23 15:33:16.926819
# Unit test for method globals of class Parser
def test_Parser_globals():
    root = '__main__'
    p = Parser(doc=False)
    p.globals(root, parse_expr("a = 'abc'", filename='<<unknown>>', mode='eval'))
    assert p.alias == {'__main__.a': 'a'}
    assert p.root == {'__main__.a': '__main__'}
    assert p.level == {'__main__': 0}
    assert p.doc == {}
    assert p.docstring == {}
    assert p.const == {}
    assert p.imp == {'__main__': set()}
    p.globals(root, parse_expr("A = 123", filename='<<unknown>>', mode='eval'))

# Generated at 2022-06-23 15:33:23.996591
# Unit test for method imports of class Parser
def test_Parser_imports():
    import unittest
    from ast import Import, ImportFrom, Name, Store
    from typing import List
    from test.dummy import Dummy

    class TestParserImports(unittest.TestCase):
        maxDiff = None
        def test_module_import(self):
            imports = [Import([Name(id='f1', ctx=Store())]),
                       Import([Name(id='f2', ctx=Store())], lineno=2)]
            p = Parser().load([f for f in imports if f.lineno == 2])
            p.imports('dummy.f2', imports[0])
            p.imports('dummy.f2', imports[1])

# Generated at 2022-06-23 15:33:34.947011
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    assert list(p.func_ann('', [arg('', None)])) == ['Self']
    assert list(p.func_ann('', [arg('a', Name('A', None))])) == ['A']
    assert list(p.func_ann('', [arg('*a', Name('A', None))])) == ['', 'A']

    r = Resolver('', dict(A="", B="B", C="C"), "")
    assert list(p.func_ann('', [arg('', None)], has_self=False)) == ['Self']
    assert list(p.func_ann('', [arg('*a', Name('A', None))])) == ['', 'A']
    assert list(p.func_ann('', [arg('a', Name('A', None))]))

# Generated at 2022-06-23 15:33:38.580940
# Unit test for function table
def test_table():
    assert table('a', 'b', [['c', '1'], ['d', '2']]) == """\
| a | b |
|:---:|:---:|
| c | 1 |
| d | 2 |

"""
test_table()



# Generated at 2022-06-23 15:33:48.254183
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    import pytest
    p = Parser()
    p.root['root.sub1.sub2'] = 'root'
    p.root['root.sub1.sub2.sub2sub1'] = 'root.sub1.sub2'
    p.root['root.sub1.sub2.sub2sub1subsub1'] = 'root.sub1.sub2.sub2sub1'
    p.imp['root'] = set()
    p.imp['root.sub1.sub2'] = {'root'}
    p.imp['root.sub1.sub2.sub2sub1'] = {'root.sub1', 'sub2sub1subsub1'}

# Generated at 2022-06-23 15:33:54.615049
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__init__')
    assert is_magic('__a__')
    assert is_magic('__a')
    assert not is_magic('__a_')
    assert not is_magic('a__')
    assert not is_magic('init')
    assert not is_magic('a')
    assert not is_magic('')
test_is_magic()



# Generated at 2022-06-23 15:33:59.987061
# Unit test for function parent
def test_parent():
    assert parent('abc') == ''
    assert parent('abc.def') == 'abc'
    assert parent('abc.def.ghi') == 'abc.def'
    assert parent('abc.def', level=2) == ''
    assert parent('abc.def.ghi', level=2) == 'abc'



# Generated at 2022-06-23 15:34:04.916524
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(
        pathlib.Path(__file__) / '../../pytype/src/pytype/pytd/parse_module.py')
    # print(json.dumps(parser.doc))
    # print(json.dumps(parser.alias))
    assert parser.doc

# Generated at 2022-06-23 15:34:08.714696
# Unit test for function table
def test_table():
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == '''\
| a | b |
|:---:|:---:|
| c | d |
| e | f |
'''
test_table()



# Generated at 2022-06-23 15:34:11.901058
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("_api_") == r"\_api\_"
    assert esc_underscore("var_1") == "var_1"
    assert esc_underscore("_var_") == r"\_var\_"



# Generated at 2022-06-23 15:34:17.646303
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    p = Parser()
    p2 = Parser()
    assert p == p2

    p2.link = True
    assert p != p2
    p.link = True

    p2.b_level = 1
    assert p != p2
    p.b_level = 1

    p2.toc = False
    assert p != p2
    p.toc = False

# Generated at 2022-06-23 15:34:24.916495
# Unit test for method imports of class Parser
def test_Parser_imports():
    """Unit test for method imports of class Parser"""
    p = Parser([], [])
    root, node = 'a', ImportFrom('b', [alias('c', 'd')], 0)
    p.imports(root, node)
    eq_(root + '.c', p.alias['a.c'])
    eq_('c', p.alias['a.d'])
    node = Import('e as f, g')
    p.imports(root, node)
    eq_('e', p.alias['a.e'])
    eq_('e', p.alias['a.f'])
    eq_('g', p.alias['a.g'])
    eq_('h', p.alias['a.h'])
    eq_({}, p.alias)
    node = Import('i')
   

# Generated at 2022-06-23 15:34:26.100246
# Unit test for function table
def test_table():
    print(table('a', 'b', [['c', 'd'], ['e', 'f']]))


# Generated at 2022-06-23 15:34:27.230838
# Unit test for function is_magic
def test_is_magic():
    assert not is_magic('')
    assert is_magic('__magic__')



# Generated at 2022-06-23 15:34:35.700168
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    import builtins as __builtin__
    from typing import Iterator, Iterable, Tuple, List
    from typing import Union as U
    import types
    import abc
    import enum
    import collections

    def _is(t1, t2): return t1 == t2 or issubclass(t1, t2)

    assert (_is(_type(Parser.func_api(None, None, None, None, False, False)),
                types.MethodType))

    assert (_is(_type(Parser.func_api(None, None, None, None, False, False)()),
                Iterator[str]))



# Generated at 2022-06-23 15:34:45.103422
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    """Test method Parser.resolve."""
    p = Parser()
    p.alias['a.b'] = 'c.d'
    p.alias['c.d'] = 'd.e'
    p.alias['d.e'] = 'B'
    p.alias['e.f'] = 'G'
    p.alias['h.i'] = 'e.f.A'
    p.alias['e.f.A'] = 'H'
    p.alias['d'] = 'D'
    p.alias['e'] = 'E'
    p.alias['g'] = 'G'
    p.alias['h'] = 'H'

# Generated at 2022-06-23 15:34:51.327594
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    import inspect
    import ast
    import aifix
    m = inspect.getmodule(aifix.api)
    root = 'aifix.api'
    alias = Parser(0).alias
    r = Resolver(root, alias)
    assert(
        'type[aifix.api.Parser]'
        == r.resolve(ast.parse('type[aifix.api.Parser]').body[0])
    )

# Generated at 2022-06-23 15:34:58.587911
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    root = 'a.b'
    doc = {
        'a.b': '',
        'a.b.c': '',
        'a.d': '',
    }
    docstring = {}
    const = {}
    alias = {}
    imp = {'a.b': {'c', 'd'}, 'a.b.c': {}, 'a.d': {}}
    level = {'a.b': 1, 'a.b.c': 2, 'a.d': 1}
    root_ = {'a.b': 'a.b', 'a.b.c': 'a.b', 'a.d': 'a.d'}
    p = Parser(doc, docstring, const, alias, imp, level, root, root_, False)

# Generated at 2022-06-23 15:35:08.206960
# Unit test for function doctest
def test_doctest():
    doc = """
    >>> import pyslvs
    >>> pyslvs
    <module 'pyslvs' from '.../pyslvs/__init__.py'>
    >>> pyslvs.__doc__
    "Solve for the positions of the links in a planar kinematic chain."
    >>> pyslvs.version
    '1.1.0'
    >>> pyslvs.version.__doc__
    'This version number.'
    """
    assert doctest(doc) == doc.splitlines()[1:]



# Generated at 2022-06-23 15:35:09.706161
# Unit test for function code
def test_code(): assert code("") == " "; assert code("a") == "`a`"



# Generated at 2022-06-23 15:35:16.653331
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():

    # check class Resolver
    assert issubclass(Resolver, NodeTransformer), "class Resolver is not a subclass of NodeTransformer"

    # check function visit_Name
    # init instance Resolver
    assert Resolver is not None, "class Resolver can not be init"

    # call function visit_Name
    # class Resolver can not be called
    assert Resolver is not None, "class Resolver can not be called"



# Generated at 2022-06-23 15:35:22.502998
# Unit test for function is_public_family
def test_is_public_family():
    assert not is_public_family('test._test')
    assert not is_public_family('test.test_test')
    assert not is_public_family('test.__test__')
    assert not is_public_family('test.test_test.__test__')
    assert is_public_family('test.test')
    assert is_public_family('test.test_test.test')



# Generated at 2022-06-23 15:35:30.067958
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    t = 'typing.NewType'
    n = Name(t, Load())
    alias = {'typing.NewType': "'abc'"}
    assert Resolver('typing', alias).visit(n).s == "'abc'"
    alias = {'typing.NewType': "typing.NewType('abc',int)"}
    assert Resolver('typing', alias).visit(n).id == 'abc'
    assert Resolver('typing', alias).visit(n).s == 'abc'

# Generated at 2022-06-23 15:35:36.670989
# Unit test for constructor of class Parser
def test_Parser():
    """Unit test for Parser"""
    p = Parser()
    assert p.link == False
    assert p.toc == True
    assert p.b_level == 3
    assert p.doc == {}
    assert p.docstring == {}
    assert p.level == {}
    assert p.imp == {'': set()}
    assert p.alias == {}
    assert p.const == {}


# Generated at 2022-06-23 15:35:45.278986
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    parser = Parser(False)
    null = None
    class Assign:
        def __init__(self, value):
            self.type_comment = value
    class Arg:
        def __init__(self, arg, annotation):
            self.arg = arg
            self.annotation = annotation
    class Arguments:
        def __init__(self, args=None, defaults=None, vararg=null,
                     kwonlyargs=None, kw_defaults=None, kwarg=null):
            self.args = args
            self.defaults = defaults
            self.vararg = vararg
            self.kwonlyargs = kwonlyargs
            self.kw_defaults = kw_defaults
            self.kwarg = kwarg

# Generated at 2022-06-23 15:35:51.011696
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    r = Resolver('root_module', {'root_module.b': 'int'}, '')
    assert r.visit(Name('a', Load())).id == 'a'
    assert r.visit(Name('b', Load())).id == 'int'
    assert r.visit(Name('c', Load())).id == 'c'


# Generated at 2022-06-23 15:35:57.451917
# Unit test for function parent
def test_parent():
    assert parent('a') == 'a'
    assert parent('a.b') == 'a'
    assert parent('a.b.c') == 'a.b'
    assert parent('a.b.c', level=2) == 'a'
    assert parent('a.b.c', level=3) == ''
    assert parent('a.b.c', level=4) == ''
    assert parent('a.b.c', level=5) == ''

# Generated at 2022-06-23 15:36:04.176195
# Unit test for constructor of class Resolver
def test_Resolver():
    r = Resolver('test_module', {'test_module.Dict': 'typing.Dict[K, V]'})
    a = r.visit(parse('Dict[K, V]').body[0])
    assert isinstance(a, Name)
    assert a.id == 'Dict'

Node = TypeVar('Node', bound=AST)



# Generated at 2022-06-23 15:36:10.445432
# Unit test for function esc_underscore
def test_esc_underscore():
    name = "solve_pyslvs"
    assert esc_underscore(name) == "solve\_pyslvs"
    name = "pyslvs"
    assert esc_underscore(name) == "pyslvs"
    name = "solve_pyslvs_config"
    assert esc_underscore(name) == "solve\_pyslvs\_config"



# Generated at 2022-06-23 15:36:13.973945
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__magic__')
    assert is_magic('test__magic__test')
    assert is_magic('pyslvs__magic__pyslvs')
    assert not is_magic('__magic')
    assert not is_magic('__magic_')
    assert not is_magic('magic__')
    assert not is_magic('magic')

# Generated at 2022-06-23 15:36:26.313043
# Unit test for function const_type
def test_const_type():
    """Unit test for function const_type."""
    assert const_type(parse("[]").body[0]) == "[]"
    assert const_type(parse("[1]").body[0]) == "[int]"
    assert const_type(parse("[1, 'str']").body[0]) == "[Any]"
    assert const_type(parse("[1, 2]").body[0]) == "[int]"
    assert const_type(parse("['str', 'str']").body[0]) == "[str]"
    assert const_type(parse("{}").body[0]) == "dict"
    assert const_type(parse("{1: 2}").body[0]) == "dict[int, int]"
    assert const_type(parse("{1, 2}").body[0]) == "{int}"

# Generated at 2022-06-23 15:36:32.215471
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    n = Subscript(Name('X', Load()), Tuple(elts=[
        Name('int', Load()), Name('float', Load())
    ], ctx=Load()), Load())
    a = {'root.X': 'typing.Union[int, float]'}
    r = Resolver('root', a)
    r.visit(n)
    assert n == BinOp(Name('int', Load()), BitOr(), Name('float', Load()))

# Generated at 2022-06-23 15:36:35.136984
# Unit test for function parent
def test_parent():
    n = __name__
    assert parent(n, level=0) == n
    assert parent(n, level=1) == _m(n)
    assert parent(n, level=2) == _m(n, n)



# Generated at 2022-06-23 15:36:48.383132
# Unit test for function const_type
def test_const_type():
    node = parse('[2, 3j, True, "str"]', mode='eval')
    assert const_type(node) == 'list[int, complex, bool, str]'
    node = parse('(2, 3j, True, "str")', mode='eval')
    assert const_type(node) == 'tuple[int, complex, bool, str]'
    node = parse('{2: 3j, True: 4.0, "str": "int"}', mode='eval')
    assert const_type(node) == 'dict[int, complex, bool, str]'
    for t in PEP585.keys():
        assert const_type(parse(f'{t!r}(2)', mode='eval')) == t

# Generated at 2022-06-23 15:36:52.701391
# Unit test for function parent
def test_parent():
    assert parent('os.path') == 'os'
    assert parent('os.path', level=2) == 'os'
    assert parent('os', level=10) == 'os'



# Generated at 2022-06-23 15:37:00.674929
# Unit test for constructor of class Resolver
def test_Resolver():
    """Test constructor of class Resolver."""
    import sys

    def assert_ann_eq(ann1: str, ann2: str) -> None:
        ann1 = Resolver('test', {}).visit(parse(ann1).body[0])
        ann2 = Resolver('test', {}).visit(parse(ann2).body[0])
        assert unparse(ann1) == unparse(ann2), (ann1, ann2)

    assert_ann_eq('1', '1')
    assert_ann_eq('typing.Union[int, float]', 'int | float')
    assert_ann_eq(
        'typing.Optional[typing.Union[int, float, str]]',
        'int | float | str | None'
    )

# Generated at 2022-06-23 15:37:05.030487
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    for name in ('bool', 'float', 'int', 'list', 'set', 'str'):
        e = f"typing.{name}[int]"
        assert _type_name(Resolver('', {}).visit(parse(e).body[0].value.value)) == name



# Generated at 2022-06-23 15:37:09.236462
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    """Unit test for method visit_Attribute of class Resolver."""
    resolver = Resolver(root='', alias={}, self_ty='')
    r = resolver.visit_Attribute(Attribute(Name('typing', Load()), 'List', Load()))
    assert r == Name('List', Load())



# Generated at 2022-06-23 15:37:19.216612
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    from ast import parse
    from .supporting import NamedTestCase
    from .ignore import test_ignore

    class TestResolverAttribute(NamedTestCase):
        def test_attribute_without_typing(self):
            r = Resolver("", {})
            assert parse("a").body[0].value == r.visit(parse("a").body[0].value)
            assert parse("a.b").body[0].value == r.visit(parse("a.b").body[0].value)

        def test_attribute_with_typing(self):
            r = Resolver("", {})
            assert parse("typing.a").body[0].value == r.visit(parse("typing.a").body[0].value)

# Generated at 2022-06-23 15:37:28.406759
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from importlib.util import module_from_spec
    from importlib.machinery import ModuleSpec
    from pathlib import Path
    import sys
    sys.path.append(str(Path.cwd().parent))
    from source import parser
    m = module_from_spec(ModuleSpec('test_parse', is_package=False))
    m.__file__ = 'test_parse.py'
    m.__doc__ = 'test module'
    m.c = parser.Parser.Node('class C:\n    """C class"""')
    p = parser.Parser()
    p.doc['test_parse.C'] = 'level C()\n\n*Full name:* `test_parse.C`\n'
    p.load_docstring('test_parse', m)

# Generated at 2022-06-23 15:37:34.395278
# Unit test for function const_type
def test_const_type():
    def _eval(value: str) -> str:
        return const_type(parse(value).body[0].value)
    assert _eval("True") == 'bool'
    assert _eval("1") == 'int'
    assert _eval("1.2") == 'float'
    assert _eval("1.2+2j") == 'complex'
    assert _eval("'Hello'") == 'str'
    assert _eval("(1, 2)") == 'tuple[int, int]'
    assert _eval("[1, 2]") == 'list[int, int]'
    assert _eval("{1, 2}") == 'set[int, int]'
    assert _eval("{1: 2, 3: 4}") == 'dict[int, int, int, int]'
    assert _eval("['Hello', 1]")

# Generated at 2022-06-23 15:37:46.145260
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    parser = Parser()
    parser.imp['a'] = set()
    parser.imp['b'] = {'_bar', 'b.bar', 'b.Baz._foo'}
    assert parser.is_public('c')
    assert parser.is_public('c.foo')
    assert parser.is_public('a')
    assert not parser.is_public('a.foo')
    assert parser.is_public('b')
    assert not parser.is_public('b.foo')
    assert parser.is_public('b.bar')
    assert parser.is_public('b.Baz')
    assert not parser.is_public('b.Baz.foo')
    assert parser.is_public('b.Baz._foo')
    assert parser.is_public('b.Baz._bar')
# Unit test

# Generated at 2022-06-23 15:37:52.413897
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from importlib import import_module
    from io import StringIO
    output = StringIO()
    i = None
    with redirect_stderr(output):
        p = Parser(link=False)
        m = import_module('sphinx_pytest.test_suite')
        p.load_docstring('sphinx_pytest.test_suite', m)
        i = p.compile()
    assert i == output.getvalue()



# Generated at 2022-06-23 15:37:59.326780
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    """Test for method ``__repr__`` of class :class:`Parser`."""

    from types import ModuleType
    import builtins
    from itertools import chain
    from typing import Any, List, Optional, Sequence
    
    import astroid
    
    
    # Sample code for testing.
    builtins.__doc__ = """
    __builtin__
    ===========
    
    Built-in functions,
    
    exceptions and attributes.
    
    """
    builtins.__all__ = ["__doc__", "__name__"]
    builtins.__name__ = "__builtin__"
    
    
    def _attr(m: ModuleType, name: str) -> Optional[Any]:
        if name == '__builtin__':
            return m

# Generated at 2022-06-23 15:38:11.222715
# Unit test for method imports of class Parser
def test_Parser_imports():
    obj = Parser()
    root = 'abc'
    node = ast.Import(names=[ast.alias(name='aa', asname='bb')])
    obj.imports(root, node)
    assert obj.alias['abc.bb'] == 'aa'
    obj.imports(root, ast.ImportFrom(module='a', level=0, names=[ast.alias(name='aa', asname='bb')]))
    assert obj.alias['abc.bb'] == 'a.aa'
    obj.imports(root, ast.ImportFrom(module='a', level=0, names=[ast.alias(name='aa', asname=None)]))
    assert obj.alias['abc.aa'] == 'a.aa'

# Generated at 2022-06-23 15:38:22.677931
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert Resolver.Resolver('a', {}).visit_Subscript(Subscript(Name('a', Load()), slice(Name('a', Load())), Load())) == Subscript(Name('a', Load()), slice(Name('a', Load())), Load()), 'test_Resolver_visit_Subscript failed'
    assert Resolver.Resolver('b', {}).visit_Subscript(Subscript(Name('b', Load()), slice(Name('b', Load())), Load())) != Subscript(Name('a', Load()), slice(Name('a', Load())), Load()), 'test_Resolver_visit_Subscript failed'

# Generated at 2022-06-23 15:38:26.490137
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    import ast
    code = """
    def func(a: typing.int):
        return a
    """
    node = ast.parse(code).body[0].args[0]
    assert Resolver(__name__, {}).visit(node).arg.id == 'int'


# Generated at 2022-06-23 15:38:29.300318
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    from .test_parser import test_is_public
    test_is_public(Parser)



# Generated at 2022-06-23 15:38:31.405491
# Unit test for function parent
def test_parent(): assert parent('aaa.bbb.ccc.ddd', level=1) == 'aaa.bbb.ccc'

# Generated at 2022-06-23 15:38:39.496374
# Unit test for method compile of class Parser
def test_Parser_compile():
    import importlib
    import builtins
    from ast import Module
    from pathlib import Path
    from typing_extensions import Literal


    builtins.__doc__ = "https://docs.python.org/3/library/functions.html"

    def import_module(name: str, path: Path = Path(".")) -> Module:
        """Import standard library module."""
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)  # type: ignore
        return module


    def do_test(name: str, module: Module) -> None:
        """Test Python standard library."""
        path = Path("../../stdlib", name + ".rst").resolve()


# Generated at 2022-06-23 15:38:50.047832
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    import re
    import sys

    path = Path(sys.argv[1])
    target = sorted(
        path.name for path in path.glob("**/*.py") if path.stem != "__init__"
    )
    for _ in target:
        p = Parser(root=_)
        for i in (
            f for f in p.doc.keys() if f.endswith(_)
        ):
            assert p.root[i] == _
        for i in (
            f for f in p.root.keys() if f.endswith(_)
        ):
            assert p.root[i] == _
        for i in (
            f for f in p.imp.keys() if f.endswith(_)
        ):
            assert p.root[i] == _

# Generated at 2022-06-23 15:38:56.715171
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():

    # This method is designed to test post initialization of Parser class
    
    # Variable Declaration
    # End Variable Declaration
    parser = Parser()
    # This test is designed to check whether literals are stored in a set of literals
    assert type(parser._literals) == set
    # This test is designed to check whether literals are stored with the same format
    assert parser._literals == {'None', 'True', 'False'}
    # This test is designed to check whether literals are stored as a set
    assert len(parser._literals) == 3

# Generated at 2022-06-23 15:39:02.510902
# Unit test for method imports of class Parser
def test_Parser_imports():
    """
    import a.b, a.b.c as d
    """
    _from = aio.from_
    _import = aio.import_
    alias = {}
    _from('a.b', _import('c'), as_='d')
    assert alias == {'::a.b': 'a.b', '::a.b.c': 'a.b.c', '::a.b.d': 'a.b.c'}


# Generated at 2022-06-23 15:39:09.813159
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert Resolver(__name__, {}).visit_Subscript(
        Subscript(Name('Union', Load()),
                  Tuple(elts=[Name('int', Load()), Name('str', Load())],
                        ctx=Load()),
                  Load())).__dict__ == \
        BinOp(Name('int', Load()), BitOr(), Name('str', Load())).__dict__

    assert Resolver(__name__, {}).visit_Subscript(
        Subscript(Name('Optional', Load()), Name('int', Load()), Load())).__dict__ == \
        BinOp(Name('int', Load()), BitOr(), Constant(None)).__dict__


# Generated at 2022-06-23 15:39:22.279053
# Unit test for function const_type
def test_const_type():
    assert const_type(parse('1').body[0]) == 'int'
    assert const_type(parse('[1, 2, 3]').body[0]) == 'list[int]'
    assert const_type(parse('(1, 2, 3)').body[0]) == 'tuple[int]'
    assert const_type(parse('{1, 2, 3}').body[0]) == 'set[int]'
    assert const_type(parse('{"a": 1, "b": 2}').body[0]) == 'dict[str, int]'
    assert const_type(parse('"a"').body[0]) == 'str'
    assert const_type(parse('(1, 2.0, 3)').body[0]) == 'tuple[Any]'

# Generated at 2022-06-23 15:39:26.806767
# Unit test for function is_public_family
def test_is_public_family():
    assert not is_public_family('_python.__class.__builtin')
    assert not is_public_family('_python.__class.__builtin.__name')
    assert is_public_family('python.__class.builtin.__name')
    assert is_public_family('python.class.builtin.__name')
test_is_public_family()



# Generated at 2022-06-23 15:39:36.046792
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    alias = {'base.head': "typing.Union[base.head, None]",
             'base.active': "typing.Union[base.active, None]",
             'base.xy': "typing.Optional[base.xy]",
             'base.z': "typing.Union[base.z, None]",
             'typing.Optional': "typing.Optional",
             'typing.Union': "typing.Union",
             'typing.Mapping': "typing.Mapping"}
    assert Resolver("base", alias).visit(
        Subscript(Name("head", Load()), Tuple([Name("head", Load())], Load()), Load())
    ) == Name("head", Load())

# Generated at 2022-06-23 15:39:41.122815
# Unit test for method compile of class Parser
def test_Parser_compile():
    test_data = "import typing\n" \
                "def foo(bar: typing.Any) -> typing.Optional[int]:\n" \
                "    \"\"\"\n" \
                "    :param bar:\n" \
                "    :return:\n" \
                "    \"\"\"\n"
    parser = Parser()
    parser.add('', test_data)
    assert parser.compile()
if __name__ == "__main__":
    test_Parser_parse()
    test_Parser_add()
    test_Parser_compile()

# Generated at 2022-06-23 15:39:46.898480
# Unit test for function table
def test_table():
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == '''| a | b |
|:---:|:---:|
| c | d |
| e | f |

'''



# Generated at 2022-06-23 15:39:48.889798
# Unit test for function table
def test_table():
    table('a')
    table('a', 'b', [['c', 'd'], ['e', 'f']])
# Unit test end



# Generated at 2022-06-23 15:39:56.045841
# Unit test for constructor of class Parser
def test_Parser():
    def _get_t(p: Parser, r: str):
        return p.alias[_m(r, 'T')]
    def _get_s(p: Parser, r: str):
        return p.alias[_m(r, 'S')]
    def _get_doc(p: Parser, r: str):
        return p.doc[_m(r, 'C')]

    p = Parser()
    with open('tests/python/resolve.py', 'r') as f:
        p.load_file('api', f)
    p.parse('api')
    assert _get_t(p, 'api') == 'typing.Union[api.C, int]'
    assert _get_t(p, 'api.a') == 'typing.Optional[List[api.b.D]]'

# Generated at 2022-06-23 15:40:02.040462
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser, Parser)
    assert parser.imp == {}
    assert parser.alias == {}
    assert parser.doc == {}
    assert parser.docstring == {}
    assert parser.root == {}
    assert parser.level == {}
    assert parser.const == {}
