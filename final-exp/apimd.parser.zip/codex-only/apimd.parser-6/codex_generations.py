

# Generated at 2022-06-23 15:30:08.924656
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    """Test the method visit_Constant of class Resolver"""
    r = Resolver("", {})
    assert r.visit_Constant(Constant("")).__repr__() == "Constant(\"\", None)"
    assert r.visit_Constant(Constant("i")).__repr__() == "Name(id='i', ctx=Load())"
    assert r.visit_Constant(Constant({})).__repr__() == "Constant({}, None)"



# Generated at 2022-06-23 15:30:10.436691
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    """
    Test for method __repr__
    """
    pass



# Generated at 2022-06-23 15:30:20.014960
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    """Test method Parser.__eq__."""
    p = Parser()
    logger.info(p)
    assert p.__eq__(p)
    assert not p.__eq__(None)
    assert not p.__eq__(object())
    assert not p.__eq__(Parser())
    p.link = True
    assert not p.__eq__(Parser())
    for attr in ('alias', 'const', 'doc', 'docstring', 'imp', 'level', 'root'):
        p2 = Parser()
        setattr(p, attr, getattr(p2, attr))
        assert p.__eq__(p2)
    assert p.__eq__(p)

# Generated at 2022-06-23 15:30:29.792668
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    from ast import parse, FunctionDef
    from inspect import cleandoc
    from .parser import Parser
    from .visitor import Visitor

    class Collector(Visitor):
        def __init__(self, node: ast.AST) -> None:
            self.result = []
            self.visit(node)

        def visit_FunctionDef(self, node: FunctionDef) -> None:
            self.result.append(node.name)

    tree = parse("""
    def f1():
        pass

    def f2():
        pass

    def f3():
        pass

    def f4():
        pass
    """)
    p: Parser = Parser()
    p.visit(tree)

# Generated at 2022-06-23 15:30:40.896145
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    """Check visit_Name of class Resolver."""
    alias = {'btn': 'Button', 'a': 'typing.List[int]'}
    root = 'tkinter'
    r = Resolver(root, alias)
    n = Name('btn', Load())
    assert unparse(n) == 'btn'
    n = r.visit(n)
    assert unparse(n) == 'Button'
    assert unparse(r.visit(Name('a', Load()))) == 'List[int]'
    assert unparse(r.visit(Name('self', Load()))) == 'self'
    assert unparse(r.visit(Name('self', Load(), generic='A'))) == 'A'

# Generated at 2022-06-23 15:30:50.890909
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    assert Parser({"__all__": set()}).is_public("__x")
    assert Parser({"__all__": set()}).is_public("__y")
    assert not Parser({"__x": set()}).is_public("__x")
    assert Parser({"__x": set()}).is_public("__x.__y")
    assert Parser({"__x": set()}).is_public("__x.__y.z")
    assert Parser({"__x": set()}).is_public("__x.y")
    assert Parser({"__x": set()}).is_public("__x.y.z")
    assert Parser({"__x": set()}).is_public("__x.z")

# Generated at 2022-06-23 15:30:58.230848
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    class A:
        "A's docstring"
    class B:
        "B's docstring"
        class C:
            "C's docstring"
        def f(self, x):
            """f's docstring"""
        async def g(self, x):
            """g's docstring"""
        @staticmethod
        def h(x):
            """h's docstring"""
        @classmethod
        def i(x):
            """i's docstring"""
    p = Parser()
    p.load_docstring('', A)
    assert p.docstring['A'] == A.__doc__
    p.load_docstring('', B)
    assert p.docstring['B'] == B.__doc__
    assert p.docstring['B.C'] == B.C.__doc__

# Generated at 2022-06-23 15:31:09.722897
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    resolver = Resolver("test", {})
    assert unparse(resolver.visit(parse("Union[int, str]").body[0])) == 'int | str'
    assert unparse(resolver.visit(parse("Optional[int]").body[0])) == 'int | None'
    assert unparse(resolver.visit(parse("typing.Optional[int]").body[0])) == 'int | None'
    assert unparse(resolver.visit(parse("typing.Union[int, str]").body[0])) == 'int | str'
    assert unparse(resolver.visit(parse("typing.Text").body[0])) == 'str'

# Generated at 2022-06-23 15:31:11.044205
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    node = Name("a", Load())
    resolver = Resolver("__main__", {"__main__": "__main__.a"})
    resolver.visit(node)



# Generated at 2022-06-23 15:31:21.811849
# Unit test for function doctest
def test_doctest():
    assert doctest("Some text") == "Some text"
    assert doctest("\n".join((
        "    Something behind is the doctest",
        "    >>> 1 + 1",
        "    2",
        "    >>> 2 * 2 + 2",
        "    6",
        "    >>> 3 * 3 + 3",
        "    12",
        "    >>> 4 * 4 + 4",
        "    20",
        "",
    ))) == (
        "    Something behind is the doctest\n"
        "```python"
        "\n>>> 1 + 1\n2\n"
        ">>> 2 * 2 + 2\n6\n"
        ">>> 3 * 3 + 3\n12\n"
        ">>> 4 * 4 + 4\n20\n"
        "```"
    )



# Generated at 2022-06-23 15:31:25.015807
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    p = Parser(toc=False)
    p.set_level(2)
    p.set_link(True)
    assert p == Parser(toc=False)

# Generated at 2022-06-23 15:31:31.416346
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    assert Parser().is_public('a') == False
    assert Parser().is_public('A') == True
    assert Parser().is_public('A.a') == False
    assert Parser().is_public('A.A') == True
    assert Parser().is_public('abc') == False
    assert Parser().is_public('A_bc') == False
    assert Parser().is_public('a_bc') == False


# Generated at 2022-06-23 15:31:35.186528
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p.toc
    assert p.b_level == 4
    assert p.link

    p = Parser(toc=False, b_level=5, link=False)
    assert not p.toc
    assert p.b_level == 5
    assert not p.link

# Generated at 2022-06-23 15:31:47.473917
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    from .linter import lint
    from .syntax import get_definition
    from .codegen import CodeGenerator

    class _T: pass

    module = ModuleType(__name__)
    module.__dict__['_T'] = _T
    generator = CodeGenerator("test", 0, "")
    with lint(module, generator) as lr:
        lr.resolver.alias['test._T'] = "self.T"
        lr.resolver.alias['test.Anonymous'] = "self.Anonymous"
        lr.resolver.alias['test.T'] = "self.T"
        lr.resolver.alias['test.Some'] = "123"
        assert lr.visit_Name(Name("_T", Load())) is Name("T", Load())
        assert lr.vis

# Generated at 2022-06-23 15:31:48.667935
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore('Solve_me') == 'Solve\_me'
    assert esc_underscore('Solve') == 'Solve'



# Generated at 2022-06-23 15:31:57.708584
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    import typing
    resolver = Resolver('', {})

    def assert_resolver(node, expected):
        actual = resolver.visit(node)
        assert isinstance(actual, expected.__class__)
        assert unparse(actual) == unparse(expected)

    assert_resolver(Subscript(Name('Optional', Load),
                              Tuple([Name('a', Load)], Load), Load),
                     BinOp(Tuple([Name('a', Load)], Load), BitOr(), Constant(None)))
    assert_resolver(Subscript(Name('Union', Load), Tuple([Name('a', Load),
                                                           Name('b', Load)],
                                                          Load), Load),
                     BinOp(Name('a', Load), BitOr(), Name('b', Load)))

# Generated at 2022-06-23 15:32:05.351865
# Unit test for function doctest
def test_doctest():
    assert doctest('''
>>> [1]
[1]
''') == '''
```python
>>> [1]
[1]
```'''
    assert doctest('''
first line
>>> [1]
[1]
''') == '''
first line
```python
>>> [1]
[1]
```'''
    assert doctest('''
first line
>>> [1]
[1]
second line
''') == '''
first line
```python
>>> [1]
[1]
```
second line
'''

# Generated at 2022-06-23 15:32:13.698639
# Unit test for function doctest
def test_doctest():
    assert doctest("""Foo\n>>> try:\n>>>     ap_if\n""") == "Foo\n```python\ntry:\n    ap_if\n```"
    assert doctest("Foo\n>>> try:\n>>>     ap_if\nBar") == "Foo\n```python\ntry:\n    ap_if\n```\nBar"
    assert doctest("Bar") == "Bar"
    assert doctest("Bar\nFoo") == "Bar\nFoo"



# Generated at 2022-06-23 15:32:18.576790
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    @dataclass
    class Test:
        n: int
    assert Resolver("", {}).visit_Attribute(Attribute(Name("typing", Load()), "Union", Load())) == Name("Union", Load())
    assert Resolver("", {}).visit_Attribute(Attribute(Name("x", Load()), "Union", Load())) == Attribute(Name("x", Load()), "Union", Load())


# Generated at 2022-06-23 15:32:24.293825
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    m = Parser(link=True)
    assert m.link == True
    assert m.b_level == 0
    assert m.toc == False
    assert m.alias == {}
    assert m.root == {}
    assert m.const == {}
    assert m.doc == {}
    assert m.docstring == {}
    assert m.imp == {}
    assert m.level == {}

# Generated at 2022-06-23 15:32:29.102637
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    r = Resolver('', {})
    a = Attribute(
        Name('typing', Load()), 'Literal', Load()
    )
    b = Attribute(
        Name('abc', Load()), 'Literal', Load()
    )
    assert isinstance(r.visit(a), Name)
    assert isinstance(r.visit(b), Attribute)

# Generated at 2022-06-23 15:32:35.574577
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    from .parser import Parser
    from .parser import ParserOptions
    """Test case for Parser.__repr__"""

    options = ParserOptions()
    options.parse_all()
    options.read_all()

    parser = Parser(options)

    parser.__init__(
        options)

    expected = "Parser(options: ParserOptions)"

    actual = parser.__repr__()

    assert expected == actual

# Generated at 2022-06-23 15:32:45.542250
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    """Unit test for Parser.__repr__"""

# Generated at 2022-06-23 15:32:48.267019
# Unit test for function parent
def test_parent():
    assert parent('') == ''
    assert parent('a.b') == 'a'
    assert parent('a.b', level=0) == 'a.b'
    assert parent('a.b', level=1) == 'a'
    assert parent('a.b', level=2) == ''



# Generated at 2022-06-23 15:32:57.461761
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    import ast
    import inspect
    from typing import Optional

    def foo(*, a: int) -> str:
        return {a: 1}

    def bar(b: str = 1, *, c: bytes = b'') -> Optional[bytearray]:
        pass

    p = Parser()
    assert p.func_ann('foo', foo.__code__, False, False) == [
        'dict[int, int]', 'str'
    ]
    assert p.func_ann('bar', bar.__code__, True, False) == [
        'Self', 'str', 'bytes', 'Optional[bytearray]'
    ]

# Generated at 2022-06-23 15:33:06.715091
# Unit test for method imports of class Parser
def test_Parser_imports():
    p = Parser()
    import user_imports.a as b
    import user_imports.c as user_imports
    import user_imports.c.d
    p.imports('user_imports', ast.parse('''
        from a import b as c
        from c import d as e
        from c import *
        import c
        import c.d
        import c.d.e as dd
        from c.d.f import g
        from f import *
    '''))
    from user_imports.a import b as c
    from user_imports.c import d as e
    from user_imports.c import *
    import user_imports.c
    import user_imports.c.d
    import user_imports.c.d.e as dd

# Generated at 2022-06-23 15:33:11.205854
# Unit test for function table
def test_table():
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == '''\
| a | b |
|:---:|:---:|
| c | d |
| e | f |

'''



# Generated at 2022-06-23 15:33:20.032149
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    p = Parser()
    p.link = True
    p.version = '0.1.0'
    p.attrs = {'name': 'unnamed', 'author': 'unknown', 'license': 'UNLICENSE',
               'license-link': 'https://choosealicense.com/no-permission/'}
    p.b_level = 2
    p.alias = {'a': 'b', 'c': 'd'}
    p.root = {'a': 'a', 'c': 'c'}
    p.doc = {'a': 'a', 'c': 'c'}
    p.docstring = {'a': 'a', 'c': 'c'}
    p.imp = {'a': set(), 'c': set()}

# Generated at 2022-06-23 15:33:24.216329
# Unit test for method parse of class Parser
def test_Parser_parse():
    "Unit test for Parser.parse"
    parser = Parser(None, None)

# Generated at 2022-06-23 15:33:35.150659
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert Resolver('.', {}).visit_Name(Name('a', Load())).id == 'a'
    assert Resolver('.', {'a': '1'}).visit_Name(Name('a', Load())).id == '1'
    assert Resolver('.', {'a': '1'}).visit_Name(Name('b', Load())).id == 'b'
    assert Resolver('.', {'a': '1', 'b': '2'}).visit_Name(Name('a', Load())).id == '1'
    assert Resolver('.', {'a': '1', 'b': '2'}).visit_Name(Name('b', Load())).id == '2'

# Generated at 2022-06-23 15:33:45.438699
# Unit test for method globals of class Parser
def test_Parser_globals():

        from .parser import Parser
        from .parser import parse
        from .utils import run_parser_for

        p = Parser()

        assert p.doc == {}

        code = """
            A = 3
            B: int = 3
            C_D, E_F = 1, 2
            G, __all__ = 'a', ['H']

            class Klass:
                H = 1
                I: int = 2
                J, __all__ = 'a', ['K']
                K: int = 2
                L = 3
                __all__ = ['A', 'B']


            class Klass2:
                M_N, __all__ = 'a', ['O_P']
                O_P = 2
                __all__ = []


        """

# Generated at 2022-06-23 15:33:50.956806
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    p = Parser()
    assert p.alias == {}
    assert p.b_level == 0
    assert p.const == {}
    assert p.doc == {}
    assert p.docstring == {}
    assert p.imp == {}
    assert p.level == {}
    assert p.link is False
    assert p.root == {}
    assert p.toc is True


# Generated at 2022-06-23 15:34:01.041693
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    parser = Parser(set(), False)
    parser.alias = dict(x='x', y='y', z='z')
    args = [
        arg('a', load_ast("x")),
        arg('b', load_ast("y")),
        arg('c', load_ast("z")),
    ]
    assert parser.func_ann('', args, False, False) == ['x', 'y', 'z']
    args = [
        arg('a', load_ast("x")),
        arg('b', load_ast("y")),
        arg('c', None),
    ]
    assert parser.func_ann('', args, False, False) == ['x', 'y', ANY]

# Generated at 2022-06-23 15:34:03.867797
# Unit test for function parent
def test_parent(): assert parent('a.b.c', level=1) == 'a.b' and parent('a.b.c', level=2) == 'a' # noqa

# Generated at 2022-06-23 15:34:12.752741
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    from .. import __version__
    from . import VERSION
    import sys
    import unittest
    from unittest.mock import patch
    from .parser import Parser
    from . import main as py2md_main
    argv = sys.argv
    try:
        with patch.object(sys, 'argv',
                          ['py2md', '--version']):
            try:
                py2md_main()
            except SystemExit as e:
                s = str(e)
            else:
                s = ""
    finally:
        sys.argv = argv
    assert s == str(f"py2md {VERSION}\nPython {VERSION} on {sys.platform}")
    assert unittest.main(__name__, exit=False).result.errors

# Generated at 2022-06-23 15:34:14.175908
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert Resolver._visit_Subscript(
        Resolver(
            root=None,
            alias=[]
        )
    ) == None



# Generated at 2022-06-23 15:34:17.375129
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    class A:
        def __eq__(self, o: object) -> bool:
            return True
    s = Parser(A())
    assert s == s
    assert s == Parser(A())


# Generated at 2022-06-23 15:34:24.832526
# Unit test for method imports of class Parser
def test_Parser_imports():
    # Making the alias dictionary an attribute of this object
    Parser.alias = AttrDict()
    # Creating a Parser object
    parser = Parser(False)
    # Creating a Module object
    module = parse("from a.b import c as d, e")
    # Calling the method imports of class Parser
    parser.imports("x.y", module)
    # Assert statement with the expected result
    assert parser.alias["x.y.d"] == "a.b.c"
    # Assert statement with the expected result
    assert parser.alias["x.y.e"] == "a.b.e"
    # Creating a Module object
    module = parse("from a import b as c, d")
    # Calling the method imports of class Parser
    parser.imports("x.y", module)
    #

# Generated at 2022-06-23 15:34:26.014744
# Unit test for method globals of class Parser
def test_Parser_globals():
    from .test_parser import test_Parser_globals
    return test_Parser_globals()

# Generated at 2022-06-23 15:34:28.367999
# Unit test for function table
def test_table():
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == '''\
| a | b |
|:---:|:---:|
| c | d |
| e | f |

'''



# Generated at 2022-06-23 15:34:38.916946
# Unit test for method compile of class Parser
def test_Parser_compile():
    class _Module:
        pass
    _Module.__file__ = 'foo/bar.py'

# Generated at 2022-06-23 15:34:48.923922
# Unit test for method compile of class Parser
def test_Parser_compile():
    def test_case(text: str, *,
                  toc: bool = False,
                  link: bool = False,
                  signature: bool = False) -> ModuleType:
        from importlib import import_module
        from pathlib import Path
        path = Path('__test_CodeSig.py')
        path.write_text(text)
        m = import_module('__test_CodeSig')
        Parser(toc, link, signature).parse(str(path), m)
        return m
    def test_case_1():
        """The first test case."""
        text = """\
        a = 1

        def foo() -> None:
            pass

        class Bar:
            ...

        def baz() -> None:
            pass
        """
        m = test_case(text)
        assert m.__

# Generated at 2022-06-23 15:34:52.784991
# Unit test for function code
def test_code():
    assert code("x") == "`x`"
    assert code("|") == "`&#124;`"
    assert code("x|x") == "<code>x|x</code>"
    assert code("x & x") == "<code>x & x</code>"
    assert code("") == " "



# Generated at 2022-06-23 15:34:56.908888
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    r = Resolver("", {'k': '1'})
    n = parse("x = k").body[0]
    r.visit(n)
    assert n.targets[0].id == 'x'
    assert n.value.n == 1

# Generated at 2022-06-23 15:35:02.869834
# Unit test for constructor of class Parser
def test_Parser():
    from .types import Function
    from .utils import Resolver as _Resolver
    from .utils import walk_body as _walk_body

# Generated at 2022-06-23 15:35:09.084153
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__eq__')
    assert is_magic('__iter__')
    assert is_magic('__init__')
    assert is_magic('__len__')
    assert is_magic('__getitem__')
    assert is_magic('__str__')
    assert not is_magic('__str_')
    assert not is_magic('_str__')
    assert not is_magic('str_')



# Generated at 2022-06-23 15:35:19.348492
# Unit test for method imports of class Parser
def test_Parser_imports():
    from . import ast_

    m = ast_.parse('''\
import a
import b as bb
from . import c
from . import d as dd
from .a import e
from .a import f as ff
from .. import g
from .. import h as hh
from ..a import i
from ..a import j as jj
import k
import k.l
import k.l.m
import k.l.m.n
import k.l.m.n.o
''')
    p = Parser()
    r = p.imports(m)
    p.imports(m.body[0])
    p.imports(m.body[1])
    p.imports(m.body[2])
    p.imports(m.body[3])

# Generated at 2022-06-23 15:35:29.398649
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert Resolver('', {}, '').visit_Name(Name('a', Load())) == Name('a', Load())
    assert Resolver('', {'a': 'b'}, '').visit_Name(Name('a', Load())) == Name('b', Load())
    assert Resolver('', {}, '').visit_Name(Name('Self', Load())) == Name('Self', Load())
    assert Resolver('c', {'c': 'a'}, '').visit_Name(Name('a', Load())) == Name('a', Load())
    assert Resolver('c', {'c': 'a'}, 'a').visit_Name(Name('a', Load())) == Name('Self', Load())

# Generated at 2022-06-23 15:35:36.100045
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    # Test if class_api can parse the class body
    p = Parser(color=False)
    root = "root"
    name = root
    bases = [Name(id='base1')]
    body = [Assign(targets=[Name(id="a")], value=Constant(None))]
    p.class_api(root, name, bases, body)

# Generated at 2022-06-23 15:35:37.574677
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    """Test method visit_Subscript of class Resolver."""

# Generated at 2022-06-23 15:35:39.027448
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    obj = Parser([])
    assert obj == obj
    
    

# Generated at 2022-06-23 15:35:50.764656
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    root = 'inn'
    doc = {}
    docstring = {}
    imp = {root: {'A'}}
    alias = {
        root: 'inn',
        _m(root, 'A'): 'inn.a.A_Class',
        _m(root, 'B'): 'inn.a.B',
        _m(root, 'C'): 'inn.a.C',
        _m(root, 'D'): 'inn.a.D',
        _m(root, 'E'): 'inn.a.E',
        _m(root, 'F'): 'inn.a.F',
    }

# Generated at 2022-06-23 15:36:02.449259
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    assert str(Resolver('abc', {}).visit_Constant(Constant('123'))) == '123'
    assert str(Resolver('abc', {}).visit_Constant(Constant('123',))) == '123'
    assert str(Resolver('abc', {}).visit_Constant(Constant('123,',))) == '123,'
    assert str(Resolver('abc', {}).visit_Constant(Constant('123, '))) == '123, '
    assert str(Resolver('abc', {}).visit_Constant(Constant('123, abc'))) == '123, abc'
    assert str(Resolver('abc', {'abc': 'bcd'}).visit_Constant(Constant('123, abc'))) == '123, bcd'

# Generated at 2022-06-23 15:36:13.749334
# Unit test for method compile of class Parser
def test_Parser_compile():
    # Test case 1
    # To test a simple docstring
    try:
        assert Parser().compile() == ""
    except Exception:
        logger.exception('Catch exception')
    # Test case 2
    # To test a simple docstring with class `b_level = Level`
    try:
        parser = Parser(Level.FUNC)
        assert parser.docstring == {}
    except Exception:
        logger.exception('Catch exception')
    # Test case 3
    # To test a simple docstring with class `b_level = Level`
    try:
        parser = Parser(Level.FUNC)
        assert parser.docstring == {}
    except Exception:
        logger.exception('Catch exception')
    # Test case 4
    # To test a simple docstring with class `b_level = Level`

# Generated at 2022-06-23 15:36:23.033331
# Unit test for method imports of class Parser
def test_Parser_imports():
    parser = Parser()
    assert not parser.imp
    parser.imports("bopy", Import(names=[alias("c", "d")]))
    assert parser.alias == {'bopy.d': 'c'}
    parser.imports("bopy", ImportFrom("a", names=[alias("c", "d")]))
    assert parser.alias == {'bopy.d': 'a.c'}
    parser.imports("bopy", ImportFrom("a", names=[alias("*", "d")]))
    assert parser.imp == {'': {'bopy.d'}}


# Generated at 2022-06-23 15:36:27.343018
# Unit test for function table
def test_table():
    assert (
        table('a', 'b', [['c', 'd'], ['e', 'f']])
        == '| a | b |\n|:---:|:---:|\n| c | d |\n| e | f |\n\n'
    )



# Generated at 2022-06-23 15:36:28.234021
# Unit test for constructor of class Parser
def test_Parser():
    # Success if not raise exception
    root = 'src'
    Parser(root, link=True)


# Generated at 2022-06-23 15:36:37.475671
# Unit test for method api of class Parser
def test_Parser_api():
    _ = Parser(False)
    doc = """
    def test_2(sl: SomeList) -> None:
        """
    f = ast.parse(doc)
    n = f.body[0]
    assert isinstance(n, FunctionDef)
    args, returns = n.args, n.returns
    assert isinstance(args, arguments)
    assert args.posonlyargs == []
    assert args.args[0].arg == 'sl'
    assert isinstance(args.args[0].annotation, Name)
    assert isinstance(returns, Name)
    assert returns.id == 'None'
    assert args.vararg is None
    assert args.kwonlyargs == []
    assert args.kw_defaults == []
    assert args.kwarg is None

# Generated at 2022-06-23 15:36:49.144331
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    import ast
    from . import TYPE, ANY, ANY_PLUS
    from .types import (
        parse as parse_type,
        Generic,
    )

    def get_ty(arg):
        ann = parse_type(arg.annotation) if arg.annotation else ANY
        if arg.arg.startswith('**'):
            return {TYPE: ANY_PLUS, '__any_plus_kind__': 'dict',
                    '__any_plus_args__': {TYPE: ann}}
        elif arg.arg.startswith('*'):
            return {TYPE: ANY_PLUS, '__any_plus_kind__': 'list',
                    '__any_plus_args__': {TYPE: ann}}

# Generated at 2022-06-23 15:36:57.454826
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    """Unit test for method resolve of class Parser."""
    porter = Parser([], False)
    table = porter.resolve
    test = [(
        "[Literal[10], Union[int, float]]",
        "[int, float]",
    ), (
        "Optional[Literal[10]]",
        Optional[int],
    ), (
        "List[int]",
        List[int],
    ), (
        "ForwardRef('List')[int]",
        List[int],
    ), (
        "Tuple[int, ...]",
        Tuple[int, ...],
    )]
    for i, o in test:
        assert table('', parse(i)) == o

# Generated at 2022-06-23 15:37:06.733358
# Unit test for method resolve of class Parser

# Generated at 2022-06-23 15:37:17.363173
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    from test.parse_test import test_parse
    from test.test_parse import ParseTestCase
    from .test.test_parse import test_functions

    class TestResolve(ParseTestCase):
        maxDiff = None

        def test_resolve(self):
            class TestResolveParser(Parser):
                def __init__(self, *args, **kargs):
                    Parser.__init__(self, *args, **kargs)
                    self.resolved = {}


# Generated at 2022-06-23 15:37:27.277292
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    alias = {'typing.Union': 'typing.Union'}
    root = 'project'
    r = Resolver(root, alias)
    node = Subscript(Name('typing', Load()), Tuple(elts=[Name('int', Load()), Name('int', Load())]), Load())
    assert unparse(r.visit_Subscript(node)).strip() == "typing.Union[int, int]"
    node = Subscript(Name('typing', Load()), Tuple(elts=[Name('int', Load()), Name('str', Load())]), Load())
    assert unparse(r.visit_Subscript(node)).strip() == "typing.Union[int, str]"

# Generated at 2022-06-23 15:37:35.970489
# Unit test for method compile of class Parser
def test_Parser_compile():
    p = Parser('')
    p.doc['__main__'] = '''# __main__

*Full name:* `__main__`

## __all__

*Constants:*

+ type:`List[str]`
'''
    with __logger('docx.parser.Parser') as log:
        with assert_warnings(log, 'Missing documentation'):
            assert p.compile() == '''# __main__

*Full name:* `__main__`

## __all__

*Constants:*

+ type:`List[str]`
'''


# Generated at 2022-06-23 15:37:44.594001
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert Resolver('', {}).visit(parse('typing.Tuple[int, str]').body[0].value) == parse('Tuple[int, str]').body[0].value
    assert Resolver('', {}).visit(parse('typing.Tuple[int, str]._fields').body[0].value) == parse('Tuple[int, str]._fields').body[0].value
    assert Resolver('', {}).visit(parse('typing.List.append').body[0].value) == parse('List.append').body[0].value


# Generated at 2022-06-23 15:37:55.013779
# Unit test for method visit_Name of class Resolver

# Generated at 2022-06-23 15:38:04.407078
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    parser = Parser(b_level=0, link=False, toc=False, debug=False)
    parser.set_import()
    parser.save(os.path.join('data', 'path', 'to', 'file.py'))
    parser.doc[('data', 'path', 'to', 'file.py', 'Class')] = 'Hello World'
    parser.doc[('data', 'path', 'to', 'file.py', 'class')] = 'Hello Python'
    try:
        assert str(parser) == '\nFile: `data/path/to/file.py`\n\n# Class\n\nHello World\n\n# class\n\nHello Python\n'
        print('Success')
    except Exception as e:
        print('Failed')
        raise e

#

# Generated at 2022-06-23 15:38:11.573657
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    parser = Parser(True, True)
    parser.__post_init__()
    assert parser.root == {}
    assert parser.level == {}
    assert parser.link == True
    assert parser.alias == {}
    assert parser.imp == {}
    assert parser.const == {}
    assert parser.doc == {}
    assert parser.docstring == {}
    assert parser.b_level == 1

# Generated at 2022-06-23 15:38:22.941543
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert unparse(Resolver(".", {}, "").visit(parse("typing.Any").body[0].value)).strip() == "Any"
    assert unparse(Resolver(".", {}, "").visit(parse("typing.Optional[int]").body[0].value)).strip() == "Optional[int]"
    assert unparse(Resolver(".", {}, "").visit(parse("typing.Union[int, str]").body[0].value)).strip() == "Union[int, str]"
    assert unparse(Resolver(".", {}, "").visit(parse("typing.List[int]").body[0].value)).strip() == "List[int]"
    assert unparse(Resolver(".", {}, "").visit(parse("typing.List[List[int]]").body[0].value)).strip()

# Generated at 2022-06-23 15:38:25.064208
# Unit test for method compile of class Parser
def test_Parser_compile():
    """Test method compile of class Parser

    This method is tested in `test_readme.py`
    """
    pass

# Generated at 2022-06-23 15:38:36.730433
# Unit test for function walk_body

# Generated at 2022-06-23 15:38:48.597148
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family("_")
    assert is_public_family("_abc")
    assert is_public_family("abc")
    assert is_public_family("abc._")
    assert is_public_family("abc.__call__")
    assert is_public_family("abc.__test__")
    assert is_public_family("abc._test")
    assert is_public_family("abc._test")
    assert is_public_family("abc.test")
    assert is_public_family("abc.__test_")
    assert is_public_family("abc.test__")
    assert not is_public_family("abc.__test__")
    assert not is_public_family("abc._test_")
    assert not is_public_family("abc._test.__call__")
    assert not is_public

# Generated at 2022-06-23 15:38:52.902813
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    """Test Resolver.visit_Constant."""
    assert Resolver("", {}).visit_Constant(Constant(1)) == Constant(1)
    assert Resolver("", {}).visit_Constant(Constant("Set[int]")) == Name("Set", Load())



# Generated at 2022-06-23 15:39:03.939476
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    from ast import parse
    from sys import path
    import os.path
    import docx
    from docx.shared import Inches
    from pathlib import Path

    # Load the module to test and initialize the Parser object
    path.append(str(Path(__file__).parent))
    dut = Parser()
    dut.parse('parser')
    dut.alias['os'] = 'os'
    dut.alias['sys'] = 'sys'

    # Test the method resolve
    assert dut.resolve('parser', parse('List').body[0].value.elts[0]) == 'os.path.dirname'
    assert dut.resolve('parser', parse('List[int]').body[0].value.elts[0]) == 'List[int]'

# Generated at 2022-06-23 15:39:10.643791
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    isinstance(Resolver('', {}).visit_Name(Name('int', Load())), Name)
    assert Resolver('', {}).visit_Name(Name('int', Load())).id == 'int'
    assert Resolver('', {}).visit_Name(Name('int', Load())).ctx == Load()
    isinstance(Resolver('', {'abc': 'def'}).visit_Name(Name('abc', Load())), Name)
    assert Resolver('', {'abc': 'def'}).visit_Name(Name('abc', Load())).id == 'def'
    assert Resolver('', {'abc': 'def'}).visit_Name(Name('abc', Load())).ctx == Load()

# Generated at 2022-06-23 15:39:16.619714
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    args=[arg('',None),arg('*args',None)]
    has_self=False
    cls_method=False
    assert list(p.func_ann('root',args,has_self,cls_method))==[]
test_Parser_func_ann()

# Generated at 2022-06-23 15:39:26.959209
# Unit test for function const_type
def test_const_type():
    assert const_type(
        parse(
            """
            (
                [] if (1, '2') else
                {} if False else
                {'3', '4'} if lambda:10 else
                {'5', '6'} if lambda:10 else
                {'7', '8'}
            )
            """
        ).body[0].value
    ) == '[str]'
    assert const_type(
        parse(
            """
            [
                10,
                "20",
            ]
            """
        ).body[0].value
    ) == 'list[int, str]'

# Generated at 2022-06-23 15:39:35.862372
# Unit test for method parse of class Parser

# Generated at 2022-06-23 15:39:41.324877
# Unit test for function walk_body
def test_walk_body():
    """Test for function walk_body."""
    class Test(NodeTransformer):
        def visit_Expr(self, node: Expr) -> expr:
            return Constant(None)
    expr = parse('x = 1').body[0]
    assert isinstance(expr, Expr)
    assert isinstance(Test().visit(expr), Constant)
    unit = walk_body([expr, parse('if True: pass')])
    assert isinstance(next(unit), Expr)
    assert isinstance(next(unit), If)
    with pytest.raises(StopIteration):
        next(unit)
test_walk_body()



# Generated at 2022-06-23 15:39:47.393865
# Unit test for method globals of class Parser
def test_Parser_globals():
    P = Parser()
    print(pformat(P.globals('__main__', parse_stmt('X = 3; __all__ = []')), indent=1))

if __name__ == "__main__":
    test_Parser_globals()
__all__ = ['parse', 'Parser']

# Generated at 2022-06-23 15:39:52.486207
# Unit test for method imports of class Parser
def test_Parser_imports():
    root = 'a'
    a = ast.parse("""from a import b""")
    a.body[0].module = 'a'
    a.body[0].names[0].name = 'b'
    node = a.body[0]
    p = Parser()
    p.imports(root, node)
    node = p.imports
    assert node['a.b'] == 'b'


# Generated at 2022-06-23 15:40:04.624441
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    """Unit test for attribute `name` of class `Parser`."""
    from sys import modules  # noqa: F821
    from pytest import raises  # noqa: F822
    import builtins  # noqa: F821

    def expect(ao: str, e: str, m=''):
        """Check that actual is equal to expected."""
        p = Parser()
        found = p.resolve(m, ast_parse(ao, mode='eval').body)
        assert found == e, f"Expect: {e}\nFound: {found}"

    expect("self.x", "self.x")
    expect("[1, 2, 3]", "List[int]")
    expect("[]", "List[Any]")
    expect("1, 2", "Tuple[int, int]")
