

# Generated at 2022-06-23 15:30:12.622165
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    """Test method `is_public` of class `Parser`."""
    import textwrap
    from typing import List
    from ast import Module, Name, FunctionDef, arguments, parse
    module_name = 'a.b.c.d'
    body = [
        FunctionDef(
            name='__some_name_',
            args=arguments(
                posonlyargs=[],
                args=[],
                vararg=None,
                kwonlyargs=[],
                kw_defaults=[],
                kwarg=None,
                defaults=[]),
            body=[],
            decorator_list=[],
            returns=None,
            type_comment=None)]
    ast_node = Module(
        body=body,
        type_ignores=[])

# Generated at 2022-06-23 15:30:16.523427
# Unit test for constructor of class Resolver
def test_Resolver():
    @dataclass
    class Node:
        root: str = ''
        alias: dict[str, str] = field(default_factory=dict)
        self_ty: str = ''
    assert Resolver(Node().root, Node().alias, Node().self_ty) is not None


# Generated at 2022-06-23 15:30:24.803988
# Unit test for function doctest
def test_doctest():
    """Function doctest."""
    assert doctest("""
>>> test
test

>>> def f():
...     print('test')
    """) == '''
```python
>>> test
test
```
>>> def f():
...     print('test')
'''
    assert doctest("""
>>> test
test
""") == '''
```python
>>> test
test
```
'''
    assert doctest("""
>>> test
test""") == '''
```python
>>> test
test
```
'''



# Generated at 2022-06-23 15:30:32.262077
# Unit test for function is_public_family
def test_is_public_family():
    """Test for function is_public_family"""
    assert is_public_family('a')
    assert is_public_family('a.b')
    assert not is_public_family('a._b')
    assert not is_public_family('a.__b__')
    assert not is_public_family('a.__b')
    assert not is_public_family('a.b__')
    assert is_public_family('a.__b')
    assert is_public_family('a.__b__')
    assert not is_public_family('a.b__')
    assert is_public_family('a.__b')
    assert not is_public_family('a.b__')
    assert is_public_family('a.__b__.c')

# Generated at 2022-06-23 15:30:40.309937
# Unit test for constructor of class Parser
def test_Parser():
    """Test Parser."""
    parser = Parser(
        [
            'tests.simple', 'tests.complex.complex',
            'tests.complex.complex.Complex'
        ], True, {})
    assert parser.level['tests'] == 0
    assert parser.level['tests.simple'] == 1
    assert parser.level['tests.simple.foo'] == 2
    assert parser.level['tests.complex'] == 1
    assert parser.level['tests.complex.complex'] == 2
    assert parser.level['tests.complex.complex.Complex'] == 3
    assert parser.level['tests.complex.complex.Complex.__init__'] == 4


# Generated at 2022-06-23 15:30:42.206010
# Unit test for constructor of class Resolver
def test_Resolver():
    """Test constructor of class Resolver."""
    assert Resolver('a', {})



# Generated at 2022-06-23 15:30:47.845787
# Unit test for function table
def test_table():
    def func(a, b):
        """This is a function."""
        pass
    t = table('Name', 'Description',
              [['Parent', 'This is a parent'],
               ['func', func.__doc__ or ' ']])
    assert t == """
    | Name | Description |
    |:---:|:---:|
    | Parent | This is a parent |
    | func |  This is a function.  |

    """.strip()
assert test_table() is None



# Generated at 2022-06-23 15:30:48.828612
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    assert True


# Generated at 2022-06-23 15:30:56.804937
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
  p1 = Parser()
  p2 = Parser()
  assert p1 == p2
  p1.alias['a'] = 'b'
  p2.alias['a'] = 'b'
  assert p1 == p2
  p2.alias['b'] = 'a'
  assert p1 != p2
  assert p1 != 'b'
  p2 = p2.copy()
  assert p1 != p2
  p2 = Parser()
  p2.const['a'] = 'b'
  assert p1 != p2
  p2 = Parser()
  p2.doc['a'] = 'b'
  assert p1 != p2
  p2 = Parser()
  p2.docstring['a'] = 'b'
  assert p1 != p2
  p2 = Pars

# Generated at 2022-06-23 15:31:01.366950
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    # Test for load_docstring method
    p = Parser(link=False)
    p.load_docstring('math', math)
    assert p.docstring['math.pow'] == '\n>>> pow(2, 3)'\
                                      '\n8\n\n'



# Generated at 2022-06-23 15:31:05.670839
# Unit test for function code
def test_code():
    assert code("CadQuery") == "<code>CadQuery</code>"
    assert code("a+b") == "`a+b`"
    assert code("a|b") == "<code>a&#124;b</code>"
    assert code("") == " "



# Generated at 2022-06-23 15:31:09.410872
# Unit test for function is_public_family
def test_is_public_family():
    assert not is_public_family('_a.b')
    assert is_public_family('a.b')
    assert is_public_family('__init__.b')



# Generated at 2022-06-23 15:31:20.715067
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    p = Parser()
    p.level = {root:0 for root in p.root}

# Generated at 2022-06-23 15:31:25.657172
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from . import __version__
    from .api import plt # type: ignore[import]

    Parser().load_docstring(__name__, plt)
    for ext in Parser().docstring:
        assert not ext.startswith('plt')


# Generated at 2022-06-23 15:31:31.043752
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('A.B')
    assert not is_public_family('A._B')
    assert is_public_family('A.__B')
    assert not is_public_family('A._B')
    assert is_public_family('A.__B__')
    assert not is_public_family('A.__B__.C')



# Generated at 2022-06-23 15:31:42.413721
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    root = 'name'
    p = Parser()
    p.b_level = 2
    name = root + '.f'
    node = arguments(
        args=[
            arg(arg='x'),
            arg(arg='y', annotation=parse('str')),
        ],
        returns=parse('int'),
        kwonlyargs=[
            arg(arg='z', annotation=parse('float')),
        ],
        kw_defaults=[Constant(value=None)],
        posonlyargs=[
            arg(arg='t'),
        ],
    )
    p.func_api(root, name, node, None)

# Generated at 2022-06-23 15:31:44.371832
# Unit test for function doctest
def test_doctest():
    """
    >>> test_doctest()
    True
    """
    return True



# Generated at 2022-06-23 15:31:51.591555
# Unit test for function table
def test_table():
    table_it = [['a', 'b'], ['c', 'd']]
    table_result = '\n'.join(['| a | b |', '|:---:|:---:|', '| c | d |'])
    assert table('a', 'b', table_it) == table_result + '\n\n'
# Test it
test_table()


T = TypeVar('T')



# Generated at 2022-06-23 15:31:59.579328
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    p = Parser(sys.modules[__package__].__file__)
    s = p.load_docstring
    assert s("tests", __import__("tests")) is None
    assert s("tests", tests) is None
    assert (
        s("tests.test_parser", __import__("tests.test_parser")) is None
    )
    assert s("tests.test_parser", tests.test_parser) is None
    assert (
        s("tests.test_parser.test_Parser_load_docstring",
          __import__("tests.test_parser.test_Parser_load_docstring")) is None
    )
    assert (
        s("tests.test_parser.test_Parser_load_docstring",
          tests.test_parser.test_Parser_load_docstring) is None
    )

# Generated at 2022-06-23 15:32:06.414780
# Unit test for function table
def test_table():
    assert table('a', 'b', items=[['c', 'd'], ['e', 'f']]) == (
        '| a | b |\n'
        '|:--:|:--:|\n'
        '| c | d |\n'
        '| e | f |\n\n'
    )
    assert table('a', 'b', 'c', 'd', items=['e', 'f']) == (
        '| a | b | c | d |\n'
        '|:---:|:---:|:---:|:---:|\n'
        '| e | f |  |  |\n\n'
    )



# Generated at 2022-06-23 15:32:15.513861
# Unit test for function is_magic
def test_is_magic():
    assert (is_magic('__name__') is True)
    assert (is_magic('__main__') is True)
    assert (is_magic('__add__') is True)
    assert (is_magic('__file__') is True)
    assert (is_magic('__doc__') is True)
    assert (is_magic('__dir__') is True)
    assert (is_magic('__doc__') is True)
    assert (is_magic('_test') is False)
    assert (is_magic('Test') is False)
    assert (is_magic('_Test__') is False)



# Generated at 2022-06-23 15:32:20.364916
# Unit test for function table
def test_table():
    from .testing import assertEqual
    assertEqual(table('a', 'b', [['c', 'd'], ['e', 'f']]),
                '| a | b |\n|:---:|:---:|\n| c | d |\n| e | f |\n\n')



# Generated at 2022-06-23 15:32:24.062783
# Unit test for function parent
def test_parent():
    assert parent('math.sqrt') == 'math'
    assert parent('math.sqrt', level=2) == ''
    assert parent('math.sqrt', level=3) == ''
# end test



# Generated at 2022-06-23 15:32:33.585823
# Unit test for function doctest
def test_doctest():
    assert doctest("""
    >>> import random
    >>> print("Hi!")
    Hi!
    """) == '''\
    ```python
    >>> import random
    >>> print("Hi!")
    Hi!
    ```'''
    assert doctest("""
    >>> import random
    >>> print("Hi!")
    """) == """\
    ```python
    >>> import random
    >>> print("Hi!")
    ```"""
    assert doctest("""
    >>> import random
    >>> print("Hi!")
    Hi!
    >>> print("You!")
    You!
    """) == """\
    ```python
    >>> import random
    >>> print("Hi!")
    Hi!
    >>> print("You!")
    You!
    ```"""

# Generated at 2022-06-23 15:32:38.325912
# Unit test for constructor of class Parser
def test_Parser():
    """Test constructor of class Parser."""
    p = Parser()
    assert p.link
    assert p.b_level == 3
    assert p.toc
    p = Parser(link=False, b_level=4, toc=False)
    assert not p.link
    assert p.b_level == 4
    assert not p.toc

# Generated at 2022-06-23 15:32:42.078263
# Unit test for function table
def test_table():
    assert table("a", "b", [['c', 'd'], ['e', 'f']]) == '''\
| a | b |
|:---:|:---:|
| c | d |
| e | f |

'''



# Generated at 2022-06-23 15:32:50.412617
# Unit test for constructor of class Parser
def test_Parser():
    """Test constructor of class Parser."""
    # <1> Basic test
    p = Parser("./example/foo.py")
    assert p.alias == {"__name__": "__main__", "__qualname__": "__main__"}
    assert p.const == {"__name__": "str"}
    assert p.level == {"__main__": 1, "__name__": 1, "__qualname__": 1}
    assert p.root == {"__main__": "__main__", "__name__": "__main__",
                      "__qualname__": "__main__"}
    assert p.imp == {"__main__": {"foo.bar", "foo.baz", "foo.spam"}}
    # <2> globals and __all__ filter

# Generated at 2022-06-23 15:32:56.392009
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert ast.dump(Resolver('', {}).visit_Attribute(
        Attribute(Name('typing', Load()), 'Tuple', Load()))) == \
        "Name('Tuple', Load())"
    assert ast.dump(Resolver('', {}).visit_Attribute(
        Attribute(Name('bool', Load()), 'Tuple', Load()))) == \
        "Attribute(value=Name('bool', Load()), attr='Tuple', ctx=Load())"


    assert ast.dump(Resolver('', {'typing.List': 'typing.Sequence'})
                    .visit_Attribute(Attribute(Name('typing', Load()),
                                               'List', Load()))) == \
        "Attribute(value=Name('typing', Load()), attr='Sequence', ctx=Load())"

# Generated at 2022-06-23 15:33:03.572824
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    p = Parser()
    # Set p.doc
    p.doc['a.a'] = 'a.a'
    p.doc['a.b'] = 'a.b'
    p.doc['b.b'] = 'b.b'
    p.doc['b.c.c'] = 'b.c.c'
    assert p.doc == {
        'a.a': 'a.a',
        'a.b': 'a.b',
        'b.b': 'b.b',
        'b.c.c': 'b.c.c'
    }
    # Set p.docstring
    p.docstring['a.a'] = p.docstring['b.b'] = p.docstring['b.c.c'] = 'D'

# Generated at 2022-06-23 15:33:11.299998
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__magic__')
    assert is_magic('___magic___')
    assert not is_magic('.___magic___')
    assert not is_magic('___magic__')
    assert not is_magic('__magic___')
    assert is_magic('__magic___')
    assert is_magic('__magic.__')
    assert not is_magic('__magic___magic')
    assert not is_magic('_magic')
    assert not is_magic('___magic_')
    assert not is_magic('__magic_')


# Generated at 2022-06-23 15:33:19.374969
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    p = Parser()
    cls = ClassDef(
        lineno=1,
        col_offset=0,
        name='A',
        args=arguments(
            lineno=1,
            col_offset=0,
            posonlyargs=[],
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        ),
        body=[],
        decorator_list=[],
        bases=[]
    )
    p.class_api('', cls, [], [])
    assert p.doc['A'] == '# class A\n\n'

# Generated at 2022-06-23 15:33:30.471218
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    class A:
        pass

    p = Parser(A(), '', False)
    assert p == Parser(A(), '', False)
    assert p != Parser(A(), '', True)
    assert p != Parser(A(), 'bbb', False)
    assert p != Parser(A(), 'bbb', True)

    class A:
        __slots__ = ['__weakref__', 'a']

    p = Parser(A(), '', False)
    assert p == Parser(A(), '', False)
    assert p != Parser(A(), '', True)
    assert p != Parser(A(), 'bbb', False)
    assert p != Parser(A(), 'bbb', True)

    class A:
        __slots__ = ['__weakref__', 'a']


# Generated at 2022-06-23 15:33:39.961623
# Unit test for method imports of class Parser
def test_Parser_imports():
    from copy import copy
    from inspect import getfullargspec
    from importlib import import_module
    from sys import argv
    from os.path import exists, abspath, dirname, realpath
    from importlib.machinery import SourceFileLoader
    from os import getcwd
    # Python 2 compatibility
    path_join = getattr(__import__("posixpath"), "join")
    # Read the file
    path = path_join(abspath(dirname(__file__)), __file__.replace("test_", "")[:-3] + ".py")
    with open(path, encoding="utf-8") as f:
        source = f.read()
    # Get the required data
    tree = parse(source)
    p = Parser(get_docstring_c)

# Generated at 2022-06-23 15:33:47.189785
# Unit test for constructor of class Resolver
def test_Resolver():
    """Test constructor of class Resolver"""
    test_alias = {
        "": "",
        "a": "b",
        "t": "typing",
        "t.Union": "typing.Union"
    }
    test_resolver = Resolver("", test_alias)
    assert test_resolver
    assert isinstance(test_resolver.alias, dict)
    assert isinstance(test_resolver.root, str)
    assert isinstance(test_resolver.self_ty, str)



# Generated at 2022-06-23 15:33:55.899475
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    # dummy class
    class A:
        def __init__(self, arg, arg1):
            self.arg = arg
            self.arg1 = arg1
        def __eq__(self, arg, arg1):
            pass
    # initiating object of class A
    a1 = A(1, 2)
    a2 = A(1, 2)
    assert (a1 == a2) is not False
    a3 = A(3, 4)
    assert (a2 == a3) is not True
test_Parser___eq__()



# Generated at 2022-06-23 15:34:02.585998
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    from io import StringIO
    from unittest.mock import patch as mock

    with mock('sys.stderr', new=StringIO()) as stderr:
        p = Parser("weak_typing")
        p.alias['a'] = 'b'
        p.const['a'] = 'b'
        p.imp['a'] = 'b'

        p._Parser__repr__()
        assert stderr.getvalue() == """\
[Name Error] not found: b
[Name Error] not found: b
[Type Error] not found: b
[Name Error] not found: b
"""

    with mock('sys.stderr', new=StringIO()) as stderr:
        p = Parser("weak_typing")
        p.alias['b'] = 'a'
        p.const

# Generated at 2022-06-23 15:34:12.084346
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    """Unit test for Parser.resolve"""
    import string

    def t(src: str, expected: str) -> bool:
        """Test case."""
        return Parser(src).resolve('', parse(src)) == expected

    assert t('', '')
    assert t('"hello"', '"hello"')
    assert t('None', 'None')
    assert t('True', 'True')
    assert t('False', 'False')
    assert t('123', '123')
    assert t('3.14', '3.14')
    assert t('1j', '1j')
    assert t('[]', '[]')
    assert t('[1, 2]', '[1, 2]')
    assert t('((1, 2), 3)', '((1, 2), 3)')

# Generated at 2022-06-23 15:34:21.565078
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    from inspect import ModuleInfo, Signature
    from types import ModuleType
    from typing import Tuple
    from .parse import Parser, Module
    from .utils import get_value
    argspec = Tuple[ModuleInfo,
                    ModuleType,
                    Tuple[str, ModuleType],
                    Tuple[str, Signature]]
    # Unit: test __init__ and __post_init__
    parser = Parser(*get_value('modules'), link=False, cache=False)
    assert isinstance(parser, Parser)
    assert isinstance(parser.root['__doc__'], str)
    # Unit: test __post_init__

# Generated at 2022-06-23 15:34:32.184644
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from . import api
    from pymdownx.highlight import Highlight
    p = Parser(link=True)
    m = importlib.import_module('typed_ast.ast3')
    p.load_docstring('typed_ast.ast3', m)
    p.alias['a'] = 'a.b'
    p.alias['a.b'] = 'a.b.c'
    p.alias['a.b.c'] = 'a.b.c.d'
    p.alias['a.b.c.d'] = 'a.b.c.d.e'


# Generated at 2022-06-23 15:34:41.025648
# Unit test for method globals of class Parser
def test_Parser_globals():
    from ast import parse, Store, Constant, Tuple
    from mypy_extensions import TypedDict
    from typing import List, Dict, Any
    parser = Parser()
    source = '''\
        def a() -> str: ...
        class foo(bar): ...
        __all__ = ["foo", "bar"]
        _f = 0
        a = 1
        A = 2
        _a = 3
        FOO = 4
        _FOO = 5
        @foo
        def b() -> str: ...
        b: Dict[None, None] = {}
        c = 10
        C = None
        B = dict()
        del c, C
        def d() -> str: ...
        d = e
    '''
    parser.run(parse(source))

# Generated at 2022-06-23 15:34:47.776338
# Unit test for function const_type

# Generated at 2022-06-23 15:34:55.988037
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    import io
    from io import StringIO
    import tempfile
    from unittest.mock import patch
    import sys
    import os
    from docx import Document
    def mock_input(prompt):
        os.write(sys.__stdin__.fileno(), ''.join(string).encode())
        os.write(sys.__stdin__.fileno(), b'\n')
    # Test for method is_public with normal input
    with patch('builtins.input', side_effect = mock_input):
        string = ['n']
        Parser()
        assert True
    # Test for method is_public with abnormal input
    with patch('builtins.input', side_effect = mock_input):
        string = ['y']
        Parser()
        assert True
    # Test for method is_public with

# Generated at 2022-06-23 15:35:03.836413
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser(None, None, None, None)
    # Case 1
    root = 'com'
    args = [arg('a', Name(id='int', ctx=Load())),
            arg('b', Name(id='float', ctx=Load())),
            arg('*', None),
            arg('c', Name(id='str', ctx=Load())),
            arg('**', Name(id='bool', ctx=Load())),
            arg('return', None)]
    has_self = True
    cls_method = True
    expected = ['type[Self]', 'int', 'float', '', 'str', 'bool', '']
    actual = list(p.func_ann(root, args, has_self, cls_method))

# Generated at 2022-06-23 15:35:15.709358
# Unit test for constructor of class Resolver

# Generated at 2022-06-23 15:35:26.911011
# Unit test for method __repr__ of class Parser

# Generated at 2022-06-23 15:35:34.182792
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    from typing import NamedTuple, Union, List, Dict

    # Some type alias.
    A = NamedTuple('A', [('a', int), ('b', str)])
    B = Dict[str, List[str]]

    p = Parser()
    p.alias['A'] = 'typing.NamedTuple'
    p.alias['B'] = 'typing.Dict'
    p.alias['T'] = 'typing.Union'
    p.alias['X'] = 'typing.Iterable'
    p.alias['a'] = 'module.A'
    p.alias['b'] = 'module.B'

    def test_parser(base: str, node: expr, exp: str) -> None:
        res = p.resolve(base, node)
        assert res == exp, f

# Generated at 2022-06-23 15:35:41.324571
# Unit test for method api of class Parser
def test_Parser_api():
    import mypy_extensions
    from .types import DefaultDict
    from .pandas import Series, DataFrame, Categorical, RangeIndex
    from .numpy import array
    from .typing import Dict, List, Tuple


# Generated at 2022-06-23 15:35:48.030982
# Unit test for function const_type
def test_const_type():
    assert const_type(parse('1', mode='eval').body) == 'int'
    assert const_type(parse('1.1', mode='eval').body) == 'float'
    assert const_type(parse('1.j', mode='eval').body) == 'complex'
    assert const_type(parse('"1"', mode='eval').body) == 'str'
    assert const_type(parse('True', mode='eval').body) == 'bool'
    assert const_type(parse('b"hello"', mode='eval').body) == 'bytes'
    assert const_type(parse('b"hello"[-1]', mode='eval').body) == 'int'
    assert const_type(parse('None', mode='eval').body) == 'None'

# Generated at 2022-06-23 15:35:58.794351
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    from .test_type_analysis import node, parse_ast
    from .type_analysis import get_type
    p = Parser(None, False)
    p.alias = {'a.b': 'a.c'}
    d = node(
        'def f(a: int = 1, *b: str, c: int = None, d=L[Tuple[int, str]]: int, **e: int) -> str: ...',
        'args', 'returns')

# Generated at 2022-06-23 15:36:11.248142
# Unit test for function walk_body
def test_walk_body():
    @dataclass
    class Node:
        """Test class."""
        name: str
        s: Sequence[stmt] = field(default_factory=list)


# Generated at 2022-06-23 15:36:22.179365
# Unit test for function walk_body
def test_walk_body():
    test_nodes = [
        Assign(),
        Assign(),
        Assign(),
        Assign(),
        Assign(),
        Assign(),
        Assign(),
        Assign(),
        Assign(),
        Assign(),
        Assign(),
    ]
    test_nodes_1 = [
        If(body=test_nodes, orelse=test_nodes),
        If(body=test_nodes, orelse=[
            If(body=test_nodes, orelse=test_nodes),
            If(body=test_nodes, orelse=test_nodes)
        ]),
        If(body=test_nodes, orelse=test_nodes),
        If(body=test_nodes, orelse=test_nodes)
    ]
   

# Generated at 2022-06-23 15:36:30.228350
# Unit test for function table
def test_table():
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == """\
| a | b |
|:---:|:---:|
| c | d |
| e | f |

"""
    assert table('a', 'b', [['c', 'd'], ['e', 'f']],
                 [['g', 'h'], ['i', 'j']]) == """\
| a | b |
|:---:|:---:|
| c | d |
| e | f |
| g | h |
| i | j |

"""



# Generated at 2022-06-23 15:36:34.830172
# Unit test for constructor of class Resolver
def test_Resolver():
    """Unit test of constructor."""
    logger.info("test_Resolver")
    assert Resolver("pyslvs_ui", {""}).root == "pyslvs_ui"
    assert Resolver("pyslvs_ui", {""}).alias == set()
    assert Resolver("pyslvs_ui", {""}, "bar").self_ty == "bar"


# Generated at 2022-06-23 15:36:48.202565
# Unit test for method api of class Parser
def test_Parser_api():
    with test("Parser.api"):
        from .test_expand import test_parser
        from .test_expand import ast_attr
        ast_attr(test_parser.test_func, 'body', "def test_func"
                 "() -> None:\n    pass")
        ast_attr(test_parser.test_async_func, 'body', "async def test"
                 "_async_func() -> None:\n    pass")
        ast_attr(test_parser.test_class, 'body',
                 "class test_class(typing.Generic[T], metaclass="
                 "type[abc.ABCMeta]):\n    pass")

# Generated at 2022-06-23 15:36:53.135044
# Unit test for method imports of class Parser
def test_Parser_imports():
    p: Parser
    p = Parser('')
    node: ImportFrom
    node = ImportFrom('_', [alias('a', 'b')], 0)
    p.imports('', node)
    assert p.alias['b'] == 'a'


# Generated at 2022-06-23 15:36:57.289012
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    p = Parser()
    assert p.b_level == 0
    assert p.link is False
    assert p.toc is False
    p = Parser(b_level=1, link=True, toc=True)
    assert p.b_level == 1
    assert p.link is True
    assert p.toc is True

# Generated at 2022-06-23 15:37:06.467517
# Unit test for function doctest
def test_doctest():
    d = '>>> a\n1\n>>> b\n2'
    assert doctest(d) == '```python\n>>> a\n1\n>>> b\n2\n```'
    d = '>>> a\n1\n2\n3\n>>> b\n2'
    assert doctest(d) == '```python\n>>> a\n1\n2\n3\n>>> b\n2\n```'
    d = '>>> a\n1\n2\n3\nb'
    assert doctest(d) == '```python\n>>> a\n1\n2\n3\n```\nb'
    d = 'a\n>>> b\n1\nb'
    assert doctest(d) == d

# Generated at 2022-06-23 15:37:16.968588
# Unit test for method globals of class Parser
def test_Parser_globals():
    import ast
    import types
    import typing
    p = Parser()
    tree = ast.parse(
        """
    from __future__ import annotations
    from typing import *
    __all__ = 'A', 'B'
    A = 1
    B: str
    C = 2
    """
    )
    p.walk(types.ModuleType('root'), tree)
    assert p.root == {'root.A': 'root', 'root.B': 'root', 'root.C': 'root'}
    assert p.alias == {'root.B': 'str', 'root.C': '2'}
    assert p.imp == {'root': {'root.A', 'root.B'}}
    assert p.const == {'root.A': 'int', 'root.C': 'int'}
#

# Generated at 2022-06-23 15:37:26.934013
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    """Test the method post_init of class Parser"""
    module_name = 'test_module'
    filename = 'test_file'
    importlib.invalidate_caches()
    module = importlib.machinery.SourceFileLoader(module_name, filename).load_module()
    test_parser = Parser(module)
    test_parser.mode = 'text'
    test_parser.toc = 'text'
    test_parser.link = 'text'
    test_parser.__post_init__()
    assert test_parser.mode == 'text', \
        "The method post_init of class Parser failed to return correct result"
    assert test_parser.toc == 'text', \
        "The method post_init of class Parser failed to return correct result"

# Generated at 2022-06-23 15:37:37.413452
# Unit test for function const_type
def test_const_type():
    assert const_type(eval("True")[0]) == "bool"
    assert const_type(eval("0")[0]) == "int"
    assert const_type(eval("0.0")[0]) == "float"
    assert const_type(eval("0+0j")[0]) == "complex"
    assert const_type(eval("'0'")[0]) == "str"
    assert const_type(eval("[]")[0]) == "list"
    assert const_type(eval("()")[0]) == "tuple"
    assert const_type(eval("{}")[0]) == "dict"
    assert const_type(eval("{True:True}")[0]) == "dict[bool]"

# Generated at 2022-06-23 15:37:49.676932
# Unit test for constructor of class Parser
def test_Parser():
    from inspect import cleandoc

    p = Parser(["a"], {"b": "c.d.e"}, 2, {})
    assert p.imp == {"a": {}}
    assert p.alias == {"b": "c.d.e"}
    assert p.b_level == 2
    assert list(p.doc) == []
    assert p.root == {}
    assert p.level == {}
    assert list(p.const) == []
    assert list(p.docstring) == []

    p = Parser([], {"a": "b.c.d"}, 0, {"b.c.d": "e", "b.c.d.f": "g"})
    assert p.imp == {"": {}}
    assert p.alias == {"a": "b.c.d"}
    assert p.b_level

# Generated at 2022-06-23 15:38:01.870745
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    import sys
    import logging
    import unittest
    logging.basicConfig(stream=sys.stdout, level=logging.INFO)
    from datetime import datetime
    from typing import Optional
    from docpie import docpie
    from docpie.utils import ModuleType
    from .test import utils
    from .test.utils import (Module, Class, Const, Fun, Var)
    def test(module: ModuleType, *,
             short: bool = True,
             link: bool = True,
             toc: bool = True) -> str:
        doc = Parser(short, link, toc).load(module)
        print(doc)
        return doc

# Generated at 2022-06-23 15:38:03.365769
# Unit test for function parent
def test_parent(): assert parent("a.b.c", level=2) == "a"

# Generated at 2022-06-23 15:38:12.059955
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    apiparser = Parser()
    test_dict = {'alias': {},
                 'b_level': 0,
                 'const': {},
                 'doc': {},
                 'docstring': {},
                 'imp': {'__main__': set()},
                 'level': {'__main__': 0},
                 'link': False,
                 'root': {'__main__': '__main__'},
                 'toc': False}
    assert apiparser.__dict__ == test_dict

# Generated at 2022-06-23 15:38:17.232522
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    import sys
    import ast
    a = ast.parse('a = 1')
    b = ast.parse('a = 1')
    assert Parser.__eq__(a, b)
    b = ast.parse('a = 2')
    assert not Parser.__eq__(a, b)

# Generated at 2022-06-23 15:38:26.551009
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser([], {}, {}, {}, {}, {})
    assert p.is_public('__name__') is False
    assert p.is_public('a.__name__') is False
    assert p.is_public('__package__') is False
    assert p.is_public('a.__package__') is False
    assert p.is_public('__doc__') is False
    assert p.is_public('a.__doc__') is False
    assert p.is_public('__file__') is False
    assert p.is_public('a.__file__') is False
    assert p.is_public('__path__') is False
    assert p.is_public('a.__path__') is False
    assert p.is_public('__loader__') is False
    assert p.is_

# Generated at 2022-06-23 15:38:36.215332
# Unit test for function parent
def test_parent():
    assert parent('__main__', level=1) == '__main__'
    assert parent('__main__.a', level=1) == '__main__'
    assert parent('__main__.a.b', level=1) == '__main__'
    assert parent('__main__.a.b.c', level=1) == '__main__.a.b'
    assert parent('__main__.a.b.c', level=2) == '__main__.a'
    assert parent('__main__.a.b.c', level=3) == '__main__'



# Generated at 2022-06-23 15:38:48.227299
# Unit test for constructor of class Parser
def test_Parser():
    # Initialize parser
    parser = Parser(_path('trees/basic.py'))
    assert parser.link is True
    assert parser.b_level == 1
    assert parser.toc is True
    assert parser.level == {'': 0}
    assert parser.root == {'': ''}
    assert parser.alias == {}
    assert parser.imp == {'': set()}
    assert parser.const == {}
    assert parser.doc == {'': 'This is the top level.\n\n'}
    assert parser.docstring == {}

    # Check parse AST from source code
    parser.parse(_path('trees/basic.py'))

# Generated at 2022-06-23 15:38:57.503880
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from argparse import Namespace
    from ast import parse, Tuple, Expr, Name
    from astunparse import unparse
    from typing import Dict, List, Optional, Sequence, Set
    from types import ModuleType
    from run import __version__, logger
    import inspect
    import sys
    from doc import code, getdoc, logger, is_public_family, doctest, is_magic, Parser
    import pytest
    
    p = Parser(
    links="",
    toc=True,
    root="",
    level=0,
    alias={},
    imp={},
    const={},
    doc={},
    docstring={}
)
    m = p.resolve

# Generated at 2022-06-23 15:39:06.501686
# Unit test for method globals of class Parser
def test_Parser_globals():
    parser = Parser(None, None, 3, False, None)
    c = 0
    if (parser.globals('root', parse('a: int'))
            is None):
        c += 1
    if (parser.globals('root', parse('__all__ = ["a"]'))
            is None):
        c += 1
    if (parser.globals('root', parse('a = 1'))
            is None):
        c += 1
    if (parser.globals('root', parse('A = 1'))
            is None):
        c += 1
    if (parser.globals('root', parse('__all__ = ["b"]'))
            is None):
        c += 1

# Generated at 2022-06-23 15:39:10.030064
# Unit test for function doctest
def test_doctest():
    d = """
Test
>>> 123
456
>>> 789
"""
    assert doctest(d) == """
Test
```python
>>> 123
456
>>> 789
```
"""
    return True



# Generated at 2022-06-23 15:39:12.552182
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert Resolver("a", {}).visit(Subscript(Name("a", Load()),
                                            Constant("b"), Load())) == Name("b", Load())



# Generated at 2022-06-23 15:39:24.775268
# Unit test for constructor of class Resolver
def test_Resolver():
    assert parse('typing.List[int]').body[0].value == \
        Resolver("", {}).visit_Call(Call(Name("List", Load()),
                                         [Constant(int)], []))
    assert parse('typing.Optional[int]').body[0].value == \
        Resolver("", {}).visit(Subscript(Name("typing.Optional", Load()),
                                         Tuple([Constant(int)], Load()),
                                         Load()))

# Generated at 2022-06-23 15:39:31.587366
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    for node in parse('''
        typing.Optional[int]
        typing.List[int]
        typing.Dict[int, int]
        typing.Tuple[int]
        typing.TypeVar()
        typing.Callable[[int], int]
    ''').body:
        print(unparse(Resolver('', {}).visit(node)))
# test_Resolver_visit_Attribute()



# Generated at 2022-06-23 15:39:42.731119
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore('_') == r'\_'
    assert esc_underscore('__') == r'\_\_'
    assert esc_underscore('___') == r'\_\_\_'
    assert esc_underscore('_abc_') == r'\_abc\_'
    assert esc_underscore('a') == 'a'
    assert esc_underscore('__a') == r'\_\_a'
    assert esc_underscore('a__') == r'a\_\_'
    assert esc_underscore('a_b') == 'a_b'
    assert esc_underscore('a___') == r'a\_\_\_'
    assert esc_underscore('a_b_c') == r'a_b_c'

# Generated at 2022-06-23 15:39:48.228296
# Unit test for method imports of class Parser
def test_Parser_imports():
    """Test for the Parser.imports method"""
    import ast
    
    m = Parser()
    m.imports('x.y', ast.parse('import a.b', mode='exec'))
    assert m.alias['x.y.b'] == 'a.b'
    
    m = Parser()
    m.imports('x.y', ast.parse('import a.b as c', mode='exec'))
    assert m.alias['x.y.c'] == 'a.b'
    
    m = Parser()
    m.imports('x.y', ast.parse('from a.b import d', mode='exec'))
    assert m.alias['x.y.d'] == 'a.b.d'
    
    m = Parser()

# Generated at 2022-06-23 15:39:55.706830
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    # Setup
    parser = Parser(link=False, toc=False)
    parser.doc['aaa.One'] = '{}\n\n'
    parser.doc['aaa.One.two'] = '{}\n\n'
    parser.doc['aaa.__all__'] = '{}\n\n'
    parser.doc['aaa.One.three'] = '{}\n\n'
    parser.doc['aaa.One.four'] = '{}\n\n'
    parser.doc['aaa.One.five'] = '{}\n\n'
    parser.doc['aaa.__all__.zero'] = '{}\n\n'
    parser.doc['aaa.__all__.one'] = '{}\n\n'

# Generated at 2022-06-23 15:39:58.161868
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    parser = Parser(None, True, False)
    assert parser == parser
    assert parser != ''

# Generated at 2022-06-23 15:40:01.497551
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    p = Parser()
    p.__post_init__()
test_Parser___post_init__()


# Generated at 2022-06-23 15:40:09.417531
# Unit test for function const_type
def test_const_type():
    """Test code.const_type."""
    assert const_type(parse('123').body[0].value) == 'int'
    assert const_type(parse('True').body[0].value) == 'bool'
    assert const_type(parse('1.0').body[0].value) == 'float'
    assert const_type(parse('"123"').body[0].value) == 'str'
    assert const_type(parse('[1, 2, 3]').body[0].value) == 'list[int]'
    assert const_type(parse('{"a":1}').body[0].value) == 'dict[str, int]'