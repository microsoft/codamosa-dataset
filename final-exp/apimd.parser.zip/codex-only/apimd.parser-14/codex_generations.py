

# Generated at 2022-06-23 15:30:07.568583
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert unparse(cast(Expr, parse("typing.Optional[int]").body[0])).strip() == \
        "typing.Optional[int]"
    assert unparse(Resolver("", {}).visit_Attribute(
        cast(Attribute, parse("typing.Optional[int]").body[0].value)
    )).strip() == "Optional[int]"

# Generated at 2022-06-23 15:30:16.875567
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    """Annotation resolver: Subscript.
    """
    from typing import Callable, Union, Optional
    from ast import Load # type: ignore
    from itertools import product
    from astunparse import unparse as ap_unparse # type: ignore
    # Load the variable `resolve`
    namespace = {}
    exec(f"from {__name__} import {Resolver.__qualname__} as resolver", namespace)
    resolve = namespace['resolver']
    # Load the variable `code`
    exec(f"from {__name__} import code", namespace)
    # Load the variable `table`
    exec(f"from {__name__} import table", namespace)
    # PEP585
    # typing.Union

# Generated at 2022-06-23 15:30:26.577542
# Unit test for function walk_body

# Generated at 2022-06-23 15:30:29.350089
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    p1 = Parser('a')
    p2 = Parser('b')
    p3 = Parser('a')
    assert p1 == p1
    assert p1 != p2
    assert p1 == p3



# Generated at 2022-06-23 15:30:38.761717
# Unit test for method parse of class Parser
def test_Parser_parse():
    import ast
    import sys
    import tokenize
    from io import StringIO
    from typing import Type
    from textwrap import dedent
    # https://bitbucket.org/takluyver/autodoc
    def get_ast(code, mode=parse):
        if '\r' in code:
            raise ValueError('CRLF line endings not allowed')
        if hasattr(tokenize, 'tokenize_by_stepping'):
            # Python 3.8 and up
            tokenize.tokenize_by_stepping(map(lambda l: str(l) + '\n',
                                              code.split('\n')),
                                          lambda s: s.__next__())

# Generated at 2022-06-23 15:30:48.288929
# Unit test for function doctest
def test_doctest():
    """
    >>> doctest('Test')
    'Test'
    >>> doctest('This is\ntest')
    'This is\ntest'
    >>> doctest('>>> Test\nThis is\ntest')
    '```python\n>>> Test\n```\nThis is\ntest'
    >>> doctest('>>> Test1\nThis is\n>>> Test2\nTest')
    '```python\n>>> Test1\n```\nThis is\n```python\n>>> Test2\n```\nTest'
    >>> doctest('>>> Test1\nThis is\n>>> Test2\nTest\n>>> Test3')
    '```python\n>>> Test1\n>>> Test2\n>>> Test3\n```\nThis is\nTest'
    """



# Generated at 2022-06-23 15:30:56.444342
# Unit test for method compile of class Parser
def test_Parser_compile():
    from .__main__ import main
    doc = "".join(main(["-c", "-T", "./tests/Tests/exam/parser.py"],
                       stdout=subprocess.PIPE).stdout)

# Generated at 2022-06-23 15:31:02.958232
# Unit test for function is_magic
def test_is_magic():
    assert not is_magic('__clash__.__clash__')
    assert not is_magic('__clash__.__clash__.__clash__')
    assert is_magic('__magic__')
    assert is_magic('__magic_magic__')
    assert is_magic('__magi__')
    assert is_magic('__magic')
    assert not is_magic('__magic1__')
    assert not is_magic('__ma_magic__')



# Generated at 2022-06-23 15:31:06.566694
# Unit test for function table
def test_table():
    t = table('a', 'b', [['c', 'd'], ['e', 'f']])
    assert t == "| a | b |\n|:---:|:---:|\n| c | d |\n| e | f |\n\n"
test_table()



# Generated at 2022-06-23 15:31:18.741794
# Unit test for function walk_body

# Generated at 2022-06-23 15:31:26.834389
# Unit test for function walk_body
def test_walk_body():
    @dataclass
    class A:
        a: int
    src = """\
if True:
    if True:
        a = 1
elif True:
    a = 2
else:
    a = 3
"""
    ifs = next(v for v in walk_body(parse(src).body) if isinstance(v, If))
    assert len(ifs.body) == 1
    assert ifs.orelse[0].value.n == 2
    assert len(ifs.orelse[1].body) == 1

# Generated at 2022-06-23 15:31:32.627272
# Unit test for method compile of class Parser
def test_Parser_compile():
    """Test for method 'compile' of class 'Parser'"""
    p = Parser()
    p.init_doc('test', ModuleType('test'), 'test')
    p.doc['test'] = '{}'
    assert p.compile() == '[**Table of contents:**](#table-of-contents)\n+ [`test`](#test)\n\n\n# test()\n'



# Generated at 2022-06-23 15:31:36.636905
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('_abc')
    assert is_public_family('pyslvs')
    assert not is_public_family('pyslvs._core')
    assert is_public_family('pyslvs_ui.info.system_info')
    assert not is_public_family('pyslvs_ui._compile_speed_test')



# Generated at 2022-06-23 15:31:47.335632
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    from typing import Optional, Union
    from .pep585 import PEP585
    for s, t in [('U[A]', 'A | None'),
                 ('O[B]', 'B | None'),
                 ('A | B', 'A | B'),
                 ('A | B | None', 'A | B | None'),
                 ('None | A | B', 'A | B | None'),
                 ('None | B | A', 'A | B | None'),
                 ('None | None | A', 'A | None'),
                 ('Optional[None]', 'None')]:
        assert code(unparse(Resolver(__name__, PEP585).visit(parse(s).body[0]))) == code(t)

# Generated at 2022-06-23 15:31:56.618502
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    import os
    import json
    import typing
    from .pep585 import PEP585
    from ast import Module
    test_file = os.path.join("tests", "test.json")
    tests = json.loads(open(test_file, mode='r', encoding='utf-8').read())
    for test in tests:
        m = Module(body=[])
        for item in test['items']:
            m.body.append(parse(item))
        r = Resolver(test['root'], PEP585)
        new = r.visit(m)
        old = Module(body=[])
        for item in test['hope']:
            old.body.append(parse(item))
        assert unparse(new) == unparse(old)

# Generated at 2022-06-23 15:32:03.761068
# Unit test for function doctest
def test_doctest():
    """Doctest for function doctest"""
    import doctest

    doctest.testmod()
    doc = """>>> a = 5
>>> b = 6
>>> a + b
11
>>> c = 3
>>> d = 2
>>> c - d
1
>>> e = 1
>>> e
1
>>> f = 2
>>> g = 3
>>> f < g
True"""
    assert doctest(doc) == """```python
>>> a = 5
>>> b = 6
>>> a + b
11
```

>>> c = 3
>>> d = 2
>>> c - d
1

>>> e = 1
>>> e
1

>>> f = 2
>>> g = 3
>>> f < g
True
```"""



# Generated at 2022-06-23 15:32:08.910652
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    m = ModuleSpec('_', loader_state={'__doc__': 'my mod docstring'},
                   submodule_search_locations=[])
    class A: 'my A class docstring'
    class B: 'my B class docstring'
    subm_a = ModuleSpec('_abc', loader_state={'__doc__': 'my submodule A'},
                        submodule_search_locations=[])
    p = Parser('', link=False)
    p.doc['_'] = '# _\n'
    p.doc['_abc.A'] = '# class A#\n'
    p.doc['_abc.B'] = '# class B\n'
    p.load_docstring('_', m)
    p.load_docstring('_abc', subm_a)
    assert dict

# Generated at 2022-06-23 15:32:19.311998
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    """Test the method with different cases."""
    def _check(value: str, slice: str, expected: str):
        node = Subscript(Name(value, Load()), parse(slice).body[0].value, Load())
        resolver = Resolver("", {})
        assert unparse(resolver.visit(node)).strip() == expected

    _check("a", "b", "a[b]")
    _check("typing.Union[a, b, c]", "d", "Union[d, a, b, c]")
    _check("typing.Optional[a]", "b", "Union[b, None]")
    _check("a", "b[c[d]]", "a[b[c[d]]]")

# Generated at 2022-06-23 15:32:20.019540
# Unit test for method visit_Constant of class Resolver

# Generated at 2022-06-23 15:32:23.966112
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    assert Parser() == Parser()
    assert not Parser(link=True) == Parser()
    assert not Parser(config=True) == Parser()
    assert not Parser(b_level=1) == Parser()

# Generated at 2022-06-23 15:32:29.534984
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    a = Mock()
    a.__doc__ = "Test"
    m = Mock()
    m.a = a
    p = Parser(toc=False, link=False)
    p.imp['a'] = {'a'}
    p.doc['a.a'] = "Doc"
    p.load_docstring('a', m)
    assert p.docstring['a.a'] == doctest("Test")


# Generated at 2022-06-23 15:32:40.328423
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    import pytest
    parser = Parser()
    parser.root['root'] = 'root'
    parser.imp['root'] = set()
    parser.alias['root.f'] = 'root.f'
    parser.alias['root.g'] = 'root.g'
    parser.alias['root.ANY'] = 'root.ANY'
    parser.alias['root.int'] = 'root.int'
    parser.alias['root.self'] = 'root.self'
    parser.alias['root.none'] = 'root.none'
    parser.alias['root.typing.Any'] = 'root.typing.Any'
    parser.alias['root.typing.NewType'] = 'root.typing.NewType'
    parser.alias['root.typing.Optional'] = 'root.typing.Optional'


# Generated at 2022-06-23 15:32:49.180077
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    Parser("test_path").is_public('a')
    # False
    Parser("test_path").is_public('b')
    # True
    Parser("test_path").is_public('c')
    # False
    Parser("test_path").is_public('d')
    # False
    Parser("test_path").is_public('e')
    # False
    Parser("test_path").is_public('f')
    # True
    Parser("test_path").is_public('g')
    # True
    Parser("test_path").is_public('g.h')
    # True
    Parser("test_path").is_public('g.i')
    # True
    Parser("test_path").is_public('j')
    # False

# Generated at 2022-06-23 15:32:52.725446
# Unit test for function esc_underscore
def test_esc_underscore():
    """Test function esc_underscore."""
    assert r"a\_b" == esc_underscore("a_b")
    assert r"a_b" == esc_underscore("a_b_")
    assert r"a_b" == esc_underscore("a__b")
    assert r"a_b" == esc_underscore("__a_b")



# Generated at 2022-06-23 15:32:54.187922
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    assert False, "TestCase not implemented"



# Generated at 2022-06-23 15:33:00.714690
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    canvas = Parser(APIConfig(dict(target=[], link=False)))
    canvas.__post_init__(dict(target=[], link=False))
    assert isinstance(canvas, Parser)
    assert canvas.imp == {}
    assert canvas.doc == {}
    assert canvas.alias == {'__builtins__': 'builtins'}
    assert canvas.level == {}
    assert canvas.root == {}
    assert canvas.const == {}
    assert canvas.docstring == {}
    assert not canvas.toc

# Generated at 2022-06-23 15:33:07.812444
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    def test_equal0():
        p1 = Parser(None, None)
        p2 = Parser(None, None)
        assert p1 == p2
        assert p2 == p1

    def test_equal1():
        p1 = Parser(None, None, link=True)
        p2 = Parser(None, None, link=True)
        assert p1 == p2
        assert p2 == p1

    def test_notequal0():
        p1 = Parser(None, None)
        p2 = Parser(None, None, link=True)
        assert p1 != p2
        assert p2 != p1

    def test_notequal1():
        p1 = Parser(None, None, link=True)
        p2 = Parser(None, None)

# Generated at 2022-06-23 15:33:18.275787
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    assert Resolver('', {}).visit_Constant(Constant(1)) == Constant(1)
    assert Resolver('', {}).visit_Constant(Constant(None)) == Constant(None)
    assert Resolver('', {}).visit_Constant(Constant('abc')) == Constant('abc')
    assert Resolver('', {}).visit_Constant(Constant(set())) == Constant(set())
    assert Resolver('', {}).visit_Constant(Constant([])) == Constant([])
    assert Resolver('', {}).visit_Constant(Constant(())) == Constant(())
    assert Resolver('', {}).visit_Constant(Constant({})) == Constant({})
    assert Resolver('', {}).visit_Constant(Constant(dict())) == Constant(dict())

# Generated at 2022-06-23 15:33:29.601804
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    import json
    import typing
    import unittest

    class T(unittest.TestCase):
        def test_1(self):
            import random
            random.choice('abc')

    import os
    import sys
    import tempfile
    import doctest
    import importlib
    import unittest

    sys.path.insert(0, os.curdir)
    module_name = '__uinttest__'
    module_name_root = module_name + '.'
    p = Parser()
    p.parse_file(module_name + '.py')
    module_name_pyc = module_name + '.pyc'
    try:
        os.unlink(module_name_pyc)
    except FileNotFoundError:
        pass

# Generated at 2022-06-23 15:33:40.250674
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    assert Parser(asdf).alias == dict()
    assert Parser(asdf).imp == dict()
    assert Parser(asdf).doc == dict()
    assert Parser(asdf).docstring == dict()
    assert Parser(asdf).root == dict()
    assert Parser(asdf).const == dict()
    assert Parser(asdf).level == dict()
    assert Parser(asdf).b_level == None
    assert Parser(asdf, link=True).alias == dict()
    assert Parser(asdf, link=True).imp == dict()
    assert Parser(asdf, link=True).doc == dict()
    assert Parser(asdf, link=True).docstring == dict()
    assert Parser(asdf, link=True).root == dict()

# Generated at 2022-06-23 15:33:49.198646
# Unit test for function const_type
def test_const_type():
    assert const_type(parse("1").body[0]) == 'int'
    assert const_type(parse("[]").body[0]) == 'listAny'
    assert const_type(parse("{}").body[0]) == 'dictAnyAny'
    assert const_type(parse("{1:2}").body[0]) == 'dictintint'
    assert const_type(parse("{1.0:2}").body[0]) == 'dictfloatint'
    assert const_type(parse("{True:2}").body[0]) == 'dictboolint'
    assert const_type(parse("{'foo':2}").body[0]) == 'dictstrint'
    assert const_type(parse("True").body[0]) == 'bool'
    assert const_type(parse("(1,)").body[0])

# Generated at 2022-06-23 15:33:55.639416
# Unit test for function walk_body
def test_walk_body():
    def walk_body_check(func: FunctionDef) -> None:
        func = parse(unparse(func)).body[0]
        assert isinstance(func, FunctionDef)
        assert len(func.body) >= 2 and isinstance(func.body[0], If) and isinstance(func.body[1], Try)
        assert len(func.body[0].body) + len(func.body[0].orelse) == 16
        assert len(func.body[1].body) + len(func.body[1].handlers[0].body) + len(func.body[1].orelse) + len(func.body[1].finalbody) == 15
        assert len([n for n in func.body if isinstance(n, Expr)]) == 4

# Generated at 2022-06-23 15:33:57.191920
# Unit test for function parent
def test_parent():
    assert parent("x.y") == "x"
    assert parent("x.y", level=2) == ""



# Generated at 2022-06-23 15:34:08.401167
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    """Test Parser.class_api"""
    from .parse import parse, parse_expr
    from .walk import walk_body
    from .resolve import Resolver
    from .resolve import _m, esc_underscore
    from .const import get_type
    node = parse('class A: pass').body[0]
    parser = Parser(
        alias={},
        imp={},
        doc={},
        docstring={},
        level={},
        root={},
        const={},
    )
    parser.class_api(_m(), node)
    assert parser.doc == {
        'A': '### class A\n\n*Full name:* `A`\n\n'
    }

    node = parse('class A: A: str\n    pass').body[0]
    parser = Parser

# Generated at 2022-06-23 15:34:09.528540
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    print(Parser())

# Generated at 2022-06-23 15:34:11.199246
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    """test._test_Resolver_visit_Constant"""
    assert Resolver("", dict())


# Generated at 2022-06-23 15:34:20.915972
# Unit test for function const_type
def test_const_type():
    assert const_type(ast.parse('True').body[0].value) == 'bool'
    assert const_type(ast.parse('0.0').body[0].value) == 'float'
    assert const_type(ast.parse('"a"').body[0].value) == 'str'
    assert const_type(ast.parse('[0]').body[0].value) == 'list[int]'
    assert const_type(ast.parse('{0:1}').body[0].value) == 'dict[int, int]'
    assert const_type(ast.parse('{"a":0}').body[0].value) == 'dict[Any, int]'
    assert const_type(ast.parse('{"a":0, 0:0.0}').body[0].value) == 'dict[Any, Any]'


# Generated at 2022-06-23 15:34:31.614615
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    p = Parser()
    assert p.resolve(
        'alice.bob',
        Name(id='object', ctx=Load()),
    ) in ('object', 'type[object]')
    assert p.resolve(
        'alice.bob',
        Name(id='object', ctx=Store()),
    ) == 'object'
    assert p.resolve(
        'alice.bob',
        Subscript(
            value=Name(id='I', ctx=Load()),
            slice=Index(value=Constant(value=1)),
        ),
    ) == 'I[1]'

# Generated at 2022-06-23 15:34:40.642013
# Unit test for method imports of class Parser
def test_Parser_imports():
    import os
    import sys
    import asttokens

    import pytest

    from .parser import Parser

    p = Parser()

    alias, root = p.alias, p.root

    m = sys.modules.copy()
    os.environ.pop('PYTHONPATH', None)
    try:
        for m in 'asttokens', 'simple_parsing':
            del sys.modules[m]
    except KeyError:
        pass

    p.parse(__file__, asttokens.ASTTokens(
        open(__file__).read(), parse=True), 'asttokens')
    p.parse(__file__, asttokens.ASTTokens(
        open(__file__).read(), parse=True), 'simple_parsing')


# Generated at 2022-06-23 15:34:49.538849
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    annotations = {
        'x': "str",
        'y': "Optional[Tuple[str, ...]]",
    }
    resolver = Resolver("module", annotations)
    node = resolver.visit(parse("x").body[0])
    assert code(unparse(node)) == "`str`"
    node = resolver.visit(parse("y").body[0])
    assert code(unparse(node)) == "`Optional[Tuple[str, ...]]`"
    annotations['y'] = "Tuple[str, ...]"
    node = resolver.visit(parse("y").body[0])
    assert code(unparse(node)) == "`Tuple[str, ...]`"



# Generated at 2022-06-23 15:34:56.615920
# Unit test for method api of class Parser
def test_Parser_api():
    """Test the method api of class Parser."""
    has_self = random.choice([True, False])
    cls_method = random.choice([True, False])
    import enum
    import builtins

# Generated at 2022-06-23 15:35:00.053225
# Unit test for function table
def test_table():
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == "\
| a | b | \
|:---:|:---:| \
| c | d | \
| e | f | \
\n"



# Generated at 2022-06-23 15:35:07.026005
# Unit test for method visit_Attribute of class Resolver

# Generated at 2022-06-23 15:35:18.124235
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():

    import os
    import tempfile
    from pathlib import Path
    from pytest import approx
    from sys import version_info

    from . import load_test_module

    qwe = load_test_module('sphinx_viz.tests.test_data.qwe')
    tmpdir = Path(os.getenv('SPHINXVIZ_TEST_TMPDIR', ''))
    if not tmpdir:
        tmpdir = tempfile.TemporaryDirectory('pytest-sphinx-viz-').name
        tmpdir = Path(tmpdir)
    if version_info < (3, 7):
        name = 'qwe'
    else:
        name = 'qwe.py'
    f = tmpdir / 'qwe.py'

# Generated at 2022-06-23 15:35:19.752859
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    assert Parser() == Parser()

# Generated at 2022-06-23 15:35:29.886584
# Unit test for method api of class Parser
def test_Parser_api():
    from typing import List
    from .ast import parse
    from .typing import parse_typing
    from .resolver import Alias

    def test_func_ann(expr: str, expect: List[str]):
        self_ty = "self-type"
        node = parse_typing(expr)
        parser = Parser(Alias())
        assert list(parser.func_ann("root", [arg("arg", node)],
                                    has_self=True, cls_method=True)) == expect

    def test_body_api(lines: List[str], expect: List[str]):
        node = parse("\n".join(lines))
        parser = Parser(Alias())
        parser.api("root", node[0])
        assert list(parser.doc.values()) == expect


# Generated at 2022-06-23 15:35:33.897974
# Unit test for function table
def test_table():
    assert table('a', 'b', ['c', 'd']) == '''\
| a | b |
|:---:|:---:|
| c | d |

'''



# Generated at 2022-06-23 15:35:35.554423
# Unit test for function walk_body
def test_walk_body():
    """Test :func:`walk_body`."""

# Generated at 2022-06-23 15:35:44.576365
# Unit test for method globals of class Parser
def test_Parser_globals():
    """Unit test for method globals of class Parser"""
    from . import load_ast
    from .test_code import Assign, Name, Constant
    from .test_code import module
    from .test_code import Assign, Name, Constant
    from .test_code import module
    from .test_code import module
    from .test_code import Assign, Name, Constant
    from .test_code import module
    from .test_code import module
    from .test_code import Assign, Name, Constant
    from .test_code import module
    from .test_code import module
    from .test_code import Assign, Name, Constant
    from .test_code import module
    from .test_code import module
    from .test_code import Assign, Name, Constant
    from .test_code import module

# Generated at 2022-06-23 15:35:47.279240
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    p1 = Parser()
    p2 = Parser()
    assert not p1.__eq__(p2)


# Generated at 2022-06-23 15:35:58.369090
# Unit test for function esc_underscore
def test_esc_underscore():
    import textwrap
    txt = """
        This is a function of `_` underscore.
        The parameter `_` is a string, so it is not a class attribute.
    """
    logger.info(textwrap.dedent(txt))
    assert textwrap.dedent(txt) == textwrap.dedent(esc_underscore(txt))
    txt = """This is a function of ```_``` underscore.
    """
    logger.info(textwrap.dedent(txt))
    assert textwrap.dedent(txt) == textwrap.dedent(esc_underscore(txt))
    txt = """
        This is a function of `__` underscore.
    """
    logger.info(textwrap.dedent(txt))

# Generated at 2022-06-23 15:36:11.063976
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    """Test for method `resolve` of class `Parser`."""
    p: Parser = Parser()
    p.alias['b.A'] = 'a.A'
    p.alias['b.C'] = 'a.C'
    assert p.resolve('a', parse_expr('b.A')) == 'a.A'
    assert p.resolve('a', parse_expr('b.C')) == 'a.C'
    assert p.resolve('a', parse_expr('a.A')) == 'a.A'
    assert p.resolve('a', parse_expr('A()')) == 'A'
    assert p.resolve('a', parse_expr('C()')) == 'C'
    assert p.resolve('a', parse_expr('int')) == 'int'


# Generated at 2022-06-23 15:36:15.418415
# Unit test for function parent
def test_parent():
    assert parent('a.b.c') == 'a.b'
    assert parent('a.b.c', level=2) == 'a'
    assert parent('a') == ''
    assert parent('a', level=2) == ''
    assert parent('a.b', level=2) == 'a'
# Test
test_parent()



# Generated at 2022-06-23 15:36:27.291342
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    """Test funtion annotation table."""
    root = "a.b.c"
    alias = {
        _m(root, 'x'): "'x'",
        _m(root, 'y'): "'y'",
        _m(root, 'self_ty'): "SelfTy",
        _m(root, 'def_ty'): "DefTy",
    }
    p = Parser(alias, const={"ANY": "Any"}, link=True, toc=False)

# Generated at 2022-06-23 15:36:35.359018
# Unit test for method api of class Parser
def test_Parser_api():
    def m(ns, dist):
        return ns if ns == dist else ns + '.' + dist

    def assert_api(source: str, dist: str, result: str) -> None:
        root = _m(*dist.split('.'))
        parser = Parser(parse_mode='exec')
        parser.visit(parser.parse(source))
        parser.api(root, parser.module)
        assert m(root, dist) in parser.doc
        assert parser.doc[m(root, dist)] == result


# Generated at 2022-06-23 15:36:48.484166
# Unit test for method api of class Parser

# Generated at 2022-06-23 15:36:53.184376
# Unit test for function parent
def test_parent():
    assert parent("a") == "a"
    assert parent("a.b") == "a"
    assert parent("a.b.c") == "a.b"
    assert parent("a.b.c", level=2) == "a"



# Generated at 2022-06-23 15:37:02.577457
# Unit test for method globals of class Parser
def test_Parser_globals():
    import ast
    from . import EMPTY
    root = 'test'
    alias = {}
    root_ = {root: root}
    const = {}
    imp = {root: set()}
    level = {root: 0}
    doc = {}
    docstring = {}
    tree = ast.parse('''
        def f(a: List[int]) -> Tuple[int, ...]: ...
        def f(a: Tuple[int, ...]) -> List[int]: ...
        class C(int, **dict): ...
        C = int
        C = list
        a = 1
        def f(*, c: int = 0): ...
        ''')

# Generated at 2022-06-23 15:37:04.380849
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():

    p: Parser = Parser()
    assert repr(p) == "Parser()"

# Generated at 2022-06-23 15:37:12.315207
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    res = Resolver('a', {})
    assert res.visit(Constant('int')) == Constant('int')
    assert res.visit(Constant('int()')) == Constant('int()')
    assert res.visit(Constant('float')) == Constant('float')
    assert res.visit(Constant('float()')) == Constant('float()')
    assert res.visit(Constant('complex')) == Constant('complex')
    assert res.visit(Constant('complex()')) == Constant('complex()')
    assert res.visit(Constant('bool')) == Constant('bool')
    assert res.visit(Constant('bool()')) == Constant('bool()')
    assert res.visit(Constant('str')) == Constant('str')

# Generated at 2022-06-23 15:37:17.989252
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    """Test for method load_docstring."""
    from importlib import import_module
    from typing import Optional
    from .test_parser import test_parser
    from . import test as _test
    from .test import TestParser, Parser as _Parser
    parser = Parser(
        root=_test.__name__,
        toc=False,
        link=False,
        b_level=0,
        no_alias=False,
        read_docstring=False,
        include_source=False,
    )
    test_parser([TestParser, _Parser], parser)


# Generated at 2022-06-23 15:37:25.002426
# Unit test for method compile of class Parser
def test_Parser_compile():
    from . import __file__
    from .parser import Parser
    from .parser_base import ParserBase
    p = ParserBase()
    m = p.parse_file(__file__)
    p = Parser(link=True, toc=True)
    p(m)
    doc = p.compile()
    assert doc.startswith('**Table of contents:**')
    assert doc.count('\n\n') >= len(p.doc) - 1

# Generated at 2022-06-23 15:37:36.136949
# Unit test for method compile of class Parser

# Generated at 2022-06-23 15:37:48.283427
# Unit test for function const_type
def test_const_type():
    assert const_type(parse("True").body[0].value) == 'bool'
    assert const_type(parse("1").body[0].value) == 'int'
    assert const_type(parse("1.0").body[0].value) == 'float'
    assert const_type(parse("1.0j").body[0].value) == 'complex'
    assert const_type(parse("''").body[0].value) == 'str'
    assert const_type(parse("[1, 2, 3]").body[0].value) == 'list[int]'
    assert const_type(parse("(1, 2, 3)").body[0].value) == 'tuple[int]'
    assert const_type(parse("{1, 2, 3}").body[0].value) == 'set[int]'
   

# Generated at 2022-06-23 15:37:49.112131
# Unit test for method api of class Parser
def test_Parser_api():
    # TODO
    pass

# Generated at 2022-06-23 15:37:56.836441
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    root = '__main__'
    alias = {
        ('foo',): '"a"'
    }
    resolver = Resolver(root, alias)
    assert isinstance(resolver.visit(parse('"a"').body[0]), Expr)
    # Not name
    assert isinstance(resolver.visit(parse('1').body[0]), Expr)



# Generated at 2022-06-23 15:38:04.603676
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    m = Module((Expr(Constant(3, kind=None)),), lineno=1, col_offset=0)
    p = Parser()
    p.load_docstring('sample', m)
    assert 'sample' not in p.docstring
    m = Module((Expr(Constant('doc', kind=None)),), lineno=1, col_offset=0)
    p = Parser()
    p.load_docstring('sample', m)
    assert p.docstring['sample'] == 'doc\n'

# Generated at 2022-06-23 15:38:10.803557
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    # Initial
    p = Parser()
    p.imp['__main__'] = {'__doc__'}
    p.imp['__main__.sub'] = {'sub', 'sub.subsub'}
    # Case 1: True
    p.doc = {
        '__main__.subsub': '',
    }
    p.root = {
        '__main__.subsub': '__main__.sub'
    }
    p.level = {
        '__main__.subsub': 1
    }
    assert p.is_public('__main__.subsub')
    # Case 2: False
    p.level['__main__.subsub'] = 0
    assert not p.is_public('__main__.subsub')
    # Case 3: False

# Generated at 2022-06-23 15:38:18.383612
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    r = Resolver('', {})
    assert isinstance(r.visit_Attribute(Attribute(Name('typing', Load()), 'Optional', Load())),
                      Name)
    assert isinstance(r.visit_Attribute(Attribute(Name('Union', Load()), 'Optional', Load())),
                      Attribute)
    assert isinstance(r.visit_Attribute(Attribute(Name('typing', Load()), 'Optional', Load())),
                      Name)

# Generated at 2022-06-23 15:38:22.768804
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__test__') == True
    assert is_magic('__not_magic__') == True
    assert is_magic('not_magic') == False
    assert is_magic('__not_magic') == False
    assert is_magic('not_magic__') == False



# Generated at 2022-06-23 15:38:25.877544
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    p = Parser()

# Generated at 2022-06-23 15:38:32.499457
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    t = Attribute(Name('typing', Load()), 'List', Load())
    assert Resolver('', {}).visit(t).__dict__ == Name('List', Load()).__dict__
    t = Attribute(Name('typing', Load()), 'typing', Load())
    assert Resolver('', {}).visit(t).__dict__ == Name('typing', Load()).__dict__



# Generated at 2022-06-23 15:38:45.153326
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from . import parser
    from . import typevar
    from . import docstring
    from . import generic
    from . import _parser
    from . import _typevar
    from . import _docstring
    from . import _generic
    import inspect
    import typing
    import regex
    assert parser._docstring is docstring
    assert parser._typevar is typevar
    assert parser._parser is _parser
    assert parser._generic is generic
    assert parser.DebugType is _docstring.DebugType
    assert parser.parse is _parser.parse
    assert parser.Dict is _generic.Dict
    assert parser.TypeVar is _typevar.TypeVar
    assert parser.TypeAlias is _docstring.TypeAlias
    assert parser.__all__ == ['Parser']
    assert parser.T is _typevar.T

# Generated at 2022-06-23 15:38:49.754916
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    p = Parser()
    p.doc['m'] = "*Full name:* `m`\n\n"
    p.load_docstring('m', ModuleType('m'))
    assert p.doc['m'] == (
        "*Full name:* `m`\n\n"
        "Test docstring.\n")


# Generated at 2022-06-23 15:38:55.803877
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    from doc_checker.import_resolver import Parser
    import doc_checker.parser
    
    p = Parser()
    assert p._Parser__post_init__.__name__ in dir(doc_checker.parser)
    assert p._Parser__post_init__.__module__ == "doc_checker.parser"
    assert callable(p._Parser__post_init__)
    assert hasattr(p._Parser__post_init__, '__code__')

# Generated at 2022-06-23 15:38:59.535385
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("Foo_bar") == "Foo\_bar"
    assert esc_underscore("Foo_bar_baz") == "Foo\_bar\_baz"
    assert esc_underscore("Foo") == "Foo"



# Generated at 2022-06-23 15:39:07.475288
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    code = '''
    class A:
        def __init__(self, x: int) -> None: ...
        def __repr__(self) -> str: ...
        def __str__(self) -> str: ...
        @classmethod
        def from_file(cls, file: Union[str, pathlib.Path]) -> 'A': ...
        
        b: int
        
        def iter(self) -> Iterator[int]: ...
    '''
    P = Parser()
    P.parser(code)
    assert ''.join(P.doc.values()) == '''class A

*Full name:* `A`

Members

- Type

  + `b: int`

'''

# Generated at 2022-06-23 15:39:12.301754
# Unit test for function code
def test_code():
    from . import utils
    assert utils.code("|") == "&#124;"
    assert utils.code("&") == "<code>&amp;</code>"
    assert utils.code("") == " "
    assert utils.code("`") == "`"
    assert utils.code("a") == "`a`"


# Generated at 2022-06-23 15:39:24.730659
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    """Test for Parser.func_ann method."""
    root = "my_package"
    p = Parser()
    p.level[root] = 0
    p.root[root] = root
    p.alias['my_package.alias'] = 'alias'

# Generated at 2022-06-23 15:39:35.379027
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    class node:
        def __init__(self, value, slice, lineno, col_offset):
            self.value = value
            self.slice = slice
            self.lineno = lineno
            self.col_offset = col_offset

    class name:
        def __init__(self, id):
            self.id = id

    class list:
        def __init__(self, elts):
            self.elts = elts

    class constant:
        def __init__(self, value):
            self.value = value

    class binop:
        def __init__(self, left, op, right):
            self.left = left
            self.op = op
            self.right = right

    class load:
        pass

    class bitor:
        pass

    class none:
        pass

   

# Generated at 2022-06-23 15:39:44.853725
# Unit test for function const_type
def test_const_type():
    assert const_type(parse('1').body[0]) == 'int'
    assert const_type(parse('[1, 1]').body[0].value) == 'list[int]'
    assert const_type(parse('[1, 1.0]').body[0].value) == 'Any'
    assert const_type(parse('[1, None]').body[0].value) == 'Any'
    assert const_type(parse('[None]').body[0].value) == 'Any'
    assert const_type(parse('[1, [1, 1]]').body[0].value) == 'Any'
    assert const_type(parse('[]').body[0].value) == 'list'
    assert const_type(parse('[1, 2.0]').body[0].value) == 'list[float]'


# Generated at 2022-06-23 15:39:54.036021
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    import inspect
    from typing import Callable

    from typepy import RealNumber, Integer
    from typepy.type import AnyType

    import pytypeutils as tus

    def sub(x: int, y: RealNumber) -> Callable[[AnyType], bool]:
        return lambda z: x < z and z < x

    parser = Parser()
    parser.func_ann('', inspect.signature(sub).parameters.values(),
                    has_self=False, cls_method=False)

    assert parser.alias == {'x': 'int', 'y': 'RealNumber'}
    assert parser.alias == {'x': 'int', 'y': 'RealNumber'}
    assert parser.root == {'x': '', 'y': ''}
    assert parser.level == {'x': 0, 'y': 0}


# Generated at 2022-06-23 15:40:06.823834
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    module = inspect.getsource(doc)
    p.parse(module)
    assert p.doc['doc']
    assert p.docstring['doc.__init__']
    assert p.alias['doc.tag'] == 'tag'
    assert p.alias['doc.doctest'] == 'doctest'
    assert p.alias['doc.node.generic_visit'] == 'ast.generic_visit'
    assert p.alias['doc.node.Num'] == 'ast.Num'
    assert p.alias['doc.node.arguments'] == 'ast.arguments'
    assert p.alias['doc.node.Expr'] == 'ast.Expr'
    assert p.alias['doc.NodeVisitor'] == 'ast.NodeVisitor'