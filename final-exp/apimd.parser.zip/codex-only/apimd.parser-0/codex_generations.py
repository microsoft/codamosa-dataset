

# Generated at 2022-06-23 15:30:05.433360
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    import typing
    assert Resolver(__name__, {__name__: 'typing'}).visit(Constant('Union[int, float]')) == BinOp(
        Call(
            Name('Union', Load()),
            [Call(
                Name('typing.TypeVar', Load()),
                [Constant('T')],
                []
            )],
            []
        ),
        BitOr(),
        Name('typing.Tuple', Load()),
    )

# Generated at 2022-06-23 15:30:08.509779
# Unit test for method globals of class Parser
def test_Parser_globals():
    parser = Parser(False)
    logger.debug("Test globals")
    parser.globals("root", ast.parse("""
    x = 123
    y = 'abc'
    c = None
    X = 1
    """))
    parser.globals("root", ast.parse("""
    x = 1
    """))
    parser.globals("root", ast.parse("""
    a: int = 1
    """))
    assert parser.const == parser.alias == {}

# Generated at 2022-06-23 15:30:10.713771
# Unit test for constructor of class Resolver
def test_Resolver():
    """Test initializer of class Resolver."""
    assert Resolver('typing', {}).root == 'typing'


# Generated at 2022-06-23 15:30:20.332950
# Unit test for method globals of class Parser
def test_Parser_globals():
    p = Parser()
    p.globals("", AST("from a import b, c as d"))
    assert p.alias == {"b": "a.b", "d": "a.c"}
    p.globals("", AST("from .a import b, c as d"))
    assert p.alias == {"b": "a.b", "d": "a.c"}
    p.globals("", AST("from ..a import b"))
    assert p.alias.pop("b") == "a.b"
    p.globals("a.b", AST("from ..a import b, c as d"))
    assert p.alias == {"b": "a.b", "d": "a.c"}

# Generated at 2022-06-23 15:30:21.482760
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    # Test whether type of returned value is correct
    assert isinstance(Parser().__post_init__(), None)

# Generated at 2022-06-23 15:30:30.540002
# Unit test for method api of class Parser
def test_Parser_api():
    import sys; sys.path.append('..')
    from tolkien import Module
    parser = Parser(import_map['os'], True)
    parser.run(parser.load(module=Module.from_path('../tolkien/module.py')))

# Generated at 2022-06-23 15:30:35.219802
# Unit test for function is_magic
def test_is_magic():
    """Unit test for function is_magic"""
    assert is_magic('__magic__')
    assert is_magic('__magic__.__magic__')
    assert not is_magic('AAA.__magic__')
    assert not is_magic('AAA')



# Generated at 2022-06-23 15:30:38.937928
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser({}).__doc__ == '''\
Generate documentation from module object.

- **mod**: Module object to generate documentation.
- **link**: Whether add link to the head of documentation.
- **toc**: Whether add table of contents.
'''


# Generated at 2022-06-23 15:30:48.996757
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    exp = """Table
==========
+--------+--------+
| Arg    | Type   |
+--------+--------+
| Self   | int    |
+--------+--------+
| arg1   | str    |
+--------+--------+
| arg2   | str    |
+--------+--------+
| arg3   | \*args |
+--------+--------+
| arg4   | \*\*kw |
+--------+--------+
| return | None   |
+--------+--------+"""
    p = Parser(False, None)
    p.alias['test.test'] = 'test.test'
    p.alias['test.arg1'] = 'int'
    p.alias['test.arg2'] = 'str'
    p.alias['test.arg3'] = 'tuple'

# Generated at 2022-06-23 15:30:50.870962
# Unit test for function is_magic
def test_is_magic():
    assert not is_magic('foo')
    assert is_magic('__foo__')
    assert not is_magic('.__foo__')



# Generated at 2022-06-23 15:30:58.278346
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    # python -m doctest -v [file ...]
    import typing
    from .api_data import DataStore
    from .api_doc import TypeContext
    from .pyslvs_ui.components.solver.constrained import ConstraintRule
    from .pyslvs_ui.widgets import GraphWidget
    r = Resolver(GraphWidget.__module__, TypeContext(DataStore(ConstraintRule)).alias)
    ex = parse('a.b.c.d').body[0]
    assert unparse(r.visit(ex)) == 'graph.b.c.d'
    ex = parse('pyslvs_ui.widgets.GraphWidget.SaveMethod').body[0]
    assert unparse(r.visit(ex)) == 'graph.SaveMethod'

# Generated at 2022-06-23 15:30:59.295177
# Unit test for function table
def test_table():
    table('a', 'b', [['c', 'd'], ['e', 'f']])



# Generated at 2022-06-23 15:31:10.785232
# Unit test for constructor of class Resolver
def test_Resolver():
    try:
        import pyslvs
    except ImportError:
        logger.error("test_Resolver is disabled...")
        return
    # Set up
    r = Resolver('pyslvs', {'pyslvs.api.str': "'s'",
                            'pyslvs.qtpy.Dpi': '96'})
    node = r.visit(parse("from pyslvs import api; api.str").body[0].value)
    assert unparse(node) == "'s'"
    node = r.visit(parse("from pyslvs import QtWidgets; QtWidgets.QWidget")
                      .body[0].value)
    assert unparse(node) == "QWidget"

# Generated at 2022-06-23 15:31:14.006659
# Unit test for function table
def test_table():
    """Unit test for function `table`."""
    return table('a', 'b', [['c', 'd'], ['e', 'f']])



# Generated at 2022-06-23 15:31:23.471963
# Unit test for method api of class Parser
def test_Parser_api():
    import doctest
    import ast
    p = Parser(False)
    root = 'a'
    node = ast.parse('''
        def f(a: int, b: str, c: list, d=1) -> typing.Optional[int]: ...
        class A(B, C): ...
    ''', type_comments=True).body
    p.api(root, node[0])
    p.api(root, node[1])
    assert p.doc[root + '.f'] == '## f()\n\n' \
        '*Full name:* `a.f`\n\n' \
        '**args** | **type**\n' \
        ':--:     | :--:\n' \
        'a        | int\n' \
        'b        | str\n'

# Generated at 2022-06-23 15:31:25.047682
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    obj = Parser()
    result = obj.__eq__('a')
    print(result)

# Generated at 2022-06-23 15:31:35.355579
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    assert list(p.func_ann('root', [arg('a', None)], has_self=False,
                           cls_method=False)) == ['Any']
    assert list(p.func_ann('a', [arg('a', None)], has_self=False,
                           cls_method=False)) == ['Any']
    assert list(p.func_ann('root', [arg('a', Name('B', Load()))],
                           has_self=False, cls_method=False)) == ['B']
    assert list(p.func_ann('a', [arg('a', Name('B', Load()))],
                           has_self=False, cls_method=False)) == ['root.B']

# Generated at 2022-06-23 15:31:39.252004
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    assert Parser() == Parser()
    assert Parser() == Parser(**{})
    assert not (Parser(link=False) == Parser(link=True))
    assert not (Parser(toc=False) == Parser(toc=True))
    assert not (Parser(levels=False) == Parser(levels=True))
    assert not (Parser(b_level=3) == Parser(b_level=4))


# Generated at 2022-06-23 15:31:46.922104
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('os.path.isfile') is True
    assert is_public_family('os._isdir') is False
    assert is_public_family('_os.path.isfile') is False
    assert is_public_family('os.__isfile__') is True
    assert is_public_family('__os.path.isfile__') is True
    assert is_public_family('_os.__isfile__') is False



# Generated at 2022-06-23 15:31:56.828221
# Unit test for method compile of class Parser
def test_Parser_compile():
    from . import config
    from . import struct
    from . import utils
    from . import ui
    from . import autodoc
    from doc_test_check import DocTestChecker

    logger = utils.logger
    class _bool(bool):
        pass

    _log_level = utils.log_level
    utils.log_level = logger.WARNING
    _dir = "doc_test_check"

# Generated at 2022-06-23 15:32:01.433020
# Unit test for method imports of class Parser
def test_Parser_imports():
    import io
    import logging
    import os
    import random
    import sys
    import tempfile
    from unittest import TestCase

    from _pytest.logging import caplog
    from jinja2 import Environment, FileSystemLoader
    from astunparse import unparse

    from typed_astunparse import unparse as tunp
    from typed_astunparse.unparse import NoAlias

    from docany import Parser, logger, ANY

    from .mocks import build_mock_module

    # set up logger
    logger.setLevel(10)
    logger.propagate = False
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(10)
    logger.addHandler(handler)


# Generated at 2022-06-23 15:32:08.981588
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from inspect import getmodule
    from pathlib import Path
    from .builder import Builder

    class C:
        """Class C"""

        def __init__(self, x) -> None:
            """init doc"""

    def f(x, y) -> int:
        """function f doc"""

    builder = Builder({BUILD: {'root': '.', 'src': ['.'],
                               'out': 'build'}})
    with builder:
        p = Parser(builder._config[BUILD]['root'], builder.root,
                   builder.out, builder.link)
        p.load_docstring('test', getmodule(C))
        p.load_docstring('test', getmodule(f))
    assert p.docstring['test.C'] == doctest(C.__doc__)

# Generated at 2022-06-23 15:32:14.162798
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert unparse(Resolver('', {}).visit(Subscript(Name('Union', Load),
                                                   Tuple(elts=[Name('a', Load),
                                                               Name('b', Load)],
                                                         ctx=Load()),
                                                   Load()))).strip() == 'a | b'

# Generated at 2022-06-23 15:32:17.285305
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__init__')
    assert is_magic('__foo__')
    assert not is_magic('__foo')
    assert not is_magic('foo__')
    assert not is_magic('foo')



# Generated at 2022-06-23 15:32:20.568535
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    node = parse('Call').body[0].value
    node = Resolver('', {}).visit(node)
    assert code(unparse(node)) == '`Call`'


# Generated at 2022-06-23 15:32:21.812897
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    p1 = Parser()
    p2 = Parser()
    assert p1 == p2


# Generated at 2022-06-23 15:32:31.284516
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    def assert_docstring(d: str, module: ModuleType):
        return (d == Parser(False).load_docstring('module', module).strip())
    assert assert_docstring('', Module(arguments([], None, None, [], [], None, []),
                                       [Expr(Str(''))]))
    assert assert_docstring('', types.ModuleType('module'))
    class C:
        """A class docstring."""
    assert assert_docstring('A class docstring.', types.ModuleType(C))
    assert assert_docstring('A class docstring.', Module(arguments([], None,
                                                        None, [], [], None, []),
                                                        [ClassDef('C', [], [],
                                                                  [], [], None)]))
    assert assert_docstring

# Generated at 2022-06-23 15:32:41.660529
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    parser = Parser(False)

    class M:
        def method(self, arg1, arg2='default') -> "str":
            ...

    func = get_code(M.method).body[0]

    parser.func_api("M", "M.method", func.args, func.returns, has_self=True, cls_method=False)
    parser.compile()


# Generated at 2022-06-23 15:32:48.964323
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    @dataclass
    class _D:
        x: int = field(metadata={'type_hint': 'typing.int'})
    m = cast(ModuleType, type(_D).__module__)
    alias = m.__dict__
    alias.update({m.__name__: m.__name__, 'typing.List': 'list'})
    assert Resolver(m.__name__, alias).visit_Attribute(parse('List[str]')).body[0] == parse('list[str]').body[0]
    assert Resolver(m.__name__, alias).visit_Attribute(parse('List[D]')).body[0] == parse('list[D]').body[0]



# Generated at 2022-06-23 15:32:54.279248
# Unit test for method api of class Parser
def test_Parser_api():
    import unittest
    class Parser_apiTest(unittest.TestCase):
        def test(self):
            parser = Parser(None)
            parser.api("",
                       FunctionDef(name="f",
                                   args=arguments(args=[arg("x", Num(1))],
                                                  returns=Num(2)),
                                   body=[Node()]),
                       prefix="")
            parser.api("",
                       FunctionDef(name="f",
                                   args=arguments(args=[arg("x", None)],
                                                  returns=None),
                                   body=[Node()]),
                       prefix="")

# Generated at 2022-06-23 15:32:58.710892
# Unit test for function is_public_family
def test_is_public_family():
    """Unit test for function is_public_family."""
    import abc
    assert is_public_family(str(abc.ABCMeta))
    assert not is_public_family('abc.__XXX__')
    assert not is_public_family('abc._ABCMeta')



# Generated at 2022-06-23 15:33:07.164335
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    parser = Parser()
    parser.class_api("a.b.c.d", "a.b.c.d.A", [], [])
    assert parser.doc["a.b.c.d.A"] == """# class A

*Full name:* `a.b.c.d.A`

+ [Enums](#enums)
+ [Members](#members)

## Enums

| Enums |
| --- |

## Members

| Members | Type |
| --- | --- |
"""
    parser.class_api("a.b.c.d", "a.b.c.d.A", [], [None, None])

# Generated at 2022-06-23 15:33:17.754642
# Unit test for function const_type
def test_const_type():
    check_const_type('1', 'int')
    check_const_type('True', 'bool')
    check_const_type('1.1', 'float')
    check_const_type('"s"', 'str')
    check_const_type('"str"', 'str')
    check_const_type('[1, 2, 3]', 'list[int]')
    check_const_type('(1, 2, 3)', 'tuple[int]')
    check_const_type('{"a": 1, "b": 2, "c": 3}', 'dict[str, int]')
    check_const_type("{1, 10, 100}", 'set[int]')
    check_const_type("(1, 1.1, 1+1j)", 'tuple[Any]')
    check

# Generated at 2022-06-23 15:33:28.948537
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    def func(a: int, b: int, c: int) -> int:
        return a
    root = 'root'
    p = Parser()
    p.alias = {
        'root.a': 'int',
        'root.b': 'int',
        'root.c': 'int',
        'root.func': 'int',
    }
    assert [str(a) for a in p.func_ann(root, func.__annotations__)] == [
        'type[a]', 'type[b]', 'type[c]', 'func']
    p.alias.pop('root.c')
    assert [str(a) for a in p.func_ann(root, func.__annotations__)] == [
        'type[a]', 'type[b]', '', 'func']
   

# Generated at 2022-06-23 15:33:33.819055
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    """Test method Parser.__repr__."""
    p = Parser(link=True)
    assert p.__repr__() == '<Parser link: True>'
    p.init_b_level(3)
    assert p.__repr__() == '<Parser link: True, TOC: 3>'

# Generated at 2022-06-23 15:33:44.127919
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser(None, None)
    assert p.func_ann('.', [arg('a', Name(id="int", ctx=Load()))]) == ['int']
    assert list(p.func_ann('.', [
        arg('a', Name(id="str", ctx=Load())),
        arg('b', Name(id="List", ctx=Load())),
        arg('c', Tuple(
            elts=[Name(id="int", ctx=Load()), Name(id="str", ctx=Load())],
            ctx=Load()))])) == [
        'str',
        'List[Unknown]',
        'Tuple[int, str]']

# Generated at 2022-06-23 15:33:50.864157
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('_local') is False
    assert is_public_family('') is True
    assert is_public_family('a') is True
    assert is_public_family('a.b') is True
    assert is_public_family('a._b') is False
    assert is_public_family('a.b.c') is True
    assert is_public_family('a.b._c') is False
    assert is_public_family('_a') is False
    assert is_public_family('__a') is True
    assert is_public_family('__a__') is True
    assert is_public_family('__a.__b') is True
    assert is_public_family('a.__b') is True
    assert is_public_family('a.b.__c') is True
   

# Generated at 2022-06-23 15:34:00.801742
# Unit test for method compile of class Parser
def test_Parser_compile():
    from bs4 import BeautifulSoup as bs
    from ast import Module


# Generated at 2022-06-23 15:34:09.423171
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    p1 = Parser("", "", False)
    p2 = Parser("", "", False)
    p3 = Parser("", "", True)
    p4 = Parser("", "a", False)
    p5 = Parser("a", "", False)
    p6 = Parser("a", "b", False)
    p7 = Parser("", "", False, 1)
    assert p1 == p2
    assert not (p1 == p3)
    assert not (p1 == p4)
    assert not (p1 == p5)
    assert not (p1 == p6)
    assert not (p1 == p7)



# Generated at 2022-06-23 15:34:12.805881
# Unit test for function walk_body
def test_walk_body():
    program = parse(
        """
        if a:
            b
        elif c:
            d
        else:
            e
        f
        try:
            g
        except h:
            i
        except:
            j
        else:
            k
        finally:
            l
        """
    )
    assert list(walk_body(program.body)) == [
        b, c, d, e, f, g, h, i, j, k, l,
    ]



# Generated at 2022-06-23 15:34:21.983809
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    from ast import parse, Expr, Name
    n = parse('"abc"', '<string>', 'eval').body
    assert n == [Expr(Constant('abc'))]
    resolver = Resolver('', {})
    n = resolver.visit(n[0])
    assert n == Expr(Constant('abc'))
    n = parse('"abc.def"', '<string>', 'eval').body
    assert n == [Expr(Constant('abc.def'))]
    resolver = Resolver('', {})
    n = resolver.visit(n[0])
    assert isinstance(n, Expr)
    assert isinstance(n.value, Attribute)
    assert isinstance(n.value.value, Name)

# Generated at 2022-06-23 15:34:29.406574
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    import os, sys
    sys.path.append(os.path.dirname(__file__))
    from slvs.datastructs import Resolver
    r = Resolver('slvs.datastructs', {'slvs.datastructs.Resolver': 'Resolver',
                                      'typing.Union': 'Union[int, float, str]'})
    assert unparse(r.visit(parse('Union[Resolver, Union[int, float], str]').body[0])) == 'Union[Resolver, Union[int, float], str]'


# Generated at 2022-06-23 15:34:32.096928
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__init__')
    assert not is_magic('__init_')
    assert not is_magic('_init_')



# Generated at 2022-06-23 15:34:38.592639
# Unit test for constructor of class Parser
def test_Parser():
    # open python3 file
    with open('python_file/test.py','r',encoding='utf-8') as f:
        code1 = f.read()
    # extract ast tree
    tree = ast.parse(code1)
    # class instance defined
    p = Parser(code1)
    # return a docstring dictionary {'full_name': 'docstring'}
    docs = p.compile()
    # return a markdown document
    doc_str = p.compile_markdown()
    # print
    print(doc_str)


# Generated at 2022-06-23 15:34:47.814473
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    """Test for method Parser.__eq__."""

    def parse(source):
        p = Parser()
        p.parse(source)
        return p

    assert parse('\n') == parse('\n')

    assert parse('\n') != parse('\n\n')

    assert parse('\n') != parse('\n\n')

    assert parse('\n') != parse('\n\n')

    assert parse('1\n') != parse('2\n')

    assert parse('1\n') != parse('2\n')

    assert parse('1+1\n') != parse('2+2\n')

    assert parse('def a(): ...\n') != parse('def a(): ...\n')



# Generated at 2022-06-23 15:34:53.691554
# Unit test for method compile of class Parser
def test_Parser_compile():
    from . import type_defs

    p = Parser()
    p.module('foo', type_defs)
    p.load_docstring('foo.type_defs', type_defs)

# Generated at 2022-06-23 15:34:57.063284
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore('a_b_c') == r'a\_b\_c'
    assert esc_underscore('_') == r'\_'
    assert esc_underscore('ab_c') == 'ab_c'
    assert esc_underscore('_cd') == r'\_cd'



# Generated at 2022-06-23 15:35:02.993218
# Unit test for method class_api of class Parser

# Generated at 2022-06-23 15:35:08.121709
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    import itertools
    import random
    import string
    from collections import defaultdict
    from pytest import mark
    from . import import_module
    parser = Parser(None, True, True)
    _imports = {}
    _module = defaultdict(list)
    _all = defaultdict(list)
    for i in itertools.count(1):
        _module[f'm{i}'].append(f'{i}')
        if random.randint(0, 1):
            _module[f'm{i}'].append(f'e{i}')
        if random.randint(0, 1):
            _all[f'm{i}'].append(f'{i}')

# Generated at 2022-06-23 15:35:14.388077
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    """Test the method `__repr__` of the class `Parser`."""
    link = True
    b_level = 1
    pars = Parser(link, b_level) # Create a instance of class Parser
    assert repr(pars) == "Parser(link=True, b_level=1)" # Test method __repr__


# Generated at 2022-06-23 15:35:25.336870
# Unit test for method globals of class Parser
def test_Parser_globals():

    # Visible on Python code
    class Mock_Parser(Parser):

        def __init__(self, root: str, level: int):
            self.root = root
            self.level = level
            self.alias = {}
            self.doc = {}
            self.imp = {}
            self.root = {}
            self.docstring = {}
            self.const = {}
            self.level = {}
            self.link = False
            self.b_level = 0

        def globals(self, root: str, node: Stmt) -> None:
            self._globals(root, node)

    parser = Mock_Parser('name', 0)

    with pytest.raises(ValueError):
        parser.globals('name', FunctionDef(
            name='test'))

# Generated at 2022-06-23 15:35:37.133278
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert unparse(Resolver("a.b", {}).visit_Subscript(Subscript(Name("a", Load()), Tuple(elts=[arg(arg="a"), arg(arg="b")], ctx=Load()), Load()))) == "a[a, b]"
    assert unparse(Resolver("a.b", {}).visit_Subscript(Subscript(Name("a", Load()), arg(arg="a"), Load()))) == "a.a"
    assert unparse(Resolver("a.b", {}).visit_Subscript(Subscript(Name("a", Load()), Tuple(elts=[Constant(value=1), Constant(value=2)], ctx=Load()), Load()))) == "a[1, 2]"

# Generated at 2022-06-23 15:35:49.068982
# Unit test for constructor of class Parser
def test_Parser():
    """Test for constructor of class Parser."""
    with open("tests/example/t.py", "r", encoding="utf8") as f:
        m = compile(f.read(), "tests/example/t.py", 'exec', dont_inherit=True)
    p = Parser(start_level=1, link=True)
    p.parse(m)

# Generated at 2022-06-23 15:35:51.387763
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    """Test method `__repr__`."""
    assert repr(Parser([])) == 'Parser([])'

# Generated at 2022-06-23 15:35:56.954836
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    p = Parser('')
    p.doc = {'module.Class': ''}
    p.root = {'module.Class': 'module'}
    p.alias = {'module.Class': 'module.Class'}
    p.level = {'module.Class': 1}
    arg = argparser(1, 'bases', [])
    p.class_api('module', 'module.Class', arg, [])
    assert p.doc['module.Class'] == '+ Bases\n\n'

    p.doc = {'module.Class': ''}
    p.root = {'module.Class': 'module'}
    p.alias = {'module.Class': 'module.Class'}
    p.level = {'module.Class': 1}

# Generated at 2022-06-23 15:36:09.626037
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    def _(node, ty):
        return const_type(Resolver('', {}).visit(node)) == ty
    assert _(Constant('str'), 'str')
    assert _(Constant('bool'), 'bool')
    assert _(Constant('int'), 'int')
    assert _(Constant('float'), 'float')
    assert _(Constant('complex'), 'complex')
    assert _(Constant(str), str)
    assert _(Constant(bool), 'bool')
    assert _(Constant(int), 'int')
    assert _(Constant(float), 'float')
    assert _(Constant(complex), 'complex')
    assert _(Constant(None), 'NoneType')
    assert _(Constant(1), 'int')
    assert _(Constant(1.1), 'float')

# Generated at 2022-06-23 15:36:17.571001
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    a = Assign(targets=[Name("a", Store())],
               value=Name("NoAnnotation", Load()))
    r = Resolver("__main__", {"__main__": "__main__"})
    assert parse("NoAnnotation").body[0] == r.visit(a).value
a = Assign(targets=[Name("a", Store())], value=Call(func=Name("int", Load()), args=[Constant('1', kind=None)], keywords=[]))
r = Resolver("__main__", {"__main__": "__main__"})
assert parse("int(1)").body[0] == r.visit(a).value

# Generated at 2022-06-23 15:36:28.757109
# Unit test for method parse of class Parser
def test_Parser_parse():
    arguments = [] # type: List[arg]
    parse(arguments, ((True, 'arg1: int', None), (False, 'arg2: int', None)))
    assert arguments == [arg('arg1', 'int'), arg('arg2', 'int')]
    arguments = [] # type: List[arg]
    parse(arguments, ((True, 'arg1: typing.List[int]', None), (False, 'arg2: int', None)))
    assert arguments == [arg('arg1', 'typing.List[int]'), arg('arg2', 'int')]
    arguments = [] # type: List[arg]
    parse(arguments, ((True, 'arg1: typing.List[int]', None), (True, None, None), (False, 'arg2: int', None)))

# Generated at 2022-06-23 15:36:36.393308
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from types import ModuleType

    from astroid import parse
    from astroid.builder import AstroidBuilder
    builder = AstroidBuilder()
    node = builder.string_build("""
    def func():
        \"\"\"This is func docstring.\"\"\"
        pass
    """)
    module: ModuleType = ModuleType("module")
    _getattr(module, "func")
    p = Parser()
    p.load_docstring(node.root, module)
    assert p.docstring[_m(node.root, "func")] == "This is func docstring.\n"

# Generated at 2022-06-23 15:36:41.577905
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    doc = Parser()
    assert doc.root == {'': ''}

    doc = Parser(link=True)
    assert doc.link

    doc = Parser(toc=True)
    assert doc.toc


# Generated at 2022-06-23 15:36:48.247085
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("foo_bar") == "foo\\_bar"
    assert esc_underscore("foo bar") == "foo bar"
    assert esc_underscore("foo__bar") == "foo__bar"
    assert esc_underscore("foo bar") == "foo bar"
    assert esc_underscore("foo_______bar") == "foo\\_\\_\\_\\_\\_\\_\\_bar"
    assert esc_underscore("foo") == "foo"



# Generated at 2022-06-23 15:36:53.134149
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    _r = Resolver("test", {"test.A": "A"})
    assert _r.visit(Constant("A", None)) == Name("A", Load())
    assert _r.visit(Constant("B", None)) == Constant("B", None)

# Generated at 2022-06-23 15:36:57.109097
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    import json
    import pytest
    import sys

    # check return value
    assert json.loads(repr(Parser(source=[{"path": __file__, "source": "import antigravity"}])))["path"] == __file__



# Generated at 2022-06-23 15:37:06.346263
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser(None)
    assert p.func_ann('m', [arg('a', None)], has_self=False,
                      cls_method=False) == ['a']
    assert p.func_ann('m', [arg('a', None)], has_self=True,
                      cls_method=False) == ['Self', 'a']
    assert p.func_ann('m', [arg('a', None)], has_self=True,
                      cls_method=True) == ['type[Self]', 'a']
    assert p.func_ann('m', [arg('*', None)], has_self=False,
                      cls_method=False) == [""]

# Generated at 2022-06-23 15:37:09.901313
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    parser = Parser()
    # @pytest.mark.parametrize('root,m', (
    root = 'm'
    m = None
    parser.load_docstring(root, m)



# Generated at 2022-06-23 15:37:16.585545
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser('', False, False)
    p.alias['r.h'] = 'r.o'
    p.alias['r.o.z'] = 'r.i'
    nodes = [arg('a', Name('t', Load())),
             arg('b', Name('h', Load())),
             arg('*c', Name('y', Load())),
             arg('d', Name('i', Load())),
             arg('e', Name('z', Load())),
             arg('**f', Name('q', Load())),
             arg('return', Name('r', Load()))]

# Generated at 2022-06-23 15:37:17.269207
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    pass

# Generated at 2022-06-23 15:37:27.245503
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    class _Parser(Parser):
        """Test class for Parser."""
        __slots__ = ()
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
    p1 = _Parser()
    p2 = _Parser()
    assert p1 == p2
    p3 = Parser()
    assert p1 == p3
    assert p3 == p1
    p1.alias['T'] = 'T'
    assert p1 != p2
    assert p1 != p3
    assert p2 != p3
    p1 = _Parser(link=True)
    p2 = _Parser(link=True)
    assert p1 == p2
    p1.alias['T'] = 'T'
    assert p1 != p2
    p

# Generated at 2022-06-23 15:37:35.927963
# Unit test for function walk_body
def test_walk_body():
    assert unparse(parse('def foo(a):\n    if a < 3:\n        pass\n    else: pass\n    try:\n        pass\n    except:\n        pass\n    else:\n        pass\n    finally:\n        pass\n')) == unparse(parse(unparse(ast2.walk_body(ast2.parse('def foo(a):\n    if a < 3:\n        pass\n    else: pass\n    try:\n        pass\n    except:\n        pass\n    else:\n        pass\n    finally:\n        pass\n').body[0].body))))


# Generated at 2022-06-23 15:37:42.185145
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    parser = Resolver("", dict())
    assert parser.visit(Constant("1")) == Constant("1")
    assert parser.visit(Constant("a")) == Constant("a")
    assert parser.visit(Constant("a.b")) == Constant("a.b")
    assert parser.visit(Constant("a.b.c")) == Constant("a.b.c")
    assert parser.visit(Constant("a.b.c.d")) == Constant("a.b.c.d")
    assert parser.visit(Constant("a[1]")) == Constant("a[1]")
    assert parser.visit(Constant("a[1].b")) == Constant("a[1].b")

# Generated at 2022-06-23 15:37:47.228771
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from doct import Parser
    from doct._parser.typing import ModuleType
    from doct._parser.ast import Module
    def test_case(docstring: str, m: ModuleType) -> str:
        parser = Parser()
        for c_doc in parser.doc.copy(), parser.docstring.copy():
            assert c_doc == {}
        parser.load_docstring('test', m)
        assert parser.docstring == {'test': docstring}
        return parser.compile()
    # Case 1
    m = Module([], [])
    m.__doc__ = None
    assert test_case('', m) == ''
    # Case 2
    m.__doc__ = '''
        Test module
        ===========

        Case 2
        ------
    '''

# Generated at 2022-06-23 15:37:51.239011
# Unit test for function code
def test_code():
    assert code('a|b') == '<code>a&#124;b</code>'
    assert code('a&b') == '<code>a&b</code>'
    assert code('a') == '`a`'
    assert code('') == ' '



# Generated at 2022-06-23 15:37:56.732601
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert code(unparse(Resolver('root', {}).visit(Attribute(Name('typing', Load()), 'Optional', Load())))) == 'Optional'
    assert code(unparse(Resolver('root', {}).visit(Attribute(Name('typing', Load()), 'Tuple', Load())))) == 'Tuple'


# Generated at 2022-06-23 15:38:08.550086
# Unit test for method globals of class Parser
def test_Parser_globals():
    from . import Parser
    instances = {}
    for obj in [Parser(root='', link=True, toc=True,
                       b_level=1)]:
        instances[id(obj)] = obj
        root = ""
        node = obj.node
        obj.globals(root, node)
    assert instances
    # test attribute alias
    assert instances[id(obj)].alias == {
        '': '',
        }
    # test attribute root
    assert instances[id(obj)].root == {
        '': '',
        }
    # test attribute const
    assert instances[id(obj)].const == {
        '': 'Type[Any]'
        }
    # test attribute imp
    assert instances[id(obj)].imp == {
        '': set(),
        }

# Generated at 2022-06-23 15:38:14.323255
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    T = TypeVar('T')
    def test_Parser___eq__():
        """Unit test for method __eq__ of class Parser"""
        a = Parser([T])
        b = Parser([T])
        assert not a == b
    return test_Parser___eq__


# Generated at 2022-06-23 15:38:23.472281
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    global P
    names = ['self', 'arg1', 'arg2', '*', 'kwarg1', 'kwarg2', '**', 'return']
    ann = P.func_ann('root', [arg(a, None) for a in names])
    assert list(ann) == ['Self', 'arg1', 'arg2', '', 'kwarg1', 'kwarg2', '', 'return']
    ann = P.func_ann('root', [arg(a, None) for a in names], has_self=False)
    assert list(ann) == ['', 'arg1', 'arg2', '', 'kwarg1', 'kwarg2', '', 'return']

# Generated at 2022-06-23 15:38:30.814694
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    from ast import parse
    from .pep585 import PEP585

    class_node = parse("class A: pass").body[0]
    # class_node.__class__.qualname = 'typing.A'
    assert class_node.__class__.__qualname__ == 'typing.ClassDef'
    assert Resolver._doctyped_class(class_node).__qualname__ == 'A'
    # class_node.__class__.qualname = 'A'
    assert class_node.__class__.__qualname__ == 'A'
    assert Resolver._doctyped_class(class_node).__qualname__ == 'A'

    class_node = parse("class typing: pass").body[0]
    # class_node.__class__.qualname = 'typing.typing

# Generated at 2022-06-23 15:38:32.769021
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    p=Parser('module.py')
    t=p.class_api('module.py', 'full_name', [], [])
    

# Generated at 2022-06-23 15:38:45.478339
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser()

# Generated at 2022-06-23 15:38:51.465734
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    from .dataclasses import Doc
    doc = Doc(root="pyslvs", alias={}, self_ty="")
    e = Resolver(doc.root, doc.alias, doc.self_ty).visit(parse("Foo").body[0])
    assert(unparse(e) == 'Foo\n')
    e = Resolver(doc.root, {"pyslvs.Foo": "Bar"}, doc.self_ty).visit(parse("Foo").body[0])
    assert(unparse(e) == 'Bar\n')



# Generated at 2022-06-23 15:38:52.529027
# Unit test for method visit_Subscript of class Resolver

# Generated at 2022-06-23 15:38:58.774335
# Unit test for function walk_body
def test_walk_body():  # pragma: no cover
    from ast import parse
    from textwrap import dedent
    body = parse(dedent("""
        if a == b:
            if b == c:
                print(a)
            else:
                print(b)
        else:
            if a == c:
                print(a)
    """))
    assert tuple(walk_body(body.body)) == (
        parse("if b == c: print(a)").body[0],
        parse("else: print(b)").body[0],
        parse("print(a)").body[0],
    )



# Generated at 2022-06-23 15:39:02.249502
# Unit test for constructor of class Resolver
def test_Resolver():
    """Test Resolver transformer."""
    assert code(unparse(Resolver('typing', {}, 'self')
                        .visit(parse('typing.Union[typing.Optional[self.a], self.b]')
                        .body[0].value))) == '[typing.Optional[self.a], self.b]'


_T = TypeVar('_T', bound='Module')



# Generated at 2022-06-23 15:39:04.075201
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    p1 = Parser()
    p2 = Parser()
    assert (p1 == p2)

# Generated at 2022-06-23 15:39:10.216329
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family("pyslvs_ui.__init__.QtWidgets")
    assert not is_public_family("pyslvs_ui._widgets.QtWidgets")
    assert is_public_family("QtWidgets")
    return True
test_is_public_family()



# Generated at 2022-06-23 15:39:14.577138
# Unit test for function code
def test_code():
    assert code("|") == "&#124;"
    assert code("&") == "<code>&</code>"
    assert code("aa") == "`aa`"
    assert code("") == " "


# Generated at 2022-06-23 15:39:25.441861
# Unit test for method imports of class Parser
def test_Parser_imports():
    from . import test_util as _
    from . import test_util as _m
    from mypy.types import Instance
    from types import ModuleType
    from typing import Type
    from importlib import import_module
    from .parse import *
    from .parse import _I, from_ast, _G
    from .parse import _ref
    from mypy.types import Type as _Type
    from typing import List, Tuple
    from typing_extensions import Literal
    assert type(Parser) == type
    assert isinstance(Parser, type)
    assert issubclass(Parser, object)
    assert Parser.imports.__annotations__ == {'root': str, 'node': '_I'}

# Generated at 2022-06-23 15:39:30.057838
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    assert Resolver('typing', {}).visit_Constant(Constant(3)).value == 3
    assert Resolver('typing', {}).visit_Constant(Constant('a')).id == 'a'


# Generated at 2022-06-23 15:39:35.084569
# Unit test for function parent
def test_parent():
    assert parent('a.b.c') == 'a.b'
    assert parent('a.b.c', level=2) == 'a'
    assert parent('a.b.c', level=3) == ''



# Generated at 2022-06-23 15:39:44.732257
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    import builtins
    p = Parser()
    f = FunctionDef(arguments([arg('x', None)], None, None, None), [], None,
                    None, None)
    p.func_api('builtins', 'builtins.func', f.args, f.returns, has_self=False, cls_method=False)
    assert p.doc['builtins.func'] == '# func()\n\n*Full name:* `builtins.func`\n\n' + \
                                     '```python\nx: Any\n```\n' + \
                                     '```python\nreturn: Any\n```'
    p.doc.clear()

# Generated at 2022-06-23 15:39:53.915098
# Unit test for constructor of class Resolver
def test_Resolver():
    from .typing import alias

    @dataclass
    class _Stub:
        a: str
        b: int


# Generated at 2022-06-23 15:39:57.842876
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    parser = Parser()
    parser.func_api('', '', parse_arguments('*a: int, x: int = 1, /, y=2'),
                    parse_expr('int'))


# Generated at 2022-06-23 15:40:06.892517
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    p = Parser()
    assert p.class_api('a', 'a.A', [], []) == '\n'
    assert p.class_api(
        'a', 'a.A', [parse_expr('b.B')],
        [parse_stmt('x: int')]) == '\n'.join([
            table('Bases', items=[code('b.B')]) + '\n',
            table('Members', 'Type', items=[
                (code('x'), code('int')),
            ]) + '\n',
        ])