

# Generated at 2022-06-23 15:30:03.420703
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    f = Parser(__file__)
    f.scan()
    print(f)

# Generated at 2022-06-23 15:30:14.090356
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    from .typing import get_annotations
    assert get_annotations(Resolver) == {'alias': dict[str, str],
                                         'self_ty': str,
                                         'root': str}
    alias = {
        'typing.Counter': 'dict',
        'typing.Dict': 'dict',
        'typing.List': 'list',
        'typing.Set': 'set',
        'typing.Tuple': 'tuple',
    }
    assert Resolver('', alias).visit(parse('typing.Dict[str,int]').body[0].value) == parse(
        'dict[str,int]'
    ).body[0].value

# Generated at 2022-06-23 15:30:22.790950
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    p.func_ann('Parsers', ('self', 'a: int', 'b', '*c: str', '**kwargs',
                           'return')) == ('Self', 'int', ANY, 'str', ANY, ANY)
    p.func_ann('Parsers', ('a: int', 'b', '*c: str', '**d'),
               has_self=False) == ('int', ANY, 'str', ANY)

if __name__ == "__main__":
    test_Parser_func_ann()
 

# Generated at 2022-06-23 15:30:26.174634
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__init__')
    assert is_magic('__call__')
    assert not is_magic('__main__')
    assert not is_magic('numpy.__init__')

# Generated at 2022-06-23 15:30:30.203756
# Unit test for method parse of class Parser
def test_Parser_parse():
    """test_Parser_parse"""
    with open('test/test_Parser_parse.py') as f:
        text = f.read()
    p = Parser(text)
    p.parse()
    assert p.alias['tuple'] == 'collections.namedtuple'
    assert p.alias['typing.Tuple'] == 'tuple'
    assert p.alias['typing.List'] == 'list'


# Generated at 2022-06-23 15:30:31.946706
# Unit test for method func_api of class Parser
def test_Parser_func_api():

    import doctest
    doctest.testmod()


# Generated at 2022-06-23 15:30:42.283338
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    import typing
    import builtins
    import importlib
    import ast
    import types
    root = get_git_root()
    os = importlib.import_module('os')
    path = importlib.import_module('pathlib')
    imp = os.path.join(root, '_data', 'import.txt')
    with open(imp) as file:
        imps = file.read().splitlines()
    pkg = importlib.import_module('dtest')
    p = Parser(root)
    for n in imps:
        if n.startswith('.'):
            continue
        path = os.path.join(get_site_packages(), *n.split('.'))

# Generated at 2022-06-23 15:30:50.464050
# Unit test for function walk_body
def test_walk_body():
    from textwrap import dedent
    from .simple_check import code
    from .compilation import ComparisonAST
    @dataclass(order=True, frozen=True)
    class SimpleCode(ComparisonAST):
        code: str

# Generated at 2022-06-23 15:30:57.931022
# Unit test for function walk_body
def test_walk_body():
    def foo():
        a = 1
        if 1:
            b = 2
        else:
            b = 3
        try:
            c = 4
        except:
            c = 5
    funcBody = cast(FunctionDef, parse(getdoc(foo)).body[0])

# Generated at 2022-06-23 15:31:01.874103
# Unit test for function doctest
def test_doctest():
    a = """
This is a test.
    >>> import math
    >>> a = 'hello world'
    """
    b = doctest(a)
    assert b == """
This is a test.
    ```python
    >>> import math
    >>> a = 'hello world'
    ```
    """
    c = """This is another test."""
    d = doctest(c)
    assert d == c



# Generated at 2022-06-23 15:31:14.102285
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    from .parser import Parser
    # Test for `x == x` and `x == y`
    x = Parser(b_level=0, link=True, toc=True)
    assert (x == x)
    y = Parser(b_level=0, link=True, toc=True)
    assert (x == y)
    # Test for `x != y`
    z = Parser(b_level=0, link=True, toc=False)
    assert (x != z)
    # Test for `x != y`
    z = Parser(b_level=1, link=True, toc=True)
    assert (x != z)
    # Test for `x != y`
    z = Parser(b_level=0, link=False, toc=True)

# Generated at 2022-06-23 15:31:23.529566
# Unit test for method api of class Parser
def test_Parser_api():
    n = 'm.f'
    pth = Path('/m.py')
    import types
    m = types.ModuleType('m')
    f = FunctionDef(name='f', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[]))
    p = Parser()
    p.api(n, f)
    assert p.doc[n] == '## f()\n\n*Full name:* `m.f`\n\n**Arguments:**\n\n|Argument|Type|\n|-|-|\n|/|None|\n|*|None|\n|**|None|\n|return|None|\n\n'

# Generated at 2022-06-23 15:31:34.171532
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    """Unit test for method is_public of class Parser."""
    def init(name: str, v: Union[str, set[str]],
             const: Dict[str, str] = None) -> Parser:
        """Initial set up."""
        p = Parser()
        p.doc[name] = ''
        p.root[name] = name
        p.level[name] = name.count('.')
        if isinstance(v, str):
            p.imp[name] = {v}
        else:
            p.imp[name] = v
        if const is not None:
            p.const = const
        return p
    check_equal(init('A', 'B.C').is_public('A'), True)

# Generated at 2022-06-23 15:31:41.335018
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    def check(text : str, doc : str) -> str:
        return text + '\n' + doc
    @dataclass
    class A():
        def f(self: 'A') -> int:
            pass
    assert check('def f(self: A) -> int:', getdoc(A.f)) == 'def f(self: A) -> int:\nReturn type: int'
test_Resolver_visit_Name()

# Generated at 2022-06-23 15:31:50.937269
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    # Test for Parser.is_public(str)
    def test(a: str, b: bool, *,
             i: Optional[list[str]] = None,
             d: Optional[dict[str, str]] = None,
             c: Optional[dict[str, str]] = None,
             l: Optional[int] = None):
        m = ModuleType('__main__')
        p = Parser()
        if i is not None:
            p.imp['__main__'] = set(i)
        if d is not None:
            p.doc = d
        if c is not None:
            p.const = c
        if l is not None:
            p.level['__main__'] = l
        assert p.is_public(a) == b

# Generated at 2022-06-23 15:31:54.089034
# Unit test for method globals of class Parser
def test_Parser_globals():
    p = Parser(link=False)
    m = ast.parse('a = 1\nb = 2')
    p.globals('', m)
    assert p.alias == {'a': '1', 'b': '2'}


# Generated at 2022-06-23 15:31:56.650272
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("abc_abc") == "abc_abc"
    assert esc_underscore("abc__abc") == r"abc\_\_abc"



# Generated at 2022-06-23 15:32:00.473733
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    err = [
        "[{__eq__.__dict__}] expected but got [{getstate.__dict__}].",
        "[{__eq__.__module__}] expected but got [{getstate.__module__}].",
        "[{__eq__.__name__}] expected but got [{getstate.__name__}].",
        "[{__eq__.__qualname__}] expected but got [{getstate.__qualname__}].",
    ]
    exp = Parser.__eq__
    res = Parser.getstate.__eq__
    assert_equal(exp, res, err)

# Generated at 2022-06-23 15:32:08.098230
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    alias = {
        'test.Test': 'int',
        'test.test': 'float',
        'test.test2': 'str'
    }
    # If the name is in alias and name not in alias[name]
    assert isinstance(Resolver("test", alias).visit(parse("Test").body[0]), Constant)
    assert isinstance(Resolver("test", alias).visit(parse("test").body[0]), Constant)
    assert isinstance(Resolver("test", alias).visit(parse("test2").body[0]), Constant)
    assert isinstance(Resolver("test", alias).visit(parse("int").body[0]), Constant)
    assert isinstance(Resolver("test", alias).visit(parse("float").body[0]), Constant)

# Generated at 2022-06-23 15:32:13.282868
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    parsed = parse('''def f(a: str, b: int = 1) -> str:
    pass
''').body[0]
    class_node = Resolver("", {}).visit(parsed)
    assert class_node.lineno == 1
    assert class_node.col_offset == 0


# Generated at 2022-06-23 15:32:22.792487
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('module')
    assert not is_public_family('module.private')
    assert not is_public_family('module.private_')
    assert is_public_family('module.public')
    assert is_public_family('module.__private')
    assert is_public_family('module.public_')
    assert is_public_family('module.__private_')
    assert is_public_family('module.__all__')
    assert not is_public_family('module._all__')
    assert not is_public_family('module.__all')
    assert not is_public_family('module.all__')
    assert is_public_family('module.__all__.public')
    assert not is_public_family('module.__all__.private')
    assert not is_public_family

# Generated at 2022-06-23 15:32:29.781311
# Unit test for function doctest
def test_doctest():
    assert doctest(
        """\
>>> 1
1
>>> print(1)
1
>>> print('1' * 3)
111
>>> table = {
...     (1, 2): 3,
...     (2, 3): 4
... }"""
    ) == """\
```python
>>> 1
1
>>> print(1)
1
>>> print('1' * 3)
111
>>> table = {
...     (1, 2): 3,
...     (2, 3): 4
... }
```"""
test_doctest()



# Generated at 2022-06-23 15:32:33.866130
# Unit test for function is_magic
def test_is_magic():
    assert not is_magic("__name__")
    assert not is_magic("_private")
    assert is_magic("__private__")
    assert is_magic("__all__")
    assert not is_magic("__init__")
    assert not is_magic("__subclass__")



# Generated at 2022-06-23 15:32:41.660154
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    parser = Parser(link=None)
    for d in walk_top('./tests'):
        if d.name in ('__pycache__',):
            continue
        elif d.is_dir():
            parser.coverage(d.relative_to('./tests'))
        elif d.name.endswith('.py'):
            parser.load(d.relative_to('./tests'))

    parser.load_docstring('tests', tests)

    print(parser.compile())

test_Parser_load_docstring()

print('Test finished')


# Generated at 2022-06-23 15:32:46.752620
# Unit test for function is_public_family
def test_is_public_family():
    assert not is_public_family('_r')
    assert not is_public_family('._r')
    assert is_public_family('__a__')
    assert is_public_family('a._a__')
    assert is_public_family('a._a')
    assert not is_public_family('a._a._b')
    assert not is_public_family('__a.__b')



# Generated at 2022-06-23 15:32:57.430842
# Unit test for function doctest
def test_doctest():
    assert doctest("") == ""
    assert doctest(">>> hi\n>>> hi") == "```python\n>>> hi\n>>> hi\n```"
    assert doctest(">>> hi\n>>> hi\n\n>>> hi\n>>> hi") == "```python\n>>> hi\n>>> hi\n```\n\n```python\n>>> hi\n>>> hi\n```"
    assert doctest(">>> hi\n>>> hi\n\n>>> hi\n>>> hi\n\nHi") == "```python\n>>> hi\n>>> hi\n```\n\n```python\n>>> hi\n>>> hi\n```\n\nHi"



# Generated at 2022-06-23 15:32:58.123834
# Unit test for method api of class Parser
def test_Parser_api(): ...

# Generated at 2022-06-23 15:33:02.690388
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    """Unit test for method visit_Attribute of class Resolver"""
    root = ''
    alias = {}
    self_ty = ''
    obj = Resolver(root, alias)
    arg1 = Name(id='typing', ctx=Load())
    arg2 = 'attr'
    obj.visit_Attribute(Attribute(value=arg1, attr=arg2, ctx=Load()))



# Generated at 2022-06-23 15:33:05.546670
# Unit test for method compile of class Parser
def test_Parser_compile():
    f = io.StringIO()
    with redirect_stdout(f):
        with Parser() as p:
            p.parse(os.path.join(os.path.dirname(__file__), '../README.md'))
            assert p.compile() == ""
    assert f.getvalue().strip() == ""


# Generated at 2022-06-23 15:33:08.841518
# Unit test for constructor of class Parser
def test_Parser():
    argv = ['--link']
    p = Parser(argv)
    assert p.link == True
    assert p.toc == False


# Generated at 2022-06-23 15:33:18.946738
# Unit test for function walk_body
def test_walk_body():
    code_str = '''
if True:
    def f():
        pass
else:
    def f():
        pass
    try:
        pass
    except:
        pass
    else:
        pass
    finally:
        pass
'''
    code_obj = parse(code_str)
    code_body = cast(FunctionDef, code_obj.body[0]).body

# Generated at 2022-06-23 15:33:21.103173
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    # 
    pytest.skip()
    """`Parser.__post_init__()`"""


# Generated at 2022-06-23 15:33:27.745917
# Unit test for constructor of class Parser
def test_Parser():
    """Test Parser has the right attributes."""
    p = Parser()
    assert p.alias == dict()
    assert p.const == dict()
    assert p.level == dict()
    assert p.root == dict()
    assert p.doc == dict()
    assert p.imp == dict()
    assert p.docstring == dict()
    assert p.b_level == 0
    assert p.link == False
    assert p.toc == False


# Generated at 2022-06-23 15:33:35.571534
# Unit test for function doctest
def test_doctest():
    assert doctest('>>> a = 5') == '```python\n>>> a = 5\n```'
    assert doctest('>>> a = 5\n>>> b = 6') == '```python\n>>> a = 5\n>>> b = 6\n```'
    assert doctest('>>> a = 5\n>>> b = 6\n\nC') == '```python\n>>> a = 5\n>>> b = 6\n```\n\nC'
    assert doctest('>>> a = 5\n\nC') == '>>> a = 5\n\nC'



# Generated at 2022-06-23 15:33:42.684250
# Unit test for method parse of class Parser
def test_Parser_parse():
    from binder import source as source_from_py
    from binder import parse as parse_from_py
    from binder import source as source_from_code
    from binder import parse as parse_from_code
    def test_parse(parse, source_from):
        parse_from = parse
        src = source_from(__file__)
        assert parse_from(src)
    test_parse(parse_from_py, source_from_py)
    test_parse(parse_from_code, source_from_code)


# Generated at 2022-06-23 15:33:45.896884
# Unit test for function table
def test_table():
    """To test table()."""
    t = table('a', 'b', [['c', 'd'], ['e', 'f']])
    assert '| c | d |' in t
    assert '| e | f |' in t



# Generated at 2022-06-23 15:33:52.308658
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__init__')
    assert is_magic('__iter__')
    assert is_magic('__name__')
    assert not is_magic('__class__')
    assert not is_magic('__foo__')
    assert not is_magic('foo')
    assert not is_magic('foo.bar')
    assert not is_magic('foo.__bar__')
    assert not is_magic('__foo.bar__')



# Generated at 2022-06-23 15:33:57.504209
# Unit test for method compile of class Parser
def test_Parser_compile():
    p = Parser(["-L"], prog=prog, ver=ver, link=True)
    p.alias = {'a.b.c': 'k.l.m', 'k.l.m': 'a.b.c'}

# Generated at 2022-06-23 15:34:06.927117
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    source = """
    class Test:
        '''
        Test class.
        '''
        def func(self):
            '''
            Test function.
            '''
            pass
    """
    m = import_from_string("test", source)
    p = Parser()
    p.api("test", m)
    p.load_docstring("test", m)
    assert p.docstring["test"] == doctest("""
        Test class.
        """)[1:]
    assert p.docstring["test.func"] == doctest("""
        Test function.
        """)[1:]



# Generated at 2022-06-23 15:34:11.818089
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    import sys
    import pytest

    class _R(Resolver):
        def __init__(self):
            super(_R, self).__init__(sys.modules[__name__].__name__, {})

        def visit_Name(self, node):
            return "HI"
    t = _R()
    assert t.visit_Name(Name("test_Resolver_visit_Name", Load())).id == "HI"

# Generated at 2022-06-23 15:34:21.408305
# Unit test for function doctest
def test_doctest():
    doc = '''
    >>> print("Hello World")
    Hello World
    '''
    assert doctest(doc) == '''
    ```python
    >>> print("Hello World")
    ```
    Hello World
    '''
    doc = '''
    >>> print("Hello World")
    Hello World
    >>> print("Hello World")
    Hello World
    '''
    assert doctest(doc) == '''
    ```python
    >>> print("Hello World")
    >>> print("Hello World")
    ```
    Hello World
    Hello World
    '''
    doc = '''
    >>> print("Hello World")
    >>> print("Hello World")
    Hello World
    '''

# Generated at 2022-06-23 15:34:32.053959
# Unit test for method api of class Parser
def test_Parser_api():
    module_name='test_module'
    interp = Parser()
    m = Module([FunctionDef('f', arguments(
        [arg('a', Name('int', Load())),
         arg('b', Name('str', Load())),
         arg('c', None),
         arg('d', None)],
        None, [arg('e', None)],
        [arg('c', Name('int', Load())),
         arg('d', Name('str', Load()))],
        None, None),
        [Return(Num(1))], [], [], [])], [])
    interp.api(module_name, m.body[0])

# Generated at 2022-06-23 15:34:40.101770
# Unit test for constructor of class Resolver
def test_Resolver():
    """Test for the constructor of class ``Resolver``."""
    r = Resolver("", {})
    assert r.root == ""
    assert r.alias == {}
    assert r.self_ty == ""
    r = Resolver("test", {"typing.List": "list"})
    assert r.root == "test"
    assert r.alias == {"typing.List": "list"}
    assert r.self_ty == ""
    r = Resolver("test", {}, "self")
    assert r.root == "test"
    assert r.alias == {}
    assert r.self_ty == "self"



# Generated at 2022-06-23 15:34:49.738331
# Unit test for constructor of class Resolver
def test_Resolver():
    assert str(Resolver("foo", {}).visit(parse("str").body[0].value)) == "str"
    assert str(Resolver("foo", {"foo.bar": "int"}).visit(parse("bar").body[0].value)) == "int"
    assert str(Resolver("foo", {"foo.bar": "[int]"}).visit(parse("bar").body[0].value)) == "[int]"
    assert str(Resolver("foo", {"foo.bar": "baz"}).visit(parse("bar").body[0].value)) == "baz"
    assert str(Resolver("foo", {"foo.bar": "bar"}).visit(parse("bar").body[0].value)) == "bar"

# Generated at 2022-06-23 15:35:00.448351
# Unit test for constructor of class Resolver
def test_Resolver():
    """Unit test for AstWalker."""

# Generated at 2022-06-23 15:35:12.989776
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    assert list(p.func_ann({}, [arg('@staticmethod', Name('int'))])) == ['Any']
    assert list(p.func_ann({}, [arg('@staticmethod', Name('int'))],
                           has_self=True, cls_method=True)) == ['Self']
    assert list(p.func_ann({}, [arg('arg', Name('int'))])) == ['Any']
    assert list(p.func_ann({}, [arg('arg', Name('int'))],
                           has_self=True)) == ['Self', 'Any']
    assert list(p.func_ann({}, [arg('arg', Name('int'))],
                           has_self=True, cls_method=True)) == ['Self', 'Any']

# Generated at 2022-06-23 15:35:18.061001
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    p = Parser()
    p.load_docstring('t', _attr(t, 't'))
    assert p.docstring['t.a'] == 'f\n'
    p.load_docstring('t.b', _attr(t.b, 'b'))
    assert p.docstring['t.b.a'] == 'f\n'

# Generated at 2022-06-23 15:35:29.355480
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    from io import StringIO
    import sys
    import tokenize

    code = """
    __all__ = 'A'
    A = 1

    """
    with StringIO(code) as f:
        s = f.readline

        with tokenize.open(f.name) as f:
            g = tokenize.generate_tokens(s)
            tokens = []
            for tok in g:
                tokens.append(tok)
            assert Parser().__post_init__(f, tokens) == "1\n"

    code = """
    __all__ = 'A', 'B'
    A = 1
    B = [1, 2, 3,]

    """
    with StringIO(code) as f:
        s = f.readline


# Generated at 2022-06-23 15:35:40.562402
# Unit test for method globals of class Parser
def test_Parser_globals():
    import ast
    import typing
    p = Parser()
    with open('test.pyi', 'r') as f:
        tree = ast.parse(f.read())
    for node in walk_body(tree):
        p.globals('test', node)
    assert p.alias['__'].startswith(
        'typing.NoReturn.__init__')
    assert p.alias['A.b'] == 'A.b'
    assert p.alias['a'].startswith(
        'typing.Union.__getitem__')
    assert p.alias['b'].startswith(
        'typing.Optional.__getitem__')
    assert p.alias['c'].startswith(
        'typing.List.__getitem__')

# Generated at 2022-06-23 15:35:52.568680
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    parser = Parser({"a": 1}, {}, {}, {}, {}, {}, {}, {}, False, False, False, False)
    args = [
        arg(arg='a', annotation=None), 
        arg(arg='b', annotation=None), 
        arg(arg='c', annotation=None), 
        arg(arg='/', annotation=None), 
        arg(arg='d', annotation=None), 
        arg(arg='e', annotation=None)]

# Generated at 2022-06-23 15:36:04.763760
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    from vyper import ast as vy_ast
    from vyper import parser as vy_parser

    def parse(s: str) -> NodeVisitor[Any]:
        return vy_parser.parse_to_ast(f"@public\nclass Foo:\n{s}")

    def get_body(s: str) -> list[NodeVisitor[Any]]:
        return parse(s).body[0].body

    def get_members(s: str) -> dict[str, str]:
        n = parse(s).body[0]
        return Parser.class_api(Parser([]), '', n.bases, n.body)

    # class Foo(Enum, Enum):
    #     a: int128 = 1
    #     b: int128 = 2
    #     c: int128 = 3

# Generated at 2022-06-23 15:36:11.701892
# Unit test for function table
def test_table():
    """Test for table"""
    table_example = (
        "|a|b|c|\n"
        "|:---:|:---:|:---:|\n"
        "|d|e|f|\n"
        "|g|h|i|\n"
    )
    assert table('a', 'b', 'c', [['d', 'e', 'f'], ['g', 'h', 'i']]) == table_example



# Generated at 2022-06-23 15:36:22.946251
# Unit test for method api of class Parser
def test_Parser_api():
    from anytree import AnyNode
    from textwrap import dedent
    from pythonparser import parse_classdef
    from .parser import Parser

    p = Parser()
    p.alias['math.pi'] = 'pi'
    p.alias['math.tau'] = 'tau'
    p.alias['html.parser.HTMLParser'] = 'html.parser.HTMLParser'
    p.root['math.pi'] = 'math'
    p.root['math.tau'] = 'math'
    p.root['html.parser.HTMLParser'] = 'html.parser'
    p.level['math.pi'] = p.level['math.tau'] = p.level['math.tau'] = 1

# Generated at 2022-06-23 15:36:26.227765
# Unit test for function code
def test_code():
    assert code('|') == '&#124;'
    assert code('a') == '`a`'
    assert code('') == ' '
    assert code('a&b') == '<code>a&amp;b</code>'



# Generated at 2022-06-23 15:36:35.200663
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser(['test.py'])
    assert not p.is_public('test.unittest')
    p = Parser(['test.py'], ['test'])
    assert not p.is_public('test.unittest')
    p = Parser(['test.py'], ['test.unittest'])
    assert p.is_public('test.unittest')
    p = Parser(['test.py'], [])
    assert p.is_public('test.unittest')

if __name__ == "__main__":
    p = Parser(['test.py'])
    p.load()
    print(p.compile())

# Generated at 2022-06-23 15:36:48.473565
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    @dataclass
    class A:
        """
        >>> a = A(1)
        >>> a.b()
        2
        """
        a: int
        b: int = 2

        def __init__(self, a: int):
            self.a = a

        def b(self) -> int:
            """
            >>> a.b()
            2
            """
            return self.b

    import sys
    import io
    from docutils.core import publish_doctree
    from pyslvs.documents import gen_api_html, api_title

    if sys.version_info < (3, 8):
        return

    root = __name__

# Generated at 2022-06-23 15:36:53.183856
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__init__')
    assert not is_magic('__all__')
    assert is_magic('a.b.__init__')
    assert not is_magic('op')
test_is_magic()



# Generated at 2022-06-23 15:37:00.948523
# Unit test for constructor of class Parser
def test_Parser():
    from . import unittest, parser
    from types import ModuleType

    class TestCase(parser.TestCase, unittest.TestCase):
        def setUp(self):
            import sys
            sys.modules['docs.ast'] = ModuleType('docs.ast')
            self.parser = parser.Parser(level=4, toc=True)

        def tearDown(self):
            import sys
            del sys.modules['docs.ast']

        def test_Parser(self):
            from . import _xml

            @self.parser.parse
            class test(enum.Enum):
                """Test docstring"""
                a = 1
                b = 2
            self.assertEqual(self.parser.docstring.get('test'), """
    Test docstring

    """)

# Generated at 2022-06-23 15:37:10.913381
# Unit test for function walk_body
def test_walk_body():
    # pylint: disable=undefined-variable,unused-variable
    # Structs
    class Foo:
        def bar(self, x: int) -> None:
            if x:
                if x == 1:
                    pass
                else:
                    a, b = 1 + x ** 2, x ** 3
                    c = a + b
                    assert a == b, c
            else:
                try:
                    pass
                except ZeroDivisionError:
                    pass
                else:
                    try:
                        pass
                    except ValueError:
                        pass
                finally:
                    pass

    # Generate AST
    # Must clean node.col_offset
    ast_body = list(walk_body(get_def_body(get_def_node(Foo.bar, 'bar'))))

# Generated at 2022-06-23 15:37:13.936132
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__magic__')
    assert not is_magic('_class')
    assert not is_magic('_magic')
    assert not is_magic('magic')
    assert not is_magic('class')
    assert not is_magic('.')
    assert not is_magic('..')
    assert not is_magic('...')



# Generated at 2022-06-23 15:37:22.912693
# Unit test for method api of class Parser
def test_Parser_api():
    # Test for function api
    root = 'm'
    node = FunctionDef(
        name = 'func',
        args = arguments(
            args=[arg('x', Name(id='int'))],
            vararg = arg('args', None),
            kwonlyargs=[arg('z', Name(id='float'))],
            kwarg = arg('kwargs', None),
            defaults= [Name(id='None'),],
            kw_defaults = [Name(id='None')],
        ),
        decorator_list = [Name(id='staticmethod'),],
        returns = Name(id='float'),
    )
    parser = Parser(link=False)
    parser.api(root, node)

# Generated at 2022-06-23 15:37:34.901250
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from typing import Callable
    from textwrap import dedent
    from .ast_visitor import TypeResolver
    from .ast_visitor import Node
    from .ast_visitor import TypeTuple
    from .ast_visitor import TypeList
    from .ast_visitor import TypeName
    from .ast_visitor import TypeGeneric
    from ..compat import parse, ClassDef

    # Build a class
    m = parse(dedent('''
        class C:
            def foo(self, a: int, b=100) -> bool: pass
    ''')).body[0]
    assert isinstance(m, ClassDef)
    cls = m.body[0]
    assert isinstance(cls, FunctionDef)
    func = cls.body[0]
    assert isinstance(func, Return)

   

# Generated at 2022-06-23 15:37:46.672823
# Unit test for method api of class Parser
def test_Parser_api():
    from . import stub
    from ...dodgy import globals_, globals_update_
    from ...io import IO
    from ...typing import Any, Callable, Dict, List, Tuple
    from ...apex import apex_context, set_apex_context
    from .. import Docstring
    from . import _visit_funcs
    from .ast import (
        AnnAssign, arguments, ClassDef, Expr, FunctionDef, Import, Module, Name,
        Store, expr, stmt
    )
    globals_update_(FunctionDef=FunctionDef, ClassDef=ClassDef, arguments=arguments,
                    TypeComment=stub(args=[]))
    set_apex_context(apex_context.test)
    from .ast import TypeComment


# Generated at 2022-06-23 15:37:56.015481
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('__os__') is True
    assert is_public_family('__a__') is True
    assert is_public_family('__a_') is False
    assert is_public_family('a_') is False
    assert is_public_family('a__') is True
    assert is_public_family('_a') is False
    assert is_public_family('_a__') is False
    assert is_public_family('_a_') is False
    assert is_public_family('_a_._b') is False
    assert is_public_family('_a_.b') is False
    assert is_public_family('a_.b') is True
    assert is_public_family('a_._b') is True
    assert is_public_family('a_.__b') is False

# Generated at 2022-06-23 15:38:02.395121
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    alias = {}
    root = 'a.b'
    def t(name: str) -> str:
        return name if name.startswith('type[') else f'type<{name}>'
    p = Parser(alias, root, False, False)
    root = 'a.b'
    args = [
        arg('self', None),
        arg('a', None),
        arg('b', None),
        arg('c', None),
        arg('d', None),
        arg('*args', None),
        arg('e', None),
        arg('f', None),
        arg('**kwargs', None),
        arg('return', None)
    ]
    p.alias[root] = 'a.b'
    alias[root] = 'a.b'

# Generated at 2022-06-23 15:38:15.031033
# Unit test for method api of class Parser
def test_Parser_api():
    from .compiler import _compile as compile
    from .compiler import _exec as exec
    from .compiler import _exec_docstring as exec_docstring
    from .compiler import _get_docstring as get_docstring
    from .compiler import _unparse as unparse
    from .compiler import _walk_body as walk_body
    from .compiler import ANY
    from .compiler import is_public_family
    from .compiler import is_magic
    from .compiler import parent
    from .compiler import name
    from .compiler import doc
    from .compiler import parse
    from .compiler import unparse
    from .compiler import walk_body
    from .compiler import walk_body
    p = Parser(link=False, toc=False)

# Generated at 2022-06-23 15:38:25.237378
# Unit test for constructor of class Resolver
def test_Resolver():
    """Test `Resolver` class."""
    assert str(Resolver(
        ".", {}, ""
    ).visit(parse("'abc'").body[0].value.type)) == "{}".format(ANY)
    assert str(Resolver(
        ".", {"a": "b"}, "self"
    ).visit(parse("a").body[0].value.type)) == "{}".format("b")
    assert str(Resolver(
        "", {"a": "1"}, ""
    ).visit(parse("a").body[0].value.type)) == "{}".format("1")
    assert str(Resolver(
        ".", {"a": "b"}, "self"
    ).visit(parse("a").body[0].value.type)) == "{}".format("b")

# Generated at 2022-06-23 15:38:29.110110
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    import docpy.parser as parser
    parser.Parser(None, None, None, [])
    print('Test successful.')

if __name__ == '__main__':
    test_Parser_func_ann()

# Generated at 2022-06-23 15:38:41.415696
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    from .pep585 import PEP585
    from typing import Optional, Union, Callable, List, Tuple, Dict, TypeVar, Protocol
    # Test for PEP585
    for k, v in PEP585.items():
        print(k, v)
        assert Resolver('test', {}).visit_Subscript(
            Subscript(Name(k, Load), Tuple(elts=[Name('str', Load)], ctx=Load()), Load())
        ).id == v
    assert Resolver('test', {}).visit_Subscript(
        Subscript(Name('typing.Union', Load),
                  Tuple(elts=[Name('str', Load), Name('int', Load)], ctx=Load()), Load())
    ).left.id == 'str'
    assert Resolver('test', {}).visit_

# Generated at 2022-06-23 15:38:45.663732
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    parser = Parser()
    parser.class_api('root', 'name', [], [])
    assert parser.doc['name'] == '# class name\n\n'
test_Parser_class_api()


# Generated at 2022-06-23 15:38:54.989298
# Unit test for method api of class Parser
def test_Parser_api():
    # Test case 1
    def f1(x: int = 0) -> None:
        pass
    # Test case 2
    def f2(*, x: int) -> None:
        pass
    # Test case 3
    def f3(x: int, *, y: int) -> None:
        pass
    # Test case 4
    def f4(*, x: int, y: int = 1) -> None:
        pass
    # Test case 5
    def f5(x, *, y) -> None:
        pass
    # Test case 6
    def f6(x = 0) -> None:
        pass
    # Test case 7
    def f7(*, x: int, y: int = 1) -> None:
        pass
    # Test case 8

# Generated at 2022-06-23 15:38:56.248756
# Unit test for method parse of class Parser
def test_Parser_parse():
    import doctest
    from . import parser
    doctest.testmod(parser)

# Generated at 2022-06-23 15:39:05.769359
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    assert list(p.func_ann("name", [arg('arg', Name("type", Load()))])) == ["type"]
    assert list(p.func_ann("name", [arg('arg', None)])) == ["Any"]
    assert list(p.func_ann("name", [arg('arg', Name("type", Load())),
                                    arg('return', Name("str", Load()))])) == ["type", "str"]
    assert list(p.func_ann("name", [arg('self', Name("t", Load())),
                                    arg('arg', None)])) == ["Self", "Any"]
    assert list(p.func_ann("name", [arg('self', None),
                                    arg('arg', None)])) == ["Any", "Any"]

# Generated at 2022-06-23 15:39:11.418154
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('_a.') == False
    assert is_public_family('a.__b') == True
    assert is_public_family('__a.__b') == True
    assert is_public_family('a.__b.') == True
    assert is_public_family('a.__b._c') == False


# Generated at 2022-06-23 15:39:18.510458
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    """Test Resolver class visit_Subscript methon"""
    resolver = Resolver('module', {})
    assert code(unparse(resolver.visit_Subscript(Subscript(Name('test', Load()), Tuple(elts=[Name('int', Load())], ctx=Load()), Load())))) == "`test[int]`"


# Generated at 2022-06-23 15:39:20.539495
# Unit test for function parent
def test_parent():
    assert parent('a.b') == 'a'
    assert parent('a.b', level=2) == ''
    assert parent('a.b', level=3) == ''
    assert parent('a.b', level=4) == ''



# Generated at 2022-06-23 15:39:28.993470
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    resolver = Resolver("", {})
    assert unparse(resolver.visit(Subscript(Name("typing.Union", Load), Tuple(elts=[Name("int", Load), Name("str", Load)], ctx=Load()), Load()))).strip() == "int | str"
    assert unparse(resolver.visit(Subscript(Name("typing.Optional", Load), Name("str", Load), Load()))).strip() == "str | None"
    assert unparse(resolver.visit(Subscript(Name("typing.List", Load), Name("int", Load), Load()))).strip() == "typing.List[int]"

# Generated at 2022-06-23 15:39:41.125919
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    # module
    cm1 = Module(body=[ClassDef(
        name='A',
        bases=[],
        body=[Assign(
            targets=[Name(id='b', ctx=Store())],
            value=Str(s='a'),
        )],
    )])
    # class

# Generated at 2022-06-23 15:39:52.410131
# Unit test for method api of class Parser
def test_Parser_api():
    p = Parser(0, False)
    p.api('test', parse_funcdef(
        'def foo(a:int): ...'
    ))
    p.api('test', parse_classdef(
        'class foo:\n'
        '    a:int\n'
        '    def bar(b:str) -> None: ...\n'
    ))

# Generated at 2022-06-23 15:39:54.445992
# Unit test for function is_magic
def test_is_magic():
    assert not is_magic('foo')
    assert not is_magic('foo.bar')
    assert is_magic('__foo__')
    assert is_magic('foo.__bar__')

# Generated at 2022-06-23 15:40:06.928794
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    root = 'A'
    alias = {
        'A.B': 'C',
        'C.D': 'E[C.F, G]'
    }
    assert Resolver(root, alias).visit_Constant(Constant('B')).id == 'B'
    assert Resolver(root, alias).visit_Constant(Constant('E[C.F, G]')).value == (E, '[', C, '.', F, ',', ' ', G, ']')
    assert Resolver(root, alias).visit_Constant(Constant('C.D')).value == (C, '.', D)