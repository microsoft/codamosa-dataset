

# Generated at 2022-06-23 15:30:12.620876
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    root = 'math'
    args: list[arg] = []
    args.append(arg('x', parse_expr('int')))
    args.append(arg('y', parse_expr('float')))
    args.append(arg('/', None))
    args.append(arg('z', parse_expr('str')))
    args.append(arg('*args', parse_expr('tuple[int, float, str]')))
    args.append(arg('return', parse_expr('int')))

    assert list(p.func_ann(root, args, has_self=False, cls_method=False)) == [
        'int',
        'float',
        '',
        'str',
        'tuple[int, float, str]',
        'int'
    ]


# Generated at 2022-06-23 15:30:24.538596
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    p = Parser()
    p.imp["root"] = set()
    p.alias = {}
    p.root = {"root.ClassDef": "root"}
    p.doc = {}
    p.level = {"root.ClassDef": 0}
    p.docstring = {}
    # Note that walk_body returns the root node at index 0, therefore the
    # expected output of the doc string should be the same as the root node

# Generated at 2022-06-23 15:30:29.252390
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore('abc_') == 'abc_'
    assert esc_underscore('_abc') == '_abc'
    assert esc_underscore('___') == '___'
    assert esc_underscore('__') == r'\_\_'
    assert esc_underscore('_') == r'\_'
    assert esc_underscore('') == ''



# Generated at 2022-06-23 15:30:34.694681
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    assert Parser() == Parser()
    assert Parser() != Parser(__alias={'a': 'b'})
    assert Parser() != Parser(__doc={'a': 'b'})
    assert Parser() != Parser(__root={'a': 'b'})
    assert Parser() != Parser(__level={'a': 1})
    assert Parser() != Parser(__docstring={'a': 'b'})
    assert Parser() != Parser(__imp={'a': {'b'}})
    assert Parser() != Parser(__const={'a': 'b'})
    assert Parser() != Parser(__b_level=1)
    assert Parser() != Parser(__link=True)
    assert Parser() != Parser(__toc=True)
   

# Generated at 2022-06-23 15:30:44.785985
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    p.doc = {'dummy_module': '**Table of contents:**'}
    p.imp = {'dummy_module': set()}
    p.const = {}
    p.root = {'dummy_module': 'dummy_module'}
    # Test case 1
    s = 'dummy_module.__all__'
    assert p.is_public(s) == False

    # Test case 2
    s = 'dummy_module.private_function'
    assert p.is_public(s) == False

    # Test case 3
    p.doc['dummy_module.private_function'] = None
    assert p.is_public(s) == True

    # Test case 4
    s = 'dummy_module._private_function'

# Generated at 2022-06-23 15:30:54.070745
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    """Test for Parser.resolve."""
    import sys
    import io
    import builtins
    #
    _f = io.StringIO()
    with redirect_stdout(_f):
        parser = Parser()
        parser.load(sys.modules['builtins'])
        parser.parse()
        parser.load_docstring('builtins', builtins)
        parser.compile()
    #
    _f.seek(0)
    _output = _f.getvalue()
    #
    _f = io.StringIO()
    with redirect_stdout(_f):
        parser = Parser(link=True)
        parser.load(sys.modules['builtins'])
        parser.parse()
        parser.load_docstring('builtins', builtins)
        parser.compile()
    #


# Generated at 2022-06-23 15:31:04.137639
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('os.path.join')
    assert is_public_family('os.path._join')
    assert not is_public_family('os.path._join._')
    assert not is_public_family('_sys.path._join._')
    assert is_public_family('_sys.path.join')
    assert is_public_family('__sys.path.join')
    assert is_public_family('__sys.__path.join')
    assert not is_public_family('__sys.path._join')
    assert not is_public_family('__sys.__path._join')
# End of unit test



# Generated at 2022-06-23 15:31:08.728998
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    r = Resolver('test', {})
    assert r.visit(Name('x')) == Name('x')
    assert r.visit(Constant(1)) == Constant(1)
    assert r.visit(Constant('x')) == Name('x')



# Generated at 2022-06-23 15:31:20.387536
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    from typing import overload, cast
    from _ast import Name
    
    arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg = arg

# Generated at 2022-06-23 15:31:32.057239
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    root = 'typing'
    alias = {
        'typing.abc.ABC': 'abc.ABC',
        'typing.ABC': 'abc.ABC',
        'typing.ABCMeta': 'abc.ABCMeta',
    }
    self_ty = 'Self'
    resolver = Resolver(root, alias, self_ty)
    ret_ast = resolver.visit(parse('int').body[0].value)
    assert isinstance(ret_ast, Constant) and ret_ast.value == 'int'
    ret_ast = resolver.visit(parse('typing.Optional[int]').body[0].value)
    assert isinstance(ret_ast, BinOp) and isinstance(ret_ast.left, Subscript)\
        and isinstance(ret_ast.right, Constant) and ret_ast

# Generated at 2022-06-23 15:31:43.861878
# Unit test for method globals of class Parser
def test_Parser_globals():
    from .parser import Parser
    from .ast import Module, Name, Str

    from .token import Token

    from .const import Const
    from .typing import TYPE_COMMENT
    _, example_path = tempfile.mkstemp()

# Generated at 2022-06-23 15:31:55.198868
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    class DummyParser(Parser):
        def __init__(self):
            self.doc = {}
    p = DummyParser()
    m = _attr(dino, 'Image')
    p.class_api('dino.image', 'dino.image.Image', m.__bases__, m.__mro__[0].__init__.__code__.co_consts)

# Generated at 2022-06-23 15:32:00.583471
# Unit test for function const_type
def test_const_type():
    assert const_type(Constant(True)) == 'bool'
    assert const_type(Constant(1)) == 'int'
    assert const_type(Constant(1.1)) == 'float'
    assert const_type(Constant(1.1j)) == 'complex'
    assert const_type(Constant('a')) == 'str'
    assert const_type(Constant('a')) == 'str'
    assert const_type(Constant(b'a')) == 'bytes'
    assert const_type(Constant(1.1j)) == 'complex'
    assert const_type(Constant(1.1j)) == 'complex'
    assert const_type(Tuple([])) == 'tuple[]'
    assert const_type(Tuple([Constant(1), Constant(1.1)]))

# Generated at 2022-06-23 15:32:06.378779
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('___')
    assert is_magic('____')
    assert is_magic('__A__')
    assert is_magic('__A_') is False
    assert is_magic('_A__') is False
    assert is_magic('__A') is False
    assert is_magic('A__') is False
    assert is_magic('A_') is False
    assert is_magic('__') is False
    assert is_magic('_') is False
    assert is_magic('') is False
    assert is_magic('A') is False



# Generated at 2022-06-23 15:32:09.435005
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    """Test the method: Parser.__post_init__()."""
    p = Parser(0, 0, None, False, False)
    assert p.level == {'__main__': 0}
    p = Parser(1, 0, None, False, False)
    assert p.level == {'__main__': 1}



# Generated at 2022-06-23 15:32:20.648982
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    assert p.parse('') == '', "Empty string"
    assert p.parse('\n') == '', "Format string"
    assert p.parse('def foo() -> int:\n    """\n    foo\n    """') == '\n        foo\n        '
    assert p.parse('async def foo() -> int:\n    """\n    foo\n    """') == '\n        foo\n        '
    assert p.parse('class Foo():\n    """\n    foo\n    """') == '\n        foo\n        '
    assert p.parse('class Foo:\n    """\n    foo\n    """') == '\n        foo\n        '

# Generated at 2022-06-23 15:32:30.569744
# Unit test for method imports of class Parser
def test_Parser_imports():
    from ast import parse
    from typing import List
    from importlib import import_module
    src = """
    from typing import List


    def f(a):
        return a


    class C:
        def f(self):
            return ""
    """
    m: Module = parse(src)
    p = Parser()
    p.imports('foo', m)
    assert p.alias == {'foo': 'foo', 'foo.f': 'f', 'foo.C': 'C', 'foo.List': 'List'}
    assert p.imp == {'foo': {'List'}}
    p.globals('foo', m)
    assert p.alias == {'foo': 'foo', 'foo.f': 'f', 'foo.C': 'C', 'foo.List': 'List'}
   

# Generated at 2022-06-23 15:32:32.887744
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__name__')
    assert not is_magic('testing')



# Generated at 2022-06-23 15:32:43.293459
# Unit test for function walk_body

# Generated at 2022-06-23 15:32:46.804233
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    root, src = 'test_Parser_func_ann', '''
        def f() -> Optional[str]:
            ...
    '''
    m = ast.parse(src)
    p = Parser()
    p.api(root, m.body[0])
    assert p.doc[root].format(root) == '''\
# f()

*Full name:* `test_Parser_func_ann`

```python
Return  # type: Optional[str]
```
'''

# Generated at 2022-06-23 15:32:58.503586
# Unit test for constructor of class Parser
def test_Parser():
  parser=Parser({'module_name':'module_1.py'},True)
  dict={'doc': {}, 'root': {}, 'imp': {}, 'alias': {}, 'const': {}, 'level': {}, 'docstring': {}}
  assert isinstance(parser,Parser)
  assert parser.mod['module_name']=='module_1.py'
  assert parser.link==True
  assert parser.b_level==1
  assert parser.toc==True
  assert parser.doc==dict['doc']
  assert parser.root==dict['root']
  assert parser.imp==dict['imp']
  assert parser.alias==dict['alias']
  assert parser.const==dict['const']
  assert parser.level==dict['level']
  assert parser.docstring==dict['docstring']

# Generated at 2022-06-23 15:33:06.978085
# Unit test for function const_type
def test_const_type():
    pep585 = PEP585()
    assert const_type(Constant.from_const(False)) == 'bool'
    assert const_type(Constant.from_const(1)) == 'int'
    assert const_type(Constant.from_const(1.0)) == 'float'
    assert const_type(Constant.from_const(1 + 1.0j)) == 'complex'
    assert const_type(Constant.from_const("1")) == 'str'
    assert const_type(Constant.from_const('1')) == 'str'
    assert const_type(Constant.from_const(" ")) == 'str'
    assert const_type(Constant.from_const(b'1')) == 'bytes'

# Generated at 2022-06-23 15:33:17.677807
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    import sys
    import os
    import tqdm
    from contextlib import redirect_stdout, redirect_stderr
    from ast import parse, dump, NodeTransformer
    from typing import List, Callable, Union
    from io import StringIO
    from doc_gen.comment import Dependence

    # print(f"sys.version = {sys.version}")
    # print(f"sys.executable = {sys.executable}")
    # print(f"os.curdir = {os.curdir}")
    # print(f"sys.path = {sys.path}")
    # print(f"tqdm.__file__ = {tqdm.__file__}")

    # fp = open(os.path.join(os.curdir,
    #                           'source\\404_

# Generated at 2022-06-23 15:33:21.203902
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__init__')
    assert is_magic('__bk__')
    assert not is_magic('_bk_')
    assert not is_magic('bk')


# Generated at 2022-06-23 15:33:31.767524
# Unit test for method parse of class Parser
def test_Parser_parse():
    """Test the `parse` method."""
    p = Parser(link=False)
    p.parse('def f(a: bool, b: bool = True) -> bool: ...')
    assert isinstance(p.alias['f'], FunctionDef)
    assert p.doc['f'] == '## f()\n\n*Full name:* `f`\n\n'
    assert p.doc['f'] == '## f()\n\n*Full name:* `f`\n\n'
    assert p.docstring['f'] is None
    assert p.func_ann(p.alias['f'].args, has_self=False, cls_method=False) == [
        'type[bool]', 'type[bool] = True', 'type[bool]']

# Generated at 2022-06-23 15:33:38.581035
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    p = Parser(True, False)
    p.doc['a.b'] = '*{}*'
    p.doc['a.c'] = '*{}*'
    m = ModuleType('a', 'docstr')
    m.b = ''
    p.load_docstring('a', m)
    assert p.doc['a.b'] == '*a.b*\n\n```\ndocstr\n```\n'
    assert p.doc['a.c'] == '*a.c*'

# Generated at 2022-06-23 15:33:44.182499
# Unit test for function is_magic
def test_is_magic():
    assert not is_magic('a')
    assert not is_magic('a.a')
    assert not is_magic('a.a.a')
    assert not is_magic('a.__a')
    assert is_magic('a.__a__')
    assert is_magic('a.__a.__')
    assert is_magic('a.__a__.a')



# Generated at 2022-06-23 15:33:47.054288
# Unit test for function code
def test_code():
    assert code('A & B') == '<code>A &amp; B</code>'
    assert code('|') == '<code>&#124;</code>'
    assert code('') == ' '

# Singleton

# Generated at 2022-06-23 15:33:57.432410
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    parser = Parser()
    assert (len(parser.alias) == 0), 'expected (len(parser.alias) == 0), got: {}'.format(len(parser.alias))
    assert (len(parser.doc) == 0), 'expected (len(parser.doc) == 0), got: {}'.format(len(parser.doc))
    assert (parser.b_level == 1), 'expected (parser.b_level == 1), got: {}'.format(parser.b_level)
    assert (parser.link == False), 'expected (parser.link == False), got: {}'.format(parser.link)
    assert (parser.toc == False), 'expected (parser.toc == False), got: {}'.format(parser.toc)



# Generated at 2022-06-23 15:34:03.525641
# Unit test for function code
def test_code():
    assert code("""
    def f(x, y):
        if x == 5:
            y = x + y
    """) == """
<code>
    def f(x, y):
        if x == 5:
            y = x + y
    </code>
"""
    assert code("""
    b = {'a': 5,
         'b': 6}
    """) == """
<code>
    b = {'a': 5,
         'b': 6}
    </code>
"""
    assert code("""
    a = '1234' + '5678'
    b = 1234 + 5678
    """) == """
<code>
    a = '1234' + '5678'
    b = 1234 + 5678
    </code>
"""
    assert code('')

# Generated at 2022-06-23 15:34:07.833718
# Unit test for method imports of class Parser
def test_Parser_imports():
    from ast import Import, Name, alias
    root = ''
    node = Import([alias('a', 'b')])
    parser = Parser(toc=False, link=False)
    parser.imports(root, node)
    assert parser.alias[_m(root, 'b')] == 'a'


# Generated at 2022-06-23 15:34:18.231273
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('a')
    assert not is_public_family('a._a')
    assert not is_public_family('a._A')
    assert is_public_family('a._A_')
    assert not is_public_family('_a')
    assert not is_public_family('._a')
    assert not is_public_family('_a._a')
    assert is_public_family('a.a')
    assert not is_public_family('a.a._a')
    assert is_public_family('__a')
    assert is_public_family('__a.__a')
    assert is_public_family('__a.a')
    assert is_public_family('a.__a')
    assert not is_public_family('_a.a')



# Generated at 2022-06-23 15:34:25.210657
# Unit test for function const_type
def test_const_type():
    """Test const_type function"""
    from ast import parse as parse_name
    assert const_type(Constant(None, type(None))) == 'NoneType'
    assert const_type(Constant(True, type(True))) == 'bool'
    assert const_type(Constant(0, type(0))) == 'int'
    assert const_type(Constant(0.0, type(0.0))) == 'float'
    assert const_type(Constant(0 + 0j, type(0 + 0j))) == 'complex'
    assert const_type(Constant("", type(""))) == 'str'
    assert const_type(Constant("0", type("0"))) == 'str'
    assert const_type(Constant("0.1", type("0.1"))) == 'str'
    assert const_

# Generated at 2022-06-23 15:34:27.567599
# Unit test for constructor of class Parser
def test_Parser():
    # pylint: disable=too-few-public-methods
    """Unit test for constructor of class Parser"""
    Parser(NewType('str', str), {}, {}, {}, {}, {}, {}, {}, {}, False)


# Generated at 2022-06-23 15:34:32.549632
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    from .pep585 import PEP585
    from ast import parse
    node = parse("typing.List[int]").body[0].value
    assert isinstance(node, Attribute)
    r = Resolver("", PEP585)
    assert isinstance(r.visit(node), Name)


# Generated at 2022-06-23 15:34:40.238677
# Unit test for method compile of class Parser
def test_Parser_compile():
    """Test method compile of class Parser"""
    import doctest as dt
    tt = dt.REPORT_NDIFF
    dt.REPORT_NDIFF = 0
    import doctest as dt
    import py_docstr.py_docstr as pd
    pd.logger.disabled = True
    kwargs = dict(optionflags=dt.REPORT_ONLY_FIRST_FAILURE)
    try:
        result = dt.testmod(pd, **kwargs)
        assert not result.failed
        assert result.attempted == 3
    finally:
        dt.REPORT_NDIFF = tt


# Generated at 2022-06-23 15:34:49.859774
# Unit test for method parse of class Parser
def test_Parser_parse():
    import types
    from ast import parse
    from inspect import Signature
    from importlib import import_module

    m = import_module('test_pdoc.testmod')
    module_tree = parse(m.__doc__)
    parser = Parser(max_level=1)
    parser.parse(m, module_tree)
    assert parser.doc == {}
    assert parser.docstring == {}
    parser = Parser(max_level=1, all_=False, link=True)
    parser.parse(m, module_tree)
    assert parser.doc == {}
    assert parser.docstring == {}
    parser = Parser(max_level=2, all_=False, link=True)
    parser.parse(m, module_tree)

# Generated at 2022-06-23 15:34:53.007751
# Unit test for function table
def test_table():
    assert '\n'.join(table('a', 'b', [['c', 'd'], ['e', 'f']]).splitlines()[:-1]) == """\
| a | b |
|:---:|:---:|
| c | d |
| e | f |"""



# Generated at 2022-06-23 15:34:56.250299
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("_") == "_"
    assert esc_underscore("__") == r"\_\_"
    assert esc_underscore("a_b") == r"a\_b"



# Generated at 2022-06-23 15:35:00.361014
# Unit test for function code
def test_code():
    assert code('|') == '`\|`'
    assert code('a&b') == '<code>a&amp;b</code>'
    assert code('def func(a: str) -> str') == '`def func(a: str) -> str`'
    assert code('') == ' '
test_code()



# Generated at 2022-06-23 15:35:05.255111
# Unit test for function walk_body
def test_walk_body():
    assert code(unparse(parse(getdoc(walk_body)))) == '"""Traverse around body and its simple definition scope."""'
    assert code(unparse(parse(getdoc(test_walk_body)))) == '"""Unit test for function walk_body"""\n'



# Generated at 2022-06-23 15:35:14.481594
# Unit test for function const_type
def test_const_type():
    assert const_type(parse('None', mode='eval').body) == 'NoneType'
    assert const_type(parse('True', mode='eval').body) == 'bool'
    assert const_type(parse('False', mode='eval').body) == 'bool'
    assert const_type(parse('1', mode='eval').body) == 'int'
    assert const_type(parse('-1', mode='eval').body) == 'int'
    assert const_type(parse('1.0', mode='eval').body) == 'float'
    assert const_type(parse('-1.0', mode='eval').body) == 'float'
    assert const_type(parse('1j', mode='eval').body) == 'complex'
    assert const_type(parse('1J', mode='eval').body) == 'complex'
   

# Generated at 2022-06-23 15:35:24.934365
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    a = Resolver('', {})
    assert a.visit(parse('["typing.List[int]"]').body[0].elts[0]) == \
        List([Constant(int())], Load())
    assert a.visit(parse('["typing.Union[int, float]"]').body[0].elts[0]) == \
        BinOp(Constant(int()), BitOr(), Constant(float()))
    assert a.visit(parse('["typing.Optional[int]"]').body[0].elts[0]) == \
        BinOp(Constant(int()), BitOr(), Constant(None))
    assert a.visit(parse('["int"]').body[0].elts[0]) == \
        Constant(int())



# Generated at 2022-06-23 15:35:36.873668
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    import ast
    from typing import Any
    code = _code
    class_ = _attr(ast, 'ClassDef')
    function = _attr(ast, 'FunctionDef')
    name = _attr(ast, 'Name')
    str_ = _attr(ast, 'Str')
    parse = ast.parse
    args = _attr(ast, 'arguments')
    arg = _attr(ast, 'arg')
    expr = _attr(ast, 'expr')
    stmt = _attr(ast, 'stmt')
    parser = Parser()
    parser.link = False
    parser.toc = False
    parser.lang = 'en'
    class A():
        def __init__(self,*args: Any,**kwargs: Any) -> None:
            pass

# Generated at 2022-06-23 15:35:44.868489
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('_') is False
    assert is_public_family('_.__') is False
    assert is_public_family('__') is True
    assert is_public_family('__.__') is True
    assert is_public_family('__.__.__') is True
    assert is_public_family('qp_') is False
    assert is_public_family('qp_.__') is False
    assert is_public_family('qp_.__.__') is False
    assert is_public_family('qp_.a') is False
    assert is_public_family('qp_.a.__') is True
    assert is_public_family('qp_.a.__.__') is True



# Generated at 2022-06-23 15:35:49.951517
# Unit test for function code
def test_code():
    """Test code."""
    assert code("") == " "
    assert code("Name") == "`Name`"
    assert code("A|B") == "<code>A|B</code>"
    assert code("A&B") == "<code>A&amp;B</code>"
test_code()



# Generated at 2022-06-23 15:36:01.408384
# Unit test for function const_type
def test_const_type():
    assert const_type(parse("True").body[0].value) == "bool"
    assert const_type(parse("1").body[0].value) == "int"
    assert const_type(parse("1.0").body[0].value) == "float"
    assert const_type(parse("1j").body[0].value) == "complex"
    assert const_type(parse("'1'").body[0].value) == "str"
    assert const_type(parse("tuple()").body[0].value) == "tuple[]"
    assert const_type(parse("tuple([1])").body[0].value) == "tuple[int]"
    assert const_type(parse("tuple([1, 2])").body[0].value) == "tuple[int, int]"
    assert const_

# Generated at 2022-06-23 15:36:13.113381
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    """Unit test for class Parser.class_api"""
    from .parse import parse

    doc = Parser()

# Generated at 2022-06-23 15:36:20.942541
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    """Unit test for method visit_Subscript of class Resolver."""
    assert Resolver("a", {}).visit_Subscript(
        Subscript(
            Name("a", Load()),
            Tuple([Name("b", Load()), Name("c", Load())], Load()),
            Load())
    ) == BinOp(BinOp(Name("b", Load()), BitOr(), Name("c", Load())),
               BitOr(), Constant(None))

# Generated at 2022-06-23 15:36:25.642674
# Unit test for function code
def test_code():
    assert code('a|b') == '<code>a&#124;b</code>'
    assert code('a&b') == '<code>a&amp;b</code>'
    assert code('ab') == '`ab`'
    assert code('') == ' '



# Generated at 2022-06-23 15:36:28.179702
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert unparse(Resolver.visit_Attribute(Resolver,Attribute(Name('typing',Load()),'Any',Load())))=='Any'

# Generated at 2022-06-23 15:36:30.666817
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    r = Resolver("self", {})
    node = parse("self").body[0]
    r.visit(node)



# Generated at 2022-06-23 15:36:33.467581
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    P = Parser('path')
    assert repr(P) == "Parser(path='path', level=0, b_level=1, toc=True, " \
                       'link=False)'

# Generated at 2022-06-23 15:36:37.074738
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore(r"_") == r"_"
    assert esc_underscore(r"__") == r"\__"
    assert esc_underscore(r"___") == r"\___"
    assert esc_underscore(r"__a__") == r"\__a\__"


# Generated at 2022-06-23 15:36:40.713409
# Unit test for function parent
def test_parent():
    assert parent('a.b.c', level=2) == 'a'
    assert parent('a.b.c', level=1) == 'a.b'



# Generated at 2022-06-23 15:36:50.631272
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    r = Resolver("_fake_", {})
    e = Expr(Constant("typing.Union[int, float]"))
    e = r.visit(e)
    assert code(unparse(e)) == "Union[int, float]"

    e = Expr(Constant("Union[int, float]"))
    e = r.visit(e)
    assert code(unparse(e)) == "Union[int, float]"

    e = Expr(Constant("typing.Optional[int]"))
    e = r.visit(e)
    assert code(unparse(e)) == "Optional[int]"

    e = Expr(Constant("List[int]"))
    e = r.visit(e)
    assert code(unparse(e)) == "List[int]"

    e = Ex

# Generated at 2022-06-23 15:36:56.469553
# Unit test for function parent
def test_parent():
    assert parent('aaa.bbb.ccc.ddd', level=1) == 'aaa.bbb.ccc'
    assert parent('a.b.c.d', level=2) == 'a.b'
    assert parent('a.b.c.d', level=3) == 'a'
    try:
        parent('a.b.c.d', level=4)
        raise Exception
    except IndexError:
        pass



# Generated at 2022-06-23 15:37:01.940437
# Unit test for function code
def test_code():
    """Test for function code"""
    test_list = [
        ("code", "`code`"),
        ("|", "&#124;"),
        ("&", "<code>&</code>"),
        ("a & b", "<code>a & b</code>"),
        ("", " "),
        (None, " "),
    ]
    for s, expect in test_list:
        assert code(s) == expect
test_code()



# Generated at 2022-06-23 15:37:11.647181
# Unit test for method class_api of class Parser
def test_Parser_class_api():

    parser = Parser(False, False)

    class MyClass:

        class A:
            pass

        class B(A):
            pass
        pass

    class TestClass:
        a: int
        L: List[int] = []
        b: Union[None, int] = None
        c: Optional[int] = None
        self: 'TestClass' = None

        @classmethod
        def foobar(cls, a: int, b: int, c: int) -> int:
            return a + b + c
        pass

    root = 'my_module'

# Generated at 2022-06-23 15:37:12.614533
# Unit test for method visit_Constant of class Resolver

# Generated at 2022-06-23 15:37:19.292149
# Unit test for function is_public_family
def test_is_public_family():
    assert not is_public_family('_a')
    assert not is_public_family('a._b')
    assert is_public_family('a.b')
    assert is_public_family('a.__b__')
    assert is_public_family('a.b.c')
    assert is_public_family('a.b.__c__')
    assert not is_public_family('a._b.c')
    assert not is_public_family('a.b._c')



# Generated at 2022-06-23 15:37:25.532143
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    class A:
        pass
    attr = A()
    attr.__doc__ = "Test"
    attr.__name__ = "a"
    attr.__module__ = "m"
    parser = Parser(test=True)
    parser.class_api("a", attr, [], [])
    assert (parser.doc["a"] == "## class a\n\n*Full name:* `a`\n\n")

# Generated at 2022-06-23 15:37:31.107442
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    c = Constant(1)
    assert Resolver("", dict()).visit(c) == c
    e = Expr(Name("int", Load()))
    assert Resolver("", dict()).visit(Constant(e)) == e.value



# Generated at 2022-06-23 15:37:39.431703
# Unit test for function const_type
def test_const_type():
    _ = {'a': 1}
    assert const_type(parse('1', mode='eval').body) == 'int'
    assert const_type(parse('1.0', mode='eval').body) == 'float'
    assert const_type(parse('1.0j', mode='eval').body) == 'complex'
    assert const_type(parse("'1'", mode='eval').body) == 'str'
    assert const_type(parse("(1,)", mode='eval').body) == 'tuple[int]'
    assert const_type(parse("(1.0,)", mode='eval').body) == 'tuple[float]'
    assert const_type(parse("(1.0j,)", mode='eval').body) == 'tuple[complex]'

# Generated at 2022-06-23 15:37:51.322174
# Unit test for method imports of class Parser
def test_Parser_imports():
    m = 'D'
    p, root, node = Parser(), 'module', Import(
        names=[alias('a', 'A'), alias('b', 'B'), alias('c', None)])
    p.imports(root, node)
    assert p.alias.pop('a') == 'A'
    assert p.alias.pop('b') == 'B'
    assert p.alias.pop('c') == 'c'
    node = ImportFrom('module', [alias('a', 'A'), alias('b', 'B')],
                      1, 'module', ['a', 'b'])
    p.imports(root, node)
    assert p.alias.pop('a') == 'module.a'
    assert p.alias.pop('b') == 'module.b'

# Generated at 2022-06-23 15:38:02.074130
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    parser = Parser(b_level=2, link=False, toc=False)
    root = 'a.b'
    args = [arg('*', None), arg('**kwargs', Name(id='int', ctx=Load())),
            arg('return', Name(id='int', ctx=Load()))]
    has_self = False
    cls_method = False
    result = parser.func_ann(root, args, has_self, cls_method)
    keys = []
    results = []
    for key, value in result:
        keys.append(key)
        results.append(value)
    assert keys == [0, 1, 2]
    assert results == ["", "int", "int"]


# Generated at 2022-06-23 15:38:14.689700
# Unit test for method api of class Parser
def test_Parser_api():
    import ast
    # pylint: disable=redefined-outer-name
    @Parser.func_api('my_module', arg('x', None), None, cls_method=True)
    def test(alias, name, args, returns, has_self, cls_method):
        doc = Parser.doc[name]
        root = Parser.root[name]
        assert root == 'my_module'
        assert has_self is True
        assert cls_method is True
        assert doc == table(
            "Arguments", "Type",
            items=[(code('self'), code('object')),
                   (code('x'), code('Any'))]
        )
        assert returns is None
        alias['self'] = 'object'
        alias['my_module'] = 'my_module'
        __tracebackhide

# Generated at 2022-06-23 15:38:19.871285
# Unit test for constructor of class Parser
def test_Parser():
    a = 'Python'
    b = 'JavaScript'
    c = 'C++'
    expected: dict[str, str] = {
        'lang': a,
        'language': b,
        'langauge': c
    }
    assert Parser(lang={a, b}, langauge={c}).lang == expected

# Generated at 2022-06-23 15:38:27.941739
# Unit test for method visit_Subscript of class Resolver

# Generated at 2022-06-23 15:38:40.227551
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    def show(node: expr) -> str:
        """Visitor to string."""
        rs = Resolver("", dict())
        try:
            return unparse(rs.visit(node)).strip()
        except SyntaxError:
            return "SyntaxError"
    assert show(Subscript(Name('Optional', Load),
                          Tuple([] if PY37 else Constant(None), Load()),
                          Load())) in ["Optional[None]", "Optional[None, ]"]
    assert show(Subscript(Name('Union', Load),
                          Tuple([Name('int', Load), Name('float', Load)],
                                Load()), Load())) == "Union[int, float]"

# Generated at 2022-06-23 15:38:50.437921
# Unit test for method globals of class Parser
def test_Parser_globals():
    from types import ModuleType
    from typing import Dict

    from .ast import AnnAssign, Assign, Import, Module, Name, Subscript

    from .parse import Parser

    from .types import ClassDef, Module, _I, FunctionDef, arg, argname, arguments

    b = Parser()
    m = ModuleType('m')
    b.globals('m', Import([arg(('n', '*'))]))
    assert b.alias == {'m.n': 'n'}
    assert b.imp == {'m': {'m.n'}}
    b.globals('m', Import([arg(('n', 'N'))]))
    assert b.alias == {'m.n': 'n', 'm.N': 'n'}

# Generated at 2022-06-23 15:38:54.825252
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    """Unit test for method load_docstring of class Parser"""
    p = Parser()
    p.load_docstring('a', __import__('subprocess'))
    print(p.docstring['subprocess.Popen'])
    print(p.docstring['subprocess.Popen.send_signal'])

# Generated at 2022-06-23 15:38:57.266242
# Unit test for constructor of class Resolver
def test_Resolver():
    """Class Resolver unit test."""
    l = Resolver("root", {})
    assert l.root == "root"
    assert l.alias == {}
    assert l.self_ty == ""


# Generated at 2022-06-23 15:39:03.395940
# Unit test for method class_api of class Parser

# Generated at 2022-06-23 15:39:14.730970
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    p.imp['x'] = {'x', 'x.y'}
    p.imp['x.y'] = {'x.y.z'}
    p.root['x.y.z'] = 'x.y.z'
    p.root['x.y'] = 'x.y'
    p.root['x'] = 'x'
    p.level['x'] = 0
    p.level['x.y'] = 1
    p.level['x.y.z'] = 2
    assert p.is_public('x') == True
    assert p.is_public('x.y') == True
    assert p.is_public('x.y.z') == True
    assert p.is_public('x.y.w') == False
    #
    p = Pars

# Generated at 2022-06-23 15:39:15.559255
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__init__') and is_magic('__len__')
    assert not is_magic('a')



# Generated at 2022-06-23 15:39:21.091962
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore('sin_') == 'sin\_'
    assert esc_underscore('_sin') == '\_sin'
    assert esc_underscore('sin_cos') == 'sin\_cos'
    assert esc_underscore('sin_cos_tan') == 'sin\_cos\_tan'



# Generated at 2022-06-23 15:39:29.384307
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    parser = Parser()
    args = arguments(args=[arg(arg='*'),
                           arg(arg='**kwargs',
                               annotation=parse_as_expr('{str}'))],
                     defaults=[parse_as_expr('{}')],
                     vararg=arg(arg='args',
                                annotation=parse_as_expr('[int]')))
    func_name = 'test.my_func'
    parser.func_api('test', func_name, args, parse_as_expr('dict[int, str]'),
                    has_self=False, cls_method=False)
    doc = parser.doc[func_name]
    assert 'test.my_func()' in doc
    assert '#' in doc
    assert '*Full name:*' in doc

# Generated at 2022-06-23 15:39:41.570307
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    proc = Parser(__name__, link=False, toc=False)
    doc = proc.compile()

# Generated at 2022-06-23 15:39:52.759429
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    from inspect import ModuleInfo
    from inspect import Parameter
    from inspect import Signature
    from typing import Any
    from typing import Callable
    from typing import Dict
    from typing import List
    from typing import Optional
    from typing import Tuple
    from typing import Type
    from typing import Union
    def func(a: str, b: int = 1, *c: float, d: float = 2, **e: str) -> str:
        pass
    def str_func(a: str, b: int = 1, *c: float, d: float = 2,
                 **e: str) -> str:
        """a
        
        a
        
        a
        """

# Generated at 2022-06-23 15:40:05.449459
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    parser = Parser()
    parser.imp["test.test"] = {"test", "a"}
    assert parser.is_public("test.test")
    assert parser.is_public("test.test.test")
    assert parser.is_public("test.test.a")
    assert parser.is_public("test.test.b")
    assert parser.is_public("test.test.class")
    assert not parser.is_public("test.test.class_")
    assert not parser.is_public("test.test.__class__")
    assert not parser.is_public("test.test.foo")
    assert not parser.is_public("test.test.foo_")
    assert not parser.is_public("test.test.__foo__")