

# Generated at 2022-06-23 15:30:05.457467
# Unit test for function walk_body

# Generated at 2022-06-23 15:30:15.799056
# Unit test for method parse of class Parser
def test_Parser_parse():
    from ._parser import Parser
    from ._parser import ANY
#   from ._parser import Mod
    from . import _ast as ast
    from ._types import List
    from typing import _SpecialForm as SpecialForm
    from typing import GenericMeta as GenericMeta
    from typing import Union
    def code(s):
        """Code a string."""
        return "`" + str(s) + "`"
    def test_one(m: ModuleType) -> ModuleType:
        """Test one."""
        root = m.__name__
        p = Parser()
        p.parse(root, m)
        assert p.root[root] == root
        assert p.level[root] == 0
        assert unparse(p.parse) == unparse(tuple(m.__doc__.splitlines()))

# Generated at 2022-06-23 15:30:21.873443
# Unit test for function doctest
def test_doctest():
    doc = """
>>> a = 1
>>> a
1
"""
    assert doctest(doc) == """
```python
>>> a = 1
>>> a
1
```
"""
    doc = """
>>> a = 1
>>> b = 2
>>> a
1

>>> print(b)
2
"""
    assert doctest(doc) == """
```python
>>> a = 1
>>> b = 2
>>> a
1
```

```python
>>> print(b)
2
```
"""



# Generated at 2022-06-23 15:30:29.123753
# Unit test for function walk_body
def test_walk_body():
    tree = parse('''
    if a:
        b
    else:
        c
    d
    try:
        e
    except:
        f
    except:
        g
    else:
        h
    finally:
        i
    j
    ''')
    body = tree.body
    assert set(unparse(n) for n in walk_body(body)) == {'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'}



# Generated at 2022-06-23 15:30:34.161813
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("_") == "_"
    assert esc_underscore("__") == r"\_\_"
    assert esc_underscore("a_b") == r"a\_b"
    assert esc_underscore("_a") == r"\_a"



# Generated at 2022-06-23 15:30:40.346634
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    body = ast.parse("""
    class foo:
        a, b = 1, 2
        c: int
        d: str = 'a'
        def e(self):
            pass
        def f(self):
            '''q'''
        class bar:
            pass
    """).body[0].body
    parser = Parser(link=False, toc=False)
    parser.class_api('foo', 'foo', [], body)

# Generated at 2022-06-23 15:30:45.141574
# Unit test for function is_magic
def test_is_magic():
    assert not is_magic('a.b')
    assert not is_magic('__a__')
    assert not is_magic('_a_b_')
    assert is_magic('__a__b__')
    assert is_magic('__b__c__')
    assert is_magic('__c__d__')
    assert is_magic('_x_x_')



# Generated at 2022-06-23 15:30:51.140759
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    r = Resolver('', {})
    node = Subscript(Name('Union', Load()),
                     Tuple(elts=[Constant(1), Constant(2)], ctx=Load()),
                     Load())
    b = node.slice.elts[0]
    for e in node.slice.elts[1:]:
        b = BinOp(b, BitOr(), e)
    assert str(r.visit(node)) == str(b)



# Generated at 2022-06-23 15:30:58.397836
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    from importlib import import_module

    def func_ann(root: str, args: Sequence[arg], *,
                 has_self: bool, cls_method: bool) -> Iterator[str]:
        """Function annotation table."""
        self_ty = ""
        for i, a in enumerate(args):
            if has_self and i == 0:
                if a.annotation is not None:
                    self_ty = self.resolve(root, a.annotation)
                    if cls_method:
                        self_ty = (self_ty.removeprefix('type[')
                                   .removesuffix(']'))
                yield 'type[Self]' if cls_method else 'Self'
            elif a.arg == '*':
                yield ""
            elif a.annotation is not None:
                yield self

# Generated at 2022-06-23 15:31:04.322459
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    parser = Parser(
        link=False,
        toc=False,
        packages=(),
        b_level=0
    )
    assert isinstance(parser, Parser)
    assert parser.alias == {}
    assert parser.doc == {}
    assert parser.docstring == {}
    assert parser.level == {}
    assert parser.root == {}
    assert parser.imp == {}
    assert parser.const == {}


# Generated at 2022-06-23 15:31:17.105225
# Unit test for function const_type
def test_const_type():
    from .parser import FunctionParser

    f = FunctionParser()

# Generated at 2022-06-23 15:31:24.758729
# Unit test for method parse of class Parser
def test_Parser_parse():
    """Unit test for method parse."""
    data = "def foo() -> int: ..."
    p = Parser()
    p.parse_str(data)
    assert p.doc['foo'] == "@foo() -> int\n\n"
    assert p.docstring['foo'] == "\n"
    p = Parser()
    p.parse_file(__file__)
    assert 'def test_' in p.doc
    assert '@test_' in p.doc



# Generated at 2022-06-23 15:31:35.078131
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    """Test case for method visit_Subscript of class Resolver.
    """

# Generated at 2022-06-23 15:31:37.492314
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    parser = Parser(None)
    parser.class_api("", "", [], [])


# Generated at 2022-06-23 15:31:43.395785
# Unit test for function table
def test_table():
    assert table('A', 'B', [['c', 'd', 'e']]) == (
        '| A | B |\n'
        + '|:---:|:---:|\n'
        + '| c | d | e |\n'
        + '\n\n'
    )



# Generated at 2022-06-23 15:31:51.771485
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    resolver = Resolver('foo',{
        'foo': 'Alias of foo.',
        'foo.bar': 'Alias of foo.bar.',
    })
    # Visit Union()
    node = resolver.visit(parse(subscript_fixture).body[0].value)
    # print(unparse(node))
    assert(unparse(node) == 'Union[int, float, bool]')
    # Visit Optional()
    node = resolver.visit(parse('foo.Optional(str)').body[0].value)
    # print(unparse(node))
    assert(unparse(node) == 'Optional[str]')

subscript_fixture = '''
foo.Union[int, float, bool]
'''


# Generated at 2022-06-23 15:31:53.786295
# Unit test for constructor of class Resolver
def test_Resolver():
    """Test for Resolver."""

# Generated at 2022-06-23 15:32:02.554832
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    # alias: typing.List['str']
    alias = {
        'typing.List': 'List[str]',
        'typing.Dict': 'Dict[str, int]',
        'typing.Optional': 'Optional[int]',
        'typing.Union': 'Union[int, float]',
        'typing.Any': 'Any',
    }
    resolver = Resolver('root', alias)
    node = parse('Alias[123]').body[0].value.func.args.args[0]
    assert unparse(resolver.visit(node)) == "List[int]"
    node = parse('Alias[123]').body[0].value.func.args.args[1]
    assert unparse(resolver.visit(node)) == "Dict[str, int]"
    node

# Generated at 2022-06-23 15:32:08.083937
# Unit test for function code
def test_code():
    assert code('') == " "
    assert code('&') == "<code>&amp;</code>"
    assert code('a|b') == "<code>a&#124;b</code>"
    assert code('a') == '`a`'



# Generated at 2022-06-23 15:32:13.229379
# Unit test for function table
def test_table():
    tab = table('a', 'b', [['c', 'd'], ['e', 'f']])
    assert tab == ('|a|b|\n'
                   '|:---:|:---:|\n'
                   '|c|d|\n'
                   '|e|f|\n\n')



# Generated at 2022-06-23 15:32:22.594181
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    f = FileFinder(__file__)
    f.find()
    mod = f.read()
    root = 'test.test_parser'
    p = Parser(mod, link=False)

# Generated at 2022-06-23 15:32:25.539108
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    p = Parser(b_level=0, link=True, toc=True)
    assert repr(p).startswith('<Parser: level: 0, link: True, toc: True')


# Generated at 2022-06-23 15:32:34.450696
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    p = Parser(['doc', '-d', '.', '-l', '-t', '-m', '.'])
    #
    #  pytailor/doc.py
    #
    assert p.src['pytailor/doc.py'] == 'doc'
    assert p.pkg['pytailor/doc.py'].name == 'doc'
    assert p.m_src['pytailor/doc.py'] == 'pytailor.doc'
    #
    #  pytailor/constants.py
    #
    assert p.src['pytailor/constants.py'] == 'constants'
    assert p.pkg['pytailor/constants.py'].name == 'constants'

# Generated at 2022-06-23 15:32:37.766469
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("_") == "_"
    assert esc_underscore("__") == r"\__"
    assert esc_underscore("get_the_image") == r"get\_the_image"



# Generated at 2022-06-23 15:32:47.355084
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    p.alias = {
        'ob.x': '23',
        'cls.meth': 'int',
        'cls.meth2': 'str',
        'cls.meth3': 'str',
        'cls.meth4': 'str',
        'cls.meth5': 'str',
        'cls.meth6': 'str',
        'cls.meth7': 'str',
        'cls.meth8': 'cls',
        'cls.meth9': 'cls',
    }
    node = parse('cls, a: int = ob.x, *args, x=5', mode='eval')

# Generated at 2022-06-23 15:32:51.685089
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    node = Cast(parse('typing.Cls').body[0], AST)
    assert Resolver.visit(node, ('a',), {}) == Name('Cls', Load())



# Generated at 2022-06-23 15:32:57.582690
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    import ast
    import sys

    p = Parser({})
    assert p.resolve("a", ast.parse("1").body[0].value) == "1"
    assert (p.resolve("a", ast.parse("int").body[0].value) ==
            "__builtins__.int")
    assert (p.resolve("a", ast.parse("'int'").body[0].value) ==
            "str('int')")

    p = Parser({"a.a": "1", "a.b": "2"})
    assert p.resolve("a", ast.parse("a").body[0].value) == "1"
    assert p.resolve("a", ast.parse("b").body[0].value) == "2"

# Generated at 2022-06-23 15:33:04.530080
# Unit test for function is_public_family
def test_is_public_family():
    assert not is_public_family('abc')
    assert not is_public_family('__init__')
    assert is_public_family('abc.def')
    assert is_public_family('abc.def.def')
    assert not is_public_family('abc._def')
    assert not is_public_family('abc._def.def')
    assert is_public_family('abc.__init__.def')
    assert is_public_family('abc.__init__.__init__')
    assert not is_public_family('abc.__init__._def')



# Generated at 2022-06-23 15:33:09.775028
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    from typechecker import ANY

    p = Parser()
    p.func_api("test", "test", FunctionDef(None, None, None), None, True)
    assert p.doc["test"] == (
        "#### test()\n"
        "\n"
        "*Full name:* `test`\n"
        "\n"
        "| Argument |\n"
        "| :-- |\n"
        "| type[Self] |\n")

    p.func_api("test", "test", FunctionDef(None, None, None), None, False)

# Generated at 2022-06-23 15:33:12.785910
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    p = Parser(True)
    assert p == Parser(True)
    assert p != Parser(False)


# Generated at 2022-06-23 15:33:17.554617
# Unit test for function code
def test_code():
    """Test function code."""
    assert code('a') == '`a`'
    assert code('a.b') == '<code>a.b</code>'
    assert code('a|b') == '<code>a&#124;b</code>'
    assert code('a&b') == '<code>a&amp;b</code>'



# Generated at 2022-06-23 15:33:24.506158
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('_a')
    assert not is_public_family('__a')
    assert is_public_family('a')
    assert is_public_family('a._b')
    assert is_public_family('a.__b')
    assert not is_public_family('a._b.__c')
    assert is_public_family('a.b._c')
    assert not is_public_family('a.b._c.__d')



# Generated at 2022-06-23 15:33:35.496408
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    import os.path
    import astroid
    import builtins

    s = """
    class Foo(Bar, Baz): pass

    class Foo(Bar, Baz):
        """
    m = astroid.parse(s)

    p = Parser(builtins)
    p.class_api(builtins.__name__, m.body[1], m.body[1].bases, m.body[1].body)
    assert p.doc[builtins.__name__ + ".Foo"] == (
        "## class Foo\n\n"
        "*Full name:* `Foo`\n\n"
        "|Bases|\n"
        "|---|\n"
        "|type[Bar]|\n"
        "|type[Baz]|\n\n")
# Unit test

# Generated at 2022-06-23 15:33:45.516670
# Unit test for method imports of class Parser
def test_Parser_imports():

    p = Parser()

    def check_imports(root: str, s: str, alias: dict[str, str]):
        name = _m(root, 'module')
        p.imp[name] = set()
        p.alias[name] = 'module'
        p.alias[name + '.a'] = 'a'
        node = parse(s)
        p.imports(name, node)
        assert p.alias == alias

    check_imports('a', 'import p1', {'a.module': 'p1'})
    check_imports('a', 'import p1.p2', {'a.module': 'p1.p2'})
    check_imports('a', 'import .p1', {'a.module': 'p1'})

# Generated at 2022-06-23 15:33:56.329467
# Unit test for constructor of class Parser
def test_Parser():
    """Unit test for constructor of class Parser."""
    p1 = Parser(False)
    assert p1.link is False
    assert p1.toc is False
    assert p1.const == {}
    assert p1.doc == {}
    assert p1.docstring == {}
    assert p1.alias == {}
    assert p1.imp == {}
    assert p1.root == {}
    assert p1.level == {}
    p2 = Parser(True, True)
    assert p2.link is True
    assert p2.toc is True
    assert p2.const == {}
    assert p2.doc == {}
    assert p2.docstring == {}
    assert p2.alias == {}
    assert p2.imp == {}
    assert p2.root == {}
    assert p2.level == {}


# Generated at 2022-06-23 15:34:02.218849
# Unit test for constructor of class Parser
def test_Parser():
    """Test constructor of class Parser."""
    # fmt: off
    import a  # type: ignore
    parser = Parser(a, ['a'], b_level=1, link=True, toc=True)
    # fmt: on
    assert parser.imp['a'] == {'a'}



# Generated at 2022-06-23 15:34:11.782085
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():

    @dataclass
    class Node:
        lineno: int = 1
        col_offset: int = 1

    assert Resolver("root", {}).visit(Name("a", Load())) == Name("a", Load())

    assert Resolver("typing", {"typing.a": "1"}).visit(Name("a", Load())) == Constant(1)
    assert Resolver("typing", {"typing.a": "1"}).visit(Name("b", Load())) == Name("b", Load())

    assert Resolver("typing", {"typing.a": "b"}).visit(Name("a", Load())) == Name("b", Load())


# Generated at 2022-06-23 15:34:21.440841
# Unit test for method compile of class Parser
def test_Parser_compile():
    # Parser.compile(): no externs
    # Parser.compile(): only docstring
    # Parser.compile(): no docstring
    # Parser.compile(): no __all__
    # Parser.compile(): __all__
    # Parser.compile(): funcs
    # Parser.compile(): funcs, classes
    # Parser.compile(): funcs, classes, nested
    # Parser.compile(): singleton
    assert_equal, expected = AssertEqual(Parser).compile

# Generated at 2022-06-23 15:34:27.915296
# Unit test for function is_public_family
def test_is_public_family():
    assert not is_public_family('__')
    assert is_public_family('_')
    assert is_public_family('__.__')
    assert not is_public_family('_.__')
    assert not is_public_family('_.a')
    assert not is_public_family('a._')
    assert is_public_family('__.a')
    assert is_public_family('a._b')
    assert is_public_family('_a.b')
    assert is_public_family('a._b.c')
    assert is_public_family('a.b._c')
    assert is_public_family('a.b.__c.d')



# Generated at 2022-06-23 15:34:37.975839
# Unit test for function doctest
def test_doctest():
    test_data = [
        "", ">>> a", ">>> a\n>>> b", ">>> a\n>>> b\n\n",
    ]
    for doc in test_data:
        assert doctest(doc) == doc

# Generated at 2022-06-23 15:34:42.309050
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family("builtins.print") == True
    assert is_public_family("math.log") == True
    assert is_public_family("_builtin_print") == False
    assert is_public_family("_math.log") == False
    assert is_public_family("__my_magic__") == True



# Generated at 2022-06-23 15:34:43.994887
# Unit test for function parent
def test_parent():
    """Unit test for function parent"""
    assert parent('a.b.c.d') == 'a.b.c'



# Generated at 2022-06-23 15:34:52.518356
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from . import test_cfg
    import ast
    from dataclasses import dataclass
    from typing import Optional, List, Dict, Any

    @dataclass
    class _arg:
        arg: str
        annotation: Optional[Any]

    def _parse(string: str) -> List[_arg]:
        """Parse argument string."""
        return [_arg(a.arg, a.annotation) for a in ast.parse(
            string,
        ).body[0].bases[0].elts[0].args.args]


# Generated at 2022-06-23 15:35:00.360590
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    ans_b_level = 2
    ans_ignore = {'test.test_test.test_test_test'}
    ans_link = True
    ans_src_dir = '.'
    ans_toc = True
    ans_version = '0.0.0'

    obj = Parser()

    assert obj.b_level == ans_b_level
    assert obj.ignore == ans_ignore
    assert obj.link == ans_link
    assert obj.src_dir == ans_src_dir
    assert obj.toc == ans_toc
    assert obj.version == ans_version

# Generated at 2022-06-23 15:35:12.946883
# Unit test for function const_type
def test_const_type():
    assert const_type(parse("[1, 2, 3]").body[0].value) == "[int]"
    assert const_type(parse("{1, 2, 3}").body[0].value) == "set[int]"
    assert const_type(parse("(1, 2, 3)").body[0].value) == "tuple[int]"
    assert const_type(parse("{1: 2, 3: 4}").body[0].value) == "dict[int, int]"
    assert const_type(parse("{1: 2, 3: 4.5}").body[0].value) == "dict[int, Any]"
    assert const_type(parse("bool(1)").body[0].value) == "bool"

# Generated at 2022-06-23 15:35:14.829444
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    p = Parser()
    assert repr(p) == "<Parser()>"


# Generated at 2022-06-23 15:35:17.195955
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    import tests.conftest

    parser.parse(tests.conftest)
    assert parser.compile

# Generated at 2022-06-23 15:35:17.878672
# Unit test for method imports of class Parser
def test_Parser_imports():
    pass

# Generated at 2022-06-23 15:35:29.043487
# Unit test for function walk_body
def test_walk_body():
    class Test1:
        def __init__(self, value: int):
            self.value = value

        def test(self):
            if self.value >= 0:
                self.value += 1
                if self.value >= 3:
                    self.value += 20
                    return self.value
                else:
                    return "..."
            else:
                try:
                    self.value += 1
                except TypeError:
                    self.value -= 1
                except ValueError:
                    self.value -= 20
                else:
                    self.value += 1
                finally:
                    self.value += 1
    node = parse(getdoc(Test1)).body
    assert all(isinstance(n, If) for n in node[0].body)

# Generated at 2022-06-23 15:35:40.245763
# Unit test for function doctest
def test_doctest():
    doc = """
    >>> a = 3
    >>> b = 2
    >>> c = a + b
    """
    target = r"""
    ```python
    >>> a = 3
    >>> b = 2
    >>> c = a + b
    ```
    """
    assert doctest(doc) == target
    doc = """
    >>> a = 3
    >>> a + b
    >>> b = 2
    >>> c = a + b
    """
    target = r"""
    ```python
    >>> a = 3
    >>> a + b
    >>> b = 2
    >>> c = a + b
    ```
    """
    assert doctest(doc) == target
    doc = """
    >>> a = 3
    >>> a + b
    >>> b = 2
    """

# Generated at 2022-06-23 15:35:41.626582
# Unit test for method parse of class Parser

# Generated at 2022-06-23 15:35:53.918091
# Unit test for constructor of class Resolver
def test_Resolver():
    main = Resolver('__main__', {})
    # Constant -> Name
    assert main.visit(Constant("test")) == Name("test", Load())
    # Constant -> Attribute
    assert main.visit(Constant("typing.test")) == Name("test", Load())
    # Constant -> Subscript
    assert main.visit(Constant("typing.test[1, 2]")) == Subscript(
        Name("test", Load()),
        Tuple(
            elts=[Constant(1), Constant(2)],
            ctx=Load(),
        ),
        Load(),
    )
    # Constant -> BinOp
    assert main.visit(Constant("typing.Optional[int]")) == BinOp(
        Name("int", Load()),
        BitOr(),
        Constant(None)
    )

# Generated at 2022-06-23 15:36:06.280628
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    p = Parser()
    class C:
        def func():
            pass

    p.class_api('', ClassDef(name='C',
                             body=[FunctionDef(name='func',
                                               body=[Pass()])],
                             decorator_list=[]),
                [],
                [FunctionDef(name='func',
                             body=[Pass()])])
    assert p.doc['C'] == """## class C

*Full name:* `C`

**Members**

+ `func`
"""

# Generated at 2022-06-23 15:36:15.648740
# Unit test for function walk_body
def test_walk_body():
    assert list(walk_body(
        [
            If(Constant(True), [If(Constant(False), [], [])], []),
            Try([], [arguments(args=[arg('e', None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])], [], [], []),
        ]
    )) == [
        If(Constant(True), [], []),
        If(Constant(False), [], []),
        Try([], [arguments(args=[arg('e', None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])], [], [], []),
    ]



# Generated at 2022-06-23 15:36:27.617137
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    parser = Parser(pathlib.Path('.'), link=True)
    def test(args: Sequence[arg], has_self: bool, cls_method: bool) -> str:
        return ''.join(parser.func_ann('root', args, has_self=has_self,
                                       cls_method=cls_method))
    assert test((arg('a', 'int'),), False, False) == 'int'
    assert test((arg('self'), arg('a', 'self.A')), True, False) == 'Self'
    assert test((arg('a', 'b'),), False, False) == 'b'
    assert test((arg('a', 'self.a'),), True, False) == 'self.a'
    assert test((arg('a', 'self.a'),), True, True) == 'Self'

# Generated at 2022-06-23 15:36:37.041834
# Unit test for constructor of class Parser
def test_Parser():
    def gen_code(
            import_name: List[str],
            package_name: str,
            code_name: str,
        ) -> str:
        code = ''
        if import_name:
            code += "import " + ", ".join(import_name) + "\n\n"
        code += "# Docstring\n"
        code += f"class {package_name + '.' + code_name}:\n"
        code += "    # Docstring\n"
        code += "    def __init__(self):\n"
        code += f"        self.name = '{code_name}'\n"
        code += f"    def __call__(self, a: {package_name + '.' + code_name}) -> {package_name + '.' + code_name}: ...\n"


# Generated at 2022-06-23 15:36:46.278385
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('numpy')
    assert is_public_family('numpy.pi')
    assert is_public_family('numpy.random._bit_generator')
    assert is_public_family('_lib.path.os')
    assert not is_public_family('_lib.path._os')
    assert not is_public_family('_lib._path.os')
    assert not is_public_family('lib.__path.os')
    assert not is_public_family('lib._path.__os')
# End unit test



# Generated at 2022-06-23 15:36:57.053994
# Unit test for function walk_body

# Generated at 2022-06-23 15:37:02.496762
# Unit test for function walk_body
def test_walk_body():
    from ast import parse, Assign, If, Try, Constant, Expr

    def test():
        a = 1
        if a:
            b = 2
            try:
                c = 3
                print(c)
            except:
                pass
        d = 4

    for d in walk_body(parse(getdoc(test)).body):
        assert isinstance(d, Expr)
        assert isinstance(d.value, Constant)
        assert d.value.value in (1, 2, 3, 4)



# Generated at 2022-06-23 15:37:11.035153
# Unit test for method parse of class Parser
def test_Parser_parse():
    """Test ``parse`` method of Parser class."""
    root = '__test__.A'
    parser = Parser(link=True)
    parser.parse(root, A)

# Generated at 2022-06-23 15:37:17.876621
# Unit test for function doctest
def test_doctest():
    assert doctest("Hello\n>>> 1\n1\n") == ("Hello\n"
                                           "```python\n"
                                           ">>> 1\n"
                                           "1\n"
                                           "```")
    assert doctest("Hello\n>>> 1\n1\n>>> 2\n2\n") == ("Hello\n"
                                                      "```python\n"
                                                      ">>> 1\n"
                                                      "1\n"
                                                      ">>> 2\n"
                                                      "2\n"
                                                      "```")

# Generated at 2022-06-23 15:37:20.512901
# Unit test for function parent
def test_parent():
    assert parent('pyslvs_ui.panels.solver') == 'pyslvs_ui.panels'

# Generated at 2022-06-23 15:37:26.516394
# Unit test for function walk_body
def test_walk_body():
    source = """
if True:
    class A: ...
else:
    class A: ...
try:
    class A: ...
except AssertionError:
    class A: ...
else:
    class B: ...
finally:
    class C: ...
"""
    class_body = [c for c in walk_body(parse(source).body) if isinstance(c, ClassDef)]
    assert len(class_body) == 6
    assert len(class_body) == sum(1 for c in class_body if isinstance(c, ClassDef))



# Generated at 2022-06-23 15:37:37.027684
# Unit test for function walk_body
def test_walk_body():
    # Basic example
    s = parse('''\
if a:
    try:
        pass
    except:
        pass
else:
    pass
''').body
    assert unparse(list(walk_body(s))).strip() == unparse(s).strip()

    # Complex example
    s = parse('''\
if a:
    try:
        pass
    except:
        pass
else:
    if b:
        pass
    else:
        try:
            pass
        except:
            pass
    try:
        pass
    except:
        pass
    finally:
        pass
''').body
    assert unparse(list(walk_body(s))).strip() == unparse(s).strip()
test_walk_body()



# Generated at 2022-06-23 15:37:49.335368
# Unit test for function walk_body
def test_walk_body():
    """Test for walk body."""
    body = parse("""
if x:
    a = 0
else:
    a = 1
    try:
        a = 2
    except:
        a = 3
    finally:
        a = 4
        if y:
            a = 5
""").body  # type: ignore
    body = [cast(If, body[0])]
    assert code(unparse(body[0])) == 'a = 0 if x else 1'
    assert code(unparse(body[0].orelse[0])) == 'a = 2'
    assert code(unparse(body[0].orelse[1])) == 'a = 4'
    assert code(unparse(body[0].orelse[2])) == 'a = 5 if y else 4'

# Generated at 2022-06-23 15:37:55.866406
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    @dataclass
    class R:
        root = ""
        alias = {}
        self_ty = "T"
    r = R("", {}, "T")
    resolver = Resolver("", {}, "T")
    t = resolver.visit(r)
    assert t == r

# Generated at 2022-06-23 15:38:03.189752
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser().alias == {}
    assert Parser().const == {}
    assert Parser().root == {}
    assert Parser().imp == defaultdict(set)
    assert Parser().level == {}
    assert Parser().doc == {}
    assert Parser().docstring == {}
    assert Parser().link is False
    assert Parser().toc is False
    assert Parser(link=True).link is True
    assert Parser(toc=True).toc is True
    assert Parser(link=True, toc=True).link is True
    assert Parser(link=True, toc=True).toc is True


# Generated at 2022-06-23 15:38:09.560760
# Unit test for function walk_body

# Generated at 2022-06-23 15:38:15.779892
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert len(p.alias) == 0
    assert len(p.doc) == 0
    assert len(p.docstring) == 0
    assert len(p.root) == 0
    assert len(p.level) == 0
    assert len(p.imp) == 0
    assert len(p.const) == 0



# Generated at 2022-06-23 15:38:20.950614
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__test__') is True
    assert is_magic('test') is False
    assert is_magic('__test') is False
    assert is_magic('test__') is False
    assert is_magic('__test.__init__') is True
    assert is_magic('__test.test') is False



# Generated at 2022-06-23 15:38:26.073091
# Unit test for method compile of class Parser
def test_Parser_compile():
    """Test compile."""
    file = 'test_data/test_doc.py'
    cwd = os.getcwd()
    file = os.path.join(cwd, file)
    with open(file, 'r') as f:
        parser = Parser()
        parser.add_file(f.name)
        doc = parser.compile()
        print(doc)

# Generated at 2022-06-23 15:38:34.579351
# Unit test for function table
def test_table():
    assert table('a', items=['b', 'c']) == '\n'.join(
        ('| a ', '|:---:|', '| b ', '| c ')
    ) + '\n\n'
    assert table('a', 'b', items=[['c', 'd'], ['e', 'f']]) == '\n'.join(
        ('| a | b ', '|:---:|:---:|', '| c | d ', '| e | f ')
    ) + '\n\n'



# Generated at 2022-06-23 15:38:39.601215
# Unit test for function walk_body
def test_walk_body():
    @dataclass
    class Node:
        body: Sequence[Node]
    node = Node([Node([Node([])])])
    assert len(list(walk_body([node]))) == 3
    assert len(list(walk_body([cast(AST, node)]))) == 0



# Generated at 2022-06-23 15:38:50.085516
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    p = Parser()
    t1 = """class A:
    class B:
        x: int
        y: str = 'a'
    a: str
    b: int = 1
"""
    t2 = """class A:
    a: str
    b: int
    @property
    def c(self) -> int: ...
    @staticmethod
    def d() -> None: ...
    @classmethod
    def e(cls) -> None: ...
"""
    t3 = """class A:
    class B:
        x: int
        y: str
    @property
    def c(self) -> int: ...
    @staticmethod
    def d() -> None: ...
    @classmethod
    def e(cls) -> None: ...
"""

# Generated at 2022-06-23 15:38:55.483987
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    from doct._parser import Parser
    global alias, doc, level, root
    alias = {}
    doc = {}
    level = {}
    root = {}
    p = Parser()

    import ast
    p.class_api('', ast.ClassDef('test', [], [], [], []), [], [])
    assert doc == {'test': '# class test\n\n*Full name:* `test`\n\n'}
    assert root == {'test': ''}
    assert level == {'test': 0}

    p.doc = {}
    p.root = {}
    p.level = {}

    from astroid import nodes
    from astroid.scoped_nodes import Class
    p.class_api('', Class('test', [], [], [], [], None), [], [])


# Generated at 2022-06-23 15:39:04.820266
# Unit test for function walk_body
def test_walk_body():
    def foo(a: int, b: int = 5) -> int:
        """Foo"""
        if a > 5:
            c = a
        else:
            try:
                if a < 10:
                    c = a - 1
                else:
                    c = a + 1
            except ZeroDivisionError:
                c = a
            except KeyboardInterrupt:
                c = a - 1
            else:
                c = a + 1
            finally:
                pass
        return c

    assert getdoc(foo) == "Foo"
    assert foo.__annotations__["return"] == int
    assert tuple(foo.__annotations__["a"] for foo in walk_body(foo.__code__.co_consts[1])) == (int,) * 3



# Generated at 2022-06-23 15:39:10.805442
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    import types
    mod = types.ModuleType('test')
    mod.__file__ = 'test'
    mod.__doc__ = 'test'
    p = Parser(link=False)
    p.load_docstring('test', mod)
    assert p.docstring['test'] == 'test'

# Generated at 2022-06-23 15:39:23.332557
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    import _ast
    import inspect
    class FunctionDef(tuple):
        def __new__(cls, *args):
            return super().__new__(cls, args)
        @property
        def fun_args(self):
            return self[0]
        @property
        def fun_ann(self):
            return self[1]
        @property
        def fun_defaults(self):
            return self[2]
        @property
        def fun_return(self):
            return self[3]
        @property
        def fun_name(self):
            return self[4]
        @property
        def fun_module(self):
            return self[5]
        @property
        def fun_has_self(self):
            return self[6]

# Generated at 2022-06-23 15:39:30.619426
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    from ast import ClassDef, Name, arguments
    p = Parser(set())
    c = ClassDef(
        name='A',
        bases=[Name(id='B', ctx=None), Name(id='C', ctx=None)],
        body=[
            arguments(
                posonlyargs=[], args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])
        ])
    doc = p.class_api('A', 'A', c.bases, c.body)
    assert doc == ""

    p = Parser(set())
    c = ClassDef(
        name='A',
        bases=[Name(id='B', ctx=None), Name(id='C', ctx=None)],
        body=[])
    doc = p.class_

# Generated at 2022-06-23 15:39:35.804539
# Unit test for method globals of class Parser
def test_Parser_globals():
    from .doc import doclex
    from .doc import docpar
    from .doc import docstr
    from .doc import doctest
    from ast import Module
    from ast import parse
    from ast import walk
    from typing import List

# Generated at 2022-06-23 15:39:45.440077
# Unit test for constructor of class Parser
def test_Parser():
    """Test class Parser."""
    import mypy.errors
    from mypy.build import Source, find_module_types, build
    from mypy.types import TupleType, Instance, CallableType, TypeOfAny, ListType, \
        TypeVar, TypeType, UnionType, DictType, AnyType, NoneTyp, TypeVarDef, \
        PlaceholderType, TypeQuery, TypeTranslator, Overloaded
    from mypy.nodes import ARG_POS, ARG_NAMED, ARG_NAMED_OPT, ARG_STAR, ARG_STAR2, NoneExpr, \
        IntExpr, StrExpr, FuncDef, Decorator, LambdaExpr
    from mypy.plugin import Plugin, MethodContext
    from mypy.typevars import fill_typevars

# Generated at 2022-06-23 15:39:49.329966
# Unit test for constructor of class Resolver
def test_Resolver():
    """Test the constructor of class Resolver."""
    node = Attribute(Name("typing", Load()), "Union", Load())
    r = Resolver("test", dict())
    assert isinstance(r.visit(node), Name)


T = TypeVar("T")



# Generated at 2022-06-23 15:39:53.169146
# Unit test for function code
def test_code():
    assert code('a') == "`a`"
    assert code('a|b') == "<code>a&#124;b</code>"
    assert code('a&b') == "<code>a&amp;b</code>"
    assert code('') == " "



# Generated at 2022-06-23 15:39:58.331619
# Unit test for method globals of class Parser
def test_Parser_globals():
    import re

    def match(name: str, doc: str) -> bool:
        return bool(re.search(r'\n\n\*Full name:* `' + name + r'`\n\n', doc))

    r"""
Globals:

+ Type alias
+ Constants
+ `__all__` filter
    """
    root = 'test'
    imp = {root: set()}
    alias = {}
    doc = {}
    root_doc = '# Root\n\n'
    const = {}
    level = {}
    level[root] = 0
    p = Parser(imp, alias, doc, level, root_doc, const)
    p.globals(root, parse('''
        a: int = 1
        b: str = ""
        '''))
   

# Generated at 2022-06-23 15:40:03.409606
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
  parser = Parser()
  assert parser.func_ann('mylib', [arg('a', None), arg('b', None)], has_self=True, cls_method=True) == ('type[Self]', 'object', 'object')
  