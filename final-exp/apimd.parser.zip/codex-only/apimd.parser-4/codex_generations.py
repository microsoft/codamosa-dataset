

# Generated at 2022-06-23 15:30:12.347074
# Unit test for method imports of class Parser
def test_Parser_imports():
    root = 'a'
    node = Import()
    node.names = [alias(name='b')]
    t = Parser()
    t.imports(root, node)
    assert t.alias == {'a.b': 'b'}
    node = ImportFrom(module='types', names=[alias(name='Tuple')], level=1)
    t = Parser()
    t.imports(root, node)
    assert t.alias == {'a.Tuple': 'types.Tuple'}
    node = ImportFrom(module='types', names=[alias(name='Tuple')], level=2)
    t = Parser()
    t.imports(root, node)
    assert t.alias == {'a.Tuple': 'parent.types.Tuple'}

# Generated at 2022-06-23 15:30:24.271442
# Unit test for method imports of class Parser
def test_Parser_imports():
    from .test_pep import f_module, f_module_2
    print('Start testing tests.test_pep.Parser.imports')
    p = Parser(verbose=True)
    p.imports(f_module, f_module.body[0])
    assert p.alias == {'requests.request': 'request',
                       'requests.get': 'get'}
    p.alias = {}
    p.imports(f_module, f_module.body[1])
    assert p.alias == {'requests.request': 'requests.request',
                       'requests.get': 'requests.get'}
    p.alias = {}
    p.imports(f_module, f_module.body[2])

# Generated at 2022-06-23 15:30:32.000394
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    p.root['foo'] = 'foo'
    p.imp['foo'] = {'foo', 'foo.bar', 'foo.bar.baz'}
    assert p.is_public('foo')
    assert not p.is_public('foo.baz')
    assert p.is_public('foo.bar')
    assert p.is_public('foo.bar.baz')
    assert p.is_public('foo.Bar')
    assert not p.is_public('foo.Bar.Baz')
    assert p.is_public('foo.foo')
    assert not p.is_public('foo.foo.foo')
    p.imp['foo'] = set()
    assert p.is_public('foo.Foo')
    assert p.is_public('foo.foo')
   

# Generated at 2022-06-23 15:30:36.655581
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert isinstance(Resolver("mod", {}).visit_Attribute(Attribute(Name("typing", Load()), "Optional", Load())), Name)
    assert isinstance(Resolver("mod", {}).visit_Attribute(Attribute(Name("mod", Load()), "Optional", Load())), Attribute)
    return True


# Generated at 2022-06-23 15:30:42.545500
# Unit test for function table
def test_table():
    """Unit test for table."""
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == \
        "| a | b |\n" \
        "|:---:|:---:|\n" \
        "| c | d |\n" \
        "| e | f |\n\n"



# Generated at 2022-06-23 15:30:45.607112
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("a_b") == "a_b"
    assert esc_underscore("a_b_c") == "a\\_b\\_c"
    assert esc_underscore("_") == "_"



# Generated at 2022-06-23 15:30:49.579456
# Unit test for method globals of class Parser
def test_Parser_globals():
    """Test method globals of class Parser"""

# Generated at 2022-06-23 15:30:54.760996
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser(2, False)
    root = 'package.module'
    name = _m(root, 'func')
    args = [arg('a', None), arg('*b', None), arg('**c', None), arg('return', None)]
    p.func_api(root, name, args, None, has_self=False, cls_method=False)

# Generated at 2022-06-23 15:30:59.948757
# Unit test for method compile of class Parser
def test_Parser_compile():
    from jupyter_sphinxcontrib.loader import load
    m = load('__main__')
    # m = load('jupyter_sphinxcontrib.loader')
    p = Parser(m)
    p.parse()
    print(p.compile())

# Generated at 2022-06-23 15:31:05.778995
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__a__')
    assert is_magic('abc.__a__')
    assert is_magic('abc.__a__.b')
    assert not is_magic('abc.__a')
    assert not is_magic('abc.__a_b__')
    assert not is_magic('abc.a__')
    assert not is_magic('abc.a__b')



# Generated at 2022-06-23 15:31:18.136648
# Unit test for method is_public of class Parser

# Generated at 2022-06-23 15:31:20.325821
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__init__')
    assert is_magic('abcabc')
    assert not is_magic('__abc__')
    assert not is_magic('abc')



# Generated at 2022-06-23 15:31:23.442140
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    p = Parser('a')
    p1 = Parser('b')
    assert p == p
    assert not p == p1


# Generated at 2022-06-23 15:31:29.365662
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    def func(a1: str, a2=None, *args, a3, a4=True, **kwargs):
        pass
    class T(Parser):
        def resolve(self, root, node, self_ty):
            return unparse(node)
    p = T({}, {}, {})
    assert p.func_ann('', func.__annotations__['return'].__args__)



# Generated at 2022-06-23 15:31:35.586675
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('__init__')
    assert is_public_family('__pyslvs')
    assert not is_public_family('_private_name')
    assert not is_public_family('local_name')
    assert not is_public_family('module._private_name')
    assert is_public_family('module.public_name')
    assert not is_public_family('module._private_name.child')
    assert is_public_family('module.public_name.child')



# Generated at 2022-06-23 15:31:36.776851
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    parser = Parser()
    assert parser

# Generated at 2022-06-23 15:31:40.198464
# Unit test for function table
def test_table():
    test_table.__doc__ = table('a', 'b', [['c', 'd'], ['e', 'f']])
    assert test_table.__doc__ == '\n'.join([
        '| a | b |',
        '|:---:|:---:|',
        '| c | d |',
        '| e | f |',
        '\n'
    ])



# Generated at 2022-06-23 15:31:50.567180
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser()
    a = FormattedText(f'This is the docstring.\n\n{code("1 + 1")}')

    # Define method
    name = 'p.func_api'

    # Define argument
    root = 'unittest_root'
    name = 'unittest_name'

# Generated at 2022-06-23 15:31:58.973354
# Unit test for method func_api of class Parser
def test_Parser_func_api():
  from typing import List, Optional, Union
  from astparse._ast import ClassDef, FunctionDef, NodeVisitor, parse

  def func_api(root: str, name: str, node: arguments,
                 returns: Optional[expr], *,
                 has_self: bool, cls_method: bool) -> None:
      args = []
      default: List[Optional[expr]] = []
      if node.posonlyargs:
          args.extend(node.posonlyargs)
          args.append(arg('/', None))
          default.extend([None] * len(node.posonlyargs))
      args.extend(node.args)
      default.extend([None] * (len(node.args) - len(node.defaults)))
      default.extend(node.defaults)

# Generated at 2022-06-23 15:32:06.123406
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    from . import app
    import tempfile
    import functools
    import inspect
    parser = Parser(b_level=0, toc=False, url_root="https://github.com/snakemake/snakemake/blob/develop/")
    with tempfile.TemporaryDirectory() as td:
        with open(os.path.join(td, 'test.py'), 'w') as f:
            f.write(doctest(inspect.getsource(app.main)))
        (m, doc) = parser.parse(td, root='test.py:main')
        assert doc == ""

# Generated at 2022-06-23 15:32:13.282473
# Unit test for function walk_body
def test_walk_body():
    # pylint: disable=unused-variable,expression-not-assigned
    a = 1
    if a == 1:
        b = 2
        print(b)
    try:
        b = 3
    except Exception:
        b = 4
    else:
        b = 5
        print(b)
    finally:
        b = 6
        print(b)



# Generated at 2022-06-23 15:32:22.792573
# Unit test for method globals of class Parser
def test_Parser_globals():
    global names
    global type_mapping
    p = Parser()
    s = """
    # Type alias
    Point = Tuple[int, int]
    # Constants
    N = 1
    __all__ = ('N',)
    """
    node = ast.parse(s)
    p.globals('__main__', node.body[0])
    p.globals('__main__', node.body[1])
    p.globals('__main__', node.body[2])
    assert p.alias == {'__main__.N': '1', '__main__.Point': 'Tuple[int, int]'}
    assert p.imp == {'__main__': {'__main__.N'}}

# Generated at 2022-06-23 15:32:31.533756
# Unit test for method parse of class Parser
def test_Parser_parse():
    from ..doc import Doc
    from ..docstring import Docstring
    import itertools

# Generated at 2022-06-23 15:32:38.752555
# Unit test for method imports of class Parser
def test_Parser_imports():
    p = Parser()
    node = parse('''
a = 1
import math
from os import path as p
from sys import *
''')
    p.imports('test', node)

# Generated at 2022-06-23 15:32:44.652396
# Unit test for function esc_underscore
def test_esc_underscore():
    output = "esc\_underscore"
    assert esc_underscore('esc_underscore') == output
    assert esc_underscore('esc_under_score') == output
    assert esc_underscore('esc') == output
    assert esc_underscore('esc_') == output
    assert esc_underscore('') == ''

# Generated at 2022-06-23 15:32:48.353864
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    """Test method Parser.__repr__."""
    p = Parser()
    p.alias = {}
    assert str(p) == 'Parser{alias: {}, imp: {}, doc: {}, const: {}, docstring: {}, level: {}, root: {}}'
    p.alias = {'a': 'b'}
    assert str(p) == "Parser{alias: {'a': 'b'}, imp: {}, doc: {}, const: {}, docstring: {}, level: {}, root: {}}"

# Generated at 2022-06-23 15:32:58.930097
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    from typing import Dict, List, Set, Tuple

    import astor

    def __test(test_case: Dict[str, List[str]], *,
               bases: List[str] = []) -> bool:
        clss = {}
        for name, doc in test_case.items():
            clss[name] = astor.parse_file(io.StringIO(doc)).body[0]
        parser = Parser()
        for name, c in clss.items():
            parser.class_api('', name, bases=list(map(ast.parse, bases)),
                             body=c.body)
        for name, c in clss.items():
            doc = parser.doc[name]

# Generated at 2022-06-23 15:33:06.507030
# Unit test for method api of class Parser
def test_Parser_api():
    from dataclasses import dataclass
    from typing import List, Union
    from .test.test_parser import Module, ClassDef, arguments, arg, FunctionDef

    @dataclass
    class Resolver:
        """Fake Resolver object."""
        root: str
        alias: dict[str, str]
        self_ty: str = ""

        @classmethod
        def visit(cls, node: _T) -> _T:
            """Visit node."""
            return node

        def generic_visit(self, node: _T) -> _T:
            """Generic visit node."""
            if isinstance(node, Name):
                return Name(self.alias[node.id], node.ctx)
            return node

    p = Parser(None, link=False)

# Generated at 2022-06-23 15:33:09.042874
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    node = parse("'list'", mode="eval").body
    assert Resolver(None, {}).visit(node) == Name("list", Load())


# Generated at 2022-06-23 15:33:19.188388
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert unparse(Resolver('abc', {'abc': {'abc': 'def'}}).visit(Name('abc', Load()))) == 'def'
    assert unparse(Resolver('abc', {'abc': {'abc': 'def'}}).visit(Name('xyz', Load()))) == 'xyz'
    assert unparse(Resolver('abc', {'abc': {'abc': 'def'}}).visit(Name('xyz', Load()))) == 'xyz'
    assert unparse(Resolver('abc', {'abc.abc': {'abc.abc': 'def'}}).visit(Name('abc.abc', Load()))) == 'def'

# Generated at 2022-06-23 15:33:30.287975
# Unit test for function walk_body
def test_walk_body():
    a = stmt(
        """
        if c:
            a = 1
            try:
                a = 2
            except:
                a = 3
            else:
                a = 4
            finally:
                a = 5
        else:
            a = 6
        """
    )

# Generated at 2022-06-23 15:33:38.545051
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    """Test visit_Name of Resolver."""
    import ast
    import typing
    alias = {'__main__.a': 'typing.List[int]', 'typing.List': 'typing.List'}
    assert ast.dump((Resolver('__main__', alias)).visit_Name(Name('a', Load()))) == \
        "Name(id='typing.List', ctx=Load())"
    assert ast.dump((Resolver('__main__', alias)).visit_Name(Name('List', Load()))) == \
        "Name(id='List', ctx=Load())"



# Generated at 2022-06-23 15:33:42.513093
# Unit test for function is_magic

# Generated at 2022-06-23 15:33:46.109561
# Unit test for method api of class Parser
def test_Parser_api():
    assert Parser.api.__doc__.startswith(
        "Create API doc for only functions and classes.")
    assert Parser.api.__doc__.endswith(
        "Where `name` is the full name.\n    ")

# Generated at 2022-06-23 15:33:56.988763
# Unit test for function walk_body
def test_walk_body():
    # If
    assert tuple(walk_body([
        If(Constant(0), [If(Constant(1), [Assign([Name("a", Load())], Constant(1))])], []),
        Assign([Name("b", Load())], Constant(2)),
    ])) == (
        Assign(targets=[Name(id='a', ctx=Load())], value=Constant(1)),
        Assign(targets=[Name(id='b', ctx=Load())], value=Constant(2)),
    )
    # Try

# Generated at 2022-06-23 15:34:08.245133
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    p.alias = {"a.b.C": "a.b.C", "a.b.D": "a.b.C", "a.b.E": "a.b.E"}
    p.imp = {"a.b": {"C", "E"}}
    p.root = {"a.b.C": "a.b", "a.b.D": "a.b", "a.b.E": "a.b"}
    assert p.is_public("a.b.C") == True
    assert p.is_public("a.b.D") == True
    assert p.is_public("a.b.E") == True
    assert p.is_public("a.b.F") == False
test_Parser_is_public()

# Generated at 2022-06-23 15:34:18.364021
# Unit test for function const_type
def test_const_type():
    def t(node: expr, nw: str) -> None:
        assert const_type(node) == nw
    t(Constant(118), 'int')
    t(Constant(False), 'bool')
    t(Constant(118.5), 'float')
    t(Constant(0.5+0.5j), 'complex')
    t(Constant(0.5j), 'complex')
    t(Constant('test'), 'str')
    t(Constant(None), ANY)
    t(Constant((1, 2)), 'tuple[int, int]')
    t(Constant([1, 2]), 'list[int, int]')
    t(Constant({1, 2}), 'set[int]')

# Generated at 2022-06-23 15:34:28.534767
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    # @add_doc(a='1')
    # class A:
    #    @add_doc(b=2)
    #     def b(self):
    #         pass
    from add_doc import add_doc
    
    def test_init():
        p = Parser(None)
        assert p
    
    def test_bases_and_decorators():
        class A:
            pass
        
        @add_doc(a='1')
        class A:
            @add_doc(b=2)
            def b(self):
                pass
        
        p = Parser(A)
        assert p.bases(A) == []
        assert p.decorators(A) == ['add_doc(a=\'1\')']
        assert p.decorators(A.b)

# Generated at 2022-06-23 15:34:38.484308
# Unit test for constructor of class Parser

# Generated at 2022-06-23 15:34:45.389565
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser(link=False)
    p.imp['test_module'] = set()
    assert p.is_public('test_module')
    assert p.is_public('test_module.public_name')
    assert p.is_public('test_module.private_name')
    p.imp['test_module'] = {'test_module.public_name'}
    assert p.is_public('test_module')
    assert p.is_public('test_module.public_name')
    assert not p.is_public('test_module.private_name')



# Generated at 2022-06-23 15:34:54.327616
# Unit test for constructor of class Resolver
def test_Resolver():
    """Unit test for constructor of class Resolver."""

# Generated at 2022-06-23 15:35:00.999848
# Unit test for method parse of class Parser
def test_Parser_parse():
    from otils.utils import get_project_dir, get_module
    from otils.core import Module
    parser = Parser(link=False, toc=False, all=False)
    
    parser.parse(get_module(Module))

    assert parser.alias[Module.__name__] == 'otils.core.Module'
    assert parser.alias[Module.__qualname__] == 'otils.core.Module'
    assert parser.alias[Module.__name__ + '.__new__'] == 'otils.core.Module.__new__'
    assert parser.alias[Module.__name__ + '.__call__'] == 'otils.core.Module.__call__'
    assert parser.alias[Module.__name__ + '.__init__'] == 'otils.core.Module.__init__'
   

# Generated at 2022-06-23 15:35:07.546693
# Unit test for function code
def test_code():
    assert code('a') == '`a`'
    assert code('a | b') == '<code>a &#124; b</code>'
    assert code('a & b') == '<code>a &amp; b</code>'
    assert code('a && b') == '`a &amp;&amp; b`'
    assert code('') == ' '



# Generated at 2022-06-23 15:35:11.996593
# Unit test for function code
def test_code():
    assert code('123') == '`123`'
    assert code('123|456') == '<code>123&#124;456</code>'
    assert code('123&456') == '<code>123&amp;456</code>'
    assert code('') == ' '

T = TypeVar('T')



# Generated at 2022-06-23 15:35:12.835388
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    parser = Parser(False)


# Generated at 2022-06-23 15:35:23.434861
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    import ast
    import typing
    ast_node = Resolver("", {}).visit(ast.parse("typing.Pattern").body[0].value)
    assert isinstance(ast_node, ast.Name)
    assert ast_node.id == "Pattern"
    ast_node = Resolver("", {}).visit(ast.parse("typing.Optional[str]").body[0].value)
    assert isinstance(ast_node, ast.BinOp)
    assert isinstance(ast_node.right, ast.Constant)
    assert ast_node.right.value == None
    assert isinstance(ast_node.left, ast.Subscript)
    assert isinstance(ast_node.left.slice, ast.Index)
    assert isinstance(ast_node.left.slice.value, ast.Name)

# Generated at 2022-06-23 15:35:25.531810
# Unit test for function table
def test_table():
    table('a', 'b', [['c', 'd'], ['e', 'f']])



# Generated at 2022-06-23 15:35:30.688594
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    """Test for method __post_init__."""
    parser = Parser([TestData(root='a', body=[])])
    assert parser.imp == {'a':set()}
    parser = Parser([TestData(root='b', body=[])])
    assert parser.imp == {'b':set()}

# Generated at 2022-06-23 15:35:41.627113
# Unit test for constructor of class Resolver
def test_Resolver():
    """Test Resolver constructor."""
    # Get the root of this module
    this = _m('pyslvs_ui', 'pyslvs', 'dynablock')

    # Test TypeVar
    r = Resolver(this, {'typing.TypeVar': 'typing.TypeVar'})
    t = Assign(
        targets=[Name("t", Store())],
        value=Subscript(
            value=Name("typing", Load()),
            slice=arg(arg="t", annotation="typing.TypeVar"),
            ctx=Load()
        )
    )
    assert eval(unparse(r.visit(t))) == t

    # Test Union
    r = Resolver(this, {'typing.Union': 'typing.Union'})

# Generated at 2022-06-23 15:35:51.636596
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    doc: Parser = Parser()
    doc.root['p.m'] = 'p'
    doc.root['p.s'] = 'p'
    doc.imp['p'] = {'p', 'p.s'}
    doc.imp['p.m'] = {'p.m'}
    assert doc.is_public('p.m')
    assert doc.is_public('p.s')
    assert not doc.is_public('p')
    doc.imp['p.m'] = set()
    assert not doc.is_public('p.m')


# Generated at 2022-06-23 15:35:57.183813
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    p = Parser()
    p.alias['root.a'] = 'root.b'
    p.alias['root.b'] = 'root.c'
    p.alias['root.c'] = 'root.d'
    p.alias['root.d'] = 'root.e'
    assert p.resolve('root', Name(id='a', ctx=Load())) == 'root.d'

    p.alias['root.a'] = 'a.b'
    p.alias['a.b'] = 'b.c'
    p.alias['b.c'] = 'c.d'
    assert p.resolve('root', Name(id='a', ctx=Load())) == 'c.d.b'

    p.alias['root.a'] = 'root.b.a'
    p.alias

# Generated at 2022-06-23 15:36:06.776672
# Unit test for function table
def test_table():
    from inspect import cleandoc
    from unittest import TestCase, main
    from io import StringIO
    from contextlib import redirect_stdout
    test = TestCase()
    with redirect_stdout(StringIO()) as stream:
        table('a', 'b', [['c', 'd'], ['e', 'f']])
        test.assertEqual(cleandoc(stream.getvalue()), """
        | a | b |
        |:---:|:---:|
        | c | d |
        | e | f |
        """.strip())
    main()



# Generated at 2022-06-23 15:36:16.510144
# Unit test for method api of class Parser
def test_Parser_api():
    # pylint: disable=c-extension-no-member
    # pylint: disable=protected-access
    p = Parser()
    # Unit test for method func_api of class Parser
    def test_func_api():
        # Unit test for method __init__ of class FunctionDef
        def func1(self):
            pass
        # Unit test for method __init__ of class FunctionDef

# Generated at 2022-06-23 15:36:27.995049
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    def visit(name, slice) -> AST:
        return Resolver('typing', {
            'typing.Union': 'typing.Union',
            'typing.Optional': 'typing.Optional',
            'typing.ClassVar': 'typing.ClassVar',
            'typing.cast': 'typing.cast',
        }).visit_Subscript(Subscript(Name(name, Load), slice, Load()))
    assert isinstance(visit('Union', parse('(str, int)').body[0]), BinOp)
    assert isinstance(visit('Optional', parse('int').body[0]), BinOp)
    assert isinstance(visit('ClassVar', parse('int').body[0]), Subscript)
    assert isinstance(visit('cast', parse('int').body[0]), Subscript)



# Generated at 2022-06-23 15:36:36.886778
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    """Tests for func_ann method of Parser class."""
    input_list = [
        (True, True, func_args('self, cls, *args, a'),
         'Self', 'type[Class]', 'Any', 'int', 'return', 'Any'),
        (False, False, func_args('self, a'),
         'Any', 'int', 'return', 'None'),
    ]
    parser = Parser(link=False, toc=False)
    for has_self, cls_method, args, *expect in input_list:
        assert list(parser.func_ann(
            '', args, has_self=has_self, cls_method=cls_method)) == expect

# Generated at 2022-06-23 15:36:48.769951
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("_") == "_"
    assert esc_underscore("__") == r"\_\_"
    assert esc_underscore("_t") == "_t"
    assert esc_underscore("t_t") == r"t\_t"
    assert esc_underscore("t_t_") == r"t\_t\_"
    assert esc_underscore("_t_t") == r"\_t\_t"
    assert esc_underscore("t_t_t") == r"t\_t\_t"
    assert esc_underscore("t_t_t_t_t") == r"t\_t\_t\_t\_t"

# Generated at 2022-06-23 15:36:59.219189
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .util import parse_import
    from . import pdoc, pdoc_show

    def parse(s: str, *, in_root: bool = False) -> pdoc.Module:
        return Parser(s, in_root=in_root).parse()

    m = parse('''
        """Docstring.

        Docstring is a method.
        """
        def method(x: int, y: int = 0) -> str:
            """Docstring.

            Docstring is a method.
            """
            return "hello " + str(x) + str(y)
    ''')
    assert m.__doc__ is None
    assert m.method.__doc__.__text__ == 'Docstring.\n\nDocstring is a method.'

# Generated at 2022-06-23 15:37:07.458036
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('a.b.c')
    assert not is_public_family('a.b._c')
    assert is_public_family('a.b.__c')
    assert not is_public_family('a.b.__c__')
    assert not is_public_family('_a.b.c')
    assert is_public_family('a.__b.c')
    assert not is_public_family('__a.b.c')
    assert not is_public_family('__a.b.c__')



# Generated at 2022-06-23 15:37:11.645088
# Unit test for function parent
def test_parent():
    assert parent("a.b.c", level=3) == parent("a.b.c") == "a.b"
    assert parent("a.b.c", level=2) == "a"
    assert parent("a.b.c", level=1) == "a.b"

# Generated at 2022-06-23 15:37:19.252913
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    # @see: https://docs.python.org/3/library/math.html
    import math
    # @see: https://docs.python.org/3/library/random.html
    import random
    import glob
    import re
    parser = Parser(link=False, 
                    docs=True, 
                    toc=True, 
                    __all__=False, 
                    modules=[math, random, glob, re])
    assert parser.docstring[math.factorial.__name__] == ""
    assert parser.docstring[math.factorial.__name__] == ""
    assert parser.docstring["math.factorial"] == ""
    assert parser.docstring[random.gauss.__name__] == ""
    assert parser.docstring[random.gauss.__name__] == ""

# Generated at 2022-06-23 15:37:27.367657
# Unit test for function walk_body
def test_walk_body():
    block = (
        If(Constant(True), [
            Assign([Name('a', ctx=Store())], Constant(1)),
            Assign([Name('b', ctx=Store())], Constant(2)),
        ], []),
        Assign([Name('c', ctx=Store())], Constant(3)),
    )
    assert list(walk_body(block)) == block
    assert list(walk_body(block + (If(Constant(True), [], []),))) == block

# Generated at 2022-06-23 15:37:29.877480
# Unit test for function doctest
def test_doctest():
    """
    >>> doctest("""

# Generated at 2022-06-23 15:37:35.860002
# Unit test for method compile of class Parser
def test_Parser_compile():
    import sys
    import pytest
    if sys.version_info >= (3, 8):
        from typing import TypedDict
    else:
        TypedDict = None

    parser = Parser()
    parser.parse('main.py', r"""
        """ if TypedDict is None else r"""
        import typing
        if sys.version_info >= (3, 8):
            from typing import TypedDict
        else:
            class TypedDict(typing.TypedDict):
                pass
        """
    )
    parser.parse('main.py', r"""
        from . import _main, magic
        from ._common import A
        from ._main.constants import B
        from ._main import constants as C
        from .magic.constants import D
        """
    )
    parser.parse

# Generated at 2022-06-23 15:37:38.897440
# Unit test for function is_public_family
def test_is_public_family():
    assert not is_public_family('_GlobalVars.__init__')
    assert not is_public_family('PrivateClass')
    assert not is_public_family('a._test')
    assert is_public_family('PublicClass')
    assert is_public_family('abc')



# Generated at 2022-06-23 15:37:43.538823
# Unit test for function code
def test_code():
    assert code('a') == '`a`'
    assert code('`a`') == '<code>`a`</code>'
    assert code('a & b') == '<code>a &amp; b</code>'



# Generated at 2022-06-23 15:37:54.308998
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: A

    b = B(A(3))
    assert Resolver("", {}).visit(parse("b.b.a").body[0].value) == \
        Attribute(Attribute(Name("b", Load()), "b", Load()), "a", Load())
    assert Resolver("", {__name__ + '.b': repr(b)}).visit(parse("b.b.a").body[0].value) == \
        Subscript(Subscript(Subscript(Constant("b"), Constant("b"), Load()), Constant("a"), Load()), Constant(0), Load())



# Generated at 2022-06-23 15:37:58.383381
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore(r"foo_bar") == r"foo_bar"
    assert esc_underscore(r"foo_bar_") == r"foo\_bar_"
    assert esc_underscore(r"foo__bar") == r"foo_\_bar"



# Generated at 2022-06-23 15:38:02.058311
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    p = Parser(False)
    assert p == p
    assert not p == 1
    assert not p == Parser(True)
    assert not p == Parser(False)

# Generated at 2022-06-23 15:38:05.203038
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    Parser.class_api(None, None, [], [Assign(targets=[Name(id='ty', ctx=Store())], value=Attribute(value=Name(id='__builtins__', ctx=Load()), attr='bool', ctx=Load()))])


# Generated at 2022-06-23 15:38:08.809641
# Unit test for function esc_underscore
def test_esc_underscore():
    logger.info(esc_underscore("Test_case"))
    logger.info(esc_underscore("Test_case_2"))
    logger.info(esc_underscore("Test_case_2_sub"))



# Generated at 2022-06-23 15:38:11.465230
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    p = Parser()
    assert p.alias == {}
    assert p.doc == {}



# Generated at 2022-06-23 15:38:16.108709
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    import unittest
    import doctest
    doctest.testmod()
    suite = unittest.TestLoader().loadTestsFromTestCase(TestParser___eq__)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-23 15:38:22.769035
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():

    resolver = Resolver('module', alias={'module.asdf': 'typing.asdf'})

    # _alias = {'module.asdf': 'typing.asdf'}
    # node = Attribute(Name('typing', Load), 'asdf', Load())

    s = unparse(resolver.visit(parse(''' \
        typing.asdf \
    ''').body[0].value)).strip()

    assert s == 'asdf'



# Generated at 2022-06-23 15:38:26.491051
# Unit test for function parent
def test_parent():
    assert parent('a.b.c') == 'a.b'
    assert parent('a.b.c', level=2) == 'a'
    assert parent('a.b.c', level=3) == ''
    assert parent('a.b.c', level=100) == ''



# Generated at 2022-06-23 15:38:39.550931
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    """Test the method `load_docstring` of class `Parser`."""
    p = Parser('./docstring_data')
    p.imp['docstring_data'] = set()
    p.b_level = 0
    p.level['docstring_data'] = 0
    p.root['docstring_data'] = 'docstring_data'
    p.root['docstring_data.module'] = 'docstring_data.module'
    p.root['docstring_data.module.Class'] = 'docstring_data.module.Class'
    p.root['docstring_data.module.AsyncFunction'] = 'docstring_data.module.AsyncFunction'
    p.root['docstring_data.module.Function'] = 'docstring_data.module.Function'

# Generated at 2022-06-23 15:38:47.801111
# Unit test for function doctest
def test_doctest():
    assert doctest("") == ""
    assert doctest("Hello") == "Hello"
    assert doctest(">>> 1") == "```python\n>>> 1\n```"
    assert doctest(">>> 2\n>>> 3") == "```python\n>>> 2\n>>> 3\n```"
    assert doctest(">>> 4\n5\n>>> 6") == "```python\n>>> 4\n5\n>>> 6\n```"
    assert doctest(">>> 7\n8\n9") == ">>> 7\n8\n9"



# Generated at 2022-06-23 15:38:57.118172
# Unit test for method imports of class Parser

# Generated at 2022-06-23 15:39:03.621026
# Unit test for function doctest
def test_doctest():
    text = """Test doctest.
>>> print("Hello")"""
    assert doctest(text) == \
        """Test doctest.
```python
>>> print("Hello")
```"""
    text += '\nHello'
    assert doctest(text) == \
        """Test doctest.
```python
>>> print("Hello")
Hello
```"""
    assert doctest(text + "\nHello") == \
        """Test doctest.
```python
>>> print("Hello")
Hello
```
Hello"""



# Generated at 2022-06-23 15:39:09.799744
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert Resolver("", {}).visit_Attribute(Attribute(Name("typing", Load()), "List", Load())) == Name("List", Load())
    assert Resolver("", {}).visit_Attribute(Attribute(Name("self", Load()), "List", Load())) == Attribute(Name("self", Load()), "List", Load())



# Generated at 2022-06-23 15:39:22.330243
# Unit test for method parse of class Parser
def test_Parser_parse():
    """Test function parse of Parser class."""
    with open('py_doc.py') as f:
        src = f.read()
    p = Parser(link=True)
    p.parse(src)
    assert p.doc['py_doc.f1'] == '''\
# f1()

*Full name:* `py_doc.f1`
[<a id="py_doc-f1"></a>]

@py_doc.deco
'''
    assert p.doc['py_doc.f2'] == '''\
# f2()

*Full name:* `py_doc.f2`
[<a id="py_doc-f2"></a>]

'''

# Generated at 2022-06-23 15:39:30.091073
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    # test1
    parser = Parser('test', [], [], {})
    root = 'ann'
    name = 'ann.test'
    bases = [
        Name(id='Base', ctx=Load(), annotation=None),
        Name(id='Base1', ctx=Load(), annotation=None)
    ]

# Generated at 2022-06-23 15:39:36.804217
# Unit test for method globals of class Parser
def test_Parser_globals():
    _root = "test"
    _p = Parser(None)
    assert _p.root == {_root:_root}
    assert _p.alias == {_root:_root}
    assert _p.imp == {_root:set()}
    assert _p.doc == {}
    assert _p.const == {}
    
    

# Generated at 2022-06-23 15:39:38.726186
# Unit test for function parent
def test_parent():
    assert parent('a.b.c') == 'a.b'
    assert parent('a.b.c', level=2) == 'a'
    assert parent('a.b.c', level=3) == ''



# Generated at 2022-06-23 15:39:41.032394
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    resolver = Resolver('', {})
    assert resolver.visit(Name('str', Load())) == Name('str', Load())



# Generated at 2022-06-23 15:39:46.490469
# Unit test for function parent
def test_parent():
    assert parent('a.b.c') == 'a.b'
    assert parent('a.b.c', level=2) == 'a'
    assert parent('a.b.c', level=3) == ''


# Generated at 2022-06-23 15:39:54.844457
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    assert Parser().func_ann('module', [], has_self=False, cls_method=False)\
                   == ['self']

    assert Parser().func_ann('module', [arg('*', None)], has_self=False,
                             cls_method=False) == ['self', '...']

    assert Parser().func_ann('module', [
        arg('*', None), arg('*', None), arg('**', None)],
        has_self=False, cls_method=False).list() == [
            'self', '...', '...', '**kwargs']

    assert Parser().func_ann('module', [
        arg('*', None), arg('a', Name('a', Load())), arg('**', None)],
        has_self=False, cls_method=False).list

# Generated at 2022-06-23 15:40:07.200478
# Unit test for constructor of class Parser
def test_Parser():
    """Test Parser"""
    pp = Parser(link=True, toc=True)

    # Test for `imports`
    root = 'a.b'
    v = pp.alias.copy()
    pp.imports(root, ast.parse('import c'))
    assert v == pp.alias
    pp.imports(root, ast.parse('import d.e as f'))
    assert {'a.b.f': 'd.e'} == pp.alias
    pp.alias.clear()
    pp.imports(root, ast.parse('from . import c as f'))
    assert {'a.b.f': 'a.c'} == pp.alias
    pp.alias.clear()
    pp.imports(root, ast.parse('from .. import e as f'))