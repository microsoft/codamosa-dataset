

# Generated at 2022-06-23 15:30:12.170145
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser(...)
    p.load("python-docstring/tests/data/module.py")
    assert 'module.Class' in p.doc
    Doc = p.doc['module.Class']
    assert isinstance(Doc, str)
    assert '# class Class' in Doc
    assert '*Full name:* ' in Doc
    assert 'Members' in Doc
    assert 'Methods' in Doc
    p = Parser(...)
    p.load("python-docstring/tests/data/module.py")
    assert 'module.Class' in p.docstring
    Doc = p.docstring['module.Class']
    assert isinstance(Doc, str)
    assert 'This is a class docstring' in Doc

# Generated at 2022-06-23 15:30:16.212931
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    tree = Subscript(Attribute(Name('typing', Load()), 'List', Load()),
                     Tuple([]))
    resolver = Resolver('root', {})
    new_tree = resolver.visit(tree)
    assert new_tree == Name('List', Load())



# Generated at 2022-06-23 15:30:18.628677
# Unit test for constructor of class Parser
def test_Parser():
    assert isinstance(Parser(''), Parser)
    assert isinstance(Parser([]), Parser)


# Generated at 2022-06-23 15:30:23.861611
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    assert Resolver("", {}).visit_Constant(Constant(1)) == Constant(1)
    assert Resolver("", {}).visit_Constant(Constant("a")).value == "a"
    assert Resolver("", {}).visit_Constant(Constant('"b"')).value == '"b"'
    assert Resolver("", {}).visit_Constant(Constant('"c"')).value == '"c"'
    assert Resolver("", {}).visit_Constant(Constant('"""d"""')).value == '"""d"""'

# Generated at 2022-06-23 15:30:31.840684
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    node1 = Attribute(Name('typing', Load()), 'List', Load())
    node2 = Attribute(Name('typing.List', Load()), 'List', Load())
    node3 = Attribute(Name('a', Load()), 'b', Load())
    assert Resolver('a', {}).visit_Attribute(node1) == Name('List', Load())
    assert Resolver('a', {}).visit_Attribute(node2) == Name('List', Load())
    assert Resolver('a', {}).visit_Attribute(node3) == node3
test_Resolver_visit_Attribute()

# Generated at 2022-06-23 15:30:39.592234
# Unit test for method imports of class Parser
def test_Parser_imports():
    """Unit test for method imports of class Parser"""
    p = Parser()
    m = "mod"
    node = Import(names=[alias(name="foo", asname="bar")])
    exp = {'mod.bar': "foo"}
    p.imports(m, node)  # Collect import aliases
    assert p.alias == exp
    node = ImportFrom(module="mod", names=[alias(name="foo", asname="bar")])
    exp = {'mod.bar': "mod.foo"}
    p.imports(m, node)  # Collect import aliases
    assert p.alias == exp

# Generated at 2022-06-23 15:30:44.295923
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("a_b") == r"a\_b"
    assert esc_underscore("a_b_c") == r"a\_b\_c"
    assert esc_underscore("a") == "a"
    assert esc_underscore("ac_b") == "ac_b"
# Test end


# Generated at 2022-06-23 15:30:49.493925
# Unit test for function parent
def test_parent():
    assert parent("foo", level=1) == "foo"
    assert parent("foo.bar", level=1) == "foo"
    assert parent("foo.bar.baz", level=1) == "foo.bar"
    assert parent("foo.bar.baz", level=2) == "foo"
    assert parent("foo.bar.baz", level=3) == "foo.bar.baz"



# Generated at 2022-06-23 15:30:51.998491
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    import py_md2doc
    for i in range(4):
        try:
            py_md2doc.Parser()
        except TypeError:
            pass

# Generated at 2022-06-23 15:30:58.972820
# Unit test for function const_type
def test_const_type():
    """Test const type inferences."""
    assert const_type(Constant(value=0)) == 'int'
    assert const_type(Tuple(elts=[Load(), Constant(value=0)])) == 'tuple[Any, int]'
    assert const_type(Tuple(elts=[Tuple(elts=[Load(), Constant(value=0)]), Constant(value=0)])) == ''
    assert const_type(List(elts=[Constant(value=0)])) == 'list[int]'
    assert const_type(List(elts=[])) == 'list[]'
    assert const_type(Set(elts=[Constant(value=0)])) == 'set[int]'

# Generated at 2022-06-23 15:31:10.575482
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    def assert_Parser_class_api(s: str, expected: str):
        from halo import Halo
        from ast import parse
        from astor import unparse
        from tutils import get_docstring
        from vyper import parser as vyper_parser, compiler as vyper_compiler
        from vyper.parser.parser_utils import (
            LLLnode,
            get_number_as_fraction as fraction
        )
        parser = Parser()
        parser.doc["name"] = "@TODO"
        parser.class_api("root", parse(f"class name:\n{s}"), [], [])
        actual = parser.doc["name"].strip()
        assert actual == expected.strip(), actual
    # Case 1
    s = """\
    """

# Generated at 2022-06-23 15:31:21.507390
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    from . import type_
    parser = Parser(link=False, toc=False, all_=False,
                    no_magic=True, no_docstring=False, b_level=2)
    parser.func_api('', '', _parse_args('''b: str, *, c: bool = False
                                           -> str'''))
    assert parser.doc['b'] == (
        "# b()\n\n"
        "*Full name:* `b`\n\n"
        "| Argument | Type |\n"
        "| --- | --- |\n"
        "| `b` | `str` |\n"
        "| `c` | `bool = False` |\n"
        "| return | `str` |\n\n"
        )

# Generated at 2022-06-23 15:31:32.580986
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    assert code(unparse(Resolver("test", {}).visit(parse("str").body[0]))) == "\`str\`"
    assert code(unparse(Resolver("test", {}).visit(parse("123").body[0]))) == "\`123\`"
    assert code(unparse(Resolver("test", {}).visit(parse("Foo").body[0]))) == "\`Foo\`"
    assert code(unparse(Resolver("test", {}, "Foo").visit(parse("Foo").body[0]))) == "\`Foo\`"
    assert code(unparse(Resolver("test", {"test.Foo": "int"}).visit(parse("Foo").body[0]))) == "\`int\`"



# Generated at 2022-06-23 15:31:33.922955
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("foo_bar") == "foo_bar"
    assert esc_underscore("foo_bar_biz") == "foo\\_bar\\_biz"



# Generated at 2022-06-23 15:31:46.414567
# Unit test for method globals of class Parser
def test_Parser_globals():
    _g = Parser('.').globals
    assert _g('a', 'b') is None
    assert _g('a', Assign(
        [Name(id='x', ctx=Store())],
        Constant(value=3, kind=None),
    )) is None
    assert _g('a', Assign(
        [Name(id='x', ctx=Store())],
        Constant(value=3, kind=None),
    )) is None
    assert _g('a', Assign(
        [Name(id='x', ctx=Store())],
        Constant(value=3, kind=None),
    )) is None

# Generated at 2022-06-23 15:31:55.149631
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    root = "a.b.c"
    args = [
        arg("self", Name("A")),
        arg("a", Name("B")),
        arg("*", None),
        arg("b", Name("C")),
        arg("**", None),
        arg("c", Name("D")),
        arg("return", Name("E")),
    ]
    it = Parser.func_ann(None, root, args, False, False)
    assert next(it) == 'Self'
    assert list(it) == ['B', '', 'C', '', 'D', 'E']
    
test_Parser_func_ann()


# Generated at 2022-06-23 15:32:00.804952
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    p = Parser()  # type: ignore
    p.alias['b'] = 'a'
    p.alias['a'] = '__name__'
    p.alias['a.c'] = '__file__'
    assert p.resolve('', Name('b', Load())) == '__name__'
    assert p.resolve('', Attribute(Name('a', Load()), 'c', Load())) == '__file__'
    assert p.resolve('', Attribute(Name('b', Load()), 'c', Load())) == '__name__.__file__'
test_Parser_resolve()
 

# Generated at 2022-06-23 15:32:08.477316
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    from dataclasses import replace
    from test.test_codegen import Module
    from .const import Module as _Module
    from .const import (Arguments as _Arguments, Assign as _Assign,
                        AssignName as _AssignName, Attribute as _Attribute,
                        ClassDef as _ClassDef, Constant as _Constant,
                        FunctionDef as _FunctionDef)
    from .const import (Global as _Global, Import as _Import,
                        ImportFrom as _ImportFrom, Name as _Name,
                        NameConstant as _NameConstant, Return as _Return,
                        Str as _Str)
    m = Module()

# Generated at 2022-06-23 15:32:18.728707
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    alias = {'sys.path': 'a', 'sys.argv': 'b', 'a.c': 'c'}
    root = 'sys'
    def r(node: str) -> str:
        return Parser({'sys': root}).resolve(root, parse(node))
    assert r('a') == 'a'
    assert r('sys.path') == 'a'
    assert r('sys.argv') == 'b'
    assert r('sys.path.hello') == 'a.hello'
    assert r('a.c') == 'c'
    assert r('a.c.x') == 'c.x'
    assert r('sys.path.c') == 'a.c'
    assert r('sys.path.a') == 'a.a'

# Generated at 2022-06-23 15:32:28.979044
# Unit test for method globals of class Parser
def test_Parser_globals():
    parser = Parser('example.py')
    parser.globals('example', ast.parse('_CONST = 1').body[0])
    parser.globals('example', ast.parse('CONST = 1').body[0])
    parser.globals('example', ast.parse('__all__ = 1').body[0])
    parser.globals('example', ast.parse('__all__ = (1,)').body[0])
    parser.globals('example', ast.parse('__all__ = [1]').body[0])
    parse('example', '__all__ = (1, "2", _CONST)', parser)
    parser.const['example._CONST']
    parser.const['example.CONST']
    parser.alias['example._CONST']

# Generated at 2022-06-23 15:32:36.258159
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    class A:
        @property
        def B(self) -> str:
            return 'x'
    class B:
        @property
        def A(self) -> str:
            return 'y'
    def C() -> str:
        return 'z'
    assert Resolver("test", {_m("test", "B"): "A", _m("test", "C"): "B"}).visit(parse("B").body[0].value).id == "B"
    assert Resolver("test", {_m("test", "B"): "A", _m("test", "C"): "B"}).visit(parse("C").body[0].value).id == "B"

# Generated at 2022-06-23 15:32:46.165239
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    print("\nTest for Parser.class_api()")
    def check(bases, body):
        p = Parser()
        p.class_api('test', 'test', bases, body)
        return p.doc['test']
    assert check([], []) == ""

# Generated at 2022-06-23 15:32:52.553880
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    '''

    >>> resolver = Resolver("db.models", {})
    >>> resolver.visit_Attribute(Attribute(Name("typing", Load()), "NewType", Load()))
    Name(id='NewType', ctx=Load())
    '''
    pass

# Generated at 2022-06-23 15:33:01.872506
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    l_a = {
        'root.a': 'b.c',
        'root.b': 'd.e',
        'root.c': 'int',
        'root.d': 'str',
        'root.h.i': 'j.k.l',
        'root.j.l': 'm.n.o',
        'root.j.k': 'h.i',
    }
    l_r = Resolver('root', l_a)
    assert Resolver.visit_Name(l_r, parse('a').body[0].value).id == 'c'
    assert Resolver.visit_Name(l_r, parse('b').body[0].value).id == 'e'

# Generated at 2022-06-23 15:33:08.638932
# Unit test for function const_type
def test_const_type():
    g = globals()
    for name, func in g.items():
        if name.startswith('const_type'):
            continue
        if not isinstance(func, type) or not issubclass(func, AST):
            continue
        for node in g[f'{name}_tree']:
            assert const_type(node) == f'{name}'

# Generated at 2022-06-23 15:33:14.419231
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from types import ModuleType

    module = ModuleType('test')
    module.__doc__ = 'This is a test module.'
    setattr(module, 'a', lambda: "")
    setattr(module, 'b', 1)
    setattr(module, 'c', lambda: "")
    setattr(module, '_d', lambda: "")
    setattr(module, 'A', lambda: "")
    setattr(module, 'B', 1)
    getattr(module, 'a').__doc__ = 'This is a lambda function.'
    setattr(module, 'D', 1)
    setattr(module, 'm', ModuleType('test.m'))
    setattr(module, 'm.b', 1)
    setattr(module, 'C', 1)
    getattr(module, 'm').__

# Generated at 2022-06-23 15:33:25.855879
# Unit test for constructor of class Parser
def test_Parser():
    import os
    import doctest
    import sys
    import typing
    assert str(Parser) == 'Parser()'
    assert str(Parser(link=True)) == 'Parser(link=True)'
    assert Parser().__eq__(Parser()) == False
    assert Parser().__ne__(Parser()) == True
    assert Parser().__repr__() == 'Parser()'
    assert Parser().link == False
    assert Parser().b_level == 1
    assert Parser().toc == False
    assert Parser().docstring == {}
    assert Parser().level == {}
    assert Parser().doc == {}
    assert Parser().alias == {}
    assert Parser().root == {}
    assert Parser().const == {}
    assert Parser().imp == {}
    assert Parser(link=True).link == True
   

# Generated at 2022-06-23 15:33:30.989115
# Unit test for function code
def test_code():
    assert code('hello world') == '`hello world`'
    assert code('world') == 'world'
    assert code('&world') == '<code>&world</code>'
    assert code('world|') == '<code>world&#124;</code>'
    assert code('') == ' '
test_code()



# Generated at 2022-06-23 15:33:31.579442
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    pass

# Generated at 2022-06-23 15:33:41.652192
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    from ast import alias as Alias
    from ast import Assign, AssignName, Attribute, Compare, Load, Name, NameConstant, Subscript, Tuple, Yield
    from ast import FunctionDef
    from ast import keyword
    from ast import Module, AugAssign, BinOp, Call, Compare, Constant, Eq, Expr, If, Load, Name, Num, Subscript
    p = Parser()

# Generated at 2022-06-23 15:33:46.517226
# Unit test for method imports of class Parser
def test_Parser_imports():
    root = 'n'
    node = Import(
        names=[
            alias('a', None),
            alias('b', 'c'),
        ]
    )
    func = Parser(root='').imports
    func(root, node)
    assert Parser.alias == {
        'n.a': 'a',
        'n.c': 'b',
    }

# Generated at 2022-06-23 15:33:57.471617
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from .test_funcs import is_ann_equal
    p = Parser(None)
    def _(args: Sequence[arg], *,
          self_ty: str = "", has_self: bool = False,
          cls_method: bool = False) -> bool:
        return is_ann_equal(p.func_ann('root', args,
                                       self_ty=self_ty, has_self=has_self,
                                       cls_method=cls_method), args)
    assert _([arg('a', 'T')], self_ty='T')
    assert _([arg('a', 'T')], self_ty='')
    assert _([arg('a', 'T'), arg('b', 'S')], self_ty='T', has_self=True)

# Generated at 2022-06-23 15:34:08.759838
# Unit test for method parse of class Parser
def test_Parser_parse():
    
    def test_Parser_parse_delete(delete):
        """Test if `Parser.parse` can handle a delete statement.
        """
        from ast import parse
        from typing import cast, Optional

        from mypy_extensions import TypedDict

        from .ast import Delete
        from .parser import AST, Parser
        from .config import Config

        @TypedDict('Config', {'del_prefix': str})
        class ConfigA:
            ...

        ConfigA()
        ConfigA.__annotations__
        ConfigA.__name__

        cfg = cast(Config, ConfigA(del_prefix=delete))
        cfg.del_prefix
        cfg.get('del_prefix')

        class Mocker:
            def __init__(self, root: str):
                self.root = root
                self

# Generated at 2022-06-23 15:34:15.498322
# Unit test for function code
def test_code():
    for i in [" ", ".", "..."]:
        assert code(i) == " "
    for i in ["()", "abc", "{}", "Hello World"]:
        assert code(i) == f"<code>{i}</code>"
    for i in ["|", "_", "|_.", "__", "ab|c", "a|b|c"]:
        assert code(i) == f"<code>{i.replace('|', '&#124;')}</code>"



# Generated at 2022-06-23 15:34:20.450925
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    node = Name("typing", Load())
    for attr in {"ClassVar", "Final", "Literal", "NoReturn", "Type"}:
        node = Attribute(node, attr, Load())
        node = Resolver("", {}).visit(node)
        assert isinstance(node, Name)
        assert node.id == attr
        assert node.ctx == Load()


# Generated at 2022-06-23 15:34:24.768858
# Unit test for function doctest
def test_doctest():
    doc = "Test case:\n\n    >>> 1\n    1\n\nNext line?\n"
    assert doctest(doc) == "Test case:\n\n```python\n>>> 1\n1\n```\nNext line?\n"



# Generated at 2022-06-23 15:34:30.387525
# Unit test for method parse of class Parser
def test_Parser_parse():
    from os import path
    from .parser import Parser
    from . import config

    # Loading json files
    with open(path.join(config.TEST, 'parser_test.json'), encoding='utf-8') as f:
        tests = json.load(f)

    for test in tests['test_Parser_parse']:
        # Setting arguments
        args = {}
        if 'root' in test:
            args['root'] = test['root']
        if 'link' in test:
            args['link'] = test['link']
        if 'toc' in test:
            args['toc'] = test['toc']

        p = Parser(**args)
        # Getting the result
        if test['module'] is not None:
            result = p.parse(test['module'])

# Generated at 2022-06-23 15:34:37.393363
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    p.root['mod.a'] = 'mod'
    p.alias['mod.a'] = 'mod.b'
    p.level['mod.a'] = 1
    p.root['mod.d'] = 'mod'
    p.alias['mod.d'] = 'mod.s'
    p.level['mod.d'] = 1
    assert (p.is_public('mod.a'))
    assert (p.is_public('mod'))
    assert (not p.is_public('mod.d'))

# Generated at 2022-06-23 15:34:46.999883
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert unparse(Resolver(__name__, {}).visit_Attribute(
        Attribute('typing.Callable', Load(), '__args__')
    )).strip() == 'Callable[..., Any]'
    assert unparse(Resolver(__name__, {}).visit_Attribute(
        Attribute('math.pi', Load(), '__args__')
    )).strip() == 'math.pi'
    assert unparse(Resolver(__name__, {}).visit_Attribute(Subscript(
        Attribute('math.pi', Load(), '__args__'),
        Tuple(List(Constant('a', Load()), Constant('b', Load())), Load()), Load())
    )).strip() == 'pi[a, b]'



# Generated at 2022-06-23 15:34:51.453350
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    code = '''
    class C:
        a: b
        def __init__(self):
            self.a = b
        def func(self):
            a
    '''
    tree = parse(code)
    r = Resolver('users.me', {'users.me': 'ts.target'})
    r.visit(tree)
    assert unparse(tree) == 'class C:\n    a: b\n    def __init__(self):\n        self.a = b\n    def func(self):\n        a\n'


# Generated at 2022-06-23 15:34:57.698821
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Test if the test works right.
    _expect = True
    _result = False
    try:
        Parser('.*test.*')
    except AttributeError:
        _expect = False
    try:
        Parser('.*test.*')
        _result = True
    except AttributeError:
        _result = False
    assert _expect == _result

# Generated at 2022-06-23 15:35:03.468368
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    class A:
        "Hi!"
    class B:
        "Bye!"
    class C:
        "See you!"
    @add_doc(doc.FUNC_DOC)
    def f():
        "Fo"
        pass
    a = Parser(True)
    B.a = A
    B.b = A.a = B
    B.c = f
    B.d = f.function
    B.e = C
    a.load_docstring('__main__', m=B)
    assert a.docstring['__main__.a'] == doctest(A.__doc__)
    assert a.docstring['__main__.a.a'] == doctest(A.__doc__)

# Generated at 2022-06-23 15:35:09.046046
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    """Test method __post_init__ of class Parser."""
    p = Parser()
    assert p.b_level==1 and p.link==False and p.local==True and p.pep==False and p.pyi==False and p.mod_doc==True and p.toc==True and p.alias=={} and p.root=={} and p.imp==defaultdict() and p.level=={} and p.const=={} and p.doc=={} and p.docstring=={}



# Generated at 2022-06-23 15:35:19.287215
# Unit test for function const_type
def test_const_type():
    """Unit test for `const_type`."""
    assert const_type(Constant(1)) == 'int'
    nd = parse('a').body[0].value
    assert const_type(nd) == 'int'
    # Call
    lst = List(elts=[Constant(0), Constant(1)])
    assert const_type(lst) == '[int]'
    set_ = Set(elts=[Constant(True)])
    assert const_type(set_) == 'set[bool]'
    dict_ = Dict(keys=[Constant(0)], values=[Constant(False)])
    assert const_type(dict_) == 'dict[int]'
    # Boolean
    a = parse('True').body[0].value
    assert const_type(a) == 'bool'
    # String

# Generated at 2022-06-23 15:35:29.386202
# Unit test for method api of class Parser
def test_Parser_api():
    """Unit test for method api of class Parser."""
    from enum import Enum
    from typing import Callable, List, Union
    from .c.types import T
    def self_cls_method(self: 'Parser[T]', cls: type) -> T:
        """Test method API."""
        return self.__class__()
    parser = Parser[T](__file__)

# Generated at 2022-06-23 15:35:30.391940
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert isinstance(p, Parser)



# Generated at 2022-06-23 15:35:41.456645
# Unit test for method imports of class Parser
def test_Parser_imports():
    """ auto-generated from _test_parser.py::test_Parser_imports """
    import ast
    import copy
    import sys
    root = 'root'
    node = ast.parse('import a').body[0]
    parser = Parser(root, [], link=True)
    parser.imports(root, node)
    assert parser.alias['root.a'] == 'a'
    node = ast.parse('import a as b').body[0]
    parser = Parser(root, [], link=True)
    parser.imports(root, node)
    assert parser.alias['root.b'] == 'a'
    node = ast.parse('from .. import a as b').body[0]
    parser = Parser(root, [], link=True)
    parser.imports(root, node)


# Generated at 2022-06-23 15:35:44.292708
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    import doctest
    doctest.testmod(verbose=True)




# Generated at 2022-06-23 15:35:51.636468
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("__init__") == "__init__"
    assert esc_underscore("_") == r"\_"
    assert esc_underscore("") == ""
    assert esc_underscore("abc") == "abc"
    assert esc_underscore("a_b") == r"a\_b"
    assert esc_underscore("a_b_a_c") == r"a\_b\_a\_c"



# Generated at 2022-06-23 15:35:53.414701
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__init__')
    assert is_magic('__name__')
    assert is_magic('__module__')
    assert not is_magic('__all__')



# Generated at 2022-06-23 15:35:57.502413
# Unit test for function table
def test_table():
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == '''\
| a | b |
|:---:|:---:|
| c | d |
| e | f |

'''



# Generated at 2022-06-23 15:36:01.618180
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    assert Resolver('', {}).visit(Constant('str')) == Name('str', Load())
    assert Resolver('', {}).visit(Constant('Union')) == Name('Union', Load())
    assert Resolver('', {}).visit(Constant('Union[int, str]')) == Call(Name('Union', Load), [Tuple([Name('int', Load()), Name('str', Load(),)], Load(),)], [], None, None, None,)
    assert Resolver('', {'r': 'Optional[T]'}).visit(Constant('r')) == Subscript(Name('Optional', Load), Tuple([Name('T', Load)], Load(),), Load(),)

# Generated at 2022-06-23 15:36:07.016321
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    obj = Parser()
    filename = ''
    try:
        obj.__post_init__(filename)
        assert False, 'Must have raised an exception here'
    except Exception as e:
        assert type(e) == FileNotFoundError
        assert str(e) == f"No such file: {filename}"

# Generated at 2022-06-23 15:36:16.621732
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    from .parser import Parser
    from .parser import _b_level
    from .parser import _doc
    from .parser import _imp
    from .parser import _I
    from .parser import _G
    from .parser import _API
    from .parser import _alias
    from .parser import _level
    from .parser import _root
    from .parser import _const
    from .parser import _docstring
    from .parser import _l
    from .parser import _L
    from .parser import _C
    from .parser import _F
    from .parser import _t_level
    from .parser import _toc
    from .parser import __m
    from .parser import __m_o
    from .parser import _m
    from .parser import _M
    from .parser import _c
    from .parser import _C_

# Generated at 2022-06-23 15:36:27.785560
# Unit test for method globals of class Parser
def test_Parser_globals():
    from . import test_Parser_globals as test
    from . import Parser
    root = 'alias.foo'
    parser = Parser(False, False)
    parser.globals(root, AnnAssign(
        target=Name(id='b'),
        annotation=Name(id='Union'),
        value=Call(
            func=Name(id='Union'),
            args=[
                Name(id='int'),
                Constant(value=None)
            ],
            keywords=[]
        )))
    assert parser.alias == test.parser_alias
    parser.globals(root, Assign(
        targets=[Name(id='c')],
        value=Str(s='test')
    ))
    assert parser.alias == test.parser_alias_1

# Generated at 2022-06-23 15:36:37.189724
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    """Test annotation resolving."""
    p = Parser()
    p.alias['a.b'] = 'B'
    p.alias['a.c'] = 'C'
    p.alias['c.d'] = 'D'
    assert p.resolve('a', parse('d.e')) == 'a.d.e'
    assert p.resolve('a', parse('a.b')) == 'a.b'
    assert p.resolve('a', parse('b')) == 'a.b'
    assert p.resolve('a.b', parse('b')) == 'a.b.b'
    assert p.resolve('a', parse('d')) == 'd'
    assert p.resolve('a', parse('c.d')) == 'C.d'
    assert p.resolve

# Generated at 2022-06-23 15:36:40.468133
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    """
    Parser().__eq__()
    """
    p = Parser()
    assert p == p

# Generated at 2022-06-23 15:36:42.467258
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser(None) is not None


# Generated at 2022-06-23 15:36:51.469400
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    p = Parser()
    p.root['a.b.c'] = 'a.b'
    p.alias['a.b.x'] = 'a'
    assert p.resolve('a.b', parse('c')) == 'c'
    assert p.resolve('a.b', parse('x')) == 'a.x'
    try:
        p.resolve('a.b', parse('y'))
    except:
        pass
    else:
        raise AssertionError
    assert p.resolve('a.b', parse('a.b.c')) == 'a.b.c'
    assert p.resolve('a.b', parse('a.b.x')) == 'a.x'
    assert p.resolve('a.b', parse('a.b.y'))

# Generated at 2022-06-23 15:36:58.945445
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    arg = namedtuple('Arg', 'arg annotation')
    args = [
        arg('Self', None),
        arg('a', Name(id='int', ctx=Load())),
        arg('b', Name(id='List[int]', ctx=Load()))
    ]
    expect = ['type[Self]', 'int', 'List[int]']
    doc = Parser('', None)
    actual = list(doc.func_ann('', args, has_self=True, cls_method=False))
    print(actual)
    assert expect == actual

# Generated at 2022-06-23 15:37:03.110706
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    self = Parser()
    self.__post_init__()
    assert self.alias == {}
    assert self.imp == {'': set()}
    assert self.const == {}
    assert self.doc == {}
    assert self.level == {}
    assert self.root == {}
    assert self.docstring == {}
    assert self.b_level == 0


# Generated at 2022-06-23 15:37:07.757797
# Unit test for constructor of class Resolver
def test_Resolver():
    """Check Resolver can replace module alias open."""
    alias = {"math.sin": "math.cos"}
    resolver = Resolver("math", alias)
    assert isinstance(resolver.visit(parse("sin").body[0]), Name)
    assert isinstance(resolver.visit(parse("sin(1)").body[0]), Call)


# Generated at 2022-06-23 15:37:18.134816
# Unit test for method globals of class Parser
def test_Parser_globals():
    _code = inspect.getsource(Parser.globals)

# Generated at 2022-06-23 15:37:27.897566
# Unit test for method globals of class Parser
def test_Parser_globals():
    """Tests function `globals` of class `Parser`."""
    import io
    import ast
    import unittest

    from pyppl_doc.parser import Parser
    from pyppl_doc.const import ANY
    from pyppl_doc.util import _I, _G, _API

    class ParserTest(unittest.TestCase):
        """Test case for `Parser::globals`."""

        # pylint: disable=missing-docstring


# Generated at 2022-06-23 15:37:35.633432
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family("a.b")
    assert is_public_family("a.__b")
    assert is_public_family("__b.a")
    assert not is_public_family("a._b")
    assert not is_public_family("_b.a")
    assert not is_public_family("a.__b_")
    assert not is_public_family("__b_.a")
    assert not is_public_family("a.__b__")
    assert not is_public_family("__b__.a")



# Generated at 2022-06-23 15:37:37.259443
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    p = Parser([])
    assert repr(p) == 'Parser([])'


# Generated at 2022-06-23 15:37:43.025898
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    """Test the method visit_Name of class Resolver."""
    root = 'root.sub.subsub'
    alias = dict(foo=f"{root}Foo", bar=f"{root}Bar")
    resolver = Resolver(root, alias)
    case1 = parse(
        '''import typing
b: typing.List[typing.Optional[int]]
c: typing.Optional[typing.List[int]]
d: typing.Optional[foo]
''').body
    case2 = parse(
        '''import typing
a: typing.List[typing.Tuple[int, typing.Optional[bar]]]
''').body

# Generated at 2022-06-23 15:37:45.526716
# Unit test for function parent
def test_parent():
    assert parent('', level=1) == ''
    assert parent('a') == ''
    assert parent('a.b.c') == 'a.b'
    assert parent('a.b.c', level=2) == 'a'
    assert parent('a.b.c.d', level=3) == ''
test_parent()
del test_parent



# Generated at 2022-06-23 15:37:46.785129
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    """Test method resolve of class Parser"""
    p = Parser()

# Generated at 2022-06-23 15:37:51.033456
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    p = Parser('', False)
    assert p.is_public('foo')
    assert not p.is_public('foo.__bar__')
    p = Parser('', True)
    assert p.is_public('foo.__bar__')

# Generated at 2022-06-23 15:37:59.260933
# Unit test for function doctest
def test_doctest():
    doc = '''
    >>> doctest = '''

# Generated at 2022-06-23 15:38:10.885636
# Unit test for function const_type
def test_const_type():
    r = "'''Some str'''"
    assert const_type(parse(r).body[0].value) == 'str'
    r = "1.234e+23"
    assert const_type(parse(r).body[0].value) == 'float'
    r = "1.234j"
    assert const_type(parse(r).body[0].value) == 'complex'
    r = "-1"
    assert const_type(parse(r).body[0].value) == 'int'
    r = "True"
    assert const_type(parse(r).body[0].value) == 'bool'
    r = "[[1, 2j], ['5']]"
    assert const_type(parse(r).body[0].value) == '[Any, Any]'

# Generated at 2022-06-23 15:38:16.262065
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    p.parse("test_parser.py")
    assert p.doc['TEST.test_func'] == '# test_func()\n\n*Full name:* `TEST.test_func`\n\n\n```python\nTEST.test_func() -> None\n```\n\n```python\nThis is test_func docstring.\n```\n'

# Generated at 2022-06-23 15:38:17.918584
# Unit test for function doctest
def test_doctest():
    doc = getdoc(doctest)
    assert doctest(doc) == doc
del test_doctest



# Generated at 2022-06-23 15:38:26.024580
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    import os.path as p
    p = p.abspath(p.dirname(__file__))
    with open(p + '/test_Parser.py', 'r', encoding='utf-8') as f:
        m = parser.parse(f.read(), f.name)
    p = Parser(docstring=True)
    p.walk(m)
    p.load_docstring(f.name, m)
    assert p.docstring['test_Parser.a'] == ''
    assert p.docstring['test_Parser.b'] == 'c'
    assert p.docstring['test_Parser.c.d'] == 'e'

# Generated at 2022-06-23 15:38:38.432954
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser(None)
    p.imp = {'m1': {'m1.a', 'm1.b.a', 'm1.b.c'}, 'm2': {'m2.a', 'm2.b'}}
    p.root = {'m1.a': 'm1', 'm1.a.a': 'm1.a', 'm1.b': 'm1', 'm1.b.a': 'm1.b',
              'm1.b.b': 'm1.b', 'm1.b.b.c': 'm1.b.b', 'm2.a': 'm2',
              'm2.b': 'm2', 'm2.b.c': 'm2.b'}

# Generated at 2022-06-23 15:38:49.563845
# Unit test for function walk_body
def test_walk_body():
    function_body = [
        Assign(targets=[Name(id="ab", ctx=Store())], value=If(
            test=Name(id="a", ctx=Load()),
            body=[Assign(targets=[Name(id="ab", ctx=Store())], value=BinOp(
                left=Name(id="ab", ctx=Load()),
                op=Add(),
                right=Name(id="b", ctx=Load()),
            ))],
            orelse=[Assign(targets=[Name(id="ab", ctx=Store())], value=BinOp(
                left=Name(id="ab", ctx=Load()),
                op=Sub(),
                right=Name(id="b", ctx=Load()),
            ))],
        ))
    ]
   

# Generated at 2022-06-23 15:38:54.613568
# Unit test for function code
def test_code():
    assert code("abc") == "`abc`"
    assert code("") == " "
    assert code("a|b") == "<code>a&#124;b</code>"
    assert code("a&b") == "<code>a&amp;b</code>"
    assert code("a|&b") == "<code>a&#124;&amp;b</code>"
test_code()



# Generated at 2022-06-23 15:39:05.060441
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    """Test method visit_Constant of class Resolver."""
    resolver = Resolver('', {})
    node = Constant(1)
    assert resolver.visit_Constant(node) is node

    node = Constant('a')
    assert resolver.visit_Constant(node) is node

    node = Constant('a.b')
    assert resolver.visit_Constant(node) is node

    code = '1 + 1'
    node = Constant(code)
    assert resolver.visit_Constant(node).value.n == 2

    code = '0.5'
    node = Constant(code)
    assert resolver.visit_Constant(node).value.n == 0.5

    code = '1j'
    node = Constant(code)
    assert resolver.visit_Con

# Generated at 2022-06-23 15:39:16.013859
# Unit test for method imports of class Parser
def test_Parser_imports():
    parser = Parser()
    parser.imports("__main__", ast.parse("""\
import logging
import scipy as s
import numpy as np, matplotlib.pyplot as plt
from os import path
from datetime import timedelta as _timedelta
from .core import *
from .core import A as _A, B
import .core as _core
""").body[0])

# Generated at 2022-06-23 15:39:22.233955
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    p = Parser()
    assert repr(p).startswith('Parser(link=True, toc=True, level_alias=False,')
    p.link = False
    p.toc = False
    p.level_alias = True
    assert repr(p).startswith('Parser(link=False, toc=False, level_alias=True,')
test_Parser___repr__()


# Generated at 2022-06-23 15:39:27.031324
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('gen')
    assert is_public_family('_gen') is False
    assert is_public_family('__gen__')
    assert is_public_family('gen._gen')
    assert is_public_family('module.gen')
    assert is_public_family('module._gen') is False
    assert is_public_family('module.__gen__')



# Generated at 2022-06-23 15:39:28.557292
# Unit test for method globals of class Parser
def test_Parser_globals():
    """Test Parser.globals method"""
    parser = Parser()
    with pytest.raises(AttributeError):
        parser.globals("", 1)


# Generated at 2022-06-23 15:39:30.780221
# Unit test for constructor of class Parser
def test_Parser():
    """Test_Parser."""
    from .. import __version__ as version

    parser = Parser(minversion=version)
    assert isinstance(parser, Parser)

# Generated at 2022-06-23 15:39:40.794773
# Unit test for function parent
def test_parent():
    from unittest import TestCase
    tc = TestCase()
    tc.assertEqual(parent('a'), '')
    tc.assertEqual(parent('a.b'), 'a')
    tc.assertEqual(parent('a.b.c'), 'a.b')
    tc.assertEqual(parent('a.b.c.d'), 'a.b')
    tc.assertEqual(parent('a.b.c.d.e', level=2), 'a.b')
    tc.assertEqual(parent('a.b.c.d.e', level=3), 'a')
test_parent()



# Generated at 2022-06-23 15:39:52.369565
# Unit test for method imports of class Parser
def test_Parser_imports():
    import src.autodoc as ad
    import astor
    f_e = "enumerate"
    f_u = "unparse"
    f_t = "table"
    f_r = "resolve"
    f_c = "const_type"
    f_i = "isinstance"
    f_m = "map"
    f_x = "code"
    f_l = "list"
    f_it = "iter"
    f_st = "str"
    f_p = "parent"
    f_a = "any"
    f_f = "bool"
    f_o = "operator"
    f_s = "sub"
    c_a = "ast"
    m_a = "astor"
    m_u = "astor.unparse"
   

# Generated at 2022-06-23 15:40:04.532201
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    """Unit test for Parser.func_api."""
    from inspect import Signature, Parameter as P
    from mypy.nodes import FuncType
    from mypy.types import AnyType, Type as T

    def resolve(root: str, node: T, self_ty: str = '') -> str:
        """Resolve type shortcut."""
        if isinstance(node, AnyType):
            return 'Any'
        return node.accept(Resolver(root, {}, self_ty))

    def items(args: Sequence[arg], *, has_self: bool, cls_method: bool,
              root: Optional[str] = None) -> Iterator[Tuple[str, str]]:
        """Create function type table."""
        self_ty = ""