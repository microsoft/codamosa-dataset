

# Generated at 2022-06-23 15:30:12.390680
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
  p = Parser()
  p.b_level = 0
  p.imp[''] = set()
  p.root[''] = ''
  p.level[''] = 0
  p.alias[''] = ''
  p.doc[''] = ''
  p.docstring[''] = ''
  p.const[''] = ''

  p.alias['n1'] = 'self.n1'
  p.root['n1'] = 'n1'
  p.level['n1'] = 0
  p.doc['n1'] = ''
  p.const['n1'] = ''

  p.alias['n21'] = 'n11'
  p.alias['n22'] = 'self.n11'
  p.root['n21'] = 'n21'
  p.root

# Generated at 2022-06-23 15:30:17.670279
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    import ast
    import astunparse
    from ..data_structure import Resolver
    a = ast.parse('1.0').body[0]
    assert astunparse.unparse(a) == astunparse.unparse(Resolver(None, {}, None).visit(a))
    a = ast.parse('"asd"').body[0]
    assert astunparse.unparse(a) == astunparse.unparse(Resolver(None, {}, None).visit(a))

# Generated at 2022-06-23 15:30:22.732790
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("__init__") == r"\_\_init\_\_"
    assert esc_underscore("_a_") == r"\_a\_"
    assert esc_underscore("_") == r"\_"
    assert esc_underscore("a_") == "a_"
    assert esc_underscore("a_a") == "a_a"



# Generated at 2022-06-23 15:30:31.180932
# Unit test for method parse of class Parser
def test_Parser_parse():
    if '__package__' not in globals():
        __package__ = '__main__'
    if __package__ != '__main__':
        from . import domain_detector
        from . import path_handler
    else:
        import domain_detector
        import path_handler
    _p = path_handler
    _dd = domain_detector
    _pa = Parser
    _dd.DATA_ROOT = _p.Path('tests/data/')
    _dd.DATA_PATH = _dd.DATA_ROOT / 'domain-{}.json'
    _dd.update()
    file_list = [p for p in _p.DATA_ROOT.iterdir() if p.is_file()]

# Generated at 2022-06-23 15:30:42.727106
# Unit test for function doctest
def test_doctest():
    assert doctest("""
    >>> a = 1
    >>> b = 2
    """) == """
    ```python
    >>> a = 1
    >>> b = 2
    ```
    """.strip()
    assert doctest("""
    >>> a = 1
    b = 2
    >>> c = 3
    """) == """
    ```python
    >>> a = 1
    b = 2
    >>> c = 3
    ```
    """.strip()
    assert doctest("""
    >>> a = 1
    b = 2
    >>> c = 3
    d = 4
    """) == """
    ```python
    >>> a = 1
    b = 2
    >>> c = 3
    d = 4
    ```
    """.strip()

# Generated at 2022-06-23 15:30:50.791307
# Unit test for constructor of class Resolver
def test_Resolver():
    root = "test"
    alias = {
        "typing.Optional": "typing.Optional",
        "typing.Union": "typing.Union",
        "typing.List": "typing.List",
        "typing.Callable": "typing.Callable",
        "typing.Tuple": "typing.Tuple"
    }
    resolver = Resolver(root, alias)
    test1 = resolver.visit(parse("Optional[int]").body[0].value)
    assert repr(test1) == repr(BinOp(Name("int", Load()),
                                     BitOr(),
                                     Constant(None)))
    test2 = resolver.visit(parse("Union[int, float]").body[0].value)

# Generated at 2022-06-23 15:30:58.156746
# Unit test for method globals of class Parser
def test_Parser_globals():
    a = 'a'
    b = 'b'
    c = 'c'
    d = 'd'
    e = 'e'
    p = Parser(str(0))
    p.globals(str(0), Assign([Name(id=a, ctx=Store())], Constant(str(0), kind=None), type_comment=str(0)))
    p.globals(str(0), Assign([Name(id=b, ctx=Store())], Constant(str(0), kind=None), type_comment=str(0)))
    p.globals(str(0), Assign([Name(id=c, ctx=Store())], Constant(str(0), kind=None), type_comment=str(0)))

# Generated at 2022-06-23 15:31:07.119418
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    v = _call(Parser(), 'func_api', '', '',
        ast.arguments(
            posonlyargs=[
                ast.arg(arg='a', annotation=None)
            ],
            args=[
                ast.arg(arg='b', annotation=None)
            ],
            vararg=None,
            kwonlyargs=[
                ast.arg(arg='c', annotation=None)
            ],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        ),
        None,
        has_self=False, cls_method=False
    )
    assert len(v) == 4

# Generated at 2022-06-23 15:31:19.291292
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    """Parser"""
    from typing import Any, List

    from .const import ANY, Code, List as L, Tuple as T

    from .parser import Parser

    def test_func(f: str, *, types: List[Code],
                  members: List[Code], enums: List[Code] = []) -> None:
        """Test function."""
        p = Parser(None)
        f_d = ast.parse(f).body[0]
        p.class_api('a', 'a.b', f_d.bases, f_d.body)
        assert p.doc['a.b'] == table("Bases", items=types)
        assert p.doc['a.b'] == table("Enums", items=enums)

# Generated at 2022-06-23 15:31:30.592312
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    p = Parser('root', {}, level={}, const={}, imp={}, alias={})
    assert p.resolve('root', ast.parse('None').body[0].value) == 'None'
    assert (p.resolve('root', ast.parse('Name(id="root")').body[0].value) ==
            'root')
    assert p.resolve('root', ast.parse('Attribute(value=Name(id="root"), '
                                       'attr="attr")').body[0].value) == 'root.attr'
    assert p.resolve('root', ast.parse('Attribute(value=Attribute(value=Name('
                                       'id="root"), attr="attr"), attr="a")'
                                       ).body[0].value) == 'root.attr.a'

# Generated at 2022-06-23 15:31:32.959580
# Unit test for constructor of class Resolver
def test_Resolver():
    n = SayHello()
    assert n.resolver.root == 'say_hello'
    assert n.resolver.alias == {
        '__main__.SayHello': '"Hello"',
        'say_hello.SayHello': '"Hello"',
    }
    assert n.resolver.self_ty == ""


# Generated at 2022-06-23 15:31:42.461937
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser(lambda s: s).alias == {}
    assert Parser(lambda s: s).imp == {}
    assert Parser(lambda s: s).doc == {}
    assert Parser(lambda s: s).docstring == {}
    assert Parser(lambda s: s).root == {}
    assert Parser(lambda s: s).level == {}
    assert Parser(lambda s: s).const == {}
    assert Parser(lambda s: s).toc
    assert Parser(lambda s: s, link=False).link
    assert Parser(lambda s: s).b_level == 1


# Generated at 2022-06-23 15:31:49.594296
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    alias = {'time.localtime': 'time.struct_time'}
    ty = 'typing.Tuple[int, int, int, int, int, int]'
    resolver = Resolver('time', alias, ty)
    code = resolver.resolve(Call(
        Name('localtime', Load()),
        [Call(Name('time', Load()), [], [], None, None)],
        [], None, None
    ))
    assert code == 'typing.Tuple[int, int, int, int, int, int]'



# Generated at 2022-06-23 15:31:54.658103
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    import numpy as np
    module = ModuleType("np")
    module.__dict__.update({
        "NamedSequence": List[Tuple[str, int]],
        "NestedSequence": List[Tuple[str, List[int]]],
    })
    alias = {'np': 'module'}
    r = Resolver('', alias)
    assert unparse(r.visit(parse('NamedSequence')), True) == \
        "module.NamedSequence: List[Tuple[str, int]]"
    assert unparse(r.visit(parse('NestedSequence')), True) == \
        "module.NestedSequence: List[Tuple[str, List[int]]]"
    assert unparse(r.visit(parse('np.NamedSequence')), True)

# Generated at 2022-06-23 15:31:59.286598
# Unit test for function table
def test_table():
    assert table("abc", "def", [['ghi', 'jkl'], ['mno', 'pqr']]) == \
        "| abc | def |\n|:---:|:---:|\n| ghi | jkl |\n| mno | pqr |\n\n"


_R = TypeVar('_R', bound='Node')



# Generated at 2022-06-23 15:32:02.246473
# Unit test for constructor of class Resolver
def test_Resolver():
    """Example of Resolver"""
    node = parse("Point2D").body[0]
    assert isinstance(node, ClassDef)
    for node in node.body:
        if isinstance(node, Assign):
            node.value.value

# End of Unit test for resolver



# Generated at 2022-06-23 15:32:09.529959
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser(False)
    assert p.is_public('_') is False
    assert p.is_public('__') is False
    assert p.is_public('___') is False
    assert p.is_public('_a') is False
    assert p.is_public('_a0') is False
    assert p.is_public('_0a') is False
    assert p.is_public('__a') is False
    assert p.is_public('a_') is True
    assert p.is_public('a0_') is True
    assert p.is_public('a_0') is True
    assert p.is_public('a__') is True
    assert p.is_public('a0__') is True
    assert p.is_public('a__0') is True

# Generated at 2022-06-23 15:32:20.681663
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert Resolver("", {}).visit(Name("Union", Load())) == Name("Union", Load())
    assert Resolver("", {"a": "str"}).visit(Name("a", Load())) == Name('str', Load())
    assert Resolver("", {"a.b": "str"}).visit(Name("b", Load())) == Name('str', Load())
    assert Resolver("", {"a.b": "str"}).visit(Name("a.b", Load())) == Name('str', Load())
    assert Resolver("", {"a.c": "str"}).visit(Name("a.b", Load())) == Name('a.b', Load())

# Generated at 2022-06-23 15:32:29.462126
# Unit test for method imports of class Parser
def test_Parser_imports():
    from pdoc3.extract import Parser
    from ast import Import, alias, ImportFrom
    from pprint import pprint
    _import = Import([alias('re', None)], 0)
    _import_from = ImportFrom('os', [alias('path', None)], 0, None)
    _import_from_relative = ImportFrom('..io', [alias('StringIO', None)], 1, None)
    pprint(Parser({}, {}).imports('', _import))
    pprint(Parser({}, {}).imports('', _import_from))
    pprint(Parser({}, {}).imports('a.b', _import_from_relative))

# Generated at 2022-06-23 15:32:37.793891
# Unit test for method api of class Parser
def test_Parser_api():
    import minivisitor
    
    def check(a, b):
        assert a == b
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    p = Parser()
    assert p.is_public('builtins.abs') is True
    p.parse('f = abs', 'builtins')
    assert p.is_public('builtins.abs') is False
    p.parse('def g():\n    pass\n\nf = g', 'a')
    assert p.is_public('a.g') is False
    p.parse('__all__ = ["a"]\n\ndef g():\n    pass\n\nf = g', 'a')

# Generated at 2022-06-23 15:32:43.351346
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    import doctest
    import importlib
    import sys

    def test_doctest_load_docstring(mod):
        parser = Parser(mod, no_link=True)
        parser.load_docstring(mod, importlib.import_module(mod))
        for name in parser.doc:
            doc = parser.docstring[name]
            if not doc:
                continue
            try:
                doctest.testmod(
                    doctest.DocTestParser().get_doctest(
                        doc, globals({mod: importlib.import_module(mod)}),
                        '<string>', mod, 0))
            except Exception as exc:
                if name in getattr(exc, '__suppress_context__', ()):
                    continue

# Generated at 2022-06-23 15:32:51.222886
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    import sys
    import inspect
    from io import StringIO
    from pathlib import Path
    from importlib import import_module
    from .interface import get_module, is_module
    
    out = StringIO()
    c = Parser(out, link=False)
    m = get_module('sys', is_module=is_module)

    c.load_docstring('sys', m)
    assert 'This module provides access to some objects used or maintained by the interpreter and to functions' in c.docstring['sys.version']
    assert 'The version number of the Python interpreter' in c.docstring['sys.version_info']
    assert 'Returns the name of the top-level Python package' in c.docstring['sys.gettrace']

    out = StringIO()
    c = Parser(out, link=False)
   

# Generated at 2022-06-23 15:32:55.223816
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('lottie.decode')
    assert not is_public_family('lottie._data.cache')
    assert not is_public_family('__init__')



# Generated at 2022-06-23 15:33:01.646747
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    import ast
    from .types import FunctionDef, ClassDef, arguments, arg, Expr, Name, Call, ModuleType
    from .build import build

    class Test(Parser):

        def func_api(self, root, name, node, returns, has_self, cls_method):
            self.doc[name] += unparse(node)

        def class_api(self, root, name, bases, body):
            self.doc[name] += unparse(bases)

        def resolve(self, root, node, self_ty=''):
            return unparse(node)

    # Test constants and enums
    test = Test(0, [])

# Generated at 2022-06-23 15:33:08.444020
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore('c_data') == r"c\_data"
    assert esc_underscore('c_data_') == r"c\_data\_"
    assert esc_underscore('_c_data') == r"\_c\_data"
    assert esc_underscore('_c_data_') == r"\_c\_data\_"
    assert esc_underscore('c__data') == r"c\_\_data"
    assert esc_underscore('c__data_') == r"c\_\_data\_"
    assert esc_underscore('_c__data') == r"\_c\_\_data"
    assert esc_underscore('_c__data_') == r"\_c\_\_data\_"

# Generated at 2022-06-23 15:33:14.235457
# Unit test for function doctest
def test_doctest():
    a = doctest("""
    >>> a = 1
    >>> b = 2
    >>> a + b
    3
    """)
    b = doctest("""
    >>> a = 1
    >>> b = 2
    >>> a + b
    3
    >>> c = 3
    >>> a + b + c
    6
    """)
    c = doctest("""
    >>> a = 1
    >>> b = 2
    >>> a + b
    3
    >>> c = 3
    """)
    d = doctest("""
    >>> a = 1
    >>> b = 2
    >>> a + b
    3
    >>> c = 3
    >>> a + b + c
    6
    """)

# Generated at 2022-06-23 15:33:22.706451
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    def assert_Resolver(code, target):
        node, = parse(code).body
        r = Resolver("typing", {}, "")
        new_node = r.visit_Subscript(node.value)
        assert unparse(new_node).strip() == target
    # Optional
    assert_Resolver("a: Optional[int]", "int | None")
    assert_Resolver("a: Optional[int, bool]", "int | bool | None")
    # Union
    assert_Resolver("a: Union[int]", "int")
    assert_Resolver("a: Union[int, bool]", "int | bool")
    # ClassVar
    assert_Resolver("a: ClassVar[int]", "int")
    # ForwardRef

# Generated at 2022-06-23 15:33:32.593387
# Unit test for constructor of class Resolver
def test_Resolver():
    """Unit test for Resolver."""
    alias = {'numpy.generic': 'numpy.ndarray',
             'numpy.ndarray': 'numpy.ndarray'}
    assert Resolver('', alias).visit(Name('a', Load())) == Name('a', Load())
    assert Resolver('', alias).visit(Name('numpy.generic', Load())) == \
        Name('numpy.ndarray', Load())
    node = parse("typing.List[typing.List[int]]").body[0]
    assert code(unparse(
        Resolver('', alias).visit(cast(Expr, node).value)
    )) == '`List[List[int]]`'

# Generated at 2022-06-23 15:33:42.610134
# Unit test for method visit_Name of class Resolver

# Generated at 2022-06-23 15:33:50.777375
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()

# Generated at 2022-06-23 15:34:00.574581
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    class A(object):
        a: int

    class B(A):
        b: float

    class C(B):
        c: str

    import doctest
    s: str
    for c in (A, B, C):
        p = Parser()
        p.class_api('', c.__doc__, docstring=doctest.DocTestParser().get_doctest(c.__doc__, c, c.__name__, c.__module__, None, c.__doc__))
        s = p.doc[''].format()
        print(s)
        assert s == """class A

*Full name:* `A`

Bases
-----
*type[object]*

Members
-------
*a* : *int[]*
""", repr(s)
        p = Pars

# Generated at 2022-06-23 15:34:10.638338
# Unit test for method __post_init__ of class Parser
def test_Parser___post_init__():
    p = Parser()
    p.__post_init__()
    assert p.b_level == 0
    assert p.link
    assert p.toc
    assert p.alias == {}
    assert p.root == {}
    assert p.doc == {}
    assert p.docstring == {}
    assert p.imp == {}
    assert p.const == {}
    assert p.level == {}
    p.__post_init__(b_level=1, link=False, toc=False)
    assert p.b_level == 1
    assert not p.link
    assert not p.toc
    assert p.alias == {}
    assert p.root == {}
    assert p.doc == {}
    assert p.docstring == {}
    assert p.imp == {}
    assert p.const == {}
    assert p.level

# Generated at 2022-06-23 15:34:20.525105
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    p = Parser()
    assert not p == None
    assert not p == {}
    assert not p == Parser()
    assert not p == Parser(func=True, cls=False,
                           link=False, toc=False)
    assert not p == Parser(func=False, cls=True,
                           link=False, toc=False)
    assert not p == Parser(func=False, cls=False,
                           link=True, toc=False)
    assert not p == Parser(func=False, cls=False,
                           link=False, toc=True)
    assert p == Parser(func=True, cls=True,
                       link=True, toc=True)
    p.func = False

# Generated at 2022-06-23 15:34:23.710461
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert unparse(Resolver("__main__", {"typing": "typing"}).visit(parse(
        "typing.List").body[0].value)).strip() == "List"


# Generated at 2022-06-23 15:34:34.228373
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    parser = Parser(link=False)
    _, d1 = parser.func_ann('', [arg('self', None)], has_self=True, cls_method=False)
    assert next(d1) == 'Self'
    _, d2 = parser.func_ann('', [arg('self', None)], has_self=True, cls_method=True)
    assert next(d2) == 'type[Self]'
    _, d3 = parser.func_ann('', [arg('*', None)], has_self=True, cls_method=True)
    assert next(d3) == ''
    _, d4 = parser.func_ann('', [arg('a', arg('b', None))], has_self=True, cls_method=True)

# Generated at 2022-06-23 15:34:39.784757
# Unit test for function parent
def test_parent():
    assert parent('a.b.c', level=2) == 'a'
    assert parent('a.b.c', level=1) == 'a.b'
    assert parent('a.b.c', level=0) == 'a.b.c'
    assert parent('a.b.c', level=3) == ''
    assert parent('a.b.c', level=4) == ''



# Generated at 2022-06-23 15:34:49.580204
# Unit test for method globals of class Parser

# Generated at 2022-06-23 15:34:56.587234
# Unit test for function is_public_family
def test_is_public_family():
    assert not is_public_family('_foo')
    assert is_public_family('foo')
    assert not is_public_family('__foo')
    assert not is_public_family('__foo__')
    assert not is_public_family('_foo.bar')
    assert not is_public_family('__foo.bar')
    assert not is_public_family('foo._bar')
    assert not is_public_family('foo.__bar')
    assert not is_public_family('foo._bar._baz')
    assert not is_public_family('foo.__bar.__baz')
    assert is_public_family('foo.bar')
    assert is_public_family('foo.bar')
    assert is_public_family('foo_bar.bar')

# Generated at 2022-06-23 15:35:01.431701
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("abc_def_123") == r"abc\_def\_123"
    assert esc_underscore("a_bc") == "a_bc"
    assert esc_underscore("abc_") == "abc_"
    assert esc_underscore("_abc") == r"\_abc"
    assert esc_underscore("_") == r"\_"



# Generated at 2022-06-23 15:35:03.054098
# Unit test for function parent
def test_parent(): assert parent('foo.bar', level=1) == 'foo'

# Generated at 2022-06-23 15:35:07.597630
# Unit test for function code
def test_code():
    assert code('How are \n you') == "<code>How are \n you</code>"
    assert code('How are \\n you') == "<code>How are \\n you</code>"
    assert code('How are you') == "`How are you`"
    assert code('') == " "



# Generated at 2022-06-23 15:35:18.390407
# Unit test for function doctest
def test_doctest():
    def test_function(*args, **kwargs) -> None:
        """Test function

        >>> test_function()
        >>> 
        >>> print(1)
        1
        >>> for _ in range(1):
        ...     print(1)
        ...     print(2)
        1
        2
        >>> for _ in range(1):
        ...     print(1)
        ...     print(2)
        1
        2
        >>> print(3)
        3
        >>> print(4)
        4
        """
        pass


# Generated at 2022-06-23 15:35:27.317736
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("") == ""
    assert esc_underscore("_") == "_"
    assert esc_underscore("__") == "__"
    assert esc_underscore("_a") == "_a"
    assert esc_underscore("__a") == "__a"
    assert esc_underscore("a") == "a"
    assert esc_underscore("a_") == "a_"
    assert esc_underscore("a__") == "a__"
    assert esc_underscore("a_a") == "a\\_a"
    assert esc_underscore("a__a") == "a\\_\\_a"



# Generated at 2022-06-23 15:35:39.396117
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from typing import NamedTuple
    from .resolver import Resolver
    Node = NamedTuple("Node", [("id", str), ("attr", str), ("ctx", object)])
    args = [arg("a", None), arg("b", Node("Id", "annotation", "Load"))]
    r = Resolver("", {}, "").func_ann("", args, has_self=True)
    assert tuple(r) == ("Self", "ANY", None)
    r = Resolver("", {}, "").func_ann("", args, has_self=True, cls_method=True)
    assert tuple(r) == ("type[Self]", "ANY", None)
    r = Resolver("", {}, "").func_ann("", args, has_self=False, cls_method=True)

# Generated at 2022-06-23 15:35:45.858563
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():

    # Test cases
    class TestCase(unittest.TestCase):
        def test_parser(self):
            p = Parser()
            assert repr(p) == "Parser()"
            p = Parser(b_level=3)
            assert repr(p) == "Parser(b_level=3)"
            p = Parser(link=True)
            assert repr(p) == "Parser(link=True)"
            p = Parser(toc=True)
            assert repr(p) == "Parser(toc=True)"

    # Run test cases
    unittest.main(TestCase(), exit=False)

# Generated at 2022-06-23 15:35:56.925008
# Unit test for function doctest
def test_doctest():
    """Simple doctest."""
    doc = """\
    >>> print(123)
    123
    >>> print(True)
    True
    >>> print({"a": 1})
    {'a': 1}
    >>> print([1, 2, 3])
    [1, 2, 3]"""
    logger.info(doctest(doc))
    assert doctest(doc) == """\
    ```python
    >>> print(123)
    123
    ```
    ```python
    >>> print(True)
    True
    ```
    ```python
    >>> print({"a": 1})
    {'a': 1}
    ```
    ```python
    >>> print([1, 2, 3])
    [1, 2, 3]
    ```"""



# Generated at 2022-06-23 15:35:58.630296
# Unit test for function table
def test_table():
    """Unit test"""
    table('a', 'b', [['c', 'd'], ['e', 'f']])
    table('a', 'b', 'c', [['d', 'e', 'f'], ['g', 'h', 'i']])



# Generated at 2022-06-23 15:36:04.868441
# Unit test for constructor of class Parser
def test_Parser():
    """Test constructor of class Parser."""
    p = Parser()
    assert not p.alias
    assert p.alias[''] == ''
    assert not p.docstring
    assert not p.doc
    assert not p.const
    assert not p.imp
    assert not p.level
    assert not p.root


# Generated at 2022-06-23 15:36:08.005606
# Unit test for function is_magic
def test_is_magic():
    assert is_magic('__magic__')
    assert not is_magic('magic')
    assert is_magic('__module__')



# Generated at 2022-06-23 15:36:11.702132
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    # test of empty argument
    parser = Parser()
    parser.func_api("root", 'name', arguments(), None, has_self=False, cls_method=False)
    assert parser.doc['name'] == '\n'

# Generated at 2022-06-23 15:36:18.659838
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    res = Resolver(root='_test', alias={}, self_ty="")
    assert code(unparse(res.visit(parse('0').body[0].value))) == "`0`"
    assert code(unparse(res.visit(parse('"0"').body[0].value))) == "`'0'`"
    assert code(unparse(res.visit(parse('None').body[0].value))) == "`None`"


# Generated at 2022-06-23 15:36:27.506302
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    def is_public(s: str) -> bool:
        return Parser(root='', link=False, toc=False).is_public(s)
    assert is_public('__a') is False
    assert is_public('_a') is False
    assert is_public('a') is True
    assert is_public('a._b') is False
    assert is_public('a.b') is True
    assert is_public('a.b._c') is False
    assert is_public('a.b.c') is False
    assert is_public('a.b.d') is True



# Generated at 2022-06-23 15:36:36.980777
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    p = Parser()
    p.alias['a.b'] = 'b'
    p.alias['a.c'] = 'c'
    p.alias['a.d'] = 'd'
    p.alias['a.d.f'] = 'f'
    p.alias['a.d.g'] = 'g'
    p.alias['a.d.g.i'] = 'i'
    assert p.resolve('a.b', Name(id='b', ctx=Load())) == 'b'
    assert p.resolve('a.b', Name(id='c', ctx=Load())) == 'c'
    assert p.resolve('a.b', Name(id='d', ctx=Load())) == 'd'

# Generated at 2022-06-23 15:36:48.894796
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    resolver = Parser()
    resolver.alias['a.b.c'] = 'int'
    resolver.alias['a'] = 1
    assert resolver.resolve('a.b.c', parse_annotation('int')) == 'int'
    assert resolver.resolve('a.b', parse_annotation('b.c')) == 'a.b.c'
    assert resolver.resolve('a.b', parse_annotation('a')) == '1'
    assert resolver.resolve('a.b', parse_annotation('b')) == 'b'
    assert resolver.resolve('a.b', parse_annotation('b.c.d')) == 'a.b.c.d'

# Generated at 2022-06-23 15:36:52.038803
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    t: Parser = Parser()
    assert (t) == (t)

# Generated at 2022-06-23 15:36:59.717614
# Unit test for method compile of class Parser
def test_Parser_compile():
    doc = Parser.compile(Parser(ast.parse("""
    def f():
        def t(): pass
        def u(): pass
    def g(): pass
    """), "__all__ = ['f']"))
    assert doc == """**Table of contents:**
    + [f()](#f)
        + [t()](#t)
        + [u()](#u)

### f()

*Full name:* `f`

@param self

@return type[Self]

### t()

*Full name:* `f.t`

@param self

@param return

@return None

### u()
""".strip()

# Generated at 2022-06-23 15:37:10.677950
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from xotl.tools.dox.parser import Parser
    from xotl.tools.objects import ModuleType
    from xotl.tools.params import Params
    from xotl.tools.symbols import Symbol
    from xotl.tools.values import NamedValues


    class M(ModuleType):
        PARAMS: Params = Params()
        A: Symbol = Symbol
        B: NamedValues = NamedValues()

    class O:
        a: Symbol
        b: NamedValues

    parser = Parser()

# Generated at 2022-06-23 15:37:17.449261
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    """
    >>> from unittest.mock import MagicMock
    >>> rv = Resolver('typing', {})
    >>> node = parse('typing.AttrType(str)').body[0]
    >>> assert eval(unparse(rv.visit(node))) == AttrType(str)

    >>> node = parse('typing.Optional[str]').body[0]
    >>> assert eval(unparse(rv.visit(node))) == Optional[str]
    """



# Generated at 2022-06-23 15:37:27.378349
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    import abc
    from typing import Generator, List, Union

    class A:
        pass

    x: Union[abc.ABC, A, List[int]] = []
    as_type = inspect.cleandoc(_ast2str(ast.parse(inspect.getsource(A)).body[0]))
    assert Parser().resolve("", ast.parse("Union[abc.ABC, A, List[int]]").body[0]) ==\
           "Union[ABC, type[A], List[int]]"
    assert Parser().resolve("", ast.parse("[1, ...]").body[0]) == "[1, ...]"
    assert Parser().resolve("abc", ast.parse("abc.A").body[0]) == "abc.A"

# Generated at 2022-06-23 15:37:33.988918
# Unit test for method globals of class Parser

# Generated at 2022-06-23 15:37:36.055332
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    p = Parser()
    print(f'{p!r}')
    assert p.__repr__() == 'Parser()'

# Generated at 2022-06-23 15:37:48.338527
# Unit test for method __eq__ of class Parser
def test_Parser___eq__():
    """Test case for method `__eq__` of class `Parser`."""

# Generated at 2022-06-23 15:37:55.435095
# Unit test for function walk_body
def test_walk_body():
    # pylint: disable=invalid-name
    ast1 = parse('''
    def foo():
        if 1:
            pass
        else:
            pass
    ''')
    # pylint: disable=unsupported-assignment-operation
    ast2 = parse('''
    def foo():
        try:
            pass
        except:
            pass
        else:
            pass
        finally:
            pass
    ''')
    assert len(list(walk_body(ast1.body))) == 2
    assert len(list(walk_body(ast2.body))) == 4

# Generated at 2022-06-23 15:38:04.656910
# Unit test for method __repr__ of class Parser
def test_Parser___repr__():
    from .parser import Parser as Parser_
    from .parser import _Module as _Module_
    from .parser import _API as _API_
    from .parser import _G as _G_
    from .parser import _I as _I_
    from unittest import mock
    from importlib import import_module
    from typing import List, Dict
    from contextlib import nullcontext
    import sys
    import json
    import types
    import pathlib
    with nullcontext():
        sys.modules.pop('test', None)
        sys.modules.pop('test.module', None)
        sys.modules.pop('test.module.module', None)
    test_m = types.ModuleType('test')
    test_m.module = types.ModuleType('module')
    test_m.module.module = types.Module

# Generated at 2022-06-23 15:38:07.002191
# Unit test for method visit_Constant of class Resolver
def test_Resolver_visit_Constant():
    Resolver("__main__", {}).visit(parse("'abc'").body[0].value)

# Generated at 2022-06-23 15:38:15.947060
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    import sys
    from . import docstring
    p = Parser(['test_docstring'], None, False, True)
    p.load_docstring('test_docstring', docstring)
    assert p.docstring['test_docstring.Parser.compile'] is not None
    assert p.docstring['test_docstring.Parser.resolve'] is not None
    if '__pypy__' in sys.builtin_module_names:
        assert p.docstring['test_docstring.Parser.run'] is not None

# Generated at 2022-06-23 15:38:20.687522
# Unit test for function table
def test_table():
    res = [
        'a', 'b',
        ['c', 'd'],
        ['e', 'f']
    ]
    assert table(*res) == """| a | b |
|:---:|:---:|
| c | d |
| e | f |

"""



# Generated at 2022-06-23 15:38:24.111551
# Unit test for function table
def test_table():
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) == \
        '| a | b |\n|:---:|:---:|\n| c | d |\n| e | f |\n\n'



# Generated at 2022-06-23 15:38:31.156935
# Unit test for function doctest
def test_doctest():
    doc = """\
>>> import pyslvs
>>> pyslvs.version
0.0.0"""
    assert doctest(doc) == """\
```python
>>> import pyslvs
>>> pyslvs.version
0.0.0
```"""
    doc = """\
>>> import pyslvs
>>> pyslvs.version"""
    assert doctest(doc) == """\
```python
>>> import pyslvs
>>> pyslvs.version
```"""
    doc = """\
>>> import pyslvs
>>> pyslvs.version
0.0.0
"""
    assert doctest(doc) == """\
```python
>>> import pyslvs
>>> pyslvs.version
0.0.0
```"""



# Generated at 2022-06-23 15:38:40.703827
# Unit test for function walk_body
def test_walk_body():
    src = '''
try:
    class A:
        def a(self):
            try:
                pass
            except:
                while True:
                    try:
                        pass
                    except:
                        pass
            finally:
                pass
            if True:
                pass
            elif False:
                pass
            else:
                pass
        def b(self):
            pass
    B = A()
except:
    pass
else:
    pass
finally:
    pass
'''
    tree = parse(src)
    assert len(list(walk_body(tree.body))) == 6



# Generated at 2022-06-23 15:38:45.254166
# Unit test for function code
def test_code():
    print(code("*a*"))
    print(code("*a|b*"))
    print(code("|a|b"))
    print(code("*a|b*"))
    print(code("#a|b"))
    print(code(""))



# Generated at 2022-06-23 15:38:53.231394
# Unit test for function walk_body
def test_walk_body():
    doc = """
        @overload
        def somme_function(a, b):
            pass

        if a:
            b = a
            if b:
                return b
            else:
                raise Exception()
        else:
            if c:
                return d
            else:
                a = c
                try:
                    a / b
                    raise a
                except:
                    a = b
                finally:
                    a = b
        """
    lines = [line.strip() for line in doc.strip().splitlines()]
    module = parse(doc)
    assert len(lines) == len(list(walk_body(module.body)))

# Generated at 2022-06-23 15:39:04.303393
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('abc.def.xyz')
    assert not is_public_family('abc.def._xyz')
    assert not is_public_family('abc.def.__xyz')
    assert not is_public_family('abc.__init__.xyz')
    assert is_public_family('abc.__init__._xyz')
    assert not is_public_family('abc.__init__.__xyz')
    assert not is_public_family('abc.__init__.__xyz._abc')
    assert not is_public_family('abc.__init__.__xyz.abc')
    assert not is_public_family('abc._def.xyz')
    assert is_public_family('abc._def._xyz')

# Generated at 2022-06-23 15:39:08.048772
# Unit test for constructor of class Parser
def test_Parser():
    """Test for Parser."""
    import sys

# Generated at 2022-06-23 15:39:17.048414
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    from argparse import ArgumentParser
    from functools import partial
    from textwrap import dedent
    parser = ArgumentParser()
    parser.add_argument('-l', '--link', action='store_true')
    parser.add_argument('-t', '--toc', action='store_true')
    parser.add_argument('-b', '--block_level', action='store', type=int, default=0)
    parser.add_argument('-f', '--file', action='store')
    parser.add_argument('-m', '--module', action='store', type=partial(import_module, source='@'))
    parser.add_argument('-c', '--code', action='store', type=dedent)
    args = parser.parse_args()

# Generated at 2022-06-23 15:39:22.416315
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert Resolver(
        "", {},
        ""
    ).visit_Subscript(Subscript(Name('Union', Load()), Tuple([]), Load())
                      ) == Tuple([], Load())
    assert Resolver(
        "", {},
        ""
    ).visit_Subscript(Subscript(Name('Optional', Load()), Tuple([]), Load())
                      ) == BinOp(
                          Tuple([], Load()), BitOr(), Constant(None)
                      )
    assert Resolver(
        "", {},
        ""
    ).visit_Subscript(Subscript(Name('Sequence', Load()), Tuple([]), Load())
                      ) == Subscript(Name('typing.Sequence', Load()), Tuple([]), Load())

# Generated at 2022-06-23 15:39:30.225131
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    def good(s1):
        root, s2 = 'u' + s1, s1.replace('.', ': ')
        assert list(Parser(None).func_ann(root, s2.split(' '))) == s1.split(
            ' ')
    def good1(s):
        good(s)
        good('self.' + s)
        good('cls.' + s)
    good1('int x')
    good1('int x = 0')
    good('type[int] * x')
    good('int * x')
    good('int * x = (1, 2)')
    good('type[int] * x = (1, 2)')
    good('int x = 0, *y')
    good('int *y, x = 0')

# Generated at 2022-06-23 15:39:42.412042
# Unit test for function const_type
def test_const_type():
    assert const_type(Constant(None, value=None)) == 'NoneType'
    assert const_type(Constant(True, value=True)) == 'bool'
    assert const_type(Constant(1)) == 'int'
    assert const_type(Constant(1.0, kind=float)) == 'float'
    assert const_type(Constant(1.0 + 2j, kind=complex)) == 'complex'
    assert const_type(Constant("a")) == 'str'
    assert const_type(List([])) == 'list[]'
    assert const_type(List([Constant(1.0, kind=float), Constant(2)])) == 'list[float, int]'
    assert const_type(List([Constant(1.0, kind=float)] * 3)) == 'list[float]'
   

# Generated at 2022-06-23 15:39:48.016109
# Unit test for function const_type
def test_const_type():
    assert "int" == const_type(parse("1").body[0].value)
    assert "bool" == const_type(parse("True").body[0].value)
    assert "str" == const_type(parse("'a'").body[0].value)
    assert "List" == const_type(parse("[0, 1]").body[0].value)
    assert "List[int]" == const_type(parse("[0, 1]").body[0].value)
    assert "List[int, int]" == const_type(parse("[0, 1, 2, 3]").body[0].value)
    assert "List[Any]" == const_type(parse("[0, True]").body[0].value)

# Generated at 2022-06-23 15:39:52.902151
# Unit test for method globals of class Parser
def test_Parser_globals():
    logger.info('Begin test_Parser_globals')
    from io import StringIO
    import sys
    import ast
    from codetransformer.api import _parse_args
    from .visitor import GenericVisitor, GenericTransformer
    from .alias import Aliases

    class TestVisitor(GenericVisitor):

        def __init__(self, root: str) -> None:
            super().__init__()
            self.root = root

        @property
        def expr(self) -> AST:
            """Resolve expressions."""
            return self.generic_visit(self.visit(self.node), self.node.slice)

        def visit_Call(self, node: Call) -> _Call:
            self.node = node
            node.args = list(map(self.expr, node.args))
            node

# Generated at 2022-06-23 15:39:53.780558
# Unit test for method resolve of class Parser
def test_Parser_resolve():
    # TODO: need to write
    pass


# Generated at 2022-06-23 15:40:06.584237
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    from .typing_ import TYPE_VAR, TYPE_VARS