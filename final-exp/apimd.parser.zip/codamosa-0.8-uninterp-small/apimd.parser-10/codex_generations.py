

# Generated at 2022-06-25 14:42:18.066613
# Unit test for function const_type
def test_const_type():
    test_case_0()


# Generated at 2022-06-25 14:42:24.874408
# Unit test for function walk_body
def test_walk_body():
    example_0 = ast.FunctionDef(name='', args=ast.arguments(), body=[], returns=None)
    example_1 = ast.If(test=None, body=[], orelse=[])
    example_2 = ast.Try(body=[], handlers=[], orelse=[], finalbody=[])
    example_3 = [example_0, example_1, example_2]
    assert {node for node in walk_body(example_3)} == {example_0, example_1, example_2}


# Generated at 2022-06-25 14:42:28.747780
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    root = 'typing.Optional'
    alias = {"typing.Optional": "typing.Optional"}
    self_ty = ""
    obj = Resolver(root, alias, self_ty)
    node = Subscript(Constant(1), Constant(1), Constant(1))
    obj.visit_Subscript(node)


# Generated at 2022-06-25 14:42:31.198870
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    var_0 = Resolver('', {})
    var_1 = module_0.Name()
    var_2 = var_0.visit_Name(var_1)


# Generated at 2022-06-25 14:42:37.208974
# Unit test for function doctest

# Generated at 2022-06-25 14:42:39.494634
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    parser = Parser()
    name = 'dataclasses'
    expect = False
    actual = parser.public(name)
    assert expect == actual


# Generated at 2022-06-25 14:42:41.871119
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    # Setup
    test_doc = ''
    test_node = FunctionDef()
    test_name = ''
    test_obj = Parser(1)
    # Exercise
    result_0 = test_obj.func_api(1, expr_0, test_node, doc, 1)
    # Verify
    assert isinstance(result_0, str)


# Generated at 2022-06-25 14:42:45.067170
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    name_0 = module_0.Name()
    body_0 = [ name_0 ]
    bases_0 = [ name_0 ]
    node_0 = module_0.ClassDef()
    root_0 = ""
    test_obj = Parser()
    test_obj.class_api(root_0, name_0, bases_0, body_0)


# Generated at 2022-06-25 14:42:46.654370
# Unit test for function walk_body
def test_walk_body():
    expr_0 = module_0.expr()
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 14:42:52.797066
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    m_0 = Module()
    body_0 = m_0.body
    body_0.append(FunctionDef(name='func', args=arguments(args=[arg(arg='arg_0', annotation=Name(id='str', ctx=Load())), arg(arg='arg_1', annotation=Name(id='int', ctx=Load()))], vararg=arg(arg='vararg_0', annotation=Name(id='float', ctx=Load())), kwonlyargs=[arg(arg='arg_2', annotation=Name(id='Tuple', ctx=Load()))], kwarg=arg(arg='kwarg_0', annotation=Name(id='Any', ctx=Load())), defaults=[List()], kw_defaults=[Dict()])))
    str_0 = const_type(body_0[0])

# Generated at 2022-06-25 14:44:17.111125
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    arg_0 = Parser()
    
    r1 = arg_0.load_docstring(arg_0, arg_0, module_0)
    assert r1 == None


# Generated at 2022-06-25 14:44:21.092919
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    expr_0 = Expr(Attribute(Name("typing", Load()), "Set", Load()))
    # Visit the AST node
    assert Resolver(*[None, {}]).visit(expr_0) == Name("Set", Load())


# Generated at 2022-06-25 14:44:23.299441
# Unit test for function is_public_family
def test_is_public_family():
    test_name_1 = 'sys.exec_info'
    assert is_public_family(test_name_1) == False


# Generated at 2022-06-25 14:44:25.493806
# Unit test for method imports of class Parser
def test_Parser_imports():
    expr_0 = Parser()
    module_0 = expr_0.imports()


# Generated at 2022-06-25 14:44:33.740304
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    # Given
    m = module_0
    import sys as module_1
    import abc as module_2
    import builtins as module_3
    import typing as module_4
    import enum as module_5
    import argparse as module_6
    import functools as module_7
    import __main__ as module_8
    import ast as module_9
    module_10 = sys.modules[__name__]
    from typing import *
    import ast as module_11
    import types as module_12
    import operator as module_13
    from typing import Generic, TypeVar, NamedTuple, Callable, Union, Tuple
    import typing as module_14
    import ast as module_15
    import token as module_16
    import keyword as module_17
    import os as module_18
    import pathlib

# Generated at 2022-06-25 14:44:35.170873
# Unit test for method compile of class Parser
def test_Parser_compile():
    s = Parser()
    s.pass_("a")
    assert False

# Generated at 2022-06-25 14:44:38.580301
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    expr_0 = module_0.expr()
    value_0 = expr_0.value
    name = value_0.id
    test_name_0 = name == 'expr'
    assert test_name_0


# Generated at 2022-06-25 14:44:40.366345
# Unit test for method api of class Parser
def test_Parser_api():
    p = Parser()
    m: str = 'a.b.c'
    g: ModuleType = ModuleType('c')
    g.__module__ = 'a.b.c'
    p.api(m, g)

# Generated at 2022-06-25 14:44:45.059627
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    expr_0 = module_0.expr()
    expr_1 = module_0.expr()
    expr_2 = module_0.expr()
    expr_3 = module_0.expr()
    expr_4 = module_0.expr()
    expr_5 = module_0.expr()
    parser_0 = Parser(True)
    parser_0.api("abc", module_0.ClassDef(), 
        prefix="abc")
    parser_0.api("abc", module_0.ClassDef(bases=[], body=[]), 
        prefix="abc")
    parser_0.api("abc", module_0.ClassDef(bases=[expr_0, expr_1], body=[]), 
        prefix="abc")

# Generated at 2022-06-25 14:44:52.486503
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    expr_0 = module_0.expr()
    ValueError_0 = ValueError()
    ValueError_0 = ValueError()
    # Unit test for method visit_Attribute of class Resolver, line 7
    try:
        pass
    except:
        pass
    else:
        pass
    # Unit test for method visit_Attribute of class Resolver, line 8
    try:
        pass
    except:
        pass
    else:
        pass
    # Unit test for method visit_Attribute of class Resolver, line 9
    try:
        pass
    except:
        pass
    else:
        pass
