

# Generated at 2022-06-25 14:42:55.343051
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    class_A = 'class A:\n    def __init__(self) -> None:\n        pass'

# Generated at 2022-06-25 14:43:04.119940
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    alias = {
        'scipy.optimize.minimize': 'abc',
    }

    # root = scipy.optimize
    root = 'scipy.optimize'
    # node = minimize
    node = Name('minimize', Load())
    # Expected value: Name('abc', Load())
    expt_value = Name('abc', Load())
    resolver = Resolver(root, alias)
    assert (resolver.visit_Name(node) == expt_value)

    # root = scipy.optimize
    root = 'scipy.optimize'
    # node = abc
    node = Name('abc', Load())
    # Expected value: Name('abc', Load())
    expt_value = Name('abc', Load())
    resolver = Resolver(root, alias)

# Generated at 2022-06-25 14:43:05.463318
# Unit test for method class_api of class Parser

# Generated at 2022-06-25 14:43:08.880593
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    resolver = Resolver(root='typing', alias={})
    resolver.visit_Subscript(Subscript(Name('typing', Load), Constant('List'), Load))

# Generated at 2022-06-25 14:43:13.342151
# Unit test for method compile of class Parser
def test_Parser_compile():
    str_0 = '."!C0xs65#P,#$dJY5j8'
    str_1 = esc_underscore(str_0)
    obj_0 = Parser()
    obj_0.compile()
    assert (str_1 == '\\."!C0xs65\\#P,#$dJY5j8')


# Generated at 2022-06-25 14:43:15.645195
# Unit test for function table
def test_table():
    titles = ['a', 'b']
    items = [['c', 'd'],['e', 'f']]
    table_str = table('a', 'b', [['c', 'd'], ['e', 'f']])
    assert '| a | b |' in table_str, 'title'
    assert '| e | f |' in table_str, 'end'


# Generated at 2022-06-25 14:43:16.793853
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse("") == "\n"


# Generated at 2022-06-25 14:43:18.892737
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser(str_1)
    if p.is_public(str_0):
        p.__get_const(str_1)
    return p.compile()


# Generated at 2022-06-25 14:43:29.146312
# Unit test for method globals of class Parser
def test_Parser_globals():
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tests/globals')
    files = [os.path.join(path, f) for f in os.listdir(path) if f.endswith('.py')]
    for file in files:
        m = Module(file, parser=RecursiveParser())
        top = m.annotate()[0]
        for e in top.body:
            if isinstance(e, AnnAssign) and isinstance(e.target, Name):
                name = e.target.id
                ann = unparse(e.annotation)
                assert name in const_map and const_map[name] == ann

# Generated at 2022-06-25 14:43:33.041720
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    s = '_'

    p = Parser()

    arg_s = s

    try:
        if hasattr(p, 'is_public'):
            return p.is_public(arg_s)
    except Exception:
        print('Cannot call method is_public in class Parser')
