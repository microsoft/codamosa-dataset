

# Generated at 2022-06-25 14:42:14.582444
# Unit test for method compile of class Parser
def test_Parser_compile():
    """Unit test for method compile of class Parser."""
    parser = Parser()
    parser.compile()


# Generated at 2022-06-25 14:42:16.689215
# Unit test for method imports of class Parser
def test_Parser_imports():
    str_0 = 'pJ*'
    str_1 = _I()
    obj_0 = Parser(str_0)
    obj_0.imports(str_0,str_1)


# Generated at 2022-06-25 14:42:26.274120
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    global root_0
    root_0 = 'src.data'
    global alias_0
    alias_0 = {'src.data.A': 'typing.Union'}
    global self_ty_0
    self_ty_0 = "Self"
    global Resolver_0
    Resolver_0 = Resolver(root_0, alias_0, self_ty_0)
    global node_0
    node_0 = Subscript(Name('A', Load), Tuple(elts=[Name('B', Load), Name('C', Load)], ctx=Load), Load)
    global res_0
    res_0 = Resolver_0.visit_Subscript(node_0)
    print(res_0)


# Generated at 2022-06-25 14:42:36.520029
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    p = Parser(set_path('/tmp/pyjoin/root'))
    p.doc['root'] = ''
    p.root['root'] = 'root'
    p.level['root'] = 0
    p.level['root.sub'] = 1
    p.level['root.sub.subsub'] = 2
    p.doc['root.sub'] = ''
    p.root['root.sub'] = 'root'
    p.doc['root.sub.subsub'] = ''
    p.root['root.sub.subsub'] = 'root'
    p.class_api('root', 'root.sub.subsub', [Name(id='b1', ctx=Load()), Name(id='b2', ctx=Load())],
                [Pass()])

# Generated at 2022-06-25 14:42:42.183192
# Unit test for function walk_body
def test_walk_body():
    code_str = \
'''
if a == 2:
    print('hello')
    if True:
        print(1)
    print('hello again')
elif False:
    print(0)
    try:
        print(2)
    except:
        print(4)
else:
    print(3)
'''
    module = parse(code_str)
    block = cast(List[stmt], module.body)
    for stmt_ in walk_body(block):
        print(stmt_)


# Generated at 2022-06-25 14:42:48.332487
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    class module_0:
        class A:
            pass
        class B:
            pass
    str_0 = 'tw^-zhOCf<;>'
    _str_0 = '+'
    _str_1 = '~'
    str_1 = code(str_0)
    _str_2 = 'Y`$M'
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {_str_0:_str_1}
    dict_6 = {_str_2:_str_1}
    dict_7 = {_str_2:_str_1}
    dict_8 = {}
    dict_9 = {}

# Generated at 2022-06-25 14:42:54.233722
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    root = ''
    name = 'root'
    node = 'node'
    has_self = 'has_self'
    cls_method = 'cls_method'

# Generated at 2022-06-25 14:42:59.926634
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    from .doc import _ModuleDocumenter, _Pair, _Subscript
    from .visitor import _Visitor

    visitor = _Visitor(__name__)

    class MockResolver(Resolver):
        def visit(self, node):
            visitor.visit(node)

    node = _Subscript()
    resolver = MockResolver('test_package.test_module', {__name__: __name__})
    resolver.visit(node)

    assert visitor.doc.is_visited(node)


# Generated at 2022-06-25 14:43:01.337457
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    pass


# Generated at 2022-06-25 14:43:11.592796
# Unit test for method globals of class Parser
def test_Parser_globals():
    # Setup
    name_0 = 'U{w;Hk-<E+1'
    scope_0 = 'u:O}aX$f_\\D'
    str_0 = 'my_string'
    name_1 = 'k$@uV7X9Z(>'
    expression_0 = 'my_string'
    name_2 = 'b5(l=,Hfk9C2'
    str_1 = 'CONST'
    str_2 = '__all__'
    ast_0 = Name(str_0, Load())
    str_3 = 'parent'
    ast_1 = Name(str_3, Load())
    node_0 = Import([alias(str_0, None)], 0)
    node_1 = Assign([ast_0], ast_1)
    node

# Generated at 2022-06-25 14:43:59.529111
# Unit test for method api of class Parser
def test_Parser_api():
    from sunfish.test import test_sunfish as test_mod

    parser = Parser()
    for name, func in inspect.getmembers(test_mod):
        if inspect.isfunction(func):
            print(parser.doc[name])


# Generated at 2022-06-25 14:44:04.273428
# Unit test for method globals of class Parser
def test_Parser_globals():
    str_0 = inp
    arg_0 = Parser(link=True)
    str_1 = None
    arg_0.globals(str_0, str_1)
    arg_0 = Parser(link=True)
    str_1 = None
    arg_0.globals(str_0, str_1)


# Generated at 2022-06-25 14:44:09.134081
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    a = Resolver("", {}, "")
    a.visit_Name(Name("tw^-zhOCf<;>", Load()))


# Generated at 2022-06-25 14:44:17.022411
# Unit test for method globals of class Parser
def test_Parser_globals():
    import inflection
    import importlib
    import inspect
    import os
    import re
    import sys
    import typing
    import typing_extensions
    import uuid
    a = os.path.join('/home/robin', 'doc')
    b = inflection.underscore(a)
    c = __import__('sys')
    d = inspect.getdoc(inflection.underscore)
    e = uuid.uuid4()
    f = re.search(r'^([\w]+)', 'Apple')
    g = typing.List[str]
    h = typing_extensions.Literal[True, False]

    def f_0():
        return str(x for x in range(10))

    x = f_0()
    y = [y for y in range(10)]
    z

# Generated at 2022-06-25 14:44:20.680906
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    parent('tw^-zhOCf<;>')
    obj_0 = Resolver('', {})
    assert obj_0.visit_Constant(Constant(str, 57)) == str
    return 0

# Generated at 2022-06-25 14:44:30.420062
# Unit test for function const_type
def test_const_type():
    node_1 = Constant(value=0, kind=None)
    node_2 = Tuple(elts=[Constant(value=1, kind=None), Constant(value=2, kind=None)], ctx=Load())
    node_3 = Dict(keys=[Constant(value='a', kind=None)], values=[Constant(value='b', kind=None)])
    node_4 = Call(func=Name(id='int', ctx=Load()))
    node_5 = Call(func=Name(id='bool', ctx=Load()))
    node_6 = Call(func=Name(id='str', ctx=Load()))
    node_7 = Call(func=Name(id='float', ctx=Load()))

# Generated at 2022-06-25 14:44:35.249607
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from dis import dis
    from types import FunctionType
    from types import CodeType
    from io import StringIO

    def fun_0():
        pass
    if __name__ == '__main__':
        logger.info("Checking free vars of function fun_0")
    res_0 = (StringIO(),)
    # Check freevars
    dis(fun_0)
    if __name__ == '__main__':
        logger.info("fun_0.__code__.co_freevars = %r", fun_0.__code__.co_freevars)
    # Check source of function fun_0
    if __name__ == '__main__':
        logger.info("fun_0.__code__.co_filename = %r", fun_0.__code__.co_filename)

# Generated at 2022-06-25 14:44:36.778751
# Unit test for function table
def test_table():
    table('a', 'b', [['c', 'd'], ['e', 'f']])


# Generated at 2022-06-25 14:44:38.619691
# Unit test for function walk_body
def test_walk_body():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 14:44:39.708377
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    test_case_0()


# Generated at 2022-06-25 14:46:08.969321
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    parser = Parser()
    args_0 = []
    has_self_0 = False
    cls_method_0 = True
    ret_0 = parser.func_ann('root_0', args_0, has_self=has_self_0, cls_method=cls_method_0)


# Generated at 2022-06-25 14:46:09.960244
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    pass


# Generated at 2022-06-25 14:46:15.240482
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    # init
    root = ''
    alias = {}
    self_ty = ''
    str_0 = 'tw^-zhOCf<;>'
    resolver_0 = Resolver(root, alias, self_ty)
    attribute_0 = Attribute(Name('f', Load()), str_0, Load())
    # call
    attribute_result = resolver_0.visit_Attribute(attribute_0)


# Generated at 2022-06-25 14:46:17.477040
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    str_0 = 'str_0'
    test_Parser = Parser()
    method = getattr(test_Parser, 'func_api')
    method('str_0', 'str_0', str_0, str_0, has_self='str_0', cls_method='str_0')


# Generated at 2022-06-25 14:46:20.690037
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    def test_case_0():
        parser = Parser()
        str_0 = 'tw^-zhOCf<;>'
        bool_0 = parser.is_public(str_0)


# Generated at 2022-06-25 14:46:30.382492
# Unit test for method api of class Parser
def test_Parser_api():
    # str_0 = '*hVu#d"'
    # str_1 = ''
    # str_2 = 'wJ.y'
    # bool_0 = bool()
    # str_3 = ''
    # int_0 = int()
    str_4 = 'BJ+I;'
    str_5 = 'g1$X'
    str_6 = '.l'
    # bool_1 = bool()
    # str_7 = ''
    # int_1 = int()
    # str_8 = ''
    # int_2 = int()
    # str_9 = ''
    # int_3 = int()
    # str_10 = ''
    # int_4 = int()
    # str_11 = ''
    # int_5 = int()
    # str_12 = ''
   

# Generated at 2022-06-25 14:46:39.402507
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    str_0 = 'pyslvs'
    str_1 = 'typing'
    str_2 = 'typing'
    str_3 = 'Dict'
    str_4 = 'list'
    str_5 = '__getitem__'
    str_6 = 'dict'
    str_7 = 'str'
    num_0 = 1
    str_8 = 'Subscript'
    str_9 = 'slice'
    num_1 = 0
    str_10 = 'lineno'
    num_2 = 1
    str_11 = 'col_offset'
    str_12 = 'typing'
    str_13 = 'str'
    str_14 = 'get__getitem__'
    num_3 = 1
    str_15 = 'pyslvs.Subscript'
    str_