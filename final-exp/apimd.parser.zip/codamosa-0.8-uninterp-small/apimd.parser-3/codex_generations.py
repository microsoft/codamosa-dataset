

# Generated at 2022-06-25 14:40:15.862167
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    def parse_args(s: str, *, filename: str = "", mode: str = "r",
                   node: Optional[arguments] = None,
                   has_self: bool = True, cls_method: bool = False,
                   root: str = "test_module") -> str:
        """Parse args from string."""
        parser = Parser()
        if node is None:
            args, _, _, returns = parse_arg_line(s, filename, mode)
            name = ""
        else:
            args, name, returns = node.args, node.name, node.returns
        parser.func_api(root, name, args, returns, has_self=has_self,
                        cls_method=cls_method)
        return parser.doc[name]


# Generated at 2022-06-25 14:40:17.975755
# Unit test for method compile of class Parser
def test_Parser_compile():
    parser_0 = Parser(link=None)
    str_0 = parser_0.compile()


# Generated at 2022-06-25 14:40:20.220510
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p_0 = Parser(toc=0, link=0)
    print(p_0.is_public('str'))


# Generated at 2022-06-25 14:40:26.576022
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    a = arg('*', None)
    a = arg('**' + a.arg, a.annotation)
    a = arg('*' + a.arg, a.annotation)
    a = arg('/', a.annotation)
    a = arg(a.arg + 'args', a.annotation)
    args = [a]
    b = parser.func_ann(args)
    c = 'type[Self]' if bool else 'Self'
    assert c == 'Self'
    d = b.arg.arg
    e = b.annotation
    f = b.arg == '*'
    g = False if f else b.annotation is not None
    h = unparse(resolve.generic_visit(resolve.visit(b.annotation)))
    i = resolve.self_ty
    j

# Generated at 2022-06-25 14:40:30.864915
# Unit test for method parse of class Parser
def test_Parser_parse():
    import ast
    from pathlib import Path
    from typing import List
    from . import Parser
    from . import parse
    parser_0 = Parser()
    module_0 = ast.parse('if True:\n\tprint("")')
    str_0 = parser_0.parse(module_0)
    module_1 = ast.parse('if True:\n\tprint("")')
    str_1 = parser_0.parse(module_1, link=True)
    pathlib_Path_0 = Path(__file__)
    str_2 = parser_0.parse(pathlib_Path_0)
    pathlib_Path_1 = Path(__file__)
    str_3 = parser_0.parse(pathlib_Path_1, link=True)
    list_0 = []

# Generated at 2022-06-25 14:40:34.424323
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    temp_root = os.curdir
    arg = arg(arg = '*args')
    arg = arg(annotation = 'str')
    arg = arg(arg = '**kwargs')
    arg = arg(arg = 'return')
    arg = arg(annotation = 'str')
    parser = Parser(temp_root)
    list_0 = [arg]
    bool_0 = True
    bool_1 = True
    str_1 = parser.func_ann(temp_root, list_0, has_self = bool_0, cls_method = bool_1)
    assert str_1 == []


# Generated at 2022-06-25 14:40:38.825766
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    module = Parser()
    root = "root"
    args = sequence_0
    has_self = True
    cls_method = True
    assert module.func_ann(root, args, has_self, cls_method) == iterator_0

if __name__ == "__main__":
    import sys
    import doctest
    doctest.testmod(verbose=True, optionflags=doctest.ELLIPSIS)

    print("Unit tests for module Parser:")
    pytest.main(["-v", "--assert=plain", __file__])

# Generated at 2022-06-25 14:40:40.818676
# Unit test for method api of class Parser
def test_Parser_api():
    x, y = None, None
    start, end = 0, 10
    step = 1

    # Call
    Parser.api(x, y)


# Generated at 2022-06-25 14:40:43.676118
# Unit test for method globals of class Parser
def test_Parser_globals():
    module_0 = Module(body=[Assign(targets=[Name(id='__all__', ctx=Store())], value=Tuple(elts=[Constant(value='abc', kind=None)], ctx=Load()))])
    parser = Parser(link=False)
    try:
        parser.parse(module_0)
    except Exception:
        assert False


# Generated at 2022-06-25 14:40:51.254169
# Unit test for function const_type
def test_const_type():
    assert const_type(Constant(value='')) == 'str'
    assert const_type(Constant(value=0)) == 'int'
    assert const_type(Constant(value=0.0)) == 'float'
    assert const_type(Constant(value=0j)) == 'complex'
    assert const_type(Constant(value=True)) == 'bool'
    assert const_type(Constant(value=False)) == 'bool'
    assert const_type(List(elts=[Constant(value='')])) == 'list[str]'
    assert const_type(List(elts=[Constant(value=0)])) == 'list[int]'
    assert const_type(List(elts=[Constant(value=0.0)])) == 'list[float]'

# Generated at 2022-06-25 14:43:05.992264
# Unit test for function const_type
def test_const_type():
    test_const_type_0()


# Generated at 2022-06-25 14:43:15.878110
# Unit test for function walk_body

# Generated at 2022-06-25 14:43:27.404507
# Unit test for method imports of class Parser
def test_Parser_imports():
    import cStringIO
    from io import StringIO, BytesIO
    from doct import Parser
    from sys import version_info
    from ast import parse

    file('test_Parser_imports.py', 'w', encoding='utf-8').writelines([
        "from io import StringIO\n",
        "from ast import parse\n",
        "def f(b: bool):\n",
        "    return BytesIO('')\n",
        "def g():\n",
        "    return StringIO('')\n",
        "class C:\n",
        "    def __init__(self):\n",
        "        self.s = StringIO('')\n",
        "        self.c = cStringIO.StringIO('')\n",
    ])

    p = Parser()


# Generated at 2022-06-25 14:43:37.640428
# Unit test for method api of class Parser

# Generated at 2022-06-25 14:43:39.361528
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    root = ""
    self_ty = ""
    args = []
    nodes = []
    has_self = True
    cls_method = False
    p = Parser()
    p.func_ann(root, args, has_self, cls_method)


# Generated at 2022-06-25 14:43:45.908813
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    # Call method "visit_Name" of class Resolver
    Resolver('abc', {'abc.def': 'ghi'}).visit_Name(Name('def', Load()))
    Resolver('abc', {'abc.def': 'ghi'}).visit_Name(Name('def', Load()))
    Resolver('abc', {'abc.def': 'ghi'}).visit_Name(Name('def', Load()))
    Resolver('abc', {'abc.def': 'ghi'}).visit_Name(Name('def', Load()))
    Resolver('abc', {'abc.def': 'ghi'}).visit_Name(Name('def', Load()))

# Generated at 2022-06-25 14:43:48.608705
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    # Set line number
    Resolver.__code__.co_firstlineno = test_Resolver_visit_Subscript.__code__.co_firstlineno + 1
    resolver = Resolver('', {})
    subscript = Subscript()
    resolver.visit_Subscript(subscript)


# Generated at 2022-06-25 14:43:54.050045
# Unit test for method globals of class Parser
def test_Parser_globals():
    module_path = './test_module/test_module.py'
    with open(module_path, 'r') as f:
        code = f.read()
    p = Parser(link=False)
    p.globals(root='test', node=parse_single(code).body[0])
    # AssertionError: {'test.__all__': '('out',)', 'test.M': 'constant'} != {'test.__all__': '('out',)', 'test.M': 'constant', 'test.P': 'a.Type'}
    assert p.alias == {'test.__all__': '(out,)', 'test.M': 'constant'}
    assert p.imp == {'test': {'test.out'}}

# Generated at 2022-06-25 14:44:05.068484
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    arg_0 = arg('arg_0', None)
    arg_1 = arg('arg_1', None)
    arg_2 = arg('arg_2', None)
    arg_3 = arg('arg_3', None)
    arg_4 = arg('arg_4', None)
    arg_5 = arg('arg_5', None)
    arg_6 = arg('arg_6', None)
    arg_7 = arg('arg_7', None)
    arg_8 = arg('arg_8', None)
    arg_9 = arg('arg_9', None)
    arg_10 = arg('arg_10', None)
    arg_11 = arg('arg_11', None)
    root = 'a5EzeY5P8N'

# Generated at 2022-06-25 14:44:11.411927
# Unit test for method compile of class Parser
def test_Parser_compile():
    str_0 = '\n        # class of Hello\n        class Hello:\n            """Welcome to Hello\n            >>> Hello.world()\n            '
    module_0 = imp.new_module('module_0')
    module_0.__doc__ = str_0
    module_0.Hello = PyObject(object)
    module_0.Hello.world = PyObject(object)
    module_0.Hello.world.__doc__ = 'hello world'
    # class Hello:
    #     """Welcome to Hello
    #     >>> Hello.world()
    #     hello world
    #     """
    #     def world():
    #         """hello world"""
    parser_0 = Parser(module_0)
    parser_0.load_docstring(module_0.__name__, module_0)
   