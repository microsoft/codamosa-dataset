

# Generated at 2022-06-25 14:44:53.674627
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    parser_0 = Parser()
    s = 'str'
    value_0 = parser_0.is_public(s)
    assert isinstance(value_0, bool)
    s = '_str'
    value_1 = parser_0.is_public(s)
    assert isinstance(value_1, bool)
    s = 'str__'
    value_2 = parser_0.is_public(s)
    assert isinstance(value_2, bool)
    s = '__str'
    value_4 = parser_0.is_public(s)
    assert isinstance(value_4, bool)
    s = '__str__'
    value_2 = parser_0.is_public(s)
    assert isinstance(value_2, bool)
    s = 'str_'
    value

# Generated at 2022-06-25 14:44:58.589544
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    root_1 = 'root string'
    args_1 = list()
    has_self_1 = True
    cls_method_1 = True
    parser_1 = Parser()
    result = parser_1.func_ann(root_1, args_1, has_self=has_self_1, cls_method=cls_method_1)
    assert isinstance(result, Iterator)
    #assert result ==


# Generated at 2022-06-25 14:45:04.551580
# Unit test for function doctest
def test_doctest():
    a = doctest("""
This is Line 1
This is Line 2

This is Line 3
This is Line 4
""")
    print(a)
    b = doctest("""
This is Line 1
This is Line 2

This is Line 3
This is Line 4
""")
    print(b)
    c = doctest("""
    This is Line 1
    This is Line 2
    >>> This is Line 3
    This is Line 4
    """)
    print(c)
    d = doctest("""

    This is Line 1
    This is Line 2
    >>> This is Line 3
    This is Line 4
    """)
    print(d)


# Generated at 2022-06-25 14:45:10.777199
# Unit test for function table
def test_table():
    test_item = [['c', 'd'], ['e', 'f']]
    test_title = ['a', 'b']
    table_str = table(test_title[0], test_title[1], test_item)
    print(table_str)
    assert table_str == '''| a | b |
|:---:|:---:|
| c | d |
| e | f |

'''


# Generated at 2022-06-25 14:45:15.783352
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    parser_0 = Parser()
    root_0 = "root_0"
    name_0 = "name_0"
    bases_0 = [1]
    body_0 = [{"a": 1, "b": 2}]
    parser_0.class_api(root_0, name_0, bases_0, body_0)
    assert parser_0.doc[name_0] == ""


# Generated at 2022-06-25 14:45:18.318161
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    parser_0 = Parser()
    root = ''
    name = ''
    bases = None
    body = None
    assert parser_0.class_api(root, name, bases, body) == None



# Generated at 2022-06-25 14:45:21.554853
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family("pyslvs")
    assert is_public_family("foo.bar.pyslvs")


# Generated at 2022-06-25 14:45:23.200547
# Unit test for method globals of class Parser
def test_Parser_globals():
    parser_0 = Parser()

# Generated at 2022-06-25 14:45:24.407008
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    Parser.class_api(None, None, None, None)

# Generated at 2022-06-25 14:45:28.141053
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():

    resolver = Resolver("root", {})
    # Constant 1
    attribute = Attribute("self", "module", Load())
    attribute = resolver.visit_Attribute(attribute)
    # Constant 2
    attribute = Attribute(Name("typing", Load()), "Type", Load())
    attribute = resolver.visit_Attribute(attribute)

    assert attribute is not None
