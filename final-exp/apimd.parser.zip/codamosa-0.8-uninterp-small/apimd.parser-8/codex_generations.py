

# Generated at 2022-06-25 14:41:12.950104
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    """
    >>> docs = DocBuilder(link=False).gen(__file__)
    >>> print(docs.splitlines()[0].strip())
    **Table of contents:**
    >>> print(docs.splitlines()[1].strip())
    + [DocBuilder()](#docbuilder)
    >>> print(docs.splitlines()[-1].strip())
    + [DocBuilder.load_docstring(self, root, m)](#docbuilderload_docstringself-root-m)
    """
    pass


# Generated at 2022-06-25 14:41:16.570296
# Unit test for method compile of class Parser
def test_Parser_compile():
    s_0 = '"W'
    Parser_0 = Parser(s_0)
    int_0 = Parser_0.compile()
    assert type(int_0) == str, "Error with Parser.compile"


# Generated at 2022-06-25 14:41:26.224392
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    import inspect

    import astunparse

    import doctest

    import typing

    str_0 = 'typing.List'
    str_1 = 'int'
    bool_0 = is_public_family(str_0)
    bool_1 = is_public_family(str_1)
    bool_2 = is_magic(str_0)
    bool_3 = is_magic(str_1)
    bool_4 = callable(doctest.DocTestSuite)
    bool_5 = callable(astunparse.unparse)
    bool_6 = callable(inspect.getmembers)
    bool_7 = callable(typing.List)
    bool_8 = callable(typing.Dict)

    str_2 = "1"
    bool_9 = str_2.startswith

# Generated at 2022-06-25 14:41:30.290758
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    str_0 = '"W'
    bool_0 = is_public_family(str_0)
    bool_1 = is_magic(str_0)
    str_1 = 'Dd'
    bool_2 = is_public_family(str_1)
    bool_3 = is_magic(str_1)
    str_2 = 'abc'
    bool_4 = is_public_family(str_2)
    bool_5 = is_magic(str_2)
    str_3 = 'abc.x'
    bool_6 = is_public_family(str_3)
    bool_7 = is_magic(str_3)
    str_4 = 'abc._'
    bool_8 = is_public_family(str_4)
    bool_9 = is_magic(str_4)

# Generated at 2022-06-25 14:41:31.916926
# Unit test for function doctest
def test_doctest():
    str_0 = '"W'
    str_1 = doctest(str_0)
    pass



# Generated at 2022-06-25 14:41:36.167584
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    parser_0 = Parser()
    root = 'root'
    name = 'name'

# Generated at 2022-06-25 14:41:37.328566
# Unit test for method compile of class Parser
def test_Parser_compile():
    obj_0 = Parser()
    str_0 = ''
    str_1 = obj_0.compile()
    assert str_1 == str_0

# Generated at 2022-06-25 14:41:38.198560
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    '''
    Parser().func_api()
    '''
    pass


# Generated at 2022-06-25 14:41:48.493415
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    name_0 = '__author__'
    bool_0 = is_magic(name_0)
    str_0 = '__author__'
    bool_0 = is_public_family(str_0)
    name_0 = '__author__'
    bool_0 = is_public_family(name_0)
    bool_0 = is_public_family('yes')
    bool_0 = is_public_family('')
    bool_0 = is_public_family('false')
    bool_0 = is_public_family('false')
    bool_0 = is_public_family('false')
    bool_0 = is_public_family('false')
    bool_0 = is_public_family('false')


# Generated at 2022-06-25 14:41:56.634564
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    str_0 = '"W'
    bool_0 = is_public_family(str_0)
    alias_0 = {str_0: '"W'}
    str_1 = '"W'
    str_2 = '"W'
    self_ty_0 = str_1
    node_0 = Name(str_2, Load())
    node_1 = Attribute(node_0, 'typing', Load())
    resolver_visit_attribute_0 = Resolver(str_1, alias_0, self_ty_0).visit_Attribute(node_1)
    str_3 = '"W'
    bool_1 = is_public_family(str_3)
    alias_1 = {str_3: '"W'}
    str_4 = '"W'
    str_

# Generated at 2022-06-25 14:42:42.480855
# Unit test for function walk_body
def test_walk_body():
    test_case_0()

# Generated at 2022-06-25 14:42:53.000831
# Unit test for function walk_body
def test_walk_body():
    def body_0(body):
        rst_0 = docbuilder.walk_body(body)
        return list(rst_0)
    str_0 = '\n    >>> docs = DocBuilder(link=False).gen(__file__)\n    >>> print(docs.splitlines()[0].strip())\n    **Table of contents:**\n    >>> print(docs.splitlines()[1].strip())\n    + [DocBuilder()](#docbuilder)\n    >>> print(docs.splitlines()[-1].strip())\n    + [DocBuilder.load_docstring(self, root, m)](#docbuilderload_docstringself-root-m)\n    '
    node_0 = docbuilder.parse(str_0)
    node_1 = docbuilder.Expr(node_0)
    node

# Generated at 2022-06-25 14:43:01.610562
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    """Test the method `func_ann` of class `Parser`."""
    node = [arg(arg='arg0', annotation=Name(id='str', ctx=Load())),
            arg(arg='arg1', annotation=Constant(value=1))]
    args = [arg(arg='arg0', annotation=Name(id='str', ctx=Load())),
            arg(arg='arg1', annotation=Constant(value=1)),
            arg(arg='arg2', annotation=List(elts=[], ctx=Load())),
            arg(arg='arg3', annotation=List(elts=[], ctx=Load())),
            arg(arg='arg4', annotation=List(elts=[], ctx=Load())),
            arg(arg='arg5', annotation=List(elts=[], ctx=Load()))]

# Generated at 2022-06-25 14:43:11.953720
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    root_0 = '__root__'
    name_0 = '__name__'
    bases_0 = expr_0 = attr_0 = '__attr__'
    body_0 = name_1 = '__name__'
    stmt_0 = '__stmt__'
    global_0 = globals()
    global_0['__name__'] = '__main__'
    global_0['__doc__'] = 'autogen'
    global_0['__file__'] = __file__
    global_0['__package__'] = None
    global_0['ANY'] = '__ANY__'
    global_0['AST'] = '__AST__'
    global_0['Call'] = '__Call__'
    global_0['ClassDef'] = '__ClassDef__'

# Generated at 2022-06-25 14:43:13.342713
# Unit test for method api of class Parser
def test_Parser_api():
    print(test_case_0())
#

# Generated at 2022-06-25 14:43:18.864667
# Unit test for method compile of class Parser
def test_Parser_compile():
    assert_equal(DocBuilder(link=False).gen(__file__).splitlines()[0].strip(), '**Table of contents:**')
    assert_equal(DocBuilder(link=False).gen(__file__).splitlines()[1].strip(), '+ [DocBuilder()](#docbuilder)')
    assert_equal(DocBuilder(link=False).gen(__file__).splitlines()[-1].strip(), '+ [DocBuilder.load_docstring(self, root, m)](#docbuilderload_docstringself-root-m)')


# Generated at 2022-06-25 14:43:29.117581
# Unit test for method visit_Attribute of class Resolver

# Generated at 2022-06-25 14:43:31.319379
# Unit test for function const_type
def test_const_type():
    for part in range(1):
        if (part == 0):
            fun = const_type
            if (fun):
                fun(part)
    return


# Generated at 2022-06-25 14:43:40.266111
# Unit test for method imports of class Parser
def test_Parser_imports():
    s_0 = StringIO('import a.b\n')
    root, node = Parser.load(s_0)
    assert root == 'a.b'
    assert node == 'import a.b'
    s_1 = StringIO('from a import b\n')
    root, node = Parser.load(s_1)
    assert root == 'a'
    assert node == 'import a'
    s_2 = StringIO('from a import b as c\n')
    root, node = Parser.load(s_2)
    assert root == 'a'
    assert node == 'import a'
    s_3 = StringIO('from ..a import b as c\n')
    root, node = Parser.load(s_3)
    assert root == '..a'

# Generated at 2022-06-25 14:43:43.355612
# Unit test for method globals of class Parser
def test_Parser_globals():
    node = Assign(
        targets=[
            Name(id='abc', ctx=Store())
        ],
        value=Constant(value=10, kind=None))
    p = Parser()
    p.globals('', node)
    assert p.const['abc'] == 'int'
