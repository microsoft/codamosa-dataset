

# Generated at 2022-06-25 14:41:58.228261
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    from multimethod import multidispatch
    from ast import parse

    root = 'example.Pony'
    node = parse('def lapo(a, b, *c, d, e=1, **f) -> int:\n    pass').body[0]
    has_self = True
    cls_method = True
    def init():
        p = Parser()
        p.level[root] = 0
        for n in node.args.args:
            p.alias[_m(root, n.arg)] = "#"
        for n in node.args.kwonlyargs:
            p.alias[_m(root, n.arg)] = "#"
        p.alias[_m(root, node.args.posonlyargs[0].arg)] = "#"

# Generated at 2022-06-25 14:42:00.395054
# Unit test for function doctest
def test_doctest():
    str_0 = '>Ts?nzd<F\nt51\n!c'
    str_1 = doctest(str_0)
    str_2 = '```python\n>Ts?nzd<F\nt51\n!c\n```'
    assert str_1 == str_2


# Generated at 2022-06-25 14:42:03.967664
# Unit test for method globals of class Parser
def test_Parser_globals():
    doc = ">Ts?nzd<F\nt51\n!c"
    code_0 = 'd = 0\na = "blank"\nd = a'
    args_0 = Module(body=parse(code_0).body)
    str_0 = parent(args_0, args_0)
    int_0 = level(args_0)
    node = Module(body=parse(doc).body)
    dict_0 = Parser(node, link=True).globals('')


# Generated at 2022-06-25 14:42:14.620577
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    str_0 = 'df:'
    str_1 = 'q'
    str_2 = 's'
    str_3 = 'w'
    str_4 = 'h'
    list_0 = [arg(str_0, str_1), arg(str_2, str_3), arg(str_4, None)]
    any_0 = ANY
    str_5 = 'e'
    list_1 = [any_0, any_0, any_0, any_0, any_0, any_0, any_0, any_0, any_0, any_0]
    str_6 = 'v'
    list_1[4] = str_6
    str_7 = 'b'
    list_1[0] = str_7
    str_8 = 't'

# Generated at 2022-06-25 14:42:25.423808
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    str_0 = '>Ts?nzd<F\nt51\n!c'
    bool_0 = is_magic(str_0)
    str_1 = '>Ts?nzd<F\nt51\n!c'
    bool_1 = is_magic(str_1)
    str_2 = '>Ts?nzd<F\nt51\n!c'
    bool_2 = is_magic(str_2)
    root = '>Ts?nzd<F\nt51\n!c'
    alias = {'>Ts?nzd<F\nt51\n!c': '@a3qQcvV7\nF<b~r6Ud\n!c'}
    self_ty = '>Ts?nzd<F\nt51\n!c'
    resolver

# Generated at 2022-06-25 14:42:29.304422
# Unit test for method api of class Parser
def test_Parser_api():
    # Set up call arguments
    root = 'root'
    node = _API(name='name')
    prefix = 'prefix'
    # Invoke method
    instance = Parser()
    instance.api(root, node, prefix = 'prefix')


# Generated at 2022-06-25 14:42:37.700576
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    local_str_0 = ''
    local_str_1 = ''
    local_bool_0 = True
    local_bool_1 = True
    local_list_0 = []
    local_list_1 = []
    local_list_2 = [local_str_0, local_str_1]
    local_Parser_0 = Parser()
    test_case_0(local_str_0, local_str_1, local_bool_0, local_bool_1, local_list_0, local_list_1, local_list_2, local_Parser_0)

# Generated at 2022-06-25 14:42:44.986832
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    """Unit test for method func_api of class Parser"""
    # normal mode
    mod = import_module('docup.testing.test_parsing.example',
                        package='docup')
    parser = Parser()
    parser.visit(parse(mod.foo.__doc__))
    parser.visit(parse(mod.bar.__doc__))
    str_0 = r'\( \)\n\n'
    str_0 += '*Full name:* `foo`\n\n'
    str_0 += '\n'
    str_0 += 'A method to show how to use sphinx seealso and directive seealso.\n'
    str_0 += '\n'
    str_0 += '**Parameters**\n\n'
    str_0 += '\n'
    str

# Generated at 2022-06-25 14:42:45.617925
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    pass


# Generated at 2022-06-25 14:42:54.548433
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    str_1 = '>Ts?nzd<F\nt51\n!c'
    str_0 = '>Ts?nzd<F\nt51\n!c'
    bool_1 = is_magic(str_1)
    node_0 = Subscript(Name(PEP585[idf], Load), node.slice, node.ctx)
    str_2 = '>Ts?nzd<F\nt51\n!c'
    bool_0 = is_magic(str_0)
    node_1 = Subscript(Name(PEP585[idf], Load), node.slice, node.ctx)
    bool_2 = is_magic(str_2)
    bool_3 = bool_0


# Generated at 2022-06-25 14:44:41.388900
# Unit test for method api of class Parser
def test_Parser_api():
    '''
    Test Parser's api method,
    when argument
    '''
    input_0 = str()
    input_1 = Module(doc = None, type_ignores = None, body = [Import(names = [alias(name = 'abc', asname = 'def')], module = None, level = None)])
    output = str()
    parser = Parser()
    parser.api(input_0, input_1)
    assert parser.doc == output


# Generated at 2022-06-25 14:44:50.242876
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    str_0 = 'f'
    str_1 = parent(str_0)
    node_0 = FunctionDef(name='foo')
    node_0.body = [node_0]
    node_0.decorator_list = [node_0]
    node_0.returns = node_0
    node_0.args = node_0
    obj_0 = Parser(node_0)
    obj_0.func_ann(str_0, [])
    obj_0.func_ann(str_0, node_0.args, has_self=False, cls_method=True)


# Generated at 2022-06-25 14:44:53.549673
# Unit test for method compile of class Parser
def test_Parser_compile():
    str_0 = 'f'
    str_1 = parent(str_0)
    p = Parser(str_1)
    assert p is not None
    assert p.compile() is not None


# Generated at 2022-06-25 14:45:01.708629
# Unit test for method api of class Parser
def test_Parser_api():
    m_0 = Module(body=[])
    m_0.lineno = 1
    m_0.col_offset = 91
    m_0.name = 'test'
    m_1 = ClassDef(name='Test', bases=[])
    m_1.lineno = 1
    m_1.col_offset = 91
    m_1.name = 'Test'
    m_1.bases = []
    m_2 = FunctionDef(name='test', args=arguments(args=[], vararg=None,
                                                  kwonlyargs=[],
                                                  kw_defaults=[],
                                                  kwarg=None, defaults=[]),
                      body=[Return(value=Constant('Test', kind=None))])
    m_2.lineno = 1

# Generated at 2022-06-25 14:45:06.259784
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    import sys
    import sys
    import sys

    class_0 = Parser(link=True)
    str_0 = 'test'
    def_0 = 'test'
    class_0.api(str_0, def_0, prefix='')
    str_1 = 'test.Test'
    expr_0 = list(str_1)
    stmt_0 = list(str_1)
    class_0.class_api(str_1, str_1, expr_0, stmt_0)


# Generated at 2022-06-25 14:45:15.475083
# Unit test for method api of class Parser
def test_Parser_api():
    str_0 = "def f(a: int) -> str:\n  ...\n"
    str_1 = "def f():\n  ...\n"
    str_2 = "def f(a: int, *, b: int = 0, **kwargs) -> str:\n  ...\n"
    str_3 = "def f(a: int, *args, b: int = 0, **kwargs) -> str:\n  ...\n"
    str_4 = "def f(a: int) -> str:\n  ...\n"
    str_5 = 'def f(a: int) -> str:\n  ...\n'
    str_6 = "def f(a: int, b: int = 0, **kwargs) -> str:\n  ...\n"

# Generated at 2022-06-25 14:45:22.663983
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    # test 0
    root = 'test_module'
    alias = {'test_module.A': 'typing.Union',
             'test_module.B': 'typing.Optional'}
    self_ty = 'self'
    node = Subscript(Name('A', Load()),
                     Tuple(elts=[Name('x', Load())], ctx=Load()),
                     Load())
    node_visited = Resolver(root, alias, self_ty).visit(node)

# Generated at 2022-06-25 14:45:29.738182
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    s = Subscript(Name('typing.Union', Load), Tuple(elts=[Constant(1, kind=None), Constant(2, kind=None)], ctx=Load()), Load())
    assert Resolver(root='', alias={}).visit_Subscript(s).__dict__ == BinOp(BinOp(Constant(1, kind=None), BitOr(), Constant(2, kind=None)), BitOr(), Constant(None, kind=None)).__dict__
    s = Subscript(Name('typing.Union', Load), Constant(2, kind=None), Load())
    assert Resolver(root='', alias={}).visit_Subscript(s).__dict__ == Constant(2, kind=None).__dict__

# Generated at 2022-06-25 14:45:34.348167
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    import io
    import sys
    import unittest
    import ast

    class TestParser(unittest.TestCase):
        def setUp(self):
            self.captured_output = io.StringIO()
            sys.stdout = self.captured_output
            self.root = 'root'
            self.name = 'name'
            self.bases = ast.Module(body = [])
            self.body = ast.Module(body = [])
            self.Parser = Parser()

        def test_true_0(self):
            self.Parser.class_api(self.root, self.name, self.bases, self.body)
            self.assertEqual(self.captured_output.getvalue(), '')


# Generated at 2022-06-25 14:45:42.909126
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    run_doc=Parser()
    run_doc.level['root'] = 0
    fun_arguments=arguments(args=[arg('a', None)], kwonlyargs=[], vararg=None, kwarg=None, defaults=[], kw_defaults=[])
    run_doc.func_api('root', 'root.b', fun_arguments, returns=None, has_self=True, cls_method=True)
    assert run_doc.doc['root.b'] == '# b()\n\n*Full name:* `root.b`\n\n' + table(
        'self', 'a', 'return',
        items=[('type[Self]', ANY, ANY)]
    ) + '\n'