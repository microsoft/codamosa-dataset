

# Generated at 2022-06-25 14:42:47.046165
# Unit test for method api of class Parser
def test_Parser_api():
    root_0 = '.'
    node_0 = FunctionDef(
        name='a',
        args=(
            arguments(
                args=(
                    arg(arg='a', annotation=None),
                    arg(arg='b', annotation=None)
                ),
                vararg=None,
                kwonlyargs=(
                    arg(arg='a', annotation=None),
                    arg(arg='b', annotation=None),
                ),
                kw_defaults=(),
                kwarg=None,
                defaults=()
            )
        ),
        body=[
            Return(value=Name(id='a', ctx=Load()))
        ],
        decorator_list=(),
        returns=Name(id='a', ctx=Load())
    )

# Generated at 2022-06-25 14:42:50.208713
# Unit test for method imports of class Parser
def test_Parser_imports():
    str_0 = 'import yaml\n'
    arg_0 = parse(str_0)
    __expected_0 = None
    arg_1 = ''
    __expected_1 = None
    obj_0 = Parser()
    obj_0.imports(arg_1, arg_0)
    assert(obj_0.alias == __expected_0)


# Generated at 2022-06-25 14:42:56.739394
# Unit test for function const_type
def test_const_type():
    # initialize input and expected result
    node_0 = Constant(value=2)
    node_1 = Constant(value=2.0)
    node_2 = Constant(value='a')
    node_3 = Constant(value=None)
    node_4 = Constant(value='a' + 'b')
    node_5 = Constant(value=True)
    node_6 = Tuple(elts=[Constant(value=2)], ctx=Load())
    node_7 = Tuple(elts=[Constant(value=2.0)], ctx=Load())
    node_8 = Tuple(elts=[Constant(value='a')], ctx=Load())
    node_9 = Tuple(elts=[Constant(value=False)], ctx=Load())

# Generated at 2022-06-25 14:43:05.991239
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    # 1. Test if the function can throw correct excption if the number of
    #    arguments is not correct
    root_0 = 'root_0'
    args_0 = [arg('arg_0', None)]
    has_self_0, cls_method_0 = [False, False]
    p_0 = Parser(link=False)
    try:
        p_0.func_ann(root_0, args_0, has_self=has_self_0, cls_method=cls_method_0)
    except:
        assert False
    args_1 = [arg('arg_0', None)] * 2
    has_self_1, cls_method_1 = [True, True]
    p_1 = Parser(link=False)

# Generated at 2022-06-25 14:43:15.952915
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    single = 'abc'
    multiple = 'abc.def'
    assert Parser().is_public(single)
    assert Parser().is_public(multiple)


if __name__ == "__main__":
    if sys.argv[-1] == 'ONLINE_JUDGE':
        import os
        with open('B2.py', 'r', encoding='utf-8') as f:
            source = f.read()
        with open(os.path.expanduser('~/A2_py.out'), 'w', encoding='utf-8') as f:
            f.write(auto(source, link=True))
    else:
        for k, v in globals().items():
            if k.startswith('test_'):
                print(k)
                v()

# Generated at 2022-06-25 14:43:21.346065
# Unit test for method api of class Parser
def test_Parser_api():
    import parser
    import sys
    from typing import Tuple, List, TypeVar, Union
    from unittest import TestCase
    from textwrap import dedent

    class ParserTest(TestCase):
        def setUp(self):
            self.parser = parser.Parser()

        def test_func_ann(self):
            from ast import parse, arguments, Name, arg, Subscript
            from ast import Call, Tuple
            from asdox import FunctionDef
            from asdox.parse import func_ann

# Generated at 2022-06-25 14:43:30.034289
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    str_0 = 'indent'
    str_1 = 'level'
    str_2 = 'default'
    str_3 = 'expression'
    str_4 = 'annotation'
    str_5 = 'bool'
    str_6 = 'str'
    str_7 = 'Callable'
    str_8 = 'None'
    str_9 = 'arg'
    str_A = 'Optional'
    str_B = 'Hook'
    str_C = '__tracebackhide__'
    str_D = 'ret'
    str_E = 'always'
    str_F = 'bool'
    str_G = 'name'
    str_H = 'Callable'
    str_I = 'None'
    str_J = 'arg'
    str_K = 'Optional'
   

# Generated at 2022-06-25 14:43:33.204885
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    r = Resolver('root', dict())
    node = parse('typing.Optional[str]').body[0].value
    type_ = r.visit_Subscript(node)
    assert(type_ == None)


# Generated at 2022-06-25 14:43:41.913327
# Unit test for method compile of class Parser

# Generated at 2022-06-25 14:43:49.884792
# Unit test for function table
def test_table():
    list_0 = [('a', 'b'), ('c', 'd'), ('e', 'f')]
    str_0 = 'Iterable[Tuple[int, int]]'
    str_1 = 'str'
    str_2 = table('a', 'b', list_0)
    str_3 = _table_cell(['a', 'b'])
    str_4 = _table_cell(['c', 'd'])
    str_5 = _table_cell(['e', 'f'])
    str_6 = _table_split(['a', 'b'])
    str_7 = '|'
    str_8 = '|'.join(f" {t} " for t in ['a', 'b'])

# Generated at 2022-06-25 14:44:36.479017
# Unit test for method compile of class Parser
def test_Parser_compile():
    str_0 = """
    class Compute:
        def add(self, x: int, y: int) -> int:
            \"\"\"Adding two integers.
            Args:
                x (int): First int.
                y (int): Second int.
            Returns:
                int: Sum of two numbers.
            \"\"\"
            return x + y


    c = Compute()
    c.add(1, 2)
    """

    str_1 = importlib.machinery.SourceFileLoader('sample', 'sample.py').load_module()
    str_2 = Parser(str_1)
    str_2.compile()


# Generated at 2022-06-25 14:44:47.545458
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    from . import Parser
    from .ast import Module, arguments, expr, FunctionDef, stmt, Name, Store, AnnAssign
    dummy = Module([], [FunctionDef(
        'func_0',
        arguments([
            arg('arg_0', expr(Name('str', Store()))),
            arg('arg_1', expr(Name('int', Store())), expr(Constant(0))),
            arg('arg_2', expr(Name('bool', Store())), expr(Constant(False)))
        ], [], [], None, None, []),
        [
            AnnAssign(expr(Name('int', Store())), expr(Name('arg_2', Load())), None)
        ], []
    )
    ])

# Generated at 2022-06-25 14:44:49.363791
# Unit test for method parse of class Parser
def test_Parser_parse():
    import typing
    m = typing.__dict__
    parser = Parser(m)
    parser.parse()


# Generated at 2022-06-25 14:44:58.474415
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    # no call and typo
    assert Resolver('root', {}).visit_Attribute(Attribute('typing', 'ValuesView', Load())) == Name('ValuesView', Load())
    # call and typo
    assert Resolver('root', {}).visit_Attribute(Attribute(Name('typing', Load()), 'ValuesView', Load())) == Name('ValuesView', Load())
    # no call and correct
    assert Resolver('root', {}).visit_Attribute(Attribute('typing', 'AbstractSet', Load())) == Name('AbstractSet', Load())
    # call and correct
    assert Resolver('root', {}).visit_Attribute(Attribute(Name('typing', Load()), 'AbstractSet', Load())) == Name('AbstractSet', Load())
    # extra prefix

# Generated at 2022-06-25 14:45:05.137709
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    from typing import Optional, List
    p = Parser()
    s = "s"
    arg_0 = arg('s', None)
    arg_1 = arg('*', None)
    arg_2 = arg('**', None)
    arg_3 = arg('return', None)
    args = [arg_0, arg_1, arg_2, arg_3]
    has_self = False
    cls_method = False
    assert str(p.func_ann(s, args, has_self=has_self, cls_method=cls_method)) == \
        "('str', None, None, None)"


# Generated at 2022-06-25 14:45:14.871323
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    code_0 = 'def fun(arg_0: int, arg_1: int) -> typing.Dict[int, int]:\n    pass'
    ast_0 = parse(code_0)
    assert(isinstance(ast_0, Module))
    assert(len(ast_0.body) == 1)
    assert(isinstance(ast_0.body[0], FunctionDef))
    assert(ast_0.body[0].name == 'fun')
    assert(len(ast_0.body[0].args.args) == 2)
    # parser
    parser_0 = Parser(False)
    name_0_0 = '__main__.fun'
    parser_0.api('__main__', ast_0.body[0])
    assert(name_0_0 in parser_0.doc)


# Generated at 2022-06-25 14:45:22.295334
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    resolver = Resolver('B', {'B': 'A'}, 'typing')
    idf = 'typing.Union'
    if node.id == self.self_ty:
        return Name("Self", Load())
    idf = self.alias.get(_m(self.root, node.id), node.id)
    if idf == 'typing.Optional':
        return BinOp(node.slice, BitOr(), Constant(None))
    elif idf in PEP585:
        logger.warning(f"{node.lineno}:{node.col_offset}: "
                       f"find deprecated name {idf}, "
                       f"recommended to use {PEP585[idf]}")
        return Subscript(Name(PEP585[idf], Load), node.slice, node.ctx)
    # if

# Generated at 2022-06-25 14:45:24.509826
# Unit test for function walk_body
def test_walk_body():
    from .schemas import FuncDef, ClassDef, Schemas

    for node in walk_body(Schemas.body):
        print(node)


# Generated at 2022-06-25 14:45:26.220370
# Unit test for method compile of class Parser
def test_Parser_compile():
    pass

if __name__ == '__main__':
    test_case_0()
    test_Parser_compile()

# Generated at 2022-06-25 14:45:31.874293
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from typing import Any
    from ast import Module
    from ast import arguments as A
    from ast import Name as N
    from ast import Attribute as A
    from ast import Str as S
    from ast import Expr as E
    from ast import parse as P
    from typing import cast as C
