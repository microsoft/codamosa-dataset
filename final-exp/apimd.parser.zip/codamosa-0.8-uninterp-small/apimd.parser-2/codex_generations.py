

# Generated at 2022-06-25 14:40:41.201323
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    str_0 = _m('root', 'prefix', 'node.name')
    str_1 = _m('root', 'prefix', 'node.name')
    str_2 = esc_underscore(_m('prefix', 'node.name'))
    str_3 = _m('root', 'prefix', 'node.name')
    str_4 = _m('root', 'prefix', 'node.name')
    str_5 = _m('root', 'prefix', 'node.name')
    str_6 = _m('root', 'prefix', 'node.name')
    str_7 = _m('root', 'prefix', 'node.name')
    str_8 = _m('root', 'prefix', 'node.name')
    str_9 = _m('root', 'prefix', 'node.name')
    str_10 = _m

# Generated at 2022-06-25 14:40:46.158258
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    """Test method func_api."""
    int_0 = 0
    str_0 = "0"
    table_6 = Table()
    list_0 = [str_0] * 0
    bool_0 = bool(list_0)
    bool_1 = bool(bool_0)
    bool_2 = bool(bool_1)
    bool_3 = bool(bool_2)
    bool_4 = bool(bool_3)
    if bool_4:
        str_2 = "1"
    else:
        str_2 = "0"
    str_1 = table_6.__init__(items=list_0, headers=list_0, widths=list_0, align=str_2)
    str_3 = code(int_0)
    list_1 = [str_3] * 2

# Generated at 2022-06-25 14:40:48.906068
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    Parser_0 = Parser()
    iterable_0 = None
    Parser_0.root = {}
    Parser_0.alias = iterable_0
    arg_0 = arg(name=None, annotation=None)
    str_0 = Parser_0.func_ann(name=None, args=[arg_0], has_self=None, cls_method=None)
    str_1 = str(str_0)


# Generated at 2022-06-25 14:40:57.043889
# Unit test for function walk_body

# Generated at 2022-06-25 14:41:00.330129
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    ##
    # Case 0
    ##
    node = Subscript(Name('typing.Optional', Load), Constant(None), Load())
    Resolver('', {}).visit_Subscript(node)


# Generated at 2022-06-25 14:41:04.559379
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    root_0 = None
    name_0 = None
    bases_0 = None
    body_0 = None
    p = Parser()
    p.class_api(root_0, name_0, bases_0, body_0)
    return None


# Generated at 2022-06-25 14:41:09.198855
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    node = Subscript(Name('node_value', Load), Tuple(elts=[Constant(None), Constant(None)], ctx=Load()), Load)
    r = Resolver('root', None)
    r.visit_Subscript(node)


# Generated at 2022-06-25 14:41:10.848764
# Unit test for function table
def test_table():
    test_case_0()

import unittest


# Generated at 2022-06-25 14:41:18.395743
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    parser = Parser(link=False)
    parser.func_api(
        '_',
        '_',
        arguments(
            args=[
                arg(arg='_', annotation=None)
            ],
            vararg=arg(arg='_', annotation=None),
            kwonlyargs=[],
            kw_defaults=[],
            defaults=[None]
        ),
        None,
        has_self=False, cls_method=False
    )


# Generated at 2022-06-25 14:41:21.279826
# Unit test for method api of class Parser
def test_Parser_api():
    assert Parser.api('root','node')
    assert Parser.api('root','node','prefix')
    assert Parser.api('root','node','prefix')


# Generated at 2022-06-25 14:46:28.138528
# Unit test for method api of class Parser
def test_Parser_api():
    from typing import Tuple, Mapping, Any, Callable
    import inspect
    import doctest
    from types import ModuleType
    from textwrap import dedent
    from ast import Module, parse, literal_eval
    from ast_pp.unparse import Unparser
    from ast_pp.walker import Walker
    from ast_pp.walker import Walkable
    from sast import get_docstring, get_type_comment
    import ast_pp.resolver
    import ast_pp.unparse
    import ast_pp.walker
    import ast_pp.walker
    import ast_pp.resolver
    import ast_pp.unparse
    import ast_pp.walker
    import ast_pp.walker
    import ast_pp.parser
    import sast

# Generated at 2022-06-25 14:46:31.427498
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    """Unit test for method func_ann of class Parser."""
    args_0 = None
    Parser_0 = Parser(None, None, None, None, None, None, None, None, None)
    Parser_0.func_ann("", args_0, has_self=False, cls_method=False)


# Generated at 2022-06-25 14:46:40.400858
# Unit test for function table
def test_table():
    # Test region
    iterable_0 = ['a', 'b']
    str_0 = table(items=iterable_0)
    assert str_0 == '|  |\n|:---:|\n| a |\n| b |\n\n'
    # Test region
    iterable_1 = [('c', 'd'), ('e', 'f')]
    str_1 = table(items=iterable_1)
    assert str_1 == '|  |  |\n|:---:|:---:|\n| c | d |\n| e | f |\n\n'
    # Test region
    iterable_2 = [('g', 'h'), ('i', 'j')]
    str_2 = table('a', 'b', items=iterable_2)
    assert str