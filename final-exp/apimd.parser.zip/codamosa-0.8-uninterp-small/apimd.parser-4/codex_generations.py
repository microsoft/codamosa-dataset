

# Generated at 2022-06-25 14:40:57.395025
# Unit test for function doctest
def test_doctest():
    test_case_0()

T = TypeVar('T')



# Generated at 2022-06-25 14:40:59.891487
# Unit test for function walk_body
def test_walk_body():
    str_0 = 'lYk{6&(80=#}\tI'
    str_1 = doctest(str_0)


# Generated at 2022-06-25 14:41:11.193489
# Unit test for method compile of class Parser
def test_Parser_compile():
    """
    [Parser.compile]
    """
    parser = Parser(['-', '__main__'], True)

    # file: my_package/init.py
    src_0 = """\"\"\"
    This is the main documentation.

    This is a package for sample code.

    *Full name:* `my_package`

    \"\"\"

    from . import foo
    from . import bar
    from . import baz

    __all__ = ['foo', 'bar', 'baz']

    pass

    """
    ast_0 = parse(src_0)
    parser.walk(ast_0, 'my_package')

    # file: my_package/foo.py

# Generated at 2022-06-25 14:41:14.574170
# Unit test for function walk_body
def test_walk_body():
    str_0 = 'lYk{6&(80=#}\tI'
    str_1 = doctest(str_0)


# Generated at 2022-06-25 14:41:15.503513
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    a: str
    b: str
