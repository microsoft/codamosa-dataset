

# Generated at 2022-06-25 14:41:50.661612
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    test_obj_0 = Resolver('', {}, '')
    test_obj_1 = 'self'
    test_obj_0.self_ty = test_obj_1
    int_0 = 2
    str_0 = 'name'
    dict_0 = {str_0: int_0}
    test_obj_1 = dict_0
    test_obj_0.alias = test_obj_1
    str_1 = 'root'
    int_1 = 1
    str_2 = 'name'
    dict_1 = {str_2: int_1}
    test_obj_1 = dict_1
    test_obj_0.alias = test_obj_1
    str_3 = 'root'
    test_obj_1 = str_3
    test_obj_0.root = test_obj

# Generated at 2022-06-25 14:41:55.908640
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    for str_0 in ['', '_', '__', 'hoge', '_hoge', '__hoge',
        '_hoge_piyo', '__hoge_piyo', '__hoge__piyo', '_0', '__0']:
        result = Parser.is_public(str_0)
        if is_public_family(str_0):
            assert(result == True)
        else:
            assert(result == False)


# Generated at 2022-06-25 14:42:06.478102
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    # test case 1
    root_0 = "pyslvs"
    alias_0 = {}
    self_ty = ""
    resolver = Resolver(root_0, alias_0, self_ty)
    node_0 = Name("T", Load())
    resolver.visit_Name(node_0)
    # test case 2
    root_1 = "pyslvs"
    alias_1 = {}
    self_ty = "Self"
    resolver = Resolver(root_1, alias_1, self_ty)
    node_1 = Name("Self", Load())
    resolver.visit_Name(node_1)
    # test case 3
    root_2 = "pyslvs"
    alias_2 = {}
    self_ty = "Self"

# Generated at 2022-06-25 14:42:08.830957
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    Resolver(root='x', alias=dict()).visit_Subscript(Subscript(Name('x', Load()), Index(Constant(0)), Load()))


# Generated at 2022-06-25 14:42:10.414250
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    Resolver('', dict()).visit_Subscript(Subscript(Name('', Load()), None, Load()))


# Generated at 2022-06-25 14:42:11.371606
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    pass


# Generated at 2022-06-25 14:42:20.090964
# Unit test for function walk_body
def test_walk_body():
    # Test case 1
    try_node = parse('''
        try:
            pass
        except Exception:
            pass
        finally:
            pass
    ''').body[0]
    assert isinstance(try_node, Try)
    assert len(list(walk_body([try_node]))) == 4
    # Test case 2
    if_node = parse('''
        if True:
            pass
    ''').body[0]
    assert isinstance(if_node, If)
    assert len(list(walk_body([if_node]))) == 1
    # Test case 3
    class_node = parse('''
        class A:
            def __init__(self):
                pass
    ''').body[0]
    assert isinstance(class_node, ClassDef)

# Generated at 2022-06-25 14:42:29.572062
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    import sys
    if sys.version_info.minor == 6:
        return
    import typing
    str_0 = '\x01\x15\x0c\x0f1'
    str_1 = '\x1f"\x0e\x17+'
    #str_0 = 'K\x03\x1c\x11'
    #str_1 = '\x16\x0e)4#'

# Generated at 2022-06-25 14:42:32.658004
# Unit test for function esc_underscore
def test_esc_underscore():
    assert test_case_0() == ']F\x0c>'



# Generated at 2022-06-25 14:42:36.054702
# Unit test for function table
def test_table():
    list_0 = ['a', 'b']
    list_1 = [['c', 'd'], ['e', 'f']]
    func_0 = table('a', 'b', [['c', 'd'], ['e', 'f']])


# Generated at 2022-06-25 14:43:52.397840
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    # First arg is the root module, second arg is the alias, just like a dict.
    resolver = Resolver('', {})
    # The line and col offset is not used in this function.
    node = Subscript(value=Name(id='', ctx=Load()),
                     slice=Tuple(
                        elts=[Constant(None)],
                        ctx=Load()),
                     ctx=Load())
    # Return a BinOp instance, with op being BitOr
    parsed = resolver.visit_Subscript(node)
    assert isinstance(parsed, BinOp)
    assert isinstance(parsed.op, BitOr)
    assert isinstance(parsed.left, Constant)
    assert parsed.left.value is None
    assert isinstance(parsed.right, Constant)

# Generated at 2022-06-25 14:44:03.589142
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    str_0 = 'y'
    str_1 = '.'
    str_2 = 's'
    str_3 = '2'
    str_4 = 'a'
    str_5 = 'T'
    str_6 = 'd'
    str_7 = 'e'
    str_8 = 'F'
    str_9 = 'r'
    root_0 = str_8 + str_5 + str_7 + str_1 + str_9 + str_0 + str_2 + str_1 + str_7 + str_4 + str_3 + str_1 + str_9 + str_0 + str_2 + str_0 + str_3 + str_1 + str_7 + str_4 + str_3 + str_1 + str_9 + str_0 + str_2 + str_1 + str

# Generated at 2022-06-25 14:44:05.295850
# Unit test for function doctest
def test_doctest():
    str_0 = 'l)?\tw23+-'
    str_1 = doctest(str_0)


# Generated at 2022-06-25 14:44:06.796489
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    import doctest
    doctest.testmod()

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 14:44:16.012150
# Unit test for method globals of class Parser
def test_Parser_globals():
    test_str_0 = 'wc_'
    test_str_1 = '_'
    test_str_2 = '_'
    test_str_3 = 'w'
    test_str_4 = '__'
    test_str_5 = '_'
    test_str_6 = '__'
    test_str_7 = '_'
    test_expr_0 = NameConstant(value=False)
    test_str_8 = '_'
    test_str_9 = '_'
    test_str_10 = 'w'
    test_str_11 = '__'
    test_str_12 = '_'
    test_str_13 = '__'
    test_str_14 = '_'
    test_str_15 = '__'
    test_str_

# Generated at 2022-06-25 14:44:20.879414
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    # Create an object of class Resolver
    resolver_0 = Resolver(None, None)
    node = Attribute()
    node.value = Name("b", Load())
    node.attr = "is_public_family"
    resolver_0.visit_Attribute(node)


# Generated at 2022-06-25 14:44:30.633888
# Unit test for method globals of class Parser
def test_Parser_globals():
    str_0 = 'l)?\tw23+-'
    list_0 = [str_0, str_0]
    list_1 = [str_0, str_0]
    list_2 = [str_0, str_0]
    list_3 = [str_0, str_0]
    parser = Parser(list_0, list_1, list_2, list_3, None)
    list_4 = [str_0, str_0]
    list_5 = [str_0, str_0]
    list_6 = [str_0, str_0]
    repr_0 = parser.globals(str_0, list_4, list_5, list_6, [str_0, str_0], None, None)
    assert repr_0 == None


# Generated at 2022-06-25 14:44:32.856146
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    resolver = Resolver('base', {})
    node = Name('a', Load())
    resolver.visit_Name(node)
    assert node.id == 'a'


# Generated at 2022-06-25 14:44:43.972122
# Unit test for method globals of class Parser
def test_Parser_globals():
    n = "ab"
    node = Assign()
    node_0 = node.__class__()
    node_0.targets = [Name()]
    node_0.__class__.targets = [Name()]
    node_0.targets = [Name()]
    node_0.__class__.returns = None
    node_0.returns = None
    node_0.__class__.returns = None
    node_0.returns = None
    node_0.__class__.returns = None
    node_0.returns = None
    node_0.__class__.returns = None
    node_0.returns = None
    node_0.__class__.returns = None
    node_0.returns = None
    node_0.__class

# Generated at 2022-06-25 14:44:45.439431
# Unit test for function doctest
def test_doctest():
    test_case_0()

# Verify the failure of test_case_0

# Generated at 2022-06-25 14:45:32.220257
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    str_0 = 'l)?\tw23+-'
    bool_0 = is_public_family(str_0)
    parser = Parser(str_0, file_name=str_0)
    bool_1 = parser.is_public(str_0)
    assert (bool_0 == bool_1)


# Generated at 2022-06-25 14:45:42.052825
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    root_0 = ''
    alias_0 = {}
    resolver_0 = Resolver(root_0, alias_0)
    id_0 = '__add__'
    ctx_0 = Load()
    name_0 = Name(id_0, ctx_0)
    resolver_0.visit_Name(name_0)
    root_1 = 'abc'
    alias_1 = {}
    resolver_1 = Resolver(root_1, alias_1)
    id_1 = '__add__'
    ctx_1 = Load()
    name_1 = Name(id_1, ctx_1)
    resolver_1.visit_Name(name_1)
    root_2 = ''
    alias_2 = {}

# Generated at 2022-06-25 14:45:46.550280
# Unit test for method parse of class Parser
def test_Parser_parse():
    print()
    print("# Unit test for method parse of class Parser")
    print()

    p = Parser()
    with open_path('./tests/cases/q00.py') as f:
        p.parse(f.read())


# Generated at 2022-06-25 14:45:54.763685
# Unit test for method api of class Parser
def test_Parser_api():
    root_0 = 'test.test_0'
    alias_0 = {'test.test_0.test_0_0': 'test_0_0'}
    doc_0 = {}
    docstring_0 = {}
    root_1 = {}
    level_1 = {}
    imp_1 = {'test.test_0': set()}
    const_1 = {}
    alias_1 = {'test.test_0.test_0_0': 'test_0_0'}
    b_level_2 = 1
    link_2 = True
    toc_2 = True
    parser_0 = Parser(doc_0, docstring_0, root_1, level_1, imp_1, const_1, alias_1, b_level_2, link_2, toc_2)



# Generated at 2022-06-25 14:46:04.975583
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    class TestClass(Resolver):
        def __init__(self, bool_0, bool_1, bool_2, bool_3, bool_4, bool_5, bool_6, bool_7, bool_8, bool_9, bool_10, bool_11, bool_12, bool_13, bool_14, bool_15, bool_16, bool_17, bool_18, bool_19, bool_20, bool_21, bool_22, bool_23, bool_24, bool_25, bool_26, bool_27, bool_28):
            self.bool_0 = bool_0
            self.bool_1 = bool_1
            self.bool_2 = bool_2
            self.bool_3 = bool_3
            self.bool_4 = bool_4
            self.bool_5 = bool_5

# Generated at 2022-06-25 14:46:09.131534
# Unit test for function esc_underscore
def test_esc_underscore():
    str_0 = "a_b"
    bool_0 = True
    assert bool_0 == esc_underscore(str_0).count(r"\_") > 1

    str_0 = "a"
    bool_0 = True
    assert bool_0 == esc_underscore(str_0).count(r"\_") == 0



# Generated at 2022-06-25 14:46:18.538905
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    # initialize objects
    arg_0 = arg('a', None)
    arg_1 = arg('b', None)
    arg_2 = arg('c', None)
    arg_3 = arg('d', None)
    arg_4 = arg('e', None)
    arg_5 = arg('f', None)
    arg_6 = arg('g', None)
    arg_7 = arg('h', None)
    arg_8 = arg('i', None)
    arg_9 = arg('j', None)
    arg_10 = arg('k', None)
    arg_11 = arg('l', None)
    arg_12 = arg('m', None)
    arg_13 = arg('*', None)
    arg_14 = arg('**', None)
    arg_15 = arg('return', None)
    list

# Generated at 2022-06-25 14:46:22.644157
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    root = "module_0"
    alias = {"module_0.name_0": "int", "module_0.name_1": "str"}
    self_ty = "Self"
    resolver_obj = Resolver(root, alias, self_ty)
    node_obj = Name(id="name_0", ctx=Load())
    assert resolver_obj.visit_Name(node_obj) == Name(id="int", ctx=Load())


# Generated at 2022-06-25 14:46:25.360513
# Unit test for method imports of class Parser
def test_Parser_imports():
    root = 'A'
    node = None
    parser = Parser()
    parser.imports(root, node)
    assert True


# Generated at 2022-06-25 14:46:34.149835
# Unit test for method api of class Parser
def test_Parser_api():
    str_0 = '#'
    str_1 = ''
    str_2 = ''
    doc_0 = '#  {}()\n\n*Full name:* `{}`\n\n'
    num_0 = 1
    int_0 = 0
    bool_0 = False
    func_0 = Parser.api
    par_0 = [str_2, func_0, str_2]
    par_1 = [str_0, str_1, par_0, num_0]
    func_1 = Parser.__init__
    par_2 = par_1
    par_3 = [str_2, func_1, par_2]
    func_2 = Parser.__init__
    par_4 = par_3