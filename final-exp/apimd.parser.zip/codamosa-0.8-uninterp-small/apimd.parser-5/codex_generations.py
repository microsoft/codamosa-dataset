

# Generated at 2022-06-25 14:43:39.594855
# Unit test for method globals of class Parser
def test_Parser_globals():
    parser_0 = Parser()
    body_0 = [Assign(targets=[Name(id='N', ctx=Store())], value=Constant(value=10))]
    parser_0.globals('', body_0[0])
    assert parser_0.alias == {'N': '10'}
    assert parser_0.root == {'N': ''}
    assert parser_0.const == {'N': 'int'}
    body_1 = [Assign(targets=[Name(id='x', ctx=Store())], value=Constant(value=10))]
    parser_0.globals('', body_1[0])
    assert parser_0.alias == {'N': '10'}
    assert parser_0.root == {'N': ''}
    assert parser

# Generated at 2022-06-25 14:43:42.427144
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    parser_0 = Parser()
    assert parser_0.is_public('_abc') == False
    assert parser_0.is_public('abc') == True
    assert parser_0.is_public('ABC') == True


# Generated at 2022-06-25 14:43:45.096757
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    import ast
    alias = {'typing': 'typing'}
    resolver = Resolver('', alias)
    node = ast.Attribute(value=ast.Name(id='typing', ctx=ast.Load()),
                         attr='List', ctx=ast.Load())
    resolver.visit_Attribute(node)


# Generated at 2022-06-25 14:43:49.675864
# Unit test for function walk_body
def test_walk_body():
    parser_1 = Parser()
    b = [Assign(targets=[Name(id='a', ctx=Store())],
      value=Constant(value=1, kind=None)), Assign(targets=[Name(id='a', ctx=Store())],
      value=Constant(value=2, kind=None))]
    i = walk_body(b)
    for each in i:
        print(each)


# Generated at 2022-06-25 14:43:55.463584
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore('_') == r"\_"
    assert esc_underscore('_test') == r"\_test"
    assert esc_underscore('test_') == r"test\_"
    assert esc_underscore('test') == r"test"
    assert esc_underscore('test_test') == r"test_test"


# Generated at 2022-06-25 14:44:05.393887
# Unit test for method api of class Parser
def test_Parser_api():
    parser_0 = Parser()
    p = parser_0.api(["_", ""])
    assert p == _m("_", "")
    assert "".join(p) in ["_", "_"]
    assert "".join(p) in ["_", "_"]
    p = parser_0.api(["_", ""])
    assert p == _m("_", "")
    assert "".join(p) in ["_", "_"]
    assert "".join(p) in ["_", "_"]
    parser_1 = Parser()
    a = parser_1.api(["_", ""])
    assert a == _m("_", "")
    assert "".join(a) in ["_", "_"]
    assert "".join(a) in ["_", "_"]

# Generated at 2022-06-25 14:44:11.434269
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    parser_func_api = Parser()
    root = "test_root_str"
    name = "test_name_str"
    node = arguments()
    node.posonlyargs = [arg(), arg()]
    node.args = [arg()]
    node.defaults = [NameConstant(), NameConstant()]
    node.vararg = arg()
    node.kwonlyargs = [arg()]
    node.kw_defaults = [NameConstant()]
    node.kwarg = arg()
    
    returns = NameConstant()
    has_self = True
    cls_method = False
    parser_func_api.func_api(root, name, node, returns, has_self, cls_method)


# Generated at 2022-06-25 14:44:18.916242
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    parser_0 = Parser()
    with pytest.raises(Exception) as pytest_wrapped_e:
        parser_0.class_api('str', 'str', [], [])
    assert 'Invalid type `str` for root' in str(pytest_wrapped_e.value)
    parser_1 = Parser()
    with pytest.raises(Exception) as pytest_wrapped_e:
        parser_1.class_api('./', './', [], [])
    assert 'Invalid type `.` for root' in str(pytest_wrapped_e.value)
    parser_2 = Parser()
    with pytest.raises(Exception) as pytest_wrapped_e:
        parser_2.class_api('', '', [], [])

# Generated at 2022-06-25 14:44:20.229231
# Unit test for method compile of class Parser
def test_Parser_compile():
    test_parser = Parser()
    assert(test_parser.compile() == '')

# Generated at 2022-06-25 14:44:30.023530
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    aliases = {'typing.Optional': 'typing_Optional', 'typing.Union': 'typing_Union'}
    # Initialize two optional node
    node_0 = Subscript(Name('typing', Load()), Tuple(elts=[Name('int', Load())], ctx=Load()), Load())
    node_1 = Subscript(Name('typing', Load()), Tuple(elts=[Name('int', Load())], ctx=Load()), Load())
    # Test whether node_2 is the same as node_1 after visiting node_0
    node_2 = Resolver.visit_Subscript(Resolver('', aliases), node_0)
    assert node_1 == node_2
    # Test whether node_3 is different from node_1 after visiting node_0 with a different module root
    node_3 = Res

# Generated at 2022-06-25 14:45:28.685870
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    parser = Parser()
    # write code to test func_ann
    # test case 1
    parser_1 = Parser()
    # method func_ann
    # assert "type[Self]" in parser_1.func_ann(root, args, has_self=True, cls_method=False)
    assert "int" in parser_1.func_ann(root, args, has_self=False, cls_method=False)
    assert "List[int]" in parser_1.func_ann(root, args, has_self=False, cls_method=False)
    assert "Dict[str, str]" in parser_1.func_ann(root, args, has_self=False, cls_method=False)
    # method resolve
    parser_1.alias[alias] = expression
    assert parser_1

# Generated at 2022-06-25 14:45:33.313347
# Unit test for function const_type
def test_const_type():
    test_0 = const_type(Constant(value=True, kind=None))
    if (test_0 != 'bool'):
        print(test_0)
        print('Fail')
    else:
        print('Test case 0: Pass')


# Generated at 2022-06-25 14:45:42.650891
# Unit test for method api of class Parser
def test_Parser_api():
    cached_1 = Parser()
    cached_2 = Parser()
    cached_3 = Parser()
    cached_4 = Parser()
    cached_5 = Parser()
    cached_6 = Parser()
    cached_7 = Parser()
    cached_8 = Parser()
    cached_9 = Parser()
    cached_10 = Parser()
    cached_11 = Parser()
    cached_12 = Parser()
    cached_13 = Parser()
    cached_14 = Parser()
    cached_15 = Parser()
    cached_16 = Parser()
    cached_17 = Parser()
    cached_18 = Parser()
    cached_19 = Parser()
    cached_20 = Parser()
    cached_21 = Parser()
    cached_22 = Parser()
   

# Generated at 2022-06-25 14:45:51.237722
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    parser_0 = Parser()

    print("Test 0 (method func_api of class Parser)")
    try:
        parser_0.func_api("hello", "hello", arguments(args=[arg("hello", None)], vararg=None, kwonlyargs=[arg("*", None)], kw_defaults=[], kwarg=None, defaults=[]), None, has_self=True, cls_method=True)
    except Exception as e:
        traceback.print_exc()
        print(e)


# Generated at 2022-06-25 14:45:52.996069
# Unit test for method globals of class Parser
def test_Parser_globals():
    parser_0 = Parser()
    root_str = ''
    node_bool = bool()
    parser_0.globals(root_str, node_bool)


# Generated at 2022-06-25 14:45:56.579457
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    parser_0 = Parser()
    parser_0.visit_Subscript()
    parser_1 = Parser()
    parser_1.visit_Subscript()


# Generated at 2022-06-25 14:45:58.030151
# Unit test for method imports of class Parser
def test_Parser_imports():
    parser_0 = Parser()
    assert True


# Generated at 2022-06-25 14:46:08.204818
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    parser_1 = Resolver(root='', alias={}, self_ty='')
    node_1 = Attribute(value=Name(id='typing', ctx=Load()), attr=ANY)
    assert parser_1.visit_Attribute(node=node_1) == Name(id=ANY, ctx=Load())
    parser_2 = Resolver(root='', alias={}, self_ty='')
    node_2 = Attribute(value=Name(id='abc', ctx=Load()), attr=ANY)
    assert parser_2.visit_Attribute(node=node_2) == Attribute(value=Name(id='abc', ctx=Load()), attr=ANY, ctx=Load())


# Generated at 2022-06-25 14:46:16.978287
# Unit test for method imports of class Parser
def test_Parser_imports():
    parser_1 = Parser(b_level=1)
    import os
    import time
    module_1 = Module(
        body=[
            ImportFrom(
                module='os',
                names=[alias('path', 'p')],
                level=1,
                type_comment=None
            ),
            ImportFrom(
                module='time',
                names=[alias('sleep')],
                level=0,
                type_comment=None
            )
        ],
        type_ignores=[]
    )
    parser_1.imports('', module_1)
    assert parser_1.alias == {'os.path': 'os.path', 'time.sleep': 'time.sleep'}


# Generated at 2022-06-25 14:46:19.710264
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    parser_0 = Parser()
    root = '.'
    name = '.'
    bases = []
    body = []
    parser_0.class_api(root, name, bases, body)
