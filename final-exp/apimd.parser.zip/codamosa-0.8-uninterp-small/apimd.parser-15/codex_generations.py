

# Generated at 2022-06-25 14:44:17.486267
# Unit test for method globals of class Parser
def test_Parser_globals():
    pass


# Generated at 2022-06-25 14:44:19.750346
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    """Unit test for method class_api of class Parser"""
    pass


# Generated at 2022-06-25 14:44:22.123572
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    Parser(link=bool(), b_level=int(), toc=bool())
    assert raise_(AssertionError, Parser.is_public, "s")


# Generated at 2022-06-25 14:44:23.217940
# Unit test for function const_type
def test_const_type():
    test_case_0()


# Generated at 2022-06-25 14:44:26.744877
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    obj = Parser()
    root = str()
    name = str()
    bases = [expr()]
    body = [stmt()]
    obj.class_api(root, name, bases, body)


# Generated at 2022-06-25 14:44:28.867775
# Unit test for function const_type
def test_const_type():
    expr_0 = module_0.expr()
    str_0 = const_type(expr_0)
    assert str_0 is None


# Generated at 2022-06-25 14:44:30.465900
# Unit test for function table
def test_table():
    result = table('a', 'b', [['c', 'd'], ['e', 'f']])
    assert result == '''| a | b |
|:---:|:---:|
| c | d |
| e | f |

'''


# Generated at 2022-06-25 14:44:36.986229
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    element_1 = module_0.ast_Node()
    element_2 = module_0.ast_Node()
    slice_0 = module_0.Tuple(elts=[element_1], ctx=module_0.Load())
    value_0 = module_0.Name(id='Union', ctx=module_0.Load())
    node_0 = module_0.Subscript(value=value_0, slice=slice_0, ctx=module_0.Load())
    root_0 = ''
    alias_0 = {'typing.Union': 'typing.Union'}
    self_ty_0 = ''
    resolver_0 = ast.Resolver(root=root_0, alias=alias_0, self_ty=self_ty_0)

# Generated at 2022-06-25 14:44:40.570977
# Unit test for function const_type
def test_const_type():
  test_case_0()

from .pep585 import PEP585
from .pep484 import PEP484, PEP484_Alias
from .pep484_alias import PEP484_Alias
from .pep484 import PEP484


# Generated at 2022-06-25 14:44:46.023628
# Unit test for function doctest
def test_doctest():
    doctest_0 = doctest(r'''
        >>> data = [0, 1]
        >>> sum(data)
        1
    ''')
    assert(doctest_0 == "```python\n        >>> data = [0, 1]\n        >>> sum(data)\n        1\n    ```")