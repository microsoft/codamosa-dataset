

# Generated at 2022-06-25 14:39:50.835070
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    str_0 = 'Bo1Q'
    p = Parser()
    assert p.is_public(str_0)
    p = Parser()
    assert p.is_public(str_0)


# Generated at 2022-06-25 14:39:58.391214
# Unit test for method api of class Parser
def test_Parser_api():
    _ = ModuleType('_')
    _.e = Enum('Enum', 'a b')
    _.e.a
    _.e.b
    _.e.c
    _.inner = type('inner', (), {})
    _.inner.class_method = classmethod(lambda: "")
    _.inner.static_method = staticmethod(lambda: "")
    _.inner.method = lambda: "", "", "", "", "", "", "", "", "", ""
    _.inner.method.__doc__ = "test doc"
    _.inner.cls_field = "cls field"
    _.inner.s_field = "s field"
    _.inner.field = "field"
    _.inner.int_field = 1

# Generated at 2022-06-25 14:40:03.422820
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser()
    p.func_api('aaa', 'bbb', 'ccc', 'ddd', has_self=True)
    p.func_ann('aaa', ('eee', 'fff'))
    p.resolve('aaa', 'ggg', 'hhh')


# Generated at 2022-06-25 14:40:05.763437
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    test_obj = Parser('./', [])
    p = test_obj.is_public('a')
    assert p == True


# Generated at 2022-06-25 14:40:09.999291
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser(add_toc=False)
    p.imp['__test__.sample'] = set()
    assert p.is_public('__test__.sample')
    assert p.is_public('__test__.sample.a')
    assert not p.is_public('sample.a')


# Generated at 2022-06-25 14:40:20.056015
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    # Test the case
    # str_0 = 'Bo1Q'
    # str_1 = code(str_0)
    str_0 = 'self'
    str_1 = 'return'
    int_2 = 0
    str_3 = '_pymake'
    str_4 = 'boolean'
    str_5 = '*'
    str_6 = 'Any'
    str_7 = 'Str'
    str_8 = 'Union[str, List[str], Tuple[str, ...]]'
    int_9 = 0
    str_10 = '*'
    str_11 = 'Any'
    str_12 = 'Str'
    str_13 = 'Union[str, List[str], Tuple[str, ...]]'
    int_14 = 0

# Generated at 2022-06-25 14:40:29.933502
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    my_Subscript = Subscript(value=Name(id='Union', ctx=Load()), slice=Tuple(elts=[Name(id='x', ctx=Load()), Name(id='y', ctx=Load())], ctx=Load()), ctx=Load())
    root = 'my_module'
    alias = {'my_module.Union': 'xxx'}
    self_ty = "self"
    new_attribute = Resolver(root=root, alias=alias, self_ty=self_ty).visit_Subscript(node=my_Subscript)
    if str(new_attribute) != 'x | y':
        print('Unit test failed')
        return
    print('Unit test passed')


# Generated at 2022-06-25 14:40:39.439972
# Unit test for function const_type
def test_const_type():
    # 1. Test for simple string
    node_0 = Constant(value='Bo1Q', kind=None)
    assert const_type(node_0) == 'str'

    # 2. Test for list of string
    node_1 = List(elts=[node_0, node_0, node_0], ctx=Load())
    assert const_type(node_1) == 'list[str, str, str]'

    # 3. Test for dict of int and string
    node_2 = Constant(value=0, kind=None)
    dict_0 = Dict(keys=[node_2, node_2], values=[node_0, node_0], ctx=Load())
    assert const_type(dict_0) == 'dict[int, str]'

    # 4. Test for bool

# Generated at 2022-06-25 14:40:44.926798
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    from asttools import ast
    from asttools.visit import Visitor

    class FuncArgs(Visitor):
        def __init__(self, node: _I) -> None:
            self.args = []
            self.has_self = False
            self.cls_method = False
            self.__evaluate(node)

        def __evaluate(self, node: _I) -> None:
            if not isinstance(node, FunctionDef):
                return
            self.args = node.args.args
            self.has_self = any(is_self(a.id) for a in self.args)
            self.cls_method = any(
                '@classmethod' in d.id for d in node.decorator_list)

    # Test case 0
    name = 'test_case_0'
    root

# Generated at 2022-06-25 14:40:46.789422
# Unit test for method imports of class Parser
def test_Parser_imports():
    root = 'str'
    node = Import([alias('a', 'b')])
    try:
        parser_0 = Parser(False, False, 2)
        parser_0.imports(root, node)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 14:42:01.306793
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    def test_case_0():
        p = Parser(level=0, link=True, toc=True)
        p.func_ann(root='test_case_0', args=[], has_self=False, cls_method=False)
        assert p._Parser__output == ''
    test_case_0()


# Generated at 2022-06-25 14:42:02.257515
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    str_0 = 'test_Parser_is_public'


# Generated at 2022-06-25 14:42:03.917249
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    # Test for a scenario where the root and s are same
    # TODO: Use assertEqual
    assert (Parser.is_public('test_case_0')) == True


# Generated at 2022-06-25 14:42:09.617518
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    """test_Resolver_visit_Attribute"""
    str_0 = 'test_Resolver_visit_Attribute'
    instance_0 = Resolver(str_0, {str_0: str_0})
    assert instance_0.visit_Attribute(Attribute(Name('typing', Load), 'str', Load())) == Name('str', Load())


# Generated at 2022-06-25 14:42:14.543740
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    m = Module(body=[])
    parser = Parser(m)
    root = 'root'
    name = 'name'
    node = ClassDef(name='ClassDef', bases=[], body=[])
    # Test body of method class_api
    assert parser.class_api(root, name, node.bases, node.body) == None


# Generated at 2022-06-25 14:42:21.407184
# Unit test for method globals of class Parser

# Generated at 2022-06-25 14:42:28.273367
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    parser = Parser(['test_case_0'], title='N/A', toc='N/A', link='N/A')
    # Test 0: <Module name='N/A' file='N/A'>
    # Expect: ['N/A', 'N/A', 'N/A']
    assert list(parser.func_ann(root='N/A', args=[arg(arg='N/A', annotation='N/A'),
                                                  arg(arg='N/A', annotation='N/A'),
                                                  arg(arg='N/A', annotation='N/A')],
                                has_self='N/A',
                                cls_method='N/A'))\
                                                  == ['N/A', 'N/A', 'N/A'], 'Test 0'

# Generated at 2022-06-25 14:42:29.400148
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    str_0 = 'test_Parser_func_ann_0'


# Generated at 2022-06-25 14:42:39.869039
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    with patch.object(__name__ + '.Parser', 'func_api',
                      return_value=None) as mock_method_trace,\
        patch.object(__name__ + '.Parser', 'resolve',
                     return_value=str_0) as mock_method_resolve:
        str_arg_0 = 'test_str_0'
        int_arg_1 = 0
        str_arg_2 = 'test_str_1'
        str_arg_3 = 'test_str_2'
        str_arg_4 = 'test_str_3'
        int_arg_5 = 1
        str_0 = 'test_case_0'
        obj = Parser()

# Generated at 2022-06-25 14:42:49.127569
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    R = Resolver(None, None)
    Subscript = test_case_0()
    test_Resolver_visit_Subscript_0 = test_Resolver_visit_Subscript_0()
    Slice = test_Resolver_visit_Subscript_0.slice
    Ctx = test_Resolver_visit_Subscript_0.ctx
    test_Resolver_visit_Subscript_0.value
    id_0 = test_Resolver_visit_Subscript_0.value
    result = R.visit_Subscript(test_Resolver_visit_Subscript_0)

# Generated at 2022-06-25 14:44:57.752924
# Unit test for function const_type
def test_const_type():
    ...

    return str_0


# Generated at 2022-06-25 14:44:59.128020
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    str_0 = 'test_Parser_class_api'



# Generated at 2022-06-25 14:45:02.162500
# Unit test for function walk_body
def test_walk_body():
    def test_case_1():
        str_1 = 'test_case_1'
        if True:
            def test_case_2():
                str_2 = 'test_case_2'
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 14:45:05.958592
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    # Init Parser object
    py_0 = PythonEditor('<input>', 'test_case_0.py')
    # Init Parser obj
    p_0 = Parser(py_0.read())
    # Get class_api of p_0
    r_0 = p_0.class_api('test_case_0', 'test_case_0')
    # Verify
    assert isinstance(r_0, NoneType)


# Generated at 2022-06-25 14:45:07.618149
# Unit test for method globals of class Parser
def test_Parser_globals():
    test_case_0()    
    str_1 = 'test_Parser_globals'


# Generated at 2022-06-25 14:45:11.627212
# Unit test for function walk_body
def test_walk_body():
    func_body = getattr(test_case_0, 'body')
    for body in walk_body(func_body):
        if isinstance(body, Assign):
            assert body.targets[0].id == 'str_0'
            assert body.value.s == 'test_case_0'


# Generated at 2022-06-25 14:45:20.072092
# Unit test for method compile of class Parser
def test_Parser_compile():
    case_0 = Parser()
    case_0.imp['test_case_0'] = {'test_case_0'}
    case_0.root['test_case_0'] = 'test_case_0'
    case_0.level['test_case_0'] = 0
    case_0.doc['test_case_0'] = '# test_case_0\n\n*Full name:* `test_case_0`\n<a id="test-case-0"></a>\n\n'
    case_0.docstring['test_case_0'] = ''
    assert case_0.compile() == '# test_case_0\n\n*Full name:* `test_case_0`\n<a id="test-case-0"></a>\n\n'
   

# Generated at 2022-06-25 14:45:28.221381
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    str_0 = None
    int_0 = Resolver(str_0, {}, str_0).visit_Subscript(Subscript(Name('Union', Load), Tuple([]), Load()))
    assert int_0.__class__.__name__ == 'Tuple'
    str_1 = str_0
    str_2 = str_0
    str_3 = str_0
    str_4 = str_0
    int_1 = Resolver(str_4, {}, str_1).visit_Subscript(Subscript(Name('Optional', Load), NameConstant(None), Load()))
    assert int_1.__class__.__name__ == 'BinOp'


# Generated at 2022-06-25 14:45:30.982770
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    parser_0 = Parser(True)
    root_0 = 'root_0'
    name_0 = 'name_0'
    bases_0 = ['bases_0']
    body_0 = [stmt('body_0_0', None), stmt('body_0_1', None)]
    parser_0.class_api(root_0, name_0, bases_0, body_0)


# Generated at 2022-06-25 14:45:41.922005
# Unit test for function const_type
def test_const_type():
    # Test for function `const_type`.
    # Case 0
    node = parse('True').body[0].value
    assert const_type(node) == 'bool'
    # Case 1
    node = parse('(1, 2, 3)').body[0].value
    assert const_type(node) == 'Tuple[int]'
    # Case 2
    node = parse('dict(a=1, b=2)').body[0].value
    assert const_type(node) == 'dict[str, int]'
    # Case 3
    node = parse('1 + 2').body[0].value
    assert const_type(node) == ANY
    # Case 4
    node = parse('...').body[0].value
    assert const_type(node) == ANY
    # Case 5