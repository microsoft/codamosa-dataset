

# Generated at 2022-06-25 14:42:08.059954
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    idf = 'typing.TypeVar'
    name = _m(Resolver.root, Resolver.id)
    if name in Resolver.alias and name not in Resolver.alias[name]:
        e = cast(Expr, parse(Resolver.alias[name]).body[0])
    value = Resolver.alias.get(_m(Resolver.root, Resolver.func_name), Resolver.func_name)
    return_val = self.visit(Resolver.e.value)


# Generated at 2022-06-25 14:42:10.274152
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    test_case_0()
    str_0 = 'G>iJ%<G'
    str_1 = code(str_0)
    assert str_0 == str_1


# Generated at 2022-06-25 14:42:18.459188
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    def test_Parser_class_api_0():
        method = Parser()
        root = 'self'
        name = 'self'
        def test_Parser_class_api_0_0(self):
            pass
        node = test_Parser_class_api_0_0
        body = node.body
        method.class_api(root, name, node.bases, body)
    def test_Parser_class_api_1():
        method = Parser()
        root = 'self'
        name = 'self'
        def test_Parser_class_api_1_0(self):
            def test_Parser_class_api_1_0_0(self):
                pass
            self.test_Parser_class_api_1_0_0 = test_Parser_class_api_1_0_0


# Generated at 2022-06-25 14:42:26.024765
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    class Resolver(NodeTransformer):
        def visit_Subscript(self, node: Subscript) -> AST:
            print(node.slice)
            return node

    resolver = Resolver()
    ast_expr = Expr(Subscript(Name('field_type', Load()),
                              Tuple([Name('int', Load()), Name('str', Load())], Load()),
                              Load()))
    resolver.visit(ast_expr)
    print(unparse(ast_expr))
    return unparse(ast_expr)


# Generated at 2022-06-25 14:42:33.686734
# Unit test for function const_type
def test_const_type():
    # Check for Constant
    str_0 = 'abc'
    node_0 = Constant(str_0)
    assert (const_type(node_0) == 'str')

    # Check for Tuple
    str_1 = 'a'
    node_1 = Constant(str_1)
    node_2 = Tuple([node_1], Load())
    assert (const_type(node_2) == 'tuple[str]')
    
    # Check for List
    str_2 = 'c'
    node_3 = Constant(str_2)
    node_4 = List([node_3], Load())
    assert (const_type(node_4) == 'list[str]')
    
    # Check for Set
    str_3 = 'd'
    node_5 = Constant(str_3)
    node

# Generated at 2022-06-25 14:42:36.901908
# Unit test for method globals of class Parser
def test_Parser_globals():
    m = {}
    P = Parser(m)
    node = ast.parse('A = 1')
    P.globals('', node.body[0])
    assert m['A'] == '1'


# Generated at 2022-06-25 14:42:42.468473
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    str_0 = 'G>iJ%<G'
    root = code(str_0)
    str_0 = 'Zn[H&'
    alias = {code(str_0): 'X9kqWg=;%cj<5'}
    str_0 = '1z4i'
    self_ty = code(str_0)
    const = Constant('G>iJ%<G')
    resolver = Resolver(root, alias, self_ty)
    resolver.visit(const)


# Generated at 2022-06-25 14:42:46.747142
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    str_0 = """
    def func(arg: str, *args: int, **kwargs: float) -> int: ...
    """
    str_1 = """
    import typing as ty
    class Dummy:
        def __init__(self, cls: ty.Type[ABC]) -> None: ...
    """
    str_2 = """
    class Dummy(ABC, metaclass=type): ...
    """
    obj_0 = Parser()
    obj_1 = obj_0.resolve
    obj_2 = obj_0.func_ann
    obj_3 = obj_0.load_docstring
    obj_4 = _parse(str_0)
    obj_5 = obj_4.body[0]
    obj_6 = obj_4.body[0].args
    obj_7 = obj

# Generated at 2022-06-25 14:42:52.880169
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    str_0 = '}j8%{wFH#@'
    str_1 = 'Y_GT'
    str_2 = 'miH<QEf'
    str_3 = 'M{nT'
    str_4 = 'nj;bPq'
    str_5 = '}]{F_)G'
    str_6 = 'XKjgQf;'
    str_7 = '~5v5&2g'
    str_8 = '4;'
    str_9 = 'y@0jy'
    str_10 = '|w#i'
    str_11 = 'F&-k'
    arg_0 = arg(str_0, str_1, str_2, str_3)

# Generated at 2022-06-25 14:42:53.833341
# Unit test for method parse of class Parser

# Generated at 2022-06-25 14:44:19.513818
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    _ = Resolver("", {})
    name = Name("name", Load())
    assert name == _.visit(name)
    name = Name("name", Load())
    assert name == _.visit(name)


# Generated at 2022-06-25 14:44:22.809149
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    # Initialization of the parser
    parser = Parser()
    # TypeError exception expected because of wrong type of the first argument passed to parser.is_public
    with raises(TypeError):
        assert parser.is_public(str_0)


# Generated at 2022-06-25 14:44:32.024663
# Unit test for function walk_body

# Generated at 2022-06-25 14:44:43.067392
# Unit test for function const_type
def test_const_type():
    assert const_type(Subscript(arg(arg=arg(arg='a', id='a'), id='b'),
                                slice=Index(value=Constant(value=1)))) == 'int'
    assert const_type(BinOp(left=Constant(value=1), op=BitOr(),
                            right=Constant(value=2))) == 'int'
    assert const_type(UnaryOp(op=USub(), operand=Constant(value=1))) == 'int'
    assert const_type(BoolOp(op=And(), values=[Constant(value=True),
                                               Constant(value=False)])) == 'bool'

# Generated at 2022-06-25 14:44:52.968523
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()

# Generated at 2022-06-25 14:45:01.355698
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    import doctest
    import re
    import sys
    stdout, sys.stdout = sys.stdout, sys.__stdout__
    doctest.testmod()

    def print(*args, **kwargs) -> None:
        kwargs['end'] = kwargs.get('end', '') + '\n'
        sys.stdout.print(*args, **kwargs)
    print = print
    sys.stdout = stdout
    def repl(m: Match[str]) -> str:
        class_name = m.group(1)
        module = sys.modules[m.group(2)]
        if class_name == 'Foo':
            return 'class Bar'
        elif class_name == 'Foo2':
            return 'class Bar2(Enum):'

# Generated at 2022-06-25 14:45:02.213516
# Unit test for method api of class Parser

# Generated at 2022-06-25 14:45:03.886897
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    _0 = Parser()
    _1 = '.'
    _1 = _0.is_public(_1)


# Generated at 2022-06-25 14:45:09.736125
# Unit test for function table
def test_table():
    str_0 = '6rn#8~nv8mG|Ee\\+xQ&s'
    str_1 = parent(str_0)
    str_2 = ''.join(['&#124;\n', '@', '\n|'])
    str_3 = '\n'.join(['|a|b|', '|:---:|:---:|', '| c | d |', '| e | f |'])



# Generated at 2022-06-25 14:45:16.923094
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    str_0 = '6rn#8~nv8mG|Ee\\+xQ&s'
    str_1 = parent(str_0)
    str_2 = parent(str_1)
    str_3 = parent(str_2)
    str_4 = parent(str_3)
    str_5 = parent(str_4)
    str_6 = parent(str_5)
    str_7 = parent(str_6)
    str_8 = parent(str_7)
    str_9 = parent(str_8)
    str_10 = parent(str_9)
