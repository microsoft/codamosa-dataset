

# Generated at 2022-06-11 19:29:52.334202
# Unit test for function const_type
def test_const_type():
    assert const_type(parse('True').body[0].value) == 'bool'
    assert const_type(parse('1').body[0].value) == 'int'
    assert const_type(parse('1.5').body[0].value) == 'float'
    assert const_type(parse('1 + 2j').body[0].value) == 'complex'
    assert const_type(parse('"abc"').body[0].value) == 'str'
    assert const_type(parse('int(1)').body[0].value) == 'int'

# Generated at 2022-06-11 19:29:57.185470
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    r = Resolver("test", {'test': '', 'test.a': 'test.b'})
    assert r.visit(Subscript(Name('a', Load()),
                             Tuple([Constant(1), Constant(2)], Load()),
                             Load())).__class__ == Subscript
    assert r.visit(Subscript(Name('b', Load()),
                             Tuple([Constant(1), Constant(2)], Load()),
                             Load())).__class__ == Tuple
    assert r.visit(Name("a", Load())).__class__ == Name
    assert r.visit(Name("b", Load())).__class__ == Tuple



# Generated at 2022-06-11 19:30:01.919528
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    name = "typing.List"
    r = Resolver("x", {name: name})
    n = Attribute(Name("typing", Load()), "List", Load())
    # Now n = typing.List
    assert unparse(n) == "typing.List"
    assert unparse(r.visit(n)) == "List"



# Generated at 2022-06-11 19:30:12.751440
# Unit test for method parse of class Parser
def test_Parser_parse():
    from javaproperties import Properties
    from pathlib import Path
    from unittest import TestCase
    from unittest.mock import patch
    from apidoc import Parser, Builder

    class _Test(TestCase):
        """Test."""

        def setUp(self):
            """Set up."""
            from sys import executable
            from pathlib import Path
            from subprocess import check_output
            import jsonschema
            from tempfile import gettempdir

            self.temp = Path(gettempdir()) / 'apidoc'
            self.temp.mkdir(parents=True, exist_ok=True)
            self.parser = Parser(self.temp)
            self.builder = Builder(self.temp)

# Generated at 2022-06-11 19:30:16.512400
# Unit test for function const_type
def test_const_type():
    assert const_type(Constant(True)) == 'bool'
    assert const_type(Constant(1)) == 'int'
    assert const_type(Constant(1.0)) == 'float'
    assert const_type(Constant(1 + 1j)) == 'complex'
    assert const_type(Constant('pyslvs')) == 'str'
    assert const_type(Tuple([], Load())) == 'tuple[]'
    assert const_type(Tuple([Constant(1)], Load())) == 'tuple[int]'
    assert const_type(Tuple([Constant(1), Constant('2')], Load())) == 'tuple[Any]'
    assert const_type(List([], Load())) == 'list[]'

# Generated at 2022-06-11 19:30:19.497063
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert Resolver("math", {}).visit(Attribute(Name("math", Load()), "pi", Load())) == Name("pi", Load())
    assert Resolver("math", {}).visit(Attribute(Name("typing", Load()), "type_of", Load())) == Name("type_of", Load())

# Generated at 2022-06-11 19:30:22.884398
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    resolver = Resolver("doc2md", {"doc2md.X": "typing.Union[Y, None]", "doc2md.Y": "int"})
    assert ast.dump(resolver.visit(
        ast.parse("typing.Optional[X]").body[0].value
    )) == ast.dump(
        ast.BinOp(
            ast.Name("X", ast.Load()),
            ast.BitOr(),
            ast.Constant(None)
        )
    )



# Generated at 2022-06-11 19:30:30.047240
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("_") == "_"
    assert esc_underscore("A") == "A"
    assert esc_underscore("_A") == "\\_A"
    assert esc_underscore("A_") == "A\\_"
    assert esc_underscore("_A_") == "\\_A\\_"
    assert esc_underscore("A__") == "A__"
    assert esc_underscore("__A") == "__A"
    assert esc_underscore("_A__") == "\\_A__"
    assert esc_underscore("__A_") == "__A\\_"
    assert esc_underscore("A__B") == "A__B"
    assert esc_underscore("B__C") == "B__C"

# Generated at 2022-06-11 19:30:35.844548
# Unit test for function esc_underscore
def test_esc_underscore():
    assert "_" == esc_underscore("_")
    assert r"\_" == esc_underscore("_" * 2)
    assert r"\_a" == esc_underscore(r"_a")
    assert r"\_" == esc_underscore(r"_a_")
    assert r"\_" == esc_underscore(r"_a_b")
    assert r"\_" == esc_underscore(r"a_b_")
    assert r"\_" == esc_underscore(r"a_b_c")



# Generated at 2022-06-11 19:30:46.782855
# Unit test for function const_type
def test_const_type():
    assert const_type(Constant(True, kind=None)) == 'bool'
    assert const_type(Constant(1, kind=None)) == 'int'
    assert const_type(Constant(1.1, kind=None)) == 'float'
    assert const_type(Constant(1j, kind=None)) == 'complex'
    assert const_type(Constant("", kind=None)) == 'str'
    assert const_type(Constant((), kind=None)) == 'tuple[any]'
    assert const_type(Constant((1,), kind=None)) == 'tuple[int]'
    assert const_type(Constant((1, '', 1.1), kind=None)) == 'tuple[any]'

# Generated at 2022-06-11 19:33:48.987035
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    res = Resolver('typing', {'typing.Union': "typing.Union[int, str]"})
    node = parse("Union[int, str]").body[0]
    node = res.visit(node)
    assert unparse(node) == "int | str"
    res = Resolver('typing', {'typing.Optional': "typing.Optional[int]"})
    node = parse("Optional[int]").body[0]
    node = res.visit(node)
    assert unparse(node) == "typing.Optional[int]"
    res = Resolver('typing', {'typing.List': 'typing.List[int]'})
    node = parse("typing.List[int]").body[0]
    node = res.visit(node)
    assert un

# Generated at 2022-06-11 19:34:00.181455
# Unit test for method api of class Parser
def test_Parser_api():
    p = Parser()
    def func(a, b, c='d') -> int:
        """docstring"""
        pass
    def func_async(a, b, c='d') -> int:
        """docstring"""
        pass
    cls = type('cls', (int,),
               {'__init__': lambda *args: None, 'member': True,
                '__doc__': 'docstring'})
    func = func_async = cls = AttrDict(vars())
    p.api('m', func)