

# Generated at 2022-06-11 19:28:30.694379
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    ast_node = Name("Alias", Load())
    alias = {}
    root = "root"
    ret = Resolver(root, alias).visit_Name(ast_node)
    assert ast_node.id == ret.id
    alias["root.Alias"] = "True"
    ret = Resolver(root, alias).visit_Name(ast_node)
    assert "true" == ret.id
    alias["root.Alias"] = "a"
    ret = Resolver(root, alias).visit_Name(ast_node)
    assert ast_node.id == ret.id
    alias["root.Alias"] = "b.c"
    ret = Resolver(root, alias).visit_Name(ast_node)
    assert "b" == ret.id

# Generated at 2022-06-11 19:28:36.861525
# Unit test for method globals of class Parser
def test_Parser_globals():
    p = Parser()
    p.globals('A', ast.parse('A = 10').body[0])
    assert p.alias['A'] == '10'
    assert p.root['A'] == 'A'
    assert p.const['A'] == 'int'
    p.globals('A', ast.parse('A = 10').body[0])
    assert p.alias['A'] == '10'
    assert p.root['A'] == 'A'
    assert p.const['A'] == 'int'
    p.globals('A.B', ast.parse('B = 10').body[0])
    assert p.alias['A.B'] == '10'
    assert p.root['A.B'] == 'A.B'
    assert p.const['A.B'] == 'int'

# Generated at 2022-06-11 19:28:47.183210
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    r = Parser()
    assert r.func_ann(
        'n',
        [arg('*', None), arg('*args', None), arg('**kwargs', None),
         arg('return', None)],
        has_self=False, cls_method=False
    ) == ["", "", "", ""]
    assert r.func_ann(
        'n',
        [arg('*', None), arg('*args', None), arg('**kwargs', None),
         arg('return', None)],
        has_self=True, cls_method=False
    ) == ["type[Self]", "", "", ""]

# Generated at 2022-06-11 19:28:55.358954
# Unit test for function walk_body
def test_walk_body():
    """Unit test for function walk_body."""
    src = """
if a:
    if a:
        if a:
            if a:
                pass
if a:
    try:
        pass
    except:
        pass
    else:
        if a:
            pass
    finally:
        pass
    """
    ast_ = cast(AST, parse(src))
    walk = tuple(walk_body(ast_.body))
    assert len(walk) == len(src.splitlines())



# Generated at 2022-06-11 19:29:04.992697
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    _slice = [
        Tuple([Name("a", Load()), Name("b", Load()), Name("c", Load())], Load()),
    ]
    _typ = Subscript(Name("Union", Load()),
                     _slice[0],
                     Load())
    _typ2 = Subscript(Name("Optional", Load()),
                      _slice[0],
                      Load())
    _typ3 = Subscript(Name("Tuple", Load()),
                      _slice[0],
                      Load())
    _typ4 = Subscript(Name("List", Load()),
                      _slice[0],
                      Load())
    _typ5 = Subscript(Name("Set", Load()),
                      _slice[0],
                      Load())

# Generated at 2022-06-11 19:29:11.584307
# Unit test for method func_ann of class Parser

# Generated at 2022-06-11 19:29:16.702037
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from .test_doctest import test_docstring
    import sys
    import inspect
    import types
    import importlib.util
    from io import StringIO
    m = types.ModuleType('dummy')
    m.__doc__ = 'Dummy module'
    m.__all__ = []
    m.__file__ = '/path/to/dummy.py'
    m.hello = lambda: 0
    m.hello.__doc__ = 'Hello'
    spec = importlib.util.spec_from_file_location('dummy', '/path/to/dummy.py')
    mod = importlib.util.module_from_spec(spec)
    mod.__dict__ = m.__dict__
    sys.modules['dummy'] = mod
    parser = Parser(True)
    test_docstring

# Generated at 2022-06-11 19:29:18.501518
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    N = Name
    idf = Resolver('test', {})
    assert idf.visit(N('A', Load())) == N('A', Load())
    assert idf.visit(N('_', Load())) == N('_', Load())

# Generated at 2022-06-11 19:29:28.603960
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    r = Resolver("root", {"typing.Union": "typing", "typing.Optional": "typing"})
    assert unparse(r.visit(arg("arg: typing.Union[int, str]",
                               lineno=0, col_offset=0))).strip() == "arg: int | str"
    assert unparse(r.visit(arg("arg: typing.Optional[int]",
                               lineno=0, col_offset=0))).strip() == "arg: int | None"
    assert (unparse(r.visit(arg("arg: typing.Union[int, typing.Union[str, bool]]",
                                lineno=0, col_offset=0))).strip()
            == "arg: int | str | bool")



# Generated at 2022-06-11 19:29:36.987451
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
  p = Parser()
  assert tuple(p.func_ann("", (arg("", None), arg("", None)))) == ("ANY", "ANY")
  assert tuple(p.func_ann("", (arg("", None), arg("", None)), has_self=True)) == ("Self", "ANY")
  assert tuple(p.func_ann("", (arg("", None), arg("", None)), has_self=True, cls_method=True)) == ("type[Self]", "ANY")
test_Parser_func_ann()


# Generated at 2022-06-11 19:30:45.140815
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    from .parser import doc
    m = ModuleType('test_Resolver_visit_Attribute')
    m.__doc__ = doc
    def test(node):
        n = Resolver(m.__name__, {}).visit(node)
        try:
            return unparse(n).strip()
        except AttributeError:
            return n
    assert test(Name('typing.Union', Load())) == 'Union'
    assert test(Name('typing', Load())) == 'typing'
    assert test(Name('typing', Load())) == 'typing'
    assert test(Name('typing.Awaitable', Load())) == 'Awaitable'
    assert test(Name('typing.Awaitable', Load())) == 'Awaitable'

# Generated at 2022-06-11 19:30:52.384144
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('__init__') is False
    assert is_public_family('__enter__') is False
    assert is_public_family('_private') is False
    assert is_public_family('public') is True
    assert is_public_family('__package__.__init__') is False
    assert is_public_family('__package___enter__') is False
    assert is_public_family('__package__._private') is False
    assert is_public_family('__package__.public') is True



# Generated at 2022-06-11 19:30:55.696532
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert(Resolver('', {}).visit_Attribute(parse('typing.List[int]').body[0].value).__class__ ==
           Name)



# Generated at 2022-06-11 19:31:06.425611
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    assert Parser().is_public('_') is False
    assert Parser().is_public('_private') is False
    assert Parser().is_public('private') is False
    assert Parser().is_public('__') is False
    assert Parser().is_public('__private') is False

    parser = Parser()
    parser.imp['foo'] = frozenset({'public'})
    assert parser.is_public('foo.public') is True
    assert parser.is_public('foo.private') is False

    parser = Parser()
    parser.imp['foo'] = frozenset({'public', 'foo'})
    assert parser.is_public('foo.public') is True
    assert parser.is_public('foo.private') is False

    parser = Parser()
    parser.imp['foo'] = fro

# Generated at 2022-06-11 19:31:17.509127
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    """Unit test for method load_docstring of class Parser."""
    def assert_doc_func(node, name, doc):
        """Assert node's docstring."""
        docstring = get_docstring(node)
        assert docstring is not None
        assert docstring.strip() == doc
    m = Parser('main')
    class_a = ClassDef(name='A', body=[])
    func_1 = FunctionDef(name='func_1', body=[],
                         decorator_list=[], args=arguments(args=[], vararg=None,
                                                           kwonlyargs=[],
                                                           kw_defaults=[],
                                                           kwarg=None,
                                                           defaults=[]))
    m.api('A', class_a)
    m.load_docstring

# Generated at 2022-06-11 19:31:20.249997
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    m = ModuleType(__name__)
    _attr(m, 'a')
    p = Parser()
    p.load_docstring('b', m)
    assert 0 == 1


# Generated at 2022-06-11 19:31:30.708544
# Unit test for method api of class Parser

# Generated at 2022-06-11 19:31:36.165553
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    def test(expr: str, ans: str) -> None:
        res = Resolver('', {})
        n = parse(expr).body[0].value
        assert unparse(res.visit(n)) == ans
    test("Union[a, b]", "((a | b))")
    test("Union[a, b, c]", "((a | b | c))")
    test("Union[Union[a, b]]", "((a | b))")
    test("Optional[a]", "((a | None))")
    test("Optional[Union[a, b]]", "((a | b | None))")
    test("Optional[Union[a, b]]", "((a | b | None))")
    test("Tuple[a, b]", "typing.Tuple[a, b]")
   

# Generated at 2022-06-11 19:31:47.266851
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    parser: Parser = Parser()
    parser.alias['self'] = '_0'
    parser.alias['alias.name'] = 'TypeName'
    assert parser.func_ann('', [arg('*args', None),
                                arg('return', None)]) == ['*args', 'None']
    assert parser.func_ann('', [arg('*args', None),
                                arg('a: str', None),
                                arg('return', None)]) == ['*args', 'str', 'None']
    assert parser.func_ann('', [arg('*args', None),
                                arg('a: _0', None),
                                arg('return', None)]) == ['*args', 'Self', 'None']

# Generated at 2022-06-11 19:31:56.618993
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert "convert._foo" == unparse(Resolver('convert', dict()).visit(Attribute(Name('convert', Load()), '_foo', Load())))
    assert "typing:Foo" == unparse(Resolver('convert', dict()).visit(Attribute(Name('typing', Load()), 'Foo', Load())))
    assert "Foo" == unparse(Resolver('convert', dict()).visit(Attribute(Name('typing', Load()), 'Foo', Load())))

