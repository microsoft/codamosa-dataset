

# Generated at 2022-06-11 19:31:19.116724
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    test_1 = (
        Parser._Parser__func_ann(
            "root",
            [
                arg("a", Name(id="b")),
                arg("c", Name(id="d"))
            ],
            has_self=False,
            cls_method=False
        ),
        ["b", "d"]
    )

    test_2 = (
        Parser._Parser__func_ann(
            "root",
            [
                arg("a", Name(id="b")),
                Name(id="c")
            ],
            has_self=False,
            cls_method=False
        ),
        ["b", ""]
    )


# Generated at 2022-06-11 19:31:29.750739
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    resolver = Resolver('test', {'test.typing': 'typing'})
    assert unparse(Subscript(Name('typing', Load()), Tuple(elts=[Name('int', Load()), Name('str', Load())], ctx=Load()), Load())) == 'typing.Union[int, str]'
    assert unparse(resolver.visit(parse('typing.Union[int, str]').body[0].value)) == 'int | str'
    assert unparse(resolver.visit(parse('Optional[int]').body[0].value)) == 'int | None'

# Generated at 2022-06-11 19:31:33.631149
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('abc')
    assert not is_public_family('_abc')
    assert is_public_family('_abc__def')
    assert is_public_family('abc._def')
    assert is_public_family('abc.def.__ghi')
    assert not is_public_family('abc._def.__ghi')
    assert not is_public_family('abc.def.__ghi._jkl')



# Generated at 2022-06-11 19:31:44.424831
# Unit test for method compile of class Parser
def test_Parser_compile():
    p = Parser()
    p.doc['a.b'] = "**{}**\n\n"
    p.doc['a.b.c'] = "**{}**\n\n"
    p.doc['a.b.c.d'] = "**{}**\n\n"
    p.doc['a.e'] = "**{}**\n\n"
    p.doc['f.g'] = "**{}**\n\n"
    p.doc['f.g.h'] = "**{}**\n\n"

# Generated at 2022-06-11 19:31:52.212598
# Unit test for method api of class Parser
def test_Parser_api():
    from rstcheck import RstChecker
    from importlib import import_module
    from apidoc import get_version

    def checker(c):
        checker = RstChecker()
        checker.check(c)
        assert not checker.report.failed

    current_dir = Path(__file__).parent
    parser = Parser()
    mod = import_module('apidoc')
    parser.visit(parse(mod.__doc__))
    parser.load_docstring('apidoc', mod)
    parser.visit(parse(mod.__init__.__doc__))
    parser.visit(parse(mod.Parser.__doc__))
    parser.visit(parse(mod.Parser.__init__.__doc__))

# Generated at 2022-06-11 19:31:56.662277
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    root = "module"
    alias = {"module.alias": "module.name"}
    node = Name("alias", Load())
    res = Resolver(root, alias).visit(node)
    assert isinstance(res, Name)
    assert res.id == "name"

# Generated at 2022-06-11 19:32:07.751201
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser()
    p.imp['testmodule'] = {'testmodule.__all__', 'testmodule.a'}
    p.imp['testmodule.a'] = {'testmodule.a.__all__', 'testmodule.a.function'}
    p.imp['testmodule.b'] = {'testmodule.b.__all__', 'testmodule.b.function'}

    private_name = 'testmodule.c'
    assert p.is_public(private_name) is False
    assert p.imp.pop(private_name) is not None

    public_name = 'testmodule.a.function'
    assert p.is_public(public_name) is True

    p.root[public_name + '.another'] = public_name

# Generated at 2022-06-11 19:32:17.463797
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    from .cli import Config
    from .reader import Reader
    from .reader import get_ast
    from .typing import Any

    c = Config(
        link=False,
        toc=False,
        show_all=False,
        b_level=1,
        b_width=0,
        b_align='',
        p_level=1,
        p_width=0,
        p_align='',
    )
    r = Reader(c)
    a = get_ast(r, '_ast.py', typ=Any, lineno=15)
    p = Parser(r, c)
    p.class_api('_ast', a, [], a.body)

# Generated at 2022-06-11 19:32:24.280507
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    def func(a: str, b: str, c: int = 3, *d: int, e: int = 5, **f: str): ...
    f = Parser(None, None)
    assert list(f.func_ann('', func.__annotations__['return'].__args__)) == \
        ['str', 'str', 'int', 'Tuple[int, ...]', 'int', 'Dict[str, str]']



# Generated at 2022-06-11 19:32:26.353739
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    """This module has no tests."""