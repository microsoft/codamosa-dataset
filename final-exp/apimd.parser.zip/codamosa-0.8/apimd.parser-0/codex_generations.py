

# Generated at 2022-06-11 19:28:44.425350
# Unit test for method imports of class Parser
def test_Parser_imports():
    doc = Parser()
    root = 'root'
    def chk(node, name):
        doc.alias = {}
        doc.imports(root, node)
        assert doc.alias[_m(root, name)] == name
    chk(Import(names=[alias('name', None)]), 'name')
    chk(ImportFrom('mod', [alias('name', 'asname')], 2), 'asname')

# Generated at 2022-06-11 19:28:48.682865
# Unit test for method api of class Parser
def test_Parser_api():
    node = parse_function('def f(): ...')
    p = Parser()
    p.api('', node)
    assert p.doc['f'] == """# f()

*Full name:* `f`

|Parameter      |Type                                                 |
|---------------|-----------------------------------------------------|
|return         |Any                                                  |
"""
    node = parse_function('def f(*args: int, /, a: int = 1, *, b: int = 2): return args, a, b',
                          type_comments=True)
    p = Parser()
    p.api('', node)

# Generated at 2022-06-11 19:28:59.565587
# Unit test for method api of class Parser
def test_Parser_api():
    from astparse import parse
    from itertools import chain
    
    
    class Mock(dict):
        def __missing__(self, key):
            return ANY
    
    
    def test(mod: str, *, alias: dict[str, str]):
        """Test function."""
        root = 'root'
        py_mod = parse(mod)
        for n, v in alias.items():
            py_mod.body.append(Assign([Name(id=n, ctx=Store())], Constant(value=v)))
        p = Parser(py_mod, alias={}, link=True, b_level=0, imp={root: set()},
                   toc=False)
        p.visit(py_mod)

# Generated at 2022-06-11 19:29:07.903111
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from . import __main__ as mod

    t = Parser()
    t.load_docstring('__main__', mod)
    assert t.docstring['__main__.parse'].startswith(
        ".. code-block:: shell\n\n    ")
    assert t.docstring['__main__.parse'].endswith(
        "docs/api.md\n\n        helloworld.py\n\n"
        ".. code-block:: shell\n\n    "
        "helloworld.py :: Hello World!\n\n")
    assert t.docstring['__main__.compile'].strip() == "hello world"
    assert t.docstring['__main__.main'].strip() == ""

# Generated at 2022-06-11 19:29:13.702818
# Unit test for method compile of class Parser
def test_Parser_compile():
    from . import f_unp
    from . import f_parse
    from . import f_doc_1
    from . import f_doc_2
    from . import f_doc_3
    from . import f_doc_4
    from . import f_doc_5
    from . import f_doc_6
    from . import f_doc_7
    from . import f_doc_8
    from . import f_doc_9
    _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _

# Generated at 2022-06-11 19:29:20.811927
# Unit test for function walk_body

# Generated at 2022-06-11 19:29:29.009025
# Unit test for function doctest
def test_doctest():
    from .logger import doclog
    from .pep585 import PEP585
    from .utils import get_module
    from .parser import parse_typing_module, parse_module
    from .checker import check_typing_module, check_module
    from .data import DocStr, DocLeaf
    from .converter import convert_typing_module, convert_module

    assert doctest('''
>>> hello = "world"
>>> print(hello)
world
>>> print(hello)
world
''') == '''
```python
>>> hello = "world"
>>> print(hello)
world
>>> print(hello)
world
```
'''

    ast = parse_typing_module(get_module(PEP585), PEP585)
    check_typing_module(ast, PEP585)

# Generated at 2022-06-11 19:29:39.628866
# Unit test for method imports of class Parser
def test_Parser_imports():
    from . import ast
    from .parse import parse
    from .util import SP
    _I = Union[Import, ImportFrom]
    _G = Union[AnnAssign, Assign]
    _API = Union[FunctionDef, AsyncFunctionDef, ClassDef]
    def _m(key: str, *args: str) -> str:
        return key + '.' + '.'.join(args)
    def _attr(obj: ModuleType, attr: str) -> ModuleType:
        for a in attr.split('.'):
            obj = getattr(obj, a)
        return obj
    from .util import ANY, esc_underscore, is_magic, is_public_family
    from .util import get_docstring, parent, unparse, walk_body
    from .util import const_type, code, doctest


# Generated at 2022-06-11 19:29:42.396514
# Unit test for method compile of class Parser
def test_Parser_compile():
    p = Parser([]).compile()
    assert p == ""


# Generated at 2022-06-11 19:29:45.381642
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser(True, True)

# Generated at 2022-06-11 19:31:32.642071
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from importlib import import_module
    import pdoc
    from libcst import parse_module
    from libcst.metadata import ModuleMetadataWrapper
    import inspect
    import os
    import tempfile
    modules = ['sys', 'test_test_Parser_load_docstring', 'sys.maxsize',
               'pdoc.pdoc', 'pdoc.cli']
    for m in modules:
        module = import_module(m)
        m_d = tempfile.mkdtemp()
        pdoc.extract_module(module, m_d, html=True)
        module_doc = os.path.join(m_d, m.replace('.', '/') + '.html')
        if not os.path.exists(module_doc):
            continue

# Generated at 2022-06-11 19:31:38.059269
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("_") == "_"
    assert esc_underscore("_ ") == "_ "
    assert esc_underscore("_a") == "_a"
    assert esc_underscore("_a_") == "\\_a\\_"
    assert esc_underscore("_a__b_") == "\\_a\\_\\_b\\_"



# Generated at 2022-06-11 19:31:48.627891
# Unit test for method globals of class Parser
def test_Parser_globals():
    buf = io.StringIO()
    with redirect_stderr(buf):
        p = Parser()
        p.globals('a', Name(id=''))
        p.globals('a', Name(id='__all__', ctx=Load()))
        p.globals('a', Name(id='__all__', ctx=Store()))
        p.globals('a', Name(id='__ALL__', ctx=Store()))
        p.globals('a', Parser.parse('a = 10'))
        p.globals('a', Parser.parse('a: int = 10'))
        assert p.const.popitem() == ('a.__ALL__', 'int')
        p.globals('b', Parser.parse('a: float'))
       

# Generated at 2022-06-11 19:31:59.758908
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser()
    func_def = FunctionDef(name='func',
                           args=arguments(args=[arg(arg='a', annotation=Name(id='int', ctx=Load()), type_comment='int')],
                                          vararg=arg(arg='*args', annotation=Name(id='int', ctx=Load()), type_comment='int')),
                           returns=Name(id='list', ctx=Load()),
                           body=[],
                           decorator_list=[],
                           type_comment=None)
    p.func_api('__main__.A', '__main__.A.func', func_def.args, func_def.returns, has_self=False, cls_method=False)

# Generated at 2022-06-11 19:32:10.183657
# Unit test for method compile of class Parser
def test_Parser_compile():
    from . import test_src
    from .typehints import _A, _N, _S

    def sha(s: _S) -> _S:
        return "".join(hex(ord(c))[2:].zfill(2) for c in s.encode()).upper()

    def find_name(doc: _S, name: _S) -> _N:
        """Find name index in documentation."""
        s = doc.find(name)
        assert s >= 0
        assert doc[s - 1] == ' ' and doc[s + len(name)] in (' ', '\n', '\r')
        return s


# Generated at 2022-06-11 19:32:19.931855
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from io import StringIO

    from rstcheck import RstReport, check

    parser = Parser(False, False)
    parser.doc['t.foo'] = "**foo()**\n\n"
    parser.doc['t.foo.bar'] = "**bar()**\n\n"
    parser.load_docstring('t', StringIO("""
    def foo():
        '''t.foo
        
        .. code:: py
        
            t.foo.bar
        '''
        pass
    """))
    assert parser.docstring['t.foo'] == 't.foo\n\n    t.foo.bar'
    assert parser.docstring['t.foo.bar'] == '\n'

# Generated at 2022-06-11 19:32:22.231748
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    # Test Method
    p = Parser()

# Generated at 2022-06-11 19:32:29.048400
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    class _Parser(Parser):
        def __init__(self, link: Optional[str] = None):
            self.link = link
            self.doc = {}
            self.docstring = {}
            self.imp = defaultdict(set)
            self.const = {}
            self.alias = {}
            self.level = {}
            self.root = {}

    p = _Parser()
    p.doc['os.path'] = ''
    p.docstring['os.path'] = ''
    p.const['os.path.abspath'] = ''
    p.const['os.path.dirname'] = ''
    p.imp['os.path'].add('os.path')
    assert not p.is_public('os.path.abspath')
    assert p.is_public('os')
    assert p

# Generated at 2022-06-11 19:32:37.762051
# Unit test for function walk_body
def test_walk_body():
    ast_ = parse(dedent("""
        if True:
            if False:
                pass
            else:
                pass
        else:
            pass
        if True:
            pass
        else:
            try:
                pass
            except Exception:
                pass
            else:
                pass
            finally:
                pass
    """))
    body = list(walk_body(ast_.body))
    assert len(body) == 2
    assert isinstance(body[0], If)
    assert isinstance(body[1], If)
    assert isinstance(body[1].orelse[0], Try)

# Generated at 2022-06-11 19:32:47.329409
# Unit test for method api of class Parser
def test_Parser_api():
    from pytest import raises
    from lagc_pkg.qobuz_ext.lagc_api.api import ParseError
    from lagc_pkg.qobuz_ext.lagc_api.api import Py_9, Py_10, Py_11
    from lagc_pkg.qobuz_ext.lagc_api.api import Py_9_9, Py_9_10, Py_9_11

    def test(code: str, expected: str, *,
             py_ver: str = "py3", py_ver_detailed: str = "py3_9") -> None:
        path = Path(__file__).parent