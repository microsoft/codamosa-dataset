

# Generated at 2022-06-11 19:29:36.532332
# Unit test for method api of class Parser
def test_Parser_api():
    p = Parser(debug=True)

# Generated at 2022-06-11 19:29:42.642592
# Unit test for method globals of class Parser
def test_Parser_globals():
    p = Parser(as_module=False)

    # Test 1: set up globals:
    # + Type alias
    # + Constants
    # + __all__ filter
    root = "pypads_padre.pads.base"
    node = ast.parse("metadata_key = 'pads_metadata'").body[0]
    p.globals(root, node)
    assert p.alias['pypads_padre.pads.base.metadata_key'] == "'pads_metadata'"
    assert p.root['pypads_padre.pads.base.metadata_key'] == "pypads_padre.pads.base"
    assert p.const['pypads_padre.pads.base.metadata_key'] == 'str'

    # Test 2: set up globals

# Generated at 2022-06-11 19:29:52.147216
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    p = Parser(False, [])
    p.doc = {'a.b': '*Full name:* `{}`\n\n', 'a.c': '*Full name:* `{}`\n\n'}
    p.docstring = {}
    p.root = {'a.b': 'a', 'a.c': 'a'}
    p.level = {'a.b': 1, 'a.c': 1}
    sys.modules['a'] = ModuleType('a')
    _attr(sys.modules['a'], 'b').__doc__ = 'b docstring'
    p.load_docstring('a', sys.modules['a'])
    assert p.docstring == {'a.b': 'b docstring'}
    del sys.modules['a']
    p

# Generated at 2022-06-11 19:30:02.722444
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from ast import arguments, arg, Name, Attribute, Str, Num, Tuple, Load, Store, param, ClassDef, Expression, FunctionDef, parse
    p = Parser(None, None)
    args = [arg('a', Str())]
    assert list(p.func_ann('', args, True, False)) == ['']
    args = [arg('/', None), arg('a', Str())]
    assert list(p.func_ann('', args, True, False)) == ['', '']
    args = [arg('a', Str()), arg('/', None), arg('b', Num())]
    assert list(p.func_ann('', args, True, False)) == ['', '', '']
    args = [arg('*', Str())]

# Generated at 2022-06-11 19:30:14.343927
# Unit test for method func_ann of class Parser

# Generated at 2022-06-11 19:30:26.634809
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    import sys, os, ast
    import doctest
    p = Parser(['_a'])
    p.doc['__main__'] = ''
    x = sys.modules.copy()
    for m in ('ast', 'typing', '_a'):
        sys.modules.pop(m, None)
    try:
        with open(os.path.join(_a.__path__[0], '__init__.py')) as f:
            m = ast.parse(f.read(), filename='__init__.py')
    finally:
        sys.modules.update(x)

# Generated at 2022-06-11 19:30:29.641734
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    # The common case
    Parser(__name__ + '*.py').is_public('fastapi.docs')


# Generated at 2022-06-11 19:30:37.049022
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    from .compile import Parser
    from .visitor import parse
    p = Parser((), None, False)
    func_api = p.func_api

    def p(*a):
        return tuple(map(lambda t: unparse(t), a))


# Generated at 2022-06-11 19:30:47.482540
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    from .typesystem import TypeSystem
    r = Resolver('_root_', TypeSystem('').alias, '_self_')
    from ast import parse, Subscript, Name, Tuple, Load
    assert r.visit(Subscript(Name('a', Load()),
                             Tuple([Name('b', Load()), Name('c', Load())], Load()), Load())) == \
        BinOp(Name('b', Load()), BitOr(), Name('c', Load()))
    assert r.visit(Subscript(Name('typing', Load()),
                             Tuple([Name('a', Load()), Name('b', Load())], Load()), Load())) == \
        BinOp(Name('a', Load()), BitOr(), Name('b', Load()))

# Generated at 2022-06-11 19:30:58.950511
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    _ = eval(
        Parser(None, None).func_api(
            'a', 'a.b', parse('def b(  ) -> None -> str: pass'), None,
            has_self=False, cls_method=False),
        {},
        {}
    )
    assert isinstance(_, Collector)
    assert _.get(0, 0) == 'def b()'
    _ = eval(
        Parser(None, None).func_api(
            'a', 'a.b', parse('def b(  ) -> None: pass'), None,
            has_self=False, cls_method=True),
        {},
        {}
    )
    assert isinstance(_, Collector)
    assert _.get(0, 0) == 'def b()'