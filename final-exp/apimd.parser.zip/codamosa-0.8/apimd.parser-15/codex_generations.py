

# Generated at 2022-06-11 19:33:48.982579
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    from inspect import Parameter

    args = inspect.signature(_attr(Parser, "func_api")).parameters.values()
    assert all(a.kind == Parameter.POSITIONAL_OR_KEYWORD for a in args)

    p = Parser()

    func = FunctionDef(
        name="func",
        args=arguments(
            posonlyargs=[arg("a", None)],
            args=[
                arg("b", None),
                arg("*", None),
                arg("**", None),
            ],
            returns=None,
        ),
    )

    p.func_api("", "", func.args, func.returns)


# Generated at 2022-06-11 19:33:56.853305
# Unit test for method globals of class Parser
def test_Parser_globals():
    from .nodes import Module
    from .tokens import Constant
    from .tokens import Name
    import ast
    import astor
    module = Module(
        body=[ast.AnnAssign(
            target=Name(id='', ctx=ast.Store()),
            annotation=ast.Name(id='', ctx=ast.Load()),
            value=Constant(value='', kind=None))])
    parser = Parser(astor.to_source(module))
    parser.globals('', module.body[0])

# Generated at 2022-06-11 19:34:03.380011
# Unit test for method globals of class Parser
def test_Parser_globals():
    import ast

    from .test.test_autodoc import Module
    p = Parser(Module('test/test_autodoc.py'))
    p.visit(ast.parse("""
    TYPE = object
    CONST = "test"
    __all__ = ("CONST", "TYPE")
    """))
    assert p.imp[''] == {'const', 'type'}