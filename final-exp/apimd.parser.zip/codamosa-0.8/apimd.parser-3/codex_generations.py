

# Generated at 2022-06-11 19:29:39.722713
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    """Test the method Parser.func_ann.
    """
    logger.info("Test the method Parser.func_ann")
    input_strs = ['a: int', 'b: str = "str"', 'c: Iterable[int]']
    TypeAnnotation = namedtuple('TypeAnnotation', 'annotation')
    Name = namedtuple('Name', 'id')
    args = list(map(lambda text: arg('', TypeAnnotation(Name(text, 0))), input_strs))
    parser = Parser()
    output_strs = list(parser.func_ann('root', args))
    logger.info("Original: %s", str(input_strs))
    logger.info("Output  : %s", str(output_strs))

# Generated at 2022-06-11 19:29:51.031153
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    from .data_struct import arg_parse
    from . import __main__
    opt = arg_parse()
    opt.module = __main__
    mod = opt.module
    for line in getdoc(mod).splitlines():
        line = line.strip()
        if line and not line.startswith('#'):
            parse(line)
    opt.root = '.'.join(mod.__package__.rsplit('.', maxsplit=1))
    alias = {
        "typing": "typing",
        _m(opt.root, 'color'): "color",
        _m(opt.root, 'color.Color'): "color.Color",
    }
    r = Resolver(opt.root, alias)

# Generated at 2022-06-11 19:29:56.839344
# Unit test for method globals of class Parser
def test_Parser_globals():
    '''
    Test method globals of class Parser.
    '''
    from inspect import Signature, Parameter
    from types import ModuleType
    from functools import partial

    from annotate import Annotation
    from docmod import Parser
    import ast

    def __test(*, is_env, is_ann, is_mod=True, is_func=False, **kwargs):
        '''
        Test for method globals of class docmod.Parser
        '''
        ast_node = ast.parse('')
        module = ast_node.body
        ast_node = ast.Assign(
            [ast.Name(id='a', ctx=ast.Store())],
            ast.Constant(value=1, kind=None))

# Generated at 2022-06-11 19:30:06.935052
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser()
    node = ast.parse('def f(x, *, y): ...')
    name = 'f'
    root = ''
    
    p.func_api(root, name, node.body[0].args, node.body[0].returns,
               has_self=False, cls_method=False)
    
    assert p.doc[name] == '# f()\n\n*Full name:* `f`\n\n'
    assert p.doc[name] == '# f()\n\n*Full name:* `f`\n\n'
    table = p.doc[name].splitlines()[-1]
    assert table == '| x | |'
    assert table == '| x | |'
    table = table.splitlines()[1]


# Generated at 2022-06-11 19:30:16.866536
# Unit test for method api of class Parser
def test_Parser_api():  # pytest: no cover
    import ast
    from textwrap import dedent
    from typing import Any

    def doc(a: int) -> Any:
        """Get a documentation."""
        return 1

    doc.__doc__ = "Something wrong."
    m = ast.parse('def add(a: int, b: int, c=1, *args: int, **kwargs: int): ...')
    p = Parser()
    p.api('', m.body[0])
    print(p.doc)
    print(p.docstring)

# Generated at 2022-06-11 19:30:22.869673
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    source = "ClassType('str', 'str')"
    expected = "ClassType('str', 'str')"
    root = 'root'
    assert unparse(Resolver(root, {}).visit(parse(source).body[0])) == \
        source, source
    assert unparse(Resolver(root, {'typing.str': 'str'}).visit(parse(source).body[0])) == \
        expected, expected
    assert unparse(Resolver(root, {'typing.str': 'str'}).visit(parse(expected).body[0])) == \
        expected, expected
    assert unparse(Resolver(root, {'typing.ClassType': 'ClassType'}).visit(parse(source).body[0])) == \
        expected, expected
    assert unparse

# Generated at 2022-06-11 19:30:33.041142
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    b = Body([
        Expr(value=Assign(
            targets=[Name(id='x')],
            value=Constant(value=1))),
        Expr(value=Assign(
            targets=[Name(id='y')],
            value=Constant(value=2))),
        Expr(value=Assign(
            targets=[Name(id='z')],
            value=Constant(value=3))),
    ])
    p = Parser()
    p.class_api('a', 'a.b', [], b)

# Generated at 2022-06-11 19:30:44.543105
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from typed_ast import parse
    from gendoc import Parser
    p = Parser()
    p.alias = {
        'p.a': 'A',
        'p.b': 'B',
        'p.C.c': 'C',
        'p.D.d': 'D',
        'p.E.e': 'E',
    }
    def f(func, *args, **kwargs):
        return tuple(p.func_ann('p', parse(func), *args, **kwargs))
    # argument annotation
    assert f("def f(x: int) -> int: pass") == ("int",)
    assert f("def f(x: int, y: str) -> int: pass") == ("int", "str")

# Generated at 2022-06-11 19:30:52.881641
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    r = Resolver('test', {})
    assert unparse(r.visit(parse('str').body[0])) == 'str'
    assert unparse(r.visit(parse('"str"').body[0])) == '"str"'
    assert unparse(r.visit(parse('typing.Tuple').body[0])) == 'Tuple'
    assert unparse(r.visit(parse('typing.Union').body[0])) == 'Union'
    assert unparse(r.visit(parse('typing.Optional').body[0])) == 'Optional'
    assert unparse(r.visit(parse('typing.List').body[0])) == 'List'

# Generated at 2022-06-11 19:31:04.402126
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from uxadt.macros import List, prod, sum
    from uxadt.pubsub import Event
    from uxadt.structure import uxadt
    from uxadt.transpiler import transpile
    class _Error(sum._Error_):  # type: ignore
        _ = prod._('a')
    _Error = transpile(uxadt(_Error(_)))._Error
    class _Event(Event):
        class Error(_Error):
            def __init__(self, a: bool):
                pass
        class Ok(Event):
            def __init__(self, a: int):
                pass

# Generated at 2022-06-11 19:32:35.348542
# Unit test for function table
def test_table():
    data = [['a', 'b'], ['c', 'd']]
    assert table('a', 'b', data) == (
        '|a|b|\n'
        '|:---:|:---:|\n'
        '|a|b|\n'
        '|c|d|\n\n'
    )
    data = ['a', 'b', 'c']
    assert table('a', items=data) == (
        '|a|\n'
        '|:---:|\n'
        '|a|\n'
        '|b|\n'
        '|c|\n\n'
    )



# Generated at 2022-06-11 19:32:41.380298
# Unit test for method api of class Parser
def test_Parser_api():
    parser = Parser()
    parser.api(root='my_module',
               node=FunctionDef(name='my_fun',
                                args=arguments(),
                                body=[],
                                decorator_list=[],
                                returns=None),
               prefix='')
    assert parser.doc == {'my_module.my_fun': '# my_fun()\n\n*Full name:* `my_module.my_fun`\n\n**Table of contents:**\n    + [`my_module.my_fun`](#my_module-my_fun)'}
    assert parser.level == {'my_module.my_fun': 0}
    assert parser.root == {'my_module.my_fun': 'my_module'}

# Generated at 2022-06-11 19:32:46.692287
# Unit test for function is_public_family
def test_is_public_family():
    """Unit test for function is_public_family"""
    assert is_public_family("__hello__")
    assert is_public_family("hello_")
    assert is_public_family("hello")
    assert is_public_family("_hello")
    assert not is_public_family("_hello__")
    assert not is_public_family("_hello")
    assert not is_public_family("__hello")
test_is_public_family()



# Generated at 2022-06-11 19:32:58.082314
# Unit test for method imports of class Parser
def test_Parser_imports():
    """Test `imports` method of class `Parser`."""
    p = Parser(link=False)
    m = 'test'
    t = import_parse(code(f"import {m}"))
    p.imports(m, t)
    assert p.alias['test'] == 'test'
    t = import_parse(code(f"import {m} as new"))
    p.imports(m, t)
    assert p.alias['new'] == 'test'
    t = import_parse(code(f"from . import {m}"))
    p.imports(m, t)
    assert p.alias['test'] == 'test'
    t = import_parse(code(f"from ..a..b.c import z"))
    p.imports(m, t)

# Generated at 2022-06-11 19:32:59.253634
# Unit test for method api of class Parser
def test_Parser_api():
    p = Parser()
    _test_Parser_api(p)

# Generated at 2022-06-11 19:33:08.234692
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    # test for normal case
    parser = Parser()
    root = 'module'
    node = FunctionDef(name='', args=arguments(args=[], defaults=[], vararg=arg(arg='', annotation=None), kwonlyargs=[arg(arg='', annotation=None), arg(arg='', annotation=None)], kw_defaults=[None, None], kwarg=None, posonlyargs=[]), body=[], decorator_list=[], returns=None)
    name = 'name'
    parser.func_api(root, name, node.args, node.returns, has_self=False, cls_method=False)
    assert parser.doc[name] == '    name()\n\n'
    # test for class method
    parser = Parser()
    root = 'module'
    node = FunctionDef

# Generated at 2022-06-11 19:33:13.698324
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    from .parser import Argument
    from .scanner import Node
    from typing import Sequence
    
    def _(args, defaults, args_type, kwonlyargs_type, kw_defaults,
          return_type, has_self, cls_method, f_args, f_defaults, f_returns):
        parser = Parser()
        parser.func_api(
            "", "", Argument(
                args, defaults, args_type, kwonlyargs_type, kw_defaults,
                return_type), Node(), has_self=has_self, cls_method=cls_method)
        args = parser.func_ann("", args, has_self=has_self, cls_method=cls_method)
        assert args == tuple(f_args)

# Generated at 2022-06-11 19:33:23.054322
# Unit test for method globals of class Parser

# Generated at 2022-06-11 19:33:34.330535
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    parser = Parser()
    name = '__main__.func'
    class docstring(arguments):
        has_self = False
        def __init__(self):
            self.keywords_only=[arg(id='name', annotation=None)]
            self.vararg = arg(arg=None, annotation=None)
            self.args = [arg(id='data', annotation=None)]
            self.kw_defaults = [(Name(id='name', ctx=Load()), Constant(value=None))]
    parser.func_api('__main__', name, docstring(), None)

# Generated at 2022-06-11 19:33:36.788734
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    assert isinstance(Resolver("", {}).visit_Attribute(Attribute(Name("typing", Load()), "List", Load())), Name)
