

# Generated at 2022-06-11 19:27:33.352342
# Unit test for function const_type
def test_const_type():
    assert const_type(Expr(Constant(1, None))) == 'int'
    assert const_type(Expr(Constant(1.0, None))) == 'float'
    assert const_type(Expr(Constant(True, None))) == 'bool'
    assert const_type(Expr(Constant('Hello', None))) == 'str'
    assert const_type(Expr(Constant(b'Hello', None))) == 'bytes'
    assert const_type(Expr(Constant({}, None))) == 'dict'
    assert const_type(Expr(List([]))) == 'list'
    assert const_type(Expr(List([]))) == 'list'
    assert const_type(Expr(Set([]))) == 'set'

# Generated at 2022-06-11 19:27:44.110997
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    T = TypeVarArray('T')  # pylint: disable=invalid-name
    assert Parser().func_ann('', [arg('a', NameConstant(1)), arg('b', None)]) == [
        "1", "Any"]
    assert Parser().func_ann('', [arg('*a', None), arg('b', None)]) == [
        "", "Any"]
    assert Parser().func_ann('', [arg('**a', NameConstant(1)),
                                  arg('b', None), arg('return', None)]) == [
                                      "", "Any", "return"]
    assert Parser().func_ann('',
                             [arg('**a', NameConstant(1)), arg('return', None)]) == [
                                 "", "return"]
    assert Parser().func_ann

# Generated at 2022-06-11 19:27:52.810553
# Unit test for method api of class Parser
def test_Parser_api():
    import pprint
    #

# Generated at 2022-06-11 19:28:00.130677
# Unit test for method api of class Parser
def test_Parser_api():
    """Test method api of class Parser."""
    p = Parser()
    assert p.doc == {}
    assert p.docstring == {}
    assert p.imp == defaultdict(set)
    assert p.alias == {}
    assert p.level == {}


# Generated at 2022-06-11 19:28:07.466731
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    parser = Parser(False)
    func_anns = tuple(parser.func_ann('foo', (arg('a', None), arg('b', None))))
    assert func_anns == ('a', 'b')
    func_anns = tuple(parser.func_ann('foo', (arg('a', None),)))
    assert func_anns == ('a',)
    func_anns = tuple(parser.func_ann('foo', (arg('a', None),), has_self=True))
    assert func_anns == ('type[Self]', 'a')
    func_anns = tuple(parser.func_ann('foo', (arg('a', None),), has_self=True,
                                      cls_method=True))
    assert func_anns == ('Self', 'a')

# Generated at 2022-06-11 19:28:17.218966
# Unit test for function walk_body
def test_walk_body():
    """Unit test for function walk_body"""
    from ast import parse, If, FunctionDef, Call, Name

    def func(a):
        if a:
            print(1)
            try:
                print(2)
            except:
                try:
                    print(3)
                except:
                    print(4)
                else:
                    print(5)
                finally:
                    print(6)
            else:
                print(7)
            print(8)
        else:
            print(9)
            try:
                print(10)
            except:
                try:
                    print(11)
                except:
                    print(12)
                else:
                    print(13)
                finally:
                    print(14)
            else:
                print(15)
            print(16)


# Generated at 2022-06-11 19:28:22.819762
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore("abc") == "abc"
    assert esc_underscore("a_b_c") == "a_b_c"
    assert esc_underscore("a_bc") == "a\\_bc"
    assert esc_underscore("a_b_c_d") == "a\\_b\\_c\\_d"



# Generated at 2022-06-11 19:28:29.946734
# Unit test for method compile of class Parser
def test_Parser_compile():
    from pysharedutils import Module
    doc = doctest(__doc__)
    root = 'test_pydocgen'
    with Module(root) as test:
        test.foo = 0
        test.bar = 1
        test.__all__ = ['foo']
        test.__author__ = "me"
        test.__version__ = "1.1.0"
        test.__docs__ = doc
        test.Foo = TypeVar('Foo')

        @_example(_callable)
        def foo(a: int, *b: float, c: float = 1, d: float = 2, **e: int) -> Foo:
            """Foo."""
            super()
            return test.foo


# Generated at 2022-06-11 19:28:37.307322
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    a = Subscript(Name("Union", Load()),
                  Tuple(elts=[Name("int", Load()), Name("str", Load())],
                        ctx=Load()),
                  Load())
    assert unparse(a) == "Union[int, str]"
    b = Subscript(Name("Optional", Load()), Name("int", Load()), Load())
    assert unparse(b) == "Optional[int]"
    c = Subscript(Name("Optional", Load()), Name("str", Load()), Load())
    assert unparse(c) == "Optional[str]"
    d = Subscript(Name("Iterable", Load()), Name("str", Load()), Load())
    assert unparse(d) == "Iterable[str]"

# Generated at 2022-06-11 19:28:47.332544
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    _ = random.random
    doc = "```python3\n>>> from {0!r} import *\n>>> from {0!r} import {1!r}\n"
    doc += ">>> {1}({2})\n{3}\n```\n"
    def f(s, *a):
        if isinstance(s, str):
            return s
        elif isinstance(s, list):
            return ''.join(f(e, *a) for e in s)
        elif isinstance(s, tuple):
            return '(' + ', '.join(f(e, *a) for e in s) + ')'
        elif isinstance(s, Call):
            return f(s.func, *a) + f(s.args, *a)
    def g(n):
        return

# Generated at 2022-06-11 19:32:51.764496
# Unit test for function doctest
def test_doctest():
    assert doctest("\n>>> keep\n>>> keep\nkeep") == (
        "```python\n>>> keep\n>>> keep\n```\nkeep"
    )
    assert doctest("\n>>> keep\n>>> keep") == "```python\n>>> keep\n>>> keep\n```"
    assert doctest("keep") == "keep"



# Generated at 2022-06-11 19:32:57.565426
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    def visit_Name_resolver():
        for i in range(1000):
            alias = {f"{i:03}": str(i)}
            resolver = Resolver("", alias)
            e = cast(Expr, resolver.visit(parse(str(i)).body[0]))
            assert e.value == Constant(i)

    visit_Name_resolver()


# Generated at 2022-06-11 19:33:05.405122
# Unit test for function table
def test_table():
    """Simple test for function table"""
    name = ["x", "y"]
    des = ["Test A", "Test B"]
    # Input
    a = ["1", "2", "3", "4"]
    b = ["a", "b", "c", "d"]
    c = ["x", "y", "z", "w"]
    # Output
    d = ["A", "B", "C", "D"]
    e = ["M", "N", "O", "P"]
    f = ["X", "Y", "Z", "W"]
    table(name, des, [a, b, c], [d, e, f])



# Generated at 2022-06-11 19:33:12.057393
# Unit test for function const_type
def test_const_type():
    assert const_type(parse("True").body[0]) == 'bool'
    assert const_type(parse("3.14").body[0]) == 'float'
    assert const_type(parse("(1, 2)").body[0]) == 'tuple[int, int]'
    assert const_type(parse("[1, 2]").body[0]) == 'list[int, int]'
    assert const_type(parse("{'a', 'b'}").body[0]) == 'set[str, str]'
    assert const_type(parse("{'a': 1, 'b': 2}").body[0]) == 'dict[str, int]'
    assert const_type(parse("bool(1)").body[0]) == 'bool'

# Generated at 2022-06-11 19:33:17.065819
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    resolver = Resolver("", {})
    assert resolver.visit(parse("a.b").body[0]).body[0].value.attr == 'b'
    assert resolver.visit(parse("typing.a").body[0]).body[0].value.id == 'a'


# Generated at 2022-06-11 19:33:24.957599
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    class Arg(arg):
        def __init__(self, arg: str, *, annotation: Optional[Arg] = None):
            super().__init__(arg, annotation)
        def __str__(self) -> str:
            return self.arg
    assert Parser().func_ann('root', [Arg('A'), Arg('B'), Arg('return', Arg('C'))]) == ['A', 'B', 'C']
    assert Parser().func_ann('root.', [Arg('self', Arg('A')), Arg('B'), Arg('return', Arg('C'))],
                             has_self=True, cls_method=True) == ['type[A]', 'B', 'C']

# Generated at 2022-06-11 19:33:35.667969
# Unit test for method globals of class Parser
def test_Parser_globals():
    from typing import TypeVar, Callable, List, Tuple
    from inspect import currentframe
    Caller = TypeVar('Caller', bound=Callable[..., Any])
    def _dump(self: Parser) -> str:
        """Dump the content of inner variables for tests."""
        return '\n'.join([str(getattr(self, i)) for i in dir(self)
                          if not i.startswith('_')
                          and i != 'dump'])
    def _make_parser() -> Parser:
        """Make a parser instance to test."""
        p = Parser()
        p.dump = Callable[_dump, Parser](_dump)
        return p
    frames: List[Tuple[str, int]] = []

# Generated at 2022-06-11 19:33:45.866747
# Unit test for function const_type
def test_const_type():
    e = parse("""True""").body[0].value
    assert const_type(e) == 'bool'
    e = parse("""1""").body[0].value
    assert const_type(e) == 'int'

# Generated at 2022-06-11 19:33:50.194211
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    assert parse(
        """[typing.Union[int, bool], typing.Optional[None],
        typing.Optional[int]]""", mode='eval').body[0] == \
            Resolver('', {}).visit_Subscript(
                Subscript(Name('typing.Union', Load), Tuple(
                    [Name('int', Load), Name('bool', Load)], Load()), Load()
                )
            )

# Generated at 2022-06-11 19:33:55.194808
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    assert Resolver("", {}).visit(parse('Union[int, str]').body[0]).body[0].value.args[0].value == parse('Union[int, str]').body[0].value.args[0].value
    assert Resolver("", {}).visit(parse('List[int]').body[0]).body[0].value.args[0].value == parse('List[int]').body[0].value.args[0].value
    assert Resolver("", {}).visit(parse('Optional[int]').body[0]).body[0].value.args[0].value == parse('Optional[int]').body[0].value.args[0].value
    assert Resolver("", {}).visit(parse('Tuple[int, str]').body[0]).body[0].value.args[0].value