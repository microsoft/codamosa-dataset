

# Generated at 2022-06-11 19:27:44.472923
# Unit test for method imports of class Parser
def test_Parser_imports():
    import itertools as it
    
    import ast
    
    import pytest
    
    from utensor_cgen.ir import Import, alias
    
    import utensor_cgen.parser as parser
    
    import utensor_cgen.utils as utils
    

# Generated at 2022-06-11 19:27:52.835659
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    class P1(Parser):
        def __init__(self, *args):
            super().__init__(*args)
            self.level["root"] = 0
            self.root["root"] = "root"
            self.doc["name"] = ""
    #
    # test for public attribute
    #
    arg_list = []
    body_list = [AnnAssign(target=Name(id="x"), annotation=Str(s="int"), value=Int(i=1))]
    body_list.append(AnnAssign(target=Name(id="y"), annotation=Str(s="int"), value=Str(s="1.0")))
    body_list.append(AnnAssign(target=Name(id="z"), annotation=Str(s="int"), value=Int(i=1)))
    body_list.append

# Generated at 2022-06-11 19:28:02.219752
# Unit test for function walk_body
def test_walk_body():
    def _body(node: Union[AST, Sequence[stmt]]) -> Sequence[stmt]:
        if isinstance(node, AST):
            return node.body
        else:
            return node


# Generated at 2022-06-11 19:28:08.872713
# Unit test for method api of class Parser
def test_Parser_api():
    import inspect
    from typing import *
    from ruyaml.main import *
    from ruyaml.parser import *
    from importlib import import_module
    """
    Parse the module and create docstring.

    :param root: The module name
    :param module: The module object
    :param b_level: Base level of header
    :param link: Add '<a id=""></a>' to docstring
    """
    def f(root: str, module: ModuleType, b_level: int=1, link: bool=True):
        p = Parser(link)
        p.get_doc(root, inspect.getmodule(module), b_level)
        return p.compile()

# Generated at 2022-06-11 19:28:16.807010
# Unit test for method api of class Parser
def test_Parser_api():
    for i in (
            (FunctionDef, 'def foo() -> None: ...'),
            (AsyncFunctionDef, 'async def foo() -> None: ...'),
            (ClassDef, 'class Foo: ...'),
    ):
        p = Parser(0, False)
        m = Module(body=[i[0](name='foo', body=[Pass()])])
        for a in walk_body(m):
            p.api('', a)
        assert p.doc['foo'].rstrip() == f'# foo()\n\n*Full name:* `foo`\n\n'
        assert unparse(i[1]) in p.__repr__()


# Generated at 2022-06-11 19:28:18.050813
# Unit test for method compile of class Parser
def test_Parser_compile():
    p = Parser(toc=True)
    # Error is expected on this line
    p.compile()

# Generated at 2022-06-11 19:28:23.698960
# Unit test for method func_ann of class Parser

# Generated at 2022-06-11 19:28:31.175411
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    import ast
    import dataclasses
    import typing
    import sys
    @dataclasses.dataclass
    class Context:
        alias: dict[str, str]
        self_ty: str
    @dataclasses.dataclass
    class Node(ast.AST):
        lineno: int = 0
        col_offset: int = 0
        context: Context = dataclasses.field(default_factory=Context)
    @dataclasses.dataclass
    class Constant(Node):
        value: object
    @dataclasses.dataclass
    class Name(Node):
        id: str
    @dataclasses.dataclass
    class Load(Node):
        pass
    @dataclasses.dataclass
    class Subscript(Node):
        value: str
        slice: object
        c

# Generated at 2022-06-11 19:28:33.084159
# Unit test for function esc_underscore
def test_esc_underscore():
    assert esc_underscore('a_a') == r'a_a'
    assert esc_underscore('a_a__a') == r'a\_a\_\_a'



# Generated at 2022-06-11 19:28:35.067364
# Unit test for method globals of class Parser
def test_Parser_globals():
    # pylint: disable=unused-variable
    p: Parser = None
    # pylint: enable=unused-variable
    assert True, "Test is incomplete"



# Generated at 2022-06-11 19:30:27.265176
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    pa = Parser()
    assert list(pa.func_ann('p', [
        arg('x', None), arg('y', Name(id='s', ctx=Load())),
        arg('*args', None), arg('*kwargs', None), arg('return', None),
    ])) == [ANY, 's', 'type[tuple]', 'dict', 'Any']

# Generated at 2022-06-11 19:30:33.279238
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    # union
    x = -1
    x = int(x)
    x = 2.0
    root = "test_Resolver_visit_Subscript"
    alias = {
        f"{root}.x": "Union[int, float]"
    }
    node = Subscript(Name('x', Load()), Tuple(elts=[
        Call(Name('int', Load()), args=[Name('x', Load())], keywords=[]),
        Name('float', Load())], ctx=Load()), Load())
    node = Resolver(root, alias).visit(node)
    assert node.left.id == 'int'
    assert node.right.id == 'float'
    assert isinstance(node.op, BitOr)

    # optional

# Generated at 2022-06-11 19:30:36.601839
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    m = ModuleType("__main__")
    p = Parser("root")
    if p.docstring is not None:
        p.docstring.clear()
    p.load_docstring("root", m)
    assert p.docstring == {}



# Generated at 2022-06-11 19:30:47.480211
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser('./test/data/__init__.py', config='{}')
    r = p.func_ann('./test/data', [arg('a', None)], has_self=False, cls_method=False)[0]
    assert r == ANY
    r = p.func_ann('./test/data', [arg('a', None)], has_self=True, cls_method=False)[0]
    assert r == "type[Self]"
    r = p.func_ann('./test/data', [arg('a', None)], has_self=True, cls_method=True)[0]
    assert r == "Self"

    p = Parser('./test/data/test_func.py', config='{}')

# Generated at 2022-06-11 19:30:55.130428
# Unit test for function walk_body
def test_walk_body():
    @staticmethod
    def a():
        if b():
            pass
        try:
            pass
        except:
            pass
        else:
            pass
        finally:
            pass
    assert list(walk_body(a.__code__.co_consts[-1])) == [
        If(test=Call(func=Name(id='b', ctx=Load()), args=[], keywords=[]),
           body=[Pass()], orelse=[]),
        Try(body=[Pass()],
            handlers=[ExceptHandler(type=Name(id='Exception', ctx=Load()),
                                    name=Name(id='Exception', ctx=Store()), body=[Pass()])],
            orelse=[Pass()], finalbody=[Pass()])
    ]
del test_walk_body



# Generated at 2022-06-11 19:31:00.482722
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    r = Resolver('test', {})
    assert r.visit(Attribute(Name('typing', Load()), 'Foo', Load())) == Name('Foo', Load())
    assert r.visit(Attribute(Name('foo', Load()), 'Foo', Load())) == Attribute(Name('foo', Load()), 'Foo', Load())
    return 'ok'


# Generated at 2022-06-11 19:31:09.187598
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    from ast import parse
    from importlib import reload
    from pathlib import Path
    import sys
    import re
    import doctest
    import io
    import atest.test_for_python
    import atest.test_for_python.globals
    import atest.test_for_python.globals.my_class
    import atest.test_for_python.globals.my_class.my_inner_class
    import atest.test_for_python.globals.my_class.my_inner_class.my_inner_inner_class

    test_path = (
        atest.test_for_python.__path__[0] +
        '/test_data/atest/test_for_python/globals.py')

# Generated at 2022-06-11 19:31:18.194299
# Unit test for method compile of class Parser
def test_Parser_compile():
    parser = Parser()
    init = re.findall(r'\n(def .*|class .*)\n', parser.compile())

# Generated at 2022-06-11 19:31:28.839190
# Unit test for method api of class Parser
def test_Parser_api():
    p = Parser()
    p.api('a.b', parse('def f() -> T: ...'),
          prefix='a')
    assert set(p.doc.keys()) == {'a.b.f'}
    assert set(p.docstring.keys()) == set()
    assert p.doc['a.b.f'] == '# f()\n\n*Full name:* `a.b.f`\n\n```python\n@a.b.T\n```'
    p.api('a.b', parse('class C(A, B): ...'))
    assert set(p.doc.keys()) == {'a.b.f', 'a.b.C'}

# Generated at 2022-06-11 19:31:34.471990
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from epydoc import apidoc
    p = Parser(['foo.py'], apidoc.optionparser, True)
    p.load('foo.py')
    p.func_ann('foo', [arg('self', None), arg('a', Name('int'))], True, False)
    p.func_ann('foo', [arg('a', Name('int'))], True, False)
    p.func_ann('foo', [arg('a', Name('int')), arg('b', None)], True, False)
    p.func_ann('foo', [arg('a', Name('int')), arg('b', None)], False, False)
