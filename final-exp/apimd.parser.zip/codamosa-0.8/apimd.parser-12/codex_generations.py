

# Generated at 2022-06-11 19:28:15.115589
# Unit test for method api of class Parser
def test_Parser_api():
    p = Parser(None)
    # FunctionDef
    tree = parse("""
    def func(a: int = 1, b: bool = True, c: float = 1.0, *args: str,
             d: str = "", **kwargs: Dict[str, int]) -> Tuple[int, ...]: ...
    """, type_comments=True)
    assert p.func_ann('', tree.body[0].args) == (
        'Self', 'int', 'bool', 'float', '*str', 'str', '**Dict[str, int]',
        'Tuple[int, ...]')
    # ClassDef

# Generated at 2022-06-11 19:28:21.460434
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    p = Parser()
    p.load_docstring('a', ModuleType('a'))
    assert p.docstring == {}
    p.doc['a.__init__'] = p.docstring['a.__init__'] = ""
    p.doc['a.__new__'] = p.docstring['a.__new__'] = ""
    p.doc['a.__a__'] = p.docstring['a.__a__'] = ""
    p.load_docstring('a', ModuleType('a'))
    assert len(p.docstring) == 2
p=Parser()

# Generated at 2022-06-11 19:28:23.423718
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    resolver = Resolver('root', {})
    assert resolver.visit_Attribute(Attribute(Name('typing', Load()),
                                              'Optional', Load()
                                              )
                                    ) == Name('Optional', Load())



# Generated at 2022-06-11 19:28:30.958272
# Unit test for method imports of class Parser
def test_Parser_imports():
    from . import lexer
    from . import parser
    
    _m = ""
    with tempfile.NamedTemporaryFile(mode='w') as f:
        f.write(_m)
        f.flush()
        tree = parser.parse(''.join(lexer.tokenize(open(f.name))))
        module = tree.body[0].names[0].name
        if module.startswith('.'):
            module = os.path.splitext(f.name)[0] + module
        for node in Parser.walk_body(tree.body):
            Parser.imports(module, node)
    
    
    
    
    

# Generated at 2022-06-11 19:28:40.325586
# Unit test for method imports of class Parser
def test_Parser_imports():
    p = Parser()
    p.imports('root', _parse('import a'))
    assert p.alias == {'root.a': 'a'}
    assert p.root == {'root.a': 'root'}
    p.imports('root', _parse('import a as b'))
    assert p.alias == {'root.a': 'a', 'root.b': 'b'}
    assert p.root == {'root.a': 'root', 'root.b': 'root'}
    p.imports('root', _parse('from . import a as b'))
    assert p.alias == {'root.a': 'a', 'root.b': 'b'}
    assert p.root == {'root.a': 'root', 'root.b': 'root'}
    p.im

# Generated at 2022-06-11 19:28:44.490420
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    r = Resolver("my_package_name", {})
    assert unparse(r.visit(parse("Union[int, str]").body[0].value)) == "Union[int, str]"
    assert unparse(r.visit(parse("Optional[int]").body[0].value)) == "Optional[int]"
    assert unparse(r.visit(parse("Optional[int, str]").body[0].value)) == "Optional[int, str]"
    assert unparse(r.visit(parse("return").body[0].value)) == "return"
    assert unparse(r.visit(parse("return").body[0].value)) == "return"
    my_Dict = "Dict"

# Generated at 2022-06-11 19:28:48.520805
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    code = """
from typing import Optional, Union, Tuple
a = Optional[int]
b = Union[int, str]
c = Tuple[int, int]
"""
    tree = parse(code)
    resolver = Resolver("", {})
    resolver.generic_visit(tree)
    expect = """
from typing import Union, Tuple
a = Union[int, None]
b = Union[int, str]
c = Tuple[int, int]
"""
    assert unparse(tree) == expect
    code = """
from typing import Literal
# Here is a comment.
a = Literal[None]
"""
    tree = parse(code)
    resolver = Resolver("", {})
    resolver.generic_visit(tree)
    expect = """
a = None
"""

# Generated at 2022-06-11 19:28:54.537113
# Unit test for function table
def test_table():  # type: ignore
    items = [['c', 'd'], ['e', 'f']]
    assert table('a', 'b', items) == \
        'a | b\n' \
        ':---:|:---:\n' \
        'c | d\n' \
        'e | f\n\n'


T = TypeVar('T')



# Generated at 2022-06-11 19:28:56.758297
# Unit test for method api of class Parser
def test_Parser_api():
    P = Parser
    # root : str
    # node : _G
    # prefix : str
    
    


# Generated at 2022-06-11 19:29:01.360280
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    f = Parser.func_api
    assert f(None, None, arguments(args=[], defaults=[], kw_defaults=[], kwonlyargs=[], kwonlydefaults=[], vararg=None, posonlyargs=[]), None, has_self=False, cls_method=False) == ()


# Generated at 2022-06-11 19:31:02.149011
# Unit test for method globals of class Parser
def test_Parser_globals():
    import doctest
    from .parser import Parser
    from .parser import _G
    from .parser import _I
    from .parser import _API
    import random
    if doctest.testmod().failed != 0:
        raise SystemError("tests are failed")
    parser = Parser()
    root: str = "root"
    parser.root[root] = root
    # Test case: globals_0

# Generated at 2022-06-11 19:31:06.598580
# Unit test for function doctest
def test_doctest():
    doc = """
    >>> test = 1
    >>> # test a
    >>> test + 1
    2
    """
    docs = """```python
    >>> test = 1
    >>> # test a
    >>> test + 1
    2
    ```"""
    assert doctest(doc) == docs



# Generated at 2022-06-11 19:31:17.514295
# Unit test for function const_type
def test_const_type():
    assert const_type(parse("1").body[0].value) == "int"
    assert const_type(parse("1.0").body[0].value) == "float"
    assert const_type(parse("True").body[0].value) == "bool"
    assert const_type(parse("'True'").body[0].value) == "str"
    assert const_type(parse("[1, 2, 3]").body[0].value) == "list[int]"
    assert const_type(parse("[1.2, 1.3]").body[0].value) == "list[float]"
    assert const_type(parse("[1.1, 1]").body[0].value) == "Any"

# Generated at 2022-06-11 19:31:28.347465
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    g = {'__name__': '__main__'}
    for key, value in {
        'typing.Tuple[[str, int], typing.Union[str, int]]:':
            '[str, int] | str | int',
        'typing.Optional[str]:':
            'str | None',
        'typing.List[typing.List[str]]:':
            'List[[str]]',
    }.items():
        t1 = cast(Expr, parse(key).body[0].value)
        t2 = cast(Expr, parse(value).body[0].value)
        assert Resolver('', {}).visit(t1) == Resolver('', {}).visit(t2)
        assert eval(unparse(t1), g), eval(unparse(t2), g)



# Generated at 2022-06-11 19:31:34.919532
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    def assert_func_ann(a, b):
        assert tuple(Parser({},{},{},{},{},{},{}).func_ann('', [arg(x, None) for x in a], True, False)) == b
    assert_func_ann(['a'], ('Self',))
    assert_func_ann(['/a'], ('/a',))
    assert_func_ann(['/a', '/b'], ('/a', '/b'))
    assert_func_ann(['/a', 'b'], ('Self', '/a', 'b'))
    assert_func_ann(['a', '*', 'b'], ('Self', 'a', '*b'))

# Generated at 2022-06-11 19:31:42.628697
# Unit test for function doctest
def test_doctest():
    __d = """
    This is first line.

    >>> This is second line.
    >>> This is third line.
    >>> This is forth line.

    This is fifth line.

    >>> This is sixth line.
    """
    __e = """
    This is first line.

    This is second line.
    >>> This is third line.
    >>> This is forth line.

    This is fifth line.

    ```python
    >>> This is sixth line.
    ```
    """
    assert doctest(__d) == __e



# Generated at 2022-06-11 19:31:49.698852
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    pk1 = importlib.import_module('typing')
    pk2 = importlib.import_module('pydoc_markdown')
    m1 = pk1.__file__.removeprefix('/').rsplit('/', 1)[0]
    m2 = pk2.__file__.removeprefix('/').rsplit('/', 1)[0]
    parser = Parser()
    parser.load_docstring(m1, pk1)
    parser.load_docstring(m2, pk2)
    logger.info(parser.compile())



# Generated at 2022-06-11 19:32:00.854234
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    # test case 1
    import math
    m = math
    p = Parser()
    p.load_docstring('math', m)
    assert len(p.docstring) == len(p.doc)
    # test case 2
    import test_Parser_load_docstring as m
    p = Parser()
    p.load_docstring('test_Parser_load_docstring', m)
    assert len(p.docstring) + 1 == len(p.doc)
    # test case 3
    m = ModuleType('m')
    p = Parser()
    p.load_docstring('m', m)
    assert len(p.docstring) == len(p.doc)
    # test case 4
    m = object()
    p = Parser()

# Generated at 2022-06-11 19:32:06.481298
# Unit test for function walk_body
def test_walk_body():
    """Test for function walk_body()"""
    import astor

# Generated at 2022-06-11 19:32:13.627848
# Unit test for function doctest
def test_doctest():
    doc = '''
    test1
    >>> print("Markdown")
    test2
    >>> print("Python")
    >>> print("Python")
    test3'''
    print(doctest(doc))
    assert doctest(doc) == '''
    test1
    ```python
    >>> print("Markdown")
    test2
    >>> print("Python")
    >>> print("Python")
    ```
    test3'''



# Generated at 2022-06-11 19:33:52.876128
# Unit test for method imports of class Parser
def test_Parser_imports():
    p = Parser()
    p.doc = {'m.A': 'm.A', 'm.B': 'm.B', 'm.C': 'm.C'}
    _ = p.imports('m', Module(body=[
        Import(names=[alias('C', 'ccc')]),
        ImportFrom('d', [alias('E', None)], 0),
        ImportFrom('d', [alias('F', None)], 1),
        ImportFrom('d.g', [alias('G', None)], 0),
        ImportFrom('d.h', [alias('H', None)], 0),
        ImportFrom('d.i', [alias('I', 'iii')], 0),
    ]))

# Generated at 2022-06-11 19:34:01.888555
# Unit test for method compile of class Parser
def test_Parser_compile():
    p = Parser(True, {'', {}, {}, {}, {}, {}, {}, {}, {}}, set(), set(), 0)
    p.const.update({'', {}})
    p.root.update({'', {}, {}})
    p.doc.update({'', '', {}, {}})
    p.docstring.update({'', {}, {}})
    p.imp.update({'', {}, {}, {}})
    p.level.update({'', {}, {}})
    p.alias.update({'', {}, {}, {}})
    # noinspection PyTypeChecker
    return p.compile()