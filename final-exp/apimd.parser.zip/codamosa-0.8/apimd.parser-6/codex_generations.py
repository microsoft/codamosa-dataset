

# Generated at 2022-06-11 19:27:33.401677
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    alias = {
        'typing.Union': 'Union', 
        'typing.Optional': 'Optional',
        'typing.TypeVar': 'TypeVar',
    }
    r = Resolver('', alias);

    # PEP585
    a = parse('''Optional[Tuple[str, ...]]''').body[0]
    assert unparse(r.visit(a)) == 'Union[Tuple[str, ...], None]'
    a = parse('''Optional[str]''').body[0]
    assert unparse(r.visit(a)) == 'Union[str, None]'
    a = parse('''Optional[int]''').body[0]
    assert unparse(r.visit(a)) == 'Union[int, None]'

# Generated at 2022-06-11 19:27:44.086709
# Unit test for method api of class Parser
def test_Parser_api():
    def test_Parser_api_0():
        arr = [_Node()]
        a = Parser(0)
        a.api('a', _Node(), prefix='')
        assert a.root == {}
        assert a.doc == {}
        assert a.level == {}
        assert a.const == {}
        assert a.docstring == {}
        assert a.root == {}
        assert a.level == {}
        assert a.alias == {'a': 'a'}
        assert a.imp == {'a': set()}
        assert a.b_level == 0
        assert a.toc == False
        assert a.link == False
    

# Generated at 2022-06-11 19:27:54.089621
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    from . import Parser
    from .parser import ClassDef

    class TestParser0(Parser):
        "Unit test."
        # pylint: disable=too-few-public-methods

        def class_api(self, *args: Any) -> None:
            assert args == (
                'root',
                'name',
                [],
                [
                    ClassDef(
                        name='T',
                        bases=[],
                        body=[],
                        decorator_list=[],
                        keywords=[],
                    ),
                ],
            )
    TestParser0().parse_file('test/parser.py')

    class TestParser1(Parser):
        "Unit test."
        # pylint: disable=too-few-public-methods


# Generated at 2022-06-11 19:28:01.471542
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    codes = ['type[Ex]', 'type[Self]', '', '', 'type[Args]', 'type[Kwargs]',
             'type[Return]']
    nodes = parse('''
                   def f(a: A, b, c: C, *args: Tuple[Args], **kwargs: Kwargs):
                       return b
                   ''')
    node = nodes[1]
    assert list(Parser(logger).func_ann('', node.args, has_self=False,
                                        cls_method=False)) == codes

# Generated at 2022-06-11 19:28:08.372663
# Unit test for function const_type
def test_const_type():
    src = (
        "bool(True)",
        "int(1)",
        "float(1.0)",
        "complex(1.0 + 1.0j)",
        "str('')",
        "Callable[[int, float], float]",
        "Optional[int]",
        "Sequence[int]",
        "Tuple[int, float]",
        "List[int]",
        "Set[int]",
        "Dict[str, int]",
        "int(x) if x else x",
        "ulist(int, float)",
        "dset(1, 2, 3, 4)",
        "tuple[0]",
        "dict[m: 1, n: 2]",
        "dict[1]",
    )
    for s in src:
        assert const_type

# Generated at 2022-06-11 19:28:17.551104
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    import inspect
    from unittest import TestCase
    from .resolver import Resolver

    def _m(a: str, b: str) -> str:
        """Return the full name of the method."""
        return a + '.' + b
    class A: # pylint: disable=too-few-public-methods
        @staticmethod
        def m1(
            a: int,
            b: float,
            c: str = None,
            *args: int,
            d: str = None,
            e: str = None,
            **kwargs: str
        ) -> float:
            """
            >>> A.m1(1, 2, 3, 4, 5, d=7, e='8')
            9
            """
            return a + b + sum(args) + int(d) + int

# Generated at 2022-06-11 19:28:23.300107
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    assert Parser.func_api(None, None, [arg('a', None), arg('b', None)],
                           None, has_self=False, cls_method=False) == ['a', 'b']
    assert Parser.func_api(None, None, [arg('a', None), arg('b', None)], None,
                           has_self=False, cls_method=True) == ['a', 'b']
    assert Parser.func_api(None, None, [arg('a', None), arg('b', None)], None,
                           has_self=True, cls_method=False) == ['Self', 'a', 'b']

# Generated at 2022-06-11 19:28:30.812804
# Unit test for method api of class Parser
def test_Parser_api():
    import ast, astor
    p = Parser(link=False, toc=False)
    g = globals()
    ast.fix_missing_locations(Dummy(g))
    astor.to_source(g)
    m = ModuleType('__m__')
    exec('', m.__dict__)
    for name, value in g.items():
        setattr(m, name, value)
    p.parse_module(m)
    for name, value in g.items():
        if not isinstance(value, Dummy):
            continue
        value.body = p.api(name, value, prefix='')
        value.body = p.doc[name].format(name, name.lower().replace('.', '-'))
        p.load_docstring(name, m)

# Generated at 2022-06-11 19:28:39.856249
# Unit test for method compile of class Parser
def test_Parser_compile():
    from .unit_test import Parser as ParserTest
    from .unit_test import logger as loggerTest

    def setUpModule():
        print()
        print(__name__)

    def test_module():
        p = ParserTest(['os'])
        assert p.parse() == ''
        p.toc = True
        p.link = True
        p.b_level = 1

# Generated at 2022-06-11 19:28:47.801954
# Unit test for method globals of class Parser
def test_Parser_globals():
    from unittest.mock import patch
    from types import ModuleType
    from typing import (
        Any, Optional, Union, Sequence, Mapping, Set, List, Tuple, Type, Callable,
        TypeVar, ClassVar, Generic, Iterable, Iterator, List, Mapping, Tuple,
        Optional, Any, Union, TypeVar, Callable, Generic, ClassVar, Sequence
    )
    from enum import Enum
    T = TypeVar('T')
    def test_parse(code: str) -> str:
        return Parser().parse(f'Module_{code}', code).compile()

# Generated at 2022-06-11 19:31:27.280752
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    imp = {'a': set(), 'b': {'b.x'}, 'c': {'c.x', 'c.y.z'}}
    parser = Parser(imp)
    assert not parser.is_public('a')
    assert parser.is_public('a.b')
    assert not parser.is_public('a.x')
    assert parser.is_public('b')
    assert parser.is_public('b.x')
    assert parser.is_public('c')
    assert parser.is_public('c.x')
    assert parser.is_public('c.y')
    assert parser.is_public('c.y.z')
    assert not parser.is_public('c.y.e')
    assert not parser.is_public('c.y.z.v')

# Generated at 2022-06-11 19:31:34.250809
# Unit test for function is_public_family
def test_is_public_family():
    assert is_public_family('asdf')
    assert is_public_family('asdf._qwre')
    assert not is_public_family('asdf.__qe')
    assert not is_public_family('asdf.__qe__')
    assert is_public_family('asdf.match')
    assert is_public_family('asdf.match._qwre')
    assert not is_public_family('asdf.match__qe')
    assert not is_public_family('asdf.match__qe__')
    assert not is_public_family('asdf.__qe.match')
    assert not is_public_family('asdf.__qe__.match')
    assert is_public_family('asdf.__qe.match._wre')
    assert is_public_family

# Generated at 2022-06-11 19:31:45.299878
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    class TestParser(Parser):
        def func_ann(self, root, args, **k):
            return ("","")
        def resolve(self, root, node, **k):
            return ""
    def test():
        class Test:
            pass
        parser = TestParser()
        parser.root[""] = ""
        parser.class_api("","",None, [Assign([Name("a", Store())],Constant("1")),Delete([Name("a", Store())]),Delete([Attribute(Name("a", Load()), "b", Store())])])
        if parser.doc[""] != "## class Test\n\n*Full name:* `Test`\n\n| Members | Type |\n| --- | --- |\n| `a` | ":
            raise RuntimeError
    test()


# Generated at 2022-06-11 19:31:52.530737
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    a = arg('a', None)
    b = arg('b', None)
    c = arg('c', None)
    p = arg('/', None)
    v = arg('*args', None)
    k = arg('**kwargs', None)
    f = arg('return', None)
    assert Parser().func_ann('', [a, b, c]) == ['ANY', 'ANY', 'ANY']
    assert Parser().func_ann('', [p, a]) == ['ANY', 'ANY']
    assert Parser().func_ann('', [p, p, a, p]) == ['ANY', 'ANY', 'ANY', 'ANY']
    assert Parser().func_ann('', [p, p, a, v]) == ['ANY', 'ANY', 'ANY', 'ANY']

# Generated at 2022-06-11 19:31:58.610064
# Unit test for method visit_Name of class Resolver
def test_Resolver_visit_Name():
    """Test Resolver.visit_Name method."""
    node = parse('''
v = 42
    ''')
    r = Resolver('test', {'test': '', 'test.v': '42'})
    node = r.visit(node)
    assert node.body[0].value.n == 42
    assert node.body[0].value.s == ''


# Generated at 2022-06-11 19:32:06.986761
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    root = "module.name"
    args = [
        arg("name", Name("str", None)),
        arg("age", Name("int", None)),
        arg("*args", Name("tuple", None)),
        arg("**kws", Name("dict", None)),
        arg("return", Name("float", None)),
    ]
    ty = (
        "type[str]",
        "type[int]",
        "type[tuple]",
        "type[dict]",
        "type[float]",
    )
    alias = {}
    p = Parser(alias)
    assert list(p.func_ann(root, args, has_self=True, cls_method=False)) == [
        "Self",
        *ty,
    ]

# Generated at 2022-06-11 19:32:10.390904
# Unit test for method compile of class Parser

# Generated at 2022-06-11 19:32:14.529061
# Unit test for function table
def test_table():
    assert table('a', 'b', [['c', 'd'], ['e', 'f']]) ==\
        '| a | b |\n'\
        '|:---:|:---:|\n'\
        '| c | d |\n'\
        '| e | f |\n\n'



# Generated at 2022-06-11 19:32:19.908167
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    from inspect import signature, Parameter
    from .parser import Parser
    from .walk import walk_body
    from .parse import parse
    from .const import ANY
    from .annotation import type_comment
    from typing import List, Tuple, Optional

    class A:
        """A class."""

        x: int
        y: Tuple[int, ...]
        z: List[int]
        w: Optional[int]

        def __init__(self, x: int = 0, y: int = 0, **kwargs) -> None:
            """Init."""

        def __enter__(self) -> 'A':
            """Enter."""


# Generated at 2022-06-11 19:32:28.095984
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser({}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, 0, {})
    p.doc = {}
    # Test 1
    p.func_api("root", "name", arg("a", Name('str', ctx=Load())),
               None, has_self=False, cls_method=False)
    assert p.doc == {"name": "## name()\n\n"
                     "*Full name:* `name`\n\n"
                     "| type[str] | |\n"
                     "|-----------|-|\n"
                     "| a         | |\n"
                     "|           | |\n"}
    # Test 2