

# Generated at 2022-06-11 19:30:12.552244
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    parser = Parser(['print', '_'], 'test')
    parser.imp = {'test': {'test', 'print'}}
    assert not parser.is_public('test.a')
    parser.const = {'test.A': 'int'}
    assert parser.is_public('test.A')
    parser.const = {}
    parser.doc = {'test.print': '# print()'}
    assert parser.is_public('test.print')



# Generated at 2022-06-11 19:30:20.533231
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    #  Check the name is public style or listed in `__all__`
    """
    This is actually unit test for method is_public of class Parser
    It tests the "publicness" of a name.

    """
    parser = Parser(link=True)
    parser.imp['__all__'] = set()
    parser.imp['a'] = {'b'}
    parser.root['a.b'] = 'a.b'
    parser.root['a.b.c'] = 'a.b.c'
    parser.root['a.b.c.d'] = 'a.b.c.d'
    parser.root['a.b.e'] = 'a.b.e'
    parser.root['a.f'] = 'a.f'

# Generated at 2022-06-11 19:30:28.614501
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    p = Parser()
    doc, name = '', 'test'
    t1, t2 = 't1', 't2'
    class MyClass:
        """Documentation."""
        x: int
        y: str = "Hello"
        def f(self, x: int = 0) -> str:
            pass
        def sub_f(self, x: int = 0) -> str:
            pass
    body = parse( dedent(f'''
    
    class MyClass(t1, t2):

        """Documentation."""

        x: int

        y: str = "Hello"

        def f(self, x: int = 0) -> str:
            pass

        def sub_f(self, x: int = 0) -> str:
            pass
    ''')).body

    p.class_

# Generated at 2022-06-11 19:30:29.293111
# Unit test for method compile of class Parser
def test_Parser_compile():
    pass

# Generated at 2022-06-11 19:30:36.817153
# Unit test for method api of class Parser
def test_Parser_api():
    p = Parser()
    import unittest
    import datetime as dt
    @p.api
    class Test():
        """Only docstring."""
        def __init__(self, name: str, year: int = 2021) -> None:
            pass
        def __call__(self, *args: int) -> None:
            """Nothing."""
        def test(self) -> bool:
            """A test function."""
        @classmethod
        def from_date(cls, year: int, month: int, day: int) -> 'Test':
            pass
        def __len__(self) -> int:
            return 1
        def __add__(self, other: int) -> int:
            pass

# Generated at 2022-06-11 19:30:44.095474
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser('tests/tests.py')
    p.parse()
    assert 'tests.tests.B.c' in p.alias
    assert 'tests.tests.C' in p.alias
    assert 'tests.tests.E.f' in p.alias
    assert 'tests.tests.E.F.b' in p.alias
    assert 'tests.tests.T' in p.alias

# Generated at 2022-06-11 19:30:48.426022
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    class TestResolver(Resolver):
        def __init__(self):
            super(TestResolver, self).__init__("", {})

    assert TestResolver().visit(parse("Union[int, str]").body[0].value) == \
        parse("bool").body[0].value
    assert TestResolver().visit(parse("Optional[str]").body[0].value) == \
        parse("str or None").body[0].value


# Generated at 2022-06-11 19:30:49.364316
# Unit test for method parse of class Parser

# Generated at 2022-06-11 19:30:56.341310
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    import sys
    main = sys.modules['__main__']
    main.__file__ = 'foo'
    main.__name__ = 'foo'
    sys.modules['foo'] = main
    p = Parser(link=False)
    assert p.is_public('foo')
    assert p.is_public('foo.bar')
    assert not p.is_public('foo.__bar')
    assert not p.is_public('foo._bar')
    assert not p.is_public('foo.__bar__')
    main.__all__ = ['bar', 'spam']
    assert p.is_public('foo')
    assert p.is_public('foo.bar')
    assert not p.is_public('foo.spam')
    p = Parser(link=False)
    assert p.is_

# Generated at 2022-06-11 19:31:06.531761
# Unit test for method is_public of class Parser
def test_Parser_is_public():
    p = Parser(link=True)
    p.imp['mod'] = {'mod.a', 'mod.b'}
    assert p.is_public('mod')
    assert p.is_public('mod.a')
    assert p.is_public('mod.b')
    assert not p.is_public('mod.c')

    p.imp['mod'] = set()
    assert p.is_public('mod')
    assert p.is_public('mod.A')
    assert p.is_public('mod.a')
    assert not p.is_public('mod.c')

    p.imp['mod'] = None
    assert p.is_public('mod')
    assert p.is_public('mod.A')
    assert not p.is_public('mod.a')

# Generated at 2022-06-11 19:32:20.941983
# Unit test for function const_type
def test_const_type():
    assert const_type(ast.parse('None', mode="eval").body) == 'None'
    assert const_type(ast.parse('True', mode="eval").body) == 'bool'
    assert const_type(ast.parse('False', mode="eval").body) == 'bool'
    assert const_type(ast.parse('2j', mode="eval").body) == 'complex'
    assert const_type(ast.parse('1', mode="eval").body) == 'int'
    assert const_type(ast.parse('1.0', mode="eval").body) == 'float'
    assert const_type(ast.parse('1.0', mode="eval").body) == 'float'
    assert const_type(ast.parse("'i'", mode="eval").body) == 'str'

# Generated at 2022-06-11 19:32:25.102774
# Unit test for function table
def test_table():
    assert table('Name', 'Color', [['Mark', 'Red'], ['John', 'Blue']]) == '''\
| Name | Color |
|:---:|:---:|
| Mark | Red |
| John | Blue |

'''  # noqa: E501



# Generated at 2022-06-11 19:32:36.946253
# Unit test for function const_type
def test_const_type():
    assert const_type(Constant(value=123)) == _type_name(123)
    assert const_type(Tuple(elts=[Constant(value=123),
                                  Constant(value=456)])) == 'tuple[int, int]'
    assert const_type(List(elts=[Constant(value=123),
                                 Constant(value=456)])) == 'list[int, int]'
    assert const_type(Set(elts=[Constant(value=123),
                                Constant(value=456)])) == 'set[int, int]'
    assert const_type(Set(elts=[Constant(value=123.0),
                                Constant(value=456)])) == 'set[Any]'
    assert const_type(Call(func=Name(id='bool', ctx=Load()))) == 'bool'


# Generated at 2022-06-11 19:32:46.848459
# Unit test for method api of class Parser
def test_Parser_api():
    p = Parser(
        b_level=0,
        toc=False,
    )
    root = 'root'
    name = 'name'
    node = FunctionDef(
        args=arguments(
            args=[
                arg(
                    arg='arg',
                    annotation=Name(
                        id='ann',
                        ctx=Load(),
                    ),
                ),
            ],
        ),
        returns=Name(
            id='name',
            ctx=Load(),
        ),
    )
    has_self = 'has_self'
    cls_method = 'cls_method'
    p.api(root, node)
    assert (p.doc[name] == "# name()\n\n*Full name:* `name`\n\n")

# Generated at 2022-06-11 19:32:58.260763
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    import pydmt
    import pydmt.test.test_doc
    p = Parser(link=False)
    p.load(pydmt, 'pydmt')
    p.load(pydmt.test.test_doc, 'pydmt.test.test_doc')
    assert len(p.doc) == 308
    assert len(p.docstring) == 60
    assert len(p.alias) == 49
    assert len(p.root) == 308
    assert len(p.level) == 308
    assert p.docstring['pydmt.test.test_doc.test_Parser_load_docstring']

    name = 'pydmt.test.test_doc.TestDoc.test_get_docstring_with_coding'

# Generated at 2022-06-11 19:32:59.149678
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    p = Parser('')



# Generated at 2022-06-11 19:33:07.848187
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    Parser(link=True).class_api(
        'root', 'root.name', [], [
            ClassDef(
                'B', [], [], [], [], [], [], [
                    Assign(
                        [Name('a', Store())],
                        Constant(1, value=1))], [], [], []),
            AnnAssign(
                Name('b', Store()),
                Constant(2, value=2),
                Constant(3, value=3)),
            Assign(
                [Name('c', Store())],
                Constant(4, value=4),
                Constant(5, value=5)),
            Delete([Name('a', Load())]),
            Delete([Name('a', Load())], [], []),
            Pass()])



# Generated at 2022-06-11 19:33:13.268368
# Unit test for function const_type
def test_const_type():
    assert const_type(ast.parse("5").body[0]) == 'int'
    assert const_type(ast.parse("5.5").body[0]) == 'float'
    assert const_type(ast.parse("1j").body[0]) == 'complex'
    assert const_type(ast.parse("\"\"").body[0]) == 'str'
    assert const_type(ast.parse("True").body[0]) == 'bool'
    assert const_type(ast.parse("(1, True)").body[0]) == 'tuple[int, bool]'
    assert const_type(ast.parse("[1, True]").body[0]) == 'list[int, bool]'
    assert const_type(ast.parse("{1, True}").body[0]) == 'set[int, bool]'

# Generated at 2022-06-11 19:33:23.055182
# Unit test for method compile of class Parser
def test_Parser_compile():
    # Test for module with docstring
    parser = Parser('', __name__, False)
    parser.load_docstring(__name__, sys.modules[__name__])
    parser.doc[__name__] = "{}\n{}"
    parser.b_level = 0
    doc = parser.compile()
    doc = doc.splitlines()
    assert "- [_Parser__func_api(root: str, name: str, node: arguments, returns: Optional[expr], *, has_self: bool, cls_method: bool) -> None](#_parser__func_api-root--str--name--str--node--arguments--returns--optional-expr----has_self--bool--cls_method--bool--none)" in doc

# Generated at 2022-06-11 19:33:31.374227
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    def func():
        return 0
    parser = Parser()
    attr = parser.func_doc(func)
    assert parser.doc[attr] == """\
# func_api()

*Full name:* `<function Parser.func_api at 0x10c2f2b90>`


+-----------+----------------------+
| Argument  | Type                 |
|-----------+----------------------|
| return    | int                  |
+-----------+----------------------+

+-------------------------------+
| Return                         |
|-------------------------------|
| int                           |
+-------------------------------+


"""
