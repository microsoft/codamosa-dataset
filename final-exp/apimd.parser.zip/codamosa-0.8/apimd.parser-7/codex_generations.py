

# Generated at 2022-06-11 19:28:23.106005
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    from docat.utils import run_test
    parser = Parser()
    def func_ann(m, *args, **kwargs):
        root = 'module'
        parser = Parser()
        parser.root[root] = root
        parser.level[root] = 0
        return list(parser.func_ann(root, *args, **kwargs))

# Generated at 2022-06-11 19:28:26.759317
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    root = os.path.join(os.path.dirname(__file__), 'sample')
    p = Parser(root=root)
    m = _import(p.dots.join(os.path.relpath(root, os.path.dirname(root))))
    p.load_docstring('sample', m)
    assert p.docstring['sample.Foo.bar'] == doctest(getdoc(m.Foo.bar))

# Generated at 2022-06-11 19:28:29.217224
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    p.parse('source/uvloop/loop.py')
    print()
    print(p.compile())


# Generated at 2022-06-11 19:28:36.053470
# Unit test for method compile of class Parser
def test_Parser_compile():
    p = Parser(b_level=1, toc=False, link=False)
    p.doc['a'] = "``{}``\n\n{}\n\n#{}\n\n"
    p.docstring['a'] = "a\n\n[test]\n\n"
    p.doc['a.b'] = "``{}``\n\n{}\n\n#{}\n\n"
    p.docstring['a.b'] = "b\n\n"
    p.doc['a.c'] = "``{}``\n\n{}\n\n"
    p.alias['a.d'] = 'a.b'
    p.doc['a.d'] = "``{}``\n\n{}\n\n"
    p.doc

# Generated at 2022-06-11 19:28:46.916681
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():

    def func_ann(root: str, args: List[arg]) -> Iterator[str]:
        """Function annotation table."""
        self_ty = ""
        for i, a in enumerate(args):
            if not has_self:
                yield a.annotation
            else:
                if i == 0:
                    self_ty = a.annotation
                yield self_ty

    p = Parser('', None, '')

# Generated at 2022-06-11 19:28:59.133611
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    import ast
    import sys
    import types
    def set_docstring(name, m):
        if name.startswith('os.'):
            m.__doc__ = f"""{name} docstring"""
    parser = Parser(set_docstring, lambda n: n.startswith('os.'))
    m = types.ModuleType('os')
    sys.modules['os'] = m
    parser.load(ast.parse('def f(): pass'))
    parser.load_docstring('os.path', m)
    assert parser.doc['os.path.f'] == """# f()\n\n*Full name:* `os.path.f`\n\n"""
    assert parser.docstring['os.path.f'] == 'os.path.f docstring\n'

# Generated at 2022-06-11 19:29:05.702674
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    root = 'a'
    # The first two elements are for root and name,
    # which are found in the method __init__.
    args = [root, 'A']
    sample = Parser(*args)
    sample.class_api(root, 'A', [], [])
    assert(sample.docstr.get('A') == None)
    sample.class_api(root, 'A', [], [Expr(value=Name(id='a', ctx=Load()))])
    assert(sample.docstr.get('A') != None)

# Generated at 2022-06-11 19:29:11.129830
# Unit test for method parse of class Parser
def test_Parser_parse():
    src = """
    def func() -> int:
        '''Func docstring.'''
        return 123"""
    parser = Parser()
    parser.parse("test", src)
    assert parser.doc == {'test.func': '# func()\n\n*Full name:* `test.func`\n\n'
                                       '## Arguments\n\n'
                                       '|      |         |\n'
                                       '| ---- | ------- |\n'
                                       '| *return* | `int` |\n\n'
                                       '## Docstring\n\n'
                                       'Func docstring.\n'}

# Generated at 2022-06-11 19:29:16.301402
# Unit test for method class_api of class Parser

# Generated at 2022-06-11 19:29:20.692557
# Unit test for method load_docstring of class Parser
def test_Parser_load_docstring():
    def f(a: int) -> str:
        """Docstring."""
    def g(a: str) -> str:
        """Docstring."""
    p = Parser()
    p.api('test', FunctionDef(name='f', args=arguments(args=[arg(arg='a', annotation=Constant(value=int))], returns=Constant(value=str)), body=[], decorator_list=[], returns=None, type_comment=None))
    p.api('test', FunctionDef(name='g', args=arguments(args=[arg(arg='a', annotation=Constant(value=str))], returns=Constant(value=str)), body=[], decorator_list=[], returns=None, type_comment=None))

# Generated at 2022-06-11 19:34:04.391817
# Unit test for function walk_body
def test_walk_body():
    from ast import parse
    from astunparse import unparse
    from .operators import code, py_code
    import ast

    py = py_code("""
    a = 0
    b = 1
    if 1:
        c = 2
        if 1:
            d = 3
        else:
            e = 3
    else:
        f = 2
        if 1:
            g = 3
        else:
            h = 3
        try:
            i = 1
        except Exception:
            j = 1
        finally:
            k = 1
    """)