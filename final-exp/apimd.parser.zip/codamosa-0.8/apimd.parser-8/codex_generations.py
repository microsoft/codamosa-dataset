

# Generated at 2022-06-11 19:33:01.651764
# Unit test for method func_api of class Parser
def test_Parser_func_api():
    import inspect
    import doctest

    def func_api(root: str, name: str, node: arguments,
                 returns: Optional[Any], *,
                 has_self: bool, cls_method: bool) -> None:
        """Function annotation table."""
        self_ty = ""
        for i, a in enumerate(args):
            if has_self and i == 0:
                if a.annotation is not None:
                    self_ty = self.resolve(root, a.annotation)
                    if cls_method:
                        self_ty = (self_ty.removeprefix('type[')
                                   .removesuffix(']'))
                yield 'type[Self]' if cls_method else 'Self'
            elif a.arg == '*':
                yield ""

# Generated at 2022-06-11 19:33:05.838014
# Unit test for function doctest
def test_doctest():
    s = '''"""
    >>> print('u' + 's')
    us
    """
    '''
    dst = '\n'.join(['', '```python', '>>> print(\'u\' + \'s\')', 'us', '```'])
    assert doctest(s) == dst



# Generated at 2022-06-11 19:33:12.307848
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    assert Parser().func_ann('X', []) == []
    assert Parser().func_ann('X', [
        arg('a', parse_ann('None')), arg('b', parse_ann('int'))
    ]) == ['None', 'int']
    assert Parser().func_ann('X', [arg('a', None)]) == ['Any']
    assert Parser().func_ann('X', [arg('a', parse_ann('Y'))]) == ['Y']
    assert Parser().func_ann('X', [arg('a', parse_ann('X'))]) == ['Self']
    assert Parser().func_ann(
        'X', [arg('/', None), arg('a', parse_ann('int'))],
        has_self=True) == ['type[Self]', 'int']

# Generated at 2022-06-11 19:33:22.540107
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    root = "a.b"
    alias = {
        "a.b.t1": "tuple",
        "a.b.t2": "tuple[str, int]",
        "a.b.t3": "tuple[str, ...]",
        "a.b.l": "list[str]",
        "a.b.s": "set[str]",
        "a.b.d": "dict[str, int]",
        "a.b.u": "Union[a.b.t1, a.b.t2, a.b.t3]",
        "a.b.typing": "typing"
    }
    resolver = Resolver(root, alias)
    assert resolver.visit(parse("t1").body[0].value)
    assert res

# Generated at 2022-06-11 19:33:33.953996
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    """Ensure that visit_Subscript return the expected values."""
    assert Resolver("xyz", {}).visit(
        parse("Union[X, Y]").body[0].value
    ) == parse("X | Y").body[0].value
    assert Resolver("xyz", {}).visit(
        parse("Optional[X, Y]").body[0].value
    ) == parse("X | Y | None").body[0].value
    assert Resolver("xyz", {}).visit(
        parse("Union[a.b, c.d]").body[0].value
    ) == parse("a.b | c.d").body[0].value
    assert Resolver("xyz", {}).visit(
        parse("Optional[a.b, c.d]").body[0].value
    ) == parse

# Generated at 2022-06-11 19:33:44.385071
# Unit test for method globals of class Parser
def test_Parser_globals():
    p = Parser()
    root = ""
    p.globals(root, Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=1)))
    assert p.alias["a"] == "1"
    p.globals(root, AnnAssign(target=Name(id='b', ctx=Store()), annotation=Name(id='int', ctx=Load()), value=None))
    assert p.alias["b"] == "int"

# Generated at 2022-06-11 19:33:51.669964
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    """Unit test for Parser.func_ann."""
    # Case 1
    root, args, ann = "", [], []
    eq_(list(Parser.func_ann(None, root, args, has_self=True, cls_method=False)), ann)
    # Case 2
    root, args, ann = "", [arg('arg1', None), arg('arg2', None)], ["arg1", "arg2"]
    eq_(list(Parser.func_ann(None, root, args, has_self=True, cls_method=False)), ann)
    # Case 3
    root, args, ann = "", [arg('self', None), arg('arg1', None), arg('arg2', None)], ["Self", "arg1", "arg2"]

# Generated at 2022-06-11 19:34:03.640712
# Unit test for function doctest
def test_doctest():
    s = """
>>>>>> sample
>>>>>> more"""
    assert doctest(s) == """```python
>>>>>> sample
>>>>>> more
```"""
    s = """
>>>>>> sample
>>>>>> more
>>>>>>
>>>>>> next\n
>>>>>> line"""
    assert doctest(s) == """```python
>>>>>> sample
>>>>>> more
```
```python
>>>>>>
>>>>>> next\n
>>>>>> line
```"""
    s = """
>>>>>> sample
>>>>>> more
>>>>>>
>>>>>> next\n
>>>>>> line
>>>>>>
>>>>>> sample"""