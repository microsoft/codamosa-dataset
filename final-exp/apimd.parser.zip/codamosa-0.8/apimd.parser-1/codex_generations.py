

# Generated at 2022-06-11 19:32:48.578891
# Unit test for function const_type
def test_const_type():
    # Simple value
    assert const_type(parse('5', '<string>', 'eval').body) == 'int'
    assert const_type(parse('5.0', '<string>', 'eval').body) == 'float'
    assert const_type(parse('5j', '<string>', 'eval').body) == 'complex'
    assert const_type(parse('"test"', '<string>', 'eval').body) == 'str'
    assert const_type(parse('True', '<string>', 'eval').body) == 'bool'
    # PEP 585
    assert const_type(parse('None', '<string>', 'eval').body) == 'typing.Optional[NoneType]'
    assert const_type(parse('True', '<string>', 'eval').body) == 'bool'
   

# Generated at 2022-06-11 19:32:59.643346
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    # Test type
    from collections import OrderedDict
    from typing import NamedTuple, Union
    class A(NamedTuple): ...
    class B(NamedTuple): ...
    class C: ...
    def fn_A(a: A) -> None: ...
    def fn_B(b: B) -> None: ...
    def fn_C(c: C) -> None: ...
    def fn_A_or_B(a: Union[A, B]) -> None: ...
    def fn_A_or_B_or_C(a: Union[A, B, C]) -> None: ...
    def fn_A_or_B_or_None(a: Union[A, B, None]) -> None: ...
    # Test case

# Generated at 2022-06-11 19:33:08.617651
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    p = Parser()
    args = [arg('x', None), arg('y', None), arg('z', None),
            arg('*', None), arg('**', None), arg('return', None)]
    g = p.func_ann('', args, has_self=False, cls_method=False)
    assert list(g) == ['Any', 'Any', 'Any', '', '', 'Any']
    args = [arg('x', None), arg('y', None), arg('z', None),
            arg('*', None), arg('**', None), arg('return', None)]
    g = p.func_ann('', args, has_self=True, cls_method=False)
    assert list(g) == ['Self', 'Any', 'Any', '', '', 'Any']

# Generated at 2022-06-11 19:33:16.720611
# Unit test for method parse of class Parser
def test_Parser_parse():
    from logging import DEBUG

    from asttokens import asttokens
    from pytest import fixture

    from .utils import set_logger

    @fixture(scope='module')
    def parser(log: bool) -> Parser:
        if log:
            set_logger(DEBUG)
        return Parser()

    @fixture(scope='module')
    def tokenizer(parser: Parser) -> ASTTokenizer:
        return parser.tokenizer


# Generated at 2022-06-11 19:33:24.797302
# Unit test for method func_ann of class Parser
def test_Parser_func_ann():
    alias = {
        'A': 'Parent',
        'A.aa': 'Parent.aa',
        'B': 'Child',
        'C': 'Parent',
        'C.cc': 'Parent.cc',
    }

    p = Parser(alias=alias, link=False)
    assert list(p.func_ann('A', [
        arg('a', None),
        arg('b', Name('A')),
        arg('c', Call(func=Name('A'), args=[], keywords=[])),
        arg('d', None),
    ])) == [ANY, 'Self', 'Parent', ANY]

# Generated at 2022-06-11 19:33:35.531636
# Unit test for method class_api of class Parser
def test_Parser_class_api():
    """Test for class_api method."""
    import ast
    from typing import Any
    p = Parser()

# Generated at 2022-06-11 19:33:43.698785
# Unit test for method visit_Attribute of class Resolver
def test_Resolver_visit_Attribute():
    resolver = Resolver('', {})
    assert isinstance(resolver.visit_Attribute(Attribute(Name('typing', Load()), 'Any', Load())), Name)
    assert not isinstance(resolver.visit_Attribute(Attribute(Name('typing', Load()), 'Any', Load())), Attribute)
    assert isinstance(resolver.visit_Attribute(Attribute(Name('any', Load()), 'Any', Load())), Attribute)
    assert not isinstance(resolver.visit_Attribute(Attribute(Name('any', Load()), 'Any', Load())), Name)



# Generated at 2022-06-11 19:33:51.322551
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    class TestResolver(Resolver):
        """Test Resolver."""
        def __init__(self, root="root", alias={}, self_ty=""):
            super().__init__(root, alias, self_ty)

        def get_ast(self, ast):
            """Get the AST tree."""
            return self.visit(ast)
    
    rslv = TestResolver(root="root", alias={}, self_ty="")
    assert get_docstring(rslv.get_ast(parse("Union[int, str]").body[0])) ==\
        "Union[int, str]"
    assert get_docstring(rslv.get_ast(parse("List[int]").body[0])) ==\
        "List[int]"

# Generated at 2022-06-11 19:34:03.491841
# Unit test for method visit_Subscript of class Resolver
def test_Resolver_visit_Subscript():
    """Unit test for method visit_Subscript of class Resolver."""
    from .py_info import ClassInfo
    root = "pyslvs"
    alias = {
        f"{root}.examples.{name}": f"{root}.{name}"
        for name in {'visual_cmd', 'project_cmd'}
    }
    path = f"{root}.examples.visual_cmd"
    info = ClassInfo(
        path,
        ModuleType(_m(path)),
        Resolver(path, alias, self_ty="self"),
        Resolver(path, alias)
    )
    x = parse('Union[int, float]').body[0]
    assert unparse(info.resolve.generic_visit(x)) == 'Union[int, float]'