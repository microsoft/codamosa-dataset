

# Generated at 2022-06-20 14:26:01.443580
# Unit test for constructor of class AggregateStats
def test_AggregateStats():

    obj = AggregateStats()
    assert obj.processed == {}
    assert obj.failures == {}
    assert obj.ok == {}
    assert obj.dark == {}
    assert obj.changed == {}
    assert obj.skipped == {}
    assert obj.rescued == {}
    assert obj.ignored == {}
    assert obj.custom == {}


# Generated at 2022-06-20 14:26:16.776057
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    agg_stats = AggregateStats()
    agg_stats.increment("ok", "server1")
    agg_stats.increment("ok", "server1")
    agg_stats.increment("ok", "server1")
    agg_stats.increment("ok", "server2")
    agg_stats.increment("ok", "server2")

    agg_stats.increment("failures", "server1")
    agg_stats.increment("failures", "server2")

    agg_stats.increment("changed", "server1")
    agg_stats.increment("changed", "server2")
    agg_stats.increment("changed", "server2")

    agg_stats.increment("dark", "server2")

    agg_stats.increment("rescued", "server1")

# Generated at 2022-06-20 14:26:22.113210
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats("A", 10)
    assert stats.custom["_run"]["A"] == 10
    stats.update_custom_stats("A", 10)
    assert stats.custom["_run"]["A"] == 20


# Generated at 2022-06-20 14:26:34.376205
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    agst = AggregateStats()
    agst.ok['foo'] = 1
    agst.ok['bar'] = 0
    agst.failures['foo'] = 0
    agst.failures['bar'] = 1
    agst.dark['foo'] = 2
    agst.dark['bar'] = 3
    agst.changed['foo'] = 4
    agst.changed['bar'] = 5
    agst.skipped['foo'] = 6
    agst.skipped['bar'] = 7
    agst.rescued['foo'] = 8
    agst.rescued['bar'] = 9
    agst.ignored['foo'] = 10
    agst.ignored['bar'] = 11


# Generated at 2022-06-20 14:26:44.530958
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    my_test = AggregateStats()
    my_test.increment("ok", "testhost")
    my_test.increment("ok", "testhost")
    my_test.increment("ok", "testhost2")
    my_test.increment("ok", "testhost2")
    assert my_test.ok["testhost"] == 2
    assert my_test.ok["testhost2"] == 2
    my_test.decrement("ok", "testhost")
    assert my_test.ok["testhost"] == 1
    assert my_test.ok["testhost2"] == 2
    my_test.decrement("ok", "testhost")
    assert my_test.ok["testhost"] == 0
    assert my_test.ok["testhost2"] == 2
    # test with non-existent '

# Generated at 2022-06-20 14:26:56.704598
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    '''
    It is importatnt to handle correctly different types in
    the custom stats, like string, integers and dictionaries.
    This method test the existing behavior.
    '''

    # let's create an aggregate object
    stats = AggregateStats()
    # we test different types
    # string
    stats.update_custom_stats('my_string', 'test_value_string')
    assert stats.custom['_run'] == {'my_string': 'test_value_string'}
    # integer - let's add 10
    stats.update_custom_stats('my_int', 10)
    assert stats.custom['_run'] == {'my_int': 10}
    # integer - let's add 10 again
    stats.update_custom_stats('my_int', 10)

# Generated at 2022-06-20 14:27:08.408230
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    from ansible.utils.vars import combine_vars
    stats = AggregateStats()
    stats.increment('ok', 'host')
    stats.increment('ok', 'host')
    stats.set_custom_stats('a', 'b')
    assert stats.custom == {'_run': {'a': 'b'}}
    assert stats.ok == {'host': 2}
    assert stats.ok['host'] == 2
    assert stats.summarize('host') == {'rescued': 0, 'ignored': 0, 'changed': 0, 'failures': 0, 'unreachable': 0, 'skipped': 0, 'ok': 2}
    assert combine_vars({"a": "b", "c": "d"}, {}) == {'a': 'b', 'c': 'd'}
   

# Generated at 2022-06-20 14:27:10.864799
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()

    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}



# Generated at 2022-06-20 14:27:23.385987
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    a = AggregateStats()

    assert a.processed == {}, "processed of class AggregateStats is not empty"
    assert a.failures == {}, "failures of class AggregateStats is not empty"
    assert a.ok == {}, "ok of class AggregateStats is not empty"
    assert a.dark == {}, "dark of class AggregateStats is not empty"
    assert a.changed == {}, "changed of class AggregateStats is not empty"
    assert a.skipped == {}, "skipped of class AggregateStats is not empty"
    assert a.rescued == {}, "rescued of class AggregateStats is not empty"
    assert a.ignored == {}, "ignored of class AggregateStats is not empty"

    a.increment("ok", "host1")
    assert a.processed

# Generated at 2022-06-20 14:27:27.426741
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    ags = AggregateStats()
    assert ags.processed == dict() and ags.ok == dict() and ags.dark == dict() and ags.changed == dict() and ags.skipped == dict() and ags.rescued == dict() and ags.ignored == dict()



# Generated at 2022-06-20 14:27:36.707075
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('skipped', 'host1')
    stats.increment('skipped', 'host1')
    stats.increment('rescued', 'host1')
    stats.increment('ignored', 'host1')
    stats.increment('ignored', 'host1')
    stats.increment('ignored', 'host1')
    stats.increment('rescued', 'host2')
    assert stats.summarize('host1') == dict(
            ok=1,
            failures=0,
            unreachable=0,
            changed=0,
            skipped=2,
            rescued=1,
            ignored=3,
        )

# Generated at 2022-06-20 14:27:47.504844
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'host1')
    aggregate_stats.increment('ok', 'host1')
    aggregate_stats.increment('failures', 'host2')
    aggregate_stats.increment('failures', 'host2')
    aggregate_stats.increment('failures', 'host2')
    assert aggregate_stats.summarize('host1') == {'ok': 2, 'failures': 0, 'skipped': 0, 'changed': 0, 'unreachable': 0, 'rescued': 0, 'ignored': 0}

# Generated at 2022-06-20 14:27:53.902848
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('changed', 'host')
    stats.changed['host'] = 2
    stats.decrement('changed', 'host')
    assert stats.changed['host'] == 1

    # Test negative decrement
    stats.decrement('changed', 'host')
    assert stats.changed['host'] == 0

    # Test negative decrement on empty key
    stats.decrement('changed', 'host')
    assert stats.changed['host'] == 0



# Generated at 2022-06-20 14:27:59.631597
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    summary = stats.summarize('localhost')
    assert summary == dict(ok=1, failures=0, unreachable=0, changed=0, skipped=0, rescued=0, ignored=0)


# Generated at 2022-06-20 14:28:04.396828
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    project_stats = AggregateStats()
    assert project_stats.processed == {}
    assert project_stats.failures == {}
    assert project_stats.ok == {}
    assert project_stats.dark == {}
    assert project_stats.changed == {}
    assert project_stats.skipped == {}
    assert project_stats.rescued == {}
    assert project_stats.ignored == {}
    assert project_stats.custom == {}


# Generated at 2022-06-20 14:28:15.658286
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    agg_stats = AggregateStats()
    agg_stats.update_custom_stats(
        'change_stats',
        {'changed': 0, 'failed': 5, 'ok': 10, 'skipped': 0, 'unreachable': 0},
        host='host1'
    )
    agg_stats.update_custom_stats(
        'change_stats',
        {'changed': 1, 'failed': 0, 'ok': 10, 'skipped': 0, 'unreachable': 0},
        host='host2'
    )
    assert agg_stats.custom['host1']['change_stats'] == {
        'changed': 0, 'failed': 5, 'ok': 10, 'skipped': 0, 'unreachable': 0
    }
    assert agg_stats.custom['host2']['change_stats']

# Generated at 2022-06-20 14:28:22.124946
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-20 14:28:33.128663
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():

    stat = AggregateStats()
    stat.ok['127.0.0.1'] = 1
    stat.failures['127.0.0.1'] = 2
    stat.dark['127.0.0.1'] = 3
    stat.changed['127.0.0.1'] = 4
    stat.skipped['127.0.0.1'] = 5
    stat.rescued['127.0.0.1'] = 6
    stat.ignored['127.0.0.1'] = 7

    results = stat.summarize('127.0.0.1')
    assert results == {'ok': 1, 'failures': 2, 'unreachable': 3, 'changed': 4, 'skipped': 5, 'rescued': 6, 'ignored': 7}

# Generated at 2022-06-20 14:28:37.963433
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    a = AggregateStats()
    a.set_custom_stats('name', 'value')
    assert a.custom == {'_run': {'name': 'value'}}


# Generated at 2022-06-20 14:28:45.509222
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    import ansible.utils.jsonfun as jsonfun

    test_data = dict(
        processed={},
        failures={},
        ok={},
        dark={},
        changed={},
        skipped={},
        rescued={},
        ignored={},
        custom={}
    )
    aggregate_stats = AggregateStats()
    test_data_str = jsonfun.dumps(test_data)
    aggregate_stats_str = jsonfun.dumps(aggregate_stats.__dict__)
    # assert equal of `test_data` and `aggregate_stats`
    assert test_data_str == aggregate_stats_str


# Generated at 2022-06-20 14:28:53.772871
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stat = AggregateStats()

    stat.set_custom_stats('a', {'b': 1})
    stat.set_custom_stats('b', [1])
    stat.set_custom_stats('c', 1, host='foo')
    stat.set_custom_stats('d', 'foo', host='bar')
    assert stat.custom == {
        '_run': {'a': {'b': 1}, 'b': [1]},
        'foo': {'c': 1},
        'bar': {'d': 'foo'},
    }

    # Test merge_hash
    stat.update_custom_stats('a', {'b': 2})

# Generated at 2022-06-20 14:29:04.012798
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.module_utils.basic import AnsibleModule
    dut = AggregateStats()

    # Test when either the custom stat or host does not exist
    dut.update_custom_stats(which='foo', what='bar', host='baz')
    assert dut.custom['baz']['foo'] == 'bar'
    dut.update_custom_stats(which='foo', what='bar')
    assert dut.custom['_run']['foo'] == 'bar'

    # Test with a dict and MergedHash
    dut = AggregateStats()
    dut.custom['baz'] = {'foo': {'bar': 'baz'}}
    dut.update_custom_stats(which='foo', what={'bar': 'qux'}, host='baz')
    assert dut.custom

# Generated at 2022-06-20 14:29:14.830720
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    host = "host.localdomain"

    # Test set custom stats for a host
    aggregate_stats.set_custom_stats("new_field_with_bool", True, host)
    aggregate_stats.set_custom_stats("new_field_with_int", 10, host)
    aggregate_stats.set_custom_stats("new_field_with_str", "hello", host)
    assert(aggregate_stats.custom[host]["new_field_with_bool"] is True)
    assert(aggregate_stats.custom[host]["new_field_with_int"] == 10)
    assert(aggregate_stats.custom[host]["new_field_with_str"] == "hello")
    assert(len(aggregate_stats.custom[host]) == 3)



# Generated at 2022-06-20 14:29:21.508225
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')

    stats.increment('changed', 'host1')
    stats.increment('changed', 'host2')

    stats.increment('failures', 'host3')
    stats.increment('failures', 'host3')
    stats.increment('failures', 'host3')


# Generated at 2022-06-20 14:29:32.186365
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ags1 = AggregateStats()
    host = 'localhost'
    ags1.failures[host] = 0
    ags1.decrement('failures', host)
    assert ags1.failures == {host : 0}
    ags1.failures[host] = 3
    ags1.decrement('failures', host)
    assert ags1.failures == {host : 2}
    ags1.failures[host] = 1
    ags1.decrement('failures', host)
    assert ags1.failures == {host : 0}



# Generated at 2022-06-20 14:29:39.870912
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('item1', 'value1')
    assert stats.custom['_run']['item1'] == 'value1'
    stats.set_custom_stats('item2', 'value2')
    assert stats.custom['_run']['item2'] == 'value2'
    stats.set_custom_stats('item3', 'value3', 'host1')
    assert stats.custom['host1']['item3'] == 'value3'
    stats.set_custom_stats('item4', 'value4', 'host1')
    assert stats.custom['host1']['item4'] == 'value4'
    stats.set_custom_stats('item5', 'value5', 'host2')
    assert stats.custom['host2']['item5']

# Generated at 2022-06-20 14:29:46.159828
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    ag = AggregateStats()
    assert (ag.processed == {})
    assert (ag.failures == {})
    assert (ag.ok == {})
    assert (ag.dark == {})
    assert (ag.changed == {})
    assert (ag.skipped == {})
    assert (ag.rescued == {})
    assert (ag.ignored == {})
    assert (ag.custom == {})
    return True


# Generated at 2022-06-20 14:29:57.116829
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok['host1'] = 9
    stats.failures['host1'] = 1
    stats.dark['host1'] = 10
    stats.changed['host1'] = 11
    stats.skipped['host1'] = 13
    stats.rescued['host1'] = 14
    stats.ignored['host1'] = 15
    assert stats.summarize('host1') == {'ok': 9, 'failures': 1, 'changed': 11,
                                        'unreachable': 10, 'rescued': 14,
                                        'skipped': 13, 'ignored': 15}

# Generated at 2022-06-20 14:30:09.317905
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    a = AggregateStats()
    assert a.custom == {}
    a.set_custom_stats('custom_stats', 'value', '_run')
    assert a.custom == {'_run': {'custom_stats': 'value'}}
    a.custom == {}
    a.set_custom_stats('custom_stats', 'value')
    assert a.custom == {'_run': {'custom_stats': 'value'}}
    a.custom == {}
    a.set_custom_stats('custom_stats', 42, '_run')
    assert a.custom == {'_run': {'custom_stats': 42}}
    a.custom == {}
    a.set_custom_stats('custom_stats', 42)
    assert a.custom == {'_run': {'custom_stats': 42}}

# Unit test

# Generated at 2022-06-20 14:30:14.665786
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    print("AggregateStats: test_AggregateStats_decrement")
    stats = AggregateStats()
    stats.increment("failures", "test_host")
    stats.increment("failures", "test_host")
    stats.decrement("failures", "test_host")
    assert stats.failures["test_host"] == 1

# Generated at 2022-06-20 14:30:27.144781
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('foo', 'bar')
    assert stats.custom == { '_run': { 'foo': 'bar' } }
    assert stats.custom['_run']['foo'] == 'bar'
    stats.set_custom_stats('foo', 'baz', '42.42.42.42')
    assert stats.custom == { '_run': { 'foo': 'bar' }, '42.42.42.42': { 'foo': 'baz' } }
    assert stats.custom['_run']['foo'] == 'bar'
    assert stats.custom['42.42.42.42']['foo'] == 'baz'


# Generated at 2022-06-20 14:30:32.634859
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ''' make sure method decrement works as expected '''

    a = AggregateStats()
    a.increment('failures', 'test_host')
    a.increment('failures', 'test_host')
    # This should not modify a.failures
    a.decrement('failures', 'test_host')
    # This should modify a.failures
    a.decrement('failures', 'test_host')
    # This should not modify a.failures
    a.decrement('failures', 'test_host')

    assert len(a.failures) == 1 and a.failures['test_host'] == 0

# Generated at 2022-06-20 14:30:38.712153
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    astat = AggregateStats()
    astat.increment('ok', 'testhost')
    astat.increment('ok', 'testhost')
    astat.increment('ignored', 'testhost')
    astat.increment('ignored', 'testhost')
    assert astat.ok['testhost'] == 2
    assert astat.ignored['testhost'] == 2

    astat.decrement('ok', 'testhost')
    astat.decrement('ignored', 'testhost')
    astat.decrement('ignored', 'testhost')
    astat.decrement('ignored', 'testhost')
    assert astat.ok['testhost'] == 1
    assert astat.ignored['testhost'] == 0


# Generated at 2022-06-20 14:30:44.989935
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg_stats = AggregateStats()
    assert agg_stats.ok == {}
    assert agg_stats.custom == {}
    assert agg_stats.processed == {}
    assert agg_stats.failures == {}
    assert agg_stats.dark == {}
    assert agg_stats.changed == {}
    assert agg_stats.skipped == {}
    assert agg_stats.rescued == {}
    assert agg_stats.ignored == {}


# Generated at 2022-06-20 14:30:48.931228
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_obj = AggregateStats()

    aggregate_stats_obj.increment("ok", "host")
    assert aggregate_stats_obj.ok['host'] == 1



# Generated at 2022-06-20 14:30:50.906604
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ag = AggregateStats()
    ag.increment('dark', 'example.com')
    if ag.dark['example.com'] != 1:
        return False
    ag.decrement('dark', 'example.com')
    if 0 not in ag.dark.values():
        return False
    return True

# Generated at 2022-06-20 14:30:54.791349
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregatestats = AggregateStats()
    host = "host1"
    what = "ok"
    aggregatestats.increment(what, host)
    assert aggregatestats.ok[host] == 1



# Generated at 2022-06-20 14:31:00.282181
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    s = AggregateStats()
    s.increment('ok', 'test_host')
    s.increment('ok', 'test_host')
    s.increment('ok', 'test_host')
    s.decrement('ok', 'test_host')

    assert(s.ok['test_host'] == 2)


# Generated at 2022-06-20 14:31:06.455816
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    c = AggregateStats()
    assert c.processed == {}
    assert c.custom == {}
    assert c.failures == {}
    assert c.dark == {}
    assert c.changed == {}
    assert c.skipped == {}
    assert c.ignored == {}
    assert c.rescued == {}
    assert c.ok == {}


# Generated at 2022-06-20 14:31:21.533419
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'server1')
    stats.increment('ok', 'server1')
    stats.increment('ok', 'server2')
    stats.increment('failures', 'server2')
    stats.increment('dark', 'server1')

    summary = stats.summarize(host='server1')
    assert summary['ok'] == 2
    assert summary['failures'] == 0
    assert summary['unreachable'] == 1

    summary = stats.summarize(host='server2')
    assert summary['ok'] == 1
    assert summary['failures'] == 1
    assert summary['unreachable'] == 0

    summary = stats.summarize(host='not server')
    assert summary['ok'] == 0
    assert summary['failures'] == 0
   

# Generated at 2022-06-20 14:31:32.781254
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import random
    import string
    import copy
    import types

    # pick a random string for a reference
    new_stats = ''.join([random.choice(string.ascii_letters + string.digits) for n in xrange(32)])

    # test all the custom stats types
    test_stats = [
        '_run',
        new_stats
    ]

    test_stats_to_add = [
        100,
        '100',
        {'test': new_stats},
        {0: [new_stats]},
        [new_stats]
    ]

    test_types = [
        types.IntType,
        types.StringType,
        types.DictType,
        types.ListType
    ]

    aggregate_stats = AggregateStats()

    # Initialize all the custom stats

# Generated at 2022-06-20 14:31:35.309975
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("ok", "client1")
    assert stats.ok["client1"] == 1
    assert stats.processed["client1"] == 1


# Generated at 2022-06-20 14:31:47.484891
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
     # Create an object AggregateStats
    stats = AggregateStats()

    # Create dictionaries for the ok, dark, and changed attributes of object
    stats.ok = {'somehost': 1}
    stats.dark = {'somehost': 2}
    stats.changed = {'somehost': 3}
    stats.skipped = {'somehost': 4}
    stats.rescued = {'somehost': 5}
    stats.ignored = {'somehost': 6}

    # Call the method we're testing
    result = stats.summarize('somehost')

    # Assert that the result is a dictionary
    assert isinstance(result, dict)

    # Assert that the dictionary has the expected keys

# Generated at 2022-06-20 14:31:53.090809
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ansible_stats = AggregateStats()
    ansible_stats.ok['testhost'] = 5
    assert ansible_stats.ok['testhost'] == 5
    ansible_stats.decrement('ok', 'testhost')
    assert ansible_stats.ok['testhost'] == 4

# Generated at 2022-06-20 14:32:02.945801
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    # create host-wide custom stats
    host = 'localhost'
    host_custom = {
        host: {
            'custom_stats': {
                'foo': 1,
                'bar': 1,
                'baz': 1,
            },
        },
    }

    # create run-wide custom stats
    run_custom = {
        '_run': {
            'custom_stats': {
                'foo': 2,
                'bar': 2,
                'baz': 2,
            },
        },
    }

    # create stats object
    stats = AggregateStats()

    # set custom stats
    stats.custom = host_custom

    # update custom stats (builtin type)
    stats.update_custom_stats('baz', 1)

# Generated at 2022-06-20 14:32:12.132705
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    stats.update_custom_stats('abc', {'a': 1, 'b': 2, 'c': 3})
    assert stats.custom['_run'] == {'abc': {'a': 1, 'b': 2, 'c': 3}}

    stats.update_custom_stats('abc', {'a': 2, 'b': 4, 'c': 6})
    assert stats.custom['_run'] == {'abc': {'a': 3, 'b': 6, 'c': 9}}

    stats.update_custom_stats('abc', {'a': 2, 'c': 6}, host='host1')
    assert stats.custom['_run'] == {'abc': {'a': 3, 'b': 6, 'c': 9}}

# Generated at 2022-06-20 14:32:17.035173
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("ok", "localhost")
    assert stats.ok['localhost'] == 1
    assert stats.ok['localhost'] == 1
    stats.increment("ok", "localhost")
    assert stats.ok['localhost'] == 2


# Generated at 2022-06-20 14:32:22.046208
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    result = aggregate_stats.summarize("one")

    assert type(result) == dict
    assert result["ok"] == 0
    assert result["failures"] == 0
    assert result["unreachable"] == 0
    assert result["changed"] == 0
    assert result["skipped"] == 0
    assert result["rescued"] == 0
    assert result["ignored"] == 0


# Generated at 2022-06-20 14:32:25.990037
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    global_result = AggregateStats()
    global_result.increment("ok", "127.0.0.1")
    assert global_result.ok["127.0.0.1"] == 1
    assert global_result.processed["127.0.0.1"] == 1


# Generated at 2022-06-20 14:32:39.303962
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    '''
    Unit test for method set_custom_stats of class AggregateStats
    '''
    class AggregateStats_1(AggregateStats):
        '''
        key-value object with interface similar to dict
        '''
        def __init__(self):
            super(AggregateStats_1, self).__init__()

        def __getitem__(self, key):
            return self.__dict__[key]

        def __setitem__(self, key, val):
            self.__dict__[key] = val

        def __contains__(self, key):
            return key in self.__dict__

        def __delitem__(self, key):
            del self.__dict__[key]

    ast = AggregateStats_1()