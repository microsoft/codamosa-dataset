

# Generated at 2022-06-20 14:25:55.827868
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggstat = AggregateStats()
    assert aggstat.__class__.__name__ == 'AggregateStats'
    assert aggstat.processed == {}
    assert aggstat.failures == {}
    assert aggstat.ok == {}
    assert aggstat.dark == {}
    assert aggstat.changed == {}
    assert aggstat.skipped == {}
    assert aggstat.rescued == {}
    assert aggstat.ignored == {}
    assert aggstat.custom == {}


# Generated at 2022-06-20 14:26:00.115854
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("ok", "host1")
    stats.increment("ok", "host2")
    stats.increment("ok", "host1")
    assert stats.ok["host1"] == 2
    assert stats.ok["host2"] == 1


# Generated at 2022-06-20 14:26:09.519106
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 'bar', 'host')
    assert stats.custom['host']['foo'] == 'bar'
    stats.update_custom_stats('foo', {'a': 1, 'b': 2}, 'host')
    assert stats.custom['host']['foo'] == {'a': 1, 'b': 2}
    stats.update_custom_stats('foo', {'c': 3}, 'host')
    assert stats.custom['host']['foo'] == {'a': 1, 'b': 2, 'c': 3}
    stats.update_custom_stats('foo', 'bar', 'host')
    assert stats.custom['host']['foo'] == 'bar'
    stats.update_custom_stats('foo', [1], 'host')
   

# Generated at 2022-06-20 14:26:22.403699
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    a = AggregateStats()

    a.increment('failures', 'myhost')
    assert a.failures['myhost'] == 1
    a.increment('failures', 'myhost')
    assert a.failures['myhost'] == 2

    a.increment('ok', 'myhost')
    assert a.ok['myhost'] == 1
    a.increment('ok', 'myhost')
    assert a.ok['myhost'] == 2

    a.increment('dark', 'myhost')
    assert a.dark['myhost'] == 1
    a.increment('dark', 'myhost')
    assert a.dark['myhost'] == 2

    a.increment('changed', 'myhost')
    assert a.changed['myhost'] == 1
    a.increment('changed', 'myhost')

# Generated at 2022-06-20 14:26:34.406433
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    # make sure we don't have any leftovers from prior runs
    import os
    os.system("rm -rf data")
    os.system("mkdir data")
    cmd = "ansible-playbook -i ./data/local site.yml"
    os.system(cmd)

    expected_ok = {'127.0.0.1': 1}
    expected_changed = {'127.0.0.1': 0}
    expected_failures = {'127.0.0.1': 0}
    expected_dark = {'127.0.0.1': 0}
    expected_skipped = {'127.0.0.1': 0}
    expected_rescued = {'127.0.0.1': 0}
    expected_ignored = {'127.0.0.1': 0}

# Generated at 2022-06-20 14:26:42.931636
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    test_object = AggregateStats()
    test_object.update_custom_stats('what', {'is': 'this'}, 'host')
    assert test_object.custom == {'host': {'what': {'is': 'this'}}}
    test_object.update_custom_stats('what', 'that', 'host')
    assert test_object.custom == {'host': {'what': {'is': 'this'}}}
    test_object.update_custom_stats('what', {'is': 'that'}, 'host')
    assert test_object.custom == {'host': {'what': {'is': 'that'}}}

# Generated at 2022-06-20 14:26:50.572738
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    ag = AggregateStats()
    ag.increment('ok', '127.0.0.1')
    ag.increment('ok', '127.0.0.1')
    ag.increment('changed', '127.0.0.1')
    ag.increment('failures', '127.0.0.1')
    ag.increment('failures', '127.0.0.1')
    ag.increment('dark', '127.0.0.1')
    ag.increment('skipped', '127.0.0.1')
    ag.set_custom_stats('checksum_changed', True, '127.0.0.1')
    ag.set_custom_stats('checksum_changed', False, '127.0.0.2')

# Generated at 2022-06-20 14:27:02.575805
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.processed = {'host1':1}
    stats.ok = {'host1':2}
    stats.failures = {'host1':3}
    stats.dark = {'host1':4}
    stats.changed = {'host1':5}
    stats.skipped = {'host1':6}
    stats.rescued = {'host1':7}
    stats.ignored = {'host1':8}

    assert stats.summarize('host1') == dict(
        ok=2,
        failures=3,
        unreachable=4,
        changed=5,
        skipped=6,
        rescued=7,
        ignored=8,
    )


# Generated at 2022-06-20 14:27:15.088423
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.playbook.play_context import PlayContext

    context = PlayContext()
    context._ansible_no_log = True

    sut = AggregateStats()

    # test for a simple item
    sut.set_custom_stats('item', 10)
    sut.update_custom_stats('item', 2)
    assert sut.custom['_run']['item'] == 12

    # test for a sum of a list
    sut.set_custom_stats('list', [1,2,3,4])
    sut.update_custom_stats('list', [2,2,2,2])
    assert sut.custom['_run']['list'] == [3,4,5,6]

    # test for a sum of a dict

# Generated at 2022-06-20 14:27:23.348986
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    # built-in stats initialization
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    # custom stats initialization
    assert stats.custom == {}


# Generated at 2022-06-20 14:27:30.612545
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    import pytest
    stats = AggregateStats()
    stats.increment('failures', 'test_host')
    stats.decrement('failures', 'test_host')
    assert stats.failures['test_host'] == 0
    with pytest.raises(KeyError):
        stats.decrement('failures', 'test_host')
    assert stats.failures == {}

# Generated at 2022-06-20 14:27:36.332269
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate = AggregateStats()
    assert aggregate.processed == {}
    assert aggregate.failures == {}
    assert aggregate.ok == {}
    assert aggregate.dark == {}
    assert aggregate.changed == {}
    assert aggregate.skipped == {}
    assert aggregate.rescued == {}
    assert aggregate.ignored == {}
    assert aggregate.custom == {}



# Generated at 2022-06-20 14:27:44.187041
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    d = dict(
        ok=2,
        failures=4,
        unreachable=6,
        changed=8,
        skipped=10,
        rescued=12,
        ignored=14,
    )
    stats = AggregateStats()
    stats.update_custom_stats('custom', d)
    #print stats.custom
    assert stats.custom['_run']['custom']['ok'] == 2
    assert stats.custom['_run']['custom']['failures'] == 4
    assert stats.custom['_run']['custom']['unreachable'] == 6
    assert stats.custom['_run']['custom']['changed'] == 8
    assert stats.custom['_run']['custom']['skipped'] == 10

# Generated at 2022-06-20 14:27:55.000214
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    for h in [ 'localhost', '192.168.1.1' ]:
        for s in [ 'ok', 'dark', 'changed', 'failed', 'skipped', 'rescue', 'ignored' ]:
            stats.increment(s, h)
    stats.set_custom_stats( 'tests', 2, h )
    assert stats.custom == { '192.168.1.1': { 'tests': 2 }, '_run': {}, 'localhost': { 'tests': 2 } }
    assert stats.ok == { '192.168.1.1': 1, 'localhost': 1 }
    assert stats.failures == { '192.168.1.1': 1, 'localhost': 1 }

# Generated at 2022-06-20 14:28:02.852723
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'test_host')
    stats.increment('ok', 'test_host')
    print('Before decrement:', stats.ok['test_host'])
    stats.decrement('ok', 'test_host')
    print('After decrement:', stats.ok['test_host'])
    assert stats.ok['test_host'] != 2
    assert stats.ok['test_host'] == 1


# Generated at 2022-06-20 14:28:07.720282
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    ag = AggregateStats()
    ag.set_custom_stats('a', 1)
    ag.set_custom_stats('b', 2, 'host')
    assert ag.custom == {'_run': {'a': 1}, 'host': {'b': 2}}


# Generated at 2022-06-20 14:28:16.536256
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    stats = AggregateStats()

    stats.ok["node"] = 3
    assert stats.ok["node"] == 3

    stats.decrement("ok", "node")
    assert stats.ok["node"] == 2

    stats.decrement("ok", "node")
    assert stats.ok["node"] == 1

    stats.decrement("ok", "node")
    assert stats.ok["node"] == 0

    stats.decrement("ok", "node")
    assert stats.ok["node"] == 0



# Generated at 2022-06-20 14:28:21.553257
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'server1')
    aggregate_stats.increment('ok', 'server2')

    assert aggregate_stats.ok['server1'] == 1
    assert aggregate_stats.ok['server2'] == 1

# Generated at 2022-06-20 14:28:29.605475
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg_stat = AggregateStats()
    agg_stat.set_custom_stats('test_key','test_value','test_host')
    assert agg_stat.custom == {'test_host': {'test_key': 'test_value'}}
    agg_stat.set_custom_stats('test_key','test_value')
    assert agg_stat.custom == {'test_host': {'test_key': 'test_value'}, '_run': {'test_key': 'test_value'}}
    agg_stat.set_custom_stats('test_key','test_value1','test_host')
    assert agg_stat.custom == {'test_host': {'test_key': 'test_value1'}, '_run': {'test_key': 'test_value'}}


# Generated at 2022-06-20 14:28:38.943433
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    a = AggregateStats()
    a.set_custom_stats('n', 10)
    assert 10 == a.custom['_run']['n']
    assert a.custom['_run']['n'] is not None

    a = AggregateStats()
    a.set_custom_stats('n', 10, 'a')
    assert 10 == a.custom['a']['n']
    assert a.custom['a']['n'] is not None
