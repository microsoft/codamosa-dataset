

# Generated at 2022-06-20 14:26:04.007079
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    # Initialize
    agg = AggregateStats()
    agg.ok = {'host1': 2, 'host2': 1, 'host3': 3}
    agg.failures = {'host1': 1, 'host3': 4}
    agg.dark = {'host1': 5}
    agg.changed = {'host2': 3}
    agg.skipped = {'host2': 2}
    agg.rescued = {'host3': 1}
    agg.ignored = {'host3': 2}
    # Verify
    assert agg.summarize('host1') == {'ok':2, 'failures': 1, 'unreachable': 5, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}

# Generated at 2022-06-20 14:26:09.257492
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.processed == {}
    assert aggregate_stats.failures == {}
    assert aggregate_stats.ok == {}
    assert aggregate_stats.dark == {}
    assert aggregate_stats.changed == {}
    assert aggregate_stats.skipped == {}
    assert aggregate_stats.rescued == {}
    assert aggregate_stats.ignored == {}
    assert aggregate_stats.custom == {}


# Generated at 2022-06-20 14:26:22.198482
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    hostname = '127.0.0.1'
    stats = AggregateStats()
    # Set failed task
    stats.increment('failures', hostname)
    # Set unreachable host
    stats.increment('dark', hostname)
    # Set a ok task
    stats.increment('ok', hostname)
    # Set a changed task
    stats.increment('changed', hostname)
    # Set a skipped task
    stats.increment('skipped', hostname)
    # Set a rescued task
    stats.increment('rescued', hostname)
    # Set a ignored task
    stats.increment('ignored', hostname)

    # Check the statistics

# Generated at 2022-06-20 14:26:34.376550
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Init the instance of class AggregateStats
    agg_stats = AggregateStats()
    which = "custom_stats"
    host = '_run'
    what = {'update': 1}

    agg_stats.update_custom_stats(which, what, host)
    # Test if the method update_custom_stats updates the custom stats
    assert agg_stats.custom[host][which]['update'] == 1

    agg_stats.update_custom_stats(which, what, host)
    # Test if the method update_custom_stats updates the custom stats after second call
    assert agg_stats.custom[host][which]['update'] == 2

    wrong_what = "1"
    agg_stats.update_custom_stats(which, wrong_what, host)
    # Test if the method update_custom_stats doesn't update the

# Generated at 2022-06-20 14:26:42.885126
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    ''' test the AggregateStats.update_custom_stat method '''

    assert AggregateStats
    stats = AggregateStats()

    stats.update_custom_stats('foo', 4, 'host1')
    assert stats.custom == {'host1': {'foo': 4}}

    stats.update_custom_stats('foo', 5, 'host1')
    assert stats.custom == {'host1': {'foo': 9}}

    stats.update_custom_stats('foo', 7, 'host2')
    assert stats.custom == {'host1': {'foo': 9}, 'host2': {'foo': 7}}

    # mimic play custom stat

# Generated at 2022-06-20 14:26:46.731315
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    test_obj = AggregateStats()
    test_obj.increment('ok', 'test_host')
    assert test_obj.processed['test_host'] == 1
    assert test_obj.ok['test_host'] == 1
    test_obj.increment('ok', 'test_host')
    assert test_obj.processed['test_host'] == 1
    assert test_obj.ok['test_host'] == 2


# Generated at 2022-06-20 14:26:51.848724
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    """
    Given no custom stats
    When I set a custom stat without specifying host
    Then I should get the custom stat with key '_run'
    """
    stats = AggregateStats()
    stats.set_custom_stats('the_custom_key', 'the_custom_value')
    assert stats.custom == {'_run': {'the_custom_key': 'the_custom_value'}}



# Generated at 2022-06-20 14:27:03.995290
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate = AggregateStats()
    aggregate.update_custom_stats('custom_bool', True)
    assert aggregate.custom['_run']['custom_bool'] is True

    aggregate.update_custom_stats('custom_bool', False)
    assert aggregate.custom['_run']['custom_bool'] is False

    aggregate.update_custom_stats('custom_dict', {"k1": 1})
    assert aggregate.custom['_run']['custom_dict'] == {"k1": 1}

    aggregate.update_custom_stats('custom_dict', {"k2": 2})
    assert aggregate.custom['_run']['custom_dict'] == {"k1": 1, "k2": 2}

    aggregate.update_custom_stats('custom_int', 1)
    assert aggregate.custom['_run']['custom_int']

# Generated at 2022-06-20 14:27:08.440161
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('test', {'test_key': 'test_value'}, '_run')
    assert stats.custom['_run']['test']['test_key'] == 'test_value'


# Generated at 2022-06-20 14:27:13.286838
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.processed.get('localhost', 0) == 1
    assert stats.ok.get('localhost', 0) == 1
    stats.increment('ok', 'localhost')
    assert stats.processed.get('localhost', 0) == 1
    assert stats.ok.get('localhost', 0) == 2
    stats.decrement('ok', 'localhost')
    assert stats.processed.get('localhost', 0) == 1
    assert stats.ok.get('localhost', 0) == 1
    stats.increment('ok', 'remotehost')
    assert stats.processed.get('remotehost', 0) == 1
    assert stats.ok.get('remotehost', 0) == 1

    assert len(stats.summarize('localhost')) == 7

# Generated at 2022-06-20 14:27:19.500599
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():

    obj = AggregateStats()
    obj.increment('ok', '127.0.0.1')
    obj.increment('failures', '127.0.0.1')
    obj.increment('unreachable', '127.0.0.1')
    obj.increment('changed', '127.0.0.1')
    obj.increment('skipped', '127.0.0.1')
    obj.increment('rescued', '127.0.0.1')
    obj.increment('ignored', '127.0.0.1')

    obj.increment('ok', '192.168.1.1')
    obj.increment('failures', '192.168.1.1')
    obj.increment('unreachable', '192.168.1.1')
   

# Generated at 2022-06-20 14:27:25.559544
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    class obj_(object):
        """docstring for obj_"""
        def __init__(self, arg):
            self.arg = arg
    class obj_dict(object):
        """docstring for obj_dict"""
        def __init__(self, arg):
            self.arg = arg

        def __getitem__(self, key):
            return self.arg[key]

        def __setitem__(self, key, val):
            self.arg[key] = val

        def copy(self):
            return obj_dict(self.arg)

    class obj_obj(object):
        """docstring for obj_obj"""
        def __init__(self, arg):
            self.arg = arg


    # Testing obj
    test = AggregateStats()

# Generated at 2022-06-20 14:27:36.757776
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.module_utils.common._collections_compat import MutableMapping

    class FakeDict(MutableMapping):
        '''Fake object for unit tests'''
        def __init__(self):
            self.store = {}

        def __getitem__(self, key):
            return self.store[key]

        def __setitem__(self, key, value):
            self.store[key] = value

        def __delitem__(self, key):
            del self.store[key]

        def __iter__(self):
            return iter(self.store)

        def __len__(self):
            return len(self.store)

    ags = AggregateStats()

    ags.update_custom_stats('success', True)

# Generated at 2022-06-20 14:27:46.443018
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggr_stats=AggregateStats()
    host = 'HOST'
    what = {'ok':1,'failures':2,'unreachable':3,'changed':4,'skipped':5,'rescued':6,'ignored':7}

    for key in what.keys():
        setattr(aggr_stats, key, {host: what[key]})
    ret_stat = aggr_stats.summarize(host)
    for key in what.keys():
        assert ret_stat[key] == what[key]

# Generated at 2022-06-20 14:27:56.727422
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()

    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('failures', 'host2')
    stats.increment('ok', 'host3')

    ret = stats.summarize('host1')
    assert ret == dict(
        ok=3,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0
    ), "Failed to summarize host1 stats"

    ret = stats.summarize('host2')

# Generated at 2022-06-20 14:28:08.018430
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    
    # Create an instance of AggregateStats
    aggregate_stats = AggregateStats()

    # Set values for the instance
    aggregate_stats.processed = {'192.168.0.5': 1, '192.168.0.15': 1}
    aggregate_stats.failures = {'192.168.0.5': 1, '192.168.0.15': 0}
    aggregate_stats.ok = {'192.168.0.5': 0, '192.168.0.15': 1}
    aggregate_stats.dark = {'192.168.0.5': 0, '192.168.0.15': 0}
    aggregate_stats.changed = {'192.168.0.5': 0, '192.168.0.15': 0}

# Generated at 2022-06-20 14:28:17.044221
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg_stats = AggregateStats()
    agg_stats.increment("ok", "localhost")
    agg_stats.increment("ok", "localhost")
    agg_stats.increment("ok", "localhost")
    assert agg_stats.ok["localhost"] == 3
    agg_stats.decrement("ok", "localhost")
    assert agg_stats.ok["localhost"] == 2
    agg_stats.decrement("ok", "localhost")
    assert agg_stats.ok["localhost"] == 1
    agg_stats.decrement("ok", "localhost")
    assert agg_stats.ok["localhost"] == 0

# Generated at 2022-06-20 14:28:23.792280
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats("custom", "set")
    assert aggregate_stats.custom["_run"] == { "custom" : "set" }
    aggregate_stats.set_custom_stats("custom", "set", "some_host")
    assert aggregate_stats.custom["some_host"] == { "custom" : "set" }


# Generated at 2022-06-20 14:28:30.418346
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg = AggregateStats()
    assert agg.processed == {}
    assert agg.failures == {}
    assert agg.ok == {}
    assert agg.dark == {}
    assert agg.changed == {}
    assert agg.skipped == {}
    assert agg.rescued == {}
    assert agg.ignored == {}
    assert agg.custom == {}


# Generated at 2022-06-20 14:28:39.435753
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggStats = AggregateStats()
    aggStats.set_custom_stats('some_key', 'some_value')
    assert aggStats.custom['_run'] == {'some_key': 'some_value'}
    assert aggStats.custom['_run'] != {'some_key': 'another_value'}
    aggStats.set_custom_stats('some_key', 'some_value', 'my_host')
    assert aggStats.custom['my_host'] == {'some_key': 'some_value'}



# Generated at 2022-06-20 14:28:47.486734
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg = AggregateStats()

    agg.increment("ok", "host1")
    assert agg.ok['host1'] == 1

    agg.increment("ok", "host1")
    assert agg.ok['host1'] == 2

    agg.increment("ok", "host2")
    assert agg.ok['host2'] == 1

    agg.increment("changed", "host1")
    assert agg.changed['host1'] == 1


# Generated at 2022-06-20 14:28:50.139731
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregatestats = AggregateStats()
    assert aggregatestats is not None

# Generated at 2022-06-20 14:28:57.534222
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    # Create a new instance of AggregateStats
    stats = AggregateStats()

    # Use the helper function to bump a statistic
    stats.increment("ok", "10.20.30.40")

    # Check if the value has been incremented
    assert stats.ok == {"10.20.30.40": 1}

    # Check if processed has been incremented
    assert stats.processed == {"10.20.30.40": 1}


# Generated at 2022-06-20 14:29:03.300664
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()
    assert isinstance(aggregate_stats, AggregateStats)
    assert isinstance(aggregate_stats.custom, dict)
    assert isinstance(aggregate_stats.failures, dict)
    assert isinstance(aggregate_stats.ok, dict)
    assert isinstance(aggregate_stats.dark, dict)
    assert isinstance(aggregate_stats.changed, dict)
    assert isinstance(aggregate_stats.skipped, dict)
    assert isinstance(aggregate_stats.rescued, dict)
    assert isinstance(aggregate_stats.ignored, dict)
    assert isinstance(aggregate_stats.processed, dict)


# Generated at 2022-06-20 14:29:10.598459
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    host = 'test_host'
    stats = AggregateStats()
    stats.update_custom_stats('test_key', 1, host)
    assert host in stats.custom
    assert 'test_key' in stats.custom[host]
    assert stats.custom[host]['test_key'] == 1


# Generated at 2022-06-20 14:29:19.746226
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ag = AggregateStats()

    # Case: No entry in the requested data store
    ag.decrement('ok', 'test1')

    assert ag.ok['test1'] == 0

    # Case: Decrementing on an entry that has been incremented once
    ag.increment('ok', 'test1')
    ag.decrement('ok', 'test1')

    assert ag.ok['test1'] == 0

    # Case: Decrementing on an entry that has been incremented twice
    ag.increment('ok', 'test1')
    ag.increment('ok', 'test1')
    ag.decrement('ok', 'test1')

    assert ag.ok['test1'] == 1

    # Case: Decrementing on an entry that has been incremented twice,
    #       and then decremented once
   

# Generated at 2022-06-20 14:29:25.428086
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    '''
    Update custom stats should merge a dictionary in the existing dictionary
    '''

    stats = AggregateStats()
    stats.update_custom_stats('custom', {'aaa': 'foo'})
    assert stats.custom['_run']['custom'] == {'aaa': 'foo'}
    stats.update_custom_stats('custom', {'bbb': 'bar'})
    assert stats.custom['_run']['custom'] == {'aaa': 'foo', 'bbb': 'bar'}

    # this should fail since 'custom' has been defined with a dict and then we
    # try to set it with a list. The type change is not allowed
    stats.update_custom_stats('custom', ['bar'])

# Generated at 2022-06-20 14:29:29.719492
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    from ansible.module_utils.six import PY3
    if PY3:
        from unittest import mock
    else:
        import mock
    n = 'ansible.module_utils.stats.AggregateStats'
    with mock.patch(n + '.__getattr__') as mock_getattr:
        stats = AggregateStats()
        stats.decrement(what='some', host='some2')
        mock_getattr.assert_called_once_with('some')

# Generated at 2022-06-20 14:29:37.010416
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    as1 = AggregateStats()
    assert "ok" in as1.summarize("host1")
    assert "failures" in as1.summarize("host1")
    assert "unreachable" in as1.summarize("host1")
    assert "changed" in as1.summarize("host1")
    assert "skipped" in as1.summarize("host1")
    assert "rescued" in as1.summarize("host1")
    assert "ignored" in as1.summarize("host1")

# Generated at 2022-06-20 14:29:47.055907
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    import random
    stats = AggregateStats()
    host = 'test_host'
    stats.increment('ok', host)
    stats.increment('ok', host)
    stats.increment('ok', host)
    stats.increment('ok', host)
    stats.increment('ok', host)
    stats.increment('ok', host)
    stats.increment('ok', host)
    stats.increment('ok', host)
    stats.increment('ok', host)
    stats.increment('ok', host)

    for i in range(0, random.randint(1, 10)):
        stats.decrement('ok', host)

    assert stats.ok[host] == 5, "Tested: {0}, Expected: 5".format(stats.ok[host])



# Generated at 2022-06-20 14:29:55.401439
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('rescued', 'host')
    stats.decrement('rescued', 'host')
    assert stats.rescued['host'] == 0



# Generated at 2022-06-20 14:29:59.872864
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('foo', 'bar')
    assert stats.custom == {'_run': {'foo': 'bar'}}
    stats.set_custom_stats('foo', 'bar', 'baz')
    assert stats.custom == {'_run': {'foo': 'bar'}, 'baz': {'foo': 'bar'}}


# Generated at 2022-06-20 14:30:02.734950
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    result = stats.increment('ok', 'test_host')
    assert stats.ok['test_host'] == 1

    assert result is None


# Generated at 2022-06-20 14:30:10.173079
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    stats.increment('failures', 'ok')
    stats.increment('failures', 'ok')
    stats.increment('failures', 'ok')
    stats.increment('ok', 'ok')
    stats.increment('ok', 'ok')
    stats.increment('dark', 'ok')
    stats.increment('changed', 'ok')
    stats.increment('changed', 'ok')
    stats.increment('changed', 'ok')
    stats.increment('changed', 'ok')
    stats.increment('skipped', 'ok')
    stats.increment('rescued', 'ok')
    stats.increment('ignored', 'ok')

    assert stats.processed == {'ok':1}
    assert stats.failures == {'ok':3}


# Generated at 2022-06-20 14:30:16.325884
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    """ test set_custom_stats method of AggregateStats class """
    agg_stats = AggregateStats()
    agg_stats.set_custom_stats("uptime", "10:00", "localhost")
    assert agg_stats.custom["localhost"]["uptime"] == "10:00"
    agg_stats.set_custom_stats("ram", "10G")
    assert agg_stats.custom["_run"]["ram"] == "10G"


# Generated at 2022-06-20 14:30:19.782799
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    actual = AggregateStats().summarize("host")
    expected = {"ok": 0, "rescued": 0, "changed": 0, "unreachable": 0, "ignored": 0, "failures": 0, "skipped": 0}
    assert actual == expected

# Generated at 2022-06-20 14:30:26.241503
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.ignored = {'host1': 10}
    aggregate_stats.decrement('ignored', 'host1')
    assert aggregate_stats.ignored['host1'] == 9

    aggregate_stats.ignored = {'host1': 0}
    aggregate_stats.decrement('ignored', 'host1')
    assert aggregate_stats.ignored['host1'] == 0

# Unit tests for method set_custom_stats of class AggregateStats

# Generated at 2022-06-20 14:30:31.152838
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    a = AggregateStats()
    assert len(a.processed) == 0
    assert len(a.failures) == 0
    assert len(a.ok) == 0
    assert len(a.dark) == 0
    assert len(a.changed) == 0
    assert len(a.skipped) == 0
    assert len(a.rescued) == 0
    assert len(a.ignored) == 0
    assert len(a.custom) == 0


# Generated at 2022-06-20 14:30:45.665113
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    # Create an empty AggregateStats object
    a = AggregateStats()

    # Set a custom stat for host 'foo'
    a.set_custom_stats('test', 'foo', 'bar')

    # Make sure it worked
    assert a.custom == {'bar': {'test': 'foo'}}

    # Try to add another stat for host 'foo'
    a.set_custom_stats('test2', 'bar', 'bar')

    # Make sure it worked
    assert a.custom == {'bar': {'test': 'foo', 'test2': 'bar'}}

    # Try to add a custom stat for host 'bar', with a different type
    a.set_custom_stats('test', 5, 'bar')

    # Make sure that it didn't work

# Generated at 2022-06-20 14:30:53.007780
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    host = 'localhost'
    stats = AggregateStats()
    stats.increment('ok', host)
    stats.increment('changed', host)
    stats.increment('ok', host)
    assert(stats.ok[host] == 2)
    assert(stats.changed[host] == 1)
    assert(stats.skipped[host] == 0)
    assert(stats.ignored[host] == 0)

    stats.decrement('ok', host)
    assert(stats.ok[host] == 1)
    stats.decrement('ok', host)
    assert(stats.ok[host] == 0)
    stats.decrement('ok', host)
    assert(stats.ok[host] == 0)
    stats.decrement('changed', host)