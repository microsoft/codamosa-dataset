

# Generated at 2022-06-20 14:26:08.935143
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    a_stats = AggregateStats()
    a_stats.increment('ok', 'test_host')
    a_stats.increment('failures', 'test_host')
    a_stats.increment('dark', 'test_host')
    a_stats.increment('changed', 'test_host')
    a_stats.increment('skipped', 'test_host')
    a_stats.increment('ignored', 'test_host')
    a_stats.increment('rescued', 'test_host')

    assert a_stats.summarize('test_host') == dict(
        ok=1,
        failures=1,
        unreachable=1,
        changed=1,
        skipped=1,
        rescued=1,
        ignored=1,
    )



# Generated at 2022-06-20 14:26:21.986337
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    class TestClass:
        def __init__(self):
            self.custom = {}

    t = TestClass()
    t.update_custom_stats('foo', 'bar')
    assert t.custom['_run']['foo'] == 'bar'
    t.update_custom_stats('foo', 'baz')
    assert t.custom['_run']['foo'] == 'baz'

    t.update_custom_stats('foo', ['bar', 'baz'])
    assert t.custom['_run']['foo'] == ['bar', 'baz']

    t.update_custom_stats('foo', ['baz'])
    assert t.custom['_run']['foo'] == ['bar', 'baz', 'baz']


# Generated at 2022-06-20 14:26:27.550886
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate = AggregateStats()
    aggregate.increment('ok', 'test_host')
    assert aggregate.ok['test_host'] == 1, "increment method not incrementing"


# Generated at 2022-06-20 14:26:36.930250
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()

    aggregate_stats.ok['hostname'] = 10
    aggregate_stats.failures['hostname'] = 2
    aggregate_stats.changed['hostname'] = 6
    aggregate_stats.rescued['hostname'] = 1

    expected = {'ok': 10, 'failures': 2, 'changed': 6,
                'unreachable': 0, 'skipped': 0, 'rescued': 1, 'ignored': 0}
    result = aggregate_stats.summarize('hostname')

    assert result == expected

# Generated at 2022-06-20 14:26:41.184658
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggstats = AggregateStats()
    aggstats.increment('ok', 'test')
    aggstats.increment('ok', 'test')

    assert aggstats.ok['test'] == 2

    aggstats.decrement('ok', 'test')

    assert aggstats.ok['test'] == 1

    aggstats.decrement('ok', 'test2')

    assert aggstats.ok == {'test': 1}

# Generated at 2022-06-20 14:26:52.127196
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', '127.0.0.1')
    stats.increment('ok', '127.0.0.1')
    stats.increment('changed', '127.0.0.1')
    assert stats.summarize('127.0.0.1') == dict(ok=2, failures=0, unreachable=0, changed=1, skipped=0, rescued=0, ignored=0)



# Generated at 2022-06-20 14:26:58.021306
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.processed == {}
    assert aggregate_stats.dark == {}
    assert aggregate_stats.ok == {}
    assert aggregate_stats.changed == {}
    assert aggregate_stats.skipped == {}
    assert aggregate_stats.rescued == {}
    assert aggregate_stats.ignored == {}
    assert aggregate_stats.custom == {}

# Generated at 2022-06-20 14:27:08.993427
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'example.org')
    stats.increment('ok', 'example.com')
    stats.increment('failures', 'example.net')
    stats.increment('dark', 'example.net')
    stats.increment('dark', 'example.org')
    assert stats.summarize('example.org') == {'ok': 1, 'dark': 1, 'failed': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}
    assert stats.summarize('example.net') == {'ok': 0, 'dark': 1, 'failed': 1, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}
    assert stats.summarize('example.com')

# Generated at 2022-06-20 14:27:22.088058
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg_stats = AggregateStats()
    agg_stats.set_custom_stats('test', {'test': 'test'})
    assert agg_stats.custom == {'_run': {'test': {'test': 'test'}}}
    agg_stats.set_custom_stats('test', {'test2': 'test2'})
    assert agg_stats.custom == {'_run': {'test': {'test': 'test', 'test2': 'test2'}}}
    agg_stats.set_custom_stats('test', {'test2': 'test2'}, 'test_host')
    assert agg_stats.custom == {'_run': {'test': {'test': 'test', 'test2': 'test2'}}, 'test_host': {'test': {'test2': 'test2'}}}

# Generated at 2022-06-20 14:27:27.162332
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    global stats
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}

    assert stats.custom == {}


# Generated at 2022-06-20 14:27:32.998949
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():

    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')

    assert stats.ok['localhost'] == 3


# Generated at 2022-06-20 14:27:41.738041
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    assert stats.ok == {'host1': 1}
    stats.increment('ok', 'host2')
    assert stats.ok == {'host1': 1, 'host2': 1}
    stats.increment('ok', 'host1')
    assert stats.ok == {'host1': 2, 'host2': 1}
    stats.increment('ok', 'host1')
    assert stats.ok == {'host1': 3, 'host2': 1}


# Generated at 2022-06-20 14:27:48.016740
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    ags = AggregateStats()
    assert ags.custom == {}
    ags.update_custom_stats('foo', 'bar')
    assert ags.custom.get('_run') == {'foo': 'bar'}

    ags.update_custom_stats('foo', 'bar')
    assert ags.custom.get('_run') == {'foo': 'bar'}

    ags.update_custom_stats('foo', 'bar', 'host1')
    assert ags.custom.get('host1') == {'foo': 'bar'}
    assert ags.custom.get('_run') == {'foo': 'bar'}


# Generated at 2022-06-20 14:27:51.554164
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggr_stats = AggregateStats()
    what = 'ok'
    host = 'localhost'
    try:
        aggr_stats.decrement(what, host)
    except:
        assert False, 'test_AggregateStats_decrement FAILED'
    assert aggr_stats.ok[host] == 0


# Generated at 2022-06-20 14:28:02.717763
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Test to check the correct merging of two dictionaries when the value of
    # the key 'what' is of type dictionary.
    stats = AggregateStats()
    stats.update_custom_stats('which', dict(k1="v1", k2="v2"))
    stats.update_custom_stats('which', dict(k2="v2", k3="v4"))
    assert stats.custom == {'_run': {'which': {'k3': 'v4', 'k1': 'v1', 'k2': 'v2'}}}

    # Test to check the addition of two values when the value of the key 'what'
    # is of type int
    stats.update_custom_stats('which', 1)
    stats.update_custom_stats('which', 2)

# Generated at 2022-06-20 14:28:10.865149
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'myhost')
    stats.increment('failures', 'myhost')
    stats.increment('failures', 'myhost')
    stats.increment('dark', 'myhost')
    stats.increment('changed', 'myhost')
    stats.increment('changed', 'myhost')
    stats.increment('changed', 'myhost')
    stats.increment('skipped', 'myhost')
    stats.increment('rescued', 'myhost')
    stats.increment('ignored', 'myhost')
    stats.increment('ignored', 'myhost')
    stats.increment('ignored', 'myhost')

# Generated at 2022-06-20 14:28:15.509625
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ansi = AggregateStats()
    ansi.increment('failures', 'test')
    assert ansi.failures['test'] == 1
    ansi.increment('failures', 'test')
    assert ansi.failures['test'] == 2


# Generated at 2022-06-20 14:28:16.933815
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats is not None

# Generated at 2022-06-20 14:28:27.667938
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    import json
    import tempfile

    tmp_file = tempfile.NamedTemporaryFile()

    # create test_hosts.yml with all possible host combinations
    tmp_file.writelines([
        '''
        hosts:
            test_host_1:
            test_host_2:
            test_host_both:
        ''',
    ])
    tmp_file.flush()

    tmp_inventory = '-i ' + tmp_file.name

    # check dict update
    test_command = '%s gather_facts: no tasks: - stats: data={{test_key: test_value}}' % tmp_inventory
    _rc, stdout, _stderr = module.run_command(test_command, json_mode=True)
    result = json.loads(stdout)

# Generated at 2022-06-20 14:28:34.286050
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'test')
    stats.increment('ok', 'test')
    stats.increment('ok', 'test')
    stats.increment('failures', 'test')
    stats.increment('failures', 'test')
    stats.increment('changed', 'test')
    stats.increment('changed', 'test')
    stats.increment('changed', 'test')
    stats.increment('changed', 'test')
    stats.increment('skipped', 'test')
    stats.increment('rescued', 'test')
    stats.increment('ignored', 'test')
    stats.increment('dark', 'test')

    results = stats.summarize('test')

    assert results['ok'] == 3