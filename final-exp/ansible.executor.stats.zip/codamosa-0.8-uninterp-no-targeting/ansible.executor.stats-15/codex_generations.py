

# Generated at 2022-06-20 14:25:58.497324
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    a = AggregateStats()
    a.set_custom_stats('foo', 'bar')

    assert a.custom['_run']['foo'] == 'bar'


# Generated at 2022-06-20 14:26:09.070145
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()
    assert(aggregate_stats.ok == {})

    aggregate_stats.increment('ok', 'host')
    assert(aggregate_stats.ok['host'] == 1)
    assert(aggregate_stats.changed == {})

    aggregate_stats.increment('changed', 'host')
    assert(aggregate_stats.ok['host'] == 1)
    assert(aggregate_stats.changed['host'] == 1)

    # negative number
    aggregate_stats.decrement('ok', 'host')
    assert(aggregate_stats.ok['host'] == 0)

    aggregate_stats.set_custom_stats('test', 100, 'host')
    assert(aggregate_stats.custom['host']['test'] == 100)


# Generated at 2022-06-20 14:26:22.070564
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats_object = AggregateStats()

    # Test a empty object
    assert aggregate_stats_object.summarize('host') == {
        'ok': 0,
        'failures': 0,
        'unreachable': 0,
        'changed': 0,
        'skipped': 0,
        'rescued': 0,
        'ignored': 0
    }

    # Test with some content
    aggregate_stats_object.increment('ok', 'host')
    aggregate_stats_object.increment('ok', 'host')
    aggregate_stats_object.increment('ok', 'host')
    aggregate_stats_object.increment('ignored', 'host')


# Generated at 2022-06-20 14:26:34.376089
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    # Set a custom statistic
    aggregate_stats.set_custom_stats('subnet_size', 20)
    assert aggregate_stats.custom == {'_run': {'subnet_size': 20}}
    # Set another custom statistic
    aggregate_stats.set_custom_stats('subnet_size', 10, 'subnet1')
    aggregate_stats.set_custom_stats('subnet_size', 20, 'subnet2')
    aggregate_stats.set_custom_stats('subnet_size', 30, 'subnet3')

# Generated at 2022-06-20 14:26:39.904989
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    as_obj = AggregateStats()
    as_obj.increment("ok", "host1")
    assert as_obj.ok["host1"] == 1
    _processed = as_obj.processed
    assert isinstance(_processed, dict)



# Generated at 2022-06-20 14:26:45.884770
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed.__class__ == {}.__class__
    assert stats.failures.__class__ == {}.__class__
    assert stats.ok.__class__ == {}.__class__
    assert stats.dark.__class__ == {}.__class__
    assert stats.changed.__class__ == {}.__class__
    assert stats.skipped.__class__ == {}.__class__
    assert stats.rescued.__class__ == {}.__class__
    assert stats.ignored.__class__ == {}.__class__
    assert stats.custom.__class__ == {}.__class__


# Generated at 2022-06-20 14:26:50.501155
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    a = AggregateStats()
    a.increment('ok', 'localhost')
    a.decrement('ok', 'localhost')
    assert a.ok['localhost'] == 0


# Generated at 2022-06-20 14:26:52.879021
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 1


# Generated at 2022-06-20 14:26:54.907447
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg_stats = AggregateStats()
    assert agg_stats.ok is not None


# Generated at 2022-06-20 14:27:06.333017
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    ''' test for the summarize method of class AggregateStats'''

    aggregate_stats = AggregateStats()
    aggregate_stats.increment("ok", "host1")
    aggregate_stats.increment("failures", "host2")
    aggregate_stats.increment("failures", "host2")
    aggregate_stats.increment("dark", "host2")
    aggregate_stats.increment("dark", "host3")
    aggregate_stats.increment("dark", "host3")
    aggregate_stats.increment("dark", "host3")
    aggregate_stats.increment("changed", "host3")


# Generated at 2022-06-20 14:27:13.935054
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()
    print (aggregate_stats.processed)
    print (aggregate_stats.failures)
    print (aggregate_stats.ok)
    print (aggregate_stats.dark)
    print (aggregate_stats.changed)
    print (aggregate_stats.skipped)
    print (aggregate_stats.rescued)
    print (aggregate_stats.ignored)


# Generated at 2022-06-20 14:27:19.477175
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stat = AggregateStats()
    stat.set_custom_stats('http_status', '200', 'host')
    stat.set_custom_stats('http_status', 404)
    assert stat.custom['host']['http_status'] == '200'
    assert stat.custom['_run']['http_status'] == 404


# Generated at 2022-06-20 14:27:23.492300
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    import pytest
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('failures', '127.0.0.1')
    aggregate_stats.increment('failures', '127.0.0.1')
    aggregate_stats.decrement('failures', '127.0.0.1')
    assert aggregate_stats.failures.get('127.0.0.1', 0) == 1

# Generated at 2022-06-20 14:27:27.930225
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    ans = AggregateStats()
    assert ans.processed == {}
    assert ans.failures == {}
    assert ans.ok == {}
    assert ans.dark == {}
    assert ans.changed == {}
    assert ans.skipped == {}
    assert ans.rescued == {}
    assert ans.ignored == {}
    assert ans.custom == {}


# Generated at 2022-06-20 14:27:36.105597
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'host')
    aggregate_stats.increment('ok', 'host')
    aggregate_stats.increment('changed', 'host2')
    aggregate_stats.increment('changed', 'host2')
    aggregate_stats.increment('changed', 'host2')
    if aggregate_stats.processed != {'host': 1, 'host2': 1}:
        raise AssertionError('processed fail')
    if aggregate_stats.failures != {}:
        raise AssertionError('failures fail')
    if aggregate_stats.ok != {'host': 2}:
        raise AssertionError('ok fail')
    if aggregate_stats.changed != {'host2': 3}:
        raise AssertionError('changed fail')
    return True



# Generated at 2022-06-20 14:27:46.289276
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    foo = AggregateStats()
    foo.decrement("ok", "fizbaz")
    if foo.ok != {"fizbaz": 0}:
        raise AssertionError("foo.ok != {\"fizbaz\": 0}")
    foo.increment("ok", "fizbaz")
    foo.decrement("ok", "fizbaz")
    if foo.ok != {"fizbaz": 0}:
        raise AssertionError("foo.ok != {\"fizbaz\": 0}")

# Generated at 2022-06-20 14:27:56.208338
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import pytest
    # Test that set_custom_stats works well
    aggStats = AggregateStats()
    aggStats.set_custom_stats('firstPing', 'ping', 'host1')
    aggStats.set_custom_stats('secondPing', 'ping', 'host1')
    aggStats.set_custom_stats('firstPing', 'pong', 'host2')
    assert aggStats.custom['host1'] == {'firstPing': 'ping', 'secondPing': 'ping'}
    assert aggStats.custom['host2'] == {'firstPing': 'pong'}
    # Test that update_custom_stats works well when the new stat has the same type
    aggStats.update_custom_stats('firstPing', 'pong', 'host1')

# Generated at 2022-06-20 14:28:07.637390
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import unittest
    import sys

    # Setup
    class FakeModule1:
        def __init__(self):
            self.module_args = dict(ansible_host='a1', ansible_user='u1', ansible_port=10)

    class FakeModule2:
        def __init__(self):
            self.module_args = dict(ansible_host='a2', ansible_user='u2', ansible_port=20)

    class FakeModule3:
        def __init__(self):
            self.module_args = dict(ansible_host='a3', ansible_user='u3', ansible_port=30)

    def _test_update_custom_stats(stats, which, what, host, expected):
        # Patch
        fake_res = 'fake_result'
       

# Generated at 2022-06-20 14:28:15.452383
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg_stats = AggregateStats()
    assert agg_stats.processed == {}
    assert agg_stats.failures == {}
    assert agg_stats.ok == {}
    assert agg_stats.dark == {}
    assert agg_stats.changed == {}
    assert agg_stats.skipped == {}
    assert agg_stats.rescued == {}
    assert agg_stats.ignored == {}


# Generated at 2022-06-20 14:28:26.634870
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    class AggregateStatsTest(AggregateStats):
        '''Test class for method increment of class AggregateStats'''
        def __init__(self):
            self.processed = {}
            self.failures = {}
            self.ok = {}
            self.dark = {}
            self.changed = {}
            self.skipped = {}
            self.rescued = {}
            self.ignored = {}
            self.custom = {}

    act_obj = AggregateStatsTest()
    act_host = 'host1'
    act_obj.increment('ok', act_host)
    assert act_obj.processed.get(act_host) == 1
    assert act_obj.ok.get(act_host) == 1
    act_obj.increment('ok', act_host)
    assert act_obj.process

# Generated at 2022-06-20 14:28:37.963440
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats(which='foo', what=2)
    stats.set_custom_stats(which='foo', what=3, host='example.com')
    assert stats.custom.get('_run',{}).get('foo') == 2
    assert stats.custom.get('example.com',{}).get('foo') == 3


# Generated at 2022-06-20 14:28:47.600761
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats('stats_type_1', {'item_1': 1})
    aggregate_stats.set_custom_stats('stats_type_1', {'item_1': 1, 'item_2': 2, 'item_3': 3})
    aggregate_stats.set_custom_stats('stats_type_1', {'item_4': 4})
    aggregate_stats.set_custom_stats('stats_type_2', 4)
    aggregate_stats.set_custom_stats('stats_type_2', 10)
    aggregate_stats.set_custom_stats('stats_type_2', 8)
    aggregate_stats.set_custom_stats('stats_type_3', {'item_1': 8})

# Generated at 2022-06-20 14:29:00.418876
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    agg_stats = AggregateStats()

    assert agg_stats.summarize("host") == dict(
        ok=0, failures=0, unreachable=0, changed=0, skipped=0, rescued=0, ignored=0)

    agg_stats.increment("ok", "host")
    assert agg_stats.summarize("host") == dict(
        ok=1, failures=0, unreachable=0, changed=0, skipped=0, rescued=0, ignored=0)

    agg_stats.increment("ok", "host")
    agg_stats.increment("failures", "host")
    assert agg_stats.summarize("host") == dict(
        ok=2, failures=1, unreachable=0, changed=0, skipped=0, rescued=0, ignored=0)



# Generated at 2022-06-20 14:29:03.640067
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats("foo", "bar", host="test_host")
    assert aggregate_stats.custom["test_host"]["foo"] == "bar"



# Generated at 2022-06-20 14:29:11.723983
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    """
    make sure the stats summary method does the right thing
    """

    # set up defaults
    stats = AggregateStats()
    stats.ok['127.0.0.1'] = 5
    stats.changed['127.0.0.1'] = 1
    stats.dark['127.0.0.1'] = 2

    # test the summary
    results = stats.summarize('127.0.0.1')
    assert results['ok'] == 5
    assert results['changed'] == 1
    assert results['unreachable'] == 2

# Generated at 2022-06-20 14:29:22.852810
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    # Decrementing 'ok'
    stats.ok['host'] = 1
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 0

    # Decrementing 'ok' again
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 0

    # Decrementing 'failures'
    stats.failures['host'] = 1
    stats.decrement('failures', 'host')
    assert stats.failures['host'] == 0

    # Decrementing 'dark'
    stats.dark['host'] = 1
    stats.decrement('dark', 'host')
    assert stats.dark['host'] == 0

    # Decrementing 'changed'
    stats.changed['host'] = 1
    stats.decre

# Generated at 2022-06-20 14:29:34.012550
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 42)
    assert stats.custom['_run'] == {'foo': 42}
    stats.update_custom_stats('foo', 43)
    assert stats.custom['_run'] == {'foo': 85}
    stats.update_custom_stats('foo', 43, 'hostname')
    assert stats.custom['hostname'] == {'foo': 43}
    stats.update_custom_stats('foo', {'bar': 'baz'}, 'hostname')
    assert stats.custom['hostname'] == {'foo': {'bar': 'baz'}}



# FIXME: copied from vars play, should be central

# Generated at 2022-06-20 14:29:42.203395
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats={'failures': {'test_failed': 1},
        'ok': {'test_ok': 1},
        'dark': {'test_unreachable': 1},
        'changed': {'test_changed': 1},
        'skipped': {'test_skipped': 1},
        'rescued': {'test_rescued': 1},
        'ignored': {'test_ignored': 1}}

    as_obj = AggregateStats()
    as_obj.increment('failures', 'test_failed')
    as_obj.increment('ok', 'test_ok')
    as_obj.increment('dark', 'test_unreachable')
    as_obj.increment('changed', 'test_changed')
    as_obj.increment('skipped', 'test_skipped')


# Generated at 2022-06-20 14:29:49.196288
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    a = AggregateStats()
    a.increment('ok', 'testhost')
    assert a.ok['testhost'] == 1
    a.increment('failures', 'testhost')
    assert a.ok['testhost'] == 1
    assert a.failures['testhost'] == 1
    a.increment('ok', 'testhost')
    assert a.ok['testhost'] == 2
    assert a.failures['testhost'] == 1


# Generated at 2022-06-20 14:30:00.132632
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok = {'s1': 1, 's2': 2}
    stats.failures = {'s1': 3, 's2': 4}
    stats.dark = {'s1': 5, 's2': 6}
    stats.changed = {'s1': 7, 's2': 8}
    stats.skipped = {'s1': 9, 's2': 10}
    stats.rescued = {'s1': 11, 's2': 12}
    assert stats.summarize('s1') == {
        'ok': 1,
        'failures': 3,
        'unreachable': 5,
        'changed': 7,
        'skipped': 9,
        'rescued': 11,
        'ignored': 0
    }

# Generated at 2022-06-20 14:30:05.886192
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement('skipped', 'host1')

# Generated at 2022-06-20 14:30:14.625618
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregateStats = AggregateStats()
    aggregateStats.increment('ok', 'test')
    aggregateStats.increment('failures', 'test')
    aggregateStats.increment('changed', 'test')
    aggregateStats.increment('skipped', 'test')
    assert aggregateStats.summarize('test') == {
                                                  'ok': 1,
                                                  'failures': 1,
                                                  'unreachable': 0,
                                                  'changed': 1,
                                                  'skipped': 1,
                                                  'rescued': 0,
                                                  'ignored': 0,
                                                }


# Generated at 2022-06-20 14:30:26.594639
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    # pylint: disable=protected-access
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'test_host')

    assert(aggregate_stats.summarize('test_host').get('ok') == 1)
    assert(aggregate_stats.summarize('unknown_host').get('ok') == 0)

    stats = aggregate_stats.summarize('test_host')
    stats_expect = {'skipped': 0, 'ignored': 0, 'rescued': 0, 'ok': 1, 'changed': 0, 'unreachable': 0, 'failures': 0}
    assert(stats == stats_expect)

# Generated at 2022-06-20 14:30:33.305617
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    astats = AggregateStats()
    astats.increment('ok', 'x.example.org')
    astats.increment('failures', 'x.example.org')
    astats.increment('ok', 'x.example.org')
    astats.increment('ok', 'x.example.org')

    astats.increment('ok', 'y.example.org')

    astats.increment('ok', 'z.example.org')
    astats.increment('failures', 'z.example.org')
    astats.increment('ok', 'z.example.org')
    astats.increment('ok', 'z.example.org')

    assert astats.summarize('x.example.org') == {'ok': 3, 'failures': 1}
    assert astats.sum

# Generated at 2022-06-20 14:30:39.225817
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ans = AggregateStats()
    ans.decrement('ok', 'foo')
    assert ans.ok.get('foo') == 0

# Generated at 2022-06-20 14:30:47.829674
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    '''Unit test for AggregateStats.summarize'''
    # Preparation
    stats = AggregateStats()
    stats.increment("ok", "localhost")
    stats.increment("ok", "localhost")
    stats.increment("ok", "localhost")
    stats.increment("failures", "localhost")
    stats.increment("dark", "localhost")
    stats.increment("changed", "localhost")
    stats.increment("skipped", "localhost")
    stats.increment("rescued", "localhost")
    stats.increment("ignored", "localhost")
    # Test
    assert stats.summarize("localhost")["ok"] == 3
    assert stats.summarize("localhost")["failures"] == 1
    assert stats.summarize("localhost")["unreachable"] == 1

# Generated at 2022-06-20 14:31:02.481855
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    assert stats.update_custom_stats(1,2) == None
    assert stats.custom == {'_run': {1: 2}}
    assert stats.update_custom_stats(1,2) == None
    assert stats.custom == {'_run': {1: 2}}
    assert stats.update_custom_stats(1,3) == None
    assert stats.custom == {'_run': {1: 5}}
    assert stats.update_custom_stats(1,3, 'foo') == None
    assert stats.custom == {'_run': {1: 5}, 'foo': {1: 3}}
    assert stats.update_custom_stats(1,3, 'foo') == None
    assert stats.custom == {'_run': {1: 5}, 'foo': {1: 6}}

# Generated at 2022-06-20 14:31:08.618610
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg_stats = AggregateStats()
    assert agg_stats.processed == {}
    assert agg_stats.failures == {}
    assert agg_stats.ok == {}
    assert agg_stats.dark == {}
    assert agg_stats.changed == {}
    assert agg_stats.skipped == {}
    assert agg_stats.rescued == {}
    assert agg_stats.ignored == {}
    assert agg_stats.custom == {}


# Generated at 2022-06-20 14:31:14.029098
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stat = 'x'
    value = 'y'
    stats.set_custom_stats(stat, value)
    assert stats.custom['_run'][stat] == value


# Generated at 2022-06-20 14:31:19.043235
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate = AggregateStats()

    assert aggregate.ok == {}
    assert aggregate.failures == {}
    assert aggregate.dark == {}
    assert aggregate.changed == {}
    assert aggregate.skipped == {}
    assert aggregate.rescued == {}
    assert aggregate.ignored == {}
    assert aggregate.custom == {}
