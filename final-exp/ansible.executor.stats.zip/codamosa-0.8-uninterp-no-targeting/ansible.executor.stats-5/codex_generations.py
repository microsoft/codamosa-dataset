

# Generated at 2022-06-20 14:25:57.768198
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.custom == {}
    aggregate_stats.set_custom_stats('test_stat', 100, 'test_host')
    assert aggregate_stats.custom == {'test_host': {'test_stat': 100}}
    # set the same stat again, stat should not be overwritten
    aggregate_stats.set_custom_stats('test_stat', 200, 'test_host')
    assert aggregate_stats.custom == {'test_host': {'test_stat': 100}}


# Generated at 2022-06-20 14:26:06.466633
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    class FakeHost:
        name = 'fake_host'
    stats = AggregateStats()
    stats.set_custom_stats('junk_key', [1, 2, 3, 4], FakeHost)
    assert stats.custom['fake_host']['junk_key'] == [1, 2, 3, 4]
    stats.set_custom_stats('junk_key', 'junk_value')
    assert stats.custom['_run']['junk_key'] == 'junk_value'


# Generated at 2022-06-20 14:26:11.641853
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate = AggregateStats()
    aggregate.set_custom_stats('stats', 'test', 'localhost')
    assert aggregate.custom.get('localhost').get('stats') == 'test'


# Generated at 2022-06-20 14:26:14.152680
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate = AggregateStats()

    assert aggregate.processed == {}
    assert aggregate.failures == {}
    assert aggregate.ok == {}
    assert aggregate.dark == {}
    assert aggregate.changed == {}
    assert aggregate.skipped == {}
    assert aggregate.rescued == {}
    assert aggregate.ignored == {}
    assert aggregate.custom == {}

# Generated at 2022-06-20 14:26:17.747237
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    data = AggregateStats()
    # Zero
    data.decrement('ok', 'example.org')
    assert data.ok['example.org'] == 0

    # Below zero
    data.decrement('ok', 'example.org')
    assert data.ok['example.org'] == 0



# Generated at 2022-06-20 14:26:26.570006
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    '''
    Initialize a AggregateStats object and test if it is initialized with empty dictionaries
    '''
    # Create an object and test if it has the attributes we expect
    stats = AggregateStats()
    assert(hasattr(stats, 'processed'))
    assert(hasattr(stats, 'failures'))
    assert(hasattr(stats, 'ok'))
    assert(hasattr(stats, 'dark'))
    assert(hasattr(stats, 'changed'))
    assert(hasattr(stats, 'skipped'))
    assert(hasattr(stats, 'rescued'))
    assert(hasattr(stats, 'ignored'))
    assert(hasattr(stats, 'custom'))

    # test if are intialized with empty dictionaries
    assert(isinstance(stats.processed, dict))

# Generated at 2022-06-20 14:26:31.143248
# Unit test for constructor of class AggregateStats
def test_AggregateStats():

    result = AggregateStats()
    assert result.processed == {}
    assert result.failures == {}
    assert result.ok == {}
    assert result.dark == {}
    assert result.changed == {}
    assert result.skipped == {}
    assert result.rescued == {}
    assert result.ignored == {}
    assert result.custom == {}



# Generated at 2022-06-20 14:26:42.259287
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'host1')
    aggregate_stats.increment('ok', 'host1')
    aggregate_stats.increment('ok', 'host1')
    aggregate_stats.increment('failures', 'host1')
    aggregate_stats.increment('failures', 'host2')
    aggregate_stats.increment('failures', 'host3')
    aggregate_stats.increment('failures', 'host3')
    aggregate_stats.increment('changed', 'host1')
    aggregate_stats.increment('changed', 'host1')
    aggregate_stats.increment('changed', 'host2')
    aggregate_stats.increment('dark', 'host1')
    aggregate_stats.increment('dark', 'host1')

# Generated at 2022-06-20 14:26:44.738864
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    # create an instance of class AggregateStats
    stats = AggregateStats()
    stats.increment('ok', 'host')
    assert stats.ok['host'] == 1
    assert stats.processed['host'] == 1



# Generated at 2022-06-20 14:26:46.358568
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate = AggregateStats()
    aggregate.set_custom_stats('custstat', 1)
    assert aggregate.custom['_run']['custstat'] == 1


# Generated at 2022-06-20 14:27:00.934962
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.utils.vars import merge_hash

    asg = AggregateStats()
    asg.update_custom_stats('test', {'1': 1, '2': 2, '3': 3}, 'wanghai')
    asg.update_custom_stats('test', {'2': 4, '4': 4, '5': 5}, 'wanghai')
    assert asg.custom['wanghai']['test']['1'] == 1
    assert asg.custom['wanghai']['test']['2'] == 6
    assert asg.custom['wanghai']['test']['3'] == 3
    assert asg.custom['wanghai']['test']['4'] == 4
    assert asg

# Generated at 2022-06-20 14:27:04.293784
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate = AggregateStats()
    aggregate.increment("ok", "test_host")
    assert aggregate.ok["test_host"] == 1
    assert aggregate.processed["test_host"] == 1

# Generated at 2022-06-20 14:27:15.311803
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggStats = AggregateStats()

    aggStats.update_custom_stats("test", "val")
    assert aggStats.custom['_run']['test'] == "val"

    aggStats.update_custom_stats("test", "val")
    assert aggStats.custom['_run']['test'] == "val"

    aggStats.update_custom_stats("test2", {"val": 1})
    assert aggStats.custom['_run']['test2']['val'] == 1

    aggStats.update_custom_stats("test2", {"val2": 2})
    assert aggStats.custom['_run']['test2']['val'] == 1
    assert aggStats.custom['_run']['test2']['val2'] == 2


# Generated at 2022-06-20 14:27:22.898577
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    key_name = 'cpu'
    value = 'Intel(R) Core(TM) i5-4210U CPU @ 1.70GHz'
    stats.set_custom_stats(key_name, value)
    assert stats.custom['_run'][key_name] == value
    key_name = 'memory'
    value = {
        'MemTotal': '1000 kB',
        'MemFree': '100 kB'
    }
    stats.set_custom_stats(key_name, value)
    assert stats.custom['_run'][key_name] == value

# Generated at 2022-06-20 14:27:33.270926
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    as_obj = AggregateStats()
    host = '127.0.0.1'
    as_obj.ok[host] = 1
    as_obj.failures[host] = 2
    as_obj.dark[host] = 3
    as_obj.changed[host] = 4
    as_obj.skipped[host] = 5
    as_obj.rescued[host] = 6
    as_obj.ignored[host] = 7

    expected = {'ok': 1, 'failures': 2, 'unreachable': 3,
                'changed': 4, 'skipped': 5, 'rescued': 6, 'ignored': 7}
    assert as_obj.summarize(host) == expected



# Generated at 2022-06-20 14:27:37.250168
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats is not None


# Generated at 2022-06-20 14:27:44.196897
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement("ok", "localhost")
    assert stats.ok['localhost'] == 0
    stats.decrement("ok", "localhost")
    assert stats.ok['localhost'] == 0
    stats.ok['localhost'] = 10
    stats.decrement("ok", "localhost")
    assert stats.ok['localhost'] == 9

# Generated at 2022-06-20 14:27:47.850104
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    ag = AggregateStats()
    ag.set_custom_stats('Test', 1, 'host1')
    ag.set_custom_stats('Test', 2, 'host2')
    assert ag.custom == {
            'host1': {'Test': 1},
            'host2': {'Test': 2},
        }



# Generated at 2022-06-20 14:27:54.299980
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    test_stats = AggregateStats()
    host = 'host1'
    what_list = ['ok', 'failures', 'dark', 'changed', 'skipped', 'rescued', 'ignored']
    for what in what_list:
        test_stats.increment(what, host)
    for what in what_list:
        assert test_stats.__dict__[what][host] == 1


# Generated at 2022-06-20 14:28:04.648438
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    aggregate_stats.ok['test']=5
    aggregate_stats.changed['test']=5
    aggregate_stats.rescued['test']=5
    aggregate_stats.ignored['test']=5
    aggregate_stats.skipped['test']=5

    assert aggregate_stats.summarize('test') == {'ok': 5, 'failures': 0, 'unreachable': 0, 'changed': 5, 'skipped': 5, 'rescued': 5, 'ignored': 5}
    assert aggregate_stats.summarize('test2') == {'ok': 0, 'failures': 0, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}



# Generated at 2022-06-20 14:28:17.881604
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate = AggregateStats()
    aggregate.ok = {'joe':1, 'moe':1, 'boe':1}
    assert aggregate.ok['joe'] == 1
    assert aggregate.ok['moe'] == 1
    assert aggregate.ok['boe'] == 1
    aggregate.decrement('ok', 'joe')
    assert aggregate.ok['joe'] == 0
    aggregate.decrement('ok', 'bud')
    assert aggregate.ok['bud'] == 0
    aggregate.decrement('ok', 'moe')
    assert aggregate.ok['moe'] == 0
    aggregate.decrement('ok', 'boe')
    assert aggregate.ok['boe'] == 0


# Generated at 2022-06-20 14:28:23.169889
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    ag = AggregateStats()
    assert ag.processed == {}
    assert ag.custom == {}
    assert ag.failures == {}
    assert ag.ok == {}
    assert ag.dark == {}
    assert ag.changed == {}
    assert ag.skipped == {}
    assert ag.rescued == {}

# Generated at 2022-06-20 14:28:30.085925
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0, stats.ok
    stats.ok['host1'] = 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0, stats.ok



# Generated at 2022-06-20 14:28:41.528367
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    '''test that update_custom_stats works as expected when merging dictionaries'''
    stats = AggregateStats()
    stats.update_custom_stats(
        'foo', {'bar': {'baz': 1}}, '127.0.0.1'
    )
    stats.update_custom_stats(
        'foo', {'bar': {'baz': 3}, 'bar2': {'baz2': 5}}, '127.0.0.1'
    )
    stats.update_custom_stats(
        'foo', {'bar': {'baz': 5}}, '127.0.0.2'
    )
    assert stats.custom['127.0.0.1']['foo'] == {'bar': {'baz': 4}, 'bar2': {'baz2': 5}}

# Generated at 2022-06-20 14:28:50.431868
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'ok': 1})
    assert stats.custom['_run']['foo']['ok'] == 1
    stats.update_custom_stats('foo', {'ok': 1})
    assert stats.custom['_run']['foo']['ok'] == 2
    stats.update_custom_stats('foo', {'ok': 1}, '192.168.1.1')
    assert stats.custom['192.168.1.1']['foo']['ok'] == 1
    stats.update_custom_stats('foo', {'ok': 1}, '192.168.1.1')
    assert stats.custom['192.168.1.1']['foo']['ok'] == 2



# Generated at 2022-06-20 14:29:02.419186
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    import json
    import os

    # initialize a new AggregateStats object
    stats = AggregateStats()

    # initialize a json_file to save host result
    json_file = 'test_AggregateStats_update_custom_stats_result.json'

    # generate host list
    hosts = ['host_a', 'host_b', 'host_c']

    # define custom stats type
    custom_stats_type = ['dict_stat', 'list_stat', 'int_stat', 'str_stat']

    stat_str1 = 'stat_str1'
    stat_str2 = 'stat_str2'
    stat_int1 = 1
    stat_int2 = 2
    stat_int3 = 3
    stat_list1 = [1, 2]
    stat_list2 = [3, 4]
    stat_dict

# Generated at 2022-06-20 14:29:14.523035
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # create empty instance of class
    stats = AggregateStats()

    # test if custom stats are updated correctly
    stats.update_custom_stats('a', {'b': {'c': 1}}, '_run')
    assert stats.custom['_run']['a'] == {'b': {'c': 1}}
    stats.update_custom_stats('a', {'b': {'c': 1}}, '_run')
    assert stats.custom['_run']['a'] == {'b': {'c': 1}}
    stats.update_custom_stats('a', {'b': {'c': 2, 'd': 10}}, '_run')
    assert stats.custom['_run']['a'] == {'b': {'c': 3, 'd': 10}}

    # test if custom stats are

# Generated at 2022-06-20 14:29:22.515697
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'host1')
    assert aggregate_stats.ok['host1'] == 1
    aggregate_stats.decrement('ok', 'host1')
    assert aggregate_stats.ok['host1'] == 0
    aggregate_stats.decrement('ok', 'host1')
    assert aggregate_stats.ok['host1'] == 0
    aggregate_stats.decrement('ok', 'host1')
    assert aggregate_stats.ok['host1'] == 0

# Generated at 2022-06-20 14:29:30.279416
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregatestats = AggregateStats()
    aggregatestats.increment("skipped", "127.0.0.1")
    assert aggregatestats.skipped == {"127.0.0.1": 1}
    aggregatestats.increment("skipped", "127.0.0.1")
    assert aggregatestats.skipped == {"127.0.0.1": 2}



# Generated at 2022-06-20 14:29:33.627511
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    stats.decrement('skipped', 'localhost')
    assert stats.skipped.get('localhost') is None

    stats.skipped['localhost'] = 10
  