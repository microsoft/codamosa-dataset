

# Generated at 2022-06-20 14:26:03.934875
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg_stats = AggregateStats()
    agg_stats.set_custom_stats('a', 1, 'host')
    agg_stats.set_custom_stats('b', 2, 'host')

    assert agg_stats.custom == {'host': {'a': 1, 'b': 2}}

    agg_stats.update_custom_stats('b', 3, 'host')
    assert agg_stats.custom == {'host': {'a': 1, 'b': 5}}

    agg_stats.update_custom_stats('c', {'c': 1, 'd': 2}, 'host')
    assert agg_stats.custom == {'host': {'a': 1, 'b': 5, 'c': {'c': 1, 'd': 2}}}


# Generated at 2022-06-20 14:26:11.013082
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    # Initializing aggregate stats
    stats = AggregateStats()

    # Check results
    assert(isinstance(stats.processed, dict))
    assert(isinstance(stats.failures, dict))
    assert(isinstance(stats.ok, dict))
    assert(isinstance(stats.dark, dict))
    assert(isinstance(stats.changed, dict))
    assert(isinstance(stats.skipped, dict))
    assert(isinstance(stats.rescued, dict))
    assert(isinstance(stats.ignored, dict))
    assert(isinstance(stats.custom, dict))


# Generated at 2022-06-20 14:26:16.576755
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    """Ensure AggregateStats object can be constructed.
    """

    a = AggregateStats()
    assert type(a) is AggregateStats

# Generated at 2022-06-20 14:26:26.186196
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():

    test_stats = AggregateStats()
    host = 'example_host'

    test_stats.increment('ok', host)
    test_stats.increment('ok', host)
    test_stats.increment('changed', host)
    test_stats.increment('failures', host)
    test_stats.increment('dark', host)
    test_stats.increment('skipped', host)
    test_stats.increment('rescued', host)
    test_stats.increment('ignored', host)

    assert(test_stats.processed[host] == 1)
    assert(test_stats.ok[host] == 2)
    assert(test_stats.changed[host] == 1)
    assert(test_stats.failures[host] == 1)

# Generated at 2022-06-20 14:26:28.503347
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregateStats = AggregateStats()
    assert isinstance(aggregateStats, AggregateStats)


# Generated at 2022-06-20 14:26:40.211375
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg_stats = AggregateStats()
    agg_stats.set_custom_stats('foo', 1)
    agg_stats.set_custom_stats('foo',  {'bar': 2})
    agg_stats.set_custom_stats('foo', 3, 'host')
    agg_stats.set_custom_stats('foo', 4, 'host')
    agg_stats.set_custom_stats('foo', 5, 'host')
    agg_stats.set_custom_stats('bar', 6, 'host')
    agg_stats.set_custom_stats('foo', {'bar': 7})

    assert agg_stats.custom == {'_run': {'foo': {'bar': 2}}, 'host': {'foo': 5, 'bar': 6}}

# Generated at 2022-06-20 14:26:44.915270
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats('active', 10, 'host')
    aggregate_stats.set_custom_stats('successful', 20)
    aggregate_stats.set_custom_stats('failed', 30, 'host')
    aggregate_stats.set_custom_stats('unreachable', 40)
    expected = {'_run': {'successful': 20}, 'host': {'active': 10, 'failed': 30}}
    assert aggregate_stats.custom == expected

# Generated at 2022-06-20 14:26:50.643169
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ''' check if method increment of class AggregateStats works'''

    # check if method increment works for every statistic
    for stat in ('failures', 'ok', 'dark', 'changed', 'skipped', 'rescued', 'ignored'):
        # create an object of class AggregateStats
        agg_stats = AggregateStats()
        # check if method decrement properly increments the statistic statistic
        assert agg_stats.__getattribute__(stat).get('test') is None
        agg_stats.increment(stat, 'test')
        assert agg_stats.__getattribute__(stat).get('test') == 1


# Generated at 2022-06-20 14:26:56.604799
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    o = AggregateStats()
    o.set_custom_stats("test_set_custom_stats", 1)
    o.set_custom_stats("test_set_custom_stats_again", 2)

    assert o.custom['_run']['test_set_custom_stats'] == 1
    assert o.custom['_run']['test_set_custom_stats_again'] == 2


# Generated at 2022-06-20 14:27:04.615541
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert isinstance(stats.processed, dict)
    assert isinstance(stats.failures, dict)
    assert isinstance(stats.ok, dict)
    assert isinstance(stats.dark, dict)
    assert isinstance(stats.changed, dict)
    assert isinstance(stats.skipped, dict)
    assert isinstance(stats.rescued, dict)
    assert isinstance(stats.ignored, dict)
    assert isinstance(stats.custom, dict)



# Generated at 2022-06-20 14:27:20.358372
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    stats.update_custom_stats("test", "some_string")
    assert stats.custom["_run"]["test"] == "some_string"

    # Append a character to the string
    stats.update_custom_stats("test", "s")
    assert stats.custom["_run"]["test"] == "some_strings"

    # Start with an integer
    stats.update_custom_stats("test", 1)
    assert stats.custom["_run"]["test"] == 1

    # Increment the integer
    stats.update_custom_stats("test", 1)
    assert stats.custom["_run"]["test"] == 2

    # Start with a dictionary
    stats.update_custom_stats("test", {"a": 1})

# Generated at 2022-06-20 14:27:25.774136
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    assert stats.processed == {'host1': 1}
    assert stats.ok == {'host1': 1}


# Generated at 2022-06-20 14:27:35.280496
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    try:
        x = AggregateStats()
        assert(type(x) == AggregateStats)
        assert(x.processed == {})
        assert(x.failures == {})
        assert(x.ok == {})
        assert(x.dark == {})
        assert(x.changed == {})
        assert(x.skipped == {})
        assert(x.rescued == {})
        assert(x.ignored == {})
        assert(x.custom == {})
    except AssertionError as e:
        print("test failed, the constructor of class AggregateStats is broken.")
        raise(e)


# Generated at 2022-06-20 14:27:44.528804
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    host = "myhost"

    assert stats.ok.get(host, None) is None
    stats.increment('ok', host)
    assert stats.ok[host] == 1

    assert stats.processed.get(host, None) is None
    stats.increment('ok', host)
    assert stats.ok[host] == 2
    assert stats.processed[host] == 1



# Generated at 2022-06-20 14:27:55.238929
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('answer', 42)
    assert stats.custom['_run']['answer'] == 42
    stats.set_custom_stats('answer', 43, host='fake_host')
    assert stats.custom['fake_host']['answer'] == 43
    stats.update_custom_stats('answer', 44)
    assert stats.custom['_run']['answer'] == 44
    stats.set_custom_stats('answer', {'a':1, 'b':2}, host='fake_host')
    stats.update_custom_stats('answer', {'b':1, 'c':3}, host='fake_host')
    assert stats.custom['fake_host']['answer'] == {'a':1, 'b':1, 'c':3}

# Generated at 2022-06-20 14:27:57.771711
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    if stats is None:
        raise AssertionError("Failed to initialize AggregateStats")

# Generated at 2022-06-20 14:28:08.550281
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.utils.vars import combine_vars

    stats = AggregateStats()

    stats.update_custom_stats("same_key", "same_value")
    stats.update_custom_stats("same_key", "same_value")

    stats.update_custom_stats("different_key", "different_value")

    assert(stats.custom['_run']['same_key'] == "same_value")
    assert(stats.custom['_run']['different_key'] == "different_value")

    stats.update_custom_stats("different_key", "different_value_other_host", "host1")

    assert(stats.custom['host1']['different_key'] == "different_value_other_host")


# Generated at 2022-06-20 14:28:16.255963
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    ok_hosts = ['ok_host_1','ok_host_2','ok_host_3','ok_host_4','ok_host_5','ok_host_6']
    for ok_host in ok_hosts:
        aggregate_stats.increment('ok', ok_host)
    failures_hosts = ['failures_host_1','failures_host_2','failures_host_3','failures_host_4','failures_host_5']
    for failures_host in failures_hosts:
        aggregate_stats.increment('failures', failures_host)
    dark_hosts = ['dark_host_1','dark_host_2','dark_host_3']

# Generated at 2022-06-20 14:28:27.217165
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', '127.0.0.1')
    stats.increment('failures', '127.0.0.1')
    stats.increment('ok', '127.0.0.1')
    assert stats.ok['127.0.0.1'] == 2
    assert stats.failures['127.0.0.1'] == 1
    stats.decrement('ok', '127.0.0.1')
    stats.decrement('failures', '127.0.0.1')
    assert stats.ok['127.0.0.1'] == 1
    assert stats.failures['127.0.0.1'] == 0
    stats.decrement('ok', '127.0.0.1')

# Generated at 2022-06-20 14:28:41.773951
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg_stats = AggregateStats()
    agg_stats.increment('ok', 'foo')
    agg_stats.increment('ok', 'foo')
    agg_stats.increment('ok', 'bar')
    agg_stats.increment('changed', 'foo')
    agg_stats.increment('dark', 'bar')
    agg_stats.increment('dark', 'baz')
    agg_stats.increment('ignored', 'baz')
    agg_stats.increment('ignored', 'baz')

    assert agg_stats.ok == {'foo': 2, 'bar': 1}
    assert agg_stats.changed == {'foo': 1}
    assert agg_stats.dark == {'bar': 1, 'baz': 1}
    assert agg_stats.ignored == {'baz': 2}