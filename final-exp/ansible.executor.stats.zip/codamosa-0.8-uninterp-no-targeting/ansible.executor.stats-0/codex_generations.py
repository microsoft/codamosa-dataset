

# Generated at 2022-06-20 14:25:58.350215
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    stats.increment('ok', 'fake_host')
    stats.set_custom_stats('failures', 'fake_failue', 'fake_host')
    stats.update_custom_stats('failures', {'a':1, 'b':2}, 'fake_host')

    if stats.ok != {'fake_host': 1}:
        raise Exception('test_AggregateStats failed')

# Generated at 2022-06-20 14:26:09.070093
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    test_aggregate_stats = AggregateStats()
    test_aggregate_stats.increment('ok', 'host')
    test_aggregate_stats.increment('ok', 'host')
    test_aggregate_stats.increment('failures', 'host')
    test_aggregate_stats.increment('dark', 'host')
    test_aggregate_stats.increment('changed', 'host')
    test_aggregate_stats.increment('skipped', 'host')
    test_aggregate_stats.increment('rescued', 'host')
    test_aggregate_stats.increment('ignored', 'host')
    result = test_aggregate_stats.summarize('host')
    failure_message = "Unexpected results returned"
    assert(result['ok'] == 2), failure_message

# Generated at 2022-06-20 14:26:15.593131
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    # construct object
    stats = AggregateStats()
    stats.increment('changed', 'localhost')
    assert stats.changed['localhost'] == 1
    assert stats.processed['localhost'] == 1
    stats.increment('changed', 'localhost')
    assert stats.changed['localhost'] == 2
    assert stats.processed['localhost'] == 2



# Generated at 2022-06-20 14:26:19.224143
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregateStats = AggregateStats()

    aggregateStats.increment('ok', '192.168.0.2')
    aggregateStats.increment('ok', '192.168.0.2')

    assert aggregateStats.ok['192.168.0.2'] == 2
    assert aggregateStats.processed['192.168.0.2'] == 1



# Generated at 2022-06-20 14:26:28.604780
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    # test for the correct instance type
    assert isinstance(stats, AggregateStats)
    # test for the correct number of instance variables
    # 6 from __init__ and 1 from refresh
    assert len(stats.__dict__) == 7
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}

# Generated at 2022-06-20 14:26:29.555284
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    AggregateStats()

# Generated at 2022-06-20 14:26:37.852198
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.processed == {}
    assert aggregate_stats.failures == {}
    assert aggregate_stats.ok == {}
    assert aggregate_stats.dark == {}
    assert aggregate_stats.changed == {}
    assert aggregate_stats.skipped == {}
    assert aggregate_stats.rescued == {}
    assert aggregate_stats.ignored == {}
    assert aggregate_stats.custom == {}



# Generated at 2022-06-20 14:26:43.754793
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('failures', 'host2')
    assert stats.summarize('host1')['ok'] == 2
    assert stats.summarize('host1')['failures'] == 0
    assert stats.summarize('host2')['ok'] == 0
    assert stats.summarize('host2')['failures'] == 1



# Generated at 2022-06-20 14:26:56.655678
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    # Initialize instance of class AggregateStats
    test_instance = AggregateStats()

    # Test if instance is correctly initialized
    assert hasattr(test_instance, 'processed')
    assert hasattr(test_instance, 'failures')
    assert hasattr(test_instance, 'ok')
    assert hasattr(test_instance, 'dark')
    assert hasattr(test_instance, 'changed')
    assert hasattr(test_instance, 'skipped')
    assert hasattr(test_instance, 'rescued')
    assert hasattr(test_instance, 'ignored')
    assert hasattr(test_instance, 'custom')
    assert test_instance.processed == {}
    assert test_instance.failures == {}
    assert test_instance.ok == {}
    assert test_instance.dark == {}
    assert test_

# Generated at 2022-06-20 14:27:03.250259
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()

    stats.increment('ok', 'localhost')
    assert stats.summarize('localhost') == {
        "ok": 1,
        "failures": 0,
        "unreachable": 0,
        "changed": 0,
        "skipped": 0,
        "rescued": 0,
        "ignored": 0
    }

# Generated at 2022-06-20 14:27:14.217360
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    # Test value for 'host'
    host = "host1"
    # Test value for 'which'
    which = "which1"
    # Test value for 'what'
    what = {"a": 1, "b": 2}

    # Create object
    astats = AggregateStats()

    astats.set_custom_stats(which, what)

    # Get the corresponding value from the object
    custom_stats = astats.custom[host][which]

    # Check for equality
    assert custom_stats == which

    # Check for type
    assert isinstance(custom_stats, str)

    # Check for value
    assert custom_stats == which

# Generated at 2022-06-20 14:27:23.631054
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import MockInventory

    pb = Playbook.load(dict(
        name = "test playbook",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'))
        ]
    ), loader=DictDataLoader(), variable_manager=MockInventory())

    pb.set_stats(AggregateStats())

    # at first, all the keys should be initialized to an empty dict
    assert pb.stats.processed == {}
    assert pb.stats.failures == {}
    assert pb.stats.ok == {}

# Generated at 2022-06-20 14:27:26.567348
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stat = AggregateStats()
    stat.set_custom_stats("custom_stats", 1)
    assert stat.custom["_run"]["custom_stats"] == 1


# Generated at 2022-06-20 14:27:30.065900
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    a = AggregateStats()
    s = "ok"
    h = "localhost"
    a.increment(s, h)
    assert a.ok.get(h, None) == 1


# Generated at 2022-06-20 14:27:41.618055
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    ag = AggregateStats()
    ag.set_custom_stats('foo', 'bar', '_run')
    assert ag.custom.get('_run') == { 'foo': 'bar' }
    ag.set_custom_stats('foo', 'baz', '_run')
    assert ag.custom.get('_run') == { 'foo': 'baz' }
    ag.set_custom_stats('foo', 'bah', 'somehost')
    assert ag.custom.get('somehost') == { 'foo': 'bah' }
    ag.set_custom_stats('cow', 'dog')
    assert ag.custom.get('_run').get('cow') == 'dog'
    ag.set_custom_stats('cow', 'cat')
    assert ag.custom.get('_run').get('cow') == 'cat'

# Generated at 2022-06-20 14:27:49.444172
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregateStats = AggregateStats()
    aggregateStats.update_custom_stats('some', {'some': 1, 'path': {'more': 'dicts'}}, host='127.0.0.1')
    aggregateStats.update_custom_stats('some', 2, host='127.0.0.1')
    aggregateStats.update_custom_stats('some', 2, host='127.0.0.1')
    aggregateStats.update_custom_stats('some', {'some': 1, 'path': {'more': 'dicts'}}, host='127.0.0.1')
    assert aggregateStats.custom['127.0.0.1']['some'] == 8
    assert aggregateStats.custom['127.0.0.1']['some'] == 8

    aggregateStats = AggregateStats()
    aggregateStats

# Generated at 2022-06-20 14:28:01.852547
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    s = AggregateStats()
    s.increment('ok', 'host1')
    s.increment('ok', 'host1')
    s.increment('ok', 'host2')
    s.increment('ok', 'host2')
    s.increment('ok', 'host2')
    s.increment('skipped', 'host2')
    s.increment('skipped', 'host1')
    assert len(s.processed.keys()) == 2
    assert s.processed['host1'] == 1
    assert s.processed['host2'] == 1
    assert len(s.ok.keys()) == 2
    assert s.ok['host1'] == 2
    assert s.ok['host2'] == 3
    assert len(s.skipped.keys()) == 2

# Generated at 2022-06-20 14:28:10.512228
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    from ansible.playbook.play_context import PlayContext

    stats = AggregateStats()
    stats.set_custom_stats('num1', 3, 'foo')
    stats.set_custom_stats('nested', {'a': 3}, 'foo')
    stats.set_custom_stats('nested', {'b': 4}, 'foo')
    stats.set_custom_stats('nested', {'a': 3}, 'foo')
    stats.increment('failures', 'foo')
    stats.increment('ok', 'bar')
    stats.increment('ok', 'bar')
    stats.increment('changed', 'foo')
    stats.increment('changed', 'foo')
    stats.increment('dark', 'foo')

    print(stats.summarize('foo'))

# Generated at 2022-06-20 14:28:24.572323
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    from nose.tools import assert_equal
    from nose.plugins.skip import SkipTest

    obj = AggregateStats()

    # which should be the first parameter of method decrement
    params = (
        ('ok', 'localhost'),
        ('failures', 'localhost'),
        ('dark', 'localhost'),
        ('changed', 'localhost'),
        ('skipped', 'localhost'),
        ('rescued', 'localhost'),
        ('ignored', 'localhost'),
    )
    # Loop over all possible parameter values
    for param in params:

        # Initialize host attribute to zero
        obj.ok['localhost'] = 0

        # Test operation of method decrement
        obj.decrement(*param)

        # assert that decrement does not work with negative values

# Generated at 2022-06-20 14:28:30.678498
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    c1 = AggregateStats()
    assert c1.processed == {}
    assert c1.failures == {}
    assert c1.ok == {}
    assert c1.dark == {}
    assert c1.changed == {}
    assert c1.skipped == {}
    assert c1.rescued == {}
    assert c1.ignored == {}
    assert c1.custom == {}


# Generated at 2022-06-20 14:28:40.208393
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok['host1'] = 1
    stats.ok['host2'] = 2
    stats.failed['host1'] = 2
    stats.failed['host2'] = 3
    stats.unreachable['host2'] = 2
    assert stats.summarize('host1') == {'ok': 1, 'failures': 2, 'changed': 0, 'ignored': 0, 'unreachable': 0, 'skipped': 0, 'rescued': 0}, \
        'AggregateStats.summarize function is broken (1)'

# Generated at 2022-06-20 14:28:44.877634
# Unit test for constructor of class AggregateStats
def test_AggregateStats():

    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}



# Generated at 2022-06-20 14:29:00.155991
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.custom = {'localhost': {}}

    # validate with basic type int
    stats.set_custom_stats('TEST', 3)
    assert stats.custom['_run']['TEST'] == 3

    # validate with basic type string
    stats.set_custom_stats('TEST', 'OK')
    assert stats.custom['_run']['TEST'] == 'OK'

    # validate with basic type list
    stats.set_custom_stats('TEST', ['a', 'b', 'c'])
    assert stats.custom['_run']['TEST'] == ['a', 'b', 'c']

    # validate with basic type dict
    stats.set_custom_stats('TEST', {'key': 'val'})

# Generated at 2022-06-20 14:29:06.031629
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    x = AggregateStats()
    print(x.__dict__)
    x.increment('ok', 'host')
    print(x.__dict__)
    x.increment('failures', 'host')
    x.increment('failures', 'host')
    print(x.__dict__)



# Generated at 2022-06-20 14:29:16.757387
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats=AggregateStats()
    aggregate_stats.increment('ok', 'host1')
    aggregate_stats.increment('changed', 'host1')
    aggregate_stats.increment('ok', 'host2')
    stats1=aggregate_stats.summarize('host1')
    assert stats1 == dict(
        ok=1,
        failures=0,
        unreachable=0,
        changed=1,
        skipped=0,
        rescued=0,
        ignored=0,
    )
    stats2=aggregate_stats.summarize('host2')
    assert stats2 == dict(
        ok=1,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0,
    )

# Generated at 2022-06-20 14:29:25.138138
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():

    from collections import namedtuple
    Test = namedtuple('Test', 'input expected')
    tests = [ Test( input=dict(ok=1, failures=2, unreachable=3),
                    expected=dict(ok=1, failures=2, unreachable=3, changed=0, skipped=0, rescued=0, ignored=0)),
              Test( input=dict(changed=1, ignored=2),
                    expected=dict(ok=0, failures=0, unreachable=0, changed=1, skipped=0, rescued=0, ignored=2))
            ]

    stats = AggregateStats()
    for test in tests:
        stats.ok['test_host'] = test.input.get('ok', 0)
        stats.failures['test_host'] = test.input.get('failures', 0)

# Generated at 2022-06-20 14:29:37.505085
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats("test_dict", {"a": "b"})
    assert stats.custom["_run"]["test_dict"] == {"a": "b"}

    stats.update_custom_stats("test_dict", {"a": "c"})
    assert stats.custom["_run"]["test_dict"] == {"a": "c"}

    stats.update_custom_stats("test_dict", {"c": "d"})
    assert stats.custom["_run"]["test_dict"] == {"a": "c", "c": "d"}

    stats.update_custom_stats("test_dict2", "abc")
    assert stats.custom["_run"]["test_dict2"] == "abc"


# Generated at 2022-06-20 14:29:52.081869
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # create instance of AggregateStats
    stats = AggregateStats()

    # test update_custom_stats for dict
    stats.update_custom_stats('dict', {'a': 1}, 'host1')
    assert stats.custom == {'host1': {'dict': {'a': 1}}}

    stats.update_custom_stats('dict', {'a': 2}, 'host1')
    assert stats.custom == {'host1': {'dict': {'a': 3}}}

    stats.update_custom_stats('dict', {'b': 2}, 'host1')
    assert stats.custom == {'host1': {'dict': {'a': 3, 'b': 2}}}

    # test update_custom_stats for int
    stats.update_custom_stats('int', 1, 'host1')
    assert stats.custom

# Generated at 2022-06-20 14:29:55.426499
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg = AggregateStats()
    agg.set_custom_stats("test_key", "test_value")
    assert agg.custom["_run"] == {"test_key": "test_value"}


# Generated at 2022-06-20 14:30:00.525884
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg = AggregateStats()
    agg.increment('ok', 'test')
    assert agg.ok['test'] == 1
    agg.increment('ok', 'test')
    assert agg.ok['test'] == 2
    agg.increment('failures', 'test')
    assert agg.ok['test'] == 2
    assert agg.failures['test'] == 1
    agg.increment('failures', 'bla')
    assert agg.failures['bla'] == 1


# Generated at 2022-06-20 14:30:07.099908
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ag = AggregateStats()
    ag.ok = {'apple': 1}
    ag.decrement('ok', 'apple')
    assert ag.ok.get('apple', 0) == 0

# Generated at 2022-06-20 14:30:11.588754
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ignored', 'host1')
    assert stats.ignored.get('host1') == 1
    stats.decrement('ignored', 'host1')
    assert stats.ignored.get('host1') == 0

# Generated at 2022-06-20 14:30:15.088610
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    stats.increment("ok", "localhost")
    assert stats.ok == {"localhost": 1}
    stats.increment("ok", "localhost")
    assert stats.ok == {"localhost": 2}



# Generated at 2022-06-20 14:30:28.023025
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats("custom_stat1", 100, "localhost")
    assert stats.custom["localhost"]["custom_stat1"] == 100
    stats.set_custom_stats("custom_stat2", (1,2), "localhost")
    assert stats.custom["localhost"]["custom_stat2"] == (1,2)
    stats.set_custom_stats("custom_stat3", [1,2,3], "localhost")
    assert stats.custom["localhost"]["custom_stat3"] == [1,2,3]
    stats.set_custom_stats("custom_stat4", {"key": "value"}, "localhost")
    assert stats.custom["localhost"]["custom_stat4"] == {"key": "value"}


# Generated at 2022-06-20 14:30:33.951811
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    # Verify that when no operation is done, the statistics are all zero.
    stats = AggregateStats()
    assert stats.summarize('myhost') == dict(ok=0, failures=0, unreachable=0,
                                             changed=0, skipped=0, rescued=0,
                                             ignored=0)

    # Increment each statistic.
    #
    # FIXME: This is not DRY; we should instead call increment()
    # instead of accessing the dictionary directly.
    stats.increment('ok', 'myhost')
    stats.increment('failures', 'myhost')
    stats.increment('dark', 'myhost')
    stats.increment('changed', 'myhost')
    stats.increment('skipped', 'myhost')
    stats.increment('rescued', 'myhost')
   

# Generated at 2022-06-20 14:30:42.703858
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    '''
    Just a sample test
    '''

    stats = AggregateStats()
    stats.increment('ignored', 'localhost')
    stats.increment('ignored', '127.0.0.1')
    stats.increment('ignored', 'localhost')
    stats.increment('ignored', '127.0.0.1')

    assert stats.ignored['localhost'] == 2
    assert stats.ignored['127.0.0.1'] == 2


# Generated at 2022-06-20 14:30:52.882716
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg = AggregateStats()

    assert type(agg.custom) == dict
    assert type(agg.dark) == dict
    assert type(agg.failures) == dict
    assert type(agg.ok) == dict
    assert type(agg.changed) == dict
    assert type(agg.skipped) == dict
    assert type(agg.rescued) == dict
    assert type(agg.ignored) == dict

    assert type(agg.increment) == type(AggregateStats.increment)
    assert type(agg.decrement) == type(AggregateStats.decrement)
    assert type(agg.summarize) == type(AggregateStats.summarize)
    assert type(agg.set_custom_stats) == type(AggregateStats.set_custom_stats)

# Generated at 2022-06-20 14:31:05.782900
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats('which', 'what')
    assert aggregate_stats.custom == {'_run': {'which': 'what'}}
    assert aggregate_stats.custom['_run'] == {'which': 'what'}

    aggregate_stats.set_custom_stats('new_which', 'new_what')
    assert aggregate_stats.custom == {'_run': {'new_which': 'new_what', 'which': 'what'}}
    assert aggregate_stats.custom['_run'] == {'new_which': 'new_what', 'which': 'what'}

    aggregate_stats.set_custom_stats('new_which', 'new_what', 'hostname')

# Generated at 2022-06-20 14:31:10.460327
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'foo')
    assert(stats.ok['foo'] == 1)
    stats.decrement('ok', 'foo')
    assert(stats.ok['foo'] == 0)
    stats.increment('ok', 'foo')
    assert(stats.ok['foo'] == 1)
    stats.decrement('ok', 'foo')
    assert(stats.ok['foo'] == 0)

# Generated at 2022-06-20 14:31:16.957843
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host')
    stats.increment('ok', 'host')
    assert stats.ok['host'] == 2
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 1
    # The following should never happen but let's be safe
    stats.decrement('ok', 'host')
    assert not stats.ok['host'] < 0