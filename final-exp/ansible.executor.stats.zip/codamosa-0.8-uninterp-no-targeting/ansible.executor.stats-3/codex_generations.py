

# Generated at 2022-06-20 14:26:02.102252
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    stats.ok = {'test': 1}
    stats.decrement('ok', 'test')
    assert stats.ok.get('test') == 0, "Check decrement for 'ok' stat for host 'test'"

    stats.ok = {'test': 0}
    stats.decrement('ok', 'test')
    assert stats.ok.get('test') == 0, "Check decrement for 'ok' stat for host 'test'"

# Generated at 2022-06-20 14:26:09.630059
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    a = AggregateStats()
    a.decrement("ok", "test")
    assert a.ok == { "test": 0 }
    a.ok["test2"] = 1
    a.decrement("ok", "test2")
    assert a.ok == {"test": 0, "test2": 0}


# Generated at 2022-06-20 14:26:21.080715
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggr_stats = AggregateStats()
    aggr_stats.increment('ok', 'testhost')
    aggr_stats.increment('ok', 'testhost')
    aggr_stats.increment('ok', 'testhost')
    aggr_stats.increment('ok', 'test2host')
    aggr_stats.increment('ok', 'test2host')
    assert aggr_stats.summarize('testhost') == {'ok': 3, 'changed': 0, 'dark': 0, 'failures': 0, 'ignored': 0, 'rescued': 0, 'skipped': 0}, \
        'Summarize should return correct value'

# Generated at 2022-06-20 14:26:25.534615
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    assert issubclass(AggregateStats, object)

test_AggregateStats()

# Generated at 2022-06-20 14:26:32.499989
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():

    aggregate_stats = AggregateStats()
    aggregate_stats.ok['hostname'] = 1
    aggregate_stats.ignored['hostname'] = 1
    aggregate_stats.changed['hostname'] = 1
    aggregate_stats.failures['hostname'] = 1
    assert aggregate_stats.summarize('hostname') == {'ok': 1, 'failures': 1, 'unreachable': 0, 'changed': 1, 'skipped': 0, 'rescued': 0, 'ignored': 1}

# Generated at 2022-06-20 14:26:39.528673
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    stats.increment('ok', 'foo')
    assert stats.ok['foo'] == 1
    assert stats.ok.get('bar') is None

    stats.increment('failures', 'foo')
    assert stats.failures['foo'] == 1

    stats.increment('ok', 'foo')
    assert stats.ok['foo'] == 2

    # It's incremented to 1
    assert stats.processed['foo'] == 1


# Generated at 2022-06-20 14:26:40.799453
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    assert AggregateStats().increment("what", "host") is None

# Generated at 2022-06-20 14:26:47.489816
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()

    aggregate_stats.update_custom_stats('foo', 1, 'localhost')
    assert aggregate_stats.custom == dict(localhost=dict(foo=1))

    aggregate_stats.update_custom_stats('foo', 2, 'localhost')
    assert aggregate_stats.custom == dict(localhost=dict(foo=3))

    aggregate_stats.update_custom_stats('bar', "bar")
    assert aggregate_stats.custom == dict(
        _run=dict(bar="bar"),
        localhost=dict(foo=3),
    )

    aggregate_stats.update_custom_stats('bar', "foo")
    assert aggregate_stats.custom == dict(
        _run=dict(bar="foobar"),
        localhost=dict(foo=3),
    )

    aggregate_stats.update

# Generated at 2022-06-20 14:26:59.176382
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    a_stats = AggregateStats()
    a_stats.update_custom_stats('which', 'what', 'host')
    assert a_stats.custom.get('host_run') == None, 'Should return None'
    a_stats.update_custom_stats('which', {'key0':'value0'}, 'host')
    assert a_stats.custom.get('host_run') != None, 'Should return not None'
    a_stats.set_custom_stats('which', {'key1':'value1'}, 'host')
    result = {'which': {'key0': 'value0', 'key1': 'value1'}}
    assert a_stats.custom.get('host_run') == result, 'Should return {}'.format(result)

# Generated at 2022-06-20 14:27:09.932092
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    tqm = None

# Generated at 2022-06-20 14:27:21.995900
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert isinstance(stats, AggregateStats)
    assert isinstance(stats.processed, dict)
    assert isinstance(stats.failures, dict)
    assert isinstance(stats.ok, dict)
    assert isinstance(stats.dark, dict)
    assert isinstance(stats.changed, dict)
    assert isinstance(stats.skipped, dict)
    assert isinstance(stats.rescued, dict)
    assert isinstance(stats.ignored, dict)
    assert isinstance(stats.custom, dict)


# Generated at 2022-06-20 14:27:24.979172
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregateStats = AggregateStats()
    aggregateStats.ok = {'a':3}
    aggregateStats.decrement('ok', 'a')
    assert aggregateStats.ok['a'] == 2


# Generated at 2022-06-20 14:27:30.824928
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()

    aggregate_stats.set_custom_stats('test', 1000)
    assert aggregate_stats.custom.get('_run', None).get('test', None) == 1000

    aggregate_stats.set_custom_stats('test', 500, 'DUMMY')
    assert aggregate_stats.custom.get('DUMMY', None).get('test', None) == 500

# Generated at 2022-06-20 14:27:32.830891
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregatestats = AggregateStats()
    aggregatestats.increment('ok', 'testhost')
    aggregatestats.increment('ok', 'testhost')
    aggregatestats.increment('changed', 'testhost')

    assert aggregatestats.ok['testhost'] == 2
    assert aggregatestats.changed['testhost'] == 1


# Generated at 2022-06-20 14:27:43.091731
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    '''
    Test input types for aggregate stats update method
    '''
    results = AggregateStats()
    stats = {'foo': 2, 'bar': 1}

    # test default host
    results.update_custom_stats('stats', stats)
    assert results.custom['_run']['stats'] == stats

    # test dict
    stats2 = {'foo': 1, 'baz': 3}
    results.update_custom_stats('stats', stats2)
    stats['foo'] += stats2['foo']
    stats['baz'] = stats2['baz']
    assert results.custom['_run']['stats'] == stats

    # test int
    results.update_custom_stats('stats', 3)
    stats['foo'] += 3
    stats['baz'] += 3

# Generated at 2022-06-20 14:27:54.300738
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggr_stats = AggregateStats()
    aggr_stats.increment('ok', 'host1')
    aggr_stats.increment('failures', 'host1')
    aggr_stats.increment('dark', 'host2')
    aggr_stats.increment('changed', 'host3')
    aggr_stats.increment('skipped', 'host4')
    aggr_stats.increment('rescued', 'host5')
    aggr_stats.increment('ignored', 'host6')
    assert aggr_stats.summarize('host1') == {'ok':1, 'failures':1, 'unreachable':0, 'changed':0, 'skipped':0, 'rescued':0, 'ignored':0}

# Generated at 2022-06-20 14:28:02.004392
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    x = AggregateStats()
    assert len(x.processed) == 0
    assert len(x.failures) == 0
    assert len(x.ok) == 0
    assert len(x.dark) == 0
    assert len(x.changed) == 0
    assert len(x.skipped) == 0
    assert len(x.rescued) == 0
    assert len(x.ignored) == 0
    assert len(x.custom) == 0


# Generated at 2022-06-20 14:28:07.208062
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-20 14:28:17.881996
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0

if __name__ == "__main__":
    import os
    import sys
    import unittest
    sys.path.insert(0, os.path.abspath('..'))
    from test.compat import mock
    from ansible.utils.stats import AggregateStats
    from ansible.playbook.task_include import TaskInclude

    class TestCase(unittest.TestCase):
        def test_AggregateStats_decrement(self):
            stats = AggregateStats()
            stats.decrement('ok', 'host1')
            assert stats.ok['host1'] == 0

# Generated at 2022-06-20 14:28:28.055233
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():

    # Execute AggregateStats.summarize()
    aggregate_stats = AggregateStats()
    aggregate_stats.increment("ok", "127.0.0.1")
    aggregate_stats.increment("ok", "127.0.0.1")
    aggregate_stats.increment("ok", "127.0.0.1")
    aggregate_stats.increment("changed", "127.0.0.1")
    aggregate_stats.increment("failures", "127.0.0.1")
    aggregate_stats.increment("dark", "127.0.0.1")
    aggregate_stats.increment("skipped", "127.0.0.1")
    aggregate_stats.increment("rescued", "127.0.0.1")

# Generated at 2022-06-20 14:28:41.530643
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
        '''
        unit test for method update_custom_stats of class AggregateStats
        '''
        stats = AggregateStats()
        stats.update_custom_stats('test_key', {'test_dict_key': 1})
        assert stats.custom['_run']['test_key'] == {'test_dict_key': 1}, \
            "custom stat not updated with test_dict_key"
        stats.update_custom_stats('test_key', {'test_dict_key': 2})
        assert stats.custom['_run']['test_key'] == {'test_dict_key': 3}, \
            "custom stat not merged with test_dict_key"
        stats.update_custom_stats('test_key', 3)

# Generated at 2022-06-20 14:28:50.667424
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats("test", "a", "localhost")
    assert stats.custom["localhost"]["test"] == "a"
    stats.update_custom_stats("test", "b", "localhost")
    assert stats.custom["localhost"]["test"] == "ab"
    stats.update_custom_stats("test", "c", "localhost")
    assert stats.custom["localhost"]["test"] == "abc"
    assert stats.custom["localhost"]["test"] == "abc"
    stats.update_custom_stats("test", 3, "localhost")
    assert stats.custom["localhost"]["test"] == "abc3"
    stats.update_custom_stats("test", 3.0, "localhost")

# Generated at 2022-06-20 14:28:54.422962
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ag = AggregateStats()
    ag.ok = {'host1': 0}
    ag.decrement('ok', 'host1')
    assert ag.ok['host1'] == 0

# Generated at 2022-06-20 14:29:04.011983
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import pytest

    # Check updating custom stat of non-existing host
    stats = AggregateStats()
    stats.update_custom_stats(which='foo', what={'bar': 'baz'})
    assert stats.custom.get('_run', {}) == {'foo': {'bar': 'baz'}}

    # Check updating custom stat of existing host
    stats = AggregateStats()
    stats.custom = {'foo': {'bar': 'baz'}}
    stats.update_custom_stats(which='bar', what={'baz': 'foo'})
    assert stats.custom == {'foo': {'bar': {'baz': 'foo'}}}

    # Check updating custom stat of existing host
    stats = AggregateStats()
    stats.custom = {'foo': {'bar': 'baz'}}


# Generated at 2022-06-20 14:29:09.448100
# Unit test for constructor of class AggregateStats
def test_AggregateStats():

    a = AggregateStats()
    assert (a.__dict__ == {'processed': {}, 'custom': {}, 'failures': {}, 'ok': {},
                           'dark': {}, 'changed': {}, 'skipped': {}, 'rescued': {}, 'ignored': {}})
    return

# Generated at 2022-06-20 14:29:19.464048
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stat = AggregateStats()
    stat.ok['host_test'] = 4

    stat.decrement('ok', 'host_test')
    assert stat.ok['host_test'] == 3
    stat.decrement('ok', 'host_test')
    assert stat.ok['host_test'] == 2
    stat.decrement('ok', 'host_test')
    assert stat.ok['host_test'] == 1
    stat.decrement('ok', 'host_test')
    assert stat.ok['host_test'] == 0
    stat.decrement('ok', 'host_test')
    assert stat.ok['host_test'] == 0

# Generated at 2022-06-20 14:29:34.676922
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    # Test standard operation
    host = 'test1'
    test_stats = AggregateStats()
    test_stats.increment('ok', host) 
    assert(test_stats.processed == {host: 1})
    assert(test_stats.ok == {host: 1})

    # Test failing operation
    test_stats = AggregateStats()
    test_stats.increment('failures', host) 
    assert(test_stats.processed == {host: 1})
    assert(test_stats.failures == {host: 1})

    # Test non-existent class member
    test_stats = AggregateStats()
    test_stats.increment('hackerz', host) 
    assert(test_stats.processed == {host: 1})
    assert(test_stats.hackerz == {host: 1})

# Generated at 2022-06-20 14:29:42.208936
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    s = AggregateStats()
    s.update_custom_stats("test", 10)
    assert s.custom['_run']['test'] == 10

    s.update_custom_stats("test", 10)
    assert s.custom['_run']['test'] == 20

    s.update_custom_stats("test3", {'a': 1, 'b': 2})
    assert s.custom['_run']['test3'] == {'a': 1, 'b': 2}

    s.update_custom_stats("test3", {'c': 3, 'd': 4})
    assert s.custom['_run']['test3'] == {'a': 1, 'b': 2, 'c': 3, 'd': 4}

    s.update_custom_stats("test4", [1, 2])
   

# Generated at 2022-06-20 14:29:47.345166
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    a = AggregateStats()
    assert a.processed == {}
    assert a.failures == {}
    assert a.ok == {}
    assert a.dark == {}
    assert a.changed == {}
    assert a.skipped == {}
    assert a.rescued == {}
    assert a.ignored == {}
    assert a.custom == {}


if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-v'])

# Generated at 2022-06-20 14:29:56.407507
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.custom == {}


# Generated at 2022-06-20 14:30:09.486796
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.failures = {'host1':1, 'host2':2}
    stats.dark = {'host2':1}
    host_summary = stats.summarize('host1')
    assert host_summary == dict(
        ok=0,
        failures=1,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0
    )

    host_summary = stats.summarize('host2')
    assert host_summary == dict(
        ok=0,
        failures=2,
        unreachable=1,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0
    )

    host_summary = stats.summarize(None)

# Generated at 2022-06-20 14:30:19.605122
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('changed', 'localhost')
    assert stats.summarize('localhost') == {'ok': 4, 'failures': 1, 'unreachable': 0, 'changed': 1, 'skipped': 0,
                                            'rescued': 0, 'ignored': 0}

# Generated at 2022-06-20 14:30:27.558901
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok['localhost'] = 1
    stats.dark['localhost'] = 1
    stats.changed['localhost'] = 1
    stats.skipped['localhost'] = 1
    stats.rescued['localhost'] = 1
    stats.ignored['localhost'] = 1
    stats.failures['localhost'] = 1
    stats.custom = {'_run': {'foo': 'bar'}}
    data = stats.summarize('localhost')
    assert data == {
        'ok': 1, 'changed': 1, 'failures': 1, 'unreachable': 1, 'skipped': 1,
        'rescued': 1, 'ignored': 1}


# Generated at 2022-06-20 14:30:30.657132
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('failures', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('ok', 'localhost')
    assert stats.failures == {'localhost': 2}, stats.failures

# Generated at 2022-06-20 14:30:45.662693
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggstats = AggregateStats()
    assert aggstats is not None, "Failed to create AggregateStats"
    assert len(aggstats.processed) == 0, "processed should be empty"
    assert len(aggstats.failures) == 0, "failures should be empty"
    assert len(aggstats.ok) == 0, "ok should be empty"
    assert len(aggstats.dark) == 0, "dark should be empty"
    assert len(aggstats.changed) == 0, "changed should be empty"
    assert len(aggstats.skipped) == 0, "skipped should be empty"
    assert len(aggstats.rescued) == 0, "rescued should be empty"
    assert len(aggstats.ignored) == 0, "ignored should be empty"


# Generated at 2022-06-20 14:30:53.003355
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'host_1')
    aggregate_stats.increment('ok', 'host_1')
    aggregate_stats.increment('ok', 'host_2')
    aggregate_stats.increment('failures', 'host_2')
    aggregate_stats.increment('dark', 'host_3')
    aggregate_stats.increment('changed', 'host_1')
    aggregate_stats.increment('changed', 'host_3')
    aggregate_stats.increment('skipped', 'host_3')
    aggregate_stats.increment('rescued', 'host_3')
    aggregate_stats.increment('ignored', 'host_4')


# Generated at 2022-06-20 14:31:02.758140
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate = AggregateStats()
    aggregate.set_custom_stats('changed', True) # host is None
    assert '_run' in aggregate.custom, "Host is not set to '_run'"
    assert aggregate.custom['_run']['changed'], "AggregateStats.set_custom_stats is not working"

    aggregate.custom = {}
    aggregate.set_custom_stats('changed', True, 'localhost')
    assert 'localhost' in aggregate.custom, "Host is not set to 'localhost'"
    assert aggregate.custom['localhost']['changed'], "AggregateStats.set_custom_stats is not working"


# Generated at 2022-06-20 14:31:11.217782
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    oAggregateStats = AggregateStats()
    oAggregateStats.increment("failures", "10.23.1.1")
    assert oAggregateStats.processed == {"10.23.1.1": 1}
    assert oAggregateStats.failures == {"10.23.1.1": 1}
    assert oAggregateStats.ok == {}
    assert oAggregateStats.dark == {}
    assert oAggregateStats.changed == {}
    assert oAggregateStats.skipped == {}
    assert oAggregateStats.rescued == {}
    assert oAggregateStats.ignored == {}
    assert oAggregateStats.custom == {}
    oAggregateStats.increment("processed", "10.23.1.1")

# Generated at 2022-06-20 14:31:22.643127
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate = AggregateStats()
    aggregate.ok['host1'] = 10
    aggregate.failures['host1'] = 2
    aggregate.dark['host1'] = 1
    aggregate.changed['host1'] = 3
    aggregate.skipped['host1'] = 4
    aggregate.rescued['host1'] = 5
    aggregate.ignored['host1'] = 6

    summary = aggregate.summarize('host1')

    assert summary['ok'] == 10
    assert summary['failures'] == 2
    assert summary['unreachable'] == 1
    assert summary['changed'] == 3
    assert summary['skipped'] == 4
    assert summary['rescued'] == 5
    assert summary['ignored'] == 6


# Generated at 2022-06-20 14:31:32.027803
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    agg_stats = AggregateStats()
    agg_stats.update_custom_stats('Value1', 'Custom_Stat_1')
    agg_stats.update_custom_stats('Value1', 100, 'host1')
    agg_stats.update_custom_stats('Value2', 'Custom_Stat_2', 'host1')
    agg_stats.update_custom_stats('Value2', 200, 'host1')
    agg_stats.update_custom_stats('Value2', {'val1': 1, 'val2': 2, 'val3': 3}, 'host1')
    agg_stats.update_custom_stats('Value3', {'val1': 1, 'val2': 2, 'val3': 3, 'val4': 4}, 'host1')

# Generated at 2022-06-20 14:31:45.082549
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('skipped', 'localhost')
    stats.increment('skipped', 'localhost')
    stats.increment('skipped', 'localhost')

    assert stats.skipped['localhost'] == 3

    return True


# Generated at 2022-06-20 14:31:56.080877
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    class Test:
        def __init__(self, expected_result):
            self.expected_result = expected_result
            self.counter = 0

    # Test for combining int and string
    int_obj = Test(3)
    str_obj = Test('foobar')
    stats = AggregateStats()
    stats.set_custom_stats('test_int', int_obj)
    stats.set_custom_stats('test_str', str_obj)
    stats.update_custom_stats('test_int', 1)
    stats.update_custom_stats('test_int', 1)
    stats.update_custom_stats('test_int', 1)
    stats.update_custom_stats('test_str', 'bar')
    stats.update_custom_stats('test_str', 'foo')

# Generated at 2022-06-20 14:32:10.216552
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():

    aggregate = AggregateStats()
    aggregate.set_custom_stats('custom_a', 'custom_a_value', '192.168.1.1')
    aggregate.set_custom_stats('custom_a', 'custom_a_value')
    aggregate.set_custom_stats('custom_b', ['a', 'b', 'c'], '192.168.1.1')
    aggregate.set_custom_stats('custom_b', ['d', 'e', 'f'])

    assert aggregate.custom['192.168.1.1']['custom_a'] == 'custom_a_value'
    assert aggregate.custom['_run']['custom_a'] == 'custom_a_value'
    assert aggregate.custom['192.168.1.1']['custom_b'] == ['a', 'b', 'c']

# Generated at 2022-06-20 14:32:18.450469
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('changed', 'host2')
    stats.increment('dark', 'host1')
    stats.increment('ok', 'host1')

    assert stats.summarize('host1') == dict(
        ok=2, failures=0, unreachable=1, changed=0, skipped=0, rescued=0, ignored=0)
    assert stats.summarize('host2') == dict(
        ok=1, failures=0, unreachable=0, changed=1, skipped=0, rescued=0, ignored=0)

# Generated at 2022-06-20 14:32:22.346915
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    a = AggregateStats()

    assert isinstance(a.ok, dict)
    assert isinstance(a.dark, dict)
    assert isinstance(a.changed, dict)
    assert isinstance(a.skipped, dict)
    assert isinstance(a.rescued, dict)
    assert isinstance(a.ignored, dict)



# Generated at 2022-06-20 14:32:26.341669
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    assert stats.summarize('host1')['ok'] == 2
    assert stats.summarize('host2')['ok'] == 1


# Generated at 2022-06-20 14:32:34.993926
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    # Constructor should create instance of class AggregateStats
    a = AggregateStats()
    assert a

    # newly created object should contain all expected instance variables
    assert a.processed
    assert a.failures
    assert a.ok
    assert a.dark
    assert a.changed
    assert a.skipped
    assert a.rescued
    assert a.ignored
    assert a.custom



# Generated at 2022-06-20 14:32:37.441208
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggrstats = AggregateStats()
    aggrstats.decrement('ok', 'testhost')
    assert aggrstats.ok['testhost'] == 0



# Generated at 2022-06-20 14:32:41.127616
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    expected = dict(processed={}, failures={}, ok={}, dark={}, changed={}, skipped={}, rescued={}, ignored={}, custom={})
    actual = AggregateStats()
    assert expected == actual.__dict__, "Test AggregateStats constructor"


# Generated at 2022-06-20 14:32:54.046215
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    def _merge_hash(dict_a, dict_b):
        merged = dict_a.copy()
        for k in dict_b:
            if isinstance(dict_b[k], MutableMapping):
                merged[k] = _merge_hash(merged.get(k, {}), dict_b[k])
            else:
                merged[k] = dict_b[k]
        return merged

    aggr_stats = AggregateStats()
    aggr_stats.update_custom_stats('a', {'b': 1})
    aggr_stats.update_custom_stats('a', {'b': 1})
    aggr_stats.update_custom_stats('a', {'b': {'c': 1}})

# Generated at 2022-06-20 14:33:26.114788
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    stats.increment("failures", "host")
    stats.increment("ok", "host")
    stats.increment("dark", "host")
    stats.increment("changed", "host")
    stats.increment("skipped", "host")
    stats.increment("rescued", "host")
    stats.increment("ignored", "host")
    stats.increment("ok", "host")
    stats.increment("dark", "host")
    stats.increment("changed", "host")
    stats.increment("ok", "host")
    stats.increment("ok", "host")
    stats.increment("ok", "host")
    stats.increment("failures", "host")

    stats.set_custom_stats("my_custom_stat","value")

# Generated at 2022-06-20 14:33:30.515810
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    host = "127.0.0.1"
    stats.increment("changed", host)
    assert stats.changed[host] == 1
    stats.increment("changed", host)
    assert stats.changed[host] == 2
    stats.increment("ok", host)
    assert stats.ok[host] == 1
    assert stats.changed[host] == 2
    assert stats.processed[host] == 1


# Generated at 2022-06-20 14:33:33.979377
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()

    host = 'localhost'

    # Add stats
    aggregate_stats.increment('ok', host)
    aggregate_stats.increment('ok', host)
    aggregate_stats.increment('failures', host)
    aggregate_stats.increment('dark', host)
    aggregate_stats.increment('changed', host)
    aggregate_stats.increme

# Generated at 2022-06-20 14:33:44.010419
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok['server01'] = 2
    stats.failures['server01'] = 5
    stats.dark['server01'] = 1
    stats.changed['server01'] = 8
    stats.skipped['server01'] = 0
    stats.rescued['server01'] = 2
    stats.ignored['server01'] = 2

    expected = dict(
        ok=2,
        failures=5,
        unreachable=1,
        changed=8,
        skipped=0,
        rescued=2,
        ignored=2,
    )
    assert expected == stats.summarize("server01")
    

# Generated at 2022-06-20 14:33:47.833430
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    testObj = AggregateStats()
    testObj.increment("rescued", "localhost")
    assert testObj.rescued["localhost"] == 1

    testObj.decrement("rescued", "localhost")
    assert testObj.rescued["localhost"] == 0

    testObj.decrement("rescued", "localhost")
    assert testObj.rescued["localhost"] == 0


# Generated at 2022-06-20 14:33:48.442751
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    assert AggregateStats().processed == {}

# Generated at 2022-06-20 14:33:53.256573
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    stats.set_custom_stats(which="a", what=1, host="b")
    stats.set_custom_stats(which="b", what=1, host="b")

    assert stats.custom['b']['a'] == 1
    assert stats.custom['b']['b'] == 1

    stats.update_custom_stats(which="a", what=1, host="b")

    assert stats.custom['b']['a'] == 2
    assert stats.custom['b']['b'] == 1

    stats.update_custom_stats(which="a", what=[1, 2], host="b")

    assert stats.custom['b']['a'] == [1, 2, 1]
    assert stats.custom['b']['b'] == 1

    stats.update_

# Generated at 2022-06-20 14:33:54.421164
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    aggrega

# Generated at 2022-06-20 14:34:00.725155
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()

    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-20 14:34:04.953611
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert isinstance(stats, AggregateStats)