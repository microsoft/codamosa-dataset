

# Generated at 2022-06-20 14:25:58.498515
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    '''
    Function to test stats aggregation
    '''
    stats = AggregateStats()
    stats.increment("ok", "localhost")
    assert stats.ok.get("localhost") == 1

# Generated at 2022-06-20 14:26:05.487095
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg = AggregateStats()
    agg.increment('dark', 'host1')
    agg.increment('dark', 'host1')
    agg.increment('dark', 'host2')
    assert agg.processed['host1'] == 1
    assert agg.processed['host2'] == 1
    assert agg.dark['host1'] == 2
    assert agg.dark['host2'] == 1
    assert agg.ok == {}


# Generated at 2022-06-20 14:26:15.105519
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    '''
    test the method update_custom_stats of class AggregateStats
    This test cover the cases:

    * host not in self.custom

    * host in self.custom, but which not in self.custom[host]

    * types of which and what don't match

    * type of what is MutableMapping

    * type of what is not MutableMapping
    '''

    import types
    import copy

    # 1. host not in self.custom
    stats = AggregateStats()
    stats.update_custom_stats('which0', 'what0')
    assert stats.custom['_run']['which0'] == 'what0'

    # 2. host in self.custom, but which not in self.custom[host]
    stats.update_custom_stats('which0', 'what1', 'host1')


# Generated at 2022-06-20 14:26:21.212563
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregateStats = AggregateStats()
    aggregateStats.skipped['host'] = 2
    aggregateStats.decrement('skipped', 'host')
    print(aggregateStats.skipped['host'])
    assert aggregateStats.skipped['host'] == 1
    assert 'host' in aggregateStats.skipped


# Generated at 2022-06-20 14:26:34.342874
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():

    stats = AggregateStats()
    stats.increment('changed', 'test1')
    stats.increment('changed', 'test1')
    stats.increment('ok', 'test1')
    stats.increment('ok', 'test1')
    stats.increment('ok', 'test1')
    stats.increment('failures', 'test1')
    stats.increment('ok', 'test2')
    stats.increment('ok', 'test2')
    stats.increment('ok', 'test2')
    stats.increment('failures', 'test2')
    summary = stats.summarize('test1')
    assert summary['ok'] == 3
    assert summary['changed'] == 2
    assert summary['failures'] == 1
    assert summary['unreachable'] == 0

# Generated at 2022-06-20 14:26:42.848052
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    from ansible.plugins.callbacks import AggregateStats
    m_stats = AggregateStats()
    m_stats.increment('ok', 'www1')
    m_stats.increment('ok', 'www1')
    m_stats.increment('ok', 'www2')
    m_stats.increment('changed', 'www2')
    m_stats.increment('failures', 'www3')
    m_stats.increment('skipped', 'www3')
    d = m_stats.summarize('www1')
    assert d['ok'] == 2 and d['failures'] == 0
    assert d['skipped'] == 0 and d['changed'] == 0
    d = m_stats.summarize('www2')
    assert d['ok'] == 1 and d['changed'] == 1
    assert d

# Generated at 2022-06-20 14:26:48.982301
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate = AggregateStats()
    # Verify updates on string
    aggregate.update_custom_stats('foo', 'bar')
    assert aggregate.custom['_run']['foo'] == 'bar'
    aggregate.update_custom_stats('foo', 'baz')
    assert aggregate.custom['_run']['foo'] == 'baz'
    # Verify updates on number
    aggregate.update_custom_stats('foo', 100)
    assert aggregate.custom['_run']['foo'] == 100
    aggregate.update_custom_stats('foo', 200)
    assert aggregate.custom['_run']['foo'] == 200
    # Verify updates on dict
    aggregate.update_custom_stats('foo', {'bar': 'baz', 'baz': 17})

# Generated at 2022-06-20 14:27:00.984720
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    a = AggregateStats()
    a.update_custom_stats('a', 1)
    assert a.custom == {'_run': {'a': 1}}

    a.update_custom_stats('b', 2)
    assert a.custom == {'_run': {'a': 1, 'b': 2}}

    a.update_custom_stats('a', 3)
    assert a.custom == {'_run': {'a': 4, 'b': 2}}

    a.update_custom_stats('a', {'c': 3})
    assert a.custom == {'_run': {'a': 4, 'b': 2, 'c': 3}}

    a.update_custom_stats('a', {'d': 4})

# Generated at 2022-06-20 14:27:10.827966
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    import pytest
    aggregateStats = AggregateStats()
    aggregateStats.increment('ok', 'testHost1')
    aggregateStats.increment('ok', 'testHost2')
    aggregateStats.increment('failures', 'testHost1')
    aggregateStats.increment('failures', 'testHost2')
    aggregateStats.increment('failures', 'testHost2')
    aggregateStats.increment('dark', 'testHost1')
    aggregateStats.increment('changed', 'testHost1')
    summarizeInfo = aggregateStats.summarize('testHost1')
    assert summarizeInfo['ok'] == 1
    assert summarizeInfo['failures'] == 1
    assert summarizeInfo['unreachable'] == 1
    assert summarizeInfo['changed'] == 1
    assert summarizeInfo['skipped'] == 0

    # Make sure testHost2

# Generated at 2022-06-20 14:27:23.388094
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('field_1', [1, 'A'])
    stats.update_custom_stats('field_1', [2, 'B'])
    assert stats.custom['_run']['field_1'] == [1, 'A', 2, 'B']
    stats.set_custom_stats('field_2', [5, 'C'])
    stats.update_custom_stats('field_2', [5, 'C'])
    assert stats.custom['_run']['field_2'] == [5, 'C', 5, 'C']
    stats.set_custom_stats('field_3', {'A': 0, 'B': 1})
    stats.update_custom_stats('field_3', {'B': 10, 'C': 11})
   

# Generated at 2022-06-20 14:27:36.144473
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    hstat = AggregateStats()

    hstat.increment('changed', 'a')
    hstat.increment('ok', 'a')

    hstat.increment('changed', 'b')
    hstat.increment('ok', 'b')

    hstat.increment('failures', 'c')

    hstat.increment('ok', 'c')
    hstat.increment('skipped', 'c')
    hstat.increment('skipped', 'c')

    hstat.increment('failures', 'd')

    hstat.increment('ok', 'd')
    hstat.increment('skipped', 'd')
    hstat.increment('skipped', 'd')
    hstat.increment('skipped', 'd')
    hstat.increment('skipped', 'd')



# Generated at 2022-06-20 14:27:44.106990
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Test for set custom stats
    aS = AggregateStats()
    aS.update_custom_stats('stats1', [1,2,3])
    assert aS.custom['_run']['stats1'] == [1,2,3]
    aS.update_custom_stats('stats2', {'a':'b'})
    assert aS.custom['_run']['stats2'] == {'a':'b'}
    aS.update_custom_stats('stats3', {'a':'b'}, host='web01')
    assert aS.custom['web01']['stats3'] == {'a':'b'}

    # Test for merge of custom stats
    aS.update_custom_stats('stats1', [4,5,6], host='web01')
    assert a

# Generated at 2022-06-20 14:27:50.272737
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    a = AggregateStats()
    assert a is not None
    assert a.processed == {}
    assert a.failures == {}
    assert a.ok == {}
    assert a.dark == {}
    assert a.changed == {}
    assert a.skipped == {}
    assert a.rescued == {}
    assert a.ignored == {}
    assert a.custom == {}


# Generated at 2022-06-20 14:28:01.925654
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('skipped', 'test_host')
    assert(stats.processed['test_host'] == 1)
    assert(stats.skipped['test_host'] == 1)

    # Decrement the skipped counter for 'test_host'
    stats.decrement('skipped', 'test_host')
    assert(stats.skipped['test_host'] == 0)

    # Decrement again, this should not have any effect
    stats.decrement('skipped', 'test_host')
    assert(stats.skipped['test_host'] == 0)

    # Test that decrementing to negative values is not allowed
    stats.skipped['test_host'] = -1
    stats.decrement('skipped', 'test_host')

# Generated at 2022-06-20 14:28:08.477152
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    ''' test_AggregateStats_set_custom_stats '''

    stats = AggregateStats()
    stats.set_custom_stats('foo', 1, 'host1')
    stats.set_custom_stats('foo', 2, 'host2')
    stats.set_custom_stats('foo', 3)
    assert stats.custom == { 'host1': {'foo': 1}, 'host2': {'foo': 2}, '_run': {'foo': 3}}

    stats = AggregateStats()
    stats.set_custom_stats('foo', {'key1': 1, 'key2': 2}, 'host1')
    stats.set_custom_stats('foo', {'key2': 3, 'key3': 4}, 'host2')

# Generated at 2022-06-20 14:28:12.450899
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-20 14:28:22.685551
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.ok["localhost"] = 1
    aggregate_stats.decrement("ok", "localhost")
    assert aggregate_stats.ok["localhost"] == 0

    aggregate_stats.ok["localhost"] = 0
    aggregate_stats.decrement("ok", "localhost")
    assert aggregate_stats.ok["localhost"] == 0

    aggregate_stats.ok["localhost"] = 1
    aggregate_stats.decrement("ok", "otherhost")
    assert aggregate_stats.ok["localhost"] == 1
    assert "otherhost" not in aggregate_stats.ok

# Generated at 2022-06-20 14:28:33.372917
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    print("Start of test_AggregateStats_update_custom_stats")
    def check(test_name, stats, host, custom_key, result, check_type):
        assert(check_type == type(result)), "Check Type is {} expected {}".format(type(result), check_type)
        stats.update_custom_stats(custom_key, result, host=host)
        assert(custom_key in stats.custom[host]), "{} Test failed: {}".format(test_name, stats.custom[host])
        assert(result == stats.custom[host][custom_key]), "{} Test failed: {}".format(test_name, stats.custom[host][custom_key])
        print("{} Test passed: {}".format(test_name, stats.custom[host]))

    stats = AggregateStats()

    # Test different

# Generated at 2022-06-20 14:28:44.427361
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate = AggregateStats()

    assert aggregate.processed == {}
    assert aggregate.failures == {}
    assert aggregate.ok == {}
    assert aggregate.dark == {}
    assert aggregate.changed == {}
    assert aggregate.skipped == {}
    assert aggregate.rescued == {}
    assert aggregate.ignored == {}
    assert aggregate.custom == {}

    aggregate.increment('failures', 'test')

    assert aggregate.processed == {'test': 1}
    assert aggregate.failures == {'test': 1}
    assert aggregate.ok == {}
    assert aggregate.dark == {}
    assert aggregate.changed == {}
    assert aggregate.skipped == {}
    assert aggregate.rescued == {}
    assert aggregate.ignored == {}
    assert aggregate.custom == {}

    aggregate.increment('failures', 'test')

# Generated at 2022-06-20 14:28:53.921255
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    s = AggregateStats()
    s.increment("ok", "host1")
    assert s.ok["host1"] == 1
    s.increment("ok", "host1")
    assert s.ok["host1"] == 2
    s.increment("ok", "host2")
    assert s.ok["host2"] == 1