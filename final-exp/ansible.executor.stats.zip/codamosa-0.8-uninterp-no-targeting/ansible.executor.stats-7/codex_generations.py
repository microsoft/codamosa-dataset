

# Generated at 2022-06-20 14:25:59.991441
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()

    assert isinstance(stats.processed, dict)
    assert isinstance(stats.failures, dict)
    assert isinstance(stats.ok, dict)
    assert isinstance(stats.dark, dict)
    assert isinstance(stats.changed, dict)
    assert isinstance(stats.skipped, dict)
    assert isinstance(stats.rescued, dict)
    assert isinstance(stats.ignored, dict)
    assert isinstance(stats.custom, dict)


# Generated at 2022-06-20 14:26:04.517550
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.ok == {}

    stats.increment('ok', 'localhost')

    assert stats.processed == {'localhost': 1}
    assert stats.ok == {'localhost': 1}
    assert stats.failures == {'localhost': 0}


# Generated at 2022-06-20 14:26:08.935173
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ags = AggregateStats()
    ags.increment("failures", "test")
    assert ags.failures.get("test") == 1, "increment should increment a variable"


# Generated at 2022-06-20 14:26:15.477662
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate = AggregateStats()
    aggregate.set_custom_stats('foo', 'bar', 'zomg')
    aggregate.set_custom_stats('foo', 'bar')
    assert aggregate.custom.get('zomg', {}).get('foo') == 'bar'
    assert aggregate.custom.get('_run', {}).get('foo') == 'bar'


# Generated at 2022-06-20 14:26:25.619233
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Use assert almost equal to compare values of different types
    from ansible.utils.vars import combine_vars

    expected_output = {"foo": 1, "bar": 2, "baz": True, "foo_bar": 1, "baz_foo_bar_baz": 1}

    sut = AggregateStats()
    sut.update_custom_stats("foo", 1)
    sut.update_custom_stats("bar", 2)
    sut.update_custom_stats("baz", True)
    sut.update_custom_stats("foo_bar", 1, host="test_host")
    sut.update_custom_stats("baz_foo_bar_baz", 1, host=None)
    sut.update_custom_stats("foo_bar", 1, host="test_host")
   

# Generated at 2022-06-20 14:26:35.448782
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('uptime', 10)
    assert stats.custom['_run']['uptime'] == 10
    stats.update_custom_stats('uptime', 40, 'foo')
    assert stats.custom['_run']['uptime'] == 10
    assert stats.custom['foo']['uptime'] == 40
    stats.update_custom_stats('uptime', 30)
    assert stats.custom['_run']['uptime'] == 40
    assert stats.custom['foo']['uptime'] == 40
    assert stats.custom['_run']['uptime'] == 40
    assert stats.custom['foo']['uptime'] == 40
    stats.update_custom_stats('uptime', {'a': 1})
    stats.update_custom_stats

# Generated at 2022-06-20 14:26:43.673485
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    a = AggregateStats()
    a.update_custom_stats("abc", "def", "ghi")
    assert a.custom == {'ghi': {'abc': 'def'}}
    a.update_custom_stats("abc", "def")
    assert a.custom == {'ghi': {'abc': 'def'}, '_run': {'abc': 'def'}}
    a.update_custom_stats("pqr", 123)
    assert a.custom == {'ghi': {'abc': 'def'}, '_run': {'abc': 'def', 'pqr': 123}}
    a.update_custom_stats("abc", "def", "jkl")

# Generated at 2022-06-20 14:26:56.654835
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    global_stats = {
        'ignored': {},
        'dark': {},
        'ok': {},
        'failures': {},
        'ignored': {},
        'skipped': {},
        'processed': {},
        'rescued': {},
        'changed': {},
        'custom': {},
    }
    ansible = AggregateStats()
    ansible.hosts = ['host1', 'host2']
    ansible.ok['host1'] = 1
    ansible.failures['host2'] = 2
    ansible.dark['host1'] = 1
    ansible.changed['host2'] = 2
    ansible.skipped['host2'] = 1
    ansible.rescued['host1'] = 2

# Generated at 2022-06-20 14:27:03.205768
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('changed', 'localhost')
    stats.increment('skipped', 'localhost')
    assert stats.ok['localhost'] == 1
    assert stats.changed['localhost'] == 1
    assert stats.skipped['localhost'] == 1
    assert stats.processed['localhost'] == 1

# Generated at 2022-06-20 14:27:15.136683
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    # custom_stats = {'_run': {'foo': [1,2,3]}}
    aggregate_stats.custom['_run'] = {'foo': [1,2,3]}
    # which = 'foo'
    which = 'foo'
    # what = [4,5,6]
    what = [4,5,6]
    # aggregate_stats.update_custom_stats(which, what)
    aggregate_stats.update_custom_stats(which, what)
    # assert aggregate_stats.custom == {'_run': {'foo': [1,2,3,4,5,6]}}
    assert aggregate_stats.custom == {'_run': {'foo': [1,2,3,4,5,6]}}
    # custom_stats =

# Generated at 2022-06-20 14:27:23.571445
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    ag = AggregateStats()
    print(ag.processed)
    assert ag.processed == {}
    print(ag.failures)
    assert ag.failures == {}
    print(ag.ok)
    assert ag.ok == {}
    print(ag.dark)
    assert ag.dark == {}
    print(ag.changed)
    assert ag.changed == {}
    print(ag.skipped)
    assert ag.skipped == {}
    print(ag.rescued)
    assert ag.rescued == {}
    print(ag.ignored)
    assert ag.ignored == {}
    print(ag.custom)
    assert ag.custom == {}


# Generated at 2022-06-20 14:27:25.932291
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'example')
    assert stats.ok == {'example': 1}


# Generated at 2022-06-20 14:27:31.504581
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()

    # Check the stats
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}



# Generated at 2022-06-20 14:27:42.576239
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    stats.update_custom_stats("test_list_stat", [])
    assert stats.custom["_run"] == {"test_list_stat": []}
    stats.update_custom_stats("test_list_stat", [1, 2])
    assert stats.custom["_run"] == {"test_list_stat": [1, 2]}
    stats.update_custom_stats("test_list_stat", [3])
    assert stats.custom["_run"] == {"test_list_stat": [1, 2, 3]}
    stats.update_custom_stats("test_list_stat", "foo")
    assert stats.custom["_run"] == {"test_list_stat": [1, 2, 3]}

    stats.update_custom_stats("test_dict_stat", {})
    assert stats

# Generated at 2022-06-20 14:27:49.830294
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    as_obj = AggregateStats()
    host_items = ['_run', 'host1', 'host2']
    for host in host_items:
        as_obj.set_custom_stats('foo', 10, host)

    assert as_obj.custom['_run']['foo'] == 10
    assert as_obj.custom['host1']['foo'] == 10
    assert as_obj.custom['host2']['foo'] == 10


# Generated at 2022-06-20 14:27:54.712332
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    custom_stats = AggregateStats()
    host = 'test_host'
    custom_stats.update_custom_stats('test_dict_key',{'test_hash_key': 'test_value'}, host)
    assert custom_stats.custom['test_host']['test_dict_key']['test_hash_key'] == 'test_value'



# Generated at 2022-06-20 14:28:04.875399
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    '''
    Run an unit test for method update_custom_stats of class AggregateStats.
    :return: Nothing
    '''
    stat = AggregateStats()
    stat.update_custom_stats('some_map', {'key': 1})
    assert stat.custom['_run']['some_map'] == {'key': 1}
    stat.update_custom_stats('some_map', {'key': 2})
    assert stat.custom['_run']['some_map'] == {'key': 3}
    stat.update_custom_stats('some_number', 1)
    stat.update_custom_stats('some_number', 1)
    assert stat.custom['_run']['some_number'] == 2
    stat.update_custom_stats('some_number', 1.0)

# Generated at 2022-06-20 14:28:15.742597
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    assert stats.summarize('host1') == dict(ok=2, failures=0, unreachable=0, changed=0, skipped=0, rescued=0, ignored=0)
    assert stats.summarize('host2') == dict(ok=1, failures=0, unreachable=0, changed=0, skipped=0, rescued=0, ignored=0)
    assert stats.summarize('host3') == dict(ok=0, failures=0, unreachable=0, changed=0, skipped=0, rescued=0, ignored=0)


# Generated at 2022-06-20 14:28:26.864797
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    test_host = '1.1.1.1'
    test_data = {
        'o': [0],
        'f': [1],
        'u': [2],
        'c': [3],
        's': [4],
        'r': [5],
        'i': [6],
    }

    # Initialize AggregateStats
    test_stats = AggregateStats()

    # Call method increment with all kind of action
    for key, value in test_data.items():
        test_stats.increment(key, test_host)
        value[0] += 1

    # Check the values of self.ok
    assert test_stats.ok[test_host] == test_data['o'][0]

    # Check the values of self.failures

# Generated at 2022-06-20 14:28:35.068374
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    as_obj = AggregateStats()
    what = 'ok'
    host = 'localhost'
    as_obj.increment(what, host)
    if as_obj.ok.get('localhost', 0) == 1:
        return True
    else:
        return False


# Generated at 2022-06-20 14:28:42.122366
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stat = AggregateStats()

    assert isinstance(stat, AggregateStats)
    assert isinstance(stat.processed, dict)
    assert isinstance(stat.failures, dict)
    assert isinstance(stat.ok, dict)
    assert isinstance(stat.dark, dict)
    assert isinstance(stat.changed, dict)
    assert isinstance(stat.skipped, dict)
    assert isinstance(stat.rescued, dict)
    assert isinstance(stat.ignored, dict)
    assert isinstance(stat.custom, dict)



# Generated at 2022-06-20 14:28:42.832998
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert(isinstance(stats, AggregateStats))


# Generated at 2022-06-20 14:28:48.725534
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg = AggregateStats()
    agg.set_custom_stats('test', 'hello world', 'localhost')
    assert agg.custom['localhost']['test'] == 'hello world'


# Generated at 2022-06-20 14:29:01.467009
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('changed', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('dark', 'localhost')
    stats.increment('skipped', 'localhost')
    stats.increment('rescued', 'localhost')
    stats.increment('ignored', 'localhost')
    stats.increment('ok', '127.0.0.1')
    results = stats.summarize('localhost')
    assert results['ok'] == 1
    assert results['changed'] == 1
    assert results['failures'] == 1
    assert results['unreachable'] == 1
    assert results['skipped'] == 1
    assert results['rescued'] == 1
    assert results['ignored'] == 1

# Generated at 2022-06-20 14:29:09.097790
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    stats.increment("dark", "127.0.0.1")
    stats.increment("dark", "127.0.0.1")
    stats.increment("dark", "127.0.0.2")
    stats.decrement("dark", "127.0.0.2")
    assert(stats.summarize("127.0.0.1") == dict(ok=0, failures=0, unreachable=2, changed=0, skipped=0, rescued=0, ignored=0))
    assert(stats.summarize("127.0.0.2") == dict(ok=0, failures=0, unreachable=1, changed=0, skipped=0, rescued=0, ignored=0))

# Generated at 2022-06-20 14:29:19.018559
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()

    stats.increment("ok", "localhost")
    stats.increment("ok", "localhost")
    stats.increment("ok", "192.168.0.1")
    stats.increment("failures", "localhost")
    stats.increment("changed", "192.168.0.1")

    summary = stats.summarize("localhost")
    assert summary == {'ok': 2, 'failures': 1, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}

    summary = stats.summarize("192.168.0.1")

# Generated at 2022-06-20 14:29:32.576737
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'foo')
    stats.increment('ok', 'foo')
    stats.increment('ok', 'foo')
    stats.increment('changed', 'foo')
    stats.set_custom_stats('custom_key', 'custom_value', 'foo')
    assert stats.summarize('foo') == dict(
        ok=3,
        failures=0,
        unreachable=0,
        changed=1,
        skipped=0,
        rescued=0,
        ignored=0,
        custom_key='custom_value',
    )



# Generated at 2022-06-20 14:29:39.243068
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'test_host')
    stats.increment('ok', 'test_host')
    stats.increment('failures', 'test_host')
    assert stats.ok['test_host'] == 2
    assert stats.failures['test_host'] == 1
    stats.decrement('ok', 'test_host')
    stats.decrement('ok', 'test_host')
    stats.decrement('ok', 'test_host')
    stats.decrement('failures', 'test_host')
    assert stats.ok['test_host'] == 0
    assert stats.failures['test_host'] == 0

# Generated at 2022-06-20 14:29:39.942924
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    assert True

# Generated at 2022-06-20 14:29:42.545775
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    test_obj = AggregateStats()
    test_obj.increment("ok", "localhost")
    assert test_obj.ok["localhost"] == 1