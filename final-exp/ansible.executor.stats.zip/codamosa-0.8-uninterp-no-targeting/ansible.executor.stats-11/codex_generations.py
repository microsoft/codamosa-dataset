

# Generated at 2022-06-20 14:26:09.174739
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    # test values
    host = 'test_host'
    host_run_count = 'test_run_count'
    host_run_count_merge_mapping = {'test_key': 'test_value'}
    host_run_count_that_should_fail = {'key': 'value'}
    host_run_count_that_should_fail_type_mismatch = 1

    # set a test value
    stats.set_custom_stats(which=host_run_count, what=1, host=host)

    # test merge_hash
    stats.update_custom_stats(which=host_run_count, what=host_run_count_merge_mapping, host=host)

# Generated at 2022-06-20 14:26:14.348373
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    as_ = AggregateStats()
    for what in ('processed', 'failures', 'ok', 'dark', 'changed', 'skipped', 'rescued', 'ignored', 'custom'):
        assert getattr(as_, what) == dict()


# Generated at 2022-06-20 14:26:24.969246
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    from ansible.playbook.play_context import PlayContext

    aggregate_stats = AggregateStats()
    play_context = PlayContext()

    # construct a host map
    host_map = {}
    host_map['192.168.1.1'] = dict(
        hostname='192.168.1.1',
        port=22,
        _hostname='192.168.1.1',
    )
    host_map['192.168.1.2'] = dict(
        hostname='192.168.1.2',
        port=22,
        _hostname='192.168.1.2',
    )

    play_context.hostvars = host_map
    play_context.inventory = host_map

    play_context.port = 22

    # when there are no hosts
    result = aggregate

# Generated at 2022-06-20 14:26:35.012145
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # initialise the object
    adata = AggregateStats()
    # test with only host provided
    adata.update_custom_stats('foo', 'bar')
    assert '_run' in adata.custom
    assert 'foo' in adata.custom['_run']
    assert adata.custom['_run']['foo'] == 'bar'
    # test with host and which provided
    adata.update_custom_stats('foo', 'bar', 'testing')
    assert 'testing' in adata.custom
    assert 'foo' in adata.custom['testing']
    assert adata.custom['testing']['foo'] == 'bar'
    # test with host, which and what provided
    adata.update_custom_stats('foo', {'bar': 'baz'}, 'testing')

# Generated at 2022-06-20 14:26:41.910204
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok['test_host'] = 1
    stats.dark['test_host'] = 2
    stats.changed['test_host'] = 3
    stats.rescued['test_host'] = 4
    stats.ignored['test_host'] = 5
    stats.failures['test_host'] = 6
    stats.skipped['test_host'] = 7
    assert stats.summarize('test_host') == dict(
        ok=1,
        unreachable=2,
        changed=3,
        rescued=4,
        ignored=5,
        failures=6,
        skipped=7,
    )

# Generated at 2022-06-20 14:26:55.716299
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    new_instance = AggregateStats()
    new_instance.update_custom_stats('test_dict', {'test': 1})
    new_instance.update_custom_stats('test_dict', {'test': 2})
    new_instance.update_custom_stats('test_dict', {'test1': 1,
                                                   'test2': 2})
    # Custom stats:
    # "_run":
    #     "test_dict": {'test': 3, 'test1': 1, 'test2': 2}
    custom_stats = new_instance.custom._run.test_dict
    print(custom_stats)
    assert custom_stats == {'test': 3, 'test1': 1, 'test2': 2}


# Generated at 2022-06-20 14:27:06.902574
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats(): # pylint: disable=invalid-name
    import sys
    import json

    class MyAggregateStats(AggregateStats):
        def custom_stats_transport(self, host):
            if host == 'A':
                return {'bytes_received': 1, 'connections': 1}
            if host == 'B':
                return {'bytes_received': 2}
            return None

        def custom_stats_fact(self, host):
            if host == 'C':
                return {'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS'}
            return None

        def update_custom_stats(self, which, what, host): # pylint: disable=arguments-differ
            if which == 'transport':
                return super(MyAggregateStats, self).update_custom_

# Generated at 2022-06-20 14:27:12.615476
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    obj = AggregateStats()
    assert obj.processed == {}
    assert obj.failures == {}
    assert obj.ok == {}
    assert obj.dark == {}
    assert obj.changed == {}
    assert obj.skipped == {}
    assert obj.rescued == {}
    assert obj.ignored == {}
    assert obj.custom == {}



# Generated at 2022-06-20 14:27:23.585638
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    ag = AggregateStats()
    ag.set_custom_stats('mystat', "aValue", "myhost")
    assert ag.custom == {'myhost': {'mystat': "aValue"}}

    ag.set_custom_stats('mystat', 2.0, "myhost")
    assert ag.custom == {'myhost': {'mystat': 2.0}}

    ag.set_custom_stats('mystat', {'key': "aValue"}, "myhost")
    assert ag.custom == {'myhost': {'mystat': {'key': "aValue"}}}

    try:
        ag.set_custom_stats('mystat', {'key': "aValue"}, "myhost")
        assert False
    except KeyError:
        assert True



# Generated at 2022-06-20 14:27:34.059889
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import os
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.executor import playbook_executor

    stats = AggregateStats()
    stats.update_custom_stats('dummy', 'bar')
    stats.update_custom_stats('dummy', {'baz': 2}, host='localhost')
    stats.update_custom_stats('dummy', {'baz': 2}, host='127.0.0.1')

    assert stats.custom.get('_run', {}).get('dummy') == 'bar'
    assert stats.custom.get('localhost', {}).get('dummy').get('baz') == 2

# Generated at 2022-06-20 14:27:49.830399
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    # case 1: processed
    stats.increment('processed', 'host1')
    assert stats.processed['host1'] == 1

    # case 2: failures
    stats.increment('failures', 'host1')
    assert stats.failures['host1'] == 1

    # case 3: ok
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 1

    # case 4: dark
    stats.increment('dark', 'host1')
    assert stats.dark['host1'] == 1

    # case 5: changed
    stats.increment('changed', 'host1')
    assert stats.changed['host1'] == 1

    # case 6: skipped
    stats.increment('skipped', 'host1')
    assert stats.skipped

# Generated at 2022-06-20 14:27:55.358301
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggstats = AggregateStats()

    assert aggstats.processed == {}
    assert aggstats.failures == {}
    assert aggstats.ok == {}
    assert aggstats.dark == {}
    assert aggstats.changed == {}
    assert aggstats.skipped == {}
    assert aggstats.rescued == {}
    assert aggstats.ignored == {}
    assert aggstats.custom == {}
    assert aggstats.processed == {}

# Generated at 2022-06-20 14:28:07.015625
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    agg_stats = AggregateStats()
    agg_stats.increment('ok', 'host1')
    agg_stats.increment('ok', 'host1')
    agg_stats.increment('failures', 'host2')
    agg_stats.increment('dark', 'host1')
    agg_stats.increment('changed', 'host1')
    agg_stats.increment('skipped', 'host2')
    agg_stats.increment('rescued', 'host1')
    agg_stats.increment('ignored', 'host2')

# Generated at 2022-06-20 14:28:12.737406
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("ok", "host1")
    stats.increment("ok", "host1")
    stats.increment("failures", "host2")
    stats.increment("ignored", "host2")
    stats.increment("ignored", "host2")
    assert stats.ok == {'host1': 2}
    assert stats.failures == {'host2': 1}
    assert stats.ignored == {'host2': 2}


# Generated at 2022-06-20 14:28:21.501416
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    rand_num = random.randint(1, 10)
    rand_host = 'localhost_' + str(random.randint(1, 4000))

    ags = AggregateStats()
    ags.increment('ok', rand_host)
    ags.increment('ok', rand_host)
    ags.increment('ok', rand_host)
    assert ags.ok[rand_host] == 3, 'test_AggregateStats_increment() FAILED'


# Generated at 2022-06-20 14:28:23.485817
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert isinstance(stats, AggregateStats)



# Generated at 2022-06-20 14:28:33.401649
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    # test list
    stats.update_custom_stats("test_list", ["a", "b"])

    assert(stats.custom['_run']['test_list'] == ["a", "b"])
    stats.update_custom_stats("test_list", ["c", "d"])
    assert(stats.custom['_run']['test_list'] == ["a", "b", "c", "d"])

    # test string
    stats.update_custom_stats("test_str", "a")
    assert(stats.custom['_run']['test_str'] == "a")
    stats.update_custom_stats("test_str", "b")
    assert(stats.custom['_run']['test_str'] == "ab")

    # test number
    stats

# Generated at 2022-06-20 14:28:40.248333
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    ''' Return true if all the created attributes in the object are empty dictionaries '''
    aggregate_stats_obj = AggregateStats()
    attributes_dictionary = dict(processed={}, failures={}, ok={}, dark={}, changed={}, skipped={}, rescued={},
                                 ignored={}, custom={})
    if str(aggregate_stats_obj.__dict__) == str(attributes_dictionary):
        return True
    return False


# Generated at 2022-06-20 14:28:49.328472
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # A simple test to cover an uncovered part of code
    stats = AggregateStats()
    stats.custom = {'_run': {'test': {}} }
    stats.update_custom_stats('test', {'a': 1})

    assert stats.custom['_run']['test']['a'] == 1

    stats.custom = {'_run': {'test': {'a': 1} } }
    stats.update_custom_stats('test', {'a': 2})
    assert stats.custom['_run']['test']['a'] == 3

    stats.custom = {'_run': {'test': {'a': 1} } }
    stats.update_custom_stats('test', ['foo'])
    assert stats.custom['_run']['test']['a'] == 1

# Generated at 2022-06-20 14:29:01.571991
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    obj = AggregateStats()
    assert obj.custom == {}
    obj.update_custom_stats('foo', 'bar', 'baz')
    assert obj.custom == {'baz': {'foo': 'bar'}}
    obj.update_custom_stats('foo', 1337, 'baz') # another string
    assert obj.custom == {'baz': {'foo': 'bar'}}
    obj.update_custom_stats('foo', '1337', 'baz') # another number
    assert obj.custom == {'baz': {'foo': 'bar'}}
    obj.update_custom_stats('foo', [1,2,3], 'baz') # a list
    assert obj.custom == {'baz': {'foo': ['bar', 1, 2, 3]}}
    obj.update_custom_

# Generated at 2022-06-20 14:29:16.896673
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('test', 1)
    assert stats.custom['_run']['test'] == 1
    stats.update_custom_stats('test', 2)
    assert stats.custom['_run']['test'] == 3
    stats.update_custom_stats('test', 3)
    assert stats.custom['_run']['test'] == 6
    stats.update_custom_stats('test_dict', {'key': 'value'})
    assert stats.custom['_run']['test_dict'] == {'key': 'value'}
    stats.update_custom_stats('test_dict', {'key2': 'value2'})

# Generated at 2022-06-20 14:29:24.888654
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    if not hasattr(AggregateStats, 'set_custom_stats'):
        return
    stats = AggregateStats()
    stats.update_custom_stats('_result', 'success')
    stats.update_custom_stats('_result', 'success', '_run')
    assert stats.custom == {'_run': {'_result': 'success'}}
    stats.update_custom_stats('_result', {'changed': True}, '_run')
    assert stats.custom == {'_run': {'_result': {'changed': True}}}
    stats.update_custom_stats('_result', {'changed': True})
    assert stats.custom == {'_run': {'_result': {'changed': True}}}
    stats.update_custom_stats('_result', {'changed': {'foo': True}})


# Generated at 2022-06-20 14:29:32.466866
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.ok={'host1':1}
    aggregate_stats.decrement('ok', 'host1')
    assert aggregate_stats.ok['host1'] == 0

    aggregate_stats.decrement('ok', 'host1')
    assert aggregate_stats.ok['host1'] == 0

if __name__ == "__main__":
    test_AggregateStats_decrement()

# Generated at 2022-06-20 14:29:35.905604
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg_stats = AggregateStats()
    agg_stats.decrement('failures', 'host1')
    agg_stats.decrement('failures', 'host1')
    assert agg_stats.failures['host1'] == -2

# Generated at 2022-06-20 14:29:46.996601
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stat = AggregateStats()

    # case 1: Dict update
    stat.set_custom_stats('aggregate', {'something': 1}, 'test_1')
    stat.update_custom_stats('aggregate', {'something': 1}, 'test_1')
    assert 3 == stat.custom['test_1']['aggregate']['something']

    # case 2: Integer update
    stat.set_custom_stats('counter', 3, 'test_2')
    stat.update_custom_stats('counter', 1, 'test_2')
    assert 4 == stat.custom['test_2']['counter']

    # case 3: No field
    stat.update_custom_stats('no_field', 'no value', 'test_3')
    assert stat.custom['test_3'] is None

    # case 4:

# Generated at 2022-06-20 14:29:57.943198
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('failures', 'host2')

    results = stats.summarize('host1')

    assert results == dict(ok=2, failures=0, unreachable=0, changed=0, skipped=0, rescued=0, ignored=0)

    results = stats.summarize('host2')

    assert results == dict(ok=1, failures=1, unreachable=0, changed=0, skipped=0, rescued=0, ignored=0)


# Generated at 2022-06-20 14:30:01.972659
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats

# Generated at 2022-06-20 14:30:09.865642
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import unittest

    class TestAggregateStats(unittest.TestCase):
        ''' unit tests for AnsibleAggregateStats update_custom_stats method '''

        def test_update_custom_stats_host_not_set(self):
            ''' host not set '''
            stats = AggregateStats()
            stats.update_custom_stats('foo', 123)
            self.assertEqual(stats.custom['_run']['foo'], 123)

        def test_update_custom_stats_custom_not_set(self):
            ''' custom not set '''
            stats = AggregateStats()
            stats.update_custom_stats('foo', 123, 'test')
            self.assertEqual(stats.custom['test']['foo'], 123)


# Generated at 2022-06-20 14:30:16.644715
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    agg = AggregateStats()
    agg.update_custom_stats("a_key", {"a": 1, "b": {"m": 2, "n": 3}})
    agg.update_custom_stats("a_key", {"a": 4, "b": {"m": 5, "n": 6}, "c": 7})
    assert agg.custom == {"_run": {"a_key": {"a": 4, "b": {"m": 5, "n": 6}, "c": 7}}}



# Generated at 2022-06-20 14:30:25.172807
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()

    assert '_run' not in aggregate_stats.custom

    aggregate_stats.set_custom_stats('foo', 'bar')

    assert '_run' in aggregate_stats.custom
    assert 'foo' in aggregate_stats.custom['_run']
    assert aggregate_stats.custom['_run']['foo'] == 'bar'

    aggregate_stats.set_custom_stats('foo', 'baz')
    assert aggregate_stats.custom['_run']['foo'] == 'baz'

    aggregate_stats.set_custom_stats('foo', 'baz', 'localhost')
    assert aggregate_stats.custom['localhost']['foo'] == 'baz'
    assert aggregate_stats.custom['_run']['foo'] == 'baz'

    aggregate_stats.set_custom

# Generated at 2022-06-20 14:30:30.580530
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-20 14:30:40.473329
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1

# Generated at 2022-06-20 14:30:47.960416
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Create a AggregateStats object
    import ansible.utils.aggregate
    astat = ansible.utils.aggregate.AggregateStats()
    # Call method
    astat.decrement('ok', 'localhost')
    astat.decrement('ok', 'localhost')
    astat.decrement('ok', 'localhost')
    # Check that the result is correct
    assert astat.ok['localhost'] == -3

# Generated at 2022-06-20 14:31:02.492290
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('failures', 'test')
    stats.increment('ok', 'test')
    stats.increment('failures', 'test')

    stats.increment('ok', 'test2')
    # Here we run out of different kind of status => no reason to add a new one

    assert stats.summarize('test') == {'failures': 2, 'ok': 1, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}
    assert stats.summarize('test2') == {'failures': 0, 'ok': 1, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}


# Generated at 2022-06-20 14:31:11.669186
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("ok", "testHost")
    assert stats.processed["testHost"] == 1
    assert stats.ok["testHost"] == 1
    assert stats.failures.get("testHost", 0) == 0
    assert stats.dark.get("testHost", 0) == 0
    assert stats.changed.get("testHost", 0) == 0
    assert stats.skipped.get("testHost", 0) == 0
    assert stats.rescued.get("testHost", 0) == 0
    assert stats.ignored.get("testHost", 0) == 0

    stats.increment("failures", "testHost")
    assert stats.processed["testHost"] == 1
    assert stats.ok["testHost"] == 1
    assert stats.failures["testHost"] == 1


# Generated at 2022-06-20 14:31:14.627421
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()

    assert stats.ok == {}, 'ok should be empty dict'
    assert stats.custom == {}, 'custom should be empty dict'

# Generated at 2022-06-20 14:31:20.000236
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # note that this previously tested subtracting one dict from another.
    # this test instead tests adding two dicts together.  which is what we
    # want.  the old test was broken because it assumed that the dicts
    # would only be integers, which doesn't match what we actually want.

    agg = AggregateStats()
    assert agg.custom == {}

    # when host is not specified, default to '_run'
    agg.update_custom_stats('stats', { 'a': 1, 'b': 2, 'c': 3 })
    assert agg.custom == { '_run': { 'stats': { 'a': 1, 'b': 2, 'c': 3 } } }

    # when host is specified, use it

# Generated at 2022-06-20 14:31:22.455611
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert isinstance(stats, AggregateStats)

# Unit tests for method AggregateStats.increment

# Generated at 2022-06-20 14:31:28.565130
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg = AggregateStats()
    agg.increment('ignored', 'localhost')
    assert agg.ignored['localhost'] == 1
    agg.increment('ignored', 'localhost')
    assert agg.ignored['localhost'] == 2
    agg.increment('ignored', '127.0.0.1')
    assert agg.ignored['127.0.0.1'] == 1

# Generated at 2022-06-20 14:31:36.257547
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate = AggregateStats()
    aggregate.set_custom_stats(which="foo", what=["x"], host="localhost")
    aggregate.update_custom_stats(which="foo", what=["y"], host="localhost")
    assert aggregate.custom == {"localhost": {"foo": ["x", "y"]}}

    aggregate = AggregateStats()
    aggregate.update_custom_stats(which="foo", what=["y"], host="localhost")
    assert aggregate.custom == {"localhost": {"foo": ["y"]}}