

# Generated at 2022-06-20 14:26:03.420465
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()

    aggregate_stats.ok['host'] = 1
    aggregate_stats.failures['host'] = 2
    aggregate_stats.dark['host'] = 3
    aggregate_stats.changed['host'] = 4
    aggregate_stats.skipped['host'] = 5
    aggregate_stats.rescued['host'] = 6
    aggregate_stats.ignored['host'] = 7

    assert aggregate_stats.summarize('host') == {
        'ok': 1,
        'failures': 2,
        'unreachable': 3,
        'changed': 4,
        'skipped': 5,
        'rescued': 6,
        'ignored': 7
    }

# Generated at 2022-06-20 14:26:09.518252
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats_obj = AggregateStats()
    aggregate_stats_obj.increment('skipped', 'test')
    aggregate_stats_obj.increment('ok', 'test')
    aggregate_stats_obj.increment('ok', 'test')
    assert aggregate_stats_obj.summarize('test') == {'ok': 2, 'failures': 0, 'unreachable': 0, 'changed': 0, 'skipped': 1, 'rescued': 0, 'ignored': 0}

# Generated at 2022-06-20 14:26:14.235235
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    expected_dict = {'ok': {}, 'processed': {}, 'rescued': {},
                     'changed': {}, 'failures': {}, 'ignored': {}, 'dark': {},
                     'custom': {}, 'skipped': {}}
    expected_dict['ok']['foo'] = 1;
    expected_dict['processed']['foo'] = 1;
    a = AggregateStats()
    a.increment('ok', 'foo')
    assert a.__dict__ == expected_dict


# Generated at 2022-06-20 14:26:16.583826
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate = AggregateStats()
    aggregate.increment('changed', 'host1')
    assert aggregate.processed == {'host1': 1}
    assert aggregate.failures == {}
    assert aggregate.ok == {}
    assert aggregate.dark == {}
    assert aggregate.changed == {'host1': 1}
    assert aggregate.skipped == {}
    assert aggregate.rescued == {}
    assert aggregate.ignored == {}


# Generated at 2022-06-20 14:26:26.215316
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()

    # decrement of one for key 'ignored', which exists in the dict
    aggregate_stats.ignored['test_host'] = 2
    aggregate_stats.decrement('ignored', 'test_host')
    assert aggregate_stats.ignored['test_host'] == 1

    # decrement of one for key 'failures', which does not exist in the dict
    aggregate_stats.failures['test_host'] = 0
    aggregate_stats.decrement('failures', 'test_host')
    assert aggregate_stats.failures['test_host'] == 0

    # decrement of one for key 'ok', which exists in the dict
    aggregate_stats.ok['test_host'] = 3
    aggregate_stats.decrement('ok', 'test_host')
    assert aggregate_stats

# Generated at 2022-06-20 14:26:35.894102
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    # merging 2 dicts
    stats = AggregateStats()
    stats.update_custom_stats('test', {1: 'foo', 2: 'bar'})
    stats.update_custom_stats('test', {1: 'baz', 3: 'foobar'})
    assert stats.custom['_run']['test'] == {1: 'baz', 2: 'bar', 3: 'foobar'}

    # merging a dict with an empty dict
    stats = AggregateStats()
    stats.update_custom_stats('test', {1: 'foo', 2: 'bar'})
    stats.update_custom_stats('test', {})
    assert stats.custom['_run']['test'] == {1: 'foo', 2: 'bar'}

    # merging an empty dict with a dict
    stats = AggregateStats()

# Generated at 2022-06-20 14:26:40.577392
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok['test'] = 4
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 3


# Generated at 2022-06-20 14:26:44.750742
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.increment("ok", "localhost") == 1
    assert aggregate_stats.increment("ok", "localhost") == 2
    assert aggregate_stats.ok == {"localhost": 2}
    assert aggregate_stats.skipped == {}
    assert aggregate_stats.increment("skipped", "localhost") == 1
    assert aggregate_stats.skipped == {"localhost": 1}


# Generated at 2022-06-20 14:26:49.647264
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('agg1', {'agg1': 'val1'})
    stats.set_custom_stats('agg1', 'val2', 'host1')
    stats.set_custom_stats('agg2', 'val3')
    assert(stats.custom == {'_run': {'agg1': {'agg1': 'val1'}}, 'host1': {'agg1': 'val2'}})


# Generated at 2022-06-20 14:26:52.502990
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggrstats = AggregateStats()
    assert isinstance(aggrstats, AggregateStats)

if __name__ == '__main__':
    test_AggregateStats()

# Generated at 2022-06-20 14:27:03.305461
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats("my_stat", "my_value", host="_run")
    stats.set_custom_stats("my_stat", "my_value2", host="_run")
    assert stats.custom["_run"]["my_stat"] == "my_value2"
    stats.set_custom_stats("my_stat", "my_value", host="localhost")
    assert stats.custom["localhost"]["my_stat"] == "my_value"



# Generated at 2022-06-20 14:27:10.240055
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'foo')
    stats.increment('ok', 'foo')
    stats.increment('ok', 'bar')
    expected = {'foo': 2, 'bar': 1}
    assert expected == stats.summarize('foo')
    assert expected == stats.summarize('bar')


# Unit test to make sure that custom stats are set properly

# Generated at 2022-06-20 14:27:16.808217
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate = AggregateStats()
    aggregate.set_custom_stats('test_key', 'test_value')
    assert aggregate.custom == {'_run': {'test_key': 'test_value'}}
    aggregate.set_custom_stats('test_key1', 'test_value', host='test_host')
    assert aggregate.custom == {'_run': {'test_key': 'test_value'},
                                'test_host': {'test_key1': 'test_value'}}



# Generated at 2022-06-20 14:27:20.918320
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats("data1", "label1")
    assert stats.custom['_run']['data1'] == 'label1'
    stats.set_custom_stats("data2", "label2")
    assert stats.custom['_run']['data2'] == 'label2'


# Generated at 2022-06-20 14:27:24.790446
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

    stats.ok['localhost'] = 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-20 14:27:36.220528
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    import collections
    as1 = AggregateStats()
    as1.processed["HOST"] = 1
    as1.failures["HOST"] = 2
    as1.ok["HOST"] = 3
    as1.dark["HOST"] = 4
    as1.changed["HOST"] = 5
    as1.skipped["HOST"] = 6
    as1.rescued["HOST"] = 7
    as1.ignored["HOST"] = 8
    as1.increment("processed", "HOST")
    as1.increment("failures", "HOST")
    as1.increment("ok", "HOST")
    as1.increment("dark", "HOST")
    as1.increment("changed", "HOST")

# Generated at 2022-06-20 14:27:44.147926
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import collections

    host_name = 'test_host'
    stats = AggregateStats()
    stats.custom = {'_run': {}}

    # test cases

# Generated at 2022-06-20 14:27:49.925609
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    agg = AggregateStats()
    host1 = agg.summarize('host1')
    host2 = agg.summarize('host2')
    assert host1 == host2
    agg.increment('ok', 'host1')
    host = agg.summarize('host1')
    assert host['ok'] == 1
    assert host['failures'] == 0


# Generated at 2022-06-20 14:27:52.965590
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok['test_decrement'] = 1
    stats.decrement('ok', 'test_decrement')
    assert stats.ok['test_decrement'] == 0

# Generated at 2022-06-20 14:27:58.537103
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats("foo", 42, "server1")
    assert stats.custom["server1"] == {"foo": 42}


# Generated at 2022-06-20 14:28:09.949765
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ignore', 'host1')
    host1 = stats.summarize('host1')
    host2 = stats.summarize('host2')
    assert host1 == {'changed': 0, 'ok': 1, 'rescued': 0, 'skipped': 0, 'unreachable': 0, 'failures': 0, 'ignored': 1}
    assert host2 == {'changed': 0, 'ok': 0, 'rescued': 0, 'skipped': 0, 'unreachable': 0, 'failures': 0, 'ignored': 0}

if __name__ == '__main__':
    test_AggregateStats_summarize()

# Generated at 2022-06-20 14:28:24.733389
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    from pprint import pprint
    from parameterized import parameterized


# Generated at 2022-06-20 14:28:32.117187
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'sometarget')
    assert 1 == stats.ok['sometarget']
    assert 0 == stats.ok.get('nonexistenttarget', 0)
    stats.decrement('ok', 'sometarget')
    assert 0 == stats.ok['sometarget']
    assert 0 == stats.ok.get('nonexistenttarget', 0)
    stats.decrement('ok', 'sometarget')
    assert 0 == stats.ok['sometarget']
    assert 0 == stats.ok.get('nonexistenttarget', 0)

# Generated at 2022-06-20 14:28:40.566779
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    sut = AggregateStats()

    # Check the default initialization state
    assert sut is not None
    assert len(sut.processed) == 0
    assert len(sut.failures) == 0
    assert len(sut.ok) == 0
    assert len(sut.dark) == 0
    assert len(sut.changed) == 0
    assert len(sut.skipped) == 0
    assert len(sut.rescued) == 0
    assert len(sut.ignored) == 0
    assert len(sut.custom) == 0


# Generated at 2022-06-20 14:28:50.001463
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    import pytest
    s = AggregateStats()
    s.increment('ignored', 'host1')
    s.increment('ignored', 'host1')
    s.increment('ignored', 'host1')
    s.increment('ignored', 'host2')

    # Decrement count of field 'ignored' by 1 for host 'host1'
    s.decrement('ignored', 'host1')
    # Decrement count of field 'ignored' by 2 for host 'host2'
    s.decrement('ignored', 'host2')
    s.decrement('ignored', 'host2')

    assert s.ignored['host1'] == 2
    assert s.ignored['host2'] == 0

    # Strictly speaking this shouldn't be necessary since s.decrement
   

# Generated at 2022-06-20 14:29:02.077256
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    stats.increment('ok', "localhost")
    assert stats.summarize('localhost') == {"ok": 1, "failures": 0, "unreachable": 0, "changed": 0, "skipped": 0, "rescued": 0, "ignored": 0}
    stats.increment('unreachable', "localhost")
    stats.increment('ok', "localhost")
    assert stats.summarize('localhost') == {"ok": 2, "failures": 0, "unreachable": 1, "changed": 0, "skipped": 0, "rescued": 0, "ignored": 0}
    stats.decrement('unreachable', "localhost")

# Generated at 2022-06-20 14:29:09.878597
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('foo', 123)
    stats.set_custom_stats('bar', {'foo': 'bar'}, '127.0.0.1')
    stats.update_custom_stats('foo', 123)
    stats.update_custom_stats('bar', {'baz': 1})
    stats.update_custom_stats('bar', {'foo': 'bar'}, '127.0.0.1')
    # Override foo and set it to 456
    stats.set_custom_stats('foo', 456)
    stats.set_custom_stats('baz', {'foo': 'bar'})
    stats.update_custom_stats('baz', {'bar': 'baz'})
    # baz won't be aggregated
    stats.set_custom

# Generated at 2022-06-20 14:29:20.991794
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('tasks', {'ok': {'foo': 1}}, 'localhost')
    assert stats.custom == {'localhost': {'tasks': {'ok': {'foo': 1}}}}

    empty_stats = AggregateStats()
    empty_stats.update_custom_stats('tasks', {'ok': {'foo': 1}}, 'localhost')
    empty_stats.update_custom_stats('tasks', {'ok': {'foo': 1}}, 'localhost')
    assert empty_stats.custom == {'localhost': {'tasks': {'ok': {'foo': 2}}}}

    empty_stats = AggregateStats()
    empty_stats.update_custom_stats('tasks', {'ok': {'foo': 1}}, 'localhost')
   

# Generated at 2022-06-20 14:29:25.411868
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg_stats = AggregateStats()
    agg_stats.increment("ok", "host1")
    agg_stats.increment("ok", "host1")
    agg_stats.increment("ok", "host2")
    agg_stats.increment("failures", "host1")
    assert agg_stats.ok == {"host1": 2, "host2": 1}
    assert agg_stats.failures == {"host1": 1}


# Generated at 2022-06-20 14:29:28.589335
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    test_stat = "ok"
    test_host = "test_hostname"
    stats.increment(test_stat, test_host)
    stats.decrement(test_stat, test_host)
    assert(stats.ok[test_host] == 0)
    assert(test_host not in stats.ok.keys())

test_AggregateStats_decrement()