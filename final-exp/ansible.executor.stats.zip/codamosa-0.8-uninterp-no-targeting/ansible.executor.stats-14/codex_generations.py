

# Generated at 2022-06-20 14:25:57.624652
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    stats.decrement("ignored", "testhost")
    assert stats.ignored.get("testhost") == 0
    stats.ignored = {"testhost": 1}
    stats.decrement("ignored", "testhost")
    assert stats.ignored.get("testhost") == 0


# Generated at 2022-06-20 14:26:00.031738
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('something', 'something')
    assert stats.custom['_run']['something'] == 'something'


# Generated at 2022-06-20 14:26:08.404493
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
  from ansible.playbook.play_context import PlayContext
  stats = AggregateStats()
  stats.set_custom_stats("dummy_stat", 1, "_run")
  stats.increment("ok", "localhost")
  stats.increment("failures", "localhost")
  ans_stats = stats.summarize("localhost")
  assert ans_stats["ok"] == 1
  assert ans_stats["failures"] == 1
  assert ans_stats["unreachable"] == 0
  assert ans_stats["changed"] == 0
  assert ans_stats["skipped"] == 0
  assert ans_stats["rescued"] == 0
  assert ans_stats["ignored"] == 0

# Generated at 2022-06-20 14:26:15.176489
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate = AggregateStats()
    aggregate.update_custom_stats('test', 'a', 'host1')
    aggregate.update_custom_stats('test', 'b', 'host2')
    aggregate.update_custom_stats('test', 'c', 'host3')
    aggregate.update_custom_stats('test', 'd', 'host4')
    aggregate.update_custom_stats('test', 'host1')
    aggregate.update_custom_stats('test', 'host2')
    aggregate.update_custom_stats('test', 'host3')
    aggregate.update_custom_stats('test', 'host4')

# Generated at 2022-06-20 14:26:25.466857
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    class mock_AggregateStats:

        def __init__(self):
            self.stat1 = {'host1': 3, 'host2': 2}
            self.stat2 = {'host1': 3, 'host2': 2}
            self.stat3 = {'host1': 3, 'host2': 2}

    mock_stats = mock_AggregateStats()

    # Case 1: decrement a stat in normal case
    sut = AggregateStats()
    sut._decrement(mock_stats, 'stat1', 'host2')
    assert mock_stats.stat1['host2'] == 1

    # Case 2: decrement a stat that is not initialized
    sut = AggregateStats()
    sut._decrement(mock_stats, 'stat2', 'host3')
    assert mock_stats

# Generated at 2022-06-20 14:26:31.068121
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.processed == {}
    assert aggregate_stats.failures == {}
    assert aggregate_stats.ok == {}
    assert aggregate_stats.dark == {}
    assert aggregate_stats.changed == {}
    assert aggregate_stats.skipped == {}
    assert aggregate_stats.rescued == {}
    assert aggregate_stats.ignored == {}
    assert aggregate_stats.custom == {}



# Generated at 2022-06-20 14:26:37.688317
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    stats.increment('ok', 'test_host')

    assert stats.processed['test_host'] == 1, 'Processed should be incremented'
    assert stats.ok['test_host'] == 1, 'ok should be incremented'



# Generated at 2022-06-20 14:26:42.812530
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    ag = AggregateStats()
    # testing set custom stats with host
    ag.set_custom_stats('test_set_custom_stats', 'test value1', 'test_host')
    assert ag.custom['test_host']['test_set_custom_stats'] == 'test value1'
    # testing set custom stats without host
    ag.set_custom_stats('test_set_custom_stats', 'test value2')
    assert ag.custom['_run']['test_set_custom_stats'] == 'test value2'



# Generated at 2022-06-20 14:26:48.934648
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('some_key', 10)
    assert stats.custom == {'_run': {'some_key': 10}}
    stats.update_custom_stats('some_key', 10)
    assert stats.custom == {'_run': {'some_key': 20}}
    stats.update_custom_stats('some_key', {})
    assert stats.custom == {'_run': {'some_key': 20}}
    stats.update_custom_stats('some_key', {'foo': 'bar'})
    assert stats.custom == {'_run': {'some_key': {'foo': 'bar'}}}
    stats.update_custom_stats('some_key', {'foo': 'bar'})

# Generated at 2022-06-20 14:26:56.186510
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    assert(stats.ok == {'host1': 2, 'host2': 1})
    stats.decrement('ok', 'host1')
    assert(stats.ok == {'host1': 1, 'host2': 1})
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host2')
    assert(stats.ok == {'host1': 1, 'host2': 0})
    # This should never happen, but let's be safe
    stats.decrement('ok', 'host2')
    assert(stats.ok == {'host1': 1, 'host2': 0})