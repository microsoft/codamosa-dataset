

# Generated at 2022-06-20 14:25:57.484815
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregateStats = AggregateStats()
    aggregateStats.increment('ok', 'baz')
    aggregateStats.increment('ok', 'baz')
    print(aggregateStats.ok)
    print(aggregateStats.ok['baz'])
    print(aggregateStats.ok['baz'] == 2)


# Generated at 2022-06-20 14:26:04.005906
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    host = "127.0.0.1"

    stats.increment("ok", host)
    stats.increment("ok", host)
    stats.increment("failures", host)
    stats.increment("dark", host)
    stats.increment("dark", host)
    stats.increment("dark", host)
    stats.increment("changed", host)
    stats.increment("skipped", host)
    stats.increment("rescued", host)
    stats.increment("ignored", host)

    assert stats.summarize(host) == dict(
        ok=2, failures=1, unreachable=3, changed=1,
        skipped=1, rescued=1, ignored=1
    )

    stats.decrement("ok", host)
    stats

# Generated at 2022-06-20 14:26:11.374079
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    aggregate_stats.ok['127.0.0.1'] = 1
    aggregate_stats.failures['127.0.0.1'] = 3
    aggregate_stats.ok['127.0.0.2'] = 2
    aggregate_stats.failures['127.0.0.2'] = 4

    ret = aggregate_stats.summarize('127.0.0.1')
    assert ret['ok'] == 1
    assert ret['failures'] == 3

    ret = aggregate_stats.summarize('127.0.0.2')
    assert ret['ok'] == 2
    assert ret['failures'] == 4



# Generated at 2022-06-20 14:26:20.284690
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    # create a new AggregateStats object
    aggstats = AggregateStats()

    # see whether it is initialized as expected
    assert aggstats.processed == {}
    assert aggstats.failures == {}
    assert aggstats.ok == {}
    assert aggstats.dark == {}
    assert aggstats.changed == {}
    assert aggstats.skipped == {}
    assert aggstats.rescued == {}
    assert aggstats.ignored == {}
    assert aggstats.custom == {}


# Generated at 2022-06-20 14:26:27.395750
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    a = AggregateStats()
    a.update_custom_stats('foo', 1)
    assert a.custom == {'_run': {'foo': 1}}
    a.update_custom_stats('foo', 4)
    assert a.custom == {'_run': {'foo': 5}}
    a.update_custom_stats('foo', {'bar': 1, 'baz': 2})
    assert a.custom == {'_run': {'foo': {'bar': 1, 'baz': 2}}}
    a.update_custom_stats('foo', {'bar': 3, 'baz': 0})
    assert a.custom == {'_run': {'foo': {'bar': 4, 'baz': 2}}}
    a.update_custom_stats('foo', 'bar')

# Generated at 2022-06-20 14:26:35.299036
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    # Arrange
    stats = AggregateStats()
    stats.set_custom_stats('which1', 'what1')

    # Act
    stats.set_custom_stats('which1', 'what2')
    stats.set_custom_stats('which2', 'what3')

    # Assert
    assert stats.custom == {
        '_run': {
            'which1': 'what2',
            'which2': 'what3',
        }
    }


# Generated at 2022-06-20 14:26:40.135525
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
	
	as1 = AggregateStats()

	assert as1.processed == {}
	assert as1.failures == {}
	assert as1.ok == {}
	assert as1.dark == {}
	assert as1.changed == {}
	assert as1.skipped == {}
	assert as1.rescued == {}
	assert as1.ignored == {}
	assert as1.custom == {}


# Generated at 2022-06-20 14:26:48.413623
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Test when host exists and count > 0
    ast = AggregateStats()
    ast.processed['localhost'] = 1
    ast.ok['localhost'] = 1
    ast.failures['localhost'] = 1
    ast.dark['localhost'] = 1
    ast.changed['localhost'] = 1
    ast.skipped['localhost'] = 1
    ast.rescued['localhost'] = 1
    ast.ignored['localhost'] = 1
    ast.decrement('ok', 'localhost')
    ast.decrement('failures', 'localhost')
    ast.decrement('dark', 'localhost')
    ast.decrement('changed', 'localhost')
    ast.decrement('skipped', 'localhost')
    ast.decrement('rescued', 'localhost')

# Generated at 2022-06-20 14:26:52.610992
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    which = 'test_key'
    what = 10
    aggregate_stats.set_custom_stats(which, what)
    assert aggregate_stats.custom.get('_run').get(which) == what


# Generated at 2022-06-20 14:27:04.576444
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('failures', 'host1')
    stats.increment('failures', 'host2')
    stats.increment('failures', 'host2')
    stats.increment('dark', 'host2')
    stats.increment('changed', 'host1')
    stats.increment('changed', 'host1')
    stats.increment('changed', 'host2')
    stats.increment('changed', 'host2')
    stats.increment('skipped', 'host1')
    stats.increment('rescued', 'host2')
    stats.increment('ignored', 'host1')
    stats

# Generated at 2022-06-20 14:27:14.266002
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host')
    assert stats.ok['host'] == 1
    assert stats.processed['host'] == 1
    stats.increment('ok', 'host')
    assert stats.ok['host'] == 2
    assert stats.processed['host'] == 2
    stats.increment('ok', 'host')
    assert stats.ok['host'] == 3
    assert stats.processed['host'] == 3


# Generated at 2022-06-20 14:27:21.373666
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('skipped', 'localhost')
    stats.increment('skipped', 'localhost')

    assert stats.summarize('localhost') == dict(ok=3, failures=0, unreachable=0, changed=0, skipped=2, rescued=0, ignored=0)



# Generated at 2022-06-20 14:27:25.853865
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats('foo', 'bar')
    assert aggregate_stats.custom['_run']['foo'] == 'bar'



# Generated at 2022-06-20 14:27:30.824813
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():

    # declare AggregateStats object
    aggr_stats = AggregateStats()

    # declare task stats of a single host
    task_stats = aggr_stats.summarize("host1")

    # assert that all task results equal 0
    for task_stat in task_stats:
        assert task_stats[task_stat] == 0

# Generated at 2022-06-20 14:27:36.515824
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggr_stats = AggregateStats()
    aggr_stats.set_custom_stats('example', 'first')
    assert aggr_stats.custom['_run']['example'] == 'first'
    aggr_stats.set_custom_stats('example', 'second')
    assert aggr_stats.custom['_run']['example'] == 'second'


# Generated at 2022-06-20 14:27:49.500679
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    AS = AggregateStats()

    assert AS.custom == {}
    test_dict = {"this": "that"}
    AS.update_custom_stats("testing", test_dict, host="this1")
    assert AS.custom == {"this1":{"testing":{"this":"that"}}}

    test_dict2 = {"this": "that2"}
    AS.update_custom_stats("testing", test_dict2, host="this1")
    assert AS.custom == {"this1":{"testing":{"this":"that that2"}}}

    test_dict3 = {"this": "that3", "foo":"bar"}
    AS.update_custom_stats("testing", test_dict3, host="this1")
    assert AS.custom == {"this1":{"testing":{"this":"that that2 that3", "foo":"bar"}}}

# Generated at 2022-06-20 14:27:54.300145
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    a = AggregateStats()

    a.increment('skipped', 'localhost')
    assert a.skipped['localhost'] == 1
    a.decrement('skipped', 'localhost')
    assert a.skipped['localhost'] == 0


# Generated at 2022-06-20 14:28:04.648371
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    test_stats = AggregateStats()
    print(test_stats)
    # Return something of type dict
    assert isinstance(test_stats.summarize('localhost'), dict)
    # Return an empty dict
    assert test_stats.summarize('localhost') == {}
    test_stats.increment('ok', 'localhost')
    print(test_stats)
    assert test_stats.summarize('localhost')['ok'] == 1
    test_stats.increment('ok', 'localhost1')
    assert test_stats.summarize('localhost1')['ok'] == 1
    test_stats.increment('ok', 'localhost')
    assert test_stats.summarize('localhost')['ok'] == 2
    print(test_stats)
    print(test_stats.summarize('localhost'))
    assert test_

# Generated at 2022-06-20 14:28:15.678524
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats('deployments', {'deployed': 1}, '127.0.0.1')
    aggregate_stats.update_custom_stats('deployments', {'deployed': 1}, '127.0.0.1')
    aggregate_stats.update_custom_stats('deployments', {'deployed': 1}, '127.0.0.1')
    aggregate_stats.update_custom_stats('deployments', {'deployed': 1}, '127.0.0.1')
    aggregate_stats.update_custom_stats('deployments', {'deployed': 1}, '127.0.0.1')

# Generated at 2022-06-20 14:28:26.829997
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    # create instance of class
    agg_stats = AggregateStats()

    # create a sample host for testing
    host = 'test_host'

    # create a sample playbook result for testing