

# Generated at 2022-06-16 21:15:37.771694
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('test', 'value')
    assert stats.custom['_run']['test'] == 'value'
    stats.update_custom_stats('test', 'value')
    assert stats.custom['_run']['test'] == 'value'
    stats.update_custom_stats('test', {'key': 'value'})
    assert stats.custom['_run']['test'] == {'key': 'value'}
    stats.update_custom_stats('test', {'key': 'value'})
    assert stats.custom['_run']['test'] == {'key': 'value'}
    stats.update_custom_stats('test', {'key': 'value', 'key2': 'value2'})

# Generated at 2022-06-16 21:15:49.631921
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')

# Generated at 2022-06-16 21:16:00.100860
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 2
    assert stats.ok['host2'] == 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 2

# Generated at 2022-06-16 21:16:10.280708
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 2})
    assert stats.custom['_run']['foo'] == {'bar': 3}
    stats.update_custom_stats('foo', {'bar': 2, 'baz': 1})
    assert stats.custom['_run']['foo'] == {'bar': 5, 'baz': 1}
    stats.update_custom_stats('foo', {'bar': 2, 'baz': 1}, 'host1')
    assert stats.custom['host1']['foo'] == {'bar': 2, 'baz': 1}
    stats.update_custom_

# Generated at 2022-06-16 21:16:20.720016
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 1
    stats.update_custom_stats('foo', 2)
    assert stats.custom['_run']['foo'] == 3
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'
    stats.update_custom_stats('foo', {'a': 1, 'b': 2})
    assert stats.custom['_run']['foo'] == {'a': 1, 'b': 2}
    stats.update_custom_stats('foo', {'a': 3, 'c': 4})

# Generated at 2022-06-16 21:16:31.828454
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')

# Generated at 2022-06-16 21:16:40.693667
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('a', 1)
    assert stats.custom['_run']['a'] == 1
    stats.update_custom_stats('a', 1)
    assert stats.custom['_run']['a'] == 2
    stats.update_custom_stats('a', 1, 'host1')
    assert stats.custom['_run']['a'] == 2
    assert stats.custom['host1']['a'] == 1
    stats.update_custom_stats('a', 1, 'host1')
    assert stats.custom['_run']['a'] == 2
    assert stats.custom['host1']['a'] == 2
    stats.update_custom_stats('b', {'b': 1})
    assert stats.custom['_run']['b']

# Generated at 2022-06-16 21:16:47.094724
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 1
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 2
    stats.increment('ok', 'host2')
    assert stats.ok['host2'] == 1
    stats.increment('ok', 'host2')
    assert stats.ok['host2'] == 2


# Generated at 2022-06-16 21:16:50.839194
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 2
    stats.increment('ok', '127.0.0.1')
    assert stats.ok['127.0.0.1'] == 1


# Generated at 2022-06-16 21:16:55.121749
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    assert stats.processed['localhost'] == 1


# Generated at 2022-06-16 21:17:02.773171
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 2
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-16 21:17:10.122672
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 0
    assert stats.ok['host3'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 0
    assert stats.ok['host3'] == 1

# Generated at 2022-06-16 21:17:17.365319
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 2
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-16 21:17:22.416217
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-16 21:17:26.724293
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'test_host')
    stats.decrement('ok', 'test_host')
    assert stats.ok['test_host'] == 0
    stats.decrement('ok', 'test_host')
    assert stats.ok['test_host'] == 0


# Generated at 2022-06-16 21:17:36.741329
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 0


# Generated at 2022-06-16 21:17:46.475863
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0


# Generated at 2022-06-16 21:17:56.134309
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Create an instance of AggregateStats
    stats = AggregateStats()
    # Set initial values for the attributes
    stats.ok = {'host1': 1, 'host2': 2}
    stats.failures = {'host1': 3, 'host2': 4}
    stats.dark = {'host1': 5, 'host2': 6}
    stats.changed = {'host1': 7, 'host2': 8}
    stats.skipped = {'host1': 9, 'host2': 10}
    stats.rescued = {'host1': 11, 'host2': 12}
    stats.ignored = {'host1': 13, 'host2': 14}
    # Call the method
    stats.decrement('ok', 'host1')
    stats.decrement('failures', 'host1')

# Generated at 2022-06-16 21:18:06.062554
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    assert stats.ok['host1'] == 3
    assert stats.ok['host2'] == 4
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 2
    assert stats.ok['host2'] == 3
    stats.decrement('ok', 'host1')

# Generated at 2022-06-16 21:18:10.553626
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2