

# Generated at 2022-06-16 21:15:37.572737
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'

    stats.update_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'

    stats.update_custom_stats('foo', 'bar', 'localhost')
    assert stats.custom['localhost']['foo'] == 'bar'

    stats.update_custom_stats('foo', 'bar', 'localhost')
    assert stats.custom['localhost']['foo'] == 'bar'

    stats.update_custom_stats('foo', {'bar': 'baz'})
    assert stats.custom['_run']['foo'] == {'bar': 'baz'}


# Generated at 2022-06-16 21:15:46.145846
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 0


# Generated at 2022-06-16 21:15:57.592616
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')

# Generated at 2022-06-16 21:15:59.788729
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    assert stats.processed['localhost'] == 1
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 2
    assert stats.processed['localhost'] == 1


# Generated at 2022-06-16 21:16:10.061288
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 1
    stats.update_custom_stats('foo', 2)
    assert stats.custom['_run']['foo'] == 3
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 2})
    assert stats.custom['_run']['foo'] == {'bar': 3}
    stats.update_custom_stats('foo', {'bar': 2, 'baz': 1})
    assert stats.custom['_run']['foo'] == {'bar': 5, 'baz': 1}
    stats

# Generated at 2022-06-16 21:16:17.887844
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2

# Generated at 2022-06-16 21:16:23.823889
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    assert stats.ok['host1'] == 2
    assert stats.ok['host2'] == 3
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 3
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1


# Generated at 2022-06-16 21:16:31.078060
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 1
    assert stats.processed['host1'] == 1
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 2
    assert stats.processed['host1'] == 1
    stats.increment('ok', 'host2')
    assert stats.ok['host2'] == 1
    assert stats.processed['host2'] == 1


# Generated at 2022-06-16 21:16:40.045361
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    assert stats.ok['host1'] == 2
    assert stats.ok['host2'] == 3
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 0

# Generated at 2022-06-16 21:16:45.485627
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')

# Generated at 2022-06-16 21:16:51.340491
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1


# Generated at 2022-06-16 21:17:00.671901
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.ok['localhost'] = 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.ok['localhost'] = 2
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0


# Generated at 2022-06-16 21:17:09.306946
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')

# Generated at 2022-06-16 21:17:14.619403
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0


# Generated at 2022-06-16 21:17:20.324509
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host3')
    stats.decrement('ok', 'host3')
    stats.decrement('ok', 'host3')
    stats.decrement('ok', 'host3')
   

# Generated at 2022-06-16 21:17:27.393855
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 0
    assert stats.ok['host3'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 0

# Generated at 2022-06-16 21:17:30.925998
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host')
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 0
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 0

# Generated at 2022-06-16 21:17:36.141928
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'test_host')
    stats.decrement('ok', 'test_host')
    assert stats.ok['test_host'] == 0
    stats.decrement('ok', 'test_host')
    assert stats.ok['test_host'] == 0


# Generated at 2022-06-16 21:17:48.062054
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    assert stats.ok['host3'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 0
    assert stats.ok['host3'] == 1
    stats.decrement('ok', 'host3')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 0
    assert stats.ok['host3'] == 0
    stats

# Generated at 2022-06-16 21:17:49.588542
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1
