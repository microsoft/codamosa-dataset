

# Generated at 2022-06-16 21:15:34.545461
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1


# Generated at 2022-06-16 21:15:44.882768
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1

# Generated at 2022-06-16 21:15:56.716903
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'bar': 1}, 'localhost')
    assert stats.custom['localhost']['foo']['bar'] == 1
    stats.update_custom_stats('foo', {'bar': 2}, 'localhost')
    assert stats.custom['localhost']['foo']['bar'] == 3
    stats.update_custom_stats('foo', {'bar': {'baz': 1}}, 'localhost')
    assert stats.custom['localhost']['foo']['bar']['baz'] == 1
    stats.update_custom_stats('foo', {'bar': {'baz': 2}}, 'localhost')
    assert stats.custom['localhost']['foo']['bar']['baz'] == 3

# Generated at 2022-06-16 21:16:00.553300
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0


# Generated at 2022-06-16 21:16:04.769481
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1

# Generated at 2022-06-16 21:16:09.727132
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 1
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 2
    stats.increment('ok', 'host2')
    assert stats.ok['host2'] == 1
    assert stats.ok['host1'] == 2


# Generated at 2022-06-16 21:16:20.363126
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 2})
    assert stats.custom['_run']['foo'] == {'bar': 3}
    stats.update_custom_stats('foo', {'baz': 1})
    assert stats.custom['_run']['foo'] == {'bar': 3, 'baz': 1}
    stats.update_custom_stats('foo', {'bar': 1, 'baz': 2})
    assert stats.custom['_run']['foo'] == {'bar': 4, 'baz': 3}

# Generated at 2022-06-16 21:16:31.703404
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host4')
    stats.increment('ok', 'host5')
    stats.increment('ok', 'host6')
    stats.increment('ok', 'host7')
    stats.increment('ok', 'host8')
    stats.increment('ok', 'host9')
    stats.increment('ok', 'host10')
    stats.increment('ok', 'host11')
    stats.increment('ok', 'host12')
    stats.increment('ok', 'host13')
    stats.increment('ok', 'host14')

# Generated at 2022-06-16 21:16:40.589277
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 0
    stats.decrement('ok', 'host2')

# Generated at 2022-06-16 21:16:45.742915
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')

# Generated at 2022-06-16 21:16:52.181168
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 0
    stats.ok['host2'] = 2
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 1


# Generated at 2022-06-16 21:17:02.669430
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment("ok", "host1")
    stats.increment("ok", "host1")
    stats.increment("ok", "host1")
    stats.increment("ok", "host2")
    stats.increment("ok", "host2")
    stats.increment("ok", "host2")
    stats.increment("ok", "host2")
    stats.increment("ok", "host2")
    stats.increment("ok", "host2")
    stats.increment("ok", "host2")
    stats.increment("ok", "host2")
    stats.increment("ok", "host2")
    stats.increment("ok", "host2")
    stats.increment("ok", "host2")

# Generated at 2022-06-16 21:17:09.458200
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 0

# Generated at 2022-06-16 21:17:17.684528
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'testhost')
    assert stats.ok['testhost'] == 0
    stats.ok['testhost'] = 1
    stats.decrement('ok', 'testhost')
    assert stats.ok['testhost'] == 0
    stats.ok['testhost'] = 2
    stats.decrement('ok', 'testhost')
    assert stats.ok['testhost'] == 1
    stats.decrement('ok', 'testhost')
    assert stats.ok['testhost'] == 0
    stats.decrement('ok', 'testhost')
    assert stats.ok['testhost'] == 0


# Generated at 2022-06-16 21:17:28.245530
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 4
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 3
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 2
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')

# Generated at 2022-06-16 21:17:35.143905
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-16 21:17:45.269665
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1

# Generated at 2022-06-16 21:17:55.514749
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host4')
    stats.increment('ok', 'host5')
    stats.increment('ok', 'host6')
    stats.increment('ok', 'host7')
    stats.increment('ok', 'host8')
    stats.increment('ok', 'host9')
    stats.increment('ok', 'host10')
    stats.increment('ok', 'host11')
    stats.increment('ok', 'host12')
    stats.increment('ok', 'host13')
    stats.increment('ok', 'host14')

# Generated at 2022-06-16 21:18:05.892835
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')

# Generated at 2022-06-16 21:18:08.476385
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0