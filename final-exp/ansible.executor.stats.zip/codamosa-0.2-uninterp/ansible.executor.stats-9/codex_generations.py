

# Generated at 2022-06-16 21:15:37.738382
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('failures', 'host1')
    stats.increment('failures', 'host1')
    stats.increment('failures', 'host2')
    stats.increment('failures', 'host2')
    stats.increment('failures', 'host2')
    stats.increment('failures', 'host2')
    stats.increment('failures', 'host2')
    stats.increment('failures', 'host2')
    stats.increment('failures', 'host2')


# Generated at 2022-06-16 21:15:49.588966
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 1

    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 2

    stats.update_custom_stats('foo', 1, 'localhost')
    assert stats.custom['localhost']['foo'] == 1

    stats.update_custom_stats('foo', 1, 'localhost')
    assert stats.custom['localhost']['foo'] == 2

    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}

    stats.update_custom_stats('foo', {'bar': 1})

# Generated at 2022-06-16 21:15:56.819881
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 0
    assert stats.ok['host3'] == 1
    assert stats.ok.get('host4', 0) == 0


# Generated at 2022-06-16 21:16:07.189525
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 1
    stats.update_custom_stats('foo', 2)
    assert stats.custom['_run']['foo'] == 3
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 2})
    assert stats.custom['_run']['foo'] == {'bar': 3}
    stats.update_custom_stats('foo', {'bar': 2, 'baz': 1})
    assert stats.custom['_run']['foo'] == {'bar': 5, 'baz': 1}
    stats

# Generated at 2022-06-16 21:16:13.009784
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')

# Generated at 2022-06-16 21:16:21.992033
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 0


# Generated at 2022-06-16 21:16:32.124378
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 3
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 2
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0


# Generated at 2022-06-16 21:16:40.930656
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 2})
    assert stats.custom['_run']['foo'] == {'bar': 3}
    stats.update_custom_stats('foo', {'bar': 2, 'baz': 1})
    assert stats.custom['_run']['foo'] == {'bar': 5, 'baz': 1}
    stats.update_custom_stats('foo', {'bar': 2, 'baz': 1}, 'host1')
    assert stats.custom['_run']['foo'] == {'bar': 5, 'baz': 1}

# Generated at 2022-06-16 21:16:50.314164
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host4')
    stats.increment('ok', 'host5')
    stats.increment('ok', 'host6')
    stats.increment('ok', 'host7')
    stats.increment('ok', 'host8')
    stats.increment('ok', 'host9')
    stats.increment('ok', 'host10')
    stats.increment('ok', 'host11')
    stats.increment('ok', 'host12')
    stats.increment('ok', 'host13')
    stats.increment('ok', 'host14')

# Generated at 2022-06-16 21:16:55.891145
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
