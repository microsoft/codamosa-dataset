

# Generated at 2022-06-16 21:15:35.210949
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 2
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-16 21:15:46.728100
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host4')
    stats.increment('ok', 'host5')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 1
    assert stats.ok['host3'] == 1
    assert stats.ok['host4'] == 1
    assert stats.ok['host5'] == 1
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host3')
    stats.decrement('ok', 'host4')

# Generated at 2022-06-16 21:15:58.199554
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('test', {'a': 1, 'b': 2})
    assert stats.custom['_run']['test'] == {'a': 1, 'b': 2}
    stats.update_custom_stats('test', {'a': 2, 'c': 3})
    assert stats.custom['_run']['test'] == {'a': 3, 'b': 2, 'c': 3}
    stats.update_custom_stats('test', {'a': 2, 'c': 3}, 'host1')
    assert stats.custom['host1']['test'] == {'a': 2, 'c': 3}
    stats.update_custom_stats('test', {'a': 2, 'c': 3}, 'host1')

# Generated at 2022-06-16 21:16:08.695484
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host4')
    stats.increment('ok', 'host4')
    stats.increment('ok', 'host4')
    stats.increment('ok', 'host4')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host3')
    stats.decrement('ok', 'host4')
    assert stats.ok

# Generated at 2022-06-16 21:16:16.924098
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 1
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 2
    stats.increment('ok', 'host2')
    assert stats.ok['host2'] == 1
    stats.increment('ok', 'host2')
    assert stats.ok['host2'] == 2
    stats.increment('ok', 'host2')
    assert stats.ok['host2'] == 3


# Generated at 2022-06-16 21:16:20.973308
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 1
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 2
    stats.increment('ok', 'host2')
    assert stats.ok['host2'] == 1


# Generated at 2022-06-16 21:16:32.084380
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 1
    stats.update_custom_stats('foo', 2)
    assert stats.custom['_run']['foo'] == 3
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 2})
    assert stats.custom['_run']['foo'] == {'bar': 3}
    stats.update_custom_stats('foo', {'baz': 1})
    assert stats.custom['_run']['foo'] == {'bar': 3, 'baz': 1}
    stats.update_custom_

# Generated at 2022-06-16 21:16:40.897093
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'a': 1, 'b': 2})
    assert stats.custom['_run']['foo'] == {'a': 1, 'b': 2}
    stats.update_custom_stats('foo', {'a': 2, 'c': 3})
    assert stats.custom['_run']['foo'] == {'a': 3, 'b': 2, 'c': 3}
    stats.update_custom_stats('foo', {'a': 4, 'd': 5}, host='host1')
    assert stats.custom['_run']['foo'] == {'a': 3, 'b': 2, 'c': 3}
    assert stats.custom['host1']['foo'] == {'a': 4, 'd': 5}

# Generated at 2022-06-16 21:16:50.284765
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 2})
    assert stats.custom['_run']['foo'] == {'bar': 3}
    stats.update_custom_stats('foo', {'baz': 1})
    assert stats.custom['_run']['foo'] == {'bar': 3, 'baz': 1}
    stats.update_custom_stats('foo', {'baz': 2})
    assert stats.custom['_run']['foo'] == {'bar': 3, 'baz': 3}
    stats.update_custom_stats('foo', {'baz': 'a'})


# Generated at 2022-06-16 21:16:58.185209
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
