

# Generated at 2022-06-16 21:15:37.771063
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 1
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 2
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 2}
    stats.update_custom_stats('foo', {'bar': 1, 'baz': 1})
    assert stats.custom['_run']['foo'] == {'bar': 3, 'baz': 1}
    stats

# Generated at 2022-06-16 21:15:47.713328
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 0
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 0


# Generated at 2022-06-16 21:15:53.549369
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'test')
    assert stats.ok['test'] == 1
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 0
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 0


# Generated at 2022-06-16 21:16:00.308387
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 1
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 2
    stats.increment('ok', 'host2')
    assert stats.ok['host2'] == 1
    stats.increment('ok', 'host2')
    assert stats.ok['host2'] == 2
    stats.increment('ok', 'host2')
    assert stats.ok['host2'] == 3


# Generated at 2022-06-16 21:16:09.414969
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 2
    stats.increment('ok', '127.0.0.1')
    assert stats.ok['127.0.0.1'] == 1
    stats.increment('ok', '127.0.0.1')
    assert stats.ok['127.0.0.1'] == 2
    stats.increment('ok', '127.0.0.1')
    assert stats.ok['127.0.0.1'] == 3


# Generated at 2022-06-16 21:16:20.174202
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')

# Generated at 2022-06-16 21:16:30.957408
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 3
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 2
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-16 21:16:39.931601
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 3
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 3
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 3

# Generated at 2022-06-16 21:16:49.458080
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host4')
    stats.increment('ok', 'host5')
    stats.increment('ok', 'host6')
    stats.increment('ok', 'host7')
    stats.increment('ok', 'host8')
    stats.increment('ok', 'host9')
    stats.increment('ok', 'host10')
    stats.increment('ok', 'host11')
    stats.increment('ok', 'host12')
    stats.increment('ok', 'host13')
    stats.increment('ok', 'host14')

# Generated at 2022-06-16 21:17:01.392186
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')

# Generated at 2022-06-16 21:17:14.092924
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'bar': 1}, 'localhost')
    assert stats.custom['localhost']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 1}, 'localhost')
    assert stats.custom['localhost']['foo'] == {'bar': 2}
    stats.update_custom_stats('foo', {'bar': 1, 'baz': 2}, 'localhost')
    assert stats.custom['localhost']['foo'] == {'bar': 3, 'baz': 2}
    stats.update_custom_stats('foo', {'bar': 1, 'baz': 2}, 'localhost')
    assert stats.custom['localhost']['foo'] == {'bar': 4, 'baz': 4}

# Generated at 2022-06-16 21:17:20.056980
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats("foo", 1)
    assert stats.custom == {'_run': {'foo': 1}}
    stats.update_custom_stats("foo", 1)
    assert stats.custom == {'_run': {'foo': 2}}
    stats.update_custom_stats("foo", 1, "bar")
    assert stats.custom == {'_run': {'foo': 2}, 'bar': {'foo': 1}}
    stats.update_custom_stats("foo", 1, "bar")
    assert stats.custom == {'_run': {'foo': 2}, 'bar': {'foo': 2}}
    stats.update_custom_stats("foo", {'bar': 1}, "bar")

# Generated at 2022-06-16 21:17:30.203203
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 2})
    assert stats.custom['_run']['foo'] == {'bar': 3}
    stats.update_custom_stats('foo', {'bar': 2, 'baz': 1})
    assert stats.custom['_run']['foo'] == {'bar': 5, 'baz': 1}
    stats.update_custom_stats('foo', {'bar': 2, 'baz': 1})
    assert stats.custom['_run']['foo'] == {'bar': 7, 'baz': 2}

# Generated at 2022-06-16 21:17:38.643161
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 1, 'host1')
    assert stats.custom['host1']['foo'] == 1
    stats.update_custom_stats('foo', 1, 'host1')
    assert stats.custom['host1']['foo'] == 2
    stats.update_custom_stats('foo', {'bar': 1}, 'host1')
    assert stats.custom['host1']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 1}, 'host1')
    assert stats.custom['host1']['foo'] == {'bar': 2}
    stats.update_custom_stats('foo', {'bar': 1, 'baz': 1}, 'host1')

# Generated at 2022-06-16 21:17:49.878985
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('test', 'test')
    assert stats.custom['_run']['test'] == 'test'
    stats.update_custom_stats('test', 'test')
    assert stats.custom['_run']['test'] == 'test'
    stats.update_custom_stats('test', 'test', 'host')
    assert stats.custom['host']['test'] == 'test'
    stats.update_custom_stats('test', 'test', 'host')
    assert stats.custom['host']['test'] == 'test'
    stats.update_custom_stats('test', {'test': 'test'})
    assert stats.custom['_run']['test'] == {'test': 'test'}

# Generated at 2022-06-16 21:17:57.811524
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'
    stats.update_custom_stats('foo', 'baz')
    assert stats.custom['_run']['foo'] == 'baz'
    stats.update_custom_stats('foo', 'baz', 'localhost')
    assert stats.custom['localhost']['foo'] == 'baz'
    stats.update_custom_stats('foo', 'baz', 'localhost')
    assert stats.custom['localhost']['foo'] == 'baz'
    stats.update_custom_stats('foo', 'baz', 'localhost')
    assert stats.custom['localhost']['foo'] == 'baz'

# Generated at 2022-06-16 21:18:06.461485
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Test with a dict
    stats = AggregateStats()
    stats.update_custom_stats('dict', {'a': 1, 'b': 2})
    assert stats.custom['_run']['dict'] == {'a': 1, 'b': 2}
    stats.update_custom_stats('dict', {'a': 2, 'c': 3})
    assert stats.custom['_run']['dict'] == {'a': 3, 'b': 2, 'c': 3}
    stats.update_custom_stats('dict', {'a': 1, 'b': 2, 'c': 3})
    assert stats.custom['_run']['dict'] == {'a': 4, 'b': 4, 'c': 6}

# Generated at 2022-06-16 21:18:15.158139
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'
    stats.update_custom_stats('foo', 'baz')
    assert stats.custom['_run']['foo'] == 'baz'
    stats.update_custom_stats('foo', 'bar', 'host1')
    assert stats.custom['host1']['foo'] == 'bar'
    stats.update_custom_stats('foo', 'baz', 'host1')
    assert stats.custom['host1']['foo'] == 'baz'
    stats.update_custom_stats('foo', 'bar', 'host2')
    assert stats.custom['host2']['foo'] == 'bar'

# Generated at 2022-06-16 21:18:21.967416
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'bar': 1, 'baz': 2})
    assert stats.custom['_run']['foo'] == {'bar': 1, 'baz': 2}
    stats.update_custom_stats('foo', {'bar': 3, 'baz': 4})
    assert stats.custom['_run']['foo'] == {'bar': 4, 'baz': 6}
    stats.update_custom_stats('foo', {'bar': 'a', 'baz': 'b'})
    assert stats.custom['_run']['foo'] == {'bar': 'a', 'baz': 'b'}
    stats.update_custom_stats('foo', {'bar': 'c', 'baz': 'd'})
    assert stats.custom

# Generated at 2022-06-16 21:18:31.920712
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'
    stats.update_custom_stats('foo', 'baz')
    assert stats.custom['_run']['foo'] == 'baz'
    stats.update_custom_stats('foo', {'bar': 'baz'})
    assert stats.custom['_run']['foo'] == {'bar': 'baz'}
    stats.update_custom_stats('foo', {'bar': 'baz', 'qux': 'quux'})
    assert stats.custom['_run']['foo'] == {'bar': 'baz', 'qux': 'quux'}