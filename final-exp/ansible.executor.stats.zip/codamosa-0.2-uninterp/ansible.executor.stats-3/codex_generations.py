

# Generated at 2022-06-16 21:15:39.017888
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    stats.ok['host1'] = 0
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0


# Generated at 2022-06-16 21:15:51.315751
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host2')
   

# Generated at 2022-06-16 21:16:01.068719
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')

# Generated at 2022-06-16 21:16:10.825257
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 0


# Generated at 2022-06-16 21:16:21.085144
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host4')
    stats.increment('ok', 'host5')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host3')
    stats.decrement('ok', 'host4')
    stats.decrement('ok', 'host5')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 0
    assert stats.ok['host3'] == 0
    assert stats.ok['host4'] == 0

# Generated at 2022-06-16 21:16:28.742895
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2

# Generated at 2022-06-16 21:16:38.123510
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo']['bar'] == 1
    stats.update_custom_stats('foo', {'bar': 2})
    assert stats.custom['_run']['foo']['bar'] == 3
    stats.update_custom_stats('foo', {'bar': 'a'})
    assert stats.custom['_run']['foo']['bar'] == 'a'
    stats.update_custom_stats('foo', {'bar': 'b'})
    assert stats.custom['_run']['foo']['bar'] == 'ab'
    stats.update_custom_stats('foo', {'bar': 'c'})

# Generated at 2022-06-16 21:16:44.559517
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 2
    assert stats.ok['host2'] == 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 2

# Generated at 2022-06-16 21:16:51.949710
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 2})
    assert stats.custom['_run']['foo'] == {'bar': 3}
    stats.update_custom_stats('foo', {'bar': 2, 'baz': 1})
    assert stats.custom['_run']['foo'] == {'bar': 5, 'baz': 1}
    stats.update_custom_stats('foo', {'baz': 2})
    assert stats.custom['_run']['foo'] == {'bar': 5, 'baz': 3}

# Generated at 2022-06-16 21:17:02.634584
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 4
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 3
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 2
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-16 21:17:15.258000
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'
    stats.update_custom_stats('foo', 'baz')
    assert stats.custom['_run']['foo'] == 'baz'
    stats.update_custom_stats('foo', 'baz', 'localhost')
    assert stats.custom['_run']['foo'] == 'baz'
    assert stats.custom['localhost']['foo'] == 'baz'
    stats.update_custom_stats('foo', 'baz', 'localhost')

# Generated at 2022-06-16 21:17:25.984448
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 1
    stats.update_custom_stats('foo', 2)
    assert stats.custom['_run']['foo'] == 3
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 2})
    assert stats.custom['_run']['foo'] == {'bar': 3}
    stats.update_custom_stats('foo', {'bar': 2, 'baz': 1})
    assert stats.custom['_run']['foo'] == {'bar': 5, 'baz': 1}
    stats

# Generated at 2022-06-16 21:17:36.431894
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 1
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 2
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 2}
    stats.update_custom_stats('foo', {'bar': 1, 'baz': 2})
    assert stats.custom['_run']['foo'] == {'bar': 3, 'baz': 2}
    stats

# Generated at 2022-06-16 21:17:48.340991
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 1, 'host1')
    assert stats.custom['host1']['foo'] == 1
    stats.update_custom_stats('foo', 1, 'host1')
    assert stats.custom['host1']['foo'] == 2
    stats.update_custom_stats('foo', {'bar': 1}, 'host1')
    assert stats.custom['host1']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 1}, 'host1')
    assert stats.custom['host1']['foo'] == {'bar': 2}
    stats.update_custom_stats('foo', {'bar': 1, 'baz': 1}, 'host1')

# Generated at 2022-06-16 21:17:57.085620
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'
    stats.update_custom_stats('foo', 'baz')
    assert stats.custom['_run']['foo'] == 'baz'
    stats.update_custom_stats('foo', 'baz', 'localhost')
    assert stats.custom['localhost']['foo'] == 'baz'
    stats.update_custom_stats('foo', 'baz', 'localhost')
    assert stats.custom['localhost']['foo'] == 'baz'

# Generated at 2022-06-16 21:18:06.411223
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 2})
    assert stats.custom['_run']['foo'] == {'bar': 3}
    stats.update_custom_stats('foo', {'bar': 1, 'baz': 1})
    assert stats.custom['_run']['foo'] == {'bar': 4, 'baz': 1}
    stats.update_custom_stats('foo', {'bar': 1, 'baz': 2})
    assert stats.custom['_run']['foo'] == {'bar': 5, 'baz': 3}

# Generated at 2022-06-16 21:18:12.684978
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 1
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 2
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 2}
    stats.update_custom_stats('foo', {'bar': 1, 'baz': 2})
    assert stats.custom['_run']['foo'] == {'bar': 3, 'baz': 2}
    stats

# Generated at 2022-06-16 21:18:20.868375
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 1
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 2
    stats.update_custom_stats('foo', 1, 'host1')
    assert stats.custom['host1']['foo'] == 1
    stats.update_custom_stats('foo', 1, 'host1')
    assert stats.custom['host1']['foo'] == 2
    stats.update_custom_stats('foo', {'bar': 1}, 'host1')
    assert stats.custom['host1']['foo'] == {'bar': 1}

# Generated at 2022-06-16 21:18:31.308051
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 2}
    stats.update_custom_stats('foo', {'bar': 1, 'baz': 1})
    assert stats.custom['_run']['foo'] == {'bar': 3, 'baz': 1}
    stats.update_custom_stats('foo', {'bar': 1, 'baz': 1})
    assert stats.custom['_run']['foo'] == {'bar': 4, 'baz': 2}

# Generated at 2022-06-16 21:18:38.647516
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 2})
    assert stats.custom['_run']['foo'] == {'bar': 3}
    stats.update_custom_stats('foo', {'bar': 1, 'baz': 2})
    assert stats.custom['_run']['foo'] == {'bar': 4, 'baz': 2}
    stats.update_custom_stats('foo', {'baz': 1})
    assert stats.custom['_run']['foo'] == {'bar': 4, 'baz': 3}