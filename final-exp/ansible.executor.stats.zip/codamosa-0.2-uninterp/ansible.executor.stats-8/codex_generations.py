

# Generated at 2022-06-16 21:15:33.546618
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0

# Generated at 2022-06-16 21:15:40.196780
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('test', 'test')
    assert stats.custom['_run']['test'] == 'test'
    stats.update_custom_stats('test', 'test')
    assert stats.custom['_run']['test'] == 'test'
    stats.update_custom_stats('test', 'test2')
    assert stats.custom['_run']['test'] == 'test2'
    stats.update_custom_stats('test', {'test': 'test'})
    assert stats.custom['_run']['test'] == {'test': 'test'}
    stats.update_custom_stats('test', {'test': 'test2'})
    assert stats.custom['_run']['test'] == {'test': 'test2'}
    stats

# Generated at 2022-06-16 21:15:46.868590
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1

# Generated at 2022-06-16 21:15:58.199944
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')

# Generated at 2022-06-16 21:16:08.711060
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo']['bar'] == 1
    stats.update_custom_stats('foo', {'bar': 2})
    assert stats.custom['_run']['foo']['bar'] == 3
    stats.update_custom_stats('foo', {'bar': {'baz': 1}})
    assert stats.custom['_run']['foo']['bar']['baz'] == 1
    stats.update_custom_stats('foo', {'bar': {'baz': 2}})
    assert stats.custom['_run']['foo']['bar']['baz'] == 3

# Generated at 2022-06-16 21:16:19.649623
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'
    stats.update_custom_stats('foo', 'baz')
    assert stats.custom['_run']['foo'] == 'baz'
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 1
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 2
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 3


# Generated at 2022-06-16 21:16:30.675415
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0


# Generated at 2022-06-16 21:16:39.633545
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')

# Generated at 2022-06-16 21:16:49.162548
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 3
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 2
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 0

# Generated at 2022-06-16 21:16:53.245415
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 2
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
