

# Generated at 2022-06-16 21:15:38.454271
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 0


# Generated at 2022-06-16 21:15:43.748535
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0


# Generated at 2022-06-16 21:15:55.377360
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host2')
    stats.dec

# Generated at 2022-06-16 21:16:05.620185
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')

# Generated at 2022-06-16 21:16:10.438729
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1

# Generated at 2022-06-16 21:16:20.805927
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'
    stats.update_custom_stats('foo', 'baz')
    assert stats.custom['_run']['foo'] == 'baz'
    stats.update_custom_stats('foo', 'baz', 'host1')
    assert stats.custom['host1']['foo'] == 'baz'
    stats.update_custom_stats('foo', {'a': 1, 'b': 2})
    assert stats.custom['_run']['foo'] == {'a': 1, 'b': 2}
    stats.update_custom_stats('foo', {'b': 3, 'c': 4})

# Generated at 2022-06-16 21:16:31.917508
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 2
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 3
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 4
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 5
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 6
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 7
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 8

# Generated at 2022-06-16 21:16:40.761241
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 1
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 2
    stats.update_custom_stats('foo', 1, 'bar')
    assert stats.custom['bar']['foo'] == 1
    stats.update_custom_stats('foo', 1, 'bar')
    assert stats.custom['bar']['foo'] == 2
    stats.update_custom_stats('foo', {'a': 1}, 'bar')
    assert stats.custom['bar']['foo'] == {'a': 1}
    stats.update_custom_stats('foo', {'b': 2}, 'bar')
    assert stats.custom

# Generated at 2022-06-16 21:16:46.004197
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 1
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 2
    stats.increment('ok', 'host2')
    assert stats.ok['host2'] == 1


# Generated at 2022-06-16 21:16:52.707401
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 1
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 2
    stats.increment('ok', 'host2')
    assert stats.ok['host2'] == 1
    stats.increment('ok', 'host2')
    assert stats.ok['host2'] == 2
    stats.increment('ok', 'host2')
    assert stats.ok['host2'] == 3
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 3
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 4
    stats.increment('ok', 'host1')
    assert stats

# Generated at 2022-06-16 21:17:03.757030
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    assert stats.ok['host3'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 0
    assert stats.ok['host3'] == 1
    stats.decrement('ok', 'host3')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 0
    assert stats.ok['host3'] == 0
    stats

# Generated at 2022-06-16 21:17:07.968369
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-16 21:17:15.665296
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 2
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-16 21:17:26.647215
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host4')
    stats.increment('ok', 'host5')
    stats.increment('ok', 'host6')
    stats.increment('ok', 'host7')
    stats.increment('ok', 'host8')
    stats.increment('ok', 'host9')
    stats.increment('ok', 'host10')
    stats.increment('ok', 'host11')
    stats.increment('ok', 'host12')
    stats.increment('ok', 'host13')
    stats.increment('ok', 'host14')

# Generated at 2022-06-16 21:17:36.685790
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host4')
    stats.increment('ok', 'host5')
    stats.increment('ok', 'host6')
    stats.increment('ok', 'host7')
    stats.increment('ok', 'host8')
    stats.increment('ok', 'host9')
    stats.increment('ok', 'host10')
    stats.increment('ok', 'host11')
    stats.increment('ok', 'host12')
    stats.increment('ok', 'host13')
    stats.increment('ok', 'host14')

# Generated at 2022-06-16 21:17:41.728195
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1

# Generated at 2022-06-16 21:17:53.194768
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    assert stats.ok['host1'] == 2
    assert stats.ok['host2'] == 3
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 0

# Generated at 2022-06-16 21:17:57.422259
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 0

# Generated at 2022-06-16 21:18:06.437496
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')

# Generated at 2022-06-16 21:18:12.692770
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')