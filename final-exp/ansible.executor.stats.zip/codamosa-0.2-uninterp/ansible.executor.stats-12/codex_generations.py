

# Generated at 2022-06-16 21:15:36.822144
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 2
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-16 21:15:41.609695
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-16 21:15:52.949116
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 0


# Generated at 2022-06-16 21:16:03.620868
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')

# Generated at 2022-06-16 21:16:10.437086
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    stats.ok['host1'] = 0
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0


# Generated at 2022-06-16 21:16:14.991611
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-16 21:16:22.802438
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host4')
    stats.increment('ok', 'host4')
    stats.increment('ok', 'host4')
    stats.increment('ok', 'host4')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2
    assert stats.ok['host3'] == 3
    assert stats.ok['host4'] == 4
    stats.decrement('ok', 'host1')

# Generated at 2022-06-16 21:16:29.804879
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-16 21:16:37.622640
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host3')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2
    assert stats.ok['host3'] == 0

# Generated at 2022-06-16 21:16:44.290299
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'
    stats.update_custom_stats('foo', 'baz')
    assert stats.custom['_run']['foo'] == 'baz'
    stats.update_custom_stats('foo', 'bar', 'localhost')
    assert stats.custom['localhost']['foo'] == 'bar'
    stats.update_custom_stats('foo', 'baz', 'localhost')
    assert stats.custom['localhost']['foo'] == 'baz'
    stats.update_custom_stats('foo', 1, 'localhost')
    assert stats.custom['localhost']['foo'] == 1
    stats.update_custom_stats('foo', 1, 'localhost')

# Generated at 2022-06-16 21:16:52.810168
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 2}
    stats.update_custom_stats('foo', {'bar': 1, 'baz': 1})
    assert stats.custom['_run']['foo'] == {'bar': 3, 'baz': 1}
    stats.update_custom_stats('foo', {'bar': 1, 'baz': 1})
    assert stats.custom['_run']['foo'] == {'bar': 4, 'baz': 2}

# Generated at 2022-06-16 21:17:02.739290
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 1
    stats.update_custom_stats('foo', 2)
    assert stats.custom['_run']['foo'] == 3
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 2})
    assert stats.custom['_run']['foo'] == {'bar': 3}
    stats.update_custom_stats('foo', {'bar': 'baz'})
    assert stats.custom['_run']['foo'] == {'bar': 'baz'}
    stats.update_custom_stats

# Generated at 2022-06-16 21:17:13.376423
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'bar': 1}, 'localhost')
    assert stats.custom['localhost']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 2}, 'localhost')
    assert stats.custom['localhost']['foo'] == {'bar': 3}
    stats.update_custom_stats('foo', {'bar': 2, 'baz': 1}, 'localhost')
    assert stats.custom['localhost']['foo'] == {'bar': 5, 'baz': 1}
    stats.update_custom_stats('foo', {'bar': 2, 'baz': 1}, 'localhost')
    assert stats.custom['localhost']['foo'] == {'bar': 7, 'baz': 2}

# Generated at 2022-06-16 21:17:19.875387
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'
    stats.update_custom_stats('foo', 'baz')
    assert stats.custom['_run']['foo'] == 'baz'
    stats.update_custom_stats('foo', {'baz': 'bar'})
    assert stats.custom['_run']['foo'] == {'baz': 'bar'}
    stats.update_custom_stats('foo', {'baz': 'bar'})
    assert stats.custom['_run']['foo'] == {'baz': 'bar'}


# Generated at 2022-06-16 21:17:29.982777
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 2})
    assert stats.custom['_run']['foo'] == {'bar': 3}
    stats.update_custom_stats('foo', {'bar': 2, 'baz': 3})
    assert stats.custom['_run']['foo'] == {'bar': 5, 'baz': 3}
    stats.update_custom_stats('foo', {'bar': 2, 'baz': 3, 'qux': 4})
    assert stats.custom['_run']['foo'] == {'bar': 7, 'baz': 6, 'qux': 4}

# Generated at 2022-06-16 21:17:38.539576
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'
    stats.update_custom_stats('foo', 'baz')
    assert stats.custom['_run']['foo'] == 'baz'
    stats.update_custom_stats('foo', 'bar', 'localhost')
    assert stats.custom['localhost']['foo'] == 'bar'
    stats.update_custom_stats('foo', 'baz', 'localhost')
    assert stats.custom['localhost']['foo'] == 'baz'
    stats.update_custom_stats('foo', {'bar': 'baz'})
    assert stats.custom['_run']['foo'] == {'bar': 'baz'}
    stats.update_custom

# Generated at 2022-06-16 21:17:49.752274
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'
    stats.update_custom_stats('foo', 'baz')
    assert stats.custom['_run']['foo'] == 'baz'
    stats.update_custom_stats('foo', {'a': 1, 'b': 2})
    assert stats.custom['_run']['foo'] == {'a': 1, 'b': 2}
    stats.update_custom_stats('foo', {'b': 3, 'c': 4})

# Generated at 2022-06-16 21:17:57.748535
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Test with a dict
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'bar': 1}, 'localhost')
    assert stats.custom['localhost']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 1}, 'localhost')
    assert stats.custom['localhost']['foo'] == {'bar': 2}
    stats.update_custom_stats('foo', {'bar': 1, 'baz': 1}, 'localhost')
    assert stats.custom['localhost']['foo'] == {'bar': 3, 'baz': 1}
    stats.update_custom_stats('foo', {'baz': 1}, 'localhost')
    assert stats.custom['localhost']['foo'] == {'bar': 3, 'baz': 2}
   

# Generated at 2022-06-16 21:18:03.743268
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    ag = AggregateStats()
    ag.update_custom_stats('test', {'a': 1, 'b': 2}, 'host1')
    assert ag.custom['host1']['test'] == {'a': 1, 'b': 2}
    ag.update_custom_stats('test', {'b': 3, 'c': 4}, 'host1')
    assert ag.custom['host1']['test'] == {'a': 1, 'b': 3, 'c': 4}
    ag.update_custom_stats('test', {'a': 5, 'b': 6}, 'host2')
    assert ag.custom['host2']['test'] == {'a': 5, 'b': 6}
    ag.update_custom_stats('test', {'b': 7, 'c': 8}, 'host2')


# Generated at 2022-06-16 21:18:10.328939
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 1
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 2
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 2}
    stats.update_custom_stats('foo', {'bar': 1, 'baz': 2})
    assert stats.custom['_run']['foo'] == {'bar': 3, 'baz': 2}
    stats