

# Generated at 2022-06-16 21:15:39.792781
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    assert stats.ok['host1'] == 2
    assert stats.ok['host2'] == 3
    assert stats.ok['host3'] == 1
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host3')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2
    assert stats.ok['host3'] == 0

# Generated at 2022-06-16 21:15:51.783135
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')

# Generated at 2022-06-16 21:16:02.384598
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')

# Generated at 2022-06-16 21:16:11.009317
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host4')
    stats.increment('ok', 'host5')
    stats.increment('ok', 'host6')
    stats.increment('ok', 'host7')
    stats.increment('ok', 'host8')
    stats.increment('ok', 'host9')
    stats.increment('ok', 'host10')
    stats.increment('ok', 'host11')
    stats.increment('ok', 'host12')
    stats.increment('ok', 'host13')
    stats.increment('ok', 'host14')

# Generated at 2022-06-16 21:16:17.053276
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-16 21:16:22.293838
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 0


# Generated at 2022-06-16 21:16:33.131590
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 2
    stats.increment('ok', '127.0.0.1')
    assert stats.ok['127.0.0.1'] == 1
    stats.increment('failures', 'localhost')
    assert stats.failures['localhost'] == 1
    stats.increment('failures', '127.0.0.1')
    assert stats.failures['127.0.0.1'] == 1
    stats.increment('ok', '127.0.0.1')
    assert stats.ok['127.0.0.1'] == 2

# Generated at 2022-06-16 21:16:41.719882
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    assert stats.processed['localhost'] == 1
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 2
    assert stats.processed['localhost'] == 1
    stats.increment('failures', 'localhost')
    assert stats.failures['localhost'] == 1
    assert stats.processed['localhost'] == 1
    stats.increment('failures', 'localhost')
    assert stats.failures['localhost'] == 2
    assert stats.processed['localhost'] == 1
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 3
    assert stats.processed['localhost'] == 1
    stats.increment('ok', 'localhost')


# Generated at 2022-06-16 21:16:45.891600
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-16 21:16:52.666425
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 3
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 2
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 0

# Generated at 2022-06-16 21:17:01.351513
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 0
    stats.ok['host1'] = 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1

# Generated at 2022-06-16 21:17:05.835797
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0


# Generated at 2022-06-16 21:17:13.123858
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2

# Generated at 2022-06-16 21:17:18.304796
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'testhost')
    stats.decrement('ok', 'testhost')
    assert stats.ok['testhost'] == 0
    stats.decrement('ok', 'testhost')
    assert stats.ok['testhost'] == 0
    stats.increment('ok', 'testhost')
    stats.increment('ok', 'testhost')
    stats.decrement('ok', 'testhost')
    assert stats.ok['testhost'] == 1


# Generated at 2022-06-16 21:17:22.327067
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0

# Generated at 2022-06-16 21:17:33.431947
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 5
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 4
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 3
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 2
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1

# Generated at 2022-06-16 21:17:44.592158
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    assert stats.ok['host1'] == 2
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 0
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 0

# Generated at 2022-06-16 21:17:55.157869
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 1}
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo'] == {'bar': 2}
    stats.update_custom_stats('foo', {'bar': 1, 'baz': 2})
    assert stats.custom['_run']['foo'] == {'bar': 3, 'baz': 2}
    stats.update_custom_stats('foo', {'bar': 1, 'baz': 2, 'qux': 3})
    assert stats.custom['_run']['foo'] == {'bar': 4, 'baz': 4, 'qux': 3}

# Generated at 2022-06-16 21:18:05.378236
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host')
    stats.increment('ok', 'host')
    stats.increment('ok', 'host')
    stats.increment('ok', 'host')
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 3
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 2
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 1
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 0
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 0


# Generated at 2022-06-16 21:18:12.175917
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host4')
    stats.increment('ok', 'host5')
    stats.increment('ok', 'host6')
    stats.increment('ok', 'host7')
    stats.increment('ok', 'host8')
    stats.increment('ok', 'host9')
    stats.increment('ok', 'host10')
    stats.increment('ok', 'host11')
    stats.increment('ok', 'host12')
    stats.increment('ok', 'host13')
    stats.increment('ok', 'host14')

# Generated at 2022-06-16 21:18:21.044231
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    assert stats.ok['host1'] == 2
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 0
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 0
    stats.decrement('ok', 'host1')


# Generated at 2022-06-16 21:18:24.297247
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-16 21:18:34.198397
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    assert stats.ok['host1'] == 2
    assert stats.ok['host2'] == 3
    assert stats.ok['host3'] == 4
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')

# Generated at 2022-06-16 21:18:38.129636
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1


# Generated at 2022-06-16 21:18:45.222727
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2

# Generated at 2022-06-16 21:18:54.443493
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')

# Generated at 2022-06-16 21:18:58.382536
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0


# Generated at 2022-06-16 21:19:07.928797
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host3')
   

# Generated at 2022-06-16 21:19:15.159556
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.ok['host1'] = 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1


# Generated at 2022-06-16 21:19:18.782091
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 0
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 0


# Generated at 2022-06-16 21:19:27.736579
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 2
    stats.decrement('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-16 21:19:35.009751
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 4
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 3
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 2
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-16 21:19:45.730116
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 1
    assert stats.ok['host3'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 0
    assert stats.ok['host3'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 0
   

# Generated at 2022-06-16 21:19:56.964027
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host2')
    stats.dec

# Generated at 2022-06-16 21:20:07.567859
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')

# Generated at 2022-06-16 21:20:16.048969
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 2
    assert stats.ok['host2'] == 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 2

# Generated at 2022-06-16 21:20:22.990031
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-16 21:20:30.439517
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 3
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 2
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 0

# Generated at 2022-06-16 21:20:40.462223
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 2
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0


# Generated at 2022-06-16 21:20:43.414585
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'test')
    assert stats.ok['test'] == 1
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 0
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 0

# Generated at 2022-06-16 21:20:53.780428
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment("ok", "localhost")
    stats.increment("ok", "localhost")
    stats.decrement("ok", "localhost")
    assert stats.ok["localhost"] == 1
    stats.decrement("ok", "localhost")
    assert stats.ok["localhost"] == 0
    stats.decrement("ok", "localhost")
    assert stats.ok["localhost"] == 0


# Generated at 2022-06-16 21:20:56.913790
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0


# Generated at 2022-06-16 21:21:06.143367
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 3
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 2
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 0

# Generated at 2022-06-16 21:21:10.455178
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'testhost')
    assert stats.ok['testhost'] == 1
    stats.decrement('ok', 'testhost')
    assert stats.ok['testhost'] == 0
    stats.decrement('ok', 'testhost')
    assert stats.ok['testhost'] == 0

# Generated at 2022-06-16 21:21:23.016079
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    assert stats.ok['host1'] == 2
    assert stats.ok['host2'] == 3
    assert stats.ok['host3'] == 1
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host2')
    stats.decrement('ok', 'host3')

# Generated at 2022-06-16 21:21:31.030574
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')

# Generated at 2022-06-16 21:21:40.329872
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 2
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0


# Generated at 2022-06-16 21:21:45.151439
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')

# Generated at 2022-06-16 21:21:56.548517
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 0


# Generated at 2022-06-16 21:22:04.867336
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 2
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    stats.decrement('ok', 'host1')