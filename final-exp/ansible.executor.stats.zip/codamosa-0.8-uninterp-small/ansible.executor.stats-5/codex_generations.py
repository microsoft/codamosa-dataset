

# Generated at 2022-06-24 19:07:18.107116
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()

    # Check [default] Host
    host = "localhost"
    # Check [default] Attribute
    what = "ok"
    result = aggregate_stats.decrement(what, host)
    assert result == 0


# Generated at 2022-06-24 19:07:21.060134
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.increment("ok", "foo")
    aggregate_stats_0.decrement("ok", "foo")
    assert aggregate_stats_0.ok["foo"] == 0


# Generated at 2022-06-24 19:07:29.169363
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_decrement = AggregateStats()
    host = 'fake_host'
    assert aggregate_stats_decrement.skipped[host] == 0
    aggregate_stats_decrement.increment('skipped', host)
    aggregate_stats_decrement.decrement('skipped', host)
    assert aggregate_stats_decrement.skipped[host] == 0


# Generated at 2022-06-24 19:07:32.097277
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement("dark", "localhost")
    assert aggregate_stats.dark == dict(localhost=0)

# Generated at 2022-06-24 19:07:38.576374
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.failures['foo'] = 0
    assert aggregate_stats_0.failures['foo'] == 0
    with pytest.raises(KeyError):
        aggregate_stats_0.decrement('failures', 'foo')
    with pytest.raises(KeyError):
        aggregate_stats_0.decrement('failures', 'foo')
    assert aggregate_stats_0.failures == {'foo': 0}
    assert aggregate_stats_0.failures.get('bar', 0) == 0


# Generated at 2022-06-24 19:07:47.606960
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    which_1 = 'foo.baz'
    what_1 = {'foo.baz': {'total': 1, 'skipped': 0, 'changed': 1, 'failures': 0, 'ok': 1, 'unreachable': 0}}
    host_1 = 'bar.baz'
    return_value_1 = aggregate_stats_1.update_custom_stats(which=which_1, what=what_1, host=host_1)
    assert which_1 == 'foo.baz'
    assert what_1 == {'foo.baz': {'total': 1, 'skipped': 0, 'changed': 1, 'failures': 0, 'ok': 1, 'unreachable': 0}}
    assert host_1 == 'bar.baz'

# Generated at 2022-06-24 19:07:51.204486
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_0 = AggregateStats()
    assert AggregateStats.increment(aggregate_stats_0, 'ok', 'host1')


# Generated at 2022-06-24 19:07:56.260175
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("ok", "test")



# Generated at 2022-06-24 19:08:00.437092
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('rescued', 'host.example.com')
    aggregate_stats_0.decrement('ok', 'host.example.com')
    aggregate_stats_0.decrement('ignored', 'host.example.com')
    aggregate_stats_0.decrement('ignored', 'host.example.com')
    aggregate_stats_0.decrement('ignored', 'host.example.com')


# Generated at 2022-06-24 19:08:01.796689
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    assert aggregate_stats_0.decrement('what', 'host') == None


# Generated at 2022-06-24 19:08:05.930144
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_instance = AggregateStats()
    aggregate_stats_result = aggregate_stats_instance.update_custom_stats('var', 'val')
    # should return None
    assert aggregate_stats_result == None


# Generated at 2022-06-24 19:08:13.295945
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('changed', 'changed')
    aggregate_stats_0.decrement('ignored', 'ignored')
    aggregate_stats_0.decrement('rescued', 'rescued')
    aggregate_stats_0.decrement('skipped', 'skipped')
    aggregate_stats_0.decrement('ok', 'ok')
    aggregate_stats_0.decrement('failures', 'failures')
    aggregate_stats_0.decrement('dark', 'dark')



# Generated at 2022-06-24 19:08:18.207285
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    test_obj = AggregateStats()
    test_obj.set_custom_stats('_fact', 'facts', 'host1')
    print(test_obj.custom)
    test_obj.update_custom_stats('_fact', 'facts', 'host1')
    print(test_obj.custom)


# Generated at 2022-06-24 19:08:21.863142
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    a = aggregate_stats_0.update_custom_stats("lightbulbs","lightbulbs")


# Generated at 2022-06-24 19:08:29.998213
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('ok', "host1")
    # Returns a figure for the number of times for ok
    assert(len(aggregate_stats_0.ok.keys()) == 1)
    assert(aggregate_stats_0.ok['host1'] == 0)



# Generated at 2022-06-24 19:08:34.883131
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Test Arguments
    what = "None"
    host = "None"
    # expecting 
    return_value = None
    # Test Logic
    aggregate_stats_0 = AggregateStats()
    return_value = aggregate_stats_0.decrement(what, host)
    assert return_value == None
    return


# Generated at 2022-06-24 19:08:37.299524
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    AggregateStats.decrement(aggregate_stats_1, "ok", "foo")


# Generated at 2022-06-24 19:08:43.640256
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.update_custom_stats('a','b','c') is None
    assert aggregate_stats.update_custom_stats('a','b') is None
    assert aggregate_stats.custom == {'c': {'a': 'b'}, '_run': {'a': 'b'}}


# Generated at 2022-06-24 19:08:47.196907
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('dark', 'host')
    aggregate_stats_0.decrement('dark', 'host')


# Generated at 2022-06-24 19:08:56.465706
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    agg_stats_1_what = 'ok'
    agg_stats_1_host = 'test'
    aggregate_stats_1.increment(agg_stats_1_what, agg_stats_1_host)
    aggregate_stats_1.increment(agg_stats_1_what, agg_stats_1_host)
    aggregate_stats_1.increment(agg_stats_1_what, agg_stats_1_host)
    aggregate_stats_1.decrement(agg_stats_1_what, agg_stats_1_host)



# Generated at 2022-06-24 19:09:06.435314
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    which = ''
    what = {}
    host = '_run'
    try:
        aggregate_stats_0.update_custom_stats(which, what, host)
    except SystemExit:
        raise SystemExit("Shouldn't have thrown SystemExit")

if __name__ == '__main__':
    # For tests #
    test_AggregateStats_update_custom_stats()

# Generated at 2022-06-24 19:09:11.627943
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats("a", 5)
    aggregate_stats.update_custom_stats("b", 5, "test_host")
    assert aggregate_stats.custom["_run"] == {"a" : 5}
    assert aggregate_stats.custom["test_host"] == {"b" : 5}

# Generated at 2022-06-24 19:09:16.725844
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    # Testing for ``which`` not being a string
    aggregate_stats_1.update_custom_stats(None, '0', '_run')
    # Testing for ``what`` not being a string
    aggregate_stats_1.update_custom_stats('custom_stats', None, '_run')
    # Testing for ``host`` not being a string
    aggregate_stats_1.update_custom_stats('custom_stats', '0', None)
    # Testing for ``what`` not being a string
    aggregate_stats_1.update_custom_stats('custom_stats', 'custom_stats', '_run')


# Generated at 2022-06-24 19:09:25.736854
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import random

    int_rand = random.randint(1, 100)
    dict_rand = {"a": int_rand}
    host_rand = random.choice(["test1", "test2", "test3"])

    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats("test", int_rand)
    assert aggregate_stats.custom == {"_run": {"test": int_rand}}
    assert aggregate_stats.custom["_run"]["test"] == int_rand

    aggregate_stats.update_custom_stats("test", int_rand)
    assert aggregate_stats.custom == {"_run": {"test": int_rand * 2}}
    assert aggregate_stats.custom["_run"]["test"] == int_rand * 2


# Generated at 2022-06-24 19:09:27.071466
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
  assert(update_custom_stats() == None)



# Generated at 2022-06-24 19:09:28.996782
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('which', 'what')


# Generated at 2022-06-24 19:09:38.064438
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stat = AggregateStats()
    stat.custom = {'_run': {'test': {'ok': 1, 'changed': 2}}}
    assert stat.custom['_run']['test']['ok'] == 1
    assert stat.custom['_run']['test']['changed'] == 2

    stat.update_custom_stats('test', {'ok': 1})
    assert stat.custom['_run']['test']['ok'] == 2
    assert stat.custom['_run']['test']['changed'] == 2
    stat.update_custom_stats('test', {'changed': 1})
    assert stat.custom['_run']['test']['ok'] == 2
    assert stat.custom['_run']['test']['changed'] == 3

# Generated at 2022-06-24 19:09:43.801255
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('test_custom_stats', 123, '_run')

    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats('test_custom_stats', 123, '_run')


# Generated at 2022-06-24 19:09:46.399366
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats('what', 'this', 'host')


# Generated at 2022-06-24 19:09:55.642028
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.custom['_run'] = {'foo': {'inner': 1, 'inner2': 10}}
    aggregate_stats_1.update_custom_stats('foo', {'inner': 2})
    assert aggregate_stats_1.custom['_run']['foo']['inner'] == 3