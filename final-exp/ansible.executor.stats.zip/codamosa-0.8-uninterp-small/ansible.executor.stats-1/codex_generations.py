

# Generated at 2022-06-24 19:07:19.416777
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.processed['127.0.0.1'] = 1
    aggregate_stats.dark['127.0.0.1'] = 2
    aggregate_stats.decrement('dark', '127.0.0.1')
    if aggregate_stats.dark['127.0.0.1'] != 1:
        raise AssertionError('Failed to decrement attribute dark of AggregateStats')


# Generated at 2022-06-24 19:07:20.863284
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    assert len(AggregateStats().update_custom_stats('x', 'y')) == 0


# Generated at 2022-06-24 19:07:26.083960
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    assert True
    aggregate_stats = AggregateStats()
    result = aggregate_stats.decrement(what="ok", host="localhost")
    assert isinstance(result, dict)


# Generated at 2022-06-24 19:07:27.526992
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test_case_AggregateStats_decrement_0()

# Generated at 2022-06-24 19:07:29.735964
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement('ok', 'host')
    # decrement function must return None
    assert None == aggregate_stats.decrement('ok', 'host')


# Generated at 2022-06-24 19:07:38.617491
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    assert AggregateStats.decrement(aggregate_stats_0, 'ok', 'localhost') is None
    assert AggregateStats.decrement(aggregate_stats_0, 'failures', 'localhost') is None
    assert AggregateStats.decrement(aggregate_stats_0, 'dark', 'localhost') is None
    assert AggregateStats.decrement(aggregate_stats_0, 'changed', 'localhost') is None
    assert AggregateStats.decrement(aggregate_stats_0, 'skipped', 'localhost') is None
    assert AggregateStats.decrement(aggregate_stats_0, 'rescued', 'localhost') is None
    assert AggregateStats.decrement(aggregate_stats_0, 'ignored', 'localhost') is None


# Generated at 2022-06-24 19:07:42.094234
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.increment('ok', 'test_host_ok')
    assert aggregate_stats_0.ok['test_host_ok'] == 1


# Generated at 2022-06-24 19:07:48.939256
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.ok = {'127.0.0.1': 1}
    assert aggregate_stats_1.ok == {'127.0.0.1': 1}
    aggregate_stats_1.decrement('ok', '127.0.0.1')
    assert aggregate_stats_1.ok == {'127.0.0.1': 0}
    aggregate_stats_1.decrement('ok', '127.0.0.2')
    assert aggregate_stats_1.ok == {'127.0.0.1': 0, '127.0.0.2': 0}


# Generated at 2022-06-24 19:07:51.676949
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("failures", "localhost")
    aggregate_stats_0.decrement("failures", "localhost")
    aggregate_stats_0.decrement("ok", "localhost")


# Generated at 2022-06-24 19:07:55.163452
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.increment('ok', 'foo')
    aggregate_stats_0.increment('ok', 'foo')
    aggregate_stats_0.increment('ok', 'foo')
    assert aggregate_stats_0.ok['foo'] == 3


# Generated at 2022-06-24 19:07:58.671585
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.decrement('ok', 'host') is None


# Generated at 2022-06-24 19:08:04.271553
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("changed", "changed@example.com")

    # check if we have decremented the correct property
    assert aggregate_stats_0.changed["changed@example.com"] == -1

# Generated at 2022-06-24 19:08:09.753013
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('ok', 'localhost')
    aggregate_stats_0.decrement('ignored', '127.0.0.1')


# Generated at 2022-06-24 19:08:12.506646
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement("ok", "host")


# Generated at 2022-06-24 19:08:15.034869
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement('ok', 'localhost')


# Generated at 2022-06-24 19:08:17.744177
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('ok', 'host 1')


# Generated at 2022-06-24 19:08:21.151587
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("ok", "localhost")



# Generated at 2022-06-24 19:08:23.680997
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats(which = "time", what = { })


# Generated at 2022-06-24 19:08:30.232632
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.failures = {u'localhost': 0, u'otherhost': 0}
    aggregate_stats_0.ok = {u'localhost': 1, u'otherhost': 0}
    aggregate_stats_0.dark = {u'localhost': 0, u'otherhost': 0}
    aggregate_stats_0.changed = {u'localhost': 0, u'otherhost': 0}
    aggregate_stats_0.skipped = {u'localhost': 0, u'otherhost': 0}
    aggregate_stats_0.rescued = {u'localhost': 0, u'otherhost': 0}
    aggregate_stats_0.ignored = {u'localhost': 0, u'otherhost': 0}

# Generated at 2022-06-24 19:08:36.381434
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats("PARAM1", "VAL1")
    # Test that a user-defined key was created in the custom dictionary
    assert aggregate_stats_1.custom.has_key('_run')
    # Test that the user-defined key has the correct value
    assert aggregate_stats_1.custom['_run']['PARAM1'] == "VAL1"


# Generated at 2022-06-24 19:08:48.968892
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('_run', 12, None)
    aggregate_stats_0.update_custom_stats('_run', 15, None)
    aggregate_stats_0.update_custom_stats('_run', 18, '_run')
    aggregate_stats_0.update_custom_stats('_run', 21, '_run')
    aggregate_stats_0.update_custom_stats('_run', 24, None)
    aggregate_stats_0.update_custom_stats('_run', 27, '_run')
    aggregate_stats_0.update_custom_stats('_run', 30, None)
    aggregate_stats_0.update_custom_stats('_run', 33, '_run')
    aggregate_stats_0.update_custom_

# Generated at 2022-06-24 19:08:50.577446
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats(which='ok', what='ok')

# Generated at 2022-06-24 19:08:55.443291
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    aggregate_stats_1 = AggregateStats()
    # simple update
    aggregate_stats_1.update_custom_stats('a','b')
    assert aggregate_stats_1.custom['_run']['a'] == 'b'

    # simple update with hosts
    aggregate_stats_1.update_custom_stats('a','b','host2')
    assert aggregate_stats_1.custom['host2']['a'] == 'b'

    # list update
    aggregate_stats_1.update_custom_stats('a',['b'])
    assert aggregate_stats_1.custom['_run']['a'] == ['b']
    aggregate_stats_1.update_custom_stats('a',['b2'])
    assert aggregate_stats_1.custom['_run']['a'] == ['b2']

   

# Generated at 2022-06-24 19:09:00.530988
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.dark['foo'] = 1
    aggregate_stats_1.decrement('dark', 'foo')
    assert aggregate_stats_1.dark['foo'] == 0

# Generated at 2022-06-24 19:09:02.688370
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement('ok', 'host')


# Generated at 2022-06-24 19:09:10.848266
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    # host aggregated stats
    aggregate_stats_0.update_custom_stats('foo', {'bar': 1}, 'host0')
    aggregate_stats_0.update_custom_stats('foo', {'bar': 2}, 'host1')

    # run stats
    aggregate_stats_0.update_custom_stats('foo', {'bar': 3})

    assert aggregate_stats_0.custom == {'host0': {'foo': {'bar': 1}},
                                        'host1': {'foo': {'bar': 2}},
                                        '_run': {'foo': {'bar': 3}}}


# Generated at 2022-06-24 19:09:11.591821
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    pass


# Generated at 2022-06-24 19:09:12.065273
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    assert 1 == 1

# Generated at 2022-06-24 19:09:16.535309
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement('changed', 'hostname_1')


# Generated at 2022-06-24 19:09:18.878208
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    host = 'test'
    what = 'rescued'
    aggregate_stats.decrement(what, host)



# Generated at 2022-06-24 19:09:26.166380
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('what', 'host')

# Generated at 2022-06-24 19:09:33.786598
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    host_0 = ''
    aggregate_stats_0.decrement('skipped', host_0)
    _what = getattr(aggregate_stats_0, 'skipped')
    try:
        if _what[host_0] - 1 < 0:
            # This should never happen, but let's be safe
            raise KeyError("Don't be so negative")
        _what[host_0] -= 1
    except KeyError:
        _what[host_0] = 0
    what_0 = 'skipped'
    host_1 = ''
    aggregate_stats_0.decrement(what_0, host_1)



# Generated at 2022-06-24 19:09:37.327478
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ag = AggregateStats()
    ag.decrement('ok', 'host')
    ag.decrement('changed', 'host')
    ag.decrement('failures', 'host')
    assert ag.ok['host'] == 0
    assert ag.changed['host'] == 0
    assert ag.failures['host'] == 0


# Generated at 2022-06-24 19:09:47.575616
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()

    # create a host
    host = 'host'
    assert(host not in aggregate_stats.custom)

    # decrement nonexistent value
    aggregate_stats.decrement('custom', host)
    assert(aggregate_stats.custom[host] == 0)

    # decrement one value
    aggregate_stats.decrement('custom', 'host')
    assert(aggregate_stats.custom[host] == -1)

    # decrement multiple
    aggregate_stats.decrement('custom', host)
    aggregate_stats.decrement('custom', host)
    assert(aggregate_stats.custom[host] == -3)
    

# Generated at 2022-06-24 19:09:53.549336
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = {}

    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('failures', 'host0')



# Generated at 2022-06-24 19:09:55.727586
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement(what = "failures", host = "10.11.12.13")


# Generated at 2022-06-24 19:09:56.648797
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test_case_0()


# Generated at 2022-06-24 19:10:00.977635
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.increment("ignored", "host3")
    assert aggregate_stats_0.ignored["host3"] == 1
    assert aggregate_stats_0.decrement("ignored", "host3") == None
    assert aggregate_stats_0.ignored["host3"] == 0


# Generated at 2022-06-24 19:10:03.328301
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    """
    # Unit test for method decrement of class AggregateStats
    """
    aggregate_stats_0 = AggregateStats()
    result = aggregate_stats_0.decrement('ok', 'host')
    assert result == 0


# Generated at 2022-06-24 19:10:11.426942
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("failures","localhost")
    aggregate_stats_0.decrement("ignored","localhost")
    aggregate_stats_0.decrement("ok","localhost")
    aggregate_stats_0.decrement("rescued","localhost")
    aggregate_stats_0.decrement("skipped","localhost")
    aggregate_stats_0.decrement("changed","localhost")
    aggregate_stats_0.decrement("dark","localhost")
