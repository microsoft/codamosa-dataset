

# Generated at 2022-06-24 19:07:18.322317
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats()


# Generated at 2022-06-24 19:07:21.569384
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats = Mock()
    aggregate_stats.update_custom_stats(which=None, what=None)
    aggregate_stats.update_custom_stats.assert_called_with(which=None, what=None, host=None)

# Generated at 2022-06-24 19:07:26.728203
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    setattr(aggregate_stats, 'foo', {'localhost': 1})
    aggregate_stats.decrement('foo', 'localhost')
    assert aggregate_stats.foo == {'localhost': 0}


# Generated at 2022-06-24 19:07:28.387766
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement('ok', 'host1')


# Generated at 2022-06-24 19:07:38.115328
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    test_aggregate_stats = AggregateStats()
    test_aggregate_stats.update_custom_stats("test_key_1", "test_value_1")
    assert test_aggregate_stats.custom == {'_run': {'test_key_1': 'test_value_1'}}
    test_aggregate_stats.update_custom_stats("test_key_1", "test_value_2")
    assert test_aggregate_stats.custom == {'_run': {'test_key_1': 'test_value_2'}}
    test_aggregate_stats.update_custom_stats("test_key_2", "test_value_3")

# Generated at 2022-06-24 19:07:44.294234
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    str_0 = AggregateStats()
    str_0.increment('ignored', '172.16.44.15')
    str_0.increment('ignored', '172.16.44.15')
    str_0.increment('ignored', '172.16.44.15')
    str_0.increment('ignored', '172.16.44.15')
    str_0.increment('ignored', '172.16.44.15')


# Generated at 2022-06-24 19:07:48.223721
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    # Test with valid arguments
    try:
        aggregate_stats_0.decrement("ok", "host")
    except KeyError:
        pass
    # Test with invalid arguments
    try:
        aggregate_stats_0.decrement("ok", "")
    except KeyError:
        pass


# Generated at 2022-06-24 19:07:50.731065
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    host_0 = "10.0.0.0"
    what_0 = "failures"
    aggregate_stats_0.decrement(what_0, host_0)


# Generated at 2022-06-24 19:08:02.065263
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.increment('ok', 'remote1')
    aggregate_stats_0.increment('ok', 'remote2')
    aggregate_stats_0.increment('ok', 'remote1')
    aggregate_stats_0.increment('ok', 'remote3')
    aggregate_stats_0.increment('ok', 'remote1')
    aggregate_stats_0.increment('failures', 'remote2')
    aggregate_stats_0.increment('failures', 'remote3')
    aggregate_stats_0.increment('failures', 'remote3')
    aggregate_stats_0.increment('failures', 'remote2')
    aggregate_stats_0.increment('failures', 'remote3')


# Generated at 2022-06-24 19:08:03.354564
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('what', 'host')


# Generated at 2022-06-24 19:08:09.793302
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("ok", "127.0.0.1")


# Generated at 2022-06-24 19:08:18.158163
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement('ok', 'dummy')
    aggregate_stats.decrement('failures', 'dummy')
    aggregate_stats.decrement('dark', 'dummy')
    aggregate_stats.decrement('changed', 'dummy')
    aggregate_stats.decrement('skipped', 'dummy')
    aggregate_stats.decrement('rescued', 'dummy')
    aggregate_stats.decrement('ignored', 'dummy')


# Generated at 2022-06-24 19:08:26.881978
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.set_custom_stats('custom_stats_what', 'custom_stats_host')
    aggregate_stats_0.update_custom_stats('custom_stats_what', 'custom_stats_host')
    aggregate_stats_0.update_custom_stats('custom_stats_what', 'custom_stats_host')
    aggregate_stats_0.update_custom_stats('custom_stats_what', 'custom_stats_host')
    aggregate_stats_0.update_custom_stats('custom_stats_what', 'custom_stats_host')
# end of test_AggregateStats_update_custom_stats

# Generated at 2022-06-24 19:08:29.798727
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement( 'rescued', 'node3')


# Generated at 2022-06-24 19:08:33.896493
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.increment('changed', 'localhost')
    aggregate_stats_1.decrement('changed', 'localhost')

    try:
        assert aggregate_stats_1.changed['localhost'] == 0
    except AssertionError:
        raise AssertionError('This assert has failed')


# Generated at 2022-06-24 19:08:37.744538
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats(which="test_stats0", what={"test_stats1":100}, host="test_host")
    assert aggregate_stats.custom == {"_run":{}, "test_host":{"test_stats0":{"test_stats1":100}}}


# Generated at 2022-06-24 19:08:46.486258
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    as0 = AggregateStats()
    as0.decrement("ok", "localhost")
    assert as0.ok["localhost"] == -1
    as0.decrement("ok", "127.0.0.1")
    assert as0.ok["127.0.0.1"] == -1


# Generated at 2022-06-24 19:08:48.525447
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('ignore', 'test3')


# Generated at 2022-06-24 19:08:51.413947
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Test case with integer decrement
    aggregate_stats_decrement_1 = AggregateStats()
    aggregate_stats_decrement_1.decrement('ok', 'test_host')

    assert aggregate_stats_decrement_1.ok['test_host'] == 0


# Generated at 2022-06-24 19:08:52.904979
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    a = AggregateStats()
    a.decrement('ok', 'localhost')


# Generated at 2022-06-24 19:09:03.132242
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    """
    This unit test is for the AggregateStats class's `update_custom_stats`
    method.
    """
    # Test overriding when both dicts are empty
    aggregate_stats_1 = AggregateStats()
    d_1 = {'a': 1, 'b': 2}
    assert(aggregate_stats_1.update_custom_stats('a', d_1) is None)
    assert(aggregate_stats_1.custom['_run']['a'] == d_1)

    # Test overriding when both dicts are the same
    aggregate_stats_2 = AggregateStats()
    d_2 = {'a': 1, 'b': 2}
    aggregate_stats_2.update_custom_stats('a', d_2)

# Generated at 2022-06-24 19:09:05.117922
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()

    which = "foo"
    what = "bar"
    host = "localhost"

    aggregate_stats_0.update_custom_stats(which, what)
    aggregate_stats_0.update_custom_stats(which, what)
    aggregate_stats_0.update_custom_stats(which, what)


# Generated at 2022-06-24 19:09:13.151333
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    _num1 = 1
    _num2 = 2
    _num3 = 3
    _num4 = 4
    _dict1 = {"key1":"value1"}
    _dict2 = {"key1":"value1","key2":"value2"}
    _list1 = [1,2,3]
    _list2 = [4,5,6]
    _list3 = [4,5,6,7]
    _list4 = [7]
    _list5 = [1,2,3,4,5,6,7]
    _list6 = [1,2,3,4,5,6]
    _str1 = "str1"
    _str2 = "str2"

    _aggregate_stats_0 = AggregateStats()

# Generated at 2022-06-24 19:09:20.926858
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    host = 'host1'
    stat_name = 'stat1'
    host_stat_value = 0
    host_stat_value_updated = 12
    aggregate_stats = AggregateStats()

    aggregate_stats.set_custom_stats(stat_name, host_stat_value, host)
    assert aggregate_stats.custom[host][stat_name] == host_stat_value

    aggregate_stats.update_custom_stats(stat_name, host_stat_value_updated, host)
    assert aggregate_stats.custom[host][stat_name] == 24

    aggregate_stats.set_custom_stats(stat_name, host_stat_value, host)
    assert aggregate_stats.custom[host][stat_name] == host_stat_value

# Generated at 2022-06-24 19:09:23.249337
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    p = AggregateStats()
    p.update_custom_stats(u'first_key', 123)
    assert p.custom[u'_run'][u'first_key'] is 123


# Generated at 2022-06-24 19:09:28.118184
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats("check_mode", True)
    assert aggregate_stats.custom['_run']['check_mode'] == True

if __name__ == '__main__':
    test_case_0()
    test_AggregateStats_update_custom_stats()

# Generated at 2022-06-24 19:09:34.678148
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    which_2 = "vars"
    what_3 = "var1"
    aggregate_stats_1.update_custom_stats(which_2, what_3)


# Generated at 2022-06-24 19:09:36.922146
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats("_host", 0)
    assert aggregate_stats_0.custom == {}


# Generated at 2022-06-24 19:09:47.304171
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()

    aggregate_stats_1.ok[u'localhost'] = 3
    aggregate_stats_1.failures[u'localhost'] = 2
    aggregate_stats_1.changed[u'localhost'] = 2
    aggregate_stats_1.skipped[u'localhost'] = 1
    aggregate_stats_1.processed[u'localhost'] = 8

    aggregate_stats_1.custom = {u'localhost': {u'processed': 5}}

    aggregate_stats_1.update_custom_stats(u'processed', 3, u'localhost')
    assert aggregate_stats_1.custom[u'localhost'][u'processed'] == 8


# Generated at 2022-06-24 19:09:58.636158
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()

    # test case 1
    aggregate_stats.update_custom_stats("stat1", 1, "host")
    aggregate_stats.update_custom_stats("stat1", 1, "host")
    aggregate_stats.update_custom_stats("stat1", 1, "host2")
    aggregate_stats.update_custom_stats("stat2", "string", "host2")
    assert aggregate_stats.custom["host"]["stat1"] == 2
    assert aggregate_stats.custom["host2"]["stat1"] == 1
    assert aggregate_stats.custom["host2"]["stat2"] == "string"

    # test case 2
    aggregate_stats.custom = {}
    aggregate_stats.update_custom_stats("stat1", "string1", "host")

# Generated at 2022-06-24 19:10:03.411441
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats(
        which='tasks', what={'a': 1, 'b': 2}, host='localhost')


# Generated at 2022-06-24 19:10:09.589100
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats("updates", 1)
    assert aggregate_stats.custom["_run"]["updates"] == 1
    aggregate_stats.set_custom_stats("updates", 2)
    assert aggregate_stats.custom["_run"]["updates"] == 2


# Generated at 2022-06-24 19:10:15.044712
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('which', 'what')
    assert aggregate_stats_0.update_custom_stats('which', 'what') == None
    assert aggregate_stats_0.custom['_run']['which'] == aggregate_stats_0.custom['_run']['which']
    aggregate_stats_0.update_custom_stats('which', 'what', '_run')
    assert aggregate_stats_0.custom['_run']['which'] == aggregate_stats_0.custom['_run']['which']


# Generated at 2022-06-24 19:10:17.829483
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('results', 'pouet', '_run')



# Generated at 2022-06-24 19:10:26.301108
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    assert aggregate_stats_0.custom == {}
    aggregate_stats_0.update_custom_stats('key', 'val')
    assert aggregate_stats_0.custom == {'_run': {'key': 'val'}}
    aggregate_stats_0.update_custom_stats('key', 'val')
    assert aggregate_stats_0.custom == {'_run': {'key': 'val'}}
    aggregate_stats_0.update_custom_stats('key', 'val', 'host')
    assert aggregate_stats_0.custom == {'_run': {'key': 'val'}, 'host': {'key': 'val'}}
    aggregate_stats_0.update_custom_stats('key', {'key': 'val'}, 'host')
    assert aggregate_stats

# Generated at 2022-06-24 19:10:29.619217
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    test_case_0()


# Generated at 2022-06-24 19:10:35.943657
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats("test_1", {"key_1": "value_1"}, "host_1")
    assert aggregate_stats_1.custom["host_1"]["test_1"]["key_1"] == "value_1"
    aggregate_stats_1.update_custom_stats("test_2", 3, "host_2")
    assert aggregate_stats_1.custom["host_2"]["test_2"] == 3
    aggregate_stats_1.update_custom_stats("test_1", 0, "host_1")
    assert aggregate_stats_1.custom["host_1"]["test_1"] == 0
    aggregate_stats_1.update_custom_stats("test_2", 3, "host_1")


# Generated at 2022-06-24 19:10:43.022298
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()

# Generated at 2022-06-24 19:10:45.646020
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    assert aggregate_stats_1.update_custom_stats('_run',
                                                 {'value': 'value'},
                                                 '_run') == 0


# Generated at 2022-06-24 19:10:47.753425
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # create AggregateStats instance
    aggregate_stats_0 = AggregateStats()
    # call method update_custom_stats
    aggregate_stats_0.update_custom_stats()


# Generated at 2022-06-24 19:11:02.492078
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    dict_a_0 = {}
    dict_a_0['_run'] = {'cow': 'moo'}
    assert aggregate_stats_0.custom == dict_a_0
    aggregate_stats_0.update_custom_stats('cow', 'moo')
    assert aggregate_stats_0.custom == dict_a_0
    dict_a_0['_run']['cow'] = 'meow'
    aggregate_stats_0.update_custom_stats('cow', 'meow')
    assert aggregate_stats_0.custom == dict_a_0
    dict_a_1 = {}
    dict_a_1['_run'] = {'cow': ['moo', 'meow']}

# Generated at 2022-06-24 19:11:11.210913
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    a = AggregateStats()
    a.custom = {'a': {'a1': 1}}
    a.update_custom_stats('a2', 2)
    assert a.custom == {'_run': {'a2': 2}, 'a': {'a1': 1}}

    a.custom = {'_run': {'a2': 2}}
    a.update_custom_stats('a2', 3)
    assert a.custom == {'_run': {'a2': 3}}

    a.custom = {'_run': {'a2': 2}}
    a.update_custom_stats('a1', 1)
    assert a.custom == {'_run': {'a2': 2, 'a1': 1}}

    a.custom = {'b': {'b1': 2}}

# Generated at 2022-06-24 19:11:14.265418
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Setup
    aggregate_stats_0 = AggregateStats()
    which = "test"
    what = {}
    host = "_run"
    # Exercise
    aggregate_stats_0.update_custom_stats(which, what, host)
    # Verify
    assert aggregate_stats_0.custom[host][which] == what


# Generated at 2022-06-24 19:11:22.120900
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()

    aggregate_stats_0.update_custom_stats('changed', {'changed': {'changed': {'changed': {'changed': 'changed'}}}})

    assert aggregate_stats_0.custom == {'_run': {'changed': {'changed': {'changed': {'changed': 'changed'}}}}}


# Generated at 2022-06-24 19:11:23.447834
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats('custom_1', 2)


# Generated at 2022-06-24 19:11:30.868042
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    assert aggregate_stats_0.custom == {}
    aggregate_stats_0.update_custom_stats("docker_task_result", "0", "localhost")
    # test that custom is set correctly
    assert aggregate_stats_0.custom == {'localhost': {'docker_task_result': '0'}}

    aggregate_stats_0.update_custom_stats("docker_task_result", "1", "localhost")
    assert aggregate_stats_0.custom == {'localhost': {'docker_task_result': '1'}}

    # test that different host is not affected by update_custom_stats
    aggregate_stats_0.update_custom_stats("docker_task_result", "2", "127.0.0.1")

# Generated at 2022-06-24 19:11:41.500548
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.custom['_run'] = {'stat': 0}
    aggregate_stats_2 = AggregateStats()
    aggregate_stats_2.custom['some-host'] = {'stat': 0}
    aggregate_stats_3 = AggregateStats()
    aggregate_stats_3.custom['_run'] = {'stat': 'string'}
    aggregate_stats_4 = AggregateStats()
    aggregate_stats_4.custom['_run'] = {'stat': 0}
    aggregate_stats_4.custom['some-host'] = {'stat': 0}
    aggregate_stats_0.update_custom_stats('stat', 1, '_run')

# Generated at 2022-06-24 19:11:50.034409
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Given:
    which = 'dummy_custom_stat'
    what = 'dummy'
    which_1 = 'dummy_custom_stat'
    what_1 = {}
    which_2 = 'dummy_custom_stat'
    what_2 = 1
    which_3 = 'dummy_custom_stat'
    what_3 = {'dummy': 1}
    which_4 = 'dummy_custom_stat'
    what_4 = {'dummy': {'dummy': 1}}
    which_5 = 'dummy_custom_stat'
    what_5 = {'dummy': {'dummy': 1}}
    which_6 = 'dummy_custom_stat'
    what_6 = {'dummy': {'dummy': 1}}
    aggregate_stats = AggregateStats()

# Generated at 2022-06-24 19:11:51.969150
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('ok', {'rc': 0})
    assert aggregate_stats_0.custom['_run']['ok'] == {'rc': 0}


# Generated at 2022-06-24 19:12:00.437979
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('logs', {'a': 'test', 'b': 'test'})

    assert aggregate_stats_0.custom == {'_run': {'logs': {'a': 'test', 'b': 'test'}}}

    aggregate_stats_0.update_custom_stats('logs', {'a': 'test2', 'c': 'test3'})

    assert aggregate_stats_0.custom == {'_run': {'logs': {'a': 'test2', 'b': 'test', 'c': 'test3'}}}

    aggregate_stats_0.update_custom_stats('logs', 4)
