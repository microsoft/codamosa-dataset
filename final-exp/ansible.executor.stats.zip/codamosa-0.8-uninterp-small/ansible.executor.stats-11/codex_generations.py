

# Generated at 2022-06-24 19:07:17.465921
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    a = AggregateStats()
    a.decrement("failures", "hostA")
    assert a.failures["hostA"] == 0, "Test for decrement failed"
    

# Generated at 2022-06-24 19:07:19.444101
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement('ok','127.0.0.1')


# Generated at 2022-06-24 19:07:21.361645
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = test_case_0()
    aggregate_stats_0.decrement("rescued", "host_00")


# Generated at 2022-06-24 19:07:29.262179
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.set_custom_stats('failed_hosts', ['host_3'])
    aggregate_stats_0.set_custom_stats('failed_hosts', ['host_3'])
    aggregate_stats_0.set_custom_stats('failed_hosts', ['host_3'])
    aggregate_stats_0.set_custom_stats('failed_hosts', ['host_3'])
    aggregate_stats_0.update_custom_stats('failed_hosts', ['host_3'])

# Generated at 2022-06-24 19:07:32.177715
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_2 = AggregateStats()
    aggregate_stats_2.decrement('failures', 'localhost')


# Generated at 2022-06-24 19:07:37.247075
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    aggregate_stats_0 = AggregateStats()

    aggregate_stats_0.decrement('failures', 'host.example.com')

    # Comment the after line to make the the test PASS
    assert aggregate_stats_0.failures['host.example.com'] == 0
    print('SUCCESS: method decrement of class AggregateStats')

if __name__ == '__main__':
    test_case_0()
    test_AggregateStats_decrement()

# Generated at 2022-06-24 19:07:39.671766
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()

    assert aggregate_stats_0.decrement("failures", "foo") == None


# Generated at 2022-06-24 19:07:48.536088
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    assert aggregate_stats_1.rescued == {}
    assert aggregate_stats_1.skipped == {}
    for i in ['ok', 'failures']:
        setattr(aggregate_stats_1, i, {'host1': 1, 'host2': 2})
    aggregate_stats_1.decrement('skipped', 'host1')
    assert aggregate_stats_1.skipped['host1'] == -1
    aggregate_stats_1.decrement('skipped', 'host2')
    assert aggregate_stats_1.skipped['host2'] == -1
    aggregate_stats_1.decrement('rescued', 'host2')
    assert aggregate_stats_1.rescued['host2'] == -1
    # These should make no difference

# Generated at 2022-06-24 19:07:52.323012
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    what_values = ["ok", "failures", "dark", "changed", "skipped", "rescued", "ignored"]
    what = what_values[random.randint(0, len(what_values)-1)]
    host = random.randint(1, 6)
    aggregate_stats.decrement(what, host)


# Generated at 2022-06-24 19:07:55.604023
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.failures['test_host_0'] = 1
    aggregate_stats_0.decrement('failures', 'test_host_0')
    assert aggregate_stats_0.failures['test_host_0'] == 0


# Generated at 2022-06-24 19:08:04.306654
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats("foo", "bar")
    assert aggregate_stats_1.custom == {'_run': {'foo': 'bar'}}

    aggregate_stats_1.update_custom_stats("bar", "baz")
    assert aggregate_stats_1.custom == {'_run': {'foo': 'bar', 'bar': 'baz'}}

    aggregate_stats_2 = AggregateStats()
    aggregate_stats_2.update_custom_stats("foo", "bar", 'foo')
    assert aggregate_stats_2.custom == {'foo': {'foo': 'bar'}}

    aggregate_stats_2.update_custom_stats("bar", "baz", 'foo')

# Generated at 2022-06-24 19:08:11.292413
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('dwight', 'eisenhower', 'host_0')
    assert aggregate_stats_0.update_custom_stats('calvin', 'coolidge', 'host_0') is None
    assert aggregate_stats_0.custom['host_0']['dwight'] == 'eisenhower'


# Generated at 2022-06-24 19:08:23.417545
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()

    aggregate_stats_0.update_custom_stats('_run', 'ok')
    aggregate_stats_0.update_custom_stats('_run', 'dark')
    aggregate_stats_0.update_custom_stats('_run', 'changed')
    aggregate_stats_0.update_custom_stats('_run', 'skipped')
    aggregate_stats_0.update_custom_stats('_run', 'rescued')
    aggregate_stats_0.update_custom_stats('_run', 'ignored')
    aggregate_stats_0.update_custom_stats('_run', 'unreachable')
    aggregate_stats_0.update_custom_stats('_run', 'failures')

# Generated at 2022-06-24 19:08:28.032949
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    try:
        print("Test 0:", aggregate_stats_0.decrement("ok", "somewhere.local"))
    except Exception as e:
        print("Test 0:", repr(e))
    try:
        print("Test 1:", aggregate_stats_0.decrement("failures", "somewhere.local"))
    except KeyError as e:
        print("Test 1:", repr(e))


# Generated at 2022-06-24 19:08:34.678275
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()

    aggregate_stats.update_custom_stats('first_item', {'my_custom_stat': 1})
    aggregate_stats.update_custom_stats('first_item', {'my_custom_stat_2': 1}, 'fake_host')

    assert aggregate_stats.custom['_run'] == {'first_item': {'my_custom_stat': 1}}
    assert aggregate_stats.custom['fake_host'] == {'first_item': {'my_custom_stat_2': 1}}



# Generated at 2022-06-24 19:08:40.762516
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    result = aggregate_stats_0.update_custom_stats(
            'the_stats',
            dict(
                failed=True,
                unreachable=True,
                changed=True,
                skipped=True,
            )
    )
    assert result == {
        'changed': True,
        'failed': True,
        'skipped': True,
        'unreachable': True,
    }


# Generated at 2022-06-24 19:08:42.585926
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement("ignored", "localhost")


# Generated at 2022-06-24 19:08:46.176882
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.increment('ok', 'host_name')

    assert aggregate_stats_0.ok['host_name'] == 1


# Generated at 2022-06-24 19:08:48.525569
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_0 = AggregateStats()
    with pytest.raises(Exception) as e_info:
        aggregate_stats_0.increment({}, {})


# Generated at 2022-06-24 19:08:51.933374
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("ok", "host")
    aggregate_stats_0.decrement("failures", "host")
    aggregate_stats_0.decrement("dark", "host")
    aggregate_stats_0.decrement("changed", "host")
    aggregate_stats_0.decrement("skipped", "host")
    aggregate_stats_0.decrement("ignored", "host")
    aggregate_stats_0.decrement("rescued", "host")


# Generated at 2022-06-24 19:09:03.112501
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()

    aggregate_stats.increment('failures', 'host_1')
    assert aggregate_stats.failures.get('host_1', 0) == 1

    aggregate_stats.increment('failures', 'host_1')
    assert aggregate_stats.failures.get('host_1', 0) == 2

    aggregate_stats.decrement('failures', 'host_1')
    assert aggregate_stats.failures.get('host_1', 0) == 1

    aggregate_stats.decrement('failures', 'host_1')
    assert aggregate_stats.failures.get('host_1', 0) == 0

    aggregate_stats.decrement('failures', 'host_1')
    assert aggregate_stats.failures.get('host_1', 0) == 0




# Generated at 2022-06-24 19:09:05.316593
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Set up
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('ok', 'host')
    assert aggregate_stats_0.ok['host'] == -1


# Generated at 2022-06-24 19:09:09.492267
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('failures', 'gomel')
    aggregate_stats_0.decrement('ok', 'gomel')
    aggregate_stats_0.decrement('dark', 'gomel')
    aggregate_stats_0.decrement('changed', 'gomel')
    aggregate_stats_0.decrement('skipped', 'gomel')
    aggregate_stats_0.decrement('rescued', 'gomel')
    aggregate_stats_0.decrement('ignored', 'gomel')


# Generated at 2022-06-24 19:09:12.291376
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats0 = AggregateStats()
    aggregate_stats0.decrement('skipped', '192.168.1.1')
    aggregate_stats0.decrement('skipped', '192.168.1.1')


# Generated at 2022-06-24 19:09:21.312235
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()

    assert aggregate_stats.decrement('ok', 'fake_host') == 0
    assert aggregate_stats.decrement('ok', 'fake_host') == 0

    assert aggregate_stats.decrement('failures', 'fake_host') == 0
    assert aggregate_stats.decrement('failures', 'fake_host') == 0

    assert aggregate_stats.decrement('dark', 'fake_host') == 0
    assert aggregate_stats.decrement('dark', 'fake_host') == 0

    assert aggregate_stats.decrement('changed', 'fake_host') == 0
    assert aggregate_stats.decrement('changed', 'fake_host') == 0

    assert aggregate_stats.decrement('skipped', 'fake_host') == 0

# Generated at 2022-06-24 19:09:23.960038
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement('ok', 'localhost')
    assert (aggregate_stats_1.ok) == {'localhost': 0}


# Generated at 2022-06-24 19:09:26.333008
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_result = AggregateStats()
    aggregate_stats_result.update_custom_stats("which", "what", "host")



# Generated at 2022-06-24 19:09:28.370442
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("failures", "hamlet")


# Generated at 2022-06-24 19:09:30.793220
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement('ok', 'host')
    if aggregate_stats_1.ok != {'host': 0}:
        return 1


# Generated at 2022-06-24 19:09:32.341338
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # In the following line, replace 'pass' by the code you want to test
    pass


# Generated at 2022-06-24 19:09:46.399546
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    print("Testing update_custom_stats")
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats('running_tasks', {'t1': 't1_status', 't2': 't2_status'}, 'host1')
    assert aggregate_stats.custom['host1']['running_tasks']['t1'] == 't1_status'
    assert aggregate_stats.custom['host1']['running_tasks']['t2'] == 't2_status'
    assert len(aggregate_stats.custom['host1']['running_tasks']) == 2



# Generated at 2022-06-24 19:09:58.619543
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Setup the object
    aggregate_stats_0 = AggregateStats()
    # Add a stat
    aggregate_stats_0.set_custom_stats('ec2',{'instances': 1})
    aggregate_stats_0.set_custom_stats('ec2',{'volumes': 2})
    # Update the same stat
    aggregate_stats_0.update_custom_stats('ec2',{'instances': 0})
    # Update with a new stat
    aggregate_stats_0.update_custom_stats('ec2',{'snapshots': 1})
    # Check the results
    assert aggregate_stats_0.custom['_run']['ec2']['snapshots'] == 1
    assert aggregate_stats_0.custom['_run']['ec2']['volumes'] == 2
    assert aggregate_stats_

# Generated at 2022-06-24 19:10:05.767205
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # verify that set_custom_stats is setting the value for the given key
    aggregate_stats_test = AggregateStats()
    aggregate_stats_test.set_custom_stats('first_key', 'first_value')
    assert aggregate_stats_test.custom['_run']['first_key'] is 'first_value'

    # Verify set_custom_stats sets the value for the given host and key
    aggregate_stats_test = AggregateStats()
    aggregate_stats_test.set_custom_stats('first_key', 'first_value', 'foo_host')
    assert aggregate_stats_test.custom['foo_host']['first_key'] is 'first_value'

    aggregate_stats_test = AggregateStats()
    aggregate_stats_test.set_custom_stats('first_key', 'first_value')


# Generated at 2022-06-24 19:10:12.167897
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    print("START test_AggregateStats_update_custom_stats")
    aggregate_stats_1 = AggregateStats()
    host_0 = "host_0"
    which_0 = "which_0"
    which_1 = "which_1"
    which_2 = "which_2"
    what_0 = "what_0" * 512;
    what_1 = "what_1" * 512;
    what_2 = "what_2" * 512;
    aggregate_stats_1.set_custom_stats(which_0, what_0, host_0)
    aggregate_stats_1.set_custom_stats(which_1, what_1, host_0)
    aggregate_stats_1.set_custom_stats(which_2, what_2, host_0)
    aggregate_stats_

# Generated at 2022-06-24 19:10:22.022724
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats(which='FAILED', what='FAILED')
    aggregate_stats_0.update_custom_stats(host='host', what='host', which='host')
    aggregate_stats_0.update_custom_stats(host='host-host', which='host-host', what='host-host')
    aggregate_stats_0.update_custom_stats(host='host-host-host', what='host-host-host', which='host-host-host')
    aggregate_stats_0.update_custom_stats(which='host-host-host-host', what='host-host-host-host', host='host-host-host-host')


# Generated at 2022-06-24 19:10:32.667324
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    which_0 = 'foo'
    what_0 = {'bar': 'foobar'}
    host_0 = '_run'
    aggregate_stats_0.update_custom_stats(which_0, what_0, host_0)
    assert aggregate_stats_0.custom['_run']['foo'] == {'bar': 'foobar'}
    aggregate_stats_0 = AggregateStats()
    which_1 = 'foo'
    what_1 = {'bar': 'foobar'}
    host_1 = '_run'
    aggregate_stats_0.set_custom_stats(which_1, what_1, host_1)
    assert aggregate_stats_0.custom['_run']['foo'] == {'bar': 'foobar'}

# Generated at 2022-06-24 19:10:40.339258
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats("test_custom_stats_which","test_custom_stats_what")
    assert(aggregate_stats_1.update_custom_stats("test_custom_stats_which","test_custom_stats_what") == None)
    assert(aggregate_stats_1.custom["_run"]["test_custom_stats_which"] == "test_custom_stats_what")


# Generated at 2022-06-24 19:10:46.695004
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    # THIS CODE IS NOT EXECUTED BY ANSIBLE
    # ASSERTIONS MUST BE MANUALLY ADDED

    aggregate_stats_0 = AggregateStats()

    # AssertionError: assert update_custom_stats(<aggregate_stats_0 instance at 0x2>, which = <parameter 1>, what = <parameter 2>, host = <parameter 3>) == <return value>
    aggregate_stats_0.update_custom_stats(which = '_run', what = 1)

# Generated at 2022-06-24 19:10:49.481906
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('ok', 'ok', 'localhost')
    ok = aggregate_stats_0.custom['localhost']['ok']
    assert ok == 'ok'


# Generated at 2022-06-24 19:10:54.185948
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats(which='w', what='asdf')
    aggregate_stats_1.update_custom_stats(which='w', what='asdf', host='abc')
