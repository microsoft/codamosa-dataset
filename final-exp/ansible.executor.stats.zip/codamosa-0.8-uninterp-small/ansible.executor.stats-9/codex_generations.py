

# Generated at 2022-06-24 19:07:15.153114
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1.decrement('_what', 'host')


# Generated at 2022-06-24 19:07:17.101512
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    int_0 = 2989
    aggregate_stats_0 = AggregateStats()

    aggregate_stats_0.decrement('what', 'host')


# Generated at 2022-06-24 19:07:18.692638
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    int_0 = 2989
    aggregate_stats_0 = AggregateStats()
    assert aggregate_stats_0.decrement('_what', 'host') == None


# Generated at 2022-06-24 19:07:25.549753
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    int_0 = 2989
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.custom = {'_run': {}}
    aggregate_stats_0.custom['_run'] = {}
    aggregate_stats_0.custom = {'_run': {}}
    aggregate_stats_0.custom['_run'] = {}
    aggregate_stats_0.custom = {'_run': {'_run': {}}}
    aggregate_stats_0.custom['_run'] = {'_run': {}}
    aggregate_stats_0.custom = {'_run': {'_run': {}}}
    aggregate_stats_0.custom['_run'] = {'_run': {}}
    aggregate_stats_0.custom['_run'] = {}

# Generated at 2022-06-24 19:07:28.045700
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    int_0 = 3215
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement(string_0, string_1)


# Generated at 2022-06-24 19:07:38.529037
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    int_0 = 2989
    aggregate_stats_0 = AggregateStats()

    aggregate_stats_0.decrement('dark', 'host')
    aggregate_stats_0.decrement('failures', 'host')
    aggregate_stats_0.decrement('ignored', 'host')
    aggregate_stats_0.decrement('ok', 'host')
    aggregate_stats_0.decrement('rescued', 'host')
    aggregate_stats_0.decrement('skipped', 'host')
    aggregate_stats_0.decrement('changed', 'host')


# Generated at 2022-06-24 19:07:42.007556
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test_case_0()
    int_0 = -1
    aggregate_stats_0 = AggregateStats()
    with pytest.raises(KeyError):
        aggregate_stats_0.decrement('', int_0)


# Generated at 2022-06-24 19:07:49.880937
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    args = {'what': {'host': 'foo.example.com'}, 'host': 'foo.example.com'}
    aggregate_stats_0 = AggregateStats()
    # Decrementing ok
    aggregate_stats_0.ok[args['host']] = 1
    aggregate_stats_0.decrement(args['what'], args['host'])
    # Decrementing failures
    aggregate_stats_0.failures[args['host']] = 1
    aggregate_stats_0.decrement(args['what'], args['host'])
    # Decrementing dark
    aggregate_stats_0.dark[args['host']] = 1
    aggregate_stats_0.decrement(args['what'], args['host'])
    # Decrementing changed

# Generated at 2022-06-24 19:07:51.543365
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats(str_0, bytes_0)


# Generated at 2022-06-24 19:07:57.056177
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    int_0 = 141
    str_0 = "failures"
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement(str_0, int_0)


# Generated at 2022-06-24 19:08:05.002938
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.increment('ok', 'localhost')
    assert(aggregate_stats_0.ok['localhost'] == 1)
    aggregate_stats_0.increment('ok', 'localhost')
    assert(aggregate_stats_0.ok['localhost'] == 2)


# Generated at 2022-06-24 19:08:10.962540
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
   aggregate_stats_0 = AggregateStats()
   aggregate_stats_0.update_custom_stats("changed", {}, '_run')
   aggregate_stats_0.decrement('changed', '_run')
   aggregate_stats_0.decrement('ok', '_run')
   aggregate_stats_0.decrement('ok', '_run')
   aggregate_stats_0.decrement('rescued', '_run')
   aggregate_stats_0.decrement('ok', '_run')
   aggregate_stats_0.decrement('dark', '_run')
   aggregate_stats_0.decrement('changed', '_run')
   aggregate_stats_0.decrement('ignored', '_run')
   aggregate_stats_0.decrement('ok', '_run')


# Generated at 2022-06-24 19:08:13.420644
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("ok", "test_string_0")



# Generated at 2022-06-24 19:08:16.635735
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    stats = None
    aggregate_stats_0.update_custom_stats("stats", stats)


# Generated at 2022-06-24 19:08:20.382339
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("ok","dehaan")
    assert aggregate_stats_0.ok.get("dehaan", 0) == 0


# Generated at 2022-06-24 19:08:28.819565
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    # initialization
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.custom = None
    aggregate_stats_1.custom = {'_run': {}}
    aggregate_stats_1.custom['_run'] = {'foo': None}
    aggregate_stats_1.custom['_run'] = {'foo': 1}
    aggregate_stats_1.custom['_run'] = {'foo': {'bar': None}}
    aggregate_stats_1.custom['_run'] = {'foo': {'bar': {}},'bar':'test1'}
    aggregate_stats_1.update_custom_stats('foo', '1')
    aggregate_stats_1.update_custom_stats('foo', '2')

# Generated at 2022-06-24 19:08:40.111527
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('ok', 'ok')
    aggregate_stats_0.update_custom_stats('ok', 1)
    aggregate_stats_0.update_custom_stats('ok', 2)
    aggregate_stats_0.update_custom_stats('ok', 3)
    aggregate_stats_0.update_custom_stats('ok', 4)
    aggregate_stats_0.update_custom_stats('ok', 5)
    aggregate_stats_0.update_custom_stats('ok', 6)
    aggregate_stats_0.update_custom_stats('ok', 7)
    aggregate_stats_0.update_custom_stats('ok', 8)
    aggregate_stats_0.update_custom_stats('ok', 9)
    aggregate_stats_0

# Generated at 2022-06-24 19:08:50.126944
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.increment("ignored", "localhost")
    assert(aggregate_stats_1.ignored["localhost"] == 1)
    assert(aggregate_stats_1.processed["localhost"] == 1)

    aggregate_stats_2 = AggregateStats()
    aggregate_stats_2.increment("failures", "localhost")
    assert(aggregate_stats_2.failures["localhost"] == 1)
    assert(aggregate_stats_2.processed["localhost"] == 1)

    aggregate_stats_3 = AggregateStats()
    aggregate_stats_3.increment("dark", "localhost")
    assert(aggregate_stats_3.dark["localhost"] == 1)
    assert(aggregate_stats_3.processed["localhost"] == 1)



# Generated at 2022-06-24 19:08:53.020648
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats(which='which_value', what='what_value')


# Generated at 2022-06-24 19:08:57.437408
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    setattr(aggregate_stats, 'ok', {'host1': 1})
    assert(aggregate_stats.decrement('ok', 'host1') == 0)
    setattr(aggregate_stats, 'ok', {'host1': 0})
    assert(aggregate_stats.decrement('ok', 'host1') == 0)
    setattr(aggregate_stats, 'ok', {'host2': 1})
    assert(aggregate_stats.decrement('ok', 'host1') == 0)


# Generated at 2022-06-24 19:09:02.114180
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('skipped', 'localhost')


# Generated at 2022-06-24 19:09:06.282603
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement("ok", "127.0.0.1")
    assert aggregate_stats_1.ok["127.0.0.1"] == 0


# Generated at 2022-06-24 19:09:09.453814
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    assert hasattr(aggregate_stats_0, 'update_custom_stats')


# Generated at 2022-06-24 19:09:13.779728
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    global aggregate_stats_0
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('ok', '127.0.0.1')
    assert aggregate_stats_0.ok['127.0.0.1'] == 0


# Generated at 2022-06-24 19:09:14.838095
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    assert(True)



# Generated at 2022-06-24 19:09:16.800678
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Setup
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('what', host='host')



# Generated at 2022-06-24 19:09:19.736217
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats(which = "jumps", what = "an obstacle", host = None)
    assert aggregate_stats.custom == {"_run":{"jumps":"an obstacle"}}


# Generated at 2022-06-24 19:09:30.933407
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_obj_1 = AggregateStats()
    aggregate_stats_obj_1.set_custom_stats('test_1', 'hello_1')
    aggregate_stats_obj_1.set_custom_stats('test_2', 'hello_2')
    aggregate_stats_obj_1.set_custom_stats('test_1', 'hello_3', host='myhost_1')
    aggregate_stats_obj_1.set_custom_stats('test_2', 'hello_4', host='myhost_1')
    aggregate_stats_obj_1.set_custom_stats('test_1', 'hello_5', host='myhost_2')
    aggregate_stats_obj_1.set_custom_stats('test_2', 'hello_6', host='myhost_2')
    aggregate_stats_obj_

# Generated at 2022-06-24 19:09:34.835025
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats("custom_stats-test_name", "custom_stats-test_what_value", "custom_stats-test_host")


# Generated at 2022-06-24 19:09:41.519563
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats("custom_top_level", "test_value", "_run")
    assert aggregate_stats_0.custom == {'_run': {'custom_top_level': 'test_value'}}
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.custom = {'_run': {'custom_top_level': 'current_value'}}
    aggregate_stats_1.update_custom_stats("custom_top_level", "new_value", "_run")
    assert aggregate_stats_1.custom == {'_run': {'custom_top_level': 'new_value'}}
    aggregate_stats_2 = AggregateStats()

# Generated at 2022-06-24 19:09:45.124592
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats(u'ping', dict(), True)


# Generated at 2022-06-24 19:09:48.479234
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggr_stats = AggregateStats()
    aggr_stats.update_custom_stats(None, None)



# Generated at 2022-06-24 19:09:52.960934
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    _custom = {'stats': {'a': 1}}
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.custom = {'stats': {'a': 1}}
    assert _custom.items() == aggregate_stats_0.custom.items()
    aggregate_stats_0.custom = {'stats': {'b': 2}}
    assert _custom.items() != aggregate_stats_0.custom.items()


# Generated at 2022-06-24 19:09:56.108325
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
   aggregate_stats_1 = AggregateStats()
   aggregate_stats_1.update_custom_stats('custom_stats','1','host')
   assert aggregate_stats_1.custom['host']['custom_stats'] == '1'


# Generated at 2022-06-24 19:09:58.187785
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test_case_0()
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('changed', 'host1')


# Generated at 2022-06-24 19:10:01.252186
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats("foo", "bar")
    assert aggregate_stats_1.custom["_run"]["foo"] == "bar"



# Generated at 2022-06-24 19:10:05.063605
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement("dark", "some_host")
    assert aggregate_stats_1.dark["some_host"] == 0
    aggregate_stats_1.dark["some_host"] = 3
    aggregate_stats_1.decrement("dark", "some_host")
    assert aggregate_stats_1.dark["some_host"] == 2


# Generated at 2022-06-24 19:10:07.929530
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats(which = "test", what = "test_string")
    aggregate_stats.update_custom_stats(which = "test", what = "test_string_1")
    assert(aggregate_stats.custom["_run"]["test"] == "test_stringtest_string_1")


# Generated at 2022-06-24 19:10:11.040633
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    key = None
    value = None
    host = None
    assert aggregate_stats.update_custom_stats(key, value, host) is None
    assert aggregate_stats.custom['_run'] == {key: value}


# Generated at 2022-06-24 19:10:15.873861
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()

    result = aggregate_stats_1.update_custom_stats("some_key", "some_value")
    expected = None
    assert result == expected

    result = aggregate_stats_1.update_custom_stats("some_key", "some_other_value", "some_host")
    expected = None
    assert result == expected

# Generated at 2022-06-24 19:10:26.162030
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    host_1 = '1.1.1.1'

    # First call with the standard values
    aggregate_stats_1.decrement('ok', host_1)

    if not aggregate_stats_1.ok[host_1] == 0:
        return(False)

    # Second call with a decremented value
    aggregate_stats_1.decrement('ok', host_1)

    if not aggregate_stats_1.ok[host_1] == 0:
        return(False)

    aggregate_stats_1.ok[host_1] = 1
    # Third call with a decremented value
    aggregate_stats_1.decrement('ok', host_1)


# Generated at 2022-06-24 19:10:35.995902
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    test_what = list(aggregate_stats_1.__dict__.keys())
    aggregate_stats_1.processed['host'] = 1
    aggregate_stats_1.processed['host2'] = 1
    for what in test_what:
        getattr(aggregate_stats_1, what)['host'] = 1
        getattr(aggregate_stats_1, what)['host2'] = 2
    for what in test_what:
        for host in ['host', 'host2']:
            aggregate_stats_1.decrement(what, host)
        assert all([i == 0 for i in getattr(aggregate_stats_1, what).values()])


# Generated at 2022-06-24 19:10:42.161497
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    print("Test AggregateStats.update_custom_stats")
    aggregate_stats = AggregateStats()
    to_add_0 = {'pending': {'foo', 'bar'}}
    aggregate_stats.update_custom_stats('pending', to_add_0)
    assert aggregate_stats.custom['_run']['pending'] == to_add_0['pending']
    to_add_1 = {'pending': {'baz'}}
    aggregate_stats.update_custom_stats('pending', to_add_1)
    assert aggregate_stats.custom['_run']['pending'] == {'foo', 'bar', 'baz'}


# Generated at 2022-06-24 19:10:46.770511
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats('a', 1, 'host1')
    aggregate_stats.update_custom_stats('b', 2, 'host1')
    aggregate_stats.update_custom_stats('c', 3, 'host2')
    aggregate_stats.update_custom_stats('c', 4, 'host2')
    assert aggregate_stats.custom['host1'] == {'b': 2, 'a': 1}
    assert aggregate_stats.custom['host2'] == {'c': 7}

if __name__ == '__main__':
    test_case_0()
    test_AggregateStats_update_custom_stats()

# Generated at 2022-06-24 19:10:51.346681
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    """Check that the update_custom_stats function of the AggregateStats class is working properly."""
    aggregate_stats = AggregateStats()

    aggregate_stats.update_custom_stats('test', 'foobar')
    assert aggregate_stats.custom['_run']['test'] == 'foobar', 'The test failed'
    aggregate_stats.update_custom_stats('test', 'foobar_2')
    assert aggregate_stats.custom['_run']['test'] == 'foobar_2', 'The test failed'


# Generated at 2022-06-24 19:10:55.625694
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg_stat = AggregateStats()
    agg_stat.decrement("dark", "localhost")
    assert agg_stat.dark["localhost"] == 1


# Generated at 2022-06-24 19:10:58.751386
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats("test", "test")
    assert aggregate_stats_0.custom["_run"]["test"] == "test"


# Generated at 2022-06-24 19:11:02.772853
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    """decrement."""
    # Arrange
    aggregate_stats = AggregateStats()
    what = 'dark'
    host = '192.168.0.100'
    aggregate_stats.increment(what, host)

    # Act
    aggregate_stats.decrement(what, host)

    # Assert
    assert aggregate_stats.dark[host] == 0


# Generated at 2022-06-24 19:11:08.562131
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement(u'ok', u'example.com')
    aggregate_stats_0.decrement(u'ok', u'example.com')
    aggregate_stats_0.decrement(u'ok', u'example.com')
    aggregate_stats_0.decrement(u'ok', u'example.com')
    aggregate_stats_0.decrement(u'ok', u'example.com')
    assert aggregate_stats_0.ok[u'example.com'] == 0


# Generated at 2022-06-24 19:11:12.505964
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    which_1 = 'foo'
    what_1 = 'hello world'
    host_1 = 'foo_host'
    expected_1 = {'foo': 'hello world'}
    aggregate_stats_1.update_custom_stats(which_1, what_1, host_1)
    result_1 = aggregate_stats_1.custom[host_1]
    assert result_1 == expected_1


# Generated at 2022-06-24 19:11:18.009693
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("failures","failures")


# Generated at 2022-06-24 19:11:22.770755
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment("changed", "www.foo.com")
    aggregate_stats.decrement("changed", "www.foo.com")

test_case_0()
test_AggregateStats_decrement()

# Generated at 2022-06-24 19:11:29.375951
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    host_0 = {'foo'}
    what = 'processed'
    aggregate_stats_0.decrement(what, host_0)


# Generated at 2022-06-24 19:11:32.504302
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('ok', 'example.org')
    aggregate_stats_0.decrement('ok', 'example.org')
    aggregate_stats_0.decrement('ok', 'example.org')


# Generated at 2022-06-24 19:11:37.527807
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    which = 'ok'
    host = 'foo'
    aggregate_stats.decrement(which, host)
    assert aggregate_stats.ok[host] == 0


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 19:11:40.187199
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test_AggregateStats_decrement_0()


# Generated at 2022-06-24 19:11:42.454496
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('ok', '')
    aggregate_stats_0.decrement('ok', '')
    aggregate_stats_0.decrement('ok', '')


# Generated at 2022-06-24 19:11:51.731373
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Initialize class/instance
    aggregate_stats = AggregateStats()
    # If it's the first time we call decrement on an host, there's nothing to decrement
    # As a result exception should be thrown and we should return 0
    assert(aggregate_stats.decrement('ok', 'localhost') == 0)
    # Just to make sure that it really doesn't decrease
    aggregate_stats.increment('ok', 'localhost')
    aggregate_stats.increment('ok', 'localhost')
    aggregate_stats.increment('ok', 'localhost')
    aggregate_stats.increment('ok', 'localhost')
    # The value should now be 4
    assert(aggregate_stats.decrement('ok', 'localhost') == 3)


# Generated at 2022-06-24 19:11:53.586757
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('changed', 'some-host')


# Generated at 2022-06-24 19:11:56.344312
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    assert aggregate_stats_0.decrement('dark', 'dark') is None
