

# Generated at 2022-06-24 19:07:17.773454
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement('ok', 'localhost')
    assert aggregate_stats.ok['localhost'] == 0


# Generated at 2022-06-24 19:07:20.125603
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_1 = AggregateStats()
    host = "test"
    aggregate_stats_1.increment("ok", host)
    assert aggregate_stats_1.ok[host] == 1


# Generated at 2022-06-24 19:07:21.599818
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    result = aggregate_stats_0.update_custom_stats('which', 'what')


# Generated at 2022-06-24 19:07:29.928791
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('failures', 'localhost')
    this_ok = aggregate_stats_0.ok.get('localhost', 0)
    this_dark = aggregate_stats_0.dark.get('localhost', 0)
    this_changed = aggregate_stats_0.changed.get('localhost', 0)
    this_skipped = aggregate_stats_0.skipped.get('localhost', 0)
    this_rescued = aggregate_stats_0.rescued.get('localhost', 0)
    this_ignored = aggregate_stats_0.ignored.get('localhost', 0)


# Generated at 2022-06-24 19:07:39.070663
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()

    # Test object state before method
    assert aggregate_stats.__dict__.get('ok') == {}, 'Failed to add value to dict.'
    assert aggregate_stats.__dict__.get('ok') != {'host': -1}, 'Value added to dict.'

    # Test after method
    aggregate_stats.decrement('ok', 'host')
    assert aggregate_stats.__dict__.get('ok') == {'host': 0}, 'Failed to decrement value in dict.'
    assert aggregate_stats.__dict__.get('ok') != {'host': -1}, 'Value in dict did not decrement.'

    # Test KeyError
    aggregate_stats.decrement('ok', 'host2')

# Generated at 2022-06-24 19:07:45.626022
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    '''
        @Test: Verify that decrement() method of class AggregateStats returns
               the decremented count.
        @Feature: AggregateStats Class
        @Assert: decrement() method should return the decremented count.
        @Status: Automated
    '''

    aggregate_stats = AggregateStats()
    # decrement(what, host)
    aggregate_stats.decrement('failures', 'test')
    aggregate_stats.decrement('failures', 'test')

    assert aggregate_stats.failures == {'test': 0}


# Generated at 2022-06-24 19:07:49.368728
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.utils.vars import merge_hash

    aggregate_stats_0 = AggregateStats()
    what = ''
    host = ''
    aggregate_stats_0.decrement(what, host)


# Generated at 2022-06-24 19:07:52.293443
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'test_host')
    assert aggregate_stats.ok['test_host'] == 1

    aggregate_stats.decrement('ok', 'test_host')
    assert aggregate_stats.ok['test_host'] == 0


# Generated at 2022-06-24 19:07:57.131551
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    stats_0 = aggregate_stats_0.decrement(what='failures', host='192.168.1.1')


# Generated at 2022-06-24 19:08:00.364368
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    test_case_0()

# Generated at 2022-06-24 19:08:05.090696
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    custom = aggregate_stats_0.custom
    assert custom == {}
    host_0 = '_run'
    which_0 = 'which'
    what_0 = 'what'
    aggregate_stats_0.update_custom_stats(which_0, what_0)
    assert custom == {'_run': {'which': 'what'}}


# Generated at 2022-06-24 19:08:07.967417
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    result = aggregate_stats_1.update_custom_stats(
        'retrieved', 1, host='_run'
    )

    assert aggregate_stats_1.custom is not None
    assert result is None



# Generated at 2022-06-24 19:08:09.609967
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats(0, 0)

test_case_0()
test_AggregateStats_update_custom_stats()

# Generated at 2022-06-24 19:08:14.627898
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.custom = {None: {}}
    aggregate_stats_1.update_custom_stats('0', '1')
    assert aggregate_stats_1.custom == {'_run': {'0': '1'}}


# Generated at 2022-06-24 19:08:23.202883
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.custom = {'_run': {'foo': 1, 'bar': {'a': 1, 'b': 2}}}
    assert aggregate_stats.update_custom_stats('foo', 2) == None
    assert aggregate_stats.update_custom_stats('bar', {'a': 4, 'c': 3}) == None
    assert aggregate_stats.custom == {'_run': {'foo': 1, 'bar': {'a': 5, 'b': 2, 'c': 3}}}


# Generated at 2022-06-24 19:08:26.243057
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    # Case 0
    aggregate_stats_0 = AggregateStats()
    # Case 0 assert
    assert aggregate_stats_0 != None

    # Case 1
    # Case 1 assert
    assert isinstance(aggregate_stats_0, AggregateStats)



# Generated at 2022-06-24 19:08:29.047730
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('changed', '10.0.2.2')


# Generated at 2022-06-24 19:08:36.459475
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("failures", "host")
    aggregate_stats_0.decrement("ok", "host")
    aggregate_stats_0.decrement("dark", "host")
    aggregate_stats_0.decrement("changed", "host")
    aggregate_stats_0.decrement("skipped", "host")
    aggregate_stats_0.decrement("rescued", "host")
    aggregate_stats_0.decrement("ignored", "host")


# Generated at 2022-06-24 19:08:48.251818
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # This is a list of potential inputs to the decrement method.
    test_cases = [
        # A test case that should succeed and decrease stats by 1.
        {
            'inputs': {
                'what': 'failures',
                'host': '127.0.0.1'
            },
            'expect': {
                'processed': {
                    '127.0.0.1': 1
                },
                'failures': {
                    '127.0.0.1': 0
                },
                'dark': {},
                'ok': {},
                'changed': {},
                'skipped': {},
                'rescued': {},
                'ignored': {}
            }
        },
    ]

    for test_case in test_cases:
        tmp_aggregate_stats = Agg

# Generated at 2022-06-24 19:08:51.682656
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    # param: what: it is an object of type dict 
    # param: host: it is an object of type str
    # param: which: it is an object of type str
    which = 'test'
    what = dict()
    aggregate_stats_0.update_custom_stats(which, what)
