

# Generated at 2022-06-24 19:07:23.017839
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_0 = AggregateStats()
    assert aggregate_stats_0.processed == {}
    assert aggregate_stats_0.failures == {}
    assert aggregate_stats_0.ok == {}
    assert aggregate_stats_0.dark == {}
    assert aggregate_stats_0.changed == {}
    assert aggregate_stats_0.skipped == {}
    assert aggregate_stats_0.rescued == {}
    assert aggregate_stats_0.ignored == {}
    assert aggregate_stats_0.custom == {}
    aggregate_stats_0.increment("ok", "NAME")
    assert aggregate_stats_0.processed == {"NAME": 1}
    assert aggregate_stats_0.failures == {}
    assert aggregate_stats_0.ok == {"NAME": 1}
    assert aggregate_stats_0.dark == {}

# Generated at 2022-06-24 19:07:28.339561
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_2 = AggregateStats()
    aggregate_stats_2.update_custom_stats('ok', 123, '_run')
    if aggregate_stats_2.custom['_run']['ok'] != 123:
        raise Exception("Unexpected value in stats.custom[host]['ok']: %s" % aggregate_stats_2.custom['_run']['ok'])
    aggregate_stats_2.update_custom_stats('ok', 123, '_run')
    if aggregate_stats_2.custom['_run']['ok'] != 246:
        raise Exception("Unexpected value in stats.custom[host]['ok']: %s" % aggregate_stats_2.custom['_run']['ok'])
    aggregate_stats_2.update_custom_stats('ok', 123, '_run')
   

# Generated at 2022-06-24 19:07:32.455135
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    host = 'host'
    aggregate_stats.decrement('failures', host)
    assert aggregate_stats.summarize(host)['failures'] == 0


# Generated at 2022-06-24 19:07:34.297017
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("ok","host_0")


# Generated at 2022-06-24 19:07:39.944924
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("ok","host")
    aggregate_stats_0.decrement("ignored","host")


# Generated at 2022-06-24 19:07:52.020354
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.ignored = {'b': 3}
    aggregate_stats_0.dark = {'a': 1}
    aggregate_stats_0.skipped = {'b': 3}
    aggregate_stats_0.rescued = {'a': 1}
    aggregate_stats_0.ok = {'a': 0, 'b': 2}
    aggregate_stats_0.changed = {'b': 3}
    aggregate_stats_0.failures = {'b': 3}
    aggregate_stats_0.decrement('ignored', 'a')
    aggregate_stats_0.decrement('dark', 'a')
    aggregate_stats_0.decrement('skipped', 'a')

# Generated at 2022-06-24 19:08:00.122179
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():

    # Test with a simple string
    aggregate_stats = AggregateStats()
    aggregate_stats.increment("ok", "somehost.local")
    aggregate_stats.increment("changed", "somehost.local")
    aggregate_stats.increment("failed", "somehost.local")

    # Test with a list of strings
    aggregate_stats.increment(["ok", "changed", "failed"], "somehost.local")
    aggregate_stats.increment(["ok", "changed", "ok", "ok"], "somehost.local")


# Generated at 2022-06-24 19:08:03.192439
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    """
        Test case for decrement method of class AggregateStats.
    """
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement(what="ok", host="host_0")
    aggregate_stats_0.decrement(what="ok", host="host_0")
    assert aggregate_stats_0.ok == {'host_0': 0}


# Generated at 2022-06-24 19:08:04.641307
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_0 = AggregateStats()
    what = ""
    host = ""
    aggregate_stats_0.increment(what, host)


# Generated at 2022-06-24 19:08:13.813202
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    global aggregate_stats_0
    test_case_0()

    host_1 = "example.com"
    what_2 = "ok"
    aggregate_stats_0.increment(what_2, host_1)
    aggregate_stats_0.increment(what_2, host_1)
    aggregate_stats_0.increment(what_2, host_1)
    aggregate_stats_0.increment(what_2, host_1)
    assert aggregate_stats_0.ok[host_1] == 4
    aggregate_stats_0.increment(what_2, host_1)
    assert aggregate_stats_0.ok[host_1] == 5


# Generated at 2022-06-24 19:08:19.240940
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats=AggregateStats()
    aggregate_stats.decrement('failures', 'host')
    assert aggregate_stats.failures.get('host') == 0


# Generated at 2022-06-24 19:08:23.489247
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    host = 'localhost'
    what = 'ignored'
    aggregate_stats_0 = AggregateStats()

# Generated at 2022-06-24 19:08:25.015953
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement("what", "host")

# Generated at 2022-06-24 19:08:33.506993
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement('failures', host='dc1')
    assert aggregate_stats_1.failures['dc1'] == 0
    aggregate_stats_1.decrement('failures', host='dc1')
    assert aggregate_stats_1.failures['dc1'] == 0


# Generated at 2022-06-24 19:08:40.834419
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    what = 'failures'
    host = 'foo'
    aggregate_stats_0.decrement(what, host)
    aggregate_stats_0.increment(what, host)
    aggregate_stats_0.increment(what, host)
    aggregate_stats_0.increment(what, host)
    aggregate_stats_0.decrement(what, host)
    aggregate_stats_0.decrement(what, host)


# Generated at 2022-06-24 19:08:42.963909
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    assert aggregate_stats_0.decrement('what', 'host') == None


# Generated at 2022-06-24 19:08:51.848098
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # test when host = None
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats(which="custom_stats_1", what=1)
    print('aggregate_stats_1:', aggregate_stats_1.custom)

    # test when host is not None
    aggregate_stats_2 = AggregateStats()
    aggregate_stats_2.update_custom_stats(which="custom_stats_2", what=1, host='host_1')
    aggregate_stats_2.update_custom_stats(which="custom_stats_3", what=2, host='host_1')
    aggregate_stats_2.update_custom_stats(which="custom_stats_2", what=3, host='host_2')

# Generated at 2022-06-24 19:09:01.171229
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    # Get class
    aggregate_stats = AggregateStats()
    host = None
    what = host

    # Test for properly called exception
    try:
        aggregate_stats.decrement(what, host)
        assert False
    except AttributeError as e:
        assert "has no attribute '%s'" % what in str(e)

    # Test for increment
    what = "ok"
    host = "foo"
    prev = aggregate_stats.ok.get(host, 0)
    aggregate_stats.decrement(what, host)
    assert aggregate_stats.ok[host] == prev - 1


# Generated at 2022-06-24 19:09:05.906512
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement(host='host1', what='changed')
    assert aggregate_stats_1.changed['host1'] == 0


# Generated at 2022-06-24 19:09:13.553212
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats("ok", 1, "cisco_g2")
    aggregate_stats_0.update_custom_stats("ok", 1, "cisco_g2")
    aggregate_stats_0.update_custom_stats("ok", 1, "cisco_g2")
    aggregate_stats_0.update_custom_stats("ok", 2, "cisco_g2")
    aggregate_stats_0.update_custom_stats("ok", 1, "cisco_g2")

    assert aggregate_stats_0.custom["cisco_g2"] == {"ok": 5}


# Generated at 2022-06-24 19:09:19.288727
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats("which", {"what": "what"}, "host")
    assert aggregate_stats.custom["host"] == {"which": {"what": "what"}}
    aggregate_stats.update_custom_stats("which", {"what": "what"}, "host")
    assert aggregate_stats.custom["host"] == {"which": {"what": "what"}}



# Generated at 2022-06-24 19:09:27.362214
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Init aggregate_stats_1
    aggregate_stats_1 = AggregateStats()

    # Check if method update_custom_stats of aggregate_stats_1 raises an
    # expected exception
    try:
        aggregate_stats_1.update_custom_stats()
        assert False, "Failed to raise exception"
    except TypeError:
        pass



# Generated at 2022-06-24 19:09:30.281942
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    test_AggregateStats = AggregateStats()
    try:
        test_AggregateStats.update_custom_stats('which', 'what')
    except:
        raise AssertionError("Failed to handle overloaded '+' operation")



# Generated at 2022-06-24 19:09:36.866004
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('x', 'x', None)
    aggregate_stats_0.update_custom_stats('x', {'x': 'x'}, None)
    aggregate_stats_0.update_custom_stats('x', 'x', '_run')
    aggregate_stats_0.update_custom_stats('x', {'x': 'x'}, '_run')

if __name__ == "__main__":
    print("test_case_0")
    test_case_0()
    print("test_AggregateStats_update_custom_stats")
    test_AggregateStats_update_custom_stats()

# Generated at 2022-06-24 19:09:39.543896
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()

    aggregate_stats_0.update_custom_stats('which', 'what')


# Generated at 2022-06-24 19:09:49.680902
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    agg_stats = AggregateStats()
    assert agg_stats.custom == {}
    agg_stats.update_custom_stats('my_key', 3)
    assert agg_stats.custom == {'_run': {'my_key': 3}}
    agg_stats.update_custom_stats('my_key', 5)
    assert agg_stats.custom == {'_run': {'my_key': 8}}
    agg_stats.update_custom_stats('my_key', 0)
    assert agg_stats.custom == {'_run': {'my_key': 8}}
    agg_stats.update_custom_stats('my_key', {'a': 3})
    assert agg_stats.custom == {'_run': {'my_key': {'a': 3}}}

# Generated at 2022-06-24 19:09:57.718697
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.custom == {}
    aggregate_stats.update_custom_stats('foo', 'bar')
    assert aggregate_stats.custom == {'_run': {'foo': 'bar'}}

    # Test increment
    aggregate_stats.update_custom_stats('foo', 1)
    assert aggregate_stats.custom == {'_run': {'foo': 2}}

    # Test merge
    aggregate_stats.update_custom_stats('foo', {'bar': 'baz'})
    assert aggregate_stats.custom == {'_run': {'foo': {'bar': 'baz'}}}

    # Test merge again
    aggregate_stats.update_custom_stats('foo', {'spam': 'eggs'})

# Generated at 2022-06-24 19:10:04.508151
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    global passed_test
    passed_test = True
    # TEST CASE 0:
    which_0 = "test_which"
    what_0 = {"test_what_0": 0, "test_what_1": 1}
    aggregate_stats_0.update_custom_stats(which_0, what_0)

    if aggregate_stats_0.custom["_run"][which_0] != what_0:
        print("FAILED: updated custom stats not added properly")
        print("aggregate_stats_0.custom[\"_run\"][which_0]: " +
              str(aggregate_stats_0.custom["_run"][which_0]))
        print("what_0: " + str(what_0))
        passed_test = False

    #

# Generated at 2022-06-24 19:10:08.379474
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats("what", "failures", " host")



# Generated at 2022-06-24 19:10:13.091714
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Test with simple list
    agg_stats = AggregateStats()
    agg_stats.update_custom_stats('lst', [1, 2, 3])
    assert agg_stats.custom['_run'] == {'lst': [1, 2, 3]}
    agg_stats.update_custom_stats('lst', [4, 5])
    assert agg_stats.custom['_run'] == {'lst': [1, 2, 3, 4, 5]}
    # Test with simple integer
    agg_stats = AggregateStats()
    agg_stats.update_custom_stats('int', 1)
    assert agg_stats.custom['_run'] == {'int': 1}
    agg_stats.update_custom_stats('int', 2)
    assert agg_stats.custom['_run'] == {'int': 3}