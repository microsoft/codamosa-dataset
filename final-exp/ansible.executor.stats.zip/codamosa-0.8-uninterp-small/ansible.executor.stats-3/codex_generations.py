

# Generated at 2022-06-24 19:07:22.629583
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats('foo', 42)
    assert aggregate_stats_1.custom['_run']['foo'] == 42, "unexpected value"
    aggregate_stats_1.update_custom_stats('foo', 5, host='bar')
    assert aggregate_stats_1.custom['bar']['foo'] == 5, "unexpected value"
    aggregate_stats_1.update_custom_stats('foo', 'bar', host='bar')
    assert aggregate_stats_1.custom['bar']['foo'] == 'bar', "unexpected value"
    aggregate_stats_1.update_custom_stats('foo', 'baz', host='bar')

# Generated at 2022-06-24 19:07:28.088228
# Unit test for method decrement of class AggregateStats

# Generated at 2022-06-24 19:07:32.097732
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.rescued[None] = 1
    aggregate_stats_0.decrement('rescued', None)
    assert aggregate_stats_0.rescued[None] == 0

# Generated at 2022-06-24 19:07:36.375899
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.increment('changed', 'test')
    # Check the value of changed attribute in aggregate_stats_0 object
    assert aggregate_stats_0.changed['test'] == 1


# Generated at 2022-06-24 19:07:45.291630
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    what = "skipped"
    host = "127.0.0.1"
    aggregate_stats_0.processed[host] = 1
    prev = (getattr(aggregate_stats_0, what)).get(host, 0)
    getattr(aggregate_stats_0, what)[host] = prev + 1
    try:
        if aggregate_stats_0.skipped[host] - 1 < 0:
            raise KeyError("Don't be so negative")
        aggregate_stats_0.skipped[host] -= 1
    except KeyError:
        aggregate_stats_0.skipped[host] = 0
    #assert aggregate_stats_0.skipped[host] == 0


# Generated at 2022-06-24 19:07:48.850252
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('', '', '')
    assert aggregate_stats_0.custom == {}
    assert aggregate_stats_0.custom['_run'] == {}


# Generated at 2022-06-24 19:07:51.307543
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats('test', 'test')
    assert aggregate_stats_1.custom == {'_run': {'test': 'test'}}


# Generated at 2022-06-24 19:07:57.995965
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    what_0 = 'ignored'
    host_0 = 'hn1.example.com'
    aggregate_stats_0.decrement(what_0, host_0)
    return

# Test for method increment of class AggregateStats

# Generated at 2022-06-24 19:08:04.507445
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    '''
    Unit test for method increment of class AggregateStats
    '''
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.increment('failures', 'host5')
    aggregate_stats_1.increment('ok', 'host5')
    assert aggregate_stats_1.custom == {}, 'aggregate_stats.custom not initialized'
    assert aggregate_stats_1.processed == {'host5': 1}, 'aggregate_stats.processed not initialized'
    assert aggregate_stats_1.changed == {}, 'aggregate_stats.changed not initialized'
    assert aggregate_stats_1.ignored == {}, 'aggregate_stats.ignored not initialized'
    assert aggregate_stats_1.dark == {}, 'aggregate_stats.dark not initialized'

# Generated at 2022-06-24 19:08:10.416381
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()

    # FIXME: non-supported type, testing for a KeyError
    with pytest.raises(KeyError): 
        aggregate_stats_0.decrement('failures', 'host')


# Generated at 2022-06-24 19:08:17.023870
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats("status", "pass", None)
    assert aggregate_stats.custom["_run"] == {"status": "pass"}

# Generated at 2022-06-24 19:08:20.961967
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    host = 'test'
    what = 'processed'
    aggregate_stats.decrement(what, host)

    assert aggregate_stats.processed[host] == 0


# Generated at 2022-06-24 19:08:24.757544
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    try:
        aggregate_stats_0.decrement(arg0=None, arg1=None)
    except AttributeError:
        # This should never happen, but let's be safe
        raise


# Generated at 2022-06-24 19:08:29.533820
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()

    result = aggregate_stats_1.update_custom_stats(None, None, None)


# Generated at 2022-06-24 19:08:34.879682
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats("custom_stats_key1", "custom_stats_value1")
    assert "custom_stats_key1" in aggregate_stats.custom['_run']
    assert aggregate_stats.custom['_run']['custom_stats_key1'] == 'custom_stats_value1'


# Generated at 2022-06-24 19:08:37.026808
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    new_AggregateStats = AggregateStats()
    new_AggregateStats.decrement('custom', 'custom')
    assert new_AggregateStats.custom == {}



# Generated at 2022-06-24 19:08:42.628475
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    host = 'localhost'
    what = 'ok'

    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.ok['localhost'] = 2

    aggregate_stats_1.decrement(what, host)
    assert aggregate_stats_1.ok['localhost'] == 1



# Generated at 2022-06-24 19:08:45.556959
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    assert aggregate_stats_0.decrement('skipped', 'localhost') == None


# Generated at 2022-06-24 19:08:47.076468
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement('ok', 'host')


# Generated at 2022-06-24 19:08:48.750229
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement('ok', 'host')

# Generated at 2022-06-24 19:08:57.346788
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    # Test with not enough arguments
    try:
        aggregate_stats.update_custom_stats()
    except TypeError:
        pass
    # Test with enough arguments
    aggregate_stats.update_custom_stats('which', 'what')


# Generated at 2022-06-24 19:09:03.228693
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('_run', '_run', '_run')
    # Operations with incompatible types "MutableMapping" and "NoneType" are not supported
    aggregate_stats_0.update_custom_stats('_run', '_run', '_run')
    aggregate_stats_0.update_custom_stats('_run', '_run')
    aggregate_stats_0.update_custom_stats('_run', '_run')
    aggregate_stats_0.update_custom_stats('_run', '_run')

test_case_0()
test_AggregateStats_update_custom_stats()

# Generated at 2022-06-24 19:09:11.997149
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Test case data
    aggregate_stats_1 = AggregateStats()
    host = "localhost"
    what = "dark"

    # Perform the test
    aggregate_stats_1.decrement(what, host)

    # Performing post-test check
    #check that decrement took place
    assert(aggregate_stats_1.dark[host] == -1)

    #check that decrement takes place even when there is no dark dictionary
    aggregate_stats_1.dark.pop(host)
    aggregate_stats_1.decrement(what, host)
    assert(aggregate_stats_1.dark[host] == -1)

    #check that decrement does not take place for invalid decrement

# Generated at 2022-06-24 19:09:17.270271
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('_what', '_when')
    assert aggregate_stats_0.custom['_run']['_what'] == '_when'


# Generated at 2022-06-24 19:09:26.292743
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    hosts = ['host1', 'host2', 'host3']
    stats = ['ok', 'failures', 'changed', 'unreachable', 'ignored', 'skipped', 'rescued']

    aggregate_stats = AggregateStats()

    for host in hosts:
        for stat in stats:
            for i in range(10):
                aggregate_stats.increment(stat, host)

    for host in hosts:
        for stat in stats:
            for i in range(10):
                aggregate_stats.decrement(stat, host)

    for host in hosts:
        assert aggregate_stats.ok.get(host) == 0
        assert aggregate_stats.failures.get(host) == 0
        assert aggregate_stats.changed.get(host) == 0

# Generated at 2022-06-24 19:09:28.996016
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
   aggregate_stats_0 = AggregateStats()
   aggregate_stats_0.decrement(what="_what", host="host")
   assert aggregate_stats_0.ok == {'host': 0}


# Generated at 2022-06-24 19:09:36.786543
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.ok = {'test_host': 1}
    assert aggregate_stats_1.ok['test_host'] == 1
    aggregate_stats_1.decrement('ok', 'test_host')
    aggregate_stats_1.decrement('ok', 'test_host')
    aggregate_stats_1.decrement('ok', 'test_host')
    assert aggregate_stats_1.ok['test_host'] == 0

test_case_0()
test_AggregateStats_decrement()

# Generated at 2022-06-24 19:09:41.249475
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.ok = {"test_host1":1}
    aggregate_stats.decrement("ok", "test_host1")
    assert aggregate_stats.ok["test_host1"] == 0


# Generated at 2022-06-24 19:09:50.730371
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_2 = AggregateStats()
    aggregate_stats_3 = AggregateStats()
    aggregate_stats_1.decrement("ok", "localhost")
    aggregate_stats_2.decrement("ok", "localhost")
    aggregate_stats_3.decrement("ok", "localhost")
    aggregate_stats_1.decrement("ok", "localhost")
    aggregate_stats_2.decrement("ok", "localhost")
    aggregate_stats_3.decrement("ok", "localhost")
    aggregate_stats_1.decrement("ok", "localhost")
    aggregate_stats_2.decrement("ok", "localhost")
    aggregate_stats_3.decrement("ok", "localhost")
    aggregate_stats_1.decrement

# Generated at 2022-06-24 19:09:55.243096
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    host_0 = ""
    host_1 = ""
    host_2 = ""
    aggregate_stats_1.ok[host_0] = 1
    aggregate_stats_1.decrement("ok", host_0)
    aggregate_stats_1.decrement("ok", host_1)
    aggregate_stats_1.decrement("ok", host_2)


# Generated at 2022-06-24 19:10:01.501203
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats("foo", {"bar": 1, "baz": 2})
    assert stats.custom == {'_run': {"foo": {"bar": 1, "baz": 2}}}
    stats.update_custom_stats("foo", {"baz": 3, "qux": 4})
    assert stats.custom == {'_run': {"foo": {"bar": 1, "baz": 3, "qux": 4}}}


# Generated at 2022-06-24 19:10:03.515398
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()

# Generated at 2022-06-24 19:10:07.760600
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("ok", "ok_0")


# Generated at 2022-06-24 19:10:10.783777
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("ok", "hostA")
    aggregate_stats_0.decrement("ok", "hostA")
    aggregate_stats_0.decrement("ok", "hostA")
    aggregate_stats_0.decrement("ok", "hostA")
    assert aggregate_stats_0.ok["hostA"] == 0


# Generated at 2022-06-24 19:10:18.733927
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    test_stats = {
        'changed': 1,
        'skipped': 1,
        'rescued': 1,
        'ignored': 1,
        'failures': 1,
        'ok': 1,
        'processed': 3
    }
    aggregate_stats.update_custom_stats('test_update_custom_stats', test_stats)
    # each host should have one count for each
    assert aggregate_stats.custom == {'_run': {'test_update_custom_stats': test_stats}}


# Generated at 2022-06-24 19:10:21.564810
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement('failures', 'localhost')
    assert aggregate_stats.failures.get('localhost', 0) == 0


# Generated at 2022-06-24 19:10:31.001605
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement('failures', 'foo')
    aggregate_stats_1.decrement('ok', 'foo')
    aggregate_stats_1.decrement('dark', 'foo')
    aggregate_stats_1.decrement('changed', 'foo')
    aggregate_stats_1.decrement('skipped', 'foo')
    aggregate_stats_1.decrement('rescued', 'foo')
    aggregate_stats_1.decrement('ignored', 'foo')


# Generated at 2022-06-24 19:10:34.699296
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_1 = AggregateStats()
    host_0 = ""
    what_0 = "ok"
    aggregate_stats_1.decrement(what_0, host_0)


# Generated at 2022-06-24 19:10:42.136797
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_8 = AggregateStats()

    aggregate_stats_8.processed = {
        'host': 1
    }
    aggregate_stats_8.failures = {
        'host': 1
    }
    aggregate_stats_8.ok = {
        'host': 0
    }
    aggregate_stats_8.dark = {
        'host': 0
    }
    aggregate_stats_8.changed = {
        'host': 0
    }
    aggregate_stats_8.skipped = {
        'host': 0
    }
    aggregate_stats_8.rescued = {
        'host': 0
    }
    aggregate_stats_8.ignored = {
        'host': 0
    }

    aggregate_stats_8.decrement('failures', 'host')

    assert aggregate

# Generated at 2022-06-24 19:10:44.928733
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats('b', 4)
    assert aggregate_stats.custom['_run']['b'] == 4


# Generated at 2022-06-24 19:10:47.760652
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('what', 'host')


# Generated at 2022-06-24 19:10:53.585492
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    # getattr(self, what)
    what_0 = ['ok', 'failures', 'dark', 'changed', 'skipped', 'rescued', 'ignored']
    for what_1 in what_0:
        # getattr(self, what)
        what_2 = what_1
        # getattr(self, what)
        what_3 = what_2
        # getattr(self, what)
        what_4 = what_3
        # getattr(self, what)
        what_5 = what_4
        # getattr(self, what)
        what_6 = what_5
        # getattr(self, what)
        what_7 = what_6
        # getattr(self, what)
        what_8 = what_7
       

# Generated at 2022-06-24 19:10:58.003339
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    try:
        aggregate_stats_0.decrement('failures', 'TEST')
    except Exception as e:
        print("Error while calling method 'decrement' of class 'AggregateStats': " + str(e))


# Generated at 2022-06-24 19:11:05.568486
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement("failures", "192.168.56.13")
    aggregate_stats_1.decrement("ok", "192.168.56.13")
    aggregate_stats_1.decrement("skipped", "192.168.56.13")
    aggregate_stats_1.decrement("dark", "192.168.56.13")
    aggregate_stats_1.decrement("changed", "192.168.56.13")
    aggregate_stats_1.decrement("rescued", "192.168.56.13")
    aggregate_stats_1.decrement("ignored", "192.168.56.13")
    

# Generated at 2022-06-24 19:11:09.978376
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("ok", "test_decrement_host")
    aggregate_stats_0.decrement("ok", "test_decrement_host")
    aggregate_stats_0.decrement("ok", "test_decrement_host")
    aggregate_stats_0.decrement("ok", "test_decrement_host")
    aggregate_stats_0.decrement("ok", "test_decrement_host")


# Generated at 2022-06-24 19:11:11.556752
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('what', 'host')


# Generated at 2022-06-24 19:11:17.520320
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement('rescued','host')
    aggregate_stats_1.decrement('skipped','host')
    assert aggregate_stats_1.rescued['host'] == 0
    aggregate_stats_1.decrement('ok','host')
    assert aggregate_stats_1.ok['host'] == 0
    aggregate_stats_1.decrement('failures','host')
    assert aggregate_stats_1.failures['host'] == 0
    aggregate_stats_1.decrement('dark','host')
    assert aggregate_stats_1.dark['host'] == 0
    aggregate_stats_1.decrement('changed','host')
    assert aggregate_stats_1.changed['host'] == 0
    aggregate_stats_1.decre

# Generated at 2022-06-24 19:11:18.395477
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()


# Generated at 2022-06-24 19:11:21.906794
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement(what = 'ok', host = 'localhost')


# Generated at 2022-06-24 19:11:23.447956
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("changed", "host")


# Generated at 2022-06-24 19:11:26.844002
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test_case_0()

# Generated at 2022-06-24 19:11:34.094292
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Test when no KeyError is raised
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement('ok', 'foo')
    assert aggregate_stats_1.ok['foo'] == 0
    aggregate_stats_1.decrement('ok', 'foo')

    # Test when KeyError is raised
    aggregate_stats_2 = AggregateStats()
    aggregate_stats_2.decrement('ok', 'bar')

    # Test when _what[host] - 1 < 0
    aggregate_stats_3 = AggregateStats()
    aggregate_stats_3.ok['foo'] = 0
    aggregate_stats_3.decrement('ok', 'foo')
    assert aggregate_stats_3.ok['foo'] == 0

# Generated at 2022-06-24 19:11:42.589313
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement(what = 'ok', host = 'localhost')
    aggregate_stats_1.decrement(what = 'changed', host = 'localhost')
    aggregate_stats_1.decrement(what = 'failures', host = 'localhost')
    aggregate_stats_1.decrement(what = 'ok', host = 'localhost')
    aggregate_stats_1.decrement(what = 'ok', host = 'localhost')
    aggregate_stats_1.decrement(what = 'rescued', host = 'localhost')
    aggregate_stats_1.decrement(what = 'ok', host = 'localhost')
    aggregate_stats_1.decrement(what = 'changed', host = 'localhost')
    aggregate_stats_1.dec

# Generated at 2022-06-24 19:11:44.608528
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("ok", "_run")
    assert aggregate_stats_0.ok["_run"] == 0

# Generated at 2022-06-24 19:11:49.251470
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test_case_0()
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("failures","server1")
    assert True

# Test case descriptions

# Generated at 2022-06-24 19:11:55.816607
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    # Create a temporary AggregateStats object
    ag1 = AggregateStats()

    # Place some data
    ag1.increment('failures', "Test1")

    # Test forcing a KeyError
    try:
        ag1.decrement("failures", "KeyError")
    except KeyError:
        assert True
    else:
        assert False

    # Test object data
    assert ag1.failures["Test1"] == 1

    # Test decrementing a value which is zero
    assert ag1.ignored["Test1"] == 0
    ag1.decrement("ignored", "Test1")
    assert ag1.ignored["Test1"] == 0



# Generated at 2022-06-24 19:12:00.022548
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    try:
        aggregate_stats_0.decrement('rescued','dark')
    except KeyError:
        assert True

    try:
        aggregate_stats_0.decrement('rescued','dark')
    except KeyError:
        assert True


# Generated at 2022-06-24 19:12:06.932891
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    descr = "Decrement the number of failed hosts"
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.increment("failures", "localhost")
    assert aggregate_stats_0.failures.get("localhost") == 1
    aggregate_stats_0.decrement("failures", "localhost")
    assert aggregate_stats_0.failures.get("localhost") == 0

# Generated at 2022-06-24 19:12:10.801707
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg = AggregateStats()
    agg.decrement('ignored', 'test_host')
    agg.decrement('ignored', 'test_host')
    assert agg.ignored['test_host'] == 0

# Generated at 2022-06-24 19:12:12.896000
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement('ok', 'host1')
