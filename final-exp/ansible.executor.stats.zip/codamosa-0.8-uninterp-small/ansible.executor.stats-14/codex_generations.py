

# Generated at 2022-06-24 19:07:22.635517
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    if not isinstance(aggregate_stats_1, AggregateStats):
        raise AssertionError('Failed to initialise AggregateStats')
    aggregate_stats_1.decrement('ok', 'example1')
    ok_1 = aggregate_stats_1.ok
    if not ok_1.has_key('example1') and ok_1['example1'] != 0:
        raise AssertionError('Failed to decrement counter')
    aggregate_stats_1.decrement('ok', 'example1')
    ok_2 = aggregate_stats_1.ok
    if not ok_2.has_key('example1') and ok_2['example1'] != 0:
        raise AssertionError('Failed to decrement counter')



# Generated at 2022-06-24 19:07:27.803953
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.increment('ok', 'fake_host')
    aggregate_stats_1.increment('ok', 'fake_host')
    aggregate_stats_1.increment('ok', 'fake_host')
    aggregate_stats_1.increment('failures', 'fake_host')



# Generated at 2022-06-24 19:07:37.466156
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("changed", "fake_hostname")
    assert aggregate_stats_0.changed["fake_hostname"] == 0

    aggregate_stats_0.decrement("rescued", "fake_hostname")
    assert aggregate_stats_0.rescued["fake_hostname"] == 0

    aggregate_stats_0.rescued["fake_hostname"] = 2
    aggregate_stats_0.decrement("rescued", "fake_hostname")
    assert aggregate_stats_0.rescued["fake_hostname"] == 1

    aggregate_stats_0.rescued["fake_hostname"] = 1
    aggregate_stats_0.decrement("rescued", "fake_hostname")
    assert aggregate_stats

# Generated at 2022-06-24 19:07:39.866623
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("what", "host")


# Generated at 2022-06-24 19:07:47.095273
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.increment('d', 'host1')
    assert aggregate_stats_0.processed['host1'] == 1



# Generated at 2022-06-24 19:07:52.026281
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    x = {}
    aggregate_stats.update_custom_stats("Failures", x)

if __name__ == '__main__':
    # test_case_0()
    test_AggregateStats_update_custom_stats()

# Generated at 2022-06-24 19:07:58.034938
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    for i in range(0, 6):
        aggregate_stats_0 = AggregateStats()
        aggregate_stats_0.failures['host'] = 2
        aggregate_stats_0.decrement('failures', 'host')
        assert aggregate_stats_0.failures['host'] == 1


# Generated at 2022-06-24 19:08:00.295691
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()

    host = "lowercase"
    what = "ok"
    assert aggregate_stats_0.decrement(what, host) == None


# Generated at 2022-06-24 19:08:01.374165
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
  """
  AggregateStats.decrement(what, host)
  """
  pass


# Generated at 2022-06-24 19:08:06.464377
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('what', 'host')
    return aggregate_stats_0

if __name__ == "__main__":
    test_case_0()
    test_AggregateStats_decrement()

# Generated at 2022-06-24 19:08:10.107092
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_3 = AggregateStats()
    assert aggregate_stats_3.decrement("ok", "host") is None


# Generated at 2022-06-24 19:08:13.289876
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    host = 'localhost'
    what = 'changed'
    aggregate_stats_0.decrement(what, host)


# Generated at 2022-06-24 19:08:24.676052
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats()
    aggregate_stats_0.update_custom_stats(which='ok')
    aggregate_stats_0.update_custom_stats(which='ok', what=0)
    aggregate_stats_0.update_custom_stats(which='ok', what=0, host='localhost')
    aggregate_stats_0.update_custom_stats(which='ok', what=1, host='localhost')

    # Set what to default value of 1 and host to default value of 'localhost'
    aggregate_stats_0.update_custom_stats('ok')
    aggregate_stats_0.update_custom_stats('stat')
    aggregate_stats_0.update_custom_stats('stat', what=1)

    # Set host to default value of 'localhost

# Generated at 2022-06-24 19:08:30.426855
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_2 = AggregateStats()
    try:
        result = aggregate_stats_2.decrement("ok", "localhost")
    except KeyError as error:
        print(error)


# Generated at 2022-06-24 19:08:36.686666
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    """
    Class: AggregateStats
    Method: decrement
    """
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_2 = AggregateStats()
    aggregate_stats_3 = AggregateStats()
    aggregate_stats_4 = AggregateStats()
    aggregate_stats_5 = AggregateStats()
    aggregate_stats_6 = AggregateStats()
    aggregate_stats_7 = AggregateStats()
    aggregate_stats_8 = AggregateStats()
    aggregate_stats_9 = AggregateStats()
    aggregate_stats_10 = AggregateStats()
    aggregate_stats_11 = AggregateStats()
    aggregate_stats_12 = AggregateStats()
    aggregate_stats_13 = AggregateStats()
    aggregate_stats_14 = AggregateStats()
    aggregate_stats_15 = AggregateStats()



# Generated at 2022-06-24 19:08:39.043478
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_obj = AggregateStats()
    aggregate_stats_obj.decrement("ok", "test_host")


# Generated at 2022-06-24 19:08:48.953907
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats("changed", 1, host='127.0.0.1')
    aggregate_stats_0.update_custom_stats("failed", 1, host='192.168.0.1')
    aggregate_stats_0.update_custom_stats("ok", 1, host='192.168.2.1')

    if ({'127.0.0.1': {'changed': 1}, '192.168.0.1': {'failed': 1}, '192.168.2.1': {'ok': 1}} == aggregate_stats_0.custom):
        print('Success!  The stats have been updated for custom variables.')
    else:
        print('Failed to update the stats for custom variables.')



# Generated at 2022-06-24 19:08:52.661362
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Setup
    aggregate_stats_1 = AggregateStats()
    which_1 = "foo"
    what_1 = "bar"
    host_1 = None

    # Execution
    aggregate_stats_1.update_custom_stats(which_1, what_1, host_1)

    # Verification
    assert aggregate_stats_1.custom[host_1][which_1] == what_1



# Generated at 2022-06-24 19:09:00.810276
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.custom_stats = {'test_dict': {}, 'test_list': [], 'test_var': None}
    aggregate_stats_0.update_custom_stats('test_dict', {'test_key': 'test_value'})
    aggregate_stats_0.update_custom_stats('test_list', ['test_value'])
    aggregate_stats_0.update_custom_stats('test_var', 'test_value')

# Generated at 2022-06-24 19:09:05.867444
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('ok', 'host_0')
    assert aggregate_stats_0.ok['host_0'] == 0


# Generated at 2022-06-24 19:09:20.265434
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.custom == {}
    aggregate_stats.update_custom_stats('insertions', 1)
    assert aggregate_stats.custom == {'_run': {'insertions': 1}}
    aggregate_stats.update_custom_stats('deletions', 1)
    assert aggregate_stats.custom == {'_run': {'insertions': 1, 'deletions': 1}}
    aggregate_stats.update_custom_stats('insertions', 1)
    assert aggregate_stats.custom == {'_run': {'insertions': 2, 'deletions': 1}}
    aggregate_stats.update_custom_stats('deletions', 10)
    assert aggregate_stats.custom == {'_run': {'insertions': 2, 'deletions': 11}}

    # Mism

# Generated at 2022-06-24 19:09:22.929760
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement('failures', 'localhost')
    if False:
        assert(aggregate_stats_1.failures == {'localhost': -1})


# Generated at 2022-06-24 19:09:28.074926
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    # Testing if update_custom_stats method works correctly
    aggregate_stats_0.update_custom_stats('foo', 3, 'bar')
    aggregate_stats_0.update_custom_stats('foo', 2, 'bar')
    assert aggregate_stats_0.custom['bar']['foo'] == 5


# Generated at 2022-06-24 19:09:32.999062
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('ok', 'test success')

# Generated at 2022-06-24 19:09:37.480627
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    host_0 = 'www.notreal.org'
    what_0 = 'ok'
    aggregate_stats_0.decrement(what_0, host_0)
    host_1 = 'www.valid.org'
    what_1 = 'ok'
    aggregate_stats_0.decrement(what_1, host_1)

if __name__ == '__main__':
    test_case_0()
    test_AggregateStats_decrement()

# Generated at 2022-06-24 19:09:43.661841
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    what_0 = "dark"
    host_0 = "myhost"
    try:
        aggregate_stats_0.decrement(what_0, host_0)
    except KeyError:
        return 0
    else:
        raise AssertionError("The KeyError exception was not raised.")


# Generated at 2022-06-24 19:09:53.359685
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    host = None

    aggregate_stats_bool = aggregate_stats.update_custom_stats("custom_stats", True, host)
    assert aggregate_stats_bool == None

    aggregate_stats_float = aggregate_stats.update_custom_stats("custom_stats_float", 2.0, host)
    assert aggregate_stats_float == None

    aggregate_stats_dict = aggregate_stats.update_custom_stats("custom_stats_dict", {"temp":2}, host)
    assert aggregate_stats_dict == None

    aggregate_stats_dict_2 = aggregate_stats.update_custom_stats("custom_stats_dict_2", {"temp":2}, host)
    assert aggregate_stats_dict_2 == None

    aggregate_stats_dict_2_AGAIN = aggregate_stats.update_custom_

# Generated at 2022-06-24 19:09:55.494096
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('', 'test_string') # TODO: Improve test coverage


# Generated at 2022-06-24 19:09:59.298553
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    what, host = 'ok', 'testhost01'
    aggregate_stats_1.increment(what, host)
    aggregate_stats_1.decrement(what, host)
    assert aggregate_stats_1.ok[host] == 0


# Generated at 2022-06-24 19:10:02.973410
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    # setup
    aggregate_stats = AggregateStats()
    aggregate_stats.custom = {'host': {'a': 1}}

    # exercise
    aggregate_stats.update_custom_stats('a', {'b': 2})

    # verify
    assert aggregate_stats.custom == {'host': {'a': {'b': 2}}}


# Generated at 2022-06-24 19:10:08.381522
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
   aggregate_stats_0 = AggregateStats()
   aggregate_stats_0.decrement("failures", "host1")
   assert(aggregate_stats_0.failures["host1"] == 0)


# Generated at 2022-06-24 19:10:11.423409
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats("changed", 'ok', '_run')


if __name__ == '__main__':
    test_case_0()
    test_AggregateStats_update_custom_stats()

# Generated at 2022-06-24 19:10:17.414957
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats('c', {'a': 1, 'b': 2}, 'host1')
    assert aggregate_stats_1.custom == {'host1': {'c': {'a': 1, 'b': 2}}}
    aggregate_stats_1.update_custom_stats('c', {'a': 3, 'b': 4})
    assert aggregate_stats_1.custom == {'host1': {'c': {'a': 1, 'b': 2}},
                                        '_run': {'c': {'a': 3, 'b': 4}}}
    aggregate_stats_1.update_custom_stats('c', {'a': 5, 'b': 6}, 'host1')

# Generated at 2022-06-24 19:10:22.614488
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()

    assert getattr(aggregate_stats_0, 'custom', '_run' not in aggregate_stats_0.custom)
    aggregate_stats_0.update_custom_stats('mocked', 'mocked')
    assert getattr(aggregate_stats_0, 'custom', '_run' in aggregate_stats_0.custom)


# Generated at 2022-06-24 19:10:29.613866
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    Stats_dict = {0:{'ignored':1}}
    aggregate_stats_0.__dict__.update(Stats_dict)

    aggregate_stats_0.decrement('ignored', 0)
    expected = {0:{'ignored':0}}
    assert aggregate_stats_0.__dict__ == expected


# Generated at 2022-06-24 19:10:31.090594
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    """
    Test decrement
    """
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('what', 'host')


# Generated at 2022-06-24 19:10:33.412634
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("ok", "testhost1")
    assert aggregate_stats_0.ok["testhost1"] == 0


# Generated at 2022-06-24 19:10:41.346843
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats(which='_raw_params', what='changed', host=None)

    aggregate_stats_2 = AggregateStats()
    aggregate_stats_2.update_custom_stats(which='_raw_params', what='changed', host=None)

    assert aggregate_stats_1.custom['_run']['_raw_params'] == 'changed'
    assert aggregate_stats_1.custom != aggregate_stats_2.custom


# Generated at 2022-06-24 19:10:45.014947
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    increment_stats_0 = AggregateStats()
    increment_stats_0.increment("changed", "test_host")
    increment_stats_0.increment("changed", "test_host")
    increment_stats_0.increment("changed", "test_host")

    assert increment_stats_0.changed["test_host"] == 3

    increment_stats_0.decrement("changed", "test_host")

    assert increment_stats_0.changed["test_host"] == 2


# Generated at 2022-06-24 19:10:53.833638
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()

    known_hosts = ["foo", "bar", "baz"]

    for host in known_hosts:
        for stat in aggregate_stats_0.__dict__.keys():
            for i in range(5):
                aggregate_stats_0.increment(stat, host)
            for i in range(5):
                aggregate_stats_0.decrement(stat, host)

    for host in known_hosts:
        for stat in aggregate_stats_0.__dict__.keys():
            assert getattr(aggregate_stats_0, stat).get(host) == 0
