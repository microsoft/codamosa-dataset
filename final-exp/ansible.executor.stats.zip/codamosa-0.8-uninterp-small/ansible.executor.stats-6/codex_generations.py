

# Generated at 2022-06-24 19:07:24.022602
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("ok", "all")
    aggregate_stats_0.decrement("changed", "all")
    aggregate_stats_0.decrement("failures", "all")
    aggregate_stats_0.decrement("ok", "all")
    aggregate_stats_0.decrement("failures", "all")
    assert aggregate_stats_0.ok["all"] == 0
    assert aggregate_stats_0.changed["all"] == 0
    assert aggregate_stats_0.failures["all"] == 0
    

# Generated at 2022-06-24 19:07:26.284759
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement('rescued','asv-8-1-1')
    assert aggregate_stats_1.rescued['asv-8-1-1'] == 0


# Generated at 2022-06-24 19:07:29.243194
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    stats_builders_0 = aggregate_stats_1
    stats_builders_1 = stats_builders_0
    stats_builders_1.decrement('skipped', 'foo')
    assert stats_builders_1.skipped['foo'] == 0


# Generated at 2022-06-24 19:07:33.491065
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Setup
    aggregate_stats_0 = AggregateStats()
    what = 'changed'
    host = 'hostname'
    # Teardown

    # Test Code
    result = aggregate_stats_0.decrement(what, host)
    assert(result is None)



# Generated at 2022-06-24 19:07:43.809974
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("ignored", "123")
    assert aggregate_stats_0.custom == {}
    assert aggregate_stats_0.processed == {}
    assert aggregate_stats_0.ok == {}
    assert aggregate_stats_0.ignored == {}
    assert aggregate_stats_0.failures == {}
    assert aggregate_stats_0.changed == {}
    assert aggregate_stats_0.dark == {}
    assert aggregate_stats_0.skipped == {}
    assert aggregate_stats_0.rescued == {}
    aggregate_stats_0.decrement("ignored", "123")
    assert aggregate_stats_0.custom == {}
    assert aggregate_stats_0.processed == {}
    assert aggregate_stats_0.ok == {}


# Generated at 2022-06-24 19:07:45.908805
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()

    aggregate_stats_1.decrement('failures','test')


# Generated at 2022-06-24 19:07:51.612445
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_3 = AggregateStats()
    # If a KeyError occurs then this test will fail
    try:
        aggregate_stats_3.decrement('what', 'host')
    except:
        assert False





# Generated at 2022-06-24 19:07:56.699549
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('skipped', '127.0.0.1')


# Generated at 2022-06-24 19:07:59.729078
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    agg_stat_decrement_1 = aggregate_stats_1.decrement("dark", "example.org")
    assert agg_stat_decrement_1 == 0, 'Unexpected value returned from AggregateStats.decrement("dark", "example.org")'


# Generated at 2022-06-24 19:08:04.748382
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_1 = AggregateStats()

    aggregate_stats_1.increment('ok', '10.10.10.10')

    assert aggregate_stats_1.ok['10.10.10.10'] == 1


# Generated at 2022-06-24 19:08:08.614672
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    as0 = AggregateStats()
    as0.increment('ok', 'host1')
    as0.decrement('ok', 'host1')
    assert as0.ok['host1'] == 0


# Generated at 2022-06-24 19:08:10.532387
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('ok', 'test_host')


# Generated at 2022-06-24 19:08:15.345295
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    param_what = 'ok'
    param_host = 'localhost'
    aggregate_stats_0.decrement(param_what, param_host)
    assert aggregate_stats_0.ok == {'localhost': 0}


# Generated at 2022-06-24 19:08:19.441543
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('ok', 'py-test-host')
    test_stat = aggregate_stats_0.ok.get('py-test-host')
    assert test_stat == 0


# Generated at 2022-06-24 19:08:26.775527
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.processed = {'t1': 1}
    aggregate_stats_1.failures = {'t1': 1}
    aggregate_stats_1.decrement('failures', 't1')
    assert aggregate_stats_1.failures == {'t1': 0}
    aggregate_stats_1.decrement('failures', 't2')
    assert aggregate_stats_1.failures == {'t1': 0}


# Generated at 2022-06-24 19:08:29.253849
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement("ok", "localhost")


# Generated at 2022-06-24 19:08:34.013562
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('failures', 'jupiter')
    aggregate_stats_0.decrement('failures', 'jupiter')
    aggregate_stats_0.decrement('failures', 'jupiter')



# Generated at 2022-06-24 19:08:42.550172
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('dark', 'host')
    assert aggregate_stats_0.dark['host'] == 0
    aggregate_stats_0.processed['host'] = 1
    aggregate_stats_0.dark['host'] = 1
    aggregate_stats_0.decrement('dark', 'host')
    assert aggregate_stats_0.dark['host'] == 0
    aggregate_stats_0.dark['host'] = 1
    aggregate_stats_0.decrement('dark', 'host')
    assert aggregate_stats_0.dark['host'] == 0
    aggregate_stats_0.rescued['host'] = 1
    aggregate_stats_0.decrement('rescued', 'host')

# Generated at 2022-06-24 19:08:46.454707
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()

    try:
        aggregate_stats_0.decrement('dark', 'manager.com')
    except Exception as e:
        assert isinstance(e, KeyError)



# Generated at 2022-06-24 19:08:49.674042
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("changed","localhost")
    aggregate_stats_0.decrement("ok","localhost")
    aggregate_stats_0.decrement("skipped","localhost")
