

# Generated at 2022-06-24 19:07:18.915469
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('test_key_1', 'test_value_1')


# Generated at 2022-06-24 19:07:25.773261
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats("timed", "timed", "host")
    assert aggregate_stats_0.custom == {'host': {'timed': 'timed'}}

    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.set_custom_stats("timed", "timed", "host")
    aggregate_stats_0.update_custom_stats("timed", "timed", "host")
    assert aggregate_stats_0.custom == {'host': {'timed': 'timedtimed'}}

    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.set_custom_stats("timed", {'elapsed': 18}, "host")
    aggregate_stats_0.update_custom_stats

# Generated at 2022-06-24 19:07:27.923577
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement('failures', 'host')


# Generated at 2022-06-24 19:07:32.042565
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    try:
        aggregate_stats_0.decrement("changed", "fake_changed")
    except Exception as e:
        assert type(e) == KeyError


# Generated at 2022-06-24 19:07:33.900009
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('ok', 'localhost')


# Generated at 2022-06-24 19:07:41.490724
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats("foo", {"a": "b", "c": "d"}, "host0")
    stats.update_custom_stats("foo", {"c": "f"}, "host1")
    assert stats.custom == {"host0": {"foo": {"a": "b", "c": "d"}}, "host1": {"foo": {"c": "f"}}}



# Generated at 2022-06-24 19:07:47.309745
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Create an instance of AggregateStats with
    # attribute ok = {'localhost': 1}
    aggregate_stats = AggregateStats()
    aggregate_stats.ok = {'localhost': 1}

    # Call method decrement with
    # what = 'ok', host = 'localhost'
    aggregate_stats.decrement('ok', 'localhost')

    # As per the logic of method decrement,
    # attribute ok should become {'localhost': 0}
    # So, assert the same
    assert aggregate_stats.ok == {'localhost': 0}


# Generated at 2022-06-24 19:07:53.167135
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.ok = {'localhost': 1}
    aggregate_stats.decrement('ok', 'localhost')
    assert aggregate_stats.ok == {'localhost': 0}
    aggregate_stats.decrement('ok', 'notlocalhost')
    assert aggregate_stats.ok == {'localhost': 0, 'notlocalhost': 0}


# Generated at 2022-06-24 19:07:58.370325
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()

    class TestObj:
        def __init__(self, name, age):
            self.name = name
            self.age = age

    test_obj_0 = TestObj('Alan', 26)
    aggregate_stats_1.update_custom_stats('users', test_obj_0, 'localhost')

    assert 'localhost' in aggregate_stats_1.custom
    assert aggregate_stats_1.custom['localhost']['users'].age == 26
    assert aggregate_stats_1.custom['localhost']['users'].name == 'Alan'

# Generated at 2022-06-24 19:07:59.479029
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.increment("ok", "localhost")


# Generated at 2022-06-24 19:08:06.947582
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    # Call method of class AggregateStats with args (test_case_0, test_case_1, test_case_2)
    aggregate_stats_0.update_custom_stats(test_case_0, test_case_1, test_case_2)


# Generated at 2022-06-24 19:08:08.636398
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    result_1 = aggregate_stats_1.decrement('ignored', 'host')
    assert result_1 is None


# Generated at 2022-06-24 19:08:10.530443
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("rescued", "localhost")


# Generated at 2022-06-24 19:08:12.601179
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = test_case_0()
    aggregate_stats.decrement(host, what)


# Generated at 2022-06-24 19:08:18.009217
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg_stats = AggregateStats()
    agg_stats.increment('ok', 'test_host')
    agg_stats.decrement('ok', 'test_host')
    assert agg_stats.ok['test_host'] == 0

test_case_0()
test_AggregateStats_decrement()

# Generated at 2022-06-24 19:08:25.576046
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.set_custom_stats('foo', 'bar')
    aggregate_stats_0.set_custom_stats('baz', 'bat', 'example.com')
    aggregate_stats_0.update_custom_stats('foo', 'bar')
    aggregate_stats_0.update_custom_stats('baz', 'bat', 'example.com')
    aggregate_stats_0.update_custom_stats('baz', 'bat', 'example.com')



# Generated at 2022-06-24 19:08:35.783883
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats("changed", 1, "test_host1")
    aggregate_stats.update_custom_stats("changed", 1, "test_host2")
    aggregate_stats.update_custom_stats("skipped", 2, "test_host3")
    assert aggregate_stats.custom=={"test_host1":{"changed":1},"test_host2":{"changed":1},"test_host3":{"skipped":2}}
    aggregate_stats.update_custom_stats("skipped", 4, "test_host3")
    assert aggregate_stats.custom=={"test_host1":{"changed":1},"test_host2":{"changed":1},"test_host3":{"skipped":6}}


# Generated at 2022-06-24 19:08:40.671542
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test = AggregateStats()
    test.rescued = {'test': 1}
    test.decrement('rescued', 'test')
    assert test.rescued == {'test': 0}
    assert test.dark == {}


# Generated at 2022-06-24 19:08:43.513256
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('failures', 'host1')
    assert aggregate_stats_0.failures['host1'] == -1


# Generated at 2022-06-24 19:08:48.861598
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    test_parameter_0 = 'failures'
    test_parameter_1 = 'test_host_0'
    test_parameter_0 = AggregateStats.decrement(aggregate_stats_0, test_parameter_0, test_parameter_1)
    assert test_parameter_0 == None


# Generated at 2022-06-24 19:08:57.441464
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    aggregate_stats_0 = AggregateStats()

    aggregate_stats_0.decrement('ok', 'local')

    assert aggregate_stats_0.ok['local'] == 0


# Generated at 2022-06-24 19:09:03.071918
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    try:
        aggregate_stats_0 = AggregateStats()
        assert aggregate_stats_0.decrement('ok', 'ok') == None
        assert aggregate_stats_0.decrement('failures', 'failures') == None
    except AttributeError as attributeerror:
        print(str(attributeerror))
        assert False
    except AssertionError as assertionerror:
        print(str(assertionerror))
        assert False
    except TypeError as typeerror:
        print(str(typeerror))
        assert False
    except KeyError as keyerror:
        print(str(keyerror))
        assert False
    return True


# Generated at 2022-06-24 19:09:06.094230
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_test = AggregateStats()
    aggregate_stats_test.decrement("dark", "all")
    assert aggregate_stats_test.dark.get("all") == 0


# Generated at 2022-06-24 19:09:08.651213
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("ok", "localhost")
    assert aggregate_stats_0.ok['localhost'] == 1


# Generated at 2022-06-24 19:09:18.878910
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Create a test instance of AggregateStats
    test_instance = AggregateStats()
    # Create a test argument
    arg = [{'changed': 0, 'ok': 2, 'skipped': 0, 'failed': 0}, {'changed': 0, 'ok': 2, 'skipped': 0, 'failed': 0}]
    # Invoke the method
    returned_value = test_instance.update_custom_stats("_run", arg)
    # Check the value returned
    extra_msg = "; returned value: %s" % returned_value
    assert returned_value is None, "Make sure 'returned_value' is None." + extra_msg
    # Print success message (if verbose)
    if verbose_mode:
        print("Success in test_AggregateStats_update_custom_stats.")


# Generated at 2022-06-24 19:09:26.387139
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("rescued", "localhost")
    aggregate_stats_0.rescued["localhost"] = 0


# Generated at 2022-06-24 19:09:29.080453
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    # Nothing raises here, which we can assume is good.
    aggregate_stats_0.update_custom_stats("arg1", "arg2")


# Generated at 2022-06-24 19:09:31.133471
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_4 = AggregateStats()
    aggregate_stats_4.decrement('ok', '127.0.0.1')


# Generated at 2022-06-24 19:09:33.167771
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats(which='which', what='what')

# Generated at 2022-06-24 19:09:37.713306
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # In this test-case, we cover the branch where there is
    # no host in the given stats.
    # We call decrement with following parameters
    what = 'rescued'
    host = 'test-host-0'

    aggregate_stats = AggregateStats()

    aggregate_stats.decrement(what, host)

    assert aggregate_stats.rescued[host] == 0


# Generated at 2022-06-24 19:09:50.600728
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_2 = AggregateStats()
    aggregate_stats_3 = AggregateStats()
    # failed
    assert aggregate_stats_1.decrement('failures', '123.123.123.123') == None
    assert aggregate_stats_2.decrement('failures', '123.123.123.123') == None
    assert aggregate_stats_3.decrement('failures', '123.123.123.123') == None
    # success
    aggregate_stats_1.increment('failures', '123.123.123.123')
    aggregate_stats_2.increment('failures', '123.123.123.123')
    aggregate_stats_3.increment('failures', '123.123.123.123')
    assert aggregate_stats

# Generated at 2022-06-24 19:09:52.664794
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement('failed', 'some_host')
    assert aggregate_stats.failed["some_host"] == 0


# Generated at 2022-06-24 19:09:54.448166
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('failures', 'h')



# Generated at 2022-06-24 19:09:56.610946
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    b = 'ok'
    host = 'test'
    aggregate_stats_0.decrement(b, host)


# Generated at 2022-06-24 19:09:59.381831
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats("foo", {"bar": "baz"}, "magic_host")
    assert 'foo' in aggregate_stats.custom['magic_host']

# Generated at 2022-06-24 19:10:04.823936
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement('ok', 'localhost')

    # AssertionError: should increment from 0, not decrement to -1
    if aggregate_stats_1.ok['localhost'] < 0:
        raise AssertionError('ok should increment from 0, not decrement to %d' % aggregate_stats_1.ok['localhost'])
    if aggregate_stats_1.ok['localhost'] != 0:
        raise AssertionError('ok should decrement to 0, not %d' % aggregate_stats_1.ok['localhost'])


# Generated at 2022-06-24 19:10:08.373919
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    test_stats = AggregateStats()
    mystat = {'a': 1, 'b': 2}
    mystat2 = {'a': 2, 'b': 4}
    test_stats.set_custom_stats('toto', mystat, 'test')
    test_stats.update_custom_stats('toto', mystat2, 'test')
    assert test_stats.custom['test']['toto'] == {'a': 3, 'b': 6}

# Generated at 2022-06-24 19:10:15.528070
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    new_instance = AggregateStats()
    new_instance.decrement('failures', '127.0.0.1')
    new_instance.decrement('warnings', '127.0.0.1')
    new_instance.decrement('ok', '127.0.0.1')
    new_instance.decrement('dark', '127.0.0.1')
    new_instance.decrement('changed', '127.0.0.1')
    new_instance.decrement('skipped', '127.0.0.1')
    new_instance.decrement('rescued', '127.0.0.1')
    new_instance.decrement('ignored', '127.0.0.1')

# Generated at 2022-06-24 19:10:19.460371
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('skipped', 'ansible_eth1')
    assert aggregate_stats_0.skipped['ansible_eth1'] == 0


# Generated at 2022-06-24 19:10:21.949801
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('what', 'host')


# Generated at 2022-06-24 19:10:27.745145
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    aggregate_stats_0 = AggregateStats()

    aggregate_stats_0.decrement('ok', 'foo')


# Generated at 2022-06-24 19:10:28.824770
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement('ok', 'I')


# Generated at 2022-06-24 19:10:30.673833
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('ok', 'foo')
    assert aggregate_stats_0.ok == {'foo': 0}


# Generated at 2022-06-24 19:10:40.991832
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    print("\nIn " + __file__)

    # initialize an instance of AggregateStats
    aggregate_stats = AggregateStats()

    # initialize a host
    host = "localhost"

    # initialize a statistic to decrement
    statistic = "ok"

    # call the method to decrement statistic
    aggregate_stats.decrement(statistic, host)

    # verify the statistic was decremented
    assert aggregate_stats.ok.get(host) == -1

    # increment the statistic back to zero
    aggregate_stats.increment(statistic, host)

    # verify the statistic is zero
    assert aggregate_stats.ok.get(host) == 0

    # decrement the statistic and verify it is -1
    aggregate_stats.increment(statistic, host)
    aggregate_stats.decrement(statistic, host)

# Generated at 2022-06-24 19:10:42.571402
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    result = aggregate_stats_1.decrement('failures', 'localhost')
    assert result == None


# Generated at 2022-06-24 19:10:49.248344
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    # Test method for decrement for undefined host
    # Testing if exception is raised
    catch_exception = False
    try:
        aggregate_stats_0.decrement('failures', None)
    except:
        catch_exception = True
    assert catch_exception
    # Test method for decrement for defined host
    aggregate_stats_0.failures['test_host'] = 2
    catch_exception = False
    try:
        aggregate_stats_0.decrement('failures', 'test_host')
    except:
        catch_exception = True
    assert not catch_exception
    assert aggregate_stats_0.failures['test_host'] == 1


# Generated at 2022-06-24 19:10:58.972883
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Init
    test_host = 'test_host'
    test_what = 'rescued'
    aggregate_stats = AggregateStats()
    aggregate_stats.increment(test_what, test_host)

    # Decrement for the first time
    # Positive case
    assert aggregate_stats.decrement(test_what, test_host) == None
    assert aggregate_stats.summarize(test_host)[test_what] == 0

    # Decrement for the second time
    # Negative case
    assert aggregate_stats.decrement(test_what, test_host) == None
    assert aggregate_stats.summarize(test_host)[test_what] == 0


# Generated at 2022-06-24 19:11:03.968035
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    global aggregate_stats_0, global_what
    assert True
    #
    # initialize vars
    #
    
    #
    # try decrementing
    #
    global_what = 'ok'
    aggregate_stats_0.decrement(global_what, '127.0.0.1')


# Generated at 2022-06-24 19:11:05.932167
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('ok', '192.168.0.1')


# Generated at 2022-06-24 19:11:07.700321
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('ok', 'localhost')
