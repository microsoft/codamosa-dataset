

# Generated at 2022-06-24 19:07:20.661993
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.increment('rescued', 'hostname')
    aggregate_stats_1.decrement('rescued', 'hostname')
    aggregate_stats_1.decrement('rescued', 'hostname')
    assert aggregate_stats_1.rescued == {'hostname': 0}



# Generated at 2022-06-24 19:07:26.662413
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0_instance = AggregateStats()
    what = 'processed'
    host = '10.1.2.3'
    aggregate_stats_0_instance.decrement(what, host)


test_AggregateStats_decrement()

# Generated at 2022-06-24 19:07:27.890832
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    assert AggregateStats().update_custom_stats() == None


# Generated at 2022-06-24 19:07:31.375376
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    assert aggregate_stats_0.decrement('changed', '192.0.2.0') == None


# Generated at 2022-06-24 19:07:33.900417
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('skipped', 'foo')
    assert aggregate_stats_0.skipped['foo'] == 0

# Generated at 2022-06-24 19:07:40.443030
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement('ok', 'localhost')
    aggregate_stats_1.decrement('ok', 'localhost')
    assert aggregate_stats_1.ok['localhost'] == 0


# Generated at 2022-06-24 19:07:43.411749
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_2 = AggregateStats()
    what_3 = 'rescued'
    host_3 = 'example'
    aggregate_stats_2.decrement(what_3, host_3)


# Generated at 2022-06-24 19:07:48.632041
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('ok', 'foo.bar.example.com')
    aggregate_stats_0.decrement('ok', 'bar.example.com')
    aggregate_stats_0.decrement('ok', 'bar.example.com')
    assert aggregate_stats_0.ok['foo.bar.example.com'] == 0
    assert aggregate_stats_0.ok['bar.example.com'] == 1



# Generated at 2022-06-24 19:07:51.892681
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.increment(u'ok', 'test')
    assert aggregate_stats_1.ok == {'test': 1}
    aggregate_stats_1.increment(u'ok', 'test')
    assert aggregate_stats_1.ok == {'test': 2}


# Generated at 2022-06-24 19:07:56.379728
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement("decrement", "decrement")


# Generated at 2022-06-24 19:08:03.966874
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    assert aggregate_stats_1.custom == {}
    aggregate_stats_1.update_custom_stats("test", "success", "test")
    assert aggregate_stats_1.custom == {"test": {"test": "success"}}
    aggregate_stats_1.update_custom_stats("test", "good")
    assert aggregate_stats_1.custom == {"test": {"test": "success"}, "_run": {"test": "good"}}
    aggregate_stats_1.update_custom_stats("test", "good")
    assert aggregate_stats_1.custom == {"test": {"test": "success"}, "_run": {"test": "good"}}
    aggregate_stats_1.update_custom_stats("test", "good", None)

# Generated at 2022-06-24 19:08:08.211440
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    host_0 = 'host_0'
    which_0 = 'which_0'
    what_0 = dict()
    aggregate_stats_0.update_custom_stats(which_0, what_0, host_0)
    return aggregate_stats_0.custom[host_0][which_0] == what_0


# Generated at 2022-06-24 19:08:15.067340
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.set_custom_stats('foobar', -1)
    assert aggregate_stats_0.custom == {'_run': {'foobar': -1}}

    # Add a value on an existing key, test that the type is handled properly
    aggregate_stats_0.update_custom_stats('foobar', False)
    assert aggregate_stats_0.custom == {'_run': {'foobar': -1}}

    # Add a value on an existing key, test that the type is handled properly
    aggregate_stats_0.update_custom_stats('foobar', 2)
    assert aggregate_stats_0.custom == {'_run': {'foobar': 1}}

    # add a value on a new key, test that the type is handled properly
    aggregate_stats

# Generated at 2022-06-24 19:08:18.551487
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats("all_hosts","test")
    assert aggregate_stats.custom["_run"]["all_hosts"] == "test"

# Generated at 2022-06-24 19:08:28.732466
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    assert aggregate_stats_0.update_custom_stats(
        'updated_ok',
        'ok'
    ) == None
    assert aggregate_stats_0.update_custom_stats(
        'updated_changed',
        'changed'
    ) == None
    assert aggregate_stats_0.update_custom_stats(
        'passed_summarize',
        {'summarize':
            {
                'ok': 1,
                'failures': 0,
                'unreachable': 0,
                'changed': 0,
                'skipped': 1,
                'rescued': 0,
                'ignored': 0
            }
        }
    ) == None

# Generated at 2022-06-24 19:08:34.303381
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats("test_name", "test_path", "test_host")
    assert aggregate_stats.custom["test_host"]["test_name"] == "test_path"
    assert aggregate_stats.custom["test_host"].get("test_name2") is None


# Generated at 2022-06-24 19:08:45.899471
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
   aggregate_stats_0 = AggregateStats()
   aggregate_stats_0.update_custom_stats("uptime", 667.5357540997362, "10.0.0.137")
   aggregate_stats_0.update_custom_stats("uptime", 667.5357540997362, "10.0.0.137")
   aggregate_stats_0.update_custom_stats("memfree_mb", 5189.197204589844, "10.0.0.137")

# Generated at 2022-06-24 19:08:52.955751
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    stats_dict = {}
    host_0 = 'localhost'
    stats_dict[host_0] = {'ok': 0, 'failures': 0, 'dark': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0, 'custom': {}}
    host_1 = 'dummy'
    stats_dict[host_1] = {'ok': 0, 'failures': 0, 'dark': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0, 'custom': {}}
    host_2 = 'dummy2'

# Generated at 2022-06-24 19:09:01.463049
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats(False, 'foo', 'foo')
    assert aggregate_stats_0.custom['foo'][False] == 'foo'

    aggregate_stats_0.update_custom_stats('bar', True)
    assert aggregate_stats_0.custom['_run']['bar'] is True

    aggregate_stats_0.update_custom_stats('bar', 1, '_run')
    assert aggregate_stats_0.custom['_run']['bar'] == 2



# Generated at 2022-06-24 19:09:11.829231
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats("changed", 1)
    assert_equals(aggregate_stats_0.custom['_run']['changed'], 1)
    aggregate_stats_0.update_custom_stats("changed", 3)
    assert_equals(aggregate_stats_0.custom['_run']['changed'], 4)
    aggregate_stats_0.update_custom_stats("changed", {'foo': 'bar'})
    assert_equals(aggregate_stats_0.custom['_run']['changed'], {'foo': 'bar'})
    aggregate_stats_0.update_custom_stats("changed", {'foo': 'baz'})

# Generated at 2022-06-24 19:09:22.046254
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    # Test 1: int to int
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.set_custom_stats('int_stats', 2, 'host1')
    aggregate_stats_1.update_custom_stats('int_stats', 2, 'host1')
    if aggregate_stats_1.custom['host1']['int_stats'] != 4:
        raise AssertionError("Integer update failed")

    # Test 2: int to string
    aggregate_stats_2 = AggregateStats()
    aggregate_stats_2.set_custom_stats('int_stats', 2, 'host1')
    aggregate_stats_2.update_custom_stats('int_stats', '2', 'host1')
    if aggregate_stats_2.custom['host1']['int_stats'] != 2:
        raise

# Generated at 2022-06-24 19:09:32.493159
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats("apples", "oranges")
    aggregate_stats.update_custom_stats("dogs", "cats")
    aggregate_stats.update_custom_stats("apples", "pears")
    assert isinstance(aggregate_stats.custom["_run"]["apples"], list)
    assert "oranges" in aggregate_stats.custom["_run"]["apples"]
    assert "pears" in aggregate_stats.custom["_run"]["apples"]
    assert aggregate_stats.custom["_run"]["apples"][0] == "oranges"
    assert aggregate_stats.custom["_run"]["apples"][1] == "pears"

# Generated at 2022-06-24 19:09:40.787913
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()

    aggregate_stats_0.set_custom_stats("test_key1", "test_value1", "test_host")
    assert aggregate_stats_0.custom["test_host"]["test_key1"] == "test_value1"

    aggregate_stats_0.update_custom_stats("test_key1", "test_value2", "test_host")
    assert aggregate_stats_0.custom["test_host"]["test_key1"] == "test_value2"

    aggregate_stats_0.set_custom_stats("test_key2", "test_value3", "test_host")
    assert aggregate_stats_0.custom["test_host"]["test_key2"] == "test_value3"

    # Adding a non-existing key to another

# Generated at 2022-06-24 19:09:50.508795
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats("changed", 22)
    print ("TEST 1")
    print (aggregate_stats_0.custom)
    # should be {'_run': {'changed': 22}}
    aggregate_stats_0.update_custom_stats("changed", 12, "192.168.1.1")
    print ("TEST 2")
    print (aggregate_stats_0.custom)
    # should be {'_run': {'changed': 22}, '192.168.1.1': {'changed': 12}}
    aggregate_stats_0.update_custom_stats("changed", 12, "192.168.1.1")
    print ("TEST 3")
    print (aggregate_stats_0.custom)
    # should be {

# Generated at 2022-06-24 19:09:58.947053
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats("numeric", 2.0)
    aggregate_stats_0.update_custom_stats("numeric", 2.0)
    assert aggregate_stats_0.custom['_run']['numeric'] == 4.0
    assert aggregate_stats_0.custom['_run']['numeric'] == aggregate_stats_0.custom['_run'].get('numeric')
    assert '_run' in aggregate_stats_0.custom
    assert aggregate_stats_0.custom['_run']['numeric'] == 4.0
    aggregate_stats_0.update_custom_stats("numeric", 2)
    assert aggregate_stats_0.custom['_run']['numeric'] == 6.0
    aggregate_stats_

# Generated at 2022-06-24 19:10:03.736192
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats(which="module_stderr", what='', host='_run')


# Generated at 2022-06-24 19:10:13.985792
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    '''Answer the question: Is it up to us to ensure that a custom stat
    aggregates meaningfully? If we do not do this, there is a risk that
    a custom stat is a MutableMapping and it's being updated with a
    MutableMapping of a different structure.

    This can work if, and only if, the existing MutableMapping is empty,
    and the new value has the same structure.

    TODO: How should we handle this?
    '''
    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats('custom_stat', {})
    aggregate_stats.update_custom_stats('custom_stat', {'value': 1})
    aggregate_stats.update_custom_stats('custom_stat', {'value': 'two'})

# Generated at 2022-06-24 19:10:19.856773
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    # set_custom_stats:which is of type str
    aggregate_stats.set_custom_stats(which="test_which",what="test_what")
    # update_custom_stats:which is of type str and which_2 is of type str
    aggregate_stats.update_custom_stats(which="test_which_2",what="test_what_2")


# Generated at 2022-06-24 19:10:26.530966
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    a = AggregateStats()
    a.update_custom_stats('key1',
                          {'key2':{'key3': 'val3'},
                           'key4': 'val4'},
                          'host')
    a.update_custom_stats('key1',
                          {'key2':{'key5': 'val5'},
                           'key6': 'val6'},
                          'host')
    assert a.custom['host']['key1'] == {'key2': {'key3': 'val3', 'key5': 'val5'}, 'key4': 'val4', 'key6': 'val6'}

# Generated at 2022-06-24 19:10:28.593271
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    my_obj = AggregateStats()
    my_obj.update_custom_stats(1, 2, '3')
