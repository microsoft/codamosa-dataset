

# Generated at 2022-06-24 19:07:19.249393
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    '''
    Unit test for method decrement of class AggregateStats
    '''
    aggregate_stats_0 = AggregateStats()
    host = 'localhost'
    aggregate_stats_0.decrement('ok', host)
    assert aggregate_stats_0.ok['localhost'] == 0


# Generated at 2022-06-24 19:07:24.084180
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.increment('ok', 'host1')
    assert aggregate_stats_1.ok == {'host1': 1}
    aggregate_stats_1.increment('ok', 'host2')
    assert aggregate_stats_1.ok == {'host1': 1, 'host2': 1}
    aggregate_stats_1.increment('ok', 'host2')
    assert aggregate_stats_1.ok == {'host1': 1, 'host2': 2}


# Generated at 2022-06-24 19:07:29.056041
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    stats = dict(
        ok=aggregate_stats.ok,
        failures=aggregate_stats.failures,
        dark=aggregate_stats.dark,
        changed=aggregate_stats.changed,
        skipped=aggregate_stats.skipped,
        rescued=aggregate_stats.rescued,
        ignored=aggregate_stats.ignored,
    )
    # Test with some fake hosts
    hosts = ["host1", "host2"]
    # First, set some stats to 1
    for host in hosts:
        aggregate_stats.increment("ok", host)

    # Next, decrement these stats
    for host in hosts:
        for name, stat in stats.items():
            aggregate_stats.decrement(name, host)

# Generated at 2022-06-24 19:07:31.720583
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("ignored", "foo")


# Generated at 2022-06-24 19:07:40.727253
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('a', 'a')
    aggregate_stats_0.update_custom_stats('b', 'b', '_run')
    aggregate_stats_0.update_custom_stats('c', {'c': 1})
    aggregate_stats_0.update_custom_stats('d', {'d': 1}, '_run')
    aggregate_stats_0.update_custom_stats('a', 2)
    aggregate_stats_0.update_custom_stats('b', 2, '_run')
    aggregate_stats_0.update_custom_stats('c', {'c': 2})
    aggregate_stats_0.update_custom_stats('d', {'d': 2}, '_run')


# Generated at 2022-06-24 19:07:46.564851
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    print('Test method decrement of class AggregateStats')
    assert isinstance(AggregateStats().decrement('what', 'host'),
                      None)


# Generated at 2022-06-24 19:07:52.817813
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    stats.increment("ok", "hostname")
    assert stats.ok["hostname"] == 1
    stats.increment("ok", "hostname")
    assert stats.ok["hostname"] == 2
    stats.increment("ok", "hostname2")
    assert stats.ok["hostname2"] == 1


# Generated at 2022-06-24 19:07:57.853766
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement(what='ok', host='localhost')
    if 'ok' not in aggregate_stats_1.__dict__:
        raise AssertionError('AggregateStats.decrement missing attribute: ' + 'ok')
    if aggregate_stats_1.ok['localhost'] != 0:
        raise AssertionError('AggregateStats.decrement not decremented: ' + str(aggregate_stats_1.ok['localhost']))


# Generated at 2022-06-24 19:07:58.961576
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_2 = AggregateStats()
    aggregate_stats_2.decrement('changed', 'localhost')


# Generated at 2022-06-24 19:08:08.956554
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('failures', 'host1')
    aggregate_stats.increment('failures', 'host2')
    aggregate_stats.increment('failures', 'host1')
    aggregate_stats.increment('ok', 'host2')
    aggregate_stats.increment('ok', 'host7')
    aggregate_stats.increment('ok', 'host1')
    aggregate_stats.increment('ignored', 'host2')
    assert(aggregate_stats.processed['host1'] == 1)
    assert(aggregate_stats.failures['host1'] == 2)
    assert(aggregate_stats.ok['host1'] == 1)
    assert(aggregate_stats.ok['host2'] == 1)

# Generated at 2022-06-24 19:08:17.744646
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('rescued', 'host')
    assert aggregate_stats_0.rescued['host'] == 0
    aggregate_stats_0.rescued['host'] = 5
    aggregate_stats_0.decrement('rescued', 'host')
    assert aggregate_stats_0.rescued['host'] == 4


# Generated at 2022-06-24 19:08:21.519734
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('_failures', 'host_name_0')


# Generated at 2022-06-24 19:08:32.001331
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement("custom", "host")
    aggregate_stats_1.decrement("dark", "host")
    aggregate_stats_1.decrement("failures", "host")
    aggregate_stats_1.decrement("ignored", "host")
    aggregate_stats_1.decrement("ok", "host")
    aggregate_stats_1.decrement("processed", "host")
    aggregate_stats_1.decrement("rescued", "host")
    aggregate_stats_1.decrement("skipped", "host")
    aggregate_stats_1.decrement("changed", "host")


# Generated at 2022-06-24 19:08:34.509252
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    stats = aggregate_stats_0.decrement(what='ok', host='host')

# Generated at 2022-06-24 19:08:36.655189
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement('ok', 'localhost')
    assert aggregate_stats.ok['localhost'] == 0

# Generated at 2022-06-24 19:08:40.038906
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement("ok", "test_host")


# Generated at 2022-06-24 19:08:45.857398
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('skipped', 'localhost')
    assert aggregate_stats_0.skipped == {'localhost': -1}
    aggregate_stats_0.decrement('skipped', 'localhost')
    assert aggregate_stats_0.skipped == {'localhost': -2}


# Generated at 2022-06-24 19:08:47.652479
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement('failures', 'localhost')
    assert aggregate_stats.failures['localhost'] == 0



# Generated at 2022-06-24 19:08:50.159945
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    host = '127.0.0.1'
    what = 'ok'
    aggregate_stats_1.decrement(what, host)


# Generated at 2022-06-24 19:08:52.037405
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    test_class = []
    for test_i in test_class:
        test_i.decrement("what", "host")


# Generated at 2022-06-24 19:09:03.837055
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('changed', 'dummy_host')
    aggregate_stats_0.decrement('ignored', 'dummy_host')
    aggregate_stats_0.decrement('failures', 'dummy_host')
    aggregate_stats_0.decrement('dark', 'dummy_host')
    aggregate_stats_0.decrement('ok', 'dummy_host')
    aggregate_stats_0.decrement('rescued', 'dummy_host')
    aggregate_stats_0.decrement('processed', 'dummy_host')
    aggregate_stats_0.decrement('skipped', 'dummy_host')


# Generated at 2022-06-24 19:09:09.097771
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # create an instance of AggregateStats
    as0 = AggregateStats()
    # use the example from module utils for 'dark'
    as0.increment('dark', 'example.org')
    ans = as0.dark['example.org']
    assert ans == 1
    as0.increment('dark', 'example.org')
    ans = as0.dark['example.org']
    assert ans == 2
    as0.increment('dark', 'example.org')
    ans = as0.dark['example.org']
    assert ans == 3
    as0.decrement('dark', 'example.org')
    ans = as0.dark['example.org']
    assert ans == 2


# Generated at 2022-06-24 19:09:19.234001
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Test 1: Call method decrement with a valid argument
    aggregate_stats = AggregateStats()

    aggregate_stats.ok['test'] = 1
    aggregate_stats.decrement('ok', 'test')
    if aggregate_stats.ok['test'] != 0:
        raise AssertionError("Expected 0, got %s" % aggregate_stats.ok['test'])

    # Test 2: Call method decrement with a valid argument,
    #         but value is 0 so it should not decrement
    aggregate_stats.ok['test'] = 0
    aggregate_stats.decrement('ok', 'test')
    if aggregate_stats.ok['test'] != 0:
        raise AssertionError("Expected 0, got %s" % aggregate_stats.ok['test'])

    # Test 3: Call method decrement with a invalid

# Generated at 2022-06-24 19:09:30.917375
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    
    #Test Case 0: Decrementing an existing value, should never throw an exception
    aggregate_stats_10 = AggregateStats()
    aggregate_stats_10.increment('ok', 'host1')
    aggregate_stats_10.increment('ok', 'host1')
    aggregate_stats_10.increment('ok', 'host1')

    aggregate_stats_10.decrement('ok', 'host1')

    assert(aggregate_stats_10.ok['host1'] == 2)
    assert(aggregate_stats_10.processed['host1'] == 1)

    #Test Case 1: Decrementing a non-existent value, should never throw an exception
    aggregate_stats_20 = AggregateStats()
    aggregate_stats_20.increment('ok', 'host1')
    aggregate_stats_20.incre

# Generated at 2022-06-24 19:09:38.803566
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    # decrement(self, what, host)
    aggregate_stats_0.decrement('failures', 'somehost')
    assert aggregate_stats_0.ok.get('somehost', 0) == 0
    assert aggregate_stats_0.failures.get('somehost', 0) == 0
    assert aggregate_stats_0.dark.get('somehost', 0) == 0
    assert aggregate_stats_0.changed.get('somehost', 0) == 0
    assert aggregate_stats_0.skipped.get('somehost', 0) == 0
    assert aggregate_stats_0.rescued.get('somehost', 0) == 0
    assert aggregate_stats_0.ignored.get('somehost', 0) == 0

# Generated at 2022-06-24 19:09:42.684487
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    import mock
    aggregate_stats = AggregateStats()
    m_what = mock.Mock()
    aggregate_stats.decrement(m_what, "hostname", "host")


# Generated at 2022-06-24 19:09:46.091462
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    what = "failed"
    host = "127.0.0.1"
    aggregate_stats_1.decrement(what, host)



# Generated at 2022-06-24 19:09:50.823881
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("ok", "ok")
    assert aggregate_stats_0.ok['ok'] == 0
    aggregate_stats_0.decrement("ok", "ok")
    assert aggregate_stats_0.ok['ok'] == 0


# Generated at 2022-06-24 19:09:57.326147
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    host_1 = 'localhost'
    what_1 = 'ok'

    aggregate_stats_1.decrement(what_1, host_1)
    assert aggregate_stats_1.ok.get(host_1, 0) == 0

    aggregate_stats_1.increment(what_1, host_1)
    assert aggregate_stats_1.ok.get(host_1, 0) == 1

    aggregate_stats_1.decrement(what_1, host_1)
    assert aggregate_stats_1.ok.get(host_1, 0) == 0


# Generated at 2022-06-24 19:10:00.404179
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    print("Testing decrement...")
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('dark', '192.168.1.1')
    print(aggregate_stats_0.dark)
