

# Generated at 2022-06-24 19:07:20.406796
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.increment('failures', 'host1')
    assert aggregate_stats_1.failures == {'host1': 1}
    assert aggregate_stats_1.processed == {'host1': 1}
    aggregate_stats_1.increment('failures', 'host1')
    assert aggregate_stats_1.failures == {'host1': 2}


# Generated at 2022-06-24 19:07:26.624806
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Test normal case, decrement count
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('failures', '10.10.0.1')

    assert aggregate_stats_0.failures['10.10.0.1'] == 0


# Generated at 2022-06-24 19:07:28.759224
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_decrement = AggregateStats()
    assert aggregate_stats_decrement.decrement("ok", "aggregate_stats_decrement_host_0") == 0


# Generated at 2022-06-24 19:07:33.360818
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement('ok','ansible.27-33-211-86.eu-central-1.compute.amazonaws.com')
    assert aggregate_stats_1.ok['ansible.27-33-211-86.eu-central-1.compute.amazonaws.com'] == -1
    aggregate_stats_1.decrement('ok','ansible.27-33-211-86.eu-central-1.compute.amazonaws.com')
    assert aggregate_stats_1.ok['ansible.27-33-211-86.eu-central-1.compute.amazonaws.com'] == -2



# Generated at 2022-06-24 19:07:42.477977
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.increment('ok', 'host1')
    assert aggregate_stats_0.ok == {'host1': 1}
    assert aggregate_stats_0.processed == {'host1': 1}
    aggregate_stats_0.increment('ok', 'host2')
    assert aggregate_stats_0.ok == {'host1': 1, 'host2': 1}
    assert aggregate_stats_0.processed == {'host1': 1, 'host2': 1}
    aggregate_stats_0.increment('ok', 'host1')
    assert aggregate_stats_0.ok == {'host1': 2, 'host2': 1}
    assert aggregate_stats_0.processed == {'host1': 1, 'host2': 1}



# Generated at 2022-06-24 19:07:50.232583
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_10 = AggregateStats()
    aggregate_stats_10.decrement("failures", "host")
    assert aggregate_stats_10.failures["host"] == 0
    aggregate_stats_10.decrement("rescued", "host")
    assert aggregate_stats_10.rescued["host"] ==0
    aggregate_stats_10.decrement("changed", "host")
    assert aggregate_stats_10.changed["host"] ==0
    aggregate_stats_10.decrement("ignored", "host")
    assert aggregate_stats_10.ignored["host"] ==0
    aggregate_stats_10.decrement("ok", "host")
    assert aggregate_stats_10.ok["host"] ==0
    aggregate_stats_10.decrement("dark", "host")

# Generated at 2022-06-24 19:08:02.035453
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()

    aggregate_stats_0.decrement("ok", "192.168.0.10")
    aggregate_stats_0.decrement("ok", "192.168.0.10")
    aggregate_stats_0.decrement("ok", "192.168.0.10")
    aggregate_stats_0.decrement("ok", "192.168.0.10")
    aggregate_stats_0.decrement("ok", "192.168.0.10")
    aggregate_stats_0.decrement("ok", "192.168.0.10")
    aggregate_stats_0.decrement("ok", "192.168.0.10")
    aggregate_stats_0.decrement("ok", "192.168.0.10")
    aggregate_

# Generated at 2022-06-24 19:08:05.619416
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('changed', 'ae:db:4a:6b:32:b4')


# Generated at 2022-06-24 19:08:07.244710
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('failures', 'foo.example.com')


# Generated at 2022-06-24 19:08:09.689995
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.increment('failures', 'fakehostname')
    aggregate_stats_0.increment('failures', 'fakehostname')
    aggregate_stats_0.increment('failures', 'fakehostname')


# Generated at 2022-06-24 19:08:24.084870
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('ok', 'ok')
    aggregate_stats_0.decrement('changed', 'changed')
    aggregate_stats_0.decrement('failures', 'failures')
    aggregate_stats_0.decrement('dark', 'dark')
    aggregate_stats_0.decrement('ignored', 'ignored')
    aggregate_stats_0.decrement('skipped', 'skipped')
    aggregate_stats_0.decrement('rescued', 'rescued')
    aggregate_stats_0.decrement('changed', 'changed')
    aggregate_stats_0.decrement('ok', 'ok')
    aggregate_stats_0.decrement('failures', 'failures')
    aggregate_stats_

# Generated at 2022-06-24 19:08:37.251505
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    args_0 = AggregateStats()
    args_0.update_custom_stats('key_0', 'value_0')
    args_0.update_custom_stats('key_0', 'value_0', host='host_1')
    args_0.update_custom_stats('key_0', 'value_0', host='host_2')
    args_0.update_custom_stats('key_2', {'key_0': 'value_0'}, host='host_0')
    args_0.update_custom_stats('key_2', {'key_1': 'value_1'}, host='host_1')
    args_0.update_custom_stats('key_1', 'value_0', host='host_0')

# Generated at 2022-06-24 19:08:40.940928
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("failures", "test_host_0")


# Generated at 2022-06-24 19:08:48.291244
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats("changed", "changed_test", "host_test")
    assert aggregate_stats_0.custom["_run"]["changed"]["changed_test"]["host_test"] == True
    aggregate_stats_0.update_custom_stats("changed", "changed_test", "host_test")
    assert aggregate_stats_0.custom["_run"]["changed"]["changed_test"]["host_test"] == 2


# Generated at 2022-06-24 19:08:49.260595
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    # @todo update this test case
    assert True


# Generated at 2022-06-24 19:08:59.469520
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats(which='c', what=10)
    assert aggregate_stats_1.custom == {'_run': {'c': 10}}
    aggregate_stats_1.update_custom_stats(which='a', what=10)
    assert aggregate_stats_1.custom == {
        '_run': {
            'c': 10,
            'a': 10,
        }
    }
    aggregate_stats_1.update_custom_stats(which='b', what=20, host='h1')
    assert aggregate_stats_1.custom == {
        '_run': {
            'c': 10,
            'a': 10,
        },
        'h1': {
            'b': 20,
        }
    }

# Generated at 2022-06-24 19:09:10.536030
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement(what='ok', host='127.0.0.1')
    assert aggregate_stats.ok == {u'127.0.0.1': 0}
    aggregate_stats.decrement(what='skipped', host='127.0.0.1')
    assert aggregate_stats.skipped == {u'127.0.0.1': 0}
    aggregate_stats.decrement(what='changed', host='127.0.0.1')
    assert aggregate_stats.changed == {u'127.0.0.1': 0}
    aggregate_stats.decrement(what='ignored', host='127.0.0.1')
    assert aggregate_stats.ignored == {u'127.0.0.1': 0}
   

# Generated at 2022-06-24 19:09:19.313212
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # self.failures is a dictionary and can not be decremented
    # self.failures = {}
    test_aggregate_stats = AggregateStats()
    test_aggregate_stats.ok['host1'] = 2
    test_aggregate_stats.decrement('ok', 'host1')
    # Test that decrement actually decrements
    assert test_aggregate_stats.ok['host1'] == 1
    # Test that decrement does not decrement below 0
    test_aggregate_stats.decrement('ok', 'host1')
    assert test_aggregate_stats.ok['host1'] == 0
    # Test that decrement does not throw an error if there is no key
    test_aggregate_stats.decrement('ok', 'host99')

# Generated at 2022-06-24 19:09:30.916585
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats("mrgq_","kghb_","rjaw_")
    aggregate_stats_0.update_custom_stats("gyc_","noqr_","rjaw_")
    aggregate_stats_0.update_custom_stats("cez_","pvyd_","rjaw_")
    aggregate_stats_0.update_custom_stats("zka_","wgws_","rjaw_")
    aggregate_stats_0.update_custom_stats("s_","wpuf_","avwf_")
    aggregate_stats_0.update_custom_stats("h_","mvjq_")

# Generated at 2022-06-24 19:09:35.016039
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    assert aggregate_stats_0.update_custom_stats("changed", "changed", "changed") is None
    assert aggregate_stats_0.custom["_run"]["changed"] == "changed"
    aggregate_stats_0.update_custom_stats("changed", None, "changed")
    assert aggregate_stats_0.custom["_run"]["changed"] == "changed"


# Generated at 2022-06-24 19:09:48.098630
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    test_case_dict = {
        'dark': {'host3': 1},
        'custom': {'host3': {'key': 'value'}},
        'ok': {'host3': 1},
        'changed': {'host3': 1},
        'skipped': {'host3': 1},
        'ignored': {'host3': 1},
        'failures': {'host3': 1},
        'rescued': {'host3': 1},
        'processed': {'host3': 1}
    }
    for key, val in test_case_dict.items():
        setattr(aggregate_stats_0, key, val)

    for key, val in test_case_dict.items():
        aggregate_stats_0.dec

# Generated at 2022-06-24 19:09:55.949427
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_2 = AggregateStats()
    aggregate_stats_3 = AggregateStats()
    aggregate_stats_4 = AggregateStats()

    aggregate_stats_1.update_custom_stats("which", "what", None)
    assert aggregate_stats_1.custom["_run"]["which"] == "what"

    aggregate_stats_2.update_custom_stats("which", "what", "host")
    assert aggregate_stats_2.custom["host"]["which"] == "what"

    aggregate_stats_3.custom["_run"] = {'some_key': "some_value"}
    aggregate_stats_3.update_custom_stats("some_key", "some_value", None)

# Generated at 2022-06-24 19:10:03.918951
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('ignored', 'host_0')
    aggregate_stats_0.decrement('skipped', 'host_0')
    aggregate_stats_0.decrement('ignored', 'host_1')
    aggregate_stats_0.decrement('skipped', 'host_1')
    aggregate_stats_0.decrement('ignored', 'host_2')
    aggregate_stats_0.decrement('skipped', 'host_2')
    aggregate_stats_0.decrement('ignored', 'host_3')
    aggregate_stats_0.decrement('skipped', 'host_3')
    aggregate_stats_0.decrement('ignored', 'host_4')

# Generated at 2022-06-24 19:10:05.604363
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats(None, None, None)
    assert aggregate_stats.custom == {}


# Generated at 2022-06-24 19:10:10.986815
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()

    # Test with what == {'_run': {'parsed': 1}, 'foobar': {'parsed': 1}}
    # and host == _run
    aggregate_stats.decrement('what', '_run')
    assert aggregate_stats.what == {'_run': {'parsed': 0}, 'foobar': {'parsed': 1}}

    # Test with what == {'_run': {'parsed': 1}, 'foobar': {'parsed': 1}}
    # and host == foobar
    aggregate_stats.decrement('what', 'foobar')
    assert aggregate_stats.what == {'_run': {'parsed': 0}, 'foobar': {'parsed': 0}}

    # Test with what == {'_

# Generated at 2022-06-24 19:10:13.222623
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    assert aggregate_stats_0.update_custom_stats("ok", 1, "localhost") == None
# test_AggregateStats_update_custom_stats()


# Generated at 2022-06-24 19:10:15.659594
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats(None, None)


# Generated at 2022-06-24 19:10:18.405682
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0._validate_update_custom_stats()


# Generated at 2022-06-24 19:10:23.439215
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    assert len(aggregate_stats.custom) == 0
    aggregate_stats.update_custom_stats("custom1", "Stufe 2", "host1")
    assert len(aggregate_stats.custom) == 1
    assert len(aggregate_stats.custom["host1"]) == 1
    assert aggregate_stats.custom["host1"]["custom1"] == "Stufe 2"


# Generated at 2022-06-24 19:10:25.335219
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement('skipped', 'localhost')
    aggregate_stats.decrement('skipped', 'localhost')


# Generated at 2022-06-24 19:10:30.268208
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('which', 'what')
    assert aggregate_stats_0.custom['_run']['which'] == 'what'


# Generated at 2022-06-24 19:10:35.174393
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    setattr(aggregate_stats, 'changed', {'host': 1})
    aggregate_stats.decrement('changed', 'host')
    assert aggregate_stats.changed == {'host': 0}
    aggregate_stats.decrement('changed', 'host')
    assert aggregate_stats.changed == {'host': 0}


# Generated at 2022-06-24 19:10:40.479637
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    stats_0 = 'ok'
    host_0 = 'localhost'
    cluster_hosts_0 = ['localhost']
    aggregate_stats_0.processed[host_0] = 1
    getattr(aggregate_stats_0, stats_0)[host_0] = 1
    aggregate_stats_0.decrement(stats_0, host_0)
    assert aggregate_stats_0.ok[host_0] == 0


# Generated at 2022-06-24 19:10:43.109962
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test_case_0()


# Generated at 2022-06-24 19:10:50.193718
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    aggregate_stats_0 = AggregateStats()

# # On Debian and Ubuntu, the default type of /etc/shadow is shadow,
# # and Ansible has a Map type explicit for shadow types, so use it
# # here directly and assume that it works.

# Generated at 2022-06-24 19:10:53.484700
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('what', 'host')



# Generated at 2022-06-24 19:10:57.878663
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    result_0 = aggregate_stats_0.update_custom_stats('ok', 'ok')
    assert result_0 is None
    result_1 = aggregate_stats_0.custom['_run']['ok']
    assert result_1 == 'ok'


# Generated at 2022-06-24 19:11:04.424935
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    what = {"changed": True, "reboot_required": True, "warnings": ["Insecure Pip Installation"]}
    which = 'changed'
    host = '_run'
    custom_stats = {}
    custom_stats[host] = {'warnings': ['Insecure Pip Installation']}
    assert AggregateStats().update_custom_stats(which, what, host) == custom_stats == AggregateStats().custom


# Generated at 2022-06-24 19:11:08.287448
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats("_run", {"parsed": 1, "failed": 0, "changed": 0, "dark": 0, "skipped": 0, "ok": 1, "processed": 1, "ignored": 0, "rescued": 0, "failed_when_result": False})
    print(aggregate_stats.custom)



# Generated at 2022-06-24 19:11:11.251967
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats(0, 0)


# Generated at 2022-06-24 19:11:19.719229
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    my_str = '123'
    my_dict = {'a': 1, 'b': 2, 'c': 3}
    my_list = [1, 2, 3, 4, 5]
    my_tuple = tuple(my_list)

    as_dict = {'a': 1, 'b': 2, 'c': 3}
    as_list = [1, 2, 3, 4, 5]
    as_tuple = tuple(as_list)

    aggregate_stats_1 = AggregateStats()

    aggregate_stats_1.update_custom_stats('metric', my_str, 'host1')
    aggregate_stats_1.update_custom_stats('metric', my_dict, 'host2')
    aggregate_stats_1.update_custom_stats('metric', my_list, 'host3')

# Generated at 2022-06-24 19:11:21.079065
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats("tls-version-min", "tls1_2", "test_case")

# Generated at 2022-06-24 19:11:23.950553
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats("test_key", "test_value")
    if aggregate_stats_1.custom['_run']['test_key'] == 'test_value':
        return True
    else:
        return False



# Generated at 2022-06-24 19:11:30.301223
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('foo', 'bar')

    if not aggregate_stats_0.custom['_run']['foo'] == 'bar':
        raise AssertionError('Failed to update_custom_stats')


# Generated at 2022-06-24 19:11:37.169244
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.set_custom_stats('0', '0')
    aggregate_stats_0.update_custom_stats('0', '0')
    assert aggregate_stats_0.custom['_run']['0'] == '0'


# Generated at 2022-06-24 19:11:41.344826
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    as_ = AggregateStats()
    as_.update_custom_stats('foo', 'bar')
    as_.update_custom_stats('foo', 'baz')
    assert as_.custom['_run']['foo'] == 'baz'

# Generated at 2022-06-24 19:11:44.956697
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.update_custom_stats("testcase0", "") is None


# Generated at 2022-06-24 19:11:46.681426
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Create instance variable
    aggregate_stats_1 = AggregateStats()
    # Call method update_custom_stats
    aggregate_stats_1.update_custom_stats(which='which', what='what', host='host')


# Generated at 2022-06-24 19:11:52.444497
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stat = AggregateStats()
    assert_equal(aggregate_stat.update_custom_stats("which1", "what1", "host1"), None)
    assert_equal(aggregate_stat.update_custom_stats("which2", "what2", "host2"), None)
    assert_equal(aggregate_stat.update_custom_stats("which3", {'toto': 'tata'}, "host3"), None)
    assert_equal(aggregate_stat.update_custom_stats("which3", {'toto': 'tata'}, "host3"), None)
    assert_equal(aggregate_stat.update_custom_stats("which4", {'toto': 'tata'}, "host4"), None)

# Generated at 2022-06-24 19:12:00.660626
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats("foo", "bar")
    assert(aggregate_stats.custom["_run"] == {'foo': 'bar'})
    aggregate_stats.update_custom_stats("foo", "baz")
    assert(aggregate_stats.custom["_run"] == {'foo': 'baz'})


if __name__ == '__main__':
    import sys