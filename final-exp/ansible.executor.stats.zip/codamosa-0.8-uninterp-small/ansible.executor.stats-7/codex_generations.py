

# Generated at 2022-06-24 19:07:22.170830
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement("failures", "1")
    aggregate_stats_1.decrement("dark", "2")
    aggregate_stats_1.decrement("ok", "3")
    aggregate_stats_1.decrement("changed", "4")
    aggregate_stats_1.decrement("skipped", "5")
    aggregate_stats_1.decrement("rescued", "6")
    aggregate_stats_1.decrement("ignored", "7")


# Generated at 2022-06-24 19:07:27.646466
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    print(aggregate_stats_1.decrement('skipped', 'badger'))


# Generated at 2022-06-24 19:07:32.740367
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    
    aggregate_stats_0 = AggregateStats()
    
    aggregate_stats_0.update_custom_stats("ok", 1, None)
    aggregate_stats_0.update_custom_stats("failures", 1, None)
    aggregate_stats_0.update_custom_stats("unreachable", 1, None)
    aggregate_stats_0.update_custom_stats("changed", 1, None)
    aggregate_stats_0.update_custom_stats("skipped", 1, None)
    aggregate_stats_0.update_custom_stats("rescued", 1, None)
    aggregate_stats_0.update_custom_stats("ignored", 1, None)
    
    assert aggregate_stats_0.custom["_run"]["ok"] == 1

# Generated at 2022-06-24 19:07:41.835437
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats('test', 'test')
    assert aggregate_stats_1.custom['_run'] == {'test': 'test'}
    aggregate_stats_1.update_custom_stats('test', 'test')
    assert aggregate_stats_1.custom['_run'] == {'test': 'test'}
    aggregate_stats_1.update_custom_stats('test', 'test')
    assert aggregate_stats_1.custom['_run'] == {'test': 'test'}
    aggregate_stats_1.update_custom_stats('test', 'test')
    assert aggregate_stats_1.custom['_run'] == {'test': 'test'}
    aggregate_stats_1.update_custom_stats('test', 'test')


# Generated at 2022-06-24 19:07:45.422506
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    aggregate_stats_0 = AggregateStats()
    assert aggregate_stats_0 != None

    data = aggregate_stats_0.update_custom_stats(
        which = "pets",
        what = "dog",
        host = None
    )

    assert data == None



# Generated at 2022-06-24 19:07:49.751502
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('dark', 'host')
    host = 'host'
    host_0 = aggregate_stats_0.summarize(host)
    host_0 = host_0['unreachable']
    if (host_0 != 0):
        return 1
    return 0


# Generated at 2022-06-24 19:07:56.907796
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.custom.get('_run',{}).get('test_custom_stats1',0) == 0

    aggregate_stats.update_custom_stats('test_custom_stats1', 30)
    aggregate_stats.update_custom_stats('test_custom_stats1', 20)

    assert aggregate_stats.custom.get('_run',{}).get('test_custom_stats1',0) == 50

    aggregate_stats.update_custom_stats('test_custom_stats2', {'a':10, 'b':20})
    aggregate_stats.update_custom_stats('test_custom_stats2', {'a':20, 'c':30})
    aggregate_stats.update_custom_stats('test_custom_stats2', {'a':30})


# Generated at 2022-06-24 19:07:57.782905
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    assert 1==1
    return


# Generated at 2022-06-24 19:07:59.166155
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("what", "host")


# Generated at 2022-06-24 19:08:09.086419
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.set_custom_stats("foo", "bar")
    aggregate_stats_1.update_custom_stats("foo", "baz")
    assert aggregate_stats_1.custom["_run"]["foo"] == "baz"
    aggregate_stats_1.set_custom_stats("foo", "bar", "host")
    aggregate_stats_1.update_custom_stats("foo", "baz", "host")
    assert aggregate_stats_1.custom["host"]["foo"] == "baz"
    aggregate_stats_1.set_custom_stats("foo", "bar")
    aggregate_stats_1.update_custom_stats("foo", {"baz": 3}, "host")

# Generated at 2022-06-24 19:08:23.418301
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('ok', 'host.example.org')
    aggregate_stats_0.decrement('changed', 'host.example.org')
    aggregate_stats_0.decrement('rescued', 'host.example.org')
    aggregate_stats_0.decrement('ok', 'host.example.org')
    aggregate_stats_0.decrement('ignored', 'host.example.org')
    aggregate_stats_0.decrement('ignored', 'host.example.org')
    aggregate_stats_0.decrement('rescued', 'host.example.org')
    aggregate_stats_0.decrement('changed', 'host.example.org')

# Generated at 2022-06-24 19:08:30.963582
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():

    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.increment('failures', 'localhost')
    aggregate_stats_0.increment('failures', 'localhost')
    aggregate_stats_0.increment('failures', 'localhost2')
    aggregate_stats_0.increment('failures', 'localhost2')

    assert(aggregate_stats_0.failures['localhost'] == 2)
    assert(aggregate_stats_0.failures['localhost2'] == 2)


# Generated at 2022-06-24 19:08:36.861277
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.increment("ok","test_host")
    assert(aggregate_stats_1.ok["test_host"] == 1)
    assert(aggregate_stats_1.processed["test_host"] == 1)
    aggregate_stats_1.increment("ok","test_host")
    assert(aggregate_stats_1.ok["test_host"] == 2)
    assert(aggregate_stats_1.processed["test_host"] == 1)
    aggregate_stats_1.increment("ok","test_host2")
    assert(aggregate_stats_1.ok["test_host2"] == 1)
    assert(aggregate_stats_1.processed["test_host2"] == 1)

# Generated at 2022-06-24 19:08:39.773143
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    res = aggregate_stats_0.decrement('ignored', '_ping_host')
    assert res is None


# Generated at 2022-06-24 19:08:42.252664
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("ok", "foo")


# Generated at 2022-06-24 19:08:51.354737
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_1 = AggregateStats() # Creation of object
    aggregate_stats_1.increment("ok", host="localhost")
    aggregate_stats_1.increment("ok", host="127.0.0.1")
    aggregate_stats_1.increment("failures", host="192.168.1.1")
    assert aggregate_stats_1.ok == {'localhost': 1, '127.0.0.1': 1}, "AggregateStats.increment test failed!"
    assert aggregate_stats_1.failures == {'192.168.1.1': 1}, "AggregateStats.increment test failed!"

# Generated at 2022-06-24 19:08:56.588910
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.dark = {'some_host': 1}
    aggregate_stats_0.decrement('dark', 'some_host')


# Generated at 2022-06-24 19:09:02.201301
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    host_0 = 'some_host'
    what_0 = 'ok'
    aggregate_stats_0.decrement(what_0,host_0)


# Generated at 2022-06-24 19:09:03.242293
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    assert False, "Not Implemented"


# Generated at 2022-06-24 19:09:04.894972
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.decrement('ignored', 'server_0') == None


# Generated at 2022-06-24 19:09:11.080292
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    assert aggregate_stats_0.decrement('ok', 'test_host_1') is None
    assert aggregate_stats_0.decrement('ok', 'test_host_2') is None

# Generated at 2022-06-24 19:09:13.016890
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("ok", "host")


# Generated at 2022-06-24 19:09:16.842918
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement
    aggregate_stats_1.decrement('dark', '127.0.0.1')
    assert aggregate_stats_1.dark.get('127.0.0.1') == 0


# Generated at 2022-06-24 19:09:20.081751
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_2 = AggregateStats()
    setattr(aggregate_stats_2, 'foo', {'bar': 1})
    aggregate_stats_2.decrement('foo', 'bar')
    assert aggregate_stats_2.foo['bar'] == 0


# Generated at 2022-06-24 19:09:23.724897
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('changed', '12')
    assert aggregate_stats_0.changed['12'] == -1


# Generated at 2022-06-24 19:09:29.313114
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()

    # Test with 'ok'
    aggregate_stats_0.decrement("ok", "test")
    assert(aggregate_stats_0.ok['test'] == 0)

    # Test with 'failures'
    aggregate_stats_0.decrement("failures", "test")
    assert(aggregate_stats_0.failures['test'] == 0)


# Generated at 2022-06-24 19:09:33.991775
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    assert aggregate_stats_0.decrement('ok', 'host') == None


# Generated at 2022-06-24 19:09:35.986786
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement(what='ok', host='ok')


# Generated at 2022-06-24 19:09:39.258640
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('what', 'host')


# Generated at 2022-06-24 19:09:48.710160
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('what', 'host')
    aggregate_stats_0.processed['host'] = 1
    aggregate_stats_0.failures['host'] = 1
    aggregate_stats_0.ok['host'] = 1
    aggregate_stats_0.dark['host'] = 1
    aggregate_stats_0.changed['host'] = 1
    aggregate_stats_0.skipped['host'] = 1
    aggregate_stats_0.rescued['host'] = 1
    aggregate_stats_0.ignored['host'] = 1
    aggregate_stats_0.decrement('what', 'host')
