

# Generated at 2022-06-24 19:07:19.672306
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # init the test cases
    aggregate_stats_0 = AggregateStats()
    what_0 = 'ok'
    host_0 = 'lamentable'
    # execute the test
    try:
        aggregate_stats_0.decrement(what_0, host_0)
    except KeyError:
        # non-zero return code
        return 1
    else:
        # zero return code
        return 0
    # error
    return 2


# Generated at 2022-06-24 19:07:25.285042
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    try:
        aggregate_stats_0.decrement("failures", "testhost")
        assert False, "Should throw exception"
    except:
        assert True, "Exception thrown"

    try:
        aggregate_stats_0.failures["testhost"] = 1
        aggregate_stats_0.decrement("failures", "testhost")
        assert aggregate_stats_0.failures["testhost"] == 0
    except:
        assert False, "Exception thrown"

    try:
        aggregate_stats_0.failures["testhost"] = 1
        aggregate_stats_0.decrement("failures", "testhost")
        assert False, "Should throw exception"
    except:
        assert True, "Exception thrown"


# Generated at 2022-06-24 19:07:26.764632
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'all')
    assert aggregate_stats.processed == {'all': 1}
    assert aggregate_stats.ok == {'all': 1}


# Generated at 2022-06-24 19:07:28.414970
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.increment("ok", "host1")



# Generated at 2022-06-24 19:07:34.139475
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    print("Testing decrement")
    aggregate_stats_0.decrement("ok", "127.0.0.1")
    aggregate_stats_0.decrement("ok", "127.0.0.1")
    assert(aggregate_stats_0.ok.get("127.0.0.1","NA") == 0)


# Generated at 2022-06-24 19:07:43.285443
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    assert aggregate_stats_0.custom == {}

    # Test: test_custom_stats_1
    aggregate_stats_0.update_custom_stats(
        'foo',
        'bar')
    expected = {'_run': {'foo': 'bar'}}
    assert aggregate_stats_0.custom == expected

    # Test: test_custom_stats_2
    aggregate_stats_0.update_custom_stats(
        'foo',
        'bar',
        'host1')
    expected = {'_run': {'foo': 'bar'}, 'host1': {'foo': 'bar'}}
    assert aggregate_stats_0.custom == expected

    # Test: test_custom_stats_3

# Generated at 2022-06-24 19:07:45.511108
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("what","host")



# Generated at 2022-06-24 19:07:49.783904
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    which_1 = 'Test String'
    host_1 = 'Test String'
    what_1 = 'Test String'
    expected_1 = None
    actual_1 = aggregate_stats_1.update_custom_stats(which_1, what_1, host_1)
    assert expected_1 == actual_1


# Generated at 2022-06-24 19:07:53.520151
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    what = random.choice(["failures", "ok", "dark", "rescued", "ignored"])
    host = random.choice(["debian-1", "debian-2", "centos-1", "", "ubuntu-1"])
    aggregate_stats_0.decrement(what, host)


# Generated at 2022-06-24 19:07:57.730248
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('usage', 'test')
    assert aggregate_stats_0.custom['_run']['usage'] == 'test'


# Generated at 2022-06-24 19:08:05.343948
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('_run', "u'ok': 55, u'skipped': 21, u'changed': 16, u'failed': 0, u'unreachable': 0", "_run")


# Generated at 2022-06-24 19:08:14.562968
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    assert(isinstance(aggregate_stats.custom, dict))
    aggregate_stats.update_custom_stats("toto", {"titi": "tata"})
    assert(aggregate_stats.custom == {"_run": {"toto": {"titi": "tata"}}})

# Test cases for method update_custom_stats of class AggregateStats
_aggr_0 = AggregateStats()
_aggr_1 = AggregateStats()
_aggr_1.update_custom_stats("toto", {"titi": "tata"})
_aggr_2 = AggregateStats()
_aggr_2.update_custom_stats("toto", {"titi": "tata"})

# Generated at 2022-06-24 19:08:25.835002
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    which_0 = 'foo'
    what_0 = 'bar'
    aggregate_stats_1.update_custom_stats(which_0, what_0)
    assert aggregate_stats_1.custom['_run']['foo'] == 'bar'

    which_1 = 'foo'
    what_1 = 'baz'
    aggregate_stats_2 = AggregateStats()
    aggregate_stats_2.update_custom_stats(which_1, what_1)
    which_2 = 'foo'
    what_2 = 'foobar'
    aggregate_stats_3 = AggregateStats()
    aggregate_stats_3.update_custom_stats(which_2, what_2)

# Generated at 2022-06-24 19:08:33.291588
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    print ('Decrementing the attribute "skipped" for host "localhost"')
    aggregate_stats_0.skipped["localhost"] = 0
    aggregate_stats_0.decrement("skipped","localhost")
    assert aggregate_stats_0.skipped["localhost"] == -1


# Generated at 2022-06-24 19:08:43.892589
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.custom = {
      '_run': {
        'test_var': 7
      }
    }
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats('test_var', 2)
    aggregate_stats_2 = AggregateStats()
    aggregate_stats_2.custom = {
      '_run': {
        'test_var': {
          'test_dict': 7
        }
      }
    }
    aggregate_stats_2.update_custom_stats('test_var', {
      'test_dict': 3
    })
    aggregate_stats_3 = AggregateStats()

# Generated at 2022-06-24 19:08:47.419092
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats is not None
    aggregate_stats.update_custom_stats('ok', 1)
    assert aggregate_stats.custom.get('_run', dict()).get('ok', 0) == 1

# Generated at 2022-06-24 19:08:57.883378
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_obj = AggregateStats()

    which = None
    what = None
    host = None
    assert not aggregate_stats_obj.update_custom_stats(which, what, host)

    which = 'what'
    what = None
    host = None
    assert not aggregate_stats_obj.update_custom_stats(which, what, host)

    which = None
    what = 1
    host = None
    assert not aggregate_stats_obj.update_custom_stats(which, what, host)

    which = None
    what = {'test': 1}
    host = None
    assert not aggregate_stats_obj.update_custom_stats(which, what, host)

    which = 'test'
    what = None
    host = 'test'
    assert not aggregate_stats_obj.update_custom_

# Generated at 2022-06-24 19:09:02.439157
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
   aggregate_stats_1 = AggregateStats()
   aggregate_stats_1.set_custom_stats('foo', 'bar')
   aggregate_stats_1.set_custom_stats('bar', 'baz')
   aggregate_stats_1.update_custom_stats('foo', 'bar')
   aggregate_stats_1.update_custom_stats('bar', 'baz')
   aggregate_stats_1.set_custom_stats('baz', 'foo')
   aggregate_stats_1.update_custom_stats('baz', 'foo')

# Generated at 2022-06-24 19:09:06.922325
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats(which='verbose_override', host='_run', what=1)
    assert aggregate_stats_1.custom['_run']['verbose_override'] == 1



# Generated at 2022-06-24 19:09:14.483384
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    # TypeError when 'what' is not a string, dict, int or list
    with pytest.raises(TypeError):
        aggregate_stats_0.update_custom_stats(None, 1)
    # TypeError when 'what' and self.custom[host][which] have mismatching types
    aggregate_stats_0.custom['string_1'] = 'string_2'
    with pytest.raises(TypeError):
        aggregate_stats_0.update_custom_stats('string_1', 1, 'string_2')
    # ValueError when 'what' and self.custom[host][which] are lists, but they don't contain the same type of element
    aggregate_stats_0.custom['string_2'] = ['string_3', 'string_4']

# Generated at 2022-06-24 19:09:20.190721
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.skipped['my_host'] = 42
    aggregate_stats_1.decrement('skipped', 'my_host')
    assert aggregate_stats_1.skipped['my_host'] == 41


# Generated at 2022-06-24 19:09:21.308840
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()


# Generated at 2022-06-24 19:09:28.622730
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    which_1 = '_all'
    what_1 = 'test-test_AggregateStats_update_custom_stats'
    aggregate_stats_1.update_custom_stats(which_1, what_1)
    custom_1 = aggregate_stats_1.custom
    custom_1_1 = custom_1['_run']
    custom_1_1_1 = custom_1_1['_all']
    assert(custom_1_1_1 == 'test-test_AggregateStats_update_custom_stats')


# Generated at 2022-06-24 19:09:37.956138
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    msg = ": return value  aggregate_stats_0['processed'] = 0"
    assert aggregate_stats_0.processed == {}, msg

    assert aggregate_stats_0.custom == {}, msg
    aggregate_stats_0.set_custom_stats('a', 'A')
    msg = ": return value  aggregate_stats_0['custom'] = 'A'"
    assert aggregate_stats_0.custom['_run']['a'] == 'A', msg

    aggregate_stats_0.set_custom_stats('a', 'B')
    msg = ": return value  aggregate_stats_0['custom'] = 'B'"
    assert aggregate_stats_0.custom['_run']['a'] == 'B', msg

    aggregate_stats_0.update_custom_

# Generated at 2022-06-24 19:09:40.946316
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_2 = AggregateStats()
    aggregate_stats_2.decrement("ok", "127.0.0.1")


# Generated at 2022-06-24 19:09:44.512798
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    assert not aggregate_stats.update_custom_stats("something", 42, "host1")
    assert aggregate_stats.update_custom_stats("something", 42, "host1") is None

# Generated at 2022-06-24 19:09:50.824442
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats("mything","write")
    aggregate_stats_1.update_custom_stats("mything","read")


########################################
# Unit test execution
########################################

if __name__ == "__main__":
    import pytest
    pytest.main([__file__, '-s', '-v'])

# Generated at 2022-06-24 19:09:56.481006
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats(which="test_key_1", what=1, host="test_host_1")
    aggregate_stats_1.update_custom_stats(which="test_key_2", what=1, host="test_host_1")
    aggregate_stats_1.update_custom_stats(which="test_key_2", what=1, host="test_host_2")
    aggregate_stats_1.update_custom_stats(which="test_key_3", what=1, host="test_host_2")

if __name__ == '__main__':
    test_case_0()
    test_AggregateStats_update_custom_stats()

# Generated at 2022-06-24 19:09:59.881760
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.decrement("ok", "foo")
    # getattr does not work for class
    # assert aggregate_stats_1.getattr("ok") == {'foo': 0}


# Generated at 2022-06-24 19:10:04.474766
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('failures', 'test_host')
    aggregate_stats_0.decrement('ok', 'test_host')



# Generated at 2022-06-24 19:10:07.948879
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement(u'ok', u'ok')


# Generated at 2022-06-24 19:10:11.137840
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg = AggregateStats()
    agg.decrement("failures", "foo")
    assert agg.failures["foo"] == 0

    agg.failures["foo"] = 1
    agg.decrement("failures", "foo")
    assert agg.failures["foo"] == 0

    agg.failures["foo"] = 2
    agg.decrement("failures", "foo")
    assert agg.failures["foo"] == 1



# Generated at 2022-06-24 19:10:21.014364
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats(
        'custom_stats_0_what', 'custom_stats_0_host')
    assert aggregate_stats_0.custom == {'_run': {'custom_stats_0_what': 'custom_stats_0_host'}}
    assert aggregate_stats_0.ok == {}
    assert aggregate_stats_0.changed == {}
    assert aggregate_stats_0.ignored == {}
    assert aggregate_stats_0.dark == {}
    assert aggregate_stats_0.rescued == {}
    assert aggregate_stats_0.failures == {}
    assert aggregate_stats_0.skipped == {}
    assert aggregate_stats_0.processed == {}


# Generated at 2022-06-24 19:10:25.473209
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement("fails", "foo")
    assert aggregate_stats_0.fails == {'foo': 0}
    aggregate_stats_0.decrement("fails", "foo")
    assert aggregate_stats_0.fails == {'foo': 0}

if __name__ == '__main__':
    test_AggregateStats_decrement()

# Generated at 2022-06-24 19:10:28.988214
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()

    for x in range(10):
        aggregate_stats_0.decrement('ok', 'local')

    assert(aggregate_stats_0.ok == {'local': 0})


# Generated at 2022-06-24 19:10:33.577427
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()

    # Verify that we can not decrement Dark if it doesn't exist
    try:
        aggregate_stats.decrement('dark', 'test_host')
        assert False
    except KeyError:
        assert True

    # Verify that the value is 0 after decrement
    aggregate_stats.increment('dark', 'test_host')
    aggregate_stats.decrement('dark', 'test_host')
    assert aggregate_stats.dark['test_host'] == 0



# Generated at 2022-06-24 19:10:39.431376
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('changed', 1, 'foo.example.org')

    assert(aggregate_stats_0.custom['foo.example.org']['changed'] == 1), "success"


# Generated at 2022-06-24 19:10:44.757002
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('changed', 'test_changed')
    assert aggregate_stats_0.changed.get('test_changed', 0) == 0


# Generated at 2022-06-24 19:10:52.330577
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.decrement('ok', 'foo')
    assert aggregate_stats_0.ok.get('foo') == 0
    aggregate_stats_0.ok = {'foo': 1}
    aggregate_stats_0.decrement('ok', 'foo')
    assert aggregate_stats_0.ok.get('foo') == 0

# Generated at 2022-06-24 19:10:54.457260
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats_0 = AggregateStats()
    assert isinstance(aggregate_stats_0, AggregateStats)
    aggregate_stats_0.decrement('changed', '127.0.0.1')
    assert aggregate_stats_0.changed['127.0.0.1'] == -1


# Generated at 2022-06-24 19:10:59.778624
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats(which=None, what=None, host=None)
    # assert_equal(expected, aggregate_stats.update_custom_stats(which, what, host))
    raise NotImplementedError()


# Generated at 2022-06-24 19:11:07.560573
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_1 = AggregateStats()
    aggregate_stats_1.update_custom_stats('changed', 'ok', 'localhost')
    aggregate_stats_1.update_custom_stats('changed', 'changed', 'localhost')
    assert aggregate_stats_1.custom == {'localhost': {'changed': 'changed'}}
    aggregate_stats_1.update_custom_stats('changed', {'local': 'localhost'})
    aggregate_stats_1.update_custom_stats('changed', {'remote': 'localhost'})
    assert aggregate_stats_1.custom == {'localhost': {'changed': 'changed'}, '_run': {'changed': {'remote': 'localhost', 'local': 'localhost'}}}


if __name__ == '__main__':
    test_case_0()
    test_AggregateStats_

# Generated at 2022-06-24 19:11:16.327790
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    # value 'which' can not be assigned to, which is of type <class 'str'>,
    # while a value of type <class 'int'> is expected in order to assign to attribute 'which' of class AggregateStats
    # aggregate_stats_0.update_custom_stats(1, {'key1': 'value1'})
    aggregate_stats_0.update_custom_stats('custom_stats_key', {'key1': 'value1'})
    aggregate_stats_0.update_custom_stats('custom_stats_key', {'key1': 'value1'})
    aggregate_stats_0.update_custom_stats('custom_stats_key', {'key2': 'value2'})

# Generated at 2022-06-24 19:11:22.366573
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    aggregate_stats = AggregateStats()

    #Exception checked for integer data type
    aggregate_stats.update_custom_stats('my_key', 10, 'localhost')
    assert aggregate_stats.custom == {"localhost": {'my_key': 10}}

    #Exception checked for dictionary data type
    aggregate_stats.update_custom_stats('my_key', {'nested_key': 'nested_value'}, 'localhost')
    assert aggregate_stats.custom == {"localhost": {'my_key': {'nested_key':'nested_value'}}}

    #Exception checked for collection data type
    aggregate_stats.update_custom_stats('my_key', [{'nested_key': 'nested_value'}], 'localhost')

# Generated at 2022-06-24 19:11:30.898105
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    test_AggregateStats_update_custom_stats_instance = AggregateStats()
    try:
        test_AggregateStats_update_custom_stats_instance.update_custom_stats("which", {}, "host")
    except:
        raise AssertionError("Failed: test_AggregateStats_update_custom_stats_instance.update_custom_stats(\"which\", {}, \"host\")")



# Generated at 2022-06-24 19:11:41.500026
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()

    # Test 1: Merge two dicts
    aggregate_stats.update_custom_stats('test', {'test_key': 1}, '_test')
    aggregate_stats.update_custom_stats('test', {'test_key': 2}, '_test')
    assert aggregate_stats.custom['_test']['test']['test_key'] == 3

    # Test 2: Merge two lists
    aggregate_stats.update_custom_stats('test', [1], '_test')
    aggregate_stats.update_custom_stats('test', [2], '_test')
    assert aggregate_stats.custom['_test']['test'] == [1, 2]

    # Test 3: Add two integers
    aggregate_stats.update_custom_stats('test', 1, '_test')
   

# Generated at 2022-06-24 19:11:48.167605
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.set_custom_stats('foo', 3, None)
    aggregate_stats_0.update_custom_stats('foo', {'bar': 3}, None)
    aggregate_stats_0.update_custom_stats('foo', {'foo': 3}, None)
    aggregate_stats_0.update_custom_stats('foo', {'bar': 3}, None)
    aggregate_stats_0.update_custom_stats('foo', {'foo': 3}, None)
    # TBD: add some assertions


# Generated at 2022-06-24 19:11:51.306723
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('foo', 'bar')
    assert aggregate_stats_0.custom['_run']['foo'] == 'bar'
    aggregate_stats_0.update_custom_stats('foo', {'baz': 'qux'})
    assert aggregate_stats_0.custom['_run']['foo'] == {'baz': 'qux'}


# Generated at 2022-06-24 19:11:57.841170
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    aggregate_stats_0.update_custom_stats('changed', 3)
    aggregate_stats_0.update_custom_stats('ok', 6)
    aggregate_stats_0.update_custom_stats('changed', 10)
    aggregate_stats_0.update_custom_stats('ok', 3, '_run')
    aggregate_stats_0.update_custom_stats('changed', 5, '_run')
    aggregate_stats_0.update_custom_stats('changed', 6, '_run')


# Generated at 2022-06-24 19:12:01.393474
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_0 = AggregateStats()
    assert aggregate_stats_0.update_custom_stats('stat_name', 0) is None
