

# Generated at 2022-06-10 23:33:37.132365
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ast = AggregateStats()

    # Check that decrement sets the number of "failures" to -1, if it wasn't initialized
    ast.failures = {}
    ast.decrement('failures', 'test')
    assert ast.failures['test'] == 0

    # Check that decrement doesn't decrement further than to 0
    ast.failures = {'test': 0}
    ast.decrement('failures', 'test')
    assert ast.failures['test'] == 0

    # Check that decrement really decrements
    ast.failures = {'test': 5}
    ast.decrement('failures', 'test')
    assert ast.failures['test'] == 4

# Generated at 2022-06-10 23:33:40.612996
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    # arrange
    stats = AggregateStats()

    # act
    stats.increment("ok", "host1")

    # assert
    assert stats.ok["host1"] == 1
    assert stats.processed["host1"] == 1

# Generated at 2022-06-10 23:33:45.820419
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('failures', 'host1')
    stats.decrement('failures', 'host1')
    assert stats.failures['host1'] == 0

    stats.decrement('failures', 'host2')
    assert stats.failures['host2'] == 0
    assert 'host2' not in stats.ok
    assert 'host2' not in stats.changed

    assert 'host1' not in stats.ok
    assert 'host1' not in stats.changed


# Generated at 2022-06-10 23:33:52.038804
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    # Initial test:
    # before increasing a statistic, its value should be 0, since it's initialised to zero.
    # Let's see what happens in the case of 'ok' statistic:
    test_as = AggregateStats()
    test_as.increment('ok', '127.0.0.1')
    assert test_as.ok == {'127.0.0.1': 1}
    assert test_as.ok.get('127.0.0.1') == 1
    assert test_as.ok.get('127.0.0.2', 0) == 0

    # The processed statistics should also be updated:
    assert test_as.processed == {'127.0.0.1': 1}
    assert test_as.processed.get('127.0.0.1') == 1
    assert test_

# Generated at 2022-06-10 23:33:59.016471
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    import pytest

    as_obj = AggregateStats()

    as_obj.decrement('failures', 'host1')
    assert as_obj.failures['host1'] == 0

    as_obj.ok['host1'] = 2
    as_obj.decrement('ok', 'host1')
    assert as_obj.ok['host1'] == 1

    with pytest.raises(KeyError):
        as_obj.ok['host1'] = 0
        as_obj.decrement('ok', 'host1')

    with pytest.raises(AttributeError):
        as_obj.decrement('invalid', 'host1')

# Generated at 2022-06-10 23:34:02.508829
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggr = AggregateStats()

    aggr.increment('failures', 'host1')
    aggr.decrement('failures', 'host1')

    assert aggr.failures['host1'] == 0
    aggr.decrement('failures', 'host1')
    assert aggr.failures['host1'] == 0

# Generated at 2022-06-10 23:34:09.545670
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 1

    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 0

    # Host not in stats.ok
    stats.decrement('ok', 'host3')
    assert stats.ok['host3'] == 0



# Generated at 2022-06-10 23:34:13.116996
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # define an instance of the object
    ast = AggregateStats()

    # add a key+value
    ast.increment('rescued', 'somehost')

    # decrement the value
    ast.decrement('rescued', 'somehost')

    # check the results
    assert ast.rescued['somehost'] == 0

# Generated at 2022-06-10 23:34:22.615602
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('skipped', 'testhost')
    stats.increment('skipped', 'testhost')
    assert stats.skipped['testhost'] == 2
    stats.decrement('skipped', 'testhost')
    assert stats.skipped['testhost'] == 1
    # decrement below zero should set count to zero
    stats.decrement('skipped', 'testhost')
    stats.decrement('skipped', 'testhost')
    assert stats.skipped['testhost'] == 0
    # decrement on unknown host should do nothing
    stats.decrement('skipped', 'othertesthost')
    assert stats.skipped['othertesthost'] == 0

# Generated at 2022-06-10 23:34:26.361104
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    a = AggregateStats()
    a.increment("ok", "host1")
    assert a.ok["host1"] == 1
    a.increment("ok", "host1")
    assert a.ok["host1"] == 2


# Generated at 2022-06-10 23:34:39.927536
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    stats = AggregateStats()
    stats.update_custom_stats('foo', {'bar': 1})
    assert stats.custom['_run']['foo']['bar'] == 1
    stats.update_custom_stats('foo', {'bar':2})
    assert stats.custom['_run']['foo']['bar'] == 3
    stats.update_custom_stats('foo', {'bar': 3}, host='localhost')
    assert stats.custom['localhost']['foo']['bar'] == 3
    stats.update_custom_stats('foo', {'bar': 4}, host='localhost')
    assert stats.custom['localhost']['foo']['bar'] == 7
    stats.update_custom_stats('foo', 4, host='localhost')
    assert stats.custom['localhost']['foo'] == 11


# Generated at 2022-06-10 23:34:49.013973
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    # Mapping of what -> expected result
    the_what = [
        [{'foo': 1, 'bar': 2}, {'foo': 1, 'bar': 2}],  # normal dict
        [{'foo': 2, 'bar': {'baz': 1}}, {'foo': 2, 'bar': {'baz': 1}}],  # nested dict
        [1, 1],
        [2, 1]
    ]

    # Mapping of previous result (which) -> expected result

# Generated at 2022-06-10 23:34:52.030025
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggstats = AggregateStats()
    aggstats.set_custom_stats('failed', 1, host='test')
    aggstats.decrement('custom', host='test')
    assert aggstats.custom['test']['failed'] == 0

# Generated at 2022-06-10 23:35:02.480283
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common._collections_compat import MutableMapping
    stats = AggregateStats()
    stats.update_custom_stats("_run", "test_run")
    assert stats.custom == {'_run': {'_run': 'test_run'}}
    stats.update_custom_stats("_run", "test_run_2", "host")
    assert stats.custom == {'_run': {'_run': 'test_run'}, 'host': {'_run': 'test_run_2'}}
    stats.update_custom_stats("_run", "test_run_3", "non_existing_host")

# Generated at 2022-06-10 23:35:10.285193
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    astats = AggregateStats()
    a = {'1':'one', '2':'two'}
    b = {'2':'two', '3':'three'}
    c = {'2':'twotwo', '3':'threethree'}
    d = {'4':'four', '5':'five'}
    astats.update_custom_stats('dict', a)
    assert astats.custom['_run']['dict'] == a
    astats.update_custom_stats('dict', b)
    assert astats.custom['_run']['dict'] == {'1':'one', '2':'two', '3':'three'}
    astats.update_custom_stats('dict', c)

# Generated at 2022-06-10 23:35:13.244909
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement('ok', 'foo')
    assert aggregate_stats.ok['foo'] == 0

    aggregate_stats.ok['foo'] = 10
    aggregate_stats.decrement('ok', 'foo')
    assert aggregate_stats.ok['foo'] == 9


# Generated at 2022-06-10 23:35:18.780104
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    ''' Test for update_custom_stats method of class AggregateStats '''
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats('test_custom_stats', 'some_value')
    assert len(aggregate_stats.custom.keys()) == 1
    assert len(aggregate_stats.custom['_run'].keys()) == 1
    assert aggregate_stats.custom['_run']['test_custom_stats'] == 'some_value'

    aggregate_stats.update_custom_stats('test_custom_stats', 'some_value', '_run')
    assert len(aggregate_stats.custom.keys()) == 1
    assert len(aggregate_stats.custom['_run'].keys()) == 1

# Generated at 2022-06-10 23:35:25.110622
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    stats = AggregateStats()
    stats.increment('ignored', 'localhost')
    stats.increment('ignored', 'localhost')
    stats.increment('ignored', 'localhost')
    stats.decrement('ignored', 'localhost')
    assert stats.ignored == {'localhost': 2}

    stats.decrement('ignored', 'localhost')
    assert stats.ignored == {'localhost': 1}

    stats.decrement('ignored', 'localhost')
    assert stats.ignored == {'localhost': 0}

    # Shouldn't decrease below 0
    stats.decrement('ignored', 'localhost')
    assert stats.ignored == {'localhost': 0}

# Generated at 2022-06-10 23:35:31.011237
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    stats.update_custom_stats('test', 5)
    assert(stats.custom['_run']['test'] == 5)

    stats.update_custom_stats('test', 5)
    assert(stats.custom['_run']['test'] == 10)

    stats.update_custom_stats('test', 5, 'host1')
    assert(stats.custom['host1']['test'] == 5)

    stats.update_custom_stats('test', '5', 'host1')
    assert(stats.custom['host1']['test'] == "55")

    stats.update_custom_stats('test1', {'a': 1}, 'host2')
    assert(stats.custom['host2']['test1'] == {'a': 1})

    stats.update_custom_

# Generated at 2022-06-10 23:35:41.617773
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # empty instance
    as_ = AggregateStats()
    as_.update_custom_stats('a', {'b': 1, 'c': [1, 2]})
    assert as_.custom == {'_run': {'a': {'b': 1, 'c': [1, 2]}}}

    # a dict is updated with a dict
    as_.update_custom_stats('a', {'b': 2, 'd': [3, 4]})
    assert as_.custom == {'_run': {'a': {'b': 2, 'c': [1, 2], 'd': [3, 4]}}}

    # no update for different type of what
    as_.update_custom_stats('a', 5)