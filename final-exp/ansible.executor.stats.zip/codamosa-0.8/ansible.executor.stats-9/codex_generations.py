

# Generated at 2022-06-10 23:33:35.927710
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok['host1'] = 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 0


# Generated at 2022-06-10 23:33:40.655358
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    a = AggregateStats()
    a.increment('failures', 'somehost')
    assert a.failures['somehost'] == 1
    a.decrement('failures', 'somehost')
    assert a.failures['somehost'] == 0
    a.decrement('failures', 'somehost')
    assert a.failures['somehost'] == 0

# Generated at 2022-06-10 23:33:47.845653
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    import copy

    # Test when value is greater than zero
    stats = AggregateStats()
    stats.ok['10.20.30.40'] = 3
    stats.decrement('ok', '10.20.30.40')
    assert stats.ok['10.20.30.40'] == 2

    # Test when value is equal to zero
    stats = AggregateStats()
    stats.ok['10.20.30.40'] = 0
    stats.decrement('ok', '10.20.30.40')
    assert stats.ok['10.20.30.40'] == 0

    # Test when value is uninitialized
    stats = AggregateStats()
    stats.decrement('ok', '10.20.30.40')
    assert stats.ok['10.20.30.40'] == 0

#

# Generated at 2022-06-10 23:33:54.757989
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    '''Test the decrement method of AggregateStats'''
    testobj = AggregateStats()

    # Branch coverage
    testobj.decrement('failures', 'host1')

    # Branch coverage, except block
    testobj.decrement('failures', 'host1')
    getattr(testobj, 'failures')['host1'] = 2
    testobj.decrement('failures', 'host1')

    # Branch coverage, last block
    getattr(testobj, 'failures')['host1'] = 0
    testobj.decrement('failures', 'host1')

    # Branch coverage, end of function
    testobj.decrement('failures', 'host1')



# Generated at 2022-06-10 23:34:01.650045
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    host = "test_host"
    # test decrement not existing attribute
    stats.decrement("foo", host)
    assert stats.foo[host] == 0
    # test decrement existing attribute
    stats.increment("foo", host)
    stats.increment("foo", host)
    stats.decrement("foo", host)
    assert stats.foo[host] == 1
    # test decrement existing attribute less than 0
    stats.decrement("foo", host)
    stats.decrement("foo", host)
    assert stats.foo[host] == 0

if __name__ == '__main__':
    test_AggregateStats_decrement()

# Generated at 2022-06-10 23:34:08.707320
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg_stats = AggregateStats()
    agg_stats.decrement('ok', 'localhost')
    assert agg_stats.ok.get('localhost', 0) == 0
    agg_stats.ok['localhost'] = 1
    agg_stats.decrement('ok', 'localhost')
    assert agg_stats.ok.get('localhost', 0) == 0
    agg_stats.ok['localhost'] = 2
    agg_stats.decrement('ok', 'localhost')
    assert agg_stats.ok.get('localhost', 0) == 1


# Generated at 2022-06-10 23:34:17.859774
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    a = AggregateStats()

    a.decrement('failures', 'luc')
    assert a.failures['luc'] == 0

    a.increment('failures', 'luc')
    assert a.failures['luc'] == 1
    assert a.failures['jean'] is None

    a.decrement('failures', 'luc')
    assert a.failures['luc'] == 0

    a.decrement('failures', 'jean')
    assert a.failures['jean'] == 0

    a.increment('failures', 'jean')
    assert 'jean' in a.failures
    assert a.failures['jean'] == 1

    a.decrement('failures', 'jean')
    assert a.failures['jean'] == 0



# Generated at 2022-06-10 23:34:21.054081
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    from mock import MagicMock

    stats = AggregateStats()
    stats.failures['host'] = 1
    stats.decrement('failures', 'host')
    assert stats.failures['host'] == 0

# Generated at 2022-06-10 23:34:26.457615
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'foo')
    stats.increment('ok', 'foo')
    stats.increment('ok', 'bar')
    stats.increment('ok', 'baz')
    stats.decrement('ok', 'foo')
    the_sum = sum(stats.ok.values())
    assert the_sum == 3

# Generated at 2022-06-10 23:34:34.659336
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    stats.decrement("ignored", "host")
    assert stats.processed == {"host": 1}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {"host": 0}

    stats.decrement("ignored", "host")
    assert stats.processed == {"host": 1}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {"host": 0}



# Generated at 2022-06-10 23:34:46.621517
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.utils.vars import combine_vars
    from ansible import constants as C

    def _check(s1, s2, expected):
        stats = AggregateStats()
        stats.update_custom_stats("foo", s1, "host")
        stats.update_custom_stats("foo", s2, "host")

        # combine global_variables with combine_vars when needed
        if isinstance(expected, dict):
            expected = combine_vars(expected, C.global_vars)

        assert stats.custom["host"]["foo"] == expected, "update_custom_stats test failed"

    _check({"a": 1, "b": 2}, {"b": 3}, {"a": 1, "b": 3})

# Generated at 2022-06-10 23:34:52.759167
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats(which='custom_stat_1', what={'a': {'b': {'c': 1}}})
    assert stats.custom['_run']['custom_stat_1'] == {'a': {'b': {'c': 1}}}
    stats.update_custom_stats(which='custom_stat_1', what={'a': {'b': {'d': 2}}})
    assert stats.custom['_run']['custom_stat_1'] == {'a': {'b': {'c': 1, 'd': 2}}}
    stats.update_custom_stats(which='custom_stat_1', what={'a': 3})
    assert stats.custom['_run']['custom_stat_1'] == {'a': 3}
    stats

# Generated at 2022-06-10 23:34:58.686001
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 0
    stats.increment('ok', 'test')
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 0
    stats.ok['test'] = 5
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 4

# Generated at 2022-06-10 23:35:07.428628
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    ag_stats = AggregateStats()
    ag_stats.update_custom_stats("foo", "bar")
    assert ag_stats.custom == {'_run': {'foo': 'bar'}}
    ag_stats.update_custom_stats("bar", "foo")
    assert ag_stats.custom == {'_run': {'foo': 'bar', 'bar': 'foo'}}
    ag_stats.update_custom_stats("foo", "biz")
    assert ag_stats.custom == {'_run': {'foo': 'biz', 'bar': 'foo'}}
    ag_stats.update_custom_stats("foo", {"biz": "baz"})
    assert ag_stats.custom == {'_run': {'foo': {"biz": "baz"}, 'bar': 'foo'}}
    ag_stats.update

# Generated at 2022-06-10 23:35:13.991119
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    agg = AggregateStats()

    # Test 1: update_custom_stats() initializes custom stats
    agg.update_custom_stats("foo1", "bar1")
    assert agg.custom[u'_run'] == {"foo1": "bar1"}

    # Test 2: update_custom_stats() updates existing stats
    agg.update_custom_stats("foo1", "bar2")
    assert agg.custom[u'_run'] == {"foo1": "bar2"}

    # Test 3: update_custom_stats() does not update mismatching types
    agg.custom[u'_run'] = {"foo1": "bar2"}
    agg.update_custom_stats("foo1", 1)
    assert agg.custom[u'_run'] == {"foo1": "bar2"}

    # Test 4: update_custom_stats

# Generated at 2022-06-10 23:35:21.930665
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    ags = AggregateStats()
    # Expected failure for mismatching types
    assert ags.update_custom_stats('fail', 1, 'host_0') is None
    # Expected fail for non-existent types
    assert ags.update_custom_stats('fail', {}, 'host_0') is None
    # Basic test
    assert ags.update_custom_stats('ok', {'a': 1}, 'host_1') is None
    assert ags.custom.get('host_1', {}).get('ok') == {'a': 1}
    # Expected fail for mismatching types
    assert ags.update_custom_stats('ok', {'a': 1}, 'host_1') is None
    # Expected fail for mismatching types

# Generated at 2022-06-10 23:35:29.184755
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    # test set of { 'foo' : 1 }
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 1

    # test update of { 'foo' : 2 }
    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 2

    # test merge of { 'bar' : 1 }
    stats.update_custom_stats('bar', 1)
    assert stats.custom['_run']['bar'] == 1

    # test merge of { 'x' : 1, 'y' : 2}
    stats.update_custom_stats('attempts', { 'x' : 1, 'y' : 2 })

# Generated at 2022-06-10 23:35:37.685355
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    stats.update_custom_stats('a', 1)
    assert(stats.custom['_run'] == {'a': 1})

    stats.update_custom_stats('a', 2)
    assert(stats.custom['_run'] == {'a': 3})

    stats.update_custom_stats('a', {'b': 1})
    assert(stats.custom['_run'] == {'a': 3, 'b': 1})

    stats.update_custom_stats('a', {'b': 2})
    assert(stats.custom['_run'] == {'a': 3, 'b': 3})

# Generated at 2022-06-10 23:35:46.330347
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    agg = AggregateStats()
    agg.update_custom_stats("test", 1)
    assert agg.custom['_run']['test'] == 1

    agg.update_custom_stats("test_dict", {'test': 1})
    assert agg.custom['_run']['test_dict'] == {'test': 1}

    agg.update_custom_stats("test_dict", {'test2': 3})
    assert agg.custom['_run']['test_dict'] == {'test': 1, 'test2': 3}

    agg.update_custom_stats("test_dict", {'test2': 4})
    assert agg.custom['_run']['test_dict'] == {'test': 1, 'test2': 7}



# Generated at 2022-06-10 23:35:51.619474
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggr = AggregateStats()
    aggr.update_custom_stats('memory', {'vms': 100, 'rss': 200})
    assert aggr.custom['_run']['memory']['vms'] == 100
    assert aggr.custom['_run']['memory']['rss'] == 200

    aggr.update_custom_stats('memory', {'vms': 20, 'rss': 40})
    assert aggr.custom['_run']['memory']['vms'] == 120
    assert aggr.custom['_run']['memory']['rss'] == 240

    aggr.update_custom_stats('loops', 1)
    assert aggr.custom['_run']['loops'] == 1

    aggr.update_custom_stats('loops', 2)
    assert aggr

# Generated at 2022-06-10 23:36:00.797293
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    asg = AggregateStats()
    asg.decrement('failures', 'test')
    assert asg.failures == {'test': 0}
    asg.increment('failures', 'test')
    asg.increment('failures', 'test')
    assert asg.failures == {'test': 2}
    asg.decrement('failures', 'test')
    assert asg.failures == {'test': 1}
    asg.decrement('failures', 'test5')
    assert asg.failures == {'test': 1, 'test5': 0}

if __name__ == "__main__":
    test_AggregateStats_decrement()

# Generated at 2022-06-10 23:36:05.714445
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.utils.ssl_friend import SSLFriend
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    ssl_context = SSLFriend(loader=loader)
    inventory = InventoryManager(loader=loader, sources="tests/inventory")
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-10 23:36:14.303619
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('skipped', 'host1')
    stats.increment('skipped', 'host1')
    stats.increment('skipped', 'host1')

    assert stats.skipped['host1'] == 3, stats.skipped['host1']

    stats.decrement('skipped', 'host1')

    assert stats.skipped['host1'] == 2, stats.skipped['host1']

    try:
        stats.decrement('skipped', 'host1')
        stats.decrement('skipped', 'host1')
        stats.decrement('skipped', 'host1')
    except:
        assert True, "Should not decrement below zero"

    assert stats.skipped['host1'] == 0, stats.skipped['host1']

# Generated at 2022-06-10 23:36:23.564547
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Decrement method set the corresponding value of the statistic to 0
    # if it has not been initialized.
    stats = AggregateStats()
    stats.decrement('failures', 'host')
    assert 0 == stats.failures['host']
    # Decrement method must decrement a given value.
    stats.increment('failures', 'host')
    assert 1 == stats.failures['host']
    stats.decrement('failures', 'host')
    assert 0 == stats.failures['host']
    # Decrement method must not decrement a given value when it is 0.
    stats.decrement('failures', 'host')
    assert 0 == stats.failures['host']

# Generated at 2022-06-10 23:36:33.521751
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.rescued['127.0.0.1'] = 5
    stats.decrement('rescued', '127.0.0.1')
    assert stats.rescued['127.0.0.1'] == 4

    # test negative
    stats.decrement('rescued', '127.0.0.1')
    assert stats.rescued['127.0.0.1'] == 3

    # test below zero
    for _ in range(4):
        stats.decrement('rescued', '127.0.0.1')

    assert stats.rescued['127.0.0.1'] == 0

# Generated at 2022-06-10 23:36:40.899338
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    import os
    import sys
    import random
    import string
    # this is required in order to test the utils class
    sys.path.append('.')
    utils_dir = os.path.dirname(os.path.abspath(__file__)) + os.sep + '..' + os.sep + 'utils'
    sys.path.append(utils_dir)
    from utils import AggregateStats
    # create a new instance of AggregateStats class
    stats = AggregateStats()
    # add in the object of the class an attribute called 'ok'
    stats.ok = random.randint(1, 10)
    # change the value of the 'ok' attribute of the class
    stats.decrement('ok', 'localhost')
    # test the value of the 'ok' attribute of the class


# Generated at 2022-06-10 23:36:46.646055
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    as_obj = AggregateStats()
    assert as_obj.decrement('ok', 'localhost') == 0
    assert as_obj.decrement('ok', 'localhost') == 0
    as_obj.increment('ok', 'localhost')
    assert as_obj.decrement('ok', 'localhost') == 0
    assert as_obj.decrement('ok', 'localhost') == 0
    as_obj.increment('ok', 'localhost')
    as_obj.increment('ok', 'localhost')
    as_obj.increment('ok', 'localhost')
    as_obj.increment('ok', 'localhost')
    assert as_obj.decrement('ok', 'localhost') == 3
    assert as_obj.decrement('ok', 'localhost') == 2

# Generated at 2022-06-10 23:36:56.154045
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    '''
    Decrements the value of what by 1
    '''
    # Test Case: Decrement a value that is set to 1
    agg_stats = AggregateStats()
    agg_stats.skipped = {'127.0.0.1': 1}
    agg_stats.decrement('skipped', '127.0.0.1')
    assert(agg_stats.skipped == {'127.0.0.1': 0})

    agg_stats.skipped = {'127.0.0.1': 10}
    agg_stats.decrement('skipped', '127.0.0.1')
    assert(agg_stats.skipped == {'127.0.0.1': 9})

    # Test Case: Decrement a value that is set to 0

# Generated at 2022-06-10 23:37:03.902705
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment("ok","test.example.com")
    assert stats.ok["test.example.com"] == 1
    stats.increment("ok","test.example.com")
    assert stats.ok["test.example.com"] == 2
    stats.increment("ok","test.example.com")
    assert stats.ok["test.example.com"] == 3
    stats.decrement("ok","test.example.com")
    assert stats.ok["test.example.com"] == 2
    stats.decrement("ok","test.example.com")
    assert stats.ok["test.example.com"] == 1
    stats.decrement("ok","test.example.com")
    assert stats.ok["test.example.com"] == 0

# Generated at 2022-06-10 23:37:10.202078
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok = {'host1':2, 'host2':10}
    stats.decrement('ok','host1')
    stats.decrement('ok','host2')
    stats.decrement('ok','host2')
    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 8