

# Generated at 2022-06-10 23:33:36.272076
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ag = AggregateStats()
    test = ag.increment("failures", "host")
    assert ag.failures == {"host": 1}
    assert ag.processed == {"host": 1}

    test = ag.increment("ok", "host")
    assert ag.ok == {"host": 1}
    assert ag.processed == {"host": 1}


# Generated at 2022-06-10 23:33:44.949622
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    as_ = AggregateStats()

    as_.ok = {'host1':1}
    as_.changed = {'host1':1, 'host2':1}
    as_.ignored = {'host2':1}

    as_.decrement('ok', 'host1')
    assert as_.ok == {'host1': 0}

    as_.decrement('changed', 'host1')
    assert as_.changed == {'host1': 0, 'host2': 1}

    as_.decrement('ok', 'host2')
    assert as_.ok == {'host1': 0}

    as_.decrement('changed', 'host2')
    assert as_.changed == {'host1': 0, 'host2': 0}

    as_.decrement('ignored', 'host2')
    assert as_.ign

# Generated at 2022-06-10 23:33:47.058318
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement("skipped", "127.0.0.1")
    assert stats.skipped == {"127.0.0.1": 0}

# Generated at 2022-06-10 23:33:52.020082
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment("failures", "test_host")
    assert stats.failures.get("test_host", 0) == 1
    stats.decrement("failures", "test_host")
    assert stats.failures.get("test_host", 0) == 0
    stats.decrement("failures", "test_host")
    assert stats.failures.get("test_host", 0) == 0

# Generated at 2022-06-10 23:34:00.216090
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Create an instance of AggregateStats
    aggregate_stats = AggregateStats()

    # Create a dict
    ok = {}
    ok['site1.example.com'] = 5
    ok['site2.example.com'] = 7

    # Assign the created dict to the attribute ok of the AggregateStats class
    aggregate_stats.ok = ok

    # Call the method decrement
    aggregate_stats.decrement('ok', 'site1.example.com')

    # Test if the ok attribute of the AggregateStats class has been updated
    assert aggregate_stats.ok == {'site1.example.com': 4, 'site2.example.com': 7}

    # Test if the ok attribute of the AggregateStats class has been updated
    aggregate_stats.decrement('ok', 'site2.example.com')

    assert aggregate

# Generated at 2022-06-10 23:34:03.638180
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host')
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 0
    stats.increment('ok', 'host2')
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 0

# Generated at 2022-06-10 23:34:06.342435
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggr = AggregateStats()
    aggr.ok = { "host1": 1, "host2": 1 }
    aggr.decrement("ok", "host1")
    assert aggr.ok["host1"] == 0
    aggr.decrement("ok", "host3")
    assert aggr.ok["host3"] == 0

# Generated at 2022-06-10 23:34:12.480591
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    test_suit = {
        "ok":{"host1":1},
        "failures":{"host1":0},
        "dark":{"host1":0},
        "changed":{"host1":0},
        "skipped":{"host1":0},
        "rescued":{"host1":0},
        "ignored":{"host1":0},
        "custom":{"host1":{}}
    }
    test_obj = AggregateStats()
    test_obj.increment("ok", "host1")
    assert test_obj.__dict__ == test_suit


# Generated at 2022-06-10 23:34:22.564834
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    import pytest
    agg = AggregateStats()
    agg.ok = {'localhost': 2, 'other': 3}
    agg.decrement('ok', 'localhost')
    assert agg.ok.get('localhost') == 1
    agg.decrement('ok', 'other')
    assert agg.ok.get('other') == 2
    agg.decrement('ok', 'other')
    assert agg.ok.get('other') == 1
    agg.decrement('ok', 'other')
    assert agg.ok.get('other') == 0
    agg.decrement('ok', 'other')
    assert agg.ok.get('other') == 0
    with pytest.raises(KeyError):
        agg.decrement('ok', 'others')

# Generated at 2022-06-10 23:34:30.836989
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    # ensure we can increment the stats counters
    stats.increment('ok', 'host1')
    assert dict(host1=1) == stats.ok
    stats.increment('ok', 'host1')
    assert dict(host1=2) == stats.ok
    stats.increment('ok', 'host2')
    assert dict(host1=2, host2=1) == stats.ok

    # ensure we can increment the stats counters
    stats.increment('changed', 'host1')
    assert dict(host1=1) == stats.changed
    stats.increment('changed', 'host1')
    assert dict(host1=2) == stats.changed
    stats.increment('changed', 'host2')
    assert dict(host1=2, host2=1) == stats.changed

# Generated at 2022-06-10 23:34:38.272890
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate = AggregateStats()
    aggregate.set_custom_stats('test_key_1', {'test_key_2': 1})
    aggregate.set_custom_stats('test_key_1', {'test_key_2': 2})
    expected_result = {'test_key_2': 3}
    assert aggregate.custom['_run']['test_key_1'] == expected_result

# Generated at 2022-06-10 23:34:46.184633
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.module_utils.common._collections_compat import MutableMapping

    sut = AggregateStats()
    sut.update_custom_stats('a', 1)

    # dict type
    sut.update_custom_stats('a', {'1': 1})
    assert sut.custom['_run']['a']['1'] == 1

    # list type
    sut.update_custom_stats('a', ['2', '3'])
    assert sut.custom['_run']['a']['1'] == 1
    assert sut.custom['_run']['a']['2'] == '3'

    # dict type
    sut.update_custom_stats('a', {'2': 3})

# Generated at 2022-06-10 23:34:52.490012
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Test dictionaries
    d = {}
    d2 = {'a': [1, 2, 3]}
    d3 = {'a': [4, 5, 6]}

    # Test integers
    i = 1
    i2 = 2

    # Running the tests
    # update_custom_stats with a dictionary
    # Runs normally
    a = AggregateStats()
    a.update_custom_stats('d', d2)
    a.update_custom_stats('d', d3)
    if d2['a'] + d3['a'] != a.custom['_run']['d']['a']:
        raise Exception('AggregateStats_update_custom_stats method does not work with dictionaries')
    # Runs with an integer for host
    a = AggregateStats()

# Generated at 2022-06-10 23:35:02.912604
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    case1 = {
        "key1": "val1",
        "key2": "val2",
    }
    case2 = {
        "key1": "val1",
        "key2": "val2",
        "key3": "val3",
    }
    case3 = {
        "key1": "new_val1",
        "key2": "val2",
        "key3": "val3",
    }

    # key1 is set with a value and update it with the same type
    agg_stats = AggregateStats()
    agg_stats.update_custom_stats('key1', 'val1', host=None)
    agg_stats.update_custom_stats('key1', 'val2', host=None)

# Generated at 2022-06-10 23:35:10.653986
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    '''
    Test method AggregateStats.update_custom_stats().
    This is called by the test-module script.
    '''

    agg = AggregateStats()
    agg.update_custom_stats('a', 1)
    agg.update_custom_stats('a', 1)
    assert agg.custom['_run']['a'] == 2
    agg.update_custom_stats('a', 1, '127.0.0.1')
    agg.update_custom_stats('a', 1, '127.0.0.1')
    assert agg.custom['127.0.0.1']['a'] == 2

    agg.update_custom_stats('a', {'b': 'c'})
    assert agg.custom['_run']['a'] == {'b': 'c'}

# Generated at 2022-06-10 23:35:15.168692
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 1, host='testhost')
    assert stats.custom['testhost']['foo'] == 1
    stats.update_custom_stats('foo', 1, host='testhost')
    assert stats.custom['testhost']['foo'] == 2
    stats.update_custom_stats('foo', None, host='testhost')
    assert stats.custom['testhost']['foo'] == 2


# Generated at 2022-06-10 23:35:23.509822
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    '''
    AggregateStats.update_custom_stats(): this test is for method
    update_custom_stats, the main purpose of this method is to merge stats
    from different hosts. Below test cases tries to cover most of the scenarios

    1. Merging of stats when the type is string
    2. Merging of stats when the type is int
    3. Merging of stats when the type is dictionary
    4. Merging of stats when the type is list
    5. Merge of stats when the type of stats are mismatch
    '''
    stats = AggregateStats()
    stats.update_custom_stats('experiment', 'xyz', host='localhost')
    assert stats.custom['localhost']['experiment'] == 'xyz'
    stats.update_custom_stats('experiment', 123, host='localhost')

# Generated at 2022-06-10 23:35:33.561719
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    '''
    We test the update of a custom stat with a dictionary and a counter.
    The dictionary is updated by merge_hash() with a new one containing modified
    and new items. The counter is updated.
    '''

    class CustomStat:
        def __init__(self):
            self.custom = {}

        def update_custom_stats(self, which, what, host=None):
            super(CustomStat, self).update_custom_stats(which, what, host)

    custom_stat_dict = {'item1': 'value1', 'item2': 'value2'}
    custom_stat_counter = 2

    aggr_stats = CustomStat()
    aggr_stats.update_custom_stats('custom_stat_dict', custom_stat_dict)

# Generated at 2022-06-10 23:35:43.309123
# Unit test for method update_custom_stats of class AggregateStats

# Generated at 2022-06-10 23:35:49.695624
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats('run_time', 5.0)
    assert aggregate_stats.custom != None
    assert aggregate_stats.custom['_run'] == {'run_time': 5.0}
    aggregate_stats.update_custom_stats('run_time', 7.0)
    assert aggregate_stats.custom['_run'] == {'run_time': 12.0}

test_AggregateStats_update_custom_stats()