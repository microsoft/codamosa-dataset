

# Generated at 2022-06-10 23:33:38.464572
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ignored = {'127.0.0.1': 1, '127.0.0.2': 2, '127.0.0.3': 0}

    for host in stats.ignored.keys():
        stats.decrement('ignored', host)

    for host, cnt in stats.ignored.items():
        assert cnt == stats.ignored.get(host) - 1
    try:
        stats.decrement('ignored', 12345)
    except TypeError:
        pass


# Generated at 2022-06-10 23:33:44.094157
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ag = AggregateStats()
    ag.increment('changed', 'host1')
    assert ag.changed['host1'] == 1
    assert ag.processed['host1'] == 1
    ag.increment('changed', 'host1')
    ag.increment('changed', 'host2')
    assert ag.changed['host1'] == 2
    assert ag.changed['host2'] == 1
    assert ag.processed == {'host1': 1, 'host2': 1}


# Generated at 2022-06-10 23:33:52.273437
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    test_class = AggregateStats()
    test_class.increment('ok', 'host1')
    assert test_class.processed == {'host1': 1}
    assert test_class.ok == {'host1': 1}
    test_class.increment('ok', 'host1')
    assert test_class.ok == {'host1': 2}
    test_class.increment('failures', 'host1')
    assert test_class.failures == {'host1': 1}
    test_class.increment('ok', 'host2')
    assert test_class.processed == {'host1': 1, 'host2': 1}
    assert test_class.ok == {'host1': 2, 'host2': 1}


# Generated at 2022-06-10 23:33:55.484623
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Arrange
    test_obj = AggregateStats()
    test_obj.ok['test_host'] = 1

    # Act
    test_obj.decrement('ok', 'test_host')

    # Assert
    assert test_obj.ok['test_host'] == 0

# Generated at 2022-06-10 23:34:01.191379
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    my_stats = AggregateStats()

    if my_stats.ok.get('test_host',0) == 0:
        my_stats.increment('ok', 'test_host')
    else:
        print("FAIL: ok host count not starting at 0")

    if my_stats.ok.get('test_host',0) != 1:
        print("FAIL: ok host count not incrementing")

    if my_stats.ok.get('other_host',0) != 0:
        print("FAIL: stats not per host")


# Generated at 2022-06-10 23:34:05.862162
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    # Test AggregateStats.decrement with a non-existing key
    test_obj = AggregateStats()
    try:
        test_obj.decrement('failures', 'localhost')
    except:
        assert False, 'Failed to decrement "failures" counter with a non-existing key'

    # Test AggregateStats.decrement with a key that is already at 0
    test_obj.failures['localhost'] = 0
    test_obj.decrement('failures', 'localhost')
    assert test_obj.failures['localhost'] == 0, 'Failed to decrement "failures" counter with a zero key'

# Generated at 2022-06-10 23:34:11.795494
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    print('<1>')
    stats.update_custom_stats('stats1', {'testkey': 'testvalue1'})
    print(stats.custom)
    print('<2>')
    stats.update_custom_stats('stats1', {'testkey': 'testvalue2'})
    print(stats.custom)
    print('<3>')
    stats.update_custom_stats('stats2', {'testkey': 'testvalue3'})
    print(stats.custom)


# Generated at 2022-06-10 23:34:15.176276
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    aggregate_stats = AggregateStats()
    what = "ok"
    host = "localhost"

    assert aggregate_stats.ok.get(host) is None
    aggregate_stats.decrement(what, host)
    assert aggregate_stats.ok[host] == 0

# Generated at 2022-06-10 23:34:26.694466
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # test removing elements from dict
    stats = AggregateStats()
    stats.ok['host1'] = 1
    stats.decrement('ok', 'host1')
    assert stats.ok.get('host1') == 0

    # test removing elements from dict
    stats = AggregateStats()
    stats.ok['host1'] = 0
    stats.decrement('ok', 'host1')
    assert stats.ok.get('host1') == 0

    # test negative numbers is not allowed
    stats = AggregateStats()
    stats.ok['host1'] = -1
    stats.decrement('ok', 'host1')
    assert stats.ok.get('host1') == 0

    # test non-existing key
    stats = AggregateStats()
    stats.decrement('ok', 'host1')

# Generated at 2022-06-10 23:34:30.357482
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    def test():
        stats = AggregateStats()
        stats.increment('failures', 'host1')
        stats.increment('ok', 'host1')
        assert stats.ok.get('host1', 0) == 1
        assert stats.failures.get('host1', 0) == 1
    test()

# Generated at 2022-06-10 23:34:36.042082
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Initialize the object
    obj = AggregateStats()

    # Create the instance of the object
    what = 'ok'
    host = 'localhost'
    obj.decrement(what, host)

    # Verify the results
    assert obj.ok['localhost'] == 0


# Generated at 2022-06-10 23:34:45.082399
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.skipped['example.com'] = 1
    aggregate_stats.decrement('skipped', 'example.com')
    assert aggregate_stats.skipped['example.com'] == 0
    # The below should not result in a decrease
    aggregate_stats.decrement('skipped', 'example.com')
    assert aggregate_stats.skipped['example.com'] == 0
    # The below should not result in a decrease
    aggregate_stats.decrement('skipped', 'foo.example.com')
    assert aggregate_stats.skipped['foo.example.com'] == 0

# Generated at 2022-06-10 23:34:51.721176
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok = {'host1': 3}
    stats.decrement('ok', 'host1')
    assert stats.ok == {'host1': 2}
    stats.decrement('ok', 'host1')
    assert stats.ok == {'host1': 1}
    stats.decrement('ok', 'host1')
    assert stats.ok == {'host1': 0}
    stats.decrement('ok', 'host1')
    assert stats.ok == {'host1': 0}

    # Test that decrementing a non-existent key raises no exception
    stats.decrement('failures', 'host1')

    stats.failures = {'host1': 0}
    stats.decrement('failures', 'host1')
    assert stats.failures

# Generated at 2022-06-10 23:35:02.448164
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # make a stat object
    stat = AggregateStats()

    # assert success decrement
    stat.increment(what='ok', host='host')
    stat.decrement(what='ok', host='host')
    assert stat.ok['host'] == 0

    # assert failure decrement
    stat.increment(what='failures', host='host')
    stat.decrement(what='failures', host='host')
    assert stat.failures['host'] == 0

    # assert rescue decrement
    stat.increment(what='rescued', host='host')
    stat.decrement(what='rescued', host='host')
    assert stat.rescued['host'] == 0

    # assert ignored decrement
    stat.increment(what='ignored', host='host')
    stat.decre

# Generated at 2022-06-10 23:35:10.019071
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggr_stats = AggregateStats()
    aggr_stats.increment('ok', 'host')
    aggr_stats.increment('ok', 'host1')

    assert aggr_stats.ok.get('host', 0) == 1
    assert aggr_stats.ok.get('host1', 0) == 1

    aggr_stats.decrement('ok', 'host')
    assert aggr_stats.ok.get('host', 0) == 0
    assert aggr_stats.ok.get('host1', 0) == 1

    aggr_stats.decrement('ok', 'host1')
    assert aggr_stats.ok.get('host', 0) == 0
    assert aggr_stats.ok.get('host1', 0) == 0



# Generated at 2022-06-10 23:35:15.050659
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'test')
    assert stats.ok.get('test') == 0
    stats.increment('ok', 'test')
    stats.increment('ok', 'test')
    assert stats.ok.get('test') == 2
    stats.decrement('ok', 'test')
    assert stats.ok.get('test') == 1
    stats.decrement('ok', 'test')
    assert stats.ok.get('test') == 0


# Generated at 2022-06-10 23:35:23.375129
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # initialize a new instance of AggregateStats
    ag = AggregateStats()

    # verify zero hosts
    assert len(ag.ok) == 0

    # increment some stats
    ag.increment('ok', 'somehost')
    ag.increment('failures', 'somehost')
    ag.increment('ok', 'otherhost')
    ag.increment('failures', 'otherhost')

    # verify two hosts
    assert len(ag.ok) == 2

    # decrement some stats
    ag.decrement('ok', 'somehost')
    ag.decrement('failures', 'somehost')
    ag.decrement('ok', 'otherhost')
    ag.decrement('failures', 'otherhost')

    # verify zero hosts again
    assert len(ag.ok) == 0

    # decre

# Generated at 2022-06-10 23:35:26.266607
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    stats = AggregateStats()
    stats.increment('failures', 'test_host')
    assert stats.failures['test_host'] == 1
    stats.decrement('failures', 'test_host')
    assert stats.failures['test_host'] == 0

# Generated at 2022-06-10 23:35:32.443354
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok = {'host': 2}
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 1

    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 0

    # test for negative values.
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 0

# Generated at 2022-06-10 23:35:42.453364
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Test set up of original values
    stats = AggregateStats()
    host = 'myhost'
    stats.increment("ok", host)
    stats.increment("ok", host)
    stats.increment("ok", host)
    stats.increment("failures", host)
    stats.increment("failures", host)
    stats.increment("dark", host)
    stats.increment("dark", host)
    stats.increment("dark", host)
    stats.increment("dark", host)
    stats.increment("changed", host)
    stats.increment("skipped", host)
    stats.increment("skipped", host)
    stats.increment("skipped", host)
    stats.increment("skipped", host)
    stats.increment("rescued", host)
   

# Generated at 2022-06-10 23:35:50.079684
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Test the method decrement of class AggregateStats
    # Creates the following objects and calls the method decrement
    # Expected result:
    #   - If a statistic was incremented, it is decremented by 1
    #   - If a statistic was not incremented, the value is 0
    #   - If a statistic was incremented more than once, it is decremented by 1
    # Cases:
    #   ok, failures, dark, changed, skipped, rescued, ignored
    _stats = AggregateStats()
    for s in ['ok', 'failures', 'dark', 'changed', 'skipped', 'rescued', 'ignored']:
        _host = 'testhost'
        _stats.increment(s, _host)
        _stats.increment(s, _host)

# Generated at 2022-06-10 23:35:54.979579
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    astats = AggregateStats()
    astats.decrement('ok', 'localhost')
    assert astats.ok == {'localhost': 0}
    astats.ok['localhost'] = 1
    astats.decrement('ok', 'localhost')
    assert astats.ok == {'localhost': 0}


# Generated at 2022-06-10 23:35:58.001157
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.failures['localhost'] = 1
    aggregate_stats.changed['localhost'] = 1
    aggregate_stats.decrement('failures', 'localhost')

    assert aggregate_stats.failures['localhost'] == 0
    assert aggregate_stats.changed['localhost'] == 1
    aggregate_stats.decrement('changed', 'localhost')
    assert aggregate_stats.changed['localhost'] == 0

# Generated at 2022-06-10 23:36:04.255396
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    agg = AggregateStats()
    agg.update_custom_stats('test_str', 'str value', 'host1')
    assert agg.custom['host1']['test_str'] == 'str value'
    agg.update_custom_stats('test_str', 'str value')
    assert agg.custom['_run']['test_str'] == 'str value'
    agg.update_custom_stats('test_int', 5, 'host1')
    assert agg.custom['host1']['test_int'] == 5
    agg.update_custom_stats('test_int', 5)
    assert agg.custom['_run']['test_int'] == 5
    agg.update_custom_stats('test_dict', {'a': 1, 'b': 2}, 'host1')

# Generated at 2022-06-10 23:36:16.764412
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    agg_stats = AggregateStats()

    # update_custom_stats called with host is None
    agg_stats.update_custom_stats('foo', 'bar')
    assert agg_stats.custom['_run']['foo'] == 'bar'

    agg_stats.update_custom_stats('foo', 'spam', 'localhost')
    assert agg_stats.custom['localhost']['foo'] == 'spam'

    # add a new stat (dict) for host localhost
    agg_stats.update_custom_stats('a', {'b': 1}, 'localhost')
    assert agg_stats.custom['localhost']['a'] == {'b': 1}

    # add a new stat (list) for host localhost
    agg_stats.update_custom_stats('c', ['d'], 'localhost')
    assert agg_

# Generated at 2022-06-10 23:36:25.727178
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import yaml

    def deep_equals(a, b):
        ''' compare two data structures'''

        return yaml.dump(a) == yaml.dump(b)

    # Test with a custom stat of type hash
    custom_stats = {'name': 'ansible', 'version': 2.0}
    a = AggregateStats()
    a.update_custom_stats('custom_stats', custom_stats)
    a.update_custom_stats('custom_stats', custom_stats)
    assert deep_equals(a.custom['_run']['custom_stats'], custom_stats)

    # Tests for mismatching data types
    a.update_custom_stats('custom_stats2', custom_stats)
    a.update_custom_stats('custom_stats2', 'mismatching type')
    assert deep

# Generated at 2022-06-10 23:36:35.238721
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('test_map', {"key1": "val1"})
    print(stats.custom)
    print(stats.custom['_run']['test_map'])
    stats.update_custom_stats('test_str', "val1")
    print(stats.custom)
    print(stats.custom['_run']['test_str'])
    stats.update_custom_stats('test_map', {"key2": "val2"})
    print(stats.custom)
    print(stats.custom['_run']['test_map'])
    stats.update_custom_stats('test_str', "val2")
    print(stats.custom)
    print(stats.custom['_run']['test_str'])
    stats.update_

# Generated at 2022-06-10 23:36:37.664773
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    agg_stats = AggregateStats()
    agg_stats.update_custom_stats("some-key", 3)

    assert agg_stats.custom["_run"]["some-key"] == 3

# Generated at 2022-06-10 23:36:41.315716
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    result = AggregateStats()
    result.ok = dict(test="test")
    result.decrement("ok", "test")
    assert result.ok == dict(test=0)


# Generated at 2022-06-10 23:36:48.356188
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    values = {
        
    }

    obj = AggregateStats()
    for (key, val) in values.items():
        setattr(obj, key, val)
    expected = {
        'processed': {},
        'failures': {},
        'ok': {},
        'dark': {},
        'changed': {},
        'skipped': {},
        'rescued': {},
        'ignored': {},
        'custom': {},
    }

    output = obj.decrement('skipped', 'localhost')
    assert output == None
    assert obj.__dict__ == expected


# Generated at 2022-06-10 23:36:53.016261
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('failures', 'localhost')
    stats.decrement('failures', 'localhost')
    assert dict(failures={'localhost': 0}) == stats.__dict__



# Generated at 2022-06-10 23:36:59.056947
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    from nose.tools import assert_equals

    # Testing "ok" value for host
    stats = AggregateStats()
    stats.ok['Host'] = 2

    stats.decrement('ok', 'Host')
    assert_equals(stats.ok['Host'], 1)
    stats.decrement('ok', 'Host')
    assert_equals(stats.ok['Host'], 0)

    stats.decrement('ok', 'Host')
    assert_equals(stats.ok['Host'], 0)

    # Testing "dark" value for host
    stats = AggregateStats()
    stats.dark['Host'] = 2

    stats.decrement('dark', 'Host')
    assert_equals(stats.dark['Host'], 1)
    stats.decrement('dark', 'Host')
    assert_

# Generated at 2022-06-10 23:37:04.485202
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.failures.update({"1":2, "2":1, "3":1})
    stats.decrement('failures', "1")
    assert stats.failures == {"1":1, "2":1, "3":1}
    stats.decrement('failures', "4")
    assert stats.failures == {"1":1, "2":1, "3":1}
    stats.decrement('failures', "2")
    assert stats.failures == {"1":1, "2":0, "3":1}

# Generated at 2022-06-10 23:37:14.106916
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    for host in ['host1', 'host2', 'host3']:
        for what in ['ok', 'failures', 'dark', 'changed', 'skipped', 'rescued', 'ignored']:
            stats.increment(what, host)
    for host in ['host1', 'host2', 'host3']:
        stats.decrement('ok', host)
        assert stats.ok[host] == 0
    assert stats.ok['host4'] is not defined

if __name__ == "__main__":
    test_AggregateStats_decrement()

# Generated at 2022-06-10 23:37:21.646133
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg_stats = AggregateStats()
    agg_stats.increment('ok', 'host1')
    assert agg_stats.ok['host1'] == 1
    agg_stats.decrement('ok', 'host1')
    assert agg_stats.ok['host1'] == 0
    # This should not decrement the count, since it has not been incremented
    agg_stats.decrement('ok', 'host1')
    assert agg_stats.ok['host1'] == 0
    agg_stats.increment('ok', 'host1')
    assert agg_stats.ok['host1'] == 1
    # This should decrement the count
    agg_stats.decrement('ok', 'host1')
    assert agg_stats.ok['host1'] == 0

# Generated at 2022-06-10 23:37:26.505469
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    host = "testhost"
    stat = "ok"

    # Check that initial decrement is handled properly
    stats.decrement(stat, host)
    assert stats.ok.get(host) == 0

    # Check that decrementing is handled properly
    stats.increment(stat, host)
    assert stats.ok.get(host) == 1
    stats.decrement(stat, host)
    assert stats.ok.get(host) == 0


# Generated at 2022-06-10 23:37:29.051788
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg = AggregateStats()
    agg.increment("ok", "test")
    agg.decrement("ok", "test")

    assert agg.ok.get("test", 0) == 0



# Generated at 2022-06-10 23:37:36.784870
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', '_run')
    assert 'ok' in stats.ok
    assert stats.ok.get('_run') == 1
    stats.decrement('ok', '_run')
    assert stats.ok.get('_run') == 0

    try:
        stats.decrement('ok', '_run')
        assert False
    except:
        assert True

    try:
        stats.ok['_run'] = -1
        stats.decrement('ok', '_run')
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-10 23:37:40.331389
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    stats.ok = {'test': 1}
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 0

    # This should never happen, but let's be safe
    stats.ok = {'test': 1}
    stats.decrement('ok', 'test')
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 0


# Generated at 2022-06-10 23:37:45.156534
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    stat_instance = AggregateStats()
    stat_instance.ok = {'127.0.0.1': 1, '192.168.1.4': 1, '192.168.1.5': 0}

    stat_instance.decrement('ok', '127.0.0.1')
    assert '127.0.0.1' in stat_instance.ok and stat_instance.ok['127.0.0.1'] == 0
    stat_instance.decrement('ok', '127.0.0.1')
    assert '127.0.0.1' in stat_instance.ok and stat_instance.ok['127.0.0.1'] == 0
    stat_instance.decrement('ok', '192.168.1.4')
    assert '192.168.1.4' in stat_

# Generated at 2022-06-10 23:37:53.584890
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', '127.0.0.1')
    stats.decrement('ok', '127.0.0.1')
    stats.decrement('ok', '127.0.0.2')
    assert '127.0.0.1' in stats.ok
    assert '127.0.0.2' in stats.ok
    assert stats.ok.get('127.0.0.1') == 0
    assert stats.ok.get('127.0.0.2') == 0


# Generated at 2022-06-10 23:37:58.938155
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    def mockFailuresget(self, key, other):
        return dict(foo=1)

    agg = AggregateStats()
    agg.failures = dict(foo=1)

    import mock
    with mock.patch.object(agg, 'failures', new=mock.PropertyMock(side_effect=mockFailuresget)):
        agg.decrement('failures', 'foo')

    assert agg.failures.get('foo', 0) == 0

    # Exponential backoff
    agg.decrement('failures', 'foo')
    assert agg.failures.get('foo', 0) == 0

# Generated at 2022-06-10 23:38:06.098146
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    base_aggregate_stats = AggregateStats()
    base_aggregate_stats.decrement("ok", "localhost")
    assert base_aggregate_stats.ok.get("localhost", 1) == 0
    base_aggregate_stats.decrement("ok", "localhost")
    assert base_aggregate_stats.ok.get("localhost", 1) == 0
    base_aggregate_stats.increment("ok", "localhost")
    base_aggregate_stats.increment("ok", "localhost")
    assert base_aggregate_stats.ok.get("localhost", 1) == 2
    base_aggregate_stats.decrement("ok", "localhost")
    assert base_aggregate_stats.ok.get("localhost", 1) == 1

# Generated at 2022-06-10 23:38:10.801692
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ignored', '127.0.0.1')
    assert stats.ignored['127.0.0.1'] == 1
    stats.decrement('ignored', '127.0.0.1')
    assert stats.ignored['127.0.0.1'] == 0

# Generated at 2022-06-10 23:38:20.769251
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    '''
        ensure that AggregateStats.decrement() is working as expected.
        That method should decrement a specific counter for a specific host.
        If the counter was not yet set, it will be set to 0, then decremented.
        If the counter is already at 0, it will remain at 0.
        If the counter is < 0, which should not happen, it will be reset to 0
    '''
    fail_stats = AggregateStats()
    ok_stats = AggregateStats()
    empty_host = "1.2.3.4"
    empty_host_2 = "2.2.2.2"
    empty_host_3 = "3.3.3.3"

    # init
    fail_stats.increment("ok", empty_host)

# Generated at 2022-06-10 23:38:23.951098
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok['host1'] = 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 0

# Generated at 2022-06-10 23:38:28.377212
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('failures', 'host1')
    stats.increment('failures', 'host1')
    stats.increment('failures', 'host1')

    assert stats.failures.get('host1') == 3
    stats.decrement('failures', 'host1')
    assert stats.failures.get('host1') == 2

# Generated at 2022-06-10 23:38:31.725209
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'test')
    assert stats.ok['test'] == 1
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 0
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 0



# Generated at 2022-06-10 23:38:37.137156
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    stats = AggregateStats()

    stats.increment('array', 'some name')
    stats.decrement('array', 'some name')
    assert stats.array == {}
    stats.decrement('array', 'some name')
    assert stats.array == {}

    stats.increment('array', 'some name')
    stats.increment('array', 'some name')
    stats.increment('array', 'some name')
    stats.decrement('array', 'some name')
    assert stats.array['some name'] == 2
    stats.decrement('array', 'some name')
    assert stats.array['some name'] == 1
    stats.decrement('array', 'some name')
    assert stats.array == {}


# Generated at 2022-06-10 23:38:43.599787
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    x = AggregateStats()
    x.increment('ignored', 'testhost')
    assert x.ignored['testhost'] == 1
    # decrement of an existing host
    x.decrement('ignored', 'testhost')
    assert x.ignored['testhost'] == 0
    # decrement of a non existing host
    x.decrement('ignored', 'non-exist-host')
    assert x.ignored['non-exist-host'] == 0
    # decrement with negative value should not change anything
    x.decrement('ignored', 'testhost')
    assert x.ignored['testhost'] == 0

# Generated at 2022-06-10 23:39:01.858991
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    what = 'ok'
    aggregate_stats.ok = {'localhost': 0}
    aggregate_stats.increment(what, 'localhost')
    aggregate_stats.increment(what, 'localhost')
    aggregate_stats.increment(what, 'localhost')
    aggregate_stats.increment(what, 'localhost')
    aggregate_stats.increment(what, 'localhost')
    aggregate_stats.decrement(what, 'localhost')
    aggregate_stats.decrement(what, 'localhost')
    assert aggregate_stats.ok['localhost'] == 3
    # This should never happen, but let's be safe
    aggregate_stats.decrement(what, 'localhost')
    aggregate_stats.decrement(what, 'localhost')

# Generated at 2022-06-10 23:39:10.497256
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    import unittest

    # Test decrementing an un-existing key

    stats = AggregateStats()
    stats.decrement('rescued', 'localhost')

    assert stats.rescued.get('localhost',0) == 0

    # test decrementing an existing key

    stats = AggregateStats()
    stats.rescued = {'localhost':1}

    stats.decrement('rescued', 'localhost')

    assert stats.rescued.get('localhost', 0) == 0

    # test decrementing to zero

    stats = AggregateStats()
    stats.rescued = {'localhost': 0}

    stats.decrement('rescued', 'localhost')

    assert stats.rescued.get('localhost', 1) == 0

    # test decrementing negative value

    stats = Aggregate

# Generated at 2022-06-10 23:39:14.838465
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 0
    assert 'host2' in stats.ok
    assert 'host3' in stats.ok
    # This should not fail
    stats.decrement('ok', 'host')
    # This should not fail
    stats.decrement('ok', 'host2')

# Generated at 2022-06-10 23:39:20.617254
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    result_ok = {'_run': {'ok': 0}}
    result_failures = {'_run': {'failures': 0}}
    result_unreachable = {'_run': {'unreachable': 0}}
    result_changed = {'_run': {'changed': 0}}
    result_skipped = {'_run': {'skipped': 0}}
    result_rescued = {'_run': {'rescued': 0}}
    result_ignored = {'_run': {'ignored': 0}}

    stats = AggregateStats()
    stats.increment('ok', '_run')
    stats.increment('failures', '_run')
    stats.increment('dark', '_run')
    stats.increment('changed', '_run')
    stats.increment

# Generated at 2022-06-10 23:39:25.529675
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Test to check that AggregateStats.decrement decrements a statistic
    # (in this case, failures) by a given host
    #
    # Prep variables
    host = 'test_host'
    what = 'failures'

    # Create AggregateStats object
    as_obj = AggregateStats()

    # Check that `what` for `host` is 0
    assert(as_obj.summarize(host)[what] == 0)

    # Increment `what` by 1
    as_obj.increment(what, host)
    assert(as_obj.summarize(host)[what] == 1)

    # Decrement `what` by 1
    as_obj.decrement(what, host)
    assert(as_obj.summarize(host)[what] == 0)


# Generated at 2022-06-10 23:39:26.744784
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    temp = AggregateStats()
    temp.decrement('changed', '1.2.3.4')
    assert(temp.changed['1.2.3.4'] == 0)

# Generated at 2022-06-10 23:39:28.585224
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    a = AggregateStats()
    a.decrement('ok', 'testhost')
    assert a.ok['testhost'] == 0
    a.ok['testhost'] = 1
    a.decrement('ok', 'testhost')
    assert a.ok['testhost'] == 0


# Generated at 2022-06-10 23:39:33.941508
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ag = AggregateStats()

    # test with host name
    ag.increment("ok", "hostname")
    assert ag.ok["hostname"] == 1
    ag.decrement("ok", "hostname")
    assert ag.ok["hostname"] == 0

    # test with host in object
    ag.increment("ok", "hostname")
    assert ag.ok["hostname"] == 1
    ag.decrement("ok", ag.ok["hostname"])
    assert ag.ok["hostname"] == 0

    # test with host not in object
    ag.decrement("ok", "hostname")
    assert ag.ok["hostname"] == 0

    # test with custom hostnames
    ag.decrement("ok", "")
    ag.decrement("ok", 0)

# Generated at 2022-06-10 23:39:44.550346
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg = AggregateStats()
    agg.increment("ok", "some_host")
    agg.increment("ok", "some_host")
    agg.increment("failures", "some_host")
    agg.increment("ok", "another_host")
    agg.increment("dark", "another_host")
    agg.increment("dark", "yet_another_host")

    agg.decrement("ok", "some_host")
    agg.decrement("ok", "some_host")
    agg.decrement("ok", "some_host")
    agg.decrement("failures", "some_host")
    agg.decrement("failures", "some_host")
    agg.decrement("failures", "some_host")

    assert len(agg.ok) == 2


# Generated at 2022-06-10 23:39:50.796135
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('failures', 'host')
    for key in dir(stats):
        if key in ('ok', 'dark', 'changed', 'skipped', 'ignored'):
            assert stats.__getattribute__(key).get('host', None) is None
        elif key in ('rescued', 'failures'):
            assert stats.__getattribute__(key).get('host', None) == 0

# Generated at 2022-06-10 23:40:06.905226
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    adict = {'a':1, 'b':2, 'c':3}
    astats = AggregateStats()
    astats.skipped = adict
    astats.decrement('skipped', 'a')
    astats.decrement('skipped', 'b')
    astats.decrement('skipped', 'c')
    astats.decrement('skipped', 'd')
    tmp = astats.skipped
    assert tmp['a'] == 1
    assert tmp['b'] == 1
    assert tmp['c'] == 1
    assert tmp['d'] == 0

# Generated at 2022-06-10 23:40:12.268443
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggs = AggregateStats()
    aggs.decrement('ok', 'host01')
    aggs.decrement('ok', 'host01')
    assert aggs.ok['host01'] == 0
    assert aggs.ok.get('host02') is None

# Generated at 2022-06-10 23:40:13.928447
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'test_host')

# Generated at 2022-06-10 23:40:17.528970
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Create an instance of AggregateStats
    stats = AggregateStats()
    stats.ok = {"foo": 0}
    stats.decrement("ok", "foo")
    assert stats.ok == {"foo": 0}

# Generated at 2022-06-10 23:40:19.957816
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    # Check that decrement does not fail when the host does not exist in
    # the stat, and check that the stat is still 0
    stats.decrement("ok", "test-host")
    assert stats.ok == {"test-host": 0}

    # Check that decrement does not set the stat to a negative value
    stats.ok["test-host"] = 0
    stats.decrement("ok", "test-host")
    assert stats.ok == {"test-host": 0}

# Generated at 2022-06-10 23:40:24.910141
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Test with a host that exists in the given statistic
    stat = AggregateStats()
    stat.decrement('ok', 'localhost')
    ok_stats = stat.ok
    assert ok_stats['localhost'] == 0
    # Test with a host that doesn't exist in the given statistic
    stat.decrement('ok', '127.0.0.1')
    ok_stats = stat.ok
    assert '127.0.0.1' not in ok_stats


# Generated at 2022-06-10 23:40:28.289967
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok['test'] = 0
    stats.decrement("ok", "test")
    assert stats.ok['test'] == 0

    stats.ok['test'] = 1
    stats.decrement("ok", "test")
    assert stats.ok['test'] == 0

    try:
        stats.decrement("ok", "notest")
        assert False
    except KeyError:
        assert True



# Generated at 2022-06-10 23:40:35.079062
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ag = AggregateStats()
    host = "test_host"

    # Case: Decrement a variable that has never been set
    ag.decrement('ok', host)
    assert ag.ok[host] == 0

    # Case: Decrement a variable with a value of 0
    ag.ok[host] = 0
    ag.decrement('ok', host)
    assert ag.ok[host] == 0

    # Case: Decrement a variable with a value of 1
    ag.ok[host] = 1
    ag.decrement('ok', host)
    assert ag.ok[host] == 0

# Generated at 2022-06-10 23:40:43.717827
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    test_host = 'test_host'

    # Decrement a host's record of unhandled errors
    stats.failures[test_host] = 2
    stats.decrement('failures', test_host)
    assert stats.failures[test_host] == 1

    # Decrement a host's record of unhandled errors but it has already
    # been decremented as much as possible
    stats.decrement('failures', test_host)
    assert stats.failures[test_host] == 0

    # Decrement a non-existing host's failed task count
    stats.decrement('failures', 'non-existing-host')
    assert stats.failures['non-existing-host'] == 0

    # Decrement a non-existing type of statistics for a host
    stats.decrement

# Generated at 2022-06-10 23:40:51.433447
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    def test(host_dict, what, host, expected_result):
        stats = AggregateStats()
        stats.__dict__[what] = host_dict
        stats.decrement(what, host)
        return (stats.__dict__[what] == expected_result)

    assert test({}, "ok", "host1", {"host1": 0})
    assert test({}, "failures", "host1", {"host1": 0})
    assert test({}, "dark", "host1", {"host1": 0})
    assert test({}, "changed", "host1", {"host1": 0})
    assert test({}, "skipped", "host1", {"host1": 0})
    assert test({}, "rescued", "host1", {"host1": 0})