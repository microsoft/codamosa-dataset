

# Generated at 2022-06-10 23:33:43.390414
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Initialize an instance of the AggregateStats class
    astats = AggregateStats()

    # Verify that decrementing the ok attribute fails
    assert not astats.decrement('ok', 'host1')

    # Verify that decrementing the failures attribute fails
    assert not astats.decrement('failures', 'host1')

    # Verify that decrementing the dark attribute fails
    assert not astats.decrement('dark', 'host1')

    # Verify that decrementing the changed attribute fails
    assert not astats.decrement('changed', 'host1')

    # Verify that decrementing the skipped attribute fails
    assert not astats.decrement('skipped', 'host1')

    # Verify that decrementing the rescued attribute fails
    assert not astats.decrement('rescued', 'host1')

# Generated at 2022-06-10 23:33:52.216748
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    assert stats.ok == {'host1': 2}
    stats.decrement('ok', 'host1')
    assert stats.ok == {'host1': 1}
    stats.decrement('ok', 'host2')
    assert stats.ok == {'host1': 1}
    stats.decrement('ok', 'host1')
    assert stats.ok == {'host1': 0}
    stats.decrement('ok', 'host1')
    assert stats.ok == {'host1': 0}

if __name__ == '__main__':
    test_AggregateStats_decrement()

# Generated at 2022-06-10 23:33:55.876872
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    a = AggregateStats()

    a.increment('ok', 'host1')
    a.increment('ok', 'host1')

    a.increment('failures', 'host2')

    assert a.processed == {'host1': 1, 'host2': 1}
    assert a.ok == {'host1': 2}
    assert a.failures == {'host2': 1}



# Generated at 2022-06-10 23:34:03.210519
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('failures', '192.168.1.1')
    stats.increment('failures', '192.168.1.1')
    stats.decrement('failures', '192.168.1.1')
    stats.decrement('failures', '192.168.1.1')
    assert stats.failures['192.168.1.1'] == 0
    stats.decrement('failures', '192.168.1.1')
    assert stats.failures['192.168.1.1'] == 0
    stats.decrement('failures', '192.168.1.1')
    assert stats.failures['192.168.1.1'] == 0
    stats.decrement('failures', '192.168.1.2')

# Generated at 2022-06-10 23:34:08.619013
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    host = 'localhost'
    for i in range(0, 5):
        stats.increment('ok', host)
    for i in range(0, 5):
        stats.decrement('ok', host)
    assert stats.ok[host] == 0
    try:
        for i in range(0, 5):
            stats.decrement('ok', host)
    except:
        pass
    assert stats.ok[host] == 0

# Generated at 2022-06-10 23:34:17.811233
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    from ansible.utils.vars import merge_hash

    stats = AggregateStats()
    stats.increment('ok', 'test_host')
    stats.increment('ok', 'test_host')
    stats.increment('ok', 'test_host')

    assert stats.ok['test_host'] == 3
    assert stats.processed['test_host'] == 1
    assert stats.failures['test_host'] == 0
    assert stats.dark['test_host'] == 0
    assert stats.changed['test_host'] == 0
    assert stats.skipped['test_host'] == 0
    assert stats.rescued['test_host'] == 0
    assert stats.ignored['test_host'] == 0

    stats.decrement('ok', 'test_host')
    assert stats.ok['test_host']

# Generated at 2022-06-10 23:34:21.001542
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host')
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 0


# Generated at 2022-06-10 23:34:28.818349
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('failures', 'host1')
    stats.increment('failures', 'host2')

    stats.decrement('failures', 'host1')
    assert stats.failures['host1'] == 0
    assert stats.failures['host2'] == 1

    stats.decrement('failures', 'host2')
    assert stats.failures['host2'] == 0

    stats.decrement('failures', 'host2')
    assert stats.failures['host2'] == 0

# Generated at 2022-06-10 23:34:39.929205
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

    class MockPlayContext:
        run_handlers = True
        run_tasks = False

    stats = AggregateStats()

    ##########
    # TaskInclude

    def _get_result(is_idle):
        return dict(
            _ansible_is_idle=is_idle
        )

    # +1, no _ansible_is_idle
    mock_task = TaskInclude()
    mock_task.action = 'test'
    mock_task._load_vars = dict()
    mock_task._role = None
    mock_task.name = 'mytest'
    mock_task._parent = Block()
   

# Generated at 2022-06-10 23:34:42.369548
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    from collections import Counter
    assert Counter(AggregateStats().decrement("ok", "test")) == Counter({"test": 0})

# Generated at 2022-06-10 23:34:50.772654
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    global_stats = AggregateStats()

    global_stats.increment("ok", "foo")
    global_stats.increment("ok", "foo")
    global_stats.increment("ok", "foo")
    assert global_stats.ok["foo"] == 3

    global_stats.decrement("ok", "foo")
    assert global_stats.ok["foo"] == 2

    global_stats.decrement("ok", "foo")
    global_stats.decrement("ok", "foo")
    assert global_stats.ok["foo"] == 0

    global_stats.decrement("ok", "foo")
    assert global_stats.ok["foo"] == 0

    global_stats.increment("ok", "foo")
    assert global_stats.ok["foo"] == 1

# Generated at 2022-06-10 23:34:54.385923
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
   agg = AggregateStats()
   agg.increment('ignored', 'host')
   agg.decrement('ignored', 'host')
   assert agg.ignored == {'host': 0}


# Generated at 2022-06-10 23:35:01.141019
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Test a positive result
    a = AggregateStats()
    a.increment('failures', 'host')
    assert a.failures == {'host': 1}
    a.decrement('failures', 'host')
    assert a.failures == {'host': 0}

    # Test a negative result
    a.decrement('failures', 'host')
    assert a.failures == {'host': 0}

# Generated at 2022-06-10 23:35:08.357375
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok['host1'] = 1
    stats.changed['host1'] = 5
    stats.failures['host1'] = 1
    # stats should contain
    # ok = 1, failures = 1 and changed = 5
    # before decrementing
    stats.decrement('ok', 'host1')
    stats.decrement('changed', 'host1')
    stats.decrement('failures', 'host1')
    # now after decrementing
    # ok = 0, failures = 0 and changed = 4
    assert stats.ok['host1'] == 0
    assert stats.changed['host1'] == 4
    assert stats.failures['host1'] == 0



# Generated at 2022-06-10 23:35:13.781665
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    assert stats.ok == {}
    stats.increment("ok", "test")
    assert stats.ok == {"test": 1}
    stats.increment("ok", "test")
    assert stats.ok == {"test": 2}
    stats.decrement("ok", "test")
    assert stats.ok == {"test": 1}
    stats.decrement("ok", "test")
    assert stats.ok == {"test": 0}
    stats.decrement("ok", "test")
    assert stats.ok == {"test": 0}

if __name__ == '__main__':
    test_AggregateStats_decrement()

# Generated at 2022-06-10 23:35:16.278014
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg_stats = AggregateStats()
    agg_stats.dark['test_host'] = 1
    agg_stats.decrement('dark', 'test_host')
    assert agg_stats.dark['test_host'] == 0

# Generated at 2022-06-10 23:35:19.575465
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.skipped = {'test_host_0': 1}
    stats.decrement('skipped', 'test_host_0')
    assert stats.skipped['test_host_0'] == 0


# Generated at 2022-06-10 23:35:24.396958
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ast = AggregateStats()
    ast.decrement("ok", "localhost")
    assert ast.ok["localhost"] == 0

    ast.ok["localhost"] = 5
    ast.dark["localhost"] = 5
    ast.increment("ok", "localhost")
    ast.increment("dark", "localhost")
    ast.decrement("ok", "localhost")
    ast.decrement("dark", "localhost")
    assert ast.ok["localhost"] == 5
    assert ast.dark["localhost"] == 5


# Generated at 2022-06-10 23:35:28.473696
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggStats = AggregateStats()
    aggStats.ok['host1'] = 2
    aggStats.decrement('ok', 'host1')
    assert aggStats.ok['host1'] == 1
    # Should not be less than 0
    aggStats.decrement('ok', 'host1')
    assert aggStats.ok['host1'] == 0
    aggStats.decrement('ok', 'host1')
    assert aggStats.ok['host1'] == 0

# Generated at 2022-06-10 23:35:35.476960
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stat = AggregateStats()
    stat.ok['blah'] = 1
    stat.decrement('ok', 'blah')
    assert stat.ok['blah'] == 0

    # Test decrementing nonexistent host
    stat.decrement('ok', 'blah')
    assert stat.ok['blah'] == 0

    # Test decrementing nonexistent attribute
    stat.decrement('fakie', 'blahblah')
    assert 'fakie' not in stat.__dict__
