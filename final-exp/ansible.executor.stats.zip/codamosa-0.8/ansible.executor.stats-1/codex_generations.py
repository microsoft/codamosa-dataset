

# Generated at 2022-06-10 23:33:40.740736
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ag = AggregateStats()
    ag.increment("ok", "127.0.0.1")
    ag.increment("ok", "127.0.0.1")

    assert ag.ok["127.0.0.1"] == 2
    ag.decrement("ok", "127.0.0.1")
    assert ag.ok["127.0.0.1"] == 1
    ag.decrement("ok", "127.0.0.1")
    assert ag.ok["127.0.0.1"] == 0

    # Should be safe
    ag.decrement("ok", "127.0.0.1")
    assert ag.ok["127.0.0.1"] == 0


# Generated at 2022-06-10 23:33:42.563149
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    s = AggregateStats()
    s.increment("failures", "localhost")
    assert s.failures["localhost"] == 1
    s.decrement("failures", "localhost")
    assert s.failures["localhost"] == 0


# Generated at 2022-06-10 23:33:50.167598
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ag = AggregateStats()
    ag.increment("ok", "localhost")
    assert(ag.ok["localhost"]==1)
    assert(ag.processed["localhost"]==1)
    ag.increment("ok", "localhost")
    assert(ag.ok["localhost"]==2)
    assert(ag.processed["localhost"]==1)
    ag.increment("failures", "localhost")
    assert(ag.ok["localhost"]==2)
    assert(ag.failures["localhost"]==1)
    assert(ag.processed["localhost"]==1)


# Generated at 2022-06-10 23:33:56.018302
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    result = AggregateStats()
    result.ignored["abraham"] = 0
    result.ignored["bart"] = 1
    result.decrement("ignored", "bart")
    assert result.ignored["abraham"] == 0
    assert result.ignored["bart"] == 0
    result.ignored["abraham"] = 0
    result.ignored["bart"] = 1
    result.decrement("ignored", "lisa")
    assert result.ignored["abraham"] == 0
    assert result.ignored["bart"] == 1

# Generated at 2022-06-10 23:33:59.703663
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    test = AggregateStats()
    test.increment('ok', '127.0.0.1')
    assert test.ok['127.0.0.1'] == 1
    test.increment('ok', '127.0.0.1')
    assert test.ok['127.0.0.1'] == 2


# Generated at 2022-06-10 23:34:01.497291
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-10 23:34:05.629369
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    stats.increment('failures', 'host_name')
    assert stats.failures['host_name'] == 1

    stats.decrement('failures', 'host_name')
    assert stats.failures['host_name'] == 0

# Generated at 2022-06-10 23:34:14.484545
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

if __name__ == '__main__':
    import sys
    # Run only test_AggregateStats_decrement if it was specified on the command line
    test_functions = {
        'test_AggregateStats_decrement': test_AggregateStats_decrement,
    }

# Generated at 2022-06-10 23:34:22.414996
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    host_name = "test-host"

    # Test initial case
    init_state = stats.processed.get(host_name)
    assert init_state is None

    # Test incrementing
    stats.increment("ok", host_name)
    assert stats.processed[host_name] == 1
    assert stats.ok[host_name] == 1

    # Test adding a second value
    stats.increment("skipped", host_name)
    assert stats.skipped[host_name] == 1



# Generated at 2022-06-10 23:34:30.779551
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()
    
    # Set the values to increment
    aggregate_stats.changed[aggregate_stats.changed.keys()[0]] = 1

    assert aggregate_stats.changed.keys()[0] == 'ok'
    assert aggregate_stats.changed.values()[0] == 1
    assert aggregate_stats.processed.keys()[0] == 'ok'
    assert aggregate_stats.processed.values()[0] == 0
    
    # Call to the method increment
    aggregate_stats.increment('ok', 'ok')
    
    assert aggregate_stats.changed.keys()[0] == 'ok'
    assert aggregate_stats.changed.values()[0] == 1
    assert aggregate_stats.processed.keys()[0] == 'ok'
    assert aggregate_stats.processed

# Generated at 2022-06-10 23:34:44.819460
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    agg = AggregateStats()
    agg.update_custom_stats('x', {'x': 1}, 'bigdata1')
    agg.update_custom_stats('x', {'y': 2}, 'bigdata1')
    agg.update_custom_stats('x', 3, 'bigdata1')
    agg.update_custom_stats('x', {'z': 4}, 'bigdata1')
    agg.update_custom_stats('x', {'z': 5}, 'bigdata1')
    agg.update_custom_stats('x', 'Hello', 'bigdata1')

    agg.update_custom_stats('x', {'x': 6}, 'bigdata2')
    agg.update_custom_stats('x', {'y': 7}, 'bigdata2')

# Generated at 2022-06-10 23:34:51.523128
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Create an instance of AggregateStats
    aggregate_stats = AggregateStats()

    # Create a dict to use as custom stat
    dict_to_use = dict()
    dict_to_use['foo'] = 1
    dict_to_use['foobar'] = "foo"

    # Update custom stat
    aggregate_stats.update_custom_stats('my_custom_stat', dict_to_use)
    # Assert expected dict
    assert(aggregate_stats.custom['_run']['my_custom_stat'] == dict_to_use)

    # Update custom stat with some other dict
    dict_to_use = dict()
    dict_to_use['foo'] = 42
    dict_to_use['bar'] = "foo"

# Generated at 2022-06-10 23:35:02.377401
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats("test", 1)
    assert stats.custom["_run"]["test"] == 1
    stats.update_custom_stats("test", 1)
    assert stats.custom["_run"]["test"] == 2
    stats.update_custom_stats("test", 1, host="toto")
    assert stats.custom["_run"]["test"] == 2
    assert stats.custom["toto"]["test"] == 1
    assert stats.custom["toto"].get("tata") is None
    assert stats.custom["toto"].get("test") == 1
    dict1 = {"h1": {"i1": "v1", "i2": "v2"}, "h2": "v2"}

# Generated at 2022-06-10 23:35:10.284052
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    a = AggregateStats()

    # Set 'ok' to 3 for host 'host1'
    a.increment('ok', 'host1')
    a.increment('ok', 'host1')
    a.increment('ok', 'host1')
    a.decrement('ok', 'host1')

    if a.ok['host1'] != 2:
        raise AssertionError('decrement did not subtract from ok')
    if a.failures.get('host1', None) is not None:
        raise AssertionError('decrement added failure for host1')
    if a.ok.get('host2', None) is not None:
        raise AssertionError('decrement added ok for host2')

    # Attempt to decrement below 0
    a.decrement('ok', 'host1')

# Generated at 2022-06-10 23:35:15.255347
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    ''' test for method update_custom_stats of class AggregateStats '''

    # Setup a specific class instance for test
    agg_stats = AggregateStats()

    # First time, create a custom stat
    agg_stats.update_custom_stats('foo', 1)
    assert agg_stats.custom == {'_run': {'foo': 1}}

    # Second time, update a custom stat
    agg_stats.update_custom_stats('foo', 2)
    assert agg_stats.custom == {'_run': {'foo': 3}}



# Generated at 2022-06-10 23:35:23.634350
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    class TestException(Exception):
        pass

    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    stats = AggregateStats()

    # empty stats
    assert stats.decrement("ok", "testhost") == None

    stats.ok = {"testhost": 0}
    assert stats.decrement("ok", "testhost") == 0

    stats.ok = {"testhost": 1}
    assert stats.decrement("ok", "testhost") == 0

    stats.ok = {"testhost": 2}
    assert stats.decrement("ok", "testhost") == 1

    # set custom stats with bad value
    stats.set_custom_stats("bad_stat", None)

# Generated at 2022-06-10 23:35:33.672111
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible import constants
    from ansible.utils.color import stringc
    from ansible.utils.vars import combine_vars
    import json
    import copy

    AGS = AggregateStats()

    host1 = "host1"
    host2 = "host2"
    host3 = "host3"
    host4 = "host4"
    host5 = "host5"
    host6 = "host6"
    host7 = "host7"
    host8 = "host8"
    host9 = "host9"
    host10 = "host10"

    # test_update_custom_stats_incr_1
    AGS.set_custom_stats("verbose", 1, host1)
    AGS.update_custom_stats("verbose", 0, host2)
    AGS.update

# Generated at 2022-06-10 23:35:43.380679
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # a few unittests for the AggregateStats class
    from ansible.playbook.play_context import PlayContext

    stats = AggregateStats()
    stats.increment('ok', 'foo')
    stats.increment('changed', 'bar')
    stats.increment('dark', 'baz')

    assert stats.summarize('foo') == dict(ok=1, failures=0, unreachable=0, changed=0, skipped=0, rescued=0, ignored=0)
    assert stats.summarize('bar') == dict(ok=0, failures=0, unreachable=0, changed=1, skipped=0, rescued=0, ignored=0)

# Generated at 2022-06-10 23:35:47.713536
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 42)
    assert stats.custom == {'_run': {'foo': 42}}
    stats.update_custom_stats('foo', 42)
    assert stats.custom == {'_run': {'foo': 84}}
    stats.update_custom_stats('foo', 42, 'bar')

# Generated at 2022-06-10 23:35:51.674807
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1
