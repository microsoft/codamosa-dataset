

# Generated at 2022-06-10 23:33:30.859456
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ags = AggregateStats()
    ags.ok = {"test": 1}
    ags.decrement("ok", "test")
    assert ags.ok["test"] == 0
    assert ags.processed["test"] == 1



# Generated at 2022-06-10 23:33:40.906293
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import json
    import sys

    def main():
        stats = AggregateStats()
        stats.set_custom_stats('blah', {'a': 1, 'b': {'c': 5}})

        if stats.custom['_run']['blah'] != {'a': 1, 'b': {'c': 5}}:
            sys.stderr.write('FAILED: expected ' + json.dumps({'a': 1, 'b': {'c': 5}}) + '\n')
            sys.stderr.write('      : got ' + json.dumps(stats.custom['_run']['blah']) + '\n')
            sys.exit(1)


# Generated at 2022-06-10 23:33:44.522375
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok = dict(localhost=1)
    stats.decrement("ok", "localhost")
    assert stats.ok["localhost"] == 0
    stats.decrement("ok", "localhost")
    assert stats.ok["localhost"] == 0
    assert stats.processed["localhost"] == 0


# Generated at 2022-06-10 23:33:48.568109
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
  aggstats = AggregateStats()
  host = 'hostname'

  for i in ['ok', 'failures', 'dark', 'changed', 'skipped', 'rescued', 'ignored']:
    aggstats.increment(i, host)
    assert aggstats.summarize(host)[i] == 1
    # Incrementing something twice should increment the stat by two
    aggstats.increment(i, host)
    assert aggstats.summarize(host)[i] == 2



# Generated at 2022-06-10 23:33:49.959109
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("dark", "localhost")
    assert stats.dark["localhost"] == 1

# Generated at 2022-06-10 23:33:55.010175
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # should raise key Error when value is less than 0
    agg_stats = AggregateStats()
    agg_stats.processed = {'host1': 1}
    agg_stats.skipped = {'host1': 0}
    assert agg_stats.skipped['host1'] - 1 < 0
    try:
        agg_stats.decrement('skipped', 'host1')
    except KeyError as e:
        assert 'Don\'t be so negative' in e.args[0]

# Generated at 2022-06-10 23:33:59.312187
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    stats.increment('skipped', 'fake')
    stats.increment('skipped', 'fake')
    assert stats.skipped['fake'] == 2

    stats.decrement('skipped', 'fake')
    assert stats.skipped['fake'] == 1

    stats.decrement('skipped', 'fake2')
    assert stats.skipped['fake2'] == 0

# Generated at 2022-06-10 23:34:03.420625
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment("ok", "localhost")
    stats.increment("ok", "localhost")
    stats.decrement("ok", "localhost")
    assert stats.ok == {"localhost": 1}
    stats.decrement("ok", "localhost")
    assert stats.ok == {"localhost": 0}
    stats.ok["localhost"] = 1
    stats.decrement("ok", "localhost")
    assert stats.ok == {"localhost": 0}

# Generated at 2022-06-10 23:34:12.020866
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    agg_stats = AggregateStats()

    agg_stats.set_custom_stats('failed_reasons', {'failed': 1})
    agg_stats.set_custom_stats('failed_reasons', {'failed': 3})
    agg_stats.set_custom_stats('changed_when_results', {'changed': 1})
    agg_stats.set_custom_stats('changed_when_results', {'changed': 3})
    agg_stats.set_custom_stats('changed_when_results', {'failed': 1})
    agg_stats.set_custom_stats('changed_when_results', {'ok': 1})
    agg_stats.set_custom_stats('changed_when_results', {'skipped': 1})


# Generated at 2022-06-10 23:34:17.704890
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ag_stat = AggregateStats()
    ag_stat.increment('ok', '127.0.0.1')
    ag_stat.increment('ok', '127.0.0.2')

    assert 1 == ag_stat.ok['127.0.0.1']
    assert 1 == ag_stat.ok['127.0.0.2']
    assert 2 == len(ag_stat.ok)


# Generated at 2022-06-10 23:34:29.675420
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    # Mocking the imports
    import collections

    global MutableMapping
    global merge_hash

    class MutableMapping(collections.Mapping): pass
    def merge_hash(a, b): return a + b

    # Setting up variables
    aggregate = AggregateStats()
    aggregate.custom = {}
    aggregate.custom['host'] = {}
    host = 'host'
    which = 'which'
    what = 'what'

    # Testing the merge of a string
    aggregate.update_custom_stats(which, what, host)
    assert aggregate.custom[host][which] == what + what

    # Testing the merge of an array
    what = ['foo', 'bar']
    aggregate.update_custom_stats(which, what, host)

# Generated at 2022-06-10 23:34:40.520693
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    from ansible.module_utils.common._collections_compat import MutableMapping
    # Test for the decrement method when the variable contain a positive value
    ast = AggregateStats()
    ast.processed = {'testhost': 1}
    ast.failures = {'testhost': 1}
    ast.ok = {'testhost': 1}
    ast.dark = {'testhost': 1}
    ast.changed = {'testhost': 1}
    ast.skipped = {'testhost': 1}
    ast.rescued = {'testhost': 1}
    ast.ignored = {'testhost': 1}

    ast.decrement('failures', 'testhost')
    ast.decrement('ok', 'testhost')
    ast.decrement('dark', 'testhost')


# Generated at 2022-06-10 23:34:45.647729
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats('failures', "1")
    assert aggregate_stats.custom['_run']['failures'] == "1"

    aggregate_stats.update_custom_stats('failures', "2")
    assert aggregate_stats.custom['_run']['failures'] == "12"



# Generated at 2022-06-10 23:34:47.901377
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agstats = AggregateStats()
    agstats.increment('ok', 'test')
    agstats.decrement('ok', 'test')
    assert agstats.ok['test'] == 0

# Generated at 2022-06-10 23:34:54.764048
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    asgs = AggregateStats()

    asgs.update_custom_stats("custom1", 2, "a")
    assert 2 == asgs.custom["a"]["custom1"]

    asgs.update_custom_stats("custom1", 3, "a")
    assert 5 == asgs.custom["a"]["custom1"]

    asgs.update_custom_stats("custom3", { "A": 1, "B": 2 }, "b")
    assert { "A": 1, "B": 2 } == asgs.custom["b"]["custom3"]

    asgs.update_custom_stats("custom3", { "C": 3 }, "b")
    assert { "A": 1, "B": 2, "C": 3 } == asgs.custom["b"]["custom3"]

    asgs.update_custom_

# Generated at 2022-06-10 23:35:05.292181
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    def assert_update_custom_stats(mapping, custom_stats, which, what, host=None, final_mapping=None):
        # assert custom_stats == final_mapping
        astats = AggregateStats()
        astats.custom = mapping
        astats.update_custom_stats(which, what, host)
        assert astats.custom == custom_stats


    # Rollback custom_stats to initial state
    def rollback_custom_stats(mapping, custom_stats):
        mapping['_run'] = custom_stats['_run']


    # Define initial state
    mapping = {'_run': {'first_key': None, 'second_key': None, 'third_key':None}}

# Generated at 2022-06-10 23:35:12.457365
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import os
    import sys
    import unittest2 as unittest
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import MutableMapping

    class TestAggregateStats(unittest.TestCase):
        def setUp(self):
            self.aggregate_stats = AggregateStats()
            self.aggregate_stats.custom={'run': {'host1': {'collection':{'key1':'val1', 'key2': 'val2'}, 'command':{'key1':'val1', 'key2': 'val2'}, 'context':{'key1':'val1', 'key2': 'val2'}}}}

        def tearDown(self):
            pass


# Generated at 2022-06-10 23:35:18.388943
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    agg = AggregateStats()
    agg.update_custom_stats('test', 1)
    agg.update_custom_stats('test', 2)
    assert agg.custom['_run']['test'] == 3

    agg.update_custom_stats('test', {'a': 1})
    assert agg.custom['_run']['test'] == {'a': 1}

    agg.update_custom_stats('test', {'b': 1})
    assert agg.custom['_run']['test'] == {'a': 1, 'b': 1}

    agg.update_custom_stats('test', {'a': 1, 'b': 1})
    assert agg.custom['_run']['test'] == {'a': 2, 'b': 2}


# Generated at 2022-06-10 23:35:26.514642
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.utils import common

    # Create a new instance of class AggregateStats
    agg_stats = AggregateStats()

    # Update a custom stats for host "localhost"
    agg_stats.set_custom_stats("http_status", 200, "localhost")
    assert agg_stats.custom.get("localhost").get("http_status") == 200

    # Update a custom stats for a host
    agg_stats.update_custom_stats("http_status", 200)
    assert agg_stats.custom.get("_run").get("http_status") == 200
    agg_stats.update_custom_stats("http_status", -200)
    assert agg_stats.custom.get("_run").get("http_status") == 0

    # Update a custom stats for a host with mismatching types
    agg_stats.update_custom_

# Generated at 2022-06-10 23:35:33.559896
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggr_stats = AggregateStats()

    aggr_stats.processed = {'host': 1}
    aggr_stats.ok = {'host': 1}
    aggr_stats.ignored = {'host': 3}
    aggr_stats.decrement('ignored', 'host')

    assert 'host' in aggr_stats.ignored
    assert aggr_stats.ignored['host'] == 2
    assert 'host' not in aggr_stats.failures