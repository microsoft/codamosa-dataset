

# Generated at 2022-06-10 23:33:39.626066
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():

    test_host = 'host1'
    agg_stats = AggregateStats()
    assert agg_stats.processed.get(test_host)==None

    agg_stats.increment('failures', test_host)
    assert agg_stats.processed.get(test_host) == 1
    assert agg_stats.failures.get(test_host) == 1

    agg_stats.increment('failures', test_host)
    assert agg_stats.processed.get(test_host) == 1
    assert agg_stats.failures.get(test_host) == 2


# Generated at 2022-06-10 23:33:43.720066
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    stats.increment("ok", "testhost")
    assert stats.ok["testhost"] == 1
    stats.increment("ok", "testhost")
    assert stats.ok["testhost"] == 2

    # Summarize for testhost should be 2 for ok
    assert stats.summarize("testhost")["ok"] == 2


# Generated at 2022-06-10 23:33:48.413698
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement("failures", "test-host-1")
    assert stats.failures["test-host-1"] == 0
    stats.increment("failures", "test-host-1")
    assert stats.failures["test-host-1"] == 1
    stats.decrement("failures", "test-host-1")
    assert stats.failures["test-host-1"] == 0
    stats.decrement("failures", "test-host-1")
    assert stats.failures["test-host-1"] == 0

# Generated at 2022-06-10 23:33:50.173331
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.skipped['host1'] = 5
    aggregate_stats.decrement('skipped', 'host1')
    assert aggregate_stats.skipped['host1'] == 4

# Generated at 2022-06-10 23:33:58.505141
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement('ok', 'host1')
    assert aggregate_stats.ok == {'host1': 0}

    aggregate_stats = AggregateStats()
    aggregate_stats.ok = {'host1': 1}
    aggregate_stats.decrement('ok', 'host1')
    assert aggregate_stats.ok == {'host1': 0}

    aggregate_stats = AggregateStats()
    aggregate_stats.ok = {'host1': 1}
    aggregate_stats.decrement('ok', 'host2')
    assert aggregate_stats.ok == {'host1': 1}

    aggregate_stats = AggregateStats()
    aggregate_stats.ok = {'host1': 1}
    aggregate_stats.decrement('ok', 'host1')
    aggregate

# Generated at 2022-06-10 23:34:04.956821
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    obj = AggregateStats()
    obj.increment('failures', '127.0.0.1')
    obj.increment('ok', '127.0.0.1')
    obj.decrement('ok', '127.0.0.1')
    obj.decrement('failures', '127.0.0.1')
    obj.decrement('failures', '127.0.0.1')
    obj.decrement('ok', '127.0.0.1')
    assert obj.summary('127.0.0.1') == {'skipped': 0, 'rescued': 0, 'failures': 0, 'ignored': 0, 'unreachable': 0, 'ok': 0, 'changed': 0}


# Generated at 2022-06-10 23:34:09.922310
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    mockedStats = AggregateStats()
    mockedStats.increment('ok', 'fake_host')
    mockedStats.increment('ok', 'fake_host')
    mockedStats.decrement('ok', 'fake_host')
    assert mockedStats.ok['fake_host'] == 1
    mockedStats.decrement('ok', 'fake_host')
    assert mockedStats.ok['fake_host'] == 0

# Generated at 2022-06-10 23:34:17.317098
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'localhost')
    assert stats.ok.get('localhost', 0) == 0
    stats.increment('ok', 'localhost')
    assert stats.ok.get('localhost', 0) == 1
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok.get('localhost', 0) == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok.get('localhost', 0) == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok.get('localhost', 0) == 0

# Generated at 2022-06-10 23:34:21.967685
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    stats.increment("ok", "foo")
    stats.increment("ok", "foo")
    stats.increment("ok", "foo")

    assert stats.ok["foo"] == 3

    stats.decrement("ok", "foo")

    assert stats.ok["foo"] == 2

# Generated at 2022-06-10 23:34:27.588764
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg_stats = AggregateStats()
    agg_stats.increment('failures', 'localhost')
    agg_stats.increment('failures', 'localhost')
    assert agg_stats.failures
    assert agg_stats.failures['localhost'] == 2
    assert agg_stats.processed
    assert agg_stats.processed['localhost'] == 1


# Generated at 2022-06-10 23:34:40.520569
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    a = AggregateStats()
    a.update_custom_stats('a', 3, 'foo')
    assert a.custom['foo']['a'] == 3, 'bad sum'
    a.update_custom_stats('a', 6, 'foo')
    assert a.custom['foo']['a'] == 9, 'bad sum'
    a.update_custom_stats('b', [1,2,3], 'foo')
    assert a.custom['foo']['b'] == [1,2,3], 'bad sum'
    a.update_custom_stats('b', [4,5,6], 'foo')
    assert a.custom['foo']['b'] == [1,2,3,4,5,6], 'bad sum'

# Generated at 2022-06-10 23:34:49.344731
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import PY3
    import collections

    aggrStats = AggregateStats()

    aggrStats.update_custom_stats('key1', 'value1')
    aggrStats.update_custom_stats('key1', 'value1')
    aggrStats.update_custom_stats('key1', 'value1', 'localhost')
    aggrStats.update_custom_stats('key1', 'value1', 'localhost')

    assert aggrStats.custom['_run']['key1'] == 'value1'
    assert aggrStats.custom['localhost']['key1'] == 'value1'

    aggrStats.update_custom_stats('key2', 42)
    aggrStats.update

# Generated at 2022-06-10 23:34:53.444564
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    stats.update_custom_stats('a', 0)
    stats.update_custom_stats('a', 1)
    assert stats.custom == {'_run': {'a': 1}}
    stats.update_custom_stats('a', 3)
    assert stats.custom == {'_run': {'a': 4}}

    stats.update_custom_stats('b', 0, host='testhost')
    stats.update_custom_stats('b', 2, host='testhost')
    assert stats.custom == {'_run': {'a': 4}, 'testhost': {'b': 2}}



# Generated at 2022-06-10 23:35:03.890584
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    class Test(object):
        def __init__(self):
            self.update_custom_stats = AggregateStats.update_custom_stats.__get__(self)
        def run(self):
            self.update_custom_stats('A', 1)
            assert self.custom['_run']['A'] == 1
            self.update_custom_stats('A', 2)
            assert self.custom['_run']['A'] == 3
            self.update_custom_stats('A', {'B': 3})
            assert self.custom['_run']['A']['B'] == 3
            self.update_custom_stats('A', {'B': 5})
            assert self.custom['_run']['A']['B'] == 8

# Generated at 2022-06-10 23:35:11.437810
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # return information about a particular host
    aggr = AggregateStats()
    aggr.update_custom_stats('foo', {'bar': 1, 'zoo': 2})
    assert aggr.custom.popitem()[1] == {'foo': {'bar': 1, 'zoo': 2}}
    # let overloaded + take care of other types
    aggr.update_custom_stats('foo', 2)
    assert aggr.custom.popitem()[1] == {'foo': {'bar': 1, 'zoo': 2}}
    aggr.update_custom_stats('foo', 'foo')
    assert aggr.custom.popitem()[1] == {'foo': {'bar': 1, 'zoo': 2}}

# Generated at 2022-06-10 23:35:17.858078
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    ag = AggregateStats()
    ag.set_custom_stats('foo', 'bar', 'foo_host')
    assert ag.custom.get('foo_host').get('foo') == 'bar'
    ag.update_custom_stats('foo', 10, 'foo_host')
    assert ag.custom.get('foo_host').get('foo') == 10
    ag.update_custom_stats('foo', 2, 'foo_host')
    assert ag.custom.get('foo_host').get('foo') == 12
    ag.update_custom_stats('foo', 'bar', 'foo_host')
    assert ag.custom.get('foo_host').get('foo') == 12
    ag.update_custom_stats('foo', {'x': 1, 'y': 2}, 'foo_host')
    assert ag.custom.get

# Generated at 2022-06-10 23:35:26.279008
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import json

    counter = AggregateStats()
    counter.update_custom_stats("foo", 1, "test")
    counter.update_custom_stats("foo", 2, "test")
    counter.update_custom_stats("foo", 3, "test2")
    counter.update_custom_stats("foo", 4, "test2")
    counter.update_custom_stats("foo", 5, "test2")

    counter.update_custom_stats("bar", [1,2], "test")
    counter.update_custom_stats("bar", [3,4], "test")

    counter.update_custom_stats("baz", [1,2], "test")
    counter.update_custom_stats("baz", 3, "test")

    # Wrong types

# Generated at 2022-06-10 23:35:36.966873
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', {'a': 1, 'b': 2})
    assert stats.custom == {'_run': {'foo': {'a': 1, 'b': 2}}}
    stats.update_custom_stats('foo', {'a': 2, 'c': 3})
    assert stats.custom == {'_run': {'foo': {'a': 3, 'b': 2, 'c': 3}}}
    stats.update_custom_stats('foo', {'b': 3, 'd': 4})
    assert stats.custom == {'_run': {'foo': {'a': 3, 'b': 5, 'c': 3, 'd': 4}}}
    stats.update_custom_stats('bar', 7)

# Generated at 2022-06-10 23:35:46.122609
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate = AggregateStats()
    aggregate.update_custom_stats('foo', 'bar')
    assert aggregate.custom['_run'] == {'foo': 'bar'}

    aggregate.update_custom_stats('foo', 'bar')
    assert aggregate.custom['_run'] == {'foo': 'bar'}

    aggregate.update_custom_stats('foo', {'bar': 'baz'})
    assert aggregate.custom['_run'] == {'foo': {'bar': 'baz'}}

    aggregate.update_custom_stats('foo', 'baz')
    assert aggregate.custom['_run'] == {'foo': {'bar': 'baz'}}

    aggregate.update_custom_stats('foo', ['bar'])

# Generated at 2022-06-10 23:35:55.161223
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.custom = {'host':{'result':{'failures':2, 'ok':2}}}
    result = {'failures':1, 'ok':1}
    stats.update_custom_stats('result', result, 'host')
    assert stats.custom['host']['result'] == {'failures':3, 'ok':3}

    stats.custom = {'host':{'result':3}}
    stats.update_custom_stats('result', 1, 'host')
    assert stats.custom['host']['result'] == 4