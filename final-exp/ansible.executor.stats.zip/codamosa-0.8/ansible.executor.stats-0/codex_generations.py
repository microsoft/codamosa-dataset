

# Generated at 2022-06-10 23:33:32.976663
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', '127.0.0.1')
    assert stats.ok['127.0.0.1'] == 0



# Generated at 2022-06-10 23:33:42.927757
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats(which='stats_1', what=1, host='host_1')
    assert stats.custom['host_1']['stats_1'] == 1

    stats.update_custom_stats(which='stats_1', what=2, host='host_1')
    assert stats.custom['host_1']['stats_1'] == 3

    stats.update_custom_stats(which='stats_2', what=0.5, host='host_1')
    assert stats.custom['host_1']['stats_2'] == 0.5

    stats.update_custom_stats(which='stats_2', what=0.25, host='host_1')
    assert stats.custom['host_1']['stats_2'] == 0.75


# Generated at 2022-06-10 23:33:52.162221
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('aggregate_fails', 1, host='test')
    assert stats.custom['test']['aggregate_fails'] == 1
    stats.set_custom_stats('aggregate_fails', 3, host='test')
    assert stats.custom['test']['aggregate_fails'] == 3
    stats.update_custom_stats('aggregate_fails_changed', 1, host='test')
    assert stats.custom['test']['aggregate_fails_changed'] == 1
    stats.update_custom_stats('aggregate_fails_changed', 3, host='test')
    assert stats.custom['test']['aggregate_fails_changed'] == 4

# Generated at 2022-06-10 23:34:00.380477
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    class AggregateStats_decrement_fake:
        def __init__(self):
            self.processed = {}
            self.failures = {}
            self.ok = {}
            self.dark = {}
            self.changed = {}
            self.skipped = {}
            self.rescued = {}
            self.ignored = {}

            # user defined stats, which can be per host or global
            self.custom = {}

    _builder = AggregateStats_decrement_fake()
    _builder.increment('ok', 'some_host')
    _builder.increment('dark', 'some_host')
    _builder.increment('failures', 'some_host')
    _builder.increment('changed', 'some_host')
    _builder.increment('skipped', 'some_host')
    _

# Generated at 2022-06-10 23:34:04.770498
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    host = 'localhost'
    host2 = 'localhost2'
    stats.increment('dark', host)
    stats.increment('dark', host)
    stats.decrement('dark', host)
    host_stats = stats.summarize(host)
    host2_stats = stats.summarize(host2)
    assert host_stats['unreachable'] == 1
    assert host2_stats['unreachable'] == 0


# Generated at 2022-06-10 23:34:08.322310
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test_aggregate_stats = AggregateStats()
    test_aggregate_stats.ok = {'host': 1}

    test_aggregate_stats.decrement('ok', 'host')
    assert test_aggregate_stats.ok['host'] == 0



# Generated at 2022-06-10 23:34:10.377615
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # verify that decrement on AggregateStats works as expected
    stats = AggregateStats()
    stats.increment("ok", "localhost")
    assert stats.ok['localhost'] == 1
    stats.decrement("ok", "localhost")
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-10 23:34:14.434888
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    s = AggregateStats()
    s.increment("changed", "127.0.0.1")
    s.increment("changed", "127.0.0.1")
    s.decrement("changed", "127.0.0.1")
    if s.changed.get("127.0.0.1", -1) != 1:
        raise AssertionError("failed to decrement")
    s.decrement("changed", "127.0.0.1")
    if s.changed.get("127.0.0.1", -1) != 0:
        raise AssertionError("failed to decrement")


# Generated at 2022-06-10 23:34:18.940937
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    stats.increment('failures', 'localhost')
    assert stats.processed == {'localhost': 1}
    assert stats.failures == {'localhost': 1}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    stats.increment('ignored', 'localhost')
    assert stats.processed == {'localhost': 1}
   

# Generated at 2022-06-10 23:34:22.058596
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok['testhost'] = 3
    stats.decrement('ok', 'testhost')
    assert stats.ok['testhost'] == 2


# Generated at 2022-06-10 23:34:31.208187
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    stats = AggregateStats()
    stats.decrement("ok", "localhost")
    assert stats.ok == {'localhost': 0}

    stats.increment("ok", "localhost")
    assert stats.ok == {'localhost': 1}

    stats = AggregateStats()
    stats.decrement("ok", "localhost")
    stats.decrement("ok", "localhost")
    stats.decrement("ok", "localhost")
    assert stats.ok == {'localhost': 0}

    stats = AggregateStats()
    stats.decrement("ok", "localhost")
    stats.increment("ok", "localhost")
    stats.increment("ok", "localhost")
    stats.decrement("ok", "localhost")
    assert stats.ok == {'localhost': 1}

# Generated at 2022-06-10 23:34:34.541333
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    t = AggregateStats()
    t.dark['foo'] = 1
    t.decrement('dark', 'foo')
    assert t.dark['foo'] == 0


# Generated at 2022-06-10 23:34:37.313494
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok = {'host1': 1}
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0

# Generated at 2022-06-10 23:34:45.870356
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.utils.vars import merge_hash

    ag = AggregateStats()
    ag.update_custom_stats('foo', 1)
    ag.update_custom_stats('foo', 2)
    assert ag.custom['_run']['foo'] == 3
    ag.update_custom_stats('foo', {'bar': 10})
    assert ag.custom['_run']['foo'] == {'bar': 10}
    ag.update_custom_stats('foo', {'bar': 20})
    assert ag.custom['_run']['foo'] == {'bar': 20}
    ag.update_custom_stats('foo', {'bar': 30, 'qux': 3})
    assert ag.custom['_run']['foo'] == {'bar': 30, 'qux': 3}

# Generated at 2022-06-10 23:34:48.706882
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Set up object
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    # Decrement 'ok' counter
    stats.decrement('ok', 'localhost')
    assert stats.summarize('localhost')['ok'] == 0


# Generated at 2022-06-10 23:34:52.393507
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    a = AggregateStats()
    a.decrement('ok', 'hoge')
    assert a.ok['hoge'] == 0
    a.increment('ok', 'hoge')
    a.decrement('ok', 'hoge')
    assert a.ok['hoge'] == 0

# Generated at 2022-06-10 23:34:55.639950
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg_stats = AggregateStats()
    agg_stats.increment("dark", "localhost")
    agg_stats.increment("dark", "localhost")
    agg_stats.decrement("dark", "localhost")
    assert agg_stats.dark["localhost"] == 1

# Generated at 2022-06-10 23:34:59.590829
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    empty_dic = {}
    test_class = AggregateStats()
    test_class.decrement('rescued', 'host')
    assert test_class.rescued == empty_dic

# Generated at 2022-06-10 23:35:08.100496
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    value1 = {'a': 1, 'b': 2}
    value2 = {'c': 'max'}
    value3 = {'a': 99, 'c': 'max'}
    value4 = {'c': 'max'}
    value5 = {'d': 12, 'e': 'max'}
    value6 = {'d': 12, 'e': 'max'}

    host = '_run'
    which = 'k'

    aggstats = AggregateStats()
    aggstats.set_custom_stats(which, value1, host)
    aggstats.update_custom_stats(which, value2, host)

# Generated at 2022-06-10 23:35:09.790953
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement("ok", "host")
    assert stats.ok["host"] == 0


# Generated at 2022-06-10 23:35:15.555987
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    # decrement 1 from key 'dark' that contains 0
    stats.decrement('dark', 'myhost')
    assert stats.dark.get('myhost') == 0
    # decrement 1 from key 'dark'
    stats.dark['myhost'] = 5
    stats.decrement('dark', 'myhost')
    assert stats.dark.get('myhost') == 4


# Generated at 2022-06-10 23:35:19.682521
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    a = AggregateStats()
    a.decrement('ok', 'host')
    assert a.ok['host'] == 0

    a.ok['host'] = 1
    a.decrement('ok', 'host')
    assert a.ok['host'] == 0

    a.decrement('ok', 'unknown')
    assert a.ok['unknown'] == 0


# Generated at 2022-06-10 23:35:26.755080
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test = AggregateStats()
    test.decrement('ok', 'test')
    assert test.ok == {'test': 0}
    test.decrement('ok', 'test')
    assert test.ok == {'test': 0}
    test.increment('ok', 'test')
    assert test.ok == {'test': 1}
    test.increment('ok', 'test')
    assert test.ok == {'test': 2}
    test.increment('ok', 'test')
    assert test.ok == {'test': 3}
    test.increment('ok', 'test')
    assert test.ok == {'test': 4}
    test.increment('ok', 'test')
    assert test.ok == {'test': 5}
    test.increment('ok', 'test')

# Generated at 2022-06-10 23:35:36.718968
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ''' This method tests if decrementing the attributes of a AggregateStats object works as expected.
        Especially, the method checks if decrementing an attribute of a AggregateStats object that is not defined
        works as expected.
    '''

    from ansible.utils.vars import combine_vars, remove_internal_keys
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    stats = AggregateStats()
    assert stats.decrement('skipped', 'host1') == None



# Generated at 2022-06-10 23:35:45.028274
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test_object = AggregateStats()

    # Test when failing decrementing
    test_object.decrement('ok', 'test')

    # Test when succeeding decrementing
    test_object.ok = {'test': 0}
    test_object.decrement('ok', 'test')

    # Test when decrementing a non existing key
    test_object.ok = {'test': 0}
    test_object.decrement('ok', 'test2')

    # Test when decrementing from a key with a very low value
    test_object.ok = {'test': 1}
    test_object.decrement('ok', 'test')
    test_object.decrement('ok', 'test')

# Generated at 2022-06-10 23:35:50.645271
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    stats.decrement(what="ok", host="host1")

    assert stats.ok.get("host1", None) == 0

    stats.ok["host1"] = 10

    stats.decrement(what="ok", host="host1")
    assert stats.ok["host1"] == 9

# Generated at 2022-06-10 23:36:01.776742
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('dark', 'test')
    stats.increment('dark', 'test')
    stats.decrement('dark', 'test')
    assert stats.dark['test'] == 1
    stats.decrement('dark', 'test')
    assert stats.dark['test'] == 0
    stats.decrement('dark', 'test')
    assert stats.dark['test'] == 0
    stats.decrement('dark', 'other')
    assert 'other' not in stats.dark
    stats.increment('dark', 'other')
    assert stats.dark['other'] == 1
    stats.decrement('dark', 'other')
    assert stats.dark['other'] == 0
    stats.increment('dark', 'nonexistant')
    assert stats.dark['nonexistant']

# Generated at 2022-06-10 23:36:10.288657
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement("ok", "localhost")
    assert stats.ok["localhost"] == 0

    stats.decrement("ok", "localhost")
    assert stats.ok["localhost"] == 0

    stats.ok["localhost"] = 1
    stats.decrement("ok", "localhost")
    assert stats.ok["localhost"] == 0

    stats.ok["localhost"] = 2
    stats.decrement("ok", "localhost")
    assert stats.ok["localhost"] == 1

# Generated at 2022-06-10 23:36:22.119824
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    agg_stats = AggregateStats()
    agg_stats.increment('ignored', '127.0.0.1')
    agg_stats.increment('ignored', '127.0.0.1')
    agg_stats.increment('ignored', '127.0.0.1')

    assert agg_stats.ignored['127.0.0.1'] == 3

    agg_stats.decrement('ignored', '127.0.0.1')
    agg_stats.decrement('ignored', '127.0.0.1')
    agg_stats.decrement('ignored', '127.0.0.1')

    assert agg_stats.ignored['127.0.0.1'] == 0


# Generated at 2022-06-10 23:36:33.608518
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    import pytest
    as_object = AggregateStats()
    as_object.processed['host'] = 1
    as_object.failures['host'] = 0
    as_object.ok['host'] = 1
    as_object.dark['host'] = 1
    as_object.changed['host'] = 1
    as_object.skipped['host'] = 1
    as_object.rescued['host'] = 1
    as_object.ignored['host'] = 1
    as_object.decrement('failures', 'host')
    assert as_object.processed['host'] == 1
    assert as_object.failures['host'] == 0
    assert as_object.ok['host'] == 1
    assert as_object.dark['host'] == 1
    assert as_object.changed['host'] == 1