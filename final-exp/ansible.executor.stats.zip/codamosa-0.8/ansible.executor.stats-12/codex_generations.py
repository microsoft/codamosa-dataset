

# Generated at 2022-06-10 23:33:45.246320
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg = AggregateStats()
    agg.decrement('ok', 'myhost')
    if agg.ok['myhost'] != 0:
        raise ValueError("Decrement of 'ok' did not set its value to 0")

    agg.increment('ok', 'myhost')
    agg.increment('ok', 'myhost')
    agg.decrement('ok', 'myhost')
    if agg.ok['myhost'] != 1:
        raise ValueError("Decrement of 'ok' did not set its value to 1")

    agg.decrement('ok', 'myhost')
    if agg.ok['myhost'] != 0:
        raise ValueError("Decrement of 'ok' did not set its value to 0")



# Generated at 2022-06-10 23:33:47.094903
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'myhost')
    assert stats.ok.get('myhost') == 0

# Generated at 2022-06-10 23:33:55.123517
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    from collections import defaultdict
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import xrange
    from ansible.utils.vars import merge_hash

    n = 100
    if PY3:
        xrange = range

    for i in xrange(n):
        s = AggregateStats()
        s.increment('ok', 'host')
        s.decrement('ok', 'host')
        assert s.ok['host'] == 0

        s = AggregateStats()
        s.increment('ok', 'host')
        s.increment('ok', 'host')
        s.decrement('ok', 'host')
        assert s.ok['host'] == 1

        s = AggregateStats()

# Generated at 2022-06-10 23:33:58.540621
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ag = AggregateStats()
    ag.increment('ok', 'host')
    ag.decrement('ok', 'host')
    assert ag.ok == {'host': 0}
    ag.decrement('ok', 'host')
    assert ag.ok == {'host': 0}


# Generated at 2022-06-10 23:34:03.965851
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment("ok", "localhost")
    stats.increment("ok", "localhost")
    assert stats.ok["localhost"] == 2, stats.ok["localhost"]

    stats.decrement("ok", "localhost")
    assert stats.ok["localhost"] == 1, stats.ok["localhost"]

    stats.decrement("ok", "localhost")
    assert stats.ok["localhost"] == 0, stats.ok["localhost"]

    # shouldn't decrease below 0
    stats.decrement("ok", "localhost")
    assert stats.ok["localhost"] == 0, stats.ok["localhost"]


# Generated at 2022-06-10 23:34:09.509612
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregateStats = AggregateStats()
    aggregateStats.increment("ok", "test_host")
    assert aggregateStats.ok["test_host"] == 1
    aggregateStats.increment("ok", "test_host")
    assert aggregateStats.ok["test_host"] == 2
    aggregateStats.increment("ok", "other_host")
    assert aggregateStats.ok["test_host"] == 2
    assert aggregateStats.ok["other_host"] == 1


# Generated at 2022-06-10 23:34:19.022494
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    # Prerequisites: Create 2 instances of AggregateStats class
    #   1. instance for unit test
    #   2. instance to compare results of unit testing with results from existing logic in method update_custom_stats

    # Instance for unit test
    test_AggregateStats = AggregateStats()

    # Instance to compare results of unit testing with results from existing logic in method update_custom_stats
    compare_AggregateStats = AggregateStats()

    # Expected result
    result_expected = {}

    # call update_custom_stats
    test_AggregateStats.update_custom_stats('test_key1', {'test_key11': 'test_value11', 'test_key12': 'test_value12'})
    test_AggregateStats.update_custom_stats('test_key2', 25)

# Generated at 2022-06-10 23:34:25.120426
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    "Test AggregateStats.decrement(what, host)"

    stats = AggregateStats()
    stats.increment('failures', 'localhost')
    assert stats.failures.get('localhost') == 1

    stats.decrement('failures', 'localhost')
    assert stats.failures.get('localhost') == 0

    stats.decrement('failures', 'localhost')
    assert stats.failures.get('localhost') == 0

# Generated at 2022-06-10 23:34:30.338491
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    for host in ['localhost', '127.0.0.1', '127.0.1.1']:
        stats.increment('ok', host)
    assert stats.processed == {'localhost':1, '127.0.0.1':1, '127.0.1.1':1}
    assert stats.ok == {'localhost':1, '127.0.0.1':1, '127.0.1.1':1}

# Generated at 2022-06-10 23:34:37.130783
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ag = AggregateStats()
    host = 0
    ag.ok[host] = 2
    ag.decrement('ok', host)
    assert ag.ok[host] == 1
    ag.decrement('ok', host)
    assert ag.ok[host] == 0
    ag.decrement('ok', host)
    assert ag.ok[host] == 0


# Generated at 2022-06-10 23:34:47.717607
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    as1 = AggregateStats()
    as1.update_custom_stats('one', {'changed': 'a', 'failed': 'b'})
    as1.update_custom_stats('two', 3)
    as1.update_custom_stats('one', {'changed': 'c', 'failed': 'd'})
    assert as1.custom['_run']['one']['changed'] == 'c', 'Failed to update aggregate custom stats'
    assert as1.custom['_run']['one']['failed'] == 'd', 'Failed to update aggregate custom stats'
    assert as1.custom['_run']['two'] == 3, 'Failed to update aggregate custom stats'


# Generated at 2022-06-10 23:34:53.321416
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import unittest

    class AggregateStatsTestCase(unittest.TestCase):
        def setUp(self):
            self.stats = AggregateStats()
            self.counters = {'ok': 0, 'failures': 0, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}
            self.custom_counters = {'time_spent': 0}

        def test_update_custom_stats(self):
            self.stats.update_custom_stats('time_spent', 1)
            self.assertEqual(self.stats.custom['_run'], {'time_spent': 1})
            self.stats.increment('ok', 'dummy1')
            self.stats.increment('ok', 'dummy1')


# Generated at 2022-06-10 23:35:03.779576
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    ags = AggregateStats()
    # Initial values
    ags.custom = {'_run': {'http_requests': 0}}
    ags.update_custom_stats('http_requests', 1)
    assert ags.custom == {'_run': {'http_requests': 1}}

    ags.custom = {'_run': {'http_requests': 9}}
    ags.update_custom_stats('http_requests', 0)
    assert ags.custom == {'_run': {'http_requests': 9}}

    ags.custom = {'_run': {'http_requests': '999'}}
    ags.update_custom_stats('http_requests', 0)

# Generated at 2022-06-10 23:35:11.347145
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    agg = AggregateStats()
    agg.update_custom_stats('a_list', [1, 2])
    assert agg.custom['_run']['a_list'] == [1, 2]
    agg.update_custom_stats('a_list', [3])
    assert agg.custom['_run']['a_list'] == [1, 2, 3]
    agg.update_custom_stats('a_list', [3])
    assert agg.custom['_run']['a_list'] == [1, 2, 3, 3]
    agg.update_custom_stats('a_dict', {'foo': 'bar'})
    assert agg.custom['_run']['a_dict'] == {'foo': 'bar'}

# Generated at 2022-06-10 23:35:17.797078
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats_instance = AggregateStats()
    custom_stats_dict = {'nested_dict': {'test_key': 'test_value'}}
    aggregate_stats_instance.update_custom_stats('test_key', custom_stats_dict, 'localhost')
    assert aggregate_stats_instance.custom['localhost']['test_key'] == custom_stats_dict
    aggregate_stats_instance = AggregateStats()
    aggregate_stats_instance.update_custom_stats('test_key', custom_stats_dict)
    assert aggregate_stats_instance.custom['_run']['test_key'] == custom_stats_dict
    nested_dict = aggregate_stats_instance.custom['_run']['test_key']
    nested_dict['test_key'] = 'test_value1'

# Generated at 2022-06-10 23:35:26.199788
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # test empty value
    stats = AggregateStats()
    stats.update_custom_stats('test', '')
    assert stats.custom == {'_run': {'test': ''}}

    # test mismatching types
    stats.update_custom_stats('test', 'foo')
    assert stats.custom == {'_run': {'test': ''}}

    # test add/update to custom stats
    d = {'a': 1, 'b': {'c': 2}}
    stats.update_custom_stats('test', d)
    assert stats.custom == {'_run': {'test': d}}
    d = {'a': 2, 'b': {'d': 2}}
    stats.update_custom_stats('test', d)

# Generated at 2022-06-10 23:35:30.086618
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('test', {'a': {'b': 2}})
    assert stats.custom == {'_run': {'test': {'a': {'b': 2}}}}

# Generated at 2022-06-10 23:35:39.995531
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate = AggregateStats()
    aggregate.update_custom_stats('a', 0, host='_run')
    assert aggregate.custom['_run']['a'] == 0
    aggregate.update_custom_stats('a', 1, host='_run')
    assert aggregate.custom['_run']['a'] == 1

    # Test dictionary
    aggregate.update_custom_stats('b', {'b':1}, host='_run')
    assert aggregate.custom['_run']['b']['b'] == 1
    aggregate.update_custom_stats('b', {'b':2}, host='_run')
    assert aggregate.custom['_run']['b']['b'] == 2

    # Test float
    aggregate.update_custom_stats('c', 0.1, host='_run')

# Generated at 2022-06-10 23:35:48.117168
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    as1 = AggregateStats()
    as1.custom = {'_run': {'sum_integer': 10, 'sum_string': '10', 'sum_mapping': {'a': 1}}}
    as1.update_custom_stats('sum_integer', 3)
    assert as1.custom['_run'] == {'sum_integer': 13, 'sum_string': '10', 'sum_mapping': {'a': 1}}
    as1.update_custom_stats('sum_string', 3)
    assert as1.custom['_run'] == {'sum_integer': 13, 'sum_string': '103', 'sum_mapping': {'a': 1}}
    as1.update_custom_stats('sum_string', '-3')

# Generated at 2022-06-10 23:35:55.370897
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    # Declaration of variables
    agg_stats = AggregateStats()
    host = '127.0.0.1'
    what = {u'errors': 0, u'ok': 8}
    agg_stats.update_custom_stats('custom_stats', what, host)

    # Check if the update of custom_stats has been successful
    assert agg_stats.custom[host]['custom_stats'] == {u'errors': 0, u'ok': 8}
