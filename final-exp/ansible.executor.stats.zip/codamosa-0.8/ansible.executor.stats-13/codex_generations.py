

# Generated at 2022-06-10 23:33:32.655989
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement("ok", "localhost")
    assert(stats.ok['localhost'] == 0)

# Generated at 2022-06-10 23:33:42.546768
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()

    host = 'test'

    # Test ok
    aggregate_stats.ok[host] = 1
    aggregate_stats.decrement('ok', host)
    assert aggregate_stats.ok[host] == 0, 'AggregateStats decrement method has failed for ok'

    # Test failures
    aggregate_stats.failures[host] = 1
    aggregate_stats.decrement('failures', host)
    assert aggregate_stats.failures[host] == 0, 'AggregateStats decrement method has failed for failures'

    # Test dark
    aggregate_stats.dark[host] = 1
    aggregate_stats.decrement('dark', host)
    assert aggregate_stats.dark[host] == 0, 'AggregateStats decrement method has failed for dark'

    # Test changed
    aggregate_

# Generated at 2022-06-10 23:33:47.790303
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test_instance = AggregateStats()
    setattr(test_instance, "test", { "test_host": 2 })
    test_instance.decrement("test", "test_host")
    assert getattr(test_instance, "test")["test_host"] == 1
    test_instance.decrement("test", "test_host")
    assert "test_host" not in getattr(test_instance, "test")
    test_instance.decrement("test", "not_exist_host")
    assert getattr(test_instance, "test")["not_exist_host"] == 0


# Generated at 2022-06-10 23:33:55.381435
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}

    # Decrementing a key not in the dict does nothing
    stats.decrement('failures', 'localhost')
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}

    # Decrementing a key

# Generated at 2022-06-10 23:34:02.437501
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Aggregation of custom stats can be tested with both dictionaries and integers
    # In the former case we use custom_stats to check the results inside update_custom_stats
    custom_stats = {
        "total": {
            "total": 0,
            "success": 0,
            "errors": 0,
            "changed": 0
        },
        "web": {
            "total": 0,
            "success": 0,
            "errors": 0,
            "changed": 0
        },
        "redis": {
            "total": 0,
            "success": 0,
            "errors": 0,
            "changed": 0
        },
        "database": {
            "total": 0,
            "success": 0,
            "errors": 0,
            "changed": 0
        },
    }

    # Run Aggregate

# Generated at 2022-06-10 23:34:08.883947
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('failures', 'host1')
    stats.increment('failures', 'host2')
    stats.increment('ok', 'host3')
    assert stats.ok == {'host1': 1, 'host3': 1}
    assert stats.failures == {'host1': 1, 'host2': 1}
    assert stats.processed == {'host1': 1, 'host2': 1, 'host3': 1}


# Generated at 2022-06-10 23:34:18.060407
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    fail_host = 'host_fail'
    success_host = 'host_success'

    # Create a new AggregateStats object
    stats = AggregateStats()

    # Increment the counters for a host
    stats.increment('failures', fail_host)
    stats.increment('skipped', fail_host)
    stats.increment('ok', success_host)
    stats.increment('ok', success_host)

    # Decrement the counters for a host
    stats.decrement('failures', fail_host)
    stats.decrement('skipped', fail_host)
    stats.decrement('ok', success_host)

    # Make sure the counters are decremented
    assert stats.failures[fail_host] == 0
    assert stats.skipped[fail_host] == 0
    assert stats

# Generated at 2022-06-10 23:34:22.985208
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    astat = AggregateStats()
    astat.decrement("ok", "host")
    astat.decrement("ok", "host")
    astat.decrement("ok", "host2")
    assert(astat.ok["host"] == 0)
    assert(astat.ok["host2"] == 0)


# Generated at 2022-06-10 23:34:29.570378
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stat_obj = AggregateStats()
    results = dict(
        dark=dict(
            host1=1,
            host2=2,
        ),
    )
    stat_obj.__dict__.update(results)

    stat_obj.decrement('dark', 'host1')
    assert stat_obj.dark['host1'] == 0, stat_obj.dark['host1']
    # host2 should be untouched
    assert stat_obj.dark['host2'] == 2, stat_obj.dark['host2']

# Generated at 2022-06-10 23:34:39.619704
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    (ok, dark) = (True, False)
    stats = AggregateStats()
    stats.increment(ok, 'test_host')
    assert stats.ok['test_host'] == 1
    assert stats.processed['test_host'] == 1
    stats.decrement(ok, 'test_host')
    assert stats.ok['test_host'] == 0
    stats.increment(dark, 'test_host')
    assert stats.dark['test_host'] == 1
    stats.decrement(ok, 'test_host')
    assert stats.ok['test_host'] == 0
    assert stats.dark['test_host'] == 1
    assert stats.processed['test_host'] == 1


# Generated at 2022-06-10 23:34:49.933397
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    # test with None
    stats.update_custom_stats('', None)
    assert stats.custom == {}

    # test with string
    stats.update_custom_stats('foo', "bar")
    assert stats.custom == {'_run': {'foo': 'bar'}}
    stats.update_custom_stats('foo', 'baz')
    assert stats.custom == {'_run': {'foo': 'baz'}}
    stats.update_custom_stats('foo', 'zoo', 'host1')
    assert stats.custom == {'_run': {'foo': 'baz'}, 'host1': {'foo': 'zoo'}}

    # test with int
    stats.update_custom_stats('foo', 1)

# Generated at 2022-06-10 23:34:55.275849
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    host = 'somehost'
    which = 'some_custom_stats'
    what = {'some_key': 1}

    # simple adding to an empty custom hash
    aggregate_stats.update_custom_stats(which, what, host)
    assert aggregate_stats.custom[host][which] == what

    # now add some more to the custom hash
    what2 = {'some_key2': 2}
    aggregate_stats.update_custom_stats(which, what2, host)
    expected = merge_hash(what, what2)
    assert aggregate_stats.custom[host][which] == expected

    # adding an int to a custom hash
    what3 = 3
    aggregate_stats.update_custom_stats(which, what3, host)

# Generated at 2022-06-10 23:35:00.578281
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # initialize
    aggregate_stats_obj = AggregateStats()
    which = 'test_counter'
    host = 'localhost'

    # increment counter
    aggregate_stats_obj.update_custom_stats(which, 1, host)

    # check result
    assert aggregate_stats_obj.custom[host][which] == 1


# Generated at 2022-06-10 23:35:09.063272
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats("test1", 1)
    stats.update_custom_stats("test1", 1)
    stats.update_custom_stats("test1", 1)
    stats.update_custom_stats("test1", 1)
    assert stats.custom["_run"]["test1"] == 4
    stats.update_custom_stats("test2", "one")
    assert stats.custom["_run"]["test2"] == "one"
    stats.update_custom_stats("test2", "two")
    assert stats.custom["_run"]["test2"] == "onetwo"
    stats.update_custom_stats("test3", {"foo": "bar"})
    assert stats.custom["_run"]["test3"] == {"foo": "bar"}
   

# Generated at 2022-06-10 23:35:16.116724
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import pprint
    agg_stats = AggregateStats()

    agg_stats.update_custom_stats('a', 42)
    assert agg_stats.custom['_run']['a'] == 42

    agg_stats.update_custom_stats('a', 42)
    assert agg_stats.custom['_run']['a'] == 84

    agg_stats.update_custom_stats('a', -42)
    assert agg_stats.custom['_run']['a'] == 42

    agg_stats.update_custom_stats('a', -42)
    assert agg_stats.custom['_run']['a'] == 0

    agg_stats.update_custom_stats('a', 'bar')
    assert agg_stats.custom['_run']['a'] == 0


# Generated at 2022-06-10 23:35:24.517651
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    # test1: adding an integer key
    stats.update_custom_stats('integer', 5)
    assert stats.custom['_run']['integer'] == 5

    # test2: adding a key of different type than the existing
    stats.update_custom_stats('integer', 'foo')
    assert stats.custom['_run']['integer'] == 5

    # test3: adding a dictionary key
    stats.update_custom_stats('dict', {'bar': 7})
    assert stats.custom['_run'] == {'integer': 5, 'dict': {'bar': 7}}

    # test4: merging a dictionary key
    stats.update_custom_stats('dict', {'foo': 3})

# Generated at 2022-06-10 23:35:26.199248
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
  stats = AggregateStats()
  stats.decrement('ignored', 'localhost')
  assert stats.ignored.get('localhost', 0) == 0

# Generated at 2022-06-10 23:35:36.929395
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # first test: if self.custom[host] does not exist, set_custom_stats called
    a = AggregateStats()
    a.update_custom_stats('custom_int', 1)
    assert a.custom == {'_run': {'custom_int': 1}}
    a.update_custom_stats('custom_int', 1, 'host1')
    assert a.custom == {'_run': {'custom_int': 1}, 'host1': {'custom_int': 1}}

    # second test: if self.custom[host][which] exists, which updated
    a.custom['host1'] = {'custom_int': 1}
    a.update_custom_stats('custom_int', 1, 'host1')

# Generated at 2022-06-10 23:35:46.057475
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    '''
    Testing update custom statistics.
    '''
    # Custom statistics should correctly merge hashes
    custom_stats = {
        '_run': {
            'custom_stat': {'host': 'hostname', 'port': 8000}
        }
    }
    aggr_stats = AggregateStats()
    aggr_stats.custom = custom_stats
    aggr_stats.update_custom_stats(
        'custom_stat',
        {'port': 8080, 'server': 'vm'}
    )
    assert aggr_stats.custom['_run']['custom_stat'] == {
        'host': 'hostname',
        'port': 8080,
        'server': 'vm'
    }

    # Custom statistics should correctly sum integers

# Generated at 2022-06-10 23:35:58.560930
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    stats.update_custom_stats('dict_value', {"key1": 1, "key2": 2})
    assert stats.custom['_run']['dict_value'] == {"key1": 1, "key2": 2}

    stats.update_custom_stats('dict_value', {"key3": 3, "key4": 4})
    assert stats.custom['_run']['dict_value'] == {"key1": 1, "key2": 2, "key3": 3, "key4": 4}

    stats.update_custom_stats('int_value', 9)
    assert stats.custom['_run']['int_value'] == 9

    stats.update_custom_stats('int_value', 1)
    assert stats.custom['_run']['int_value'] == 10

