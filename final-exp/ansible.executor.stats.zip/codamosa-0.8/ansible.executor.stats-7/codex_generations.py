

# Generated at 2022-06-10 23:33:37.131545
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.utils.vars import merge_hash
    stats = AggregateStats()

    stats.update_custom_stats('foo', {'a': 1, 'b': 2})
    assert stats.custom['_run']['foo'] == {'a': 1, 'b': 2}

    stats.update_custom_stats('foo', {'b': 2, 'c': 3})
    assert stats.custom['_run']['foo'] == {'a': 1, 'b': 4, 'c': 3}

    stats.update_custom_stats('bar', [1, 2, 3], 'localhost')
    assert stats.custom['localhost']['bar'] == [1, 2, 3]

    stats.update_custom_stats('bar', ['foo'], 'localhost')
    assert stats.custom['localhost']['bar']

# Generated at 2022-06-10 23:33:40.958903
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('failures', 'host')
    assert stats.failures['host'] == 0
    stats.failures['host'] = 1
    stats.decrement('failures', 'host')
    assert stats.failures['host'] == 0

# Generated at 2022-06-10 23:33:49.106062
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    a = AggregateStats()
    host = 'localhost'
    print("Testing update_custom_stats")
    a.update_custom_stats("dict", {'k': 'v'}, host)
    assert a.custom[host]['dict'] == {'k': 'v'}
    a.update_custom_stats("dict", {'k': 'v2'}, host)
    assert a.custom[host]['dict'] == {'k': 'v2'}
    a.update_custom_stats("dict", {'k2': 'v2'}, host)
    assert a.custom[host]['dict'] == {'k2': 'v2', 'k': 'v2'}
    a.update_custom_stats("list", [1,2,3], host)

# Generated at 2022-06-10 23:33:56.827612
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats(): 
    print("run test_AggregateStats_update_custom_stats")

    stats = AggregateStats()
    stats.update_custom_stats("foo", 1)
    assert stats.custom["_run"]["foo"] == 1

    stats.update_custom_stats("foo", 2)
    assert stats.custom["_run"]["foo"] == 3

    stats.update_custom_stats("foo", 2)
    assert stats.custom["_run"]["foo"] == 5

    stats.update_custom_stats("bar", {"baz": 1}, "mysql")
    assert stats.custom["mysql"]["bar"] == {"baz": 1}

    stats.update_custom_stats("bar", {"baz": 1}, "mysql")

# Generated at 2022-06-10 23:34:00.142614
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok['localhost'] = 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    # decrement the second time
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0


# Generated at 2022-06-10 23:34:02.218859
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('failures', 'host1')
    assert stats.summary('host1')['failures'] == 1


# Generated at 2022-06-10 23:34:11.231280
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    '''
    Some simple tests to make sure we don't break something
    '''
    a = AggregateStats()
    a.increment('ok', 'host1')
    a.increment('ok', 'host1')
    a.increment('ok', 'host1')

    assert a.ok['host1'] == 3

    a.decrement('ok', 'host1')
    assert a.ok['host1'] == 2

    # Should not be possible, but let's be safe
    a.decrement('ok', 'host1')
    a.decrement('ok', 'host1')
    a.decrement('ok', 'host1')
    a.decrement('ok', 'host1')
    a.decrement('ok', 'host1')


# Generated at 2022-06-10 23:34:21.546922
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    # test simple addition
    a = AggregateStats()
    a.update_custom_stats('test', 1)
    assert a.custom['_run']['test'] == 1
    a.update_custom_stats('test', 2)
    assert a.custom['_run']['test'] == 3
    a.update_custom_stats('test', 3)
    assert a.custom['_run']['test'] == 6

    # test simple subtraction
    a.update_custom_stats('test', -1)
    assert a.custom['_run']['test'] == 5
    a.update_custom_stats('test', -2)
    assert a.custom['_run']['test'] == 3
    a.update_custom_stats('test', -3)

# Generated at 2022-06-10 23:34:29.486794
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    # Create a object for the test
    stats = AggregateStats()

    stats.increment('ok', '127.0.0.1')
    # check the value of the attribute
    assert stats.ok['127.0.0.1'] == 1

    # increase the value
    stats.increment('ok', '127.0.0.1')
    assert stats.ok['127.0.0.1'] == 2

    # add a new value for the attribute
    stats.increment('failures', '127.0.0.1')
    assert stats.failures['127.0.0.1'] == 1



# Generated at 2022-06-10 23:34:38.336542
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    host  = 'localhost'

    # Check that decrementing an empty stat does not
    # modify the value
    stats.decrement('ok', host)
    assert stats.ok['localhost'] == 0

    # Check that decrementing a stat decrements it
    stats.ok[host] = 1
    stats.decrement('ok', host)
    assert stats.ok['localhost'] == 0

    # Check that decrementing a stat is safe
    stats.ok[host] = -1
    stats.decrement('ok', host)
    assert stats.ok['localhost'] == -1
