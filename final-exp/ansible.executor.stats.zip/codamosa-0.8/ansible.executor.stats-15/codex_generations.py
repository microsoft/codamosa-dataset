

# Generated at 2022-06-10 23:33:34.825492
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment("ok", "host1")
    stats.decrement("ok", "host1")
    assert stats.ok["host1"] == 0
    assert stats.processed["host1"] == 1
    assert stats.summary("host1")["ok"] == stats.ok["host1"]


# Generated at 2022-06-10 23:33:43.991209
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ''' We only care about the statistic we test, the others
    are not important and are not tested. '''

    aggregatestats = AggregateStats()
    stats = 'ok'

    # Check if decrementing with value that is not in dict
    aggregatestats.decrement(stats, 'testhost')
    assert aggregatestats.ok == {'testhost': 0}

    # Check if decrementing with value that is in dict
    aggregatestats.increment(stats, 'testhost')
    aggregatestats.decrement(stats, 'testhost')
    assert aggregatestats.ok == {'testhost': 0}

    # Check if decrementing with value that is in dict and larger 0
    for i in range(2):
        aggregatestats.increment(stats, 'testhost')

# Generated at 2022-06-10 23:33:49.372987
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    from ansible.utils.vars import combine_vars
    stats = AggregateStats()
    stats.ok['a'] = 100
    stats.ok['b'] = 100
    stats.ok['c'] = 100
    stats.decrement('ok', 'a')
    assert stats.ok['a'] == 99
    assert stats.ok['b'] == 100
    assert stats.ok['c'] == 100

# Generated at 2022-06-10 23:33:53.768076
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Generate an instance of AggregateStats
    aggregate_stats = AggregateStats()

    # Execute method increment of aggregate_stats instance
    aggregate_stats.increment('skipped', 'host1')

    # Execute method decrement of aggregate_stats instance
    aggregate_stats.decrement('skipped', 'host1')

    # Check if skipped value of aggregate_stats is 0
    assert aggregate_stats.skipped['host1'] == 0

# Generated at 2022-06-10 23:34:01.650180
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'test_host')
    stats.increment('ignored', 'test_host')
    stats.decrement('ok', 'test_host')
    assert stats.ok['test_host'] == 0
    assert stats.ignored['test_host'] == 1
    stats.decrement('ignored', 'test_host')
    stats.decrement('ignored', 'test_host')
    stats.decrement('ignored', 'test_host')
    stats.decrement('ignored', 'test_host')
    stats.decrement('ignored', 'test_host')
    assert stats.ok['test_host'] == 0
    assert stats.ignored['test_host'] == 0

# Generated at 2022-06-10 23:34:07.684207
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    class TestClass():
        def __init__(self):
            self.failures = {'host1': 1}
        def get(self, which, key, default):
            return self.failures.get(key, default)

    astats = AggregateStats()
    astats.failures = TestClass()
    astats.decrement('failures', 'host1')
    assert astats.failures.get('host1', 1) == 0

# Generated at 2022-06-10 23:34:16.561794
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    host = "host1"
    # 1 case
    custom_stat_1 = {"key1": 1}
    custom_stat_2 = {"key1": 2}
    custom_stat_3 = {"key1": 3}
    ag_stats = AggregateStats()
    ag_stats.update_custom_stats("key1", custom_stat_1, host)
    assert ag_stats.custom[host]["key1"] == 1
    ag_stats.update_custom_stats("key1", custom_stat_2, host)
    assert ag_stats.custom[host]["key1"] == 2
    ag_stats.update_custom_stats("key1", custom_stat_3, host)
    assert ag_stats.custom[host]["key1"] == 3

    # 2 case

# Generated at 2022-06-10 23:34:27.973946
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('my_count', 2, 'test')
    assert stats.custom == {'test': {'my_count': 2}}
    stats.update_custom_stats('my_count', 2, 'test')
    assert stats.custom == {'test': {'my_count': 4}}
    stats.update_custom_stats('my_count', {'a': 2, 'b': 3}, 'test')
    assert stats.custom == {'test': {'my_count': {'a': 4, 'b': 6}}}
    stats.update_custom_stats('my_count', [1,2,3], 'test')
    assert stats.custom == {'test': {'my_count': [1, 2, 3, 1, 2, 3]}}
    stats.update

# Generated at 2022-06-10 23:34:33.209203
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    as1 = AggregateStats()
    as1.update_custom_stats('c', 1)
    assert as1.custom['_run']['c'] == 1
    as1.update_custom_stats('c', 1)
    assert as1.custom['_run']['c'] == 2


# Generated at 2022-06-10 23:34:37.087126
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    stats = AggregateStats()
    stats.ok['hostname'] = 0
    stats.decrement("ok", "hostname")
    assert stats.ok == {'hostname': 0}


# Generated at 2022-06-10 23:34:46.260430
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    a = AggregateStats()
    a.processed['host00'] = 1
    a.failures['host00'] = 1
    a.ok['host00'] = 1
    a.dark['host00'] = 1
    a.changed['host00'] = 1
    a.skipped['host00'] = 1
    a.rescued['host00'] = 1
    a.ignored['host00'] = 1
    a.decrement('ok', 'host00')
    a.decrement('failures', 'host00')
    a.decrement('dark', 'host00')
    a.decrement('changed', 'host00')
    a.decrement('skipped', 'host00')
    a.decrement('rescued', 'host00')

# Generated at 2022-06-10 23:34:50.466482
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    stats.increment('ok', 'test-host')
    assert stats.ok['test-host'] == 1

    stats.decrement('ok', 'test-host')
    assert stats.ok['test-host'] == 0

    # test that decrement method doesn't crash if the stat is missing
    stats.decrement('ok', 'test-host')
    assert stats.ok['test-host'] == 0


# Generated at 2022-06-10 23:34:53.795290
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.failures['test_host'] = 2
    stats.decrement('failures', 'test_host')
    assert stats.failures['test_host'] == 1

    stats.decrement('failures', 'test_host')
    assert stats.failures['test_host'] == 0

    stats.decrement('failures', 'test_host')
    assert stats.failures['test_host'] == 0

# Generated at 2022-06-10 23:35:04.262453
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'foo')
    assert stats.ok['foo'] == 1
    stats.decrement('ok', 'foo')
    assert stats.ok['foo'] == 0
    stats.increment('changed', 'foo')
    assert stats.changed['foo'] == 1
    stats.decrement('changed', 'foo')
    assert stats.changed['foo'] == 0
    stats.increment('failures', 'foo')
    assert stats.failures['foo'] == 1
    stats.decrement('failures', 'foo')
    assert stats.failures['foo'] == 0
    stats.increment('dark', 'foo')
    assert stats.dark['foo'] == 1
    stats.decrement('dark', 'foo')
    assert stats.dark['foo'] == 0

# Generated at 2022-06-10 23:35:10.487730
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment("ok", "host1")
    stats.decrement("ok", "host1")
    assert stats.ok["host1"] == 0

    # Test that decrementing with a KeyError doesn't blow up
    stats = AggregateStats()
    stats.decrement("ok", "host1")
    assert stats.ok["host1"] == 0

    # Test that decrementing below 0 doesn't blow up
    stats = AggregateStats()
    stats.decrement("ok", "host1")
    stats.decrement("ok", "host1")
    assert stats.ok["host1"] == 0

# Generated at 2022-06-10 23:35:13.447849
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.ok = {'localhost':1}
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-10 23:35:16.384285
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement('ok', 'test_host')
    if aggregate_stats.ok['test_host'] != 0 or aggregate_stats.processed['test_host'] != 1:
        raise Exception('decrement method of class AggregateStats failed')

# Generated at 2022-06-10 23:35:18.067302
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('changed', 'localhost')
    assert stats.changed['localhost'] == 0

# Generated at 2022-06-10 23:35:23.110778
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    oAS = AggregateStats()
    oAS.decrement("ok","host1")
    assert oAS.ok["host1"]==0
    oAS.increment("ok","host1")
    oAS.increment("ok","host2")
    oAS.decrement("ok","host1")
    assert oAS.ok["host1"]==0
    assert oAS.ok["host2"]==1


# Generated at 2022-06-10 23:35:29.727358
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'test_host')
    assert ('test_host' not in stats.ok)

    stats.decrement('ok', 'test_host')
    assert ('test_host' not in stats.ok)

    stats.increment('ok', 'test_host')
    stats.decrement('ok', 'test_host')
    assert (stats.ok['test_host'] == 0)

    stats.processed['test_host'] = 1
    stats.increment('ok', 'test_host')
    stats.decrement('ok', 'test_host')
    assert (stats.ok['test_host'] == 0)

    stats.increment('ok', 'test_host')
    stats.increment('ok', 'test_host')

# Generated at 2022-06-10 23:35:37.122972
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg, name, host = AggregateStats(), "skipped", "localhost"
    agg.increment(name, host)
    assert agg.skipped[host] == 1
    # Ensure decrementing by 1 works
    agg.decrement(name, host)
    assert agg.skipped[host] == 0
    # Ensure decrementing by more than 1 does not work
    agg.decrement(name, host)
    assert agg.skipped[host] == 0

# Generated at 2022-06-10 23:35:45.920892
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'test')
    assert stats.ok['test'] == 1
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 0
    stats.increment('ok', 'test')
    stats.increment('ok', 'test')
    assert stats.ok['test'] == 2
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 1
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 0
    try:
        stats.decrement('ok', 'test')
        assert False, "Don't be so negative"
    except KeyError:
        pass
    assert stats.ok['test'] == 0

# Generated at 2022-06-10 23:35:53.990028
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    # Test with a host that has none of the requested key
    a1 = AggregateStats()
    a1.decrement('ok', 'h1')
    assert a1.ok == {'h1': 0}

    # Test with a host that has some of the requested key
    a2 = AggregateStats()
    a2.ok = {'h1': 1}
    a2.decrement('ok', 'h1')
    assert a2.ok == {'h1': 0}


# Generated at 2022-06-10 23:35:57.320759
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment("ok", "foo")
    assert stats.ok["foo"] == 1
    stats.decrement("ok", "foo")
    assert stats.ok["foo"] == 0


# Generated at 2022-06-10 23:36:00.144792
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    a = AggregateStats()
    a.increment('ok', '127.0.0.1')
    a.decrement('ok', '127.0.0.1')

    assert a.ok == {'127.0.0.1':0}


# Generated at 2022-06-10 23:36:02.311991
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'test')
    assert stats.ok['test'] == 1
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 0



# Generated at 2022-06-10 23:36:11.901700
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement('ok', 'host')
    assert aggregate_stats.ok.get('host', 0) == 0
    aggregate_stats.ok['host'] = 2
    aggregate_stats.decrement('ok', 'host')
    assert aggregate_stats.ok['host'] == 1
    aggregate_stats.decrement('ok', 'host')
    assert aggregate_stats.ok['host'] == 0
    aggregate_stats.decrement('ok', 'host')
    assert aggregate_stats.ok['host'] == 0


# Generated at 2022-06-10 23:36:15.726166
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    stats.increment('ok', 'test_host')
    stats.decrement('ok', 'test_host')

    assert stats.ok['test_host'] == 0


# Generated at 2022-06-10 23:36:20.781581
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('skipped', '127.0.0.1')
    assert stats.skipped['127.0.0.1'] == 0
    stats.skipped['127.0.0.1'] = 3
    stats.decrement('skipped', '127.0.0.1')
    assert stats.skipped['127.0.0.1'] == 2

# Generated at 2022-06-10 23:36:33.040067
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    _test_id_0 = u'id_0'
    _test_id_1 = u'id_1'
    _test_id_2 = u'id_2'

    # Test decrementing ok
    _a = AggregateStats()
    _a.increment('ok', _test_id_0)
    _a.increment('ok', _test_id_1)
    _a.increment('ok', _test_id_2)
    _a.decrement('ok', _test_id_1)
    assert _a.ok == {_test_id_0: 1, _test_id_1: 0, _test_id_2: 1}

    # Test decrementing changed
    _a = AggregateStats()