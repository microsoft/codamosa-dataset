

# Generated at 2022-06-10 23:33:38.197695
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    # Test decrement function without initializing a key
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 0

    stats.ok = {'host': 5}
    stats.decrement('ok', 'host')

    assert stats.ok['host'] == 4

    # Test if decrementing below zero is handled
    stats.ok = {'host': 0}
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 0

# Generated at 2022-06-10 23:33:42.331099
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    class Test_AggregateStats(AggregateStats):
        def __init__(self):
            self.ok = {'host': 0}
    obj =  Test_AggregateStats()
    assert obj.ok['host'] == 0
    obj.decrement('ok', 'host')
    assert obj.ok['host'] == 0

# Generated at 2022-06-10 23:33:48.823145
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import unittest
    class AggregateStats_update_custom_stats_TestCase(unittest.TestCase):
        def test_update_custom_stats(self):
            agg_stats = AggregateStats()
            agg_stats.update_custom_stats('counter', 1)
            self.assertEqual(agg_stats.custom['_run']['counter'], 1)
            agg_stats.update_custom_stats('counter', 1)
            self.assertEqual(agg_stats.custom['_run']['counter'], 2)
            agg_stats.update_custom_stats('counter', {'foo': 'bar'})
            self.assertEqual(agg_stats.custom['_run']['counter'], {'counter': 2, 'foo': 'bar'})
            agg_stats.update_custom_stats

# Generated at 2022-06-10 23:33:52.567054
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('rescued', 'host')
    assert stats.rescued['host'] == 1
    stats.decrement('rescued', 'host')
    assert stats.rescued['host'] == 0
    try:
        stats.decrement('rescued', 'host')
        assert False
    except KeyError:
        assert True

# Generated at 2022-06-10 23:33:58.500184
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment("ok", "host1")
    stats.increment("ok", "host1")
    stats.increment("ok", "host2")
    assert stats.ok["host1"] == 2
    stats.decrement("ok", "host1")
    assert stats.ok["host1"] == 1
    stats.decrement("ok", "host2")
    assert stats.ok["host2"] == 0
    stats.decrement("ok", "host2")
    assert stats.ok["host2"] == 0


# Generated at 2022-06-10 23:34:05.145016
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    target = AggregateStats()
    target.update_custom_stats('foo', 'foo')
    target.update_custom_stats('foo', 'foo')
    target.update_custom_stats('foo', 'foo')
    assert target.custom['_run']['foo'] == 'foofoofoo'
    target.update_custom_stats('foo', 5)
    assert target.custom['_run']['foo'] == 10
    target.update_custom_stats('foo', 10)
    assert target.custom['_run']['foo'] == 20
    target.update_custom_stats('foo', 20)
    assert target.custom['_run']['foo'] == 40
    # mismatching types
    target.update_custom_stats('foo', {'bar': 'baz'})

# Generated at 2022-06-10 23:34:14.114643
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    host = 'localhost'
    stats.increment('ok', host)
    stats.increment('ok', host)
    stats.increment('failures', host)
    stats.increment('failures', host)
    stats.increment('dark', host)
    stats.increment('changed', host)
    stats.increment('skipped', host)
    stats.increment('rescued', host)
    stats.increment('ignored', host)

    expected_ok    = 2
    expected_fail  = 2
    expected_dark  = 1
    expected_chang = 1
    expected_skip  = 1
    expected_resc  = 1
    expected_ignor = 1

# Generated at 2022-06-10 23:34:15.677638
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate = AggregateStats()
    aggregate.increment('ok', 'localhost')
    aggregate.decrement('ok', 'localhost')
    assert aggregate.ok['localhost'] == 0
    assert aggregate.processed['localhost'] == 1

# Generated at 2022-06-10 23:34:24.324767
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', '127.0.0.1')
    stats.increment('ok', '127.0.0.2')
    assert(stats.ok['127.0.0.1'] == 1)
    assert(stats.ok['127.0.0.2'] == 1)
    stats.decrement('ok', '127.0.0.1')
    assert(stats.ok['127.0.0.1'] == 0)
    assert(stats.ok['127.0.0.2'] == 1)



# Generated at 2022-06-10 23:34:31.414827
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    total_hosts = 10
    as_ = AggregateStats()
    as_.ok = dict()
    as_.failures = dict()
    as_.dark = dict()
    as_.changed = dict()
    as_.skipped = dict()
    as_.rescued = dict()
    as_.ignored = dict()
    for i in range(total_hosts):
        as_.increment('ok', i)
        as_.increment('failures', i)
        as_.increment('dark', i)
        as_.increment('changed', i)
        as_.increment('skipped', i)
        as_.increment('rescued', i)
        as_.increment('ignored', i)
        as_.increment('ok', i)
    for i in range(total_hosts):
        as_.dec

# Generated at 2022-06-10 23:34:41.954077
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 0
    stats.ok['test'] = 1
    stats.ok['test'] = 2
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 1
    # Test only setting decrement to 1, but not lower
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 0
    # Test decrementing non-existing key
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 0

# Generated at 2022-06-10 23:34:47.871601
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    from ansible import callbacks
    c = callbacks.AggregateStats()

    assert c.failures == {}
    assert c.ok == {}
    assert c.dark == {}
    assert c.changed == {}
    assert c.skipped == {}
    assert c.ignored == {}

    c.increment('failures', 'localhost')
    assert c.failures['localhost'] == 1
    c.increment('failures', 'localhost')
    assert c.failures['localhost'] == 2

    c.decrement('failures', 'localhost')
    assert c.failures['localhost'] == 1
    c.decrement('failures', 'localhost')
    assert c.failures['localhost'] == 0

    c.increment('ok', 'localhost')
    assert c.ok['localhost'] == 1
    c.dec

# Generated at 2022-06-10 23:34:53.394330
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # decrement should be able to decrease the value of a key.
    # If a key does not exist, decrement will set its value to be 0.
    # If key does exist, decrement will decrease its value by 1.
    # If its value is 0, decrement will set its value to be 0.

    aggregate_stats = AggregateStats()

    # Key:ok
    # Expected result:
    # Case Key doesn't exist, decrement will set its value to be 0.
    aggregate_stats.decrement(what='ok', host='host_1')
    assert aggregate_stats.ok.get('host_1') == 0

    # Case Key does exist, decrement will decrease its value by 1.
    aggregate_stats.increment(what='ok', host='host_2')

# Generated at 2022-06-10 23:35:03.853519
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    stats = AggregateStats()

    # test merging of dicts
    stats.set_custom_stats('foo', {'bar': 1})
    stats.set_custom_stats('foo', {'baz': 2})
    assert stats.custom['_run']['foo'] == {'bar': 1, 'baz': 2}
    stats.update_custom_stats('foo', {'bar': 3})
    assert stats.custom['_run']['foo'] == {'bar': 4, 'baz': 2}

    # test merging with non-dicts
    stats.set_custom_stats('foo', {'qux': 3})
    assert stats.custom['_run']['foo'] == {'bar': 4, 'baz': 2, 'qux': 3}

    # test merging within dicts
    stats.set

# Generated at 2022-06-10 23:35:08.321534
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', "localhost")
    assert stats.ok["localhost"] == 0
    stats.increment('ok', "localhost")
    stats.decrement('ok', "localhost")
    assert stats.ok["localhost"] == 0
    try:
        stats.decrement('ok', "localhost")
        raise RuntimeError("Should have raised KeyError")
    except KeyError:
        pass

# Generated at 2022-06-10 23:35:14.818658
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    stats.update_custom_stats('test', {'a': 1, 'b': 2})
    assert stats.custom['_run'] == {'test': {'a': 1, 'b': 2}}

    stats.update_custom_stats('test', [1, 2])
    assert stats.custom['_run'] == {'test': [1, 2]}

    stats.update_custom_stats('test', [3, 4])
    assert stats.custom['_run'] == {'test': [1, 2, 3, 4]}

    stats.update_custom_stats('test', {'a': 1})
    assert stats.custom['_run'] == {'test': [1, 2, 3, 4]}

# Generated at 2022-06-10 23:35:20.465935
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.ok['host1'] = 10
    assert aggregate_stats.ok['host1'] == 10
    aggregate_stats.decrement('ok', 'host1')
    assert aggregate_stats.ok['host1'] == 9
    aggregate_stats.decrement('ok', 'host1')
    assert aggregate_stats.ok['host1'] == 8
    aggregate_stats.decrement('ok', 'host2')
    assert aggregate_stats.ok['host2'] == 0


# Generated at 2022-06-10 23:35:28.006328
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'barbar'
    stats.update_custom_stats('foo', 'baz', 'host1')
    assert stats.custom['host1']['foo'] == 'baz'
    stats.update_custom_stats('foo', 'baz', 'host1')
    assert stats.custom['host1']['foo'] == 'bazbaz'
    stats.update_custom_stats('bar', ['baz', 'foo'])
    assert stats.custom['_run']['bar'] == ['baz', 'foo']

# Generated at 2022-06-10 23:35:32.492517
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    stats = AggregateStats()

    # Test decrement
    stats.decrement('ok', 'localhost')
    assert stats.ok == {'localhost': 0}

    # Test decrement without key
    stats.decrement('ok', 'localhost')
    assert stats.ok == {'localhost': 0}

# Generated at 2022-06-10 23:35:42.497795
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import json

    #test_cases = [
    #    {'what': 'test'},
    #    {'what': ['test1', 'test2']},
    #    {'what': {'test1': 'test1'}},
    #    {'what': {'test2': ['test2']}},
    #    {'what': {'test3': {'test3': 'test3'}}},
    #    {'what': {'test4': {'test4': ['test4']}}},
    #]

    # test with hash-hash
    aggregate_stats = AggregateStats()
    what = {'users': {'jdoe': {'age': 25, 'sex': 'male'}}}
    aggregate_stats.update_custom_stats('auth1', what, 'host1')

    what

# Generated at 2022-06-10 23:35:46.687681
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    aggregate = AggregateStats()
    aggregate.increment('ok', 'a')
    aggregate.decrement('ok', 'a')

    assert aggregate.summarize('a')['ok'] == 0, "The ok stats should be 0"
    assert aggregate.ok['a'] == 0, "The ok stats should be 0"

# Generated at 2022-06-10 23:35:52.834562
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    astats = AggregateStats()
    astats.decrement('ok', 'testhost')
    assert astats.ok['testhost'] == 0
    astats.decrement('ok', 'testhost')
    assert astats.ok['testhost'] == 0
    astats.ok['testhost'] = 1
    astats.decrement('ok', 'testhost')
    assert astats.ok['testhost'] == 0


# Generated at 2022-06-10 23:36:01.512228
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    for test in [
        ("ok", "test_host", 1),
        ("failures", "test_host", 0),
        ("failures", "test_host", -1),
        ("unreachable", "test_host", 0),
        ("unreachable", "test_host", -1),
        ("changed", "test_host", 0),
        ("changed", "test_host", -1),
        ("skipped", "test_host", 0),
        ("skipped", "test_host", -1),
        ("rescued", "test_host", 0),
        ("rescued", "test_host", -1),
        ("ignored", "test_host", 0),
        ("ignored", "test_host", -1),
    ]:
        stats_obj = AggregateStats()
        stats_

# Generated at 2022-06-10 23:36:10.967025
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'test_host')
    stats.decrement('ok', 'test_host')
    assert stats.ok['test_host'] == 0, "AggregateStats.decrement: ok should be 0"
    stats.increment('ok', 'test_host')
    stats.decrement('ok', 'test_host')
    stats.decrement('ok', 'test_host')
    assert stats.ok['test_host'] == 0, "AggregateStats.decrement: ok should be 0"

# Generated at 2022-06-10 23:36:16.764485
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg = AggregateStats()
    agg.increment('ok', 'host1')
    agg.increment('ok', 'host1')
    agg.decrement('ok', 'host1')
    assert agg.ok['host1'] == 1
    agg.decrement('ok', 'host1')
    assert agg.ok['host1'] == 0

# Generated at 2022-06-10 23:36:20.531704
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    stats.increment('dark', 'host1')
    assert stats.dark['host1'] == 1
    stats.decrement('dark', 'host1')
    assert stats.dark['host1'] == 0

# Generated at 2022-06-10 23:36:27.234924
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg = AggregateStats()
    agg.decrement("ok", "foo")
    agg.decrement("ok", "foo")
    agg.decrement("ok", "foo")
    agg.decrement("ok", "bar")
    agg.decrement("ok", "bar")

    assert agg.ok.get("foo") == 0
    assert agg.ok.get("bar") == 0

# Generated at 2022-06-10 23:36:35.781522
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    a = AggregateStats()
    a.processed = {}
    a.failures = {}
    a.ok = {'host1': 1, 'host2': 2}
    a.skipped = {'host1': 1, 'host3': 2}
    a.decrement('ok', 'host2')
    a.decrement('skipped', 'host3')
    assert a.skipped['host3'] == 1
    assert a.ok['host2'] == 1

    # test decrement to 0
    a.decrement('ok', 'host2')
    a.decrement('skipped', 'host3')
    assert 'host2' not in a.ok
    assert 'host3' not in a.skipped

    # test decrement not existing key

# Generated at 2022-06-10 23:36:37.834290
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    host = 'localhost'
    stats = AggregateStats()
    stats.ok[host] = 0
    stats.decrement('ok', host)
    assert stats.ok[host] == 0

# Generated at 2022-06-10 23:36:41.352143
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    x = AggregateStats()
    x.decrement('ok', 'localhost')
    assert x.ok['localhost'] == 0
    assert x.ok == {'localhost': 0}

