

# Generated at 2022-06-10 23:33:39.584667
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    obj = AggregateStats()
    obj.increment(u'ok', u'127.0.0.1')
    obj.decrement(u'ok', u'127.0.0.1')
    assert u'127.0.0.1' in obj.ok
    assert obj.ok[u'127.0.0.1'] == 0
    del obj


# Generated at 2022-06-10 23:33:42.804914
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():

    # Create a new instance of class AggregateStats
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 2


# Generated at 2022-06-10 23:33:52.020568
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 10)
    assert stats.custom['_run']['foo'] == 10

    stats.update_custom_stats('foo', 20)
    assert stats.custom['_run']['foo'] == 20

    stats.update_custom_stats('bar', 'quux')
    assert stats.custom['_run']['bar'] == 'quux'

    stats.update_custom_stats('bar', 'baz', host='somehost')
    assert stats.custom['_run']['bar'] == 'quux'
    assert stats.custom['somehost']['bar'] == 'baz'

    stats.update_custom_stats('bar', 'zoo', host='_run')

# Generated at 2022-06-10 23:34:00.216834
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.module_utils.common._collections_compat import MutableMapping
    aggregate_stats = AggregateStats()
    which = "perf_data"
    which1 = "perf_data"
    which2 = "perf_data"
    which3 = "perf_data"
    host1 = "server1"
    host2 = "server2"
    what = {"cpu_idle": 342, 'cpu_busy': 3456}
    what1 = {"cpu_idle": 342, 'cpu_busy': 3456}
    what2 = {"cpu_idle": 22, 'cpu_busy': 10}
    what3 = {"cpu_idle": 342, 'cpu_busy': 3456}
    # The below should return a dictionary
    result = aggregate_stats.set_custom_

# Generated at 2022-06-10 23:34:05.046163
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ''' unit tests for AggregateStats.increment method '''
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.inventory.host import Host

    stats = AggregateStats()

    stats.increment('ok', 'test_host')
    assert stats.ok['test_host'] == 1
    stats.increment('ok', 'test_host')
    assert stats.ok['test_host'] == 2
    stats.increment('ok', 'test_host')
    assert stats.ok['test_host'] == 3

# Generated at 2022-06-10 23:34:07.469027
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # There is no return value for method decrement
    # Everything we care about is done through side effects,
    # so there are no assertions to be made.
    # This method exists purely for code coverage purposes.
    s = AggregateStats()
    s.increment('changed', 'example.com')
    s.decrement('changed', 'example.com')

# Generated at 2022-06-10 23:34:16.306191
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    stats.update_custom_stats('a', 1)
    assert stats.custom['_run']['a'] == 1
    stats.update_custom_stats('a', 2)
    assert stats.custom['_run']['a'] == 3
    stats.update_custom_stats('a', '1')
    assert stats.custom['_run']['a'] == 3
    stats.update_custom_stats('a', '2')
    assert stats.custom['_run']['a'] == '32'

    # test non-dict update
    stats.update_custom_stats('b', 1)
    assert stats.custom['_run']['b'] == 1
    stats.update_custom_stats('b', 2)
    assert stats.custom['_run']['b'] == 3

# Generated at 2022-06-10 23:34:25.880275
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    for h in ('a', 'b'):
        for w in ('ok', 'dark', 'changed', 'rescued', 'ignored'):
            stats.increment(w, h)
            assert stats.processed[h] == 1
            assert getattr(stats, w)[h] == 1
            stats.increment(w, h)
            assert getattr(stats, w)[h] == 2

    for w in ('ok', 'dark', 'changed', 'rescued', 'ignored'):
        assert stats.processed == stats.ok == stats.dark == stats.changed == stats.rescued == stats.ignored



# Generated at 2022-06-10 23:34:30.159097
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():

    stats = AggregateStats()

    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')

    assert stats.processed == {'host1': 1}, 'processed is incremented'
    assert stats.ok == {'host1': 2}, 'ok is incremented'


# Generated at 2022-06-10 23:34:42.110723
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg = AggregateStats()
    agg.increment('ok', 'host1') # ok = 1
    agg.increment('rescued', 'host1') # rescued = 1
    agg.increment('ok', 'host1') # ok = 2

    agg.decrement('ok', 'host1') # ok = 1
    agg.decrement('ok', 'host1') # ok = 0
    agg.decrement('ok', 'host1') # ok = 0
    agg.decrement('rescued', 'host1') # rescued = 0
    agg.decrement('ok', 'host2') # ok = 0

    assert agg.ok == {'host1': 0}
    assert agg.rescued == {'host1': 0}
    assert agg.ok.get('host2', 0) == 0


# Generated at 2022-06-10 23:34:47.485033
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # init object
    agg_stats = AggregateStats()
    # initialize a key/value pair in dark dict
    dark_val = agg_stats.dark['dark_host'] = 1
    # execute method under test
    agg_stats.decrement('dark', 'dark_host')

    assert agg_stats.dark['dark_host'] == dark_val - 1


# Generated at 2022-06-10 23:34:49.655814
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ag = AggregateStats()
    ag.increment("ok", "host1")
    ag.decrement("ok", "host1")
    assert ag.ok == {'host1': 0}


# Generated at 2022-06-10 23:34:55.177617
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Create a clean instance of AggregateStats
    aggstats = AggregateStats()
    aggstats.custom = {}

    # Update the custom stats for a host and a non-existing stat
    aggstats.update_custom_stats("new_stat", 99, "testhost")
    assert aggstats.custom == {"testhost": {"new_stat": 99}}

    # Update the custom stats for a host and an existing stat
    aggstats.update_custom_stats("new_stat", 1, "testhost")
    assert aggstats.custom == {"testhost": {"new_stat": 100}}

    # Update the custom stats for a host and an existing stat
    aggstats.update_custom_stats("new_stat", [1], "testhost")
    assert aggstats.custom == {"testhost": {"new_stat": [1]}}

    # Update the

# Generated at 2022-06-10 23:35:05.526365
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # test custom dict rebuild
    stats = AggregateStats()
    stats.set_custom_stats('foo', {'bar':'baz'})
    assert stats.custom['_run']['foo'] == {'bar': 'baz'}
    stats.update_custom_stats('foo', {'barbar':'bazbaz'})
    assert stats.custom['_run']['foo'] == {'bar': 'baz', 'barbar': 'bazbaz'}

    # test dict merge
    stats = AggregateStats()
    stats.set_custom_stats('foo', {'bar':{'baz':'foobar'}})
    stats.update_custom_stats('foo', {'bar':{'bazbaz':'foobaz'}})

# Generated at 2022-06-10 23:35:12.656928
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    host = "myhost"
    which = "my_var"
    stats = AggregateStats()

    # my_var int
    what = 0
    assert stats.update_custom_stats(which, what, host) == 0
    assert stats.custom[host][which] == what

    what1 = 1
    assert stats.update_custom_stats(which, what1, host) == 1
    assert stats.custom[host][which] == what1

    # my_var str
    which = "my_var_str"
    what = ""
    assert stats.update_custom_stats(which, what, host) == ""
    assert stats.custom[host][which] == what

    what = "pipo"
    assert stats.update_custom_stats(which, what, host) == "pipo"
    assert stats

# Generated at 2022-06-10 23:35:16.852665
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    stats = AggregateStats()
    stats.update_custom_stats('test_custom_stats', {'foo': 'bar'})
    stats.update_custom_stats('test_custom_stats', {'bar': 42})
    stats.update_custom_stats('test_custom_stats', 'baz')
    assert stats.custom['_run']['test_custom_stats'] == {'foo': 'bar', 'bar': 42, 'baz': 'baz'}

# Generated at 2022-06-10 23:35:21.895969
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', '127.0.0.1')
    assert stats.ok['127.0.0.1'] == 1
    stats.decrement('ok', '127.0.0.1')
    assert stats.ok['127.0.0.1'] == 0
    stats.increment('ok', '127.0.0.1')
    assert stats.ok['127.0.0.1'] == 1


# Generated at 2022-06-10 23:35:25.260197
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    host = 'host1'
    aggregate_stats.increment('failures', 'host1')
    aggregate_stats.decrement('failures', 'host1')
    assert aggregate_stats.failures[host] == 0

# Generated at 2022-06-10 23:35:29.077748
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_obj = AggregateStats()
    aggregate_obj.decrement("ok", "test1")
    aggregate_obj.decrement("ok", "test2")
    aggregate_obj.decrement("ok", "test3")
    assert (aggregate_obj.ok['test1'] == 0)
    assert (aggregate_obj.ok['test2'] == 0)
    assert (aggregate_obj.ok['test3'] == 0)



# Generated at 2022-06-10 23:35:39.440063
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    s = AggregateStats()
    s.increment('failures', 'myhost')
    s.increment('ok', 'myhost')
    s.increment('skipped', 'myhost')

    assert s.failures.get('myhost', 0) == 1
    assert s.ok.get('myhost', 0) == 1
    assert s.skipped.get('myhost', 0) == 1

    s.decrement('failures', 'myhost')
    s.decrement('ok', 'myhost')
    s.decrement('skipped', 'myhost')

    assert s.failures.get('myhost', 0) == 0
    assert s.ok.get('myhost', 0) == 0
    assert s.skipped.get('myhost', 0) == 0

    s.decrement

# Generated at 2022-06-10 23:35:45.666359
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.processed = {'host1':1}
    stats.ok = {'host1':1}

    host = "host1"
    what = "ok"
    stats.increment(what, host)

    stats.decrement(what, host)

    assert stats.ok[host] == 1

    # Now the stats of the host should be zero
    stats.decrement(what, host)

    assert stats.ok[host] == 0

# Generated at 2022-06-10 23:35:55.222841
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    '''
    Feature test for decrement in AggregateStats class
    '''
    agg = AggregateStats()
    agg.decrement('ok', 'first')
    assert agg.ok['first'] == 0
    agg.ok['first'] = 10
    agg.decrement('ok', 'first')
    assert agg.ok['first'] == 9
    agg.decrement('ok', 'first')
    agg.decrement('ok', 'first')
    assert agg.ok['first'] == 7
    assert 'first' in agg.ok
    assert 'second' not in agg.ok


# Generated at 2022-06-10 23:35:57.812207
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    assert stats.decrement('ok', 'localhost') == 0
    assert stats.ok.get('localhost') == 0
    assert stats.decrement('ok', 'localhost') == 0
    assert stats.decrement('ok', '192.168.1.1') == 0
    assert stats.ok.get('192.168.1.1') == 0

# Generated at 2022-06-10 23:36:03.741340
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement("failures", "host_name")
    stats.decrement("failures", "host_name")
    stats.decrement("failures", "host_name")
    stats.decrement("failures", "host_name")
    stats.decrement("failures", "host_name")
    assert stats.failures["host_name"] == 0
    assert stats.failures["host_name"] == 0
    assert stats.failures["host_name"] == 0
    assert stats.failures["host_name"] == 0
    assert stats.failures["host_name"] == 0
    assert stats.failures["host_name"] == 0


# Generated at 2022-06-10 23:36:09.240048
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test_aggregate_stats = AggregateStats()

    test_aggregate_stats.increment('ok', 'host1')
    assert test_aggregate_stats.ok['host1'] == 1

    test_aggregate_stats.decrement('ok', 'host1')
    assert test_aggregate_stats.ok['host1'] == 0

# Generated at 2022-06-10 23:36:14.586041
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg = AggregateStats()
    agg.decrement("failures", "localhost")
    assert agg.failures["localhost"] == 0

    agg.failures["otherhost"] = 1
    agg.decrement("failures", "otherhost")
    assert agg.failures["otherhost"] == 0



# Generated at 2022-06-10 23:36:21.104982
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ''' testing decrement method of AggregateStats class '''
    ag = AggregateStats()
    ag.failures = {'host1': 1, 'host2': 0}
    ag.decrement("failures", "host1")
    assert ag.failures['host1'] == 0
    ag.decrement("failures", "host2")
    assert ag.failures['host2'] == 0


# Generated at 2022-06-10 23:36:27.468206
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok = {'host1': 1}
    stats.increment('ok', 'host1')
    assert stats.ok == {'host1': 2}
    stats.decrement('ok', 'host1')
    assert stats.ok == {'host1': 1}
    assert stats.processed == {'host1': 1}

# Generated at 2022-06-10 23:36:32.280475
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment("ok", "foo")
    stats.decrement("ok", "foo")
    assert stats.ok["foo"] == 0
    stats.decrement("ok", "foo")
    assert stats.ok["foo"] == 0

# Generated at 2022-06-10 23:36:35.143225
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    as_obj = AggregateStats()
    what = 'ok'
    host = 'localhost'
    as_obj.increment(what, host)
    assert as_obj.ok[host] == 1
    as_obj.decrement(what, host)
    assert as_obj.ok[host] == 0

# Generated at 2022-06-10 23:36:43.499289
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ag = AggregateStats()
    ag.increment('ok', 'localhost')
    ag.increment('ok', 'localhost')
    ag.increment('ok', 'localhost')
    assert ag.ok['localhost'] == 3
    ag.decrement('ok', 'localhost')
    assert ag.ok['localhost'] == 2
    ag.decrement('ok', 'localhost')
    assert ag.ok['localhost'] == 1
    ag.decrement('ok', 'localhost')
    assert ag.ok['localhost'] == 0

# Generated at 2022-06-10 23:36:48.661473
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Decrement a non-existent value, verify it goes to 0
    a = AggregateStats()
    a.decrement("ok", "host1")
    assert a.ok["host1"] == 0

    # Decrement a value of 1, verify it goes 0
    a = AggregateStats()
    a.ok = {"host1": 1}
    a.decrement("ok", "host1")
    assert a.ok["host1"] == 0

    # Add a value, and decrement it twice, should still be 0
    a = AggregateStats()
    a.ok = {"host1": 2}
    a.decrement("ok", "host1")
    a.decrement("ok", "host1")
    assert a.ok["host1"] == 0


# Generated at 2022-06-10 23:36:52.271488
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    aggr_stats = AggregateStats()
    aggr_stats.decrement('ok', 'host1')
    assert aggr_stats.ok['host1'] == 0, 'It should be 0'

# Generated at 2022-06-10 23:36:56.701094
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    '''
    Test to verify that decrement method decrements the value of 'what' for 'host' by 1
    '''
    stats = AggregateStats()
    stats.increment('ok', 'test_host')
    assert stats.ok == {'test_host': 1}
    stats.decrement('ok','test_host')
    assert stats.ok == {'test_host': 0}


# Generated at 2022-06-10 23:37:00.237312
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok['host1'] = 1
    stats.ok['host2'] = 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 2

# Generated at 2022-06-10 23:37:04.380869
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    hosts = ['hostA', 'hostB', 'hostC']
    playbook_stats = AggregateStats()

    for host in hosts:
        playbook_stats.ok[host] = 1

    for host in hosts:
        playbook_stats.decrement('ok', host)

    assert 1 not in playbook_stats.ok.values()

    # check runtimeError
    assert_raises(RuntimeError, playbook_stats.decrement, 'ok', 'invalid_host')

# Generated at 2022-06-10 23:37:11.091311
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg = AggregateStats()
    agg.decrement('ok', 'test1')
    assert agg.ok['test1'] == 0
    agg.decrement('ok', 'test1')
    assert agg.ok['test1'] == 0
    agg.ok['test1'] = 5
    agg.decrement('ok', 'test1')
    assert agg.ok['test1'] == 4

# Generated at 2022-06-10 23:37:16.945135
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    test_obj = AggregateStats()

    test_obj.failures = {'test_host': 1}

    test_obj.decrement('failures','test_host')

    assert test_obj.failures['test_host'] == 0

    test_obj.decrement('ok','test_host')

    assert test_obj.ok['test_host'] == 0

# Generated at 2022-06-10 23:37:19.583474
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ignored', 'myhost')
    assert stats.ignored == {'myhost': 0}
    stats.ignored = {'myhost': 1}
    stats.decrement('ignored', 'myhost')
    assert stats.ignored == {'myhost': 0}
    stats.decrement('ignored', 'myhost')
    assert stats.ignored == {'myhost': 0}

# Generated at 2022-06-10 23:37:21.987919
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Create the object instance
    aggregate_stats = AggregateStats()
    # Counter for the stats.ok
    aggregate_stats.ok["host1"] = 2

    # Decrement the counter for stats.ok and check if the result is correct
    aggregate_stats.decrement("ok", "host1")
    assert aggregate_stats.ok["host1"] == 1



# Generated at 2022-06-10 23:37:27.675245
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    a = AggregateStats()
    a.decrement('ok', 'host')
    assert a.ok == {'host': 0}
    a.ok['host'] = 1
    a.decrement('ok', 'host')
    assert a.ok == {'host': 0}



# Generated at 2022-06-10 23:37:32.536972
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stat = AggregateStats()
    stat.increment('ok', 'localhost')
    assert stat.ok['localhost'] == 1
    assert stat.decrement('ok', 'localhost') == None
    assert stat.ok['localhost'] == 0
    assert stat.decrement('ok', 'localhost') == None
    assert stat.ok['localhost'] == 0


# Generated at 2022-06-10 23:37:35.396795
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.ok['localhost'] = 2
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1


# Generated at 2022-06-10 23:37:39.988469
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg = AggregateStats()
    stat = dict()
    agg.increment('stat', 'myhost')
    agg.decrement('stat', 'myhost')
    assert agg.stat.get('myhost', 0) == 0
    agg.increment('stat', 'myhost')
    agg.decrement('stat', 'myhost')
    agg.decrement('stat', 'myhost')
    assert agg.stat.get('myhost', 0) == 0


# Generated at 2022-06-10 23:37:42.751803
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    _stats = AggregateStats()

    _stats.decrement('ok', 'foo')
    assert _stats.ok['foo'] == 0

    _stats.ok['foo'] = 1
    _stats.decrement('ok', 'foo')
    assert _stats.ok['foo'] == 0

# Generated at 2022-06-10 23:37:48.850448
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg_stats = AggregateStats()
    assert agg_stats.decrement('failures', '127.0.0.1') == 0
    agg_stats.increment('failures', '127.0.0.1')
    agg_stats.increment('ok', '127.0.0.1')
    agg_stats.increment('ok', '127.0.0.1')
    agg_stats.increment('ok', '127.0.0.2')
    assert agg_stats.failures['127.0.0.1'] == 1
    assert agg_stats.ok['127.0.0.1'] == 2
    assert agg_stats.decrement('failures', '127.0.0.1') == 0

# Generated at 2022-06-10 23:37:56.016735
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregateStats = AggregateStats()
    aggregateStats.processed = {'host1':1, 'host2':1}
    aggregateStats.failures = {'host2':2, 'host3':2}
    aggregateStats.ok = {'host1':1}

    aggregateStats.decrement('ok', 'host2')
    aggregateStats.decrement('failures', 'host2')
    aggregateStats.decrement('ok', 'host3')
    aggregateStats.decrement('failures', 'host3')

    assert aggregateStats.ok == {'host1':1}
    assert aggregateStats.failures == {'host2':1, 'host3':1}

    aggregateStats.decrement('ok', 'host1')
    aggregateStats.decrement('failures', 'host2')

# Generated at 2022-06-10 23:38:02.038425
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate = AggregateStats()
    aggregate.ignored = {'localhost': 4}
    assert aggregate.ignored['localhost'] == 4
    aggregate.decrement('ignored', 'localhost')
    assert aggregate.ignored['localhost'] == 3
    aggregate.decrement('ignored', 'localhost')
    assert aggregate.ignored['localhost'] == 2
    aggregate.decrement('ignored', 'localhost')
    assert aggregate.ignored['localhost'] == 1
    aggregate.decrement('ignored', 'localhost')
    assert aggregate.ignored['localhost'] == 0
    aggregate.decrement('ignored', 'localhost')
    assert aggregate.ignored['localhost'] == 0



# Generated at 2022-06-10 23:38:08.673794
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ''' test AggregateStats.decrement() '''

    # Initialize a AggregateStats object
    stats = AggregateStats()
    stats.increment('ok', 'host1')

    # decrement a zero stats
    stats.decrement('ignored', 'host1')
    assert stats.ignored['host1'] == 0

    # decrement an existent stats
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0


# Generated at 2022-06-10 23:38:12.832691
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('failed', 'test')
    assert stats.failures['test'] == 0
    stats.increment('failed', 'test')
    stats.decrement('failed', 'test')
    assert stats.failures['test'] == 0

if __name__ == '__main__':
    test_AggregateStats_decrement()