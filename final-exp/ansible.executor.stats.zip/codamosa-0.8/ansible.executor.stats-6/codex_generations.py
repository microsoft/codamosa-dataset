

# Generated at 2022-06-10 23:33:31.162491
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    import os
    import shutil
    import tempfile

    stats = AggregateStats()
    stats.ok['test_host'] = 1

    stats.decrement('ok', 'test_host')

    assert(stats.ok['test_host'] == 0)


# Generated at 2022-06-10 23:33:37.214361
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate = AggregateStats()

    aggregate.ok = {'host1': 1}
    aggregate.decrement('ok', 'host1')
    assert aggregate.ok['host1'] == 0

    aggregate.ok = {'host1': 0}
    aggregate.decrement('ok', 'host1')
    assert aggregate.ok['host1'] == 0

    aggregate.ok = {}
    aggregate.decrement('ok', 'host1')
    assert aggregate.ok['host1'] == 0

# Generated at 2022-06-10 23:33:40.251494
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ag = AggregateStats()
    ag.increment("ok", "host")

    assert ag.ok['host'] == 1
    ag.decrement("ok", "host")
    assert ag.ok['host'] == 0

# Generated at 2022-06-10 23:33:46.882936
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    # test for decrement to zero
    stats.ignored['dummy_host'] = 0
    stats.decrement('ignored', 'dummy_host')
    assert stats.ignored['dummy_host'] == 0
    # test for decrement to negative
    stats.ignored['dummy_host'] = 0
    stats.decrement('ignored', 'dummy_host')
    assert stats.ignored['dummy_host'] == 0
    # test for decrement to positive
    stats.ignored['dummy_host'] = 1
    stats.decrement('ignored', 'dummy_host')
    assert stats.ignored['dummy_host'] == 0

# Generated at 2022-06-10 23:33:54.967389
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Initialize a AggregateStats object with manually-created entries.
    stats = AggregateStats()
    stats.processed = {'host1': 1}
    stats.failures = {'host1': 2}
    stats.ok = {'host1': 3}
    stats.dark = {'host1': 4}
    stats.changed = {'host1': 5}
    stats.skipped = {'host1': 6}
    stats.rescued = {'host1': 7}
    stats.ignored = {'host1': 8}
    # Decrement ignored['host1'] to 0
    stats.decrement('ignored', 'host1')
    # Ensure that decrement did not affect any other entries
    assert stats.processed == {'host1': 1}

# Generated at 2022-06-10 23:34:00.178908
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg_stat = AggregateStats()
    agg_stat.increment("ok", "test_host")
    assert agg_stat.ok == {"test_host": 1}
    agg_stat.increment("ok", "test_host")
    assert agg_stat.ok == {"test_host": 2}
    agg_stat.increment("ok", "test_host2")
    assert agg_stat.ok == {"test_host": 2, "test_host2": 1}


# Generated at 2022-06-10 23:34:03.606927
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    from ansible.utils.vars import merge_hash
    from ansible.module_utils.common._collections_compat import MutableMapping

    agg = AggregateStats()
    agg.increment('ok', 'foo')
    agg.decrement('ok', 'foo')
    assert agg.ok['foo'] == 0

# Generated at 2022-06-10 23:34:05.447107
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg_stats = AggregateStats()
    agg_stats.ok['test'] = 1
    agg_stats.decrement('ok', 'test')
    assert agg_stats.ok['test'] == 0



# Generated at 2022-06-10 23:34:13.739024
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.decrement('ignored', '_run') == None

    aggregate_stats.ignored = {}
    aggregate_stats.ignored['_run'] = 0
    assert aggregate_stats.decrement('ignored', '_run') == None
    assert aggregate_stats.ignored['_run'] == 0

    aggregate_stats.ignored['_run'] = 1
    assert aggregate_stats.decrement('ignored', '_run') == None
    assert aggregate_stats.ignored['_run'] == 0

    aggregate_stats.ignored = {}
    assert aggregate_stats.decrement('ignored', '_run') == None
    assert aggregate_stats.ignored['_run'] == 0

# Generated at 2022-06-10 23:34:16.064562
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok['testhost'] = 5
    stats.decrement('ok', 'testhost')
    assert stats.ok['testhost'] == 4

# Generated at 2022-06-10 23:34:28.296892
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    stats.update_custom_stats('foo', 'bar', 'test_host')
    assert stats.custom['test_host']['foo'] == 'bar'

    stats.update_custom_stats('foo', {'a': 'b', 'a1': 'b1'}, 'test_host')
    assert stats.custom['test_host']['foo'] == {'a': 'b', 'a1': 'b1'}

    stats.update_custom_stats('foo', {'a': 'b', 'a1': 'b1'}, 'test_host')
    assert stats.custom['test_host']['foo'] == {'a': 'b', 'a1': 'b1'}


# Generated at 2022-06-10 23:34:39.878213
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    from ansible.module_utils.common._collections_compat import MutableMapping

    st = AggregateStats()
    st.update_custom_stats('test', 1)
    assert st.custom['_run']['test'] == 1
    st.update_custom_stats('test', 1)
    assert st.custom['_run']['test'] == 2
    st.update_custom_stats('test', 1)
    assert st.custom['_run']['test'] == 3

    st2 = AggregateStats()
    st2.update_custom_stats('test', {'a': 1, 'b': 2})
    assert st2.custom['_run']['test'] == {'a': 1, 'b': 2}

# Generated at 2022-06-10 23:34:46.942003
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    '''Unit test for method update_custom_stats of class AggregateStats'''

    # Test with a single call to update_custom_stats
    # The method is called with which = 'stats', host = 'example.org' and what = {u'counters': {
    # u'changed': 3, u'skipped': 2, u'ok': 5, u'unreachable': 0, u'failures': 0}, u'failures': [],
    # u'ok': {u'reboot': {u'invocation': {u'module_name': u'command', u'_ansible_no_log': False,
    # u'_ansible_verbose_always': False}, u'changed': True, u'_ansible_item_label': u'reboot',
    # u'_ansible_loop_var': u

# Generated at 2022-06-10 23:34:53.842425
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('test_dict', {'a': 'b'}, 'test_host')
    stats.update_custom_stats('test_dict', {'c': 'd'}, 'test_host')
    assert stats.get_custom_stats('test_dict', 'test_host') == {'a': 'b', 'c': 'd'}
    stats.update_custom_stats('test_dict', {'a': 'f'}, 'test_host')
    assert stats.get_custom_stats('test_dict', 'test_host') == {'a': 'f', 'c': 'd'}
    stats.update_custom_stats('test_dict2', {'a': ['b']}, 'test_host')

# Generated at 2022-06-10 23:35:04.299005
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    as_ = AggregateStats()

    # Test for int
    as_.set_custom_stats('test_int', 1)
    as_.update_custom_stats('test_int', 2)
    assert as_.custom.get('_run').get('test_int') == 3

    # Test for dict
    as_.set_custom_stats('test_dict', {'a': 1})
    as_.update_custom_stats('test_dict', {'b': 2})
    assert as_.custom.get('_run').get('test_dict') == {'a': 1, 'b': 2}

    # Test that the value is not updated when it is a different type
    as_.set_custom_stats('non_mutable_mapping', [1, 2])

# Generated at 2022-06-10 23:35:11.761831
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggr_stat = AggregateStats()
    # Test 1: adding string
    aggr_stat.update_custom_stats("string", "Hello", None)
    assert aggr_stat.custom['_run']['string'] == "Hello"
    # Test 2: adding integer
    aggr_stat.update_custom_stats("integer", 10, None)
    assert aggr_stat.custom['_run']['integer'] == 10
    # Test 3: adding dictionary
    aggr_stat.update_custom_stats("dict", {"a": 1}, None)
    assert aggr_stat.custom['_run'] == {'string': 'Hello', 'integer': 10, 'dict': {'a': 1}}
    # Test 4: adding another dictionary

# Generated at 2022-06-10 23:35:17.985808
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats("test", 1)
    assert stats.custom["_run"] == {'test': 1}
    stats.update_custom_stats("test", 1)
    assert stats.custom["_run"] == {'test': 2}
    stats.update_custom_stats("test", 1, "host")
    assert stats.custom["host"] == {'test': 1}
    stats.update_custom_stats("test", {"a": 1}, "host")
    assert stats.custom["host"] == {'test': {'a': 1}}
    # mismatching types
    stats.update_custom_stats("test", "ab", "host")
    assert stats.custom["host"] == {'test': {'a': 1}}

# Generated at 2022-06-10 23:35:26.358663
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()

    # check if 'None' is returned when there is no host in custom
    assert aggregate_stats.update_custom_stats('test', 'value', 'host') is None
    assert aggregate_stats.custom == {}

    aggregate_stats.custom['host'] = {'test': 'old_value'}
    # check if 'None' is returned when type of value does not match
    assert aggregate_stats.update_custom_stats('test', 'value', 'host') is None
    assert aggregate_stats.custom == {'host': {'test': 'old_value'}}

    # check if value is properly updated when match in type
    aggregate_stats.custom = {'_run': {'test': 'old_value'}}
    aggregate_stats.update_custom_stats('test', 1, '_run')

# Generated at 2022-06-10 23:35:37.003731
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # initialize a class
    aggregateStats = AggregateStats()

    assert aggregateStats.custom == {}

    # set a custom stat
    aggregateStats.set_custom_stats("foo", "bar", "baz")
    assert aggregateStats.custom == {"baz":{"foo": "bar"}}

    # update custom stat
    aggregateStats.update_custom_stats("foo", "newest", "baz")
    assert aggregateStats.custom == {"baz":{"foo": "newest"}}

    # update with mismatching types
    aggregateStats.update_custom_stats("foo", 1, "baz")
    assert aggregateStats.custom == {"baz":{"foo": 1}}

    aggregateStats.update_custom_stats("foo", {"new": "value"}, "baz")

# Generated at 2022-06-10 23:35:46.152816
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Create the object instance
    aggregate_stats = AggregateStats()
    # By default, no custom stats have been set
    assert(len(aggregate_stats.custom) == 0)
    # Aggregate stats for a host
    aggregate_stats.update_custom_stats(which='yo', what='hello', host='host1')
    assert(len(aggregate_stats.custom) == 1)
    assert(len(aggregate_stats.custom['host1']) == 1)
    assert(aggregate_stats.custom['host1']['yo'] == 'hello')
    aggregate_stats.update_custom_stats(which='yo', what='world', host='host1')
    assert(len(aggregate_stats.custom) == 1)
    assert(len(aggregate_stats.custom['host1']) == 1)
   