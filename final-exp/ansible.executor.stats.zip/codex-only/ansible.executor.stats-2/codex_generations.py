

# Generated at 2022-06-22 20:15:03.521579
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    import unittest
    class TestAggregateStats(unittest.TestCase):
        def setUp(self):
            self.stats = AggregateStats()

        def test_AggregateStats_summarize_empty(self):
            self.assertEqual(self.stats.summarize('testhost'), {'ok':0, 'failures':0, 'unreachable':0, 'changed':0, 'skipped':0, 'rescued':0, 'ignored':0})

        def test_AggregateStats_summarize_normal(self):
            self.stats.increment('ok', 'testhost')
            self.stats.increment('failures', 'testhost')
            self.stats.increment('dark', 'testhost')
            self.stats.increment('changed', 'testhost')

# Generated at 2022-06-22 20:15:07.169016
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment(what='ok', host='127.0.0.1')
    assert stats.ok['127.0.0.1'] == 1
    assert stats.processed['127.0.0.1'] == 1


# Generated at 2022-06-22 20:15:11.061945
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():

    stats = AggregateStats()
    stats.increment('ok', 'host0')
    stats.increment('ok', 'host0')
    stats.increment('ok', 'host0')
    result = stats.summarize('host0')
    assert result['ok'] == 3


# Generated at 2022-06-22 20:15:20.369783
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    from ansible.module_utils.common._collections_compat import MutableSet

    ans_set = MutableSet(['t1', 't2', 't3'])

    stats = AggregateStats()
    stats.ok = dict.fromkeys(ans_set, 100)
    stats.failures = dict.fromkeys(ans_set, 200)
    stats.dark = dict.fromkeys(ans_set, 0)
    stats.changed = dict.fromkeys(ans_set, 10)
    stats.skipped = dict.fromkeys(ans_set, 0)
    stats.rescued = dict.fromkeys(ans_set, 0)
    stats.ignored = dict.fromkeys(ans_set, 0)


# Generated at 2022-06-22 20:15:26.058636
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    h = AggregateStats()
    h.update_custom_stats('custom_data', {'key1': 'value1'})
    h.update_custom_stats('custom_data', {'key2': 'value2'})
    assert h.custom['_run']['custom_data'] == {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-22 20:15:29.686171
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats("foo", ["some list"])
    assert stats.custom["_run"]["foo"] == ["some list"]


# Generated at 2022-06-22 20:15:37.754786
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    name = 'Test'
    test_hosts = ['host1', 'host2']
    test_what = ['ok', 'dark']
    test_stats = AggregateStats()

    for host in test_hosts:
        for what in test_what:
            test_stats.increment(what, host)

    assert test_stats.ok[test_hosts[0]] == 1
    assert test_stats.ok[test_hosts[1]] == 1
    assert test_stats.dark[test_hosts[0]] == 1
    assert test_stats.dark[test_hosts[1]] == 1

# Generated at 2022-06-22 20:15:41.728347
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.failures['localhost'] = 1
    stats.decrement('failures', 'localhost')
    assert stats.failures['localhost'] == 0

    stats.decrement('failures', 'something')
    assert stats.failures['something'] == 0



# Generated at 2022-06-22 20:15:49.289999
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    a = AggregateStats()

    a.increment('ok', 'host1')
    a.increment('ok', 'host1')
    a.increment('ok', 'host1')
    a.increment('ok', 'host2')
    a.increment('failures', 'host2')
    a.increment('ok', 'host2')
    a.increment('ok', 'host2')
    a.increment('ok', 'host2')
    a.increment('ok', 'host2')
    a.increment('ok', 'host3')
    a.increment('failures', 'host3')
    a.increment('failures', 'host3')
    a.increment('failures', 'host3')
    a.increment('ok', 'host3')

    assert a.sum

# Generated at 2022-06-22 20:16:00.277117
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ast = AggregateStats()
    ast.increment('ok', 'host1')
    ast.increment('dark', 'host2')
    ast.increment('ok', 'host1')
    ast.increment('ok', 'host2')
    ast.increment('failures', 'host2')
    ast.increment('skipped', 'host2')
    assert ast.ok == {'host1': 2, 'host2': 1}
    assert ast.dark == {'host2': 1}
    assert ast.failures == {'host2': 1}
    assert ast.skipped == {'host2': 1}
    assert ast.ok == {'host1': 2, 'host2': 1}


# Generated at 2022-06-22 20:16:05.871464
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg = AggregateStats()
    agg.FAILED = False
    agg.set_custom_stats('foo', 'bar')
    agg.set_custom_stats('foo', 'baz', 'localhost')
    assert agg.custom['_run']['foo'] == 'bar'
    assert agg.custom['localhost']['foo'] == 'baz'


# Generated at 2022-06-22 20:16:11.448423
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-22 20:16:21.927091
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import json
    import pytest
    stats = AggregateStats()

    stats.update_custom_stats("test", 1, "host1")
    assert stats.custom.get("host1", {}).get("test") == 1

    stats.update_custom_stats("test", 2, "host1")
    assert stats.custom.get("host1", {}).get("test") == 3

    stats.update_custom_stats("test", [0], "host2")
    assert stats.custom.get("host2", {}).get("test") == [0]

    stats.update_custom_stats("test", [1], "host2")
    assert stats.custom.get("host2", {}).get("test") == [1]

    stats.update_custom_stats("test", "string", "host3")
    assert stats.custom

# Generated at 2022-06-22 20:16:33.333268
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    stats.increment('failures', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('dark', 'localhost')
    stats.increment('changed', 'localhost')
    stats.increment('skipped', 'localhost')
    stats.increment('rescued', 'localhost')
    stats.increment('ignored', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')

    assert stats.processed == {'localhost' : 1}
    assert stats.failures == {'localhost' : 1}


# Generated at 2022-06-22 20:16:44.181210
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    from ansible.callbacks import AggregateStats
    astat = AggregateStats()
    astat.increment("ok", "localhost")
    assert astat.processed["localhost"] == 1
    assert astat.ok["localhost"] == 1
    assert astat.failures["localhost"] == 0
    assert astat.dark["localhost"] == 0
    assert astat.changed["localhost"] == 0
    assert astat.skipped["localhost"] == 0
    assert astat.rescued["localhost"] == 0
    assert astat.ignored["localhost"] == 0

    astat.increment("failures", "localhost")
    assert astat.processed["localhost"] == 1
    assert astat.ok["localhost"] == 1
    assert astat.failures["localhost"] == 1
    assert astat.dark["localhost"] == 0

# Generated at 2022-06-22 20:16:53.211466
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    import pytest
    aggregates_stats = AggregateStats()
    aggregates_stats.increment('ok', 'hostname')
    aggregates_stats.increment('changed', 'hostname')
    aggregates_stats.increment('ignored', 'hostname')
    aggregates_stats.increment('dark', 'hostname')
    aggregates_stats.increment('rescued', 'hostname')
    aggregates_stats.increment('failures', 'hostname')
    aggregates_stats.increment('skipped', 'hostname')


# Generated at 2022-06-22 20:17:00.901620
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    result = AggregateStats()
    result.ok = {'ok': 1}
    result.decrement('ok', 'ok')
    assert result.ok.get('ok') == 0
    result.decrement('ok', 'nook')
    assert result.ok.get('nook') == 0

    # test for random decrement
    result.changed = {'changed': 2}
    result.decrement('changed', 'changed')
    assert result.changed.get('changed') == 1

# Generated at 2022-06-22 20:17:04.168779
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('file', 5)
    assert stats.custom['_run']['file'] == 5


# Generated at 2022-06-22 20:17:07.174755
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg = AggregateStats()
    agg.increment('ok', 'host')
    agg.decrement('ok', 'host')

    assert agg.ok['host'] == 0


# Generated at 2022-06-22 20:17:13.743490
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate = AggregateStats()
    aggregate.ok = {'127.0.0.1':1}
    aggregate.decrement('ok', '127.0.0.1')
    assert aggregate.ok['127.0.0.1'] == 0
    aggregate.decrement('ok', '127.0.0.2')
    assert aggregate.ok['127.0.0.2'] == 0
    assert aggregate.ok['127.0.0.1'] == 0

# Generated at 2022-06-22 20:17:17.545179
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('changed', 'test_host')
    # Now test_host has one changed value
    assert(stats.changed['test_host'] == 1)


# Generated at 2022-06-22 20:17:28.548771
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'foohost')
    stats.increment('ok', 'bahost')
    stats.increment('ok', 'foohost')
    stats.increment('ok', 'foohost')
    stats.increment('ok', 'foohost')
    assert stats.ok['foohost'] == 3
    assert stats.ok['bahost'] == 1
    stats.increment('ok', 'foohost')
    assert stats.ok['foohost'] == 4
    stats.increment('ok', 'barhost')
    stats.increment('failures', 'barhost')
    assert stats.ok['barhost'] == 1
    assert stats.failures['barhost'] == 1


# Generated at 2022-06-22 20:17:38.157737
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Test for merging dictionaries
    as1 = AggregateStats()
    as1.update_custom_stats('foo', {'bar': 1, 'qux': True})
    as1.update_custom_stats('foo', {'bar': 2})
    assert as1.custom['_run']['foo']['bar'] == 2
    assert as1.custom['_run']['foo']['qux'] == True

    # Test for adding ints
    as2 = AggregateStats()
    as2.update_custom_stats('foo', 1)
    as2.update_custom_stats('foo', 2)
    assert as2.custom['_run']['foo'] == 3

    # Test for adding floats
    as3 = AggregateStats()

# Generated at 2022-06-22 20:17:42.487894
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-22 20:17:49.904738
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    host = "127.0.0.1"
    stats.increment("ok", host)
    assert stats.ok[host] == 1
    stats.increment("ok", host)
    assert stats.ok[host] == 2
    stats.increment("ignored", host)
    assert stats.ignored[host] == 1
    stats.increment("ignored", host)
    assert stats.ignored[host] == 2
    stats.increment("ignored", host)
    assert stats.ignored[host] == 3


# Generated at 2022-06-22 20:17:51.069445
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats != None


# Generated at 2022-06-22 20:18:03.149983
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import copy
    import json

    class TestClass:
        def __copy__(self):
            return TestClass()

        def __deepcopy__(self, memo):
            return TestClass()

    class TestClass2:
        def __init__(self, d):
            self.__dict__ = d

        def __repr__(self):
            return json.dumps(self.__dict__)

    agg_stats = AggregateStats()

    # test an immutable class
    val = TestClass()
    agg_stats.set_custom_stats('test', val)
    assert(agg_stats.custom == {'_run': {'test': val}})

    # TestClass2 is mutable
    val = TestClass2({'a': 1})
    agg_stats.set_custom_stats('test', val)
   

# Generated at 2022-06-22 20:18:07.874549
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}

# unit test for function increment

# Generated at 2022-06-22 20:18:13.087406
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', '192.168.1.1')
    assert stats.ok['192.168.1.1'] == 1
    stats.increment('ok', '192.168.1.1')
    assert stats.ok['192.168.1.1'] == 2


# Generated at 2022-06-22 20:18:24.865379
# Unit test for constructor of class AggregateStats
def test_AggregateStats():

    stats = AggregateStats()
    stats.increment('ok', 'host')
    stats.increment('ok', 'host')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('failures', 'host')
    stats.increment('failures', 'host1')
    stats.increment('changed', 'host2')

    assert stats.processed == {'host': 1, 'host1': 1, 'host2': 1}
    assert stats.ok == {'host': 2, 'host1': 1, 'host2': 1}
    assert stats.failures == {'host': 1, 'host1': 1}
    assert stats.changed == {'host2': 1}

# Generated at 2022-06-22 20:18:30.632913
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment("ok"     , "host1")

    assert stats.summarize("host1") == dict(ok=1, failures=0, unreachable=0, changed=0, skipped=0, rescued=0, ignored=0)
    assert stats.summarize("host2") == dict(ok=0, failures=0, unreachable=0, changed=0, skipped=0, rescued=0, ignored=0)

# Generated at 2022-06-22 20:18:37.217539
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    agg = AggregateStats()
    agg.update_custom_stats('test_map', {'all': 'all', 'none': 'none'}, '_run')
    assert agg.custom['_run']['test_map'] == {'all': 'all', 'none': 'none'}
    agg.update_custom_stats('test_map', {'all': 'override', 'new': 'new'}, '_run')
    assert agg.custom['_run']['test_map'] == {'all': 'override', 'none': 'none', 'new': 'new'}
    agg.update_custom_stats('test_map', {'all': 'override', 'new': 'new'}, '_run')

# Generated at 2022-06-22 20:18:46.160394
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    # Try with a custom stat that does not exist yet
    stats.update_custom_stats('custom', {'changed': {'ok': 1, 'changed': 2}}, host='host1')
    assert stats.custom == {'host1': {'custom': {'changed': {'ok': 1, 'changed': 2}}}}

    # Try with an existing stat
    stats.update_custom_stats('custom', {'changed': {'ok': 2, 'changed': 1}}, host='host1')
    assert stats.custom == {'host1': {'custom': {'changed': {'ok': 3, 'changed': 3}}}}

    # Try with a different stat
    stats.update_custom_stats('custom', {'changed': {'ok': 2, 'changed': 1}}, host='host2')

# Generated at 2022-06-22 20:18:57.696304
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    host = 'localhost'
    custom_stats_what = {'tests': 0, 'failures': 0, 'errors': 0, 'skipped': 0, 'expectedFailures': 0, 'unexpectedSuccesses': 0}
    custom_stats_what2 = {'tests': 5, 'failures': 2, 'errors': 0, 'skipped': 0, 'expectedFailures': 0, 'unexpectedSuccesses': 0}
    custom_stats_what3 = {'tests': 5, 'failures': 2, 'errors': 3, 'skipped': 0, 'expectedFailures': 0, 'unexpectedSuccesses': 0}
    custom_stats_what4 = {'tests': 6, 'failures': 2, 'errors': 3, 'skipped': 0, 'expectedFailures': 0, 'unexpectedSuccesses': 0}
    custom_stats_

# Generated at 2022-06-22 20:19:03.240953
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    a = AggregateStats()
    assert a.processed == {}
    assert a.failures == {}
    assert a.ok == {}
    assert a.dark == {}
    assert a.changed == {}
    assert a.skipped == {}
    assert a.rescued == {}
    assert a.ignored == {}
    assert a.custom == {}



# Generated at 2022-06-22 20:19:12.558910
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('test', 'value')
    assert stats.custom['_run']['test'] == 'value'
    stats.set_custom_stats('test', 'value2', 'host')
    assert stats.custom['host']['test'] == 'value2'
    stats.set_custom_stats('test', {'foo':'bar'})
    assert stats.custom['_run']['test'] == {'foo':'bar'}
    stats.set_custom_stats('test', {'baz':'qux'}, 'host')
    assert stats.custom['host']['test'] == {'baz':'qux'}


# Generated at 2022-06-22 20:19:17.162410
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}

    assert stats.custom == {}


# Generated at 2022-06-22 20:19:25.037439
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    A = AggregateStats()
    A.rescued = {'1': 10, '2': 10}
    A.decrement('rescued', '1')
    assert A.rescued['1'] == 9
    A.decrement('rescued', '2')
    assert A.rescued['2'] == 9
    A.decrement('rescued', '2')
    assert A.rescued['2'] == 8

# Generated at 2022-06-22 20:19:35.040227
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # variable to store result
    result = None
    # variable to store expected result
    expected = None

    # set object as AggregateStats and set stats as follows
    #  ok: 1
    #  failures: 1
    #  dark: 1
    #  changed: 1
    #  skipped: 1
    #  rescued: 1
    #  ignored: 1
    # and host is 'host'
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'host')
    aggregate_stats.increment('failures', 'host')
    aggregate_stats.increment('dark', 'host')
    aggregate_stats.increment('changed', 'host')
    aggregate_stats.increment('skipped', 'host')
    aggregate_stats.increment('rescued', 'host')
    aggregate_stats

# Generated at 2022-06-22 20:19:45.310930
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    # Test with empty custom dictionary
    test_stat = AggregateStats()
    test_stat.set_custom_stats('foo_stat', 'bar', 'host1')
    assert test_stat.custom['host1'] == {'foo_stat': 'bar'}

    # Test with existing values in the dictionary
    test_stat = AggregateStats()
    test_stat.custom = {'host1': {'original_stat': 'first'}}
    test_stat.set_custom_stats('foo_stat', 'bar', 'host1')
    assert test_stat.custom['host1'] == {'original_stat': 'first', 'foo_stat': 'bar'}

    # Test with default host
    test_stat = AggregateStats()
    test_stat.set_custom_stats('foo_stat', 'bar')

# Generated at 2022-06-22 20:19:55.228482
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Test case: mismatching types. Should not return any value and keep old value
    ag1 = AggregateStats()
    ag1.set_custom_stats('myrun', 'ok', 'host1')
    ag1.set_custom_stats('myrun', 12, 'host2')
    test_passed = ag1.custom['host1']['myrun'] == 'ok'
    ag1.update_custom_stats('myrun', 'changed', 'host1')
    test_passed = test_passed and ag1.custom['host1']['myrun'] == 'ok'
    ag1.update_custom_stats('myrun', 'ok', 'host2')
    test_passed = test_passed and ag1.custom['host2']['myrun'] == 12

# Generated at 2022-06-22 20:20:04.479631
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    as_obj = AggregateStats()

# Generated at 2022-06-22 20:20:13.491525
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    """Test decrement method"""


# Generated at 2022-06-22 20:20:16.222848
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    """
    Creates the object AggregateStats
    """
    A = AggregateStats()
    assert type(A) == AggregateStats
    assert len(A.__dict__.keys()) == 6


# Generated at 2022-06-22 20:20:27.963740
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats("foo", "bar")
    assert stats.custom == {'_run': {'foo': 'bar'}}

    # Update custom stats with mismatching types
    stats = AggregateStats()
    stats.update_custom_stats("foo", "bar")
    assert stats.custom == {'_run': {'foo': 'bar'}}
    stats.update_custom_stats("foo", 100)
    assert stats.custom == {'_run': {'foo': 'bar'}}

    stats = AggregateStats()
    stats.update_custom_stats("foo", "bar")
    assert stats.custom == {'_run': {'foo': 'bar'}}
    stats.update_custom_stats("foo", {'a': 1})

# Generated at 2022-06-22 20:20:40.430923
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():

    aggregate = AggregateStats()

    # Test for a valid host
    aggregate.set_custom_stats('key1', 'value1', 'host1')
    assert aggregate.custom['host1'] == {'key1': 'value1'}

    # Test for a non-existent key
    aggregate.set_custom_stats('key2', 'value2', 'host1')
    assert aggregate.custom['host1'] == {'key1': 'value1', 'key2': 'value2'}

    # Test for an existing key
    aggregate.set_custom_stats('key2', 'value3', 'host1')
    assert aggregate.custom['host1'] == {'key1': 'value1', 'key2': 'value3'}

    # Test for a valid host

# Generated at 2022-06-22 20:20:46.293910
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg_stats = AggregateStats()
    assert agg_stats.processed == {}
    assert agg_stats.failures == {}
    assert agg_stats.ok == {}
    assert agg_stats.dark == {}
    assert agg_stats.changed == {}
    assert agg_stats.skipped == {}
    assert agg_stats.rescued == {}
    assert agg_stats.ignored == {}
    assert agg_stats.custom == {}


# Generated at 2022-06-22 20:20:52.577922
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('test_attr', 'test_val')
    stats.set_custom_stats('test_attr1', 'test_val1', 'test_host')

    assert stats.custom['test_host']['test_attr1'] == 'test_val1', "AggregateStats class: set_custom_stats failed"


# Generated at 2022-06-22 20:20:57.184319
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():

    ag = AggregateStats()
    ag.increment('ok', 'host1')
    ag.increment('ok', 'host1')
    ag.increment('ok', 'host2')
    assert ag.summarize('host1')['ok'] == 2
    assert ag.summarize('host2')['ok'] == 1


# Generated at 2022-06-22 20:20:59.751025
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats("count", 1, "localhost")
    assert stats.custom["localhost"]["count"] == 1


# Generated at 2022-06-22 20:21:01.737260
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    stats.increment("ok", "host1")
    stats.increment("ok", "host1")
    assert stats.ok["host1"] == 2

    stats.increment("ok", "host1")
    assert stats.ok["host1"] == 3


# Generated at 2022-06-22 20:21:12.756626
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    # Check that the class got initialised with 5 variables (processed, failures, ok, dark and changed)
    assert len(stats.__dict__.keys()) == 8
    # Check that each of those variables are initialised as dictionaries
    for i in stats.__dict__.keys():
        assert type(stats.__dict__[i]) == dict
    assert len(stats.processed) == 0
    assert len(stats.failures) == 0
    assert len(stats.ok) == 0
    assert len(stats.dark) == 0
    assert len(stats.changed) == 0
    assert len(stats.skipped) == 0
    assert len(stats.rescued) == 0
    assert len(stats.ignored) == 0
    assert len(stats.custom) == 0

# Unit

# Generated at 2022-06-22 20:21:24.038762
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg = AggregateStats()
    agg.set_custom_stats('set_custom_stats', 1)
    assert agg.custom['_run']['set_custom_stats'] == 1
    agg.set_custom_stats('set_custom_stats', '1')
    assert agg.custom['_run']['set_custom_stats'] == '1'
    agg.set_custom_stats('set_custom_stats', ['1'])
    assert agg.custom['_run']['set_custom_stats'] == ['1']
    agg.set_custom_stats('set_custom_stats', {'1':1})
    assert agg.custom['_run']['set_custom_stats'] == {'1':1}



# Generated at 2022-06-22 20:21:31.334379
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()

    # Add a custom stat with a host
    aggregate_stats.set_custom_stats('TEST', 5, 'myhost')

    assert aggregate_stats.custom['myhost']['TEST'] == 5

    # Add a custom stat without host
    aggregate_stats.set_custom_stats('TEST', 10, '_run')

    assert aggregate_stats.custom['_run']['TEST'] == 10


# Generated at 2022-06-22 20:21:38.961912
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('mystat', 1)
    assert stats.custom['_run']['mystat'] == 1
    # Now check per-host statistics
    stats.set_custom_stats('mystat', 1, 'localhost')
    assert stats.custom['_run']['mystat'] == 1
    assert stats.custom['localhost']['mystat'] == 1
    # Check invalid types
    stats.set_custom_stats('mystat_invalid', stats)
    assert 'mystat_invalid' not in stats.custom['_run']
    assert stats.custom['localhost']['mystat'] == 1


# Generated at 2022-06-22 20:21:42.291431
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('a', 1, 'foo')
    assert stats.custom == {'foo': {'a': 1}}


# Generated at 2022-06-22 20:21:47.516721
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok = {
        'test': 1,
        'test2': 5
    }
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 0
    assert stats.ok['test2'] == 5


# Generated at 2022-06-22 20:21:55.850122
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggstat = AggregateStats()
    assert aggstat.processed == {}
    assert aggstat.failures == {}
    assert aggstat.ok == {}
    assert aggstat.dark == {}
    assert aggstat.changed == {}
    assert aggstat.skipped == {}
    assert aggstat.rescued == {}
    assert aggstat.ignored == {}
    assert aggstat.custom == {}
    assert aggstat.summarize('localhost') == {'ok': 0, 'failures': 0, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}
    aggstat.increment('ok', 'localhost')
    assert aggstat.ok['localhost'] == 1
    aggstat.decrement('ok', 'localhost')

# Generated at 2022-06-22 20:22:01.587376
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    # Init
    aggregate_stats = AggregateStats()
    aggregate_stats.ok['example.org'] = 1
    aggregate_stats.changed['example.org'] = 3
    aggregate_stats.skipped['example.org'] = 0

    # Test
    result = aggregate_stats.summarize('example.org')

    # Verify
    assert result == dict(ok=1, failures=0, unreachable=0, changed=3,
                            skipped=0, rescued=0, ignored=0)

# Generated at 2022-06-22 20:22:07.676591
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    instance = AggregateStats()
    instance.decrement("dark", "host")
    assert(instance.dark.get("host", None) == 0)

    instance.dark["host"] = 4
    instance.decrement("dark", "host")
    assert(instance.dark.get("host", None) == 3)

# Generated at 2022-06-22 20:22:15.607890
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    # Create a new AggregateStats object
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.set_custom_stats('foo', 'bar', 'host1')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    assert stats.get_custom_stats('foo', 'host1') == 'bar'
    stats.increment('ok', 'host1')
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0


# Generated at 2022-06-22 20:22:20.951374
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats(
        'variable',
        {
            'foo': 'bar',
        },
        '_run',
    )
    assert aggregate_stats.custom['_run'] == {'variable': {'foo': 'bar'}}  # pylint: disable=protected-access
    aggregate_stats.update_custom_stats(
        'variable',
        {
            'baz': 'blip',
        },
        '_run',
    )
    assert aggregate_stats.custom['_run'] == {'variable': {'foo': 'bar', 'baz': 'blip'}}  # pylint: disable=protected-access

# Generated at 2022-06-22 20:22:32.233550
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    # Test when all entries are present
    agg = AggregateStats()

    # Test when some entries are not present
    agg = AggregateStats()
    agg.increment('changed', 'host1')
    agg.increment('changed', 'host1')
    agg.increment('changed', 'host1')
    agg.increment('ok', 'host1')
    agg.increment('ok', 'host1')
    agg.increment('rescued', 'host1')
    agg.increment('ignored', 'host1')
    agg.increment('failures', 'host1')
    agg.increment('dark', 'host1')


# Generated at 2022-06-22 20:22:40.938418
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('test', 1)
    assert stats.custom == {'_run': {'test': 1}}

    stats.update_custom_stats('test', {'key': 1})
    assert stats.custom == {'_run': {'test': {'key':1}}}

    stats.update_custom_stats('test', {'key2': 2})
    assert stats.custom == {'_run': {'test': {'key': 1, 'key2': 2}}}

    stats.update_custom_stats('test', 1, 'host')
    assert stats.custom == {'_run': {'test': {'key': 1, 'key2': 2}}, 'host': {'test': 1}}


# Generated at 2022-06-22 20:22:52.426046
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    as_ = AggregateStats()
    host = 'test.host.example'

    # verify all initial values are zero
    assert as_.processed[host] == 0
    assert as_.failures[host] == 0
    assert as_.ok[host] == 0
    assert as_.dark[host] == 0
    assert as_.changed[host] == 0
    assert as_.skipped[host] == 0
    assert as_.rescued[host] == 0
    assert as_.ignored[host] == 0
    assert as_.custom[host] == {}

    # verify all values are incremented by one
    as_.increment('processed', host)
    as_.increment('failures', host)
    as_.increment('ok', host)
    as_.increment('dark', host)

# Generated at 2022-06-22 20:22:57.106016
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('dark', 'localhost')
    stats.decrement('dark', 'localhost')
    assert stats.dark['localhost'] == 0
    stats.decrement('dark', 'localhost')
    assert stats.dark['localhost'] == 0

# Generated at 2022-06-22 20:23:00.947288
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    stats.increment('ok', 'test_host')
    assert stats.ok['test_host'] == 1
    stats.decrement('ok', 'test_host')
    assert stats.ok['test_host'] == 0
    try:
        stats.decrement('ok', 'test_host')
    except KeyError:
        pass
    assert 'test_host' not in stats.ok



# Generated at 2022-06-22 20:23:10.843099
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    c = AggregateStats()
    c.increment('ok', 'host1')
    c.increment('ok', 'host1')
    c.increment('ok', 'host2')
    assert c.ok['host1'] == 2
    assert c.ok['host2'] == 1
    assert c.processed['host1'] == 1
    assert c.processed['host2'] == 1
    assert c.ok['host1'] == 2
    assert c.processed['host1'] == 1
    assert c.ok['host2'] == 1
    assert c.processed['host2'] == 1



# Generated at 2022-06-22 20:23:18.393576
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ans = AggregateStats()

    # On runtime the host was not processed
    assert all(value == 0 for value in ans.processed.values())

    # The host was processed once
    ans.increment("ok", "localhost")
    assert ans.processed["localhost"] == 1
    assert ans.ok["localhost"] == 1

    # The host was processed twice more (3 times total)
    ans.increment("ok", "localhost")
    ans.increment("ok", "localhost")
    assert ans.processed["localhost"] == 1
    assert ans.ok["localhost"] == 3



# Generated at 2022-06-22 20:23:29.036474
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'example_host')
    stats.increment('ok', 'example_host')
    stats.increment('ok', 'example_host')
    stats.increment('ok', 'another_host')
    stats.increment('ok', 'another_host')
    stats.increment('changed', 'another_host')
    assert stats.summarize('example_host') == {'ok': 3, 'failures': 0, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}, 'summarize did not return expected result on example_host'

# Generated at 2022-06-22 20:23:36.748064
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    # type: () -> None

    aggregate_stats = AggregateStats()

    aggregate_stats.set_custom_stats(which="memory", what=8, host="server1")
    aggregate_stats.set_custom_stats(which="disk", what=1, host="server1")

    aggregate_stats.set_custom_stats(which="memory", what=32, host="server2")
    aggregate_stats.set_custom_stats(which="disk", what=2, host="server2")

    assert aggregate_stats.custom == {
        "server1": {
            "memory": 8,
            "disk": 1
        },
        "server2": {
            "memory": 32,
            "disk": 2
        }
    }


# Generated at 2022-06-22 20:23:43.108672
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    astat = AggregateStats()
    assert isinstance(astat, AggregateStats)
    assert astat.processed == {}
    assert astat.failures == {}
    assert astat.ok == {}
    assert astat.dark == {}
    assert astat.changed == {}
    assert astat.skipped == {}
    assert astat.rescued == {}
    assert astat.ignored == {}
    assert astat.custom == {}

# Generated at 2022-06-22 20:23:49.477772
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("ok", "localhost")
    assert stats.ok["localhost"] == 1
    assert stats.processed["localhost"] == 1
    stats.increment("ok", "localhost")
    assert stats.ok["localhost"] == 2
    assert stats.processed["localhost"] == 1
    stats.increment("ok", "remotehost")
    assert stats.ok["remotehost"] == 1
    assert stats.processed["remotehost"] == 1


# Generated at 2022-06-22 20:23:56.545894
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()

    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-22 20:24:05.683702
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    # Initialize AggregateStats instance
    aggregate_stats_instance = AggregateStats()

    # Test that a custom stat is updated with a new value
    aggregate_stats_instance.update_custom_stats('test_var', 'test_value')
    assert aggregate_stats_instance.custom['_run']['test_var'] == 'test_value'

    # Test that a custom stat is updated with a new value
    aggregate_stats_instance.update_custom_stats('test_var', 'new_test_value')
    assert aggregate_stats_instance.custom['_run']['test_var'] == 'new_test_value'

    # Test that a custom stat is updated with a new value
    aggregate_stats_instance.update_custom_stats('test_var', {'key': 'value'})

# Generated at 2022-06-22 20:24:17.586851
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    s = AggregateStats()
    s.processed['c'] = 1
    s.ok['c'] = 2
    s.rescued['c'] = 2
    s.decrement('ok', 'c')
    assert s.ok['c'] == 1
    s.decrement('rescued', 'c')
    assert s.rescued['c'] == 1
    s.decrement('ok', 'c')
    assert s.ok['c'] == 0
    s.decrement('rescued', 'c')
    assert s.rescued['c'] == 0
    with pytest.raises(KeyError):
        s.decrement('custom', 'c')
    with pytest.raises(KeyError):
        s.decrement('rescued', 'cat')

#

# Generated at 2022-06-22 20:24:22.864052
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.summarize('localhost') == {
        'ok': 0,
        'failures': 0,
        'unreachable': 0,
        'changed': 0,
        'skipped': 0,
        'rescued': 0,
        'ignored': 0,
    }
    aggregate_stats.increment('ok', 'localhost')
    assert aggregate_stats.summarize('localhost') == {
        'ok': 1,
        'failures': 0,
        'unreachable': 0,
        'changed': 0,
        'skipped': 0,
        'rescued': 0,
        'ignored': 0,
    }



# Generated at 2022-06-22 20:24:30.396938
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment(u'ok', u'test_host')
    assert(stats.ok[u'test_host'] == 1)
    stats.decrement(u'ok', u'test_host')
    assert(stats.ok[u'test_host'] == 0)
    stats.decrement(u'ok', u'test_host')
    assert(stats.ok[u'test_host'] == 0)


# Generated at 2022-06-22 20:24:40.783310
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    test_agg_stats = AggregateStats()
    assert test_agg_stats.processed == {}
    assert test_agg_stats.failures == {}
    assert test_agg_stats.ok == {}
    assert test_agg_stats.dark == {}
    assert test_agg_stats.changed == {}
    assert test_agg_stats.skipped == {}
    assert test_agg_stats.rescued == {}
    assert test_agg_stats.ignored == {}
    assert test_agg_stats.custom == {}

    test_agg_stats.increment('ok', 'test-host')
    assert test_agg_stats.processed == {'test-host': 1}
    assert test_agg_stats.failures == {}
    assert test_agg_stats.ok == {'test-host': 1}
    assert test

# Generated at 2022-06-22 20:24:43.410084
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    test_object = AggregateStats()
    assert isinstance(test_object, AggregateStats)


# Generated at 2022-06-22 20:24:49.212835
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg = AggregateStats()
    assert agg.processed == {}
    assert agg.failures == {}
    assert agg.ok == {}
    assert agg.dark == {}
    assert agg.changed == {}
    assert agg.skipped == {}
    assert agg.rescued == {}
    assert agg.ignored == {}
    assert agg.custom == {}



# Generated at 2022-06-22 20:24:58.938605
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('failures', 'host1')
    stats.increment('changed', 'host2')
    stats.increment('dark', 'host1')
    stats.increment('skipped', 'host1')
    stats.increment('skipped', 'host2')
    stats.increment('skipped', 'host2')
    stats.increment('rescued', 'host1')
    stats.increment('ignored', 'host1')
    stats.increment('ignored', 'host2')
    stats.set_custom_stats('foo', 'bar', 'host2')
    stats.set_custom_stats