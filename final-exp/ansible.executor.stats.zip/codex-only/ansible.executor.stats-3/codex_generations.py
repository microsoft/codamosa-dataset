

# Generated at 2022-06-22 20:15:03.185002
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.utils.vars import merge_hash

    stats = AggregateStats()
    stats.update_custom_stats('succeeded_count', 1)
    assert isinstance(stats.custom['_run']['succeeded_count'], int)
    assert stats.custom['_run']['succeeded_count'] == 1

    stats.update_custom_stats('succeeded_count', 2)
    assert stats.custom['_run']['succeeded_count'] == 3

    stats.update_custom_stats('statuses', {'status1': 'failed'})
    assert isinstance(stats.custom['_run']['statuses'], MutableMapping)

# Generated at 2022-06-22 20:15:14.015809
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Test with a property that has not been initialized
    stats = AggregateStats()
    stats.decrement("failures", "someHost")
    assert stats.failures["someHost"] == 0

    # Test with a property that has been initialized
    stats.increment("failures", "someHost")
    stats.decrement("failures", "someHost")
    assert stats.failures["someHost"] == 0

    # Test with a lower value
    stats.failures["someHost"] = 3
    stats.decrement("failures", "someHost")
    assert stats.failures["someHost"] == 2

    # Test with a negative value
    stats.failures["someHost"] = -1
    stats.decrement("failures", "someHost")
    assert stats.failures["someHost"] == 0



# Generated at 2022-06-22 20:15:22.485108
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ag = AggregateStats()

    # a new object should be empty
    assert ag.__dict__ == {
        'processed': {},
        'failures': {},
        'ok': {},
        'dark': {},
        'changed': {},
        'skipped': {},
        'rescued': {},
        'ignored': {},
        'custom': {},
    }

    # Increment all fields
    for field in ag.__dict__.keys():
        # By default consider the host as localhost
        ag.increment(field, 'localhost')
        assert ag.__dict__[field] == {'localhost': 1}

        # Increment the same field for a remote host
        ag.increment(field, 'remotehost')

# Generated at 2022-06-22 20:15:29.098707
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert(isinstance(stats.processed, dict))
    assert(isinstance(stats.failures, dict))
    assert(isinstance(stats.ok, dict))
    assert(isinstance(stats.dark, dict))
    assert(isinstance(stats.changed, dict))
    assert(isinstance(stats.skipped, dict))
    assert(isinstance(stats.rescued, dict))
    assert(isinstance(stats.ignored, dict))
    assert(isinstance(stats.custom, dict))


# Generated at 2022-06-22 20:15:34.104900
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok == {'localhost': 1}
    assert stats.processed == {'localhost': 1}
    assert stats.failures == {}
    stats.increment('failures', 'localhost')
    assert stats.ok == {'localhost': 1}
    assert stats.processed == {'localhost': 1}
    assert stats.failures == {'localhost': 1}


# Generated at 2022-06-22 20:15:44.249884
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    s = AggregateStats()
    s.decrement('ok', 'host1')
    assert s.ok['host1'] == 0, "ok should be 0 after decrementing from nothing"
    s.ok['host1'] = 2
    s.decrement('ok', 'host1')
    assert s.ok['host1'] == 1, "ok should be 1 after decrementing from 2"
    try:
        s.decrement('ok', 'host1')
        assert False, "decrementing ok from 1 should raise an exception"
    except KeyError:
        assert True
    # This will never happen but let's be safe
    s.ok = {'host1': 0}
    s.decrement('ok', 'host1')

# Generated at 2022-06-22 20:15:46.388340
# Unit test for constructor of class AggregateStats
def test_AggregateStats():

    try:
        # All fields should be empty
        stats = AggregateStats()
        assert stats.processed == {}
        assert stats.failures == {}
        assert stats.ok == {}
        assert stats.dark == {}
        assert stats.changed == {}
        assert stats.skipped == {}
        assert stats.rescued == {}
        assert stats.ignored == {}
        assert stats.custom == {}
    except:
        raise


# Generated at 2022-06-22 20:15:51.873995
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Initialization
    test_stats = AggregateStats()

    # Testing function
    # Dictionary
    test_stats.update_custom_stats('test_dict', {'test_key':'test_value'})
    assert test_stats.custom['_run']['test_dict']['test_key'] == 'test_value'

    # List
    test_stats.update_custom_stats('test_list', ['test_value_1', 'test_value_2'])
    assert test_stats.custom['_run']['test_list'][0] == 'test_value_1'
    assert test_stats.custom['_run']['test_list'][1] == 'test_value_2'

    # Integer
    test_stats.update_custom_stats('test_int', 1)

# Generated at 2022-06-22 20:15:56.489197
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}



# Generated at 2022-06-22 20:16:04.801619
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()

    stats.set_custom_stats('foo', 'bar', 'localhost')
    assert stats.custom == {'localhost': {'foo': 'bar'}}, "expected {'localhost': {'foo': 'bar'}}"

    stats.set_custom_stats('foo', 'baz', 'localhost')
    assert stats.custom == {'localhost': {'foo': 'baz'}}, "expected {'localhost': {'foo': 'baz'}}"

    stats.set_custom_stats('foo', 'qux', '127.0.0.1')

# Generated at 2022-06-22 20:16:12.329468
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('some_stat', 'some_value')
    assert stats.custom['_run'] == {'some_stat': 'some_value'}

    stats.set_custom_stats('some_stat', 'some_other_value', 'some_host')
    assert stats.custom['some_host'] == {'some_stat': 'some_other_value'}
    assert stats.custom['_run'] == {'some_stat': 'some_value'}



# Generated at 2022-06-22 20:16:22.599099
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok = {
        "host1": 1,
        "host2": 2,
        "host3": 3
    }
    stats.failures = {
        "host2": 3,
        "host3": 4
    }
    stats.dark = {
        "host1": 1,
        "host3": 2
    }
    stats.changed = {
        "host2": 3,
    }
    stats.skipped = {
        "host3": 4
    }
    stats.ignored = {
        "host3": 5
    }



# Generated at 2022-06-22 20:16:34.137815
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats("foo", "bar")
    assert stats.custom["_run"]["foo"] == "bar"
    stats.update_custom_stats("foo", "baz")
    assert stats.custom["_run"]["foo"] == "baz"
    stats.update_custom_stats("foo", "bar", host="localhost")
    assert stats.custom["localhost"]["foo"] == "bar"
    stats.update_custom_stats("foo", "baz")
    assert stats.custom["localhost"]["foo"] == "baz"
    stats.update_custom_stats("foo", "bar", host="example.com")
    assert stats.custom["example.com"]["foo"] == "bar"

# Generated at 2022-06-22 20:16:44.664524
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
   
    stats = AggregateStats()

    stats.increment("ok", "test-host")
    stats.increment("ok", "test-host")
    stats.increment("failures", "test-host")
    stats.increment("dark", "test-host")
    stats.increment("changed", "test-host")
    stats.increment("skipped", "test-host")
    stats.increment("rescued", "test-host")
    stats.increment("ignored", "test-host")
    
    expected_result = dict(
        ok=2,
        failures=1,
        unreachable=1,
        changed=1,
        skipped=1,
        rescued=1,
        ignored=1,
    )

    assert expected_result == stats.summarize("test-host")

# Generated at 2022-06-22 20:16:50.955916
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()
    assert isinstance(aggregate_stats, AggregateStats)
    assert aggregate_stats.processed == {}
    assert aggregate_stats.failures == {}
    assert aggregate_stats.ok == {}
    assert aggregate_stats.dark == {}
    assert aggregate_stats.changed == {}
    assert aggregate_stats.skipped == {}
    assert aggregate_stats.rescued == {}
    assert aggregate_stats.ignored == {}
    assert aggregate_stats.custom == {}


# Generated at 2022-06-22 20:16:52.181096
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    assert AggregateStats() is not None
    


# Generated at 2022-06-22 20:17:03.808129
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    """
    This function tests the return value of the summarize method of the
    AggregateStats class.
    """

    # Create an object of type AggregateStats
    stats = AggregateStats()

    # The host strings used for the tests
    host1 = 'localhost'
    host2 = '127.0.0.1'
    host3 = 'www.ansible.com'

    # Initialize the dictionary of dictionaries
    stats.ok = {host1: 1, host2: 2, host3: 0}
    stats.failures = {host1: 3, host2: 4, host3: 5}
    stats.dark = {host1: 6, host2: 7, host3: 8}
    stats.changed = {host1: 9, host2: 10, host3: 11}

# Generated at 2022-06-22 20:17:13.384860
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    stats = AggregateStats()
    assert isinstance(stats, AggregateStats)

    stats.ok['host1'] = 2
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 1
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0
    try:
        stats.decrement('ok', 'host1')
        assert False
    except:
        assert True

    # now try a non-existing key
    assert 'host2' not in stats.ok
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 0

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-22 20:17:22.037431
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('changed', 'localhost')
    stats.increment('rescued', 'localhost')
    stats.increment('rescued', 'localhost')
    stats.increment('failures', 'localhost')

    summary = stats.summarize('localhost')
    assert summary['ok'] == 3
    assert summary['failures'] == 1
    assert summary['changed'] == 1
    assert summary['rescued'] == 2



# Generated at 2022-06-22 20:17:27.689191
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    a = AggregateStats()
    a.increment('changed', "test_hostname")
    a.increment('changed', "test_hostname")
    a.increment('failed', "test_hostname")
    assert a.changed == {"test_hostname": 2}
    assert a.failures == {"test_hostname": 1}

# Generated at 2022-06-22 20:17:34.721489
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():

    # create an instance of AggregateStats
    agg_stats = AggregateStats()
    agg_stats.increment('ok', '127.0.0.1')
    agg_stats.increment('failures', '127.0.0.1')

    # test if the value of the key '127.0.0.1' is incremented as expected
    assert agg_stats.ok['127.0.0.1'] == 1 and agg_stats.failures['127.0.0.1'] == 1


# Generated at 2022-06-22 20:17:38.403809
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    _what = {}
    host = 'test_hostname'
    _what[host] = 1
    assert _what[host] == 1

    instance = AggregateStats()
    instance.decrement('skipped', host)
    assert _what[host] == 0



# Generated at 2022-06-22 20:17:40.338232
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement("ok", "host1")
    assert stats.ok["host1"] == 0

# Generated at 2022-06-22 20:17:45.908396
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregatestats = AggregateStats()

    aggregatestats.decrement('ok', 'host')
    assert aggregatestats.ok['host'] == -1

    aggregatestats.increment('ok', 'host')
    assert aggregatestats.ok['host'] == 0

    aggregatestats.failures['host'] = 1
    aggregatestats.decrement('failures', 'host')
    assert aggregatestats.failures['host'] == 0

# Generated at 2022-06-22 20:17:56.235429
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('a', 1)
    assert stats.custom == {'_run': {'a': 1}}
    stats.set_custom_stats('b', 2, 'host1')
    assert stats.custom == {'_run': {'a': 1}, 'host1': {'b': 2}}
    stats.set_custom_stats('c', 3, 'host1')
    assert stats.custom == {'_run': {'a': 1}, 'host1': {'b': 2, 'c': 3}}
    stats.set_custom_stats('d', 4, 'host2')
    assert stats.custom == {'_run': {'a': 1}, 'host1': {'b': 2, 'c': 3}, 'host2': {'d': 4}}
   

# Generated at 2022-06-22 20:17:57.286969
# Unit test for constructor of class AggregateStats
def test_AggregateStats():

    stats = AggregateStats()
    print(stats.processed)
    print(stats.failures)

# Generated at 2022-06-22 20:18:07.340765
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    s = AggregateStats()
    s.increment('ok', 'testhost1')
    s.increment('ok', 'testhost1')
    s.increment('ok', 'testhost1')
    s.increment('failures', 'testhost1')
    s.increment('failures', 'testhost2')
    s.increment('changed', 'testhost5')
    s.increment('ok', 'testhost5')

    summary1 = s.summarize('testhost1')
    summary2 = s.summarize('testhost2')
    summary3 = s.summarize('testhost3')
    summary5 = s.summarize('testhost5')

    assert summary1['ok'] == 3
    assert summary1['failures'] == 1
    assert summary1['changed'] == 0


# Generated at 2022-06-22 20:18:19.051356
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    # Create a dummy ansible inventory
    inventory_file = open('test_inventory.cfg', 'w')
    inventory_file.write("[test_hosts]\ntest_host1\ntest_host2")
    inventory_file.close()

    # Create a playbook test
    playbook = AnsibleFile("test_playbook", "1.9")
    playbook.add_block(
        AnsibleBlock("hosts", "test_hosts"),
        AnsibleBlock("tasks",
                     AnsibleTask("debug", "msg=Hello World"),
                     AnsibleTask("debug", "msg=Bye World")
                     )
    )

    # Create the runner for the test
    test_runner = AnsibleRunner(playbook)

    # Create the stats for the test
    stats = AggregateStats()

    # Create the varmanager for

# Generated at 2022-06-22 20:18:30.226185
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    # Very simple test case:
    # - no host
    # - no accumulated value
    # - integer value
    stats.update_custom_stats("inventories", 5)
    assert stats.custom["_run"] == {"inventories": 5}

    # Simple test case:
    # - no host
    # - no accumulated value
    # - float value
    stats.update_custom_stats("inventories", 5.5)
    assert stats.custom["_run"] == {"inventories": 5.5}

    # Simple test case:
    # - no host
    # - no accumulated value
    # - string value
    stats.update_custom_stats("inventories", "string")
    assert stats.custom["_run"] == {"inventories": "string"}

    # Simple test

# Generated at 2022-06-22 20:18:39.725616
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # create test object
    stats = AggregateStats()
    stats.ok = {'host': 2}
    # check initial value
    assert stats.ok == {'host': 2}
    # do the test
    stats.decrement('ok', 'host')
    assert stats.ok == {'host': 1}
    # check what is supposed to be unchanged
    assert stats.failures == {}
    assert stats.processed == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}
    # make sure we can't decrement beyond 0
    stats.decrement('ok', 'host')
    stats.decrement('ok', 'host')
    stats.dec

# Generated at 2022-06-22 20:18:48.071660
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ag = AggregateStats()
    ag.increment("ok", "10.10.10.10")
    assert ag.ok.get("10.10.10.10",0) == 1
    assert ag.processed.get("10.10.10.10", 0) == 1
    assert ag.failures.get("10.10.10.10", 0) == 0
    assert ag.dark.get("10.10.10.10", 0) == 0
    assert ag.changed.get("10.10.10.10", 0) == 0
    assert ag.skipped.get("10.10.10.10", 0) == 0
    assert ag.rescued.get("10.10.10.10", 0) == 0
    assert ag.ignored.get("10.10.10.10", 0) == 0

# Generated at 2022-06-22 20:18:53.934476
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-22 20:19:03.865831
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    a = AggregateStats()
    a.increment("ok", "host")
    assert a.processed == {"host": 1}
    assert a.failures == {}
    assert a.ok == {"host": 1}
    assert a.dark == {}
    assert a.changed == {}
    assert a.skipped == {}
    assert a.rescued == {}
    assert a.ignored == {}
    assert a.custom == {}
    assert a.summarize("host") == {"ok": 1, "failures": 0, "unreachable": 0, "changed": 0, "skipped": 0, "rescued": 0, "ignored": 0}
    a.increment("ok", "host")
    assert a.processed == {"host": 1}
    assert a.failures == {}
    assert a.ok

# Generated at 2022-06-22 20:19:14.858059
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    '''Test AggregateStats.update_custom_stats.

    This is a unit test for method update_custom_stats of class
    AggregateStats.
    '''
    a = AggregateStats()

    a.update_custom_stats('cpu', 4)
    if a.custom['_run']['cpu'] != 4:
        raise Exception('AggregateStats.update_custom_stats failed on cpu')

    a.update_custom_stats('cpu', 2)
    if a.custom['_run']['cpu'] != 6:
        raise Exception('AggregateStats.update_custom_stats failed on cpu')

    a.update_custom_stats('ram', 10)
    if a.custom['_run']['ram'] != 10:
        raise Exception('AggregateStats.update_custom_stats failed on ram')


# Generated at 2022-06-22 20:19:26.660346
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('changed', 'host1')
    stats.increment('changed', 'host2')
    assert stats.summarize('host1') == {'ok': 2, 'failures': 0,
        'unreachable': 0, 'changed': 1, 'skipped': 0, 'rescued': 0,
        'ignored': 0}
    assert stats.summarize('host2') == {'ok': 1, 'failures': 0,
        'unreachable': 0, 'changed': 1, 'skipped': 0, 'rescued': 0,
        'ignored': 0}
    assert stats.summar

# Generated at 2022-06-22 20:19:32.019033
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    assert isinstance(aggregate_stats, AggregateStats)

    aggregate_stats.increment("failures", "test_host")
    aggregate_stats.decrement("failures", "test_host")

    assert aggregate_stats.processed["test_host"] == 1
    assert aggregate_stats.failures["test_host"] == 0


# Generated at 2022-06-22 20:19:42.444385
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('test', 'string', 'host1')
    stats.set_custom_stats('test2', 3, 'host2')
    assert 'host1' in stats.custom
    assert 'host2' in stats.custom
    assert stats.custom['host1'] == {'test': 'string'}
    assert stats.custom['host2'] == {'test2': 3}
    # Hostname shouldn't be changed
    assert stats.custom['host1'] == {'test': 'string'}
    stats.set_custom_stats('test', 'string')
    assert stats.custom['_run'] == {'test': 'string'}


# Generated at 2022-06-22 20:19:53.458324
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    ''' test set_custom_stats method of class AggregateStats'''
    test_stats = AggregateStats()

    # Test setting string
    test_stats.set_custom_stats('string_field', 'test', 'localhost')
    assert test_stats.custom == { 'localhost' : { 'string_field' : 'test' } }

    # Test setting integer
    test_stats.set_custom_stats('int_field', 12, 'localhost')
    assert test_stats.custom == { 'localhost' : { 'string_field' : 'test', 'int_field' : 12 } }, test_stats.custom

    # Test setting dict
    test_dict = {'some_dict': 'some_value'}
    test_stats.set_custom_stats('dict_field', test_dict, 'localhost')
    assert test_stats

# Generated at 2022-06-22 20:20:02.637026
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    import mock

    stats = AggregateStats()

    for what in ('failures', 'ok', 'dark', 'changed', 'skipped', 'rescued', 'ignored'):
        increment = 'AggregateStats.increment("{0}", "localhost.localdomain")'.format(what)

        with mock.patch("builtins.print", new=mock.Mock()) as mock_print:
            exec(increment)

        assert mock_print.called
        mock_print.call_count == 1

        with mock.patch("builtins.print") as mock_print:
            exec(increment)

        assert mock_print.called
        mock_print.call_count == 2


# Generated at 2022-06-22 20:20:08.120304
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregateStats = AggregateStats()
    aggregateStats.increment('failures', 'localhost')
    assert aggregateStats.failures['localhost'] == 1
    aggregateStats.increment('failures', 'localhost')
    assert aggregateStats.failures['localhost'] == 2


# Generated at 2022-06-22 20:20:17.525079
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():

    aggregate = AggregateStats()
    host = 'localhost'

    # Test if the host was created and the statistics was initialized with 0
    assert 'localhost' in aggregate.processed
    assert aggregate.processed['localhost'] == 1
    assert aggregate.ok['localhost'] is not None
    assert aggregate.ok['localhost'] == 0
    assert aggregate.failures['localhost'] is not None
    assert aggregate.failures['localhost'] == 0
    assert aggregate.dark['localhost'] is not None
    assert aggregate.dark['localhost'] == 0
    assert aggregate.changed['localhost'] is not None
    assert aggregate.changed['localhost'] == 0
    assert aggregate.skipped['localhost'] is not None
    assert aggregate.skipped['localhost'] == 0
    assert aggregate.rescued['localhost'] is not None
    assert aggregate.rescued['localhost'] == 0

# Generated at 2022-06-22 20:20:29.885528
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats(which='date', what="10:40:17", host="127.0.0.1")
    if 'date' not in stats.custom["127.0.0.1"]:
        raise AssertionError("1: date not in stats.custom[127.0.0.1]")
    if stats.custom["127.0.0.1"]["date"] != "10:40:17":
        raise AssertionError("1: stats.custom[127.0.0.1][date] != '10:40:17'")

    stats.set_custom_stats(which='date', what="10:50:35", host="127.0.0.1")

# Generated at 2022-06-22 20:20:42.163016
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    """Unit test for class AggregateStats"""
    from nose.tools import assert_equal, assert_true

    test_aggregate_stats = AggregateStats()

    assert_true('processed' in test_aggregate_stats.__dict__)
    assert_true('failures' in test_aggregate_stats.__dict__)
    assert_true('ok' in test_aggregate_stats.__dict__)
    assert_true('dark' in test_aggregate_stats.__dict__)
    assert_true('changed' in test_aggregate_stats.__dict__)
    assert_true('skipped' in test_aggregate_stats.__dict__)
    assert_true('rescued' in test_aggregate_stats.__dict__)

# Generated at 2022-06-22 20:20:47.761969
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggr = AggregateStats()
    aggr.ok['blah'] = 0
    aggr.decrement("ok", "blah")
    assert aggr.ok == {}
    aggr.ok['blah'] = 5
    aggr.decrement("ok", "blah")
    assert aggr.ok == {'blah': 4}
    aggr.ok['blah'] = 1
    aggr.decrement("ok", "blah")
    assert aggr.ok == {}

# Generated at 2022-06-22 20:20:58.651903
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('uptime', [1, 2, 3])
    assert stats.custom == {'_run': {'uptime': [1, 2, 3]}}
    stats.set_custom_stats('users', {'steve': 1})
    assert stats.custom == {'_run': {'uptime': [1, 2, 3], 'users': {'steve': 1}}}
    
    # check _host versions
    stats.set_custom_stats('uptime', [3, 2, 1], host='host1')
    assert stats.custom == {
        '_run': {'uptime': [1, 2, 3], 'users': {'steve': 1}},
        'host1': {'uptime': [3, 2, 1]}
    }
   

# Generated at 2022-06-22 20:21:09.767124
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats(
        'custom_stats',
        {'value': {'key1': 'val1', 'key2': 'val2'}}
    )
    assert aggregate_stats.custom['_run']['custom_stats'] == {'value': {'key1': 'val1', 'key2': 'val2'}}

    aggregate_stats.update_custom_stats(
        'custom_stats',
        {'value': {'key1': 'val3', 'key2': 'val4', 'key3': 'val5'}}
    )
    assert aggregate_stats.custom['_run']['custom_stats'] == {'value': {'key1': 'val3', 'key2': 'val4', 'key3': 'val5'}}

# Generated at 2022-06-22 20:21:16.624574
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Test no host
    stats = AggregateStats()
    stats.decrement('ok', '')
    assert stats.ok == {}
    # Test known host
    stats.ok['myhost.example.com'] = 2
    stats.decrement('ok', 'myhost.example.com')
    assert stats.ok['myhost.example.com'] == 1
    # Test no negative numbers
    stats.decrement('ok', 'myhost.example.com')
    assert stats.ok['myhost.example.com'] == 0
    stats.decrement('ok', 'myhost.example.com')
    assert stats.ok['myhost.example.com'] == 0

# Generated at 2022-06-22 20:21:23.921995
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    statTest = AggregateStats()
    assert len(statTest.processed) == 0
    assert len(statTest.failures) == 0
    assert len(statTest.ok) == 0
    assert len(statTest.dark) == 0
    assert len(statTest.changed) == 0
    assert len(statTest.skipped) == 0
    assert len(statTest.rescued) == 0
    assert len(statTest.ignored) == 0
    assert len(statTest.custom) == 0


# Generated at 2022-06-22 20:21:34.917428
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Create an instance of type AggregateStats
    aggregateStats = AggregateStats()

    # Method to test is update_custom_stats, which is responsible for
    # updating custom statistics for a host.
    #
    # The test will pass a number of different parameters to the method, and
    # verify that the output is as expected.
    #
    # The test will use the following method of determining successful
    # completion of the test.
    #
    # 1. Verify that the before and after state of the object is correct.
    # 2. Verify that the method returns None if it has successfully updated
    #    the value.
    # 3. Verify that the method returns None when it fails to update the
    #    value, and that the state of the object has not changed.
    #
    # Test number one:
    # int as value with dict as return

# Generated at 2022-06-22 20:21:40.699068
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg_stats = AggregateStats()
    assert isinstance(agg_stats.processed, dict)
    assert isinstance(agg_stats.failures, dict)
    assert isinstance(agg_stats.ok, dict)
    assert isinstance(agg_stats.dark, dict)
    assert isinstance(agg_stats.changed, dict)
    assert isinstance(agg_stats.skipped, dict)
    assert isinstance(agg_stats.rescued, dict)
    assert isinstance(agg_stats.ignored, dict)
    assert isinstance(agg_stats.custom, dict)

# Generated at 2022-06-22 20:21:51.322548
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    test_class = AggregateStats()
    test_class.update_custom_stats("custom1", {"a":1})
    assert test_class.custom['_run']["custom1"] == {"a": 1}
    test_class.update_custom_stats("custom1", {"a":2})
    assert test_class.custom['_run']["custom1"] == {"a": 3}
    test_class.update_custom_stats("custom1", {"a":2, "b":1})
    assert test_class.custom['_run']["custom1"] == {"a": 5, "b": 1}
    test_class.update_custom_stats("custom2", "string1")
    assert test_class.custom['_run']["custom2"] == "string1"
    test_class.update_custom_

# Generated at 2022-06-22 20:22:00.715491
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    # Create an AggregateStats object
    aggregate = AggregateStats()
    # Call method set_custom_stats and ensure it works as expected
    aggregate.set_custom_stats('custom_stats1', 'custom_value1')
    if '_run' not in aggregate.custom:
        raise AssertionError('_run not in aggregate.custom')
    if 'custom_stats1' not in aggregate.custom['_run']:
        raise AssertionError('custom_stats1 not in aggregate.custom[_run]')
    if aggregate.custom['_run']['custom_stats1'] != 'custom_value1':
        raise AssertionError('aggregate.custom[_run][\'custom_stats1\'] != \'custom_value1\'')


# Generated at 2022-06-22 20:22:10.522670
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.config.manager import ConfigManager
    from ansible.inventory import Inventory
    ConfigManager(["ansible.cfg"])
    inv = Inventory(host_list='localhost,')
    stats = AggregateStats()
    stats.update_custom_stats("test1", {'a': {'b': 1}}, 'localhost')
    stats.update_custom_stats("test1", {'a': {'c': 1}}, 'localhost')
    stats.update_custom_stats("test2", 1, 'localhost')
    stats.update_custom_stats("test2", 2, 'localhost')
    exp_dict1 =  {'test1': {'a': {'b': 1, 'c': 1}}, 'test2': 3}

# Generated at 2022-06-22 20:22:21.758141
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    global_stats = AggregateStats()
    assert global_stats
    global_stats.update_custom_stats('foo', {'bar': 1})
    assert global_stats.custom
    assert global_stats.custom['_run']['foo'] == {'bar': 1}
    global_stats.update_custom_stats('foo', {'bar': 1})
    assert global_stats.custom['_run']['foo'] == {'bar': 2}
    global_stats.update_custom_stats('foo', {'bar': 1, 'baz': True})
    assert global_stats.custom['_run']['foo'] == {'bar': 3, 'baz': True}
    global_stats.update_custom_stats('foo', 'a string')

# Generated at 2022-06-22 20:22:26.214363
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg_stats = AggregateStats()
    agg_stats.increment('ok', 'localhost')
    agg_stats.increment('ok', 'localhost')
    assert(agg_stats.ok['localhost'] == 2)



# Generated at 2022-06-22 20:22:29.837515
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ag = AggregateStats()
    ag.increment('ok', 'host1')

    assert ag.ok['host1'] == 1
    assert ag.processed['host1'] == 1
    assert ag.skipped ==  {}


# Generated at 2022-06-22 20:22:35.378883
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    ag = AggregateStats()
    ag.set_custom_stats('test', 'test_data')
    assert ag.custom['_run']['test'] == 'test_data'
    ag.set_custom_stats('test', 'test_data_2', 'test_host')
    assert ag.custom['test_host']['test'] == 'test_data_2'


# Generated at 2022-06-22 20:22:39.450016
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    a = AggregateStats()
    a.processed['host1'] = 1
    a.ok['host1'] = 1
    a.increment('ok', 'host1')
    a.increment('ok', 'host2')

    assert a.processed['host1'] == 1
    assert a.ok['host1'] == 2
    assert a.ok['host2'] == 1


# Generated at 2022-06-22 20:22:46.072452
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("dark", "localhost")
    assert stats.dark["localhost"] == 1
    assert stats.processed["localhost"] == 1
    stats.increment("ok", "localhost")
    assert stats.ok["localhost"] == 1
    assert stats.processed["localhost"] == 1
    stats.increment("ok", "localhost")
    assert stats.ok["localhost"] == 2
    assert stats.processed["localhost"] == 1


# Generated at 2022-06-22 20:22:49.633823
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    '''
    This test covers the decrement method of class AggregateStats.
    '''
    agg = AggregateStats()

    agg.decrement('ok', 'host1')

    assert(agg.ok['host1'] == 0)

    agg.decrement('ok', 'host2')

    assert(agg.ok['host2'] == 0)



# Generated at 2022-06-22 20:23:00.425364
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate = AggregateStats()
    aggregate.ok     = {'localhost': 1, '127.0.0.1': 2}
    aggregate.failures = {'localhost': 3, '127.0.0.1': 4}
    aggregate.dark = {'localhost': 5, '127.0.0.1': 6}
    aggregate.changed = {'localhost': 7, '127.0.0.1': 8}
    aggregate.skipped = {'localhost': 9, '127.0.0.1': 10}
    aggregate.rescued = {'localhost': 11, '127.0.0.1': 12}
    aggregate.ignored = {'localhost': 13, '127.0.0.1': 14}

# Generated at 2022-06-22 20:23:10.412832
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    # decrement with empty dict
    stats.decrement('ok', 'test')
    assert stats.processed == {'test': 1}
    assert stats.ok == {'test': 0}

    # decrement with existing value
    stats.ok['test'] = 1
    stats.decrement('ok', 'test')
    assert stats.ok == {'test': 0}

    # decrement with negative value, should not happen
    stats.ok['test'] = -1
    stats.decrement('ok', 'test')
    assert stats.ok == {'test': 0}


# Generated at 2022-06-22 20:23:19.900727
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Create the object 'stats'
    stats = AggregateStats()

    # Add "failures" stat to stats
    stats.failures = {'localhost': 1}

    # Test for decrementing failures for host "localhost"
    stats.decrement("failures", "localhost")
    assert 'localhost' in stats.failures
    assert stats.failures['localhost'] == 0

    # Test for decrementing failures for host "localhost" and test
    # that the resulting value is >= 0
    stats.decrement("failures", "localhost")
    assert 'localhost' in stats.failures
    assert stats.failures['localhost'] >= 0

    # Test for decrementing fails for host "localhost" that does not exist
    stats.decrement("failures", "doesnotexist")
    assert 'doesnotexist' not in stats

# Generated at 2022-06-22 20:23:24.568508
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    astats = AggregateStats()

    # Test the decrement from 0.
    astats.decrement('ok', 'localhost')
    assert astats.ok['localhost'] == 0

    # Decrement from a positive value.
    astats.ok['localhost'] = 20
    astats.decrement('ok', 'localhost')
    assert astats.ok['localhost'] == 19

# Generated at 2022-06-22 20:23:35.297408
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from collections import OrderedDict
    import copy

    as_ = AggregateStats()

    # Try a simple dict
    a = {'a': 1, 'b': 2}
    b = {'a': 3}
    as_.update_custom_stats('a_dict', a)
    assert as_.custom['_run'] == {'a_dict': a}
    as_.update_custom_stats('a_dict', b)
    assert as_.custom['_run'] == {'a_dict': merge_hash(a, b)}

    # Try an OrderedDict
    a = OrderedDict([('a', 1), ('b', 2)])
    b = OrderedDict([('a', 3), ('c', 4)])
    as_.update_custom_stats('b_dict', b)

# Generated at 2022-06-22 20:23:42.077019
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg_stats = AggregateStats()
    agg_stats.increment('changed', '10.1.1.1')
    agg_stats.decrement('changed', '10.1.1.1')
    assert agg_stats.changed.get('10.1.1.1') == 0, agg_stats.changed.get('10.1.1.1')
    agg_stats.decrement('changed', '10.1.1.1')
    assert agg_stats.changed.get('10.1.1.1') == 0, agg_stats.changed.get('10.1.1.1')

# Generated at 2022-06-22 20:23:44.858923
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('dark', 'foo')
    aggregate_stats.decrement('dark', 'foo')
    assert aggregate_stats.dark.get('foo') == 0

# Generated at 2022-06-22 20:23:51.234026
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert(stats.processed == {})
    assert(stats.failures == {})
    assert(stats.ok == {})
    assert(stats.dark == {})
    assert(stats.changed == {})
    assert(stats.skipped == {})
    assert(stats.rescued == {})
    assert(stats.ignored == {})


# Generated at 2022-06-22 20:24:00.960718
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    # Create custom stat for a host
    stats.set_custom_stats('mystat', 3, host='testhost')
    assert stats.custom['testhost'] == {'mystat': 3}
    # Create custom stat for global run stats
    stats.set_custom_stats('mystat', 7, host=None)
    assert stats.custom['_run'] == {'mystat': 7}
    # Overwrite custom stat
    stats.set_custom_stats('mystat', 4, host=None)
    assert stats.custom['_run'] == {'mystat': 4}
    assert stats.custom['testhost'] == {'mystat': 3}


# Generated at 2022-06-22 20:24:02.912460
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'testhost')
    assert stats.ok.get('testhost') == 1


# Generated at 2022-06-22 20:24:14.731283
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import ansible
    stats = AggregateStats()
    stats.update_custom_stats('test_stat', {'a': 1, 'b': 2, 'c': 3}, 'localhost')
    assert stats.custom['localhost']['test_stat'] == {'a': 1, 'b': 2, 'c': 3}
    assert stats.custom['localhost']['test_stat']['a'] == 1

    try:
        stats.update_custom_stats('test_stat2', {'a': 1, 'b': 2, 'c': 3})
    except Exception as e:
        pytest.fail("update_custom_stats() failed with exception:" + str(e))


# Generated at 2022-06-22 20:24:16.343632
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    assert AggregateStats().failures == {}


# Generated at 2022-06-22 20:24:23.676892
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    a = AggregateStats()
    a.set_custom_stats('aa', 10, host='host1')
    assert a.custom == {'host1': {'aa': 10}}
    a.set_custom_stats('aa', 10, host='host2')
    assert a.custom == {'host2': {'aa': 10}, 'host1': {'aa': 10}}
    a.set_custom_stats('aa', 20, host='host1')
    assert a.custom == {'host2': {'aa': 10}, 'host1': {'aa': 20}}
    a.set_custom_stats('bb', 'foo', host='host1')
    assert a.custom == {'host2': {'aa': 10}, 'host1': {'aa': 20, 'bb': 'foo'}}
    a.set_

# Generated at 2022-06-22 20:24:26.693385
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('failures', 'localhost')
    assert stats.failures['localhost'] == 1



# Generated at 2022-06-22 20:24:33.491125
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():

    agg = AggregateStats()
    agg.set_custom_stats(None, None)

    assert agg.custom['_run'] == {}

    agg.set_custom_stats('foo', 'bar')
    assert agg.custom['_run'] == {'foo': 'bar'}

    agg.set_custom_stats('baz', 'xyzzy', 'the_host')
    assert agg.custom['_run'] == {'foo': 'bar'}
    assert agg.custom['the_host'] == {'baz': 'xyzzy'}



# Generated at 2022-06-22 20:24:38.673331
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}



# Generated at 2022-06-22 20:24:49.672348
# Unit test for constructor of class AggregateStats
def test_AggregateStats():

    # Not much we can do here except make sure it runs without
    # throwing errors, but let's write some tests anyway
    stats = AggregateStats()
    stats.increment("ok", "testhost")
    stats.increment("dark", "testhost")
    stats.increment("dark", "testhost")
    stats.increment("ok", "bad")

    print(stats.summarize("testhost"))
    print(stats.summarize("bad"))

    assert stats.summarize("testhost")['ok'] == 1
    assert stats.summarize("testhost")['unreachable'] == 2
    assert stats.summarize("bad")['ok'] == 1

# Generated at 2022-06-22 20:24:55.090956
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    # Setup
    agg_stats = AggregateStats()
    which = 'custom'
    what = {'k1': 'v1'}
    host = 'testhost'

    # Execute
    agg_stats.set_custom_stats(which, what, host)

    # Assert
    assert agg_stats.custom[host] == {which: what}



# Generated at 2022-06-22 20:25:06.288688
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    as_ = AggregateStats()
    as_.increment('ok', '1.2.3.4')
    as_.increment('changed', '1.2.3.4')
    as_.increment('ok', '1.2.3.4')
    assert as_.summarize('1.2.3.4') == dict(ok=2, changed=1)
    assert as_.summarize('1.2.3.6') == dict(ok=0, changed=0)
    assert as_.summarize('1.2.3.6') == dict(ok=0, changed=0)
    assert as_.custom['_run'] == dict()
    as_.set_custom_stats('some_stat', 'value')
    as_.set_custom_stats('other_stat', 'value2')