

# Generated at 2022-06-22 20:15:09.118286
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'a')
    stats.increment('ok', 'b')
    stats.increment('ok', 'a')
    stats.increment('ok', 'c')

    stats.increment('failures', 'a')
    stats.increment('failures', 'b')
    stats.increment('failures', 'c')
    stats.increment('failures', 'c')

    stats.increment('dark', 'a')

    assert stats.ok['a'] == 2
    assert stats.ok['b'] == 1
    assert stats.ok['c'] == 1

    assert stats.failures['a'] == 1
    assert stats.failures['b'] == 1
    assert stats.failures['c'] == 2

    assert stats.dark['a'] == 1

# Generated at 2022-06-22 20:15:13.536823
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    a = AggregateStats()
    a.increment('ok', 'host1') # Increment ok count for host1
    assert a.ok['host1'] == 1
    a.increment('dark', 'host1') # Increment dark count for host1
    assert a.dark['host1'] == 1
    assert a.processed['host1'] == 1

    a.increment('ok', 'host2') # Increment ok count for host2
    assert a.ok['host2'] == 1


# Generated at 2022-06-22 20:15:20.800592
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregateStats = AggregateStats()
    aggregateStats.increment("ok", "foo")
    aggregateStats.increment("changed", "foo")
    aggregateStats.increment("ok", "bar")
    assert(aggregateStats.summarize("foo") == {'ok': 1, 'failures': 0, 'unreachable': 0, 'changed': 1, 'skipped': 0, 'rescued': 0, 'ignored': 0})
    assert(aggregateStats.summarize("bar") == {'ok': 1, 'failures': 0, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0})

# Generated at 2022-06-22 20:15:30.357662
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    s = AggregateStats()
    s.update_custom_stats("count", 2, "host1")
    s.update_custom_stats("count", 3, "host1")
    assert s.custom['host1']['count'] == 5
    s.update_custom_stats("count", 2)
    s.update_custom_stats("count", 3)
    assert s.custom['_run']['count'] == 5

    s.update_custom_stats("dict", {"a": 3, "b": 2}, "host1")
    s.update_custom_stats("dict", {"a": 1, "c": 2}, "host1")
    assert s.custom['host1']['dict'] == {"a": 4, "b": 2, "c": 2}

# Generated at 2022-06-22 20:15:38.242527
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    custom_stat = {}
    assert custom_stat == {}
    custom_stat = AggregateStats().update_custom_stats('rescue', 123)
    assert custom_stat == {'_run': {'rescue': 123}}
    custom_stat = AggregateStats().update_custom_stats('rescue', 123, 'host001')
    assert custom_stat == {'host001': {'rescue': 123}}
    custom_stat = AggregateStats().update_custom_stats('rescue', 'error', 'host001')
    assert custom_stat == {'host001': {'rescue': 'error'}}
    custom_stat = AggregateStats().update_custom_stats('rescue', 'fix', 'host001')
    assert custom_stat == {'host001': {'rescue': 'fix'}}
    custom_stat = Agg

# Generated at 2022-06-22 20:15:46.764023
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    import pytest
    a = AggregateStats()
    a.increment('failures', 'h1')
    a.increment('ok', 'h1')
    assert a.processed == {'h1': 1}, "processed is incorrect"
    assert a.failures == {'h1': 1}, "failures is incorrect"
    assert a.ok == {'h1': 1}, "ok is incorrect"
    assert a.dark == {}, "dark is incorrect"
    assert a.changed == {}, "changed is incorrect"
    assert a.skipped == {}, "skipped is incorrect"
    assert a.rescued == {}, "rescued is incorrect"
    assert a.ignored == {}, "ignored is incorrect"


# Generated at 2022-06-22 20:15:52.071835
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('changed', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('skipped', 'localhost')
    stats.increment('rescued', 'localhost')
    stats.increment('ignored', 'localhost')
    stats.increment('changed', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment

# Generated at 2022-06-22 20:16:01.024534
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():

    # create aggregate stats instance
    aggregate_stats = AggregateStats()

    # test for empty custom stats
    assert aggregate_stats.custom == {}

    # test for custom stats with host specific
    aggregate_stats.set_custom_stats("test", "set_custom_stats", "test_host")
    assert aggregate_stats.custom == {"test_host": { "test": "set_custom_stats" }}

    # test for custom stats with global
    aggregate_stats.set_custom_stats("global", "global_test")
    assert aggregate_stats.custom == {"test_host": { "test": "set_custom_stats" }, "_run": { "global": "global_test" }}



# Generated at 2022-06-22 20:16:07.218780
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    ''' Test method AggregateStats.update_custom_stats '''
    import sys
    import os
    import tempfile
    import shutil

    # Change to a temporary directory
    oldcwd = os.getcwd()
    tmpdir = tempfile.mkdtemp()
    os.chdir(tmpdir)

    # Import module_utils/facts.py after changing to the temp directory,
    # since it writes files there.
    sys.path.append(oldcwd)
    facts = __import__('module_utils.facts')
    facts = sys.modules['module_utils.facts']
    sys.path.pop()

    # Mock module to all methods to return True.
    # This is needed because some parts of the module assume facts are at root.
    # The only method we have to mock is sanitize_facts, all

# Generated at 2022-06-22 20:16:15.991691
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate = AggregateStats()
    assert isinstance(aggregate.processed, dict)
    assert isinstance(aggregate.failures, dict)
    assert isinstance(aggregate.ok, dict)
    assert isinstance(aggregate.dark, dict)
    assert isinstance(aggregate.changed, dict)
    assert isinstance(aggregate.skipped, dict)
    assert isinstance(aggregate.rescued, dict)
    assert isinstance(aggregate.ignored, dict)
    assert isinstance(aggregate.custom, dict)



# Generated at 2022-06-22 20:16:24.730006
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    '''
    unit tests for set_custom_stats method of class AggregateStats
    '''

    test_custom = {}
    test_stats = AggregateStats()

    test_stats.set_custom_stats('a', 1, '_run')
    test_stats.set_custom_stats('b', 2, '_run')
    test_stats.set_custom_stats('a', 10, '_run')

    test_custom['_run'] = {'a': 10, 'b': 2}

    assert test_stats.custom['_run'] == test_custom['_run']

    # test host specific custom stats
    test_stats.set_custom_stats('a', 1, 'host1')
    test_stats.set_custom_stats('b', 2, 'host1')
    test_stats.set_custom_

# Generated at 2022-06-22 20:16:36.335524
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    assert stats.custom == {}
    stats.set_custom_stats("a", "b")
    assert stats.custom == {'_run': {'a': 'b'}}
    stats.set_custom_stats("a", "b", "foo")
    assert stats.custom == {'_run': {'a': 'b'}, 'foo': {'a': 'b'}}
    stats.set_custom_stats("x", "y", "foo")
    assert stats.custom == {'_run': {'a': 'b'}, 'foo': {'a': 'b', 'x': 'y'}}
    stats.set_custom_stats("a", "b", "bar")

# Generated at 2022-06-22 20:16:45.977922
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    stats.update_custom_stats('custom_stats', 'test_str')
    assert stats.custom['_run']['custom_stats'] == 'test_str'
    stats.update_custom_stats('custom_stats', [1, 2, 3])
    assert stats.custom['_run']['custom_stats'] == [1, 2, 3]
    stats.update_custom_stats('custom_stats', 2)
    assert stats.custom['_run']['custom_stats'] == 4
    stats.update_custom_stats('custom_stats', {'key': 'value'})
    assert stats.custom['_run']['custom_stats'] == 4
    stats.update_custom_stats('custom_stats', {'key2': 'value2'})

# Generated at 2022-06-22 20:16:48.718906
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'test_host')
    stats.decrement('ok', 'test_host')
    assert stats.ok['test_host'] == 0

# Generated at 2022-06-22 20:17:00.082754
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    stats.increment('ok', 'myhost1')
    stats.increment('ok', 'myhost1')
    assert(stats.ok == dict(myhost1=2))

    stats.increment('ok', 'myhost2')
    assert(stats.ok == dict(myhost1=2, myhost2=1))

    stats.increment('failures', 'myhost1')
    assert(stats.ok == dict(myhost1=2, myhost2=1))
    assert(stats.failures == dict(myhost1=1))

    stats.increment('dark', 'myhost1')
    assert(stats.ok == dict(myhost1=2, myhost2=1))
    assert(stats.failures == dict(myhost1=1))

# Generated at 2022-06-22 20:17:10.596884
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stat_name = 'dark'
    host = 'host'

    stats.increment(stat_name, host)
    assert host in stats.dark, "Error creating host record in initial increment"
    assert stats.dark[host] == 1, "Error incremented incorrect value"

    stats.increment(stat_name, host)
    assert stats.dark[host] == 2, "Error incrementing value multiple times"

    stats.increment('processed', 'other_host')
    assert host in stats.processed, "Error creating Processed records"
    assert stats.processed[host] == 1, "Error incrementing Processed value"

    assert (
        stats.summarize(host)['unreachable'] == 2
    ), "Error summarizing unreachable stats for host"


# Generated at 2022-06-22 20:17:16.336778
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():

    stats = AggregateStats()

    stats.set_custom_stats("auth", {"password": 2, "ssh-key": 1}, "localhost")
    assert stats.custom == {"localhost": {"auth": {"password": 2, "ssh-key": 1}}}

    stats = AggregateStats()
    stats.set_custom_stats("auth", {"password": 2, "ssh-key": 1})
    assert stats.custom == {"_run": {"auth": {"password": 2, "ssh-key": 1}}}



# Generated at 2022-06-22 20:17:25.102627
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    # test to set 2 values
    stats.increment('changed', 'test_changed')
    stats.increment('changed', 'test_changed')

    # test to set 2 values
    stats.increment('ok', 'test_ok')
    stats.increment('ok', 'test_ok')

    expected_results = {'changed': {'test_changed': 2}, 'ok': {'test_ok': 2}}
    assert (expected_results == stats.__dict__), "Failed to increment"


test_AggregateStats_increment()


# Generated at 2022-06-22 20:17:34.631902
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    stats = AggregateStats()

    stats.update_custom_stats('foo', 1, 'bar')
    stats.update_custom_stats('foo', 1, 'bar')

    assert stats.custom == {'bar': {'foo': 2}}

    stats.update_custom_stats('foo', 1, 'qux')
    stats.update_custom_stats('foo', 1, 'qux')
    assert stats.custom == {'bar': {'foo': 2}, 'qux': {'foo': 2}}

    stats.update_custom_stats('foo', 'a', 'bar')
    assert stats.custom == {'bar': {'foo': None}, 'qux': {'foo': 2}}

# Generated at 2022-06-22 20:17:40.464330
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregatestats = AggregateStats()
    aggregatestats.ok['localhost'] = 21
    aggregatestats.failures['localhost'] = 2
    aggregatestats.ok['127.0.0.1'] = 12
    assert aggregatestats.summarize('localhost') == {'changed': 0, 'failures': 2, 'ok': 21, 'rescued': 0, 'skipped': 0, 'ignored': 0, 'unreachable': 0}

# Generated at 2022-06-22 20:17:47.308910
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    # Testing only method increment and property ok
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    # Calling method increment several times
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 3


# Generated at 2022-06-22 20:17:53.655600
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    keys = ['_run', '127.0.0.1']
    values = {
        '_run': {'custom_sum': 0, 'custom_list': []},
        '127.0.0.1': {'custom_sum': 0, 'custom_list': []}
    }
    for key in keys:
        stats.set_custom_stats('custom_sum', 1, host=key)
        stats.set_custom_stats('custom_list', [1], host=key)
    assert stats.custom == values


# Generated at 2022-06-22 20:18:04.721327
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()

    # Check custom stats
    stats.set_custom_stats("cpu_load", "3")
    print(stats.custom["_run"]["cpu_load"])
    stats.set_custom_stats("cpu_load", "5")
    print(stats.custom["_run"]["cpu_load"])
    stats.set_custom_stats("cpu_load", "4", "host1")
    stats.set_custom_stats("cpu_load", "8", "host1")
    print(stats.custom["host1"]["cpu_load"])
    stats.update_custom_stats("cpu_load", "7", "host1")
    print(stats.custom["host1"]["cpu_load"])


if __name__ == '__main__':
    test_Agg

# Generated at 2022-06-22 20:18:12.168430
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()

    # new object
    assert stats.summarize('localhost') == {
        'ok': 0,
        'failures': 0,
        'unreachable': 0,
        'changed': 0,
        'skipped': 0,
        'rescued': 0,
        'ignored': 0,
    }

    # add a lot of conditions and make sure the totals are correct
    stats.increment('ok', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('dark', 'localhost')
    stats.increment('changed', 'localhost')
    stats.increment('skipped', 'localhost')
    stats.increment('rescued', 'localhost')

# Generated at 2022-06-22 20:18:23.632284
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('failures', 'host2')
    stats.increment('dark', 'host3')
    stats.increment('changed', 'host3')
    stats.increment('changed', 'host3')
    stats.increment('skipped', 'host3')
    stats.increment('rescued', 'host3')
    stats.increment('ignored', 'host3')
    assert stats.summarize('host1') == dict(ok=2, failures=0, unreachable=0, changed=0, skipped=0, rescued=0, ignored=0)

# Generated at 2022-06-22 20:18:33.623322
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    for type in ['ok', 'failures', 'unreachable', 'changed', 'skipped', 'rescued', 'ignored']:
        stats.increment(type, 'host1')
        stats.increment(type, 'host1')
        stats.increment(type, 'host2')
    result = {
        'ok': 2,
        'failures': 2,
        'unreachable': 2,
        'changed': 2,
        'skipped': 2,
        'rescued': 2,
        'ignored': 2,
    }
    assert 'host1' in stats.processed
    assert stats.summarize('host1') == result, \
        "test_AggregateStats_summarize method fails for host1"
    assert 'host2' in stats

# Generated at 2022-06-22 20:18:43.308606
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    test_obj = AggregateStats()
    assert test_obj.custom == {}
    test_obj.update_custom_stats('foo', 1, '_run')
    assert test_obj.custom == {'_run': {'foo': 1}}
    test_obj.update_custom_stats('foo', 1, 'host1')
    assert test_obj.custom == {'_run': {'foo': 1}, 'host1': {'foo': 1}}
    test_obj.update_custom_stats('foo', 'abc', '_run')
    assert test_obj.custom == {'_run': {'foo': 'abc'}, 'host1': {'foo': 1}}
    test_obj.update_custom_stats('foo', {'a': 1, 'b': 2}, '_run')
    assert test_obj.custom

# Generated at 2022-06-22 20:18:45.896422
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg = AggregateStats()

    # increment variable ok
    agg.increment('ok', 'host01')

    assert agg.ok['host01'] == 1
    assert agg.processed['host01'] == 1
    assert agg.dark['host01'] == 0
    assert agg.changed['host01'] == 0
    assert agg.failures['host01'] == 0


# Generated at 2022-06-22 20:18:56.861375
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stat = AggregateStats()
    stat.increment("ok", "host1")
    stat.increment("ok", "host1")
    stat.increment("ok", "host2")
    stat.increment("changed", "host2")
    stat.increment("failures", "host1")
    assert {"ok": 2, "failures": 1, "unreachable": 0, "changed": 1, "skipped": 0, "rescued": 0, "ignored": 0} == stat.summarize("host1")
    assert {"ok": 1, "failures": 0, "unreachable": 0, "changed": 1, "skipped": 0, "rescued": 0, "ignored": 0} == stat.summarize("host2")


# Generated at 2022-06-22 20:18:57.962615
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()


# Generated at 2022-06-22 20:19:06.338752
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    ''' Check the method set_custom_stats of class AggregateStats '''

    # object init
    ag = AggregateStats()

    # Empty object
    assert not ag.custom

    # Set custom stats
    ag.set_custom_stats("foo", "bar", "baz")
    assert {'baz': {'foo': 'bar'}} == ag.custom

    # Add a custom stat (existing key)
    ag.set_custom_stats("foo", "bar")
    assert {'_run': {'foo': 'bar'}, 'baz': {'foo': 'bar'}} == ag.custom

    # Add a custom stat (non-existing key)
    ag.set_custom_stats("foo", "bar", "buzz")

# Generated at 2022-06-22 20:19:11.535965
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment("ok", "host")
    assert aggregate_stats.processed["host"] == 1
    assert aggregate_stats.ok["host"] == 1


# Generated at 2022-06-22 20:19:19.455338
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate = AggregateStats()
    aggregate.set_custom_stats('test', {'foo': 1, 'bar': 2})
    assert aggregate.custom['_run']['test'] == {'foo': 1, 'bar': 2}
    aggregate.update_custom_stats('test', {'foo': 2, 'bar': -2})
    assert aggregate.custom['_run']['test'] == {'foo': 3, 'bar': 0}
    aggregate.update_custom_stats('test', {'foo': 'string'})
    assert aggregate.custom['_run']['test'] == {'foo': 3, 'bar': 0}
    aggregate.update_custom_stats('test', {'foo': 1})
    assert aggregate.custom['_run']['test'] == {'foo': 3, 'bar': 0}
    aggregate

# Generated at 2022-06-22 20:19:25.446111
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():

    ags = AggregateStats()
    ags.increment('ok', '1.1.1.1')
    assert ags.ok['1.1.1.1'] == 1
    assert ags.processed['1.1.1.1'] == 1



# Generated at 2022-06-22 20:19:28.069528
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('example', dict(a=42), host='localhost')
    assert stats.custom['localhost']['example'] == dict(a=42)


# Generated at 2022-06-22 20:19:39.913896
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Tests for decrement method of class AggregateStats
    aggstats = AggregateStats()
    aggstats.processed = {'host1': 1, 'host2': 1, 'host3': 1}
    aggstats.ok = {'host1': 1, 'host2': 2, 'host3': 1}
    aggstats.failures = {'host1': 1, 'host2': 1, 'host3': 2}
    aggstats.dark = {'host1': 1, 'host2': 2, 'host3': 1}
    aggstats.changed = {'host1': 2, 'host2': 1, 'host3': 2}
    aggstats.skipped = {'host1': 1, 'host2': 1, 'host3': 2}

# Generated at 2022-06-22 20:19:44.432910
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    print("Unit test for method set_custom_stats of class AggregateStats")
    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats("which", "what", '_run')
    print("Pass" if aggregate_stats.custom['_run']['which'] == "what" else "Fail")


# Generated at 2022-06-22 20:19:54.094275
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    s = AggregateStats()
    s.ok['localhost'] = 1
    s.failures['localhost'] = 2
    s.dark['localhost'] = 3
    s.changed['localhost'] = 4
    s.skipped['localhost'] = 5
    s.rescued['localhost'] = 6
    s.ignored['localhost'] = 7

    result = s.summarize('localhost')
    assert result['ok'] == 1
    assert result['failures'] == 2
    assert result['unreachable'] == 3
    assert result['changed'] == 4
    assert result['skipped'] == 5
    assert result['rescued'] == 6
    assert result['ignored'] == 7


# Generated at 2022-06-22 20:19:56.087737
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg = AggregateStats()
    agg.increment('failures', 'foo')
    assert agg.failures['foo'] == 1


# Generated at 2022-06-22 20:20:02.550302
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('failures', 'host1')
    if stats.failures['host1'] != 0:
        print("Decrement didn't work, got: " + str(stats.failures['host1']))

    stats.increment('failures', 'host1')
    stats.decrement('failures', 'host1')
    if stats.failures['host1'] != 0:
        print("Decrement didn't work, got: " + str(stats.failures['host1']))


# Generated at 2022-06-22 20:20:13.083301
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment("ok", "host1")
    stats.increment("ok", "host1")
    stats.increment("ok", "host2")
    assert stats.summarize("host1") == dict(
        ok=2,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0,
    )
    assert stats.summarize("host2") == dict(
        ok=1,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0,
    )

# Generated at 2022-06-22 20:20:19.062977
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    '''Test the set_custom_stats method with a hostname and without '''

    stats = AggregateStats()
    stats.set_custom_stats('return_code', 0)

    # Check with a hostname
    stats.set_custom_stats('return_code', 0, 'localhost')

    # Check without a hostname
    assert '_run' in stats.custom
    assert isinstance(stats.custom['_run'], dict)
    assert 'return_code' in stats.custom['_run']
    assert stats.custom['_run']['return_code'] == 0



# Generated at 2022-06-22 20:20:29.082590
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()

    stats.ok['host1'] = 1
    stats.ok['host2'] = 2
    stats.ok['host3'] = 3

    stats.changed['host1'] = 1
    stats.changed['host2'] = 2
    stats.changed['host3'] = 3

    stats.failures['host1'] = 1
    stats.failures['host2'] = 2
    stats.failures['host3'] = 3

    stats.unreachable['host1'] = 1
    stats.unreachable['host2'] = 2
    stats.unreachable['host3'] = 3

    stats.skipped['host1'] = 1
    stats.skipped['host2'] = 2
    stats.skipped['host3'] = 3

    stats.rescued['host1'] = 1
   

# Generated at 2022-06-22 20:20:37.074356
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert isinstance(stats, AggregateStats)
    assert stats.custom == {}
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}

# Generated at 2022-06-22 20:20:41.013740
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-22 20:20:50.728602
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('changed', 'localhost')
    stats.increment('changed', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('dark', 'localhost')
    stats.increment('dark', 'localhost')
    stats.increment('skipped', 'localhost')

    assert stats.summarize('localhost') == {
        'ok': 3,
        'changed': 2,
        'failures': 1,
        'unreachable': 2,
        'skipped': 1,
    }


# Generated at 2022-06-22 20:21:00.783424
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()

    # Set impossible values
    stats.ok['host1'] = -1
    stats.failures['host1'] = -1
    stats.changed['host1'] = -1
    stats.dark['host1'] = -1
    stats.skipped['host1'] = -1
    stats.rescued['host1'] = -1
    stats.ignored['host1'] = -1

    # Summarize the stat object
    summarized_stat = stats.summarize('host1')

    # Check if the summarized_stat is of the expected type
    assert isinstance(summarized_stat, dict)

    # Check if the summarized_stat has the expected content

# Generated at 2022-06-22 20:21:06.807510
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()

    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}



# Generated at 2022-06-22 20:21:09.009647
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():

    stats = AggregateStats()
    stats.increment("ok", "localhost")
    assert stats.ok.get("localhost") == 1


# Generated at 2022-06-22 20:21:17.745498
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    from ansible.module_utils.common._collections_compat import MutableMapping

    stats = AggregateStats()
    stats.increment("dark", "test1")
    stats.increment("dark", "test1")
    stats.increment("dark", "test1")
    stats.decrement("dark", "test1")
    assert isinstance(stats.dark, MutableMapping)
    assert stats.dark.get("test1", 0) == 2
    stats.decrement("dark", "test1")
    assert stats.dark.get("test1", 0) == 1
    stats.decrement("dark", "test1")
    assert stats.dark.get("test1", 0) == 0
    stats.decrement("dark", "test2")

# Generated at 2022-06-22 20:21:25.100500
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ''' Test decrement in AggregateStats'''
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    assert stats.processed['localhost'] == 1

    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    assert stats.processed['localhost'] == 1
    return True

if __name__ == '__main__':
    test_AggregateStats_decrement()

# Generated at 2022-06-22 20:21:31.826807
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    astat = AggregateStats()
    astat.set_custom_stats('total_languages', 1, "example.org")
    astat.set_custom_stats('languages', { 'Perl':'1.0' }, "example.org")

    assert astat.custom == { 'example.org': {
        'languages': { 'Perl':'1.0' },
        'total_languages': 1
    } }


# Generated at 2022-06-22 20:21:35.009736
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()

    # Check global custom stats can be reset
    stats.set_custom_stats('foo', 'bar')
    assert stats.custom['_run'] == {'foo': 'bar'}


# Generated at 2022-06-22 20:21:42.291843
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():

    def get_custom_stats(aggregate_stats_obj, host):
        return aggregate_stats_obj.custom[host]

    def custom_stats_match(custom_stats_observed, custom_stats_expected):
        return custom_stats_observed == custom_stats_expected

    aggregate_stats_obj = AggregateStats()
    aggregate_stats_obj.set_custom_stats('custom_stats_key', 'custom_stats_value')
    custom_stats_observed = get_custom_stats(aggregate_stats_obj, '_run')
    custom_stats_expected = {'custom_stats_key': 'custom_stats_value'}
    assert(custom_stats_match(custom_stats_observed, custom_stats_expected))

    aggregate_stats_obj = AggregateStats()

# Generated at 2022-06-22 20:21:50.240480
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():

    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')

    result = stats.summarize('host1')
    assert result['ok'] == 3
    assert result['changed'] == 0
    assert result['unreachable'] == 0
    assert result['failures'] == 0
    assert result['skipped'] == 0
    assert result['rescued'] == 0
    assert result['ignored'] == 0

# Generated at 2022-06-22 20:22:01.137102
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'test1')
    stats.increment('failures', 'test1')
    stats.increment('ok', 'test1')
    stats.increment('ok', 'test2')
    stats.increment('failures', 'test2')
    stats.increment('ok', 'test2')
    stats.increment('failures', 'test2')

    assert stats.summarize('test1') == {'ok': 2, 'failures': 1, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}

# Generated at 2022-06-22 20:22:08.634362
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment("ok", "localhost")
    stats.increment("ok", "localhost")
    stats.decrement("ok", "localhost")
    assert stats.ok["localhost"] == 1
    stats.decrement("ok", "localhost")
    assert stats.ok["localhost"] == 0
    stats.decrement("ok", "localhost")
    assert stats.ok["localhost"] == 0

# Generated at 2022-06-22 20:22:17.275801
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    # Test that an existing custom stat is updated when types match
    stats = AggregateStats()
    stats.custom['a'] = {'b': 4}
    stats.update_custom_stats('b', 1, 'a')
    assert stats.custom['a']['b'] == 5

    # Test that an existing custom stat is updated when types match
    stats = AggregateStats()
    stats.custom['a'] = {'b': {'c':4}}
    stats.update_custom_stats('b', {'c':1}, 'a')
    assert stats.custom['a']['b']['c'] == 5

    # Test that it doesn't update when types don't match
    stats = AggregateStats()
    stats.custom['a'] = {'b': 4}

# Generated at 2022-06-22 20:22:26.474034
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    ''' test the summarize method of AggregateStats '''

    stats = AggregateStats()
    stats.increment('ok', 'test_host')
    stats.increment('ok', 'test_host')
    stats.increment('ok', 'test_host')
    stats.increment('failures', 'test_host')
    stats.increment('dark', 'test_host')
    stats.increment('changed', 'test_host')
    stats.increment('skipped', 'test_host')
    stats.increment('rescued', 'test_host')
    stats.increment('ignored', 'test_host')

    test_host_result = stats.summarize('test_host')
    assert test_host_result['ok'] == 3
    assert test_host_result['failures'] == 1
   

# Generated at 2022-06-22 20:22:36.164062
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    # List
    stats.update_custom_stats('list', ['foo'])
    assert stats.custom['_run']['list'] == ['foo']
    stats.update_custom_stats('list', ['bar'])
    assert stats.custom['_run']['list'] == ['foo', 'bar']

    # Hash
    stats.update_custom_stats('hash', {'foo': 'bar'})
    assert stats.custom['_run']['hash'] == {'foo': 'bar'}
    stats.update_custom_stats('hash', {'fuu': 'baz'})
    assert stats.custom['_run']['hash'] == {'foo': 'bar', 'fuu': 'baz'}

    # Integer

# Generated at 2022-06-22 20:22:38.415829
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('changed', 1, 'testhost')
    assert stats.custom['testhost'] == {'changed': 1}


# Generated at 2022-06-22 20:22:40.128633
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('changed', 'localhost')
    assert stats.changed['localhost'] == 0


# Generated at 2022-06-22 20:22:51.542871
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    host1 = 'host1'
    host2 = 'host2'

    success_msg = "Unit test for method decrement of AggregateStats passed"
    stats = AggregateStats()

    stats.increment("failures", host1)
    if stats.failures[host1] != 1:
        raise AssertionError("stats.increment fail")

    stats.decrement("failures", host1)
    if stats.failures[host1] != 0:
        raise AssertionError("stats.decrement failed (1)")

    stats.decrement("failures", host1)
    if stats.failures[host1] != 0:
        raise AssertionError("stats.decrement failed (2)")

    stats.decrement("dark", host2)

# Generated at 2022-06-22 20:23:01.710844
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    summary = AggregateStats()
    assert summary.summarize("host1") == { 'ignored' : 0, 'failures' : 0, 'unreachable' : 0, 'ok' : 0, 'skipped' : 0, 'changed' : 0, 'rescued' : 0 }
    summary.set_custom_stats("custom_stats", {})
    assert summary.summarize("host1") == { 'ignored' : 0, 'failures' : 0, 'unreachable' : 0, 'ok' : 0, 'skipped' : 0, 'changed' : 0, 'rescued' : 0 }

    stats = [ "ok", "failures", "dark", "changed", "skipped", "rescued", "ignored" ]

# Generated at 2022-06-22 20:23:13.685574
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('complex', {'complex': 'stuff'})
    assert stats.custom['_run'] == {'complex': {'complex': 'stuff'}}

    stats.update_custom_stats('string', 'fang')
    stats.update_custom_stats('int', 5)
    assert stats.custom['_run'] == {'complex': {'complex': 'stuff'}, 'string': 'fang', 'int': 5}

    stats.update_custom_stats('complex', {'complex': 'stuff', 'something': 'else'})
    assert stats.custom['_run'] == {'complex': {'complex': 'stuff', 'something': 'else'}, 'string': 'fang', 'int': 5}

    stats.update_custom_stats('string', 'bar')
   

# Generated at 2022-06-22 20:23:23.145923
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    import unittest

    class TestAggregateStats(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.stats = AggregateStats()
            cls.stats.increment('ok', 'host1')
            cls.stats.increment('ok', 'host1')
            cls.stats.increment('ok', 'host2')
            cls.stats.increment('failures', 'host1')
            cls.stats.increment('dark', 'host1')
            cls.stats.increment('changed', 'host1')
            cls.stats.increment('skipped', 'host2')


# Generated at 2022-06-22 20:23:30.315860
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert isinstance(stats.processed, dict)
    assert isinstance(stats.failures, dict)
    assert isinstance(stats.ok, dict)
    assert isinstance(stats.dark, dict)
    assert isinstance(stats.changed, dict)
    assert isinstance(stats.skipped, dict)
    assert isinstance(stats.rescued, dict)
    assert isinstance(stats.ignored, dict)
    assert isinstance(stats.custom, dict)


# Generated at 2022-06-22 20:23:35.347110
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-22 20:23:44.590062
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    ag = AggregateStats()
    ag.increment('ok', 'host1')
    ag.increment('ignore', 'host1')
    res = ag.summarize('host1')
    assert res == {'ok': 1, 'failures': 0, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 1}

    ag.increment('failures', 'host2')
    res = ag.summarize('host2')
    assert res == {'ok': 0, 'failures': 1, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}

# Generated at 2022-06-22 20:23:56.722092
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    s = AggregateStats()
    s.update_custom_stats('counter', 1)
    s.update_custom_stats('counter', 1)
    assert s.custom['_run']['counter'] == 2
    s.update_custom_stats('counter', 1)
    assert s.custom['_run']['counter'] == 3

    s.update_custom_stats('dict1', {'key_string': 'value', 'key_int': 2})
    s.update_custom_stats('dict1', {'key_int': 3})
    assert s.custom['_run']['dict1']['key_string'] == 'value'
    assert s.custom['_run']['dict1']['key_int'] == 5


# Generated at 2022-06-22 20:23:58.679179
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host')
    assert stats.ok['host'] == 1


# Generated at 2022-06-22 20:24:01.945651
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
	stats = AggregateStats()
	assert set(["processed", "failures", "ok", "dark", "changed", "skipped", "custom", "rescued", "ignored"]) == set(stats.__dict__.keys())


# Generated at 2022-06-22 20:24:06.806502
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregateStats = AggregateStats()

    aggregateStats.decrement('ok', 'host1')
    assert aggregateStats.ok['host1'] == 0

    aggregateStats.ok['host1'] = 1
    aggregateStats.decrement('ok', 'host1')
    assert aggregateStats.ok['host1'] == 0


# Generated at 2022-06-22 20:24:18.408779
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    stats = AggregateStats()

    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run'] == {'foo': 1}

    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run'] == {'foo': 2}

    stats.update_custom_stats('foo', 1, 'localhost')
    assert stats.custom['localhost'] == {'foo': 1}

    stats.update_custom_stats('foo', 1, 'localhost')
    assert stats.custom['localhost'] == {'foo': 2}

    stats.update_custom_stats('foo', [1])
    assert stats.custom['_run'] == {'foo': [1, 2]}

    stats.update

# Generated at 2022-06-22 20:24:23.434266
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ignored = {"abc": 1, "def": 2, "ghi": 3}
    stats.decrement("ignored", "abc")
    stats.decrement("ignored", "def")
    stats.decrement("ignored", "ghi")
    stats.decrement("ignored", "jkl")

    assert stats.ignored["abc"] == 0
    assert stats.ignored["def"] == 1
    assert stats.ignored["ghi"] == 2
    assert "jkl" not in stats.ignored

# Generated at 2022-06-22 20:24:34.296430
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    s = AggregateStats()
    s.increment('ok', '192.0.2.1')
    s.increment('skipped', '192.0.2.1')
    s.increment('skipped', '192.0.2.1')
    s.increment('skipped', '192.0.2.2')
    s.increment('skipped', '192.0.2.2')
    s.increment('failed', '192.0.2.2')
    s.increment('rescued', '192.0.2.2')
    s.increment('changed', '192.0.2.3')
    s.increment('unchanged', '192.0.2.3')
    s.increment('dark', '192.0.2.4')

    s.set

# Generated at 2022-06-22 20:24:39.991761
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    c = AggregateStats()
    c.increment('failures', 'localhost')
    c.increment('failures', 'localhost')
    c.increment('dark', 'localhost')
    assert c.failures == {'localhost': 2}
    assert c.dark == {'localhost': 1}
    assert c.ok == {}
    assert c.changed == {}
    assert c.skipped == {}
    assert c.rescued == {}
    assert c.ignored == {}


# Generated at 2022-06-22 20:24:51.674552
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    s = AggregateStats()
    s.set_custom_stats('x', '10')
    s.set_custom_stats('y', '20')
    s.update_custom_stats('x', '5')
    s.update_custom_stats('y', '3')
    assert s.custom['_run']['x'] == '15'
    assert s.custom['_run']['y'] == '23'
    s.set_custom_stats('m', '10', host='h1')
    s.set_custom_stats('n', '20', host='h1')
    s.update_custom_stats('m', '5', host='h1')
    s.update_custom_stats('n', '3', host='h1')

# Generated at 2022-06-22 20:24:59.998385
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.vars import VariableManager
    from ansible.template import Templar

    import unitsh

    stats = AggregateStats()
