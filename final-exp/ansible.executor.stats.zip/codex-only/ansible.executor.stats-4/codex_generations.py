

# Generated at 2022-06-22 20:15:09.089883
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.summarize('localhost') == {'ok': 1, 'failures': 0, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}
    stats.increment('failures', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('failures', 'localhost')
    assert stats.summarize('localhost') == {'ok': 1, 'failures': 3, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    assert stats.summar

# Generated at 2022-06-22 20:15:16.069623
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ag = AggregateStats()
    ag.increment('failures', 'host1')
    ag.increment('ok', 'host2')
    ag.increment('skipped', 'host2')
    ag.increment('skipped', 'host1')

    assert ag.failures == {'host1': 1}
    assert ag.ok == {'host2': 1}
    assert ag.skipped == {'host2': 1, 'host1': 1}


# Generated at 2022-06-22 20:15:22.517127
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stat = AggregateStats()

    assert stat.processed == {}
    assert stat.failures == {}
    assert stat.ok == {}
    assert stat.dark == {}
    assert stat.changed == {}
    assert stat.skipped == {}
    assert stat.rescued == {}
    assert stat.ignored == {}
    assert stat.custom == {}

# Generated at 2022-06-22 20:15:26.344123
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()

    # Test attributes are initialized with empty dict
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}



# Generated at 2022-06-22 20:15:26.914102
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    assert 1 == 0

# Generated at 2022-06-22 20:15:28.101562
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.failures == {}

# Generated at 2022-06-22 20:15:29.478162
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    assert_equals(AggregateStats().ignored, {})


# Generated at 2022-06-22 20:15:31.005923
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    ag_stats = AggregateStats()
    assert ag_stats is not None


# Generated at 2022-06-22 20:15:42.447448
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    assert stats.summarize('host1')['ok'] == 2
    stats.decrement('ok', 'host1')
    assert stats.summarize('host1')['ok'] == 1
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host1')
    assert stats.summarize('host1')['ok'] == 0
    with pytest.raises(KeyError):
        stats.decrement('ok', 'host1')
    with pytest.raises(KeyError):
        stats.decrement('ok', 'host3')
    assert stats.summarize

# Generated at 2022-06-22 20:15:48.250039
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('skipped', 'host1')
    stats.increment('skipped', 'host2')
    stats.increment('skipped', 'host2')
    assert stats.ok == {'host1': 2, 'host2': 1}, stats.ok
    assert stats.skipped == {'host1': 1, 'host2': 2}


# Generated at 2022-06-22 20:15:51.510368
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('user', 'who', 'localhost')
    assert stats.custom['localhost']['user'] == 'who'


# Generated at 2022-06-22 20:16:00.244580
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.failures['example_host'] = 2
    stats.decrement('failures', 'example_host')
    assert stats.failures['example_host'] == 1
    stats.decrement('failures', 'example_host')
    assert stats.failures['example_host'] == 0
    stats.decrement('failures', 'example_host')
    assert stats.failures['example_host'] == 0
    stats.decrement('failures', 'example_host2')
    assert 'example_host2' not in stats.failures

# Generated at 2022-06-22 20:16:03.695741
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    test_aggregate_stats = AggregateStats()
    test_host = 'hostname'

    # test update_custom_stats with existing value and a new value that is an integer
    test_aggregate_stats.custom[test_host] = {'exist_key': 1}
    test_aggregate_stats.update_custom_stats('exist_key', 12, test_host)
    assert test_aggregate_stats.custom[test_host]['exist_key'] == 13
    test_aggregate_stats.update_custom_stats('exist_key', -12, test_host)
    assert test_aggregate_stats.custom[test_host]['exist_key'] == 1

    # test update_custom_stats with an existing value and a new value that is a string
    test_aggregate_stats.custom[test_host]

# Generated at 2022-06-22 20:16:15.339084
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('num_fail', 2)
    assert stats.custom['_run']['num_fail'] == 2

    stats.update_custom_stats('num_fail', 3)
    assert stats.custom['_run']['num_fail'] == 5

    stats.update_custom_stats('failed_hosts', ['host2'])
    assert stats.custom['_run']['failed_hosts'] == ['host2']

    stats.update_custom_stats('failed_hosts', ['host1'])
    assert stats.custom['_run']['failed_hosts'] == ['host2', 'host1']

    stats.update_custom_stats('failed_hosts', {'host4': 'msg4'})

# Generated at 2022-06-22 20:16:22.755497
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')

    stats.decrement('ok', 'host1')

    # ok is not None
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1
    # ok is None
    stats.decrement('ok', 'host3')
    assert 'host3' not in stats.ok
    # This was causing traceback
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0

# Generated at 2022-06-22 20:16:34.289012
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('test', 1)
    assert stats.custom['_run']['test'] == 1
    stats.update_custom_stats('test', 1)
    assert stats.custom['_run']['test'] == 2
    stats.update_custom_stats('test', {'key1': 1, 'key2': 2})
    assert stats.custom['_run']['test'] == {'key1': 1, 'key2': 2}
    stats.update_custom_stats('test', {'key2': 3, 'key3': 4})
    assert stats.custom['_run']['test'] == {'key1': 1, 'key2': 3, 'key3': 4}

    # For this test to actually make sense, we have to have run_once=False

# Generated at 2022-06-22 20:16:43.405340
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('custom_stat', 2)
    assert stats.custom == {'_run': {'custom_stat': 2}}
    stats.set_custom_stats('other_custom_stat', 3)
    assert stats.custom == {'_run': {'custom_stat': 2, 'other_custom_stat': 3}}
    stats.set_custom_stats('custom_stat', 5, 'myhost')
    assert stats.custom == {'_run': {'custom_stat': 2, 'other_custom_stat': 3},
                            'myhost': {'custom_stat': 5}}


# Generated at 2022-06-22 20:16:46.528000
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('custom_stat', 1)
    stats.update_custom_stats('custom_stat', 2)
    stats.update_custom_stats('custom_stat', 3)

    stats.update_custom_stats('custom_stat', 4, '_run')
    stats.update_custom_stats('custom_stat', 5, '_run')
    stats.update_custom_stats('custom_stat', 6, '_run')

    assert stats.custom['_run']['custom_stat'] == 15


# Generated at 2022-06-22 20:16:57.907202
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()

    aggregate_stats.set_custom_stats('key_1', 1)
    aggregate_stats.set_custom_stats('key_2', '2')
    aggregate_stats.set_custom_stats('key_3', {'a': 1})
    aggregate_stats.set_custom_stats('key_4', [1])

    assert aggregate_stats.custom['_run']['key_1'] == 1
    assert aggregate_stats.custom['_run']['key_2'] == '2'
    assert aggregate_stats.custom['_run']['key_3'] == {'a': 1}
    assert aggregate_stats.custom['_run']['key_4'] == [1]

    # set different value for key_3

# Generated at 2022-06-22 20:17:08.924185
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    # Case when host is None.
    # Case when custom_stats is not present.
    aggregate_stats.update_custom_stats("which","what")
    assert aggregate_stats.custom["_run"]["which"] == "what"
    # Case when custom_stats is of type MutableMapping
    aggregate_stats.update_custom_stats("which", {"key":"value"}, "test_host")
    assert aggregate_stats.custom["test_host"]["which"] == {"key":"value"}
    # Case when custom_stats is of type not present.
    aggregate_stats.update_custom_stats("which", "what")
    assert aggregate_stats.custom["_run"]["which"] == "what"

# Generated at 2022-06-22 20:17:13.752352
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    a = AggregateStats()
    assert a.processed == {}
    assert a.failures == {}
    assert a.ok == {}
    assert a.dark == {}
    assert a.changed == {}
    assert a.skipped == {}
    assert a.rescued == {}
    assert a.custom == {}
    assert a.ignored == {}


# Generated at 2022-06-22 20:17:25.456774
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg_stats = AggregateStats()
    agg_stats.set_custom_stats('my_custom_stats', {'a': 3})
    assert agg_stats.custom == {'_run': {'my_custom_stats': {'a': 3}}}
    agg_stats.set_custom_stats('my_other_custom_stats', 10)
    assert agg_stats.custom == {'_run': {'my_custom_stats': {'a': 3}, 'my_other_custom_stats': 10}}
    agg_stats.custom = {}
    agg_stats.set_custom_stats('my_custom_stats', {'b': 2}, host='myhost')
    assert agg_stats.custom == {'myhost': {'my_custom_stats': {'b': 2}}}
    agg_stats.set_custom_stats

# Generated at 2022-06-22 20:17:33.445089
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('failures', 'localhost')
    assert stats.failures.get('localhost') == 1
    stats.increment('failures', 'localhost')
    assert stats.failures.get('localhost') == 2
    assert stats.ok.get('localhost') == 0
    stats.increment('ok', 'localhost')
    assert stats.ok.get('localhost') == 1
    stats.increment('ok', 'localhost')
    assert stats.ok.get('localhost') == 2


# Generated at 2022-06-22 20:17:37.069386
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggstat = AggregateStats()
    aggstat.increment('ok', 'localhost')
    assert aggstat.ok['localhost'] == 1

    aggstat.increment('ok', 'localhost')
    assert aggstat.ok['localhost'] == 2



# Generated at 2022-06-22 20:17:43.953745
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test_object = AggregateStats()
    test_object.processed['host'] = 1
    test_object.ok['host'] = 1
    test_object.failures['host'] = 0
    test_object.dark['host'] = 0
    test_object.changed['host'] = 0
    test_object.skipped['host'] = 0
    test_object.rescued['host'] = 0
    test_object.ignored['host'] = 0
    test_object.decrement('ok', 'host')
    result = test_object.ok['host']
    assert(result == 0)


# Generated at 2022-06-22 20:17:45.647413
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg_stats = AggregateStats()
    assert type(agg_stats) == AggregateStats

# Generated at 2022-06-22 20:17:51.337809
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    a = AggregateStats()
    a.skipped = { 'host1': 1, 'host2': 2 }
    assert a.skipped[ 'host1' ] == 1
    a.decrement( 'skipped', 'host1' )
    assert a.skipped[ 'host1' ] == 0
    assert a.skipped[ 'host2' ] == 2
    a.decrement( 'skipped', 'host2' )
    assert a.skipped[ 'host2' ] == 1

# Generated at 2022-06-22 20:18:03.487420
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    stats.update_custom_stats('list', ['1'], 'host')
    stats.update_custom_stats('list', ['2'], 'host')
    stats.update_custom_stats('list', ['3'], 'host')

    assert stats.custom['host']['list'] == ['1', '2', '3']

    stats.update_custom_stats('dict', {'1': '2'}, 'host')
    stats.update_custom_stats('dict', {'3': '4'}, 'host')

    assert stats.custom['host']['dict'] == {'1': '2', '3': '4'}

    stats.update_custom_stats('int', 1, 'host')
    stats.update_custom_stats('int', 2, 'host')

    assert stats

# Generated at 2022-06-22 20:18:09.758047
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Setup
    astats = stats.AggregateStats()
    stats.increment(what, host, astats)
    stats.increment(what, host, astats)

    # Exercise
    stats.decrement(what, host, astats)

    # Verify
    expected_result = {}
    expected_result[what] = {}
    expected_result[what][host] = 1
    assert astats.__dict__[what] == expected_result[what]

    # Cleanup - none necessary, everything is container/mutable


# Generated at 2022-06-22 20:18:21.753717
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    for what in ['failures', 'ok', 'dark', 'changed', 'skipped', 'rescued', 'ignored']:
        a = AggregateStats()
        a.increment(what, 'host1')
        assert a.processed == {'host1': 1}
        assert getattr(a, what) == {'host1': 1}
        assert a.summarize('host1') == {'ok': 1, 'failures': 0, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}
        a.increment(what, 'host2')
        assert a.processed == {'host1': 1, 'host2': 1}
        assert getattr(a, what) == {'host1': 1, 'host2': 1}

# Generated at 2022-06-22 20:18:25.158405
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('custom', 'test')
    assert stats.custom == {'_run': {'custom': 'test'}}


# Generated at 2022-06-22 20:18:33.961498
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'test-host')
    aggregate_stats.increment('changed', 'test-host')
    aggregate_stats.increment('ignored', 'test-host')
    aggregate_stats.increment('rescued', 'test-host')
    aggregate_stats.increment('skipped', 'test-host')

    summarize = aggregate_stats.summarize('test-host')
    assert summarize['ok'] == 1
    assert summarize['failures'] == 0
    assert summarize['unreachable'] == 0
    assert summarize['changed'] == 1
    assert summarize['rescued'] == 1
    assert summarize['ignored'] == 1
    assert summarize['skipped'] == 1

# Generated at 2022-06-22 20:18:45.019337
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.processed = {'foo':1}
    stats.ok = {'foo':2}
    stats.failures = {'foo':3}
    stats.dark = {'foo':4}
    stats.changed = {'foo':5}
    stats.skipped = {'foo':6}
    stats.rescued = {'foo':7}
    stats.ignored = {'foo':8}
    expected = {
        'ok': 2,
        'failures': 3,
        'unreachable': 4,
        'changed': 5,
        'skipped': 6,
        'rescued': 7,
        'ignored': 8,
    }
    assert stats.summarize('foo') == expected



# Generated at 2022-06-22 20:18:52.442441
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggr_stats = AggregateStats()
    aggr_stats.set_custom_stats('foo', 42, 'bar')
    assert aggr_stats.custom['bar']['foo'] == 42
    aggr_stats.set_custom_stats('foo', 43, 'bar')
    assert aggr_stats.custom['bar']['foo'] == 43
    aggr_stats.set_custom_stats('foo', 44)
    assert aggr_stats.custom['_run']['foo'] == 44


# Generated at 2022-06-22 20:19:01.734542
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    '''
    Ensure that complex types are merged properly
    '''
    astats = AggregateStats()

    astats.update_custom_stats('dict_stats', {'foo': 1}, 'localhost')
    assert astats.custom['localhost']['dict_stats'] == {'foo': 1}

    astats.update_custom_stats('dict_stats', {'foo': 2}, 'localhost')
    assert astats.custom['localhost']['dict_stats'] == {'foo': 2}

    astats.update_custom_stats('dict_stats', {'bar': 2}, 'localhost')
    assert astats.custom['localhost']['dict_stats'] == {'foo': 2, 'bar': 2}

# Generated at 2022-06-22 20:19:05.519906
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    x = AggregateStats()
    assert x.processed == {}
    assert x.failures == {}
    assert x.ok == {}
    assert x.dark == {}
    assert x.changed == {}
    assert x.skipped == {}
    assert x.rescued == {}
    assert x.ignored == {}
    assert x.custom == {}


# Generated at 2022-06-22 20:19:10.024619
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats('somekey', 'somevalue', host='bogushost')

    assert 'bogushost' in aggregate_stats.custom
    assert '_run' not in aggregate_stats.custom
    assert aggregate_stats.custom['bogushost']['somekey'] == 'somevalue'



# Generated at 2022-06-22 20:19:13.472294
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ags = AggregateStats()
    ags.increment('ok', "foo")
    ags.increment('skipped', "foo")
    if ags.ok["foo"] == 1 and ags.skipped["foo"] == 1:
        return True
    else:
        return False


# Generated at 2022-06-22 20:19:21.311110
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('stat1', 1, 'host1')

    assert stats.custom == {
        'host1': {
            'stat1': 1
        }
    }

    stats.update_custom_stats('stat2', 2)

    assert stats.custom == {
        'host1': {
            'stat1': 1
        },
        '_run': {
            'stat2': 2
        }
    }

    stats.update_custom_stats('stat2', 1)

    assert stats.custom == {
        'host1': {
            'stat1': 1
        },
        '_run': {
            'stat2': 3
        }
    }

    stats.update_custom_stats('stat1', {'k': 1})

    assert stats.custom

# Generated at 2022-06-22 20:19:33.196928
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # we need to test the case of decrementing the "new" stats
    # being added after 2.3
    test_decrement = AggregateStats()
    test_decrement.processed = {'host': 1}
    test_decrement.ok = {'host': 1}
    test_decrement.failures = {'host': 1}
    test_decrement.dark = {'host': 1}
    test_decrement.changed = {'host': 1}
    test_decrement.skipped = {'host': 1}
    test_decrement.rescued = {'host': 1}
    test_decrement.ignored = {'host': 1}

# Generated at 2022-06-22 20:19:44.389486
# Unit test for method update_custom_stats of class AggregateStats

# Generated at 2022-06-22 20:19:55.547680
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()
    for i in range(10):
        host = "host{}".format(i)
        aggregate_stats.increment("ok", host)
        aggregate_stats.increment("ok", host)
        aggregate_stats.increment("failures", host)
        aggregate_stats.increment("dark", host)
        aggregate_stats.increment("changed", host)
        aggregate_stats.increment("skipped", host)
        aggregate_stats.increment("rescued", host)
        aggregate_stats.increment("ignored", host)

        aggregate_stats.update_custom_stats("foo", i)
        aggregate_stats.update_custom_stats("foo", i, host=host)
        aggregate_stats.update_custom_stats("bar", i, host=host)


# Generated at 2022-06-22 20:19:58.167741
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'host')
    assert stats.ok['host'] == 1
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 0

# Generated at 2022-06-22 20:20:05.610664
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    ag = AggregateStats()
    ag.set_custom_stats('test:stats', {'avg_duration': 2.0, 'total_duration': 10.0})
    assert ag.custom['_run']['test:stats'] == {'avg_duration': 2.0, 'total_duration': 10.0}
    ag.set_custom_stats('test:stats', {'avg_duration': 3.0, 'total_duration': 16.0})
    assert ag.custom['_run']['test:stats'] == {'avg_duration': 3.0, 'total_duration': 16.0}


# Generated at 2022-06-22 20:20:10.406384
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'test_host')
    assert aggregate_stats.processed == {'test_host': 1}
    assert aggregate_stats.ok == {'test_host': 1}
    assert aggregate_stats.failures == {}
    assert aggregate_stats.dark == {}
    assert aggregate_stats.changed == {}
    assert aggregate_stats.skipped == {}
    assert aggregate_stats.rescued == {}
    assert aggregate_stats.ignored == {}
    assert aggregate_stats.custom == {}


# Generated at 2022-06-22 20:20:16.459698
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    a = AggregateStats()
    host = "test_host"
    which = "my_custom_stat"
    what = "a string"
    a.set_custom_stats(which, what, host)
    assert a.custom[host][which] == what
    assert a.custom["_run"][which] == what

    a = AggregateStats()
    a.set_custom_stats(which, what)
    assert a.custom["_run"][which] == what



# Generated at 2022-06-22 20:20:28.084071
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    import json
    import pytest
    stats = AggregateStats()
    stats.increment("ok", "localhost")
    stats.increment("failures", "localhost")
    stats.increment("ok", "127.0.0.1")
    stats.increment("failures", "127.0.0.1")
    stats.increment("failures", "127.0.0.2")
    stats.increment("ok", "127.0.0.1")
    stats.increment("dark", "localhost")
    stats.increment("dark", "127.0.0.1")
    stats.increment("changed", "localhost")
    stats.increment("changed", "127.0.0.1")
    stats.increment("changed", "127.0.0.2")
    stats.increment

# Generated at 2022-06-22 20:20:40.517855
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    ''' Test case for AggregateStats.summarize() '''

    stats = AggregateStats()
    stats.increment("ok", "foo")
    stats.increment("ok", "foo")
    stats.increment("failures", "foo")
    stats.increment("dark", "foo")
    stats.increment("dark", "foo")
    stats.increment("dark", "foo")
    stats.increment("changed", "foo")
    stats.increment("skipped", "foo")
    stats.increment("rescued", "foo")
    stats.increment("ignored", "foo")


# Generated at 2022-06-22 20:20:50.879032
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    ''' test method summarize of class AggregateStats '''

    aggregate_stats = AggregateStats()
    aggregate_stats.ok = {'host1': 1, 'host2': 2, 'host3': 3}
    aggregate_stats.dark = {'host1': 0, 'host2': 1, 'host3': 2}
    aggregate_stats.changed = {'host1': 3, 'host2': 0, 'host3': 1}
    aggregate_stats.failures = {'host1': 1, 'host2': 0, 'host3': 9}

    assert aggregate_stats.summarize('host1') == {'ok': 1, 'failures': 1, 'unreachable': 0, 'changed': 3, 'skipped': 0, 'rescued': 0, 'ignored': 0}
    assert aggregate_stats.summar

# Generated at 2022-06-22 20:20:59.783127
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    play_context = PlayContext()
    aggregate_stats = AggregateStats()

    aggregate_stats.processed['host1'] = 1
    aggregate_stats.ok['host1'] = 1
    aggregate_stats.ok['host2'] = 2
    aggregate_stats.ok['host3'] = 3
    aggregate_stats.ok['host4'] = 4

    aggregate_stats.custom['host1'] = dict(a=1)
    aggregate_stats.custom['host2'] = dict(a=2)
    aggregate_stats.custom['host3'] = dict(a=3)
    aggregate_stats.custom

# Generated at 2022-06-22 20:21:01.107826
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    a = AggregateStats()
    host = "test_host"
    a.increment("ok", host)
    assert a.ok[host] == 1



# Generated at 2022-06-22 20:21:12.347525
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # instantiate AggregateStats
    stats = AggregateStats()

    # define pairs of {custom_stat: expected_value} for each case
    pairs_1 = {
        'foo': ['bar'],
        'bar': {'baz': 'baaz'}
    }
    pairs_2 = {
        'foo': ['bar', 'baz'],
        'bar': {'baz': 'baaz', 'baaz': 'bazz'}
    }

    # 1st case, with host in self.custom already
    # call 1st time
    for custom_stat, what in pairs_1.items():
        stats.set_custom_stats(custom_stat, what, host='some_host')

    # check 1st time
    for custom_stat, expected in pairs_1.items():
        assert stats.custom

# Generated at 2022-06-22 20:21:23.065323
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    test_aggregate_stats = AggregateStats()
    assert isinstance(test_aggregate_stats.processed, dict)
    assert isinstance(test_aggregate_stats.ok, dict)
    assert isinstance(test_aggregate_stats.dark, dict)
    assert isinstance(test_aggregate_stats.changed, dict)
    assert isinstance(test_aggregate_stats.skipped, dict)
    assert isinstance(test_aggregate_stats.rescued, dict)
    assert isinstance(test_aggregate_stats.ignored, dict)
    assert isinstance(test_aggregate_stats.custom, dict)

# Generated at 2022-06-22 20:21:33.059254
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    import pytest

    a = AggregateStats()
    a.ok['host1'] = 2
    a.failures['host2'] = 3
    a.dark['host1'] = 10

    assert a.summarize('host1') == {'ok': 2, 'failures': 0, 'unreachable': 10, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}
    assert a.summarize('host2') == {'ok': 0, 'failures': 3, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}
    pytest.raises(Exception, a.summarize, 'host3')

# Generated at 2022-06-22 20:21:34.709549
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    import pytest

    with pytest.raises(AttributeError) as excinfo:
        AggregateStats()

# Generated at 2022-06-22 20:21:42.095881
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    from ansible.utils.display import Display
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('ok', 'example.com')
    stats.increment('failures', 'example.com')
    stats.increment('dark', 'example.com')

    display = Display()
    assert dict(changed=0, failures=1, ignored=0, ok=2, rescued=0, skipped=0, unreachable=0) == stats.summarize('localhost')
    assert dict(changed=0, failures=1, ignored=0, ok=0, rescued=0, skipped=0, unreachable=1) == stats.summarize('example.com')

    # Unit test for method

# Generated at 2022-06-22 20:21:49.904208
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert type(stats.processed) == dict
    assert type(stats.failures) == dict
    assert type(stats.ok) == dict
    assert type(stats.dark) == dict
    assert type(stats.changed) == dict
    assert type(stats.skipped) == dict
    assert type(stats.rescued) == dict
    assert type(stats.ignored) == dict
    assert type(stats.custom) == dict

# Unit tests for function increment, decrement and summarize

# Generated at 2022-06-22 20:22:00.919882
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
  results = AggregateStats()
  assert results.custom == dict()
  assert results.dark == dict()
  assert results.processed == dict()
  assert results.ignored == dict()
  assert results.ok == dict()
  assert results.skipped == dict()
  assert results.changed == dict()
  assert results.failures == dict()
  assert results.rescued == dict()
  #assert results.__getattribute__("_AggregateStats__increment")
  #assert results.__getattribute__("_AggregateStats__decrement")
  #assert results.__getattribute__("_AggregateStats__summarize")
  #assert results.__getattribute__("_AggregateStats__set_custom_stats")
  #assert results.__getattribute__("_AggregateStats__update_custom_stats")



# Generated at 2022-06-22 20:22:10.824670
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():

    test_obj = AggregateStats()
    # Testing the initial value of processed
    initial_value = test_obj.processed
    assert len(initial_value) == 0

    # Testing the initial value of failures
    initial_value = test_obj.failures
    assert len(initial_value) == 0

    # Testing the initial value of ok
    initial_value = test_obj.ok
    assert len(initial_value) == 0

    # Testing the initial value of dark
    initial_value = test_obj.dark
    assert len(initial_value) == 0

    # Testing the initial value of ignored
    initial_value = test_obj.ignored
    assert len(initial_value) == 0

    # Testing the initial value of changed
    initial_value = test_obj.changed
    assert len(initial_value) == 0



# Generated at 2022-06-22 20:22:19.269084
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    """
    Tests the constructor for AggregateStats

    :return:
    """
    test_obj = AggregateStats()
    assert test_obj.processed == {}
    assert test_obj.failures == {}
    assert test_obj.ok == {}
    assert test_obj.dark == {}
    assert test_obj.changed == {}
    assert test_obj.skipped == {}
    assert test_obj.rescued == {}
    assert test_obj.ignored == {}
    assert test_obj.custom == {}

# Unit test to test incrementing of statistics

# Generated at 2022-06-22 20:22:28.161496
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    from ansible.utils.vars import combine_hash
    from ansible.module_utils._text import to_text


# Generated at 2022-06-22 20:22:37.419575
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    assert stats.custom == {}

    stats.update_custom_stats('foo', 0, 'bar')
    assert stats.custom == {'bar': {'foo': 0}}

    stats.update_custom_stats('foo', 1, 'bar')
    assert stats.custom == {'bar': {'foo': 1}}

    # Test with custom host
    stats.update_custom_stats('foo', 1, 'baz')
    assert stats.custom == {'bar': {'foo': 1}, 'baz': {'foo': 1}}

    # Test None host
    stats.update_custom_stats('foo', 1, None)
    assert stats.custom == {'bar': {'foo': 1}, 'baz': {'foo': 1}, '_run': {'foo': 1}}

    # Test with

# Generated at 2022-06-22 20:22:47.910228
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    # The first summarize should return 0 for all fields
    expected_result = {
        'ok': 0,
        'failures': 0,
        'unreachable': 0,
        'changed': 0,
        'skipped': 0,
        'rescued': 0,
        'ignored': 0,
    }
    assert expected_result == stats.summarize('some_host')

    # If a value is incremented, it should show up in the summary
    stats.increment('ok', 'some_host')
    assert 1 == stats.ok.get('some_host', 0)

# Generated at 2022-06-22 20:22:59.247154
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    import sys
    if sys.version_info[0] > 2:
        builtin_object = object
    else:
        builtin_object = __builtins__.object
    class TestAggregateStats(builtin_object):
        def __init__(self):
            self.custom= {}
        def set_custom_stats(self, which, what, host):
            # call the actual method (with no host!)
            AggregateStats.set_custom_stats(self, which, what)
        def update_custom_stats(self, which, what, host):
            # call the actual method (with no host!)
            AggregateStats.update_custom_stats(self, which, what)

    test = TestAggregateStats()

    # custom_stats with len()==0

# Generated at 2022-06-22 20:23:05.713072
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("ok", "host")
    stats.increment("failures", "host")

    assert stats.processed["host"] == 1
    assert stats.ok["host"] == 1
    assert stats.failures["host"] == 1
    assert stats.ok["host"] == stats.processed["host"] - stats.failures["host"]


# Generated at 2022-06-22 20:23:14.358640
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'www1')
    assert stats.ok['www1'] == 1
    stats.increment('ok', 'www1')
    assert stats.ok['www1'] == 2
    stats.increment('ok', 'www2')
    assert stats.ok['www2'] == 1
    stats.increment('failures', 'www2')
    assert stats.failures['www2'] == 1
    stats.increment('failures', 'www2')
    assert stats.failures['www2'] == 2


# Generated at 2022-06-22 20:23:23.609234
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    # decrementing an existing value for host
    stats.ok['test_host'] = 100
    stats.decrement('ok', 'test_host')
    assert stats.ok['test_host'] == 99
    # decrementing a non existing value for host
    stats.decrement('ok', 'test_host')
    assert stats.ok['test_host'] == 98
    # decrementing a non existing value for non existing host
    stats.decrement('ok', 'not_existing_host')
    assert stats.ok['not_existing_host'] == 0
    # decrementing a value less then 0 should result in a 0 value
    stats.decrement('ok', 'test_host')
    assert stats.ok['test_host'] == 0

# Generated at 2022-06-22 20:23:33.374903
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    host = 'host1'
    aggregate_stats.ok[host] = 1
    aggregate_stats.failures[host] = 1
    aggregate_stats.dark[host] = 1
    aggregate_stats.changed[host] = 1
    aggregate_stats.skipped[host] = 1
    aggregate_stats.rescued[host] = 1
    aggregate_stats.ignored[host] = 1

    summary = aggregate_stats.summarize(host)
    assert summary['ok'] == 1
    assert summary['failures'] == 1
    assert summary['unreachable'] == 1
    assert summary['changed'] == 1
    assert summary['skipped'] == 1
    assert summary['rescued'] == 1
    assert summary['ignored'] == 1

# Generated at 2022-06-22 20:23:35.518133
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg_stats = AggregateStats()
    agg_stats.increment('changed', 'localhost')
    assert agg_stats.changed == {'localhost': 1}

# Generated at 2022-06-22 20:23:41.842943
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    fail_counter = AggregateStats()
    fail_counter.increment('failures', 'localhost')
    fail_counter.increment('failures', 'localhost')
    fail_counter.decrement('failures', 'localhost')
    assert fail_counter.failures != {'localhost': 0}
    fail_counter.decrement('failures', 'localhost')
    assert fail_counter.failures == {'localhost': 0}



# Generated at 2022-06-22 20:23:48.052905
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats('key', 'value', 'hostName')
    assert aggregate_stats.custom == {'hostName': {'key': 'value'}}
    aggregate_stats.custom = {}
    aggregate_stats.set_custom_stats('key', 'value', 'hostName')
    assert aggregate_stats.custom == {'hostName': {'key': 'value'}}
    aggregate_stats.set_custom_stats('key2', 'value2', 'hostName')
    assert aggregate_stats.custom == {'hostName': {'key': 'value', 'key2': 'value2'}}

# testing _custom_stats

# Generated at 2022-06-22 20:23:51.804231
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom == {'_run': {'foo': 'bar'}}
    stats.update_custom_stats('foo', {'spam': 'eggs'})
    assert stats.custom == {'_run': {'foo': {'spam': 'eggs'}}}
    stats.update_custom_stats('foo', {'spam': 'bacon'})
    assert stats.custom == {'_run': {'foo': {'spam': 'bacon'}}}
    stats.update_custom_stats('foo', {'bacon': 'spam'})
    assert stats.custom == {'_run': {'foo': {'spam': 'bacon', 'bacon': 'spam'}}}

# Generated at 2022-06-22 20:23:57.415835
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext

    playbook = Playbook()
    play_context = PlayContext()
    play = playbook.get_play('test')
    stats = AggregateStats()
    stats.increment('failures', "localhost")
    stats.increment('failures', "localhost")
    stats.increment('ok', "localhost")
    stats.increment('ok', "localhost")
    stats.increment('ok', "localhost")
    stats.increment('ok', "localhost")
    stats.increment('changed', "localhost")
    stats.increment('ignored', "localhost")
    stats.increment('rescued', "localhost")
    stats.increment('dark', "localhost")
    stats.increment('skipped', "localhost")

# Generated at 2022-06-22 20:24:05.568842
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():

    stats = AggregateStats()

    stats.set_custom_stats('test_stat', 1)
    stats.set_custom_stats('test_stat2', 2, host='_run')
    stats.set_custom_stats('test_stat', 1, host='test_host')
    stats.set_custom_stats('test_stat2', 2, host='test_host2')

    assert stats.custom == {
        '_run': {
            'test_stat2': 2,
        },
        'test_host': {
            'test_stat': 1,
        },
        'test_host2': {
            'test_stat2': 2,
        },
    }



# Generated at 2022-06-22 20:24:17.491846
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()

    assert stats is not None, "object not created"

    assert stats.processed == {}, "processed dictionary not empty"
    assert stats.failures == {}, "failures dictionary not empty"
    assert stats.ok == {}, "ok dictionary not empty"
    assert stats.dark == {}, "dark dictionary not empty"
    assert stats.changed == {}, "changed dictionary not empty"
    assert stats.skipped == {}, "skipped dictionary not empty"
    assert stats.rescued == {}, "rescued dictionary not empty"
    assert stats.ignored == {}, "ignored dictionary not empty"
    assert stats.custom == {}, "custom dictionary not empty"

    stats.increment('ok', 'test')


# Generated at 2022-06-22 20:24:23.146638
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stat = AggregateStats()

    assert(stat.processed == {})
    assert(stat.failures == {})
    assert(stat.ok == {})
    assert(stat.dark == {})
    assert(stat.changed == {})
    assert(stat.skipped == {})
    assert(stat.rescued == {})
    assert(stat.ignored == {})
    assert(stat.custom == {})

    stat.increment('ok', '127.0.0.1')
    assert(stat.processed == {'127.0.0.1':1})
    assert(stat.ok == {'127.0.0.1':1})
    assert(stat.failures == {})
    assert(stat.dark == {})
    assert(stat.changed == {})

# Generated at 2022-06-22 20:24:34.222213
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stat = AggregateStats()
    stat.update_custom_stats('foo', 10)
    stat.update_custom_stats('foo', 12)
    assert isinstance(stat.custom['_run']['foo'], int)
    assert stat.custom['_run']['foo'] == 22
    stat.update_custom_stats('foo', {'new': 5})
    assert isinstance(stat.custom['_run']['foo'], dict)
    assert stat.custom['_run']['foo'] == {'new': 5, 'foo': 22}
    stat.update_custom_stats('foo', {'new': 5})
    assert isinstance(stat.custom['_run']['foo'], dict)
    assert stat.custom['_run']['foo'] == {'new': 10, 'foo': 22}

# Generated at 2022-06-22 20:24:38.310243
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg = AggregateStats()
    agg.increment('ok', 'localhost')
    assert agg.ok['localhost'] == 1
    agg.increment('ok', 'localhost')
    agg.increment('ok', 'localhost')
    assert agg.ok['localhost'] == 3


# Generated at 2022-06-22 20:24:44.218033
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    # create a stat to test
    stat = AggregateStats()
    host = 'testhost'

    # set a value
    stat.ok[host] = 2

    # decrement it
    stat.decrement('ok', host)

    # see if it was decremented
    assert(stat.ok[host] == 1)

    # decrement it to 0
    stat.decrement('ok', host)

    # see if it was decremented
    assert(stat.ok[host] == 0)

    # decrement it to -1
    stat.decrement('ok', host)

    # see if it was decremented
    assert(stat.ok[host] == 0)



# Generated at 2022-06-22 20:24:49.159430
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggr = AggregateStats()
    aggr.increment('skipped', 'test_host')
    assert aggr.skipped['test_host'] == 1
    aggr.decrement('skipped', 'test_host')
    assert aggr.skipped['test_host'] == 0

# Generated at 2022-06-22 20:24:51.687495
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():

    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats('Foo', 'Bar')
    assert aggregate_stats.custom['_run'] == {'Foo': 'Bar'}

# Generated at 2022-06-22 20:24:56.194981
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("ok", "test")
    assert stats.ok['test'] == 1
    stats.increment("ok", "test")
    assert stats.ok['test'] == 2
    stats.increment("dark", "test")
    assert stats.dark['test'] == 1


# Generated at 2022-06-22 20:25:03.633009
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregatestats = AggregateStats()
    aggregatestats.set_custom_stats('numbers', 3)
    assert aggregatestats.custom['_run']['numbers'] == 3

    aggregatestats.set_custom_stats('numbers', 2, '127.0.0.1')
    assert aggregatestats.custom['127.0.0.1']['numbers'] == 2
