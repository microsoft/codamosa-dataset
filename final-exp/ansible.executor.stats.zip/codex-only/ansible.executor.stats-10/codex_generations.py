

# Generated at 2022-06-22 20:15:03.378874
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ag = AggregateStats()
    ag.increment('dark', 'myhost')
    assert ag.dark['myhost'] == 1
    ag.increment('dark', 'myhost')
    assert ag.dark['myhost'] == 2


# Generated at 2022-06-22 20:15:10.054370
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test_host = 'host'
    fake_stats = AggregateStats()
    fake_stats.increment('ok', test_host) # Increment the ok stat for the test host
    fake_stats.decrement('ok', test_host) # Decrement the ok stat for the test host
    test_result = fake_stats.ok.get(test_host)
    assert test_result == 0 # Check that the ok stat for the test host is now 0


# Generated at 2022-06-22 20:15:17.400379
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate = AggregateStats()
    aggregate.set_custom_stats('changed', 10)
    assert aggregate.custom['_run'] == {'changed': 10}
    aggregate.set_custom_stats('changed', 10, 'host1')
    aggregate.set_custom_stats('changed', 10, 'host2')
    aggregate.set_custom_stats('changed', 10, 'host1')
    assert aggregate.custom['host1'] == {'changed': 10}
    assert aggregate.custom['host2'] == {'changed': 10}
    assert len(aggregate.custom) == 3


# Generated at 2022-06-22 20:15:28.613191
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    stats = AggregateStats()
    host = 'somehost'
    stats.update_custom_stats('some_key', 1, host)
    assert stats.custom[host]['some_key'] == 1, "integer type is not supported"

    stats.update_custom_stats('some_key', 'some value', host)
    assert stats.custom[host]['some_key'] == 'some value', "string type is not supported"

    stats.update_custom_stats('some_key', [1, 2, 3], host)
    assert stats.custom[host]['some_key'] == [1, 2, 3], "list type is not supported"

    stats.update_custom_stats('some_key', {'one': 1, 'two': 2}, host)

# Generated at 2022-06-22 20:15:35.906844
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    host = "127.0.0.1"
    count = 0
    for what in ['ok', 'changed', 'rescued', 'ignored', 'failures', 'dark', 'skipped']:
        stats.increment(what, host)
        count += 1
        assert stats.ok[host] == count
        assert stats.changed[host] == count
        assert stats.rescued[host] == count
        assert stats.ignored[host] == count
        assert stats.failures[host] == count
        assert stats.dark[host] == count
        assert stats.skipped[host] == count


# Generated at 2022-06-22 20:15:45.096720
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregateStats = AggregateStats()
    aggregateStats.set_custom_stats("name","customName")
    assert (aggregateStats.custom[u'_run'] == {u'name': u'customName'})
    aggregateStats.set_custom_stats("name","customName2")
    assert (aggregateStats.custom[u'_run'] == {u'name': u'customName2'})

    aggregateStats.set_custom_stats("name","customName3",'host1')
    assert (aggregateStats.custom[u'host1'] == {u'name': u'customName3'})
    aggregateStats.set_custom_stats("name","customName4",'host1')
    assert (aggregateStats.custom[u'host1'] == {u'name': u'customName4'})

# Unit test

# Generated at 2022-06-22 20:15:51.320165
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()

    # Check that all the instance variables are properly initilised.
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}

    # Check the methods
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    assert stats.ok == {'host1': 2, 'host2': 3}
    assert stats.summarize

# Generated at 2022-06-22 20:15:59.264884
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    a = AggregateStats()
    a.set_custom_stats('foo', 'bar')
    a.set_custom_stats('foo', 'bar', 'localhost')
    a.set_custom_stats('foo', 'baz', '127.0.0.1')

    assert a.custom['_run']['foo'] == 'bar'
    assert a.custom['localhost']['foo'] == 'bar'
    assert a.custom['127.0.0.1']['foo'] == 'baz'


# Generated at 2022-06-22 20:16:04.678200
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-22 20:16:09.606770
# Unit test for constructor of class AggregateStats
def test_AggregateStats():

    stats = AggregateStats()

    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}

# Generated at 2022-06-22 20:16:18.351478
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats("foo", 1, "node1")
    stats.set_custom_stats("foobar", 2, "node1")
    stats.set_custom_stats("foobar", 3)
    stats.set_custom_stats("bar", 3, "node2")

    assert stats.custom["node1"]["foo"] == 1
    assert stats.custom["node1"]["foobar"] == 2
    assert stats.custom["_run"]["foobar"] == 3
    assert stats.custom["node2"]["bar"] == 3


# Generated at 2022-06-22 20:16:28.660155
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    """Updating custom stats works properly"""
    # Create object
    stats = AggregateStats()
    # Create some custom stats
    stats.set_custom_stats('test_stat_1', 1, 'host1')
    stats.set_custom_stats('test_stat_2', 1, 'host1')
    # Update stats
    stats.update_custom_stats('test_stat_1', 1, 'host1')
    stats.update_custom_stats('test_stat_2', "Hello", 'host1')
    # Check that we have what we expect
    assert('host1' in stats.custom)
    assert('host1' in stats.custom)
    assert('test_stat_1' in stats.custom['host1'])
    assert('test_stat_2' in stats.custom['host1'])

# Generated at 2022-06-22 20:16:40.714217
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    stats = AggregateStats()

    # test int value
    stats.set_custom_stats("my_key_int", 1)
    stats.update_custom_stats("my_key_int", 1)
    assert stats.custom['_run']['my_key_int'] == 2

    # test string value by making it an int
    stats.set_custom_stats("my_key_str", "1")
    stats.update_custom_stats("my_key_str", 1)
    assert stats.custom['_run']['my_key_str'] == 2

    # test list value by adding another item to the list
    stats.set_custom_stats("my_key_list", [1])
    stats.update_custom_stats("my_key_list", [2])

# Generated at 2022-06-22 20:16:43.661278
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    import sys

    stats = AggregateStats()
    stats.set_custom_stats('xyz', sys.version_info[0])
    assert stats.custom['_run']['xyz'] == sys.version_info[0]

# Generated at 2022-06-22 20:16:49.816276
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    ag = AggregateStats()
    assert ag.processed == {}
    assert ag.failures == {}
    assert ag.ok == {}
    assert ag.dark == {}
    assert ag.changed == {}
    assert ag.skipped == {}
    assert ag.rescued == {}
    assert ag.ignored == {}
    assert ag.custom == {}


# Generated at 2022-06-22 20:16:51.798624
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment(what="ok", host="localhost")
    print(stats.ok["localhost"])


# Generated at 2022-06-22 20:17:03.332814
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    my_stats = AggregateStats()

    my_stats.increment('changed', '1.1.1.1')
    my_stats.increment('changed', '1.1.1.1')
    my_stats.increment('changed', '1.1.1.1')

    my_stats.decrement('changed', '1.1.1.1')
    my_stats.decrement('changed', '1.1.1.1')

    assert my_stats.changed == {'1.1.1.1': 1}

    try:
        my_stats.decrement('changed', '1.1.1.1')
        my_stats.decrement('changed', '1.1.1.1')
    except KeyError:
        assert False


# Generated at 2022-06-22 20:17:09.305974
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.processed == {}
    assert aggregate_stats.failures == {}
    assert aggregate_stats.ok == {}
    assert aggregate_stats.dark == {}
    assert aggregate_stats.changed == {}
    assert aggregate_stats.skipped == {}
    assert aggregate_stats.rescued == {}
    assert aggregate_stats.ignored == {}
    assert aggregate_stats.custom == {}


# Generated at 2022-06-22 20:17:19.800305
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Method update_custom_stats must support update of a custom stat.
    #
    # For example, if I have a custom stat, for example, "foo"
    # and I run 2 tasks, the 2nd one updates this stat, then the final
    # value should be the sum of values set by the 2 tasks.
    #
    # This test checks this.

    # Create a test subject.
    stats = AggregateStats()

    # Set the initial value of a custom stat.
    stats.set_custom_stats("foo", 3)

    # Simulate the first task that works on localhost.
    stats.set_custom_stats("foo", 1, "localhost")
    assert stats.custom["localhost"]["foo"] == 1

    # Simulate the second task that works on localhost.

# Generated at 2022-06-22 20:17:26.077201
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate = AggregateStats()
    aggregate.increment('ok', 'host')
    aggregate.increment('ok', 'host')
    aggregate.increment('ok', 'host')
    aggregate.increment('failures', 'host')
    aggregate.increment('failures', 'host')
    aggregate.increment('changed', 'host')
    aggregate.increment('skipped', 'host')
    aggregate.increment('skipped', 'host')
    aggregate.increment('skipped', 'host')
    aggregate.increment('skipped', 'host')
    aggregate.increment('rescued', 'host')
    aggregate.increment('ignored', 'host')
    aggregate.increment('ignored', 'host')
    ok, failures, changed, skipped, rescued, ignored = aggregate.summarize('host').values()
   

# Generated at 2022-06-22 20:17:36.737603
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()

    stats.increment("dark", "host1")
    stats.increment("dark", "host1")
    stats.increment("dark", "host2")
    stats.increment("ok", "host1")
    stats.increment("changed", "host2")

    stats.set_custom_stats("test_custom_stat", 1, "host1")
    stats.set_custom_stats("test_custom_stat", 2, "host2")
    stats.set_custom_stats("test_custom_stat", 3, "host3")

    assert stats.summarize("host1") == dict(
        ok=1,
        failures=0,
        unreachable=2,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0
    )



# Generated at 2022-06-22 20:17:39.446617
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg = AggregateStats()
    agg.increment('ok', 'localhost')

    assert agg.ok['localhost'] == 1
    assert agg.processed['localhost'] == 1


# Generated at 2022-06-22 20:17:47.843515
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    """Testing AggregateStats class constructor"""
    stats = AggregateStats()
    assert isinstance(stats, AggregateStats)
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}

# Unit tests for method increment of class AggregateStats

# Generated at 2022-06-22 20:17:54.109791
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()
    assert isinstance(aggregate_stats.processed, dict)
    assert isinstance(aggregate_stats.failures, dict)
    assert isinstance(aggregate_stats.ok, dict)
    assert isinstance(aggregate_stats.dark, dict)
    assert isinstance(aggregate_stats.changed, dict)
    assert isinstance(aggregate_stats.skipped, dict)
    assert isinstance(aggregate_stats.rescued, dict)
    assert isinstance(aggregate_stats.ignored, dict)
    assert isinstance(aggregate_stats.custom, dict)

# Generated at 2022-06-22 20:17:58.640249
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats("foo", "bar")
    stats.set_custom_stats("foo", "baz", "foohost")
    assert stats.custom == {"_run": {"foo": "bar"}, "foohost": {"foo": "baz"}}


# Generated at 2022-06-22 20:18:08.887473
# Unit test for constructor of class AggregateStats
def test_AggregateStats():

    # check initailization of AggregateStats
    aStats = AggregateStats()
    assert aStats is not None, "initailization of AggregateStats"

    # check class variables
    assert isinstance(aStats.processed, dict), "processed should be a dictionary"
    assert isinstance(aStats.failures, dict), "failures should be a dictionary"
    assert isinstance(aStats.ok, dict), "ok should be a dictionary"
    assert isinstance(aStats.dark, dict), "dark should be a dictionary"
    assert isinstance(aStats.changed, dict), "changed should be a dictionary"
    assert isinstance(aStats.skipped, dict), "skipped should be a dictionary"
    assert isinstance(aStats.rescued, dict), "rescued should be a dictionary"

# Generated at 2022-06-22 20:18:18.276837
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok','127.0.0.1')
    stats.increment('ok','127.0.0.1')
    stats.increment('ok','127.0.0.2')
    assert len(stats.processed) == 2
    assert stats.processed['127.0.0.1'] == 1
    assert stats.processed['127.0.0.2'] == 1
    assert len(stats.ok) == 2
    assert stats.ok['127.0.0.1'] == 2
    assert stats.ok['127.0.0.2'] == 1


# Generated at 2022-06-22 20:18:22.755603
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate = AggregateStats()
    assert isinstance(aggregate.processed, dict)
    assert isinstance(aggregate.failures, dict)
    assert isinstance(aggregate.ok, dict)
    assert isinstance(aggregate.dark, dict)
    assert isinstance(aggregate.changed, dict)
    assert isinstance(aggregate.skipped, dict)
    assert isinstance(aggregate.rescued, dict)
    assert isinstance(aggregate.ignored, dict)
    assert isinstance(aggregate.custom, dict)

# Generated at 2022-06-22 20:18:33.115690
# Unit test for constructor of class AggregateStats
def test_AggregateStats():

    stats = AggregateStats()

    stats.increment('ok', '127.0.0.1')
    stats.increment('changed', '127.0.0.1')
    stats.increment('failures', '127.0.0.1')

    stats.increment('ok', '127.0.0.2')
    stats.increment('failures', '127.0.0.2')
    stats.increment('dark', '127.0.0.2')

    assert stats.summarize('127.0.0.1') == dict(
        ok=1,
        failures=1,
        unreachable=0,
        changed=1,
        skipped=0,
        rescued=0,
        ignored=0,
    )


# Generated at 2022-06-22 20:18:35.248836
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 1


# Generated at 2022-06-22 20:18:46.130029
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('rds', {'present': 9, 'absent': 1})
    stats.update_custom_stats('rds', {})
    assert stats.custom == {'_run': {'rds': {'present': 9, 'absent': 1}}}
    stats.update_custom_stats('rds', {'present': 4, 'absent': 2})
    assert stats.custom == {'_run': {'rds': {'present': 13, 'absent': 3}}}
    stats.update_custom_stats('rds', {'present': 4, 'updated': 1})
    assert stats.custom == {'_run': {'rds': {'present': 17, 'updated': 1, 'absent': 3}}}

# Generated at 2022-06-22 20:18:51.169838
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("ok", "testHost")
    assert stats.processed["testHost"] == 1
    assert stats.ok["testHost"] == 1
    stats.increment("ok", "testHost")
    assert stats.ok["testHost"] == 2


# Generated at 2022-06-22 20:19:01.654328
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg = AggregateStats()
    agg.set_custom_stats("test_set_custom_stats", "test_set_custom_stats_data", "test_set_custom_stats_host")
    assert agg.custom["test_set_custom_stats_host"]["test_set_custom_stats"] == "test_set_custom_stats_data"
    agg.set_custom_stats("test_set_custom_stats2", 1, "test_set_custom_stats_host")
    assert agg.custom["test_set_custom_stats_host"]["test_set_custom_stats2"] == 1
    agg.set_custom_stats("test_set_custom_stats3", ["test_set_custom_stats_data3"], "test_set_custom_stats_host")

# Generated at 2022-06-22 20:19:06.270731
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    global_stats = AggregateStats()
    global_stats.increment("custom", "custom_value", "host1")
    global_stats.decrement("custom", "custom_value", "host1")
    assert global_stats.custom["host1"]["custom_value"] == 0
    global_stats.decrement("custom", "custom_value", "host1")
    assert global_stats.custom["host1"]["custom_value"] == 0



# Generated at 2022-06-22 20:19:12.350343
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    ansible_host = 'localhost'
    expected_summary = dict(
        ok=1,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0,
    )
    aggregate_stats_obj = AggregateStats()
    aggregate_stats_obj.increment('ok', ansible_host)
    assert aggregate_stats_obj.summarize(ansible_host) == expected_summary, 'AggregateStats.summarize method test failed'

# Generated at 2022-06-22 20:19:23.691620
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}
    stats.increment('ok', 'host1')
    assert stats.processed == {'host1': 1}
    assert stats.ok == {'host1': 1}
    stats.increment('ok', 'host2')
    assert stats.processed == {'host1': 1, 'host2': 1}
    assert stats.ok == {'host1': 1, 'host2': 1}
    stats.increment('ok', 'host2')

# Generated at 2022-06-22 20:19:29.959160
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggr = AggregateStats()
    result = aggr.summarize("host1")
    assert len(result) == 7
    assert result["ok"] == 0
    assert result["failures"] == 0
    assert result["unreachable"] == 0
    assert result["changed"] == 0
    assert result["skipped"] == 0
    assert result["rescued"] == 0
    assert result["ignored"] == 0
    assert aggr.processed["host1"] == 1



# Generated at 2022-06-22 20:19:41.748313
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():

    # test initialization
    agg_stats = AggregateStats()
    assert agg_stats.custom == {}

    # set some custom stats
    agg_stats.set_custom_stats('failure_reason', 'test')
    assert agg_stats.custom == {'_run': {'failure_reason': 'test'}}
    agg_stats.set_custom_stats('failure_reason', 'test2', 'example.com')
    assert agg_stats.custom == {'_run': {'failure_reason': 'test'}, 'example.com': {'failure_reason':'test2'}}

    # verify that custom stats are not overwritten, if they already exist
    agg_stats.set_custom_stats('failure_reason', 'test_overwritten', 'example.com')

# Generated at 2022-06-22 20:19:52.109758
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    class A(AggregateStats):
        pass
    a = A()
    a.increment('failures', 'host1')
    a.increment('ok', 'host2')
    a.increment('skipped', 'host2')
    a.increment('ignored', 'host2')
    a.increment('ok', 'host3')
    a.increment('skipped', 'host3')

    assert a.summarize('host1') == dict(failures=1, ok=0, unreachable=0, changed=0,
                                        skipped=0, rescued=0, ignored=0)
    assert a.summarize('host2') == dict(failures=0, ok=1, unreachable=0, changed=0,
                                        skipped=1, rescued=0, ignored=1)
    assert a

# Generated at 2022-06-22 20:20:00.772752
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggr_stats = AggregateStats()
    aggr_stats.failures['host1'] = 1
    aggr_stats.decrement('failures', 'host1')
    assert aggr_stats.failures == {'host1': 0}

    aggr_stats.failures['host2'] = 0
    aggr_stats.decrement('failures', 'host2')
    assert aggr_stats.failures == {'host1': 0, 'host2': 0}

    aggr_stats.failures['host3'] = 1
    aggr_stats.decrement('failures', 'host3')
    assert aggr_stats.failures == {'host1': 0, 'host2': 0, 'host3': 0}


# Generated at 2022-06-22 20:20:10.689827
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    plugin_aggregate = AggregateStats()
    plugin_aggregate.increment('ok', 'hostname')
    plugin_aggregate.increment('changed', 'hostname')
    plugin_aggregate.increment('dark', 'hostname')
    plugin_aggregate.increment('skipped', 'hostname')
    plugin_aggregate.increment('failures', 'hostname')
    plugin_aggregate.increment('ignored', 'hostname')

    assert plugin_aggregate.summarize('hostname') == {'ok': 1, 'failures': 1, 'unreachable': 1, 'changed': 1, 'skipped': 1, 'rescued': 0, 'ignored': 1}


# Generated at 2022-06-22 20:20:15.041259
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg_stats = AggregateStats()
    assert agg_stats.ok == {} and agg_stats.dark == {} and \
        agg_stats.changed == {} and agg_stats.skipped == {} and \
        agg_stats.rescued == {} and agg_stats.ignored == {} and \
        agg_stats.custom == {}


# Generated at 2022-06-22 20:20:18.610237
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    test_AggregateStats = AggregateStats()
    test_AggregateStats.set_custom_stats('test_stat', 1, 'test_host')
    assert test_AggregateStats.custom.get('test_host') == {'test_stat': 1}
    assert test_AggregateStats.custom.get('test_host_run') == None


# Generated at 2022-06-22 20:20:28.931683
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate = AggregateStats()
    aggregate.ok = {'127.0.0.1': 1, '192.168.56.102': 0}
    aggregate.failures = {'127.0.0.1': 0, '192.168.56.102': 1}
    aggregate.dark = {'127.0.0.1': 0, '192.168.56.102': 1}
    aggregate.changed = {'127.0.0.1': 1, '192.168.56.102': 1}
    aggregate.skipped = {'127.0.0.1': 0, '192.168.56.102': 3}
    aggregate.rescued = {'127.0.0.1': 1, '192.168.56.102': 2}

# Generated at 2022-06-22 20:20:39.277982
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    '''Exercise method decrement of class AggregateStats'''
    stats = AggregateStats()
    stats.decrement('failures', 'test_host')
    assert stats.failures['test_host'] == 0
    stats.increment('failures', 'test_host')
    assert stats.failures['test_host'] == 1
    stats.decrement('failures', 'test_host')
    assert stats.failures['test_host'] == 0
    assert stats.decrement('failures', 'test_host') is None
    assert stats.decrement('failures', 'test_host') is None
    assert stats.failures['test_host'] == 0

# Generated at 2022-06-22 20:20:47.453113
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats(which='test', what={'a': {'b': 1}})
    assert stats.custom['_run'] == {'test': {'a': {'b': 1}}}
    stats.update_custom_stats(which='test', what={'a': {'c': 1}})
    assert stats.custom['_run'] == {'test': {'a': {'b': 1, 'c': 1}}}
    stats.update_custom_stats(which='test', what={'a': {'b': 2}})
    assert stats.custom['_run'] == {'test': {'a': {'b': 2, 'c': 1}}}


# Generated at 2022-06-22 20:20:55.842429
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('changed', 'test')
    assert stats.changed['test'] == 1
    stats.increment('changed', 'test')
    assert stats.changed['test'] == 2

    # Test for change in dict statistics
    stats.increment('dark', 'test')
    assert stats.dark['test'] == 1
    stats.increment('dark', 'test')
    assert stats.dark['test'] == 2

    # Test if newly added host is also updated
    stats.increment('changed', 'test2')
    assert stats.changed['test2'] == 1



# Generated at 2022-06-22 20:21:06.999483
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('failures', 'host1')
    stats.increment('failures', 'host2')
    stats.increment('ok', 'host3')
    stats.increment('ok', 'host3')
    stats.increment('dark', 'host3')
    assert stats.summarize('host1') == {'ok': 0, 'failures': 1, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0}
    assert stats.summarize('host2') == {'ok': 0, 'failures': 1, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0}

# Generated at 2022-06-22 20:21:16.338191
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    stats.update_custom_stats('A', {'x': {'y': 1}}, 'host')
    assert stats.custom == {'_run': {}, 'host': {'A': {'x': {'y': 1}}}}

    stats.update_custom_stats('B', {'x': {'y': 2}}, 'host')
    assert stats.custom == {'_run': {}, 'host': {'A': {'x': {'y': 1}}, 'B': {'x': {'y': 2}}}}

    stats.update_custom_stats('A', {'x': {'y': 3}}, 'host')

# Generated at 2022-06-22 20:21:26.172836
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    ag = AggregateStats()
    ag.update_custom_stats('test_update_custom_stats', 1, 'host1')
    assert ag.custom['host1']['test_update_custom_stats'] == 1
    ag.update_custom_stats('test_update_custom_stats', 2, 'host1')
    assert ag.custom['host1']['test_update_custom_stats'] == 3
    ag.update_custom_stats('test_update_custom_stats2', 1, 'host1')
    assert ag.custom['host1']['test_update_custom_stats2'] == 1
    ag.update_custom_stats('test_update_custom_stats', {'test_update_custom_stats': 1}, 'host1')

# Generated at 2022-06-22 20:21:34.262120
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()

    # Store a mapping
    stats.set_custom_stats("foo", {"bar": 1})
    assert stats.custom["_run"]["foo"]["bar"] == 1

    # Store an integer
    stats.set_custom_stats("foo", 2)
    assert stats.custom["_run"]["foo"] == 2

    # Store a list
    stats.set_custom_stats("foo", [1,2,3])
    assert stats.custom["_run"]["foo"] == [1,2,3]

#Unit test for method update_custom_stats of class AggregateStats

# Generated at 2022-06-22 20:21:36.176183
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    ag = AggregateStats()
    assert type(ag) == AggregateStats


# Generated at 2022-06-22 20:21:44.930050
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    """ tests set_custom_stats method of class AggregateStats """

    test = AggregateStats()
    test.set_custom_stats('stuff', 2)
    assert test.custom['_run']['stuff'] == 2
    test.set_custom_stats('stuff', 3)
    assert test.custom['_run']['stuff'] == 3
    test.set_custom_stats('stuff', 4, '127.0.0.1')
    assert test.custom['127.0.0.1']['stuff'] == 4


# Generated at 2022-06-22 20:21:53.873887
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggr_stats = AggregateStats()
    assert aggr_stats.custom == {}

    # test normal use case
    aggr_stats.set_custom_stats('user_fact', 'my_value', 'my_host')
    aggr_stats.update_custom_stats('user_fact', 'new_value', 'sample_host')
    assert aggr_stats.custom == {'my_host': {'user_fact': 'my_value'}, 'sample_host': {'user_fact': 'new_value'}}
    aggr_stats.update_custom_stats('user_fact', 'new_value')

# Generated at 2022-06-22 20:22:02.762825
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    s = AggregateStats()
    s.increment("ok", "localhost")
    assert s.summarize("localhost") == {"ok": 1, "failures": 0, "unreachable": 0, "changed": 0, "skipped": 0, "rescued": 0, "ignored": 0}
    s.increment("changed", "localhost")
    assert s.summarize("localhost") == {"ok": 1, "failures": 0, "unreachable": 0, "changed": 1, "skipped": 0, "rescued": 0, "ignored": 0}
    s.increment("rescued", "localhost")

# Generated at 2022-06-22 20:22:09.240421
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    a = AggregateStats()
    a.increment('ignored', 'foo')
    a.increment('ignored', 'foo')
    a.increment('ignored', 'bar')
    a.increment('ok', 'foo')
    a.decrement('ok', 'foo')
    assert (a.ok['foo'] == 0)
    assert (a.ignored['foo'] == 2)


# Generated at 2022-06-22 20:22:20.360046
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('a', 1, 'host')
    assert stats.custom['host']['a'] == 1

    stats.update_custom_stats('b', 1, 'host')
    assert stats.custom['host']['b'] == 1

    stats.update_custom_stats('a', 2, 'host')
    assert stats.custom['host']['a'] == 3

    stats.update_custom_stats('a', {'c': 3}, 'host')
    assert stats.custom['host']['a'] == {'c': 3}

    stats.update_custom_stats('a', {'d': 4}, 'host')
    assert stats.custom['host']['a'] == {'c': 3, 'd': 4}

    stats.update_custom_stats

# Generated at 2022-06-22 20:22:22.608727
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stat = AggregateStats()
    assert isinstance(stat, AggregateStats)


# Generated at 2022-06-22 20:22:24.830968
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('failures', 'host1')
    assert ('host1' in stats.failures) == True


# Generated at 2022-06-22 20:22:33.797650
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    s = AggregateStats()
    s.update_custom_stats('foo', 0, 'bar')
    assert s.custom == {'_run': {'foo': 0}, 'bar': {'foo': 0}}

    s.update_custom_stats('foo', 1, 'bar')
    assert s.custom == {'_run': {'foo': 1}, 'bar': {'foo': 1}}

    s.update_custom_stats('foo', 1)
    assert s.custom == {'_run': {'foo': 2}, 'bar': {'foo': 1}}

    s.update_custom_stats('foo', 0)
    assert s.custom == {'_run': {'foo': 2}, 'bar': {'foo': 1}}

    s.set_custom_stats('foo', {'bar': 1})
    assert s

# Generated at 2022-06-22 20:22:40.151049
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('foo', 'bar', 'ansible.local')
    assert stats.custom['ansible.local']['foo'] == 'bar'
    stats.set_custom_stats('foo', 'baz', 'ansible.local')
    assert stats.custom['ansible.local']['foo'] == 'baz'
    stats.set_custom_stats('foo', 'baz')
    assert stats.custom['_run']['foo'] == 'baz'
    assert stats.custom['ansible.local']['foo'] == 'baz'


# Generated at 2022-06-22 20:22:42.987149
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg = AggregateStats()
    agg.increment('ok', 'test_host')
    assert agg.ok.get('test_host') == 1


# Generated at 2022-06-22 20:22:50.450751
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    process = AggregateStats()
    process.increment('ok', 'testhost')
    process.increment('ok', 'testhost')
    process.increment('ok', 'testhost')
    process.increment('failures', 'testhost')
    assert process.summarize('testhost') == {'ok': 3, 'failures': 1, 'changed': 0, 'unreachable': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}



# Generated at 2022-06-22 20:23:00.448892
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    # Tests with only failures

    agg = AggregateStats()
    agg.increment('failures', 'test1')
    agg.increment('failures', 'test2')
    agg.increment('failures', 'test2')
    agg.increment('ok', 'test1')
    agg.increment('ok', 'test1')
    agg.increment('ok', 'test1')
    agg.increment('ok', 'test2')

    expected = {'test1': {'failures': 1, 'ok': 3, 'changed': 0, 'unreachable': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}}
    assert agg.summarize('test1') == expected['test1']
    assert agg.summarize('test2') == expected['test1']



# Generated at 2022-06-22 20:23:12.652397
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats1 = AggregateStats()
    stats2 = AggregateStats() # for testing host = 'foo'
    stats3 = AggregateStats() # for testing host = '_run'

    # For this test, we will check the value of 'custom' variable.
    # This variable is updated in method set_custom_stats
    # The variable is a dictionary with host as the key and a dictionary
    # as the value. The value dictionary contains the custom statistics

    # For host = None, the key will be '_run'
    stats1.set_custom_stats('foo', 'bar')
    assert stats1.custom['_run']['foo'] == 'bar'

    stats2.set_custom_stats('foo', 'bar', 'foo')
    assert stats2.custom['foo']['foo'] == 'bar'

    stats3.set

# Generated at 2022-06-22 20:23:16.811829
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ags = AggregateStats()
    ags.increment("ok", "some_host")
    assert ags.ok
    ags.decrement("ok", "some_host")
    assert not ags.ok
    ags.decrement("ok", "some_host")
    assert not ags.ok

# Generated at 2022-06-22 20:23:23.088999
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Create an instance of AggregateStats
    aggrstats = AggregateStats()

    # Check that decrement of an unset value is 0
    aggrstats.decrement("ok", "bcd")
    assert aggrstats.ok["bcd"] == 0

    # Check what happens if you decrement below 0
    aggrstats.decrement("ok", "bcd")
    assert aggrstats.ok["bcd"] == 0


# Generated at 2022-06-22 20:23:33.223344
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'b')
    stats.increment('ok', 'b')
    assert stats.ok['b'] == 2
    assert stats.processed['b'] == 1
    assert stats.ok == {'b': 2}
    assert stats.processed == {'b': 1}
    stats.increment('failures', 'b')
    assert stats.ok['b'] == 2
    assert stats.processed['b'] == 1
    assert stats.failures['b'] == 1
    assert stats.ok == {'b': 2}
    assert stats.processed == {'b': 1}
    assert stats.failures == {'b': 1}
    stats.increment('ok', 'a')
    assert stats.ok['a'] == 1
    assert stats.process

# Generated at 2022-06-22 20:23:43.603216
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    assert stats.summarize('localhost') == dict(
        ok=0,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0)

    stats.increment('ok', 'localhost')
    assert stats.summarize('localhost') == dict(
        ok=1,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0)

    # Incrementing stats of an unknown host
    stats.increment('ok', 'example.com')

# Generated at 2022-06-22 20:23:48.842052
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    agg = AggregateStats()
    agg.update_custom_stats('lineinfile', {'changed':True}, 'local')
    assert agg.custom['local']['lineinfile'] == {'changed':True}
    agg.update_custom_stats('lineinfile', {'changed':True}, 'local')
    assert agg.custom['local']['lineinfile'] == {'changed':True}


# Generated at 2022-06-22 20:24:00.923617
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    import datetime
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.utils.vars import merge_hash

    aStats = AggregateStats()
    aStats.set_custom_stats('foo', 1)
    assert aStats.custom['_run'] == {'foo': 1}
    aStats.set_custom_stats('foo', 1, 'someHost')
    assert aStats.custom['_run'] == {'foo': 1}
    assert aStats.custom['someHost'] == {'foo': 1}
    aStats.custom['someHost'].update({'bar': 2})
    assert aStats.custom['someHost'] == {'foo': 1, 'bar': 2}
    aStats.set_custom_stats('foo', 3, 'someHost')
   

# Generated at 2022-06-22 20:24:10.113490
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment("skipped", "localhost")
    stats.increment("ok", "localhost")
    stats.increment("ok", "localhost")
    stats.increment("failures", "localhost")
    stats.increment("dark", "localhost")
    stats.increment("dark", "localhost")
    stats.increment("dark", "localhost")
    stats.increment("changed", "localhost")
    stats.increment("changed", "localhost")
    stats.increment("changed", "localhost")
    stats.increment("changed", "localhost")
    stats.increment("rescued", "localhost")
    stats.increment("ignored", "localhost")
    stats.increment("ignored", "localhost")

    result = stats.summarize("localhost")

    assert result == dict

# Generated at 2022-06-22 20:24:16.992821
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('some_key', 'some_value')
    stats.update_custom_stats('key_to_update', 'value_to_update')
    stats.update_custom_stats('key_to_update', {'innervalue': 'innervalue'})
    stats.set_custom_stats('host_key', 'host_value', 'host1')
    assert stats.custom['_run']['some_key'] == 'some_value'
    assert stats.custom['_run']['key_to_update'] == {'innervalue': 'innervalue'}
    assert stats.custom['host1']['host_key'] == 'host_value'

# Generated at 2022-06-22 20:24:23.198059
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggg = AggregateStats()
    which = 'stats'
    host = '_test'

    # ensure that it works with everything that can be added
    aggg.update_custom_stats(which, 1, host)
    assert aggg.custom[host][which] == 1
    aggg.update_custom_stats(which, 2, host)
    assert aggg.custom[host][which] == 3
    aggg.update_custom_stats(which, 'foo', host)
    assert aggg.custom[host][which] == 'foo2'
    aggg.update_custom_stats(which, [], host)
    assert aggg.custom[host][which] == [2]

    # ensure that no modification happens for mismatching types
    aggg.update_custom_stats(which, None, host)
    assert ag

# Generated at 2022-06-22 20:24:34.221034
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    assert stats.set_custom_stats('a', 'b') == None
    stats.set_custom_stats('a', 'b')
    assert stats.custom['_run']['a'] == 'b'
    stats.set_custom_stats('a', 'c')
    assert stats.custom['_run']['a'] == 'c'
    stats.set_custom_stats('a', 'b', 'k1')
    assert stats.custom['k1']['a'] == 'b'
    stats.set_custom_stats('a', 'c', 'k1')
    assert stats.custom['k1']['a'] == 'c'
    # unit test for merging
    stats.set_custom_stats('d', {'e': 'f'})

# Generated at 2022-06-22 20:24:39.910591
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    '''Test case for constructor of class AggregateStats.'''
    aggregate_stats = AggregateStats()

    assert aggregate_stats.processed == {}
    assert aggregate_stats.failures == {}
    assert aggregate_stats.ok == {}
    assert aggregate_stats.dark == {}
    assert aggregate_stats.changed == {}
    assert aggregate_stats.skipped == {}
    assert aggregate_stats.rescued == {}
    assert aggregate_stats.ignored == {}
    assert aggregate_stats.custom == {}

# Generated at 2022-06-22 20:24:51.597319
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    from ansible.module_utils.common._collections_compat import MutableMapping

    agg = AggregateStats()

    agg.increment('ignored', 'host0')
    agg.increment('ignored', 'host1')
    agg.increment('skipped', 'host1')
    agg.increment('skipped', 'host2')

    agg.decrement('ignored', 'host0')
    agg.decrement('skipped', 'host0')

    # Check an decrementing with no previous value doesn't change anything
    agg.decrement('skipped', 'host3')

    agg.ignored['host2'] = -1
    agg.decrement('ignored', 'host2')

    assert agg.ignored['host0'] == 0

# Generated at 2022-06-22 20:24:56.853232
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    a = AggregateStats()
    a.increment('failures', '127.0.0.1')
    a.increment('failures', '127.0.0.1')
    a.increment('ok', '127.0.0.1')
    assert a.failures['127.0.0.1'] == 2
    assert a.ok['127.0.0.1'] == 1


# Generated at 2022-06-22 20:25:01.107024
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('my_key', 'my_val')
    assert stats.custom['_run']['my_key'] == 'my_val'

