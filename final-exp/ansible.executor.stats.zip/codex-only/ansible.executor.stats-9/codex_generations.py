

# Generated at 2022-06-22 20:15:09.142914
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('a', {1: 2, 3: 4})
    assert stats.custom['_run']['a'] == {1: 2, 3: 4}
    stats.update_custom_stats('a', {3: 5})
    assert stats.custom['_run']['a'] == {1: 2, 3: 5}, "overwrite of key 3 failed"
    stats.update_custom_stats('a', {4: 5})
    assert stats.custom['_run']['a'] == {1: 2, 3: 5, 4: 5}, "addition of new key 4 failed"
    stats.update_custom_stats('a', 6)

# Generated at 2022-06-22 20:15:11.880176
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    as_instance = AggregateStats()
    as_instance.set_custom_stats("one", 1, "localhost")
    assert as_instance.custom["localhost"] == {"one": 1}


# Generated at 2022-06-22 20:15:16.246653
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    ''' testing AggregateStats:set_custom_stats method '''
    stats = AggregateStats()
    stats.set_custom_stats('omega', {'foo':'bar'})
    assert stats.custom['_run']['omega']['foo'] == 'bar'


# Generated at 2022-06-22 20:15:26.447059
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    import os, tempfile
    fd, tmp = tempfile.mkstemp()
    os.close(fd)
    o = AggregateStats()
    o.set_custom_stats("updated", 5)
    assert o.custom == {'_run': {'updated': 5}}
    o.set_custom_stats("updated", 5, host="localhost")
    assert o.custom == {'_run': {'updated': 5}, 'localhost': {'updated': 5}}
    o.set_custom_stats("updated", 5, host="localhost")
    assert o.custom == {'_run': {'updated': 5}, 'localhost': {'updated': 5}}



# Generated at 2022-06-22 20:15:30.288443
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.__dict__ == {
        'processed': {},
        'failures': {},
        'ok': {},
        'dark': {},
        'changed': {},
        'skipped': {},
        'rescued': {},
        'ignored': {},
        'custom': {}
    }



# Generated at 2022-06-22 20:15:42.052848
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    a = AggregateStats()
    a.increment('ok', 'localhost')
    a.increment('ok', 'localhost')
    a.increment('ok', 'localhost')
    a.increment('ok', 'localhost')
    a.increment('ok', 'localhost')
    assert a.ok['localhost'] == 5

    # decrement
    a.decrement('ok', 'localhost')
    assert a.ok['localhost'] == 4
    a.decrement('ok', 'localhost')
    assert a.ok['localhost'] == 3
    a.decrement('ok', 'localhost')
    assert a.ok['localhost'] == 2
    a.decrement('ok', 'localhost')
    assert a.ok['localhost'] == 1
    a.decrement('ok', 'localhost')

# Generated at 2022-06-22 20:15:47.253493
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'localhost')
    aggregate_stats.increment('ok', 'localhost')
    aggregate_stats.increment('ok', '127.0.0.1')
    assert aggregate_stats.ok['localhost'] == 2
    assert aggregate_stats.ok['127.0.0.1'] == 1

# Generated at 2022-06-22 20:15:55.498957
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('foo', 'bar')
    assert stats.custom == {'_run': {'foo': 'bar'}}
    stats.set_custom_stats('foo', 'bar')
    assert stats.custom == {'_run': {'foo': 'bar'}}
    stats.set_custom_stats('foo', 'baz', 'host1')
    assert stats.custom == {'_run': {'foo': 'bar'}, 'host1': {'foo': 'baz'}}


# Generated at 2022-06-22 20:16:04.394594
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    statistics = ['processed','failures','ok','dark','changed','skipped','rescued','ignored','custom']
    host = 'fake-host'
    # Initialization
    for stat in statistics:
        assert stats.get(stat).get(host,0) == 0

    for stat in statistics:
        stats.increment(stat,host)
        assert stats.get(stat).get(host,0) == 1

    stats.increment('custom',host)
    assert stats.get('custom').get(host,{}).get('_run',{}).get('custom',[]) == []


# Generated at 2022-06-22 20:16:15.947220
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    class TestClass:
        def test_sum_dict(self):
            """Test aggregating a dict by summing it"""
            stats = AggregateStats()
            agg1 = { "a": 1, "b": 2, "c": 3 }
            agg2 = { "a": 2, "b": 4, "c": 6 }
            exp = { "a": 3, "b": 6, "c": 9 }
            stats.update_custom_stats( "agg", agg1 )
            stats.update_custom_stats( "agg", agg2 )
            assert stats.custom['_run']['agg'] == exp

        def test_sum_list(self):
            """Test aggregating a list by summing it"""
            stats = AggregateStats()
            agg1 = [ 1, 2, 3 ]

# Generated at 2022-06-22 20:16:23.579891
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()
    assert(hasattr(aggregate_stats, 'processed'))
    assert(hasattr(aggregate_stats, 'failures'))
    assert(hasattr(aggregate_stats, 'ok'))
    assert(hasattr(aggregate_stats, 'dark'))
    assert(hasattr(aggregate_stats, 'changed'))
    assert(hasattr(aggregate_stats, 'skipped'))
    assert(hasattr(aggregate_stats, 'rescued'))
    assert(hasattr(aggregate_stats, 'ignored'))
    assert(hasattr(aggregate_stats, 'custom'))


# Generated at 2022-06-22 20:16:29.132583
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("failures", "cnode1")
    stats.increment("failures", "cnode2")
    assert stats.failures["cnode1"] == 1
    assert stats.failures["cnode2"] == 1
    assert stats.ok["cnode1"] == 0
    assert stats.ok["cnode2"] == 0


# Generated at 2022-06-22 20:16:34.289126
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.processed = {'1': 1, '2': 1}
    stats.ok = {'1': 1}
    assert stats.processed[1] == stats.processed[2]
    assert stats.ok[1] != stats.ok[2]

# Generated at 2022-06-22 20:16:41.703702
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    ag = AggregateStats()
    assert ag.summarize('host1')['ok'] == 0
    ag.increment('ok', 'host1')
    assert ag.summarize('host1')['ok'] == 1
    ag.increment('ok', 'host1')
    assert ag.summarize('host1')['ok'] == 2
    assert ag.summarize('host2')['ok'] == 0


if __name__ == '__main__':

    test_AggregateStats_summarize()

# Generated at 2022-06-22 20:16:45.940418
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg = AggregateStats()
    assert agg.processed == {}
    assert agg.failures == {}
    assert agg.ok == {}
    assert agg.dark == {}
    assert agg.changed == {}
    assert agg.skipped == {}
    assert agg.rescued == {}
    assert agg.ignored == {}
    assert agg.custom == {}


# Generated at 2022-06-22 20:16:51.599562
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    fake_aggregatestats = AggregateStats()
    fake_aggregatestats.ok = {'hostA': 1, 'hostB': 0}
    fake_aggregatestats.decrement('ok', 'hostA')

    assert(fake_aggregatestats.ok == {'hostA': 0, 'hostB': 0})

    fake_aggregatestats.decrement('ok', 'hostB')

    assert(fake_aggregatestats.ok == {'hostA': 0, 'hostB': 0})


# Generated at 2022-06-22 20:17:03.084779
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    from ansible.compat.tests import unittest
    from ansible.utils.vars import merge_hash

    class TestAggregateStatsSetCustomStats(unittest.TestCase):
        '''
        TestCase for AggregateStats.set_custom_stats method
        '''

        def test_set_custom_stats(self):
            stats = AggregateStats()
            stats.set_custom_stats('result', {'success': 4})

            expected_custom_stats = {'result': {'success': 4}}
            self.assertEqual(expected_custom_stats, stats.custom['_run'])

            stats.set_custom_stats('result', {'fail': 2}, host='hostname')
            expected_custom_stats = {'hostname': {'result': {'fail': 2}}}

            expected_custom_

# Generated at 2022-06-22 20:17:10.788913
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    import types
    _aggregate_stats = AggregateStats()
    try:
        _aggregate_stats.decrement('ok', 'localhost')
        assert _aggregate_stats.ok['localhost'] == 0
    except Exception:
        assert False, "decrement when key not found should set value to 0"
    _aggregate_stats.ok['localhost'] = 1
    _aggregate_stats.decrement('ok', 'localhost')
    assert _aggregate_stats.ok['localhost'] == 0
    try:
        _aggregate_stats.ok['localhost'] = -1
        _aggregate_stats.decrement('ok', 'localhost')
        assert False, "decrement should not allow negative values"
    except Exception:
        pass


# Generated at 2022-06-22 20:17:14.697826
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate = AggregateStats()
    aggregate.increment('ok', 'test_host')
    assert aggregate.processed['test_host'] == 1
    assert aggregate.ok['test_host'] == 1
    aggregate.increment('ok', 'test_host')
    assert aggregate.ok['test_host'] == 2


# Generated at 2022-06-22 20:17:23.180391
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    def test(should_fail):
        stats = AggregateStats()
        stats.increment("ignored", "host1")
        assert stats.ignored["host1"] == 1

        if should_fail:
            try:
                stats.decrement("ignored", "host2")
            except:
                return
            assert False, "Must throw"
        else:
            stats.decrement("ignored", "host2")
            assert stats.ignored["host2"] == 0

    test(should_fail=False)
    test(should_fail=True)

# Generated at 2022-06-22 20:17:34.765458
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    # TODO: this unit test needs some work
    # the first assertion seems to be the 'old' value of
    # the value prior to decrementing by 1
    # the second assertion seems to be the correct value after
    # decrement

    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('failures', 'host1')
    stats.increment('changed', 'host1')

    stats.increment('ok', 'host2')
    stats.increment('failures', 'host2')
    stats.increment('changed', 'host2')

    assert stats.ok['host1'] == 2
    assert stats.failures['host1'] == 2
    assert stats.changed['host1'] == 2

    assert stats.ok['host2'] == 2
    assert stats.fail

# Generated at 2022-06-22 20:17:42.199936
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()
    assert isinstance(aggregate_stats.processed, dict)
    assert isinstance(aggregate_stats.failures, dict)
    assert isinstance(aggregate_stats.ok, dict)
    assert isinstance(aggregate_stats.dark, dict)
    assert isinstance(aggregate_stats.changed, dict)
    assert isinstance(aggregate_stats.skipped, dict)
    assert isinstance(aggregate_stats.rescued, dict)
    assert isinstance(aggregate_stats.ignored, dict)
    assert isinstance(aggregate_stats.custom, dict)


# Generated at 2022-06-22 20:17:47.681001
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():

    class FakeHost(object):
        def get_name(self):
            return 'foobar'

    stats = AggregateStats()
    stats.increment('dark', FakeHost())
    assert stats.dark['foobar'] == 1

    stats.increment('ok', FakeHost())
    assert stats.ok['foobar'] == 1


# Generated at 2022-06-22 20:17:54.705461
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()

    stats.ok["host1"] = 2
    stats.failures["host2"] = 3
    summary = stats.summarize("host1")
    assert summary == {u'ok': 2, u'changed': 0, u'failures': 0, u'ignored': 0, u'unreachable': 0, u'skipped': 0, u'rescued': 0}

    summary = stats.summarize("host2")
    assert summary == {u'ok': 0, u'changed': 0, u'failures': 3, u'ignored': 0, u'unreachable': 0, u'skipped': 0, u'rescued': 0}



# Generated at 2022-06-22 20:17:57.473151
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'filter_host')
    assert stats.ok['filter_host'] == 1


# Generated at 2022-06-22 20:18:04.550253
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregatestats = AggregateStats()
    assert aggregatestats.processed == {}
    assert aggregatestats.failures == {}
    assert aggregatestats.ok == {}
    assert aggregatestats.dark == {}
    assert aggregatestats.changed == {}
    assert aggregatestats.skipped == {}
    assert aggregatestats.rescued == {}
    assert aggregatestats.ignored == {}
    assert aggregatestats.custom == {}

test_AggregateStats()

# Generated at 2022-06-22 20:18:09.174232
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    ans = AggregateStats()
    assert ans.processed == {}
    assert ans.failures == {}
    assert ans.ok == {}
    assert ans.dark == {}
    assert ans.changed == {}
    assert ans.skipped == {}
    assert ans.rescued == {}
    assert ans.ignored == {}
    assert ans.custom == {}


# Generated at 2022-06-22 20:18:09.755196
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    assert True

# Generated at 2022-06-22 20:18:20.499808
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    aggregate_stats = AggregateStats()
    aggregate_stats.ok = {'127.0.0.1': 1}
    aggregate_stats.decrement('ok', '127.0.0.1')
    assert aggregate_stats.ok['127.0.0.1'] == 0
    aggregate_stats.decrement('ok', '127.0.0.1')
    assert aggregate_stats.ok['127.0.0.1'] == 0

    aggregate_stats.ignored = {'127.0.0.2': 2}
    aggregate_stats.decrement('ignored', '127.0.0.2')
    assert aggregate_stats.ignored['127.0.0.2'] == 1


# Generated at 2022-06-22 20:18:25.161527
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment("ok", "host")
    stats.decrement("ok", "host")
    assert stats.ok["host"] == 0
    stats.decrement("ok", "host")
    assert stats.ok["host"] == 0

# Generated at 2022-06-22 20:18:30.371055
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    # We'll use two different hosts
    host1 = 'www.example1.com'
    host2 = 'www.example2.com'

    # Create AggregateStats instance
    stats = AggregateStats()

    # Set custom stats
    stats.set_custom_stats('key1', 'value1', host1)
    stats.set_custom_stats('key2', 2, host2)

    # Check
    assert stats.custom[host1] == {'key1': 'value1'}
    assert stats.custom[host2] == {'key2': 2}



# Generated at 2022-06-22 20:18:39.797571
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    stats = AggregateStats()

    stats.update_custom_stats('foo', 1)
    assert stats.custom['_run']['foo'] == 1
    stats.update_custom_stats('foo', 2)
    assert stats.custom['_run']['foo'] == 3

    stats.update_custom_stats('foo', 1, 'local')
    assert stats.custom['local']['foo'] == 1
    stats.update_custom_stats('foo', 2, 'local')
    assert stats.custom['local']['foo'] == 3

    stats.update_custom_stats('bar', {'a': 1, 'b': 2, 'c': 3})
    assert stats.custom['_run']['bar'] == {'a': 1, 'b': 2, 'c': 3}
    stats.update_custom_stats

# Generated at 2022-06-22 20:18:49.570914
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import io
    import sys

    class Bunch:
        pass

    bunch = Bunch()
    bunch.changed = True
    bunch.skipped = False

    class Capturing(list):
        def __enter__(self):
            self._stdout = sys.stdout
            sys.stdout = self._stringio = io.StringIO()
            return self
        def __exit__(self, *args):
            self.extend(self._stringio.getvalue().splitlines())
            sys.stdout = self._stdout

    # TODO: Implement a better test
    with Capturing() as output:
        as_ = AggregateStats()
        as_.set_custom_stats('bunch', bunch)
        as_.update_custom_stats('bunch', bunch)
        print(repr(as_))

    return

# Generated at 2022-06-22 20:18:52.298464
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('failures', 'host2')

# Generated at 2022-06-22 20:18:52.924592
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    assert AggregateStats()

# Generated at 2022-06-22 20:19:03.104056
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    from ansible.playbook.task import Task
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.callback.default import CallbackModule

    MockTask = Task()

    class TestAggregateStats(unittest.TestCase):

        def setUp(self):
            self.task_name = "Mock task name"
            self.task_name2 = "Mock task2 name"

            self.return_data = dict(
                msg="Mock return message",
                changed=False,
            )


# Generated at 2022-06-22 20:19:08.142512
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('failures', 'exampleHost')
    assert stats.failures == {'exampleHost': 1},\
        "Test case for method increment failed"

# Generated at 2022-06-22 20:19:09.618860
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggr_stats = AggregateStats()
    # test the default value
    assert aggr_stats.processed == {}

# Generated at 2022-06-22 20:19:18.278402
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import sys
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_native

    # keep track of original stderr for later restoring
    stderr = sys.stderr

    # PY2 does not have unittest.mock.patch, so we use the older mock library.
    # PY3 will not install mock, so we use unittest.mock.patch.
    if PY3:
        from unittest.mock import patch
    else:
        from mock import patch

    # set up our own warning filter so we can test stderr output
    def filterwarnings(message, category, *args, **kwargs):
        if str(category).startswith('UserWarning'):
            return True
        return False

    # keep track of original

# Generated at 2022-06-22 20:19:30.228306
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY3

    class Test:
        def __init__(self, **kw):
            self.__dict__.update(kw)

    stats = AggregateStats()

    # test initial
    stats.update_custom_stats('test', 'initial')
    assert stats.custom['_run']['test'] == 'initial'

    # test None
    stats.update_custom_stats('test', None)
    assert stats.custom['_run']['test'] is None

    # test int
    stats.update_custom_stats('test', 1)
    assert stats.custom['_run']['test'] == 1

    # test float
    stats.update_custom_stats('test', 1.0)
    assert stats

# Generated at 2022-06-22 20:19:36.375388
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate = AggregateStats()
    aggregate.increment("ok", "localhost")
    assert aggregate.ok["localhost"] == 1
    assert aggregate.processed["localhost"] == 1
    aggregate.increment("ok", "localhost")
    assert aggregate.ok["localhost"] == 2
    assert aggregate.processed["localhost"] == 2


# Generated at 2022-06-22 20:19:42.191339
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    a = AggregateStats()
    a.set_custom_stats('foo', 'bar')
    assert a.custom == {'_run': {'foo': 'bar'}}
    a.set_custom_stats('foo', 'baz', host='test_host')
    assert a.custom == {'_run': {'foo': 'bar'}, 'test_host': {'foo': 'baz'}}


# Generated at 2022-06-22 20:19:53.153350
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    '''
    Event summary information for each host should include:
    ok: The number of successful events
    changed: The number of changed events
    unreachable: The number of unreachable events
    failures: The number of failed events
    skipped: The number of skipped events
    rescued: The number of rescued events
    ignored: The number of ignored events
    '''
    host = "faux-host"
    result = AggregateStats()
    result.increment("ok", host)
    result.increment("ok", host)
    result.increment("ok", host)
    result.increment("failures", host)
    result.increment("failures", host)
    result.increment("dark", host)
    result.increment("changed", host)
    result.increment("changed", host)

# Generated at 2022-06-22 20:19:59.525680
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    test_obj = AggregateStats()
    assert isinstance(test_obj, AggregateStats)
    assert test_obj.processed == {}
    assert test_obj.failures == {}
    assert test_obj.ok == {}
    assert test_obj.dark == {}
    assert test_obj.changed == {}
    assert test_obj.skipped == {}
    assert test_obj.rescued == {}
    assert test_obj.ignored == {}
    assert test_obj.custom == {}


# Generated at 2022-06-22 20:20:10.523979
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregateStats = AggregateStats()
    aggregateStats.increment("rescued", "myHost")
    aggregateStats.increment("ok", "myHost")
    aggregateStats.increment("ok", "myHost")
    aggregateStats.increment("changed", "myHost")
    aggregateStats.increment("ignored", "yourHost")
    assert aggregateStats.ok == {"myHost" : 2}
    assert aggregateStats.ignored == {"yourHost" : 1}
    assert aggregateStats.rescued == {"myHost" : 1}
    assert aggregateStats.ignored == {"yourHost" : 1}
    assert aggregateStats.skipped == {}
    assert aggregateStats.processed == {"myHost" : 1, "yourHost" : 1}
    assert aggregateStats.changed == {"myHost" : 1}


# Generated at 2022-06-22 20:20:18.805461
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    # test_hosts macros 
    test_hosts = [
        'host1',
        'host2',
        'host3',
        'host4',
        'host5',
    ]

    # Creating an AggregateStats object
    agg_stats = AggregateStats()

    # verifying test_hosts are not present in aggregate stats
    for host in test_hosts:
        assert host not in agg_stats.ok
        assert host not in agg_stats.failures
        assert host not in agg_stats.dark
        assert host not in agg_stats.changed
        assert host not in agg_stats.skipped
        assert host not in agg_stats.rescued
        assert host not in agg_stats.ignored

    # Adding some results

# Generated at 2022-06-22 20:20:28.779562
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', '192.168.0.1')
    stats.increment('ok', '192.168.0.1')
    stats.increment('changed', '192.168.0.1')
    assert stats.summarize('192.168.0.1') == {'ok': 2, 'failures': 0, 'unreachable': 0, 'changed': 1, 'skipped': 0, 'rescued': 0, 'ignored': 0}
    assert stats.summarize('192.168.0.2') == {'ok': 0, 'failures': 0, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}

# Generated at 2022-06-22 20:20:41.014910
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.custom == {}
    # set stats per host
    aggregate_stats.set_custom_stats("test", "value", "test_host")
    assert aggregate_stats.custom == {"test_host": {"test": "value"}}
    aggregate_stats.set_custom_stats("test", "value", "test_host")
    assert aggregate_stats.custom == {"test_host": {"test": "value"}}
    aggregate_stats.set_custom_stats("test", "value")
    assert aggregate_stats.custom == {"test_host": {"test": "value"}, "_run": {"test": "value"}}
    # set stats globally
    aggregate_stats.set_custom_stats("test", "value")

# Generated at 2022-06-22 20:20:45.912477
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate = AggregateStats()
    aggregate.decrement('ok', 'host')
    assert aggregate.ok.get('host', 0) == 0
    aggregate.ok = {'host': 1}
    aggregate.decrement('ok', 'host')
    assert aggregate.ok.get('host', 0) == 0
    aggregate.ok = {'some_other_host': 1}
    aggregate.decrement('ok', 'host')
    assert aggregate.ok.get('host', 0) == 0

# Generated at 2022-06-22 20:20:53.320951
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    stats.decrement('ignored', 'localhost')
    assert stats.processed['localhost'] == 1
    assert stats.ignored['localhost'] == 0

    stats.increment('ignored', 'localhost')
    assert stats.processed['localhost'] == 1
    assert stats.ignored['localhost'] == 1

    stats.decrement('ignored', 'localhost')
    assert stats.processed['localhost'] == 1
    assert stats.ignored['localhost'] == 0


# Generated at 2022-06-22 20:20:59.224070
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    agg_stats = AggregateStats()
    agg_stats.update_custom_stats('test', 'value', 'test_host')
    agg_stats.update_custom_stats('test', 'value2', 'test_host')
    assert len(agg_stats.custom) == 1
    assert len(agg_stats.custom['test_host']) == 1
    assert agg_stats.custom['test_host']['test'] == 'value2'

# Generated at 2022-06-22 20:21:06.517052
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("ok", "hostname")
    assert stats.ok["hostname"] == 1
    assert stats.processed["hostname"] == 1
    assert stats.failures.get("hostname", 0) == 0
    assert stats.dark.get("hostname", 0) == 0
    assert stats.changed.get("hostname", 0) == 0
    assert stats.skipped.get("hostname", 0) == 0
    assert stats.rescued.get("hostname", 0) == 0
    assert stats.ignored.get("hostname", 0) == 0

# Generated at 2022-06-22 20:21:08.768452
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 1

# Generated at 2022-06-22 20:21:12.885684
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment("ok", "host")
    assert stats.summarize("host") == {"ok":1, "failures":0, "unreachable":0, "changed":0, "skipped":0, "rescued":0, "ignored":0}


# Generated at 2022-06-22 20:21:21.482029
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('dark', 'foo')
    stats.increment('changed', 'foo')
    stats.increment('changed', 'foo')
    assert stats.summarize('foo') == {
        'ok': 0,
        'failures': 0,
        'unreachable': 1,
        'changed': 2,
        'skipped': 0,
        'rescued': 0,
        'ignored': 0,
    }

# Generated at 2022-06-22 20:21:25.189898
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    tstats = AggregateStats()
    tstats.increment('ok', 'localhost')
    assert tstats.ok['localhost'] == 1
    tstats.decrement('ok', 'localhost')
    assert tstats.ok['localhost'] == 0

# Generated at 2022-06-22 20:21:35.597242
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('x', {'a': 1, 'b': 2, 'c': 3}, 'localhost')
    stats.update_custom_stats('x', {'a': 4, 'b': 5, 'c': 6}, 'localhost')
    assert stats.custom['localhost']['x']['a'] == 5
    assert stats.custom['localhost']['x']['b'] == 7
    assert stats.custom['localhost']['x']['c'] == 9
    stats.set_custom_stats('y', [1, 2, 3], 'localhost')
    stats.update_custom_stats('y', [4, 5, 6], 'localhost')
    assert stats.custom['localhost']['y'] == [1, 2, 3, 4, 5, 6]
   

# Generated at 2022-06-22 20:21:39.797638
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    expected_result = {'localhost': 3}
    assert stats.ok == expected_result



# Generated at 2022-06-22 20:21:45.876033
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-22 20:21:52.449307
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('test1', 1)
    assert stats.custom['_run']['test1'] == 1
    stats.set_custom_stats('test2', 2, 'test-host')
    assert stats.custom['test-host']['test2'] == 2
    stats.set_custom_stats('test3', 'test-host', 'test-host')
    assert stats.custom['test-host']['test3'] == 'test-host'


# Generated at 2022-06-22 20:22:00.883465
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    import random
    import string

    oStats = AggregateStats()

    # Test: host is None
    _what = random.randint(0, 10)
    oStats.set_custom_stats('myvalue', _what)
    assert _what == oStats.custom['_run']['myvalue']

    _host = ''.join(random.choice(string.ascii_uppercase + string.digits) for x in range(10))
    _what = random.randint(0, 10)
    oStats.set_custom_stats('myvalue', _what, _host)
    assert _what == oStats.custom[_host]['myvalue']


# Generated at 2022-06-22 20:22:04.736634
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('failures', 'host1')
    stats.increment('failures', 'host1')
    assert stats.failures['host1'] == 2
    assert stats.processed['host1'] == 1



# Generated at 2022-06-22 20:22:14.696696
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok = {'ts-01': 1, 'ts-02': 4}
    stats.failures = {'ts-01': 3, 'ts-02': 2}
    stats.dark = {'ts-01': 5}
    stats.changed = {'ts-01': 7, 'ts-02': 6}
    stats.skipped = {'ts-02': 8}
    stats.rescued = {'ts-01': 9}
    stats.ignored = {'ts-01': 10, 'ts-02': 11}


# Generated at 2022-06-22 20:22:25.217849
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    '''
    This is a unit test for the AggregateStats.summarize() method.
    :return:
    '''
    test = AggregateStats()
    test.processed = {'host01': 1, 'host02': 1}
    test.failures = {'host01': 2, 'host02': 1}
    test.ok = {'host01': 1, 'host02': 1}
    test.dark = {'host012': 1, 'host00': 1}
    test.changed = {'host01': 1, 'host02': 0}
    test.skipped = {'host00': 1, 'host01': 0}
    test.rescued = {'host00': 0, 'host01': 1}
    test.ignored = {'host00': 1, 'host01': 1}

   

# Generated at 2022-06-22 20:22:31.608544
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    a = AggregateStats()
    a.increment('ok', "127.0.0.1")
    assert a.processed["127.0.0.1"] == 1
    assert a.ok["127.0.0.1"] == 1
    # Make sure only ok was incremented and not the other counters
    assert a.dark == {}
    assert a.changed == {}
    assert a.skipped == {}
    assert a.rescued == {}
    assert a.ignored == {}



# Generated at 2022-06-22 20:22:37.307206
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    # check if variables are initialized correctly
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}

# Generated at 2022-06-22 20:22:47.910999
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # New object of class AggregateStats
    agg = AggregateStats()

    # Simple test int -> int
    assert agg.update_custom_stats('var1', 1, 'localhost') == None
    assert agg.custom['localhost']['var1'] == 1

    # Test + int -> int
    agg.update_custom_stats('var1', 1, 'localhost')
    assert agg.custom['localhost']['var1'] == 2

    # Test + float -> float
    agg.update_custom_stats('var1', 1.2, 'localhost')
    assert agg.custom['localhost']['var1'] == 3.2

    # Test Merge dict
    test_dict = {'a': 1, 'b': {'c': 1, 'd': 2}}

# Generated at 2022-06-22 20:22:59.246502
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    aggregate_stats.processed = {'host1' : 1, 'host2' : 1}
    aggregate_stats.failures = {'host1' : 1}
    aggregate_stats.ok = {'host2' : 1}
    aggregate_stats.dark = {'host1' : 1}
    aggregate_stats.changed = {'host1' : 1}
    aggregate_stats.skipped = {'host2' : 1}
    aggregate_stats.rescued = {'host1' : 1}
    aggregate_stats.ignored = {'host2' : 1}

# Generated at 2022-06-22 20:23:05.450927
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    stats.update_custom_stats('key', 1)
    assert stats.custom['_run']['key'] == 1

    stats.update_custom_stats('key', 1, 'host1')
    assert stats.custom['host1']['key'] == 1

    stats.update_custom_stats('key', 2)
    assert stats.custom['_run']['key'] == 3

    stats.update_custom_stats('key', 2, 'host2')
    assert stats.custom['host2']['key'] == 2

    stats.update_custom_stats('key', 3, 'host2')
    assert stats.custom['host2']['key'] == 5

    stats.update_custom_stats('key', dict(a=1, b=2))

# Generated at 2022-06-22 20:23:09.649031
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement("ok", "test_host")
    assert stats.processed.get("test_host", 0) == 0
    assert stats.ok.get("test_host", 0) == 0

# Generated at 2022-06-22 20:23:14.358591
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}

# Generated at 2022-06-22 20:23:23.581479
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')

    assert stats.ok['host1'] == 1
    assert stats.ok['host2'] == 1

    stats.decrement('ok', 'host1')

    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1

    # check boundary conditions
    stats.decrement('ok', 'host1')  # should do nothing
    stats.decrement('ok', 'host1')  # should do nothing
    assert stats.ok['host1'] == 0
    assert stats.ok['host2'] == 1

    # Increment again to check if decrement works from 2 to 0
    stats.increment('ok', 'host1')

# Generated at 2022-06-22 20:23:33.629301
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    # decrement with default value
    stats.decrement('ok', 'host1.example.com')
    assert stats.ok['host1.example.com'] == 0

    # decrement from 1
    stats.increment('ok', 'host1.example.com')
    stats.decrement('ok', 'host1.example.com')
    assert stats.ok['host1.example.com'] == 0

    # decrement from 0 (should not get < 0)
    stats.decrement('ok', 'host1.example.com')
    assert stats.ok['host1.example.com'] == 0

    # decrement from >1
    stats.increment('ok', 'host1.example.com')
    stats.increment('ok', 'host1.example.com')
   

# Generated at 2022-06-22 20:23:39.899203
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    '''Unit test for class AggregateStats'''
    aggregate_stats = AggregateStats()
    assert aggregate_stats.custom == {}
    assert aggregate_stats.dark == {}
    assert aggregate_stats.processed == {}
    assert aggregate_stats.skipped == {}
    assert aggregate_stats.failures == {}
    assert aggregate_stats.ok == {}
    assert aggregate_stats.changed == {}


# Generated at 2022-06-22 20:23:47.177300
# Unit test for method update_custom_stats of class AggregateStats

# Generated at 2022-06-22 20:23:58.159883
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.skipped.update({'test_host':2})
    stats.decrement('skipped', 'test_host')
    assert stats.skipped.get('test_host') == 1,\
           'AggregateStats decrement of 2 - 1 should be 1'
    stats.decrement('skipped', 'test_host')
    assert stats.skipped.get('test_host') == 0,\
           'AggregateStats decrement of 1 - 1 should be 0'
    stats.decrement('skipped', 'test_host')
    assert stats.skipped.get('test_host') == 0,\
           'AggregateStats decrement of 0 - 1 should be 0'

# Generated at 2022-06-22 20:24:05.598277
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    from ansible.utils.vars import combine_vars
    stats =AggregateStats()
    stats.set_custom_stats('foo', 'bar')
    stats.set_custom_stats('hostvars', {'test':'host'})
    stats.set_custom_stats('hostvars', {'test2':'host'})
    assert stats.custom['_run']['foo'] == 'bar'
    assert combine_vars(a=stats.custom['_run']['hostvars'], b=stats.custom['_run']['hostvars']) == {'test': 'host', 'test2': 'host'}

# Generated at 2022-06-22 20:24:17.153107
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    # No stats for host test_host
    stats.increment("ok", "test_host")
    stats.increment("ok", "test_host")
    # One dark, one failure
    stats.increment("dark", "test_host2")
    stats.increment("failures", "test_host2")
    # Test with empty host
    stats.increment("failures", "")
    expected_result = dict(
        ok=2,
        failures=1,
        unreachable=1,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0,
    )
    result = stats.summarize("test_host2")
    assert result == expected_result

# Generated at 2022-06-22 20:24:22.325686
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():

    test_agg_stats = AggregateStats()

    test_agg_stats.increment("failures", "host1")
    test_agg_stats.increment("ok", "host1")
    test_agg_stats.increment("failures", "host1")
    test_agg_stats.increment("failures", "host2")

    assert test_agg_stats.failures.get("host1", None) == 2
    assert test_agg_stats.ok.get("host1", None) == 1
    assert test_agg_stats.failures.get("host2", None) == 1
    assert test_agg_stats.ok.get("host2", None) == 0



# Generated at 2022-06-22 20:24:33.458449
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('dark', 'localhost')
    stats.increment('changed', 'localhost')
    stats.increment('skipped', 'localhost')
    stats.increment('rescued', 'localhost')
    stats.increment('ignored', 'localhost')
    stats.increment('ok', 'remotehost')
    stats.increment('failures', 'remotehost')
    stats.increment('ok', 'remotehost')
    stats.increment('dark', 'remotehost')
    stats.increment('changed', 'remotehost')
    stats.increment('skipped', 'remotehost')

# Generated at 2022-06-22 20:24:42.320396
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    s = AggregateStats()
    s.increment('ok', 'foo')
    s.increment('ok', 'bar')
    s.increment('ok', 'bar')
    s.increment('failures', 'bar')
    s.increment('ok', 'baz')

    assert s.processed == {'foo': 1, 'bar': 1, 'baz': 1}
    assert s.ok == {'foo': 1, 'bar': 2, 'baz': 1}
    assert s.failures == {'bar': 1}


# Generated at 2022-06-22 20:24:49.420950
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed.keys() == []
    assert stats.failures.keys() == []
    assert stats.ok.keys() == []
    assert stats.dark.keys() == []
    assert stats.changed.keys() == []
    assert stats.skipped.keys() == []
    assert stats.rescued.keys() == []
    assert stats.ignored.keys() == []
    assert stats.custom.keys() == []

# Generated at 2022-06-22 20:24:59.152471
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    # Test 1: summarize a host with no stats.
    test_host = "host1"
    aggregate_stats = AggregateStats()
    expected_result = dict(
        ok=0,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0,
    )

    actual_result = aggregate_stats.summarize(test_host)

    assert expected_result == actual_result

    # Test 2: summarize a host with stats.
    expected_result = dict(
        ok=1,
        failures=1,
        unreachable=1,
        changed=1,
        skipped=1,
        rescued=1,
        ignored=1,
    )

    aggregate_stats.increment("ok", test_host)
    aggregate_