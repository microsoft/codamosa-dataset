

# Generated at 2022-06-22 20:15:03.157755
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('a', 1)
    assert stats.custom == {'_run': {'a': 1}}
    stats.update_custom_stats('b', 2)
    assert stats.custom == {'_run': {'a': 1, 'b': 2}}
    stats.update_custom_stats('a', 3)
    assert stats.custom == {'_run': {'a': 4, 'b': 2}}
    stats.update_custom_stats('a', 1.1)
    assert stats.custom == {'_run': {'a': 5.1, 'b': 2}}
    stats.update_custom_stats('c', 's')

# Generated at 2022-06-22 20:15:09.648858
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg_stats = AggregateStats()
    assert agg_stats.processed == {}
    assert agg_stats.failures == {}
    assert agg_stats.ok == {}
    assert agg_stats.dark == {}
    assert agg_stats.changed == {}
    assert agg_stats.skipped == {}
    assert agg_stats.rescued == {}
    assert agg_stats.ignored == {}
    assert agg_stats.custom == {}


# Generated at 2022-06-22 20:15:19.267054
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    import pprint
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    # Create AggregateStats object
    aggregate = AggregateStats()

    # Create Play object
    play_source =  dict(
            name        = "Ansible Play",
            hosts       = 'webservers',
            gather_facts= 'no',
            tasks       = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
             ]
        )

    play = Play().load(play_source, variable_manager=None, loader=None)

    # Create Role object
    role = Role()

    # Create Host object

# Generated at 2022-06-22 20:15:29.302088
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    summary = AggregateStats()
    summary.increment('ok', 'localhost')
    summary.increment('ok', 'localhost')
    summary.increment('ok', 'localhost')
    summary.increment('ok', 'localhost')
    summary.increment('ok', 'localhost')
    summary.increment('ok', 'localhost')
    summary.increment('ok', 'localhost')
    summary.increment('ok', 'localhost')
    summary.increment('ok', 'localhost')
    summary.increment('ok', 'localhost')
    summary.increment('ok', 'localhost')

    assert summary.summarize('localhost') == {'changed': 0, 'failures': 0, 'ok': 11, 'rescued': 0, 'ignored': 0, 'unreachable': 0, 'skipped': 0}

    summary.incre

# Generated at 2022-06-22 20:15:33.381090
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    a = AggregateStats()
    assert a.processed == {}
    assert a.failures == {}
    assert a.ok == {}
    assert a.dark == {}
    assert a.changed == {}
    assert a.skipped == {}
    assert a.rescued == {}
    assert a.ignored == {}
    assert a.custom == {}


# Generated at 2022-06-22 20:15:44.178065
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    initial_values = [stats.ok, stats.failures, stats.dark,
                      stats.changed, stats.skipped, stats.rescued,
                      stats.ignored]
    for stat in initial_values:
        assert not stat
        assert len(stat) == 0
        assert stat == {}

    # Test increment
    test_host = 'test_host1'
    stats.increment(what='ok', host=test_host)
    assert stats.ok == {test_host: 1}
    assert stats.ok[test_host] == 1

    stats.increment(what='failures', host=test_host)
    stats.increment(what='failures', host=test_host)
    assert stats.failures == {test_host: 2}
    assert stats.failures

# Generated at 2022-06-22 20:15:48.955414
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    stats.increment('dark', '127.0.0.1')
    stats.increment('ok', '127.0.0.1')
    stats.increment('changed', '127.0.0.1')

    assert stats.dark['127.0.0.1'] == 1
    assert stats.ok['127.0.0.1'] == 1
    assert stats.changed['127.0.0.1'] == 1
    assert stats.summarize('127.0.0.1') == {
            'ok': 1,
            'failures': 0,
            'unreachable': 1,
            'changed': 1,
            'skipped': 0,
            'rescued': 0,
            'ignored': 0,
            }

# Generated at 2022-06-22 20:16:00.644898
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    x = AggregateStats()
    assert x.summarize('foo') == {
        'ok': 0,
        'failures': 0,
        'unreachable': 0,
        'changed': 0,
        'skipped': 0,
        'rescued': 0,
        'ignored': 0
    }
    x.increment('ok', 'foo')
    assert x.summarize('foo') == {
        'ok': 1,
        'failures': 0,
        'unreachable': 0,
        'changed': 0,
        'skipped': 0,
        'rescued': 0,
        'ignored': 0
    }
    x.increment('failures', 'foo')
    assert x.failures['foo'] == 1

# Generated at 2022-06-22 20:16:07.700220
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok = {'host': 1}
    stats.dark = {'host': 1}
    stats.skipped = {'host': 1}
    assert stats.summarize('host') == {
        'ok': 1,
        'failures': 0,
        'unreachable': 1,
        'changed': 0,
        'skipped': 1,
        'rescued': 0,
        'ignored': 0,
    }


# Generated at 2022-06-22 20:16:11.247205
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment("ok", "foo")
    assert stats.ok["foo"] == 1
    stats.decrement("ok", "foo")
    assert stats.ok["foo"] == 0

# Generated at 2022-06-22 20:16:13.333853
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregateStats = AggregateStats()
    assert(isinstance(aggregateStats, AggregateStats))


# Generated at 2022-06-22 20:16:23.138900
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    custom_stats = AggregateStats()
    # test with integer inputs
    # no custom stat
    assert custom_stats.update_custom_stats('my_custom_stat', 10) == None
    # custom stat already set
    custom_stats.set_custom_stats('my_custom_stat', 100)
    assert custom_stats.update_custom_stats('my_custom_stat', 10) == None
    # custom stat not set
    assert custom_stats.update_custom_stats('new_custom_stat', 10, 'host') == 10
    assert custom_stats.custom['host']['new_custom_stat'] == 10
    # test with dictionary inputs
    custom_stats = AggregateStats()

# Generated at 2022-06-22 20:16:34.790613
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    
    # Test for "not decrement if the dict for the stat is empty"
    #
    # 1. set no stat for host
    # 2. decrement the stat for host
    # 3. check if the stat is properly set
    stats.decrement("ok", "host")
    assert stats.ok["host"] == 0

    # Test for "not decrement the stat if it is 0 or less"
    #
    # 1. set the stat for host to 0
    # 2. decrement the stat for host
    # 3. check if the sta is properly set
    stats.ok["host"] = 0
    stats.decrement("ok", "host")
    assert stats.ok["host"] == 0

    # Test for "decrement the stat if it is greater than 0"
    #

# Generated at 2022-06-22 20:16:41.448929
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.processed == {}
    assert aggregate_stats.failures == {}
    assert aggregate_stats.ok == {}
    assert aggregate_stats.dark == {}
    assert aggregate_stats.changed == {}
    assert aggregate_stats.skipped == {}
    assert aggregate_stats.rescued == {}
    assert aggregate_stats.ignored == {}
    assert aggregate_stats.custom == {}


# Generated at 2022-06-22 20:16:52.140930
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.ok={'test_host': 2}
    aggregate_stats.failures={'test_host': 2}
    aggregate_stats.dark={'test_host': 2}
    aggregate_stats.changed={'test_host': 2}
    aggregate_stats.skipped={'test_host': 0}
    aggregate_stats.rescued={'test_host': 2}
    aggregate_stats.ignored={'test_host': 0}
    aggregate_stats.decrement('ok', 'test_host')
    aggregate_stats.decrement('failures', 'test_host')
    aggregate_stats.decrement('dark', 'test_host')
    aggregate_stats.decrement('changed', 'test_host')

# Generated at 2022-06-22 20:16:56.056865
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats("http_requests", 10)
    assert stats.custom['_run']['http_requests'] == 10
    assert stats.custom == {'_run': {'http_requests': 10}}

# Generated at 2022-06-22 20:17:04.889162
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregateStats = AggregateStats()

    # scalar addition
    aggregateStats.set_custom_stats('scalar', 69)
    aggregateStats.update_custom_stats('scalar', 1)
    assert aggregateStats.custom["_run"]["scalar"] == 70

    # dict addition
    aggregateStats.set_custom_stats('dictionary', {"a": 69})
    aggregateStats.update_custom_stats('dictionary', {"a": 1, "b": 1})
    assert aggregateStats.custom["_run"]["dictionary"] == {"a": 70, "b": 1}

# Generated at 2022-06-22 20:17:09.766721
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert {
        'ok': {},
        'failures': {},
        'dark': {},
        'changed': {},
        'skipped': {},
        'rescued': {},
        'ignored': {},
        'processed': {}
    } == stats.__dict__
    assert stats.custom == {}

# Generated at 2022-06-22 20:17:20.096921
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    # setup
    import warnings
    warnings.filterwarnings("ignore")

    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'localhost')

    # test ok
    assert aggregate_stats.ok['localhost'] == 1, "method increment() of class AggregateStats failed"

    # test failures
    aggregate_stats.increment('failures', 'localhost')
    assert aggregate_stats.failures['localhost'] == 1, "method increment() of class AggregateStats failed"

    # test dark
    aggregate_stats.increment('dark', 'localhost')
    assert aggregate_stats.dark['localhost'] == 1, "method increment() of class AggregateStats failed"

    # test changed
    aggregate_stats.increment('changed', 'localhost')

# Generated at 2022-06-22 20:17:26.252385
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Decrement a value that exists
    agg = AggregateStats()
    agg.ok['host1'] = 5
    agg.decrement('ok', 'host1')
    assert agg.ok['host1'] == 4
    # Decrement a value that doesn't exist
    agg.decrement('ok', 'host1')
    assert agg.ok['host1'] == 0


# Generated at 2022-06-22 20:17:30.347332
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    host = 'localhost'
    aggregate_stats.set_custom_stats("total tasks", 1, host)
    assert aggregate_stats.custom[host]["total tasks"] == 1


# Generated at 2022-06-22 20:17:40.714722
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import pytest

    test_stats = AggregateStats()
    test_stats.update_custom_stats('test_key', 'test_value', 'test_host')
    assert test_stats.custom['test_host']['test_key'] == 'test_value'
    test_stats.update_custom_stats('test_key', 'test_value2', 'test_host')
    assert test_stats.custom['test_host']['test_key'] == 'test_value'
    test_stats.update_custom_stats('test_key', 'test_value2', 'test_host2')
    assert test_stats.custom['test_host2']['test_key'] == 'test_value2'

# Generated at 2022-06-22 20:17:48.413325
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok['host1'] = 1
    stats.ok['host2'] = 1

    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host2')
    assert stats.ok == {'host1': 0, 'host2': 0}

    stats.decrement('ok', 'host1')
    assert stats.ok == {'host1': 0, 'host2': 0}

# Generated at 2022-06-22 20:17:53.223960
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert(stats.processed == {})
    assert(stats.failures == {})
    assert(stats.ok == {})
    assert(stats.dark == {})
    assert(stats.changed == {})
    assert(stats.skipped == {})
    assert(stats.rescued == {})
    assert(stats.ignored == {})
    assert(stats.custom == {})

# Generated at 2022-06-22 20:18:00.955811
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    from ansible.utils.vars import combine_vars

    # Define aggregate stats object
    aggregate_stats = AggregateStats()

    # Test set_custom_stats method
    aggregate_stats.set_custom_stats('message', 'This is a custom stat')
    aggregate_stats.set_custom_stats('message', 'This is a custom stat 2', '_run')
    assert aggregate_stats.custom['_run']['message'] == 'This is a custom stat 2'



# Generated at 2022-06-22 20:18:04.248459
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    ag_stats = AggregateStats()
    ag_stats.set_custom_stats("which", "what", "host")
    assert ag_stats.custom == {'host': {'which': 'what'}}


# Generated at 2022-06-22 20:18:07.912203
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()

    stats.set_custom_stats('foo', 'bar', 'localhost')
    stats.set_custom_stats('foo', 'bar')
    assert stats.custom == {'localhost': {'foo': 'bar'}, '_run': {'foo': 'bar'}}


# Generated at 2022-06-22 20:18:10.534653
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    import ansible.playbook
    pb = ansible.playbook.PlayBook()
    assert pb.stats.__class__.__name__ == 'AggregateStats'


# Generated at 2022-06-22 20:18:14.425487
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats("foo", "bar", "localhost")
    assert aggregate_stats.custom == {"localhost": {"foo": "bar"}}


# Generated at 2022-06-22 20:18:26.291002
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    ast = AggregateStats()
    ast.update_custom_stats('dict_merge', {'key1': 1, 'key2': 2, 'key3': 3}, 'an_ip')
    assert ast.custom['an_ip']['dict_merge'] == {'key1': 1, 'key2': 2, 'key3': 3}

    ast.update_custom_stats('dict_merge', {'key2': 3, 'key3': 2, 'key4': 1}, 'an_ip')
    assert ast.custom['an_ip']['dict_merge'] == {'key1': 1, 'key2': 3, 'key3': 2, 'key4': 1}

    ast.update_custom_stats('value_merge', 5, 'an_ip')

# Generated at 2022-06-22 20:18:34.954512
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    stats.increment( "ok", "host1" )
    assert stats.ok.get( "host1", 0 ) == 1
    stats.increment( "ok", "host2" )
    assert stats.ok.get( "host2", 0 ) == 1

    stats.increment( "failures", "host1" )
    assert stats.failures.get( "host1", 0 ) == 1
    stats.increment( "failures", "host2" )
    assert stats.failures.get( "host2", 0 ) == 1
    stats.increment( "failures", "host2" )
    assert stats.failures.get( "host2", 0 ) == 2

    stats.increment( "skipped", "host1" )

# Generated at 2022-06-22 20:18:39.012567
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('some_stats', 'some_value')
    assert stats.custom['_run']['some_stats'] == 'some_value'

# Generated at 2022-06-22 20:18:45.563709
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    stats.increment('ok', 'localhost')
    assert stats.ok.get('localhost', 0) == 1

    stats.decrement('ok', 'localhost')
    assert stats.ok.get('localhost', 0) == 0

    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok.get('localhost', 0) == 0


# Generated at 2022-06-22 20:18:56.774456
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    '''Unit test for method set_custom_stats of class AggregateStats'''
    stats = AggregateStats()

    test_custom_stats_set_simple = {'test_custom_stat': 3}
    stats.set_custom_stats(**test_custom_stats_set_simple)

    # Check integrity of the composite custom stat dict
    assert stats.custom['_run']['test_custom_stat'] == test_custom_stats_set_simple['test_custom_stat']
    assert len(stats.custom['_run']) == 1

    # Check integrity of the composite custom stat dict
    test_custom_stats_set_multiple = {'test_custom_stat_multiple': 7}
    stats.set_custom_stats(**test_custom_stats_set_multiple)


# Generated at 2022-06-22 20:19:05.520746
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # test simple value
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats('my_string', 'my_simple_string')
    assert aggregate_stats.custom['_run']['my_string'] == 'my_simple_string'
    aggregate_stats.update_custom_stats('my_string', 'my_new_string')
    assert aggregate_stats.custom['_run']['my_string'] == 'my_new_string'

    # test list
    aggregate_stats.update_custom_stats('my_list', [1, 2])
    assert aggregate_stats.custom['_run']['my_list'] == [1, 2]
    aggregate_stats.update_custom_stats('my_list', [3, 4])

# Generated at 2022-06-22 20:19:08.629544
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    assert stats.ok == {'localhost': 2}
    assert stats.changed == {}


# Generated at 2022-06-22 20:19:16.506580
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    out = AggregateStats()
    out.set_custom_stats('test1', 'test2', 'test3')
    assert out.custom['test3']['test1'] == 'test2'
    out.set_custom_stats('test1', 'test2', 'test3')
    assert out.custom['test3']['test1'] == 'test2'
    out.set_custom_stats('test1', 'test2', 'test4')
    assert out.custom['test4']['test1'] == 'test2'
    out.set_custom_stats('test1', 'test2', 'test3')
    assert out.custom['test3']['test1'] == 'test2'



# Generated at 2022-06-22 20:19:25.089907
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stat = AggregateStats()

    # Test with a host specified
    host = 'remote_host_1'
    stat.set_custom_stats('custom stat', 42, host)
    assert stat.custom[host] == {'custom stat': 42}

    # Test without a host specified.
    # The test is carried out by looking at the value of stat.custom._run
    stat.set_custom_stats('custom stat', 42)
    assert stat.custom['_run'] == {'custom stat': 42}

# Generated at 2022-06-22 20:19:27.670435
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.dark == {}



# Generated at 2022-06-22 20:19:31.524087
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ignored', 'host')
    assert stats.ignored['host'] == 0
    stats.ok['host'] = 5
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 4


# Generated at 2022-06-22 20:19:37.584123
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    from copy import deepcopy
    # A test case for method set_custom_stats of class AggregateStats
    # containing
    #     a. A string to be set in the custom stats field
    #     b. A dict to be set in the custom stats field
    #     c. A list to be set in the custom stats field
    testcase = [("custom_stats", {"custom_stats": {"name": "my_custom_stats"}},
                 "my_custom_stats"),
                ("custom_stats", {"custom_stats": ["one", "two", "three"]},
                 ["one", "two", "three"]),
                ("custom_stats", {"custom_stats": 12345}, 12345)]
        # Run the test case
    for i in testcase:
        custom_stats = i[0]

# Generated at 2022-06-22 20:19:47.210273
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats1 = AggregateStats()
    assert aggregate_stats1.processed == {}
    assert aggregate_stats1.failures == {}
    # Call the method increment
    aggregate_stats1.increment('failures', 'test_host')
    assert aggregate_stats1.processed == {'test_host': 1}
    assert aggregate_stats1.failures == {'test_host': 1}
    aggregate_stats1.increment('failures', 'test_host')
    assert aggregate_stats1.processed == {'test_host': 1}
    assert aggregate_stats1.failures == {'test_host': 2}
    aggregate_stats1.increment('ok', 'test_host')
    assert aggregate_stats1.processed == {'test_host': 2}
    assert aggregate_stats1.failures

# Generated at 2022-06-22 20:19:56.522684
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.custom == {}
    aggregate_stats.set_custom_stats('changed', 10, '192.168.1.1')
    assert aggregate_stats.custom == {'192.168.1.1': {'changed': 10}}
    aggregate_stats.set_custom_stats('changed', 20, '192.168.1.1')
    assert aggregate_stats.custom == {'192.168.1.1': {'changed': 20}}
    aggregate_stats.set_custom_stats('changed', 10, '192.168.1.2')
    host1_expected = {'changed': 20}
    host2_expected = {'changed': 10}

# Generated at 2022-06-22 20:19:57.659370
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats is not None


# Generated at 2022-06-22 20:20:00.462651
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('some', 'thing')
    assert stats.custom['_run']['some'] == 'thing'


# Generated at 2022-06-22 20:20:04.401327
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate = AggregateStats()
    aggregate.increment('ok', 'host')
    assert aggregate.ok['host'] == 1
    assert aggregate.processed['host'] == 1
    aggregate.increment('ignored', 'host')
    assert aggregate.ok['host'] == 1
    assert aggregate.ignored['host'] == 1


# Generated at 2022-06-22 20:20:11.636359
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()

    # Test for host that has stats and for one that doesn't
    stats.ok['host1'] = 1
    assert stats.summarize('host1')['ok'] == 1
    assert stats.summarize('host2')['ok'] == 0
    assert stats.summarize('host1')['skipped'] == 0


# Generated at 2022-06-22 20:20:15.851046
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host1')

    assert stats.summarize('host1')['ok'] == 2
    assert stats.summarize('host2')['ok'] == 1



# Generated at 2022-06-22 20:20:23.738137
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()

    assert stats.processed == {}
    assert stats.ok == {}
    assert stats.failures == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-22 20:20:27.694249
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.decrement('ok', '192.168.33.17')
    assert aggregate_stats.ok['192.168.33.17'] == 0

# Generated at 2022-06-22 20:20:37.270532
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggr_stats = AggregateStats()

    aggr_stats.increment('failures', '127.0.0.1')

    if aggr_stats.failures.get('127.0.0.1', 0) != 1 or aggr_stats.processed.get('127.0.0.1', 0) != 1 :
        raise AssertionError("AggregateStats increment method unit test 1 failed")



# Generated at 2022-06-22 20:20:45.159178
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    s = AggregateStats()
    s.set_custom_stats('foo', 'bar')
    assert s.custom['_run']['foo'] == 'bar', \
        "AggregateStats.set_custom_stats() does not set default value for host"

    s.set_custom_stats('foo', 'baz', 'test')
    assert s.custom['test']['foo'] == 'baz', \
        "AggregateStats.set_custom_stats() does not set value for host"

    s.set_custom_stats('foo', 'baz', 'test')
    assert s.custom['test']['foo'] == 'baz', \
        "AggregateStats.set_custom_stats() does not override value for host"


# Generated at 2022-06-22 20:20:48.561815
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    as1 = AggregateStats()
    as1.increment("ok", "test_host")

    as1.decrement("ok", "test_host")
    assert as1.ok.get("test_host") == 0

# Generated at 2022-06-22 20:20:59.525410
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    agg = AggregateStats()
    agg.update_custom_stats("var", 2)
    # assert agg.custom == {'_run': {'var': 2}}
    agg.update_custom_stats("var", 3)
    # assert agg.custom == {'_run': {'var': 5}}
    agg.update_custom_stats("var", {"x": "y"})
    # assert agg.custom == {'_run': {'var': {'x': 'y'}}}

    # try to add mismatching types
    agg.update_custom_stats("var", 2)
    # assert agg.custom == {'_run': {'var': {'x': 'y'}}}

    # try different hosts
    agg.update_custom_stats("var", "another host", "another host")
    # assert agg.custom ==

# Generated at 2022-06-22 20:21:04.313539
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    '''
    >>> test_AggregateStats()
    '''
    stats = AggregateStats()
    if stats.processed != {} or stats.failures != {} or stats.dark != {} or stats.changed != {} or stats.skipped != {} or stats.rescued != {} or stats.ignored != {} or stats.custom != {}:
        raise AssertionError


# Generated at 2022-06-22 20:21:14.268789
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'www.example.com')
    stats.increment('ok', 'www.example.com')
    stats.increment('ok', 'www.example.com')

    stats.increment('failures', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('failures', 'invalid.example.com')

    stats.increment('changed', 'localhost')

    stats.increment('skipped', 'www.example.com')
    stats.increment('skipped', 'www.example.com')
    stats.increment('skipped', 'www.example.com')

# Generated at 2022-06-22 20:21:20.673578
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.ok == {}
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-22 20:21:29.552888
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats('up_to_date', 0)
    aggregate_stats.update_custom_stats('changed', 0)
    aggregate_stats.update_custom_stats('failed', 0)
    aggregate_stats.update_custom_stats('skipped', 0)
    aggregate_stats.update_custom_stats('rescued', 0)
    aggregate_stats.update_custom_stats('ignored', 0)
    aggregate_stats.update_custom_stats('processed', 0)
    aggregate_stats.update_custom_stats('dark', 0)
    aggregate_stats.update_custom_stats('ok', 0)

    assert aggregate_stats.custom['_run']['up_to_date'] == 0

# Generated at 2022-06-22 20:21:38.822912
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    # 2.1. Mismatching types
    stat = AggregateStats()
    # 2.1.1. String and int
    stat.set_custom_stats('Test', '5')
    stat.update_custom_stats('Test', 3)
    assert stat.custom['_run']['Test'] == '5'
    # 2.1.2. List and dict
    stat.set_custom_stats('Test', ['foo'])
    stat.update_custom_stats('Test', {'test': 'bar'})
    assert stat.custom['_run']['Test'] == ['foo']
    # 2.1.3. Dict and string
    stat.set_custom_stats('Test', {'test': 'bar'})
    stat.update_custom_stats('Test', 'baz')

# Generated at 2022-06-22 20:21:50.314798
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    SUT = AggregateStats()

    # The stat 'custom' is not initialized
    SUT.update_custom_stats("toto", "titi", "tata")
    assert(SUT.custom == {'tata': {'toto': 'titi'}})

    # The stat 'custom' is already initialized
    SUT.update_custom_stats("soso", "sasi")
    assert(SUT.custom == {'tata': {'toto': 'titi'}, '_run': {'soso': 'sasi'}})

    # The stat 'custom' is already initialized, but not for this host
    SUT.update_custom_stats("toto", "tutu", "tata")

# Generated at 2022-06-22 20:22:01.207047
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    host = 'localhost'

    assert_is_merged = [
        (
            {'a': {1: 2, 3: 4}},
            {'a': {5: 6, 3: 5}},
            {'a': {1: 2, 3: 5, 5: 6}}
        )
    ]
    assert_is_added = [
        (
            {'a': 12},
            {'a': 20},
            {'a': 32}
        )
    ]
    assert_is_ignored = [
        (
            {'a': 12},
            {'a': '30'},
            {'a': 12}
        )
    ]

    stats = AggregateStats()

# Generated at 2022-06-22 20:22:05.686823
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.processed = {'localhost': 1}
    stats.ok = {'localhost': 1}
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-22 20:22:15.607079
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment("ok", host="host1")
    stats.increment("ok", host="host1")
    stats.increment("ok", host="host2")
    stats.increment("failures", host="host1")
    stats.increment("changed", host="host1")

    stats.increment("ok", host="_run")
    stats.increment("ok", host="_run")
    stats.increment("failures", host="_run")

    assert stats.summarize("host1") == {'ok': 2, 'failures': 1, 'unreachable': 0,
                                        'changed': 1, 'skipped': 0, 'rescued': 0, 'ignored': 0}

# Generated at 2022-06-22 20:22:23.841678
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok['host1'] = 3
    stats.dark['host3'] = 0
    stats.failures['host2'] = 2
    stats.changed['host1'] = 1
    summary = stats.summarize('host1')
    assert summary['ok'] == 3
    assert summary['failures'] == 0
    assert summary['unreachable'] == 0
    assert summary['changed'] == 1
    assert summary['skipped'] == 0
    assert summary['rescued'] == 0
    assert summary['ignored'] == 0


# Generated at 2022-06-22 20:22:26.639150
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("ok", "host1")
    assert stats.processed == {"host1": 1}
    assert stats.failures == {}
    assert stats.ok == {"host1": 1}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-22 20:22:36.034856
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    as_obj = AggregateStats()

    # set custom stat
    as_obj.set_custom_stats('stdout', 'ATLAS')
    assert len(as_obj.custom) == 1
    assert '_run' in as_obj.custom

    # update with a string
    as_obj.update_custom_stats('stdout', 'CLOUD')
    assert len(as_obj.custom) == 1
    assert '_run' in as_obj.custom
    assert as_obj.custom['_run']['stdout'] == 'ATLASCLOUD'

    # update with an integer
    as_obj.update_custom_stats('num_hosts', 4)
    assert len(as_obj.custom) == 1
    assert '_run' in as_obj.custom

# Generated at 2022-06-22 20:22:42.303193
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('dict', {"a": 1})
    stats.update_custom_stats('dict', {"b": 2})
    assert stats.custom == {
        '_run': {
            'dict': {
                'a': 1,
                'b': 2,
            }
        }
    }
    stats.update_custom_stats('list', ["a"])
    stats.update_custom_stats('list', ["b"])
    assert stats.custom == {
        '_run': {
            'dict': {
                'a': 1,
                'b': 2,
            },
            'list': [
                'a',
                'b'
            ]
        }
    }
    stats.update_custom_stats('int', 1)
    stats.update

# Generated at 2022-06-22 20:22:43.271937
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    assert AggregateStats() != None


# Generated at 2022-06-22 20:22:51.637813
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stat = AggregateStats()
    stat.increment('ok', 'foo')
    stat.increment('ok', 'foo')
    stat.increment('ok', 'bar')
    stat.increment('ok', 'bar')
    stat.increment('ok', 'bar')
    stat.increment('changed', 'foo')

    assert stat.ok == {'foo':2, 'bar':3}
    assert stat.changed == {'foo':1}

    stat.increment('foobar', 'bar')
    assert stat.foobar == {'bar':1}


# Generated at 2022-06-22 20:23:01.779902
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'a')
    stats.increment('ok', 'a')
    stats.increment('ok', 'b')
    assert(stats.summarize('a') == dict(
        ok=2,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0,
    ))

    stats.increment('rescued', 'a')
    assert(stats.summarize('a') == dict(
        ok=2,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=1,
        ignored=0,
    ))

    stats.increment('ignored', 'b')

# Generated at 2022-06-22 20:23:08.032123
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    a = AggregateStats()
    assert a.processed == {}
    assert a.failures == {}
    assert a.ok == {}
    assert a.dark == {}
    assert a.changed == {}
    assert a.skipped == {}
    assert a.rescued == {}
    assert a.ignored == {}
    assert a.custom == {}


# Generated at 2022-06-22 20:23:14.310723
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()

    # These should not raise.  They are testing that a KeyError will not be raised
    # by decrement
    aggregate_stats.decrement('ok', 'hostname')
    aggregate_stats.decrement('failures', 'hostname')
    aggregate_stats.decrement('rescued', 'hostname')
    aggregate_stats.decrement('ignored', 'hostname')

# Generated at 2022-06-22 20:23:18.942986
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    # Create object of class AggregateStats
    aggr_stats = AggregateStats()
    
    host = 'fake_host'
    which = 'fake_which'
    what = 'fake_what'
    aggr_stats.set_custom_stats(which, what, host)
    
    assert aggr_stats.custom[host][which] == 'fake_what', 'Wrong value was set'


# Generated at 2022-06-22 20:23:21.073275
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    a_stats = AggregateStats()
    assert isinstance(a_stats, AggregateStats)

# Generated at 2022-06-22 20:23:27.881144
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    """Unit test for class AggregateStats"""
    stats = AggregateStats()
    assert (stats.processed == {})
    assert (stats.failures == {})
    assert (stats.ok == {})
    assert (stats.dark == {})
    assert (stats.changed == {})
    assert (stats.skipped == {})
    assert (stats.rescued == {})
    assert (stats.ignored == {})
    assert (stats.custom == {})


# Generated at 2022-06-22 20:23:38.866948
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'
    stats.set_custom_stats('foo', 'baz')
    assert stats.custom['_run']['foo'] == 'baz'
    stats.update_custom_stats('foo', 'baz')
    assert stats.custom['_run']['foo'] == 'bazbaz'
    stats.update_custom_stats('foo', 'bax', 'host')
    assert stats.custom['host']['foo'] == 'bax'
    stats.set_custom_stats('foo', 'bay', 'host')
    assert stats.custom['host']['foo'] == 'bay'

# Generated at 2022-06-22 20:23:49.524139
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    host = 'localhost'
    assert stats.processed.get(host,0) == 0
    assert stats.failures.get(host,0) == 0
    assert stats.ok.get(host,0) == 0
    assert stats.dark.get(host,0) == 0
    assert stats.changed.get(host,0) == 0
    assert stats.skipped.get(host,0) == 0
    assert stats.rescued.get(host,0) == 0
    assert stats.ignored.get(host,0) == 0
    assert stats.custom == {}

    # Check that the number of processed hosts is incremented
    stats.increment('ok', host)
    assert stats.processed.get(host, 0) == 1

# Generated at 2022-06-22 20:23:51.750992
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert None is not stats

# Generated at 2022-06-22 20:24:01.278994
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    class AggregateStats_test(AggregateStats):
        def __init__(self):
            super(AggregateStats_test, self).__init__()
            self.processed = {}
            self.failures = {}
            self.ok = {}
            self.dark = {}

    test_object = AggregateStats_test()
    test_object.increment('failures', 'localhost')
    test_object.increment('ok', 'localhost')
    test_object.increment('dark', 'localhost')

    assert test_object.failures['localhost'] == 1
    assert test_object.ok['localhost'] == 1
    assert test_object.dark['localhost'] == 1



# Generated at 2022-06-22 20:24:11.627086
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    # create object for class AggregateStats()
    host_stats = AggregateStats()
    # check object is not empty
    assert host_stats
    # check all variables are declared correctly
    assert isinstance(host_stats.processed, dict)
    assert isinstance(host_stats.failures, dict)
    assert isinstance(host_stats.ok, dict)
    assert isinstance(host_stats.dark, dict)
    assert isinstance(host_stats.changed, dict)
    assert isinstance(host_stats.skipped, dict)
    assert isinstance(host_stats.rescued, dict)
    assert isinstance(host_stats.ignored, dict)
    assert isinstance(host_stats.custom, dict)


# Generated at 2022-06-22 20:24:18.296428
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', '127.0.0.1')
    stats.increment('ok', '127.0.0.1')
    stats.increment('ok', '127.0.0.1')
    stats.increment('failures', '127.0.0.1')
    stats.increment('changed', '127.0.0.1')
    stats.increment('changed', '127.0.0.1')
    stats.increment('ignored', '127.0.0.1')
    stats.increment('ignored', '127.0.0.1')
    stats.increment('skipped', '127.0.0.1')
    stats.increment('skipped', '127.0.0.1')

# Generated at 2022-06-22 20:24:23.739153
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggr_stats = AggregateStats()
    aggr_stats.set_custom_stats('foo', 10)
    assert aggr_stats.custom == {'_run': {'foo': 10}}

    aggr_stats.set_custom_stats('bar', 20, 'localhost')
    assert aggr_stats.custom == {'_run': {'foo': 10}, 'localhost': {'bar': 20}}

    aggr_stats.set_custom_stats('bar', 'baz', 'localhost')
    assert aggr_stats.custom == {'_run': {'foo': 10}, 'localhost': {'bar': 'baz'}}


# Generated at 2022-06-22 20:24:27.545238
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    as1 = AggregateStats()
    as1.decrement('failures', '127.0.0.1')
    assert as1.failures == {'127.0.0.1': 0}

# Generated at 2022-06-22 20:24:31.667125
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Test decrement() by modifying a value and checking that it is different
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1

# Generated at 2022-06-22 20:24:38.725065
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    taskstat = AggregateStats()
    taskstat.increment('ok', 'localhost.localdomain')
    assert 'localhost.localdomain' in taskstat.ok
    assert 'localhost.localdomain' in taskstat.processed
    taskstat.increment('ok', 'localhost.localdomain')
    assert taskstat.ok['localhost.localdomain'] == 2

    # The Ok key should not be in the failures dict
    assert 'localhost.localdomain' not in taskstat.failures



# Generated at 2022-06-22 20:24:50.978452
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    stats.update_custom_stats("my_stat", 1, "localhost")
    assert stats.custom["localhost"] == {"my_stat": 1}

    stats.update_custom_stats("my_stat", {1: 2, 3: 4}, "localhost")
    assert stats.custom["localhost"] == {"my_stat": {1: 2, 3: 4}}

    stats.update_custom_stats("my_stat", {3: 5}, "localhost")
    assert stats.custom["localhost"] == {"my_stat": {1: 2, 3: 5}}

    stats.update_custom_stats("my_stat", {3: "overwritten"}, "localhost")
    assert stats.custom["localhost"] == {"my_stat": {1: 2, 3: "overwritten"}}

    stats.update_custom_stats

# Generated at 2022-06-22 20:24:59.390145
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():

    stats_instance = AggregateStats()
    stats_instance.ok['localhost'] = 1000
    stats_instance.failures['localhost'] = 20
    stats_instance.dark['localhost'] = 1
    stats_instance.changed['localhost'] = 99
    stats_instance.skipped['localhost'] = 33
    stats_instance.rescued['localhost'] = 2
    stats_instance.ignored['localhost'] = 10

    expected_result = dict(
        ok=1000, failures=20, unreachable=1, changed=99, skipped=33,
        rescued=2, ignored=10
    )

    assert (stats_instance.summarize('localhost') == expected_result)
