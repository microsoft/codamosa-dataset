

# Generated at 2022-06-22 20:15:02.321680
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('failures', 'localhost')
    assert stats.failures == {'localhost': 1}


# Generated at 2022-06-22 20:15:04.362971
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.ok == {}
    assert stats.processed == {}


# Generated at 2022-06-22 20:15:15.097405
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # init stats
    stats = AggregateStats()

    # test update dict to dict
    stats.set_custom_stats('stats_1', {'key':'value'})
    assert stats.custom['_run']['stats_1'] == {'key':'value'}
    stats.update_custom_stats('stats_1', {'another_key':'another_value'})
    assert stats.custom['_run']['stats_1'] == {'key':'value', 'another_key':'another_value'}

    # test update dict to int
    stats.set_custom_stats('stats_2', {'key':'value'})
    assert stats.custom['_run']['stats_2'] == {'key':'value'}
    stats.update_custom_stats('stats_2', 1)

# Generated at 2022-06-22 20:15:16.968084
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'host')
    assert aggregate_stats.ok['host'] == 1


# Generated at 2022-06-22 20:15:28.296284
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    import pytest
    # create object
    obj = AggregateStats()
    # call set_custom_stats method
    obj.set_custom_stats('change', 1, 'server')
    obj.set_custom_stats('change2', 2, 'server')
    assert obj.custom['server'] == {'change': 1, 'change2': 2}
    obj.set_custom_stats('change', 3, 'server')
    assert obj.custom['server'] == {'change': 3, 'change2': 2}
    obj.set_custom_stats('change', [1], 'server')
    assert obj.custom['server'] == {'change': [1], 'change2': 2}
    obj.set_custom_stats('change', [1, 2], 'server')

# Generated at 2022-06-22 20:15:39.406893
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stat = AggregateStats()
    stat.update_custom_stats('test_key', 'test_value')
    assert stat.custom.get('_run', {}).get('test_key') == 'test_value'
    assert stat.custom['_run']['test_key'] == 'test_value'
    stat.update_custom_stats('test_key', {'key':'value'})
    assert stat.custom['_run']['test_key'] == {'key':'value'}
    stat.update_custom_stats('new_key', {'key':'value'})
    assert stat.custom['_run']['new_key'] == {'key':'value'}
    stat.update_custom_stats('new_key', {'key2':'value2'})

# Generated at 2022-06-22 20:15:47.925976
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    #
    # Test 1: test dict merging
    #
    target = AggregateStats()
    # Set the base dict
    target.set_custom_stats("bar", { "foo": { "bar": 42 }})
    # Adjust the leaf
    target.update_custom_stats("bar", { "foo": { "bar": 14 }, "baz": 3 })
    # Make sure it's as expected
    assert(target.custom["_run"]["bar"] == { "foo": { "bar": 14 }, "baz": 3 })

    #
    # Test 2: test int aggregation
    #
    target = AggregateStats()
    # Set the base int
    target.set_custom_stats("bar", 42)
    # Adjust the int
    target.update_custom_stats("bar", 3)
    # Make sure it's as

# Generated at 2022-06-22 20:15:55.501743
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg = AggregateStats()
    agg.increment('ok', 'ok_host')
    agg.increment('failures', 'failure_host')
    agg.increment('failures', 'failure_host')
    agg.increment('ok', 'ok_host')
    agg.increment('changed', 'changed_host')

    assert agg.ok['ok_host'] == 2
    assert agg.failures['failure_host'] == 2
    assert agg.changed['changed_host'] == 1

# Generated at 2022-06-22 20:16:04.912677
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ''' test AggregateStats.increment() method'''
    aggregate = AggregateStats()
    host = "127.0.0.1"
    aggregate.increment("ok", host)
    assert aggregate.processed[host] == 1
    assert aggregate.ok[host] == 1
    assert aggregate.ok.get("NotTheHost", 0) == 0
    assert aggregate.ok.get(host, 0) == 1
    aggregate.increment("ok", host)
    assert aggregate.ok[host] == 2
    assert aggregate.ok.get(host, 0) == 2
    # cleanup
    aggregate.ok.clear()
    aggregate.processed.clear()


# Generated at 2022-06-22 20:16:09.415540
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats =  AggregateStats()
    k = 'test_key'
    value = 'test_value'
    host = 'test_host'
    stats.set_custom_stats(k, value, host)
    assert stats.custom[host] == { k: value }


# Generated at 2022-06-22 20:16:12.285560
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('foo', 10)
    assert stats.custom['_run']['foo'] == 10


# Generated at 2022-06-22 20:16:22.598926
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'testhost')
    stats.increment('ok', 'testhost')
    stats.increment('failed', 'testhost')
    stats.increment('dark', 'testhost')
    stats.increment('changed', 'testhost')
    stats.increment('skipped', 'testhost')
    stats.increment('rescued', 'testhost')
    stats.increment('ignored', 'testhost')

    result = stats.summarize('testhost')
    expected_result = {
        'ok': 2,
        'failures': 1,
        'unreachable': 1,
        'changed': 1,
        'skipped': 1,
        'rescued': 1,
        'ignored': 1,
    }


# Generated at 2022-06-22 20:16:26.017582
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    test_obj = AggregateStats()
    test_obj.increment("ok", "host1")
    assert test_obj.ok["host1"] == 1


# Generated at 2022-06-22 20:16:30.781466
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Test for method increment of class AggregateStats

# Generated at 2022-06-22 20:16:37.934738
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg_stats = AggregateStats()
    agg_stats.increment("ok", "localhost")
    assert agg_stats.ok["localhost"] == 1
    agg_stats.decrement("ok", "localhost")
    assert agg_stats.ok["localhost"] == 0
    agg_stats.decrement("ok", "localhost")
    assert agg_stats.ok["localhost"] == 0

test_AggregateStats_decrement()

# Generated at 2022-06-22 20:16:48.205719
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    agg = AggregateStats()
    agg.update_custom_stats('converged',1)
    assert agg.custom['_run']['converged'] == 1
    agg.update_custom_stats('converged',1)
    assert agg.custom['_run']['converged'] == 2
    agg.update_custom_stats('converged',{'a':1, 'b':2})
    assert agg.custom['_run']['converged'] == {'a':1, 'b':2}
    agg.update_custom_stats('converged',{'a':2, 'c':2})
    assert agg.custom['_run']['converged'] == {'a':3, 'b':2, 'c':2}

# Generated at 2022-06-22 20:16:57.115102
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("changed", "host1")
    assert stats.processed["host1"] == 1
    assert stats.changed["host1"] == 1
    stats.increment("changed", "host1")
    assert stats.processed["host1"] == 1
    assert stats.changed["host1"] == 2
    stats.increment("ignored", "host1")
    assert stats.processed["host1"] == 1
    assert stats.ignored["host1"] == 1
    assert stats.ignored["host2"] == 0
    assert stats.changed["host2"] == 0
    assert stats.failures["host2"] == 0


# Generated at 2022-06-22 20:17:02.936629
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg = AggregateStats()
    agg.increment('ok', '127.0.0.1')
    assert agg.processed == {'127.0.0.1': 1}
    assert agg.ok == {'127.0.0.1':1}


# Generated at 2022-06-22 20:17:05.597634
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 1


# Generated at 2022-06-22 20:17:10.061843
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg = AggregateStats()
    agg.set_custom_stats('test', 'value')
    assert agg.custom['_run']['test'] == 'value'
    agg.set_custom_stats('test', 'other', 'some-host')
    assert agg.custom['some-host']['test'] == 'other'


# Generated at 2022-06-22 20:17:15.351109
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    x = AggregateStats()
    x.increment('ok', 'host')

    assert x.ok['host'] == 1
    x.decrement('ok', 'host')
    assert x.ok['host'] == 0
    # if decremented below 0, set to 0
    x.decrement('ok', 'host')
    assert x.ok['host'] == 0

test_AggregateStats_decrement()

# Generated at 2022-06-22 20:17:25.811904
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    '''
    This function is used for unit testing of method decrement
    '''

    # Create an instance of the class
    aggregate_stats = AggregateStats()

    # Set the dict of {'ok': {}}
    aggregate_stats.ok['host0'] = 1
    aggregate_stats.increment('ok', 'host0')
    aggregate_stats.decrement('ok', 'host0')
    assert aggregate_stats.ok['host0'] == 1

    # Set the dict of {'ok': {}}
    aggregate_stats.ok['host1'] = 1
    aggregate_stats.increment('ok', 'host1')
    aggregate_stats.decrement('ok', 'host1')
    assert aggregate_stats.ok['host1'] == 1

# Generated at 2022-06-22 20:17:34.091922
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    from nose import tools as nt

    stats = AggregateStats()
    #add a host with some result
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('failed', 'host1')

    nt.assert_equal(stats.summarize('host1'), {'ok':3, 'failures':1, 'unreachable': 0,
                                               'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0})

# Generated at 2022-06-22 20:17:43.530249
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    a = AggregateStats()
    assert a.custom == {}

    a.set_custom_stats('foo', 'bar')
    assert a.custom == {'_run': {'foo': 'bar'}}

    a.set_custom_stats('baz', 42)
    assert a.custom == {'_run': {'foo': 'bar', 'baz': 42}}

    a.set_custom_stats('baz', 43, 'foo.example.com')
    assert a.custom == {'_run': {'foo': 'bar', 'baz': 42}, 'foo.example.com': {'baz': 43}}

    a.set_custom_stats('nog', dict(a=1, b=2), 'bar.example.com')

# Generated at 2022-06-22 20:17:49.270023
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    # init the object
    result = AggregateStats()
    # call
    result.set_custom_stats("test_which", "test_what", "test_host")
    # assert
    assert all(
        [
            result.custom == {"test_host": {"test_which": "test_what"}},
            result.custom.get("test_host").get("test_which") == "test_what"
        ]
    )


# Generated at 2022-06-22 20:17:53.284148
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    for host in ["host1", "host2", "host3"]:
        for play in range(0, 3):
            for task in range(0, 5):
                stats.increment("ok", host)

    assert stats.ok["host1"] == 5 * 3 and stats.ok["host2"] == 5 * 3 and stats.ok["host3"] == 5 * 3



# Generated at 2022-06-22 20:17:57.021956
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats('key1', 'val1')
    assert aggregate_stats.custom == {'_run': {'key1': 'val1'}}


# Generated at 2022-06-22 20:18:04.249123
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggStats = AggregateStats()
    assert type(aggStats) == AggregateStats
    assert aggStats.processed == {}
    assert aggStats.failures == {}
    assert aggStats.ok == {}
    assert aggStats.dark == {}
    assert aggStats.changed == {}
    assert aggStats.skipped == {}
    assert aggStats.rescued == {}
    assert aggStats.ignored == {}
    assert aggStats.custom == {}

# Unit tests for each of the instance methods

# Generated at 2022-06-22 20:18:07.080905
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')

    assert stats.ok['host1'] == 2
    assert stats.ok['host2'] == 0



# Generated at 2022-06-22 20:18:08.700647
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats is not None

# Generated at 2022-06-22 20:18:14.781288
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import ansible.utils.vars
    import ansible.module_utils.common._collections_compat
    import ansible.runner.aggregate_stats

    stats = ansible.runner.aggregate_stats.AggregateStats()
    ansible.utils.vars.merge_hash = mock.MagicMock()

    # test update_custom_stats when host is _run
    update_custom_stats = ansible.runner.aggregate_stats.AggregateStats.update_custom_stats
    update_custom_stats(stats, 'stats', 'status')
    assert stats.custom['_run'] == {'stats': 'status'}

    # test update_custom_stats when host is not _run
    update_custom_stats(stats, 'stats', 'status', 'host')

# Generated at 2022-06-22 20:18:22.004643
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    '''
        unit test function for method decrement of class AggregateStats
    '''

    aggregate_stats = AggregateStats()
    aggregate_stats.ok = {'test_host': 1}
    aggregate_stats.decrement('ok', 'test_host')
    assert aggregate_stats.ok == {'test_host': 0}, "unit test for method decrement of class AggregateStats failed"


# Unit tests for method decrement of class AggregateStats

# Generated at 2022-06-22 20:18:32.876870
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    st = AggregateStats()
    st.increment('ok', 'host1')
    st.increment('ok', 'host1')
    st.increment('ok', 'host1')
    st.increment('ok', 'host2')
    st.increment('ok', 'host2')
    st.increment('failures', 'host1')
    st.increment('failures', 'host2')
    st.increment('changed', 'host1')
    st.increment('skipped', 'host1')
    st.increment('rescued', 'host2')
    st.increment('ignored', 'host1')
    st.increment('ignored', 'host2')


# Generated at 2022-06-22 20:18:42.519121
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.custom == {}

    aggregate_stats.set_custom_stats('custom_stats', 'foo')
    expected = {'_run': {'custom_stats': 'foo'}}
    assert aggregate_stats.custom == expected

    aggregate_stats.set_custom_stats('custom_stats', 'foo', 'host1')
    expected = {'host1': {'custom_stats': 'foo'}}
    assert aggregate_stats.custom == expected

    aggregate_stats.set_custom_stats('custom_stats', {'foo': 'bar'}, 'host1')
    expected = {'host1': {'custom_stats': {'foo': 'bar'}}}
    assert aggregate_stats.custom == expected


# Generated at 2022-06-22 20:18:46.530467
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement("dark", "example.org")
    assert stats.dark["example.org"] == 0
    stats.increment("dark", "example.org")
    assert stats.dark["example.org"] == 1
    stats.decrement("dark", "example.org")
    assert stats.dark["example.org"] == 0

# Generated at 2022-06-22 20:18:51.319774
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("ok", "host")
    assert stats.processed["host"] == 1
    assert stats.ok["host"] == 1
    stats.increment("ok", "host")
    assert stats.ok["host"] == 2


# Generated at 2022-06-22 20:19:01.775131
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('cpu_used', 50, 'localhost')
    assert stats.custom['localhost']['cpu_used'] == 50
    stats.update_custom_stats('cpu_used', {'clock': 600}, 'localhost')
    assert stats.custom['localhost']['cpu_used'] == {'clock': 600}
    stats.update_custom_stats('cpu_used', 50, 'myhost')
    assert stats.custom['myhost']['cpu_used'] == 50
    stats.update_custom_stats('cpu_used', {'clock': 800}, 'myhost')
    assert stats.custom['myhost']['cpu_used'] == {'clock': 800}
    stats.update_custom_stats('cpu_used', {'clock': 1000}, 'myhost')
   

# Generated at 2022-06-22 20:19:04.702513
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', '127.0.0.1')
    assert stats.processed['127.0.0.1'] == 1
    assert stats.ok['127.0.0.1'] == 1


# Generated at 2022-06-22 20:19:14.161619
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    """
    Test if the function return the expected value
    """
    test = AggregateStats()
    test.ok = {'test_host': 1, 'test_host2': 4}
    test.ok = {'test_host': 2, 'test_host2' : 4}
    test.ok = {'test_host': 3, 'test_host2' : 4}
    test.ok = {'test_host': 4, 'test_host2' : 4}
    test.ok = {'test_host': 5, 'test_host2' : 4}
    test.ok = {'test_host': 6, 'test_host2' : 4}
    test.ok = {'test_host': 7, 'test_host2' : 4}

# Generated at 2022-06-22 20:19:16.426104
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('skipped', 'foo')
    stats.decrement('skipped', 'foo')
    assert stats.skipped['foo'] == 0

# Generated at 2022-06-22 20:19:28.153185
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok['host1'] = 1
    stats.ok['host2'] = 2
    stats.dark['host2'] = 3
    stats.changed['host3'] = 4
    stats.skipped['host3'] = 5
    stats.rescued['host4'] = 6
    stats.ignored['host4'] = 7
    stats.failures['host5'] = 8

    expected = {'host1': {'ok': 1},
                'host2': {'ok': 2, 'unreachable': 3},
                'host3': {'changed': 4, 'skipped': 5},
                'host4': {'rescued': 6, 'ignored': 7},
                'host5': {'failures': 8}}


# Generated at 2022-06-22 20:19:39.960976
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('test_dict', {'a': 1, 'b': 2, 'c': 3})
    assert(stats.custom['_run']['test_dict'] == {'a': 1, 'b': 2, 'c': 3})
    stats.update_custom_stats('test_dict', {'a': 1, 'b': 4, 'd': 5})
    assert(stats.custom['_run']['test_dict'] == {'a': 2, 'b': 6, 'c': 3, 'd': 5})
    stats.update_custom_stats('test_dict', {'x': 1, 'b': 4, 'd': 5})

# Generated at 2022-06-22 20:19:49.341708
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stat = AggregateStats()
    for i in range(1, 101):
        stat.increment("ok", i)
    for i in range(101, 201):
        stat.increment("failures", i)
    for i in range(201, 301):
        stat.increment("dark", i)
    for i in range(301, 401):
        stat.increment("changed", i)
    for i in range(401, 501):
        stat.increment("ignored", i)
    for i in range(501, 601):
        stat.increment("skipped", i)
    for i in range(601, 701):
        stat.increment("rescued", i)
    for i in range(701, 801):
        stat.increment("processed", i)

    assert stat.ok[1]

# Generated at 2022-06-22 20:19:57.738094
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    s = AggregateStats()
    s.update_custom_stats("ok", "123")
    if s.custom["_run"]["ok"] != "123":
        raise Exception("Test failed!")
    s.update_custom_stats("ok", "123")
    if s.custom["_run"]["ok"] != "123":
        raise Exception("Test failed!")
    s.update_custom_stats("ok", "456", "h1")
    if s.custom["h1"]["ok"] != "456":
        raise Exception("Test failed!")
    s.update_custom_stats("ok", "456", "h1")
    if s.custom["h1"]["ok"] != "456":
        raise Exception("Test failed!")

test_AggregateStats_update_custom_stats()

# Generated at 2022-06-22 20:20:06.611351
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    ag_stats = AggregateStats()

    # Test if the custom stat is updated correctly when it is not initialized
    ag_stats.update_custom_stats('my_stat', 1, 'my_host')
    assert ag_stats.custom['_run']['my_stat'] == 1
    ag_stats.update_custom_stats('my_stat', 1, 'my_host')
    assert ag_stats.custom['_run']['my_stat'] == 2

    # Test if the custom stat is updated correctly when it is initialized
    ag_stats.custom['my_host'] = {'my_stat': 10}
    ag_stats.update_custom_stats('my_stat', 1, 'my_host')
    assert ag_stats.custom['_run']['my_stat'] == 2

# Generated at 2022-06-22 20:20:16.800501
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate = AggregateStats()

    # Initial value
    aggregate.update_custom_stats('uptime', 5, host='localhost')
    assert aggregate.custom['localhost']['uptime'] == 5

    # Type mismatch
    aggregate.update_custom_stats('uptime', '5', host='localhost')
    assert aggregate.custom['localhost']['uptime'] == 5

    # Dictionary
    aggregate.update_custom_stats('uptime', {'first': 1, 'second': 2}, host='localhost')
    assert aggregate.custom['localhost']['uptime'] == {'first': 1, 'second': 2}
    aggregate.update_custom_stats('uptime', {'second': 20, 'third': 3}, host='localhost')

# Generated at 2022-06-22 20:20:25.611335
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregateStats = AggregateStats()
    assert aggregateStats.custom == {}
    assert aggregateStats.dark == {}
    assert aggregateStats.skipped == {}
    assert aggregateStats.processed == {}
    assert aggregateStats.ok == {}
    assert aggregateStats.failures == {}
    assert aggregateStats.ignored == {}
    assert aggregateStats.rescued == {}
    assert aggregateStats.changed == {}


# Generated at 2022-06-22 20:20:36.554660
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('stat1', {'key': 'value'})
    assert stats.custom['_run']['stat1'] == {'key': 'value'}
    stats.update_custom_stats('stat2', 'value')
    assert stats.custom['_run']['stat2'] == 'value'
    stats.update_custom_stats('stat3', 1)
    assert stats.custom['_run']['stat3'] == 1
    stats.update_custom_stats('stat1', {'key': 'value2'})
    assert stats.custom['_run']['stat1'] == {'key': 'value2'}
    stats.update_custom_stats('stat2', 'value2')

# Generated at 2022-06-22 20:20:39.435091
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    foo = AggregateStats()
    foo.increment('ok', 'testHost')
    assert foo.ok == {'testHost': 1}, foo.ok
    assert foo.processed == {'testHost': 1}, foo.processed


# Generated at 2022-06-22 20:20:48.378337
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()

    aggregate_stats.ok["toto"] = 1
    aggregate_stats.failures["toto"] = 3
    aggregate_stats.dark["toto"] = 2
    aggregate_stats.changed["toto"] = 4
    aggregate_stats.skipped["toto"] = 5
    aggregate_stats.rescued["toto"] = 6
    aggregate_stats.ignored["toto"] = 7
    aggregate_stats.custom["toto"] = dict(custom_changed=1, custom_ignored=2)

    assert aggregate_stats.ok["toto"] == 1
    assert aggregate_stats.failures["toto"] == 3
    assert aggregate_stats.dark["toto"] == 2
    assert aggregate_stats.changed["toto"] == 4

# Generated at 2022-06-22 20:20:59.328209
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import pytest

    stats = AggregateStats()

    stats.update_custom_stats('up_sub_sub', 6, 'a')
    assert stats.custom['a']['up_sub_sub'] == 6

    stats.update_custom_stats('up_sub_sub', 6, 'b')
    assert stats.custom['b']['up_sub_sub'] == 6

    stats.update_custom_stats('up_sub_sub', 6, 'a')
    assert stats.custom['a']['up_sub_sub'] == 12

    stats.update_custom_stats('up_sub_sub', {'a': 6}, 'a')
    assert stats.custom['a']['up_sub_sub'] == {'a': 6}


# Generated at 2022-06-22 20:21:08.233151
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'localhost')
    assert getattr(aggregate_stats, 'ok')['localhost'] == 1
    aggregate_stats.increment('ok', 'localhost')
    assert getattr(aggregate_stats, 'ok')['localhost'] == 2
    aggregate_stats.increment('ok', 'remotehost')
    assert getattr(aggregate_stats, 'ok')['remotehost'] == 1
    aggregate_stats.increment('skipped', 'remotehost')
    assert getattr(aggregate_stats, 'skipped')['remotehost'] == 1
    aggregate_stats.increment('skipped', 'localhost')
    assert getattr(aggregate_stats, 'skipped')['localhost'] == 1


# Generated at 2022-06-22 20:21:10.394225
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    as1 = AggregateStats()
    assert as1.processed == {}
    assert as1.failures == {}
    assert as1.ok == {}
    assert as1.dark == {}


# Generated at 2022-06-22 20:21:19.367466
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    # Test case for dict which does not have a key.
    def test_key_missing():
        s = AggregateStats()
        s.increment('ok', 'host1')
        s.increment('ok', 'host1')
        s.increment('ok', 'host1')
        s.increment('ok', 'host2')

        s.increment('failures', 'host1')
        s.increment('failures', 'host2')

        s.increment('dark', 'host1')
        s.increment('dark', 'host2')

        s.increment('changed', 'host1')
        s.increment('changed', 'host2')

        s.increment('skipped', 'host1')
        s.increment('skipped', 'host2')


# Generated at 2022-06-22 20:21:25.548832
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg = AggregateStats()
    agg.increment('ok', 'test_host')
    agg.increment('ok', 'test_host')
    assert agg.ok['test_host'] == 2
    agg.decrement('ok', 'test_host')
    assert agg.ok['test_host'] == 1
    agg.decrement('ok', 'test_host')
    assert agg.ok['test_host'] == 0
    # test catching a negative
    agg.decrement('ok', 'test_host')
    assert agg.ok['test_host'] == 0

# Generated at 2022-06-22 20:21:32.458361
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert isinstance(stats.processed, dict)
    assert isinstance(stats.failures, dict)
    assert isinstance(stats.ok, dict)
    assert isinstance(stats.dark, dict)
    assert isinstance(stats.changed, dict)
    assert isinstance(stats.skipped, dict)
    assert isinstance(stats.rescued, dict)
    assert isinstance(stats.ignored, dict)
    assert isinstance(stats.custom, dict)

# Generated at 2022-06-22 20:21:40.756866
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()

    # Set some custom stats
    stats.set_custom_stats('a', 1)
    stats.set_custom_stats('b', 2)
    stats.set_custom_stats('b', 3, 'some_host')
    stats.set_custom_stats('c', {'c_key': 4})

    assert '_run' in stats.custom
    assert stats.custom['_run']['a'] == 1
    assert stats.custom['_run']['b'] == 2
    assert stats.custom['_run']['c'] == {'c_key': 4}
    assert 'some_host' in stats.custom
    assert stats.custom['some_host']['b'] == 3

    # Update some stats
    stats.update_custom_stats('a', 2)
    stats

# Generated at 2022-06-22 20:21:46.829104
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('failures', 'host1')
    aggregate_stats.increment('failures', 'host2')
    aggregate_stats.increment('failures', 'host1')

    assert aggregate_stats.failures['host1'] == 2
    assert aggregate_stats.failures['host2'] == 1


# Generated at 2022-06-22 20:21:49.546778
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('one', 1)
    assert stats.custom['_run']['one'] == 1


# Generated at 2022-06-22 20:21:55.713915
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    test_agg_stats = AggregateStats()
    test_agg_stats.increment("ok", "test_host")
    assert test_agg_stats.ok["test_host"] == 1
    test_agg_stats.increment("ok", "test_host")
    assert test_agg_stats.ok["test_host"] == 2


# Generated at 2022-06-22 20:22:03.569365
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ''' Test the increment method of the class AggregateStats'''

    testcases = [
        {'what': 'ok', 'host': 'localhost'},
        {'what': 'failures', 'host': 'localhost'},
        {'what': 'dark', 'host': 'localhost'},
        {'what': 'changed', 'host': 'localhost'},
        {'what': 'skipped', 'host': 'localhost'},
        {'what': 'rescued', 'host': 'localhost'},
        {'what': 'ignored', 'host': 'localhost'}
    ]

    aggregate_stats = AggregateStats()

    aggregate_stats.increment(what=testcases[0]['what'], host=testcases[0]['host'])

# Generated at 2022-06-22 20:22:13.952211
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()

    # Test when custom stat is a dictionnary
    aggregate_stats.update_custom_stats("test", {'a': 1})
    assert aggregate_stats.custom['_run']['test'] == {'a': 1}

    aggregate_stats.update_custom_stats("test", {'b': 2})
    assert aggregate_stats.custom['_run']['test'] == {'a': 1, 'b': 2}

    aggregate_stats.update_custom_stats("test", {'a': 3})
    assert aggregate_stats.custom['_run']['test'] == {'a': 3, 'b': 2}

    # Test when custom stat is a int
    aggregate_stats.update_custom_stats("test2", 10)

# Generated at 2022-06-22 20:22:20.509860
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggstats = AggregateStats()
    aggstats.ok.update({'testhost': 1, 'testhost1': 2, 'testhost2': 3})
    aggstats.failures.update({'testhost': 1, 'testhost1': 2})
    aggstats.dark.update({'testhost': 1})
    aggstats.changed.update({'testhost': 1, 'testhost1': 2, 'testhost2': 3, 'testhost3': 4})
    aggstats.skipped.update({'testhost': 1, 'testhost3': 2})
    aggstats.rescued.update({'testhost': 1, 'testhost3': 2})
    aggstats.ignored.update({'testhost': 1})

# Generated at 2022-06-22 20:22:31.855247
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    myhost = 'localhost'
    mykey = 'myvalue'
    myvalue = 1
    myrepetition = 3

    stats.update_custom_stats(mykey,myvalue,myhost)
    assert stats.custom[myhost][mykey] == myvalue

    stats.update_custom_stats(mykey,myvalue,myhost)
    assert stats.custom[myhost][mykey] == myvalue + myvalue

    stats.update_custom_stats(mykey,myvalue,myhost)
    assert stats.custom[myhost][mykey] == myvalue + myvalue + myvalue

    for repetition in range(myrepetition):
        stats.update_custom_stats(mykey,myvalue)
        assert stats.custom['_run'][mykey] == myvalue + my

# Generated at 2022-06-22 20:22:34.211269
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    pass


# Generated at 2022-06-22 20:22:41.399867
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    astats = AggregateStats()
    astats.increment('ok', 'localhost')
    astats.increment('ok', 'localhost')
    astats.increment('ok', '127.0.0.1')
    astats.increment('failures', 'localhost')
    astats.increment('ignored', 'localhost')
    astats.increment('ignored', '127.0.0.1')
    astats.increment('dark', 'localhost')
    astats.increment('dark', '127.0.0.1')
    astats.increment('dark', '127.0.0.1')
    astats.increment('dark', '127.0.0.1')
    astats.increment('changed', 'localhost')
    astats.increment('changed', 'localhost')
   

# Generated at 2022-06-22 20:22:47.241532
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('dark', 'testhost')
    assert stats.dark['testhost'] == 1
    stats.increment('dark', 'testhost')
    assert stats.dark['testhost'] == 2
    stats.increment('ok', 'testhost')
    assert stats.ok['testhost'] == 1


# Generated at 2022-06-22 20:22:56.486219
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'foo')
    assert stats.ok['foo'] == 1
    stats.increment('ok', 'foo')
    assert stats.ok['foo'] == 2
    stats.increment('ok', 'foo')
    assert stats.ok['foo'] == 3
    stats.decrement('ok', 'foo')
    assert stats.ok['foo'] == 2
    stats.decrement('ok', 'foo')
    assert stats.ok['foo'] == 1
    stats.decrement('ok', 'foo')
    assert stats.ok['foo'] == 0

# Generated at 2022-06-22 20:23:04.192172
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    as1 = AggregateStats()
    as1.set_custom_stats("db_mode", "single")
    assert as1.custom == {'_run': {'db_mode': 'single'}}
    as1.set_custom_stats("db_mode", "primary")
    assert as1.custom == {'_run': {'db_mode': 'primary'}}
    as1.set_custom_stats("db_mode", "primary", "host1")
    assert as1.custom == {'_run': {'db_mode': 'primary'}, 'host1': {'db_mode': 'primary'}}
    as1.set_custom_stats("db_mode", "secondary", "host2")

# Generated at 2022-06-22 20:23:15.537306
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.utils.vars import combine_vars

    astats = AggregateStats()

    astats.update_custom_stats('a', {'a': {'x': 1000, 'y': 2000}})
    astats.update_custom_stats('a', {'a': {'x': 100, 'z': 300}})
    astats.update_custom_stats('a', {'a': {'x': 10, 'y': 20}})

    # check that 'y' is the sum of original values (2000 + 20)
    assert astats.custom['_run']['a']['a']['y'] == 2020
    # check that 'z' is the sum of original values (300)
    assert astats.custom['_run']['a']['a']['z'] == 300
    #

# Generated at 2022-06-22 20:23:24.257742
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.utils.vars import isidentifier
    stats = AggregateStats()

    stats.update_custom_stats('string', 'string')
    assert stats.custom['_run']['string'] == 'string'

    stats.update_custom_stats('int', 'string')
    assert not isidentifier(stats.custom['_run']['int'])

    stats.update_custom_stats('int', 0)
    assert stats.custom['_run']['int'] == 0

    stats.update_custom_stats('int', 1)
    assert stats.custom['_run']['int'] == 1

    stats.update_custom_stats('int', -1)
    assert stats.custom['_run']['int'] == 0

    stats.update_custom_stats('list', [1])
    assert stats

# Generated at 2022-06-22 20:23:28.523305
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg_stats=AggregateStats()
    agg_stats.set_custom_stats('some_stats','some_value')
    assert agg_stats.custom['_run'] == {'some_stats': 'some_value'}


# Generated at 2022-06-22 20:23:38.400516
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stat = AggregateStats()
    stat.increment("ok", "test")
    stat.increment("ok", "test")
    stat.increment("failures", "test")
    stat.increment("dark", "test")
    stat.increment("changed", "test")
    stat.increment("skipped", "test")
    stat.increment("rescued", "test")
    stat.increment("ignored", "test")

    assert stat.summarize("test") == dict(
        ok=2,
        failures=1,
        unreachable=1,
        changed=1,
        skipped=1,
        rescued=1,
        ignored=1,
    )

# Generated at 2022-06-22 20:23:49.085416
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    import pytest

    stats = AggregateStats()
    stats.increment('ok', 'host0')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host0')
    stats.increment('failures', 'host0')
    stats.increment('failures', 'host2')
    stats.increment('dark', 'host1')
    stats.increment('changed', 'host1')
    stats.increment('changed', 'host1')


# Generated at 2022-06-22 20:23:56.895501
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg = AggregateStats()
    agg.decrement('ok', 'test')
    assert agg.ok['test'] == 0
    agg.ok['test'] = 1
    agg.decrement('ok', 'test')
    assert agg.ok['test'] == 0
    agg.ok['test'] = -1
    agg.decrement('ok', 'test')
    assert agg.ok['test'] == 0


# Generated at 2022-06-22 20:24:05.897044
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    stats.update_custom_stats("stats1", 1)
    assert stats.custom == {'_run': {'stats1': 1}}

    stats.update_custom_stats("stats1", 2)
    assert stats.custom == {'_run': {'stats1': 3}}

    stats.update_custom_stats("stats2", {'a': {'b': [1, 2, 3]}})
    assert stats.custom == {'_run': {'stats1': 3,
                                     'stats2': {'a': {'b': [1, 2, 3]}}}}

    stats.update_custom_stats("stats1", 2)

# Generated at 2022-06-22 20:24:09.141423
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():

    a=AggregateStats()
    a.increment("ok","a")
    assert a.ok["a"] == 1
    assert a.processed["a"] == 1


# Generated at 2022-06-22 20:24:17.102415
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment("ok", "localhost")
    stats.increment("ok", "localhost")
    stats.increment("ok", "localhost")
    stats.increment("failures", "localhost")
    stats.increment("ignored", "localhost")
    stats.increment("changed", "localhost")
    stats.increment("rescued", "localhost")
    stats.increment("dark", "localhost")
    stats.increment("dark", "localhost")
    stats.increment("skipped", "otherhost")
    stats.increment("skipped", "otherhost")
    my_summarized = stats.summarize("localhost")

# Generated at 2022-06-22 20:24:19.187780
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment("ok", "host")
    assert aggregate_stats.ok["host"] == 1
    assert aggregate_stats.processed["host"] == 1


# Generated at 2022-06-22 20:24:23.714407
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    result = AggregateStats()
    result.increment("ok", "host")
    assert dict(ok=dict(host=1)) == result.ok
    assert dict() == result.changed


# Generated at 2022-06-22 20:24:27.544715
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    as_obj = AggregateStats()
    as_obj.set_custom_stats('which', 'what')
    assert as_obj.custom['_run']['which'] == 'what'



# Generated at 2022-06-22 20:24:30.987400
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate = AggregateStats()
    aggregate.increment('ok', 'localhost')
    assert aggregate.ok['localhost'] == 1
    aggregate.increment('processed', 'localhost')
    assert aggregate.processed['localhost'] == 1

# Generated at 2022-06-22 20:24:40.851419
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import unittest

    class TestAggregateStats(unittest.TestCase):
        def setUp(self):
            self.stats = AggregateStats()

        def test_simple_string(self):
            self.stats.update_custom_stats('test_stat', 'this is a test')
            self.assertEqual(self.stats.custom['_run']['test_stat'], 'this is a test')

        def test_string_with_host(self):
            self.stats.update_custom_stats('test_stat', 'this is a test', host='foo')
            self.assertEqual(self.stats.custom['foo']['test_stat'], 'this is a test')

        def test_int(self):
            self.stats.update_custom_stats('test_stat', 1)
            self

# Generated at 2022-06-22 20:24:51.971614
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'server1')
    stats.increment('ok', 'server2')
    assert stats.summarize('server1') == {'ok': 1, 'failures': 0, 'unreachable': 0, 'changed': 0, 'skipped': 0,
                                          'rescued': 0, 'ignored': 0}
    assert stats.summarize('server2') == {'ok': 1, 'failures': 0, 'unreachable': 0, 'changed': 0, 'skipped': 0,
                                          'rescued': 0, 'ignored': 0}

# Generated at 2022-06-22 20:24:57.173044
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'hostname')
    stats.increment('changed', 'hostname')
    assert stats.summarize('hostname') == dict(
        ok=1,
        failures=0,
        unreachable=0,
        changed=1,
        skipped=0,
        rescued=0,
        ignored=0,
    ), "Failed to summarize host statistics"

# Generated at 2022-06-22 20:24:58.647585
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()

    assert isinstance(stats, AggregateStats)