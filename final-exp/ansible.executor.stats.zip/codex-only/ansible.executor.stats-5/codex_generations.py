

# Generated at 2022-06-22 20:15:03.102434
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    s = AggregateStats()
    d = {'a': 1, 'b': 2}
    s.update_custom_stats('count-hash', d, '192.0.2.1')
    assert s.custom['192.0.2.1']['count-hash'] == d

    s.update_custom_stats('count-hash', {'a': 2, 'c': 3}, '192.0.2.1')
    assert s.custom['192.0.2.1']['count-hash'] == {'a': 3, 'b': 2, 'c': 3}

    s.update_custom_stats('count-hash', {'d': 4}, '192.0.2.1')

# Generated at 2022-06-22 20:15:07.431003
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ignored', 'foo')
    assert stats.ignored['foo'] == 0
    stats.increment('ignored', 'foo')
    stats.decrement('ignored', 'foo')
    assert stats.ignored['foo'] == 0
    return True


# Generated at 2022-06-22 20:15:17.208775
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    stats = AggregateStats()
    stats.update_custom_stats("ansible_facts", {"foo": "bar"})
    assert dict(ansible_facts={"foo": "bar"}) == stats.custom["_run"]
    stats.update_custom_stats("ansible_facts", {"foo": "bar-bar"})
    assert dict(ansible_facts={"foo": "bar-bar"}) == stats.custom["_run"]
    stats.update_custom_stats("ansible_facts", {"foo": "bar-bar", "answer": 42})
    assert dict(ansible_facts={"foo": "bar-bar", "answer": 42}) == stats.custom["_run"]
    stats.update_custom_stats("ansible_facts", {"foo": "bar-bar", "answer": 42, "name": "bar"})

# Generated at 2022-06-22 20:15:23.359270
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('value', 20)
    host = '_run'
    assert stats.custom[host]['value'] == 20
    stats.set_custom_stats('value', 30, 'host.name')
    assert stats.custom['host.name']['value'] == 30


# Generated at 2022-06-22 20:15:26.543638
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    # Given
    stats = AggregateStats()
    host = 'host'
    what = 'dark'

    # When
    stats.increment(what, host)

    # Then
    assert stats.processed[host] == 1
    assert stats.dark[host] == 1



# Generated at 2022-06-22 20:15:30.653494
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping
    import sys

    result_passed = True
    # Create a new AggregateStats object
    stats = AggregateStats()

    # test_AggregateStats_update_custom_stats: try to set a custom stat with a string value (should work)
    try:
        stats.update_custom_stats('custom_string', 'my_custom_string')
    except Exception as e:
        result_passed = False
        print("Test case '%s' FAILED: %s" % ('test_AggregateStats_update_custom_stats: try to set a custom stat with a string value (should work)', e))

    # test_AggregateStats_update_custom_stats: try

# Generated at 2022-06-22 20:15:32.609899
# Unit test for constructor of class AggregateStats
def test_AggregateStats():

    stats = AggregateStats()
    assert isinstance(stats, AggregateStats)


# Generated at 2022-06-22 20:15:44.145478
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg_stats = AggregateStats()
    agg_stats.skipped['host1'] = 1
    agg_stats.skipped['host2'] = 2
    agg_stats.skipped['host3'] = None
    agg_stats.skipped['host4'] = None

    # Decrement from 1
    agg_stats.decrement('skipped', 'host1')
    assert agg_stats.skipped['host1'] == 0

    # Decrement from 2
    agg_stats.decrement('skipped', 'host2')
    assert agg_stats.skipped['host2'] == 1

    # Decrement when already 0
    agg_stats.decrement('skipped', 'host1')
    assert agg_stats.skipped['host1'] == 0

    # Decrement when already 0 and key doesn't exist
    agg

# Generated at 2022-06-22 20:15:49.073886
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    ''' Test the update_custom_stats method of class AggregateStats. '''

    ag_stats = AggregateStats()
    ag_stats.update_custom_stats('unreachable_tasks_count', 1)
    assert ag_stats.custom['_run']['unreachable_tasks_count'] == 1

    # Non-MutableMapping type parameter, let overloaded + take care of other types
    ag_stats.update_custom_stats('unreachable_tasks_count', 1)
    assert ag_stats.custom['_run']['unreachable_tasks_count'] == 2

    ag_stats.update_custom_stats('task_dict', {'name': 'test', 'hosts': {'host1': {'ok': 1}}})

# Generated at 2022-06-22 20:15:56.254891
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats() # Instance of class AggregateStats
    stats.set_custom_stats("_result", 42, "localhost") #This is the "return" statement of method set_custom_stats
    assert stats.custom["localhost"] == {"_result": 42}
    stats.update_custom_stats("_result", 43, "localhost") #This is the "return" statement of method update_custom_stats
    assert stats.custom["localhost"] == {"_result": 85}

# Generated at 2022-06-22 20:16:07.267667
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('test_counter', 1)
    stats.update_custom_stats('test_counter', 2)
    stats.update_custom_stats('test_str', 'foo')
    stats.update_custom_stats('test_str', 'foo')
    assert stats.custom['_run'] == {
        'test_counter': 3,
        'test_str': 'foo',
    }
    stats.update_custom_stats('test_dict', {'foo': 'bar'})
    stats.update_custom_stats('test_dict', {'bar': 'foo'})

# Generated at 2022-06-22 20:16:18.719683
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    print(aggregate_stats.summarize('host'))
    print(aggregate_stats.summarize('host1'))
    print(aggregate_stats.summarize('host2'))
    aggregate_stats.increment('ok', 'host')
    aggregate_stats.increment('ok', 'host')
    aggregate_stats.increment('failures', 'host')
    aggregate_stats.increment('dark', 'host')
    aggregate_stats.increment('changed', 'host')
    aggregate_stats.increment('skipped', 'host')
    aggregate_stats.increment('rescued', 'host')
    aggregate_stats.increment('ignored', 'host')
    print(aggregate_stats.summarize('host'))

# Generated at 2022-06-22 20:16:29.221893
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    data = {'failures': {'localhost': 1},
            'ok': {'localhost': 2},
            'dark': {'localhost': 3},
            'changed': {'localhost': 4},
            'skipped': {'localhost': 5},
            'rescued': {'localhost': 6},
            'ignored': {'localhost': 7},
            'custom': {'localhost': {'a': 'b'}}}
    
    stats = AggregateStats()
    stats.failures = data['failures']
    stats.ok = data['ok']
    stats.dark = data['dark']
    stats.changed = data['changed']
    stats.skipped = data['skipped']
    stats.rescued = data['rescued']
    stats.ignored = data['ignored']

# Generated at 2022-06-22 20:16:34.790024
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg = AggregateStats()
    agg.increment('ignored', 'test')
    agg.increment('ok', 'test')
    agg.increment('rescued', 'test')
    assert agg.ok['test'] == 1
    assert agg.ignored['test'] == 1
    assert agg.rescued['test'] == 1



# Generated at 2022-06-22 20:16:45.195065
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Test 1: Test the Overloaded +
    # Test Case 1:
    a = AggregateStats()
    a.update_custom_stats('what', 5, 'host')
    assert (a.custom == {'host': {'what': 5}})
    # Test Case 2:
    a.update_custom_stats('what', 5, 'host')
    assert (a.custom == {'host': {'what': 10}})

    # Test 2: Test a dict
    # Test Case 1:
    a = AggregateStats()
    a.update_custom_stats('what', 5, 'host')
    assert (a.custom == {'host': {'what': 5}})
    # Test Case 2:
    a.update_custom_stats('what', {'what': 5}, 'host')

# Generated at 2022-06-22 20:16:50.510433
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement("ok", "fake_host")
    assert stats.ok["fake_host"] == 0
    stats.decrement("ok", "fake_host")
    assert stats.ok["fake_host"] == 0
    stats.ok["fake_host"] = 1
    stats.decrement("ok", "fake_host")
    assert stats.ok["fake_host"] == 0

# Generated at 2022-06-22 20:17:01.814911
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    astats = AggregateStats()
    astats.update_custom_stats('foo', 1, 'test_host')
    assert astats.custom['test_host']['foo'] == 1
    astats.update_custom_stats('foo', 3, 'test_host')
    assert astats.custom['test_host']['foo'] == 4
    astats.update_custom_stats('foo', dict(a=1, b=2), 'test_host')
    assert astats.custom['test_host']['foo'] == dict(a=1, b=2)
    astats.update_custom_stats('foo', dict(a=4, c=5), 'test_host')
    assert astats.custom['test_host']['foo'] == dict(a=5, b=2, c=5)


# Generated at 2022-06-22 20:17:05.053315
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert(len(stats.custom)==0)

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-22 20:17:09.932736
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    ags = AggregateStats()
    host = '127.0.0.1'

    ags.set_custom_stats('changed', 9, host)
    assert ags.custom[host]['changed'] == 9

    ags.set_custom_stats('failure', 8)
    assert ags.custom['_run']['failure'] == 8



# Generated at 2022-06-22 20:17:20.096528
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    # Initialize a new instance of the class
    aggregate_stats = AggregateStats()

    # Test 1: Try to set a custom stat when 'which' and 'what' are of type string 
    # and 'host' is not specified. It should return None.
    assert aggregate_stats.set_custom_stats('some_stat1', 'some value 1') is None

    # Test 2: Try to set a custom stat when 'which' and 'what' are of type string 
    # and 'host' is specified. It should return None.
    assert aggregate_stats.set_custom_stats('some_stat2', 'some value 2', 'some_host') is None

    # Test 3: Verify that the object contains the expected custom stats.
    assert aggregate_stats.custom['_run'] == {'some_stat1': 'some value 1'}


# Generated at 2022-06-22 20:17:29.716475
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert isinstance(stats.processed, MutableMapping)
    assert isinstance(stats.failures, MutableMapping)
    assert isinstance(stats.ok, MutableMapping)
    assert isinstance(stats.dark, MutableMapping)
    assert isinstance(stats.changed, MutableMapping)
    assert isinstance(stats.skipped, MutableMapping)
    assert isinstance(stats.rescued, MutableMapping)
    assert isinstance(stats.ignored, MutableMapping)
    assert isinstance(stats.custom, MutableMapping)


# Generated at 2022-06-22 20:17:37.952942
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    agg = AggregateStats()
    agg.increment("processed", "test_host")
    agg.increment("ok", "test_host")
    agg.increment("changed", "test_host")
    agg.increment("failures", "test_host")
    agg.increment("dark", "test_host")
    agg.increment("skipped", "test_host")

    result = agg.summarize("test_host") == {'ok': 1, 'failures': 1, 'unreachable': 1, 'changed': 1, 'skipped': 1, 'rescued': 0, 'ignored': 0}
    assert result, "Summarize should return all the values set"

# Generated at 2022-06-22 20:17:43.237325
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ag = AggregateStats()
    print(ag.processed)
    ag.increment('ok', 'host1')
    print(ag.processed)
    print(ag.ok)
    ag.increment('ok', 'host1')
    print(ag.processed)
    print(ag.ok)
    ag.increment('ok', 'host2')
    print(ag.processed)
    print(ag.ok)


# Generated at 2022-06-22 20:17:47.100403
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'all')
    assert stats.ok == {'all': 1}
    stats.increment('ok', 'all')
    assert stats.ok == {'all': 2}


# Generated at 2022-06-22 20:17:50.455672
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg_stats = AggregateStats()
    agg_stats.increment('ok', '127.0.0.1')
    agg_stats.increment('ok', '127.0.0.1')
    return (agg_stats.ok['127.0.0.1'] == 2)


# Generated at 2022-06-22 20:18:02.407629
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.inventory.host import Host
    from ansible.vars.unsafe_proxy import wrap_var
    import sys

    # Test case 1
    stats = AggregateStats()
    stats.update_custom_stats("test_dict", {})
    stats.update_custom_stats("test_dict", { "key1": "value1" })
    stats.update_custom_stats("test_dict", { "key2": "value2" })
    stats.update_custom_stats("test_dict", { "key1": "value3" })

# Generated at 2022-06-22 20:18:06.781065
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', '127.0.0.1')
    assert stats.ok['127.0.0.1'] == 1
    # test decrement
    stats.decrement('ok', '127.0.0.1')
    assert stats.ok['127.0.0.1'] == 0



# Generated at 2022-06-22 20:18:18.715469
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import pytest

    def test_AggregateStats_update_custom_stats_1(capsys):
        '''Tests with dict as values'''
        ags = AggregateStats()
        host = '_run'

        ags.update_custom_stats('dummy1', {'k1': 1, 'k2': 2}, host)
        ags.update_custom_stats('dummy2', {'k1': 10, 'k2': 20, 'k3': 30}, host)
        ags.update_custom_stats('dummy3', {'k4': 40, 'k5': 50, 'k6': 60}, host)

        assert ags.custom[host]['dummy1']['k1'] == 1
        assert ags.custom[host]['dummy1']['k2'] == 2

# Generated at 2022-06-22 20:18:23.484849
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    assert stats.decrement('ok', 'localhost') == 0
    assert stats.ok['localhost'] == 0

    stats.ok['localhost'] = 1
    assert stats.decrement('ok', 'localhost') == 0
    assert stats.ok['localhost'] == 0


# Generated at 2022-06-22 20:18:31.496937
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    """Testing free function test_AggregateStats"""

    oAggregateStats = AggregateStats()
    assert oAggregateStats
    assert oAggregateStats.processed == {}
    assert oAggregateStats.failures == {}
    assert oAggregateStats.ok == {}
    assert oAggregateStats.dark == {}
    assert oAggregateStats.changed == {}
    assert oAggregateStats.skipped == {}
    assert oAggregateStats.rescued == {}
    assert oAggregateStats.ignored == {}
    assert oAggregateStats.custom == {}


# Generated at 2022-06-22 20:18:40.973064
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    stats.increment('ok', 'host1')
    results = {'host1': 1}
    assert stats.ok == results, 'Failed to increment ok for host1'

    stats.increment('ok', 'host2')
    results = {'host2': 1, 'host1': 1}
    assert stats.ok == results, 'Failed to increment ok for host2'

    stats.increment('ok', 'host1')
    results = {'host2': 1, 'host1': 2}
    assert stats.ok == results, 'Failed to increment ok for host1 (second time)'



# Generated at 2022-06-22 20:18:48.844439
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    agg_stats = AggregateStats()

    # Test case 1: update empty custom statistics ('_run' for host none)
    agg_stats.update_custom_stats('test_dict', {'a':1})
    assert agg_stats.custom == {'_run': {'test_dict': {'a': 1}}}

    # Test case 2: update with new value of same type
    agg_stats.update_custom_stats('test_dict', {'a':2})
    assert agg_stats.custom == {'_run': {'test_dict': {'a': 3}}}
    agg_stats.update_custom_stats('test_int', 1)
    assert agg_stats.custom == {'_run': {'test_dict': {'a': 3}, 'test_int': 1}}

    # Test case 3: update with new

# Generated at 2022-06-22 20:18:59.368531
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    a = AggregateStats()
    hosts = ['foo', 'bar']
    a.ok['foo'] = 1
    a.ok['bar'] = 2
    a.failures['foo'] = 3
    a.failures['bar'] = 4
    a.dark['bar'] = 5
    a.changed['foo'] = 6
    for host in hosts:
        assert a.summarize(host)['ok'] == a.ok[host]
        assert a.summarize(host)['failures'] == a.failures[host]
        assert a.summarize(host)['unreachable'] == a.dark.get(host, 0)
        assert a.summarize(host)['changed'] == a.changed.get(host, 0)

# Generated at 2022-06-22 20:19:07.619208
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():

    class TestStats(AggregateStats):
        def __init__(self):
            super(TestStats, self).__init__()
            self.custom = {}

    t = TestStats()

    t.set_custom_stats('foo', 'bar')
    assert t.custom == {'_run': {'foo': 'bar'}}

    t.set_custom_stats('foo', 'baz')
    assert t.custom == {'_run': {'foo': 'baz'}}

    t.set_custom_stats('bar', 'baz')
    assert t.custom == {'_run': {'foo': 'baz', 'bar': 'baz'}}

    t.set_custom_stats('foo', 'bar', 'test')

# Generated at 2022-06-22 20:19:16.033286
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    test_suite = [
        (('test1',10),
         {'_run':
          {'test1': 10}}),
        (('test1',{'a':'a'}),
         {'_run':
          {'test1': {'a': 'a'}}}),
        (('test2',10),
         {'_run':
          {'test1': {'a': 'a'},
           'test2': 10}}),
        (('test1',10,'testhost1'),
        {'testhost1':
          {'test1': 10}}),
        (('test1',10,'testhost2'),
        {'testhost1':
          {'test1': 10},
         'testhost2':
          {'test1': 10}})
    ]

    test = Aggregate

# Generated at 2022-06-22 20:19:27.776543
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    import types

    agg = AggregateStats()
    agg.ok = { "host1":1, "host2":2, "host3":0 }
    agg.failures = { "host1":2, "host2":0, "host3":3 }
    agg.changed = { "host1":0, "host2":2, "host3":0 }
    agg.dark = { "host1":3, "host2":1, "host3":0 }
    agg.skipped = { "host1":0, "host2":0, "host3":2 }
    agg.ignored = { "host1":2, "host2":0, "host3":0 }

    ret_val = agg.summarize('host1')

# Generated at 2022-06-22 20:19:39.506616
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    import nose.plugins.skip
    raise nose.plugins.skip.SkipTest
    #setup test
    aggr = AggregateStats()
    aggr.increment('ok','testhost')
    aggr.increment('ok','testhost')
    aggr.increment('failures','testhost')
    aggr.increment('failures','testhost')
    aggr.increment('ok','secondhost')
    aggr.increment('failures','secondhost')
    #test
    assert aggr.ok['testhost'] == 2
    assert aggr.failures['testhost'] == 2
    assert aggr.ok['secondhost'] == 1
    assert aggr.failures['secondhost'] == 1
    assert aggr.dark['secondhost'] == 1

    #decrement

# Generated at 2022-06-22 20:19:48.952094
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()

    stats.set_custom_stats('a', 1)
    assert(stats.custom == {'_run': {'a': 1}})
    stats.set_custom_stats('b', 2)
    assert(stats.custom == {'_run': {'a': 1, 'b': 2}})
    stats.set_custom_stats('b', 3)
    assert(stats.custom == {'_run': {'a': 1, 'b': 3}})

    stats.set_custom_stats('a', 10, 'hostA')
    assert(stats.custom == {'_run': {'a': 1, 'b': 3}, 'hostA': {'a': 10}})
    stats.set_custom_stats('b', 20, 'hostA')

# Generated at 2022-06-22 20:19:57.576965
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    # object constructor
    test_obj = AggregateStats()
    # test all attributes in constructor are set
    assert test_obj.processed == {}
    assert test_obj.failures == {}
    assert test_obj.ok == {}
    assert test_obj.dark == {}
    assert test_obj.changed == {}
    assert test_obj.skipped == {}
    assert test_obj.rescued == {}
    assert test_obj.ignored == {}
    assert test_obj.custom == {}

# Generated at 2022-06-22 20:20:03.134518
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate = AggregateStats()
    assert aggregate.ok.get('a', None) is None
    aggregate.increment('ok', 'a')
    assert aggregate.ok['a'] == 1
    assert aggregate.processed['a'] == 1
    aggregate.increment('ok', 'a')
    aggregate.increment('ok', 'a')
    assert aggregate.ok['a'] == 3
    assert aggregate.processed['a'] == 1


# Generated at 2022-06-22 20:20:12.467671
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    ag = AggregateStats()
    assert type(ag.processed) == type({})
    assert type(ag.failures) == type({})
    assert type(ag.ok) == type({})
    assert type(ag.dark) == type({})
    assert type(ag.changed) == type({})
    assert type(ag.skipped) == type({})
    assert type(ag.rescued) == type({})
    assert type(ag.ignored) == type({})
    assert type(ag.custom) == type({})



# Generated at 2022-06-22 20:20:18.214764
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ag = AggregateStats()
    ag.increment("ok", "foo")
    ag.increment("failures", "bar")
    ag.increment("ignored", "foo")
    ag.increment("ignored", "bar")
    ag.increment("ignored", "baz")
    assert ag.ok == { "foo": 1 }
    assert ag.failures == { "bar": 1 }
    assert ag.ignored == { "foo": 1, "bar": 1, "baz": 1 }


# Generated at 2022-06-22 20:20:23.358033
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    results = AggregateStats()
    results.dark['host1'] = 1
    results.decrement('dark', 'host1')
    assert results.dark['host1'] == 0


# Generated at 2022-06-22 20:20:25.062380
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    assert(AggregateStats())

# Generated at 2022-06-22 20:20:27.330650
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.__class__ == AggregateStats


# Generated at 2022-06-22 20:20:39.895841
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Test for decrement() method of AggregateStats class
    # Test Case:  Base Case
    # Test Case:  What = ok , Host == '127.0.0.1'
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', '127.0.0.1')
    assert aggregate_stats.ok['127.0.0.1'] == 1
    aggregate_stats.decrement('ok', '127.0.0.1')
    assert aggregate_stats.ok['127.0.0.1'] == 0
    # Test Case:  What = ok , Host == '127.0.0.1', Decrease the value passed the set limit of zero
    aggregate_stats.decrement('ok', '127.0.0.1')

# Generated at 2022-06-22 20:20:50.221490
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    test_stats = AggregateStats()
    test_stats.custom = {'_run': {'test_stat': {'test_sub_stat': 'test_sub_stat_value'}}}
    test_stats.update_custom_stats('test_stat', {'test_sub_stat': 'new_value'})
    assert test_stats.custom['_run']['test_stat']['test_sub_stat'] == 'new_value'

    test_stats.custom = {}
    test_stats.update_custom_stats('test_stat', 'new_value')
    assert test_stats.custom['_run']['test_stat'] == 'new_value'

    test_stats.custom = {}

# Generated at 2022-06-22 20:20:59.532999
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    # Init
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('dark', 'localhost')
    stats.increment('changed', 'localhost')
    stats.increment('skipped', 'localhost')
    stats.increment('rescued', 'localhost')
    stats.increment('ignored', 'localhost')

    # Check
    assert stats.summarize('localhost') == dict(
        ok=1,
        failures=1,
        unreachable=1,
        changed=1,
        skipped=1,
        rescued=1,
        ignored=1,
    )



# Generated at 2022-06-22 20:21:07.106708
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'localhost')
    result = stats.summarize('localhost')
    assert result == {'ok': 0, 'failures': 0, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}
    stats.decrement('ok', 'localhost')
    result = stats.summarize('localhost')
    assert result == {'ok': 0, 'failures': 0, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}


# Generated at 2022-06-22 20:21:15.516715
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats("foo", "bar")
    assert stats.custom == {'_run': {'foo': 'bar'}}
    assert stats.custom["_run"]["foo"] == "bar"

    stats.set_custom_stats("baz", "qux", host="127.0.0.1")
    assert stats.custom == {'_run': {'foo': 'bar'}, '127.0.0.1': {'baz': 'qux'}}
    assert stats.custom["_run"]["foo"] == "bar"
    assert stats.custom["127.0.0.1"]["baz"] == "qux"



# Generated at 2022-06-22 20:21:21.185120
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats() 

    stats.increment('ok', 'test')
    assert stats.ok['test'] == 1

    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 0

    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 0

# Generated at 2022-06-22 20:21:25.277638
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    which = 'test_key'
    what = 'test_val'
    aggregate_stats.set_custom_stats(which, what)
    assert aggregate_stats.custom['_run'][which] == what


# Generated at 2022-06-22 20:21:33.060903
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    x=AggregateStats()

    x.increment("ok", "testhost")
    assert x.ok["testhost"] == 1

    x.increment("ok", "testhost")
    assert x.ok["testhost"] == 2

    x.increment("failures", "testhost")
    x.increment("failures", "testhost")
    assert x.ok["testhost"] == 2
    assert x.failures["testhost"] == 2

    x.increment("failures", "otherhost")
    assert x.failures["otherhost"] == 1



# Generated at 2022-06-22 20:21:41.442935
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    # Test setting custom stats when host is not set
    as1 = AggregateStats()
    as1.set_custom_stats('foo', 'bar')
    assert as1.custom == {'_run': {'foo': 'bar'}}

    # Set the custom stat when the host is set
    as1.set_custom_stats('foo', 'bar2', host='localhost')
    assert as1.custom == {'_run': {'foo': 'bar'}, 'localhost': {'foo': 'bar2'}}
    assert as1.custom['_run'] == {'foo': 'bar'}
    assert as1.custom['localhost'] == {'foo': 'bar2'}

    # Overwrite custom stats for a host, when it is already set

# Generated at 2022-06-22 20:21:52.377817
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    ag_stats = AggregateStats()

    ag_stats.increment('ok', 'host1')
    ag_stats.increment('changed', 'host1')
    ag_stats.increment('changed', 'host1')
    ag_stats.increment('ok', 'host2')
    ag_stats.set_custom_stats('foo', 'bar', host='host1')

    sum1 = ag_stats.summarize('host1')
    assert sum1['ok'] == 1
    assert sum1['changed'] == 2
    assert sum1['unreachable'] == 0
    assert sum1['skipped'] == 0
    assert 'foo' not in sum1

    sum2 = ag_stats.summarize('host2')
    assert sum2['ok'] == 1
    assert sum2['changed'] == 0

# Generated at 2022-06-22 20:21:55.421084
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg = AggregateStats()

    agg.set_custom_stats('foo', 1, host='localhost')
    assert agg.custom['localhost']['foo'] == 1



# Generated at 2022-06-22 20:21:56.827173
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats is not None


# Generated at 2022-06-22 20:21:58.069086
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert(stats is not None)


# Generated at 2022-06-22 20:22:03.456476
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.custom = {}

    aggregate_stats.set_custom_stats('new_key', 'new_value')
    aggregate_stats.set_custom_stats('newer_key', 'newer_value', host='other_host')

    assert len(aggregate_stats.custom) == 2
    assert aggregate_stats.custom['_run'] == {'new_key': 'new_value'}
    assert aggregate_stats.custom['other_host'] == {'newer_key': 'newer_value'}


# Generated at 2022-06-22 20:22:08.308552
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg_stats = AggregateStats()
    agg_stats.increment('ok', 'host1')
    agg_stats.increment('ok', 'host1')
    agg_stats.decrement('ok', 'host1')
    assert agg_stats.ok.get('host1') == 1

# Generated at 2022-06-22 20:22:19.225741
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok = {'host1': 2, 'host2': 1}
    stats.failures = {'host2': 1}
    stats.dark = {'host1': 1}
    stats.changed = {'host1': 1}
    stats.skipped = {'host1': 2}
    stats.rescued = {'host2': 1}
    stats.ignored = {'host1': 1}
    assert stats.summarize('host1') == {'ok': 2, 'failures': 0,
                                        'unreachable': 1, 'changed': 1,
                                        'skipped': 2, 'rescued': 0,
                                        'ignored': 1}

# Generated at 2022-06-22 20:22:25.217725
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggr_stats = AggregateStats()
    aggr_stats.increment('ok', 'host1')
    assert aggr_stats.ok['host1'] == 1
    assert aggr_stats.processed['host1'] == 1

    aggr_stats.increment('ok', 'host2')
    aggr_stats.increment('ok', 'host2')
    assert aggr_stats.ok['host2'] == 2
    assert aggr_stats.processed['host2'] == 1


# Generated at 2022-06-22 20:22:34.610654
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg_stats = AggregateStats()
    # Check that all attributes of AggregateStats intialized
    assert agg_stats.processed
    assert agg_stats.failures
    assert agg_stats.ok
    assert agg_stats.dark
    assert agg_stats.changed
    assert agg_stats.skipped
    assert agg_stats.rescued
    assert agg_stats.ignored
    assert agg_stats.custom

    # Check that all attributes are empty dictionaries
    assert agg_stats.processed == {}
    assert agg_stats.failures == {}
    assert agg_stats.ok == {}
    assert agg_stats.dark == {}
    assert agg_stats.changed == {}
    assert agg_stats.skipped == {}
    assert agg_stats.rescued == {}
    assert agg_stats.ignored == {}


# Generated at 2022-06-22 20:22:38.061211
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok['test_host'] = 1
    stats.decrement('ok', 'test_host')
    assert stats.ok['test_host'] == 0
    stats.decrement('ok', 'test_host')
    assert stats.ok['test_host'] == 0

# Generated at 2022-06-22 20:22:45.199159
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    import json
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('dark', 'localhost')
    stats.increment('dark', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('changed', 'localhost')
    print(json.dumps(stats.summarize('localhost'), indent=4))

# Generated at 2022-06-22 20:22:49.457484
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    host = "testhost"
    stats.increment('ok', host)
    stats.increment('ok', host)
    assert stats.ok[host] == 2
    assert stats.processed[host] == 1


# Generated at 2022-06-22 20:22:55.202280
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()

    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-22 20:23:00.757748
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aset = AggregateStats()
    aset.dark['xyz'] = 3
    aset.decrement('dark', 'xyz')
    assert aset.dark['xyz'] == 2
    aset.decrement('dark', 'xyz')
    assert aset.dark['xyz'] == 1
    aset.decrement('dark', 'xyz')
    assert aset.dark['xyz'] == 0
    aset.decrement('dark', 'xyz')
    assert aset.dark['xyz'] == 0

# Generated at 2022-06-22 20:23:07.731675
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test = AggregateStats()
    test.skipped['localhost'] = 2

    test.decrement('skipped', 'localhost')
    assert test.skipped['localhost'] == 1
    test.decrement('skipped', 'localhost')
    assert test.skipped['localhost'] == 0
    test.decrement('skipped', 'localhost')
    assert test.skipped['localhost'] == 0

# Generated at 2022-06-22 20:23:17.957309
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    from ansible.utils.display import Display
    display = Display()
    agg = AggregateStats()
    agg.increment("ok", "192.168.1.1")
    agg.increment("ok", "192.168.1.1")
    assert agg.ok["192.168.1.1"] == 2

    agg.increment("ok", "192.168.1.2")
    assert agg.ok["192.168.1.2"] == 1
    assert agg.summarize("192.168.1.1")["ok"] == 2

    agg.increment("failures", "192.168.1.3")
    agg.increment("failures", "192.168.1.3")
    assert agg.failures["192.168.1.3"] == 2


# Generated at 2022-06-22 20:23:28.623770
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    stat1 = AggregateStats()
    # test_update_custom_stats_host_absent
    stat1.update_custom_stats('what', 'how', host='_run')
    assert stat1.custom == {'_run': {'what': 'how'}}
    # test_update_custom_stats_field_absent
    stat1.update_custom_stats('what', 'how1', host='_run')
    assert stat1.custom == {'_run': {'what': 'how1'}}
    stat1.update_custom_stats('what', 'how', host='host')
    assert stat1.custom == {'_run': {'what': 'how1'}, 'host': {'what': 'how'}}
    stat1.update_custom_stats('what', 'how1', host='host')


# Generated at 2022-06-22 20:23:33.629188
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()

    stats.set_custom_stats('name', 1)
    stats.set_custom_stats('name', 1, 'server1')
    stats.set_custom_stats('name', 2, 'server2')

    assert stats.custom['_run']['name'] == 1
    assert stats.custom['server1']['name'] == 1
    assert stats.custom['server2']['name'] == 2



# Generated at 2022-06-22 20:23:40.261476
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.processed = {}
    stats.failures = {}
    stats.ok = {}
    stats.dark = {}
    stats.changed = {}
    stats.skipped = {}
    stats.rescued = {}
    stats.ignored = {}

    host = "127.0.0.1"
    stats.increment("ok", host)
    assert stats.ok[host] == 1
    assert stats.processed[host] == 1


# Generated at 2022-06-22 20:23:47.561427
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    """Test method update_custom_stats of class AggregateStats"""
    aggr_stats = AggregateStats()
    aggr_stats.update_custom_stats("int", 3)
    assert aggr_stats.custom["_run"]["int"] == 3
    aggr_stats.update_custom_stats("int", 5)
    assert aggr_stats.custom["_run"]["int"] == 8
    aggr_stats.update_custom_stats("float", 3.14)
    assert aggr_stats.custom["_run"]["float"] == 3.14
    aggr_stats.update_custom_stats("float", 2.71)
    assert aggr_stats.custom["_run"]["float"] == 5.85
    aggr_stats.update_custom_stats("str", "he")

# Generated at 2022-06-22 20:23:56.233227
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()
    host = 'host'

    # process a no-host
    aggregate_stats.increment('ok', 'no-host')
    assert aggregate_stats.ok['no-host'] == 1
    assert aggregate_stats.processed['no-host'] == 1

    # process a host
    aggregate_stats.increment('ok', host)
    assert aggregate_stats.ok[host] == 1
    assert aggregate_stats.processed[host] == 1


# Generated at 2022-06-22 20:24:00.397209
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    assert AggregateStats().summarize('host') == {
        'ok': 0,
        'failures': 0,
        'unreachable': 0,
        'changed': 0,
        'skipped': 0,
        'rescued': 0,
        'ignored': 0
    }

# Generated at 2022-06-22 20:24:08.255672
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok['host_one'] = 1
    stats.ok['host_two'] = 2
    stats.ok['host_three'] = 3

    stats.failures['host_one'] = 1
    stats.failures['host_two'] = 2
    stats.failures['host_three'] = 3

    stats.dark['host_one'] = 1
    stats.dark['host_two'] = 2
    stats.dark['host_three'] = 3

    stats.changed['host_one'] = 1
    stats.changed['host_two'] = 2
    stats.changed['host_three'] = 3

    stats.skipped['host_one'] = 1
    stats.skipped['host_two'] = 2
    stats.skipped['host_three'] = 3

    stats.resc

# Generated at 2022-06-22 20:24:19.363493
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    class MockClass:
        def __init__(self):
            pass

    obj = AggregateStats()
    p = MockClass()
    q = MockClass()
    obj.set_custom_stats("test", p)
    assert obj.custom["_run"]["test"] == p
    obj.update_custom_stats("test", q)
    assert obj.custom["_run"]["test"] == p

    p = dict(a=1, b=2)
    q = dict(a=1, b=2, c=3)
    obj.set_custom_stats("test", p)
    assert obj.custom["_run"]["test"] == p
    obj.update_custom_stats("test", q)

# Generated at 2022-06-22 20:24:23.987613
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    # Check only the case when what is not 'custom'
    s = AggregateStats()
    s.increment('ok', 'host1')
    assert s.ok['host1'] == 1


# Generated at 2022-06-22 20:24:34.675717
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    my_dict = {'a': 1, 'b': 2}
    my_list = ["a","b"]
    host = "localhost"
    aggregate_stats.update_custom_stats("my_dict", my_dict, host)
    aggregate_stats.update_custom_stats("my_list", my_list, host)
    my_dict["c"] = 3
    my_list.append("c")
    aggregate_stats.update_custom_stats("my_dict", my_dict, host)
    aggregate_stats.update_custom_stats("my_list", my_list, host)
    assert aggregate_stats.custom[host]["my_dict"] == {'a': 2, 'b': 4, 'c': 3}

# Generated at 2022-06-22 20:24:42.896961
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():

    stats = AggregateStats()
    stats.set_custom_stats('status', 'passed', 'host1')
    stats.set_custom_stats('status', 'failed', 'host2')
    stats.set_custom_stats('status', 'skipped')
    assert stats.custom == {'host1': {'status': 'passed'}, 'host2': {'status': 'failed'}, '_run': {'status': 'skipped'}}

    stats = AggregateStats()
    stats.set_custom_stats('status', {'passed': 1}, 'host1')
    stats.set_custom_stats('status', {'failed': 1}, 'host2')
    stats.set_custom_stats('status', {'skipped': 1})

# Generated at 2022-06-22 20:24:52.758158
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    # Positive test cases
    assert AggregateStats().set_custom_stats('api_call_count', '10', '_run') == \
        {'_run': {'api_call_count': '10'}}
    assert AggregateStats().set_custom_stats('api_call_count', 10, '_run') == \
        {'_run': {'api_call_count': 10}}

    # Negative test cases
    assert AggregateStats().set_custom_stats('api_call_count', '10', '_run') == \
        {'_run': {'api_call_count': '10'}}
    assert AggregateStats().set_custom_stats('api_call_count', '10', '_run') == \
        {'_run': {'api_call_count': '10'}}

# Generated at 2022-06-22 20:24:58.979364
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host')
    assert stats.summarize('host')['ok'] == 1
    assert stats.summarize('host')['failures'] == 0
    assert stats.summarize('host')['unreachable'] == 0
    assert stats.summarize('host')['changed'] == 0
    assert stats.summarize('host')['skipped'] == 0
    assert stats.summarize('host')['rescued'] == 0
    assert stats.summarize('host')['ignored'] == 0
