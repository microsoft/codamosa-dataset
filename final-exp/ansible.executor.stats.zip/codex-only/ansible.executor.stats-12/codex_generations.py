

# Generated at 2022-06-22 20:15:09.088956
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    test_aggregate_stats = AggregateStats()
    assert isinstance(test_aggregate_stats, AggregateStats)
    assert hasattr(test_aggregate_stats, 'processed')
    assert hasattr(test_aggregate_stats, 'failures')
    assert hasattr(test_aggregate_stats, 'ok')
    assert hasattr(test_aggregate_stats, 'dark')
    assert hasattr(test_aggregate_stats, 'changed')
    assert hasattr(test_aggregate_stats, 'skipped')
    assert hasattr(test_aggregate_stats, 'rescued')
    assert hasattr(test_aggregate_stats, 'ignored')
    assert hasattr(test_aggregate_stats, 'custom')
    assert isinstance(test_aggregate_stats.processed, dict)
   

# Generated at 2022-06-22 20:15:12.543947
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg_stats = AggregateStats()
    agg_stats.ok['localhost'] = 2
    agg_stats.decrement('ok', 'localhost')
    assert agg_stats.ok['localhost'] == 1

# Generated at 2022-06-22 20:15:21.623493
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # dict of dicts
    stats = AggregateStats()
    stats.update_custom_stats("foo", {'a':1, 'b':2})
    assert stats.custom['_run']['foo'] == {'a':1, 'b':2}
    stats.update_custom_stats("foo", {'c':3, 'b':4})
    assert stats.custom['_run']['foo'] == {'a':1, 'b':4, 'c':3}
    stats.update_custom_stats("foo", {'d':5, 'e':6})
    assert stats.custom['_run']['foo'] == {'a':1, 'b':4, 'c':3, 'd':5, 'e':6}

    # list of lists
    stats = AggregateStats()

# Generated at 2022-06-22 20:15:30.621426
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    from ansible.module_utils.six import PY3
    assert PY3  # This test does not work with Python 2.x
    from io import StringIO

    class record(object):
        def __init__(self):
            self.stdout = StringIO()
            self.stderr = StringIO()
            self.rc = 0
            self.changed = False

    class host(object):
        def __init__(self, name):
            self.name = name
            self.records = {'verbose': record(), 'non_verbose': record()}
            self.stderr_lines = []

    # this one is actually the class name of a Host
    class Host:
        pass

    res = AggregateStats()

    # The key is the host name and the value is the type of the stats
    expected

# Generated at 2022-06-22 20:15:38.713588
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Test KeyError
    aggregate_stats = AggregateStats()
    aggregate_stats.ok['test1.example.tld'] = 1
    aggregate_stats.decrement('ok', 'test1.example.tld')
    assert aggregate_stats.ok['test1.example.tld'] == 0

    aggregate_stats.decrement('ok', 'test1.example.tld')
    assert aggregate_stats.ok['test1.example.tld'] == 0


# Generated at 2022-06-22 20:15:40.932576
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert type(stats) is AggregateStats
    assert type(stats.ok) is dict


# Generated at 2022-06-22 20:15:42.447286
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert(isinstance(stats, AggregateStats))

# Generated at 2022-06-22 20:15:49.744466
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from collections import defaultdict
    from ansible.utils.vars import combine_vars

    stats = AggregateStats()
    vars = defaultdict(lambda: defaultdict(bool))
    host = "10.0.0.1"
    # Initialize custom stats
    stats.set_custom_stats("example_custom_stats", {}, host)
    vars[host]["example_custom_stats"] = {}
    # Test primitives
    stats.set_custom_stats("test_int", 1, host)
    vars[host]["test_int"] = 1
    stats.update_custom_stats("test_int", 1, host)
    assert stats.custom[host]["test_int"] == 2
    vars[host]["test_int"] = 2

# Generated at 2022-06-22 20:15:51.277383
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed is not None

# Generated at 2022-06-22 20:15:56.403483
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg = AggregateStats()
    assert len(agg.failures) == 0
    assert len(agg.processed) == 0

    agg.increment('failures', 'foo')
    assert len(agg.failures) == 1
    assert len(agg.processed) == 1
    assert agg.failures['foo'] == 1
    assert agg.processed['foo'] == 1


# Generated at 2022-06-22 20:15:59.441633
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    a = AggregateStats()
    a.increment("ok" , "host")
    assert a.processed["host"] == 1
    assert a.ok["host"] == 1

# Generated at 2022-06-22 20:16:10.381373
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host1')
    stats.increment('failures', 'host1')
    stats.increment('failures', 'host2')
    stats.increment('changed', 'host1')
    stats.increment('dark', 'host1')
    stats.increment('dark', 'host2')
    stats.increment('rescued', 'host1')
    stats.increment('ignored', 'host1')
    stats.increment('ignored', 'host1')
    stats.set_custom_stats('some_key', 'some_value', 'host1')

# Generated at 2022-06-22 20:16:21.190183
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    _AggregateStats = AggregateStats()
    assert not _AggregateStats.decrement('changed', 'testhost')
    _AggregateStats.changed['testhost'] = 1
    assert not _AggregateStats.decrement('changed', 'testhost')
    _AggregateStats.changed['testhost'] = -1
    assert not _AggregateStats.decrement('changed', 'testhost')
    _AggregateStats.changed['testhost'] = 0
    assert not _AggregateStats.decrement('changed', 'testhost')
    _AggregateStats.changed['testhost'] = 1
    assert _AggregateStats.changed['testhost'] == 0
    _AggregateStats.changed['testhost'] = -1
    assert _AggregateStats.changed['testhost'] == 0


# Generated at 2022-06-22 20:16:26.103383
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg_stats = AggregateStats()
    host = 'host1'
    what = 'ok'
    agg_stats.increment(what, host)
    assert agg_stats.ok[host] == 1


# Generated at 2022-06-22 20:16:37.449328
# Unit test for constructor of class AggregateStats
def test_AggregateStats():

    results = AggregateStats()
    results.increment('ok', 'localhost')
    results.increment('ok', 'localhost')
    results.increment('dark', '192.168.99.99')
    results.increment('ok', '192.168.99.99')
    results.increment('ok', '192.168.99.99')
    results.increment('skipped', '192.168.99.99')
    results.increment('skipped', '192.168.99.99')

    assert(results.processed['localhost'] == 1)
    assert(results.processed['192.168.99.99'] == 1)
    assert(results.ok['localhost'] == 2)
    assert(results.ok['192.168.99.99'] == 3)

# Generated at 2022-06-22 20:16:41.534219
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    a = AggregateStats()
    a.update_custom_stats('custom', {'a': 1})
    a.update_custom_stats('custom', {'b': 2})
    assert a.custom['_run']['custom'] == {'a': 1, 'b': 2}

# Generated at 2022-06-22 20:16:52.222199
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import yaml
    statistics = AggregateStats()
    print("Before test (initial statistics)")
    print(statistics)
    # Set a custom stat:
    statistics.set_custom_stats("unifiedpush_push_counts", {
        "Android": {"sent": 0, "failed": 0, "pending": 0, "received": 0},
        "iOS": {"sent": 0, "failed": 0, "pending": 0, "received": 0}
    })
    statistics.set_custom_stats("unifiedpush_push_counts", {
        "Android": {"sent": 1, "failed": 0, "pending": 0, "received": 0},
        "iOS": {"sent": 0, "failed": 0, "pending": 0, "received": 0}
    })

# Generated at 2022-06-22 20:16:55.024914
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggstats = AggregateStats()
    aggstats.increment('ok', 'host123')
    assert aggstats.ok['host123'] == 1


# Generated at 2022-06-22 20:17:06.688738
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()

    res = stats.increment('ok', 'host')
    assert res is None
    assert stats.ok['host'] == 1
    assert stats.processed['host'] == 1
    assert stats.failures.get('host', 0) == 0

    res = stats.increment('failures', 'host')
    assert res is None
    assert stats.processed['host'] == 1
    assert stats.ok.get('host', 0) == 1
    assert stats.failures['host'] == 1

    res = stats.decrement('failures', 'host')
    assert res is None
    assert stats.processed['host'] == 1
    assert stats.ok.get('host', 0) == 1
    assert stats.failures.get('host', 0) == 0

    res = stats.decre

# Generated at 2022-06-22 20:17:16.036517
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', '127.0.0.1')
    assert stats.processed == {'127.0.0.1': 1}
    assert stats.failures == {}
    assert stats.ok == {'127.0.0.1': 1}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}
    stats.increment('failures', '127.0.0.1')
    stats.increment('failures', '127.0.0.1')
    assert stats.processed == {'127.0.0.1': 1}

# Generated at 2022-06-22 20:17:21.417512
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    ast = AggregateStats()
    assert ast.processed == {}
    assert ast.failures == {}
    assert ast.ok == {}
    assert ast.dark == {}
    assert ast.changed == {}
    assert ast.skipped == {}
    assert ast.rescued == {}
    assert ast.ignored == {}
    assert ast.custom == {}


# Generated at 2022-06-22 20:17:33.189312
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggr = AggregateStats()
    # Create a dict to be merged
    dict_to_merge = dict(k1=1, k2=2)
    aggr.update_custom_stats('dict', dict_to_merge)
    assert aggr.custom['_run']['dict'] == dict_to_merge
    # Create a dict to be merged
    dict_to_merge = dict(k1=11, k2=12)
    aggr.update_custom_stats('dict', dict_to_merge)
    assert aggr.custom['_run']['dict'] == dict_to_merge
    # Create a dict to be merged
    dict_to_merge = dict(k1=21, k2=22)
    # Test merge of dict on host 'host1'
    aggr

# Generated at 2022-06-22 20:17:36.784753
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('test_stat', 'test_value', host='test_host')
    assert stats.custom == {'test_host': {'test_stat': 'test_value'}}


# Generated at 2022-06-22 20:17:42.407425
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    # Precondition: no stats
    assert stats.ok.get('testhost', 0) == 0

    # Increment the stats counter
    stats.increment('ok', 'testhost')

    # precondition: stats needs to be set
    assert stats.ok.get('testhost', 0) == 1

    # Decrement the stats counter
    stats.decrement('ok', 'testhost')

    # Postcondition: stats counter is zero
    assert stats.ok.get('testhost', 0) == 0

    # Decrement the stats counter
    stats.decrement('ok', 'testhost')

    # Postcondition: stats counter is still zero
    assert stats.ok.get('testhost', 0) == 0



# Generated at 2022-06-22 20:17:52.154914
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats(which='foo', what=2)
    assert stats.custom['_run']['foo'] == 2
    stats.update_custom_stats(which='foo', what=3)
    assert stats.custom['_run']['foo'] == 5
    stats.update_custom_stats(which='foo', what=2, host='host2')
    assert stats.custom['_run'].get('foo') == 5
    assert stats.custom['host2']['foo'] == 2
    stats.update_custom_stats(which='foo', what=3, host='host2')
    assert stats.custom['host2']['foo'] == 5
    stats.update_custom_stats(which='bar', what={'1': 1, '2': 2})

# Generated at 2022-06-22 20:18:02.001218
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert isinstance(stats.custom, MutableMapping)
    assert isinstance(stats.processed, MutableMapping)
    assert isinstance(stats.failures, MutableMapping)
    assert isinstance(stats.ok, MutableMapping)
    assert isinstance(stats.dark, MutableMapping)
    assert isinstance(stats.changed, MutableMapping)
    assert isinstance(stats.skipped, MutableMapping)
    assert isinstance(stats.rescued, MutableMapping)
    assert isinstance(stats.ignored, MutableMapping)

# Generated at 2022-06-22 20:18:08.200784
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    for k, v in iter(stats.__dict__.items()):
        assert isinstance(v, dict), "AggregateStats property is not a dict %s: %s" % (k, type(v))
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}


# Generated at 2022-06-22 20:18:14.825737
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    stats.ok = {'localhost': 0, '127.0.0.1': 1}

    stats.decrement('ok', 'localhost')
    stats.decrement('ok', '127.0.0.1')
    stats.decrement('ok', '127.0.0.1')

    assert stats.ok == {'localhost': 0, '127.0.0.1': 0}

# Generated at 2022-06-22 20:18:26.716998
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    
    # function to test how the function update_custom_stats works
    # test two kinds of type of variable
    # 1: dictionary
    # 2: integer
    
    # initialize a AggregateStats, will test whether the AggregateStats can 
    # correctly record the information
    stat = AggregateStats()
    
    # initialize the two kinds of variables
    var1 = {'a':1, 'b':2}
    var2 = 1
    
    # test for description
    description1 = 'A description for a test'
    description2 = 'A description for another test'
    
    stat.update_custom_stats(description1, var1)
    stat.update_custom_stats(description2, var2)
    
    # test whether the custom_stat is successfully updated

# Generated at 2022-06-22 20:18:29.589377
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert isinstance(stats.custom, MutableMapping)
    assert isinstance(stats.custom.get("_run", None), MutableMapping)


# Generated at 2022-06-22 20:18:31.900792
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('changed', 'host')
    assert stats.changed['host'] == 1


# Generated at 2022-06-22 20:18:43.432270
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    ag = AggregateStats()
    # dict
    ag.set_custom_stats(which='dict_test', what={'key_1':'value_1'})
    ag.update_custom_stats(which='dict_test', what={'key_2':'value_2'})
    assert('dict_test' in ag.custom['_run'])
    assert(ag.custom['_run']['dict_test'] == {'key_1':'value_1', 'key_2':'value_2'})
    # list
    ag.custom = {}
    ag.set_custom_stats(which='list_test', what=[1])
    ag.update_custom_stats(which='list_test', what=[2])
    assert('list_test' in ag.custom['_run'])

# Generated at 2022-06-22 20:18:46.421271
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    obj = AggregateStats()
    assert not hasattr(obj, '_processed')
    assert not hasattr(obj, '_failures')
    assert not hasattr(obj, '_ok')
    assert not hasattr(obj, '_dark')
    assert not hasattr(obj, '_changed')
    assert not hasattr(obj, '_skipped')
    assert not hasattr(obj, '_rescued')
    assert not hasattr(obj, '_ignored')


# Generated at 2022-06-22 20:18:48.894337
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
  stats = AggregateStats()
  stats.increment('ok', 'host1')
  stats.increment('ok', 'host1')
  stats.decrement('ok', 'host1')
  assert(stats.ok.get('host1', 0) == 1)

# Generated at 2022-06-22 20:18:52.921151
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'example.org')
    assert stats.ok['example.org'] == 1

    stats.decrement('ok', 'example.org')
    assert stats.ok['example.org'] == 0

# Generated at 2022-06-22 20:19:03.103900
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import pytest
    t = AggregateStats()
    t.update_custom_stats("test1", 0)
    assert t.custom["_run"]["test1"] == 0
    t.update_custom_stats("test1", 0)
    assert t.custom["_run"]["test1"] == 0
    t.update_custom_stats("test1", 1)
    assert t.custom["_run"]["test1"] == 1
    t.update_custom_stats("test1", 1)
    assert t.custom["_run"]["test1"] == 2
    t.update_custom_stats("test1", 12)
    assert t.custom["_run"]["test1"] == 14
    t.update_custom_stats("test1", 10)

# Generated at 2022-06-22 20:19:14.054029
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    ags = AggregateStats()
    ags.increment('ok', 'host')
    ags.increment('ok', 'host')
    ags.increment('ok', 'another_host')
    ags.increment('dark', 'host')
    ags.increment('dark', 'host')
    ags.increment('failures', 'host')
    ags.increment('failures', 'host')
    ags.increment('failures', 'host')
    assert ags.summarize('host') == {'ok': 2, 'failures': 3, 'unreachable': 2, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}

# Generated at 2022-06-22 20:19:18.052447
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok == {'localhost': 1}
    stats.decrement('ok', 'localhost')
    assert stats.ok == {'localhost': 0}
    stats.decrement('ok', 'localhost')
    assert stats.ok == {'localhost': 0}

# Generated at 2022-06-22 20:19:30.004608
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # This is a nested dict we will use to update the custom
    # stats with the method update_custom_stats
    nested_dict = dict(
        dict1=dict(a=1,b=2),
        dict2=dict(c=3,d=4)
    )

    stats = AggregateStats()
    stats.set_custom_stats('foo', 0)
    stats.set_custom_stats('bar', nested_dict)

    # Update custom stats with a simple int
    stats.update_custom_stats('foo', 2)
    assert stats.custom['_run']['foo'] == 2

    # Update custom stats with a nested dict (also, passing a host)
    stats.update_custom_stats('bar', nested_dict, host='A')
    assert stats.custom['A']['bar'] == nested_dict

# Generated at 2022-06-22 20:19:35.832002
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    what = {'a': 1, 'b': 2}
    stats.update_custom_stats('custo', what)

    assert '_run' in stats.custom
    assert 'custo' in stats.custom['_run']
    assert stats.custom['_run']['custo'] == what

    what = {'b': 3, 'c': 4}
    stats.update_custom_stats('custo', what)

    assert stats.custom['_run']['custo'] == {'a': 1, 'b': 3, 'c': 4}

    what = 5
    stats.update_custom_stats('custo', what)


# Generated at 2022-06-22 20:19:44.525322
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    # Initialize a new object of class AggregateStats
    s = AggregateStats()

    # Create an Array with a mocked dictionary
    attrs = ['ok', 'failures', 'dark', 'changed', 'skipped',
             'rescued', 'ignored']

    # Populate the array with mocked dicts
    for k in attrs:
        d = {'host': 0}
        setattr(s, k, d)

    # Decrement all
    for stat in attrs:
        s.decrement(stat, 'host')

    # Check the result
    for k in attrs:
        assert (getattr(s, k))['host'] == 0


# Generated at 2022-06-22 20:19:47.089638
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('cowbell', 'more', 'example.org')
    assert stats.custom['example.org']['cowbell'] == 'more'



# Generated at 2022-06-22 20:19:54.622875
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('failures', 'host1')
    expected = dict(
        ok=3,
        failures=1,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0,
    )
    assert stats.summarize('host1') == expected
    assert stats.summarize('host2') == expected

# Generated at 2022-06-22 20:20:01.288921
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg_stats = AggregateStats()
    agg_stats.set_custom_stats('foo', 'bar')
    assert agg_stats.custom['_run']['foo'] == 'bar'
    agg_stats.set_custom_stats('foo', 'bar', 'some_host')
    assert agg_stats.custom['some_host']['foo'] == 'bar'
    agg_stats.set_custom_stats('foo', 'baz', 'some_host')
    assert agg_stats.custom['some_host']['foo'] == 'baz'

# Generated at 2022-06-22 20:20:05.719333
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    ags = AggregateStats()
    assert ags.custom == {}
    assert ags.processed == {}
    assert ags.failures == {}
    assert ags.ok == {}
    assert ags.dark == {}
    assert ags.changed == {}
    assert ags.skipped == {}
    assert ags.rescued == {}
    assert ags.ignored == {}

# Generated at 2022-06-22 20:20:14.001015
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok['host1'] = 1
    stats.ok['host2'] = 0
    stats.ok['host3'] = 1
    stats.failures['host2'] = 1
    stats.failures['host3'] = 0
    stats.failures['host4'] = 1
    stats.dark['host1'] = 1
    stats.dark['host2'] = 0
    stats.dark['host5'] = 1
    stats.changed['host1'] = 1
    stats.changed['host2'] = 0
    stats.changed['host6'] = 1
    stats.skipped['host2'] = 1
    stats.skipped['host3'] = 0
    stats.skipped['host7'] = 1
    stats.rescued['host3'] = 1

# Generated at 2022-06-22 20:20:18.244872
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    print('Testing decrement')
    stats = AggregateStats()
    stats.ok['test_host'] = 0
    stats.decrement('ok', 'test_host')
    print('Test was successful')

# Test for decrement method of class AggregateStats
if __name__ == '__main__':
    test_AggregateStats_decrement()
    print('All tests completed successfully')

# Generated at 2022-06-22 20:20:28.775182
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    a = AggregateStats()
    a.update_custom_stats('name', 10)
    assert a.custom == {'_run': {'name': 10}}
    a.update_custom_stats('name2', {'key': 'val'})
    assert a.custom == {'_run': {'name': 10, 'name2': {'key': 'val'}}}
    a.update_custom_stats('name3', 'val3')
    assert a.custom == {'_run': {'name': 10, 'name2': {'key': 'val'}, 'name3': 'val3'}}
    a.update_custom_stats('name', 10, 'host')

# Generated at 2022-06-22 20:20:32.083158
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host')
    assert stats.ok['host'] == 1


# Generated at 2022-06-22 20:20:43.421550
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    from copy import deepcopy

    # Initial case - empty custom variable
    as_s = AggregateStats()
    as_s.update_custom_stats("key", "value")
    assert as_s.custom == {"_run": {"key": "value"}}

    # Existing keys - overwriting
    as_s.update_custom_stats("key", "value")
    assert as_s.custom == {"_run": {"key": "value"}}

    # New keys
    as_s.update_custom_stats("key2", "value2")
    assert as_s.custom == {"_run": {"key": "value", "key2": "value2"}}

    # Merge of dictionaries
    d_a = {"key3": "value3"}

# Generated at 2022-06-22 20:20:50.419494
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}, stats.processed
    assert stats.failures == {}, stats.failures
    assert stats.ok == {}, stats.ok
    assert stats.dark == {}, stats.dark
    assert stats.changed == {}, stats.changed
    assert stats.skipped == {}, stats.skipped
    assert stats.rescued == {}, stats.rescued
    assert stats.ignored == {}, stats.ignored
    assert stats.custom == {}, stats.custom



# Generated at 2022-06-22 20:20:51.634137
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()


# Generated at 2022-06-22 20:20:54.143409
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'


# Generated at 2022-06-22 20:21:05.257090
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    s = AggregateStats()
    s.increment('ok', '127.0.0.1')
    s.increment('failures', '127.0.0.1')
    s.increment('dark', '127.0.0.1')
    s.increment('changed', '127.0.0.1')
    s.increment('skipped', '127.0.0.1')
    s.increment('rescued', '127.0.0.1')
    s.increment('ignored', '127.0.0.1')

    s.increment('ok', '192.168.0.1')
    s.increment('failures', '192.168.0.1')

    summarise = s.summarize('127.0.0.1')
    assert summarise

# Generated at 2022-06-22 20:21:15.026764
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import types

    stats = AggregateStats()
    stats.update_custom_stats('foo', 20)
    assert stats.custom['_run']['foo'] == 20

    stats.update_custom_stats('foo', [30])
    assert stats.custom['_run']['foo'] == [30]

    stats.update_custom_stats('foo', [30])
    assert stats.custom['_run']['foo'] == [30, 30]

    stats.update_custom_stats('foo', {'x': 'bar'})
    assert stats.custom['_run']['foo'] == {'x': 'bar'}

    stats.update_custom_stats('foo', {'x': 'baz'})
    assert stats.custom['_run']['foo'] == {'x': 'baz'}

   

# Generated at 2022-06-22 20:21:17.022226
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():

    assert AggregateStats().summarize(None) == dict(ok=0, failures=0, unreachable=0, changed=0, skipped=0, rescued=0, ignored=0)

# Generated at 2022-06-22 20:21:26.074000
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('dark', 'localhost')
    stats.increment('changed', 'localhost')
    stats.increment('skipped', 'localhost')
    stats.increment('rescued', 'localhost')
    stats.increment('ignored', 'localhost')

    summary = stats.summarize('localhost')
    assert summary['ok'] == 2
    assert summary['failures'] == 1
    assert summary['unreachable'] == 1
    assert summary['changed'] == 1
    assert summary['skipped'] == 1
    assert summary['rescued'] == 1
    assert summary['ignored'] == 1

# Generated at 2022-06-22 20:21:30.049209
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    a = AggregateStats()
    assert a.processed == {}
    assert a.failures == {}
    assert a.ok == {}
    assert a.dark == {}
    assert a.changed == {}
    assert a.skipped == {}
    assert a.rescued == {}
    assert a.ignored == {}
    assert a.custom == {}


# Generated at 2022-06-22 20:21:31.478116
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats_object = AggregateStats()
    assert aggregate_stats_object != None

# Generated at 2022-06-22 20:21:38.187948
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert type(stats.processed) == type({})
    assert type(stats.failures) == type({})
    assert type(stats.ok) == type({})
    assert type(stats.dark) == type({})
    assert type(stats.changed) == type({})
    assert type(stats.skipped) == type({})
    assert type(stats.rescued) == type({})
    assert type(stats.ignored) == type({})
    assert type(stats.custom) == type({})


# Generated at 2022-06-22 20:21:49.898680
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    agg = AggregateStats()

    # Addition of regular fields
    assert agg.custom == {}
    agg.update_custom_stats("foo", 10)
    assert agg.custom == {'_run': {'foo': 10}}
    agg.update_custom_stats("foo", 20)
    assert agg.custom == {'_run': {'foo': 30}}

    # Addition of nested fields
    agg.update_custom_stats("bar", { "a": 1 })
    assert agg.custom == {'_run': {'foo': 30, 'bar': {'a': 1}}}
    agg.update_custom_stats("bar", { "b": 2 })
    assert agg.custom == {'_run': {'foo': 30, 'bar': {'a': 1, 'b': 2}}}

    # Addition of string fields


# Generated at 2022-06-22 20:21:54.063912
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    a = AggregateStats()
    a.increment("dark", "localhost")
    assert a.dark["localhost"] == 1
    assert a.processed["localhost"] == 1


# Generated at 2022-06-22 20:21:59.281034
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('test', 'bar', host='foo')
    assert stats.custom == {'foo': {'test': 'bar'}}
    stats.set_custom_stats('test', 'foo')
    assert stats.custom == {'foo': {'test': 'bar'}, '_run': {'test': 'foo'}}
    return True


# Generated at 2022-06-22 20:22:00.852731
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('http_status_code', 403, 'host1')
    assert stats.custom['host1']['http_status_code'] == 403


# Generated at 2022-06-22 20:22:05.076680
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    #assert True
    stats = AggregateStats()
    stats.ok['host'] = 1
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 0
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 0


# Generated at 2022-06-22 20:22:08.498217
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test_stats = AggregateStats()
    test_stats.ok['test_host'] = 1
    test_stats.decrement('ok', 'test_host')
    assert test_stats.ok['test_host'] == 0



# Generated at 2022-06-22 20:22:19.403126
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('test_key', 1, 'test_host')
    # Adding new key and set to value 1
    assert stats.custom == {'test_host': {'test_key': 1}}

    # Updating 'test_key' value 1 to 2, and set to 2
    stats.update_custom_stats('test_key', 1, 'test_host')
    assert stats.custom == {'test_host': {'test_key': 2}}

    # Updating 'test_key' value integer 2 to boolean True, and set to 2
    stats.update_custom_stats('test_key', True, 'test_host')
    # Custom stats is not updated, because the type of value is not same.

# Generated at 2022-06-22 20:22:28.267345
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    '''
    test case:
    run 1 hosts: host1, host2, host3
    run 2 hosts: host1, host2, host3, host4
    '''
    stats = [AggregateStats(), AggregateStats()]
    hosts = ['host1', 'host2', 'host3', 'host4']
    stats[0].increment('ok', hosts[0])
    stats[0].increment('ok', hosts[1])
    stats[0].increment('ok', hosts[2])
    stats[0].increment('dark', hosts[1])
    stats[1].increment('ok', hosts[0])
    stats[1].increment('ok', hosts[1])
    stats[1].increment('ok', hosts[2])
    stats[1].increment('ok', hosts[3])

   

# Generated at 2022-06-22 20:22:37.766862
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()

    stats.set_custom_stats("test", "test", None)
    assert("_run" in stats.custom)
    assert("test" in stats.custom["_run"])
    assert(stats.custom["_run"]["test"] == "test")

    test_dict = {"test2": "test2"}
    stats.set_custom_stats("test", test_dict, None)
    assert("_run" in stats.custom)
    assert("test" in stats.custom["_run"])
    assert(stats.custom["_run"]["test"] == test_dict)

    stats.set_custom_stats("test", "test", "host")
    assert("host" in stats.custom)
    assert("test" in stats.custom["host"])

# Generated at 2022-06-22 20:22:40.574443
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    """
    Basic unit test for the AggregateStats.decrement method.
    """
    a = AggregateStats()
    a.decrement('ok', 'host')
    assert a.ok['host'] == 0


# Generated at 2022-06-22 20:22:52.020844
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    # Perform a simple unit test for class AggregateStats,
    # simply to ensure that all of it's fields are created
    # properly and at least one of those fields has expected
    # values.
    stats = AggregateStats()
    assert type(stats.processed) == type({})
    assert stats.processed == {}
    assert type(stats.failures) == type({})
    assert stats.failures == {}
    assert type(stats.ok) == type({})
    assert stats.ok == {}
    assert type(stats.dark) == type({})
    assert stats.dark == {}
    assert type(stats.changed) == type({})
    assert stats.changed == {}
    assert type(stats.skipped) == type({})
    assert stats.skipped == {}

# Generated at 2022-06-22 20:22:57.064947
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    ''' test setting of a custom stat'''
    host = 'test'
    stat = AggregateStats()
    stat.set_custom_stats('test_key', 'test_val', host)
    assert stat.custom[host]['test_key'] == 'test_val'


# Generated at 2022-06-22 20:23:04.515726
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    a = AggregateStats()
    a.increment("ok", "1.2.3.4")
    a.increment("ok", "1.2.3.4")
    a.increment("ok", "1.2.3.4")
    a.increment("changed", "1.2.3.4")
    a.increment("failures", "1.2.3.4")
    a.increment("unreachable", "1.2.3.4")

    res = a.summarize("1.2.3.4")

    assert res['ok'] == 3
    assert res['failures'] == 1
    assert res['unreachable'] == 1

if __name__ == '__main__':
    import sys
    import nose

# Generated at 2022-06-22 20:23:15.117269
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    as_ = AggregateStats()
    as_.increment('ok', 'host1')
    as_.increment('changed', 'host1')
    as_.increment('changed', 'host2')
    as_.increment('skipped', 'host2')
    as_.increment('dark', 'host3')
    as_.increment('rescued', 'host3')

    expected = {'ok': 1,
                'failures': 0,
                'unreachable': 1,
                'changed': 1,
                'skipped': 1,
                'rescued': 1,
                'ignored': 0}

    assert as_.summarize('host1') == expected
    assert as_.summarize('unknown') == expected

# Generated at 2022-06-22 20:23:19.900299
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats('foo', 'bar', 'host1')
    assert aggregate_stats.custom == {'host1': {'foo': 'bar'}}
    aggregate_stats.set_custom_stats('foo', 'bar')
    assert aggregate_stats.custom == {'host1': {'foo': 'bar'}, '_run': {'foo': 'bar'}}


# Generated at 2022-06-22 20:23:24.516897
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate = AggregateStats()
    assert aggregate.processed == {}
    assert aggregate.failures == {}
    assert aggregate.ok == {}
    assert aggregate.dark == {}
    assert aggregate.changed == {}
    assert aggregate.skipped == {}
    assert aggregate.rescued == {}
    assert aggregate.ignored == {}
    assert aggregate.custom == {}


# Generated at 2022-06-22 20:23:35.297534
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment("ok", "192.168.1.1")
    stats.increment("ok", "192.168.1.1")
    stats.increment("ok", "192.168.1.2")
    result = stats.summarize("192.168.1.1")
    assert result == {'ok': 2, 'failures': 0, 'unreachable': 0,
                      'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}
    stats.increment("ok", "192.168.1.2")
    stats.increment("changed", "192.168.1.2")
    result = stats.summarize("192.168.1.2")

# Generated at 2022-06-22 20:23:45.268869
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    aggregate_stats.ok['host1'] = 3
    aggregate_stats.failures['host1'] = 2
    aggregate_stats.dark['host1'] = 1
    aggregate_stats.changed['host1'] = 2
    aggregate_stats.skipped['host1'] = 0
    aggregate_stats.rescued['host1'] = 0
    aggregate_stats.ignored['host1'] = 0

    assert aggregate_stats.summarize('host1') == {
        'ok': 3,
        'failures': 2,
        'unreachable': 1,
        'changed': 2,
        'skipped': 0,
        'rescued': 0,
        'ignored': 0,
    }


# Generated at 2022-06-22 20:23:57.389247
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment("ok", "foo")
    stats.increment("ok", "foo")
    stats.increment("ok", "bar")
    stats.increment("failures", "foo")
    stats.increment("dark", "foo")
    stats.increment("changed", "foo")
    stats.increment("skipped", "foo")
    stats.increment("rescued", "foo")
    stats.increment("ignored", "foo")

    expected = dict(
        ok=2,
        failures=1,
        unreachable=1,
        changed=1,
        skipped=1,
        rescued=1,
        ignored=1,
    )

    assert stats.summarize("foo") == expected


# Generated at 2022-06-22 20:23:59.800724
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    print("TESTING AggregateStats decrement")
    from nose.plugins.skip import SkipTest
    raise SkipTest


# Generated at 2022-06-22 20:24:11.983036
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    # simulate call to __init__
    stats = {
        'processed': {},
        'failures': {},
        'ok': {},
        'dark': {},
        'changed': {},
        'skipped': {},
        'rescued': {},
        'ignored': {},
        'custom': {}
    }

    for host in ['host1', 'host2']:
        for attr in ['ok', 'failures', 'dark', 'changed', 'skipped', 'rescued', 'ignored']:
            stats[attr][host] = 1

    agg_stats = AggregateStats()

    for attr in stats:
        setattr(agg_stats, attr, stats[attr])

    res = agg_stats.summarize('host1')


# Generated at 2022-06-22 20:24:18.534138
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    s = AggregateStats()
    assert s.ok == {}
    s.increment('ok', 'host1')
    s.increment('ok', 'host2')
    s.increment('ok', 'host1')
    assert s.ok['host1'] == 2
    assert s.ok['host2'] == 1
    s.decrement('ok', 'host1')
    assert s.ok['host1'] == 1
    s.decrement('ok', 'host1')
    assert s.ok['host1'] == 0
    assert len(s.ok) == 2
    s.decrement('ok', 'host1')
    assert s.ok['host1'] == 0
    s.decrement('ok', 'host2')
    assert s.ok['host2'] == 0

# Generated at 2022-06-22 20:24:21.021873
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    expected = {'processed': {}, 'failures': {}, 'ok': {}, 'dark': {}, 'changed': {}, 'skipped': {}, 'rescued': {}, 'ignored': {}, 'custom': {}}
    assert AggregateStats().__dict__ == expected


# Generated at 2022-06-22 20:24:28.344084
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg_stats = AggregateStats()
    agg_stats.ok['some_host'] = 1
    agg_stats.decrement('ok', 'some_host')
    assert agg_stats.ok['some_host'] == 0
    # Test the case where decrement makes the value negative
    agg_stats.decrement('ok', 'some_host')
    assert agg_stats.ok['some_host'] == 0

# Generated at 2022-06-22 20:24:38.759277
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg_stats = AggregateStats()
    agg_stats.set_custom_stats('test_key', 'test_value')
    assert agg_stats.custom['_run']['test_key'] == 'test_value'
    assert 'test_key' in agg_stats.custom['_run']
    agg_stats.set_custom_stats('test_key', 'test_value_1', 'test_hostname')
    assert agg_stats.custom['test_hostname']['test_key'] == 'test_value_1'
    assert 'test_key' in agg_stats.custom['test_hostname']


# Generated at 2022-06-22 20:24:46.191798
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    test = AggregateStats()
    test.increment('ok', 's1')
    test.increment('ok', 's1')
    test.increment('ok', 's2')
    test.increment('ok', 's2')

    assert test.ok['s1'] == 2
    assert test.ok['s2'] == 2


# Generated at 2022-06-22 20:24:55.879549
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    '''
    Unit test for method update_custom_stats of class AggregateStats
    '''
    agg_stats = AggregateStats()
    agg_stats.update_custom_stats('a_stats', 4, '_run')
    agg_stats.update_custom_stats('a_stats', 2, '_run')
    assert agg_stats.custom['_run']['a_stats'] == 6

    agg_stats.update_custom_stats('b_stats', 'snake')
    agg_stats.update_custom_stats('b_stats', 'fish')
    assert agg_stats.custom['_run']['b_stats'] == 'snakefish'

    agg_stats.update_custom_stats('c_stats', [1, 2], 'c_host')

# Generated at 2022-06-22 20:25:06.988015
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    aggregate_stats.ok = {'host1': 10}
    aggregate_stats.failures = {'host1': 1}
    aggregate_stats.dark = {'host1': 3}
    aggregate_stats.changed = {'host1': 5}
    aggregate_stats.skipped = {'host1': 4}
    aggregate_stats.rescued = {'host1': 2}
    aggregate_stats.ignored = {'host1': 6}
    summary = aggregate_stats.summarize('host1')
    assert summary['ok'] == 10
    assert summary['failures'] == 1
    assert summary['unreachable'] == 3
    assert summary['changed'] == 5
    assert summary['skipped'] == 4
    assert summary['rescued'] == 2