

# Generated at 2022-06-22 20:15:03.444137
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    from ansible.playbook.play import Play
    aggregated_stats_summarize = AggregateStats()
    aggregated_stats_summarize.ok = {Play().hosts[0]:2}
    aggregated_stats_summarize.failures = {Play().hosts[0]:1}
    aggregated_stats_summarize.dark = {Play().hosts[0]:1}
    aggregated_stats_summarize.changed = {Play().hosts[0]:1}
    assert aggregated_stats_summarize.summarize(Play().hosts[0]) == {'ok':2, 'failures':1, 'unreachable':1, 'changed':1, 'skipped':0, 'rescued':0, 'ignored':0}

# Generated at 2022-06-22 20:15:06.784394
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    stats.increment('ok','host')

    stats.ok == {'host': 1}

    stats.increment('ok','host')

    stats.ok == {'host': 2}


# Generated at 2022-06-22 20:15:16.713505
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    agg = AggregateStats()
    host = 'testhost'
    agg.increment('ok', host)
    agg.increment('ok', host)
    agg.increment('ok', host)
    agg.increment('failures', host)
    agg.increment('failures', host)
    agg.increment('dark', host)
    agg.increment('changed', host)
    agg.increment('skipped', host)
    agg.increment('rescued', host)
    agg.increment('ignored', host)

# Generated at 2022-06-22 20:15:28.142249
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stat = AggregateStats()
    stat.increment('ok', 'host1')
    stat.increment('ok', 'host1')
    stat.increment('ok', 'host1')
    stat.increment('failures', 'host1')
    stat.increment('changed', 'host1')
    stat.increment('skipped', 'host1')
    stat.increment('rescued', 'host1')
    stat.increment('ignored', 'host1')
    stat.increment('ok', 'host2')
    stat.increment('ok', 'host2')
    stat.increment('failures', 'host2')
    stat.increment('dark', 'host3')
    stat.increment('ok', 'host3')

    # Check normal case

# Generated at 2022-06-22 20:15:36.579019
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    '''unit tests for aggregate stats'''

    from nose.tools import assert_equals

    aggregate_stats = AggregateStats()

    aggregate_stats.increment('ok', 'myhost')
    assert_equals(aggregate_stats.ok['myhost'], 1)
    aggregate_stats.increment('changed', 'myhost')
    assert_equals(aggregate_stats.changed['myhost'], 1)
    aggregate_stats.increment('skipped', 'myhost')
    assert_equals(aggregate_stats.skipped['myhost'], 1)
    aggregate_stats.increment('rescued', 'myhost')
    assert_equals(aggregate_stats.rescued['myhost'], 1)
    aggregate_stats.increment('ignored', 'myhost')
    assert_equals

# Generated at 2022-06-22 20:15:43.917378
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()
    assert len(aggregate_stats.processed) == 0
    assert len(aggregate_stats.failures) == 0
    assert len(aggregate_stats.ok) == 0
    assert len(aggregate_stats.dark) == 0
    assert len(aggregate_stats.changed) == 0
    assert len(aggregate_stats.skipped) == 0
    assert len(aggregate_stats.rescued) == 0
    assert len(aggregate_stats.ignored) == 0
    assert len(aggregate_stats.custom) == 0


# Generated at 2022-06-22 20:15:47.820125
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    target = AggregateStats()
    target.set_custom_stats('test', {'success': 3, 'failure': 2})
    assert target.custom['_run']['test'] == {'success': 3, 'failure': 2}



# Generated at 2022-06-22 20:15:53.425813
# Unit test for constructor of class AggregateStats
def test_AggregateStats():

    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-22 20:15:57.432379
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host_fake')
    assert stats.ok.get('host_fake') == 1
    stats.increment('ok', 'host_fake')
    assert stats.ok.get('host_fake') == 2

# Generated at 2022-06-22 20:16:08.042680
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggStats = AggregateStats()
    aggStats.update_custom_stats(which="test", what={'x':1}, host="foo")
    aggStats.update_custom_stats(which="test", what={'y':2}, host="foo")
    assert aggStats.custom == {'foo': {'test': {'x': 1, 'y': 2}}}
    aggStats.update_custom_stats(which="test", what={'z':3})
    assert aggStats.custom == {'foo': {'test': {'x': 1, 'y': 2}}, '_run': {'test': {'z': 3}}}
    aggStats.update_custom_stats(which="test", what=4, host="foo")

# Generated at 2022-06-22 20:16:17.195820
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggr = AggregateStats()
    aggr.ok = {'host1': 1, 'host3': 2, 'host4': 0, 'host5': 3}
    aggr.decrement('ok', 'host1')
    assert aggr.ok['host1'] == 0
    aggr.decrement('ok', 'host3')
    assert aggr.ok['host3'] == 1
    aggr.decrement('ok', 'host5')
    assert aggr.ok['host5'] == 2

if __name__ == "__main__":
    test_AggregateStats_decrement()

# Generated at 2022-06-22 20:16:25.433536
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Create test object
    stat = AggregateStats()
    stat.update_custom_stats("foo", {})
    stat.update_custom_stats("foo", {'bar': 1, 'baz': 2})
    stat.update_custom_stats("foo", {'bar': 3})
    stat.update_custom_stats("foo", {'biz': 5})

    # Verify the data integrity
    assert stat.custom == {'_run': {'foo': {'bar': 3, 'baz': 2, 'biz': 5}}}

    stat.update_custom_stats("bar", 1)
    stat.update_custom_stats("bar", 2)
    stat.update_custom_stats("bar", 3)

    # Verify the data integrity

# Generated at 2022-06-22 20:16:34.937995
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    '''
    test_AggregateStats_decrement: decrement a stat and make sure it is decremented
    '''
    jake = AggregateStats()
    jake.increment("ok", '127.0.0.1')
    assert jake.ok['127.0.0.1'] == 1

    # decrement by 1
    jake.decrement('ok', '127.0.0.1')
    assert jake.ok['127.0.0.1'] == 0

    # decrement by 2
    jake.decrement('ok', '127.0.0.1')
    assert jake.ok['127.0.0.1'] == 0


# Generated at 2022-06-22 20:16:45.274351
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate = AggregateStats()
    aggregate.set_custom_stats('foo', 42)
    assert aggregate.custom == {'_run': {'foo': 42}}
    aggregate.set_custom_stats('foo', 42, 'all')
    assert aggregate.custom == {'_run': {'foo': 42}, 'all': {'foo': 42}}
    aggregate.set_custom_stats('foo', 23, 'all')
    assert aggregate.custom == {'_run': {'foo': 42}, 'all': {'foo': 23}}
    aggregate.set_custom_stats('bar', 'baz', 'all')
    assert aggregate.custom == {'_run': {'foo': 42}, 'all': {'foo': 23, 'bar': 'baz'}}

    aggregate = AggregateStats()

# Generated at 2022-06-22 20:16:48.765259
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    s = AggregateStats()
    s.increment('ok', 'test_host')
    assert s.ok == {'test_host': 1}


# Generated at 2022-06-22 20:16:55.344809
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    a = AggregateStats()
    a.set_custom_stats("custom_stats_1", 10, "host1")
    assert a.custom["host1"]["custom_stats_1"] == 10
    a.set_custom_stats("custom_stats_1", 20, "host1")
    assert a.custom["host1"]["custom_stats_1"] == 20
    assert a.custom["host1"].get("custom_stats_2") is None



# Generated at 2022-06-22 20:17:01.962777
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    as_ = AggregateStats()
    assert as_.custom == {}
    as_.set_custom_stats('a', 1)
    assert as_.custom == {'_run': {'a': 1}}
    as_.set_custom_stats('a', 2, host='h')
    assert as_.custom == {'_run': {'a': 1}, 'h': {'a': 2}}


# Generated at 2022-06-22 20:17:07.915330
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('failures', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')

    results = stats.summarize('localhost')
    assert results['ok'] == 3
    assert results['failures'] == 2



# Generated at 2022-06-22 20:17:15.902105
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()

    assert(len(aggregate_stats.processed) == 0)
    assert(len(aggregate_stats.failures) == 0)
    assert(len(aggregate_stats.ok) == 0)
    assert(len(aggregate_stats.dark) == 0)
    assert(len(aggregate_stats.changed) == 0)
    assert(len(aggregate_stats.skipped) == 0)
    assert(len(aggregate_stats.rescued) == 0)
    assert(len(aggregate_stats.ignored) == 0)
    assert(len(aggregate_stats.custom) == 0)


# Generated at 2022-06-22 20:17:25.102524
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    hosts = ["localhost", "otherhost"]
    stats = AggregateStats()
    for host in hosts:
        for attr in ["ok", "failures", "dark", "changed", "skipped", "rescued", "ignored"]:
            setattr(stats, attr, {host: 1})

    for host in hosts:
        assert stats.summarize(host) == {
            'ok': 1,
            'failures': 1,
            'unreachable': 1,
            'changed': 1,
            'skipped': 1,
            'rescued': 1,
            'ignored': 1,
        }


# Generated at 2022-06-22 20:17:35.672700
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    # Create AggregateStats object
    as1 = AggregateStats()

    as1.increment('ok', 'host1')
    as1.increment('ok', 'host1')
    as1.increment('ok', 'host2')
    as1.increment('failures', 'host1')

    assert len(as1.processed) == 2
    assert as1.processed['host1'] == 1
    assert as1.processed['host2'] == 1

    assert len(as1.ok) == 2
    assert as1.ok['host1'] == 2
    assert as1.ok['host2'] == 1

    assert len(as1.failures) == 1
    assert as1.failures['host1'] == 1


# Generated at 2022-06-22 20:17:41.728965
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()

    stats.set_custom_stats('test_stat1', 42, host='a_host')
    assert stats.custom['a_host'] == {'test_stat1': 42}

    stats.set_custom_stats('test_stat2', 'answer to the Ultimate Question of Life, the Universe, and Everything', host='a_host')
    assert stats.custom['a_host'] == {'test_stat1': 42, 'test_stat2': 'answer to the Ultimate Question of Life, the Universe, and Everything'}

    stats.set_custom_stats('test_stat3', [1, 2, 3])
    assert stats.custom['_run'] == {'test_stat3': [1, 2, 3]}

# Generated at 2022-06-22 20:17:46.209205
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg_stats = AggregateStats()
    agg_stats.set_custom_stats('unzip', ('/home/something/test/test.zip', True), 'localhost')
    assert len(agg_stats.custom) == 1
    assert agg_stats.custom['localhost']['unzip'] == ('/home/something/test/test.zip', True)



# Generated at 2022-06-22 20:17:53.626166
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()
    assert len(aggregate_stats.processed) == 0
    assert len(aggregate_stats.failures) == 0
    assert len(aggregate_stats.ok) == 0
    assert len(aggregate_stats.dark) == 0
    assert len(aggregate_stats.changed) == 0
    assert len(aggregate_stats.skipped) == 0
    assert len(aggregate_stats.rescued) == 0
    assert len(aggregate_stats.ignored) == 0
    assert len(aggregate_stats.custom) == 0


# Generated at 2022-06-22 20:17:58.746658
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    a = AggregateStats()
    assert {}, a.processed
    assert {}, a.failures
    assert {}, a.ok
    assert {}, a.dark
    assert {}, a.changed
    assert {}, a.skipped
    assert {}, a.rescued
    assert {}, a.ignored
    assert {}, a.custom

# Generated at 2022-06-22 20:18:08.988157
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats('key', 'value')
    assert aggregate_stats.custom == {
        '_run': {'key': 'value'}
    }
    aggregate_stats.update_custom_stats('key', 'newvalue')
    assert aggregate_stats.custom == {
        '_run': {'key': 'newvalue'}
    }
    aggregate_stats.update_custom_stats('key', {'subkey': 'subvalue'})
    assert aggregate_stats.custom == {
        '_run': {'key': {'subkey': 'subvalue'}}
    }
    aggregate_stats.update_custom_stats('key', ['subvaluelist'])

# Generated at 2022-06-22 20:18:14.740070
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate = AggregateStats()

    assert aggregate.processed == {}
    assert aggregate.failures == {}
    assert aggregate.ok == {}
    assert aggregate.dark == {}
    assert aggregate.changed == {}
    assert aggregate.skipped == {}
    assert aggregate.rescued == {}
    assert aggregate.ignored == {}
    assert aggregate.custom == {}


# Generated at 2022-06-22 20:18:18.226399
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():

    stats = AggregateStats()

    assert 0 == stats.ok.get('localhost', 0)

    stats.increment('ok', 'localhost')

    assert 1 == stats.ok.get('localhost', 0)


# Generated at 2022-06-22 20:18:19.005032
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats=AggregateStats()
    assert stats.ok=={}


# Generated at 2022-06-22 20:18:30.185510
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():

    stats = AggregateStats()

    stats.set_custom_stats("variableOne", "I am a string")
    stats.set_custom_stats("variableTwo", 123)
    stats.set_custom_stats("variableTwo", 456, "localhost")
    stats.set_custom_stats("variableThree", 1.23)
    stats.set_custom_stats("variableFour", ["one", "two"])
    stats.set_custom_stats("variableFour", ["three", "four"], "localhost")
    stats.set_custom_stats("variableFive", {"one": 1, "two": 2})
    stats.set_custom_stats("variableFive", {"three": 3, "four": 4}, "localhost")

    assert stats.custom["_run"]["variableOne"] == "I am a string"

# Generated at 2022-06-22 20:18:37.016953
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stat1 = AggregateStats()
    stat1.update_custom_stats('files', {'toto': {'changed': 2}})
    assert stat1.custom == {'_run': {'files': {'toto': {'changed': 2}}}}
    stat1.update_custom_stats('files', {'titi': {'skipped': 4}})
    assert stat1.custom == {'_run': {'files': {'titi': {'skipped': 4},
                                               'toto': {'changed': 2}}}}
    stat1.update_custom_stats('failures', {'tata': {'skipped': 4}})

# Generated at 2022-06-22 20:18:46.405296
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()

    # without host
    aggregate_stats.set_custom_stats('failures', 1)
    assert aggregate_stats.custom['_run']['failures'] == 1

    # with host
    aggregate_stats.set_custom_stats('failures', 2, 'foohost')
    assert aggregate_stats.custom['foohost']['failures'] == 2

    # type
    aggregate_stats.set_custom_stats('failures', 'a_string', 'foohost')
    assert isinstance(aggregate_stats.custom['foohost']['failures'], str)
    assert aggregate_stats.custom['foohost']['failures'] == 'a_string'


# Generated at 2022-06-22 20:18:47.556396
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    assert AggregateStats().__class__.__name__ == 'AggregateStats'

# Generated at 2022-06-22 20:18:59.418703
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    '''
    Test cases:
    1. update_custom_stats of an existing key
    2. update_custom_stats of a non-existing key
    3. update_custom_stats with mismatching types
    '''

    # 1. update_custom_stats of a non-existing key
    stats = AggregateStats()
    stats.update_custom_stats('test', {'test1': 'test2'}, 'test_host')
    assert stats.custom.get('test_host') == {'test': {'test1': 'test2'}}

    # 2. update_custom_stats of an existing key
    stats.update_custom_stats('test', {'test2': 'test3'}, 'test_host')

# Generated at 2022-06-22 20:19:07.940776
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('failures', 'localhost')
    
    stats.increment('ok', '127.0.0.1')
    stats.increment('ok', '127.0.0.1')

    stats.increment('failures', '127.0.0.1')
    stats.increment('failures', '127.0.0.1')

    assert stats.summarize('localhost')['ok'] == 3

# Generated at 2022-06-22 20:19:11.054596
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.ok['localhost'] = 5
    aggregate_stats.decrement('ok', 'localhost')
    if aggregate_stats.ok['localhost'] != 4:
        raise AssertionError("Decrementing value ok must decrement value by 1")

# Generated at 2022-06-22 20:19:13.187907
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', '127.0.0.1')
    assert stats.ok['127.0.0.1'] == 1

# Generated at 2022-06-22 20:19:15.480254
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats is not None
    #assert stats.ok == {}
    #assert stats.failures == {}
    #assert stats.processed == {}

# Generated at 2022-06-22 20:19:27.287000
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('failures', 'host1')
    stats.increment('failures', 'host2')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('dark', 'host2')
    stats.increment('changed', 'host2')
    stats.increment('skipped', 'host1')
    stats.increment('rescued', 'host1')
    stats.increment('ignored', 'host1')
    assert stats.summarize('host1') == dict(
        ok=1, failures=1, unreachable=0, changed=0, skipped=1, rescued=1, ignored=1
    )

# Generated at 2022-06-22 20:19:35.560619
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('a', 1)
    assert stats.custom['_run']['a'] == 1
    assert stats.custom == {'_run': {'a': 1}}
    stats.update_custom_stats('a', 2, 'host1')
    stats.update_custom_stats('a', 3, 'host2')
    assert stats.custom == {'_run': {'a': 1}, 'host1': {'a': 2}, 'host2': {'a': 3}}
    stats.update_custom_stats('b', 1)
    assert stats.custom == {'_run': {'a': 1, 'b': 1}, 'host1': {'a': 2}, 'host2': {'a': 3}}

# Generated at 2022-06-22 20:19:41.564592
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    ag_stats = AggregateStats()
    assert ag_stats.ok == {}
    assert ag_stats.failures == {}
    assert ag_stats.changed == {}
    assert ag_stats.dark == {}
    assert ag_stats.rescued == {}
    assert ag_stats.ignored == {}
    assert ag_stats.processed == {}
    assert ag_stats.skipped == {}
    assert ag_stats.custom == {}


# Generated at 2022-06-22 20:19:51.912436
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok = {'host1':1, 'host2':2}
    stats.failures = {'host1':3, 'host2':4}
    stats.dark = {'host1':5, 'host2':6}
    stats.changed = {'host1':7, 'host2':8}
    stats.skipped = {'host1':9, 'host2':10}
    stats.rescued = {'host1':11, 'host2':12}
    stats.ignored = {'host1':13, 'host2':14}

    output1 = stats.summarize('host1')

# Generated at 2022-06-22 20:19:54.541053
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'test')
    stats.increment('ok', 'test')
    stats.decrement('ok', 'test')
    assert stats.ok.get('test', 0) == 1

# Generated at 2022-06-22 20:19:57.148157
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggStats = AggregateStats()
    assert aggStats is not None
    assert aggStats.processed == {}
    assert aggStats.custom == {}
   

# Unit tests for other functions of class AggregateStats

# Generated at 2022-06-22 20:20:06.139373
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    aggregate_stats.ok['host1'] = 1
    aggregate_stats.failures['host2'] = 2
    aggregate_stats.dark['host3'] = 3
    aggregate_stats.changed['host4'] = 4
    aggregate_stats.skipped['host5'] = 5
    aggregate_stats.rescued['host6'] = 6
    aggregate_stats.ignored['host7'] = 7
    aggregate_stats.increment('failures', 'host8')


# Generated at 2022-06-22 20:20:08.575774
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    # Make sure hosts are incremented correctly
    stats.increment("ok", "localhost")
    assert stats.ok["localhost"] == 1

    stats.increment("ok", "localhost")
    assert stats.ok["localhost"] == 2


# Generated at 2022-06-22 20:20:15.332558
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('skipped', 'host1')
    stats.increment('ignored', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.increment('failures', 'host3')
    stats.increment('changed', 'host3')
    stats.increment('changed', 'host3')

    assert stats.summarize('host1') == dict(
        ok=1,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=1,
        rescued=0,
        ignored=1,
    )

# Generated at 2022-06-22 20:20:27.328028
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    from collections import namedtuple
    from ansible.utils.vars import combine_vars

    stats = AggregateStats()
    stats.processed['localhost'] = 1

    stats.ok['localhost'] = 9
    stats.failures['localhost'] = 8
    stats.dark['localhost'] = 7
    stats.changed['localhost'] = 6
    stats.skipped['localhost'] = 5
    stats.rescued['localhost'] = 4
    stats.ignored['localhost'] = 3

    stats.decrement('ok', 'localhost')
    stats.decrement('failures', 'localhost')
    stats.decrement('dark', 'localhost')
    stats.decrement('changed', 'localhost')
    stats.decrement('skipped', 'localhost')
    stats.decrement('rescued', 'localhost')


# Generated at 2022-06-22 20:20:37.142406
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert isinstance(stats.custom, dict)
    assert isinstance(stats.processed, dict)
    assert isinstance(stats.failures, dict)
    assert isinstance(stats.ok, dict)
    assert isinstance(stats.dark, dict)
    assert isinstance(stats.changed, dict)
    assert isinstance(stats.skipped, dict)
    assert isinstance(stats.rescued, dict)
    assert isinstance(stats.ignored, dict)


# Generated at 2022-06-22 20:20:45.368614
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from copy import deepcopy
    from ansible.utils.vars import merge_hash
    import unittest

    class TestAggregateStats(unittest.TestCase):

        def test_update_custom_stats_with_dict(self):
            aggregate_stats = AggregateStats()
            original_value = {'test': {'test2': 1}}
            new_value = {'test': {'test1': 1}}
            expected_value = {'test': {'test1': 1, 'test2': 1}}

            aggregate_stats.set_custom_stats('value', original_value, '_run')
            aggregate_stats.update_custom_stats('value', new_value, '_run')

# Generated at 2022-06-22 20:20:46.656837
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    obj = AggregateStats()
    assert obj is not None


# Generated at 2022-06-22 20:20:57.675894
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    ''' unit test for method summarize of class AggregateStats '''

    # given
    stats = AggregateStats()
    stats.changed['host1'] = 1
    stats.changed['host2'] = 2
    stats.ignored['host1'] = 5
    stats.ignored['host2'] = 6

    # when
    summary1 = stats.summarize('host1')

    # then
    assert summary1 == {
        'ok': 0,
        'failures': 0,
        'unreachable': 0,
        'changed': 1,
        'skipped': 0,
        'rescued': 0,
        'ignored': 5,
    }

    # when
    summary2 = stats.summarize('host2')

    # then

# Generated at 2022-06-22 20:21:03.613798
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    a = AggregateStats()
    a.decrement('failures', 'host')

    assert a.failures['host'] == 0

    a.increment('failures', 'host')
    a.increment('failures', 'host')

    assert a.failures['host'] == 2

    a.decrement('failures', 'host')

    assert a.failures['host'] == 1

# Generated at 2022-06-22 20:21:09.202427
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('failures', 'foo')
    assert stats.failures == {'foo': 1}
    stats.increment('failures', 'foo')
    assert stats.failures == {'foo': 2}
    stats.increment('failures', 'bar')
    assert stats.failures == {'foo': 2, 'bar': 1}


# Generated at 2022-06-22 20:21:17.417631
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    # check if a MutableMapping is correctly merged
    stats.update_custom_stats('items', {'item1':1, 'item2':2})
    assert stats.custom['_run']['items'] == {'item1':1, 'item2':2}
    stats.update_custom_stats('items', {'item3':3}, host='host1')
    assert stats.custom['host1']['items'] == {'item3':3}
    stats.update_custom_stats('items', {'item1':4, 'item4':4}, host='host1')
    assert stats.custom['host1']['items'] == {'item1':4, 'item3':3, 'item4':4}

# Generated at 2022-06-22 20:21:23.832963
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    compiler = AggregateStats()
    assert compiler.processed == {}
    assert compiler.failures == {}
    assert compiler.ok == {}
    assert compiler.dark == {}
    assert compiler.changed == {}
    assert compiler.skipped == {}
    assert compiler.rescued == {}
    assert compiler.ignored == {}
    assert compiler.custom == {}


# Generated at 2022-06-22 20:21:29.833362
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("ok", "localhost")
    assert stats.ok == {"localhost": 1}
    stats.increment("ok", "localhost")
    assert stats.ok == {"localhost": 2}
    stats.increment("ok", "example.com")
    assert stats.ok == {"localhost": 2, "example.com": 1}



# Generated at 2022-06-22 20:21:33.902818
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    astats = AggregateStats()
    astats.increment('ok', 'testhost')
    astats.decrement('ok', 'testhost')
    assert astats.ok['testhost'] == 0

    astats.decrement('ok', 'testhost')
    assert astats.ok['testhost'] == 0

# Generated at 2022-06-22 20:21:41.653160
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats("foo", 42, "unit_test_one")
    stats.set_custom_stats("foo", 42, "unit_test_two")
    stats.update_custom_stats("foo", 1, "unit_test_one")
    assert stats.custom == {
        "_run": {},
        "unit_test_one": {"foo": 43},
        "unit_test_two": {"foo": 42},
    }
    stats.update_custom_stats("foo", 1.1, "unit_test_one")
    assert stats.custom == {
        "_run": {},
        "unit_test_one": {"foo": 44.1},
        "unit_test_two": {"foo": 42},
    }

# Generated at 2022-06-22 20:21:48.504648
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregatestats = AggregateStats()
    host = 'test_host'
    which = 'test_which'
    what = 'test_what'

    aggregatestats.set_custom_stats(which, what, host)

    assert what == aggregatestats.custom[host][which], 'Set Custom Stats is not correct'
    print("Test 'set_custom_stats' done")


# Generated at 2022-06-22 20:21:52.629162
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert isinstance(stats, AggregateStats), "instance should be an instance of the AggregateStats class"


# Generated at 2022-06-22 20:22:02.113113
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok['1.1.1.1'] = 1
    stats.failures['1.1.1.1'] = 1
    stats.dark['1.1.1.1'] = 1
    stats.changed['1.1.1.1'] = 1
    stats.skipped['1.1.1.1'] = 1
    stats.rescued['1.1.1.1'] = 1
    stats.ignored['1.1.1.1'] = 1

    result = stats.summarize('1.1.1.1')
    assert isinstance(result, type({}))
    assert result['ok'] == 1
    assert result['failures'] == 1
    assert result['unreachable'] == 1
    assert result['changed'] == 1

# Generated at 2022-06-22 20:22:12.647781
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    ag_stats = AggregateStats()

    assert isinstance(ag_stats, AggregateStats)
    assert isinstance(ag_stats.processed, dict)
    assert isinstance(ag_stats.failures, dict)
    assert isinstance(ag_stats.ok, dict)
    assert isinstance(ag_stats.dark, dict)
    assert isinstance(ag_stats.changed, dict)
    assert isinstance(ag_stats.skipped, dict)
    assert isinstance(ag_stats.rescued, dict)
    assert isinstance(ag_stats.ignored, dict)

    # instantiate test host
    host = 'host_1'

    # ensure default values for each host

# Generated at 2022-06-22 20:22:22.584391
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment("ok", 'host1')
    stats.increment("ok", 'host2')

    # Decrement hosts with positive values
    stats.decrement('ok', 'host1')
    assert(stats.ok['host1'] == 0)
    stats.decrement('ok', 'host2')
    assert(stats.ok['host2'] == 0)

    # Decrement the host with negative values
    stats.decrement('ok', 'host1')
    assert(stats.ok['host1'] == 0)

    # Skip the host that's not initialized
    stats.decrement('ok', 'host3')
    assert(stats.ok['host3'] == 0)

# Generated at 2022-06-22 20:22:26.171794
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg_stats = AggregateStats()
    agg_stats.increment('failures', 'localhost')
    assert agg_stats.failures['localhost'] == 1


# Generated at 2022-06-22 20:22:35.362740
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    from ansible.module_utils.six import PY3
    stats = AggregateStats()
    stats.increment('ok', 'foo')
    stats.increment('ok', 'foo')
    stats.increment('ok', 'foo')
    stats.increment('failures', 'foo')
    stats.increment('failures', 'foo')
    stats.increment('dark', 'foo')
    stats.increment('dark', 'bar')
    stats.increment('changed', 'foo')
    stats.increment('changed', 'foo')
    stats.increment('changed', 'foo')
    stats.increment('pre_ok', 'foo')
    stats.increment('pre_ok', 'foo')
    stats.increment('post_ok', 'foo')

# Generated at 2022-06-22 20:22:42.020003
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}

    # increment ok with host foo
    stats.increment('ok', 'foo')
    assert stats.ok == {'foo': 1}
    assert stats.processed == {'foo': 1}

    # increment ok again with host foo
    stats.increment('ok', 'foo')
    assert stats.ok == {'foo': 2}
    assert stats.processed == {'foo': 1}

    # increment ok with host bar

# Generated at 2022-06-22 20:22:52.993404
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    assert stats.summarize('server1') == dict(
        ok=0,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0,
    )

    stats.increment('ok', 'server1')
    stats.increment('changed', 'server1')
    assert stats.summarize('server1') == dict(
        ok=1,
        failures=0,
        unreachable=0,
        changed=1,
        skipped=0,
        rescued=0,
        ignored=0,
    )

    stats.increment('rescued', 'server1')
    stats.increment('ok', 'server2')


# Generated at 2022-06-22 20:23:02.901638
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    # Setup
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('failures', 'host1')
    stats.increment('failures', 'host1')
    stats.increment('failures', 'host2')
    stats.increment('changed', 'host1')
    stats.increment('changed', 'host2')
    stats.increment('skipped', 'host2')

    # Test
    results = stats.summarize('host1')

    # Verify
    assert results['ok'] == 2
    assert results['failures'] == 2
    assert results['unreachable'] == 0
    assert results['changed'] == 1

# Generated at 2022-06-22 20:23:10.557419
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate = AggregateStats()

    aggregate.increment('ok', "127.0.0.1")
    aggregate.increment('ok', "127.0.0.1")
    aggregate.increment('failures', "127.0.0.1")

    assert aggregate.summary("127.0.0.1") == {'ok': 2, 'failures': 1, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}



# Generated at 2022-06-22 20:23:12.994846
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    import json
    aggregate_stats = AggregateStats()
    print(json.dumps(aggregate_stats.__dict__))



# Generated at 2022-06-22 20:23:24.274341
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    import json
    t = AggregateStats()

    assert t.summarize('host1') == \
            {'ok': 0, 'failures': 0, 'unreachable': 0, 'changed': 0,
             'skipped': 0, 'rescued': 0, 'ignored': 0}

    t.increment('ok', 'host1')
    t.increment('ok', 'host1')
    t.increment('ok', 'host1')
    t.increment('failures', 'host1')

    assert t.summarize('host1') == \
            {'ok': 3, 'failures': 1, 'unreachable': 0, 'changed': 0,
             'skipped': 0, 'rescued': 0, 'ignored': 0}

    t.increment('ok', 'host2')

# Generated at 2022-06-22 20:23:34.221797
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    '''
    1. Create an instance of class AggregateStats
    2. Call method summarize
    3. Because in step 1 we didn't call increment any times, so the result is all zeros,
       no matter what host is passed in parameter.
    '''
    aggregate_stats = AggregateStats()
    assert {'ok': 0, 'failures': 0, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0} == aggregate_stats.summarize('host')
    assert {'ok': 0, 'failures': 0, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0} == aggregate_stats.summarize(None)

# Generated at 2022-06-22 20:23:41.944088
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregateStats = AggregateStats()
    aggregateStats.set_custom_stats('which', 'what')
    assert '_run' in aggregateStats.custom
    assert 'which' in aggregateStats.custom['_run']
    assert aggregateStats.custom['_run']['which'] == 'what'
    aggregateStats.set_custom_stats('which', 'what', host='host')
    assert 'host' in aggregateStats.custom
    assert 'which' in aggregateStats.custom['host']
    assert aggregateStats.custom['host']['which'] == 'what'



# Generated at 2022-06-22 20:23:46.629001
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()

    # set host:
    aggregate_stats.set_custom_stats("test", "1234", "127.0.0.1")
    assert aggregate_stats.custom["127.0.0.1"]["test"] == "1234"

    # set global:
    aggregate_stats.set_custom_stats("test", "abcd")
    assert aggregate_stats.custom["_run"]["test"] == "abcd"



# Generated at 2022-06-22 20:23:58.680033
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    custom_stats = AggregateStats()

    custom_stats.update_custom_stats(which="random_stats", what={'task1':False, 'task2':True}, host="_run")

    if not isinstance(custom_stats.custom["_run"]["random_stats"], MutableMapping):
        raise AssertionError("custom_stats.custom['_run']['random_stats'] is not a MutableMapping, {0} is."
                             .format(type(custom_stats.custom["_run"]["random_stats"])))

# Generated at 2022-06-22 20:24:07.445649
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'host0')
    stats.increment('ok', 'host0')
    stats.increment('ok', 'host0')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('failures', 'host3')
    stats.increment('dark', 'host4')
    ref = {
        'ok': 3,
        'failures': 1,
        'unreachable': 1,
        'changed': 0,
        'skipped': 0,
        'rescued': 0,
        'ignored': 0,
    }
    assert stats.summarize('host0') == ref
    assert stats.summarize('host1') == ref
    assert stats.summarize

# Generated at 2022-06-22 20:24:10.468628
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    host = 'me'
    stats.increment('ok', host)
    assert stats.ok[host] == 1


# Generated at 2022-06-22 20:24:20.043585
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    stats.processed['host1'] = 1
    stats.ok['host1'] = 1
    stats.decrement('ok', 'host1')
    assert stats.processed == {'host1':1}
    assert stats.ok == {'host1':0}

    stats.decrement("ok","host1")
    assert stats.ok == {'host1':0}

    stats.ok['host1'] = -1
    stats.decrement("ok","host1")
    assert stats.ok == {'host1':0}

    stats.decrement("ok","host1")
    assert stats.ok == {'host1':0}


# Generated at 2022-06-22 20:24:29.260856
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg = AggregateStats()

    # Should be no problem if there are no dict elements to decrement
    agg.decrement('ok', 'host')

    agg.increment('ok', 'host')
    agg.decrement('ok', 'host')
    assert agg.ok == {}

    # If a KeyError occurs, the value should be reset to 0
    try:
        agg.decrement('ok', 'host')
    except KeyError:
        pass
    assert agg.ok == {'host': 0}

# Generated at 2022-06-22 20:24:40.640957
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    collection = AggregateStats()
    assert collection.custom == {}
    collection.update_custom_stats('foo', 123)
    assert collection.custom == {'_run': {'foo': 123}}
    collection.update_custom_stats('foo', 123)
    assert collection.custom == {'_run': {'foo': 246}}
    collection.set_custom_stats('foo', 123, host='victim')
    collection.update_custom_stats('foo', 123, host='victim')
    assert collection.custom == {'_run': {'foo': 246}, 'victim': {'foo': 123}}
    collection.update_custom_stats('foo', 888, host='victim')
    assert collection.custom == {'_run': {'foo': 246}, 'victim': {'foo': 1001}}
    collection.update

# Generated at 2022-06-22 20:24:51.872036
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    # test for UnknownHost
    a = AggregateStats()
    assert len(a.processed) == 0
    a.increment('ok', 'UnknownHost')
    assert 'UnknownHost' in a.processed
    assert len(a.processed) == 1
    assert a.processed['UnknownHost'] == 1
    a.increment('ok', 'UnknownHost')
    assert a.processed['UnknownHost'] == 2

    # test for KnownHost
    b = AggregateStats()
    assert len(b.processed) == 0
    b.increment('ok', 'KnownHost')
    assert 'KnownHost' in b.processed
    assert len(b.processed) == 1
    assert b.processed['KnownHost'] == 1
    b.increment('ok', 'KnownHost')
    assert b.processed

# Generated at 2022-06-22 20:24:58.617123
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agstats = AggregateStats()

    # Test decrement first
    agstats.decrement('failures', 'localhost')
    assert agstats.failures['localhost'] == 0

    # Then test increment
    agstats.increment('failures', 'localhost')
    assert agstats.failures['localhost'] == 1
    assert agstats.processed['localhost'] == 1

    # Now test decrement again
    agstats.decrement('failures', 'localhost')
    assert agstats.failures['localhost'] == 0
    assert agstats.processed['localhost'] == 1
