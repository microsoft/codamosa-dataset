

# Generated at 2022-06-22 20:15:06.588390
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Create a test object
    stats = AggregateStats()
    # Set custom stats with host and with run
    stats.set_custom_stats('test1', 1, 'test_host')
    stats.set_custom_stats('test2', 'test2', 'test_host')
    stats.set_custom_stats('test1', 1)
    stats.set_custom_stats('test2', 'test2')
    # Try overwriting with different type
    stats.update_custom_stats('test2', 2, 'test_host')
    # Try overwriting with different type
    stats.update_custom_stats('test2', 2)
    # Try updating with different type
    stats.update_custom_stats('test3', 1, 'test_host')

# Generated at 2022-06-22 20:15:09.448275
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.failures == {}
    assert stats.custom == {}


# Generated at 2022-06-22 20:15:12.713480
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    as_stats = AggregateStats()
    result = as_stats.set_custom_stats('foo','bar','localhost')
    expected = { 'localhost': { 'foo': 'bar' } }
    assert as_stats.custom == expected


# Generated at 2022-06-22 20:15:16.246236
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()

    stats.set_custom_stats('test_key', 'test_value', 'test_host')

    assert stats.custom == {'test_host': {'test_key': 'test_value'}}


# Generated at 2022-06-22 20:15:21.318061
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    test_object = AggregateStats()
    test_object.set_custom_stats("test_key", "test_value")
    assert test_object.custom["_run"]["test_key"] == "test_value", "set_custom_stats fails"


# Generated at 2022-06-22 20:15:27.534012
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert isinstance(stats, AggregateStats)
    assert 'ok' in dir(stats)
    assert 'failures' in dir(stats)
    assert 'dark' in dir(stats)
    assert 'changed' in dir(stats)
    assert 'skipped' in dir(stats)
    assert 'rescued' in dir(stats)
    assert 'ignored' in dir(stats)
    assert 'custom' in dir(stats)



# Generated at 2022-06-22 20:15:36.155051
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggstats = AggregateStats()
    aggstats.ok['10.1.1.1'] = 2
    aggstats.failures['10.1.1.1'] = 1
    aggstats.dark['10.1.1.1'] = 1
    aggstats.changed['10.1.1.1'] = 1
    aggstats.skipped['10.1.1.1'] = 1
    aggstats.rescued['10.1.1.1'] = 1
    aggstats.ignored['10.1.1.1'] = 1
    # Test host 10.1.1.1

# Generated at 2022-06-22 20:15:43.878137
# Unit test for constructor of class AggregateStats
def test_AggregateStats():

    aggregate_stats = AggregateStats()

    assert isinstance(aggregate_stats.processed, dict)
    assert isinstance(aggregate_stats.failures, dict)
    assert isinstance(aggregate_stats.ok, dict)
    assert isinstance(aggregate_stats.dark, dict)
    assert isinstance(aggregate_stats.changed, dict)
    assert isinstance(aggregate_stats.skipped, dict)
    assert isinstance(aggregate_stats.rescued, dict)
    assert isinstance(aggregate_stats.ignored, dict)
    assert isinstance(aggregate_stats.custom, dict)


# Generated at 2022-06-22 20:15:49.610945
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ags = AggregateStats()
    ags.decrement('rescued', 'host1')
    assert ags.rescued['host1'] == 0
    ags.rescued['host1'] = 1
    ags.decrement('rescued', 'host1')
    assert ags.rescued['host1'] == 0

if __name__ == '__main__':
    test_AggregateStats_decrement()

# Generated at 2022-06-22 20:15:52.018145
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok == {'localhost': 1}


# Generated at 2022-06-22 20:15:55.760030
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test_object = AggregateStats()
    host = 'some_host'
    test_object.increment('ok', host)
    test_object.increment('ok', host)
    test_object.decrement('ok', host)
    assert(test_object.ok[host] == 1)

# Generated at 2022-06-22 20:16:06.848134
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment("ok", "host1")
    aggregate_stats.increment("ok", "host1")
    aggregate_stats.increment("failures", "host1")
    aggregate_stats.increment("failures", "host1")
    aggregate_stats.increment("failures", "host1")
    aggregate_stats.increment("dark", "host1")
    aggregate_stats.increment("dark", "host2")
    aggregate_stats.increment("ok", "host2")
    aggregate_stats.increment("ok", "host2")
    aggregate_stats.increment("changed", "host2")

    data = aggregate_stats.summarize("host1")
    assert data["ok"] == 2
    assert data["failures"] == 3

# Generated at 2022-06-22 20:16:18.358404
# Unit test for method update_custom_stats of class AggregateStats

# Generated at 2022-06-22 20:16:28.660296
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Positive test cases
    # Argument 'what' is a dictionary
    custom_stats = AggregateStats()
    host = 'testhost'
    what = {'key1': 'value1', 'key2': 'value2'}
    custom_stats.update_custom_stats('which', what, host)
    assert custom_stats.custom[host]['which'] == what
    # Argument 'what' is a non-dictionary
    what = 1
    custom_stats.update_custom_stats('which', what, host)
    assert custom_stats.custom[host]['which'] == what

    # Negative test cases
    # Argument 'what' is a dictionary but with mismatching types
    what = {'key1': 'value1', 'key2': 2}
    custom_stats.update_custom_stats('which', what, host)

# Generated at 2022-06-22 20:16:34.543264
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats is not None
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}


# Generated at 2022-06-22 20:16:42.259142
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert isinstance(stats, AggregateStats)
    assert isinstance(stats.processed, dict)
    assert isinstance(stats.failures, dict)
    assert isinstance(stats.ok, dict)
    assert isinstance(stats.dark, dict)
    assert isinstance(stats.changed, dict)
    assert isinstance(stats.skipped, dict)
    assert isinstance(stats.rescued, dict)
    assert isinstance(stats.ignored, dict)
    assert isinstance(stats.custom, dict)

# Generated at 2022-06-22 20:16:52.978912
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('stat1', 1, 'host1')
    stats.update_custom_stats('stat2', 2, 'host1')

    assert(stats.custom['host1'] == {'stat1': 1, 'stat2': 2})

    # Update already set stat
    stats.update_custom_stats('stat1', 10, 'host1')
    assert(stats.custom['host1'] == {'stat1': 10, 'stat2': 2})

    # Update stat with another type
    stats.update_custom_stats('stat1', ['test'], 'host1')
    assert(stats.custom['host1'] == {'stat1': ['test'], 'stat2': 2})

    # Update stat with another complex type

# Generated at 2022-06-22 20:16:56.613064
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg_stats_obj = AggregateStats()
    agg_stats_obj.set_custom_stats("my_custom", "value")
    assert agg_stats_obj.custom["_run"]["my_custom"] == "value"


# Generated at 2022-06-22 20:17:02.496763
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()

    stats.set_custom_stats('foo', 'bar')
    assert stats.custom.get('_run',{}).get('foo') == 'bar'

    stats.set_custom_stats('foo', 'bar', 'localhost')
    assert stats.custom.get('localhost',{}).get('foo') == 'bar'

# Generated at 2022-06-22 20:17:09.598487
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    result = AggregateStats()
    assert result._fields == ('processed', 'failures', 'ok', 'dark', 'changed', 'skipped', 'rescued', 'ignored', 'custom')
    assert result.processed == {}
    assert result.failures == {}
    assert result.ok == {}
    assert result.dark == {}
    assert result.changed == {}
    assert result.skipped == {}
    assert result.rescued == {}
    assert result.ignored == {}
    assert result.custom == {}


# Generated at 2022-06-22 20:17:20.097223
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    # Create host variables
    hostvars1 = {
        'a': 1,
        'b': 2,
    }
    hostvars2 = {
        'b': 2,
        'c': 3,
    }
    hostvars3 = {
        'c': 3,
        'd': 4,
    }
    # Initialize stats
    stats = AggregateStats()
    # Set custom stats
    stats.set_custom_stats('ansible_facts', hostvars1, 'host1')
    stats.set_custom_stats('ansible_facts', hostvars2, 'host2')
    stats.set_custom_stats('ansible_facts', hostvars3, 'host3')
    # Check that custom stats were correctly set
    assert stats.custom['host1']['ansible_facts']

# Generated at 2022-06-22 20:17:24.950280
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('a', '1')
    assert stats.custom['_run']['a'] == '1'
    stats.set_custom_stats('a', '2')
    assert stats.custom['_run']['a'] == '2'



# Generated at 2022-06-22 20:17:35.877379
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    s = AggregateStats()

    # dict type
    # set dict type
    s.update_custom_stats("a", {'a': 1, "b": 2})
    assert s.custom["_run"]["a"] == {'a': 1, "b": 2}
    # merge dict type
    s.update_custom_stats("a", {'a': 2, "c": 1})
    assert s.custom["_run"]["a"] == {'a': 2, "b": 2, 'c': 1}
    # not merge dict type
    s.update_custom_stats("a", {'a': 1}, "hostname")
    assert s.custom["hostname"]["a"] == {'a': 1}

    # int type
    # set int type

# Generated at 2022-06-22 20:17:43.918804
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    aggregate_stats.ok['host1'] = 10
    aggregate_stats.ok['host2'] = 20
    aggregate_stats.rescued['host1'] = 2
    aggregate_stats.rescued['host2'] = 4
    aggregate_stats.ignored['host1'] = 0
    aggregate_stats.ignored['host2'] = 10
    aggregate_stats.changed['host1'] = 1
    aggregate_stats.changed['host2'] = 3
    assert aggregate_stats.summarize('host1') == {'ok': 10, 'failures': 0, 'unreachable': 0, 'changed': 1, 'skipped': 0, 'rescued': 2, 'ignored': 0}

# Generated at 2022-06-22 20:17:49.574319
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('foo', 42)
    stats.set_custom_stats('bar', 43, host='host1')
    stats.set_custom_stats('baz', 44, host='host2')
    assert stats.custom == {'_run': {'foo': 42}, 'host1': {'bar': 43}, 'host2': {'baz': 44}}


# Generated at 2022-06-22 20:17:55.978480
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', '127.0.0.1')
    stats.increment('ok', '127.0.0.1')
    stats.increment('changed', '127.0.0.1')
    stats.increment('failures', '127.0.0.1')
    stats.increment('dark', '127.0.0.1')
    stats.increment('skipped', '127.0.0.1')
    stats.increment('ignored', '127.0.0.1')
    stats.increment('ok', '127.0.0.2')
    stats.increment('changed', '127.0.0.2')
    stats.increment('dark', '127.0.0.2')

# Generated at 2022-06-22 20:17:58.372843
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement("ok", "host1")
    assert stats.ok["host1"] == 0


# Generated at 2022-06-22 20:18:04.593050
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.processed == {}
    assert aggregate_stats.failures == {}
    assert aggregate_stats.ok == {}
    assert aggregate_stats.dark == {}
    assert aggregate_stats.changed == {}
    assert aggregate_stats.skipped == {}
    assert aggregate_stats.rescued == {}
    assert aggregate_stats.ignored == {}
    assert aggregate_stats.custom == {}


# Generated at 2022-06-22 20:18:07.377753
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('test_key', 'test_value', 'test_host')
    assert stats.custom['test_host']['test_key'] == 'test_value'


# Generated at 2022-06-22 20:18:13.350500
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    assert stats.custom == {}

    # test updating stats[host]
    stats.set_custom_stats('foo', 'bar')
    assert stats.custom == {'_run': {'foo': 'bar'}}

    # test updating stats[host][which]
    stats.update_custom_stats('foo', 'bar')
    assert stats.custom == {'_run': {'foo': 'bar'}}

    stats.update_custom_stats('foo', 'baz')
    assert stats.custom == {'_run': {'foo': 'baz'}}

    # test updating stats[host][which] with different types
    stats.update_custom_stats('foo', {'bar': 'baz'})

# Generated at 2022-06-22 20:18:15.670160
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ag = AggregateStats()
    ag.increment("ok", "localhost")
    assert ag.ok["localhost"] == 1


# Generated at 2022-06-22 20:18:24.813693
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # create an AggregateStats object
    stats = AggregateStats()

    # accumulate the statistic 'ok' for host 'host1'
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')

    # check that 'ok' is 2 for host 'host1'
    assert stats.ok['host1'] == 2

    # decrement the statistic 'ok' for host 'host1'
    stats.decrement('ok', 'host1')

    # check that 'ok' is 1 for host 'host1'
    assert stats.ok['host1'] == 1



# Generated at 2022-06-22 20:18:31.981137
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('failures', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('changed', 'localhost')
    assert stats.failures['localhost'] == 1
    assert stats.ok['localhost'] == 1
    assert stats.changed['localhost'] == 1
    assert stats.dark == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-22 20:18:43.484680
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    from ansible.module_utils.six import iteritems

    which = "foo"
    host = "bar"

    # Testing of the update_custom_stats method needs that the update_custom_stats is working as merge_hash.
    stats = AggregateStats()
    stats.update_custom_stats(which, dict(a=1, b=dict(c=2)))
    stats.update_custom_stats(which, dict(b=dict(d=3)))
    stats.update_custom_stats(which, dict(a=2, b=dict(e=6)))
    assert stats.custom["_run"][which] == dict(a=2, b=dict(c=2, d=3, e=6))

    # Testing the update_custom_stats for the merge of a list
    stats = AggregateStats()
    stats

# Generated at 2022-06-22 20:18:50.019874
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'host1')
    aggregate_stats.increment('ok', 'host1')
    aggregate_stats.increment('ok', 'host1')
    aggregate_stats.increment('failures', 'host1')
    aggregate_stats.increment('failures', 'host1')
    aggregate_stats.increment('dark', 'host1')
    aggregate_stats.increment('changed', 'host1')
    aggregate_stats.increment('skipped', 'host1')
    aggregate_stats.increment('rescued', 'host1')
    aggregate_stats.increment('ignored', 'host1')
    aggregate_stats.increment('ignored', 'host1')

    stats = aggregate_stats.summarize('host1')

# Generated at 2022-06-22 20:18:56.508738
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test_obj = AggregateStats()
    test_obj.increment('ok', 'localhost')
    assert(test_obj.ok['localhost'] == 1)
    test_obj.decrement('ok', 'localhost')
    assert(test_obj.ok['localhost'] == 0)
    test_obj.decrement('ok', 'localhost')
    assert(test_obj.ok['localhost'] == 0)


# Generated at 2022-06-22 20:19:01.366735
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.ok == {}
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}



# Generated at 2022-06-22 20:19:11.583177
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    test_host_name = 'test_host'
    stats.processed[test_host_name] = 1
    stats.ok[test_host_name] = 1
    stats.failures[test_host_name] = 2
    stats.dark[test_host_name] = 3
    stats.changed[test_host_name] = 4
    stats.skipped[test_host_name] = 5
    stats.rescued[test_host_name] = 6

    assert stats.summarize(test_host_name) == dict(
        ok=1,
        failures=2,
        unreachable=3,
        changed=4,
        skipped=5,
        rescued=6,
        ignored=0,
    )


# Generated at 2022-06-22 20:19:19.270788
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg_stats = AggregateStats()
    agg_stats.set_custom_stats('agg_key_int', 2000, None)
    assert agg_stats.custom['_run']['agg_key_int'] == 2000

    agg_stats.set_custom_stats('agg_key_dict', {'k1': 'v1'}, None)
    assert agg_stats.custom['_run']['agg_key_dict'] == {'k1': 'v1'}

    agg_stats.set_custom_stats('agg_key_dict', {'k2': 'v2'}, None)
    assert agg_stats.custom['_run']['agg_key_dict'] == {'k1': 'v1', 'k2': 'v2'}


# Generated at 2022-06-22 20:19:30.962043
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():

    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.summarize('localhost') == {'ok':1, 'failures':0, 'unreachable':0, 'changed':0, 'skipped':0, 'rescued':0, 'ignored':0}
    stats.increment('failures', 'localhost')
    assert stats.summarize('localhost') == {'ok':1, 'failures':1, 'unreachable':0, 'changed':0, 'skipped':0, 'rescued':0, 'ignored':0}
    stats.increment('dark', 'localhost')

# Generated at 2022-06-22 20:19:42.781411
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    ag = AggregateStats()

    test_dict = {
        'ok': {'host1': 0},
        'failures': {'host1': 0},
        'dark': {'host1': 0},
        'changed': {'host1': 0},
        'skipped': {'host1': 0},
        'rescued': {'host1': 0},
        'ignored': {'host1': 0},
        'custom': {}
    }

    assert ag.processed == {}
    assert ag.failures == {}
    assert ag.ok == {}
    assert ag.dark == {}
    assert ag.changed == {}
    assert ag.skipped == {}
    assert ag.rescued == {}
    assert ag.ignored == {}
    assert ag.custom == {}


# Generated at 2022-06-22 20:19:47.048798
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg = AggregateStats()
    agg.set_custom_stats('foo', 5, 'local')
    assert agg.custom == {'local': {'foo': 5}}

    agg = AggregateStats()
    agg.set_custom_stats('foo', 5)
    assert agg.custom == {'_run': {'foo': 5}}


# Generated at 2022-06-22 20:19:50.125583
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    stats.decrement('ok', 'foo')
    # unknown stats should not be changed
    assert stats.ok['foo'] == 0

# Generated at 2022-06-22 20:19:58.448623
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    
    stat_hosts = ['host1','host2','host3','host4','host5',]
    stat_values = [0,1,2,3,4,]
    for host,value in zip(stat_hosts,stat_values):
        stats.ok[host] = value

    assert stats.summarize('host1') == dict(ok=0, failures=0, unreachable=0, changed=0, skipped=0, rescued=0, ignored=0)
    assert stats.summarize('host2') == dict(ok=1, failures=0, unreachable=0, changed=0, skipped=0, rescued=0, ignored=0)

# Generated at 2022-06-22 20:20:07.191671
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    res = AggregateStats()
    # test case 1:
    res.update_custom_stats("x", "X", "h1")
    expected_custom = {"h1": {"x": "X"}}
    assert res.custom == expected_custom, "Error on test case 1"

    # test case 2:
    res.update_custom_stats("x", "X", "h2")
    expected_custom = {"h1": {"x": "X"}, "h2": {"x": "X"}}
    assert res.custom == expected_custom, "Error on test case 2"

    # test case 3:
    res.update_custom_stats("x", "Y", "h1")
    expected_custom = {"h1": {"x": "Y"}, "h2": {"x": "X"}}

# Generated at 2022-06-22 20:20:17.055304
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    a = AggregateStats()
    assert a.custom == {}
    a.set_custom_stats('foo', 'bar', host='localhost')
    assert a.custom == {'localhost': {'foo': 'bar'}}
    a.set_custom_stats('foo', 'bar')
    assert a.custom == {'localhost': {'foo': 'bar'}, '_run': {'foo': 'bar'}}
    a.set_custom_stats('foo', 'baz', host='localhost')
    assert a.custom == {'localhost': {'foo': 'baz'}, '_run': {'foo': 'bar'}}
    a.set_custom_stats('baz', {'bat': 'bam'}, host='localhost')

# Generated at 2022-06-22 20:20:23.233390
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 1
    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 2


# Generated at 2022-06-22 20:20:31.449825
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok['host1'] = 1
    stats.failures['host1'] = 2
    stats.dark['host1'] = 3
    stats.changed['host1'] = 4
    stats.skipped['host1'] = 5
    stats.rescued['host1'] = 6
    stats.ignored['host1'] = 7
    stats_summary = stats.summarize('host1')
    assert stats_summary['ok'] == 1
    assert stats_summary['failures'] == 2
    assert stats_summary['unreachable'] == 3
    assert stats_summary['changed'] == 4
    assert stats_summary['skipped'] == 5
    assert stats_summary['rescued'] == 6
    assert stats_summary['ignored'] == 7



# Generated at 2022-06-22 20:20:43.082198
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('foo', 2, 'host1')
    assert stats.update_custom_stats('foo', 2, 'host1') == 4
    assert stats.custom['host1']['foo'] == 4
    assert stats.update_custom_stats('bar', 2, 'host1') == 2
    assert stats.custom['host1']['bar'] == 2
    assert stats.update_custom_stats('foo', 4, 'host1') == 8
    assert stats.custom['host1']['foo'] == 8
    assert stats.update_custom_stats('foo', {'a': 1, 'b': 2}, 'host1') == {'a': 1, 'b': 2, 'foo': 8}

# Generated at 2022-06-22 20:20:45.681206
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('dark', 'localhost')
    assert stats.dark['localhost'] == 1
    stats.increment('dark', 'localhost')
    assert stats.dark['localhost'] == 2


# Generated at 2022-06-22 20:20:56.600408
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    as1 = AggregateStats()
    as1.increment('ok', 'host1')
    as1.increment('ok', 'host1')
    as1.increment('ok', 'host1')
    as1.increment('ok', 'host2')
    as1.increment('failures', 'host1')
    as1.increment('failures', 'host2')


    assert as1.summarize('host1') == {'ok': 3, 'failures': 1, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'ignored': 0}
    assert as1.summarize('host2') == {'ok': 1, 'failures': 1, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'ignored': 0}

# Generated at 2022-06-22 20:21:07.894857
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment("ok", "host1")
    stats.increment("ok", "host1")
    stats.increment("ok", "host1")
    stats.increment("failures", "host2")
    stats.increment("failures", "host2")
    stats.increment("dark", "host3")
    stats.increment("dark", "host3")
    stats.increment("dark", "host3")
    stats.increment("dark", "host3")

    res = stats.summarize("ip")
    assert res["ok"] == 0
    assert res["failures"] == 0
    assert res["unreachable"] == 0
    assert res["changed"] == 0
    assert res["skipped"] == 0
    assert res["rescued"] == 0


# Generated at 2022-06-22 20:21:13.854290
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregateStats = AggregateStats()
    aggregateStats.increment('ok', '127.0.0.1')
    aggregateStats.increment('skipped', '127.0.0.1')

    # ok should be 1
    assert aggregateStats.summarize('127.0.0.1')['ok'] == 1

    # skipped should be 1
    assert aggregateStats.summarize('127.0.0.1')['skipped'] == 1



# Generated at 2022-06-22 20:21:24.921681
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    import json
    import sys
    import unittest

    _stats = AggregateStats()
    _stats.increment("ok", "localhost")
    _stats.increment("ok", "localhost")
    _stats.increment("ok", "localhost")
    _stats.increment("ok", "localhost")
    _stats.increment("failures", "localhost")
    _stats.increment("failures", "localhost")
    _stats.increment("ok", "otherhost")

    """
    Returns the summarized data for the given host.
    """

    _result = _stats.summarize(str("localhost"))

# Generated at 2022-06-22 20:21:28.728585
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('aggregate_status', 'success', 'localhost')
    assert stats.custom['localhost']['aggregate_status'] == 'success'


# Generated at 2022-06-22 20:21:38.153391
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Verify merging of two hashes using method update_custom_stats of class AggregateStats
    aggregate_stats = AggregateStats()
    custom_stats_1 = {'hash': {'k1': 'v1', 'k2': 'v2'}}
    host_1 = "test_host_1"
    aggregate_stats.update_custom_stats("test_key", custom_stats_1, host_1)
    assert aggregate_stats.custom[host_1]["test_key"] == custom_stats_1['hash'], "Hashes did not merge correctly."

    # Verify merging of two hashes using method update_custom_stats of class AggregateStats
    custom_stats_2 = {'k1': 'v5', 'k3': 'v3'}

# Generated at 2022-06-22 20:21:44.194222
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Setup
    from ansible import constants as C

    # Execute
    A = AggregateStats()
    A.decrement('failures','localhost')
    A.decrement('failures','localhost')
    A.decrement('failures','localhost')

    # Verify
    assert A.failures['localhost'] == 0


# Generated at 2022-06-22 20:21:46.651916
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('total', 5)
    assert stats.custom['_run']['total'] == 5

    stats.update_custom_stats('total', 7)
    assert stats.custom['_run']['total'] == 12

# Generated at 2022-06-22 20:21:54.364832
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('first', 'one')
    assert stats.custom['_run']['first'] == 'one'
    stats.set_custom_stats('first', 2, '10.0.0.1')
    assert stats.custom['10.0.0.1']['first'] == 2
    stats.set_custom_stats('second', 'two', '10.0.0.2')
    stats.set_custom_stats('second', 3, '10.0.0.2')
    assert stats.custom['10.0.0.2']['second'] == 'two'
    assert stats.custom['_run']['first'] == 'one'


# Generated at 2022-06-22 20:22:03.031887
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats("test_int", 2)
    stats.set_custom_stats("test_float", 2.0)
    stats.set_custom_stats("test_string", "2.0")
    stats.set_custom_stats("test_boolean", True)
    stats.set_custom_stats("test_dict", {'a': 'b'})
    assert stats.custom['_run']['test_int'] == 2
    assert stats.custom['_run']['test_float'] == 2.0
    assert stats.custom['_run']['test_string'] == "2.0"
    assert stats.custom['_run']['test_boolean'] is True

# Generated at 2022-06-22 20:22:07.382948
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement("ignored", "all")
    assert stats.ignored['all'] == 0
    stats.ignored['all'] = 1
    stats.decrement("ignored", "all")
    assert stats.ignored['all'] == 0

# Generated at 2022-06-22 20:22:12.072432
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ags = AggregateStats()
    host = 'test'
    what = 'ok'
    ags.increment(what, host)
    ags.increment(what, host)
    ags.decrement(what, host)
    assert ags.ok[host] == 1, "test_AggregateStats_decrement failed"


# Generated at 2022-06-22 20:22:13.419045
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats is not None


# Generated at 2022-06-22 20:22:24.428741
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():

    from ansible.utils.vars import combine_vars
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    stats = AggregateStats()

    stats.increment('failures', 'example')
    stats.increment('ignored', 'example')
    stats.increment('ok', 'example')
    stats.increment('dark', 'example')
    stats.increment('changed', 'example')
    stats.increment('skipped', 'example')
    stats.increment('rescued', 'example')

    p = PlayContext()
    to_exec = None

    stats.set_custom_stats('foo', 'value')
    stats.set_custom_stats('foo', 'value', 'example')

# Generated at 2022-06-22 20:22:33.553424
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    a = AggregateStats()
    assert (a.custom.get('_run', 'None') == None)

    # dict-dict aggregation
    a.set_custom_stats('foo', {'x':1}, '_run')
    a.update_custom_stats('foo', {'x':1, 'y':2}, '_run')
    assert (a.custom['_run']['foo'] == {'x':2, 'y':2})

    # str-str concatenation
    a.set_custom_stats('foo', 'x', '_run')
    a.update_custom_stats('foo', 'y', '_run')
    assert (a.custom['_run']['foo'] == 'xy')

    # int-int addition

# Generated at 2022-06-22 20:22:37.766640
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok.get('localhost', 0) == 1
    stats.increment('ok', 'localhost')
    assert stats.ok.get('localhost', 0) == 2


# Generated at 2022-06-22 20:22:45.600124
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment("ok", "localhost")
    stats.increment("ok", "localhost")
    stats.increment("ok", "localhost")
    assert stats.ok["localhost"] > 0
    stats.decrement("ok", "localhost")
    assert stats.ok["localhost"] > 0
    stats.decrement("ok", "localhost")
    assert stats.ok["localhost"] > 0
    stats.decrement("ok", "localhost")
    assert stats.ok["localhost"] == 0


if __name__ == '__main__':
    test_AggregateStats_decrement()

# Generated at 2022-06-22 20:22:52.339162
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host')
    assert stats.ok == {'host': 1}
    stats.increment('ok', 'host')
    assert stats.ok == {'host': 2}
    for i in xrange(3):
        stats.increment('dark', 'host')
    assert stats.dark == {'host': 3}
    assert stats.processed == {'host': 1}



# Generated at 2022-06-22 20:23:02.292027
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    # List
    aggregate_stats.update_custom_stats('list_key', [1, 2, 3])
    assert aggregate_stats.custom['_run']['list_key'] == [1, 2, 3]
    aggregate_stats.update_custom_stats('list_key', [1, 2, 3])
    assert aggregate_stats.custom['_run']['list_key'] == [1, 2, 3, 1, 2, 3]
    aggregate_stats.update_custom_stats('list_key', [1, 2, 3, 4])
    assert aggregate_stats.custom['_run']['list_key'] == [1, 2, 3, 1, 2, 3, 1, 2, 3, 4]
    # Dict

# Generated at 2022-06-22 20:23:05.621070
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    test1 = AggregateStats()
    test1.set_custom_stats('which', 'what', 'host')
    assert test1.custom['host']['which'] == 'what'


# Generated at 2022-06-22 20:23:11.963924
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    as1 = AggregateStats()
    assert as1.processed == {}
    assert as1.failures == {}
    assert as1.ok == {}
    assert as1.dark == {}
    assert as1.changed == {}
    assert as1.skipped == {}
    assert as1.rescued == {}
    assert as1.ignored == {}
    assert as1.custom == {}


# Generated at 2022-06-22 20:23:21.629866
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    agg_stats = AggregateStats()
    agg_stats.update_custom_stats('custom_stat', 3, 'host1')
    agg_stats.update_custom_stats('custom_stat', 1, 'host1')
    agg_stats.update_custom_stats('custom_stat', '1', 'host1')

    assert agg_stats.custom['host1']['custom_stat'] == 4
    agg_stats.update_custom_stats('custom_stat', {'a': 1}, 'host1')
    agg_stats.update_custom_stats('custom_stat', {'b': 2}, 'host2')

    assert agg_stats.custom['host1']['custom_stat'] == {'a': 1, 'b': 2}

# Generated at 2022-06-22 20:23:22.567206
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()

# Generated at 2022-06-22 20:23:32.711298
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('ok', 'host3')
    stats.increment('failures', 'host2')
    stats.increment('failures', 'host3')
    stats.increment('dark', 'host3')
    stats.increment('dark', 'host1')
    stats.increment('dark', 'host1')
    stats.increment('changed', 'host1')
    stats.increment('changed', 'host2')
    stats.increment('changed', 'host3')
    stats.increment('changed', 'host1')

# Generated at 2022-06-22 20:23:35.857788
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host123')
    assert stats.processed == {'host123':1}, 'processed'
    assert stats.ok == {'host123':1}, 'ok'


# Generated at 2022-06-22 20:23:42.930144
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    stats.increment('ok', 'testhost')

    # Check if ok value for host 'testhost' are incremented
    assert stats.ok['testhost'] == 1

    stats.increment('ok', 'testhost')

    # Check if ok value for host 'testhost' are incremented
    assert stats.ok['testhost'] == 2

    # Check if processed value for host 'testhost' is 1
    assert stats.processed['testhost'] == 1


# Generated at 2022-06-22 20:23:54.756583
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg_stats = AggregateStats()
    agg_stats.set_custom_stats('foo', 1)
    assert agg_stats.custom['_run']['foo'] == 1
    agg_stats.set_custom_stats('foo', 2, 'host1')
    assert agg_stats.custom['host1']['foo'] == 2
    agg_stats.set_custom_stats('foo', 3)
    agg_stats.set_custom_stats('bar', 4, 'host1')
    assert agg_stats.custom['_run']['foo'] == 3
    assert agg_stats.custom['host1']['foo'] == 2
    assert agg_stats.custom['_run']['bar'] == 4
    assert agg_stats.custom['host1']['bar'] == 4


# Generated at 2022-06-22 20:23:57.170882
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg = AggregateStats()
    agg.decrement('failures', 'host')
    assert agg.failures == {'host': 0}

# Generated at 2022-06-22 20:24:06.301656
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import become_loader, connection_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    play_context = PlayContext()
    strategy = StrategyBase(play_context)
    strategy._become = become_loader.get('sudo') or become_loader.get('su')
    strategy._connection = connection_loader.get('local')
    loader, inventory, variable_manager = PlaybookExecutor.load_playbook_from_file(playbook_path="playbook_path", inventory="inventory")

# Generated at 2022-06-22 20:24:12.275735
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg = AggregateStats()

    assert agg.processed == {}
    assert agg.failures == {}
    assert agg.ok == {}
    assert agg.dark == {}
    assert agg.changed == {}
    assert agg.skipped == {}
    assert agg.rescued == {}
    assert agg.ignored == {}
    assert agg.custom == {}


# Generated at 2022-06-22 20:24:19.333323
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    a = AggregateStats()
    a.ok = {'host1': 1, 'host2': 2, 'host3': 3}
    a.failures = {'host1': 1, 'host2': 2, 'host3': 3}
    rval = a.summarize('host1')
    assert rval=={'ok': 1, 'failures': 1, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}

# Generated at 2022-06-22 20:24:28.339535
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert(isinstance(stats, AggregateStats))
    assert(stats.processed == {})
    assert(stats.failures == {})
    assert(stats.ok == {})
    assert(stats.dark == {})
    assert(stats.changed == {})
    assert(stats.skipped == {})
    assert(stats.rescued == {})
    assert(stats.ignored == {})
    assert(stats.custom == {})


# Generated at 2022-06-22 20:24:40.343846
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    agg_stats = AggregateStats()

    agg_stats.update_custom_stats('sum', 5.1)
    assert agg_stats.custom['_run']['sum'] == 5.1

    agg_stats.update_custom_stats('sum', 5.1)
    assert agg_stats.custom['_run']['sum'] == 10.2

    agg_stats.update_custom_stats('sum', 'text')
    assert agg_stats.custom['_run']['sum'] == 'text'

    agg_stats.update_custom_stats('dict', {'a': 1})
    assert agg_stats.custom['_run']['dict'] == {'a': 1}

    agg_stats.update_custom_stats('dict', {'b': 1})

# Generated at 2022-06-22 20:24:51.866791
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok['host'] = 1
    stats.ok['host2'] = 2

    stats.failures['host'] = 3
    stats.failures['host2'] = 4

    stats.dark['host'] = 5
    stats.dark['host2'] = 6

    stats.changed['host'] = 7
    stats.changed['host2'] = 8

    stats.skipped['host'] = 9
    stats.skipped['host2'] = 10

    stats.rescued['host'] = 11
    stats.rescued['host2'] = 12

    stats.ignored['host'] = 13
    stats.ignored['host2'] = 14


# Generated at 2022-06-22 20:24:54.826762
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    for i in stats.__dict__:
        assert isinstance(stats.__dict__[i], dict)


# Generated at 2022-06-22 20:25:02.805592
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    a = AggregateStats()
    a.increment('ok', '1.1.1.1')
    a.increment('ok', '1.1.1.1')
    a.increment('ok', '1.1.1.1')
    a.increment('ok', '1.1.1.1')
    a.decrement('ok', '1.1.1.1')
    assert a.ok['1.1.1.1'] == 3