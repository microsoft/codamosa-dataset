

# Generated at 2022-06-22 20:15:01.429764
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('skipped', 'test')
    assert stats.skipped == {'test': 1}

    stats.decrement('skipped', 'test')
    assert stats.skipped == {'test': 0}

    assert stats.skipped.get('test', 0) == 0


# Generated at 2022-06-22 20:15:06.012936
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg_stats = AggregateStats()
    agg_stats.set_custom_stats("test_bool", True)
    assert agg_stats.custom["_run"]["test_bool"] == True
    agg_stats.set_custom_stats("test_int", 5)
    assert agg_stats.custom["_run"]["test_int"] == 5
    agg_stats.set_custom_stats("test_str", "foo")
    assert agg_stats.custom["_run"]["test_str"] == "foo"
    agg_stats.set_custom_stats("test_list", ["foo", "bar"])
    assert agg_stats.custom["_run"]["test_list"] == ["foo", "bar"]
    agg_stats.set_custom_stats("test_dict", {"foo": "bar"})
   

# Generated at 2022-06-22 20:15:11.013948
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    if not isinstance(stats.ok, dict):
        raise AssertionError('AggregateStats ok is not a dictionary')
    if not isinstance(stats.custom, dict):
        raise AssertionError('AggregateStats custom is not a dictionary')
    if stats.ok or stats.custom:
        raise AssertionError('AggregateStats ok and custom were not initialized empty')

# Generated at 2022-06-22 20:15:20.336959
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    a = AggregateStats()
    assert a.custom == {}
    a.set_custom_stats("foo", "bar")
    assert a.custom == {'_run': {'foo': 'bar'}}

    a.set_custom_stats("foo", 42, host="127.0.0.1")
    assert a.custom == {'_run': {'foo': 'bar'}, '127.0.0.1': {'foo': 42}}

    a.set_custom_stats("foo", 42)
    assert a.custom == {'_run': {'foo': 42}, '127.0.0.1': {'foo': 42}}

    a.set_custom_stats("foo", "bar", host="127.0.0.1")

# Generated at 2022-06-22 20:15:25.721723
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment("ok", "host1")
    stats.increment("ok", "host2")
    stats.decrement("ok", "host1")
    stats.decrement("ok", "host2")

    assert stats.ok == {'host1': 0, 'host2': 0}

# Generated at 2022-06-22 20:15:30.965805
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():

  # Arrange
  aggr_stats = AggregateStats()
  aggr_stats.set_custom_stats('foo', 'bar')
  aggr_stats.set_custom_stats('foo', 'bar')

  # Assert
  assert aggr_stats.custom['_run']['foo'] == 'bar'


# Generated at 2022-06-22 20:15:38.806768
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    my_stats = AggregateStats()

    # Test if we can set a custom global stat
    my_stats.set_custom_stats('foo', 'bar')
    assert my_stats.custom['_run']['foo'] == 'bar'

    # Test if we can set a custom host stat
    my_stats.set_custom_stats('foo', 'bar', 'myhost')
    assert my_stats.custom['myhost']['foo'] == 'bar'


# Generated at 2022-06-22 20:15:45.348942
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('failures', 'host1')
    aggregate_stats.increment('failures', 'host1')
    aggregate_stats.increment('failures', 'host2')
    aggregate_stats.increment('failures', 'host2')
    aggregate_stats.increment('failures', 'host2')

    assert aggregate_stats.failures == {'host1': 2, 'host2': 3}
    aggregate_stats.decrement('failures', 'host1')
    assert aggregate_stats.failures == {'host1': 1, 'host2': 3}
    aggregate_stats.decrement('failures', 'host2')
    assert aggregate_stats.failures == {'host1': 1, 'host2': 2}



# Generated at 2022-06-22 20:15:49.464164
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('test', 1, 'host1')
    stats.set_custom_stats('test', 2, 'host2')
    assert stats.custom['host1']['test'] == 1
    assert stats.custom['host2']['test'] == 2


# Generated at 2022-06-22 20:15:58.992422
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'Machine1')
    aggregate_stats.increment('failures', 'Machine2')
    aggregate_stats.increment('ok', 'Machine1')
    aggregate_stats.increment('ok', 'Machine3')

    assert aggregate_stats.ok['Machine1'] == 2
    assert aggregate_stats.failures['Machine2'] == 1
    assert aggregate_stats.ok['Machine3'] == 1
    assert aggregate_stats.ok == {'Machine1': 2, 'Machine3': 1}
    assert aggregate_stats.failures == {'Machine2': 1}


# Generated at 2022-06-22 20:16:02.657413
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate = AggregateStats()
    aggregate.increment('ok', 'test.local')
    aggregate.increment('ok', 'test.local')
    aggregate.increment('ok', 'test.local')
    assert(aggregate.ok['test.local'] == 3)


# Generated at 2022-06-22 20:16:14.321265
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stat = AggregateStats()

    # test for the case that host is not in the custom dict yet
    stat.update_custom_stats('custom_stat', 1, 'host1')
    assert stat.custom['host1'] == {'custom_stat': 1}

    # test for the case that 'custom_stat' is not in the custom dict yet
    stat.update_custom_stats('custom_stat', 2, 'host2')
    assert stat.custom['host2'] == {'custom_stat': 2}

    # test for the case that 'custom_stat' is in the custom dict and types of current and new value are equal
    stat.update_custom_stats('custom_stat', 2, 'host2')
    assert stat.custom['host2'] == {'custom_stat': 4}

    # test for the case that type of current and

# Generated at 2022-06-22 20:16:22.402984
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('failures', 'test_host')
    stats.increment('failures', 'test_host')
    assert stats.failures['test_host'] == 2
    stats.decrement('failures', 'test_host')
    assert stats.failures['test_host'] == 1

    # Test that the decrement is idempotent
    stats.decrement('failures', 'test_host')
    stats.decrement('failures', 'test_host')
    stats.decrement('failures', 'test_host')
    assert stats.failures['test_host'] == 0

# Generated at 2022-06-22 20:16:23.791729
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    assert stats.increment('changed', 'test')


# Generated at 2022-06-22 20:16:26.873255
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    '''
        Perform unit test for method increment of class AggregateStats
    '''
    a = AggregateStats()

    a.increment('ok', 'test_host')
    assert a.ok['test_host'] == 1

    a.increment('ok', 'test_host')
    assert a.ok['test_host'] == 2



# Generated at 2022-06-22 20:16:30.931548
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg = AggregateStats()
    agg.increment("ok", "host")

    # Check if the host key exsits in the AggregateStats object
    assert agg.ok.has_key("host")
    # Check if the host key has the value 1
    assert agg.ok["host"] == 1


# Generated at 2022-06-22 20:16:37.694302
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg_stats = AggregateStats()

    agg_stats.ok = {'host': 3}
    agg_stats.decrement('ok', 'host')
    assert agg_stats.ok.get('host') == 2

    agg_stats.ok = {'host': 0}
    agg_stats.decrement('ok', 'host')
    assert agg_stats.ok.get('host') == 0

# Generated at 2022-06-22 20:16:48.417564
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    # Create a new object of class AggregateStats
    aggregate_stats = AggregateStats()

    # Set custom stats for a host (in this case the run) and a custom value
    aggregate_stats.set_custom_stats('ad_hoc', 1, '_run')

    # If we want to change the custom value and keep the custom name we need to use set_custom_stats method
    aggregate_stats.set_custom_stats('ad_hoc', 2, '_run')

    # Check if the updated value is there
    assert aggregate_stats.custom['_run']['ad_hoc'] == 2

    # Set custom stats for a host (in this case 'host1') and a custom value
    aggregate_stats.set_custom_stats('ad_hoc2', 3, 'host1')

    # If we want to change the custom

# Generated at 2022-06-22 20:16:51.086149
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 1


# Generated at 2022-06-22 20:16:57.522200
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert isinstance(stats, AggregateStats)
    assert isinstance(stats.processed, dict)
    assert isinstance(stats.failures, dict)
    assert isinstance(stats.ok, dict)
    assert isinstance(stats.dark, dict)
    assert isinstance(stats.changed, dict)
    assert isinstance(stats.skipped, dict)
    assert isinstance(stats.rescued, dict)
    assert isinstance(stats.ignored, dict)



# Generated at 2022-06-22 20:17:09.263638
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('changed', 'host1')
    aggregate_stats.increment('changed', 'host1')
    aggregate_stats.increment('dark', 'host1')
    aggregate_stats.increment('ok', 'host2')
    aggregate_stats.increment('failures', 'host2')
    assert aggregate_stats.summarize('host1') == dict(
        ok=0,
        failures=0,
        unreachable=1,
        changed=2,
        skipped=0,
        rescued=0,
        ignored=0,
    )

# Generated at 2022-06-22 20:17:16.245688
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate = AggregateStats()
    aggregate.set_custom_stats('test1', 'test2')
    assert aggregate.custom['_run'] == {'test1': 'test2'}
    aggregate.set_custom_stats('test3', 'test4', 'test5')
    assert aggregate.custom['test5'] == {'test3': 'test4'}
    aggregate.set_custom_stats('test1', 'test1')
    assert aggregate.custom['_run'] == {'test1': 'test1'}


# Generated at 2022-06-22 20:17:21.639482
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    y = AggregateStats()
    assert y.processed == {}
    assert y.failures == {}
    assert y.ok == {}
    assert y.dark == {}
    assert y.changed == {}
    assert y.skipped == {}
    assert y.rescued == {}
    assert y.ignored == {}
    assert y.custom == {}


# Generated at 2022-06-22 20:17:26.745549
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment("ok", "localhost")
    assert stats.ok["localhost"] == 1
    stats.decrement("ok", "localhost")
    assert stats.ok["localhost"] == 0
    stats.decrement("ok", "localhost")
    assert stats.ok["localhost"] == 0

# Generated at 2022-06-22 20:17:36.971435
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate = AggregateStats()
    aggregate.update_custom_stats("stats", {"changed": 1, "failures": 2, "ok": 3})
    assert aggregate.custom['_run']['stats'] == {"changed": 1, "failures": 2, "ok": 3}
    aggregate.update_custom_stats("stats", {"changed": 1, "failures": 2, "ok": 3})
    assert aggregate.custom['_run']['stats'] == {"changed": 2, "failures": 4, "ok": 6}
    aggregate.update_custom_stats("stats", {"changed": 1, "failures": 2, "ok": 3}, host='localhost')
    assert aggregate.custom['localhost']['stats'] == {"changed": 1, "failures": 2, "ok": 3}

# Generated at 2022-06-22 20:17:41.703577
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    s = AggregateStats()
    assert s._get_data() == {'ok': {},
                             'unreachable': {},
                             'failed': {},
                             'changed': {},
                             'skipped': {},
                             'rescued': {},
                             'ignored': {},
                             'processed': {},
                             'custom': {}}


# Generated at 2022-06-22 20:17:50.310299
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    # Test when host is None
    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats('my_custom_key', 'my_custom_value', None)
    assert aggregate_stats.custom == {'_run': {'my_custom_key': 'my_custom_value'}}
    # Test when host is not None
    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats('my_custom_key', 'my_custom_value', 'my_host')
    assert aggregate_stats.custom == {'my_host': {'my_custom_key': 'my_custom_value'}}


# Generated at 2022-06-22 20:17:56.185844
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    ag = AggregateStats()
    assert ag.processed == {}
    assert ag.failures == {}
    assert ag.ok == {}
    assert ag.dark == {}
    assert ag.changed == {}
    assert ag.skipped == {}
    assert ag.rescued == {}
    assert ag.ignored == {}
    assert ag.custom == {}


# Generated at 2022-06-22 20:18:06.627452
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    astats = AggregateStats()
    astats.update_custom_stats("cow", "moo")
    assert astats.custom["_run"]["cow"] == "moo"
    astats.update_custom_stats("cow", "moo")
    assert astats.custom["_run"]["cow"] == "moomoo"
    astats.update_custom_stats("bikinis", 1)
    assert astats.custom["_run"]["bikinis"] == 1
    astats.update_custom_stats("bikinis", 1)
    assert astats.custom["_run"]["bikinis"] == 2
    astats.update_custom_stats("bikinis", "baby-o")
    assert astats.custom["_run"]["bikinis"] == 2

# Generated at 2022-06-22 20:18:14.868320
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    # class initializes with empty dicts
    assert isinstance(AggregateStats().processed, dict)
    assert isinstance(AggregateStats().failures, dict)
    assert isinstance(AggregateStats().ok, dict)
    assert isinstance(AggregateStats().dark, dict)
    assert isinstance(AggregateStats().changed, dict)
    assert isinstance(AggregateStats().skipped, dict)
    assert isinstance(AggregateStats().rescued, dict)
    assert isinstance(AggregateStats().ignored, dict)

# Generated at 2022-06-22 20:18:19.508556
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    # Create an instance of class AggregateStats
    stats = AggregateStats()
    # Set stats to custom stats
    stats.set_custom_stats('new', 'stat')
    # Check whether stats is set properly
    assert stats.custom['_run']['new']=='stat'


# Generated at 2022-06-22 20:18:27.388351
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert isinstance(stats.processed, dict)
    assert isinstance(stats.failures, dict)
    assert isinstance(stats.ok, dict)
    assert isinstance(stats.dark, dict)
    assert isinstance(stats.changed, dict)
    assert isinstance(stats.skipped, dict)
    assert isinstance(stats.rescued, dict)
    assert isinstance(stats.ignored, dict)
    assert isinstance(stats.custom, dict)


# Generated at 2022-06-22 20:18:32.258404
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg = AggregateStats()
    assert agg.processed == {}
    assert agg.failures == {}
    assert agg.ok == {}
    assert agg.dark == {}
    assert agg.changed == {}
    assert agg.skipped == {}
    assert agg.rescued == {}
    assert agg.ignored == {}
    assert agg.custom == {}


# Generated at 2022-06-22 20:18:40.317598
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok.get('localhost', 0) == 1
    stats.increment('ok', 'localhost')
    assert stats.ok.get('localhost', 0) == 2
    stats.increment('ok', 'remotehost')
    assert stats.ok.get('remotehost', 0) == 1
    stats.increment('failures', 'remotehost')
    assert stats.failures.get('remotehost', 0) == 1


# Generated at 2022-06-22 20:18:46.058824
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggStats = AggregateStats()
    aggStats.set_custom_stats('test', 1, host='test1')
    assert(aggStats.custom['test1']['test'] == 1)

    aggStats.set_custom_stats('test', 2)
    assert(aggStats.custom['_run']['test'] == 2)

    aggStats.set_custom_stats('test', 3)
    assert(aggStats.custom['_run']['test'] == 3)


# Generated at 2022-06-22 20:18:49.299249
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'host1')
    stats.decrement('ok', 'host1')
    assert stats.ok['host1'] == 0

# Generated at 2022-06-22 20:19:00.564519
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    from ansible.utils.vars import merge_hash
    from ansible.module_utils.common._collections_compat import MutableMapping
    as_ = AggregateStats()
    as_.increment('ok', 'host1')
    as_.increment('ok', 'host2')
    as_.decrement('ok', 'host1')
    for i in ('ok', 'dark'):
        for j in ('host1', 'host2'):
            assert i in as_.__dict__
            assert j in as_.__dict__[i]
            assert as_.__dict__[i][j] == 1
            assert isinstance(as_.__dict__[i], dict)
            assert isinstance(as_.__dict__[i][j], int)

# Generated at 2022-06-22 20:19:03.357272
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats('foo', 'bar', host='test_host')
    assert aggregate_stats.custom['test_host']['foo'] == 'bar'


# Generated at 2022-06-22 20:19:14.126469
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():

    # summarize of empty object
    s = AggregateStats()
    assert s.summarize(None) == {'ok': 0, 'changed': 0, 'failures': 0, 'unreachable': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}

    # summarize of an object with one set of stats
    s.increment('ok', 'host1')
    s.increment('failures', 'host1')
    s.increment('dark', 'host1')
    s.increment('changed', 'host1')
    s.increment('skipped', 'host1')
    s.increment('rescued', 'host1')
    s.increment('ignored', 'host1')

# Generated at 2022-06-22 20:19:17.475673
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('a', {'a': 'a', 'b': 'b'})
    assert stats.custom['_run']['a'] == {'a': 'a', 'b': 'b'}


# Generated at 2022-06-22 20:19:23.230790
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    x = AggregateStats()
    x.increment('ok', 'foo')
    x.increment('ok', 'foo')
    x.increment('ok', 'bar')
    assert x.ok['foo'] == 2
    assert x.ok['bar'] == 1

# Generated at 2022-06-22 20:19:26.142194
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    as_obj = AggregateStats()
    assert isinstance(as_obj, AggregateStats)


# Generated at 2022-06-22 20:19:31.960945
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    host = 'localhost'
    # Decrement a statistic
    stats.decrement("failures", host)
    # Retrieve the statistic
    failures = stats.failures.get(host, 0)
    assert failures == 0
    # Decrement a statistic
    stats.decrement("failures", host)
    # Retrieve the statistic
    failures = stats.failures.get(host, 0)
    assert failures == 0



# Generated at 2022-06-22 20:19:37.706403
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment("failures", "test")
    assert aggregate_stats.failures == { "test": 1 }
    aggregate_stats.increment("failures", "test")
    assert aggregate_stats.failures == { "test": 2 }

# Generated at 2022-06-22 20:19:43.286549
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    """
    >>> stats = AggregateStats()
    >>> stats.processed
    {}
    >>> stats.failures
    {}
    >>> stats.ok
    {}
    >>> stats.dark
    {}
    >>> stats.changed
    {}
    >>> stats.skipped
    {}
    >>> stats.rescued
    {}
    >>> stats.ignored
    {}
    >>> stats.custom
    {}
    """


# Generated at 2022-06-22 20:19:49.188138
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    # Verify that the constructor sets all the required variables
    astats = AggregateStats()
    assert astats.processed is not None
    assert astats.failures is not None
    assert astats.ok is not None
    assert astats.dark is not None
    assert astats.changed is not None
    assert astats.skipped is not None
    assert astats.rescued is not None
    assert astats.ignored is not None
    assert astats.custom is not None



# Generated at 2022-06-22 20:19:55.503429
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    import os, sys
    my_path = '/home/helios/anaconda3/lib/python3.7/site-packages/ansible'
    sys.path.insert(1, my_path)
    a = AggregateStats()
    print(a)


if __name__ == '__main__':
    test_AggregateStats()

# Generated at 2022-06-22 20:20:01.089224
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ans = AggregateStats()

    ans.increment('ok', 'localhost')
    assert ans.ok['localhost'] == 1
    assert ans.failures['localhost'] == 0
    assert ans.processed['localhost'] == 1

    ans.increment('ok', 'localhost')
    assert ans.ok['localhost'] == 2
    assert ans.failures['localhost'] == 0
    assert ans.processed['localhost'] == 1


# Generated at 2022-06-22 20:20:12.223270
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    # Arrange
    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats("test", 0)
    aggregate_stats.set_custom_stats("test", 1, "localhost")
    aggregate_stats.set_custom_stats("another_test", {"test": "test"})
    aggregate_stats.set_custom_stats("another_test", [{}, {"test": 1}], "localhost")
    # Assert
    assert aggregate_stats.custom["_run"]["test"] == 0
    assert aggregate_stats.custom["localhost"]["test"] == 1
    assert aggregate_stats.custom["_run"]["another_test"] == {"test": "test"}
    assert aggregate_stats.custom["localhost"]["another_test"] == [{}, {"test": 1}]


# Generated at 2022-06-22 20:20:17.293097
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()

    what = "hello world"
    which = "custom_stats_name"

    stats.set_custom_stats(which, what)
    assert stats.custom['_run'] == {'custom_stats_name': 'hello world'}

    stats.set_custom_stats(which, what, 'localhost')
    assert stats.custom['localhost'] == {'custom_stats_name': 'hello world'}


# Generated at 2022-06-22 20:20:27.239106
# Unit test for constructor of class AggregateStats
def test_AggregateStats():  # noqa
    test = AggregateStats()
    test.increment("ok", "127.0.0.1")
    test.increment("ok", "127.0.0.1")
    test.increment("ok", "127.0.0.2")
    assert test.ok["127.0.0.1"] == 2
    assert test.ok["127.0.0.2"] == 1
    assert len(test.ok) == 2

# Generated at 2022-06-22 20:20:36.926461
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('failures', 'localhost')

    # Verify that dict of stats has been returned
    assert isinstance(stats.summarize('localhost'), dict)

    # Verify that values are correct
    assert stats.summarize('localhost').get('ok', 0) == 2
    assert stats.summarize('localhost').get('failures', 0) == 1

# Generated at 2022-06-22 20:20:46.092541
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    # >>>> test a string
    stats.update_custom_stats('a_string', 'a string', '_run')
    assert stats.custom['_run']['a_string'] == 'a string'

    stats.update_custom_stats('a_string', 'another string', '_run')
    assert stats.custom['_run']['a_string'] == 'a stringanother string'

    # >>>> test a number
    stats.update_custom_stats('a_number', 1, '_run')
    assert stats.custom['_run']['a_number'] == 1

    stats.update_custom_stats('a_number', 1, '_run')
    assert stats.custom['_run']['a_number'] == 2

    # >>>> test a list

# Generated at 2022-06-22 20:20:52.394839
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats("http_sleep_time", 10)
    assert aggregate_stats.custom["_run"]["http_sleep_time"] == 10
    aggregate_stats.update_custom_stats("http_sleep_time", 10)
    assert aggregate_stats.custom["_run"]["http_sleep_time"] == 20

# Generated at 2022-06-22 20:21:03.140804
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    assert stats.custom == {}

    stats.update_custom_stats(which='tests', what=1)
    assert stats.custom['_run']['tests'] == 1

    stats.update_custom_stats(which='tests', what=2)
    assert stats.custom['_run']['tests'] == 3

    stats.update_custom_stats(which='tests', what=1, host='myhost')
    assert stats.custom['myhost']['tests'] == 1
    assert stats.custom['_run']['tests'] == 3

    # Mismatching types
    stats.update_custom_stats(which='tests', what={'a': 2}, host='myhost')
    assert stats.custom['myhost']['tests'] == {'a': 2}

# Generated at 2022-06-22 20:21:13.479891
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    stats.set_custom_stats('dict', {'key':'value'})
    stats.set_custom_stats('dict', {'key':'value'}, host='localhost')
    stats.update_custom_stats('dict', {'key':'value'}, host='localhost')

    # mismatching types
    stats.update_custom_stats('dict', 'value', host='localhost')
    stats.update_custom_stats('dict', [1,2,3], host='localhost')

    # unset stats
    stats.update_custom_stats('dict', {'key':'value'})
    stats.update_custom_stats('dict', {'key':'value'}, host='example.com')

    stats.update_custom_stats('numeric', 1000)
    stats.update_custom_stats

# Generated at 2022-06-22 20:21:20.936974
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats('foo', 'bar')
    aggregate_stats.set_custom_stats('foo', 'otherbar', 'test_host')
    assert aggregate_stats.custom['_run']['foo'] == 'bar'
    assert aggregate_stats.custom['test_host']['foo'] == 'otherbar'


# Generated at 2022-06-22 20:21:29.789709
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    import sys
    sys.path.insert(0, '../')
    from lib.utils import get_config

    # Reset config
    config = get_config()
    config.reset()

    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext

    s = AggregateStats()
    s.increment('changed', 'testhost')
    s.increment('changed', 'testhost2')
    s.increment('skipped', 'testhost')
    s.increment('skipped', 'testhost')
    s.increment('skipped', 'testhost2')

    # Stub Host
    testhost = Host('testhost')
    testhost2 = Host('testhost2')
    play_context = PlayContext()

    assert s.summarize(testhost.name)

# Generated at 2022-06-22 20:21:38.996449
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    # Increment Fails because we want to increment and invalid statistic
    stats.increment('invalidstatistic', 'host1')
    assert stats.processed == {'host1': 1}
    assert stats.failures == {'host1': 1}

    # Increment OK on host1 (first time)
    stats.increment('ok', 'host1')
    assert stats.ok == {'host1': 1}

    # Increment OK on host1 (second time)
    stats.increment('ok', 'host1')
    assert stats.ok == {'host1': 2}

    # Increment OK on host2 (first time)
    stats.increment('ok', 'host2')
    assert stats.ok == {'host1': 2, 'host2': 1}

# Unit test

# Generated at 2022-06-22 20:21:50.458973
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggr_stats = AggregateStats()
    aggr_stats.increment('ok', 'host1')
    assert aggr_stats.summarize('host1') == {'ok': 1, 'failures': 0, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}
    aggr_stats.increment('ok', 'host1')
    assert aggr_stats.summarize('host1') == {'ok': 2, 'failures': 0, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}
    aggr_stats.increment('failures', 'host1')

# Generated at 2022-06-22 20:21:58.195341
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment("ok", "localhost")
    stats.increment("ok", "localhost")
    stats.increment("dark", "localhost")
    stats.increment("dark", "localhost")
    stats.increment("dark", "localhost")
    summary = stats.summarize("localhost")
    assert summary["ok"] == 2
    assert summary["unreachable"] == 3
    assert summary["changed"] == 0
    assert summary["failed"] == 0


# Generated at 2022-06-22 20:22:01.984072
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    as_ = AggregateStats()
    as_.update_custom_stats('foo', 1) # update_custom_stats with default host=None
    assert as_.custom['_run']['foo'] == 1
    as_.update_custom_stats('foo', 2)
    assert as_.custom['_run']['foo'] == 2

# Generated at 2022-06-22 20:22:08.153684
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    assert 0 == AggregateStats().decrement('ok', 'host1')
    assert 0 == AggregateStats().decrement('failures', 'host1')
    assert 0 == AggregateStats().decrement('ok', 'host2')
    assert 0 == AggregateStats().decrement('failures', 'host2')


# Generated at 2022-06-22 20:22:15.275485
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok['host1'] = 1
    stats.failures['host2'] = 5
    stats.decrement('failures','host2')
    assert stats.ok['host1'] == 1
    assert stats.failures['host2'] == 4
    try:
        stats.decrement('failures','host2')
        stats.failures['host2'] == -1
        raise RuntimeError("This should not have happened")
    except KeyError:
        assert stats.failures['host2'] == 0


# Generated at 2022-06-22 20:22:18.324587
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('test', {'a': 1, 'b': 2})


# Generated at 2022-06-22 20:22:27.084512
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ag = AggregateStats()
    ag.increment("ok", host='localhost')
    assert ag.ok['localhost'] == 1
    ag.increment("ok", host='localhost')
    assert ag.ok['localhost'] == 2
    ag.decrement("ok", host='localhost')
    assert ag.ok['localhost'] == 1
    ag.decrement("ok", host='localhost')
    assert ag.ok['localhost'] == 0

    # Test is_host_ok with a host that has no ok value
    ag.decrement("ok", host='somehost')
    assert ag.ok['somehost'] == 0

    # Test that decrementing below 0 throws an error
    try:
        ag.decrement("ok", host='somehost')
        assert False
    except KeyError:
        pass

    # Test decre

# Generated at 2022-06-22 20:22:30.210517
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test = AggregateStats()

    test.increment('ok', 'toto')
    test.decrement('ok', 'toto')

    assert test.ok['toto'] == 0


# Generated at 2022-06-22 20:22:39.514662
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    # Create new object
    ag = AggregateStats()

    # Check correct values for one host
    ag.increment('ok', 'host')
    ag.increment('ok', 'host')
    assert ag.processed['host'] == 1
    assert ag.ok['host'] == 2

    # Check correct values for another host
    ag.increment('ok', 'another_host')
    assert ag.processed['another_host'] == 1
    assert ag.ok['another_host'] == 1

    # Check correct values for a third host
    ag.increment('skipped', 'host')
    assert ag.skipped['host'] == 1
    assert ag.processed['host'] == 1

    # Check all hosts are processed
    assert len(ag.processed) == 3


# Generated at 2022-06-22 20:22:50.783120
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import pytest

    def test_data(what, expected, pre_data=None):
        aggregatestats = AggregateStats()
        if pre_data:
            aggregatestats.custom['_run'] = pre_data
        aggregatestats.update_custom_stats('globals', what)
        assert aggregatestats.get_custom_stats('globals', '_run') == expected

    with pytest.raises(KeyError):
        test_data(1, None)

    test_data(1, 1)
    test_data(2, 3)

    test_data({'k1': 1, 'k2': 2}, {'k1': 1, 'k2': 2})

# Generated at 2022-06-22 20:22:58.520266
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()

    # decrement operations
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

    stats.ok['localhost'] = 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

    stats.ok['localhost'] = 0
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0

# Generated at 2022-06-22 20:23:03.684875
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    # GIVEN a running host
    stats = AggregateStats()
    stats.increment("ok", "localhost")

    # WHEN host is summarized
    summary = stats.summarize("localhost")

    # THEN summary should indicate a running host
    assert summary["ok"] == 1
    assert summary["failures"] == 0
    assert summary["unreachable"] == 0
    assert summary["changed"] == 0
    assert summary["skipped"] == 0
    assert summary["rescued"] == 0
    assert summary["ignored"] == 0


# Generated at 2022-06-22 20:23:15.026639
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    assert stats == AggregateStats()
    stats.increment("ok", "localhost")
    assert stats == AggregateStats()
    stats.increment("ok", "localhost")
    assert stats.processed == {"localhost": 1}
    assert stats.ok == {"localhost": 2}
    stats.increment("ok", "cloud.example.org")
    assert stats.processed == {"localhost": 1, "cloud.example.org": 1}
    assert stats.ok == {"localhost": 2, "cloud.example.org": 1}
    stats.increment("ok", "cloud.example.org")
    assert stats.processed == {"localhost": 1, "cloud.example.org": 1}
    assert stats.ok == {"localhost": 2, "cloud.example.org": 2}


# Generated at 2022-06-22 20:23:23.983897
# Unit test for method summarize of class AggregateStats

# Generated at 2022-06-22 20:23:26.163485
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    a = AggregateStats()
    a.increment('failures', 'localhost')
    assert a.failures['localhost'] == 1


# Generated at 2022-06-22 20:23:31.937798
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    assert AggregateStats().custom == {}
    assert AggregateStats().dark == {}
    assert AggregateStats().skipped == {}
    assert AggregateStats().failures == {}
    assert AggregateStats().processed == {}
    assert AggregateStats().changed == {}
    assert AggregateStats().ignored == {}
    assert AggregateStats().ok == {}
    assert AggregateStats().rescued == {}


# Generated at 2022-06-22 20:23:38.825943
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats("key", "a", "host")
    aggregate_stats.update_custom_stats("key", "b", "host")
    assert aggregate_stats.custom["host"]["key"] == "ab"

    aggregate_stats.set_custom_stats("key", {"a": 1}, "host")
    aggregate_stats.update_custom_stats("key", {"b": 2}, "host")
    assert aggregate_stats.custom["host"]["key"] == {"a": 1, "b": 2}

# Generated at 2022-06-22 20:23:48.304094
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    instance = AggregateStats()
    assert instance.increment("ignored", "_run") == None
    instance = AggregateStats()
    assert instance.increment("ok", "_run") == None
    instance = AggregateStats()
    assert instance.increment("rescued", "_run") == None
    instance = AggregateStats()
    assert instance.increment("dark", "_run") == None
    instance = AggregateStats()
    assert instance.increment("changed", "_run") == None
    instance = AggregateStats()
    assert instance.increment("skipped", "_run") == None
    instance = AggregateStats()
    assert instance.increment("failures", "_run") == None


# Generated at 2022-06-22 20:23:53.469123
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    a = AggregateStats()
    a.increment('ok', 'localhost')
    a.increment('ok', 'localhost')
    assert a.ok['localhost'] == 2
    assert a.processed['localhost'] == 1


# Generated at 2022-06-22 20:23:55.577735
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    obj = AggregateStats()
    assert isinstance(obj, AggregateStats)



# Generated at 2022-06-22 20:24:03.830634
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    # test when a host has no data
    res = aggregate_stats.summarize('host1')
    assert res == dict(ok=0, failures=0, unreachable=0, changed=0, skipped=0, rescued=0, ignored=0)
    # test when a host has some data
    aggregate_stats.increment('ok', 'host1')
    aggregate_stats.increment('ignored', 'host1')
    aggregate_stats.increment('rescued', 'host1')
    res = aggregate_stats.summarize('host1')
    assert res == dict(ok=1, failures=0, unreachable=0, changed=0, skipped=0, rescued=1, ignored=1)

# Generated at 2022-06-22 20:24:15.610343
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'
    stats.set_custom_stats('foo', 'baz', host='127.0.0.1')
    assert stats.custom['127.0.0.1']['foo'] == 'baz'
    stats.set_custom_stats('foo', 'qux', host='127.0.0.1')
    assert stats.custom['127.0.0.1']['foo'] == 'qux'
    assert stats.custom['_run']['foo'] == 'bar'

    stats.set_custom_stats('bar', 'baz')

# Generated at 2022-06-22 20:24:21.527599
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    test = AggregateStats()

    test.increment('ok', 'localhost')
    assert test.processed.get('localhost', 0) == 1
    assert test.ok.get('localhost', 0) == 1
    assert test.failures.get('localhost', 0) == 0

    test.increment('failures', 'localhost')
    assert test.processed.get('localhost', 0) == 1
    assert test.ok.get('localhost', 0) == 1
    assert test.failures.get('localhost', 0) == 1

    test.increment('failures', 'example.com')
    assert test.processed.get('localhost', 0) == 1
    assert test.processed.get('example.com', 0) == 1
    assert test.ok.get('localhost', 0) == 1

# Generated at 2022-06-22 20:24:31.751590
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('stat1', 'first')
    assert stats.custom['_run']['stat1'] == 'first'
    stats.set_custom_stats('stat1', 'second')
    assert stats.custom['_run']['stat1'] == 'second'
    stats.set_custom_stats('stat1', 'third', 'host1')
    assert stats.custom['host1']['stat1'] == 'third'
    stats.set_custom_stats('stat1', 'fourth', 'host1')
    assert stats.custom['host1']['stat1'] == 'fourth'


# Generated at 2022-06-22 20:24:41.196723
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats("item1", "value1")
    assert aggregate_stats.custom == {"_run": {"item1": "value1"}}

    aggregate_stats.update_custom_stats("item1", "value2", host="host1")
    assert aggregate_stats.custom == {"_run": {"item1": "value1"},
                                       "host1": {"item1": "value2"}}

    aggregate_stats.update_custom_stats("item1", {"key1":"value1", "key2":"value2"}, host="host1")
    assert aggregate_stats.custom == {"_run": {"item1": "value1"},
                                       "host1": {"item1": {"key1":"value1", "key2":"value2"}}}

    # None should not be

# Generated at 2022-06-22 20:24:52.160859
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    test_hosts = ['foo', 'bar', '_run']
    test_what = [0, {'baz': 'qux'}, {'qux': 'baz'}, 'qux']
    test_which = ['baz', 'baz', 'qux', 'baz']
    expected = [0, {'baz': 'qux'}, {'baz': 'qux', 'qux': 'baz'}, 'quxqux']

    for count, host in enumerate(test_hosts):
        for i, which in enumerate(test_which):
            aggregate_stats.set_custom_stats(which, test_what[i], host)

            # test that what is set correctly

# Generated at 2022-06-22 20:24:56.944601
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'host_1')
    assert stats.processed == {'host_1': 1}
    assert stats.ok == {'host_1': 1}
    stats.increment('ok', 'host_1')
    assert stats.processed == {'host_1': 1}
    assert stats.ok == {'host_1': 2}

