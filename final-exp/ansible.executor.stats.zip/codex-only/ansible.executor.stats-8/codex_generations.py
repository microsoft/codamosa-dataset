

# Generated at 2022-06-22 20:15:03.472677
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.custom == {}

    # test with all three types of objects
    which, host = "custom", "test_host"
    aggregate_stats.update_custom_stats(which, 0, host)
    assert aggregate_stats.custom[host][which] == 0
    aggregate_stats.update_custom_stats(which, 1, host)
    aggregate_stats.update_custom_stats(which, 1, host)
    assert aggregate_stats.custom[host][which] == 2

    which, host = "custom", "test_host"
    aggregate_stats.update_custom_stats(which, 0.1, host)
    assert round(aggregate_stats.custom[host][which], 3) == 0.1

# Generated at 2022-06-22 20:15:09.158378
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    a = AggregateStats()
    assert a.processed == {}
    assert a.failures == {}
    assert a.ok == {}
    assert a.dark == {}
    assert a.changed == {}
    assert a.skipped == {}
    assert a.rescued == {}
    assert a.ignored == {}
    assert a.custom == {}


# Generated at 2022-06-22 20:15:16.924039
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    # Test for initial custom stats creation with dict
    as1 = AggregateStats()
    as1.update_custom_stats('test_stats', {'test_key1': 'test_value1'})
    assert as1.custom['_run']['test_stats'] == {'test_key1': 'test_value1'}

    # Test for initial custom stats creation with lists
    as2 = AggregateStats()
    as2.update_custom_stats('test_stats', ['test_value1', 'test_value2'])
    assert as2.custom['_run']['test_stats'] == ['test_value1', 'test_value2']

    # Test for initial custom stats creation with ints
    as3 = AggregateStats()
    as3.update_custom_stats('test_stats', 4)

# Generated at 2022-06-22 20:15:28.294608
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('foo', 1)
    stats.set_custom_stats('foo', 1, 'host_1')
    stats.set_custom_stats('foo', 1, 'host_2')
    stats.set_custom_stats('bar', 'baz')
    stats.set_custom_stats('bar', 'baz', 'host_1')
    stats.set_custom_stats('bar', 'baz', 'host_2')

    assert stats.custom == {'_run': {'foo': 1, 'bar': 'baz'}, 'host_1': {'foo': 1, 'bar': 'baz'}, 'host_2': {'foo': 1, 'bar': 'baz'}}
    stats.update_custom_stats('foo', 1)

# Generated at 2022-06-22 20:15:36.042956
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.summarize('localhost')['ok'] == 1
    stats.increment('ok', 'localhost')
    assert stats.summarize('localhost')['ok'] == 2
    stats.increment('ok', 'localhost')
    assert stats.summarize('localhost')['ok'] == 3
    stats.increment('ok', 'localhost')
    assert stats.summarize('localhost')['ok'] == 4



# Generated at 2022-06-22 20:15:40.891401
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.ok == {}
    assert stats.failures == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}
    assert stats.processed == {}


# Generated at 2022-06-22 20:15:45.096572
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    print(stats.processed)
    print(stats.failures)
    print(stats.ok)
    print(stats.dark)
    print(stats.changed)
    print(stats.skipped)
    print(stats.rescued)

if __name__ == "__main__":
    test_AggregateStats()

# Generated at 2022-06-22 20:15:51.297290
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    def _init_aggregate_stats():
        aggregate_stats = AggregateStats()
        aggregate_stats.custom = {
            '_run': {'some_list': [1, 2, 3]},
            'host_2': {'some_list': [4, 5, 6]},
        }
        return aggregate_stats


    aggregate_stats = _init_aggregate_stats()

    # test merging lists
    list_to_merge = [7, 8, 9]
    aggregate_stats.update_custom_stats('some_list', list_to_merge)
    assert aggregate_stats.custom['_run']['some_list'] == [1, 2, 3, 7, 8, 9]

    aggregate_stats = _init_aggregate_stats()

    # test merging multiple lists
    aggregate_stats.update

# Generated at 2022-06-22 20:16:01.551288
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    import sys
    sys.path.insert(0, '/')

    stats = AggregateStats()
    stats.set_custom_stats("foo", "bar")
    assert stats.custom.get("_run").get("foo") == "bar"

    stats.set_custom_stats("foo", "baz", "ok")
    assert stats.custom.get("_run").get("foo") == "bar"
    assert stats.custom.get("ok").get("foo") == "baz"

    stats.set_custom_stats("baz", "qux", "ok")
    assert stats.custom.get("ok").get("foo") == "baz"
    assert stats.custom.get("ok").get("baz") == "qux"

    stats.set_custom_stats("foo", "bar", "_run")

# Generated at 2022-06-22 20:16:05.516216
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert stats.ok['localhost'] == 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0


# Generated at 2022-06-22 20:16:17.045764
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    host = 'test_host'
    which = 'test_which'
    what = 'test_what'

    stats.update_custom_stats(which, what, host)
    assert stats.custom[host][which] == 'test_what'

    what = 1
    stats.update_custom_stats(which, what, host)
    assert stats.custom[host][which] == 1

    what = {'key': 'value'}
    stats.update_custom_stats(which, what, host)
    assert stats.custom[host][which] == {'key': 'value'}

    what = {'key': 'new_value'}
    stats.update_custom_stats(which, what, host)

# Generated at 2022-06-22 20:16:26.542683
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    stats.update_custom_stats('foo', 1)
    assert stats.custom == {'_run': {'foo': 1}}

    stats.update_custom_stats('foo', 1)
    assert stats.custom == {'_run': {'foo': 2}}

    stats.update_custom_stats('foo', 1, 'host')
    assert stats.custom == {'_run': {'foo': 2}, 'host': {'foo': 1}}

    stats.update_custom_stats('foo', 1, 'host')
    assert stats.custom == {'_run': {'foo': 2}, 'host': {'foo': 2}}

    stats.update_custom_stats('bar', 'baz', 'host')

# Generated at 2022-06-22 20:16:36.712870
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats("my_counter", 1)
    stats.set_custom_stats("my_counter", -1)
    assert stats.custom["_run"]["my_counter"] == 0

    # host-based custom stats
    stats.set_custom_stats("my_counter", 1, "localhost")
    stats.set_custom_stats("my_counter", 1, "localhost")
    assert stats.custom["localhost"]["my_counter"] == 1
    stats.set_custom_stats("my_counter", 1, "127.0.0.1")
    assert stats.custom["127.0.0.1"]["my_counter"] == 1


# Generated at 2022-06-22 20:16:45.632637
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    aggregate_stats.ok['host1'] = 1
    aggregate_stats.failures['host1'] = 2
    aggregate_stats.dark['host1'] = 3
    aggregate_stats.changed['host1'] = 4
    aggregate_stats.skipped['host1'] = 5
    aggregate_stats.rescued['host1'] = 6
    aggregate_stats.ignored['host1'] = 7

    expected_result = {'ok': 1, 'dark': 3, 'rescued': 6, 'failures': 2,
                       'ignored': 7, 'changed': 4, 'skipped': 5}
    assert aggregate_stats.summarize('host1') == expected_result



# Generated at 2022-06-22 20:16:53.060734
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    stats.increment("ok", "test")
    assert stats.summarize("test") == dict(
        ok=1,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0,
    )
    stats.increment("ignored", "test")
    stats.increment("rescued", "test")
    assert stats.summarize("test") == dict(
        ok=1,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=1,
        ignored=1,
    )
    stats.increment("failures", "test")
    stats.increment("ok", "test")

# Generated at 2022-06-22 20:17:04.553409
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('my_custom_stats', {'a': 4, 'c': 6}, 'localhost')
    assert stats.custom['localhost']['my_custom_stats'] == {'a': 4, 'c': 6}
    stats.update_custom_stats('my_custom_stats', {'a': 2, 'b': 10}, 'localhost')
    assert stats.custom['localhost']['my_custom_stats'] == {'a': 2, 'b': 10, 'c': 6}
    stats.update_custom_stats('my_custom_stats', {'c': 2}, 'localhost')
    assert stats.custom['localhost']['my_custom_stats'] == {'a': 2, 'b': 10, 'c': 2}

# Generated at 2022-06-22 20:17:08.474668
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'host')
    assert stats.ok.get('host', 0) == 0
    stats.decrement('ok', 'host2')
    assert stats.ok.get('host2', 0) == 0

# Generated at 2022-06-22 20:17:15.929309
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()

    stats.set_custom_stats('foo', 10)
    stats.set_custom_stats('foo', 10, 'host1')
    stats.set_custom_stats('foo', 10, None)
    stats.set_custom_stats('foo', 20, 'host2')
    stats.set_custom_stats('bar', 30, 'host1')

    assert stats.custom['_run'] == dict(foo=10)
    assert stats.custom['host1'] == dict(foo=10, bar=30)
    assert stats.custom['host2'] == dict(foo=20)


# Generated at 2022-06-22 20:17:21.737195
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():

    stats = AggregateStats()
    stats.set_custom_stats('a','b','c')
    stats.set_custom_stats('d','e','f')
    stats.set_custom_stats('_run','g')

    assert stats.custom['c']['a'] == 'b'
    assert stats.custom['f']['d'] == 'e'
    assert stats.custom['_run'] == 'g'

# Generated at 2022-06-22 20:17:25.305645
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    as1 = AggregateStats()
    as1.increment('ok', 'host1')
    assert as1.processed['host1'] == 1
    assert as1.ok['host1'] == 1


# Generated at 2022-06-22 20:17:36.164160
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ag_stats = AggregateStats()

    ag_stats.increment('ok', 'host1')
    ag_stats.increment('ok', 'host1')
    ag_stats.increment('ok', 'host2')

    assert ag_stats.ok['host1'] == 2
    assert ag_stats.ok['host2'] == 1

    # Other fields should be empty
    assert len(ag_stats.failures) == 0
    assert len(ag_stats.dark) == 0
    assert len(ag_stats.changed) == 0
    assert len(ag_stats.skipped) == 0
    assert len(ag_stats.rescued) == 0
    assert len(ag_stats.ignored) == 0
    assert len(ag_stats.custom) == 0

# Generated at 2022-06-22 20:17:45.493111
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    agg_stats = AggregateStats()
    # summarize() should generate an empty dict if there is no host or host is invalid
    assert agg_stats.summarize(None) == {}
    assert agg_stats.summarize('') == {}
    # set up some data
    agg_stats.increment('ok', 'host1')
    agg_stats.increment('ok', 'host1')
    agg_stats.increment('ok', 'host2')
    agg_stats.increment('failures', 'host1')
    agg_stats.increment('failures', 'host2')
    agg_stats.increment('failures', 'host2')
    agg_stats.increment('skipped', 'host1')
    agg_stats.increment('skipped', 'host2')
    assert agg_stats.summar

# Generated at 2022-06-22 20:17:55.899520
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok["host_one"] = 1
    stats.dark["host_two"] = 1
    stats.skipped["host_three"] = 3
    stats.ignored["host_four"] = 4

    assert stats.summarize("host_one") == dict(ok=1, failures=0, unreachable=0, changed=0, skipped=0, rescued=0, ignored=0)
    assert stats.summarize("host_two") == dict(ok=0, failures=0, unreachable=1, changed=0, skipped=0, rescued=0, ignored=0)
    assert stats.summarize("host_three") == dict(ok=0, failures=0, unreachable=0, changed=0, skipped=3, rescued=0, ignored=0)
    assert stats.summar

# Generated at 2022-06-22 20:18:03.295272
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    print('Testing Object Creation')
    aggStats = AggregateStats()
    assert aggStats is not None
    assert aggStats.processed is not None
    assert aggStats.failures is not None
    assert aggStats.ok is not None
    assert aggStats.dark is not None
    assert aggStats.changed is not None
    assert aggStats.skipped is not None
    assert aggStats.rescued is not None
    assert aggStats.ignored is not None
    assert aggStats.custom is not None


# Generated at 2022-06-22 20:18:09.188550
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate = AggregateStats()
    aggregate.increment('ok', 'host')
    result = aggregate.summarize('host')
    expected = dict(
        ok=1,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0,
    )
    assert result == expected

# Generated at 2022-06-22 20:18:20.643126
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate = AggregateStats()
    aggregate.increment('ok', 'some_host')
    aggregate.increment('ok', 'some_host')
    aggregate.increment('failures', 'some_host')
    aggregate.increment('dark', 'some_host')
    aggregate.increment('changed', 'some_host')
    aggregate.increment('skipped', 'some_host')
    aggregate.increment('rescued', 'some_host')
    aggregate.increment('ignored', 'some_host')

    assert aggregate.summarize('some_host') == {
        'ok': 2,
        'failures': 1,
        'unreachable': 1,
        'changed': 1,
        'skipped': 1,
        'rescued': 1,
        'ignored': 1,
    }

# Generated at 2022-06-22 20:18:27.209648
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    ags = AggregateStats()

    assert ags.processed == {}
    assert ags.failures == {}
    assert ags.ok == {}
    assert ags.dark == {}
    assert ags.changed == {}
    assert ags.skipped == {}
    assert ags.rescued == {}
    assert ags.ignored == {}
    assert ags.custom == {}


# Generated at 2022-06-22 20:18:34.467285
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok = {'host1': 0}
    stats.dark = {'host2': 1}
    stats.failures = {'host1': 1, 'host2': 0}
    stats.changed = {'host1': 0, 'host2': 0}
    stats.skipped = {'host1': 0, 'host2': 0}
    stats.rescued = {'host1': 0, 'host2': 0}
    stats.ignored = {'host1': 0, 'host2': 0}

    assert stats.summarize('host1') == dict(ok=0, failures=1, unreachable=0, changed=0, skipped=0, rescued=0, ignored=0)

# Generated at 2022-06-22 20:18:42.484766
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    s = AggregateStats()
    s.increment("ok", "127.0.0.1")
    s.increment("ok", "127.0.0.1")
    s.increment("dark", "127.0.0.1")
    assert s.processed == {"127.0.0.1": 1}
    assert s.ok == {"127.0.0.1": 2}
    assert s.dark == {"127.0.0.1": 1}



# Generated at 2022-06-22 20:18:45.954003
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    # Create an AggregateStats object and set a custom statistic
    ag = AggregateStats()
    ag.set_custom_stats("custom_test", 10)

    # Assert that the object was properly set
    assert ag.custom["_run"]["custom_test"] == 10


# Generated at 2022-06-22 20:18:48.377922
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok['localhost'] = 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0



# Generated at 2022-06-22 20:18:59.236544
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg_stats = AggregateStats()
    # Check initial values
    assert agg_stats.processed == {}
    assert agg_stats.failures == {}
    assert agg_stats.ok == {}
    assert agg_stats.dark == {}
    assert agg_stats.changed == {}
    assert agg_stats.skipped == {}
    assert agg_stats.rescued == {}
    assert agg_stats.ignored == {}
    assert agg_stats.custom == {}

    # Check increment function
    agg_stats.increment('failures', 'host')
    assert agg_stats.failures['host'] == 1
    agg_stats.increment('failures', 'host')
    assert agg_stats.failures['host'] == 2


# Generated at 2022-06-22 20:19:07.178873
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    from ansible.utils.unicode import to_unicode
    stats = AggregateStats()

    stats.increment('ok', 'hostA')
    stats.increment('failures', 'hostA')
    stats.increment('ok', 'hostB')
    stats.increment('failures', 'hostB')
    stats.increment('ok', 'hostA')
    stats.increment('failures', 'hostB')

    ok = {'hostA': 2, 'hostB': 1}
    failures = {'hostA': 1, 'hostB': 2}
    summary = {'hostA': {'ok': 2, 'failures': 1}, 'hostB': {'ok': 1, 'failures': 2}}
    tags = {'hostA': ['start', 'end']}


# Generated at 2022-06-22 20:19:11.259796
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # Arrange
    stats = AggregateStats()

    # Act
    stats.increment("ok", "host")
    stats.increment("ok", "host")
    stats.increment("failures", "host")
    stats.decrement("ok", "host")

    # Assert
    assert stats.ok["host"] == 1
    assert stats.failures["host"] == 1

# Generated at 2022-06-22 20:19:15.023988
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 0
    stats.ok['test'] = 1
    stats.decrement('ok', 'test')
    assert stats.ok['test'] == 0


# Generated at 2022-06-22 20:19:21.162489
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.custom == {}
    assert stats.skipped == {}
    assert stats.ignored == {}
    assert stats.rescued == {}


# Generated at 2022-06-22 20:19:26.141857
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok['test_hostname'] = 3  # This looks like a hack, yes.

    stats.decrement('ok', 'test_hostname')
    assert stats.ok['test_hostname'] == 2

# Generated at 2022-06-22 20:19:35.190297
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    testdata = AggregateStats()
    testdata.set_custom_stats("which1", "what1")
    res = testdata.custom
    assert len(res) == 1
    assert "_run" in res
    assert "which1" in res["_run"]
    assert res["_run"]["which1"] == "what1"

    testdata.set_custom_stats("which2", "what2", "test")
    assert len(res) == 2
    assert "_run" in res
    assert "which1" in res["_run"]
    assert res["_run"]["which1"] == "what1"
    assert "test" in res
    assert "which2" in res["test"]
    assert res["test"]["which2"] == "what2"


# Generated at 2022-06-22 20:19:44.624157
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    # initiate object
    agg_stats = AggregateStats()

    # update_custom_stats is called from within method runner.run of class TaskQueueManager
    # we will test for method update_custom_stats for all methods of class TaskQueueManager
    # which call it
    # method TaskQueueManager.get_facts
    agg_stats.update_custom_stats(
        which='changed', what=False, host='test_host'
    )
    assert agg_stats.custom['test_host']['changed'] is False

    # method TaskQueueManager.run_task
    agg_stats.update_custom_stats(
        which='changed', what=False, host='test_host'
    )
    assert agg_stats.custom['test_host']['changed'] is False

    # method TaskQueueManager.run_handlers
    agg

# Generated at 2022-06-22 20:19:52.278585
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.skipped["example.org"] = 0
    stats.decrement("skipped", "example.org")
    assert stats.skipped["example.org"] == 0
    stats.skipped["example.org"] = 1
    stats.decrement("skipped", "example.org")
    assert stats.skipped["example.org"] == 0
    stats.skipped["example.org"] = 2
    stats.decrement("skipped", "example.org")
    assert stats.skipped["example.org"] == 1

# Generated at 2022-06-22 20:19:52.790441
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    assert AggregateStats() is not None

# Generated at 2022-06-22 20:20:02.209277
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('failures', 'host1')
    stats.increment('dark', 'host1')
    stats.increment('changed', 'host1')
    stats.increment('skipped', 'host1')
    stats.increment('rescued', 'host1')
    stats.increment('ignored', 'host1')
    stats.increment('ok', 'host3')

# Generated at 2022-06-22 20:20:09.248794
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    ag = AggregateStats()
    ag.skipped = {'node1': 1, 'node2': 3}

    assert ag.processed == {}
    assert ag.skipped == {'node1': 1, 'node2': 3}
    assert ag.summarize('node1') == {'skipped': 1}
    assert ag.summarize('node2') == {'skipped': 3}



# Generated at 2022-06-22 20:20:13.566129
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
	aggStats = AggregateStats()
	assert aggStats.ok == {}
	assert aggStats.failures == {}
	assert aggStats.dark == {}
	assert aggStats.skipped == {}
	assert aggStats.rescued == {}
	assert aggStats.ignored == {}
	assert aggStats.custom == {}


# Generated at 2022-06-22 20:20:21.056228
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    '''testing that AggregateStats can count'''
    stats = AggregateStats()

    stats.increment('ok', 'host1')
    assert stats.ok['host1'] == 1 and stats.failures['host1'] == 0 and stats.processed['host1'] == 1

    stats.increment('ok', 'host2')
    stats.increment('ok', 'host2')
    assert stats.ok['host2'] == 2 and stats.failures['host2'] == 0 and stats.processed['host2'] == 1

    stats.increment('failures', 'host1')

    assert stats.ok['host1'] == 1 and stats.failures['host1'] == 1 and stats.processed['host1'] == 1

    stats.increment('failures', 'host2')

    assert stats.ok['host2']

# Generated at 2022-06-22 20:20:26.209505
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg = AggregateStats()
    agg.set_custom_stats('key1', 'value1', 'host1')
    assert agg.custom['host1']['key1'] == 'value1'


# Generated at 2022-06-22 20:20:37.762561
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    host = 'host.example.org'

    stats = AggregateStats()
    stats.increment('ok', host)
    stats.increment('failures', host)
    stats.increment('dark', host)
    stats.increment('changed', host)
    stats.increment('skipped', host)
    stats.increment('rescued', host)
    stats.increment('ignored', host)

    summary = stats.summarize(host)

    assert isinstance(summary, dict)
    assert all(item in summary for item in stats.__dict__.keys())
    assert all(item == 1 for item in summary.values())


# Generated at 2022-06-22 20:20:45.995692
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()

    # Test case 1:
    aggregate_stats.update_custom_stats('what', 1)
    assert aggregate_stats.custom['_run']['what'] == 1

    # Test case 2:
    aggregate_stats.update_custom_stats('what', 1)
    assert aggregate_stats.custom['_run']['what'] == 2

    # Test case 3:
    aggregate_stats.custom['_run']['what'] = {}
    aggregate_stats.update_custom_stats('what', {'what': 1})
    assert aggregate_stats.custom['_run']['what']['what'] == 1

    # Test case 4:
    aggregate_stats.update_custom_stats('what', {'what': 1})

# Generated at 2022-06-22 20:20:51.102701
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg = AggregateStats()
    agg.increment("processed", "test1")
    agg.increment("ok", "test1")
    agg.increment("ok", "test1")
    assert agg.processed["test1"] == 1
    assert agg.ok["test1"] == 2


# Generated at 2022-06-22 20:20:51.572990
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    pass

# Generated at 2022-06-22 20:20:58.602667
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    a = AggregateStats()
    a.increment('ok', 'host')
    a.increment('failures', 'host')
    a.increment('dark', 'host')
    a.increment('changed', 'host')
    a.increment('rescued', 'host')
    a.increment('ignored', 'host')

    summary = a.summarize('host')
    assert summary == dict(ok=1, failures=1, changed=1, unreachable=1,
                           skipped=0, rescued=1, ignored=1)

# Generated at 2022-06-22 20:21:08.055683
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    test = AggregateStats()
    test.increment("failures", "host1")
    assert({"host1": 1} == test.failures)

    test.increment("dark", "host1")
    assert({"host1": 1} == test.dark)

    test.increment("ok", "host1")
    assert({"host1": 1} == test.ok)

    test.increment("ok", "host2")
    assert({"host1": 1, "host2": 1} == test.ok)

    test.increment("dark", "host2")
    assert({"host1": 1, "host2": 2} == test.dark)


# Generated at 2022-06-22 20:21:16.168177
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    as1 = AggregateStats()
    test_host = 'test'
    attrs = {}

    as1.increment('ok', test_host)
    attrs = as1.summarize(test_host)
    assert attrs['ok'] == 1 and attrs['failures'] == 0 and attrs['unreachable'] == 0 and attrs['changed'] == 0 and attrs['skipped'] == 0 and attrs['rescued'] == 0

    as1.increment('ok', test_host)
    as1.increment('ok', test_host)
    as1.increment('ok', test_host)
    attrs = as1.summarize(test_host)
    assert attrs['ok'] == 4 and attrs['failures'] == 0 and attrs['unreachable'] == 0 and attrs

# Generated at 2022-06-22 20:21:25.872960
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stat = AggregateStats()
    stat.increment('ok', 'host1')
    stat.increment('ok', 'host1')
    stat.increment('ok', 'host2')
    stat.increment('changed', 'host2')

    assert stat.ok == {'host1': 2, 'host2': 1}
    assert stat.changed == {'host2': 1}

    assert stat.summarize('host1') == dict(
        ok=2,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0,
    )


# Generated at 2022-06-22 20:21:35.588228
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.failures["host1"] = 1
    stats.dark["host1"] = 10
    stats.ignored["host1"] = 100
    stats.increment("ok", "host1")
    stats.increment("ok", "host1")
    stats.increment("ok", "host1")
    stats.increment("changed", "host1")
    stats.increment("rescued", "host1")
    stats.increment("rescued", "host1")
    assert stats.summarize("host1") == dict(
        ok=3,
        failures=1,
        unreachable=10,
        changed=1,
        skipped=0,
        rescued=2,
        ignored=100,
    )


# Generated at 2022-06-22 20:21:41.442436
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert isinstance(stats, AggregateStats)
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-22 20:21:48.280172
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    import json

    testAggregateStats = AggregateStats()
    testAggregateStats.set_custom_stats('failed', 5)
    assert testAggregateStats.custom['_run']['failed'] == 5

    testAggregateStats.set_custom_stats('failed', {'c': 5})
    assert testAggregateStats.custom['_run']['failed'] == {'c': 5}


# Generated at 2022-06-22 20:21:56.537889
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    '''Unit test for constructor of class AggregateStats'''

    ag = AggregateStats()
    assert ag.processed == {}
    assert ag.failures == {}
    assert ag.ok == {}
    assert ag.dark == {}
    assert ag.changed == {}
    assert ag.skipped == {}
    assert ag.rescued == {}
    assert ag.ignored == {}
    assert ag.custom == {}


# Generated at 2022-06-22 20:22:01.241047
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    ''' Unit test for Increment'''
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'host1')
    aggregate_stats.increment('ok', 'host1')
    aggregate_stats.increment('ok', 'host2')
    assert aggregate_stats.ok['host1'] == 2
    assert aggregate_stats.ok['host2'] == 1


# Generated at 2022-06-22 20:22:08.709274
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    ags = AggregateStats()
    assert ags.processed == {}
    assert ags.failures == {}
    assert ags.ok == {}
    assert ags.dark == {}
    assert ags.changed == {}
    assert ags.skipped == {}
    assert ags.rescued == {}
    assert ags.ignored == {}
    assert ags.custom == {}

## Unit test for method increment()

# Generated at 2022-06-22 20:22:19.783933
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import pytest

    # Test 1
    a = AggregateStats()
    a.set_custom_stats('a', 1)
    a.update_custom_stats('a', {'b': 1})
    assert a.custom['_run']['a'] == {'b': 1}

    # Test 2
    a = AggregateStats()
    b = {'a': 1}
    a.set_custom_stats('x', b)
    a.update_custom_stats('x', b)
    assert a.custom['_run']['x'] == {'a': 2}

    # Test 3
    a = AggregateStats()
    a.set_custom_stats('x', 1)
    with pytest.raises(TypeError):
        a.update_custom_stats('x', {'a': 1})

# Generated at 2022-06-22 20:22:26.789282
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-22 20:22:30.909937
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment("changed", "host1")
    stats.increment("changed", "host2")
    stats.decrement("changed", "host1")
    assert stats.changed["host1"] == 0
    assert stats.changed["host2"] == 1

# Generated at 2022-06-22 20:22:40.112247
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stat_obj = AggregateStats()
    stat_obj.increment("ok", "localhost")
    stat_obj.increment("ok", "localhost")
    stat_obj.increment("ok", "localhost")
    stat_obj.increment("ok", "localhost")
    stat_obj.increment("ignored", "localhost")
    stat_obj.increment("ignored", "localhost")
    stat_obj.increment("ignored", "localhost")
    stat_obj.decrement("ok", "localhost")
    stat_obj.decrement("ok", "localhost")
    stat_obj.decrement("ok", "localhost")
    stat_obj.decrement("ok", "localhost")
    stat_obj.decrement("ignored", "localhost")

# Generated at 2022-06-22 20:22:43.710124
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    a = AggregateStats()
    a.increment('changed', 'host1')
    assert a.changed['host1'] == 1
    a.increment('changed', 'host1')
    assert a.changed['host1'] == 2



# Generated at 2022-06-22 20:22:47.918823
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement("ok", "host")
    assert stats.ok["host"] == 0

    stats.ok["host"] = 1
    stats.decrement("ok", "host")
    assert stats.ok["host"] == 0


# Generated at 2022-06-22 20:22:49.728568
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    stats.increment('dark', 'localhost')
    assert stats.summarize('localhost')['unreachable'] == 1

# Generated at 2022-06-22 20:23:00.506066
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    ag = AggregateStats()
    ag.update_custom_stats("x", "a")
    assert(ag.custom)
    ag.update_custom_stats("x", "a", "host")
    assert(ag.custom["host"]["x"] == "a")
    ag.update_custom_stats("x", "b", "host")
    assert(ag.custom["host"]["x"] == "b")
    ag.update_custom_stats("x", "a")
    assert(ag.custom["_run"]["x"] == "a")
    ag.update_custom_stats("x", "b")
    assert(ag.custom["_run"]["x"] == "b")

if __name__ == "__main__":
    test_AggregateStats_update_custom_stats()

# Generated at 2022-06-22 20:23:02.576807
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    s = AggregateStats()
    assert (s is not None)

# Generated at 2022-06-22 20:23:14.266344
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    stats = AggregateStats()
    stats.update_custom_stats("my_custom_stats", {"some_value": 1, "str_value": "some_string"}, "localhost")
    stats.update_custom_stats("my_custom_stats", {"some_value": 2, "str_value": "some_other_string"}, "localhost")
    assert stats.custom["localhost"]["my_custom_stats"]["some_value"] == 3
    assert stats.custom["localhost"]["my_custom_stats"]["str_value"] == combine_vars("some_string", "some_other_string")

# Generated at 2022-06-22 20:23:23.551159
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    print("Testing method update_custom_stats of class AggregateStats")

    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats("cust_stat1", "val1")
    aggregate_stats.update_custom_stats("cust_stat2", "val2")
    aggregate_stats.update_custom_stats("cust_stat3", "val3")
    aggregate_stats.update_custom_stats("cust_stat4", "val4")

    val1 = aggregate_stats.custom["_run"]["cust_stat1"]
    val2 = aggregate_stats.custom["_run"]["cust_stat2"]
    val3 = aggregate_stats.custom["_run"]["cust_stat3"]

# Generated at 2022-06-22 20:23:29.167957
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate = AggregateStats()

    assert aggregate.processed == {}
    assert aggregate.failures == {}
    assert aggregate.ok == {}
    assert aggregate.dark == {}
    assert aggregate.changed == {}
    assert aggregate.skipped == {}
    assert aggregate.rescued == {}
    assert aggregate.ignored == {}
    assert aggregate.custom == {}


# Generated at 2022-06-22 20:23:38.897130
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    print('\n' + __name__)

    test_stats = AggregateStats()
    test_stats.update_custom_stats('val1', 100)
    assert test_stats.custom['_run']['val1'] == 100

    test_stats.update_custom_stats('val1', 100)
    assert test_stats.custom['_run']['val1'] == 200

    test_stats.update_custom_stats('val2', 'foo')
    assert test_stats.custom['_run']['val2'] == 'foo'

    test_stats.update_custom_stats('val2', 'bar')
    assert test_stats.custom['_run']['val2'] == 'foobar'

# Generated at 2022-06-22 20:23:49.573681
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}
    # check methods are defined
    stats.increment('ok', 'host')
    stats.increment('skipped', 'host')
    stats.increment('skipped', 'host')
    stats.increment('skipped', 'host')
    stats.decrement('skipped', 'host')

# Generated at 2022-06-22 20:23:55.072606
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    # Create a class
    # ass = AggregateStats()

    # Run the decrement method
    # ass.decrement("ok", "localhost")

    # Just in case we find errors, create exceptions
    assert False, "Do unit tests for the method decrement of class AggregateStats"

# Generated at 2022-06-22 20:24:04.851755
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    results = AggregateStats()

    results.decrement('rescued', 'testhost')
    assert results.rescued['testhost'] == 0
    assert results.rescued.get('testhost', 'should not be here') == 0

    results.increment('rescued', 'testhost')
    assert results.rescued['testhost'] == 1
    assert results.rescued.get('testhost', 'should not be here') == 1

    results.increment('rescued', 'testhost')
    assert results.rescued['testhost'] == 2
    assert results.rescued.get('testhost', 'should not be here') == 2

    results.decrement('rescued', 'testhost')
    assert results.rescued['testhost'] == 1
    assert results.rescued

# Generated at 2022-06-22 20:24:16.767876
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    from ansible.playbook.task import Task
    agg_stats = AggregateStats()
    task = Task()
    task._role = 'my_role'
    host = 'my_host'

    # let's add a result. The data structure will be filled with a result.
    # We're actually testing the method increment.
    agg_stats.increment('ok', host)
    agg_stats.increment('failures', host)
    agg_stats.increment('dark', host)
    agg_stats.increment('changed', host)
    agg_stats.increment('skipped', host)
    agg_stats.increment('rescued', host)
    agg_stats.increment('ignored', host)

    assert agg_stats.processed[host] == 1

# Generated at 2022-06-22 20:24:20.974982
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-22 20:24:32.710144
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    # Test the int value
    stats.update_custom_stats("count", 1)
    assert stats.custom["_run"] == {"count": 1}

    # Test the float value
    stats.update_custom_stats("count", 0.1)
    assert stats.custom["_run"] == {"count": 1.1}

    # Test the string value
    stats.update_custom_stats("count", "test")
    assert stats.custom["_run"] == {"count": "1.1test"}

    # Test the list value
    stats.update_custom_stats("count", ["test"])
    assert stats.custom["_run"] == {"count": ["test"]}

    # Test the dict value
    stats.update_custom_stats("count", {"count": ["test"]})

# Generated at 2022-06-22 20:24:38.592595
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stat = AggregateStats()
    stat.increment('ok', 'host1')
    assert stat.ok['host1'] == 1
    stat.increment('ok', 'host1')
    assert stat.ok['host1'] == 2
    stat.increment('failures', 'host1')
    assert stat.ok['host1'] == 2
    assert stat.failures['host1'] == 1
    assert stat.processed['host1'] == 1



# Generated at 2022-06-22 20:24:44.176933
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('test', 1)
    assert stats.custom['_run']['test'] == 1, "Expected 1 but got %s" % stats.custom['_run']['test']


# Generated at 2022-06-22 20:24:48.368474
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test_object = AggregateStats()
    test_object.failures = {'test_host': 1}
    test_object.decrement('failures', 'test_host')
    assert test_object.failures['test_host'] == 0

# Generated at 2022-06-22 20:24:57.602352
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('changes', {'gid': 401, 'mode': '0755', 'owner': 'root'}, 'localhost')
    assert stats.custom['localhost']['changes'] == {'gid': 401, 'mode': '0755', 'owner': 'root'}

    stats.update_custom_stats('changes', {'gid': 2001, 'mode': '0644', 'owner': 'joe'}, 'localhost')
    assert stats.custom['localhost']['changes'] == {'gid': 2001, 'mode': '0644', 'owner': 'joe'}

    stats.update_custom_stats('changes', "newline\n", 'localhost')
    assert stats.custom['localhost']['changes'] == "newline\n"

    stats.update_custom