

# Generated at 2022-06-22 20:15:00.613828
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    import copy

    # Use a copy so the changes will not modify the real code
    aggr = copy.deepcopy(AggregateStats())
    aggr.increment('ok', 'host1')

    assert aggr.summarize('host1') == {'ok': 1, 'failures': 0, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}

# Generated at 2022-06-22 20:15:04.363017
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ags = AggregateStats()
    ags.increment('skipped', 'foo')
    ags.decrement('skipped', 'foo')
    assert ags.skipped == {"foo":0}

# Generated at 2022-06-22 20:15:15.097519
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggr_stats = AggregateStats()
    aggr_stats.update_custom_stats('key1', {'a': 1, 'b': 2}, '_run')
    assert aggr_stats.custom == {'_run': {'key1': {'a': 1, 'b': 2}}}

    # Add a new key
    aggr_stats.update_custom_stats('key2', {'c': 3}, '_run')
    assert aggr_stats.custom == {'_run': {'key1': {'a': 1, 'b': 2}, 'key2': {'c': 3}}}

    # Add a new key and update value of existing key
    # existing key is a dictionary
    aggr_stats.update_custom_stats('key1', {'b': 3, 'd': 4}, '_run')


# Generated at 2022-06-22 20:15:17.474206
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats("foo", "bar")

    custom = stats.custom["_run"]
    assert custom["foo"] == "bar"



# Generated at 2022-06-22 20:15:23.572613
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', '127.0.0.1')
    assert stats.ok['127.0.0.1'] == 1
    stats.increment('ok', '127.0.0.1')
    assert stats.ok['127.0.0.1'] == 2



# Generated at 2022-06-22 20:15:31.360712
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    '''AggregateStats: test set_custom_stats method'''

    stats = AggregateStats()

    stats.set_custom_stats('foo', 'bar')
    assert stats.custom['_run']['foo'] == 'bar'

    stats.set_custom_stats('bar', 'foo', 'baz')
    assert stats.custom['baz']['bar'] == 'foo'


# Generated at 2022-06-22 20:15:42.564175
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
# Test 1: host=None, which="x", what=3,
    stats.update_custom_stats("x", 3)
    assert stats.custom["_run"]["x"] == 3
# Test 2: host="y", which="x", what=3,
    stats.update_custom_stats("x", 3, "y")
    assert stats.custom["y"]["x"] == 3
# Test 3: host="z", which="x", what=3,
    stats.update_custom_stats("x", 3, "z")
    assert stats.custom["z"]["x"] == 3
# Test 4: host=None, which="x", what=4,
    # stats.custom will be {"_run": {"x": 4}}

# Generated at 2022-06-22 20:15:46.466374
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    _ansible = AggregateStats()
    _ansible.increment('ok', 'test01')
    _ansible.increment('ok', 'test02')
    _ansible.increment('ok', 'test01')
    assert _ansible.ok['test01'] == 2
    assert _ansible.ok['test02'] == 1



# Generated at 2022-06-22 20:15:49.368363
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'host1')
    aggregate_stats.increment('ok', 'host1')
    aggregate_stats.increment('ok', 'host2')
    assert aggregate_stats.ok == {'host1':2, 'host2':1}


# Generated at 2022-06-22 20:16:01.015489
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agstats = AggregateStats()
    assert agstats.custom == {}
    agstats.set_custom_stats('_fact1', 'foo')
    assert agstats.custom == {'_run': {'_fact1': 'foo'}}
    # Try to update custom stat
    agstats.set_custom_stats('_fact1', 'foo')
    assert agstats.custom == {'_run': {'_fact1': 'foo'}}
    agstats.set_custom_stats('_fact2', 'bar')
    assert agstats.custom == {'_run': {'_fact1': 'foo', '_fact2': 'bar'}}
    agstats.set_custom_stats('_fact2', 'baz', 'localhost')

# Generated at 2022-06-22 20:16:07.218872
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    from ansible.utils.vars import merge_hash

    # Test increment: what = failures, host = host1
    agg_stats = AggregateStats()
    agg_stats.increment('failures', 'host1')

    # all host keys exist
    assert agg_stats.processed.get('host1') == 1, \
        'incr: no processed.host1'
    assert agg_stats.failures.get('host1') == 1, \
        'incr: no failures.host1'
    assert agg_stats.ok.get('host1') == 0, \
        'incr: ok.host1 nonzero'
    assert agg_stats.dark.get('host1') == 0, \
        'incr: dark.host1 nonzero'

# Generated at 2022-06-22 20:16:13.140354
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    options = AggregateStats()
    assert options.processed == {}
    assert options.failures == {}
    assert options.ok == {}
    assert options.dark == {}
    assert options.changed == {}
    assert options.skipped == {}
    assert options.rescued == {}
    assert options.ignored == {}
    assert options.custom == {}



# Generated at 2022-06-22 20:16:15.108041
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'test_host')
    stats.increment('ok', 'test_host')
    stats.increment('ok', 'test_host')
    assert stats.ok['test_host'] == 3


# Generated at 2022-06-22 20:16:21.395810
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():

    stats = AggregateStats()

    stats1 = stats.set_custom_stats('a', 'b', '_run')
    assert stats1 is None
    assert stats.custom == {'_run': {'a': 'b'}}

    stats2 = stats.set_custom_stats('c', 'd', '_run')
    assert stats2 is None
    assert stats.custom == {'_run': {'a': 'b', 'c': 'd'}}


# Generated at 2022-06-22 20:16:33.284131
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    import sys
    import os
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.utils.vars import merge_hash

    my_stats = AggregateStats()
    my_stats.increment('failures', 'www.example.com')
    my_stats.increment('ok', 'www.example.com')
    my_stats.increment('ok', 'example.com')
    my_stats.increment('failures', 'www.example.com')
    my_stats.increment('changed', 'www.example.com')
    my_stats.increment('changed', 'example.com')

# Generated at 2022-06-22 20:16:40.312306
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.ok['localhost'] = 1
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0
    stats.ok['localhost'] = -5
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 0


# Generated at 2022-06-22 20:16:43.473840
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stat = AggregateStats()

    assert(isinstance(stat, AggregateStats))
    assert(stat.processed == {})
    assert(stat.failures == {})
    assert(stat.ok == {})
    assert(stat.dark == {})
    assert(stat.changed == {})
    assert(stat.skipped == {})
    assert(stat.rescued == {})
    assert(stat.ignored == {})



# Generated at 2022-06-22 20:16:47.495810
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
  as1 = AggregateStats()
  as1.increment('processed', 'localhost')
  as1.increment('skipped', 'localhost')
  as1.decrement('skipped', 'localhost')

  assert(as1.processed == {'localhost': 1})
  assert(as1.skipped == {'localhost': 1})
  assert(as1.skipped['localhost'] == 1)
  as1.skipped['localhost'] = 0
  assert(as1.skipped['localhost'] == 0)
  as1.skipped['localhost'] = -1
  assert(as1.skipped['localhost'] == 0)

  as1 = AggregateStats()
  as1.decrement('skipped', 'localhost')
  assert(as1.skipped == {'localhost': 0})


# Unit test that

# Generated at 2022-06-22 20:16:52.057858
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg_stats = AggregateStats()
    agg_stats.set_custom_stats('my_stats_key', 'my_stats_value', 'my_host')
    assert agg_stats.custom['my_host']['my_stats_key'] == 'my_stats_value'


# Generated at 2022-06-22 20:17:03.620372
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    aggregate = AggregateStats()
    aggregate.update_custom_stats('testattr', "testval1", "testhost")
    aggregate.update_custom_stats('testattr', "testval2", "testhost")
    aggregate.update_custom_stats('testattr', "testval3", "testhost")

    assert aggregate.custom['testhost']['testattr'] == "testval3"
    aggregate.update_custom_stats('testattr', ["in_list1"], "testhost")
    assert aggregate.custom['testhost']['testattr'] == ["in_list1"]
    aggregate.update_custom_stats('testattr', ["in_list2"], "testhost")
    assert aggregate.custom['testhost']['testattr'] == ["in_list1", "in_list2"]

    aggregate.update_custom_stats

# Generated at 2022-06-22 20:17:13.899796
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment("ok", "test")
    stats.increment("ok", "test")
    stats.increment("ok", "test")
    stats.increment("failures", "test")
    stats.increment("dark", "test")
    stats.increment("changed", "test")
    stats.increment("skipped", "test")
    stats.increment("rescued", "test")
    stats.increment("ignored", "test")

    summary = stats.summarize("test")
    assert summary == dict(
        ok=3,
        failures=1,
        unreachable=1,
        changed=1,
        skipped=1,
        rescued=1,
        ignored=1
    )



# Generated at 2022-06-22 20:17:20.592275
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    which = 'key'
    what = 'value'
    what2 = 'value2'
    host = 'host'
    aggregate_stats.update_custom_stats(which, what, host)
    assert aggregate_stats.custom[host][which] == what
    aggregate_stats.update_custom_stats(which, what2, host)
    assert aggregate_stats.custom[host][which] == what + what2

# Generated at 2022-06-22 20:17:22.819913
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate = AggregateStats()
    aggregate.increment('failures', 'localhost')
    assert aggregate.failures['localhost'] == 1


# Generated at 2022-06-22 20:17:33.342438
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    aggregate = AggregateStats()
    aggregate.increment("ok", "host")
    assert aggregate.ok["host"] == 1
    aggregate.decrement("ok", "host")
    assert aggregate.ok["host"] == 0

    aggregate.increment("ok", "host2")
    aggregate.increment("ok", "host2")

    assert aggregate.ok["host2"] == 2
    aggregate.decrement("ok", "host2")
    assert aggregate.ok["host2"] == 1

    aggregate.decrement("ok", "host")
    assert aggregate.ok["host"] == 0

    aggregate.decrement("ok", "host2")
    assert aggregate.ok["host2"] == 0



# Generated at 2022-06-22 20:17:40.086142
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()

    host = 'localhost'
    stats.increment('ok', host)
    stats.increment('skipped', host)

    assert stats.summarize(host) == dict(
        ok=1,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=1,
        rescued=0,
        ignored=0,
    )

    stats.increment('skipped', host)
    assert stats.summarize(host)['skipped'] == 2



# Generated at 2022-06-22 20:17:45.641514
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    obj = AggregateStats()
    host = 'localhost'
    what = 'test'
    obj.test = {
            host: 1
    }
    obj.decrement(what, host)
    assert obj.test[host] == 0



# Generated at 2022-06-22 20:17:54.398542
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    import pytest
    s = AggregateStats()
    s.increment('failures', 'test-host')
    s.increment('ok', 'test-host')

    try:
        s.decrement('ok', 'test-host')
        s.decrement('ok', 'test-host')
    except KeyError:
        pytest.fail()

    try:
        s.decrement('ok', 'test-host')
        pytest.fail()
    except KeyError:
        pass

    assert s.failures.get('test-host', 0) == 1
    assert s.ok.get('test-host', 0) == 0


# Generated at 2022-06-22 20:17:57.623788
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("ok", "localhost")
    assert stats.ok == {"localhost": 1}

if __name__ == '__main__':
    test_AggregateStats_increment()

# Generated at 2022-06-22 20:18:03.626655
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggstats = AggregateStats()
    assert aggstats.processed == {}
    assert aggstats.failures == {}
    assert aggstats.ok == {}
    assert aggstats.dark == {}
    assert aggstats.changed == {}
    assert aggstats.skipped == {}
    assert aggstats.rescued == {}
    assert aggstats.ignored == {}
    assert aggstats.custom == {}


# Generated at 2022-06-22 20:18:10.093093
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    if (stats.processed != {} or
            stats.failures != {} or
            stats.ok != {} or
            stats.dark != {} or
            stats.changed != {} or
            stats.skipped != {} or
            stats.rescued != {} or
            stats.ignored != {} or
            stats.custom != {}):
        raise AssertionError('Unable to initiate class AggregateStats.')


# Generated at 2022-06-22 20:18:19.144060
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert(isinstance(stats, AggregateStats))
    assert(isinstance(stats.processed, dict))
    assert(isinstance(stats.failures, dict))
    assert(isinstance(stats.ok, dict))
    assert(isinstance(stats.dark, dict))
    assert(isinstance(stats.changed, dict))
    assert(isinstance(stats.skipped, dict))
    assert(isinstance(stats.rescued, dict))
    assert(isinstance(stats.ignored, dict))
    assert(isinstance(stats.custom, dict))


# Generated at 2022-06-22 20:18:30.308760
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():

    aggregate_stats = AggregateStats()

    aggregate_stats.ok["1.1.1.1"] = 1
    aggregate_stats.failures["1.1.1.1"] = 1
    aggregate_stats.dark["1.1.1.1"] = 1
    aggregate_stats.changed["1.1.1.1"] = 1
    aggregate_stats.skipped["1.1.1.1"] = 1
    aggregate_stats.rescued["1.1.1.1"] = 1
    aggregate_stats.ignored["1.1.1.1"] = 1


# Generated at 2022-06-22 20:18:32.876493
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    host = 'localhost'
    what = 'ok'
    stats.increment(what, host)
    assert (stats.summarize(host)[what] == 1)

# Generated at 2022-06-22 20:18:39.087220
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    """Tests for method set_custom_stats of class AggregateStats."""
    as_obj = AggregateStats()
    as_obj.set_custom_stats('foo', 'bar', 'localhost')
    assert as_obj.custom['localhost']['foo'], 'bar'
    as_obj.set_custom_stats('foo', 'baz')
    assert as_obj.custom['_run']['foo'], 'baz'


# Generated at 2022-06-22 20:18:47.741548
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    def compare_dicts(dict1, dict2, path=None):
        if path is None:
            path = []
        if not isinstance(dict1, dict) or not isinstance(dict2, dict):
            raise ValueError("one of arguments is not a dict")
        for k, v in dict1.items():
            if k not in dict2:
                raise ValueError("key %s not found in dict2 on path %s" % (k, '.'.join(path)))
            if isinstance(v, dict):
                compare_dicts(v, dict2[k], path + [str(k)])
            assert v == dict2[k], "values not equal for key %s on path %s" % (k, '.'.join(path))

    stats = AggregateStats()

# Generated at 2022-06-22 20:18:59.623441
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ''' Test decrease of a statistic '''
    stats = AggregateStats()
    stats.changed['localhost'] = 5
    stats.decrement('changed', 'localhost')
    assert stats.changed['localhost'] == 4
    assert stats.changed == {'localhost': 4}
    stats.decrement('changed', 'localhost')
    assert stats.changed['localhost'] == 3
    assert stats.changed == {'localhost': 3}
    stats.decrement('changed', 'localhost')
    assert stats.changed['localhost'] == 2
    assert stats.changed == {'localhost': 2}
    stats.decrement('changed', 'localhost')
    assert stats.changed['localhost'] == 1
    assert stats.changed == {'localhost': 1}
    stats.decrement('changed', 'localhost')

# Generated at 2022-06-22 20:19:06.247073
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    aggregate_stats.set_custom_stats('x', 1, 'foo_host')
    aggregate_stats.set_custom_stats('y', 2, 'bar_host')
    aggregate_stats.set_custom_stats('z', {'a': 'a', 'b': 'b'}, 'baz_host')

    assert aggregate_stats.custom['foo_host']['x'] == 1
    assert aggregate_stats.custom['bar_host']['y'] == 2
    assert aggregate_stats.custom['baz_host']['z']['a'] == 'a'
    assert aggregate_stats.custom['baz_host']['z']['b'] == 'b'



# Generated at 2022-06-22 20:19:15.016716
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    stats.update_custom_stats('a', 1, 'foo')
    stats.update_custom_stats('a', {'b': 1}, 'foo')
    stats.update_custom_stats('foo', 1, 'bar')
    stats.update_custom_stats('bar', {'b': 1}, 'bar')
    stats.update_custom_stats('baz', {'b': {'c': 1}}, 'bar')
    stats.update_custom_stats('baz', {'b': {'c': 2, 'd': 3}}, 'bar')

    assert stats.custom['foo'] == {'a': {'b': 1}}

# Generated at 2022-06-22 20:19:25.395733
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggregate_stats = AggregateStats()
    stats = dict(
        fatal=0,
        ok=0,
        changed=0,
        skipped=0,
        unreachable=0,
        failed=0,
        assertions=dict(
            passed=0,
            failed=0,
            skipped=0,
        ))

    aggregate_stats.update_custom_stats('stat', stats, '_run')
    assert aggregate_stats.custom['_run'] == dict(stat=stats)

    aggregate_stats.update_custom_stats('stat', stats, '_run')
    assert aggregate_stats.custom['_run'] == dict(stat=stats)

# Generated at 2022-06-22 20:19:32.322700
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggr_stats = AggregateStats()
    assert aggr_stats.custom == {}
    aggr_stats.set_custom_stats("which", "what")
    assert aggr_stats.custom == {"_run": {"which": "what"}}
    aggr_stats.set_custom_stats("which", "another what", "host")
    assert aggr_stats.custom == {"_run": {"which": "what"}, "host": {"which": "another what"}}


# Generated at 2022-06-22 20:19:42.824284
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    a = AggregateStats()
    a.set_custom_stats("whitelist", ['127.0.0.1'], None)
    assert(dict(whitelist=['127.0.0.1']) == a.custom['_run'])
    a.set_custom_stats("whitelist", ['127.0.0.1'])
    assert(dict(whitelist=['127.0.0.1']) == a.custom['_run'])
    a.set_custom_stats("whitelist", ['127.0.0.1'], 'host-example')
    assert(dict(whitelist=['127.0.0.1']) == a.custom['host-example'])


# Generated at 2022-06-22 20:19:46.397030
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok['host'] = 1
    stats.decrement('ok', 'host')
    assert stats.ok['host'] == 0
    stats.decrement('ok', 'host2')
    assert stats.ok['host2'] == 0

# Generated at 2022-06-22 20:19:50.903875
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    print(stats.ok)
    print(stats.ok['localhost'])
    stats.decrement('ok', 'localhost')
    print(stats.ok)
    print(stats.ok['localhost'])



# Generated at 2022-06-22 20:19:59.494315
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.custom == dict(), 'Failed to initialize custom statistics'

    what = dict(
        a=1,
        b=2
    )
    aggregate_stats.set_custom_stats('test', what)
    assert aggregate_stats.custom == dict(
        _run=dict(test=what)
    ), 'Failed to set custom statistics for the run'
    aggregate_stats.set_custom_stats('test', what, 'host1')
    assert aggregate_stats.custom == dict(
        _run=dict(test=what),
        host1=dict(test=what)
    ), 'Failed to set custom statistics for host1'
    aggregate_stats.set_custom_stats(w='what', h='host1')

# Generated at 2022-06-22 20:20:07.581486
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', '127.0.0.1')
    stats.increment('ok', '127.0.0.1')
    stats.increment('ok', '127.0.0.2')
    stats.increment('failures', '127.0.0.2')
    assert stats.summarize('127.0.0.1') == dict(ok=2, failures=0, unreachable=0, changed=0, skipped=0, rescued=0, ignored=0)
    assert stats.summarize('127.0.0.2') == dict(ok=1, failures=1, unreachable=0, changed=0, skipped=0, rescued=0, ignored=0)

# Generated at 2022-06-22 20:20:13.500226
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.processed == {}
    assert aggregate_stats.failures == {}
    assert aggregate_stats.ok == {}
    assert aggregate_stats.dark == {}
    assert aggregate_stats.changed == {}
    assert aggregate_stats.skipped == {}
    assert aggregate_stats.rescued == {}
    assert aggregate_stats.ignored == {}
    assert aggregate_stats.custom == {}


# Generated at 2022-06-22 20:20:17.893151
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok = { 'test-host': 5 }
    stats.decrement('ok', 'test-host')
    assert stats.ok == { 'test-host': 4 }, "Decreasing ok count failed"

    stats.decrement('ok', 'test-host')
    assert stats.ok == { 'test-host': 3 }, "Decreasing ok count failed"


# Generated at 2022-06-22 20:20:25.240987
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    stats.increment('ok', 'test.example.com')
    assert stats.ok['test.example.com'] == 1

    stats.increment('ok', 'test.example.com')
    assert stats.ok['test.example.com'] == 2



# Generated at 2022-06-22 20:20:30.416928
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("ok", "host")
    assert stats.processed == {"host": 1}

    try:
        stats.increment("xxx", "host")
    except AttributeError:
        assert True
    else:
        assert False


# Generated at 2022-06-22 20:20:40.496486
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    s = AggregateStats()
    s.update_custom_stats("dict", {})
    s.update_custom_stats("dict", {"a": 1})
    s.update_custom_stats("dict", {"a": 2})
    assert s.custom.get("_run").get("dict") == {"a": 3}
    s.update_custom_stats("list", [])
    s.update_custom_stats("list", [1])
    s.update_custom_stats("list", [2])
    assert s.custom.get("_run").get("list") == [1, 2]
    s.update_custom_stats("string", "")
    s.update_custom_stats("string", "foo")
    s.update_custom_stats("string", "bar")

# Generated at 2022-06-22 20:20:49.741912
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.ok = {'host': 2}
    assert stats.ok == {'host': 2}
    stats.decrement('ok', 'host')
    assert stats.ok == {'host': 1}
    stats.decrement('ok', 'host')
    assert stats.ok == {'host': 0}
    stats.decrement('ok', 'host')
    assert stats.ok == {'host': 0}
    stats.ok = {'host': -2}
    assert stats.ok == {'host': -2}
    stats.decrement('ok', 'host')
    assert stats.ok == {'host': -3}
    stats.decrement('ok', 'host')
    assert stats.ok == {'host': -4}

# Generated at 2022-06-22 20:20:54.190734
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg_stats = AggregateStats()
    assert agg_stats is not None, "agg_stats is None after creating"
    assert agg_stats.ok == {}, "ok is not empty"
    assert agg_stats.custom == {}, "custom is not empty"


# Generated at 2022-06-22 20:21:01.039141
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    from ansible.errors import AnsibleError
    try:
        as_ = AggregateStats()
        as_.decrement('ok', 'foo')
        assert False
    except KeyError:
        # This is the correct case
        assert True

    try:
        as_ = AggregateStats()
        as_.increment('ok', 'foo')
        as_.decrement('ok', 'foo')
        assert as_.ok['foo'] == 0
        assert True
    except Exception as e:
        assert False

    try:
        as_ = AggregateStats()
        as_.increment('ok', 'foo')
        as_.decrement('ok', 'bar')
        # This should fail since host should have been added
        assert False
    except KeyError:
        assert True

# Generated at 2022-06-22 20:21:07.481863
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("ok", "192.168.0.1")
    assert stats.processed["192.168.0.1"] == 1
    assert stats.ok["192.168.0.1"] == 1
    stats.increment("ok", "192.168.0.1")
    assert stats.ok["192.168.0.1"] == 2


# Generated at 2022-06-22 20:21:13.192355
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("ok", "host1")
    stats.increment("failures", "host2")
    stats.increment("dark", "host3")
    stats.increment("changed", "host4")
    stats.increment("skipped", "host5")
    stats.increment("rescued", "host6")
    stats.increment("ignored", "host7")


# Generated at 2022-06-22 20:21:24.850451
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg = AggregateStats()
    host = '192.168.0.1'

    agg.increment('ok', host)

    agg.increment('dark', host)
    agg.increment('changed', host)
    agg.increment('changed', host)
    agg.increment('skipped', host)
    agg.increment('rescued', host)
    agg.increment('ignored', host)
    agg.increment('ignored', host)
    agg.increment('failures', host)
    agg.increment('failures', host)

    agg.increment('dark', host)

    assert agg.ok[host] == 1
    assert agg.dark[host] == 2
    assert agg.changed[host] == 2
    assert agg.skipped[host] == 1
    assert agg.res

# Generated at 2022-06-22 20:21:34.713880
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    x = AggregateStats()
    x.decrement("ok", "test_host")
    assert x.ok == {'test_host': 0}

    x.ok['test_host'] = 2
    x.decrement("ok", "test_host")
    assert x.ok == {'test_host': 1}

    x.ok['test_host'] = -1
    x.decrement("ok", "test_host")
    assert x.ok == {'test_host': 0}

    # This should never happen, but let's be safe
    x.ok['test_host'] = 0
    x.decrement("ok", "test_host")
    assert x.ok == {'test_host': 0}

# Generated at 2022-06-22 20:21:40.545942
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}
    assert stats.__class__ == AggregateStats
    assert stats.__class__.__name__ == "AggregateStats"

AggregateStats.test_AggregateStats = test_AggregateStats

# Generated at 2022-06-22 20:21:51.239570
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment("dark", "host1")
    stats.increment("failures", "host1")
    stats.increment("failed", "host2")
    stats.increment("ok", "host1")
    stats.increment("ok", "host2")
    stats.increment("ok", "host1")

    assert stats.summarize("host1") == {"ok": 2,
                                        "failures": 1,
                                        "unreachable": 1,
                                        "changed": 0,
                                        "skipped": 0,
                                        "rescued": 0,
                                        "ignored": 0}

# Generated at 2022-06-22 20:22:01.600353
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    import unittest
    import sys
    import json

    ansible_python_version = sys.version_info[:2]
    if ansible_python_version == (2, 6):
        try:
            import unittest2 as unittest
        except ImportError:
            print("unable to import unittest2, try 'pip install unittest2'")
            sys.exit(1)

    class TestAggregateStats(unittest.TestCase):

        def setUp(self):
            self.aggregate_stats = AggregateStats()

        def test_update_aggregate_stats(self):
            self.aggregate_stats.update_custom_stats("test_list", [1,2,3])

# Generated at 2022-06-22 20:22:11.871934
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', '127.0.0.1')
    stats.increment('dark', '127.0.0.1')
    stats.increment('dark', '127.0.0.1')
    stats.increment('changed', '127.0.0.1')
    stats.increment('changed', '127.0.0.1')
    stats.increment('changed', '127.0.0.1')
    stats.increment('ok', '127.0.0.1')
    stats.increment('failures', '127.0.0.1')
    stats.increment('skipped', '127.0.0.1')
    stats.increment('ok', '127.0.0.1')


# Generated at 2022-06-22 20:22:15.765216
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    test_AggregateStats = AggregateStats()
    test_AggregateStats.increment("failures", "fake_host")
    test_AggregateStats.decrement("failures", "fake_host")
    assert test_AggregateStats.failures["fake_host"] == 0


# Generated at 2022-06-22 20:22:26.028897
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()

    assert aggregate_stats.processed == {}
    assert aggregate_stats.failures == {}
    assert aggregate_stats.ok == {}
    assert aggregate_stats.dark == {}
    assert aggregate_stats.changed == {}
    assert aggregate_stats.skipped == {}
    assert aggregate_stats.rescued == {}
    assert aggregate_stats.ignored == {}
    assert aggregate_stats.custom == {}

    aggregate_stats.increment("ok", "127.0.0.1")

    assert aggregate_stats.processed == {"127.0.0.1": 1}
    assert aggregate_stats.failures == {}
    assert aggregate_stats.ok == {"127.0.0.1": 1}
    assert aggregate_stats.dark == {}
    assert aggregate_stats.changed == {}
   

# Generated at 2022-06-22 20:22:31.686321
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    agg_stats = AggregateStats()
    agg_stats.increment('ok', 'server1')
    assert(agg_stats.ok['server1'] == 1)
    agg_stats.increment('ok', 'server1')
    assert(agg_stats.ok['server1'] == 2)
    agg_stats.increment('failures', 'server1')
    assert(agg_stats.failures['server1'] == 1)


# Generated at 2022-06-22 20:22:40.778305
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    a = AggregateStats()

    assert a.summarize('west') == {'ok': 0, 'failures': 0, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}

    a.increment('ok', 'west')
    assert a.summarize('west') == {'ok': 1, 'failures': 0, 'unreachable': 0, 'changed': 0, 'skipped': 0, 'rescued': 0, 'ignored': 0}

    a.increment('changed', 'west')
    assert a.summarize('west') == {'ok': 1, 'failures': 0, 'unreachable': 0, 'changed': 1, 'skipped': 0, 'rescued': 0, 'ignored': 0}

    a

# Generated at 2022-06-22 20:22:52.250997
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()

    stats.update_custom_stats('foo', 'bar', 'baz')
    assert stats.custom == {'baz': {'foo': 'bar'}}

    stats.update_custom_stats('foo', 'foobar')
    assert stats.custom == {'baz': {'foo': 'bar'}, '_run': {'foo': 'foobar'}}

    stats.update_custom_stats('foo', 1, 'baz')
    assert stats.custom == {'baz': {'foo': 'bar'}, '_run': {'foo': 'foobar'}}

    stats.update_custom_stats('foo', 1, 'qux')

# Generated at 2022-06-22 20:23:02.223190
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    def dict_compare(d1, d2):
        d1_keys = set(d1.keys())
        d2_keys = set(d2.keys())
        if d1_keys != d2_keys:
            return False
        for key in d1_keys:
            if d1[key] != d2[key]:
                return False

        return True

    stats = AggregateStats()
    assert dict_compare(stats.processed, {})
    assert dict_compare(stats.failures, {})
    assert dict_compare(stats.ok, {})
    assert dict_compare(stats.dark, {})
    assert dict_compare(stats.changed, {})
    assert dict_compare(stats.skipped, {})

# Generated at 2022-06-22 20:23:14.080417
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    stats = AggregateStats()
    # test dictionary
    stats.update_custom_stats('updated_dict', {'updated': 'value'})
    assert stats.custom['_run']['updated_dict'] == {'updated': 'value'}

    # test dictionary merging
    stats.update_custom_stats('updated_dict', {'new': 'value'})
    assert stats.custom['_run']['updated_dict'] == {'updated': 'value', 'new': 'value'}

    # test int
    stats.update_custom_stats('updated_int', 1)
    assert stats.custom['_run']['updated_int'] == 1

    # test int aggregation
    stats.update_custom_stats('updated_int', 1)
    assert stats.custom['_run']['updated_int'] == 2

   

# Generated at 2022-06-22 20:23:23.431560
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    test = AggregateStats()
    test.update_custom_stats('foo',1)
    assert test.custom['_run']['foo'] == 1

    test.update_custom_stats('foo','bar')
    assert test.custom['_run']['foo'] == 'bar'

    test.update_custom_stats('foo',['bar','baz'])
    assert test.custom['_run']['foo'] == ['bar','baz']

    test.update_custom_stats('foo',{'bar':'baz'})
    assert test.custom['_run']['foo'] == {'bar':'baz'}

    test.update_custom_stats('foo',1, 'bar')
    assert test.custom['bar']['foo'] == 1


# Generated at 2022-06-22 20:23:29.874794
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    host = 'localhost'
    assert(stats.failures.get(host, 0) == 0)
    stats.increment('failures', host)
    assert(stats.failures.get(host, 0) == 1)
    stats.increment('failures', host)
    stats.increment('failures', host)
    assert(stats.failures.get(host, 0) == 3)


# Generated at 2022-06-22 20:23:39.785111
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'foo')
    stats.increment('failures', 'foo')
    stats.increment('ok', 'bar')
    stats.increment('ok', 'bar')
    stats.increment('failures', 'bar')

    assert stats.summarize('foo') == dict(
        ok=1,
        failures=1,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0
    )
    assert stats.summarize('bar') == dict(
        ok=2,
        failures=1,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0
    )

# Generated at 2022-06-22 20:23:46.414419
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    stats = AggregateStats()

    stats.update_custom_stats('cmdline', '/usr/bin/ansible-playbook')
    stats.update_custom_stats('version', '2.0')
    stats.update_custom_stats('foo', 'bar')
    stats.update_custom_stats('foo', 'baz', host='h')

    assert stats.custom['_run']['cmdline'] == '/usr/bin/ansible-playbook'
    assert stats.custom['_run']['version'] == '2.0'
    assert stats.custom['_run']['foo'] == 'bar'
    assert stats.custom['h']['foo'] == 'baz'


# Generated at 2022-06-22 20:23:53.674054
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    agg = AggregateStats()
    agg.decrement('ok', 'localhost')
    assert agg.ok['localhost'] == 0
    agg.ok['localhost'] = 1
    agg.decrement('ok', 'localhost')
    assert agg.ok['localhost'] == 0
    agg.ok['localhost'] = 0
    agg.decrement('ok', 'localhost')
    assert agg.ok['localhost'] == 0

# Generated at 2022-06-22 20:24:03.318438
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()

    aggregate_stats.increment('ok', 'host1')
    assert (aggregate_stats.ok == {'host1': 1})
    assert (aggregate_stats.processed == {'host1': 1})

    aggregate_stats.increment('ok', 'host2')
    assert(aggregate_stats.ok == {'host1': 1, 'host2': 1})
    assert(aggregate_stats.processed == {'host1': 1, 'host2': 1})

    aggregate_stats.increment('failure', 'host1')
    assert(aggregate_stats.failures == {'host1': 1})
    assert(aggregate_stats.processed == {'host1': 1, 'host2': 1})


# Generated at 2022-06-22 20:24:07.758150
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'host1')
    aggregate_stats.increment('ok', 'host2')
    aggregate_stats.increment('ok', 'host1')
    assert aggregate_stats.ok == {'host1': 2, 'host2': 1}

# Generated at 2022-06-22 20:24:10.371211
# Unit test for constructor of class AggregateStats
def test_AggregateStats():

    # Test if it returns the correct type
    assert (isinstance(AggregateStats(), AggregateStats) == True)


# Generated at 2022-06-22 20:24:16.098809
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats_obj = AggregateStats()
    aggregate_stats_obj.set_custom_stats('test_key', {'test_key2': 'test_value2'})
    assert aggregate_stats_obj.custom['_run'] == {'test_key': {'test_key2': 'test_value2'}}



# Generated at 2022-06-22 20:24:21.964521
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.utils.vars import merge_hash

    stats = AggregateStats()
    stats.set_custom_stats("foo", 0, "localhost")
    assert stats.custom['localhost']['foo'] == 0

    stats.update_custom_stats("foo", 1, "localhost")
    assert stats.custom['localhost']['foo'] == 1

    stats.update_custom_stats("foo", 1.0, "localhost")
    assert stats.custom['localhost']['foo'] == 2

    stats.set_custom_stats("foo", 'hello world', "localhost")
    assert stats.custom['localhost']['foo'] == 'hello world'

    stats.update_custom_stats("foo", 'hello world', "localhost")
   

# Generated at 2022-06-22 20:24:31.915993
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    print("Testing constructor of class AggregateStats")
    stats = AggregateStats()
    assert stats.ok == {}, "ok should be initialized to empty dictionary"
    assert stats.failures == {}, "failures should be initialized to empty dictionary"
    assert stats.dark == {}, "dark should be initialized to empty dictionary"
    assert stats.changed == {}, "changed should be initialized to empty dictionary"
    assert stats.skipped == {}, "skipped should be initialized to empty dictionary"
    assert stats.rescued == {}, "rescued should be initialized to empty dictionary"
    assert stats.ignored == {}, "ignored should be initialized to empty dictionary"


# Generated at 2022-06-22 20:24:41.230164
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    assert stats.decrement("failures", "fake_host") == 0
    stats.increment("failures", "fake_host")
    assert stats.decrement("failures", "fake_host") == 0
    stats.increment("failures", "fake_host")
    stats.increment("failures", "fake_host")
    assert stats.decrement("failures", "fake_host") == 1
    stats.increment("failures", "fake_host")
    stats.increment("failures", "fake_host")
    stats.increment("failures", "fake_host")
    assert stats.decrement("failures", "fake_host") == 2
    stats.increment("failures", "fake_host")

# Generated at 2022-06-22 20:24:51.938791
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    """Test for ``AggregateStats.update_custom_stats``
    """
    host = 'localhost'
    aggregate_stats = AggregateStats()
    aggregate_stats.update_custom_stats('which', {'what': 'what'}, host)
    assert aggregate_stats.custom[host]['which'] == {'what': 'what'}

    new_dict = {'what_new': 'what'}
    aggregate_stats.update_custom_stats('which', new_dict, host)
    assert aggregate_stats.custom[host]['which'] == {'what': 'what', 'what_new': 'what'}

    aggregate_stats.update_custom_stats('which', 1, host)
    assert aggregate_stats.custom[host]['which'] == 1

# Generated at 2022-06-22 20:24:53.621677
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    assert AggregateStats().decrement('ok', 'localhost') == 0


# Generated at 2022-06-22 20:25:05.054501
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    # Test with different value of what
    # Test with host: '', 'localhost', 'host1'
    # Test with different values of what other than ok, failures, unreachable, changed, skipped, rescued, ignored
    # Test with not existing attribute

    aggregate_stats = AggregateStats()
    what = None
    host = 'localhost'
    try:
        aggregate_stats.increment(what, host)
    except:
        pass

    what = 'ok'
    try:
        aggregate_stats.increment(what, host)
    except:
        pass

    what = 'failures'
    try:
        aggregate_stats.increment(what, host)
    except:
        pass

    what = 'unreachable'
    try:
        aggregate_stats.increment(what, host)
    except:
        pass