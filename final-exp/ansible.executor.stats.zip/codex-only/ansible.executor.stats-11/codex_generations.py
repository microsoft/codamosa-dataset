

# Generated at 2022-06-22 20:14:59.370845
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()

    stats.set_custom_stats('a', 1, None)
    assert stats.custom['_run']['a'] == 1

    stats.set_custom_stats('b', 2, 'host1')
    assert stats.custom['host1']['b'] == 2



# Generated at 2022-06-22 20:15:09.400387
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()

    aggregate_stats.set_custom_stats("one", 1)
    aggregate_stats.set_custom_stats("two", 2, "hostA")
    aggregate_stats.set_custom_stats("three", 3, "hostB")
    aggregate_stats.set_custom_stats("two", 5, "hostA")
    aggregate_stats.set_custom_stats("three", 9, "hostB")
    aggregate_stats.set_custom_stats("two", 8, "hostA")
    aggregate_stats.set_custom_stats("three", 27, "hostB")

    assert aggregate_stats.custom["_run"] == {"one": 1}
    assert aggregate_stats.custom["hostA"] == {"two": 8}
    assert aggregate_stats.custom["hostB"] == {"three": 27}

# Generated at 2022-06-22 20:15:16.368007
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    aggregate_stats_obj = AggregateStats()
    assert aggregate_stats_obj.processed == {}
    assert aggregate_stats_obj.failures == {}
    assert aggregate_stats_obj.ok == {}
    assert aggregate_stats_obj.dark == {}
    assert aggregate_stats_obj.changed == {}
    assert aggregate_stats_obj.skipped == {}
    assert aggregate_stats_obj.rescued == {}
    assert aggregate_stats_obj.ignored == {}
    assert aggregate_stats_obj.custom == {}


# Generated at 2022-06-22 20:15:27.861136
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    
    # Test case1:
    # Create a object of AggregateStats class
    aggregateStats = AggregateStats()
    # Create some stats,
    aggregateStats.ok = {"192.168.1.1": 2}
    aggregateStats.failures = {"192.168.1.1": 2}
    aggregateStats.dark = {"192.168.1.1": 2}
    aggregateStats.changed = {"192.168.1.1": 2}
    aggregateStats.skipped = {"192.168.1.1": 2}
    aggregateStats.rescued = {"192.168.1.1": 2}
    aggregateStats.ignored = {"192.168.1.1": 2}
    # Call decrement method to decrease value of stats
    aggregateStats.decrement('ok', '192.168.1.1')


# Generated at 2022-06-22 20:15:30.300218
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'test')

    expected_stats = {'test': 1}
    assert expected_stats == stats.ok


# Generated at 2022-06-22 20:15:38.218003
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    ag = AggregateStats()
    ag.ok['host_ok'] = 1
    ag.failures['host_fail'] = 2
    ag.dark['host_dark'] = 3
    ag.changed['host_changed'] = 4
    ag.skipped['host_skipped'] = 5
    ag.rescued['host_rescued'] = 6
    ag.ignored['host_ignored'] = 7

    assert ag.summarize('host_fail') == dict(
        ok=0,
        failures=2,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0,
    )

# Generated at 2022-06-22 20:15:43.213777
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate = AggregateStats()
    aggregate.set_custom_stats("custom_key", {"dict_key": "dict_value"})
    aggregate.set_custom_stats("custom_key", {"dict_key": "second_value"}, host='myhost')
    assert aggregate.custom.get('_run').get("custom_key").get("dict_key") == "dict_value"
    assert aggregate.custom.get('myhost').get("custom_key").get("dict_key") == "second_value"


# Generated at 2022-06-22 20:15:53.846863
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggregate_stats = AggregateStats()
    aggregate_stats.ok = {'localhost': 1, 'example.com': 2}
    aggregate_stats.failures = {'example.com': 3}
    aggregate_stats.dark = {'example.com': 4}
    aggregate_stats.changed = {'example.com': 5}
    aggregate_stats.skipped = {'example.com': 6}
    aggregate_stats.rescued = {'example.com': 7}
    aggregate_stats.ignored = {'example.com': 8}

    expected = dict(
        ok=2,
        failures=3,
        unreachable=4,
        changed=5,
        skipped=6,
        rescued=7,
        ignored=8
    )
    assert expected == aggregate_stats.summarize('example.com')

# Generated at 2022-06-22 20:15:58.410465
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    '''Use pytest for unittest'''
    aggregate = AggregateStats()
    aggregate.increment('ok', 'host1')
    assert aggregate.ok['host1'] == 1
    aggregate.decrement('ok', 'host1')
    assert aggregate.ok['host1'] == 0

# Generated at 2022-06-22 20:16:04.580166
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg_stats = AggregateStats()
    assert agg_stats.processed == {}
    assert agg_stats.failures == {}
    assert agg_stats.ok == {}
    assert agg_stats.dark == {}
    assert agg_stats.changed == {}
    assert agg_stats.skipped == {}
    assert agg_stats.rescued == {}
    assert agg_stats.ignored == {}
    assert agg_stats.custom == {}


# Generated at 2022-06-22 20:16:16.088938
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    as1 = AggregateStats()
    as1.increment('failures', 'localhost')
    assert as1.processed['localhost'] == 1
    assert as1.failures['localhost'] == 1
    assert as1.ok.get('localhost', None) == None
    as1.increment('failures', 'localhost')
    assert as1.processed['localhost'] == 1
    assert as1.failures['localhost'] == 2
    assert as1.ok.get('localhost', None) == None
    as1.increment('ok', 'localhost')
    assert as1.processed['localhost'] == 1
    assert as1.failures['localhost'] == 2
    assert as1.ok.get('localhost', None) == 1
    as1.increment('ok', 'anotherhost')

# Generated at 2022-06-22 20:16:24.762219
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment("ok", "test_host")
    assert stats.ok["test_host"] == 1
    stats.increment("ok", "test_host")
    assert stats.ok["test_host"] == 2
    stats.increment("ok", "other_host")
    assert stats.ok["other_host"] == 1
    stats.increment("failures", "test_host")
    assert stats.failures["test_host"] == 1
    stats.increment("failures", "other_host")
    assert stats.failures["other_host"] == 1
    stats.increment("failures", "other_host")
    assert stats.failures["other_host"] == 2
    stats.increment("changed", "test_host")

# Generated at 2022-06-22 20:16:36.334403
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('failed', 1)
    stats.update_custom_stats('skipped', 1)
    stats.update_custom_stats('changed', 1)
    stats.update_custom_stats('ignored', 1)
    stats.update_custom_stats('ok', 1)
    stats.update_custom_stats('rescued', 1)
    stats.update_custom_stats('dark', 1)
    stats.update_custom_stats('processed', 1)

# Generated at 2022-06-22 20:16:45.976354
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok = {'host1':1, 'host2':2, 'host3':3}
    stats.failures = {'host1':2, 'host2':1, 'host3':0}
    stats.dark = {'host1':3, 'host2':0, 'host3':1}
    stats.changed = {'host1':4, 'host2':2, 'host3':1}
    stats.skipped = {'host1':5, 'host2':3, 'host3':2}
    stats.rescued = {'host1':6, 'host2':4, 'host3':1}
    stats.ignored = {'host1':7, 'host2':5, 'host3':0}
    # assertEqual(first, second, msg

# Generated at 2022-06-22 20:16:53.160176
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()

    # Initial state
    assert len(stats.custom) == 0

    # Set first custom stat for host
    stats.set_custom_stats('stat1', 'value', host='host01')
    assert stats.custom['host01'] is not None and stats.custom['host01'] == {'stat1': 'value'}

    # Set second custom stat for host
    stats.set_custom_stats('stat2', 'value', host='host01')
    assert stats.custom['host01'] is not None and stats.custom['host01'] == {'stat1': 'value', 'stat2': 'value'}

    # Set first custom stat for run
    stats.set_custom_stats('stat1', 'value')

# Generated at 2022-06-22 20:16:57.522205
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    stats = AggregateStats()
    stats.update_custom_stats('a', {'b': 5}, host = '_run')
    stats.update_custom_stats('a', {'b': 5}, host = '_run')

    assert stats.custom['_run']['a'] == {'b': 10}

# Generated at 2022-06-22 20:17:04.113986
# Unit test for constructor of class AggregateStats
def test_AggregateStats():

    stats = AggregateStats()

    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-22 20:17:14.465659
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    aggr_stats = AggregateStats()
    dict_target = dict(a=1, b=2, c=dict(c1=1, c2=2))
    aggr_stats.update_custom_stats('test', dict_target, '_run')
    aggr_stats.update_custom_stats('test', dict_target, '_run')
    assert aggr_stats.custom['_run']['test']['a'] == 1
    assert aggr_stats.custom['_run']['test']['b'] == 2
    assert aggr_stats.custom['_run']['test']['c']['c1'] == 1
    assert aggr_stats.custom['_run']['test']['c']['c2'] == 2

    int_target = 500
    aggr

# Generated at 2022-06-22 20:17:18.375498
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    agg_stats = AggregateStats()
    agg_stats.set_custom_stats("foo", "bar", "localhost")
    assert agg_stats.custom == {"localhost": {"foo": "bar"}}


# Generated at 2022-06-22 20:17:30.081777
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    # Create an instance of AggregateStats
    ag = AggregateStats()
    assert ag.processed == {}

    # Create a bunch of hosts
    hosts = ['localhost', '127.0.0.1', '::1']

    # Ensure that the values of each key in processed, is an empty dictionary
    for host in hosts:
        assert ag.processed[host] == {}

    # Ensure that the values of each key in processed, is an empty dictionary
    for host in hosts:
        assert ag.processed[host] == {}

    # Ensure that the values of each key in failures, is an empty dictionary
    for host in hosts:
        assert ag.failures[host] == {}

    # Ensure that the values of each key in ok, is an empty dictionary
    for host in hosts:
        assert ag.ok[host] == {}

   

# Generated at 2022-06-22 20:17:37.648629
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    a=AggregateStats()
    a.increment("ok","localhost")
    a.increment("ok","localhost")
    # Key was previously decremented, should return 0
    a.decrement("ok","localhost")
    a.decrement("ok","localhost")
    assert a.ok["localhost"] == 0

    # Key has not been incremented, should return 0
    a.decrement("failures","localhost")
    assert a.failures["localhost"] == 0

    # Try when the key is not present
    try:
        a.decrement("ok","not present")
    except KeyError:
        assert True


# Generated at 2022-06-22 20:17:47.215577
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    assert 1 == stats.ok['localhost']
    assert 0 == stats.ok.get('example.com', 0)
    assert 0 == stats.failures.get('localhost', 0)
    assert 1 == stats.processed['localhost']

    # Test that decrement works
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert 1 == stats.ok['localhost']

    # Test that decrement works with unknown host
    stats.decrement('ok', 'unknown')
    assert 0 == stats.ok.get('unknown', 0)

    # Test decrement for an unknown field
    stats.decrement('unknown', 'localhost')
    assert 0 == stats.unknown.get('localhost', 0)

    #

# Generated at 2022-06-22 20:17:57.624547
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    '''
    Ensures summarize method from class AggregateStats will return proper
    statistics.
    '''
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('dark', 'localhost')
    stats.increment('changed', 'localhost')
    stats.increment('skipped', 'localhost')
    stats.increment('rescued', 'localhost')
    stats.increment('ignored', 'localhost')

    summary = stats.summarize('localhost')

    if summary['ok'] != 1:
        raise AssertionError("Expected summary['ok'] to be 1, not '%s'", summary['ok'])

# Generated at 2022-06-22 20:18:03.248847
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-22 20:18:06.678519
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    ags = AggregateStats()
    ags.set_custom_stats('label', 'value', 'localhost')

    assert ags.custom['localhost'] == {'label': 'value'}


# Generated at 2022-06-22 20:18:18.617110
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    '''
    Tests:
    - Instantiate a class AggregateStats
    - Check that attributes are initialized as expected
    '''

    test_AggregateStats = AggregateStats()

    assert getattr(test_AggregateStats, 'processed') == {}
    assert getattr(test_AggregateStats, 'failures') == {}
    assert getattr(test_AggregateStats, 'ok') == {}
    assert getattr(test_AggregateStats, 'dark') == {}
    assert getattr(test_AggregateStats, 'changed') == {}
    assert getattr(test_AggregateStats, 'skipped') == {}
    assert getattr(test_AggregateStats, 'rescued') == {}
    assert getattr(test_AggregateStats, 'ignored') == {}

# Generated at 2022-06-22 20:18:22.606034
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment( 'ok', 'host' )
    assert stats.ok['host'] == 1
    stats.increment( 'ok', 'host' )
    assert stats.ok['host'] == 2


# Generated at 2022-06-22 20:18:32.101330
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    t1 = AggregateStats()
    t1.update_custom_stats('a', 1, host='_run')
    t1.update_custom_stats('b', 2, host='_run')
    t1.update_custom_stats('c', 3, host='_run')
    t1.update_custom_stats('a', 4)
    t1.update_custom_stats('b', 5)
    t1.update_custom_stats('c', 6)

    # checks
    assert t1.custom['_run']['a'] == 5
    assert t1.custom['_run']['b'] == 7
    assert t1.custom['_run']['c'] == 9



# Generated at 2022-06-22 20:18:41.653375
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    from ansible.utils.vars import combine_hash

    results = AggregateStats()
    results.increment('ok', 'localhost')
    results.increment('ok', 'localhost')
    results.increment('ok', 'localhost')
    results.increment('ok', 'localhost')
    results.increment('failures', 'localhost')
    results.increment('dark', 'localhost')
    results.increment('changed', 'localhost')
    results.increment('skipped', 'localhost')
    results.increment('rescued', 'localhost')
    results.increment('ignored', 'localhost')
    results.set_custom_stats('test1', 'test1', 'localhost')
    results.set_custom_stats('test2', 'test2', 'localhost')


# Generated at 2022-06-22 20:18:45.959069
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    ''' This test is to test the decrement method of AggregateStats class '''

    # initialize the object
    stats = AggregateStats()

    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.decrement('ok', 'localhost')
    assert stats.ok['localhost'] == 1

# Generated at 2022-06-22 20:18:57.298032
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}

    stats.increment('ok', 'localhost')
    assert stats.processed == {'localhost': 1}
    assert stats.ok == {'localhost': 1}

    stats.increment('ok', 'localhost')
    assert stats.processed == {'localhost': 1}
    assert stats.ok == {'localhost': 2}

    stats.increment('ok', 'host2')
    assert stats.processed == {'localhost': 1, 'host2': 1}

# Generated at 2022-06-22 20:19:05.934939
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    # This is a unit test for method summarize of class AggregateStats.
    # It is only for testing; it should never be included in the final playbook.
    # 1. instantiate aggregate stats
    agg_stats = AggregateStats()
    # 2. add some known stats
    agg_stats.ok['TEST01'] = 1
    agg_stats.dark['TEST01'] = 2
    agg_stats.ok['TEST02'] = 3
    agg_stats.dark['TEST02'] = 4
    # 3. get the summary for test01 and test02
    summary01 = agg_stats.summarize('TEST01')
    summary02 = agg_stats.summarize('TEST02')
    # 4. compare the expected values with the actual values

# Generated at 2022-06-22 20:19:12.629895
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('abc', 1, None)
    assert stats.custom['_run'] == {'abc': 1}
    stats.set_custom_stats('abc', 2, None)
    assert stats.custom['_run'] == {'abc': 2}
    stats.set_custom_stats('abc', 3, 'localhost')
    assert stats.custom['localhost'] == {'abc': 3}
    stats.set_custom_stats('def', 4, 'localhost')
    assert stats.custom['localhost'] == {'abc': 3, 'def': 4}


# Generated at 2022-06-22 20:19:20.817776
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    custom1 = dict(a=dict(b=1))
    custom2 = dict(a=dict(b=2))
    custom3 = dict(a=dict(b=3), c=2)
    custom4 = dict(a=dict(b=4, c=9), d=45)
    custom5 = dict(a=dict(b=5), c=3)

    stats = AggregateStats()
    stats.update_custom_stats('custom', custom1)
    assert stats.custom['_run']['custom'] == custom1

    stats.update_custom_stats('custom', custom2)
    assert stats.custom['_run']['custom'] == custom2

    stats.update_custom_stats('custom', custom3)
    assert stats.custom['_run']['custom'] == custom3

    stats.update

# Generated at 2022-06-22 20:19:28.808218
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok['localhost'] = 1
    stats.failures['localhost'] = 1
    stats.dark['localhost'] = 1
    stats.changed['localhost'] = 1
    stats.skipped['localhost'] = 1
    stats.rescued['localhost'] = 1
    stats.ignored['localhost'] = 1

    assert stats.summarize('localhost') == {'ok': 1, 'failures': 1, 'unreachable': 1, 'changed': 1, 'skipped': 1, 'ignored': 1, 'rescued': 1}

# Generated at 2022-06-22 20:19:34.962377
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}


# Generated at 2022-06-22 20:19:43.752924
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    stats = AggregateStats()
    stats.update_custom_stats("test", 123)
    assert stats.custom["_run"]["test"] == 123

    stats.update_custom_stats("test", {"z": 8}, "test-host")
    assert stats.custom["test-host"]["test"] == {"z": 8}

    stats.update_custom_stats("test", 456, "test-host")
    assert stats.custom["test-host"]["test"] == 456

    stats.update_custom_stats("test", {"z": 8}, "test-host")
    assert stats.custom["test-host"]["test"] == {"z": 8}

# Generated at 2022-06-22 20:19:54.472229
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()

    stats.set_custom_stats('test_key', 10)
    stats.set_custom_stats('test_key2', 3.14)
    stats.set_custom_stats('test_key3', 'test_string')
    stats.set_custom_stats('test_key4', {'a' : 'b', 'c' : 10})
    stats.set_custom_stats('test_key5', ['a', 'b', 'c'])

    # fail if same key is set twice
    stats.set_custom_stats('test_key', 10)

    # test_key
    assert isinstance(stats.custom['_run']['test_key'], int)
    assert stats.custom['_run']['test_key'] == 10

    # test_key2

# Generated at 2022-06-22 20:20:01.819318
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('failures', 'host1.example.net')
    print("Wanted : {'host1.example.net': 1}")
    print("Got : ", stats.failures)
    stats.decrement('failures', 'host1.example.net')
    print("Wanted: {'host1.example.net': 0}")
    print("Got : ", stats.failures)


if __name__ == "__main__":
    import doctest
    doctest.testmod()
    test_AggregateStats_decrement()

# Generated at 2022-06-22 20:20:03.578070
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('attacks', 1)
    assert stats.custom['_run']['attacks'] == 1

# Generated at 2022-06-22 20:20:12.631272
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    aggr_stats = AggregateStats()
    aggr_stats.ok["localhost"] = 2
    aggr_stats.changed["localhost"] = 1
    aggr_stats.dark["localhost"] = 3

    expected = dict(
        ok=2,
        failures=0,
        unreachable=3,
        changed=1,
        skipped=0,
        rescued=0,
        ignored=0,
    )
    result = aggr_stats.summarize("localhost")
    assert result == expected


test_AggregateStats_summarize()

# Generated at 2022-06-22 20:20:17.087742
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    custom = 'test'
    stats = AggregateStats()
    stats.set_custom_stats(custom, 1234, 'host1')
    assert stats.custom['host1']['test'] == 1234
    stats.set_custom_stats(custom, 5678, 'host2')
    assert stats.custom['host2']['test'] == 5678


# Generated at 2022-06-22 20:20:28.364339
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()

    assert aggregate_stats.custom == {}
    aggregate_stats.set_custom_stats("foo", 12)
    assert aggregate_stats.custom == {'_run': {'foo': 12}}
    aggregate_stats.set_custom_stats("bar", 34, 'localhost')
    assert aggregate_stats.custom == {'_run': {'foo': 12}, 'localhost': {'bar': 34}}
    aggregate_stats.set_custom_stats("foobar", 56, 'localhost')
    assert aggregate_stats.custom == {'_run': {'foo': 12}, 'localhost': {'bar': 34, 'foobar': 56}}
    aggregate_stats.set_custom_stats("foobar", 78, 'localhost')

# Generated at 2022-06-22 20:20:40.100007
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():

    from ansible.utils.display import Display
    display = Display()

    agg = AggregateStats()
    agg.ok['host1'] = 2
    agg.decrement('ok', 'host1')
    assert agg.ok['host1'] == 1
    agg.decrement('ok', 'host1')
    assert agg.ok['host1'] == 0
    agg.decrement('ok', 'host1')
    assert agg.ok['host1'] == 0,\
            display.error("Decrement can't be below 0")
    agg.ok['host1'] = None
    agg.decrement('ok', 'host1')
    assert agg.ok['host1'] == 0,\
            display.error("Decrement can't be below 0")

# Generated at 2022-06-22 20:20:45.495169
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    a = AggregateStats()
    # test for custom stats that aren't initialized yet
    a.update_custom_stats('a', 1)
    assert a.custom['_run']['a'] == 1
    # test for custom stats that are existing
    a.update_custom_stats('a', 1)
    assert a.custom['_run']['a'] == 2
    # test for custom stats that are existing but with a different type
    a.update_custom_stats('a', 'another', host='localhost')
    assert a.custom['localhost']['a'] == 'another'




# Generated at 2022-06-22 20:20:56.346959
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.ok['localhost'] = 1
    stats.ok['client.localdomain'] = 1
    stats.failures['server.localdomain'] = 1
    stats.rescued['client.localdomain'] = 1

    assert stats.summarize('localhost') == {'ok': 1, 'changed': 0, 'ignored': 0, 'rescued': 0, 'skipped': 0, 'failures': 0, 'unreachable': 0}
    assert stats.summarize('client.localdomain') == {'ok': 1, 'changed': 0, 'ignored': 0, 'rescued': 1, 'skipped': 0, 'failures': 0, 'unreachable': 0}

# Generated at 2022-06-22 20:21:07.533355
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()

    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('failures', 'localhost')

    assert stats.summarize('localhost') == dict(
        ok=2,
        failures=3,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0,
    )

    stats.increment('changed', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('skipped', 'localhost')
    stats.increment('skipped', 'localhost')
    stats.increment('skipped', 'localhost')
    stats.increment

# Generated at 2022-06-22 20:21:11.913511
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()
    aggregate_stats.increment('ok', 'test')
    aggregate_stats.increment('ok', 'test')
    assert aggregate_stats.ok == dict(test=2)
    assert aggregate_stats.processed == dict(test=1)

# Generated at 2022-06-22 20:21:20.102560
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('a','b','1.2.3.4')
    assert stats.custom['1.2.3.4']['a'] == 'b'

    stats.set_custom_stats('a','b')
    assert stats.custom['_run']['a'] == 'b'


# Generated at 2022-06-22 20:21:27.313976
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.increment('ignored', 'host1')
    stats.decrement('ignored', 'host1')
    assert not stats.ignored

    stats.increment('ignored', 'host1')
    stats.increment('ignored', 'host2')
    assert stats.ignored == {'host1': 1, 'host2': 1}
    stats.decrement('ignored', 'host2')
    assert stats.ignored == {'host1': 1, 'host2': 0}
    stats.decrement('ignored', 'host1')
    assert stats.ignored == {'host1': 0, 'host2': 0}

# Generated at 2022-06-22 20:21:37.080310
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    '''Unit test for method summarize of class AggregateStats'''

    stat = AggregateStats()

    # Test: summarize() for null stats
    assert stat.summarize("dummy_host") == dict(
            ok=0,
            failures=0,
            unreachable=0,
            changed=0,
            skipped=0,
            rescued=0,
            ignored=0,
        )

    # Test: getter/setter and summarize() for "ok"
    stat.ok["dummy_host"] = 100
    assert stat.ok["dummy_host"] == 100
    assert stat.summarize("dummy_host")["ok"] == 100

    # Test: getter/setter and summarize() for "failures"
    stat.failures["dummy_host"] = 100

# Generated at 2022-06-22 20:21:48.849353
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    from ansible.executor.task_result import TaskResult

    hostname = "unittesthost"
    # Test 1: return None when task passed
    res = TaskResult(host=hostname, task=dict(name="unittesttask"))
    res._result = dict(failed=False, changed=False, skipped=False)

    aggr = AggregateStats()
    aggr.set_custom_stats("_result", res, host=hostname)
    assert aggr.custom == {
        hostname: {
            "_result": res
        }
    }

    # Test 2: return None when task failed
    res = TaskResult(host=hostname, task=dict(name="unittesttask"))
    res._result = dict(failed=True, changed=False, skipped=False)

    aggr2 = AggregateStats

# Generated at 2022-06-22 20:22:00.580555
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    astats = AggregateStats()
    astats.increment("ok", "host1")
    astats.increment("ok", "host1")
    astats.increment("ok", "host2")
    astats.increment("failures", "host1")
    astats.increment("ignored", "host2")
    #
    assert astats.summarize("host1") == dict(
        ok=2,
        failures=1,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0,
    )

# Generated at 2022-06-22 20:22:03.886982
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats("a", 10)
    assert stats.custom["_run"]["a"] == 10
    stats.set_custom_stats("b", "hello")
    assert stats.custom["_run"]["b"] == "hello"



# Generated at 2022-06-22 20:22:07.921082
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    stats.increment("ok", "127.0.0.1")
    assert stats.ok["127.0.0.1"] == 1

# Generated at 2022-06-22 20:22:12.599756
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    agg_stats = AggregateStats()

    assert agg_stats.ok == {}
    assert agg_stats.failures == {}
    assert agg_stats.dark == {}
    assert agg_stats.changed == {}
    assert agg_stats.skipped == {}
    assert agg_stats.rescued == {}
    assert agg_stats.ignored == {}


# Generated at 2022-06-22 20:22:23.721567
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():

    # Instantiates an object of class AggregateStats
    test_aggr_stats = AggregateStats()

    # Instantiate 2 dictionaries to test
    test_dict_1 = {
        'test': {
            '1': 1
        }
    }

    test_dict_2 = {
        'test': {
            '1': 2,
            '2': 3
        }
    }

    # Call method update_custom_stats
    test_aggr_stats.update_custom_stats('test', test_dict_1)
    test_aggr_stats.update_custom_stats('test', test_dict_2)

    expected_results = {'test': {'1': 3, '2': 3}}

    assert test_aggr_stats.custom['_run'] == expected_results

# Generated at 2022-06-22 20:22:24.832258
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats.ok == {}


# Generated at 2022-06-22 20:22:30.665147
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    assert AggregateStats().custom      == {}
    assert AggregateStats().processed   == {}
    assert AggregateStats().failures    == {}
    assert AggregateStats().ok          == {}
    assert AggregateStats().dark        == {}
    assert AggregateStats().changed     == {}
    assert AggregateStats().skipped     == {}
    assert AggregateStats().rescued     == {}
    assert AggregateStats().ignored     == {}

# Generated at 2022-06-22 20:22:35.923524
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats == {
        'processed': {},
        'failures': {},
        'ok': {},
        'dark': {},
        'changed': {},
        'skipped': {},
        'rescued': {},
        'ignored': {},
        'custom': {},
    }

# Generated at 2022-06-22 20:22:39.577218
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert stats
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}
    assert stats.custom == {}

# Generated at 2022-06-22 20:22:50.832550
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    stats = AggregateStats()
    stats.set_custom_stats('fruits', {})
    stats.set_custom_stats('fruits', {'apple': 10}, 'test-01')
    stats.set_custom_stats('fruits', {'apple': 10, 'banana': 5}, 'test-02')

    # _run does not exist, it should not be changed, and no exception should be raised
    stats.set_custom_stats('fruits', {'apple': 10, 'banana': 5, 'orange': 15})

    aggregate_stats = stats.custom

    assert len(aggregate_stats) == 3
    assert aggregate_stats['_run'] == {'fruits': {}}
    assert aggregate_stats['test-01'] == {'fruits': {'apple': 10}}

# Generated at 2022-06-22 20:23:01.169623
# Unit test for method update_custom_stats of class AggregateStats
def test_AggregateStats_update_custom_stats():
    host = 'localhost'
    host_run = '_run'
    stat = AggregateStats()

    # test no existing custom stat
    stat.update_custom_stats('custom1', [1,2,3], host)
    assert stat.custom[host]['custom1'] == [1,2,3]

    # test adding to existing custom stat
    stat.update_custom_stats('custom1', [4,5,6], host)
    assert stat.custom[host]['custom1'] == [1,2,3,4,5,6]

    # test adding to existing custom stat (again)
    stat.update_custom_stats('custom1', [7,8,9], host)

# Generated at 2022-06-22 20:23:11.876516
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # testing corner cases for decrement
    stats = AggregateStats()
    stats.decrement("ok", "foo")
    assert stats.ok["foo"] == 0
    stats.decrement("ok", "bar")
    assert stats.ok["bar"] == 0
    stats.decrement("ok", "foo")
    assert stats.ok["foo"] == 0
    stats.ok["bar"] = 2
    stats.decrement("ok", "bar")
    assert stats.ok["bar"] == 1
    stats.decrement("ok", "bar")
    assert stats.ok["bar"] == 0
    stats.decrement("ok", "bar")
    assert stats.ok["bar"] == 0

# Generated at 2022-06-22 20:23:21.547174
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()

    stats.increment('ok', '10.1.1.1')
    stats.increment('ok', '10.1.1.1')
    stats.increment('ok', '10.1.1.2')
    stats.increment('changed', '10.1.1.2')
    stats.increment('failed', '10.1.1.3')
    stats.increment('ok', '10.1.1.4')
    stats.increment('ok', '10.1.1.4')
    stats.increment('failed', '10.1.1.4')

    assert stats.processed['10.1.1.1'] == 1
    assert stats.processed['10.1.1.2'] == 1

# Generated at 2022-06-22 20:23:30.752901
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    assert stats.processed == {}
    assert stats.failures == {}
    assert stats.ok == {}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}

    stats.increment("ok", "localhost")

    assert stats.processed == {"localhost": 1}
    assert stats.failures == {}
    assert stats.ok == {"localhost": 1}
    assert stats.dark == {}
    assert stats.changed == {}
    assert stats.skipped == {}
    assert stats.rescued == {}
    assert stats.ignored == {}


# Generated at 2022-06-22 20:23:37.745118
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    assert len(stats.processed.keys()) == 0
    assert len(stats.failures.keys()) == 0
    assert len(stats.ok.keys()) == 0
    assert len(stats.dark.keys()) == 0
    assert len(stats.changed.keys()) == 0
    assert len(stats.skipped.keys()) == 0
    assert len(stats.rescued.keys()) == 0
    assert len(stats.ignored.keys()) == 0
    assert len(stats.custom.keys()) == 0


# Generated at 2022-06-22 20:23:42.332109
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.custom == {}
    aggregate_stats.set_custom_stats('foo', 'bar', 'localhost')
    assert aggregate_stats.custom == {'localhost': {'foo': 'bar'}}


# Generated at 2022-06-22 20:23:46.213088
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    hosts = ['host1', 'host2']

    ok = AggregateStats()
    for host in hosts:
        ok.increment('ok', host)

    for host in hosts:
        ok.decrement('ok', host)

    for host in hosts:
        assert ok.ok[host] == 0

# Generated at 2022-06-22 20:23:58.289313
# Unit test for method set_custom_stats of class AggregateStats
def test_AggregateStats_set_custom_stats():

    stats = AggregateStats()
    stats.set_custom_stats('test', 'a')
    assert stats.custom.get('_run') == {'test': 'a'}, "set_custom_stats didn't set"
    stats.set_custom_stats('test', 'b')
    assert stats.custom.get('_run') == {'test': 'b'}, "set_custom_stats didn't replace existing"
    stats.set_custom_stats('test', 'c', 'localhost')
    assert stats.custom.get('localhost') == {'test': 'c'}, "set_custom_stats didn't set for host"
    stats.set_custom_stats('test', 'd', 'localhost')

# Generated at 2022-06-22 20:24:07.149753
# Unit test for constructor of class AggregateStats
def test_AggregateStats():
    stats = AggregateStats()
    stats.increment('ok','127.0.0.1')
    stats.increment('ok','127.0.0.2')
    stats.increment('ok','127.0.0.3')
    stats.increment('ok','127.0.0.3')
    stats.increment('ok','127.0.0.3')
    stats.increment('ok','127.0.0.3')
    stats.increment('ok','127.0.0.3')
    stats.increment('ok','127.0.0.3')

    stats.increment('changed','127.0.0.1')
    stats.increment('changed','127.0.0.2')
    stats.increment('failed','127.0.0.1')
    stats.incre

# Generated at 2022-06-22 20:24:18.702220
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    aggregate_stats = AggregateStats()
    assert aggregate_stats.processed == {}
    assert aggregate_stats.failures == {}
    assert aggregate_stats.ok == {}
    assert aggregate_stats.dark == {}
    assert aggregate_stats.changed == {}
    assert aggregate_stats.skipped == {}
    assert aggregate_stats.rescued == {}
    assert aggregate_stats.ignored == {}

    aggregate_stats.increment("ok", "host0")
    assert aggregate_stats.processed == {"host0": 1}
    assert aggregate_stats.failures == {}
    assert aggregate_stats.ok == {"host0": 1}
    assert aggregate_stats.dark == {}
    assert aggregate_stats.changed == {}
    assert aggregate_stats.skipped == {}
    assert aggregate_stats.rescued == {}
    assert aggregate

# Generated at 2022-06-22 20:24:26.936044
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    test_subject = AggregateStats()
    test_subject.increment('ok', 'localhost')
    test_subject.increment('failures', 'localhost')
    actual = test_subject.ok['localhost']
    expected = 1
    assert actual == expected, "increment() failed to increment ok"
    actual = test_subject.failures['localhost']
    expected = 1
    assert actual == expected, "increment() failed to increment failures"


# Generated at 2022-06-22 20:24:37.702056
# Unit test for method summarize of class AggregateStats
def test_AggregateStats_summarize():
    stats = AggregateStats()
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host1')
    stats.increment('ok', 'host2')
    stats.increment('changed', 'host2')
    stats.increment('failures', 'host2')
    stats.increment('ok', 'host3')
    stats.increment('dark', 'host3')
    stats.increment('ok', 'host4')
    stats.increment('ok', 'host4')
    stats.increment('ignored', 'host4')
    stats.increment('ignored', 'host4')
    stats.increment('ignored', 'host4')


# Generated at 2022-06-22 20:24:46.713296
# Unit test for method increment of class AggregateStats
def test_AggregateStats_increment():
    stats = AggregateStats()
    stats.increment('changed', 'foo')
    assert stats.changed['foo'] == 1
    stats.increment('changed', 'foo')
    assert stats.changed['foo'] == 2
    stats.increment('skipped', 'foo')
    assert stats.skipped['foo'] == 1
    stats.increment('skipped', 'baz')
    assert stats.skipped['baz'] == 1
    assert stats.skipped['foo'] == 1

# Generated at 2022-06-22 20:24:53.056884
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    # build a test fixture for the object
    stats = AggregateStats()
    stats.increment('ok', 'localhost')
    stats.increment('ok', 'localhost')
    stats.increment('failures', 'localhost')
    stats.increment('changed', 'localhost')

    assert stats.ok['localhost'] == 2
    assert stats.failures['localhost'] == 1
    assert stats.changed['localhost'] == 1

    # run the method on the fixture
    stats.decrement('ok', 'localhost')

    # ensure the method ran as expected
    assert stats.ok['localhost'] == 1


# Generated at 2022-06-22 20:24:56.655612
# Unit test for method decrement of class AggregateStats
def test_AggregateStats_decrement():
    stats = AggregateStats()
    stats.failures['host1'] = 1
    stats.decrement('failures', 'host1')
    assert stats.failures['host1'] == 0
    stats.decrement('failures', 'host1')
    assert stats.failures['host1'] == 0