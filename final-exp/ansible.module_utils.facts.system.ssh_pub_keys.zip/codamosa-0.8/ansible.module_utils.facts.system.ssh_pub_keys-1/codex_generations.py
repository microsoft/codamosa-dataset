

# Generated at 2022-06-11 05:20:58.167354
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    module = None
    collected_facts = dict()
    ssh_pub_key_facts = collector.collect(module, collected_facts)
    assert len(ssh_pub_key_facts) > 0

# Generated at 2022-06-11 05:21:08.898845
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()

# Generated at 2022-06-11 05:21:17.735834
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import stat
    import shutil
    import tempfile
    import ansible.module_utils.facts.collectors.ssh_pubkey as ssh_pubkey
    import ansible.module_utils.facts.collectors.base as base
    import ansible.module_utils.facts.utils as utils

    temp_dir = tempfile.mkdtemp()
    temp_key_dir = os.path.join(temp_dir, 'ssh_pub_keys')
    os.mkdir(temp_key_dir)
    temp_key_files = []

    temp_text_files = [os.path.join(temp_key_dir, f) for f in ['ssh_host_rsa_key.pub', 'ssh_host_dsa_key.pub']]

# Generated at 2022-06-11 05:21:26.388294
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''Unit test for method collect of class SshPubKeyFactCollector'''
    ssh_pub_key_facts = SshPubKeyFactCollector.collect()
    # keys should contain the name of all facts produced by this class
    assert ssh_pub_key_facts.keys() == {'ssh_host_pub_keys',
                                        'ssh_host_key_dsa_public',
                                        'ssh_host_key_rsa_public',
                                        'ssh_host_key_ecdsa_public',
                                        'ssh_host_key_ed25519_public'}



# Generated at 2022-06-11 05:21:32.758709
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    input_paths = {'/etc/ssh/ssh_host_rsa_key.pub': 'ssh-rsa keydata hostname'}
    expected = {'ssh_host_key_rsa_public': 'keydata',
                'ssh_host_key_rsa_public_keytype': 'ssh-rsa'}

    collector = SshPubKeyFactCollector()
    output = collector.collect(collected_facts={}, module_=None)

    assert output == expected

# Generated at 2022-06-11 05:21:42.789550
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import FactCollector


# Generated at 2022-06-11 05:21:53.766690
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Test SshPubKeyFactCollector.collect()."""
    # Test with an empty dict.
    fact_collector = SshPubKeyFactCollector()
    collected_facts = {}

# Generated at 2022-06-11 05:21:58.164085
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # all keys are valid
    collector = SshPubKeyFactCollector(None)

# Generated at 2022-06-11 05:22:08.251938
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector(None)


# Generated at 2022-06-11 05:22:18.804636
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # Test without any sshpubkey present on the box
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']

    # Create a SshPubKeyFactCollector
    sshpubkey_fact_collector = SshPubKeyFactCollector()
    # Execute run method of SshPubKeyFactCollector
    facts = sshpubkey_fact_collector.collect(module=MockModule())
    # Assert if method returns empty facts
    assert not facts

    # Test with sshpubkey present on the box
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']

    # Create a SshPubKeyFactCollector


# Generated at 2022-06-11 05:22:29.066815
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils

    tmpdir = tempfile.mkdtemp(dir='/tmp')
    keydir = os.path.join(tmpdir, 'ssh')
    os.mkdir(keydir)
    os.chdir(keydir)

    mock_collector = ansible.module_utils.facts.collector.BaseFactCollector()


# Generated at 2022-06-11 05:22:39.082744
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = []
    collector = SshPubKeyFactCollector()
    facts = collector.collect(module, collected_facts)
    # facts = dict()
    # for fact_name, fact_val in collected_facts:
    #     facts[fact_name] = fact_val

# Generated at 2022-06-11 05:22:41.235913
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''test_SshPubKeyFactCollector_collect(collect_subset=None)'''
    SshPubKeyFactCollector.collect(None)

# Generated at 2022-06-11 05:22:47.560972
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.settings import Settings

    SshPubKeyFactCollector.__bases__ = (object,)
    Settings._instance = Settings()
    Settings.get_setting('FACT_CACHE_TIMEOUT').value = 0
    facts = {}
    collector_obj = SshPubKeyFactCollector()
    result = collector_obj.collect(module=None, collected_facts=facts)
    assert result is not None
    assert isinstance(result, dict)

# Generated at 2022-06-11 05:22:52.731188
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    testobj = SshPubKeyFactCollector()

    # case1: collect tests with module_utils/facts/collector/ssh_pub_key.py
    # TODO: Need to implement this
    #caseobj = {}
    #assert testobj.collect(caseobj) == {}

    # case2: collect tests with module_utils/facts/collector/ssh_pub_key.py
    # TODO: Needs to implement this
    #caseobj = {}
    #assert testobj.collect(caseobj) == {}

# Generated at 2022-06-11 05:22:54.961686
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    assert collector.collect() == {}
    assert collector.collect(collected_facts=dict(foo='bar')) == {}

# Generated at 2022-06-11 05:23:04.144698
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    ssh_pub_key_facts = {}
    for algo in algos:
        factname = 'ssh_host_key_%s_public' % algo
        ssh_pub_key_facts[factname] = '%s' % algo
        ssh_pub_key_facts[factname + '_keytype'] = 'ssh-rsa'

    # mocks
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = mock.Mock(return_value=None)
    # save original function
    ansible_original_function = BaseFactCollector.__init__
    def ansible_mock_function(self, module):
        self.module = module
    BaseFactCollect

# Generated at 2022-06-11 05:23:13.931954
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import pytest
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import PropertyMock, patch
    import ansible_collections.ansible.community.plugins.module_utils.facts.collectors.ssh_pub_keys.SshPubKeyFactCollector as ssh_pub_key_collector

    class TestSshPubKeyFactCollector(unittest.TestCase):

        def setUp(self):
            self.tmp_dir = os.path.join(os.path.dirname(__file__), 'tmp')
            if not os.path.isdir(self.tmp_dir):
                os.makedirs(self.tmp_dir)


# Generated at 2022-06-11 05:23:23.372424
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:23:34.056700
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()

# Generated at 2022-06-11 05:23:48.853036
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # arrange
    files = ['/etc/ssh/ssh_host_rsa_key.pub', 
             '/etc/ssh/ssh_host_dsa_key.pub',
             '/etc/ssh/ssh_host_ecdsa_key.pub',
             '/etc/ssh/ssh_host_ed25519_key.pub']

# Generated at 2022-06-11 05:23:55.731415
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = type('', (), {})()

    # Return all keys
    SshPubKeyFactCollector.collect(module)

    # Return only the existing keys, test condition:
    # ssh_pub_key_facts = {}
    # if factname in ssh_pub_key_facts:
    #     # a previous keydir was already successful, stop looking for keys
    #     return ssh_pub_key_facts
    # key_filename = '%s/ssh_host_%s_key.pub' % (keydir, algo)
    # keydata = get_file_content(key_filename)
    # if keydata is not None:
    #     (keytype, key) = keydata.split()[0:2]
    #     ssh_pub_key_facts[factname] = key
    #     ssh_pub

# Generated at 2022-06-11 05:24:06.422876
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import default_collectors

    facts_dict = {}
    facts_collector = FactsCollector(default_collectors, facts_dict)
    facts_dict['ssh_pub_key_facts'] = SshPubKeyFactCollector(facts_collector).collect()

    #
    # Test if expected keys are discovered, with expected values
    #

    # Test if the rsa public key is in the list of keys
    assert 'ssh_host_key_rsa_public' in facts_dict['ssh_pub_key_facts']

    # Test if the rsa key value is correct

# Generated at 2022-06-11 05:24:09.445821
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    
    test_collector = SshPubKeyFactCollector()
    facts = test_collector.collect()
    
    assert len(facts) > 0
    assert isinstance(facts, dict)

# Generated at 2022-06-11 05:24:11.957387
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.collect() == {}

# Generated at 2022-06-11 05:24:14.093464
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    assert isinstance(ssh_pub_key_facts, dict)

# Generated at 2022-06-11 05:24:18.087258
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    input_facts = {'_ansible_cmdline': {'chdir': '/home/stack/tripleo-quickstart'}}

    module = Mock(params={'ssh_key_data': 'some data'})
    c = SshPubKeyFactCollector()
    c.collect(module, input_facts)

# Generated at 2022-06-11 05:24:27.885858
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    import glob
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import collector

    # creating a dummy instance of collector
    test_collector = Collector()
    # set of dummy facts to be collected by the collector
    test_collector.fact_list = ['ssh_pub_keys']
    # creating a dummy instance of SshPubKeyFactCollector and adding them to
    # the collector instance
    test_collector.add_collector(SshPubKeyFactCollector())
    # dummy facts_dict
    facts_dict = {}
    # run the collect method of the collector
    test_collector.collect(module=None, collected_facts=facts_dict)
    # assert if a fact is present in the collected facts

# Generated at 2022-06-11 05:24:29.320617
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    c = SshPubKeyFactCollector()
    c.collect()

# Generated at 2022-06-11 05:24:39.917221
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes

    # NOTE: the file contents are hardcoded in the test, to create a
    # representative results.
    # The actual result on a machine may be different.
    # The test compares the actual data only.

# Generated at 2022-06-11 05:24:55.403101
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    keytest1 = 'ssh-rsa somekey user@host'
    keytest2 = 'ssh-ecdsa anotherkey user@host'
    keytest3 = 'ssh-ed25519 yetanotherkey user@host'
    keytest4 = 'ssh-dss ssh-dss-key user@host'
    keytest5 = 'ssh-dsa ssh-dsa-key user@host'
    ssh_pub_key_facts = {}
    import os

    # make a temporary directory to put keys in
    from tempfile import mkdtemp
    os.environ['ANSIBLE_LOCAL_TMP'] = key_dir = mkdtemp()


# Generated at 2022-06-11 05:25:04.531543
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance

    fact_collector = get_collector_instance('SshPubKeyFactCollector')
    # Test for collection of facts
    result = fact_collector.collect(module=None, collected_facts=None)
    assert result.get('ssh_host_key_dsa_public') == 'dsa-key-20100101'
    assert result.get('ssh_host_key_rsa_public') == 'rsa-key-20100101'
    assert result.get('ssh_host_key_ecdsa_public') == 'ecdsa-key-20100101'
    assert result.get('ssh_host_key_ed25519_public') == 'ed25519-key-20100101'

# Generated at 2022-06-11 05:25:07.335380
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''
    Unit test for method collect of class SshPubKeyFactCollector
    This method is a (very) simple proxy to AnsibleModule's get_file_content method
    so no specific unit test is required
    '''
    pass

# Generated at 2022-06-11 05:25:08.749731
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector = SshPubKeyFactCollector()
    assert fact_collector.collect() == {}

# Generated at 2022-06-11 05:25:13.549439
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # init class
    ssh_pub_key_module = SshPubKeyFactCollector()
    # set path of fake files

# Generated at 2022-06-11 05:25:22.822254
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts_path = '/tmp/ssh_pub_key_facts_data.txt'

# Generated at 2022-06-11 05:25:32.766543
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_lines

    # mock module, the module object is not used
    ansible_module = {}

    # Empty list
    assert get_file_lines('/path/does/not/exist') is None

    # Empty file (lines=None)
    # [TODO]
    # assert get_file_lines('') is None

    # Wrong file (lines=None)
    # [TODO]
    # assert get_file_lines('') is None

    collector = SshPubKeyFactCollector(ansible_module)
    facts_collected = collector.collect()

    # result is expected to be a dict
    assert isinstance(facts_collected, dict)

    # at least one fact is expected to be collected

# Generated at 2022-06-11 05:25:43.210599
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes

    module_mock = None
    collected_facts_mock = None
    key_filename_mock = '/tmp/mock_key'


# Generated at 2022-06-11 05:25:46.904175
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = FakeModule()
    collected_facts = {}
    SshPubKeyFactCollector.collect(module, collected_facts)
    assert collected_facts['ssh_host_pub_keys'] == 'list of public ssh keys'


# Generated at 2022-06-11 05:25:55.988291
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # create mock module
    mock_module = Mock()

    # create mock collected_facts
    mock_collected_facts = {
            'ssh_host_key_rsa_public': 'ssh-rsa 12345 rsa-key-20160523',
            'ssh_host_key_ecdsa_public': 'ecdsa-sha2-nistp256 12345 ecdsa-key-20160523',
            'ssh_host_key_ed25519_public': 'ssh-ed25519 12345 ed25519-key-20160523'
    }

    # create instance of SshPubKeyFactCollector
    ssh_pub_key_fact_collector = SshPubKeyFactCollector(mock_module)

    # invoke method collect of SshPubKeyFactCollector instance
    collected_facts = ssh_pub

# Generated at 2022-06-11 05:26:12.537947
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create a fake module with associated data
    module = AnsibleModule(
        argument_spec = dict(
        ),
        supports_check_mode = True
    )

    # create a fake module with associated data
    module = None

    # create a fake collector
    collector = SshPubKeyFactCollector(module=module)

    # generate ssh pub key facts
    ssh_pub_key_facts = collector.collect()

    # at least ssh_host_key_rsa_public_keytype should exist
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts.keys()

# Generated at 2022-06-11 05:26:21.778358
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create fake module
    module = type('module', (object,), {'_unit_test': True})()

    # Call the method collect without fake collected facts
    result = SshPubKeyFactCollector().collect(module=module)

    # Check the result

# Generated at 2022-06-11 05:26:30.194786
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    import textwrap
    import shutil


# Generated at 2022-06-11 05:26:39.570784
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:26:40.819311
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass
    # Have to write the unit tests for the new fact collector method

# Generated at 2022-06-11 05:26:46.907461
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_collector = SshPubKeyFactCollector()

    fact_value = ssh_pub_key_collector.collect()
    assert fact_value['ssh_host_key_dsa_public'] is not None
    assert fact_value['ssh_host_key_rsa_public'] is not None
    assert fact_value['ssh_host_key_ecdsa_public'] is not None
    assert fact_value['ssh_host_key_ed25519_public'] is not None

# Generated at 2022-06-11 05:26:57.552383
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import platform
    import tempfile
    import os
    import os.path
    import shutil

    tmpdir = os.path.join(tempfile.gettempdir(), "test_ansible_ssh_pub_keys")
    ssh_host_key_rsa_public_keytype = 'ssh-rsa'
    ssh_host_key_ecdsa_public_keytype = 'ssh-ecdsa'
    ssh_host_key_ed25519_public_keytype = 'ssh-ed25519'

# Generated at 2022-06-11 05:26:59.182804
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # create test object
    test_obj = SshPubKeyFactCollector()

    # return value should be a dict
    assert isinstance(test_obj.collect(), dict)

# Generated at 2022-06-11 05:27:08.116775
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    collector = SshPubKeyFactCollector()
    facts_dict = {}
    facts_dict['ssh_host_pub_keys'] = ['ssh_host_rsa_key.pub', 'ssh_host_dsa_key.pub', 'ssh_host_ecdsa_key.pub',
                                       'ssh_host_ed25519_key.pub']

# Generated at 2022-06-11 05:27:08.713516
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-11 05:27:37.087853
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = type('', (), {'params': {'gather_subset': ''}})
    # When no ssh key files exists
    module.params['gather_subset'] = '!all'
    collected_facts = {}
    result = SshPubKeyFactCollector().collect(module=module, collected_facts=collected_facts)
    assert result == collected_facts
    # When some ssh key files exists

# Generated at 2022-06-11 05:27:45.887854
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # given
    ssh_pub_key_facts = {}
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')

    # list of directories to check for ssh keys
    # used in the order listed here, the first one with keys is used
    keydirs = ['/etc/ssh', '/etc/openssh', '/etc']

    for keydir in keydirs:
        for algo in algos:
            factname = 'ssh_host_key_%s_public' % algo
            if factname in ssh_pub_key_facts:
                # a previous keydir was already successful, stop looking
                # for keys
                return ssh_pub_key_facts
            key_filename = '%s/ssh_host_%s_key.pub' % (keydir, algo)


# Generated at 2022-06-11 05:27:54.953332
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # pylint: disable=protected-access
    import os

    # Create temporary files for testing

# Generated at 2022-06-11 05:28:04.766686
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Use a mock module to return the first key found
    import mock

# Generated at 2022-06-11 05:28:11.717020
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:28:16.173856
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Unit test for method collect of class SshPubKeyFactCollector"""

    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public_keytype' in ssh_pub_key_facts

# Generated at 2022-06-11 05:28:24.660557
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """ Test that ssh_host_pub_keys is successfully collected"""

    # Test data

# Generated at 2022-06-11 05:28:33.728346
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()

# Generated at 2022-06-11 05:28:37.632609
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    assert collector.collect() == {'ssh_host_key_ed25519_public': 'AAAAC3NzaC1lZDI1NTE5AAAAIJQ2w+uC7hThOxRi0C0bX9Dph+lPmGkMHPm+1W8tFpw5'}

# Generated at 2022-06-11 05:28:42.925767
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Creating a mock class with a mock return value for the method collect()
    class Mock(object):
        @classmethod
        def collect(cls, module=None, collected_facts=None):
            return collected_facts
    # Overriding the collect method of SshPubKeyFactCollector with the mock
    SshPubKeyFactCollector.collect = Mock.collect
    # Asserting that the method return value equals the expected return value
    assert SshPubKeyFactCollector.collect() is None

# Generated at 2022-06-11 05:29:30.834191
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Test ssh_host_key facts are collected correctly."""
    # no keys found, no facts
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    assert not ssh_pub_key_facts

    # keys found, facts exist

# Generated at 2022-06-11 05:29:40.889942
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector = SshPubKeyFactCollector()
    collected_facts = {}

    # Test that when no keys are found, an empty dictionary is returned
    facts = fact_collector.collect(None, collected_facts)
    assert facts == {'ssh_host_pub_keys': {}}

    # Add some data
    collected_facts['ansible_local'] = {
        'ssh_host_key_ecdsa_public': 'ssh-ecdsa AAA...',
        'ssh_host_key_rsa_public': 'ssh-rsa AAA...',
        'ssh_host_key_ed25519_public': 'ssh-ed25519 AAA...'
    }

    # Test that the correct set of facts are returned
    facts = fact_collector.collect(None, collected_facts)
    assert facts == collected_

# Generated at 2022-06-11 05:29:50.299149
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.utils import AnsibleFactCollector

    # mock ansible module
    module = MockModule()

    # create the object to test
    fact_collector = SshPubKeyFactCollector()

    # run the code to test
    facts = AnsibleFactCollector(module, collectors=[fact_collector]).collect()

    # check the expected vs actual results

# Generated at 2022-06-11 05:29:58.488015
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    import mock
    from ansible.module_utils.facts.utils import get_file_content


# Generated at 2022-06-11 05:30:08.734947
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = {}
    ssh_pub_key_facts['ssh_host_key_dsa_public'] = 'dsa:ABC:ABC:ABC+123'
    ssh_pub_key_facts['ssh_host_key_rsa_public'] = 'rsa:ABC:ABC:ABC+123'
    ssh_pub_key_facts['ssh_host_key_ecdsa_public'] = 'ecdsa:ABC:ABC:ABC+123'
    ssh_pub_key_facts['ssh_host_key_ed25519_public'] = 'ed25519:ABC:ABC:ABC+123'
    ssh_pub_key_facts['ssh_host_key_dsa_public_keytype'] = 'dsa'

# Generated at 2022-06-11 05:30:14.567369
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import collect_subset

    ssh_pub_key_collector = SshPubKeyFactCollector()
    ssh_pub_key_collector.collect()
    facts = Facts('all', {}, {}, ssh_pub_key_collector)
    collected_facts = collect_subset(ssh_pub_key_collector, facts, ['!filters', 'ssh_pub_keys'])
    assert collected_facts['ssh_pub_keys'] != {}

# Generated at 2022-06-11 05:30:20.442795
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    ssh_pub_key_facts = SshPubKeyFactCollector().collect()

    assert isinstance(ssh_pub_key_facts['ssh_host_key_rsa_public'], str)
    assert ssh_pub_key_facts['ssh_host_key_rsa_public'].startswith('ssh-rsa ')
    assert isinstance(ssh_pub_key_facts['ssh_host_key_rsa_public_keytype'], str)
    assert ssh_pub_key_facts['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa'

# Generated at 2022-06-11 05:30:27.843079
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.path = '/usr/bin:/bin:/usr/sbin:/sbin'

    fake_module = FakeModule()
    res = SshPubKeyFactCollector().collect(fake_module)
    assert isinstance(res, dict)
    assert 'ssh_host_key_dsa_public' in res
    assert 'ssh_host_key_rsa_public' in res
    assert 'ssh_host_key_ecdsa_public' in res
    assert 'ssh_host_key_ed25519_public' in res

# Generated at 2022-06-11 05:30:35.243030
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import mock
    import __main__ as ansible_module_main

    # mock module_utils/facts/utils/get_file_content
    mock_get_file_content = mock.MagicMock(name='get_file_content')

# Generated at 2022-06-11 05:30:37.954130
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    success = True
    keys = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    facts = SshPubKeyFactCollector().collect()
    for key in keys:
        factname = 'ssh_host_key_%s_public' % key
        if factname not in facts:
            success = False
    return success