

# Generated at 2022-06-11 05:20:58.005998
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    def _get_file_content(filename):
        data = None

# Generated at 2022-06-11 05:20:59.444003
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    keys = SshPubKeyFactCollector.collect()
    assert keys != None

# Generated at 2022-06-11 05:21:05.464822
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import get_collector_instance
    # First we make sure the correct class is instantiated
    assert isinstance(get_collector_instance('SshPubKeyFactCollector'), SshPubKeyFactCollector)
    # Now we check the return of the method collect
    assert get_collector_instance('SshPubKeyFactCollector').collect() == {}

# Generated at 2022-06-11 05:21:15.192275
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
    Unit test for method collect
    """

# Generated at 2022-06-11 05:21:25.822661
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # test setup
    import tempfile
    import os
    import shutil
    murmurhash_path = os.path.join(tempfile.mkdtemp(), 'ssh_host_murmurhash_key.pub')

# Generated at 2022-06-11 05:21:34.714277
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:21:44.840096
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:21:54.096164
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    ansible_facts = {'ansible_distribution': 'RedHat'}
    collected_facts = collector.collect(ansible_facts)
    assert 'RedHat' in collected_facts
    assert 'ssh_host_key_dsa_public' in collected_facts['RedHat']
    assert 'ssh_host_key_rsa_public' in collected_facts['RedHat']
    assert 'ssh_host_key_ecdsa_public' in collected_facts['RedHat']
    assert 'ssh_host_key_ed25519_public' in collected_facts['RedHat']

# Generated at 2022-06-11 05:22:02.028528
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector = SshPubKeyFactCollector()
    assert fact_collector.collect() == {'ssh_host_key_dsa_public': 'ssh-dss',
                                        'ssh_host_key_dsa_public_keytype': None,
                                        'ssh_host_key_ecdsa_public': None,
                                        'ssh_host_key_ecdsa_public_keytype': None,
                                        'ssh_host_key_ed25519_public': None,
                                        'ssh_host_key_ed25519_public_keytype': None,
                                        'ssh_host_key_rsa_public': 'ssh-rsa',
                                        'ssh_host_key_rsa_public_keytype': None}

# Generated at 2022-06-11 05:22:13.204768
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os

    # Create a temp directory to write test keys
    tempdir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'ssh_test_keys')
    os.mkdir(tempdir)

    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    for algo in algos:
        keyfile = os.path.join(tempdir, 'ssh_host_%s_key.pub' % algo)

# Generated at 2022-06-11 05:22:24.831472
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts, \
        "Failed to get ssh_host_key_dsa_public"
    assert 'ssh_host_key_dsa_public_keytype' in ssh_pub_key_facts, \
        "Failed to get ssh_host_key_dsa_public_keytype"
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts, \
        "Failed to get ssh_host_key_rsa_public"

# Generated at 2022-06-11 05:22:33.521608
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = ['ssh_host_key_rsa_public_keytype',
                         'ssh_host_key_ecdsa_public',
                         'ssh_host_key_dsa_public',
                         'ssh_host_key_rsa_public',
                         'ssh_host_key_dsa_public_keytype',
                         'ssh_host_key_ecdsa_public_keytype']
    keydirs = ['/etc/ssh/', '/etc/openssh', '/etc']
    algos = ['dsa', 'rsa', 'ecdsa']

    factcollector = SshPubKeyFactCollector()
    ssh_pub_key_facts = factcollector.collect()

    for fact in ssh_pub_key_facts:
        assert fact in ssh_pub_key_facts

# Generated at 2022-06-11 05:22:43.669385
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import get_collector_instance

    # Create a fake ssh_host_ed25519_key.pub file with a matching keytype
    data = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIPoYzlLkSf36mrqUv+6Uxh6ALeH6UADQlF5hp5R+r6\n"
    fname = "test_ssh_host_ed25519_key.pub"
    with open(fname, 'w') as f:
        f.write(data);
    Collector._file_cache[fname] = data

    #

# Generated at 2022-06-11 05:22:52.698598
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
    Unit test for method collect of class SshPubKeyFactCollector
    """
    # Test for class SshPubKeyFactCollector
    ssh_pub_key_fc = SshPubKeyFactCollector()
    ssh_host_pub_keys = ssh_pub_key_fc.collect()

    assert 'ssh_host_key_dsa_public' in ssh_host_pub_keys
    assert 'ssh_host_key_dsa_public_keytype' in ssh_host_pub_keys
    assert 'ssh_host_key_rsa_public' in ssh_host_pub_keys
    assert 'ssh_host_key_rsa_public_keytype' in ssh_host_pub_keys
    assert 'ssh_host_key_ecdsa_public' in ssh_host_pub_keys

# Generated at 2022-06-11 05:23:01.544654
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:23:07.216513
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import get_collector_class

    FactCollector._instance = None

    collector = get_collector_class('ssh_pub_keys')(None)
    module = None
    collected_facts = {}
    facts = collector.collect(module, collected_facts)
    assert facts['ssh_pub_keys'] is not None

# Generated at 2022-06-11 05:23:16.562241
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os

    # old ssh_host_key_public files, assuming a typical path
    # /etc/ssh/ssh_host_x_key.pub

# Generated at 2022-06-11 05:23:26.172287
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    sshkeyfacts = SshPubKeyFactCollector.collect()
    assert isinstance(sshkeyfacts, dict)

# Generated at 2022-06-11 05:23:36.254637
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Test of method collect of class SshPubKeyFactCollector"""
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.ssh_pub_keys import SshPubKeyFactCollector

    testcase = dict()
    testcase['module'] = None
    testcase['collector'] = SshPubKeyFactCollector()

# Generated at 2022-06-11 05:23:47.068571
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    #
    # 1. Unit test for an empty ssh public keys directory
    #
    from ansible.module_utils.facts.collectors.ssh_pub_keys import SshPubKeyFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_text

    # Create the SUT.
    ssh_pub_keys_fact_collector = SshPubKeyFactCollector()

    # Get the keys with no keys present
    original_get_file_content = get_file_content
    def mock_get_file_content(filename, default=None):
        if filename.endswith('/etc/ssh/ssh_host_dsa_key.pub'):
            return None

# Generated at 2022-06-11 05:24:00.561798
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils._text import to_bytes

    # The SshPubKeyFactCollector needs an object of
    # class ansible.module_utils.facts.collector.Collector
    # to be passed to its constructor.
    # The only method that Collector expects is
    # get_file_content which returns the content of a file
    # as bytes.
    # This class mocks the above class and provides
    # the required method.
    class MockCollector(object):
        def __init__(self):
            self.file_content = {}


# Generated at 2022-06-11 05:24:11.298430
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    keydir = '/tmp'
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')

    ssh_pub_keys = {}

    for algo in algos:
        key_filename = '%s/ssh_host_%s_key.pub' % (keydir, algo)
        print("key_filename: " + key_filename)
        keydata = get_file_content(key_filename)
        if keydata is not None:
            (keytype, key) = keydata.split()[0:2]
            ssh_pub_keys[algo] = key

    print("pub_keys: " + str(ssh_pub_keys))

if __name__ == '__main__':
    test_SshPubKeyFactCollector_collect()

# Generated at 2022-06-11 05:24:20.427955
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:24:23.345573
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    facts_collected = dict(ansible_facts=dict())
    SshPubKeyFactCollector().collect(facts_collected)
    print('collected facts: %s' % facts_collected['ansible_facts'])


# Generated at 2022-06-11 05:24:24.513256
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    SshPubKeyFactCollector()

# Generated at 2022-06-11 05:24:35.648786
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector.ssh_pub_keys import SshPubKeyFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    import os


# Generated at 2022-06-11 05:24:44.341878
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    import unittest
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import patch


# Generated at 2022-06-11 05:24:48.490063
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()

    assert ssh_pub_key_facts != {}
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts

# Generated at 2022-06-11 05:24:57.876445
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    import shutil
    import stat

    # Setup a temporary directory to use
    tmp_dir = tempfile.mkdtemp()

    # Create a fake /etc/ssh directory
    etc_ssh_dir = os.path.join(tmp_dir, 'etc', 'ssh')
    os.makedirs(etc_ssh_dir)

    # Create a fake /etc/openssh directory
    etc_openssh_dir = os.path.join(tmp_dir, 'etc', 'openssh')
    os.makedirs(etc_openssh_dir)

    # Create a fake ssh_host_ed25519_key.pub file in the fake /etc/ssh directory

# Generated at 2022-06-11 05:25:02.360287
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_collector = SshPubKeyFactCollector()
    result = test_collector.collect(collected_facts={})

    print("SSH pub keys:", result)

    assert 'ssh_host_key_rsa_public' in result
    assert 'ssh_host_key_rsa_public_keytype' in result

# Generated at 2022-06-11 05:25:19.090298
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:25:28.940398
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:25:39.031998
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Set up a module to use for the test
    class AnsibleModuleFake(object):

        def __init__(self, params):
            self.params = params

        def fail_json(self, *args, **kwargs):
            msg = args[0]
            raise Exception(msg)

    module = AnsibleModuleFake({})

    # Set up a fake facts dict to contain a few mock facts
    facts = {
        'somefact': 'someval',
        'anotherfact': 'anotherval'
    }

    # Create an instance of SshPubKeyFactCollector
    sshpubkeyfactcollector = SshPubKeyFactCollector()

    # Invoke the collect method of SshPubKeyFactCollector by passing it the
    # AnsibleModuleFake and facts dict

# Generated at 2022-06-11 05:25:49.691059
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Test function for method collect
    """
    fact_collector = SshPubKeyFactCollector()
    result, _warnings = fact_collector.collect()

    assert type(result) is dict
    assert 'ssh_host_pub_keys' in result
    assert type(result['ssh_host_pub_keys']) is dict

    assert 'ssh_host_key_rsa_public' in result
    assert type(result['ssh_host_key_rsa_public']) is str

    assert 'ssh_host_key_rsa_public_keytype' in result
    assert type(result['ssh_host_key_rsa_public_keytype']) is str

    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')

# Generated at 2022-06-11 05:25:57.784851
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class FakeModule:
        pass
    ssh_pub_key_facts = SshPubKeyFactCollector().collect(module=FakeModule())
    assert ssh_pub_key_facts['ssh_host_key_dsa_public'].startswith('AAAAB3NzaC1kc3MAAACBAMe2OcX')
    assert ssh_pub_key_facts['ssh_host_key_dsa_public_keytype'] == 'ssh-dss'

    assert ssh_pub_key_facts['ssh_host_key_rsa_public'].startswith('AAAAB3NzaC1yc2EAAAADAQABAAABAQDn')
    assert ssh_pub_key_facts['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa'

    assert ssh_pub

# Generated at 2022-06-11 05:26:00.883968
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    result = ssh_pub_key_fact_collector.collect()
    assert 'ssh_host_key_dsa_public' in result

# Generated at 2022-06-11 05:26:10.536633
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import Collector
    import os

    # Set up test ssh dsa key files
    dsa_keydir = 'testsshdir/etc/ssh'
    dsa_keyfile = '%s/ssh_host_dsa_key.pub' % dsa_keydir

# Generated at 2022-06-11 05:26:19.600093
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Setup a MockModule object
    mockmodule = MockModule()

    # Setup a MockFile object for the required file /etc/ssh/ssh_host_rsa_key.pub
    mockfile1 = MockFile('/etc/ssh/ssh_host_rsa_key.pub',
                        b'rsa-key-20171018 AAAABBBBCCCCDDDDEEEEFFFFGGGGHHHHIIIIJJJJKKKKLLLLMMMMNNNNOOOOPPPPQQQQRRRRSSSSTTTTUUUUVVVVAAAABBBBCCCCDDDDEEEEFFFFGGGGHHHHIIIIJJJJKKKKLLLLMMMMNNNNOOOOPPPPQQQQRRRRSSSSTTTTUUUUVVVV\n')

    # Setup a MockFile object for the required file /etc/ssh/ssh_host_dsa_key.

# Generated at 2022-06-11 05:26:20.542612
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    SshPubKeyFactCollector.collect()

# Generated at 2022-06-11 05:26:29.308232
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector.collect()
    # verify that the dictionary is not empty
    assert ssh_pub_key_facts
    # verify that the dictionary contains keys ssh_host_key_*_public
    ssh_keys = [key for key in ssh_pub_key_facts.keys() if key[0:16] == 'ssh_host_key_']
    assert ssh_keys
    # verify that the ssh_host_pub_keys item exist and is a dictionary
    assert ssh_pub_key_facts['ssh_host_pub_keys'] is not None
    for key in ssh_keys:
        # verify that the ssh_host_pub_keys dictionary contains all the keys
        assert key in ssh_pub_key_facts['ssh_host_pub_keys']
        # verify that the ssh_host_

# Generated at 2022-06-11 05:26:51.452544
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    collected_facts = collector.collect()
    expected_facts_keys = ['ssh_host_key_rsa_public', 'ssh_host_key_rsa_public_keytype', 'ssh_host_key_dsa_public', 'ssh_host_key_dsa_public_keytype']
    for key in expected_facts_keys:
        assert key in collected_facts

# Generated at 2022-06-11 05:27:00.088743
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    tmpdir = tempfile.mkdtemp()
    expected_facts = {}

    # create some temporary ssh host key files for testing
    for algo in ('dsa', 'rsa', 'ecdsa', 'ed25519'):
        tmpfile = os.path.join(tmpdir, 'ssh_host_%s_key.pub' % algo)
        keytype = 'ssh-%s' % algo
        key = 'AAAAB3NzaC1%sAAAA' % algo.upper()
        content = '%s %s foo' % (keytype, key)
        with open(tmpfile, 'w') as f:
            f.write(content)

        expected_facts['ssh_host_key_%s_public' % algo] = key

# Generated at 2022-06-11 05:27:09.247400
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Arrange
    from ansible.module_utils.facts.utils import AnsibleFactsCollector
    from ansible.module_utils.facts.collectors.file.ssh_pub_key import SshPubKeyFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # no keys in any directory
    def mock_get_file_content(*args, **kwargs):
        return None

    # one key in each directory

# Generated at 2022-06-11 05:27:18.315217
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import pytest
    import re

    instance = SshPubKeyFactCollector()
    assert instance.name == 'ssh_pub_keys'
    assert instance._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])
    assert instance.collect() == {}

    from ansible.module_utils._text import to_bytes
    # unit test for first keydir with keys
    # assume ssh_host_ed25519_key.pub is present in /etc/ssh
    # (check if ssh-keygen is installed on the target system)

# Generated at 2022-06-11 05:27:23.994103
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import (
        Collector as _Collector
    )
    pubkey_fact = SshPubKeyFactCollector()

    def stub_collect():
        """Return empty list of facts"""
        return {}

    try:
        _Collector.collect = stub_collect
        collected_facts = pubkey_fact.collect()
    except Exception as ex:
        collected_facts = {}
        print(ex)

    return collected_facts

# vim: expandtab:tabstop=4:shiftwidth=4

# Generated at 2022-06-11 05:27:26.585951
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    collected_facts = ssh_pub_key_fact_collector.collect()

    assert collected_facts.get('ssh_host_pub_keys', None) is not None

# Generated at 2022-06-11 05:27:29.954279
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector_sshpubkey = SshPubKeyFactCollector()
    collector_sshpubkey_facts = collector_sshpubkey.collect()
    assert(set(collector_sshpubkey.fact_ids()) == set(collector_sshpubkey_facts.keys()))


# Generated at 2022-06-11 05:27:36.677757
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    gfc = SshPubKeyFactCollector()
    for algo in ('dsa', 'rsa', 'ecdsa', 'ed25519'):
        factname = 'ssh_host_key_%s_public' % algo
        fact_value = gfc.collect()
        if factname in fact_value:
            assert "RSA" in fact_value[factname]
        else:
            assert "RSA"
            # else to raise exception if rsa was not found
    # Unit test for default behavior of method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:27:45.507324
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # Create a mock `module` for the function `get_file_content`
    class MockModule:
        class MockParams:
            def __init__(self):
                self.get = lambda x: None
        def __init__(self):
            self.params = MockModule.MockParams()

    # Create object of class `SshPubKeyFactCollector`
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # Test case where no ssh public keys are found
    assert ssh_pub_key_fact_collector.collect(MockModule()) == {}

    # Test case where all the ssh public keys are found

# Generated at 2022-06-11 05:27:54.584718
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:28:36.667116
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector.collect()

# Generated at 2022-06-11 05:28:41.460695
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh = SshPubKeyFactCollector()
    facts = ssh.collect()

    print(facts)
    assert 'ssh_host_key_rsa_public' in facts
    assert 'ssh_host_key_dsa_public' in facts
    assert 'ssh_host_key_ecdsa_public' in facts
    assert 'ssh_host_key_ed25519_public' in facts

# Generated at 2022-06-11 05:28:48.502124
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()

    # check the functionality of get_file_content in module_utils/facts
    # since we read the files from default directories, this should work
    # on all OSes we have ssh_host_key_*_public facts for (centos6, centos7, dell6, dell7,
    # ubuntu1204, ubuntu1404, ubuntu1604, ubuntu1804, freebsd10, openbsd5, opensuse13)
    assert ssh_pub_key_facts['ssh_host_key_rsa_public'] is not None

# Generated at 2022-06-11 05:28:54.862320
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    Collector._instance = None
    collector = Collector()

    # check that a Collector instance failed to create a collector
    # for unknown fact name
    assert collector.get_collector('foo') is None

    # check that a Collector instance can create a proper
    # collector for a known fact name
    assert collector.get_collector('ssh_pub_keys')

    # check that collect method of the created collector
    # indeed returns proper values
    assert collector.get_collector('ssh_pub_keys').collect() is not None

# Generated at 2022-06-11 05:29:04.957241
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
    Unit test for method collect of class SshPubKeyFactCollector

    """
    test_collector = SshPubKeyFactCollector()

    # test lsb distribution facts
    facts_dict = test_collector.collect()
    assert 'ssh_host_key_rsa_public' in facts_dict
    assert facts_dict['ssh_host_key_rsa_public'] == 'AAA'
    assert 'ssh_host_key_rsa_public_keytype' in facts_dict
    assert facts_dict['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa'
    assert 'ssh_host_key_dsa_public' in facts_dict
    assert facts_dict['ssh_host_key_dsa_public'] == 'BBB'

# Generated at 2022-06-11 05:29:13.962610
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import facts_d
    import fileinput
    if 'ssh_pub_keys' not in facts_d['ansible_local']:
        print('ssh_pub_keys not present in local facts. Cannot perform test.')
        return
    print('Testing class SshPubKeyFactCollector method collect')
    print('Tested class: %s' % SshPubKeyFactCollector.name)
    print('Tested method: %s' % SshPubKeyFactCollector.collect.__name__)
    collector = SshPubKeyFactCollector('/etc/ansible')
    collected_facts = {}
    result = collector.collect(collected_facts)
    assert('ssh_host_pub_keys' not in result)
    contents = {}

# Generated at 2022-06-11 05:29:23.410996
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:29:26.814172
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = collector.collect()
    for key in ssh_pub_key_facts.keys():
        assert isinstance(key, str)
        assert isinstance(ssh_pub_key_facts[key], str)

# Generated at 2022-06-11 05:29:36.179138
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:29:46.361929
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
