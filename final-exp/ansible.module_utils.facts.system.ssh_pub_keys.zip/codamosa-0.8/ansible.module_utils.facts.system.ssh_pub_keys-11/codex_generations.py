

# Generated at 2022-06-11 05:20:56.472529
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    print("Testing method 'collect' of class 'SshPubKeyFactCollector'")

    # Create a new class instance
    sshPubKeyFactCollector = SshPubKeyFactCollector()

    # Create a module
    module = { }

    # Create a collected_facts
    collected_facts = { }

    # Call the method collect of class SshPubKeyFactCollector
    ansible_ssh_pub_keys = sshPubKeyFactCollector.collect(module, collected_facts)

    # Check if we have the result
    assert ('ssh_host_key_rsa_public' in ansible_ssh_pub_keys)


# Generated at 2022-06-11 05:21:05.319112
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect({}, {})
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_facts
    expected_len = 4
    actual_len = len(ssh_pub_key_facts.keys())
    assert expected_len == actual_len

# Generated at 2022-06-11 05:21:15.039320
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class mock_module():
        def __init__(self, facts):
            self.facts = facts

    class mock_collector():
        def __init__(self, facts):
            self.module = mock_module(facts)

    keydirs = ['/etc/ssh', '/etc/openssh', '/etc']

    # Test: No keys found
    collected_facts = {'ssh_host_key_dsa_public': '',
                       'ssh_host_key_rsa_public': '',
                       'ssh_host_key_ecdsa_public': '',
                       'ssh_host_key_ed25519_public': ''}
    collector = mock_collector(collected_facts)
    assert SshPubKeyFactCollector().collect(collector) == {}

    # Test: All keys found in first directory


# Generated at 2022-06-11 05:21:18.827324
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    mock_module = object()
    mock_facts = {'ssh_host_dsa_key_public': 'mock_key',
                  'ssh_host_rsa_key_public': 'mock_key'}
    fc = SshPubKeyFactCollector()
    facts = fc.collect(mock_module, mock_facts)
    assert isinstance(facts, dict)
    assert facts == {}

# Generated at 2022-06-11 05:21:30.155499
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # SshPubKeyFactCollector.collect():
    # We have no control over the contents of /etc/ssh and we don't want to
    # create files there. So we will create a fake etc dir, put a fake key
    # in it, and then have ansible look for that key.

    import tempfile


# Generated at 2022-06-11 05:21:39.718131
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import DefaultCollectors

    class MockModule(object):
        def __init__(self):
            self.params = {}

    class MockFacts(object):
        def __init__(self):
            self.facts = {}


# Generated at 2022-06-11 05:21:40.334106
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-11 05:21:51.051547
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """ Unit test for method collect of class SshPubKeyFactCollector"""
    module = None
    collected_facts = None
    # Setup test fixture with a empty ssh known_hosts file
    ssh_known_hosts_file = open('/tmp/ssh_known_hosts', 'w')
    ssh_known_hosts_file.close()
    # Run method collect to gather ssh_pub_key_facts
    ssh_pub_key_facts = SshPubKeyFactCollector.collect(
        module, collected_facts)
    assert('ssh_host_key_dsa_public' in ssh_pub_key_facts)
    assert('ssh_host_key_rsa_public' in ssh_pub_key_facts)
    assert('ssh_host_key_ecdsa_public' in ssh_pub_key_facts)

# Generated at 2022-06-11 05:21:53.766588
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    argspec = {
        "module": None,
        "collected_facts": None
    }
    SshPubKeyFactCollector.collect(**argspec)


# Generated at 2022-06-11 05:22:02.162253
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    collected_facts = collector.collect()
    assert (collected_facts['ssh_host_key_dsa_public_keytype'] == 'ssh-dss' or
            collected_facts['ssh_host_key_dsa_public_keytype'] == 'ssh-dss')
    assert (collected_facts['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa' or
            collected_facts['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa')

# Generated at 2022-06-11 05:22:15.677299
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:22:25.314036
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Given
    class mock_get_file_content():
        def __init__(self, out="ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAILU6+FmD6b8V7jq3qe+V2X9A6P8V7pOJr6UmsV6r/rTc cw"):
            self.out = out
        def __call__(self, key_filename):
            return self.out

    class mock_BaseFactCollector():
        def __init__(self):
            self.name = 'ssh_pub_keys'
            self._fact_ids = set()

    class mock_module():
        def __init__(self):
            self.params = {}
            self.fail_json = None

    # When
    value = mock

# Generated at 2022-06-11 05:22:34.187515
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_module = None
    test_collect_facts = None
    test_module_path = '/etc/ssh/ssh_host_ed25519_key.pub'
    test_content = 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAILzEjYgbQ/F/9XbB0P/h7sUoCg45Vjq3HZwcrV7qlb'
    test_SshPubKeyFactCollector = SshPubKeyFactCollector(test_module,
                                               test_collect_facts)

    class TestGetFileContent(object):
        def __init__(self, filename, content=None):
            self.filename = filename
            self.content = content

# Generated at 2022-06-11 05:22:40.895954
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    # only add SshPubKeyFactCollector to the list of collectors
    # so that its collect method is tested
    FactCollector._fact_collectors = [SshPubKeyFactCollector]

    # create the SshPubKeyFactCollector instance
    fc = SshPubKeyFactCollector()

    # call the collect method
    collected_facts = fc.collect()

    # check the content
    assert collected_facts != {}

# Generated at 2022-06-11 05:22:45.713580
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector.collect(None)
    assert isinstance(ssh_pub_key_facts, dict)
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts

# Generated at 2022-06-11 05:22:53.681021
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    #Create instance of class SshPubKeyFactCollector
    ssh_pub_key_obj = SshPubKeyFactCollector()

    #Create dictionary for ssh_pub_keys facts
    ssh_pub_keys_facts = {}

    #Create dictionary for expected result

# Generated at 2022-06-11 05:23:02.693353
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collected_facts = {}
    collected_facts['_ansible_no_log'] = False
    test_obj = SshPubKeyFactCollector()
    test_dict = test_obj.collect(collected_facts=collected_facts)
    assert 'ssh_host_key_rsa_public' in test_dict
    assert 'ssh_host_key_rsa_public_keytype' in test_dict
    assert 'ssh_host_key_dsa_public' in test_dict
    assert 'ssh_host_key_dsa_public_keytype' in test_dict
    assert 'ssh_host_key_ecdsa_public' in test_dict
    assert 'ssh_host_key_ecdsa_public_keytype' in test_dict
    assert 'ssh_host_key_ed25519_public'

# Generated at 2022-06-11 05:23:12.695220
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:23:22.025150
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Config
    config = Config()

    config.add_section('plugins')
    config.set('plugins', 'fact_cache', '')
    config.set('plugins', 'ssh_pub_keys', 'SshPubKeyFactCollector')

    from ansible.module_utils.facts import facts
    fact_list = facts._create_fact_list(config)

    ssh_pub_key_collector = None
    for collector in fact_list:
        if isinstance(collector, SshPubKeyFactCollector):
            ssh_pub_key_collector = collector
            break

    assert ssh_pub_key_collector is not None

    # test when there are no files in /etc/ssh

# Generated at 2022-06-11 05:23:32.956327
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector.collect()
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts
    assert 'ssh_host_key_dsa_public_keytype' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public_keytype' in ssh_pub_key_facts

# Generated at 2022-06-11 05:23:48.118096
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:23:48.692508
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-11 05:23:55.640362
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:24:06.279752
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class CollectedFacts(object):
        pass
    collected_facts = CollectedFacts()
    collecter = SshPubKeyFactCollector()
    fact_data = collecter.collect(collected_facts=collected_facts)
    
    assert fact_data['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa'

# Generated at 2022-06-11 05:24:16.718452
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils._text import to_bytes
    from _ast import Str

    fact_ids = set()
    fact_ids.add('ssh_host_pub_keys')
    fact_ids.add('ssh_host_key_dsa_public')
    fact_ids.add('ssh_host_key_rsa_public')
    fact_ids.add('ssh_host_key_ecdsa_public')
    fact_ids.add('ssh_host_key_ed25519_public')

    collector = get_collector_instance('SshPubKeyFactCollector')
    
    ssh_pub_key_facts = collector.collect()


# Generated at 2022-06-11 05:24:20.616997
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # test if ssh_pub_key_facts is empty when no ssh keys are in the filesystem
    ssh_pub_key_facts = SshPubKeyFactCollector.collect(None, None)
    assert len(ssh_pub_key_facts) == 0

    # TODO:
    # write test if ssh keys are in the filesystem
    # write test if only one algorithm of the keys is present

# Generated at 2022-06-11 05:24:30.719732
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = mock.Mock()
    module.get_bin_path.return_value = ''
    ssh_pub_key_facts = SshPubKeyFactCollector.collect(module)
    assert ssh_pub_key_facts['ssh_host_key_dsa_public'] == 'dsa-key-20180320'
    assert ssh_pub_key_facts['ssh_host_key_rsa_public'] == 'rsa-key-20180320'
    assert ssh_pub_key_facts['ssh_host_key_ecdsa_public'] == 'ecdsa-key-20180320'
    assert ssh_pub_key_facts['ssh_host_key_ed25519_public'] == 'ed25519-key-20180320'

# Generated at 2022-06-11 05:24:41.135135
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    collect = SshPubKeyFactCollector().collect

    class ModuleMock():
        pass

    module_mock = ModuleMock()

    # empty collected_facts
    collected_facts = {}
    assert collect(module_mock, collected_facts) == {}

    # ssh_host_dsa_public does not exist
    collected_facts = {'ssh_host_dsa_public': 'dsa key here'}
    assert collect(module_mock, collected_facts) == {'ssh_host_dsa_public': 'dsa key here'}

    # ssh_host_key_rsa_public does not exist
    collected_facts = {'ssh_host_key_rsa_public': 'rsa key here'}

# Generated at 2022-06-11 05:24:47.264907
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:24:48.107052
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
   pass

# Generated at 2022-06-11 05:25:05.574380
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import shutil
    import tempfile
    import unittest

    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class TestSshPubKeyFactCollector(unittest.TestCase):
        TEST_DIR = None

# Generated at 2022-06-11 05:25:10.931001
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.os_facts import OpenSshPubKeyFactCollector

    # Create a mock OpenSshPubKeyFactCollector
    ospkfc = OpenSshPubKeyFactCollector()
    ospkfc.collect = lambda: {'ssh_host_ed25519_public': 'mypubkey'}

    # Create a mock AnsibleFactCollector
    afc = AnsibleFactCollector()
    afc.collectors = [ospkfc]

    # Create SshPubKeyFactCollector
    spkfc = SshPubKeyFactCollector()

    # Test collect method
    result = spkfc.collect(collected_facts=afc.collect())

# Generated at 2022-06-11 05:25:12.065512
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    c = SshPubKeyFactCollector()
    c.collect()

# Generated at 2022-06-11 05:25:21.568026
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:25:25.193148
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Test method collect of class SshPubKeyFactCollector

    """

    module = AnsibleModule(argument_spec={})
    result = SshPubKeyFactCollector.collect(module)
    assert isinstance(result, dict)  # this method always returns a dict



# Generated at 2022-06-11 05:25:35.258948
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import fact_cache

    from ansible.module_utils.facts.collector import FactCollector


# Generated at 2022-06-11 05:25:45.919153
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import inspect
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # instantiate the SshPubKeyFactCollector object
    sshpubkeyfact = SshPubKeyFactCollector()
    # instantiate the Collector object with the SshPubKeyFactCollector object
    # as a parameter
    fact_collection = Collector(default_collectors=[sshpubkeyfact])

    # create the module object
    class FakeModule():
        def __init__(self, someparams):
            self.params=someparams

    fake_module = FakeModule({})

    # create the collected facts object
    collected_

# Generated at 2022-06-11 05:25:55.332758
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    class MockModule(object):
        pass

    module = MockModule()

    # collect should return a dict
    collector = SshPubKeyFactCollector(module)
    collected_facts = collector.collect()
    assert isinstance(collected_facts, dict)

    # test the empty case
    assert 'ssh_host_key_dsa_public' in collected_facts
    assert not collected_facts['ssh_host_key_dsa_public']
    assert 'ssh_host_key_rsa_public' in collected_facts
    assert not collected_facts['ssh_host_key_rsa_public']
    assert 'ssh_host_key_ecdsa_public' in collected_facts
    assert not collected_facts['ssh_host_key_ecdsa_public']

# Generated at 2022-06-11 05:26:05.147206
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
    Method collect of class SshPubKeyFactCollector(BaseFactCollector)
    """
    # Here, we create a SshPubKeyFactCollector object
    ssh_pub_key_collector = SshPubKeyFactCollector()
    # Then we define a dictionary where we want to store our facts
    collected_facts = {}
    # We call the method collect of our object ssh_pub_key_collector with
    # our empty dictionary
    ssh_pub_key_collector.collect(collected_facts=collected_facts)

    # ssh_pub_key_facts has been updated by the collect method
    ssh_pub_key_facts = ssh_pub_key_collector.collect()

    # Let's check that ssh_pub_key_facts is not empty
    assert ssh_pub_key_facts is not None



# Generated at 2022-06-11 05:26:14.472868
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.utils import ansible_collector

    # ansible_collector is a global variable in this file
    # save it to avoid interfering with other unit tests for the CollectorBase
    saved_ansible_collector = ansible_collector


# Generated at 2022-06-11 05:26:33.128014
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    c = SshPubKeyFactCollector()
    c.collect()

# Generated at 2022-06-11 05:26:38.703042
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Return a fact dict of ssh public keys."""
    collector = SshPubKeyFactCollector()
    facts = collector.collect(module=None, collected_facts=None)

    assert 'ssh_host_key_dsa_public' in facts
    assert 'ssh_host_key_rsa_public' in facts
    assert 'ssh_host_key_ecdsa_public' in facts
    assert 'ssh_host_key_ed25519_public' in facts

# Generated at 2022-06-11 05:26:48.375150
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # create an instance of the SshPubKeyFactCollector class with the required
    # arguments
    ssh_pub_key_fact_collector = SshPubKeyFactCollector({ 'include_ssh_host_pub_keys': True })

    # create some vars to populate collected_facts with
    collected_facts = { 'ssh_host_key_rsa_public': 'ssh-rsa some_key somedomain.com',
                        'ssh_host_key_ecdsa_public': 'ecdsa-sha2-nistp256 some_key somedomain.com' }

    # run the collect method of the instance and store the result 
    result = ssh_pub_key_fact_collector.collect(collected_facts=collected_facts)

    # verify the values returned by the ssh_pub_key_fact_collect

# Generated at 2022-06-11 05:26:58.416069
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:27:04.090809
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # UT requires a module in order to get access
    # to __ansible_module_nonlocal_context__
    module = None
    # The test case
    class TestCase():
        def runTest(self):
            collector = SshPubKeyFactCollector()
            # The following  calls are needed to initialize the collector
            # __ansible_module_nonlocal_context__
            module = collector.set_context(module=module)
            collector.collect(module=module)
            # Now we can test the collector
            self.assertEqual(collector._fact_ids, collector.fact_ids())
            # The dictionary of facts is what we want to check
            self.assertEqual(len(collector.collect(module=module)), 0)
    # Run the test
    testCase = TestCase()
    testCase.runTest

# Generated at 2022-06-11 05:27:12.363332
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    fact_keys = ssh_pub_key_facts.keys()
    fact_keys.sort()
    assert fact_keys == [
        'ssh_host_key_dsa_public',
        'ssh_host_key_dsa_public_keytype',
        'ssh_host_key_ecdsa_public',
        'ssh_host_key_ecdsa_public_keytype',
        'ssh_host_key_ed25519_public',
        'ssh_host_key_ed25519_public_keytype',
        'ssh_host_key_rsa_public',
        'ssh_host_key_rsa_public_keytype',
    ]

# Generated at 2022-06-11 05:27:21.737760
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # Create instance of class SshPubKeyFactCollector
    sshpubkeycollect = SshPubKeyFactCollector()

    # Create 'facts' dict
    facts = dict()

    # Unit test for method collect when ssh_host_key_dsa_public does
    # not exists
    def test_collect_when_ssh_host_key_dsa_public_does_not_exists():
        # Create 'module' obj
        module = dict()
        # Set 'base_dir' value to module
        module['base_dir'] = '/root'
        # Call method collect of class SshPubKeyFactCollector
        sshpubkeycollect.collect(module=module, collected_facts=facts)

    # Unit test for method collect when ssh_host_key_dsa_public exists

# Generated at 2022-06-11 05:27:24.165529
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    result = ssh_pub_key_collector.collect()

    assert result is not None

# Generated at 2022-06-11 05:27:29.572244
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Verifies the collect function of SshPubKeyFactCollector"""
    ssh = SshPubKeyFactCollector()
    facts = ssh.collect()

    # Verify that we got keys back
    assert facts['ssh_host_key_rsa_public'] is not None
    assert facts['ssh_host_key_dsa_public'] is not None
    assert facts['ssh_host_key_ecdsa_public'] is not None
    assert facts['ssh_host_key_ed25519_public'] is not None

# Generated at 2022-06-11 05:27:33.876730
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert SshPubKeyFactCollector().collect() == dict(ssh_host_key_ed25519_public='AAAAC3NzaC1lZDI1NTE5AAAAIB/4P/o0MCvYXW/z0I0l/1lUDm1v3HW0MP8Q5oKL5a5')

# Generated at 2022-06-11 05:28:07.235621
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-11 05:28:16.465382
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-11 05:28:25.042111
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:28:33.944796
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_module_class = type(BaseFactCollector)
    test_module = test_module_class()
    test_module.file_exists = lambda x: True

    test_module.get_file_content = lambda x: 'testkey'

    test_ssh_pub_key_facts = SshPubKeyFactCollector()

    ssh_pub_keys_facts = test_ssh_pub_key_facts.collect(module=test_module)

    assert ssh_pub_keys_facts['ssh_host_key_dsa_public'] == 'testkey'
    assert ssh_pub_keys_facts['ssh_host_key_rsa_public'] == 'testkey'
    assert ssh_pub_keys_facts['ssh_host_key_ecdsa_public'] == 'testkey'
    assert ssh_pub_keys_

# Generated at 2022-06-11 05:28:42.378834
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import pytest
    from ansible.module_utils.facts import FactCollector

    # Setup
    collector = FactCollector()
    SshPubKeyFactCollector(collector)
    module = {}
    SshPubKeyFactCollector.collect(module, {})

    import os
    # Assert #1
    assert os.path.exists('/etc/ssh/ssh_host_dsa_key.pub')
    assert os.path.exists('/etc/ssh/ssh_host_rsa_key.pub')
    assert os.path.exists('/etc/ssh/ssh_host_ecdsa_key.pub')
    assert os.path.exists('/etc/ssh/ssh_host_ed25519_key.pub')

    # Assert #2

# Generated at 2022-06-11 05:28:51.429896
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Unit test class SshPubKeyFactCollector.collect"""
    # pylint: disable=too-few-public-methods
    class ModuleDouble:
        def __init__(self, params={}):
            self.params = params
            self.check_mode = params.get('check_mode', False)
            self.fail_json = params.get('fail_json', False)

    module_collector = SshPubKeyFactCollector()
    module = ModuleDouble(params={'check_mode': False, 'fail_json': False})
    facts = {}
    expected_facts = {}

    # call with keys in directory /etc/ssh
    facts.update(module_collector.collect(module=module,
                                         collected_facts=facts))

# Generated at 2022-06-11 05:28:58.629391
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    # Create a SshPubKeyFactCollector instance
    spkf = SshPubKeyFactCollector()
    # Call collect on the instance
    ssh_pub_key_facts = spkf.collect()

    # Check result
    for algo in algos:
        factname = 'ssh_host_key_%s_public' % algo
        assert factname in ssh_pub_key_facts
        assert isinstance(ssh_pub_key_facts[factname], basestring)

# Generated at 2022-06-11 05:29:08.120148
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector.ssh_pub_keys import SshPubKeyFactCollector

    ssh_pub_key_fact_collector = SshPubKeyFactCollector(module=None)
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()

    assert ssh_pub_key_facts.keys()

    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts

    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public_keytype' in ssh_pub_key_facts


# Generated at 2022-06-11 05:29:17.154552
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:29:18.609356
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    facts = collector.collect()
    assert(facts == {})

# Generated at 2022-06-11 05:30:37.233913
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Dummy class for the module parameter
    class Module(object):
        pass
    # Dummy class for the collected_facts parameter
    class CollectedFacts(object):
        pass

    # Create the object by calling the constructor
    obj = SshPubKeyFactCollector()
    # Call the collect method
    result = obj.collect(Module(), CollectedFacts())
    assert 'ssh_host_key_dsa_public' in result


# Generated at 2022-06-11 05:30:44.475574
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fc = SshPubKeyFactCollector()

    # no value set
    facts = {}
    result = fc.collect(facts=facts)
    assert result == {}

    # values already set
    facts = {
        'ssh_host_key_rsa_public': '',
        'ssh_host_key_rsa_public_keytype': '',
        'ssh_host_key_ecdsa_public': '',
        'ssh_host_key_ecdsa_public_keytype': '',
        'ssh_host_key_ed25519_public': '',
        'ssh_host_key_ed25519_public_keytype': ''
    }
    result = fc.collect(facts=facts)
    assert result == {}

# Generated at 2022-06-11 05:30:47.137527
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Unit test: ssh_pub_key
    module = None
    facts = {}
    SshPubKeyFactCollector().collect(module=module,
                                     collected_facts=facts)
    assert 'ssh_host_pub_keys' in facts