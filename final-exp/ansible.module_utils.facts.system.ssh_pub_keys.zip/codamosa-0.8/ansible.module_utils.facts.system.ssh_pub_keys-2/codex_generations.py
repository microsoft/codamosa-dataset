

# Generated at 2022-06-11 05:20:46.790024
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    obj = SshPubKeyFactCollector()
    assert obj.collect() == {}

# Generated at 2022-06-11 05:20:56.348654
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible import constants
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    assert len(ssh_pub_key_facts) > 0

    if constants.IS_WINDOWS:
        import winrm

# Generated at 2022-06-11 05:21:07.140062
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector
    import mock
    import os

    class MockModule(object):
        def fail_json(self, *args, **kwargs):
            raise AssertionError(args, kwargs)

    class MockCollector(BaseFactCollector):
        _fact_ids = set()

    # create a mock module and collector object
    mocked_module = MockModule()
    mocked_collector = MockCollector()

    # invoke collect() method of class SshPubKeyFactCollector
    # with mocked-out values for imported modules

# Generated at 2022-06-11 05:21:13.278563
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Test case for SshPubKeyFactCollector.collect()"""

    # arrange
    mock = {}
    mock['module'] = None
    mock['collected_facts'] = None
    sshkey_collector = SshPubKeyFactCollector()

    # act
    collect = sshkey_collector.collect(mock)

    # assert
    assert collect is not None, "collect can't be None"
    assert len(collect) > 0, "collect can't be empty"

# Generated at 2022-06-11 05:21:14.980600
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # Create an instance of the class SshPubKeyFactCollector
    obj = SshPubKeyFactCollector()

    assert obj.collect() == None

# Generated at 2022-06-11 05:21:25.450617
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = None

# Generated at 2022-06-11 05:21:30.016781
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from types import GeneratorType
    
    module = FakeAnsibleModule()
    fact_collector = FactCollector(module)
    assert isinstance(fact_collector.collect(), GeneratorType), "collect() returns a Generator"

# Fake module class

# Generated at 2022-06-11 05:21:38.761951
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # create a fact collector
    fact_collector = SshPubKeyFactCollector()

    # create a module object and pass empty arguments
    module = {}

    # create a collected facts object and pass it to the collector along with
    # the module
    collected_facts = {}
    fact_collector.collect(module, collected_facts)

    # check that the facts in the collected facts object are correct
    assert len(collected_facts) > 0
    for algo in ('dsa', 'rsa', 'ecdsa', 'ed25519'):
        factname = 'ssh_host_key_%s_public' % algo
        assert collected_facts[factname] != None
        assert collected_facts[factname + '_keytype'] != None

# Generated at 2022-06-11 05:21:49.434967
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class MockModule(object):
        def __init__(self):
            self.params = {}

    class MockCollector(SshPubKeyFactCollector):
        def __init__(self):
            super(MockCollector, self).__init__()
            self.facts = {}


# Generated at 2022-06-11 05:21:59.221580
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import ansible.module_utils.facts.utils as facts_utils
    SshPubKeyFactCollector.FACT_UTILS_GET_FILE_CONTENT = facts_utils.get_file_content

    class TestModule:
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = '!all,!any,network,ssh_pub_keys'

    class TestCollector:
        def __init__(self):
            self.module = TestModule()

    collector = TestCollector()
    ssh_pub_key_facts = SshPubKeyFactCollector().collect(module=collector.module)

    assert ssh_pub_key_facts is not None
    assert 'ssh_host_key_dsa_public_keytype' in ssh_pub_key_facts


# Generated at 2022-06-11 05:22:12.492639
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Mock modules
    import ansible.module_utils.facts.collector
    class MockModule:
        def __init__(self):
            self.params = {}
    mod = MockModule()
    mod.params = {'gather_subset': 'all', 'gather_timeout': 10}
    mod.params['gather_subset'] = ['!min']

    # Mock facts
    collected_facts = {}

    # Mock method get_file_content from ansible.module_utils.facts.collector

# Generated at 2022-06-11 05:22:22.817200
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:22:30.384949
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:22:40.446137
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os.path

    import ansible.module_utils.facts.collectors.ssh_pub_keys as ssh_pub_keys

    class TestModule(object):
        def params(self):
            return {}


# Generated at 2022-06-11 05:22:44.139622
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    col = SshPubKeyFactCollector()

    facts = col.collect({'_ansible_sysroot': '/'})

    assert 'ssh_host_key_rsa_public_keytype' in facts

# Generated at 2022-06-11 05:22:53.040067
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test module used to mock the existence of ssh public keys which will be
    # used by this class
    class TestModule(object):
        def __init__(self, keydirs):
            self.keydirs = keydirs

        def get_bin_path(self, name, required=False, opt_dirs=None):
            return name

        def get_file_content(self, filename):
            keypath = '%s/%s' % (self.keydirs[self.index][0], filename)
            if self.keydirs[self.index][1] is None:
                return None
            for key in self.keydirs[self.index][1]:
                if key[0] == keypath:
                    return key[1]


# Generated at 2022-06-11 05:23:02.004873
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
    Test whether collect method of SshPubKeyFactCollector class produces
    the right output
    """
    keys = [ 'ssh-rsa 1111 ansible',
             'ssh-dsa 2222 ansibleapi',
             'ssh-ecdsa 3333 ansibleapi',
             'ssh-ed25519 4444 ansible']
    dir_keys = {'/etc/ssh': keys, '/etc/openssh': keys}
    fact_collector = SshPubKeyFactCollector()
    fact_collector._get_file_content = lambda x: dir_keys.get(x, None)

# Generated at 2022-06-11 05:23:12.063975
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class FakeModule():
        def __init__(self):
            self.params = []

    collector = SshPubKeyFactCollector()

    # Test empty base case
    assert collector.collect() == {}

    # Test standard case

# Generated at 2022-06-11 05:23:21.356588
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector.ssh_pub_key import SshPubKeyFactCollector
    # Test when ssh keys are in /etc/ssh
    keydir = '/tmp/test_ssh_pub_key_facts/etc/ssh'

# Generated at 2022-06-11 05:23:30.596006
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''Unit test for method collect of class SshPubKeyFactCollector'''
    algos = ['dsa', 'rsa', 'ecdsa', 'ed25519']
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()

    assert ssh_pub_key_facts is not None
    assert 'ssh_host_pub_keys' in ssh_pub_key_facts

    for algo in algos:
        factname = 'ssh_host_key_%s_public' % algo
        assert factname in ssh_pub_key_facts
        assert factname + '_keytype' in ssh_pub_key_facts

# Generated at 2022-06-11 05:23:45.674829
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector.ssh_pub_keys import (
        SshPubKeyFactCollector
    )
    import os

    # Dict of collected facts, to be returned by the collect method
    ssh_pub_key_facts = {}

    # Dict of collected module parameters, to be used by the collect method
    collected_facts = {'ssh_pub_key_facts': ssh_pub_key_facts}

    # Fake SSH public keys, to be picked up by the collect method,
    # when looking in the fake directory

# Generated at 2022-06-11 05:23:53.677763
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts import fact_cache
    from ansible.module_utils.facts.utils import get_file_content

    def mock_get_file_content(filename):
        return "ssh-rsa bla bla"

    module = AnsibleModuleMock()
    fact_cache.pop('ssh_host_key_rsa_public', None)
    FactCollector._collectors = []
    FactCollector.add_collector(ssh_pub_key.SshPubKeyFactCollector)
    get_file_content.side_effect = mock_get_file_content
    ssh_pub_key_facts = FactCollector(module).collect()

# Generated at 2022-06-11 05:23:54.588579
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    SshPubKeyFactCollector.collect()

# Generated at 2022-06-11 05:24:05.267422
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector = SshPubKeyFactCollector()

# Generated at 2022-06-11 05:24:09.054151
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ed25519_public_keytype' in ssh_pub_key_facts

# Generated at 2022-06-11 05:24:18.981479
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:24:26.167850
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    SshPubKeyFactCollector = SshPubKeyFactCollector()
    # empty dictionary
    collected_facts = {}
    # call collect method
    ansible_facts = SshPubKeyFactCollector.collect(collected_facts=collected_facts)
    # check if output is a dictionary
    assert isinstance(ansible_facts, dict)
    # check if output has a key
    assert 'ssh_host_ed25519_public' in ansible_facts
    # check if output has a value for a key
    assert ansible_facts['ssh_host_ed25519_public'] is not None

# Generated at 2022-06-11 05:24:37.279516
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test if no keys are found
    def mock_get_file_content(filename):
        return None

    collector = SshPubKeyFactCollector()
    assert collector.collect(get_file_content=mock_get_file_content) == {}

    # Test when keydir is successful
    keydir = '/etc/ssh'
    key_filename = '%s/ssh_host_%s_key.pub' % (keydir, 'rsa')

# Generated at 2022-06-11 05:24:45.286018
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import FactsCollector

    module = mock.Mock()

    # no keys found
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect(module=module)
    assert not ssh_pub_key_facts

    # has one set of keys
    mock_get_file_content = mock.Mock()
    mock_get_file_content.side_effect = [to_bytes('test-key-data')]
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

# Generated at 2022-06-11 05:24:56.341304
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """ Test module for SshPubKeyFactCollector._collect function """


# Generated at 2022-06-11 05:25:07.994645
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_obj = SshPubKeyFactCollector()
    result = test_obj.collect()
    assert isinstance(result, dict)
    assert isinstance(result, dict)
    assert 'ssh_host_key_ecdsa_public' in result


# Generated at 2022-06-11 05:25:09.656653
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = None
    fc = SshPubKeyFactCollector()
    fc.collect(module, collected_facts)

# Generated at 2022-06-11 05:25:18.624066
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_collector.collect()

    # check the presence of the facts
    assert ssh_pub_key_facts['ssh_host_key_rsa_public']
    assert ssh_pub_key_facts['ssh_host_key_rsa_public_keytype']
    assert ssh_pub_key_facts['ssh_host_key_dsa_public']
    assert ssh_pub_key_facts['ssh_host_key_dsa_public_keytype']
    assert ssh_pub_key_facts['ssh_host_key_ecdsa_public']
    assert ssh_pub_key_facts['ssh_host_key_ecdsa_public_keytype']
    assert ssh_pub_key

# Generated at 2022-06-11 05:25:28.377609
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector.ssh_pub_key import SshPubKeyFactCollector
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content
    import mock
    import os

    # define a dictionary with the output of a mock function

# Generated at 2022-06-11 05:25:38.405082
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os.path
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    import ansible.module_utils.facts.collectors.ssh_pub_key

    # create a temp directory with key files
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    keydirs = ('/etc/ssh', '/etc/openssh', '/etc')
    for keydir in keydirs:
        os.makedirs(os.path.join(tmpdir, keydir))

# Generated at 2022-06-11 05:25:49.232168
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import sys
    import __builtin__

    # Following is the fake implementation of open() so that we can mock
    # return value of open() as well as change open.called property.

    class FakeOpen(object):
        # faked called property
        called = False
        # faked return value for open()
        return_value = None

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.fileobj = "Some Fake File Obj"
            self.called = True

        def __call__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            return self.return_value


# Generated at 2022-06-11 05:25:57.526674
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    fake_module = None
    fake_collected_facts = None

    fake_keydir = '/etc/ssh'
    fake_dsakey_filename = '%s/ssh_host_dsa_key.pub' % fake_keydir
    fake_rsakey_filename = '%s/ssh_host_rsa_key.pub' % fake_keydir
    fake_ecdsakey_filename = '%s/ssh_host_ecdsa_key.pub' % fake_keydir
    fake_ed25519key_filename = '%s/ssh_host_ed25519_key.pub' % fake_keydir

    # returns tuple of (keytype, key) from the given keyfile data
    def get_keytype_and_key_from(filename):
        data = get_file_content(filename)


# Generated at 2022-06-11 05:26:07.382573
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    testhost = 'hostname'
    testdir = '/testdir'
    keydirs = [testdir]
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    pubkey_facts = dict()
    pubkey_facts[testhost] = dict()
    pubkey_facts[testhost]['ssh_host_pub_keys'] = dict()
    for keydir in keydirs:
        for algo in algos:
            key_filename = '%s/ssh_host_%s_key.pub' % (keydir, algo)
            with open(key_filename, 'r') as f:
                keydata = f.read()
                (keytype, key) = keydata.split()[0:2]
                ssh_host_key_public = key


# Generated at 2022-06-11 05:26:10.327413
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()

    print(ssh_pub_key_facts)

    assert isinstance(ssh_pub_key_facts, dict)

# Generated at 2022-06-11 05:26:19.404055
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import tempfile
    import os
    import stat

    filename_dsa = tempfile.mktemp()
    filename_rsa = tempfile.mktemp()
    filename_ecdsa = tempfile.mktemp()
    filename_ed25519 = tempfile.mktemp()
    filename_nonexistant = tempfile.mktemp()

# Generated at 2022-06-11 05:26:45.669266
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:26:56.565908
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os

    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.collector import get_collector_instance

    # test with valid keys in a directory
    mydir = os.path.join(os.path.dirname(__file__), 'fixtures', 'ssh_pubkey')
    os.environ['HOME'] = mydir
    assert os.environ['HOME'] == mydir
    key_fact_collector = get_collector_instance('SshPubKeyFactCollector')
    ansible_ssh_key_facts = key_fact_collector.collect()

# Generated at 2022-06-11 05:27:03.160128
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()

# Generated at 2022-06-11 05:27:12.167438
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create a SshPubKeyFactCollector instance
    sshPubKeyFactCollector = SshPubKeyFactCollector()

    # Assert that get_file_content mock was called with the correct parameters

# Generated at 2022-06-11 05:27:21.544984
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-11 05:27:29.186706
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert SshPubKeyFactCollector.collect() == {
        'ssh_host_key_ecdsa_public': '1',
        'ssh_host_key_ecdsa_public_keytype': '1',
        'ssh_host_key_ed25519_public': '2',
        'ssh_host_key_ed25519_public_keytype': '2',
        'ssh_host_key_rsa_public': '3',
        'ssh_host_key_rsa_public_keytype': '3',
        'ssh_host_key_dsa_public': '4',
        'ssh_host_key_dsa_public_keytype': '4'
    }

# Generated at 2022-06-11 05:27:38.385745
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from mock import patch


# Generated at 2022-06-11 05:27:47.167617
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    params = [['/etc/ssh'], ['/etc/openssh'], ['/etc']]
    testkeydirs = []


# Generated at 2022-06-11 05:27:56.413938
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # this mimics the input received by a module
    module_input_facts = {
        'kernel': 'Linux'
    }

    facts_collector = SshPubKeyFactCollector()
    collected = facts_collector.collect(None, module_input_facts)

    assert 'ssh_pub_keys' in collected

# Generated at 2022-06-11 05:28:06.024434
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    class TestModule(object):
        pass

    TestFacts = dict()

# Generated at 2022-06-11 05:28:46.860832
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # pylint: disable=protected-access
    collector = SshPubKeyFactCollector()
    assert collector.collect() == {}


# vim: set expandtab ts=4 sw=4

# Generated at 2022-06-11 05:28:55.600079
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance

    ssh_pub_key_instance = get_collector_instance('SshPubKeyFactCollector')
    ssh_pub_keys = ssh_pub_key_instance.collect()

    assert type(ssh_pub_keys) == dict
    assert 'ssh_host_key_rsa_public' in ssh_pub_keys
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_keys
    assert 'ssh_host_key_dsa_public' in ssh_pub_keys
    assert 'ssh_host_key_dsa_public_keytype' in ssh_pub_keys
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_keys

# Generated at 2022-06-11 05:28:58.430980
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    sshpubkeyfc = SshPubKeyFactCollector()
    sshpubkeyfcs = sshpubkeyfc.collect()
    assert isinstance(sshpubkeyfcs, dict)

# Generated at 2022-06-11 05:29:07.959627
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    expected_results = {
        'ssh_host_key_dsa_public': 'dsa-key-20120507',
        'ssh_host_key_dsa_public_keytype': 'ssh-dss',
        'ssh_host_key_rsa_public': 'rsa-key-20120507',
        'ssh_host_key_rsa_public_keytype': 'ssh-rsa',
        'ssh_host_key_ecdsa_public': 'ecdsa-key-20120507',
        'ssh_host_key_ecdsa_public_keytype': 'ecdsa-sha2-nistp256'
    }

    test_facts_collector = SshPubKeyFactCollector()
    results = test_facts_collector.collect(collected_facts=dict())

   

# Generated at 2022-06-11 05:29:12.804591
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    testobj = SshPubKeyFactCollector()
    result = testobj.collect()
    assert 'ssh_host_key_rsa_public' in result
    assert 'ssh_host_key_rsa_public_keytype' in result
    assert 'ssh_host_key_ecdsa_public' in result
    assert 'ssh_host_key_ecdsa_public_keytype' in result

# Generated at 2022-06-11 05:29:22.301814
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import collect
    from ansible.module_utils.facts.collectors.system import SshPubKeyFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes

    Collector.collectors['ssh_pub_keys'] = SshPubKeyFactCollector()

    orig_get_file_content = get_file_content

# Generated at 2022-06-11 05:29:31.468341
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    import os
    import tempfile

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import set_file_content

    # mock out ssh key files in an OS specific directory
    (fh, filename) = tempfile.mkstemp(prefix='ssh_host_key_', suffix='.pub')
    os.close(fh)
    os.unlink(filename)

# Generated at 2022-06-11 05:29:41.630931
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
    Unit tests for method collect
    """
    # pylint: disable=protected-access
    # pylint: disable=too-many-locals

    # Set up test object
    ssh_pub_key_collector = SshPubKeyFactCollector()

    # Set up method collect parameters
    # Parameter: module
    module = None
    # Parameter: collected_facts
    collected_facts = None

    # Set up module object
    # Return value of method get_file_content of class module
    get_file_content_return_value = None

    # Set up module parameters
    # Parameter: filename
    key_filename = 'whatever'

    # Create a side effect for method get_file_content of class module to
    # return a tuple of ('ssh-rsa', '1234whatever')

# Generated at 2022-06-11 05:29:42.246365
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-11 05:29:51.467624
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import cache
