

# Generated at 2022-06-25 00:44:18.704236
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

# Generated at 2022-06-25 00:44:25.948754
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()
    print(ssh_pub_key_facts)

if __name__ == '__main__':
    test_case_0()
    test_SshPubKeyFactCollector_collect()

# Generated at 2022-06-25 00:44:35.453086
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    fact_id_set_0 = set(['ssh_host_key_ed25519_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_dsa_public', 'ssh_host_pub_keys'])
    fact_set_0 = set(['ssh_host_key_ed25519_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_dsa_public', 'ssh_host_pub_keys'])


# Generated at 2022-06-25 00:44:44.042332
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:44:47.318928
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collection = SshPubKeyFactCollector.collect(None, {})
    assert collection != {}

# Generated at 2022-06-25 00:44:49.869431
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()

    assert set(ssh_pub_key_fact_collector_1.collect().keys()) == SshPubKeyFactCollector._fact_ids

# Generated at 2022-06-25 00:44:54.011226
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_collect = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_collect.collect()

# Unit test the function get_file_content

# Generated at 2022-06-25 00:44:57.578740
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''
    Unit test for collect method of class SshPubKeyFactCollector
    '''
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

# Test case for instance attribute _fact_class_name  of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:45:01.002030
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # no parameters for collect() for now
    ssh_pub_key_fact_collector.collect()

    return True

# Generated at 2022-06-25 00:45:07.164593
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_facts_1 = ssh_pub_key_fact_collector_1.collect()
    assert type(ssh_pub_key_facts_1) is dict
    assert len(ssh_pub_key_facts_1) >= 4

# Generated at 2022-06-25 00:45:17.622719
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ansible_module = {}
    ansible_module_facts_dict = {}
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect(ansible_module, ansible_module_facts_dict)
    assert isinstance(ssh_pub_key_facts, dict)
    assert 'ssh_host_pub_keys' in ssh_pub_key_facts
    assert isinstance(ssh_pub_key_facts['ssh_host_pub_keys'], list)

# Generated at 2022-06-25 00:45:27.972022
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    #
    #
    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    # {'ssh_host_pub_keys': '', 'ssh_host_key_rsa_public': '', 'ssh_host_key_ed25519_public': '', 'ssh_host_key_ecdsa_public': '', 'ssh_host_key_dsa_public': ''}

    #
    #
    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    ssh_pub_key_fact_collector_collect_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_collect_0.collect()



# Generated at 2022-06-25 00:45:37.130730
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:45:46.245298
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    #ssh_args = {'_ansible_syslog_facility': 'LOG_USER', '_ansible_verbosity': 0, '_ansible_version': '2.4.2.0', '_ansible_sftp_extra_args': '-f /dev/null', '_ansible_no_log': False, '_ansible_check_mode': False, '_ansible_module_name': 'setup', '_ansible_module_name': 'setup', '_ansible_module_name': 'setup', '_ansible_module_name': 'setup', '_ansible_module_name': 'setup', '_ansible_module_name': 'setup', '_ansible_module_name': 'setup',

# Generated at 2022-06-25 00:45:52.361945
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    res = ssh_pub_key_fact_collector.collect()


# Generated at 2022-06-25 00:45:55.078928
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    test_dict = {}
    assert ssh_pub_key_fact_collector_0.collect(test_dict) == {}


# Generated at 2022-06-25 00:45:58.520175
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    retvalue = ssh_pub_key_fact_collector_0.collect()
    assert not retvalue

# Generated at 2022-06-25 00:46:08.819284
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()
    assert ssh_pub_key_facts["ssh_host_key_ed25519_public_keytype"] == "ssh-ed25519"
    assert ssh_pub_key_facts["ssh_host_key_rsa_public_keytype"] == "ssh-rsa"
    assert ssh_pub_key_facts["ssh_host_key_ecdsa_public_keytype"] == "ecdsa-sha2-nistp256"
    assert ssh_pub_key_facts["ssh_host_key_dsa_public_keytype"] == "ssh-dss"

# Generated at 2022-06-25 00:46:14.125647
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    from ansible.module_utils.facts import FactCollector
    fact_collector_obj_0 = FactCollector()
    res = ssh_pub_key_fact_collector_0.collect(None, fact_collector_obj_0.collect(None))


# Generated at 2022-06-25 00:46:21.156904
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:46:30.440568
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

# Generated at 2022-06-25 00:46:37.365503
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

# Generated at 2022-06-25 00:46:45.596534
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()
    assert isinstance(ssh_pub_key_facts, dict)
    assert 'ssh_host_pub_keys' in ssh_pub_key_facts
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_dsa_public_keytype' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key

# Generated at 2022-06-25 00:46:48.906629
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:46:57.036489
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_facts_1 = ssh_pub_key_fact_collector_1.collect()
    assert isinstance(ssh_pub_key_facts_1, dict)
    for factname in ['ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public']:
        assert factname in ssh_pub_key_facts_1
        assert isinstance(ssh_pub_key_facts_1[factname], str)

# Generated at 2022-06-25 00:47:01.370341
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0._module = None
    ssh_pub_key_fact_collector_0._collected_facts = None
    ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:47:04.948401
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()
    assert ssh_pub_key_facts['ssh_host_key_dsa_public_keytype'] == 'ssh-dss'

# Generated at 2022-06-25 00:47:08.520994
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts_0 = ssh_pub_key_fact_collector_0.collect()
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts_0


# Generated at 2022-06-25 00:47:10.684172
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector_0.collect()
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_facts

# Generated at 2022-06-25 00:47:18.809998
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector._module = {}
    ssh_pub_key_fact_collector._module['executable'] = "/usr/bin/python"
    ssh_pub_key_fact_collector._module['os_family'] = "RedHat"
    ssh_pub_key_fact_collector._module['path'] = "/tmp:"
    ssh_pub_key_fact_collector._module['shell'] = "/bin/sh"
    ssh_pub_key_fact_collector._module['system'] = "Linux"

# Generated at 2022-06-25 00:47:44.191896
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_facts_1 = ssh_pub_key_fact_collector_1.collect()
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts_1
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts_1
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts_1
    assert 'ssh_host_key_dsa_public_keytype' in ssh_pub_key_facts_1
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts_1

# Generated at 2022-06-25 00:47:50.145806
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    res = ssh_pub_key_fact_collector_1.collect()
    assert res is not None
    assert 'ssh_host_key_dsa_public' in res
    assert 'ssh_host_key_rsa_public' in res
    assert 'ssh_host_key_ecdsa_public' in res
    assert 'ssh_host_key_ed25519_public' in res

# Generated at 2022-06-25 00:47:56.184263
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()


# Generated at 2022-06-25 00:47:58.752181
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_1.collect() == {}


# Generated at 2022-06-25 00:48:05.445349
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    keydir = '/etc/'
    algos = ['dsa', 'rsa', 'ecdsa', 'ed25519']
    for algo in algos:
        factname = 'ssh_host_key_%s_public' % algo
        key_filename = '%s/ssh_host_%s_key.pub' % (keydir, algo)
        keydata = get_file_content(key_filename)
        assert keydata is not None
        (keytype, key) = keydata.split()[0:2]
        assert factname in ssh_pub_key_facts
        assert factname + '_keytype' in ssh_pub_key_facts
        assert ssh_pub_key_facts[factname + '_keytype'] == keytype

# Generated at 2022-06-25 00:48:13.451543
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()

    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_dsa_public_keytype' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public_keytype' in ssh_pub_key_facts

# Generated at 2022-06-25 00:48:22.644661
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    # Unit test for the following method
    #       SshPubKeyFactCollector.collect(module, collected_facts=None)
    ###########################################################################
    # Unit test for the following method
    #       SshPubKeyFactCollector.collect(module, collected_facts=None)
    ###########################################################################
    # Test with a mocked class
    #    ModuleUtils.get_file_content

# Generated at 2022-06-25 00:48:29.089913
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ansible_module = AnsibleModule(
        argument_spec = dict()
    )
    ansible_module.params = {
    }
    result = ssh_pub_key_fact_collector_0.collect(ansible_module)
#    assert result['ansible_facts']['ssh_pub_keys'] == 'xx'


# Generated at 2022-06-25 00:48:36.116943
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # we should assert that name is equal to 'ssh_pub_keys'
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'

    # we should assert that len(ssh_pub_key_fact_collector_0._fact_ids) == 5
    assert len(ssh_pub_key_fact_collector_0._fact_ids) == 5

    # we should assert that 'ssh_host_pub_keys' in ssh_pub_key_fact_collector_0._fact_ids
    assert 'ssh_host_pub_keys' in ssh_pub_key_fact_collector_0._fact_ids

    # we should assert that 'ssh_host_key_dsa_public' in ssh_pub_key_fact_collector_0._fact_ids

# Generated at 2022-06-25 00:48:41.775069
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:24.568704
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    collected_facts = {}
    collected_facts = ssh_pub_key_fact_collector.collect(module=None, collected_facts=collected_facts)
    assert collected_facts == {}, 'ssh_host_key_ed25519_public' in collected_facts

# Generated at 2022-06-25 00:49:30.343478
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:32.318622
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    res = ssh_pub_key_fact_collector_0.collect()
    assert(len(res) > 0)


# Generated at 2022-06-25 00:49:36.072840
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Testing with empty result.
    ssh_pub_key_fact_collector_collect_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_collect_0.collect()


# Generated at 2022-06-25 00:49:40.196210
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # Test when no public keys are present
    assert ssh_pub_key_fact_collector.collect() == {}

    # The unit test framework doesn't have access to '/etc/ssh' so
    # it can't test when these values are present.

# Generated at 2022-06-25 00:49:45.925781
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0.collect()


if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-25 00:49:54.936716
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # Create a SshPubKeyFactCollector object
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()

    # Call method collect of SshPubKeyFactCollector object
    ssh_pub_key_facts = ssh_pub_key_fact_collector_1.collect()

    # Assert that required values are set
    for fact in ('ssh_host_key_rsa_public', 'ssh_host_key_rsa_public_keytype',
                 'ssh_host_key_ecdsa_public', 'ssh_host_key_ecdsa_public_keytype',
                 'ssh_host_key_ed25519_public', 'ssh_host_key_ed25519_public_keytype'):
        assert fact in ssh_pub_key_facts
        assert ssh_pub_

# Generated at 2022-06-25 00:49:57.262100
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector_0.collect()
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts

# Generated at 2022-06-25 00:49:59.886457
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts_0 = ssh_pub_key_fact_collector_0.collect()
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_facts_0
    assert 'ssh-ed25519' in ssh_pub_key_facts_0['ssh_host_key_ed25519_public']


test_cases_SshPubKeyFactCollector = [
    test_SshPubKeyFactCollector_collect]


# Generated at 2022-06-25 00:50:08.845141
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:51:41.008523
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector_0.collect()
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_facts

# Generated at 2022-06-25 00:51:47.390155
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()
    for key in ['ssh_host_key_dsa_public',
                'ssh_host_key_rsa_public',
                'ssh_host_key_ecdsa_public',
                'ssh_host_key_ed25519_public']:
        assert key in ssh_pub_key_facts

# Generated at 2022-06-25 00:51:53.756148
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    collected_facts = {}
    ssh_pub_key_facts = {}
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()
    assert 'ssh_host_key_dsa_public' not in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public' not in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public' not in ssh_pub_key_facts
    assert 'ssh_host_key_ed25519_public' not in ssh_pub_key_facts


# Generated at 2022-06-25 00:51:57.465387
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    collected_facts = dict()
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect(collected_facts)
    for fact in ssh_pub_key_fact_collector._fact_ids:
        assert fact in ssh_pub_key_facts
        assert isinstance(ssh_pub_key_facts.get(fact), str)

# Generated at 2022-06-25 00:52:01.429747
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_0.collect() == {'ssh_host_key_ed25519_public': 'AAAAC3NzaC1lZDI1NTE5AAAAIDGDmOjJ5+i9z8r6WZ5v5DYPEKMFAfgz8YMdO+vg2g0zC'}


# Generated at 2022-06-25 00:52:10.962858
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()


# Generated at 2022-06-25 00:52:13.256566
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()

    assert ssh_pub_key_facts is not None
    assert type(ssh_pub_key_facts) is dict

    # On a fresh OS install where no public keys are installed,
    # the dictionary returned from collect should be empty.
    assert len(ssh_pub_key_facts) == 0

# Generated at 2022-06-25 00:52:23.341247
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    result = ssh_pub_key_fact_collector_0.collect()
    assert type(result) == dict
    assert len(result) == 5
    assert 'ssh_host_pub_keys' in result

# Generated at 2022-06-25 00:52:32.978446
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

# Generated at 2022-06-25 00:52:37.989137
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect(module=None, collected_facts=None)
    assert type(ssh_pub_key_facts) == dict