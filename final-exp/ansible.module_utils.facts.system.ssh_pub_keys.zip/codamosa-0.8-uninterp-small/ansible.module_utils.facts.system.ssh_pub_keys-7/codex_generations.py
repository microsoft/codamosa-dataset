

# Generated at 2022-06-25 00:44:14.007540
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_keys_fact_collector = SshPubKeyFactCollector()
    collected_ssh_pub_keys = ssh_pub_keys_fact_collector.collect()
    assert isinstance(collected_ssh_pub_keys, dict)

# Generated at 2022-06-25 00:44:18.658173
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # AssertionError: TypeError('{} expected, got {}'.format(type(module), type(module)))
    pass


# Generated at 2022-06-25 00:44:28.538058
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    _SshPubKeyFactCollector__fact_ids = {'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public'}
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector._SshPubKeyFactCollector__fact_ids = _SshPubKeyFactCollector__fact_ids
    ssh_pub_key_fact_collector.collect()
    print('test_SshPubKeyFactCollector_collect: ' + 'success')

if __name__ == '__main__':
    #test_case_0()
    test_SshPubKeyFactCollector_collect()

# Generated at 2022-06-25 00:44:30.798588
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_facts_1 = ssh_pub_key_fact_collector_1.collect()
    assert isinstance(ssh_pub_key_facts_1, dict)
    assert set(ssh_pub_key_facts_1.keys()) == SshPubKeyFactCollector._fact_ids

# Generated at 2022-06-25 00:44:40.227302
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test Setup - Create a SshPubKeyFactCollector instance
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

    # Test Setup - Create a dummy module with an empty params
    module_0 = DummyModule(params={})

    # Test Setup - Create a empty facts dict
    collected_facts_0 = {}

    # Test Case - Check that facts are added to the collected_facts
    # The following keys should be added:
    # 'ssh_host_pub_keys'
    # 'ssh_host_key_dsa_public'
    # 'ssh_host_key_rsa_public'
    # 'ssh_host_key_dsa_public_keytype'
    # 'ssh_host_key_rsa_public_keytype'
    # 'ssh_host_key_

# Generated at 2022-06-25 00:44:44.613781
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:44:51.268099
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    collected_facts = {}
    collected_facts = ssh_pub_key_fact_collector.collect(collected_facts=collected_facts)

    assert collected_facts.keys() | SshPubKeyFactCollector._fact_ids == ssh_pub_key_fact_collector._fact_ids

    # the following tests assume a system with ssh host keys present
    assert collected_facts['ssh_host_key_rsa_public'] is not None
    assert collected_facts['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa'
    assert collected_facts['ssh_host_key_ecdsa_public'] is not None
    assert collected_facts['ssh_host_key_ecdsa_public_keytype']

# Generated at 2022-06-25 00:44:53.866189
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()


# Generated at 2022-06-25 00:45:01.651143
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Build the behaviour
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    # Build the expected result

# Generated at 2022-06-25 00:45:03.749979
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_fact_collector_1, SshPubKeyFactCollector)

# Generated at 2022-06-25 00:45:11.689357
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()


test_SshPubKeyFactCollector_collect()

# Generated at 2022-06-25 00:45:15.122552
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0 == {}, 'Return value should be as expected'



# Generated at 2022-06-25 00:45:22.866349
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # test with empty kwargs
    var = ssh_pub_key_fact_collector.collect()

    # test with kwargs set to None
    var = ssh_pub_key_fact_collector.collect(module=None, collected_facts=None)

    # test with invalid kwargs
    with pytest.raises(TypeError):
        var = ssh_pub_key_fact_collector.collect(module_=None, collected_facts=None)

# Generated at 2022-06-25 00:45:25.689523
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test on a real host, should always succeed
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.collect()



# Generated at 2022-06-25 00:45:26.732034
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert SshPubKeyFactCollector().collect() == {}


# Generated at 2022-06-25 00:45:35.584671
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert isinstance(var_0.get('ssh_host_pub_keys', {}), dict)
    assert isinstance(var_0.get('ssh_host_key_dsa_public', ''), str)
    assert isinstance(var_0.get('ssh_host_key_rsa_public', ''), str)
    assert isinstance(var_0.get('ssh_host_key_ecdsa_public', ''), str)
    assert isinstance(var_0.get('ssh_host_key_ed25519_public', ''), str)

# Generated at 2022-06-25 00:45:36.714791
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:45:39.771958
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Test for `SshPubKeyFactCollector.collect`"""
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:42.791731
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 00:45:48.449277
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # This test case will run only if
    # system has dsa, rsa, ecdsa, ed25519 keys in /etc/ssh

    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

    fact_ids = ssh_pub_key_fact_collector_0._fact_ids

    for id in fact_ids:
        assert id in vars(var_0)

# Generated at 2022-06-25 00:45:59.803571
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:46:09.926812
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:46:12.894056
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    f_collect = SshPubKeyFactCollector.collect
    assert f_collect is not None, "Function 'collect' in class SshPubKeyFactCollector not found"


# Generated at 2022-06-25 00:46:15.680568
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_test_0 = SshPubKeyFactCollector()
    var_test_0 = ssh_pub_key_fact_collector_test_0.collect()
    assert var_test_0 == {}

# Generated at 2022-06-25 00:46:18.382412
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 00:46:22.704907
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert var_0 == {}

# Generated at 2022-06-25 00:46:25.487137
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    # Test with no exception
    var_1 = ssh_pub_key_fact_collector_0.collect()



# Generated at 2022-06-25 00:46:28.057309
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_1.collect()
    assert type(var_0) == dict

# Generated at 2022-06-25 00:46:35.867580
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fixture_facts = {}
    param_0 = fixture_facts
    fixture_return_value = {}
    fixture_return_value_0 = {}

    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0._ssh_pub_key_fact_collector__get_key_data_0 = []
    ssh_pub_key_fact_collector_0._ssh_pub_key_fact_collector__get_key_data_0.append(fixture_return_value)
    fixture_return_value_1 = {}
    ssh_pub_key_fact_collector_0._ssh_pub_key_fact_collector__get_key_data_0.append(fixture_return_value_1)
    fixture_return_value

# Generated at 2022-06-25 00:46:40.839454
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # No keys
    keyfile = '/etc/ssh/ssh_host_ecdsa_key.pub'
    with open(keyfile, 'w') as f:
        f.write('')

    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert not var_0

# Generated at 2022-06-25 00:46:55.176915
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_1 = SshPubKeyFactCollector()
    var_2 = {}
    var_3 = var_1.collect(collected_facts=var_2)
    var_4 = '/etc/ssh/ssh_host_dsa_key.pub'
    var_5 = get_file_content(var_4)
    var_6 = var_5.split()
    var_7 = var_6[1]
    assert var_3['ssh_host_key_dsa_public'] == var_7

# Generated at 2022-06-25 00:46:56.617501
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:46:59.101483
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()



# Generated at 2022-06-25 00:47:01.957949
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:08.189435
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    # The code after this line will not be executed
    # This returns the correct object in an environment where the file
    # /etc/ssh/ssh_host_dsa_key.pub exists

# Generated at 2022-06-25 00:47:10.658404
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # case 0
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:20.651048
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    if 'ssh_host_pub_keys' in var_0:
        assert var_0['ssh_host_pub_keys'] == []
        assert 'ssh_host_key_dsa_public' in var_0
        assert 'ssh_host_key_ecdsa_public' in var_0
        assert 'ssh_host_key_ed25519_public' in var_0
        assert 'ssh_host_key_rsa_public' in var_0
    else:
        assert 'ssh_host_key_dsa_public' not in var_0
        assert 'ssh_host_key_ecdsa_public' not in var_0
        assert 'ssh_host_key_ed25519_public' not in var_0
        assert 'ssh_host_key_rsa_public' not in var_0

# Generated at 2022-06-25 00:47:23.497993
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
    assert var_1 is not None


# Generated at 2022-06-25 00:47:31.090766
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    # Change ssh_host_key_ecdsa_public_keytype
    ssh_pub_key_fact_collector._fact_ids.add('ssh_host_key_ecdsa_public_keytype')
    # Change ssh_host_key_dsa_public_keytype
    ssh_pub_key_fact_collector._fact_ids.add('ssh_host_key_ecdsa_public_keytype')
    # Change ssh_host_key_dsa_public
    ssh_pub_key_fact_collector._fact_ids.add('ssh_host_key_ecdsa_public_keytype')
    # Change ssh_host_key_ecdsa_public
    ssh_pub_key_fact_collector._

# Generated at 2022-06-25 00:47:33.905086
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0 is not None

# Generated at 2022-06-25 00:47:59.381040
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    # Test with the following structure
    # ssh_pub_key_fact_collector_0 = {
    #   "ssh_host_key_dsa_public": "AAAAB3NzaC1kc3MAAACBAJPgC5x0/hN5ifdMyyN0Vyc0GTuX7P/h/FZ4knV0/9LWjg1LF3qJzVGZdMSj8WGnB52w1yh0CfRV9XnRhKj4LZ4ObiZ0zQon16cxCwjS5d5HhWDlV6XWU6M7U6KaIY1LKjF8x0r/

# Generated at 2022-06-25 00:48:03.750938
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_fact_collector_0.collect(), dict)


# Generated at 2022-06-25 00:48:09.800471
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0._fact_ids = None
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert not var_0
    fact_ids = set()
    ssh_pub_key_fact_collector_0._fact_ids = fact_ids
    var_1 = ssh_pub_key_fact_collector_0.collect()
    assert not var_1


# Generated at 2022-06-25 00:48:16.377815
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
  ssh_pub_key_fact_collector = SshPubKeyFactCollector()
  factor = ssh_pub_key_fact_collector.collect()
  assert isinstance(factor, dict)

# Generated at 2022-06-25 00:48:17.328008
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-25 00:48:20.378471
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_1 = SshPubKeyFactCollector()
    var_2 = {}
    var_3 = var_1.collect()
    assert len(var_3) > 0
    assert var_3.keys() == var_2.keys()


# Generated at 2022-06-25 00:48:23.123626
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:48:28.036765
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0 == ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:48:28.511297
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-25 00:48:35.702807
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from .. import SshPubKeyFactCollector
    facts = dict()
    facts['ansible_all_ipv4_addresses'] = ['127.0.0.1']
    collected_facts = dict()
    collected_facts['ansible_facts'] = {'ansible_all_ipv4_addresses': ['127.0.0.1'], 'ansible_machine': 'x86_64', 'ansible_python': {'has_sslcontext': True, 'version': (2, 7, 15, 'final', 0), 'version_info': (2, 7, 15, 'final', 0), 'version_major': 2, 'version_minor': 7, 'version_micro': 15, 'version_releaselevel': 'final', 'version_serial': 0}}
    collected_facts.update(facts)
    ssh_pub

# Generated at 2022-06-25 00:49:17.065553
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:18.003202
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:49:24.174601
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    print(var_0) 

test_SshPubKeyFactCollector_collect()

# Generated at 2022-06-25 00:49:27.754597
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0._fact_ids = set()
    var_1 = ssh_pub_key_fact_collector_0.collect()
    assert var_1 == {}


# Generated at 2022-06-25 00:49:33.513187
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # case_0
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()



# Generated at 2022-06-25 00:49:36.482902
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector_0 = SshPubKeyFactCollector()
    var_0 = fact_collector_0.collect()
    assert var_0 == {}

# Generated at 2022-06-25 00:49:42.375766
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_1 = SshPubKeyFactCollector()
    var_2 = var_1.collect()
    assert var_2 != None
    assert len(var_2) == 5
    assert 'ssh_host_key_dsa_public' in var_2
    assert 'ssh_host_key_rsa_public' in var_2
    assert 'ssh_host_key_ecdsa_public' in var_2
    assert 'ssh_host_key_ed25519_public' in var_2
    assert 'ssh_host_pub_keys' in var_2

# Generated at 2022-06-25 00:49:44.539817
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
    var_2 = ssh_pub_key_fact_collector_1.collect()
    assert var_1 == var_2


# Generated at 2022-06-25 00:49:49.399916
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:54.620402
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 00:51:32.797580
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert type(test_case_0()) is dict

# Generated at 2022-06-25 00:51:33.842962
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # No exception is expected here
    SshPubKeyFactCollector().collect()

# Generated at 2022-06-25 00:51:40.338584
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert 'ssh_host_key_rsa_public' in var_0
    assert 'ssh_host_key_dsa_public' in var_0
    assert 'ssh_host_key_ecdsa_public' in var_0
    assert 'ssh_host_key_ed25519_public' in var_0
    assert '/etc/ssh' in var_0['ssh_host_key_rsa_public']
    assert 'AAAAB3NzaC1yc2EAAAADAQABAAABAQC' in var_0['ssh_host_key_rsa_public']

# Generated at 2022-06-25 00:51:45.581744
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var = dict()
    var['v1'] = 'v1'
    var['v2'] = 'v2'
    var['v3'] = 'v3'
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector.collect()

# Generated at 2022-06-25 00:51:53.607396
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Test method collect of class SshPubKeyFactCollector"""

    # Create an instance of SshPubKeyFactCollector
    # This usually happens in the Ansible module_utils
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

    # Call method collect of SshPubKeyFactCollector
    # This results in calling the collect() method in the class SshPubKeyFactCollector
    # The return value is stored in var_0
    var_0 = ssh_pub_key_fact_collector_0.collect()

    # Assert equal for var_0 and var_1, the returned values
    # If all assert statements pass, the testcase will pass
    # The first assert is commented out, because it will not pass,
    # since we do not have a collect function yet, but only a pass statement

# Generated at 2022-06-25 00:51:54.950621
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    var = ssh_pub_key_fact_collector.collect()
    assert(type(var) == dict)


# Generated at 2022-06-25 00:52:00.367133
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_ = SshPubKeyFactCollector()
    var_0 = var_.collect()
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 00:52:02.161977
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_1.collect() == None


# Generated at 2022-06-25 00:52:11.019069
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    collected_facts_1 = {'ssh_host_key_dsa_public': 'my_keytype my_ssh_dsa_key',
                         'ssh_host_key_rsa_public': 'my_keytype my_ssh_rsa_key'}
    var_1 = ssh_pub_key_fact_collector_1.collect(collected_facts=collected_facts_1)

# Generated at 2022-06-25 00:52:13.160878
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    print("test_SshPubKeyFactCollector_collect")
    test_case_0()
