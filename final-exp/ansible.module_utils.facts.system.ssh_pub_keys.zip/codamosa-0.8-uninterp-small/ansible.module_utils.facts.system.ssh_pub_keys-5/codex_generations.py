

# Generated at 2022-06-25 00:44:24.131694
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    keydirs = ['/etc/ssh', '/etc/openssh', '/etc']
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_facts_1 = ssh_pub_key_fact_collector_1.collect(
        collected_facts={})

    assert ssh_pub_key_facts_1['ssh_host_key_rsa_public'] is not None
    assert type(ssh_pub_key_facts_1['ssh_host_key_rsa_public']) == str
    assert ssh_pub_key_facts_1['ssh_host_key_rsa_public_keytype'] is not None
    assert type(ssh_pub_key_facts_1['ssh_host_key_rsa_public_keytype']) == str
    assert ssh

# Generated at 2022-06-25 00:44:26.654101
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_0.collect() is not None


# Generated at 2022-06-25 00:44:27.391810
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    res = SshPubKeyFactCollector().collect()

# Generated at 2022-06-25 00:44:29.194219
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # initial test case
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts_0 = ssh_pub_key_fact_collector_0.collect()
    assert ssh_pub_key_facts_0 == {}

# Generated at 2022-06-25 00:44:29.563210
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-25 00:44:39.675422
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector_1.collect()

# Generated at 2022-06-25 00:44:49.723167
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    collected_facts_0 = {}
    ssh_pub_key_facts_0 = ssh_pub_key_fact_collector_0.collect()

    assert ssh_pub_key_facts_0.items() == {'ssh_host_key_rsa_public_keytype': 'ssh-rsa', 'ssh_host_key_dsa_public_keytype': 'ssh-dss'}.items()
    assert not isinstance(ssh_pub_key_facts_0.items(), list)
    assert not isinstance(ssh_pub_key_facts_0.items(), dict)
    assert not isinstance(ssh_pub_key_facts_0.items(), tuple)


# Generated at 2022-06-25 00:44:53.569540
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

    # test collect
    results = ssh_pub_key_fact_collector_0.collect()
    assert isinstance(results, dict)
    for key, value in results.items():
        assert isinstance(key, str)
        assert isinstance(value, str)

# Generated at 2022-06-25 00:45:01.427926
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # Has ssh_host_pub_keys as true (exists)
    # Has ssh_host_key_dsa_public as true (exists)
    # Has ssh_host_key_rsa_public as true (exists)
    # Has ssh_host_key_ecdsa_public as true (exists)
    # Has ssh_host_key_ed25519_public as true (exists)

# Generated at 2022-06-25 00:45:06.593687
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ansible_facts = ssh_pub_key_fact_collector.collect()
    assert 'ssh_host_key_rsa_public' in ansible_facts

# Generated at 2022-06-25 00:45:13.082070
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:24.368325
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = test_case_0()
    assert "ssh_pub_keys" in var_0.keys()
    assert "ssh_host_pub_keys" in var_0.keys()
    assert "ssh_host_key_dsa_public" in var_0.keys()
    assert "ssh_host_key_rsa_public" in var_0.keys()
    assert "ssh_host_key_ecdsa_public" in var_0.keys()
    assert "ssh_host_key_ed25519_public" in var_0.keys()
    assert "ssh_host_key_dsa_public_keytype" in var_0.keys()
    assert "ssh_host_key_rsa_public_keytype" in var_0.keys()

# Generated at 2022-06-25 00:45:26.969713
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()


# Generated at 2022-06-25 00:45:27.496247
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert False

# Generated at 2022-06-25 00:45:30.125024
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
  test_case_0()

# Generated at 2022-06-25 00:45:35.645402
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_1 = SshPubKeyFactCollector()
    var_2 = SshPubKeyFactCollector._fact_ids
    var_3 = var_1.collect()
    assert var_2 == {'ssh_host_pub_keys', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public', 'ssh_host_key_dsa_public'}, "Field var_2 of function test_SshPubKeyFactCollector_collect is incorrect"

# Generated at 2022-06-25 00:45:45.246301
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()

# Generated at 2022-06-25 00:45:48.014945
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    if True:
        assert True
    else:
        raise AssertionError('test_SshPubKeyFactCollector_collect()')



# Generated at 2022-06-25 00:45:53.216095
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()
    # we can't test the data returned, but we can test that it exists and
    # is a dict
    assert isinstance(ssh_pub_key_facts, dict)
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts

# Generated at 2022-06-25 00:45:54.715025
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:59.492157
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:46:09.672476
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts = {}
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    keydirs = ['/etc/ssh', '/etc/openssh', '/etc']
    for keydir in keydirs:
        for algo in algos:
            factname = 'ssh_host_key_%s_public' % algo
            key_filename = '%s/ssh_host_%s_key.pub' % (keydir, algo)

# Generated at 2022-06-25 00:46:11.979997
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_0.collect()


# Generated at 2022-06-25 00:46:13.196115
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector_0 = SshPubKeyFactCollector()
    var_0 = fact_collector_0.collect(module=None, collected_facts=None)

# Generated at 2022-06-25 00:46:18.407830
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var = SshPubKeyFactCollector()
    var_str = 'var'
    var_collect = 'collect'
    var_excep = 'excep'
    var_2 = 'var 2'
    try:
        var.collect(var_str, var_2)
    except Exception:
        var_excep = Exception
    assert var_collect == 'collect'
    assert var_str == 'var'
    assert var_2 == 'var 2'
    assert var_excep == Exception

# Generated at 2022-06-25 00:46:21.683897
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_1 = var_0.collect()
    assert var_1 is not None
    assert var_1 is not None

# Generated at 2022-06-25 00:46:24.493639
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # create instance of class with optional input parameters
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    # ssh_pub_key_fact_collector_0.collect()



# Generated at 2022-06-25 00:46:33.030004
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:46:42.214304
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    current_keydir = '/etc/ssh'
    current_algo = 'dsa'
    keydirs = ['/etc/ssh', '/etc/openssh', '/etc']
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')

    file_contents = {}
    key_filename = '%s/ssh_host_%s_key.pub' % (current_keydir, current_algo)

# Generated at 2022-06-25 00:46:49.123531
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    key = ssh_pub_key_fact_collector_0.collect()
    if not type(key) == dict:
        raise Exception('Returned value is not of type "dict".')
    elif not key:
        raise Exception('Return empty dict')
    else:
        for key, value in key.items():
            if not type(key) == str:
                raise Exception('Returned value is not of type "str".')
            elif not key:
                raise Exception('Return empty string for key')
            elif not type(value) == str:
                raise Exception('Returned value is not of type "str".')
            elif not value:
                raise Exception('Return empty string for value')



# Generated at 2022-06-25 00:46:58.178262
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert test_case_0() is None

# Generated at 2022-06-25 00:47:00.992658
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()

# Generated at 2022-06-25 00:47:02.823437
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector = SshPubKeyFactCollector()
    result = fact_collector.collect()
    assert len(result) > 0

# Generated at 2022-06-25 00:47:05.099492
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_1 = SshPubKeyFactCollector.collect(module=None)
    assert var_1 is not None
    assert isinstance(var_1, dict)

# Generated at 2022-06-25 00:47:10.302436
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts_0 = ssh_pub_key_fact_collector_0.collect()

    assert(len(ssh_pub_key_facts_0) > 0)
    assert(('ssh_host_key_dsa_public' in ssh_pub_key_facts_0) or ('ssh_host_key_rsa_public' in ssh_pub_key_facts_0))

# Generated at 2022-06-25 00:47:15.370156
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    try:
        assert var_0.keys() == [u'ssh_host_key_rsa_public', u'ssh_host_key_dsa_public', u'ssh_host_key_rsa_public_keytype', u'ssh_host_key_dsa_public_keytype']
    except AssertionError as e:
        raise AssertionError(str(e) + ": " + str(var_0))



# Generated at 2022-06-25 00:47:16.140908
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-25 00:47:17.576328
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    c = SshPubKeyFactCollector()
    c.collect()
    pass

# Generated at 2022-06-25 00:47:19.970953
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:22.700274
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:47:42.141085
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
    assert len(var_1) > 0


# Generated at 2022-06-25 00:47:50.329483
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Set up mock AnsibleModule object
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0 is not None

# # Unit test for method get_fact_names of class SshPubKeyFactCollector
# def test_SshPubKeyFactCollector_get_fact_names():
#     # Set up mock AnsibleModule object
#     ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
#     var_0 = ssh_pub_key_fact_collector_0.get_fact_names()
#     assert var_0 is not None

# Generated at 2022-06-25 00:47:59.564115
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:48:00.951603
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    assert isinstance(var_0.collect(), dict)

# Generated at 2022-06-25 00:48:02.323308
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_1 = SshPubKeyFactCollector()
    var_1.collect



# Generated at 2022-06-25 00:48:05.545043
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    if isinstance(ssh_pub_key_fact_collector_0, BaseFactCollector):
        ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:48:06.400676
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert True



# Generated at 2022-06-25 00:48:07.547305
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
  t0 = SshPubKeyFactCollector()
  s0 = t0.collect()

# Generated at 2022-06-25 00:48:15.008967
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.ssh_host_key_ed25519_public_keytype
    var_2 = ssh_pub_key_fact_collector_1.ssh_host_key_ecdsa_public_keytype
    var_3 = ssh_pub_key_fact_collector_1.ssh_host_key_dsa_public_keytype
    var_4 = ssh_pub_key_fact_collector_1.ssh_host_key_rsa_public_keytype
    var_5 = ssh_pub_key_fact_collector_1.ssh_host_key_ecdsa_public
    var_6 = ssh_pub_key_fact_collector_

# Generated at 2022-06-25 00:48:22.672150
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    collected_facts = dict()
    assert collected_facts == dict(), "Initial Collector does not contain any ssh pub keys"
    collected_facts = ssh_pub_key_fact_collector.collect(collected_facts=collected_facts)
    assert 'ssh_host_key_dsa_public' in collected_facts
    assert 'ssh_host_key_rsa_public' in collected_facts
    assert 'ssh_host_key_ecdsa_public' in collected_facts
    assert 'ssh_host_key_ed25519_public' in collected_facts

# Generated at 2022-06-25 00:48:58.021814
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # Invoke method
    result = SshPubKeyFactCollector.collect()

    # Tests
    assert result is None

# Generated at 2022-06-25 00:49:01.152789
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_2 = SshPubKeyFactCollector()
    var_3 = ssh_pub_key_fact_collector_2.collect()
    assert var_3 is not False


# Generated at 2022-06-25 00:49:03.141174
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    SshPubKeyFactCollector_collect_instance = SshPubKeyFactCollector()
    var_0 = SshPubKeyFactCollector_collect_instance.collect()
    print(var_0)

# Generated at 2022-06-25 00:49:04.572240
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:11.686953
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Define the test case inputs, and expected results.

    # set up object
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    # run the code to be tested
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()

    # assert that the results are as expected
    assert isinstance(ssh_pub_key_facts, dict)
    assert ssh_pub_key_facts.keys() == set(['ssh_host_pub_keys',
                                            'ssh_host_key_dsa_public',
                                            'ssh_host_key_rsa_public',
                                            'ssh_host_key_ecdsa_public',
                                            'ssh_host_key_ed25519_public'])

# Generated at 2022-06-25 00:49:17.273386
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Testing for case 0
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:18.858019
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert len(ssh_pub_key_fact_collector_0.collect()['ssh_host_key_ecdsa_public_keytype']) == 8


# Generated at 2022-06-25 00:49:20.106646
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:29.570957
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Return ssh_host_pub_keys and ssh_host_key_*_public facts for ssh keys
    found in /etc/ssh or /etc/openssh or /etc.  The first directory found
    containing keys is the one used."""
    test_0 = SshPubKeyFactCollector()
    # 'ssh_host_pub_keys': '/etc/ssh/ssh_host_dsa_key.pub',
    # 'ssh_host_key_dsa_public': 'ssh-dss AAAAB3NzaC1kc3MAA...',
    # 'ssh_host_key_dsa_public_keytype': 'ssh-dss'

# Generated at 2022-06-25 00:49:34.256477
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.collect() == {}, 'Return value of function collect of class SshPubKeyFactCollector does not match expected value.'


# Generated at 2022-06-25 00:51:00.157483
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    # eval is required to make the repr callable
    var_0 = eval(str(ssh_pub_key_fact_collector_0))
    var_0.collect()


# Generated at 2022-06-25 00:51:06.253748
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    var_1 = ssh_pub_key_fact_collector_0.collect()
    assert var_0 == var_1

# Generated at 2022-06-25 00:51:08.259114
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_0.collect()
    assert type(var_1) is dict


# Generated at 2022-06-25 00:51:11.174677
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:51:15.502387
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Assign values for the purpose of the test
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_2 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_3 = SshPubKeyFactCollector()

    # Call function collect of class SshPubKeyFactCollector
    result_1 = ssh_pub_key_fact_collector_1.collect(module=None, collected_facts=None)
    result_2 = ssh_pub_key_fact_collector_2.collect(module=None, collected_facts=None)
    result_3 = ssh_pub_key_fact_collector_3.collect(module=None, collected_facts=None)


# Generated at 2022-06-25 00:51:17.642689
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    var = ssh_pub_key_fact_collector.collect()


# Generated at 2022-06-25 00:51:25.661894
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:51:28.123600
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()


# Generated at 2022-06-25 00:51:32.901908
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:51:34.300858
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector.collect()