

# Generated at 2022-06-25 00:44:16.325456
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 00:44:19.303089
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test with good ssh_host_keys
    ssh_pub_key_fact_collector_2 = SshPubKeyFactCollector()


# Generated at 2022-06-25 00:44:21.168426
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_1.collect()

# Generated at 2022-06-25 00:44:29.761538
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_collect = SshPubKeyFactCollector()
    ssh_pub_key_facts_0 = ssh_pub_key_fact_collector_collect.collect()

# Generated at 2022-06-25 00:44:39.701124
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # Testing successful collection without any ssh host keys
    collected_facts = {'ansible_all_ipv4_addresses' : ['10.1.2.3']}
    expected_facts = {}
    ssh_pub_key_fact_collector.collect(collected_facts=collected_facts)
    assert (ssh_pub_key_fact_collector.get_facts() == expected_facts)

    # Testing successful collection with a single ssh host key
    collected_facts = {'ansible_all_ipv4_addresses' : ['10.1.2.3']}

# Generated at 2022-06-25 00:44:46.477812
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

    ssh_pub_key_facts_0 = ssh_pub_key_fact_collector_0.collect()

    assert isinstance(ssh_pub_key_facts_0, dict)

# Generated at 2022-06-25 00:44:47.987588
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_1.collect(None, None)

# Generated at 2022-06-25 00:44:49.070617
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()


# Generated at 2022-06-25 00:44:55.183065
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()
    assert 'ssh_host_pub_keys' not in ssh_pub_key_facts
    assert 'ssh_host_key_dsa_public' not in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public' not in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public' not in ssh_pub_key_facts
    assert 'ssh_host_key_ed25519_public' not in ssh_pub_key_facts

# Generated at 2022-06-25 00:45:05.065465
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:45:13.110960
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    result = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:24.367617
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    collected_facts = {}
    # case 0 - empty
    collected_facts = {}
    ssh_pub_key_facts = {}
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect(None, collected_facts)
    assert ssh_pub_key_facts == {}

    # case 1 - some ssh keys present
    # ssh_host_key_dsa_public present
    collected_facts = {'ssh_host_key_dsa_publid': 'ssh-dss AAAAB3NzaC1kc3MAAAA=='}
    ssh_pub_key_facts = {}
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect(None, collected_facts)


# Generated at 2022-06-25 00:45:33.753827
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test 1: no ssh keys found

    # create the object
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    
    # list of directories to check for ssh keys
    keydirs = ['/etc/ssh', '/etc/openssh', '/etc']

    for keydir in keydirs:
        # remove any ssh key files
        for algo in ('dsa', 'rsa', 'ecdsa', 'ed25519'):
            key_filename = '%s/ssh_host_%s_key.pub' % (keydir, algo)
            try:
                os.remove(key_filename)
            except:
                pass

    # run the collect method
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()

    # assert that all

# Generated at 2022-06-25 00:45:37.971176
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    instance = SshPubKeyFactCollector()
    instance.collect()

#
# Unit testing classes below this line
#
#
#

# Generated at 2022-06-25 00:45:43.124605
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Dummy AnsibleModule instance
    am = None

    # Dummy collected facts dictionary
    cf = { 'ssh_host_key_rsa_public': '', 'ssh_host_key_dsa_public': '' }

    # Invoke the collect method of SshPubKeyFactCollector
    rt = SshPubKeyFactCollector.collect(ssh_pub_key_fact_collector_0, am, cf)

    assert rt is not None

# Generated at 2022-06-25 00:45:50.859105
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    result = ssh_pub_key_fact_collector.collect()

    ssh_host_pub_keys = result['ssh_host_pub_keys']
    assert 'dsa' in ssh_host_pub_keys.keys()
    assert 'rsa' in ssh_host_pub_keys.keys()
    assert 'ecdsa' in ssh_host_pub_keys.keys()
    assert 'ed25519' in ssh_host_pub_keys.keys()

    for algo in ('ecdsa', 'rsa', 'dsa', 'ed25519'):
        factname = 'ssh_host_key_%s_public' % algo


# Generated at 2022-06-25 00:45:59.076584
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_cases = [
        # TestCase_0
        {
            "data": {},
            "expect_results": {},
            "expect_return": {
                'ssh_host_pub_keys': {
                    'ed25519': None,
                    'dsa': None,
                    'rsa': None,
                    'ecdsa': None,
                },
                'ssh_host_key_dsa_public': None,
                'ssh_host_key_rsa_public': None,
                'ssh_host_key_ecdsa_public': None,
                'ssh_host_key_ed25519_public': None
            }
        },
    ]

    for test_case in test_cases:
        test_case_0(test_case)

    module_args = {}
    ansible

# Generated at 2022-06-25 00:46:09.350800
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts_0 = ssh_pub_key_fact_collector_0.collect()
    assert len(ssh_pub_key_facts_0) == 5
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts_0
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts_0
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts_0
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_facts_0
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts_0

# Generated at 2022-06-25 00:46:13.015422
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_0.collect() is None


# Generated at 2022-06-25 00:46:15.113458
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    result = ssh_pub_key_fact_collector_0.collect()
    assert result is not None

# Generated at 2022-06-25 00:46:31.834479
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_collect = SshPubKeyFactCollector()
    return_value = ssh_pub_key_fact_collector_collect.collect()

# Generated at 2022-06-25 00:46:33.169137
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()


# Generated at 2022-06-25 00:46:39.123551
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # Test case with ssh_host_rsa_key.pub
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_facts_1 = ssh_pub_key_fact_collector_1.collect()
    assert isinstance(ssh_pub_key_facts_1, dict)
    assert len(ssh_pub_key_facts_1) == 2

# Generated at 2022-06-25 00:46:42.842725
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ansible_module_0 = AnsibleModule(argument_spec=dict())
    ansible_module_0.params['content'] = 'aaaa'
    ssh_pub_key_fact_collector_0.collect(ansible_module_0)

# Generated at 2022-06-25 00:46:47.264200
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create an instance of SshPubKeyFactCollector
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

    # Call method collect of SshPubKeyFactCollector
    ssh_pub_key_facts = ssh_pub_key_fact_collector_0.collect()

    for fact_name in SshPubKeyFactCollector._fact_ids:
        assert fact_name in ssh_pub_key_facts

# Generated at 2022-06-25 00:46:48.614483
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    SshPubKeyFactCollector.collect()


# Generated at 2022-06-25 00:46:57.860459
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    collected_facts = {}

# Generated at 2022-06-25 00:46:59.912921
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_1.collect() == []

# Generated at 2022-06-25 00:47:07.428608
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    arg_0_values = (None, None,)
    arg_0_name = 'module'
    arg_0_default = None
    arg_1_values = (None, None,)
    arg_1_name = 'collected_facts'
    arg_1_default = None
    with open('/tmp/ansible_fact_collector_test_cases/test_SshPubKeyFactCollector_collect_0.txt') as f:
        expected_results_0 = f.read()

# Generated at 2022-06-25 00:47:14.589596
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:47:34.299291
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # No validation of return value of collect method
    # Not much else to do in unit test
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_1.collect()

# Generated at 2022-06-25 00:47:44.155539
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()
    assert type(ssh_pub_key_facts) is dict
    assert type(ssh_pub_key_facts['ssh_host_pub_keys']) is str
    assert type(ssh_pub_key_facts['ssh_host_key_dsa_public']) is str
    assert type(ssh_pub_key_facts['ssh_host_key_rsa_public']) is str
    assert type(ssh_pub_key_facts['ssh_host_key_ecdsa_public']) is str
    assert type(ssh_pub_key_facts['ssh_host_key_ed25519_public']) is str

# Generated at 2022-06-25 00:47:52.901338
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    answer_dict_1 = ssh_pub_key_fact_collector_1.collect()
    assert type(answer_dict_1) is dict
    assert 'ssh_host_pub_keys' in answer_dict_1
    assert type(answer_dict_1['ssh_host_pub_keys']) is dict
    for algo in ('dsa', 'rsa', 'ecdsa', 'ed25519'):
        assert 'ssh_host_key_%s_public' % algo in answer_dict_1['ssh_host_pub_keys']
        assert type(answer_dict_1['ssh_host_key_%s_public' % algo]) is str

# Generated at 2022-06-25 00:47:59.836645
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    res_1 = ssh_pub_key_fact_collector_1.collect()
    assert 'ssh_host_key_rsa_public' in res_1
    assert 'ssh_host_key_rsa_public_keytype' in res_1
    assert res_1['ssh_host_key_rsa_public_keytype'] == b'ssh-rsa'

# Generated at 2022-06-25 00:48:04.122989
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    try:
        test_case_0()
    except NameError as e:
        print("Testcase 0 failed: " + str(e))

if __name__ == "__main__":
    test_SshPubKeyFactCollector_collect()

# Generated at 2022-06-25 00:48:05.620057
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:48:10.144836
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fake_collected_facts = {}
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    (ssh_pub_key_facts_ret_0) = ssh_pub_key_fact_collector_0.collect(collected_facts=fake_collected_facts)
    assert ssh_pub_key_facts_ret_0 == {}


# Generated at 2022-06-25 00:48:20.116470
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    collected_facts = {'ansible_all_ipv4_addresses': ['10.0.0.11'], 'ansible_all_ipv6_addresses': []}
    collected_facts = ssh_pub_key_fact_collector_0.collect(collected_facts=collected_facts)

    assert 'ssh_host_key_dsa_public' in collected_facts
    assert 'ssh_host_key_rsa_public' in collected_facts
    assert 'ssh_host_key_ecdsa_public' in collected_facts
    assert 'ssh_host_key_ed25519_public' in collected_facts

# Generated at 2022-06-25 00:48:30.692382
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

# Generated at 2022-06-25 00:48:35.776213
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Needs to be updated

    # Test 0: all keys
    ssh_pub_key_collector_0 = SshPubKeyFactCollector()
    keydir_0 = TestDir('/test/test/test')
    keydir_1 = TestDir('/test/test/')
    keydir_2 = TestDir('/test/')

    keys_0 = []
    keys_0.append(TestFile('/test/test/test/ssh_host_dsa_key.pub',
                           'test/test/test/ssh_host_dsa_key.pub',
                           'ssh-dss AAAAB...zA== HostName'))

# Generated at 2022-06-25 00:49:16.891535
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector.collect()

# Generated at 2022-06-25 00:49:19.187582
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-25 00:49:26.244668
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts_0 = ssh_pub_key_fact_collector_0.collect(module=None, collected_facts=None)
    assert ('ssh_host_key_dsa_public' in ssh_pub_key_facts_0)
    assert ('ssh_host_key_rsa_public' in ssh_pub_key_facts_0)
    assert ('ssh_host_key_ecdsa_public' in ssh_pub_key_facts_0)
    assert ('ssh_host_key_ed25519_public' in ssh_pub_key_facts_0)

# Generated at 2022-06-25 00:49:28.670047
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_keys_result_0 = ssh_pub_key_fact_collector_0.collect(module=None, collected_facts=None)
    assert ssh_pub_keys_result_0 is not None


# Generated at 2022-06-25 00:49:33.621982
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    result = ssh_pub_key_fact_collector_0.collect()
    assert result is None


# Generated at 2022-06-25 00:49:42.725761
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()

# Generated at 2022-06-25 00:49:52.525453
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:49:58.726971
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ansible_collected_facts_0 = {}
    ansible_collected_facts_0['ansible_all_ipv4_addresses'] = '192.0.2.1'
    ansible_collected_facts_0['ansible_all_ipv6_addresses'] = '2001:db8::2ec1'
    ansible_collected_facts_0['ansible_architecture'] = 'x86_64'
    ansible_collected_facts_0['ansible_bios_date'] = '08/24/2006'
    ansible_collected_facts_0['ansible_bios_version'] = '6.00'

# Generated at 2022-06-25 00:50:00.218821
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_1.collect() == {}


# Generated at 2022-06-25 00:50:09.209205
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    fact_collector = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:51:44.679857
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    collected_facts = {}
    assert ssh_pub_key_fact_collector_0.collect(collected_facts=collected_facts) == {}

# Generated at 2022-06-25 00:51:53.471420
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Case 0
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts_0 = ssh_pub_key_fact_collector_0.collect()
    factid_set_0 = set(ssh_pub_key_facts_0.keys())

# Generated at 2022-06-25 00:51:59.643016
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_keys_collector = SshPubKeyFactCollector()
    actual_result = ssh_pub_keys_collector.collect()
    expected_result = {}
    assert expected_result == actual_result, "test_SshPubKeyFactCollector_collect_return value does not match"

# Generated at 2022-06-25 00:52:05.915189
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    factdata = {}

    #Case 0: test all known file types (dsa, rsa, ecdsa, ed25519) are present
    #  and return their key data.

# Generated at 2022-06-25 00:52:07.225527
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_1.collect() == dict()

# Generated at 2022-06-25 00:52:17.070579
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
    Returns ssh_pub_keys facts
    """
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_keys = ssh_pub_key_fact_collector.collect()
    assert isinstance(ssh_pub_keys, dict), 'ssh_pub_keys is not a dictionary'
    assert 'ssh_host_key_dsa_public' in ssh_pub_keys, 'ssh_host_key_dsa_public key is not in ssh_pub_keys'
    assert 'ssh_host_key_rsa_public' in ssh_pub_keys, 'ssh_host_key_rsa_public key is not in ssh_pub_keys'

# Generated at 2022-06-25 00:52:24.140809
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()

# Generated at 2022-06-25 00:52:28.469678
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_1.collect() is not None

# Generated at 2022-06-25 00:52:30.316666
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    facts = ssh_pub_key_fact_collector.collect()
    assert facts is None or isinstance(facts, dict)

# Generated at 2022-06-25 00:52:39.869291
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector_0.collect()
    assert ssh_pub_key_facts['ssh_host_key_ecdsa_public'] == 'AAAAC3NzaC1lZDI1NTE5AAAAIImU/QP4crSXS+gJNEDN+NHpIy/N5V5p5Rzw7V34ou+bD'