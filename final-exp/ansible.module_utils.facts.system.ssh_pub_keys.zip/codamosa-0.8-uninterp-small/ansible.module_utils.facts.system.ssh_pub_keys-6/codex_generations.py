

# Generated at 2022-06-25 00:44:18.704185
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    result = ssh_pub_key_fact_collector.collect()
    assert (result['ssh_host_key_ecdsa_public'] == 'AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBBHJ2Kw0n+MZq3QL+sqdCe8JlvX9pjjm0fH/R+mQ2gkDO0iBH3qZqLRcZb5hMbs5WM5d2a5PeUrrIGiPFw/O60=')

# Generated at 2022-06-25 00:44:25.966292
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts_0 = ssh_pub_key_fact_collector_0.collect()
    assert len(ssh_pub_key_facts_0) == 5
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts_0

# Generated at 2022-06-25 00:44:32.868114
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_collect = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector_collect.collect()
    assert isinstance(ssh_pub_key_facts, dict)
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts


# Generated at 2022-06-25 00:44:43.372871
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # test for successful ssh_host_ed25519_public
    # case 0
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_host_key_ed25519_public = ssh_pub_key_fact_collector_0.collect().get('ssh_host_key_ed25519_public', None)
    assert ssh_host_key_ed25519_public is not None

    # test for successful ssh_host_ecdsa_public
    # case 1
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_host_key_ecdsa_public = ssh_pub_key_fact_collector_1.collect().get('ssh_host_key_ecdsa_public', None)
    assert ssh_host_

# Generated at 2022-06-25 00:44:47.588096
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_1.collect() is None


# Generated at 2022-06-25 00:44:51.139148
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_0.collect() == {
        'ssh_host_key_dsa_public': 'ssh-dsa AAAAB3NzaC1kc3MAAACBAKMQSm5I5q+9KjJxC7nUzAnk+V7IFL6D',
        'ssh_host_key_dsa_public_keytype': 'ssh-dss',
    }


# Generated at 2022-06-25 00:44:56.946883
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()
    assert type(ssh_pub_key_facts) is dict
    assert len(ssh_pub_key_facts) == 5
    assert ssh_pub_key_facts['ssh_host_key_ecdsa_public'] is not None

# Generated at 2022-06-25 00:44:57.862079
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()


# Generated at 2022-06-25 00:45:01.305097
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # ssh_pub_key_fact_collector_0 instantiation
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:08.921058
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

    assert 'ssh_host_key_dsa_public' in ssh_pub_key_fact_collector_0.collect()

    assert 'ssh_host_key_rsa_public' in ssh_pub_key_fact_collector_0.collect()

    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_fact_collector_0.collect()

    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:45:15.582954
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # this is mostly tested indirectly through integration testing as it
    # mocks out the filesystem
    pass

# Generated at 2022-06-25 00:45:25.980405
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_facts_0 = ssh_pub_key_fact_collector_0.collect()
    key_name_0 = None
    key_name_1 = None
    for key, value in ssh_pub_key_facts_0.items():
        if key_name_0 is None:
            key_name_0 = key
        else:
            key_name_1 = key
            break
    assert key_name_0 in ssh_pub_key_facts_0
    assert key_name_1 in ssh_pub_key_facts_0

# Generated at 2022-06-25 00:45:35.247619
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()

# Generated at 2022-06-25 00:45:45.199247
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
        def __init__(self):
            self.name = 'ssh_pub_keys'
            self._fact_ids = set(['ssh_host_pub_keys',
                                  'ssh_host_key_dsa_public',
                                  'ssh_host_key_rsa_public',
                                  'ssh_host_key_ecdsa_public',
                                  'ssh_host_key_ed25519_public'])
    """
    # Testing with a list of directories to check for ssh keys
    # used in the order listed here, the first one with keys is used
    keydirs = ['/etc/ssh', '/etc/openssh', '/etc']

    # Testing with a list of directories to check for ssh keys
    # used in the order listed here, the first one with keys is used

# Generated at 2022-06-25 00:45:48.276441
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert 'ssh_host_pub_keys' in ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:52.922496
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()

    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public_keytype' in ssh_pub_key_facts

# Generated at 2022-06-25 00:45:56.183909
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    fact_subset = ssh_pub_key_fact_collector_0.collect(collected_facts={'a': 'b'})
    assert 'a' in fact_subset


# Generated at 2022-06-25 00:45:58.335015
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_fact_collector_1, SshPubKeyFactCollector)

# Generated at 2022-06-25 00:46:08.646307
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ansible_module = AnsibleModule(argument_spec={})
    ansible_module.get_bin_path = lambda _: '/bin/false'

    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # Test with no ssh keys existing on the host
    out = ssh_pub_key_fact_collector.collect(module=ansible_module)
    assert out == {}

    # Test with all ssh keys existing on the host
    ansible_module.get_bin_path = lambda _: '/bin/true'
    out = ssh_pub_key_fact_collector.collect(module=ansible_module)

# Generated at 2022-06-25 00:46:13.095318
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    try:
        ssh_pub_key_fact_collector_1.collect()
    except:
        raise


if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-25 00:46:23.653303
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_0.collect(collected_facts=None)
    assert 'ssh_host_key_ecdsa_public' in var_1
    assert var_1.get('ssh_host_key_ecdsa_public_keytype') == 'ecdsa-sha2-nistp521'

# Generated at 2022-06-25 00:46:32.287796
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

    assert (var_0.get('ssh_host_pub_keys') is None or
            var_0.get('ssh_host_pub_keys') == {})
    assert (var_0.get('ssh_host_key_dsa_public') is None or
            isinstance(var_0.get('ssh_host_key_dsa_public'), str))
    assert (var_0.get('ssh_host_key_rsa_public') is None or
            isinstance(var_0.get('ssh_host_key_rsa_public'), str))

# Generated at 2022-06-25 00:46:35.491610
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0 == {}
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0 == {}

# Generated at 2022-06-25 00:46:38.819937
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()


# Generated at 2022-06-25 00:46:39.377300
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # No return value
    pass

# Generated at 2022-06-25 00:46:46.444974
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_0.collect().has_key('ssh_host_key_ed25519_public')
    assert ssh_pub_key_fact_collector_0.collect().has_key('ssh_host_key_ecdsa_public')
    assert ssh_pub_key_fact_collector_0.collect().has_key('ssh_host_key_rsa_public')
    assert ssh_pub_key_fact_collector_0.collect().has_key('ssh_host_key_dsa_public')
# end class SshPubKeyFactCollector

# Generated at 2022-06-25 00:46:49.140389
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.collect() is None

# Generated at 2022-06-25 00:46:51.962864
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    for _ in range(100):
        var_0 = SshPubKeyFactCollector()
        var_0.collect()
        assert var_0 is not None

# Generated at 2022-06-25 00:46:54.672418
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:46:55.220901
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:47:04.131457
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert test_case_0() == True

# Generated at 2022-06-25 00:47:11.171744
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    param_0 = get_mock_object('ssh_pub_key_fact_collector_0')
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect(param_0)
    assert 'ssh_host_pub_keys' in var_0
    assert 'ssh_host_key_dsa_public' in var_0
    assert 'ssh_host_key_rsa_public' in var_0
    assert 'ssh_host_key_ecdsa_public' in var_0
    assert 'ssh_host_key_ed25519_public' in var_0



# Generated at 2022-06-25 00:47:13.408280
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    print(var_0)

# Generated at 2022-06-25 00:47:19.332878
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    mock_module = Mock(params={})
    mock_collected_facts = { 'ssh_host_key_dsa_public': 'ssh-dss public_key' }

    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0.collect(module=mock_module, collected_facts=mock_collected_facts)

# Generated at 2022-06-25 00:47:27.553746
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test case 0: uses a valid ssh_pub_key file
    
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    
    # Execute method collect
    var_0 = ssh_pub_key_fact_collector_0.collect()
    
    # Test cases with invalid ssh_pub_key files
    
    # Test case 1: uses an invalid ssh_pub_key file
    
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    
    # Execute method collect
    var_1 = ssh_pub_key_fact_collector_1.collect()
    
    # Test case 2: uses an invalid ssh_pub_key file
    
    ssh_pub_key_fact_collector_2 = SshPubKeyFactCollect

# Generated at 2022-06-25 00:47:30.022339
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert False is False

# Generated at 2022-06-25 00:47:32.043092
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var = SshPubKeyFactCollector()
    if var is not None:
        assert True
    else:
        assert False


# Generated at 2022-06-25 00:47:33.385730
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert isinstance(SshPubKeyFactCollector().collect(), dict)

# Generated at 2022-06-25 00:47:39.083271
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()

    ssh_pub_key_fact_collector_0.collect()
    ssh_pub_key_fact_collector_1.collect()
    if ssh_pub_key_fact_collector_0.name == ssh_pub_key_fact_collector_1.name:
        assert(True)
    else:
        assert(False)

# Generated at 2022-06-25 00:47:48.108766
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_1 = 'ssh_host_key_rsa_public'
    var_2 = 'ssh_host_key_dsa_public'
    var_3 = 'ssh_host_key_ecdsa_public'
    var_4 = 'ssh_host_key_ed25519_public'
    var_5 = 'ssh_host_pub_keys'
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    data = ssh_pub_key_fact_collector_1.collect()
    assert var_1 in data
    assert var_2 in data
    assert var_3 in data
    assert var_4 in data
    assert var_5 in data

# Generated at 2022-06-25 00:48:07.037393
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:48:14.630376
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_facts_1 = ssh_pub_key_fact_collector_1.collect()

    assert isinstance(ssh_pub_key_facts_1, dict)

# Generated at 2022-06-25 00:48:22.135825
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # mock ssh_host_key_rsa_public
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_0.collect()
    var_1['ssh_host_key_rsa_public'] = 'ssh_host_key_rsa_public'
    var_2 = 'ssh_host_key_rsa_public'
    var_3 = 'ssh_host_key_rsa_public'
    assert var_1['ssh_host_key_rsa_public'] == var_2


# Generated at 2022-06-25 00:48:26.570613
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_fact_collector_1.collect(), dict)


# Generated at 2022-06-25 00:48:28.837093
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:48:30.875149
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    var = ssh_pub_key_fact_collector.collect()
    assert not var

# Generated at 2022-06-25 00:48:33.313685
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_obj = SshPubKeyFactCollector()

    # Invoke method
    ssh_pub_key_fact_collector_obj.collect()


# Generated at 2022-06-25 00:48:42.593743
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert ssh_pub_key_fact_collector_0._fact_ids == set(['ssh_host_pub_keys',
                                                          'ssh_host_key_dsa_public',
                                                          'ssh_host_key_rsa_public',
                                                          'ssh_host_key_ecdsa_public',
                                                          'ssh_host_key_ed25519_public'])

# Generated at 2022-06-25 00:48:44.364512
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Init scenarios
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:48:53.194734
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert ssh_pub_key_fact_collector_0._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])
    assert ssh_pub_key_fact_collector_0.name == 'ssh_pub_keys'


# Generated at 2022-06-25 00:49:32.474395
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_1 = SshPubKeyFactCollector()
    var_1.name
    var_1.fact_ids
    var_1.collect()

# Generated at 2022-06-25 00:49:35.986226
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_1 = SshPubKeyFactCollector()
    var_1.collect()

# Generated at 2022-06-25 00:49:38.281837
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    var = ssh_pub_key_fact_collector.collect()

# Generated at 2022-06-25 00:49:43.817731
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    try:
        class_0 = SshPubKeyFactCollector()
        # Act
        ret_val_0 = class_0.collect()
    except:
        assert False
    else:
        assert False


# Generated at 2022-06-25 00:49:48.794322
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()


# Generated at 2022-06-25 00:49:52.777350
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Test method collect of class SshPubKeyFactCollector"""

    # Object of class SshPubKeyFactCollector
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()

    # Call method collect of class SshPubKeyFactCollector
    return_value = ssh_pub_key_fact_collector_1.collect()

    assert return_value is not None
    return return_value


# Generated at 2022-06-25 00:49:55.120721
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
    assert True == isinstance(var_1, dict)



# Generated at 2022-06-25 00:49:57.597340
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:50:02.741779
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_collector_0.collect()


# Generated at 2022-06-25 00:50:07.270853
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.collect() == {}

# Generated at 2022-06-25 00:51:40.378409
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:51:50.177314
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:51:52.177262
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    var = ssh_pub_key_fact_collector.collect()
    assert isinstance(var, dict)


# Generated at 2022-06-25 00:51:54.567556
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_2 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_2.collect()

# Generated at 2022-06-25 00:51:59.045895
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # No key found
    var_0 = SshPubKeyFactCollector()
    var_0.collect(None, None)

    # Found one key
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect(None, None)
    assert type(var_0) == dict
    assert var_0.keys() == ['ssh_host_key_rsa_public']

# Generated at 2022-06-25 00:52:03.605871
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()
    expected_keys = set(['ssh_host_key_rsa_public', 'ssh_host_key_rsa_public_keytype'])
    assert set(ssh_pub_key_facts.keys()) == expected_keys


if __name__ == '__main__':
    test_SshPubKeyFactCollector_collect()

# Generated at 2022-06-25 00:52:08.229511
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    var = ssh_pub_key_fact_collector.collect()
    var_is_not_None = var is not None
    assert var_is_not_None == True


# Generated at 2022-06-25 00:52:17.123702
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:52:20.166912
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:52:24.468433
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    var_0
    assert var_0 is not None
    assert isinstance(var_0, dict)