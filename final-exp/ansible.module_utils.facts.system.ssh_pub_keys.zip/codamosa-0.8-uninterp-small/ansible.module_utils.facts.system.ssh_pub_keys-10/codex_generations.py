

# Generated at 2022-06-25 00:44:16.222979
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    return


# Generated at 2022-06-25 00:44:19.302720
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # TODO: Add test cases


# Generated at 2022-06-25 00:44:21.259436
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_1.collect() is not None

# Generated at 2022-06-25 00:44:24.268428
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_1.collect() == {}

# Generated at 2022-06-25 00:44:34.456585
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_dict = ssh_pub_key_fact_collector_0.collect()
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_dict
    assert 'ssh_host_key_dsa_public_keytype' in ssh_pub_key_dict
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_dict
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_dict
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_dict
    assert 'ssh_host_key_ecdsa_public_keytype' in ssh_pub_key_dict

# Generated at 2022-06-25 00:44:43.584767
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:44:47.766031
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0.collect()

test_case_0()

# Generated at 2022-06-25 00:44:49.787521
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_1.collect() is None

# Generated at 2022-06-25 00:44:52.778082
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

    ssh_pub_key_fact_collector_0.collect()


if __name__ == '__main__':
    test_SshPubKeyFactCollector_collect()

# Generated at 2022-06-25 00:45:00.467057
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    collected_facts = ssh_pub_key_fact_collector_1.collect()

    assert 'ssh_host_pub_keys' in collected_facts.keys()
    assert 'ssh_host_key_dsa_public' in collected_facts.keys()
    assert 'ssh_host_key_rsa_public' in collected_facts.keys()
    assert 'ssh_host_key_ecdsa_public' in collected_facts.keys()
    assert 'ssh_host_key_ed25519_public' in collected_facts.keys()
    assert 'ssh_host_key_dsa_public_keytype' in collected_facts.keys()
    assert 'ssh_host_key_rsa_public_keytype' in collected_facts

# Generated at 2022-06-25 00:45:05.676507
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()

    assert isinstance(var_1, dict)
# Testing ends here


# Generated at 2022-06-25 00:45:07.230676
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:09.774548
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-25 00:45:15.051463
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert 'ssh_host_pub_keys' in ssh_pub_key_fact_collector_0.collect()

# We have to have this module here so we can use the collect() method defined in BaseFactCollector
# This module is primarily (only?) going to be used as a parent class of other FactCollector
# classes

# Generated at 2022-06-25 00:45:17.632170
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    # Testing the return type of the collect method
    assert isinstance(ssh_pub_key_fact_collector.collect(), dict)

# Generated at 2022-06-25 00:45:21.121570
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # create a fact collector
    fact_collector_0 = SshPubKeyFactCollector()

    # call the method collect
    fact_collector_0.collect()


# Generated at 2022-06-25 00:45:24.495168
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    print(var_0)


# Generated at 2022-06-25 00:45:29.865191
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert 'ssh_host_key_ed25519_public' in var_0
    assert 'ssh_host_key_ecdsa_public' in var_0
    assert 'ssh_host_key_rsa_public' in var_0
    assert 'ssh_host_key_dsa_public' in var_0


# Generated at 2022-06-25 00:45:32.264768
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert type(var_0) is dict

# Generated at 2022-06-25 00:45:34.719676
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_2 = ssh_pub_key_fact_collector_1.collect()
    assert var_2 == {}

# Generated at 2022-06-25 00:45:41.750377
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:45.561264
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test to ensure we can properly get ssh pub key facts from the system.
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert var_0 == {}

# Generated at 2022-06-25 00:45:53.131054
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    var = ssh_pub_key_fact_collector.collect()
    assert var is not None
    assert 'ssh_host_key_rsa_public' in var
    assert 'ssh_host_key_ecdsa_public' in var
    assert 'ssh_host_key_ed25519_public' in var
    assert 'ssh_host_key_dsa_public' in var
    ssh_pub_key_fact_collector_false = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_false.collect()
    assert var_1 is not None

# Generated at 2022-06-25 00:45:55.486522
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Return the facts collected by the SshPubKeyFactCollector class.
    assert 'ssh_host_key_rsa_public' in SshPubKeyFactCollector.collect()


# Generated at 2022-06-25 00:45:57.957643
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
    assert isinstance(var_1, dict)


# Generated at 2022-06-25 00:46:00.633794
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0 is not None

if __name__ == "__main__":
    test_SshPubKeyFactCollector_collect()

# Generated at 2022-06-25 00:46:05.018595
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # Try calling with only required args: module, collected_facts
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

    # Setup a faked ansible module to use as an argument to the method call
    fake_module_0 = MagicMock()

    # Setup a faked ansible module to use as an argument to the method call
    fake_collected_facts_0 = MagicMock()

    # Call method collect of SshPubKeyFactCollector with the unpacked keyword arguments
    #    ssh_pub_key_fact_collector_0.collect(module=fake_module_0, collected_facts=fake_collected_facts_0)


# Generated at 2022-06-25 00:46:12.248774
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_2 = SshPubKeyFactCollector()
    var_2.collect()
    ssh_host_key_dsa_public = None
    ssh_host_key_rsa_public = None
    ssh_host_key_dsa_public_keytype = None
    ssh_host_key_ecdsa_public = None
    ssh_host_key_rsa_public_keytype = None
    ssh_host_key_ecdsa_public_keytype = None
    ssh_host_key_ed25519_public = None
    ssh_host_key_ed25519_public_keytype = None

# Generated at 2022-06-25 00:46:14.448724
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()

# Generated at 2022-06-25 00:46:21.495141
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Mock the arguments.
    params = {
        'module': None,
        'collected_facts': None,
    }

    # Mock the result of the 'get_file_content' function
    try:
        file_content = get_file_content.return_value
        file_content.split.return_value = ('keytype', 'key')
    except Exception as exception:
        print('An exception was raised when mocking the '
              '\'get_file_content\' function.')
        raise exception

    # Call the method under test.

# Generated at 2022-06-25 00:46:36.397218
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_1 = SshPubKeyFactCollector()
    var_1 = var_1.collect()
    assert var_1 == {}
    var_2 = SshPubKeyFactCollector()
    var_2 = var_2.collect()
    assert var_2 == {}
    var_3 = SshPubKeyFactCollector()
    var_3 = var_3.collect()
    assert var_3 == {}
    var_4 = SshPubKeyFactCollector()
    var_4 = var_4.collect()
    assert var_4 == {}
    var_5 = SshPubKeyFactCollector()
    var_5 = var_5.collect()
    assert var_5 == {}
    var_6 = SshPubKeyFactCollector()
   

# Generated at 2022-06-25 00:46:44.636315
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    tf = SshPubKeyFactCollector()

# Generated at 2022-06-25 00:46:49.773743
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:46:57.284220
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
# print(ansible_facts)
#
# ansible_facts['ssh_host_key_dsa_public'] = 'dsa'
# ansible_facts['ssh_host_key_ed25519_public'] = 'ed25519'
# ansible_facts['ssh_host_key_ecdsa_public'] = 'ecdsa'
# ansible_facts['ssh_host_key_rsa_public'] = 'rsa'

# Generated at 2022-06-25 00:46:59.642799
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:47:04.539560
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_0.collect()


testcases_SshPubKeyFactCollector = [
    (
        test_case_0,
        [],
    ),
    (
        test_SshPubKeyFactCollector_collect,
        [],
    ),
]

# Generated at 2022-06-25 00:47:10.344808
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    # Check for facts
    assert var_0['ssh_host_key_rsa_public'] is not None
    assert var_0['ssh_host_key_dsa_public'] is not None
    assert var_0['ssh_host_key_ecdsa_public'] is not None
    assert var_0['ssh_host_key_ed25519_public'] is not None

# Generated at 2022-06-25 00:47:11.234154
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-25 00:47:12.554450
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # TODO: generate test for method collect of class SshPubKeyFactCollector
    assert True == True


# Generated at 2022-06-25 00:47:22.621637
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
  assert True


# Test cases might be used in local testing, but don't use them in
# Ansible PRs.


# ansible/test/units/module_utils/test_facts.py
#
# Test case for the facts.utils module
# (ansible/module_utils/facts/utils.py)
#
# Ansible is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Ansible is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#

# Generated at 2022-06-25 00:47:43.921886
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:52.709949
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
   ssh_pub_key_fact_collector = SshPubKeyFactCollector()

# Generated at 2022-06-25 00:47:56.332486
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert {} == ssh_pub_key_fact_collector.collect()

# Generated at 2022-06-25 00:48:00.441485
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector.ssh_pub_keys import SshPubKeyFactCollector
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    # Test lines below
    #
    # Used when testing this library locally
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:48:03.564137
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:48:07.469260
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert type(var_0) is dict
    assert len(var_0) == 0 or type(list(var_0)[0]) is str


# Generated at 2022-06-25 00:48:07.970130
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-25 00:48:09.331961
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var = SshPubKeyFactCollector()
    var.collect()

# Generated at 2022-06-25 00:48:11.703148
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()


# Generated at 2022-06-25 00:48:20.340991
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''
    Unit test for method collect of class SshPubKeyFactCollector
    '''
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_fact_collector_1, SshPubKeyFactCollector)
    assert issubclass(SshPubKeyFactCollector, BaseFactCollector)
    assert BaseFactCollector.collect(ssh_pub_key_fact_collector_1) is not None
    assert SshPubKeyFactCollector.collect(ssh_pub_key_fact_collector_1) is not None
    assert ssh_pub_key_fact_collector_1.collect() is not None

# Generated at 2022-06-25 00:49:06.570749
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:49:13.245169
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_facts_1 = ssh_pub_key_fact_collector_1.collect(None, None)
    var_2 = None
    if 'ssh_host_key_dsa_public' in ssh_pub_key_facts_1:
        var_2 = ssh_pub_key_facts_1['ssh_host_key_dsa_public']
    var_3 = None
    if 'ssh_host_key_rsa_public' in ssh_pub_key_facts_1:
        var_3 = ssh_pub_key_facts_1['ssh_host_key_rsa_public']
    var_4 = None

# Generated at 2022-06-25 00:49:22.069284
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Return variables
    var_1 = dict([('ssh_host_key_ecdsa_public', 'ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBJAnIUo+jfWKSgBxOQLZoHbv+q3OQ8X+jS7HGLIca3q3YJ2g1G4j4ebIqvHOHoSSmRgXt/Np7Cp+jDB/J7nGeUI='), ('ssh_host_key_ecdsa_public_keytype', 'ecdsa-sha2-nistp256')])
    # Assertion on object "ssh_pub_key_fact_collector_1

# Generated at 2022-06-25 00:49:26.723668
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:49:34.465587
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

# Generated at 2022-06-25 00:49:37.977317
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:49:41.830916
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Defined outside of method to ensure we have access to it in the test
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

    # Replace these calls with mock calls to the relevant functions
    var_0 = ssh_pub_key_fact_collector_0.collect()

    assert var_0 == {}


# Generated at 2022-06-25 00:49:45.817281
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()


# Generated at 2022-06-25 00:49:54.917834
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_9 = None
    var_8 = None
    var_1 = ssh_pub_key_fact_collector_1.collect(var_9, var_8)
    assert 'ssh_host_key_dsa_public' in var_1
    assert 'ssh_host_key_ecdsa_public_keytype' in var_1
    assert 'ssh_host_key_ed25519_public' in var_1
    assert 'ssh_host_key_ed25519_public_keytype' in var_1
    assert 'ssh_host_key_rsa_public' in var_1
    assert 'ssh_host_key_rsa_public_keytype' in var_1

# Generated at 2022-06-25 00:49:58.031927
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector.collect() #method should execute without errors
    assert var_0 is not None


# Generated at 2022-06-25 00:51:51.637784
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert ssh_pub_key_fact_collector_0._fact_ids == {'ssh_host_key_dsa_public', 'ssh_host_key_ed25519_public', 'ssh_host_key_rsa_public', 'ssh_host_pub_keys', 'ssh_host_key_ecdsa_public'}
    assert ssh_pub_key_fact_collector_0.name == 'ssh_pub_keys'
    assert var_0 == {}




# Generated at 2022-06-25 00:51:59.286652
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

# Generated at 2022-06-25 00:52:05.574903
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()

# Generated at 2022-06-25 00:52:10.105732
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    collected_facts = dict()
    test_module = dict()
    test_module['path'] = ['/bin', '/usr/bin']
    test_module['ansible_module_generated_fact'] = 'random_string'
    test_module['ansible_module_generated_fact_subdir'] = dict()
    test_module['ansible_module_generated_fact_subdir']['random_subdir_list'] = ['subdir_list_item_0', 'subdir_list_item_1']
    test_module['ansible_module_generated_fact_subdir']['random_subdir_dict'] = dict()

# Generated at 2022-06-25 00:52:14.362347
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Instantiate a SshPubKeyFactCollector object
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    # Invoke method collect of SshPubKeyFactCollector object
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert type(var_0) is dict

# Generated at 2022-06-25 00:52:19.589953
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

    assert isinstance(ssh_pub_key_fact_collector_0.collect(), dict)


# Generated at 2022-06-25 00:52:24.595239
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
    assert isinstance(var_1, dict)

# Generated at 2022-06-25 00:52:28.256467
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.collect() == {}

# Generated at 2022-06-25 00:52:30.356766
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test case 0 - empty path
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert(var_0 == {})

# Generated at 2022-06-25 00:52:36.780824
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    result = ssh_pub_key_fact_collector.collect()
    assert isinstance(result, (dict, type(None)))

