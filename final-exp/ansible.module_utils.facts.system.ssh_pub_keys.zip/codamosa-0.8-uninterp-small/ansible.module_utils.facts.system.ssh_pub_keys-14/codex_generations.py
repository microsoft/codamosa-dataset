

# Generated at 2022-06-25 00:44:18.629111
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:44:25.891517
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0._check_for_keydirs = lambda : True
    (ssh_pub_key_facts_0,_) = ssh_pub_key_fact_collector_0.collect()

    # test for equality of ssh_host_key_dsa_public_keytype fact
    ssh_host_key_dsa_public_keytype_0 = ssh_pub_key_facts_0['ssh_host_key_dsa_public_keytype']
    assert ssh_host_key_dsa_public_keytype_0 == 'ssh-dss'

    # test for equality of ssh_host_key_rsa_public fact
    ssh_host_key_rsa_public_0

# Generated at 2022-06-25 00:44:26.617411
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-25 00:44:32.722392
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_1.collect() == {}, "Failed to setup fixture for SshPubKeyFactCollector.collect()"
    # Test failed due to missing attributes
    pass


# Generated at 2022-06-25 00:44:43.370485
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    # AssertionError: Expected that 'SshPubKeyFactCollector.collect' would accept arguments
    # assert ssh_pub_key_fact_collector_0.collect() == None
#    assert ssh_pub_key_fact_collector_0.collect() == {'ssh_host_key_rsa_public_keytype': 'ssh-rsa', 'ssh_host_key_ecdsa_public': 'AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBI0IDGFXzjwU+E6Ux4lOkak4A4JLWcEb6gRuq3CqHpM0w

# Generated at 2022-06-25 00:44:47.876290
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    (ansible_facts) = {}
    test_case_0()
    test_object_0 = SshPubKeyFactCollector()
    test_object_0.collect(module=None, collected_facts=ansible_facts)


# Generated at 2022-06-25 00:44:54.927778
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ret = ssh_pub_key_fact_collector_0.collect()
    keys = ('ssh_host_key_dsa_public',
            'ssh_host_key_rsa_public',
            'ssh_host_key_ecdsa_public',
            'ssh_host_key_ed25519_public')

    for key in ret.keys():
        assert key in keys

# Generated at 2022-06-25 00:44:59.831585
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.collect() is not None

# Generated at 2022-06-25 00:45:10.101447
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # Create a mock module class to actually return a value
    class MockModule():
        def __init__(self):
            self.params = {}
    mockmodule = MockModule()

    # Return empty result
    mocked_return_value = {'ssh_host_key_rsa_public': 'AAAAB3NzaC1yc2EAAAABIwAAAQEAklOUpkDHrfHY17SbrmTIpNLTGK9Tjom/BWDSU'}
    retval = {'ansible_facts': {}}
    retval.update(ssh_pub_key_fact_collector.collect(mockmodule, retval['ansible_facts']))
    assert retval['ansible_facts'] == mocked_return_value

# Generated at 2022-06-25 00:45:13.605834
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_0.collect() == {}

# Generated at 2022-06-25 00:45:16.577999
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:45:26.970003
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    sshpubkey_fact_collector_0 = SshPubKeyFactCollector()
    sshpubkey_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:32.494626
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    if isinstance(ssh_pub_key_fact_collector_0, BaseFactCollector):
        result_0 = ssh_pub_key_fact_collector_0.collect()
    else:
        result_0 = None
    assert result_0 is not None

# Generated at 2022-06-25 00:45:37.262365
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    # Call method collect of class SshPubKeyFactCollector
    var_0.collect()
    var_1 = SshPubKeyFactCollector()
    # Call method collect of class SshPubKeyFactCollector
    var_1.collect()
    var_2 = SshPubKeyFactCollector()
    # Call method collect of class SshPubKeyFactCollector
    var_2.collect()
    var_3 = SshPubKeyFactCollector()
    # Call method collect of class SshPubKeyFactCollector
    var_3.collect()
    var_4 = SshPubKeyFactCollector()
    # Call method collect of class SshPubKeyFactCollector
    var_4.collect()
    var_5 = SshPubKeyFactCollector()


# Generated at 2022-06-25 00:45:37.841633
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert True == True

# Generated at 2022-06-25 00:45:40.958743
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
    assert isinstance(var_1, dict)


# Generated at 2022-06-25 00:45:44.125691
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    var = ssh_pub_key_fact_collector.collect()
    assert type(var) == dict

# Generated at 2022-06-25 00:45:46.406155
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    var = ssh_pub_key_fact_collector.collect()



# Generated at 2022-06-25 00:45:47.507953
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_case_0()
    test_case_1()

# Generated at 2022-06-25 00:45:53.946207
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_collector_0 = SshPubKeyFactCollector()
    fact_var_0 = ssh_pub_key_collector_0.collect()
    assert fact_var_0 is not None
    assert fact_var_0.__class__.__name__ == 'dict'
    assert fact_var_0 == {'ssh_host_key_dsa_public': None, 'ssh_host_key_rsa_public': None, 'ssh_host_key_ecdsa_public': None, 'ssh_host_key_ed25519_public': None}

# Generated at 2022-06-25 00:45:58.632805
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:46:04.529207
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_1 = SshPubKeyFactCollector()
    var_2 = var_1.collect()
    assert var_1._fact_ids == set(['ssh_host_key_dsa_public',
                                   'ssh_host_key_rsa_public',
                                   'ssh_host_key_ecdsa_public',
                                   'ssh_host_key_ed25519_public',
                                   'ssh_host_pub_keys'])

# Generated at 2022-06-25 00:46:07.992272
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()



# Generated at 2022-06-25 00:46:11.980973
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:46:15.167990
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert type(ssh_pub_key_fact_collector_0.collect()) is dict, \
        'a return value from collect() method should be dict'


# Generated at 2022-06-25 00:46:15.703853
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert not SshPubKeyFactCollector().collect()

# Generated at 2022-06-25 00:46:19.518789
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
    assert var_1 is not None, "SshPubKeyFactCollector.collect() did not return expected result"

# Generated at 2022-06-25 00:46:24.247589
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0.keys() == ['ssh_host_key_rsa_public', 'ssh_host_key_rsa_public_keytype']

# Generated at 2022-06-25 00:46:32.818612
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_1 = SshPubKeyFactCollector()
    var_1.collect()
    var_2 = SshPubKeyFactCollector()
    var_2.collect()
    var_3 = SshPubKeyFactCollector()
    var_3.collect()
    var_4 = SshPubKeyFactCollector()
    var_4.collect()
    var_5 = SshPubKeyFactCollector()
    var_5.collect()
    var_6 = SshPubKeyFactCollector()
    var_6.collect()
    var_7 = SshPubKeyFactCollector()
    var_7.collect()
    var_8 = SshPubKeyFactCollector()
    var_8.collect()
    var_9 = SshPubKeyFactCollector()
    var_9.collect()
   

# Generated at 2022-06-25 00:46:36.690725
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.collect() == ssh_pub_key_fact_collector.collect(None, None)


# Generated at 2022-06-25 00:46:46.364723
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # TODO
    pass

# Generated at 2022-06-25 00:46:49.730456
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:46:56.700418
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create the object under test
    ssh_pub_key_fact_collector_obj_0 = SshPubKeyFactCollector()
    # Call the method under test - caught all exceptions
    try:
        ansible_facts_0 = ssh_pub_key_fact_collector_obj_0.collect()
    except Exception:
        pass
    else:
        # Test the result
        assert ansible_facts_0 == var_0
    # Destroy the object under test
    del ssh_pub_key_fact_collector_obj_0

# Generated at 2022-06-25 00:46:59.185285
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:47:06.979428
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_fact_name = 'ssh_pub_keys'
    var_fact_ids = {'ssh_host_key_dsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_rsa_public', 'ssh_host_pub_keys', 'ssh_host_key_ed25519_public'}
    var_115 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:14.286599
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()

    var_1 = ssh_pub_key_fact_collector_1.collect()


# Generated at 2022-06-25 00:47:24.337506
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    if (var_0 != None):
        assert ('ssh_host_key_dsa_public' in var_0)
        assert ('ssh_host_key_ecdsa_public_keytype' in var_0)
        assert ('ssh_host_key_ecdsa_public' in var_0)
        assert ('ssh_host_key_ed25519_public_keytype' in var_0)
        assert ('ssh_host_key_ed25519_public' in var_0)
        assert ('ssh_host_key_rsa_public_keytype' in var_0)

# Generated at 2022-06-25 00:47:27.469406
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
	ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
	var_0 = ssh_pub_key_fact_collector_0.collect()
	assert var_0 == {}

# Generated at 2022-06-25 00:47:29.078640
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
    Test the method collect of class SshPubKeyFactCollector
    """
    test_case_0()

# Generated at 2022-06-25 00:47:38.084088
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    keydirs = ['/etc/ssh']
    algos = ['dsa', 'rsa', 'ecdsa', 'ed25519']

# Generated at 2022-06-25 00:47:56.894787
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_0.collect()

# Generated at 2022-06-25 00:47:59.341879
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_2 = SshPubKeyFactCollector()
    var_2 = ssh_pub_key_fact_collector_2.collect()


# Generated at 2022-06-25 00:48:06.837803
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # Test with a file that exists
    var = ssh_pub_key_fact_collector._get_file_content('/etc/os-release')
    assert var == get_file_content('/etc/os-release')

    # Test with a file that does not exist
    var = ssh_pub_key_fact_collector._get_file_content('/tmp/fake_file')
    assert var is None

# Generated at 2022-06-25 00:48:10.069311
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    var_1 = ssh_pub_key_fact_collector_0.collect()



# Generated at 2022-06-25 00:48:17.440413
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_cases = [test_case_0]
    failed_tests = [test_case for test_case in test_cases if test_case() == False]
    # method = SshPubKeyFactCollector.collect
    if len(failed_tests) > 0:
        # print error message for each failed test case
        [test_case() for test_case in failed_tests]
        return False
    return True

test_SshPubKeyFactCollector_collect()

# Generated at 2022-06-25 00:48:25.357964
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_1 = var_0.collect()

# Generated at 2022-06-25 00:48:27.852560
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector_0 = SshPubKeyFactCollector()
    fact_collector_0.collect()


# Generated at 2022-06-25 00:48:32.054579
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_1 = var_0.collect()

# Generated at 2022-06-25 00:48:37.116603
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector_0.collect()
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public_keytype' in ssh_pub_key_facts
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ed25519_public_keytype' in ssh_pub_key_facts


# Generated at 2022-06-25 00:48:42.876352
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:23.220530
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-25 00:49:27.023794
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert 'ssh_host_key_rsa_public' in SshPubKeyFactCollector().collect()

# Generated at 2022-06-25 00:49:29.502561
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:40.762972
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    for_class_SshPubKeyFactCollector = '''{}'''
    var_without_arguments = SshPubKeyFactCollector()
    var_with_arguments = SshPubKeyFactCollector(module=None, collected_facts=None)
    for_class_SshPubKeyFactCollector = '''{}'''
    var_with_any_arguments = SshPubKeyFactCollector(module='module_value', collected_facts='collected_facts_value')
    #26
    assert var_without_arguments.collect() == eval(for_class_SshPubKeyFactCollector)
    #27
    assert var_with_arguments.collect() == eval(for_class_SshPubKeyFactCollector)
    #28
    assert var_with_any_arguments.collect()

# Generated at 2022-06-25 00:49:50.366513
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create an instance of SshPubKeyFactCollector
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

    # Invoke method collect of class SshPubKeyFactCollector
    # assert return type
    ssh_pub_key_facts = ssh_pub_key_fact_collector_0.collect()
    assert isinstance(ssh_pub_key_facts, dict)

    # assert keys
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts


# Generated at 2022-06-25 00:49:51.384965
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_0.collect()

# Generated at 2022-06-25 00:49:57.828443
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()

# Generated at 2022-06-25 00:50:03.084743
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_1 = SshPubKeyFactCollector()
    ssh_pub_key_facts = var_1.collect()

# Generated at 2022-06-25 00:50:08.020383
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:50:13.186734
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:51:52.645652
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    for foo in [0]:
        try:
            test_case_0()
        except Exception as e:
            print('Exception: {0}'.format(e))
            assert False
            

# Generated at 2022-06-25 00:51:54.392165
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert len(var_0) == 4

# Generated at 2022-06-25 00:52:03.205487
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0 is not None and isinstance(var_0, dict), 'Return value for collect of SshPubKeyFactCollector should be type dict'
    assert 'ssh_host_pub_keys' in var_0, 'ssh_host_pub_keys' not in var_0
    assert 'ssh_host_key_dsa_public' in var_0, 'ssh_host_key_dsa_public' not in var_0
    assert 'ssh_host_key_rsa_public' in var_0, 'ssh_host_key_rsa_public' not in var_0

# Generated at 2022-06-25 00:52:09.870413
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0 == {'ssh_host_key_dsa_public': 'ssh-dss',
                     'ssh_host_key_ecdsa_public': 'ecdsa-sha2-nistp256',
                     'ssh_host_key_ed25519_public': 'ssh-ed25519',
                     'ssh_host_key_rsa_public': 'ssh-rsa'}

# Generated at 2022-06-25 00:52:15.009881
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0.keys() == set(['ssh_host_key_ed25519_public', 'ssh_host_key_rsa_public', 'ssh_host_key_dsa_public', 'ssh_host_key_ecdsa_public'])

# Generated at 2022-06-25 00:52:19.905029
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    var = ssh_pub_key_fact_collector.collect()
    assert isinstance(var, dict) or var is None


# Generated at 2022-06-25 00:52:23.432409
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_fact_collector = SshPubKeyFactCollector()
    var_0 = var_fact_collector.collect()



# Generated at 2022-06-25 00:52:28.378607
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:52:31.110667
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert(len(ssh_pub_key_fact_collector_0._fact_ids) == 5)
    assert(len(var_0) == 5)

# Generated at 2022-06-25 00:52:39.221347
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector = SshPubKeyFactCollector()
    facts = fact_collector.collect()

    # Check the non-existence of key facts
    assert facts.get('ssh_host_key_dsa_public') is None
    assert facts.get('ssh_host_key_rsa_public') is None
    assert facts.get('ssh_host_key_ecdsa_public') is None
    assert facts.get('ssh_host_key_ed25519_public') is None
    assert facts.get('ssh_host_key_rsa_public_keytype') is None

