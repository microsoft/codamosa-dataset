

# Generated at 2022-06-25 00:44:16.037549
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    collected_facts = dict()
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect(
        module=None, collected_facts=collected_facts)
    assert ssh_pub_key_facts['ssh_host_key_ed25519_public'] == 'AAAA...'

# Generated at 2022-06-25 00:44:21.097811
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_facts_1 = ssh_pub_key_fact_collector_1.collect()
    assert type(ssh_pub_key_facts_1) == dict
    assert len(ssh_pub_key_facts_1) > 0


# Generated at 2022-06-25 00:44:31.793669
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:44:35.851532
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert type(ssh_pub_key_fact_collector_0.collect()) == dict

# Generated at 2022-06-25 00:44:40.703914
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test when get_file_content return None and function works correctly
    current_key_file = '/etc/ssh-keygen.yml'
    current_content = None
    result = SshPubKeyFactCollector.collect(current_key_file,current_content)
    assert result is None


# Generated at 2022-06-25 00:44:46.561567
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()

    ssh_pub_key_facts_1 = ssh_pub_key_fact_collector_1.collect()
    assert (ssh_pub_key_facts_1 is not None)

# Generated at 2022-06-25 00:44:48.295938
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Testing with a non-existent key
    ssh_pub_key_fact_collector_2 = SshPubKeyFactCollector()
    assert (ssh_pub_key_fact_collector_2.collect() == {})

# Generated at 2022-06-25 00:44:59.292069
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''
    Test normal case when key is present
    '''
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector_0.collect()
    assert ('ssh_host_key_dsa_public' in ssh_pub_key_facts)
    assert ('ssh_host_key_rsa_public' in ssh_pub_key_facts)
    assert ('ssh_host_key_ecdsa_public' in ssh_pub_key_facts)
    assert ('ssh_host_key_ed25519_public' in ssh_pub_key_facts)
    assert ('ssh_host_key_dsa_public_keytype' in ssh_pub_key_facts)

# Generated at 2022-06-25 00:45:01.568524
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_0.collect() is not None


# Generated at 2022-06-25 00:45:06.378197
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:14.918810
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    facts_dict_0 = {}
    assert_equals(ssh_pub_key_fact_collector_0.collect(module=None, collected_facts=facts_dict_0), {})

# Generated at 2022-06-25 00:45:25.422532
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_2 = SshPubKeyFactCollector()

# Generated at 2022-06-25 00:45:30.113123
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    collected_ssh_pub_key_facts = ssh_pub_key_fact_collector_1.collect()
    assert (collected_ssh_pub_key_facts is not None)
   

# Generated at 2022-06-25 00:45:30.652247
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-25 00:45:37.756079
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    response = ssh_pub_key_fact_collector.collect()
    assert isinstance(response, dict)

# Generated at 2022-06-25 00:45:46.785136
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    collected_facts = dict()
    ansible_module = dict()
    ansible_module['ansible_architecture'] = "x86_64"
    ansible_module['ansible_os_family'] = "RedHat"
    ansible_module['ansible_distribution'] = "CentOS"
    ansible_module['ansible_distribution_version'] = "7.0.1406"
    ansible_module['ansible_distribution_release'] = "Core"
    ansible_module['ansible_distribution_major_version'] = "7"
    ansible_module['ansible_system'] = "Linux"
    ansible_module['ansible_pkg_mgr'] = "yum"
   

# Generated at 2022-06-25 00:45:48.754777
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_1.collect()

# Generated at 2022-06-25 00:45:55.004097
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test case data
    test_case = {
        'data': {},
        'expected': {},
        'result': {}
    }

    # Set up object
    ssh_pub_key_fact_collector_obj = SshPubKeyFactCollector()

    # Run test case
    ssh_pub_key_fact_collector_obj.collect(test_case['data'], test_case['result'])

    # Compare test case data to expected data
    assert test_case['result'] == test_case['expected']



# Generated at 2022-06-25 00:45:58.435317
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    collected_facts_result = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:59.190371
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # empty
    assert True

# Generated at 2022-06-25 00:46:06.849838
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:46:08.924457
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:46:12.613232
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import pytest
    test_cases = [
        (0, ),
    ]
    for index, test_case in enumerate(test_cases):
        yield eval(test_case[0])

# Generated at 2022-06-25 00:46:20.567409
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    collected_facts_1 = {}
    ssh_pub_key_facts_1 = ssh_pub_key_fact_collector_1.collect(collected_facts_1)
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts_1
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts_1
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts_1
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_facts_1
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts_1

# Generated at 2022-06-25 00:46:29.523265
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    instance = SshPubKeyFactCollector()

# Generated at 2022-06-25 00:46:33.957208
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

    # Test for SSH host keys fact collection fallback.
    # FIXME: Refactor code to be able to test this code path in isolation.

    # Test for SSH host keys fact collection fallback.

    # Test for SSH host keys fact collection fallback.

    # Test for SSH host keys fact collection fallback.


# Generated at 2022-06-25 00:46:39.646734
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_1 = SshPubKeyFactCollector()
    var_2 = None
    var_3 = None
    var_4 = SshPubKeyFactCollector()
    var_5 = None
    from ansible.module_utils.facts.utils import get_file_content
    var_6 = get_file_content('test_file_0')
    class get_file_content_object:
        def __init__(self):
            self.var_0 = var_6
    var_7 = get_file_content_object()
    var_8 = get_file_content('test_file_1')
    class get_file_content_object:
        def __init__(self):
            self.var_0 = var_8
    var_9 = get_file_content_object()

# Generated at 2022-06-25 00:46:44.910422
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()

# Generated at 2022-06-25 00:46:46.093380
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_1 = var_0.collect()

    assert var_1 == {}

# Generated at 2022-06-25 00:46:47.497527
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:04.368446
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Instantiate a instance of class SshPubKeyFactCollector
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    # Setup arguments and parse return value
    results = ssh_pub_key_fact_collector.collect()
    # Verify the result
    assert results == {
        'ssh_host_key_dsa_public': 'ssh-dss',
        'ssh_host_key_rsa_public': 'ssh-rsa',
    } or results == {
        'ssh_host_key_ed25519_public': 'ssh-ed25',
        'ssh_host_key_ecdsa_public': 'ecdsa-sha2-nistp256',
    } or results == {}

# Generated at 2022-06-25 00:47:07.301693
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect(module='module_0', collected_facts='collected_facts_0')

# Generated at 2022-06-25 00:47:11.837303
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector.collect = MagicMock()

# Generated at 2022-06-25 00:47:14.194782
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()


# Generated at 2022-06-25 00:47:21.635283
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # initialize
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # test with empty dict
    collected_facts = dict()
    result = ssh_pub_key_fact_collector.collect(collected_facts=collected_facts)
    assert result == dict()

    # test with extra params
    collected_facts = dict()
    result = ssh_pub_key_fact_collector.collect(foo='bar', collected_facts=collected_facts)
    assert result == dict()

# Generated at 2022-06-25 00:47:24.458385
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
    assert var_1 == {}


# Generated at 2022-06-25 00:47:26.458619
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:28.240625
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:37.340899
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Mock class for BaseFactCollector
    class BaseFactCollector_Mock:

        # Mock method __enter__ for class BaseFactCollector
        def __enter__(self):
            return None

        # Mock method __exit__ for class BaseFactCollector
        def __exit__(self):
            return None

        # Mock method collect for class BaseFactCollector
        def collect(self, module=None, collected_facts=None):
            return "ssh_pub_keys"

    # Mock class for get_file_content
    class get_file_content_Mock:

        # Mock method __enter__ for class get_file_content
        def __enter__(self):
            return None

        # Mock method __exit__ for class get_file_content
        def __exit__(self):
            return None

        # Mock method get_

# Generated at 2022-06-25 00:47:42.530020
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    module_0 = AnsibleModule(argument_spec={})
    collected_facts = {}
    # pass
    result = ssh_pub_key_fact_collector_0.collect(module=module_0, collected_facts=collected_facts)
    print(result)
    assert result == {}


# Generated at 2022-06-25 00:48:03.787233
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
    assert (var_1 is not None)

# Generated at 2022-06-25 00:48:06.124615
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:48:07.586102
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_1 = SshPubKeyFactCollector()
    var_1.collect()

# Generated at 2022-06-25 00:48:08.392461
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:48:09.332339
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:48:16.088030
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert ssh_pub_key_fact_collector_0.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector_0._fact_ids == {'ssh_host_pub_keys',
                                                      'ssh_host_key_dsa_public',
                                                      'ssh_host_key_rsa_public',
                                                      'ssh_host_key_ecdsa_public',
                                                      'ssh_host_key_ed25519_public'}

# Generated at 2022-06-25 00:48:21.863605
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:48:26.351328
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Check if the method returns a dictionary
    var_1 = SshPubKeyFactCollector.collect(ssh_pub_key_fact_collector_0)
    assert isinstance(var_1, dict)

# Generated at 2022-06-25 00:48:27.219346
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test Case 0:
    test_case_0()

# Generated at 2022-06-25 00:48:29.511811
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test code:
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:08.794401
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    var = ssh_pub_key_fact_collector.collect()


# Generated at 2022-06-25 00:49:09.214627
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
  pass

# Generated at 2022-06-25 00:49:11.631135
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    result_1 = ssh_pub_key_fact_collector_1.collect()
    assert result_1 == {}

# Generated at 2022-06-25 00:49:21.927886
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()

# Generated at 2022-06-25 00:49:25.589250
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect(collected_facts=None)
    var_1 = ssh_pub_key_fact_collector_0.collect(collected_facts=None)
    assert var_0 == var_1
    var_2 = ssh_pub_key_fact_collector_0.collect(collected_facts=None)
    assert var_2 == var_1
    var_3 = ssh_pub_key_fact_collector_0.collect(collected_facts=None)
    assert var_3 == var_1
    test_case_0()

# Generated at 2022-06-25 00:49:27.447435
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
    assert var_1 == {}



# Generated at 2022-06-25 00:49:34.878168
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:49:38.737525
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_fact_collector.collect(), dict)

# testing if class SshPubKeyFactCollector has attribute 'name'

# Generated at 2022-06-25 00:49:46.091086
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_0.collect()
    assert var_0 == var_1

# Generated at 2022-06-25 00:49:47.814415
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    arg_0 = None
    arg_1 = None
    var_0 = ssh_pub_key_fact_collector_0.collect(arg_0, arg_1)

# Generated at 2022-06-25 00:51:23.012381
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0 != None, "var_0 is None"


# Generated at 2022-06-25 00:51:27.028240
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()

# Generated at 2022-06-25 00:51:32.592796
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:51:34.085241
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:51:40.499441
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()

# Generated at 2022-06-25 00:51:41.700090
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Run tests from here
    test_case_0()
    # Done

# Generated at 2022-06-25 00:51:46.593841
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_1 = var_0.collect()

    assert 'ssh_host_key_rsa_public' in var_1
    assert 'ssh_host_key_dsa_public' not in var_1
    assert len(var_1.keys()) == 2



# Generated at 2022-06-25 00:51:48.345988
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector = SshPubKeyFactCollector()
    fact_collector.collect()

# Generated at 2022-06-25 00:51:57.730107
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:52:00.033314
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0 == {}
