

# Generated at 2022-06-25 00:44:24.302369
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:44:26.001941
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # Test with correct argument from ansible
    collect_return = SshPubKeyFactCollector.collect()

    assert isinstance(collect_return, dict)

# Generated at 2022-06-25 00:44:31.392238
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    dict_0 = {}
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector(dict_0)
    ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:44:38.057281
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test 1
    dict_1 = {}
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector(dict_1)
    module_1 = None
    collected_facts_1 = None
    # Execute the function under test.
    ssh_pub_key_fact_collector_1.collect(module_1, collected_facts_1)

# Generated at 2022-06-25 00:44:42.917466
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    dict_0 = {}
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector(dict_0)
    expected = {}
    result = ssh_pub_key_fact_collector_0.collect()
    assert result == expected


# Generated at 2022-06-25 00:44:52.956711
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    dict_0 = {}
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector(dict_0)

# Generated at 2022-06-25 00:44:54.574759
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    dict_0 = {}
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector(dict_0)


# Generated at 2022-06-25 00:45:00.000622
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    dict_0 = {}
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector(dict_0)
    module_0 = object()
    collected_facts_0 = object()

    # Call method collect on SshPubKeyFactCollector object
    ssh_pub_key_facts_0 = ssh_pub_key_fact_collector_0.collect(module_0, collected_facts_0)

    # Check if it returns a dictionary
    assert type(ssh_pub_key_facts_0) is dict

# Generated at 2022-06-25 00:45:01.705246
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    dict_0 = {}
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector(dict_0)

# Generated at 2022-06-25 00:45:04.062955
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    dict_1 = {}
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector(dict_1)
    assert {} == ssh_pub_key_fact_collector_1.collect()


# Generated at 2022-06-25 00:45:13.481616
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts_0 = ssh_pub_key_fact_collector_0.collect()
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts_0.keys()

# Generated at 2022-06-25 00:45:17.291618
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    result = ssh_pub_key_fact_collector_1.collect()
    print("test_SshPubKeyFactCollector_collect() = " + str(result))


# Generated at 2022-06-25 00:45:25.682824
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    collected_facts = ssh_pub_key_fact_collector_0.collect()

    assert(collected_facts['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa')
    assert(collected_facts['ssh_host_key_ecdsa_public_keytype'] == 'ecdsa-sha2-nistp256')
    assert(collected_facts['ssh_host_key_ed25519_public_keytype'] == 'ssh-ed25519')

# Generated at 2022-06-25 00:45:35.072912
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:45:38.781070
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    result = ssh_pub_key_fact_collector_0.collect()
    assert result == {}


# Generated at 2022-06-25 00:45:47.647629
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    # Test with a single .pub file(/etc/ssh/ssh_host_dsa_key.pub)
    ssh_pub_key_facts_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:54.727863
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    facts_dict = dict()
    ansible_module = dict()
    ansible_module['params'] = dict()
    ansible_module['params']['gather_subset'] = []
    ansible_module['params']['gather_timeout'] = 10
    ansible_module['params']['filter'] = dict()
    ansible_module['params']['filter']['*'] = False
    facts_dict = ssh_pub_key_fact_collector_0.collect(ansible_module, facts_dict)

# Generated at 2022-06-25 00:45:56.097263
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.collect() == {}

# Generated at 2022-06-25 00:45:59.400776
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    result = ssh_pub_key_fact_collector_1.collect()
    assert result == {}



# Generated at 2022-06-25 00:46:02.183322
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # Create a class object
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    # Call the method
    result = ssh_pub_key_fact_collector_1.collect()
    # Assert resulting output
    assert result == {}

test_case_0()
test_SshPubKeyFactCollector_collect()

# Generated at 2022-06-25 00:46:12.611213
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    result = ssh_pub_key_fact_collector.collect()
    assert type(result['ssh_host_key_dsa_public']) is str
    assert type(result['ssh_host_key_rsa_public']) is str
    assert type(result['ssh_host_key_ecdsa_public']) is str
    assert type(result['ssh_host_key_ed25519_public']) is str
    assert type(result['ssh_host_key_dsa_public_keytype']) is str
    assert type(result['ssh_host_key_rsa_public_keytype']) is str
    assert type(result['ssh_host_key_ecdsa_public_keytype']) is str

# Generated at 2022-06-25 00:46:15.406260
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
        ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
        result = ssh_pub_key_fact_collector_0.collect()
        assert(result == {'changed': False, 'failed': False})

# Generated at 2022-06-25 00:46:18.371591
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    SshPubKeyFactCollector_collect_obj = SshPubKeyFactCollector()
    # Check if the method 'collect' of class 'SshPubKeyFactCollector' is working as expected
    assert (SshPubKeyFactCollector_collect_obj.collect() == {})

# Generated at 2022-06-25 00:46:22.934656
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    assert len(ssh_pub_key_fact_collector_1._fact_ids)==5
    assert len(ssh_pub_key_fact_collector_1.collect()) == 0


# Generated at 2022-06-25 00:46:31.601451
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    facts = ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:46:33.513896
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_1.collect()

# Generated at 2022-06-25 00:46:38.730843
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    s = SshPubKeyFactCollector()
    f = s.collect()
    assert 'ssh_host_key_dsa_public' in f and 'ssh_host_key_rsa_public' in f \
        and 'ssh_host_key_ecdsa_public' in f and 'ssh_host_key_ed25519_public' in f


# Generated at 2022-06-25 00:46:40.920794
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_1.collect()

# Generated at 2022-06-25 00:46:48.321090
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.collect() is not None

# Generated at 2022-06-25 00:46:54.924544
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Case 0. Check that all facts returned by this collector are in fact_ids.
    ssh_pub_key_facts_0 = SshPubKeyFactCollector().collect()
    assert ssh_pub_key_facts_0 is not None
    assert set(ssh_pub_key_facts_0.keys()) <= SshPubKeyFactCollector._fact_ids

if __name__ == '__main__':
    test_case_0()
    test_SshPubKeyFactCollector_collect()

# Generated at 2022-06-25 00:47:05.062838
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()



# Generated at 2022-06-25 00:47:08.005275
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()

    # set up test values for method collect
    module = None
    collected_facts = None
    ssh_pub_key_fact_collector_1.collect(module, collected_facts)

# Generated at 2022-06-25 00:47:14.975315
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()

    # check calling collect with no arguments
    ssh_pub_key_facts = ssh_pub_key_fact_collector_1.collect()

    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_facts

# Generated at 2022-06-25 00:47:16.673225
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:47:25.496225
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    if sys.version_info >= (2, 7):
        ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
        ansible_module_0.params = {}
        ansible_module_0.params['test'] = None
        ansible_module_0.params['gather_subset'] = ['all']
        ansible_module_0.params['filter'] = '*'
        ansible_facts = {}
        ansible_facts['ansible_local'] = {}
        ansible_facts['ansible_local']['my_fact'] = False
        ssh_pub_key_facts = ssh_pub_key_fact_collector_0.collect(ansible_module_0, ansible_facts)

# Generated at 2022-06-25 00:47:34.603403
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    fact_subset = dict()
    fact_subset['ssh_host_key_dsa_public'] = 'aaaaaaa'
    fact_subset['ssh_host_key_rsa_public'] = 'bbbbbbb'
    fact_subset['ssh_host_key_ecdsa_public'] = 'ccccccc'
    fact_subset['ssh_host_key_ed25519_public'] = 'ddddddd'
    ret = ssh_pub_key_fact_collector_0.collect(collected_facts=fact_subset)
    assert ret == dict()

    fact_subset = dict()
    fact_subset['ssh_host_key_dsa_public'] = 'aaaaaaa'

# Generated at 2022-06-25 00:47:41.951804
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    list_of_ssh_pub_key_facts = list(ssh_pub_key_fact_collector_0.collect())
    assert 'ssh_host_key_dsa_public' in list_of_ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public' in list_of_ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public' in list_of_ssh_pub_key_facts
    assert 'ssh_host_key_ed25519_public' in list_of_ssh_pub_key_facts

# Generated at 2022-06-25 00:47:44.076774
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # Invoke method collect of SshPubKeyFactCollector
    _result = SshPubKeyFactCollector.collect()

    assert _result is not None


# Generated at 2022-06-25 00:47:52.839438
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    collected_facts = {}
    collected_facts['ssh_host_key_dsa_public'] = 'AAAAB3NzaC1kc3MAAACBAMhWwgEZ7G5Z3cq3PVqWl'
    collected_facts['ssh_host_key_dsa_public_keytype'] = 'ssh-dss'
    collected_facts['ssh_host_key_ecdsa_public'] = 'AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBImz'

# Generated at 2022-06-25 00:47:57.840028
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    empty_dict = {}
    assert ssh_pub_key_fact_collector_0.collect(module=None, collected_facts=empty_dict) == {}


# Generated at 2022-06-25 00:48:19.232939
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    # Read ssh keys from file
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()
    # Verify if empty
    assert(not ssh_pub_key_facts)

# Generated at 2022-06-25 00:48:23.570061
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    host_key_facts_data = ssh_pub_key_fact_collector.collect()
    assert isinstance(host_key_facts_data, dict)
    assert host_key_facts_data != {}

# Generated at 2022-06-25 00:48:33.383327
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    result = ssh_pub_key_fact_collector.collect()

    # assert if the ssh_host_key_dsa_public_keytype exists in the result
    assert isinstance(result['ssh_host_key_dsa_public_keytype'], str)
    assert result['ssh_host_key_dsa_public_keytype'] is not None

    # assert if the ssh_host_key_ecdsa_public exists in the result
    assert isinstance(result['ssh_host_key_ecdsa_public'], str)
    assert result['ssh_host_key_ecdsa_public'] is not None

    # assert if the ssh_host_key_ecdsa_public_keytype exists in the result

# Generated at 2022-06-25 00:48:40.023562
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_0.collect() == {}
    assert ssh_pub_key_fact_collector_0.collect(collected_facts={}) == {}

# Generated at 2022-06-25 00:48:42.024427
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector_1.collect()
    assert len(ssh_pub_key_facts) > 0

# Generated at 2022-06-25 00:48:47.333939
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:48:48.631107
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-25 00:48:49.235067
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass


# Generated at 2022-06-25 00:48:54.499188
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_0.collect() == None


# Generated at 2022-06-25 00:48:55.858572
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_cases = [test_case_0()]

    for test_case in test_cases:
        test_case.collect()

# Generated at 2022-06-25 00:49:22.747007
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:23.460600
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:49:27.413405
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fc_inst_0 = SshPubKeyFactCollector()
    var_1 = fc_inst_0.collect()
    print(var_1)

# Generated at 2022-06-25 00:49:34.847967
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:49:43.447777
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    var = ssh_pub_key_fact_collector.collect()
    assert var is not None
    if var is not None:
        assert type(var) is dict
        assert 'ssh_host_key_ed25519_public_keytype' in var
        assert 'ssh_host_key_ed25519_public_keytype' in var
        assert 'ssh_host_key_ed25519_public' in var
        assert 'ssh_host_key_rsa_public_keytype' in var
        assert 'ssh_host_key_rsa_public' in var
        assert 'ssh_host_key_ecdsa_public' in var
        assert 'ssh_host_key_ecdsa_public_keytype' in var
       

# Generated at 2022-06-25 00:49:48.572115
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:49:55.457404
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:55.868669
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert True == True

# Generated at 2022-06-25 00:49:59.047268
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_1.collect()
    assert isinstance(var_0, dict)
    assert len(var_0) == 0


# Generated at 2022-06-25 00:50:00.418752
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:50:51.418494
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # No exception raised.
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()



# Generated at 2022-06-25 00:50:53.870571
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    my_var = SshPubKeyFactCollector()
    my_var_2 = my_var.collect()

# Generated at 2022-06-25 00:50:57.972034
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect(module=None, collected_facts=None)
    assert var_0 == {}

# Generated at 2022-06-25 00:51:00.323143
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:51:09.921837
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Declaring a variable for SshPubKeyFactCollector
    sshPubKeyFactCollector = SshPubKeyFactCollector()
    # Declaring a variable for a dictionary

# Generated at 2022-06-25 00:51:15.834863
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    myvar_1 = None
    myvar_1 = ssh_pub_key_fact_collector_1.collect(module=myvar_1, collected_facts=myvar_1)
    assert 'ssh_host_key_rsa_public_keytype' in myvar_1

# Generated at 2022-06-25 00:51:20.439427
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 00:51:21.868407
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.collect() == {}

# Generated at 2022-06-25 00:51:27.600847
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0 == {}

# Generated at 2022-06-25 00:51:37.686774
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    collected_facts = {}
    collected_facts['ansible_architecture'] = {'sample_ansible_architecture_fact': 'i386'}

    # Add a sample fact entry in the collected fact dictionary
    fact_dictionary = {'sample_fact_collector_fact': 'sample_fact'}

    # following is the expected output after adding to the collected facts

# Generated at 2022-06-25 00:53:13.492629
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector__return_value = SshPubKeyFactCollector().collect()

    assert 'ssh_host_key_rsa_public_keytype' in fact_collector__return_value
    assert 'ssh_host_key_dsa_public' in fact_collector__return_value


# Generated at 2022-06-25 00:53:15.989963
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    result = ssh_pub_key_fact_collector.collect()

    assert 'ssh_host_key_rsa_public' in result
    assert 'ssh_host_key_rsa_public_keytype' in result


# Generated at 2022-06-25 00:53:19.045717
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.collect()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:53:22.780508
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0 is not None

# Generated at 2022-06-25 00:53:27.283859
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:53:29.452260
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    # Setting up mock/fake values
    collected_facts_1 = dict()
    # Calling method collect with mocked arguments
    ssh_pub_key_fact_collector_1.collect(collected_facts=collected_facts_1)

# Generated at 2022-06-25 00:53:35.015531
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    collected_facts = {}
    collected_facts['ssh_host_dsa_key_filename'] = 'ssh_host_dsa_key'
    collected_facts['ssh_host_rsa_key_filename'] = 'ssh_host_rsa_key'
    collected_facts['ssh_host_ecdsa_key_filename'] = 'ssh_host_ecdsa_key'
    collected_facts['ssh_host_ed25519_key_filename'] = 'ssh_host_ed25519_key'
    collected_facts['ssh_host_dsa_key_file'] = 'ssh_host_dsa_key.pub'

# Generated at 2022-06-25 00:53:36.868788
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    x_0 = ssh_pub_key_fact_collector_1.collect()
    assert x_0 == {}


# Generated at 2022-06-25 00:53:42.049406
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create an instance of the SshPubKeyFactCollector class with default
    # values
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

    # Call method collect
    var_0 = ssh_pub_key_fact_collector_0.collect()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 00:53:45.544297
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_0.collect()
    assert var_1 == {}

