

# Generated at 2022-06-25 00:44:21.771329
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_1._parse_ssh_key_file = lambda x: ('keytype', 'keydata')
    ssh_pub_key_facts = ssh_pub_key_fact_collector_1.collect()

    assert isinstance(ssh_pub_key_facts, dict) is True
    for fact, value in ssh_pub_key_facts.items():
        assert value == 'keydata'

# Generated at 2022-06-25 00:44:23.617623
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:44:33.992387
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

# Generated at 2022-06-25 00:44:43.433731
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

# Generated at 2022-06-25 00:44:51.154909
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    collected_facts = ssh_pub_key_fact_collector.collect()
    assert collected_facts is not None
    assert 'ssh_host_key_rsa_public' in collected_facts.keys()
    assert 'ssh_host_key_rsa_public_keytype' in collected_facts.keys()
    assert 'ssh_host_key_dsa_public' in collected_facts.keys()
    assert 'ssh_host_key_dsa_public_keytype' in collected_facts.keys()


# Generated at 2022-06-25 00:45:00.228085
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    SshPubKeyFactCollector_collect_instance = SshPubKeyFactCollector()
    test_case_0_ssh_pub_key_facts = ssh_pub_key_fact_collector_0.collect(module=None, collected_facts=None)
    assert len(test_case_0_ssh_pub_key_facts["ssh_host_key_ecdsa_public"]) == 66
    assert len(test_case_0_ssh_pub_key_facts["ssh_host_key_ed25519_public"]) == 54
    assert len(test_case_0_ssh_pub_key_facts["ssh_host_key_rsa_public"]) == 394
    assert len(test_case_0_ssh_pub_key_facts["ssh_host_key_dsa_public"]) == 382

# Generated at 2022-06-25 00:45:05.371762
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:45:09.767608
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert 'ssh_host_key_ed25519_public_keytype' not in ssh_pub_key_fact_collector_0.collect()
    assert 'ssh_host_key_ecdsa_public_keytype' in ssh_pub_key_fact_collector_0.collect()
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_fact_collector_0.collect()
    assert 'ssh_host_key_dsa_public_keytype' in ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:15.417217
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Access attributes of class SshPubKeyFactCollector
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts_0 = SshPubKeyFactCollector.collect(ssh_pub_key_fact_collector_0)
    # Check values of attributes of class SshPubKeyFactCollector
    assert ssh_pub_key_fact_collector_0.name == 'ssh_pub_keys'

# Generated at 2022-06-25 00:45:25.809771
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    res = ssh_pub_key_fact_collector_1.collect()


# Generated at 2022-06-25 00:45:32.990681
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    facts = ssh_pub_key_fact_collector_0.collect()
    # Test assertion should be updated to make sure we are getting the right
    # keys back
    assert facts

# Generated at 2022-06-25 00:45:37.821459
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector_1.collect()

# Generated at 2022-06-25 00:45:46.822395
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
    1. Create a SshPubKeyFactCollector
    2. Use the collect method to retrieve ssh key facts.
    3. Assert that the results are as expected.
    """

    # Creae a SshPubKeyFactCollector
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    # Assert that _fact_ids is set to the expected value
    expected_fact_ids = set(['ssh_host_pub_keys',
                             'ssh_host_key_dsa_public',
                             'ssh_host_key_rsa_public',
                             'ssh_host_key_ecdsa_public',
                             'ssh_host_key_ed25519_public'])
    assert ssh_pub_key_fact_collector._fact_ids == expected_fact_

# Generated at 2022-06-25 00:45:48.055498
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert False


# Generated at 2022-06-25 00:45:51.656858
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_facts_0 = ssh_pub_key_fact_collector_0.collect()
    assert type(ssh_pub_key_facts_0) is dict

# Generated at 2022-06-25 00:45:54.685674
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    obj = SshPubKeyFactCollector()
    collected_facts = {'ssh_host_pub_keys': None}
    result = obj.collect(module=None, collected_facts=collected_facts)
    assert isinstance(result, dict)
    assert result == {}

# Generated at 2022-06-25 00:45:59.646485
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    results = ssh_pub_key_fact_collector.collect()
    assert results == {'ssh_host_key_ed25519_public': 'AAAAE2VjZHNhLXNoYTItbmlzdHAy',
                       'ssh_host_key_ed25519_public_keytype': 'ssh-ed25519'}

# Generated at 2022-06-25 00:46:02.888350
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_fact_collector_1.collect(), dict)


# Generated at 2022-06-25 00:46:11.402065
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:46:14.970861
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()
    assert isinstance(ssh_pub_key_facts, dict)


# Generated at 2022-06-25 00:46:28.301261
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # Declare mock values and variables
    mock_module = 0
    mock_collected_facts = 0

    # Declare test input data

# Generated at 2022-06-25 00:46:30.409198
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_1 = var_0.collect()
    assert (var_1 == '')

# Generated at 2022-06-25 00:46:37.328176
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Unit test for method collect of class SshPubKeyFactCollector
    # Ensure that ssh_pub_key_facts contains keys for each type of
    # ssh key file that is present
    var_1 = SshPubKeyFactCollector()

# Generated at 2022-06-25 00:46:38.164099
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:46:46.298915
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:46:52.350304
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var__ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    try:
        var__ssh_pub_key_fact_collector_0.collect()
    except Exception:
        var__err = True
        var__err_msg = str(traceback.format_exc())
    assert var__err == False
    assert var__err_msg == ''


# Generated at 2022-06-25 00:46:57.121794
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class Mock_module:
        pass
    mock_module = Mock_module()
    mock_module.params = {}
    mock_module.params['gather_subset'] = ['all']
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect(mock_module)

# Generated at 2022-06-25 00:47:05.453778
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:47:08.123263
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
    assert  var_1 is not None


# Generated at 2022-06-25 00:47:12.523507
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_var_0 = ssh_pub_key_fact_collector_0.collect(module=None)
    assert (ssh_pub_key_fact_collector_var_0['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa')


# Generated at 2022-06-25 00:47:28.116786
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Setup
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # Stub function get_file_content

# Generated at 2022-06-25 00:47:36.708588
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    (var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_7, var_8, var_9, var_10, var_11, var_12, var_13, var_14, var_15, var_16, var_17, var_18, var_19, var_20, var_21, var_22, var_23, var_24, var_25, var_26, var_27, var_28, var_29, var_30, var_31) = ssh_pub_key_fact_collector_0.collect(module=None, collected_facts=None)

# Generated at 2022-06-25 00:47:38.872803
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:44.302364
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    collected_facts = {}
    assert ssh_pub_key_fact_collector_0.collect(collected_facts=collected_facts) == {}
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_1.collect()


# Generated at 2022-06-25 00:47:53.046468
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_1 = SshPubKeyFactCollector()

    def mock_collect(self, module=None, collected_facts=None):
        algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')

        # list of directories to check for ssh keys
        # used in the order listed here, the first one with keys is used
        keydirs = ['/etc/ssh', '/etc/openssh', '/etc']

        for keydir in keydirs:
            for algo in algos:
                factname = 'ssh_host_key_%s_public' % algo
                if factname in self.ssh_host_pub_keys:
                    # a previous keydir was already successful, stop looking
                    # for keys
                    return self.ssh_host_pub_keys

# Generated at 2022-06-25 00:47:57.768612
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Testing the return value of method 'collect'
    var_0 = SshPubKeyFactCollector().collect()
    # Now var_0 is an object of type 'dict'
    assert type(var_0) is dict


# Generated at 2022-06-25 00:48:00.525430
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 00:48:10.033600
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockFactCollector(BaseFactCollector):
        _fact_ids = set(['test_fact1', 'test_fact2', 'test_fact3'])

        def collect(self, module=None, collected_facts=None):
            return dict(test_fact1=1, test_fact2=2, test_fact3=3)

    mock_fact_collector = MockFactCollector()

    class MockModule(object):
        pass

    mock_module = MockModule()

    mock_module.params = dict(gather_subset=[])
    assert mock_fact_collector.collect(mock_module) is None

    mock_module.params = dict(gather_subset=['!all'])
    assert mock_fact

# Generated at 2022-06-25 00:48:15.064143
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

    # Issue #11105: bypass unittest's deprecated assert methods
    try:
        assert(isinstance(ssh_pub_key_fact_collector_0.collect(), dict))
    except AssertionError:
        raise

    # Issue #11105: bypass unittest's deprecated assert methods
    try:
        assert(len(ssh_pub_key_fact_collector_0.collect()) >= 1)
    except AssertionError:
        raise



# Generated at 2022-06-25 00:48:19.046534
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_0.collect()
    assert var_1 is None

# Generated at 2022-06-25 00:48:44.331582
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert 'ssh_host_key_dsa_public' in var_0.keys()
    assert 'ssh_host_key_rsa_public' in var_0.keys()
    assert 'ssh_host_key_ecdsa_public' in var_0.keys()
    assert 'ssh_host_key_ed25519_public' in var_0.keys()
    assert 'ssh_host_key_dsa_public_keytype' in var_0.keys()
    assert 'ssh_host_key_rsa_public_keytype' in var_0.keys()

# Generated at 2022-06-25 00:48:48.200623
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:48:54.602487
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector_obj=SshPubKeyFactCollector()
    res=fact_collector_obj.collect()

# Generated at 2022-06-25 00:48:56.175590
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    var = ssh_pub_key_fact_collector.collect()


# Generated at 2022-06-25 00:49:01.041664
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
    assert var_1 == None


# Generated at 2022-06-25 00:49:03.467972
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_collect = ssh_pub_key_fact_collector.collect()
    assert ssh_pub_key_fact_collector_collect == {}


# Generated at 2022-06-25 00:49:05.302746
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:07.928404
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert var_0 == {}

# Generated at 2022-06-25 00:49:10.649124
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_0.collect()
    assert not (type(var_1) is dict)

# Generated at 2022-06-25 00:49:17.527221
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert not var_0


# Generated at 2022-06-25 00:49:53.787972
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_0.collect()

# check if methods exist in class

# Generated at 2022-06-25 00:50:01.578537
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0.keys() == ['ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ed25519_public', 'ssh_host_key_ecdsa_public']

# Generated at 2022-06-25 00:50:05.566831
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_fact_collector_0.collect(),
                      dict) == True


# Generated at 2022-06-25 00:50:06.710737
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector_0 = SshPubKeyFactCollector()
    fact_collector_0.collect()


# Generated at 2022-06-25 00:50:07.853350
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var = SshPubKeyFactCollector()
    assert isinstance(var.collect(), dict)


# Generated at 2022-06-25 00:50:13.089028
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:50:16.151441
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0.collect()



# Generated at 2022-06-25 00:50:18.296488
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0 == {}

# Generated at 2022-06-25 00:50:20.678804
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_1 = SshPubKeyFactCollector()
    var_2 = var_1.collect()
    assert isinstance(var_2, dict)



# Generated at 2022-06-25 00:50:26.042796
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    var = ssh_pub_key_fact_collector.collect()
    assert var == {'ssh_host_key_rsa_public_keytype': 'ssh-rsa', 'ssh_host_key_ecdsa_public': 'AAAAC3NzaC1lZDI1NTE5AAAAIHbgYaMg0i7xEUkvxuG7fikKi1zEfOqN0/uU6iNrn/Naa'}

# Generated at 2022-06-25 00:51:55.525391
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert var_0 == {}

# Generated at 2022-06-25 00:52:02.345005
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert 'ssh_host_key_dsa_public' in var_0
    assert 'ssh_host_key_rsa_public' in var_0
    assert 'ssh_host_key_ecdsa_public' in var_0
    assert 'ssh_host_key_ed25519_public' in var_0

# Generated at 2022-06-25 00:52:08.151155
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert 'ssh_host_pub_keys' in var_0


# Generated at 2022-06-25 00:52:13.522331
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # Test with different versions of python for coverage
    for _ in range(0, 4):
        assert ssh_pub_key_fact_collector.collect() is not None

# Generated at 2022-06-25 00:52:20.965672
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_0.name = None
    var_1 = SshPubKeyFactCollector()
    var_0.name = var_1.name
    var_1 = SshPubKeyFactCollector()
    var_0.name = var_1.name
    var_0.name = var_1.name
    var_0.name = var_1.name

# Generated at 2022-06-25 00:52:30.729119
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    var_1 = ssh_pub_key_fact_collector_0.collect()
    var_2 = ssh_pub_key_fact_collector_0.collect()
    var_3 = ssh_pub_key_fact_collector_0.collect()
    var_4 = ssh_pub_key_fact_collector_0.collect()
    var_5 = ssh_pub_key_fact_collector_0.collect()
    var_6 = ssh_pub_key_fact_collector_0.collect()
    var_7 = ssh_pub_key_fact_collector_0.collect()
    var_8 = ssh_pub

# Generated at 2022-06-25 00:52:34.262294
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    obj = SshPubKeyFactCollector()
    var_0 = obj.collect()
    assert type(var_0) == dict


# Generated at 2022-06-25 00:52:37.705761
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

    assert True

# Generated at 2022-06-25 00:52:46.546057
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:52:49.955955
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
    assert isinstance(var_1, dict)
    assert var_1 == {}