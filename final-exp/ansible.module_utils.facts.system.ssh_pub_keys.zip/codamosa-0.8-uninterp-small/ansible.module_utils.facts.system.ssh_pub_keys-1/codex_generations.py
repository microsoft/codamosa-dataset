

# Generated at 2022-06-25 00:44:19.057935
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:44:21.233757
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()

    ret_collect = ssh_pub_key_fact_collector_1.collect()

    return ret_collect

# Generated at 2022-06-25 00:44:31.932827
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    server_config_file = '/etc/ssh/sshd_config'


# Generated at 2022-06-25 00:44:43.161387
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    result = ssh_pub_key_fact_collector_0.collect()
    assert result['ssh_host_key_ecdsa_public'] == 'AAAAC3NzaC1lZDI1NTE5AAAAIEu4iLFCzSVpjtOL5YtqqFGI3qLPZ7xXFc9i8UPWpZv1w'
    assert result['ssh_host_key_ed25519_public'] == 'AAAAC3NzaC1lZDI1NTE5AAAAIOQaG180uhte0I1bb+f8V7R1CvOI+Z4F9X3qM5UCJqmD1'

# Generated at 2022-06-25 00:44:48.757537
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Make SshPubKeyFactCollector object
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # Call method collect of SshPubKeyFactCollector object
    fact_list = ssh_pub_key_fact_collector.collect()
    assert type(fact_list) == dict


# Generated at 2022-06-25 00:44:54.206054
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_1.collect(None, {'ansible_local': {'ssh_host_key_dsa_public': 'dummy', 'ssh_host_key_rsa_public': 'dummy', 'ssh_host_key_ecdsa_public': 'dummy', 'ssh_host_key_ed25519_public': 'dummy'}})

# Generated at 2022-06-25 00:45:01.929094
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_data_0 = {'cwd': '/etc/ansible', 'path': ['/usr/lib64/python2.7/site-packages/ansible']}
    SshPubKeyFactCollector_instance_0 = SshPubKeyFactCollector()

# Generated at 2022-06-25 00:45:08.016161
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_cases = [
        {
            'global_vars': {
            },
            'module_args': {},
            'expected_result': {}
        },
    ]

    for case in test_cases:
        collector = SshPubKeyFactCollector()
        actual = collector.collect(module_name=case.get('module_name'),
                                   collected_facts=case.get('global_vars'))

        assert actual == case.get('expected_result')

# Generated at 2022-06-25 00:45:13.638154
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_collect_data = ssh_pub_key_fact_collector_1.collect()
    assert isinstance(ssh_pub_key_collect_data, dict)


# Generated at 2022-06-25 00:45:14.323745
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # TODO
    pass

# Generated at 2022-06-25 00:45:20.216753
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect(module=None)

# Generated at 2022-06-25 00:45:29.278307
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Setup test data
    ssh_key_data = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAAAgQCPCYwYfWMStmd4wi\
KjDg3q4hnz9he4iOGhu5a5nw5ZxiYcL5S5K/pIxuf/0/cGg1iX/1lHtxQ2lWSg\
Yut/bmD8Md65MJI61j1qy3Q4X971tZ5OtI5wCZ45PmZ5aGdBIdh27vMNcTXpUp\
X9P8cWddHvMQwZqYrQjKHx7VuQhQyUDQ=="

# Generated at 2022-06-25 00:45:32.188888
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()



# Generated at 2022-06-25 00:45:34.932989
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_collector = SshPubKeyFactCollector()

    var_0 = ssh_pub_key_collector.fact_ids
    var_1 = ssh_pub_key_collector.collect
    assert var_0 == var_1

# Generated at 2022-06-25 00:45:38.781766
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert True


# Generated at 2022-06-25 00:45:40.602316
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.collect().__class__.__name__ == 'dict'

# Generated at 2022-06-25 00:45:50.149967
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # setup expected response from built-in get_file_content method
    get_file_content_ret_val_0 = "return from ansible.module_utils.facts.utils.get_file_content"
    get_file_content_ret_val_1 = "return from ansible.module_utils.facts.utils.get_file_content"
    get_file_content_ret_val_2 = "return from ansible.module_utils.facts.utils.get_file_content"
    get_file_content_ret_val_3 = "return from ansible.module_utils.facts.utils.get_file_content"
    get_file_content_ret_val_4 = None

# Generated at 2022-06-25 00:45:57.124510
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    expected_keys = set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public',
                         'ssh_host_key_rsa_public', 'ssh_host_key_dsa_public_keytype',
                         'ssh_host_key_rsa_public_keytype', 'ssh_host_pub_keys_keytype'])
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
    assert set(var_1.keys()) == expected_keys

# Generated at 2022-06-25 00:46:03.070718
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_1 = var_0.collect()

# Generated at 2022-06-25 00:46:07.367008
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
    assert var_1 == {}



# Generated at 2022-06-25 00:46:13.348459
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_0.collect()


# Generated at 2022-06-25 00:46:15.485729
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_fact_collector_0.collect(), dict)

# Generated at 2022-06-25 00:46:16.006389
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-25 00:46:17.891355
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:46:20.404085
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = ansible.module_utils.facts.collector.BaseFactCollector()
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    var = ssh_pub_key_fact_collector.collect()
    assert var == {}

# Generated at 2022-06-25 00:46:23.598743
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
    assert not var_1

# Generated at 2022-06-25 00:46:32.248077
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    import shutil

    # replace the function 'get_file_content' with a more simple one
    # which returns a string in the expected format

# Generated at 2022-06-25 00:46:36.179684
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

    var_1 = ssh_pub_key_fact_collector_0._fact_ids
    var_1 = ssh_pub_key_fact_collector_0.name

    var_2 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:46:39.239904
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
    assert (len(var_1) == 0)


# Generated at 2022-06-25 00:46:41.393149
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_fact_collector.collect(), dict)


# Generated at 2022-06-25 00:46:58.806162
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_1 = None
    var_2 = None
    var_3 = None
    var_3 = var_0.collect(var_1, var_2)
    assert isinstance(var_3, dict) == True
    assert isinstance(var_3['ssh_host_key_ecdsa_public'], str) == True

# Generated at 2022-06-25 00:47:01.661018
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_1 = var_0.collect()
    assert(var_1 is None or isinstance(var_1, dict))

# Generated at 2022-06-25 00:47:04.543546
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
    if var_1 is not None:
        # test condition
        assert var_1 is not None

# Generated at 2022-06-25 00:47:05.964608
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_0.collect()
    var_0.collect()

# Generated at 2022-06-25 00:47:10.577883
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_expected_0 = 'ssh_host_key_rsa_public_keytype'
    ssh_pub_key_fact_collector_0.collect()
    assert var_expected_0 in ssh_pub_key_fact_collector_0.collect(), \
        "do not contain ssh_host_key_rsa_public_keytype"

# Generated at 2022-06-25 00:47:20.651142
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:47:22.164017
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    print("test_SshPubKeyFactCollector_collect not implemented")
    assert(False)

# Generated at 2022-06-25 00:47:24.902478
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_0.collect()
    # Verify that all of the items in the returned dictionary from
    # SshPubKeyFactCollector.collect() are the same as the keys in the
    # _fact_ids set defined in the class
    assert var_1.keys() == SshPubKeyFactCollector._fact_ids

# Generated at 2022-06-25 00:47:34.565377
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ##########################################################################################################
    # The following is test code for the SshPubKeyFactCollector.collect method when using default arguments.  #
    ##########################################################################################################

    # In order for the unit test to pass/fail properly, you need to comment out the
    # following code.

    # Call the function.
    test_case_0()

    ##########################################################################################################
    # The following is code that was used to create the test case.  DO NOT MODIFY.                            #
    ##########################################################################################################

    """
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    """

    ##########################################################################################################
    # The following is code that is verifying the test case. 

# Generated at 2022-06-25 00:47:36.143811
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_case_0()



# Generated at 2022-06-25 00:47:57.637630
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_0.collect() == {}


# Generated at 2022-06-25 00:48:01.851493
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    var_1 = ssh_pub_key_fact_collector_0.collect()
    assert var_1 == var_0
    assert var_0 is not None
    assert var_0 is not False

# Generated at 2022-06-25 00:48:03.383470
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_0.collect()

# Generated at 2022-06-25 00:48:07.310848
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
    if var_1:
        var_2 = var_1.get('ssh_host_key_dsa_public')
        assert var_2 is None


# Generated at 2022-06-25 00:48:09.605217
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()

# Generated at 2022-06-25 00:48:11.915374
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0 == {}

# Generated at 2022-06-25 00:48:14.911872
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0.get('ssh_host_key_rsa_public') is not None

# Generated at 2022-06-25 00:48:18.853475
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:48:26.265596
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create class
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    # Create object
    var_0 = ssh_pub_key_fact_collector_0.collect()

    # Get property value of name
    name_value = ssh_pub_key_fact_collector_0.name
    # Get property value of fact_ids
    fact_ids_value = ssh_pub_key_fact_collector_0.fact_ids

    assert name_value == 'ssh_pub_keys'
    assert fact_ids_value == {'ssh_host_key_dsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_rsa_public', 'ssh_host_pub_keys', 'ssh_host_key_ed25519_public'}

# Generated at 2022-06-25 00:48:27.407985
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    obj = SshPubKeyFactCollector()
    obj.collect()

# Generated at 2022-06-25 00:49:07.071520
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

    if var_0 is None:
        assert False


# Generated at 2022-06-25 00:49:09.060264
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()

# Generated at 2022-06-25 00:49:11.268110
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:21.872699
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    
    # Set up test environment
    module = AnsibleModuleStub()
    collected_facts = {
        "ssh_host_key_ecdsa_public_keytype": "ecdsa-sha2-nistp256", 
        "ssh_host_key_rsa_public_keytype": "ssh-rsa", 
        "ssh_host_key_rsa_public": "keydata", 
        "ssh_host_key_ecdsa_public": "keydata"}

    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0._module = module
    ssh_pub_key_fact_collector_0._collected_facts = collected_facts

    var_1 = ssh_pub_key_fact_collector

# Generated at 2022-06-25 00:49:23.025297
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_0.collect()
    var_1 = SshPubKeyFactCollector()
    var_1.collect()

# Generated at 2022-06-25 00:49:27.033380
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert len(ssh_pub_key_fact_collector.collect()) > 0


# Generated at 2022-06-25 00:49:29.502646
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:34.255298
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_1 = None
    var_2 = None
    var_3 = None
    var_0.__init__()
    var_3 = var_0.collect()
    assert var_3 == var_2

# Generated at 2022-06-25 00:49:42.491055
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:49:43.814322
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_1.collect()

# Generated at 2022-06-25 00:51:20.205166
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:51:26.087154
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    for keydir in ['/etc/ssh', '/etc/openssh', '/etc']:
        for algo in ('dsa', 'rsa', 'ecdsa', 'ed25519'):
            factname = 'ssh_host_key_%s_public' % algo
            if factname in var_0.keys():
                # a previous keydir was already successful, stop looking
                # for keys
                return
            key_filename = '%s/ssh_host_%s_key.pub' % (keydir, algo)
            keydata = get_file_content(key_filename)
            if keydata is not None:
                (keytype, key) = keydata.split()[0:2]
                assert var_0[factname] == key

# Generated at 2022-06-25 00:51:26.546477
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-25 00:51:34.291091
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    # Test with fact_ids and fact_subset arguments
    var = ssh_pub_key_fact_collector.collect(collected_facts={})

# Generated at 2022-06-25 00:51:39.252694
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0.collect()
    # Test method collect of class SshPubKeyFactCollector with arguments.
    # The following call to collect() is commented out, because it would
    # alter the running system.
    # ssh_pub_key_fact_collector_0.collect(module=None, collected_facts=None)
    #assert ssh_pub_key_fact_collector_0.collect(module=None, collected_facts=None) is None


# Generated at 2022-06-25 00:51:42.798923
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_0.collect()
    assert var_1 is None


# Generated at 2022-06-25 00:51:51.427574
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0.collect()
    assert ssh_pub_key_fact_collector_0.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector_0.collect() == {}
    assert ssh_pub_key_fact_collector_0._fact_ids == {'ssh_host_key_ed25519_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_dsa_public', 'ssh_host_pub_keys'}

# Generated at 2022-06-25 00:51:54.386631
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_1 = SshPubKeyFactCollector()
    var_2 = {}
    var_3 = var_1.collect(var_2)


# Generated at 2022-06-25 00:51:56.282560
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    expected_0 = None
    assert var_0 == expected_0


# Generated at 2022-06-25 00:51:59.757371
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_case_0()