

# Generated at 2022-06-25 00:44:20.570846
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert set(ssh_pub_key_fact_collector_0.collect().keys()) == set(['ssh_host_key_ecdsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_dsa_public'])


# Generated at 2022-06-25 00:44:25.750794
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_1.collect()

test_case_0()

# Generated at 2022-06-25 00:44:31.141649
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_0.collect() == {}


# Generated at 2022-06-25 00:44:38.141488
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    res = ssh_pub_key_fact_collector.collect(None)

    assert 'ssh_host_key_rsa_public' in res.keys()
    assert 'ssh_host_key_ecdsa_public' in res.keys()
    assert 'ssh_host_key_ed25519_public' in res.keys()

# Generated at 2022-06-25 00:44:47.913018
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_1.collect = \
        lambda x: {
            'ssh_host_key_rsa_public': 'ssh-rsa mykey',
            'ssh_host_key_ecdsa_public': 'ecdsa-sha2-nistp256 mykey',
            'ssh_host_key_ed25519_public': 'ssh-ed25519 mykey',
            'ssh_host_key_dsa_public': 'ssh-dss mykey'
        }

    result = ssh_pub_key_fact_collector_1.collect()


# Generated at 2022-06-25 00:44:55.183248
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test with a good ssh key dir
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert sorted(ssh_pub_key_fact_collector_0.collect()['ssh_pub_key_facts'].keys()) == sorted(['ssh_host_key_rsa_public_keytype', 'ssh_host_key_ed25519_public_keytype', 'ssh_host_key_dsa_public_keytype', 'ssh_host_key_rsa_public', 'ssh_host_key_dsa_public', 'ssh_host_key_ecdsa_public_keytype', 'ssh_host_key_ed25519_public', 'ssh_host_key_ecdsa_public'])

    # Test with a bad ssh key dir
    # TODO: can't find

# Generated at 2022-06-25 00:45:05.065367
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_ = SshPubKeyFactCollector()
    result = ssh_pub_key_fact_collector_.collect()

# Generated at 2022-06-25 00:45:10.525673
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_fact_collector_0.collect(), dict)

# Generated at 2022-06-25 00:45:14.441212
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    assert isinstance(ssh_pub_key_facts, dict)
    assert set(ssh_pub_key_facts.keys()) == SshPubKeyFactCollector._fact_ids

# Generated at 2022-06-25 00:45:20.492509
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes, to_text
    mock_module = MagicMock(name="module")
    mock_collected_facts = MagicMock(name="collected_facts")
    SshPubKeyFactCollector.collect(mock_module, mock_collected_facts)

# Generated at 2022-06-25 00:45:25.594756
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_0.collect() is not False


# Generated at 2022-06-25 00:45:32.993436
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    class args:
        module = None
        collected_facts = None
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()

    # Bad input test case
    if (ssh_pub_key_fact_collector_0.collect() != None):
        raise AssertionError("Expected None and got %s" %
                             ssh_pub_key_fact_collector_0.collect())

    # Bad input test case
    if (ssh_pub_key_fact_collector_0.collect(args) != None):
        raise AssertionError("Expected None and got %s" %
                             ssh_pub_key_fact_collector_0.collect(args))

    # Bad input test case

# Generated at 2022-06-25 00:45:37.821808
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    module_0 = None
    collected_facts_0 = None

# Generated at 2022-06-25 00:45:39.817487
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert ssh_pub_key_fact_collector_0.collect().get('ssh_host_key_ed25519_public') is not None

# Generated at 2022-06-25 00:45:48.408384
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_collect_0 = SshPubKeyFactCollector()
    collected_facts = {}

# Generated at 2022-06-25 00:45:54.570393
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    results = ssh_pub_key_fact_collector.collect()
    # double check that the results are a dict
    assert isinstance(results, dict)
    for key in results:
        # check that each key is a string, something like:
        # ssh_host_key_rsa_public
        assert isinstance(key, str)
        val = results[key]
        # val should be a string
        assert isinstance(val, str)


# Generated at 2022-06-25 00:45:58.201066
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()
    assert type(ssh_pub_key_facts) is dict

# Generated at 2022-06-25 00:46:08.468072
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
    Expected Functionality:
        - Collects keys for every algorithm supported by SSH
        - Collects them from the first matching path in keydirs
        - If no keys are found, it returns empty
    """

    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    # Set the collect keys to be changed at will
    key_names = ['ssh_host_key_rsa_public',
                 'ssh_host_key_dsa_public',
                 'ssh_host_key_ecdsa_public',
                 'ssh_host_key_ed25519_public']

    # Set the collect keytypes to be changed at will

# Generated at 2022-06-25 00:46:18.108727
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    fd = open("unit_test_file.txt", 'w')

# Generated at 2022-06-25 00:46:18.592714
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
  pass

# Generated at 2022-06-25 00:46:22.973392
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    var = ssh_pub_key_fact_collector.collect()

# Generated at 2022-06-25 00:46:25.774703
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert isinstance(var_0, dict)



# Generated at 2022-06-25 00:46:28.341622
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:46:30.766036
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()

# Generated at 2022-06-25 00:46:31.600660
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert True


# Generated at 2022-06-25 00:46:34.326941
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    result_1 = ssh_pub_key_fact_collector_1.collect()
    assert result_1 is not None
    assert isinstance(result_1, dict)

# Generated at 2022-06-25 00:46:38.445667
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

    assert isinstance(var_0, dict)


# Generated at 2022-06-25 00:46:46.553813
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Constructing a mock object for BaseFactCollector
    mock_BaseFactCollector = mock.Mock(spec=BaseFactCollector)
    # Constructing a mock object for SshPubKeyFactCollector
    mock_SshPubKeyFactCollector = SshPubKeyFactCollector()
    # Calling method collect on mock object
    var_1 = mock_SshPubKeyFactCollector.collect(mock_BaseFactCollector)

#def test_case_1():
#    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
#    var_2 = ssh_pub_key_fact_collector_1.collect()

#def test_case_2():
#    ssh_pub_key_fact_collector_2 = SshPubKeyFactCollector()
#    var_

# Generated at 2022-06-25 00:46:47.697509
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:46:50.553236
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create and initialize instance of class SshPubKeyFactCollector with arguments
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:00.914494
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # create mock object of class SshPubKeyFactCollector
    mock_SshPubKeyFactCollector = SshPubKeyFactCollector() 

    # mock the return value of the method collect of class SshPubKeyFactCollector
    mock_SshPubKeyFactCollector.collect=Mock(return_value={'ssh_host_key_ecdsa_public': 'ecdsa-key', 'ssh_host_key_rsa_public': 'rsa-key', 'ssh_host_key_ed25519_public': 'ed25519-key'})

    # check the return value of the method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:47:02.121889
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
  assert True # TODO: implement your test here


# Generated at 2022-06-25 00:47:08.284749
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert len(var_0) == 5
    val = 'ssh-rsa'
    if 'ssh_host_key_rsa_public_keytype' in var_0:
        val = var_0['ssh_host_key_rsa_public_keytype']
    assert val == 'ssh-rsa'

# Generated at 2022-06-25 00:47:09.131349
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert True



# Generated at 2022-06-25 00:47:10.341782
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ret_val_0 = []
    assert ret_val_0 == {}

# Generated at 2022-06-25 00:47:20.529354
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()
    assert var_1 is not None
    assert len(var_1) == 5

# Generated at 2022-06-25 00:47:23.699157
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert var_0 == {}

# Generated at 2022-06-25 00:47:26.636866
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    def test_var_0():
        ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
        var_0 = ssh_pub_key_fact_collector_0.collect()
        assert var_0 == []
    test_var_0()

# Generated at 2022-06-25 00:47:32.564580
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0.collect()


if __name__ == '__main__':
    ansible_module_0 = AnsibleModule({})
    ansible_module_0.params = dict()
    ansible_module_0.params[u'gather_subset'] = set([])
    ansible_module_0.params[u'filter'] = u'*'

    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0.collect(module=ansible_module_0)

# Generated at 2022-06-25 00:47:33.625029
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:47:47.276751
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test using a mock object
    class TestMock():
        def __init__(self):
            pass

        def collect(self, module=None, collected_facts=None):
            return {}

    test_obj = TestMock()

    setattr(test_obj, 'collect', SshPubKeyFactCollector.collect)

    SshPubKeyFactCollector.collect(test_obj)

# Generated at 2022-06-25 00:47:50.254464
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector_obj = SshPubKeyFactCollector()
    mock_module = MagicMock()
    fact_collector_obj.collect(module=mock_module)
    mock_module.get_bin_path.assert_called_with('ssh-keygen')

# Generated at 2022-06-25 00:47:59.460394
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0.keys() == [
        'ssh_host_key_ed25519_public_keytype',
        'ssh_host_key_rsa_public',
        'ssh_host_key_ed25519_public',
        'ssh_host_key_rsa_public_keytype']
    assert var_0['ssh_host_key_ed25519_public_keytype'] == 'ssh-ed25519'
    assert var_0['ssh_host_key_rsa_public'] == 'AAAAB3NzaC1yc2EAAAA'

# Generated at 2022-06-25 00:48:09.878295
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_1 = var_0.collect()

# Generated at 2022-06-25 00:48:13.574346
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

    assert var_0 is not None



# Generated at 2022-06-25 00:48:15.281254
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    var = ssh_pub_key_fact_collector.collect()

# Generated at 2022-06-25 00:48:23.788634
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Define test data
    keys = {'ssh_host_key_dsa_public': 'ssh-dss AAAAB3Nz',
            'ssh_host_key_ecdsa_public': 'ecdsa-sha2-nistp256 AAAA',
            'ssh_host_key_ed25519_public': 'ssh-ed25519 AAAAC3NzaC1lZDI',
            'ssh_host_key_rsa_public': 'ssh-rsa AAAAB3NzaC1yc2E'}

    # Run method
    collector = SshPubKeyFactCollector()
    result = collector.collect()

    # Check results

# Generated at 2022-06-25 00:48:27.779065
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:48:29.810910
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:48:34.680808
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert var_0['ssh_host_key_ed25519_public'] == 'AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBAU6bcfU6mHU+l9XqB3qkN+YJclN/RdR5/5Q5MEUIcANVI/mJ0i9XbO2E1G+OZ66UnnjxC7zw3qKKCWVtbMjtJc='

# Generated at 2022-06-25 00:48:55.338690
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_1.collect()

# Generated at 2022-06-25 00:48:56.943260
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0 == {}


# Generated at 2022-06-25 00:49:05.889208
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    module_arg_spec = dict()
    module_arg_spec.update(dict(
        ansible_facts=dict(type='dict', default={})
    ))

    # AnsibleModule is a helper class to access the AnsibleModule.
    # It is only used here as a constructor to pass the arg_spec.
    ansible_module = AnsibleModule(argument_spec=module_arg_spec)

    # ansible_facts is a dict that AnsibleModule uses to pass the results
    # of the module's execution
    ansible_facts = {}

    # Create an instance of the class we're testing.
    # ansible_facts is passed to the constructor,
    # and will be updated by the instance.
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_fact_

# Generated at 2022-06-25 00:49:08.024875
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:49:10.504734
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    # Do here the assert.

# Generated at 2022-06-25 00:49:21.845764
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_fact_collector, SshPubKeyFactCollector)

    var = ssh_pub_key_fact_collector.collect()
    if False: # example: 
        assert 'ssh_host_key_ecdsa_public' in var
        assert isinstance(var, dict)

    if False: # example: 
        assert 'ssh_host_key_rsa_public' in var
        assert isinstance(var, dict)

    if False: # example: 
        assert isinstance(var, dict)
        assert 'ssh_host_key_ed25519_public' in var

    if False: # example: 
        assert isinstance(var, dict)

# Generated at 2022-06-25 00:49:25.493456
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    var_1 = SshPubKeyFactCollector()
    var_2 = SshPubKeyFactCollector()
    var_3 = var_1
    #
    # check that the facts are in the supported_facts list
    #
    for fact in var_0.supported_facts:
        if fact in var_1._fact_ids:
            try:
                key = var_2.collect().get(fact)
            except KeyError:
                raise AssertionError()
        else:
            try:
                key = var_3.collect().get(fact)
                raise AssertionError()
            except KeyError:
                pass

# Generated at 2022-06-25 00:49:26.995330
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 00:49:29.469039
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:33.692959
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert 'ssh_host_pub_keys' in ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:50:15.917050
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect(collected_facts=None)


# Generated at 2022-06-25 00:50:19.434051
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_1.collect()
    # No code here, just a test to exercise the code path
    # and make sure it doesn't blow up

# Generated at 2022-06-25 00:50:21.415116
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:50:23.661789
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:50:24.627429
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass


# Generated at 2022-06-25 00:50:26.875398
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_0.collect()
    assert var_1 == dict()


# Generated at 2022-06-25 00:50:28.521356
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()

# Generated at 2022-06-25 00:50:35.236153
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create a new instance of class SshPubKeyFactCollector
    test_collector_0 = SshPubKeyFactCollector()
    # Create a new instance of class SshPubKeyFactCollector
    test_collector_1 = SshPubKeyFactCollector()
    test_collect_0 = test_collector_0.collect(module=None, collected_facts=None)

    assert "ssh_host_key_dsa_public" in test_collect_0.keys()
    assert "ssh_host_key_rsa_public" in test_collect_0.keys()
    assert "ssh_host_key_ecdsa_public" in test_collect_0.keys()
    assert "ssh_host_key_ed25519_public" in test_collect_0.keys()


# Generated at 2022-06-25 00:50:41.026242
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    var_1 = SshPubKeyFactCollector()
    var_1.collect() == None

# Generated at 2022-06-25 00:50:46.142391
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-25 00:52:17.457329
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    var_0 = SshPubKeyFactCollector()
    assert (var_0.collect() == {})

# Generated at 2022-06-25 00:52:21.674832
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # This is probably a good assert, but I'm not sure how to write a
    # test case for it.  The exception is the normal case, not the
    # exceptional; is there a better assert function to use here?
    # assertAssertionError(SshPubKeyFactCollector().collect)
    # The easiest way for now is to just not have a test for this method
    pass

# Generated at 2022-06-25 00:52:23.105603
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:52:28.106123
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert not ssh_pub_key_fact_collector_0.collect()


# Generated at 2022-06-25 00:52:33.666450
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    facts = ssh_pub_key_fact_collector.collect()

    assert len(facts) == 5

    for fact in facts:
        assert len(facts[fact]) > 0

    assert facts['ssh_host_key_dsa_public_keytype'] == 'ssh-dss'
    assert facts['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa'
    assert facts['ssh_host_key_ecdsa_public_keytype'] == 'ecdsa-sha2-nistp256'
    assert facts['ssh_host_key_ed25519_public_keytype'] == 'ssh-ed25519'

# Generated at 2022-06-25 00:52:40.601944
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Setup test variables, some that are expected to be returned from the
    # collect() method and others that will be used as input to the method
    fact_ids = set(['ssh_host_pub_keys',
                    'ssh_host_key_dsa_public',
                    'ssh_host_key_rsa_public',
                    'ssh_host_key_ecdsa_public',
                    'ssh_host_key_ed25519_public'])


# Generated at 2022-06-25 00:52:44.147448
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    var_0 = ssh_pub_key_fact_collector_0.collect()
    assert var_0 == {}, 'Return value is not as expected'

# Generated at 2022-06-25 00:52:48.947798
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_fact_collector_0.collect(), dict)

# Generated at 2022-06-25 00:52:54.208998
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    args = []
    ssh_pub_key_fact_collector_1 = SshPubKeyFactCollector()
    var_1 = ssh_pub_key_fact_collector_1.collect()

# Generated at 2022-06-25 00:52:58.756196
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector_0 = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_0.collect()