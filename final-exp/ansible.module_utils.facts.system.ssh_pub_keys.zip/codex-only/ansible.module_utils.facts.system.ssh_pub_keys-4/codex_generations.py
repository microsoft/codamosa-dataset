

# Generated at 2022-06-23 01:50:19.933527
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:50:27.076912
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_facts_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts_collector._fact_ids == {'ssh_host_pub_keys',
                                                     'ssh_host_key_dsa_public',
                                                     'ssh_host_key_rsa_public',
                                                     'ssh_host_key_ecdsa_public',
                                                     'ssh_host_key_ed25519_public'}

# Generated at 2022-06-23 01:50:36.227127
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # since we are in a package, test needs to be at this level
    # basic test structure is from test_HardwareFactCollector_collect()
    # in test_hardware_collector.py, which is a good template

    # this is the SshPubKeyFactCollector instance being tested
    ssh_pub_key_fc = SshPubKeyFactCollector()

    # parameters to the collect function (any others?)
    params = {}

    # test collect function, return values are compared to expected

# Generated at 2022-06-23 01:50:47.813076
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import Facts
    import json

    module = MockModule()
    fake_collected_facts = Facts()
    fake_collected_facts.populate()
    sshpubkey_fact_collector_mock = SshPubKeyFactCollector(module=module,
                                                           collected_facts=fake_collected_facts)
    # we need to mock the method raw_facts
    Collector._raw_facts = Mock(return_value=dict())
    sshpubkey_fact_collector_mock.collect()

# Generated at 2022-06-23 01:50:49.410906
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:50:58.668122
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os

    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils.facts import collector

    base_test_fact_path = os.path.join(os.path.dirname(__file__), 'test_facts')
    online_test_fact_path = os.path.join(os.path.dirname(__file__), 'test_facts_online')

    # Check parent class inheritance
    assert issubclass(SshPubKeyFactCollector, BaseFactCollector)

    # Collect facts
    collected_facts = SshPubKeyFactCollector().collect(module=None, collected_facts={})

    # Check if collected facts are present

# Generated at 2022-06-23 01:51:09.508643
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:51:17.138998
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:51:25.981189
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """SshPubKeyFactCollector - test collect() method"""

    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible_collections.ansible.netcommon.plugins.module_utils.network.common.facts.facts as ans_facts

    ans_facts.DEFAULT_GATHERING = ['ssh_pub_keys']

    def get_file_proxy_mock(filename):
        if filename == '/etc/ssh/ssh_host_rsa_key.pub':
            return "ssh-rsa RSA_PUB_KEY"
        if filename == '/etc/ssh/ssh_host_dsa_key.pub':
            return "ssh-dss DSA_PUB_KEY"

# Generated at 2022-06-23 01:51:37.275631
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # set up the test environment
    import errno
    import os
    import tempfile
    import textwrap

    # write empty file to a temp dir
    dummy_keys = []
    for key in ('dsa', 'rsa', 'ecdsa', 'ed25519'):
        filename = 'ssh_host_%s_key.pub' % key
        t = tempfile.NamedTemporaryFile(prefix=filename, delete=False)
        t.close()
        dummy_keys.append(t.name)

    # bind the test environment to a local variable
    # to be able to use it within the closure
    def bind_test_env(test_env):
        def _test():
            mod = get_test_module(test_env['test_env'])
            pubkeys = SshPubKeyFactCollector.collect

# Generated at 2022-06-23 01:51:47.907003
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # method collect will be called with module and collected_facts as
    # arguments, but neither of these are used internally in the method
    # so call the method with anything, either None, or any dummy
    # object which happens to be available
    ssh_pub_key_facts = SshPubKeyFactCollector().collect(None, None)

    # verify that we got some results
    assert ssh_pub_key_facts is not None
    assert len(ssh_pub_key_facts) > 0

    # verify that we got public keys for the various algorithms
    # ssh_host_key_dsa_public is not used anymore, but delete it from the
    # list of expected facts

# Generated at 2022-06-23 01:51:58.376216
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fc = SshPubKeyFactCollector()
    assert 'ssh_pub_keys' == ssh_pub_key_fc.name
    assert set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public',
                'ssh_host_key_dsa_public_keytype', 'ssh_host_key_rsa_public',
                'ssh_host_key_rsa_public_keytype', 'ssh_host_key_ecdsa_public',
                'ssh_host_key_ecdsa_public_keytype',
                'ssh_host_key_ed25519_public',
                'ssh_host_key_ed25519_public_keytype']) == ssh_pub_key_fc._fact_ids

# Generated at 2022-06-23 01:52:01.022483
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Test with no arguments
    obj = SshPubKeyFactCollector()
    assert obj.collect() == {}
    assert obj.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:52:07.646945
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = dict()
    ssh_pub_key_facts_obj = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_facts_obj.collect(module, collected_facts)
    assert ssh_pub_key_facts['ssh_host_key_ed25519_public'] is not None
    assert ssh_pub_key_facts['ssh_host_key_ed25519_public_keytype'] is not None

# Generated at 2022-06-23 01:52:16.411317
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:52:26.378508
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts_mock = {}

    # Placeholder for a dummy class that implements method collect
    # of class SshPubKeyFactCollector and returns ssh_pub_key_facts_mock.
    class DummySshPubKeyFactCollector(SshPubKeyFactCollector):
        def collect(self, module=None, collected_facts=None):
            return ssh_pub_key_facts_mock

    # Instantiate dummy class with method collect.
    dummy_ssh_pub_key_collector = DummySshPubKeyFactCollector()

    # Call method collect and assert that the ssh_pub_key_facts_mock
    # is returned.
    ssh_pub_key_facts = dummy_ssh_pub_key_collector.collect()
    assert ssh_pub_key_facts == ssh_pub

# Generated at 2022-06-23 01:52:36.411077
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    from ansible.module_utils.facts.utils import mock_open


# Generated at 2022-06-23 01:52:37.413276
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-23 01:52:39.654162
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # create object to test with
    obj = SshPubKeyFactCollector()
    # test the object name
    assert obj.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:52:52.811447
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''Test SshPubKeyFactCollector.collect'''

    SshPubKeyFactCollector_instance = SshPubKeyFactCollector()

    # Test with no ssh keys
    fake_keys_dir = '/tmp/ssh_pub_keys_none'
    fake_keys_dir_content = []
    result = SshPubKeyFactCollector_instance.collect(None, {'ssh_pub_keys_dir': fake_keys_dir})
    assert result['ssh_host_key_dsa_public'] == None
    assert result['ssh_host_key_rsa_public'] == None
    assert result['ssh_host_key_ecdsa_public'] == None
    assert result['ssh_host_key_ed25519_public'] == None

    # Test with one key

# Generated at 2022-06-23 01:52:54.732764
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_key_facts = SshPubKeyFactCollector.collect()
    assert ssh_key_facts

# Generated at 2022-06-23 01:53:05.474229
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    import os
    import tempfile


# Generated at 2022-06-23 01:53:13.043081
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKeyFactCollectorobj = SshPubKeyFactCollector()
    assert sshPubKeyFactCollectorobj.name == 'ssh_pub_keys'
    assert sshPubKeyFactCollectorobj._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:53:16.875239
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_keys = SshPubKeyFactCollector()

    ssh_host_keys = ssh_pub_keys.collect()
    assert 'ssh_host_key_rsa_public' in ssh_host_keys

# Generated at 2022-06-23 01:53:28.366562
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:53:31.621194
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector_obj = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_obj.name == "ssh_pub_keys"

# Generated at 2022-06-23 01:53:33.329421
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-23 01:53:43.360243
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule():
        def __init__(self):
            self.params = {'gather_subset': 'all'}
            self.exit_json = lambda *args, **kwargs: exit()

    class MockFile():
        def __init__(self, path, data):
            self.path = path
            self.data = to_bytes(data)

    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    keydirs = ['/etc/ssh', '/etc/openssh', '/etc']

    # mock file content
    keys = {}

# Generated at 2022-06-23 01:53:50.387496
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import shutil

    fixture_dir = 'tests/unit/modules/ansible_collections/ansible/os/plugins/test_fixtures/'
    keydir = '/etc/ssh'
    keydir_bak = '/etc/ssh_bak'
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    expected_facts = {}
    expected_key_facts = {}

# Generated at 2022-06-23 01:53:53.706471
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()

    assert x.name == 'ssh_pub_keys'
    assert len(x._fact_ids) == 5

# Generated at 2022-06-23 01:53:56.717605
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKeyFactCollector_obj = SshPubKeyFactCollector()
    assert sshPubKeyFactCollector_obj.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:53:59.539831
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    test_obj = SshPubKeyFactCollector()
    assert test_obj

# vim: set et ts=8 sw=4 sts=4:

# Generated at 2022-06-23 01:54:11.053646
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert isinstance(ssh_pub_key_collector._fact_ids, set)
    assert 'ssh_host_pub_keys' in ssh_pub_key_collector._fact_ids
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_collector._fact_ids
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_collector._fact_ids
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_collector._fact_ids
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_collector._fact_ids

# Generated at 2022-06-23 01:54:13.630625
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert isinstance(obj._fact_ids, set)

# Generated at 2022-06-23 01:54:14.222689
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-23 01:54:24.857292
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:54:27.729871
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    facts = collector.collect()
    assert facts
    assert type(facts) is dict
    assert 'ssh_host_key_rsa_public' in facts
    assert facts['ssh_host_key_rsa_public'] is not None

# Generated at 2022-06-23 01:54:39.690913
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector = SshPubKeyFactCollector()
    collected_facts = {
        'ssh_host_key_dsa_public': None,
        'ssh_host_key_rsa_public': None,
        'ssh_host_key_ecdsa_public': None,
        'ssh_host_key_ed25519_public': None,
        'ssh_host_key_dsa_public_keytype': None,
        'ssh_host_key_rsa_public_keytype': None,
        'ssh_host_key_ecdsa_public_keytype': None,
        'ssh_host_key_ed25519_public_keytype': None
    }

# Generated at 2022-06-23 01:54:46.380037
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])



# Generated at 2022-06-23 01:54:47.331456
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert SshPubKeyFactCollector().collect() == {}

# Generated at 2022-06-23 01:54:58.375026
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # dummy class for testing
    class DummyModule:
        def get_bin_path(self, path, required=False, opt_dirs=[]):
            return path
    dummy_module = DummyModule()

    # dummy class for testing
    class DummyCollector:
        def __init__(self):
            self.facts = {}
    dummy_collector = DummyCollector()

    # define fake file system to use

# Generated at 2022-06-23 01:55:09.017488
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = type('', (object,), {})()
    setattr(module, 'params', {'gather_subset': ['ssh-hostkeys']})
    setattr(module, 'exit_json', lambda **kwargs: None)
    setattr(module, 'fail_json', lambda **kwargs: None)
    setattr(module, 'fail_json', lambda **kwargs: None)
    setattr(module, 'add_path_info', lambda x, y, z=None: None)
    setattr(module, 'get_bin_path', lambda x, opt_dirs=[] : None)
    setattr(module, 'get_file_content', lambda x, z=None: None)
    setattr(module, 'get_platform', lambda: None)

# Generated at 2022-06-23 01:55:11.529350
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    '''Test constructor of SshPubKeyFactCollector'''
    SshPubKeyFactCollector()

# Generated at 2022-06-23 01:55:22.717411
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
    SshPubKeyFactCollector.collect should return a dict of facts about the SSH host keys
    or an empty dict if non could be found.

    The return value should contain the following keys:
    - ssh_host_key_dsa_public
    - ssh_host_key_rsa_public
    - ssh_host_key_ecdsa_public
    - ssh_host_key_ed25519_public
    """

    # All files listed in test_files will be used to return facts:
    # - in the order listed
    # - if the first file contains content, the other files will not be used

# Generated at 2022-06-23 01:55:25.063040
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert 'ssh_host_rsa_public' in SshPubKeyFactCollector._fact_ids
    assert 'ssh_pub_keys' == SshPubKeyFactCollector.name

# Generated at 2022-06-23 01:55:31.207181
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    print(ssh_pub_key_collector)
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'


if __name__ == '__main__':
    test_SshPubKeyFactCollector()

# Generated at 2022-06-23 01:55:40.394739
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = {}
    expected_facts = {'ssh_host_key_ed25519_public': 'AAAAC3NzaC1lZDI1NTE5AAAAIA7JjveS5U6Ps5U6aMb6aN1kaMZ/XQHv+ix/fJj+lnN/',
                      'ssh_host_key_ed25519_public_keytype': 'ssh-ed25519'}

    # Mock the methods:
    #     get_file_content(file_name)
    #     _get_file_content(path)
    def get_file_content(file_name):
        ssh_host_keys = {}

# Generated at 2022-06-23 01:55:48.481856
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = type('MockAnsibleModule', (), dict(params={}))
    collected_facts = dict()
    spkfc = SshPubKeyFactCollector(module=module, collected_facts=collected_facts)
    res = spkfc.collect()
    assert 'ssh_host_key_rsa_public' in res
    assert 'ssh_host_key_rsa_public_keytype' in res
    assert res['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa'
    assert 'ssh_host_key_dsa_public' in res
    assert 'ssh_host_key_dsa_public_keytype' in res
    assert res['ssh_host_key_dsa_public_keytype'] == 'ssh-dss'

# Generated at 2022-06-23 01:55:50.046635
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    c = SshPubKeyFactCollector()
    c.collect()

# Generated at 2022-06-23 01:56:01.248670
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    ssh_pub_key_facts = {}
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    for algo in algos:
        factname = 'ssh_host_key_%s_public' % algo
        ssh_pub_key_facts[factname] = factname
        ssh_pub_key_facts[factname + '_keytype'] = factname + '_keytype'

    from ansible.module_utils.facts.collector import MockModule

    module = MockModule()

    ssh_pub_key_collector = SshPubKeyFactCollector()

    assert ssh_pub_key_collector.collect(module, ssh_pub_key_facts) == ssh_pub_key_facts

# Generated at 2022-06-23 01:56:08.657399
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    decimals = 2
    my_facts = {}
    # Run the method
    my_object = SshPubKeyFactCollector()
    my_result = my_object.collect(my_facts)
    assert isinstance(my_result, dict)

    # test an ECDSA key
    assert 'ssh_host_key_ecdsa_public' in my_result
    assert 'ssh_host_key_ecdsa_public_keytype' in my_result
    assert my_result.get('ssh_host_key_ecdsa_public_keytype') == 'ecdsa-sha2-nistp256'
    assert 'ssh_host_key_ecdsa_public' in my_result

# Generated at 2022-06-23 01:56:20.502319
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])
    sfk = SshPubKeyFactCollector()
    assert sfk.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:56:29.434734
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # stubs
    module = None
    collected_facts = {}

    # initialize object
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # call method
    ansible_facts = ssh_pub_key_fact_collector.collect(
        module=module,
        collected_facts=collected_facts
    )

    # assert
    assert 'ssh_host_key_ecdsa_public' in ansible_facts
    assert 'ssh_host_key_ed25519_public' in ansible_facts
    assert 'ssh_host_key_ecdsa_public_keytype' in ansible_facts
    assert 'ssh_host_key_ed25519_public_keytype' in ansible_facts

# Generated at 2022-06-23 01:56:38.288767
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_keys = { 'ssh_host_key_dsa_public': 'dsa AAAABB',
                 'ssh_host_key_rsa_public': 'rsa AAAABB',
                 'ssh_host_key_ecdsa_public': 'ecdsa AAAABB',
                 'ssh_host_key_ed25519_public': 'ed25519 AAAABB',
                 'ssh_host_key_dsa_public_keytype': 'ssh-dss',
                 'ssh_host_key_rsa_public_keytype': 'ssh-rsa',
                 'ssh_host_key_ecdsa_public_keytype': 'ecdsa-sha2-nistp256',
                 'ssh_host_key_ed25519_public_keytype': 'ssh-ed25519'}


# Generated at 2022-06-23 01:56:39.741773
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-23 01:56:43.893388
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    assert collector.collect() == {
        'ssh_host_key_ed25519_public': 'foo',
        'ssh_host_key_ed25519_public_keytype': 'ssh-ed25519'
    }

# Generated at 2022-06-23 01:56:51.402332
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()

    assert collector.name == 'ssh_pub_keys'

    # Fact ids that are exposed by this module
    ids_to_check = ['ssh_host_pub_keys',
                    'ssh_host_key_dsa_public',
                    'ssh_host_key_rsa_public',
                    'ssh_host_key_ecdsa_public',
                    'ssh_host_key_ed25519_public']

    fact_ids = []
    for fact_id in ids_to_check:
        fact_ids.append(fact_id)
    assert sorted(list(collector._fact_ids)) == sorted(fact_ids)

# Generated at 2022-06-23 01:56:53.610449
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'
    assert collector.priority == 25

# Generated at 2022-06-23 01:57:03.845928
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Test SshPubKeyFactCollector.collect()."""


# Generated at 2022-06-23 01:57:07.288214
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Test for constructor
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector
    assert isinstance(ssh_pub_key_collector, SshPubKeyFactCollector)


# Generated at 2022-06-23 01:57:10.311420
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector() is not None

# Generated at 2022-06-23 01:57:18.567251
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector=SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:57:23.702190
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pubKey_fact = SshPubKeyFactCollector()
    assert len(ssh_pubKey_fact._fact_ids) == 5
    assert ssh_pubKey_fact.name == 'ssh_pub_keys'
    assert ssh_pubKey_fact.collect() == {}

# Generated at 2022-06-23 01:57:26.898158
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    result = collector.collect()
    assert result['ssh_host_key_dsa_public'] is not None
    assert type(result['ssh_host_key_dsa_public']) is str

# Generated at 2022-06-23 01:57:29.613648
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    for fact in ssh_pub_key_facts:
        print(fact + ':')
        print(ssh_pub_key_facts[fact])
    assert True

# Generated at 2022-06-23 01:57:40.415308
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Mocking module_utils.facts.utils.get_file_content
    collect_mock_keydirs = {}

    def collect_mock_get_file_content(arg):
        ''' Collect our own get_file_content mock method. '''

        collect_mock_keydirs[arg] = True
        return 'ssh-rsa test_ssh_pub_key'

    import __builtin__
    setattr(__builtin__, 'get_file_content', collect_mock_get_file_content)
    import ansible.module_utils.facts.collectors.system.ssh_pub_key as ssh_pub_key

    module = None
    collected_facts = {}
    fact_collector = ssh_pub_key.SshPubKeyFactCollector()

    # Run the fact collector
    fact

# Generated at 2022-06-23 01:57:45.044103
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'
    assert collector._fact_ids == set(['ssh_host_pub_keys',
                                       'ssh_host_key_dsa_public',
                                       'ssh_host_key_rsa_public',
                                       'ssh_host_key_ecdsa_public',
                                       'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:57:48.478252
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    result = SshPubKeyFactCollector()
    assert "SshPubKeyFactCollector" == result.__class__.__name__


# Generated at 2022-06-23 01:57:59.818252
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_instance_list
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_subset_collector_names

    class dummymodule(object):
        def __init__(self, name=None, additional_subset_names=None, timeout=None):
            self.name = name
            self.additional_subset_names = additional_subset_names
            self.timeout = timeout
            self.params = {}
            self.subset = None
            self.subsets = {}


# Generated at 2022-06-23 01:58:09.938592
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:58:17.122133
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    testmodule = SshPubKeyFactCollector()
    assert testmodule.name == 'ssh_pub_keys'
    assert testmodule._fact_ids == set(['ssh_host_pub_keys',
                                        'ssh_host_key_dsa_public',
                                        'ssh_host_key_rsa_public',
                                        'ssh_host_key_ecdsa_public',
                                        'ssh_host_key_ed25519_public'])
    assert isinstance(testmodule.__doc__, str)


# Generated at 2022-06-23 01:58:27.248083
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKeyFactCollector = SshPubKeyFactCollector()
    assert sshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert len(sshPubKeyFactCollector._fact_ids) == 5
    assert sshPubKeyFactCollector._fact_ids.pop() == 'ssh_host_key_ed25519_public'
    assert sshPubKeyFactCollector._fact_ids.pop() == 'ssh_host_key_ecdsa_public'
    assert sshPubKeyFactCollector._fact_ids.pop() == 'ssh_host_key_rsa_public'
    assert sshPubKeyFactCollector._fact_ids.pop() == 'ssh_host_key_dsa_public'
    assert sshPubKeyFactCollector._fact_ids.pop() == 'ssh_host_pub_keys'

# Generated at 2022-06-23 01:58:38.845007
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)


# Generated at 2022-06-23 01:58:47.828473
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create a class instance
    collector = SshPubKeyFactCollector(None, {})
    # Call the method to be tested
    result = collector.collect()
    # Assert result

# Generated at 2022-06-23 01:58:56.611378
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """Test constructor for SshPubKeyFactCollector class"""

    # Constructor without parameters
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # Testing __init__()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set([
        'ssh_host_pub_keys',
        'ssh_host_key_dsa_public',
        'ssh_host_key_rsa_public',
        'ssh_host_key_ecdsa_public',
        'ssh_host_key_ed25519_public'])
    assert ssh_pub_key_fact_collector.priority == 6


# Generated at 2022-06-23 01:59:00.079852
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c = SshPubKeyFactCollector()
    assert c.name == 'ssh_pub_keys'
    assert c._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:59:06.950940
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fc = SshPubKeyFactCollector()
    assert fc.name == 'ssh_pub_keys'
    assert fc._fact_ids == set(['ssh_host_pub_keys',
                                'ssh_host_key_dsa_public',
                                'ssh_host_key_rsa_public',
                                'ssh_host_key_ecdsa_public',
                                'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:59:15.811401
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector is not None

    expected_ssh_pub_key_fact_ids = set(['ssh_host_pub_keys',
                                         'ssh_host_key_dsa_public',
                                         'ssh_host_key_rsa_public',
                                         'ssh_host_key_ecdsa_public',
                                         'ssh_host_key_ed25519_public'])

    assert ssh_pub_key_fact_collector._fact_ids == expected_ssh_pub_key_fact_ids

# Generated at 2022-06-23 01:59:27.275377
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class TestModule:
        def __init__(self):
            self.params = {'gather_subset': ['!all', 'min']}

    class TestFacts:
        def __init__(self):
            self.system = 'Linux'
            self.distribution = 'CentOS'

    facts = TestFacts()

    collector = SshPubKeyFactCollector(
        module=TestModule(),
        collected_facts=facts)

    ansible_facts = collector.collect()

    if isinstance(ansible_facts, dict):
        ansible_facts_ssh_pub_keys = ansible_facts.get('ssh_pub_keys', {})
    else:
        ansible_facts_ssh_pub_keys = {}

    # assert that the ssh_pub_keys facts exist

# Generated at 2022-06-23 01:59:34.915064
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshpubkeyfc = SshPubKeyFactCollector()
    assert sshpubkeyfc.name == 'ssh_pub_keys'
    assert sshpubkeyfc._fact_ids == set(['ssh_host_pub_keys',
                                'ssh_host_key_dsa_public',
                                'ssh_host_key_rsa_public',
                                'ssh_host_key_ecdsa_public',
                                'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:59:36.740338
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    test = SshPubKeyFactCollector()
    assert isinstance(test, SshPubKeyFactCollector)

# Generated at 2022-06-23 01:59:39.401098
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    facts = SshPubKeyFactCollector()
    assert facts.name == 'ssh_pub_keys'
    assert facts._fact_ids == set(['ssh_host_pub_keys',
                                   'ssh_host_key_dsa_public',
                                   'ssh_host_key_rsa_public',
                                   'ssh_host_key_ecdsa_public',
                                   'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:59:40.210879
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    p = SshPubKeyFactCollector()
    assert p.collect() == {}

# Generated at 2022-06-23 01:59:45.213018
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Test SshPubKeyFactCollector.collect - dsa, rsa, ecdsa, ed25519 keys
    Return a list of ssh_host_*_key.pub key files that exist
    """
    from ansible.module_utils.facts.collector import FactCollector
    import os
    import tempfile
    import shutil
    import textwrap
    import pytest

    # create temporary directories to emulate /etc/ssh, /etc/openssh, /etc
    tmpdir1 = tempfile.mkdtemp()
    tmpdir2 = tempfile.mkdtemp()
    tmpdir3 = tempfile.mkdtemp()

    # list of dsa keyfiles to create

# Generated at 2022-06-23 01:59:49.692087
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Init
    ssh_pub_key_facts = SshPubKeyFactCollector()
    # Execute
    ssh_pub_key_facts.collect()
    # Verify
    ssh_pub_key_facts._fact_ids

# Generated at 2022-06-23 01:59:56.828627
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_facts_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts_collector._fact_ids == set(['ssh_host_pub_keys',
                                                         'ssh_host_key_dsa_public',
                                                         'ssh_host_key_rsa_public',
                                                         'ssh_host_key_ecdsa_public',
                                                         'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:59:58.702802
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    SshPubKeyFactCollector().collect()

# Generated at 2022-06-23 02:00:05.279632
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == "ssh_pub_keys"
    assert obj._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 02:00:09.981041
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_factCollector = SshPubKeyFactCollector()
    assert ssh_pub_key_factCollector.name == 'ssh_pub_keys'
    assert ssh_pub_key_factCollector._fact_ids != None
    assert ssh_pub_key_factCollector.collect != None

# Generated at 2022-06-23 02:00:16.192729
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])