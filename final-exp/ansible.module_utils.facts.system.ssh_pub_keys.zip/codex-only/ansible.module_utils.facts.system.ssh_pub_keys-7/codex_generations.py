

# Generated at 2022-06-23 01:50:22.688387
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    col = SshPubKeyFactCollector()
    assert col.name == 'ssh_pub_keys'
    assert col._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:50:34.469256
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test arguments
    module = None
    collected_facts = {}

    # Test return values
    ssh_pub_key_facts = {}
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')

    # Test name, collected_facts and _fact_ids
    c = SshPubKeyFactCollector()
    assert c.name == 'ssh_pub_keys'
    assert c._fact_ids == {'ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'}

    # Test collect
    for algo in algos:
        factname = 'ssh_host_key_%s_public'

# Generated at 2022-06-23 01:50:42.130463
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    c = SshPubKeyFactCollector()
    c._module = MockModule()
    data = c.collect()
    assert data
    if data["ssh_host_key_rsa_public"]:
        assert data["ssh_host_key_rsa_public_keytype"]
    if data["ssh_host_key_dsa_public"]:
        assert data["ssh_host_key_dsa_public_keytype"]
    if data["ssh_host_key_ecdsa_public"]:
        assert data["ssh_host_key_ecdsa_public_keytype"]
    if data["ssh_host_key_ed25519_public"]:
        assert data["ssh_host_key_ed25519_public_keytype"]

# Mock object used for unit tests

# Generated at 2022-06-23 01:50:43.236187
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # TODO: implement
    pass

# Generated at 2022-06-23 01:50:46.190533
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    class FakeModule(object):
        def __init__(self):
            self.facts = {}
    module = FakeModule()
    collector = SshPubKeyFactCollector(module=module)
    assert collector is not None

# Generated at 2022-06-23 01:50:52.679720
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert len(ssh_pub_key_collector._fact_ids) == 5
    assert 'ssh_host_pub_keys' in ssh_pub_key_collector._fact_ids
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_collector._fact_ids
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_collector._fact_ids
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_collector._fact_ids
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_collector._fact_ids

# Generated at 2022-06-23 01:51:00.393205
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Replace global _SshPubKeyFactCollector instance with a mock
    import ansible.module_utils.facts.system.ssh_pub_keys
    ansible.module_utils.facts.system.ssh_pub_keys._SshPubKeyFactCollector = MockSshPubKeyFactCollector
    # Call module code
    import ansible.module_utils.facts.system.ssh_pub_keys
    ssh_pub_keys_module = ansible.module_utils.facts.system.ssh_pub_keys
    ssh_pub_keys_module.main()
    # Check the results
    # fail_json should not have been called
    assert not ssh_pub_keys_module.fail_json.called
    # exit_json should have been called once with a dictionary fact
    call_args, call_kwargs = ssh_pub_keys_

# Generated at 2022-06-23 01:51:04.319426
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    factCollector = SshPubKeyFactCollector()
    assert factCollector.name == 'ssh_pub_keys'
    assert factCollector.fact_ids == {'ssh_host_pub_keys',
                                      'ssh_host_key_dsa_public',
                                      'ssh_host_key_rsa_public',
                                      'ssh_host_key_ecdsa_public',
                                      'ssh_host_key_ed25519_public'}


# Generated at 2022-06-23 01:51:13.335421
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:51:23.357860
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()

    facts = {}


# Generated at 2022-06-23 01:51:32.394426
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    facts = ssh_pub_key_fact_collector.collect()
    assert facts, "Facts are None"
    assert len(facts) > 0, "Facts are empty"
    assert 'ssh_host_key_rsa_public' in facts, \
        "Expected fact 'ssh_host_key_rsa_public' is missing"
    assert 'ssh_host_key_rsa_public_keytype' in facts, \
        "Expected fact 'ssh_host_key_rsa_public_keytype' is missing"
    assert 'ssh_host_key_dsa_public' not in facts, \
        "Fact 'ssh_host_key_dsa_public' is present"

# Generated at 2022-06-23 01:51:41.498262
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # create an instance of SshPubKeyFactCollector
    module = None
    collected_facts = None
    ssh_pub_key_facts = {}
    ssh_pub_key_facts_collector = SshPubKeyFactCollector(module=module, collected_facts=collected_facts, ssh_pub_key_facts=ssh_pub_key_facts)

    # try to collect the ssh_pub_key_fact, should return a dict of all the SSH public keys
    ssh_pub_key_facts = ssh_pub_key_facts_collector.collect()

# Generated at 2022-06-23 01:51:51.140111
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.facts = {}
            self.tmpdir = '/tmp'

    class MockFiles(object):
        def __init__(self):
            self.files = {}

    def mock_get_file_content(file, default=None):
        return MockFiles.files[file]

    SshPubKeyFactCollector.collect(module=MockModule())
    collected_facts = SshPubKeyFactCollector.collect(module=MockModule())

    assert collected_facts == {}


# Generated at 2022-06-23 01:51:56.445502
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    keys = SshPubKeyFactCollector()
    assert isinstance(keys.collect(), dict)

# Generated at 2022-06-23 01:51:59.646646
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshkey_obj = SshPubKeyFactCollector()
    assert sshkey_obj.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:52:09.975208
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    import os

    # Create and populate temporary directory with mock keys
    test_dir = '/tmp/ansible_test_ssh_pub_keys'

    os.mkdir(test_dir)
    os.mkdir(os.path.join(test_dir, 'ssh'))
    os.mkdir(os.path.join(test_dir, 'openssh'))

    for algo in ('dsa', 'rsa', 'ecdsa', 'ed25519'):
        with open(os.path.join(test_dir, 'ssh', 'ssh_host_%s_key.pub' % algo), 'w') as f:
            f.writelines(['%s AAAA %s\n' % (algo, algo)])


# Generated at 2022-06-23 01:52:21.654492
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    fact_collector = SshPubKeyFactCollector()
    result = fact_collector.collect(module=module)


# Generated at 2022-06-23 01:52:23.127451
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    s = SshPubKeyFactCollector()
    assert isinstance(s, object)

# Generated at 2022-06-23 01:52:26.970685
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    name = obj.name
    assert name == 'ssh_pub_keys'
    fact_ids = obj._fact_ids
    assert ('ssh_host_key_dsa_public' in fact_ids)

# Generated at 2022-06-23 01:52:30.647988
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    SshPubKeyFactCollector._load_platform_subclass = Mock(return_value=SshPubKeyFactCollector)
    sshpubkey = SshPubKeyFactCollector()
    assert sshpubkey.collect() == {}


# Generated at 2022-06-23 01:52:40.303254
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()

    assert ssh_pub_key_facts['ssh_host_key_dsa_public'].startswith('ssh-dss')
    assert ssh_pub_key_facts['ssh_host_key_rsa_public'].startswith('ssh-rsa')
    assert ssh_pub_key_facts['ssh_host_key_ecdsa_public'].startswith('ecdsa-sha2-nistp256')
    assert ssh_pub_key_facts['ssh_host_key_ed25519_public'].startswith('ssh-ed25519')

# Generated at 2022-06-23 01:52:49.805116
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                           'ssh_host_key_dsa_public',
                                           'ssh_host_key_rsa_public',
                                           'ssh_host_key_ecdsa_public',
                                           'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:52:51.970556
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:52:54.685624
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    sshPubKeyFactCollector = SshPubKeyFactCollector()
    result = sshPubKeyFactCollector.collect()

    assert result is not None


# Generated at 2022-06-23 01:53:05.390323
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert len(ssh_pub_key_fact_collector._fact_ids) == 5
    assert 'ssh_host_pub_keys' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_ed25519_public'

# Generated at 2022-06-23 01:53:07.645873
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:53:12.736216
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    assert ssh_pub_key_facts['ssh_host_key_rsa_public'] is not None
    assert ssh_pub_key_facts['ssh_host_key_rsa_public_keytype'] is not None

# Generated at 2022-06-23 01:53:16.572852
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == "ssh_pub_keys"
    assert ssh_pub_key_facts._fact_ids == set(['ssh_host_pub_keys',
                                               'ssh_host_key_dsa_public','ssh_host_key_rsa_public','ssh_host_key_ecdsa_public','ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:53:28.042599
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Test SshPubKeyFactCollector.collect()"""

    # Helper to test SshPubKeyFactCollector.collect()
    #
    # Expected values are defined in ssh_pub_key_mock_ssh_pub_key_facts.
    # By default the mock_open built-into the unittest.mock module does not
    # accept unicode, so a custom mock_open function is used. The second_call
    # parameter, index and value, is used to get a different return value for
    # the second and suceeding calls.

    import os
    import unittest.mock as mock
    from ansible.module_utils.facts.utils import get_file_content

    from ansible.module_utils.facts.collector import BaseFactCollector

# Generated at 2022-06-23 01:53:34.233566
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    _fact_ids = set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])
    assert obj._fact_ids.__len__() == _fact_ids.__len__()
    assert obj._fact_ids == _fact_ids


# Generated at 2022-06-23 01:53:47.902837
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create a class to test against
    class Testclass:
        def __init__(self, data):
            self.__data = data

        """Mock of the readlines method.
        """
        def readlines(self):
            return self.__data

    # Mock of the open method

# Generated at 2022-06-23 01:53:51.016086
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    o = SshPubKeyFactCollector()
    assert o is not None

# Unit test SshPubKeyFactCollector.name

# Generated at 2022-06-23 01:54:00.812648
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector = SshPubKeyFactCollector()
    collected_facts = {}
    facts_dict = fact_collector.collect(None, collected_facts)


# Generated at 2022-06-23 01:54:04.968385
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Constructor test:
    # Create an instance of SshPubKeyFactCollector
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_collector, SshPubKeyFactCollector)

# Generated at 2022-06-23 01:54:10.666290
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'
    assert collector._fact_ids == set(['ssh_host_pub_keys',
                                       'ssh_host_key_dsa_public',
                                       'ssh_host_key_rsa_public',
                                       'ssh_host_key_ecdsa_public',
                                       'ssh_host_key_ed25519_public'])
    assert collector.options == {}

# Generated at 2022-06-23 01:54:11.943146
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-23 01:54:22.806491
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = Mock()
    keydirs = ['/etc/ssh', '/etc/openssh', '/etc']

    class SshPubKeyFactCollectorTest(SshPubKeyFactCollector):
        pass

    collector = SshPubKeyFactCollectorTest()
    res = collector.collect(module)

# Generated at 2022-06-23 01:54:28.418139
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Test constructor of class SshPubKeyFactCollector
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'
    assert collector._fact_ids == set(['ssh_host_pub_keys',
                                       'ssh_host_key_dsa_public',
                                       'ssh_host_key_rsa_public',
                                       'ssh_host_key_ecdsa_public',
                                       'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:54:40.025618
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
    SshPubKeyFactCollector.collect: adds a fact for each supported key type
    (dsa, rsa, ecdsa, ed25519) with the content of the corresponding
    public keyfile, or an empty string if the keyfile does not exist.
    """
    import os
    import tempfile

    from ansible.module_utils.facts.collector import Cache

    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.facts.collectors.ssh_pub_key import SshPubKeyFactCollector

    # Create a directory for the temporary key files, then create
    # temporary files for DSA and RSA keyfiles.
    # We are going to test for the public keys, but we need the
    # private keys as well to be able to generate the public keys.

# Generated at 2022-06-23 01:54:46.621338
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector = SshPubKeyFactCollector()
    assert fact_collector.name == 'ssh_pub_keys'
    assert fact_collector._fact_ids == set([
        'ssh_host_pub_keys',
        'ssh_host_key_dsa_public',
        'ssh_host_key_rsa_public',
        'ssh_host_key_ecdsa_public',
        'ssh_host_key_ed25519_public',
    ])

# Generated at 2022-06-23 01:54:55.852063
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    assert isinstance(ssh_pub_key_facts, dict)
    assert len(ssh_pub_key_facts) == 10
    assert ssh_pub_key_facts['ssh_host_key_rsa_public'] == 'ssh-rsa '
    assert ssh_pub_key_facts['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa'
    assert ssh_pub_key_facts['ssh_host_key_ecdsa_public'] == 'ecdsa-sha2-nistp256 '
    assert ssh_pub_key_facts['ssh_host_key_ecdsa_public_keytype'] == 'ecdsa-sha2-nistp256'

# Generated at 2022-06-23 01:55:00.020482
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    t = SshPubKeyFactCollector()
    assert t.name == 'ssh_pub_keys'
    assert t._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:55:02.751014
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    my_obj = SshPubKeyFactCollector()
    assert my_obj.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:55:03.340209
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-23 01:55:08.113739
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    testobj = SshPubKeyFactCollector()
    assert testobj.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:55:10.913642
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    iface = SshPubKeyFactCollector()
    result = iface.collect()
    print(result)
    assert isinstance(result['ssh_host_key_rsa_public'], str)

if __name__ == '__main__':
    test_SshPubKeyFactCollector_collect()

# Generated at 2022-06-23 01:55:12.337112
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == "ssh_pub_keys"

# Generated at 2022-06-23 01:55:18.851494
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils.facts.system.ssh_pub_keys import SshPubKeyFactCollector
    c = SshPubKeyFactCollector()
    assert not isinstance(c, BaseFactCollector)
    assert not isinstance(c, Collector)

# Generated at 2022-06-23 01:55:21.596308
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshfact = SshPubKeyFactCollector()
    assert sshfact.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:55:23.768978
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact = SshPubKeyFactCollector()
    assert ssh_pub_key_fact.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:55:32.252191
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_collector._fact_ids == set(['ssh_host_pub_keys',
                                                   'ssh_host_key_dsa_public',
                                                   'ssh_host_key_rsa_public',
                                                   'ssh_host_key_ecdsa_public',
                                                   'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:55:34.086802
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:55:40.818965
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector.collect()
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_dsa_public_keytype' in ssh_pub_key_facts
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts

# Generated at 2022-06-23 01:55:47.874002
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # instance of a SshPubKeyFactCollector object
    # initialize a base class object
    base = BaseFactCollector()
    ssh_obj = SshPubKeyFactCollector(None, None, base)

    # assert statements to test return of method collect

# Generated at 2022-06-23 01:55:49.798406
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    cl = SshPubKeyFactCollector()
    assert cl.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:56:01.796472
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    fact_collector = SshPubKeyFactCollector()
    facts = {}


# Generated at 2022-06-23 01:56:08.590743
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                                   'ssh_host_key_dsa_public',
                                                   'ssh_host_key_rsa_public',
                                                   'ssh_host_key_ecdsa_public',
                                                   'ssh_host_key_ed25519_public'])

# vim: set et ts=4 sts=4 sw=4 :

# Generated at 2022-06-23 01:56:09.383079
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # unit test for collect method
    pass

# Generated at 2022-06-23 01:56:10.316362
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
  x = SshPubKeyFactCollector()

# Generated at 2022-06-23 01:56:19.767705
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_collector._fact_ids == set(['ssh_host_pub_keys',
                                                   'ssh_host_key_dsa_public',
                                                   'ssh_host_key_rsa_public',
                                                   'ssh_host_key_ecdsa_public',
                                                   'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:56:26.621842
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKey = SshPubKeyFactCollector()

    assert sshPubKey.name == 'ssh_pub_keys'
    assert sshPubKey._fact_ids == set([
        'ssh_host_pub_keys',
        'ssh_host_key_dsa_public',
        'ssh_host_key_rsa_public',
        'ssh_host_key_ecdsa_public',
        'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:56:28.372453
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'
    assert collector.priority == 80

# Generated at 2022-06-23 01:56:37.533153
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # default constructor, need to call the setup(module) method
    # to do the initialization
    fact_collector = SshPubKeyFactCollector()
    fact_collector.setup(None)
    facts = fact_collector.collect()

    assert len(facts) == 6
    assert 'ssh_host_key_dsa_public' in facts
    assert 'ssh_host_key_rsa_public' in facts
    assert 'ssh_host_key_ecdsa_public' in facts
    assert 'ssh_host_key_ed25519_public' in facts
    assert 'ssh_host_key_dsa_public_keytype' in facts
    assert 'ssh_host_key_rsa_public_keytype' in facts

# Generated at 2022-06-23 01:56:48.761537
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:56:52.007178
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts.collectors.network import SshPubKeyFactCollector
    k = SshPubKeyFactCollector()
    assert k.collect() == {}

# Generated at 2022-06-23 01:56:53.466246
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Testing with default values
    SshPubKeyFactCollector.collect()

# Generated at 2022-06-23 01:56:59.423943
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'
    assert collector.priority == 10
    assert collector._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public',
                                       'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public',
                                       'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:57:08.795382
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collector = SshPubKeyFactCollector()
    facts = collector.collect(module)

    # The keyfiles are supposed to exist on the system and all return the
    # same keys. In case the system has no keyfiles we assume the return is
    # empty.
    if facts:
        assert len(facts) == 5

# Generated at 2022-06-23 01:57:12.089537
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    result = SshPubKeyFactCollector()
    assert 'ssh_host_key_dsa_public_keytype' in result._fact_ids


# Generated at 2022-06-23 01:57:22.371326
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:57:30.629216
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector = None
    fact_collector = SshPubKeyFactCollector()
    assert fact_collector.name == 'ssh_pub_keys'
    assert len(fact_collector._fact_ids) == 5
    assert 'ssh_host_pub_keys' in fact_collector._fact_ids
    assert 'ssh_host_key_dsa_public' in fact_collector._fact_ids
    assert 'ssh_host_key_rsa_public' in fact_collector._fact_ids
    assert 'ssh_host_key_ecdsa_public' in fact_collector._fact_ids
    assert 'ssh_host_key_ed25519_public' in fact_collector._fact_ids


# Generated at 2022-06-23 01:57:40.399091
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:57:44.533263
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_SshPubKeyFactCollector = SshPubKeyFactCollector()
    assert test_SshPubKeyFactCollector.collect() == {}

# Generated at 2022-06-23 01:57:48.144496
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    '''
    Unit test for constructor of class SshPubKeyFactCollector
    '''
    SshPubKeyFactCollector()

# Generated at 2022-06-23 01:57:51.042212
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh = SshPubKeyFactCollector()
    assert ssh.name == 'ssh_pub_keys'
    assert ssh._fact_ids == {'ssh_host_pub_keys',
                             'ssh_host_key_dsa_public',
                             'ssh_host_key_rsa_public',
                             'ssh_host_key_ecdsa_public',
                             'ssh_host_key_ed25519_public'}

# Generated at 2022-06-23 01:57:57.472569
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import NETWORK_INTERFACE_ORDER
    ssh_fact_collector = FactCollector()
    ssh_pub_key_collector = SshPubKeyFactCollector()

    facts = ssh_pub_key_collector.collect()
    assert 'ssh_host_key_dsa_public' in facts

# Generated at 2022-06-23 01:58:00.542738
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_keys = SshPubKeyFactCollector()
    ssh_facts = ssh_pub_keys.collect()
    assert 'ssh_host_key_dsa_public' in ssh_facts

# Generated at 2022-06-23 01:58:03.169633
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == "ssh_pub_keys"
    assert len(ssh_pub_key_collector._fact_ids) == 5

# Generated at 2022-06-23 01:58:10.328423
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'
    assert collector._fact_ids == set(['ssh_host_pub_keys',
                                       'ssh_host_key_dsa_public',
                                       'ssh_host_key_rsa_public',
                                     'ssh_host_key_ecdsa_public',
                                     'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:58:14.572861
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'
    assert collector._fact_ids == set(['ssh_host_pub_keys',
                                       'ssh_host_key_dsa_public',
                                       'ssh_host_key_rsa_public',
                                       'ssh_host_key_ecdsa_public',
                                       'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:58:25.434574
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector('ssh_pub_keys')
    fact_result = {'ssh_host_key_ecdsa_public': 'ecdsa-sha2-nistp256 AAAA...',
                   'ssh_host_key_ecdsa_public_keytype': 'ecdsa-sha2-nistp256',
                   'ssh_host_key_ed25519_public': 'ssh-ed25519 AAAA...',
                   'ssh_host_key_ed25519_public_keytype': 'ssh-ed25519',
                   'ssh_host_key_rsa_public': 'ssh-rsa AAAA...',
                   'ssh_host_key_rsa_public_keytype': 'ssh-rsa'}

    # Monkeypatch _get_file_content

# Generated at 2022-06-23 01:58:36.284302
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector().name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector()._fact_ids == \
           set(['ssh_host_pub_keys',
                'ssh_host_key_dsa_public',
                'ssh_host_key_rsa_public',
                'ssh_host_key_ecdsa_public',
                'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:58:44.238785
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKeyFactCollector = SshPubKeyFactCollector()
    assert sshPubKeyFactCollector.name == "ssh_pub_keys"
    assert sshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:58:53.513739
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import collector

    mock_fact_collector_module = {
        'get_file_content': lambda x: "ssh-rsa keydata"}

    mock_collected_facts = {
        'ssh_host_pub_keys': "",
        'ssh_host_key_dsa_public': "",
        'ssh_host_key_rsa_public': "",
        'ssh_host_key_ecdsa_public': "",
        'ssh_host_key_ed25519_public': "",
    }

    ssh_pub_key_fact_collector = SshPubKeyFactCollector(mock_fact_collector_module,
                                                             mock_collected_facts)

    facts = ssh_pub_key_fact_collector.collect()


# Generated at 2022-06-23 01:58:58.690259
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'
    assert collector._fact_ids == set(['ssh_host_pub_keys',
                                       'ssh_host_key_dsa_public',
                                       'ssh_host_key_rsa_public',
                                       'ssh_host_key_ecdsa_public',
                                       'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:59:06.450228
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:59:11.852931
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_collector._fact_ids == set(['ssh_host_pub_keys',
                                                   'ssh_host_key_dsa_public',
                                                   'ssh_host_key_rsa_public',
                                                   'ssh_host_key_ecdsa_public',
                                                   'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:59:15.381308
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                                        'ssh_host_key_dsa_public',
                                                        'ssh_host_key_rsa_public',
                                                        'ssh_host_key_ecdsa_public',
                                                        'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:59:23.804308
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:59:30.809983
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:59:38.383601
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:59:45.048117
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:59:54.319417
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
    Test that the SshPubKeyFactCollector class can collect
    the ssh public keys in the order of the list of key directories,
    with the first set of keys found by key type
    """
    import tempfile
    import os.path
    import os


# Generated at 2022-06-23 02:00:03.749416
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    key_collector = SshPubKeyFactCollector()
    assert isinstance(key_collector, BaseFactCollector)
    assert key_collector.name == 'ssh_pub_keys'
    assert key_collector._fact_ids == set(['ssh_host_pub_keys',
                                           'ssh_host_key_dsa_public',
                                           'ssh_host_key_rsa_public',
                                           'ssh_host_key_ecdsa_public',
                                           'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 02:00:13.910337
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import tempfile
    import os

    # a directory for temporary files
    tmpdir = tempfile.gettempdir()

    # collect facts from a temp directory
    # no facts should be collected as there are no keys in this dir
    result = SshPubKeyFactCollector().collect({'_tempdir': tmpdir})
    assert result == {}

    # create a temporary key files
    temp_files = []
    for algo in ('dsa', 'rsa', 'ecdsa', 'ed25519'):
        key_file_path = os.path.join(tmpdir, 'ssh_host_%s_key.pub' % algo)
        temp_files.append(key_file_path)

# Generated at 2022-06-23 02:00:24.491831
# Unit test for method collect of class SshPubKeyFactCollector