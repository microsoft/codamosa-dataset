

# Generated at 2022-06-23 01:50:14.470881
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-23 01:50:24.193315
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                                        'ssh_host_key_dsa_public',
                                                        'ssh_host_key_rsa_public',
                                                        'ssh_host_key_ecdsa_public',
                                                        'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:50:34.751824
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''
    Testing SshPubKeyFactCollector.collect by loading
    a set of keys from files and then checking them
    '''
    import os
    import os.path
    import tempfile
    import shutil

    # load keys from files
    fixture_dir = os.path.join(os.path.dirname(__file__), 'fixtures')

    keydir = tempfile.mkdtemp()

# Generated at 2022-06-23 01:50:40.839553
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create object under test
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # Create a module
    module = type('', (), {})

    # Create a collected facts and add necessary facts
    collected_facts = dict()
    collected_facts['_ansible_no_log'] = False

    # Test collect method
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect(module, collected_facts)
    assert ssh_pub_key_facts is not None, 'Invalid ssh_pub_key_facts'

# Generated at 2022-06-23 01:50:47.072173
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c = SshPubKeyFactCollector()
    assert c.name == 'ssh_pub_keys'
    assert c._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])



# Generated at 2022-06-23 01:50:54.211549
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c = SshPubKeyFactCollector(None)
    assert c.name == 'ssh_pub_keys'
    assert isinstance(c.fact_ids, set)
    assert c.fact_ids == set(['ssh_host_pub_keys',
                              'ssh_host_key_dsa_public',
                              'ssh_host_key_rsa_public',
                              'ssh_host_key_ecdsa_public',
                              'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:50:59.895315
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:51:01.189430
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    c = SshPubKeyFactCollector()
    c.collect()


# Generated at 2022-06-23 01:51:11.833301
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:51:17.885209
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set([
            'ssh_host_pub_keys',
            'ssh_host_key_dsa_public',
            'ssh_host_key_rsa_public',
            'ssh_host_key_ecdsa_public',
            'ssh_host_key_ed25519_public'
        ])

# Generated at 2022-06-23 01:51:24.362064
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts._fact_ids == set(['ssh_host_pub_keys',
                                               'ssh_host_key_dsa_public',
                                               'ssh_host_key_rsa_public',
                                               'ssh_host_key_ecdsa_public',
                                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:51:26.347808
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    facts = SshPubKeyFactCollector()
    assert facts.name == 'ssh_pub_keys'
    assert facts.collect() == {}

# Generated at 2022-06-23 01:51:37.653378
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:51:48.181810
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collectors.ssh_pub_keys import SshPubKeyFactCollector
    import os
    import tempfile
    import shutil
    import sys

    # for tests we just make sure that the helper functions
    # are being called with the expected parameters

    testdir = "/tmp/ansible_test_facts_ssh_pub_keys"
    os.makedirs(testdir)

    # initialize a ssh-keygen-like file structure that
    # the helper functions understand
    # we need to do this because we can't really
    # test the functions themselfs in a psudo-sandbox
    # because they need root to write and read keys
    #
    # also, we have to make sure that the SshPubKeyFactCollector
    # class is using the right keysdir (in this case '/

# Generated at 2022-06-23 01:51:58.754140
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Unit test doesn't work on Windows, so this is skipped
    import sys
    if sys.platform.startswith('win'):
        return

    import os
    import shutil
    import tempfile

    # create directory for testing
    tmpdir = tempfile.mkdtemp(prefix='ansible_fact_tests.tmp_SshPubKeyFactCollector_collect')
    f = open(os.path.join(tmpdir, 'ssh_host_dsa_key.pub'), 'w')

# Generated at 2022-06-23 01:51:59.798026
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    SshPubKeyFactCollector.collect()

# Generated at 2022-06-23 01:52:06.200597
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c = SshPubKeyFactCollector()
    assert c.name == 'ssh_pub_keys'
    assert c._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:52:07.441901
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert True

# Generated at 2022-06-23 01:52:16.114396
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    module = None
    collected_facts = {}
    result = collector.collect(module, collected_facts)
    assert 'ssh_host_key_dsa_public' in result
    assert 'ssh_host_key_dsa_public_keytype' in result
    assert 'ssh_host_key_rsa_public' in result
    assert 'ssh_host_key_rsa_public_keytype' in result
    assert 'ssh_host_key_ecdsa_public' in result
    assert 'ssh_host_key_ecdsa_public_keytype' in result
    assert 'ssh_host_key_ed25519_public' in result
    assert 'ssh_host_key_ed25519_public_keytype' in result

# Generated at 2022-06-23 01:52:26.123813
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    '''
    Test constructor of class SshPubKeyFactCollector
    '''

    # Create instance of class SshPubKeyFactCollector
    ssh_pub_key_facts = SshPubKeyFactCollector()

    # Save the original value of name attribute
    original_name = ssh_pub_key_facts.name

    # Verify that name attribute contains valid value
    assert original_name == 'ssh_pub_keys'

    # Save the original value of _fact_ids attribute
    original_fact_ids = ssh_pub_key_facts._fact_ids

    # Verify that _fact_ids attribute contains valid value

# Generated at 2022-06-23 01:52:35.202525
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector().name == 'ssh_pub_keys'
    assert sorted(SshPubKeyFactCollector()._fact_ids) == sorted(set(['ssh_host_pub_keys',
                 'ssh_host_key_dsa_public', 'ssh_host_key_dsa_public_keytype',
                 'ssh_host_key_rsa_public', 'ssh_host_key_rsa_public_keytype',
                 'ssh_host_key_ecdsa_public', 'ssh_host_key_ecdsa_public_keytype',
                 'ssh_host_key_ed25519_public', 'ssh_host_key_ed25519_public_keytype']))

# Generated at 2022-06-23 01:52:42.268590
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert sorted(ssh_pub_key_fact_collector._fact_ids) == sorted([
        'ssh_host_pub_keys',
        'ssh_host_key_dsa_public',
        'ssh_host_key_rsa_public',
        'ssh_host_key_ecdsa_public',
        'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:52:46.162520
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshpubkeyfacts = SshPubKeyFactCollector()
    assert sorted(sshpubkeyfacts._fact_ids) == sorted(['ssh_host_pub_keys',
                                              'ssh_host_key_dsa_public',
                                              'ssh_host_key_rsa_public',
                                              'ssh_host_key_ecdsa_public',
                                              'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:52:55.790766
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = {}
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')

    for algo in algos:
        ssh_pub_key_facts['ssh_host_key_%s_public' % algo] = '%s_pub_key' % algo
        ssh_pub_key_facts['ssh_host_key_%s_public_keytype' % algo] = '%s_pub_key_keytype' % algo
    ssh_pub_key_facts['ssh_host_pub_keys'] = 'ssh_host_pub_keys'

    assert SshPubKeyFactCollector().collect() == ssh_pub_key_facts

# Generated at 2022-06-23 01:52:58.542389
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'


# Generated at 2022-06-23 01:53:00.140089
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-23 01:53:03.325685
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector(None, None).collect()

    assert ssh_pub_key_facts == {}, ssh_pub_key_facts

# Generated at 2022-06-23 01:53:08.325382
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import collector

    module_mock = Mock()
    facts_mock = Mock()

    collector_obj = SshPubKeyFactCollector(module_mock, facts_mock)
    test_ssh_pub_key_facts = collector_obj.collect()

    assert test_ssh_pub_key_facts



# Generated at 2022-06-23 01:53:18.508728
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import ansible.module_utils.facts.collector
    import os
    import tempfile
    import pytest

    ssh_pub_key_facts = SshPubKeyFactCollector()
    algos = ['rsa', 'dsa', 'ecdsa', 'ed25519']

    @pytest.fixture(autouse=True)
    def createtmpdir(request):
        temp_dir = tempfile.mkdtemp(prefix='ansible_facts')
        temp_ssh_dir = temp_dir + "/" + "ssh"
        os.mkdir(temp_ssh_dir)
        original_path = ansible.module_utils.facts.collector.PATH
        ansible.module_utils.facts.collector.PATH = temp_ssh_dir


# Generated at 2022-06-23 01:53:21.416032
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:53:26.828374
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:53:27.745049
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-23 01:53:33.623741
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector = SshPubKeyFactCollector()
    assert fact_collector.name == 'ssh_pub_keys'
    assert fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                            'ssh_host_key_dsa_public',
                                            'ssh_host_key_rsa_public',
                                            'ssh_host_key_ecdsa_public',
                                            'ssh_host_key_ed25519_public'])



# Generated at 2022-06-23 01:53:43.594016
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    tmpdir = tempfile.mkdtemp()
    os.mkdir(os.path.join(tmpdir, 'ssh'))
    os.mkdir(os.path.join(tmpdir, 'openssh'))
    os.mkdir(os.path.join(tmpdir, 'no_ssh'))

    # Test the case when the directory /etc/ssh or /etc/openssh does not exist
    fact = SshPubKeyFactCollector()
    result = fact.collect()
    assert result == {}

    # Test the case when the key files are in /etc/ssh
    ssh_dir = os.path.join(tmpdir, 'ssh')

# Generated at 2022-06-23 01:53:50.429168
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:53:58.851819
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == "ssh_pub_keys"
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])

if __name__ == '__main__':
    test_SshPubKeyFactCollector()

# Generated at 2022-06-23 01:54:04.312120
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    with open("tests/unit/module_utils/facts/collector/ssh_pub_key_facts.txt", 'r') as f:
        expected_output = f.read()
    output = obj.collect()
    assert expected_output == str(output)

# Generated at 2022-06-23 01:54:13.451267
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ''' Unit test for method collect of class SshPubKeyFactCollector '''

    # Setup
    ssh_then_openssh_keydirs = ['/etc/ssh', '/etc/openssh', '/etc']
    openssh_then_ssh_keydirs = ['/etc/openssh', '/etc/ssh', '/etc']
    nokey_keydirs = ['/etc']

    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    fact_ids = ssh_pub_key_fact_collector._fact_ids


# Generated at 2022-06-23 01:54:24.213902
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Patch os.uname to return specific value for a Linux system
    import os
    import platform

    class uname:
        def __init__(self):
            self.system = 'Linux'
            self.node = 'ansible'
            self.release = '3.10.0-123.20.1.el7.x86_64'
            self.version = '#1 SMP Thu Jan 29 18:05:33 EST 2015'
            self.machine = 'x86_64'
            self.processor = 'x86_64'

    class Popen:
        def __init__(self, *args, **kwargs):
            pass


# Generated at 2022-06-23 01:54:27.917309
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''
    This is a test method for class SshPubKeyFactCollector
    '''
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    assert isinstance(ssh_pub_key_facts, dict)
    for key in ['ssh_host_key_base_public',
                'ssh_host_key_base_public_keytype']:
        assert key in ssh_pub_key_facts

# Generated at 2022-06-23 01:54:39.817510
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    import tempfile

    # test 1 - ssh keys found in /etc/ssh
    etcssh_dir = tempfile.mkdtemp(suffix='.ansible-unittest')
    setattr(Collector, '_platform', 'Linux')

# Generated at 2022-06-23 01:54:44.193754
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Test AnsibleFactsCollector method collect"""

    # We use several methods of AnsibleFactsCollector to create a Mock
    # object with all methods we need.
    mocked_collector = SshPubKeyFactCollector(None, None)
    mocked_collector.collect()

# Generated at 2022-06-23 01:54:50.898117
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'

    assert {'ssh_host_pub_keys',
            'ssh_host_key_dsa_public',
            'ssh_host_key_rsa_public',
            'ssh_host_key_ecdsa_public',
            'ssh_host_key_ed25519_public'} == ssh_pub_key_fact_collector._fact_ids

# Generated at 2022-06-23 01:55:01.658029
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
    Unit test function to test the method collect of class SshPubKeyFactCollector.
    This method returns the ssh public keys from the system if they
    are present.
    """
    base_obj = BaseFactCollector()

# Generated at 2022-06-23 01:55:07.489176
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    a = SshPubKeyFactCollector()
    assert a.name == 'ssh_pub_keys'
    assert a._fact_ids == set([
        'ssh_host_pub_keys',
        'ssh_host_key_dsa_public',
        'ssh_host_key_rsa_public',
        'ssh_host_key_ecdsa_public',
        'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:55:09.966059
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    SshPubKeyFactCollector = SshPubKeyFactCollector()
    assert SshPubKeyFactCollector.collect().keys() == set(['ansible_ssh_host_pub_keys'])


# Generated at 2022-06-23 01:55:12.390423
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """Test SshPubKeyFactCollector constructor"""

    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:55:19.693686
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()

    assert(ssh_pub_key_facts.name == 'ssh_pub_keys')
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    for algo in algos:
        factname = 'ssh_host_key_%s_public' % algo
        assert(factname in ssh_pub_key_facts._fact_ids)

# Generated at 2022-06-23 01:55:29.135401
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    test_facts = ssh_pub_key_facts.collect()
    print(test_facts)

# Generated at 2022-06-23 01:55:39.052431
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test empty collect
    result = SshPubKeyFactCollector().collect()
    assert {} == result
    # Test collect with all keys available
    result = SshPubKeyFactCollector().collect({}, {'ssh_host_pub_keys': ["ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDz/az54fKE7KdAZ== dummyhost@dummyhost"]})

# Generated at 2022-06-23 01:55:45.242729
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert set(ssh_pub_key_fact_collector._fact_ids) == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:55:52.869993
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import s_cache

    target = SshPubKeyFactCollector()
    target.collect(module=basic.AnsibleModule(argument_spec={}))

    assert 'ssh_host_key_dsa_public' in s_cache.sysinfo
    assert 'ssh_host_key_rsa_public' in s_cache.sysinfo
    assert 'ssh_host_key_ecdsa_public' in s_cache.sysinfo


# Generated at 2022-06-23 01:56:04.590021
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import tempfile
    data = dict()

# Generated at 2022-06-23 01:56:10.532693
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    keys = set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])
    assert ssh_pub_key_fact_collector._fact_ids == keys

# vim: et ts=4 sw=4

# Generated at 2022-06-23 01:56:19.583291
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_collector._fact_ids == set(['ssh_host_pub_keys',
                                                   'ssh_host_key_dsa_public',
                                                   'ssh_host_key_rsa_public',
                                                   'ssh_host_key_ecdsa_public',
                                                   'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:56:26.133501
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:56:32.835126
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:56:40.094789
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    a = SshPubKeyFactCollector()
    assert a.name == 'ssh_pub_keys'
    assert 'ssh_host_pub_keys' in a._fact_ids
    assert 'ssh_host_key_dsa_public' in a._fact_ids
    assert 'ssh_host_key_rsa_public' in a._fact_ids
    assert 'ssh_host_key_ecdsa_public' in a._fact_ids
    assert 'ssh_host_key_ed25519_public' in a._fact_ids

# Generated at 2022-06-23 01:56:49.367284
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts._fact_ids == set(['ssh_host_pub_keys',
                                               'ssh_host_key_dsa_public',
                                               'ssh_host_key_rsa_public',
                                               'ssh_host_key_ecdsa_public',
                                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:56:55.414075
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_collector._fact_ids == set(['ssh_host_pub_keys',
         'ssh_host_key_dsa_public','ssh_host_key_rsa_public','ssh_host_key_ecdsa_public','ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:57:05.478224
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile

    (fd, keyfile) = tempfile.mkstemp()
    os.write(fd, "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIF0bPVjKOP9uD7VrpYOuqsKVwKO1MiIx7VzdQ2u8h")
    os.close(fd)

    collected_facts = {
        'ssh_host_key_dsa_public': None,
        'ssh_host_key_rsa_public': None,
        'ssh_host_key_ecdsa_public': None,
        'ssh_host_key_ed25519_public': None,
    }
    fact_collector = SshPubKeyFactCollector()
    facts = fact_collector.collect

# Generated at 2022-06-23 01:57:13.319734
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector = SshPubKeyFactCollector()

    assert fact_collector.name == 'ssh_pub_keys'
    assert fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                            'ssh_host_key_dsa_public',
                                            'ssh_host_key_rsa_public',
                                            'ssh_host_key_ecdsa_public',
                                            'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:57:24.144660
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    x = SshPubKeyFactCollector()

    def get_file_content(path):
        return 'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQC1JWN2Y......'

    x.get_file_content = get_file_content

    result = x.collect()

    assert result == {
        'ssh_host_key_rsa_public': 'AAAAB3NzaC1yc2EAAAADAQABAAABAQC1JWN2Y......',
        'ssh_host_key_rsa_public_keytype': 'ssh-rsa'
    }

# Generated at 2022-06-23 01:57:28.507396
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector_class = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_class.collect()

# Generated at 2022-06-23 01:57:32.021066
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert isinstance(SshPubKeyFactCollector._fact_ids, set)
    assert len(SshPubKeyFactCollector._fact_ids) == 5

# Generated at 2022-06-23 01:57:32.680141
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-23 01:57:42.055023
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = MockModule()
    collected_facts = {}
    fact_collector = SshPubKeyFactCollector(module=module,
                                            collected_facts=collected_facts)
    fact_collector.collect()

# Generated at 2022-06-23 01:57:44.065460
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector.collect() is None

# Generated at 2022-06-23 01:57:47.240944
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert isinstance(SshPubKeyFactCollector(),SshPubKeyFactCollector)

# Generated at 2022-06-23 01:57:56.552470
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Init class object
    obj = SshPubKeyFactCollector({})

    # test 1 - keyfiles exist, returned ssh_pub_key_facts are expected
    # results

# Generated at 2022-06-23 01:58:00.057938
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshpubkeycollector = SshPubKeyFactCollector()
    assert sshpubkeycollector is not None

# Generated at 2022-06-23 01:58:07.413628
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os.path
    import tempfile
    import shutil
    import ansible.module_utils.facts.collector as fc
    import ansible.module_utils.facts.utils as futils
    import ansible.module_utils.facts.collectors.base as fbase

    tmpdir = tempfile.mkdtemp()
    keydirs = [os.path.join(tmpdir, x) for x in ['etc/ssh', 'etc/openssh', 'etc']]
    for keydir in keydirs:
        os.makedirs(keydir)

    def cleanup():
        shutil.rmtree(tmpdir)

# Generated at 2022-06-23 01:58:14.595254
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():

    # check initialisation
    fact_collector = SshPubKeyFactCollector()
    assert fact_collector.name == 'ssh_pub_keys'
    assert fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                            'ssh_host_key_dsa_public',
                                            'ssh_host_key_rsa_public',
                                            'ssh_host_key_ecdsa_public',
                                            'ssh_host_key_ed25519_public'])
    # check that collection returns empty dict when no keys are present
    ssh_pub_key_facts = fact_collector.collect()
    assert ssh_pub_key_facts == {}


# Generated at 2022-06-23 01:58:23.902095
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names

    ssh_fact_collector = get_collector_instance('ssh_pub_keys')
    ssh_fact_collector.collect()
    ssh_fact_names = get_collector_names(ssh_fact_collector)
    assert(ssh_fact_names == ['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:58:26.584422
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector = SshPubKeyFactCollector(None, None, '')
    assert fact_collector.name == "ssh_pub_keys"

# Generated at 2022-06-23 01:58:36.141922
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Test ssh pub key collect fact"""

    # Given: a mocked module, a ssh pub key fact collector and a mocked ansible module instance
    # When: collect method called on ssh pub key fact collector
    # Then: ssh pub key facts are returned
    # And: when no ssh pub key are found None is returned
    module = mock.MagicMock()
    module.params = {'gather_subset': '!all,!min,!virtual'}
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ansible_module_instance = mock.MagicMock()
    ansible_module_instance.ssh_host_key_dsa_public_keytype = 'test_keytype'
    ansible_module_instance.ssh_host_key_dsa_public = 'test_key'
    ans

# Generated at 2022-06-23 01:58:46.836711
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    collector = Collector()
    collector._module = MagicMock()

    collector.add_fact_collector(SshPubKeyFactCollector())
    mock_collector = MagicMock()
    mock_collector.name = 'mock'
    mock_collector._fact_ids = set(['mock_fact_id'])
    mock_collector.collect = MagicMock(return_value={'mock_fact': 'mock_value'})
    collector.add_fact_collector(mock_collector)

    facts = collector.collect()

    assert facts['ssh_host_key_dsa_public_keytype'] == "ssh-dss"

# Generated at 2022-06-23 01:58:58.206362
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    def test_get_file_content(path):
        if path == '/etc/ssh/ssh_host_ed25519_key.pub':
            return 'ssh-ed25519 AAAAC3V+DSA_PUBLIC_KEY= comment'
        elif path == '/etc/openssh/ssh_host_ed25519_key.pub':
            return 'ssh-ed25519 AAAAC3V+DSA_PUBLIC_KEY= comment'

# Generated at 2022-06-23 01:59:05.588914
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    try:
        import __main__
        __main__.__ansible_facts__ = dict()
    except:
        __ansible_facts__ = dict()

    SshPubKeyFactCollector().collect()
    assert 'ssh_host_key_rsa_public' in __ansible_facts__
    assert 'ssh_host_key_rsa_public_keytype' in __ansible_facts__

# Generated at 2022-06-23 01:59:06.908014
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # We are not testing the method collect of class SshPubKeyFactCollector
    pass

# Generated at 2022-06-23 01:59:12.194955
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():

    ssh_pub_key_facts = SshPubKeyFactCollector()

    assert (ssh_pub_key_facts.name == 'ssh_pub_keys')
    assert (len(ssh_pub_key_facts._fact_ids) == 5)

# The test decorator below was removed
# as it will cause the test to fail.
# A reference to the class object is already created
# when it is imported by the test_ansible_module_fact.py 
#
# @pytest.mark.usefixtures('ssh_pub_key_facts')

# Generated at 2022-06-23 01:59:23.852925
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_dsa_public_keytype' in ssh_pub_key_facts
    assert ssh_pub_key_facts['ssh_host_key_dsa_public_keytype'] == 'ssh-dss'
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts
    assert ssh_pub_key_facts['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa'

# Generated at 2022-06-23 01:59:34.667205
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = {}
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    for algo in algos:
        ssh_pub_key_facts['ssh_host_key_%s_public' % algo] = 'test'

    class MockModule(object):
        def fail_json(self, msg):
            raise AssertionError('fail_json should not have been called')
        def run_command(self, cmd, check_rc=True):
            raise AssertionError('run_command() should not have been called')

    assert SshPubKeyFactCollector(MockModule()).collect(None) == ssh_pub_key_facts

# Generated at 2022-06-23 01:59:36.617277
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # return value
    #SshPubKeyFactCollector.collect()
    return {}


# Generated at 2022-06-23 01:59:40.970237
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Test case to show collect method of class SshPubKeyFactCollector"""
    # Initialize the class SshPubKeyFactCollector
    test_class_obj = SshPubKeyFactCollector()
    # Store the method collect to a local variable
    method_collect = test_class_obj.collect
    # Check method collect returns a dict type
    assert isinstance(method_collect(), dict)

# Generated at 2022-06-23 01:59:49.168786
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fc = SshPubKeyFactCollector()
    assert fc.name == 'ssh_pub_keys'
    assert fc._fact_ids == set(['ssh_host_pub_keys',
                                'ssh_host_key_dsa_public',
                                'ssh_host_key_rsa_public',
                                'ssh_host_key_ecdsa_public',
                                'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:59:57.905284
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    keydir = '/tmp/test1_ssh_keys'
    os.makedirs(keydir)
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')

    # create fake keys
    for algo in algos:
        key_filename = '%s/ssh_host_%s_key.pub' % (keydir, algo)

# Generated at 2022-06-23 02:00:09.326127
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 02:00:15.506826
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert(x.name == 'ssh_pub_keys')
    assert(x._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public']))

