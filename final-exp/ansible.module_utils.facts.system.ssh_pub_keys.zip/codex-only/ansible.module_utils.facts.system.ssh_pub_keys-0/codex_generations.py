

# Generated at 2022-06-23 01:50:24.232430
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert 'ssh_pub_keys' == ssh_pub_key_fact_collector.name
    assert {'ssh_host_key_dsa_public',
            'ssh_host_key_rsa_public',
            'ssh_host_key_ecdsa_public',
            'ssh_host_key_ed25519_public'} == ssh_pub_key_fact_collector._fact_ids

# Generated at 2022-06-23 01:50:31.245161
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():

    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert set(SshPubKeyFactCollector._fact_ids) == set(['ssh_host_pub_keys',
                                                         'ssh_host_key_dsa_public',
                                                         'ssh_host_key_rsa_public',
                                                         'ssh_host_key_ecdsa_public',
                                                         'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:50:33.631667
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert 'ssh_host_key_dsa_public' in x._fact_ids

# Generated at 2022-06-23 01:50:39.936837
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'
    assert len(collector._fact_ids) == 5
    assert set(collector._fact_ids) == set(['ssh_host_pub_keys',
                                            'ssh_host_key_dsa_public',
                                            'ssh_host_key_rsa_public',
                                            'ssh_host_key_ecdsa_public',
                                            'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:50:49.710228
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os

    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system


# Generated at 2022-06-23 01:50:59.610105
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:51:10.669369
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    a = SshPubKeyFactCollector()
    assert a.name == 'ssh_pub_keys'

    # The following is a list of possible values for:
    # 'ssh_host_pub_keys', 'ssh_host_key_dsa_public',
    # 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public',
    # 'ssh_host_key_ed25519_public'
    assert set(a._fact_ids) == set(['ssh_host_pub_keys',
                                    'ssh_host_key_dsa_public',
                                    'ssh_host_key_rsa_public',
                                    'ssh_host_key_ecdsa_public',
                                    'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:51:13.533135
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert len(x._fact_ids) == 5

# Generated at 2022-06-23 01:51:23.516924
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os.path
    import tempfile
    import pytest

    facts = {}

    # Create all SSH keys that we use for testing, using a temp directory
    (temp_dir, temp_dir_name) = tempfile.mkstemp()

    # os.rmdir(temp_dir_name)
    os.mkdir(temp_dir_name)


    (fd, filename) = tempfile.mkstemp(prefix='ssh_host_',
                                      suffix='_key',
                                      dir=temp_dir_name)
    os.write(fd, 'foo')
    os.close(fd)

# Generated at 2022-06-23 01:51:32.495075
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = None

    s = SshPubKeyFactCollector()
    facts = s.collect(module=module, collected_facts=collected_facts)

    assert 'ssh_host_key_dsa_public' in facts
    assert 'ssh_host_key_dsa_public_keytype' in facts
    assert 'ssh_host_key_rsa_public' in facts
    assert 'ssh_host_key_rsa_public_keytype' in facts
    assert 'ssh_host_key_ecdsa_public' in facts
    assert 'ssh_host_key_ecdsa_public_keytype' in facts
    assert 'ssh_host_key_ed25519_public' in facts
    assert 'ssh_host_key_ed25519_public_keytype' in facts

# Generated at 2022-06-23 01:51:38.119113
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:51:42.919284
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class ModuleMock(object):
        pass

    ssh_pub_key_collector = SshPubKeyFactCollector()
    result = ssh_pub_key_collector.collect(ModuleMock())
    assert len(result) > 0
    for k in result:
        assert k.startswith('ssh_host_key_')

# Generated at 2022-06-23 01:51:44.804997
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == "ssh_pub_keys"

# Generated at 2022-06-23 01:51:47.902300
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    collector = FactCollector(None,
            collector_classes=[SshPubKeyFactCollector, AnsibleCollector])
    data = collector.collect(None, None)
    assert(len(data.keys()) > 0)

# Generated at 2022-06-23 01:51:49.241232
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass #todo

# Generated at 2022-06-23 01:51:55.647563
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    s = SshPubKeyFactCollector()
    assert s.name == 'ssh_pub_keys'
    assert s._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:52:07.828580
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    from ansible.module_utils.facts.utils import get_file_content

    my_collector = SshPubKeyFactCollector()

# Generated at 2022-06-23 01:52:09.108563
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-23 01:52:17.213708
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:52:23.124313
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:52:32.040670
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert 'ssh_host_pub_keys' in SshPubKeyFactCollector._fact_ids
    assert 'ssh_host_key_dsa_public' in SshPubKeyFactCollector._fact_ids
    assert 'ssh_host_key_rsa_public' in SshPubKeyFactCollector._fact_ids
    assert 'ssh_host_key_ecdsa_public' in SshPubKeyFactCollector._fact_ids
    assert 'ssh_host_key_ed25519_public' in SshPubKeyFactCollector._fact_ids

# Generated at 2022-06-23 01:52:33.418641
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert isinstance(SshPubKeyFactCollector(), SshPubKeyFactCollector)

# Generated at 2022-06-23 01:52:43.663857
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import mock
    import os

# Generated at 2022-06-23 01:52:55.212574
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    import pytest

    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils.facts.collectors.ssh_pub_keys import SshPubKeyFactCollector

    # Unit test for ssh_pub_keys collector

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-23 01:53:02.432971
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = "ansible.module_utils.facts.collector.SshPubKeyFactCollector"
    class_ = SshPubKeyFactCollector
    params = ()
    return_val = ()
    res = class_.collect(module, params)
    assert set(res.keys()).issubset(class_._fact_ids)
    # if there are no keys it must be empty
    assert len(res) == 0 or all([ '_keytype' in x for x in res.keys() ])

# Generated at 2022-06-23 01:53:13.760884
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()

    # check that ssh_host_key_*_public_keytype facts are present
    if 'ssh_host_key_dsa_public' in ssh_pub_key_facts:
        assert 'ssh_host_key_dsa_public_keytype' in ssh_pub_key_facts
    if 'ssh_host_key_rsa_public' in ssh_pub_key_facts:
        assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts
    if 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts:
        assert 'ssh_host_key_ecdsa_public_keytype' in ssh_pub_key_facts

# Generated at 2022-06-23 01:53:17.835422
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    assert isinstance(ssh_pub_key_facts, dict)
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts

# Generated at 2022-06-23 01:53:28.725386
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # create a mock module
    module = AnsibleModule(argument_spec={})
    # create a mock ansible_facts dict
    # create a mock module
    module = AnsibleModule(argument_spec={})
    # create a mock ansible_facts dict
    facts = dict()
    collected_facts = dict()
    facts['ansible_local'] = collected_facts
    # create a instance of SshPubKeyFactCollector
    sshpubkey_fc = SshPubKeyFactCollector()
    # run the execution under test
    sshpubkey_fc.collect(module=module, collected_facts=collected_facts)
    # assert that method run has been called with proper arguments

# Generated at 2022-06-23 01:53:33.070009
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = {}
    ssh_pub_key_facts_collector = SshPubKeyFactCollector()
    collected_facts = ssh_pub_key_facts_collector.collect(module=module, collected_facts=collected_facts)
    assert collected_facts == {}

# Generated at 2022-06-23 01:53:39.075471
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh = SshPubKeyFactCollector()

    assert ssh.name == 'ssh_pub_keys'

    assert(ssh._fact_ids == set(['ssh_host_pub_keys',
                             'ssh_host_key_dsa_public',
                             'ssh_host_key_rsa_public',
                             'ssh_host_key_ecdsa_public',
                             'ssh_host_key_ed25519_public']))

    # Can't currently test the 'collect' function without mocking out
    # the file reading function.

# Generated at 2022-06-23 01:53:49.965674
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create a SshPubKeyFactCollector fact collector
    fact_collector = SshPubKeyFactCollector()

    # Collect ssh keys facts
    facts = fact_collector.collect()

    # Assert keys facts have been collected
    assert facts is not None
    assert 'ssh_host_key_dsa_public' in facts
    assert 'ssh_host_key_dsa_public_keytype' in facts
    assert 'ssh_host_key_rsa_public' in facts
    assert 'ssh_host_key_rsa_public_keytype' in facts
    assert 'ssh_host_key_ecdsa_public' in facts
    assert 'ssh_host_key_ecdsa_public_keytype' in facts
    assert 'ssh_host_key_ed25519_public' in facts

# Generated at 2022-06-23 01:53:54.480189
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
 
    # Test constructor
    ssh_pub_key_facts = SshPubKeyFactCollector()
    ssh_pub_key_facts = SshPubKeyFactCollector(name='ssh_pub_keys')
    ssh_pub_key_facts = SshPubKeyFactCollector(name='ssh_pub_keys',
                                               fact_ids=['ssh_host_key_rsa_public'])

# Generated at 2022-06-23 01:54:04.217074
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    empty_collector = SshPubKeyFactCollector()

    # Creating a mocked cachable class to be used in the test
    class cachable:
        def __init__(self, value):
            self.value = value
        def cache(self):
            return self.value

    # Simulating a key with empty content
    key_empty = cachable(None)
    # Simulating a key with content
    key_content = cachable('ssh-rsa somecontent')
    # Simulating a mock_open
    mock_open = cachable(key_empty)

    # Creating a mocked module class to be used in the test
    class module:
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = []
            self.params['gather_timeout'] = 10


# Generated at 2022-06-23 01:54:13.375146
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    import unittest
    from ansible.module_utils.facts import collector

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', 'network']

    class TestSshPubKeyFactCollector(unittest.TestCase):

        def setUp(self):
            collector.collectors = []
            collector.CACHE = {}
            self.collector = SshPubKeyFactCollector()

        def tearDown(self):
            del collector.collectors[:]
            collector.CACHE = {}

        def test__get_file_content(self):
            tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 01:54:24.131161
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    testobj = SshPubKeyFactCollector()
    assert testobj is not None
    assert testobj.name is not None
    assert testobj._fact_ids is not None

    # a set of known keys to use for testing

# Generated at 2022-06-23 01:54:29.994664
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import pytest
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.ssh_pub_keys import SshPubKeyFactCollector
    import tempfile
    import subprocess

    ssh_pub_keys_fact_collector = get_collector_instance(SshPubKeyFactCollector)

# Generated at 2022-06-23 01:54:32.735428
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():

    ssh_pub_key_Collector = SshPubKeyFactCollector(None)

    ssh_pub_key_Collector.collect()

# Generated at 2022-06-23 01:54:42.293243
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    (missing_args, facts) = SshPubKeyFactCollector.test(
        module='setup', collector=SshPubKeyFactCollector)
    assert not missing_args

# Generated at 2022-06-23 01:54:47.257828
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    factCollector = SshPubKeyFactCollector()

    assert factCollector._fact_ids is not None, \
    "SshPubKeyFactCollector() object is expecting _fact_ids not to be None"

# Generated at 2022-06-23 01:54:54.856099
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_collector._fact_ids == set(['ssh_host_pub_keys',
                                                   'ssh_host_key_dsa_public',
                                                   'ssh_host_key_rsa_public',
                                                   'ssh_host_key_ecdsa_public',
                                                   'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:55:04.061542
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_paths = {
        'ssh_host_key_dsa_public': 'test/unit/ansible_collections/ansible/os_facts/files/ssh_host_dsa_key.pub',
        'ssh_host_key_rsa_public': 'test/unit/ansible_collections/ansible/os_facts/files/ssh_host_rsa_key.pub',
        'ssh_host_key_ecdsa_public': 'test/unit/ansible_collections/ansible/os_facts/files/ssh_host_ecdsa_key.pub',
        'ssh_host_key_ed25519_public': 'test/unit/ansible_collections/ansible/os_facts/files/ssh_host_ed25519_key.pub',
    }



# Generated at 2022-06-23 01:55:13.198132
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Create a SshPubKeyFactCollector and assert that name and _fact_id attributes
    # are set correctly.
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == "ssh_pub_keys"
    assert len(ssh_pub_key_fact_collector._fact_ids) == 5
    assert "ssh_host_key_dsa_public" in ssh_pub_key_fact_collector._fact_ids
    assert "ssh_host_key_rsa_public" in ssh_pub_key_fact_collector._fact_ids
    assert "ssh_host_key_ecdsa_public" in ssh_pub_key_fact_collector._fact_ids

# Generated at 2022-06-23 01:55:23.532372
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector.collect()
    assert ssh_pub_key_facts['ssh_host_key_ecdsa_public'] == 'AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBBVc/2Qq+JNkUIoLNw7VxMfH1EWYXbWY+tTKJtOyaAjK8V1zsIl+D3qJxKjBk8XA+Q2vDjKZ1DtxWDh+cWpOsTM0='

# Generated at 2022-06-23 01:55:31.415922
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect(module=None, collected_facts=None)

# Generated at 2022-06-23 01:55:40.390742
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import sys
    import os

    class MockModule:
        def __init__(self):
            self.params = {}

    class MockCollector(SshPubKeyFactCollector):
        def __init__(self, module):
            self.module = module

        def collect(self, module, collected_facts=None):
            return super(MockCollector, self).collect(module, collected_facts)

    def get_file_content(file):
        prefix = os.path.dirname(sys.modules['ansible.module_utils.facts.ssh_pub_keys'].__file__)
        fname = os.path.join(prefix, 'unit', 'unit_test_data', file)
        with open(fname, 'r') as f:
            return f.read()


# Generated at 2022-06-23 01:55:47.957246
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts._fact_ids == set(['ssh_host_pub_keys',
                                               'ssh_host_key_dsa_public',
                                               'ssh_host_key_rsa_public',
                                               'ssh_host_key_ecdsa_public',
                                               'ssh_host_key_ed25519_public'])

if __name__ == '__main__':
    test_SshPubKeyFactCollector()

# Generated at 2022-06-23 01:55:50.265092
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKeyFactCollector=SshPubKeyFactCollector()

    assert sshPubKeyFactCollector.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:56:01.795270
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    collected_facts = collector.collect()

# Generated at 2022-06-23 01:56:03.543126
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    s = SshPubKeyFactCollector()
    assert s.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:56:11.337910
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test for ssh_host_key_dsa_public_keytype and ssh_host_key_dsa_public
    key_filename = 'test/unit/utils/data/ssh_host_dsa_key.pub'
    keydata = get_file_content(key_filename)
    (keytype, key) = keydata.split()[0:2]
    assert keytype == 'ssh-dss'

# Generated at 2022-06-23 01:56:22.528827
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Test the method collect of class SshPubKeyFactCollector"""
    from ansible.module_utils.facts.collector.ssh_pub_keys import SshPubKeyFactCollector
    try:
        collector = SshPubKeyFactCollector()
    except Exception:
        e = get_exception()
        pytest.fail("Exception during SshPubKeyFactCollector.__init__(): %s" % str(e))
    result = collector.collect()
    assert result is not None
    assert len(result) > 0
    assert 'ssh_host_key_dsa_public' in result
    assert 'ssh_host_key_rsa_public' in result
    assert 'ssh_host_key_ecdsa_public' in result
    assert 'ssh_host_key_ed25519_public' in result

# Generated at 2022-06-23 01:56:30.741452
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts is not None
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts._fact_ids == \
           set(['ssh_host_pub_keys',
                'ssh_host_key_dsa_public',
                'ssh_host_key_rsa_public',
                'ssh_host_key_ecdsa_public',
                'ssh_host_key_ed25519_public'])
    assert ssh_pub_key_facts.priority == 50
    assert callable(ssh_pub_key_facts.collect)

# Unit test -- test that the collector class can be instantiated

# Generated at 2022-06-23 01:56:42.092787
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import collector
    collector.collectors['ssh_pub_keys'] = SshPubKeyFactCollector()
    SshPubKeyFactCollector().collect()
    ssh_pub_key_facts = collector.collectors['ssh_pub_keys'].get_facts()

    assert 'ssh_host_key_defined' in ssh_pub_key_facts
    assert ssh_pub_key_facts['ssh_host_key_defined'] == \
        ssh_pub_key_facts['ssh_host_pub_keys'] != {}

    assert 'ssh_host_pub_keys' in ssh_pub_key_facts
    assert isinstance(ssh_pub_key_facts['ssh_host_pub_keys'], dict)

# Generated at 2022-06-23 01:56:52.220777
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import tempfile
    import os
    import shutil
    import json
    from ansible.module_utils.facts.utils import get_file_content
    # Set up temp directory
    tempdir = tempfile.mkdtemp()
    dsakeyfile = os.path.join(tempdir, "ssh_host_dsa_key.pub")
    f = open(dsakeyfile, "w+")

# Generated at 2022-06-23 01:56:52.811329
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    pass

# Generated at 2022-06-23 01:57:03.082934
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import unittest
    from ansible.module_utils.facts.collector import BaseFactCollector, FactCollector
    from ansible.module_utils.facts.collector.ssh_pub_keys import SshPubKeyFactCollector
    from ansible.module_utils.facts.utils import get_file_content, get_file_lines

    class TestFactCollector(FactCollector):
        def __init__(self):
            self._collectors = [BaseFactCollector(), SshPubKeyFactCollector()]


# Generated at 2022-06-23 01:57:04.164082
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c = SshPubKeyFactCollector()

# Generated at 2022-06-23 01:57:05.890881
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKeyFactCollector = SshPubKeyFactCollector()
    assert sshPubKeyFactCollector is not None

# Generated at 2022-06-23 01:57:14.007910
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:57:16.240736
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector

# Generated at 2022-06-23 01:57:16.937543
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-23 01:57:18.255765
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    tmp = SshPubKeyFactCollector()
    assert tmp

# Generated at 2022-06-23 01:57:23.753133
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Initialize the module class
    ssh_pub_key_facts = SshPubKeyFactCollector()

    # Assert method collect returns a dict
    assert isinstance(ssh_pub_key_facts.collect(), dict), \
           'Failed to create dict for ssh_pub_key_facts'

# Generated at 2022-06-23 01:57:28.565012
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts
    assert ssh_pub_key_facts['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa'
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts

# Generated at 2022-06-23 01:57:38.679982
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_name = 'ssh_pub_keys'
    assert SshPubKeyFactCollector.name == fact_name
    assert isinstance(SshPubKeyFactCollector._fact_ids, set)
    assert 'ssh_host_pub_keys' in SshPubKeyFactCollector._fact_ids
    assert 'ssh_host_key_dsa_public' in SshPubKeyFactCollector._fact_ids
    assert 'ssh_host_key_rsa_public' in SshPubKeyFactCollector._fact_ids
    assert 'ssh_host_key_ecdsa_public' in SshPubKeyFactCollector._fact_ids
    assert 'ssh_host_key_ed25519_public' in SshPubKeyFactCollector._fact_ids

# Generated at 2022-06-23 01:57:45.030699
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    assert(ssh_pub_key_facts.get('ssh_host_key_rsa_public_keytype') == 'ssh-rsa')

# Generated at 2022-06-23 01:57:48.095531
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.collect()

# Generated at 2022-06-23 01:57:57.033027
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import tempfile
    import stat
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Collect facts
    test_ssh_pub_key_facts = SshPubKeyFactCollector().collect()

    # Assert empty facts

# Generated at 2022-06-23 01:58:04.226334
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """
    This function just instantiates the class, it does not actually do anything
    """
    ssh_data = SshPubKeyFactCollector()
    assert ssh_data.name == 'ssh_pub_keys'
    assert ssh_data._fact_ids == set(['ssh_host_pub_keys',
                                      'ssh_host_key_dsa_public',
                                      'ssh_host_key_rsa_public',
                                      'ssh_host_key_ecdsa_public',
                                      'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:58:12.642682
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_collector._fact_ids == set(['ssh_host_pub_keys',
                                                   'ssh_host_key_dsa_public',
                                                   'ssh_host_key_rsa_public',
                                                   'ssh_host_key_ecdsa_public',
                                                   'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:58:13.988457
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    testobj = SshPubKeyFactCollector()
    assert testobj is not None

# Generated at 2022-06-23 01:58:17.822443
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    factCollector = SshPubKeyFactCollector()
    assert factCollector.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:58:24.047026
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert 'ssh_host_key_dsa_public' in obj._fact_ids
    assert 'ssh_host_key_rsa_public' in obj._fact_ids
    assert 'ssh_host_key_ecdsa_public' in obj._fact_ids
    assert 'ssh_host_key_ed25519_public' in obj._fact_ids


# Generated at 2022-06-23 01:58:33.804708
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    from ansible.module_utils.facts.utils import AnsibleFailJson
    from ansible.module_utils.facts import default_collectors

    m = AnsibleFailJson()

    # fake the content of a DSA public key

# Generated at 2022-06-23 01:58:41.558457
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    instance = SshPubKeyFactCollector()

    assert instance.name == 'ssh_pub_keys'

    expected = set(['ssh_host_pub_keys',
                    'ssh_host_key_dsa_public',
                    'ssh_host_key_rsa_public',
                    'ssh_host_key_ecdsa_public',
                    'ssh_host_key_ed25519_public'])

    assert instance._fact_ids == expected

# Generated at 2022-06-23 01:58:51.142884
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    facts = collector.collect()
    #assert False, facts

# Generated at 2022-06-23 01:58:52.066077
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:58:58.185658
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_fact_collector.name, str)
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
        'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public',
        'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:59:00.623819
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-23 01:59:10.313450
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
    Unit test for method collect of class SshPubKeyFactCollector
    """

    test_collector = SshPubKeyFactCollector()

    result = test_collector.collect()


# Generated at 2022-06-23 01:59:17.128761
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector(None).name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector(None)._fact_ids == set(['ssh_host_pub_keys',
                                                          'ssh_host_key_dsa_public',
                                                          'ssh_host_key_rsa_public',
                                                          'ssh_host_key_ecdsa_public',
                                                          'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:59:26.043457
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """Unit test for constructor of class SshPubKeyFactCollector"""
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector.fact_ids == set(['ssh_host_pub_keys',
                                                       'ssh_host_key_dsa_public',
                                                       'ssh_host_key_rsa_public',
                                                       'ssh_host_key_ecdsa_public',
                                                       'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:59:36.377229
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    base_fact_collector = BaseFactCollector()
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    assert isinstance(ssh_pub_key_fact_collector, BaseFactCollector)
    assert isinstance(ssh_pub_key_fact_collector, SshPubKeyFactCollector)
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:59:46.826996
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert len(ssh_pub_key_fact_collector._fact_ids) == 5
    for fact_id in ssh_pub_key_fact_collector._fact_ids:
        assert type(fact_id) is str

#
# Unit tests for the collect method of class SshPubKeyFactCollector.
#
# The collect method returns a dictionary with the following elements::
#
#  {
#    'ssh_host_pub_keys': '',
#    'ssh_host_key_dsa_public': '',
#    'ssh_host_key_rsa_public': '',
#    'ssh_host_key_ec

# Generated at 2022-06-23 01:59:55.106804
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # This is the default SSH package key directory in CentOS 7.
    kd = '/etc/ssh'
    # The public key file
    kpf = '{0}/ssh_host_dsa_key.pub'.format(kd)
    # The private key file
    kf = '{0}/ssh_host_dsa_key'.format(kd)
    # The key type
    kt = 'ssh-dss'

    # Construct fake facts
    facts_dict = {}
    for key in ['common', 'hardware', 'virtual', 'network', 'system', 'distribution']:
        facts_dict[key] = {}

    from ansible.module_utils.facts import ansible_facts

    facts = ansible_facts
    facts._initialize(facts_dict)


# Generated at 2022-06-23 01:59:59.136134
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'

# Generated at 2022-06-23 02:00:01.142698
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'

# Generated at 2022-06-23 02:00:03.435660
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    try:
        SshPubKeyFactCollector()
    except Exception:
        assert True
    else:
        assert False

# Generated at 2022-06-23 02:00:08.576804
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collect_obj = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_collect_obj, SshPubKeyFactCollector)
    assert ssh_pub_key_collect_obj.name == 'ssh_pub_keys'
    assert len(ssh_pub_key_collect_obj._fact_ids) == 5


# Generated at 2022-06-23 02:00:20.446324
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
    Test of method collect of class SshPubKeyFactCollector
    """
    # Test with ssh keys in /etc/ssh
    setattr(SshPubKeyFactCollector, 'real_test_collect', False)
    collector = SshPubKeyFactCollector()
    module = None
    collected_facts = {}
    result = collector.collect(module, collected_facts)
    assert 'ssh_host_key_dsa_public' in result
    assert 'ssh_host_key_rsa_public' in result
    assert 'ssh_host_key_ecdsa_public' in result
    assert 'ssh_host_key_ed25519_public' in result