

# Generated at 2022-06-23 01:50:21.061484
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    facts = collector.collect()
    assert facts['ssh_host_key_ecdsa_public'] == 'AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBDFt0yI+S2SMyYkvq8WrbNAdJE+F/N/GX9W1+8jZL/HfaAS5C5/oW/IJ8yPd3zcq3aSX9WnS8GnxDZrsRJ4v4xyw='



# Generated at 2022-06-23 01:50:29.199145
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleFailJson
    import ansible_collections.ansible.community.plugins.module_utils.facts.collectors.ssh_pub_keys as ssh_keys_collector

    ssh_keys_collector.get_file_content = lambda filename: b'public_key'


# Generated at 2022-06-23 01:50:40.092209
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    assert ssh_pub_key_facts.get('ssh_host_pub_keys')
    assert ssh_pub_key_facts.get('ssh_host_key_rsa_public')
    assert ssh_pub_key_facts.get('ssh_host_key_rsa_public_keytype')
    assert ssh_pub_key_facts.get('ssh_host_key_dsa_public')
    assert ssh_pub_key_facts.get('ssh_host_key_dsa_public_keytype')
    assert ssh_pub_key_facts.get('ssh_host_key_ecdsa_public')
    assert ssh_pub_key_facts.get('ssh_host_key_ecdsa_public_keytype')
    assert ssh

# Generated at 2022-06-23 01:50:48.775879
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create temporary ssh config files in the temporary directory and add
    # them to a list of config files to be tested
    config_files = []
    for key in ('ssh_host_dsa_key.pub',
                'ssh_host_rsa_key.pub',
                'ssh_host_ecdsa_key.pub',
                'ssh_host_ed25519_key.pub'):
        config_files.append((key, '%s/%s' % (tmpdir, key)))

    # Create the temporary config files
    for (key, keyfile) in config_files:
        with open(keyfile, 'w') as f:
            if key == 'ssh_host_dsa_key.pub':
                f

# Generated at 2022-06-23 01:50:58.077836
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    my_module = None
    my_collector = SshPubKeyFactCollector()
    my_facts = my_collector.collect(module=my_module, collected_facts=None)

    # Assert that no private keys are returned
    assert 'ssh_host_key_dsa_private' not in my_facts
    assert 'ssh_host_key_rsa_private' not in my_facts
    assert 'ssh_host_key_ecdsa_private' not in my_facts
    assert 'ssh_host_key_ed25519_private' not in my_facts

    # Assert that no keytype facts are returned
    assert 'ssh_host_key_dsa_public_keytype' not in my_facts
    assert 'ssh_host_key_rsa_public_keytype' not in my_facts
   

# Generated at 2022-06-23 01:51:05.657420
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect(module=None, collected_facts=None)
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_dsa_public_keytype' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public_keytype' in ssh_pub_key_facts
    assert 'ssh_host_key_ed25519_public' in ssh_pub_

# Generated at 2022-06-23 01:51:09.535919
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    ret_ssh_pub_key_facts = ssh_pub_key_facts.collect()
    assert ('ssh_host_key_ecdsa_public' in ret_ssh_pub_key_facts)

# Generated at 2022-06-23 01:51:21.186520
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.utils import MockModule
    from ansible.module_utils.facts.utils import mock_get_file_content


# Generated at 2022-06-23 01:51:26.444052
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'



# Generated at 2022-06-23 01:51:29.420223
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()

    # fact_ids
    assert collector.fact_ids() == collector._fact_ids

    # name
    assert collector.name == collector.name

# Generated at 2022-06-23 01:51:37.822658
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """ Unit test for constructor of class SshPubKeyFactCollector"""
    ssh_pub_key_fact = SshPubKeyFactCollector()
    assert ssh_pub_key_fact.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact._fact_ids == set(['ssh_host_pub_keys',
                                              'ssh_host_key_dsa_public',
                                              'ssh_host_key_rsa_public',
                                              'ssh_host_key_ecdsa_public',
                                              'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:51:45.524568
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # mock module
    module = MagicMock()
    # mock collected_facts
    collected_facts = {}

    # define class instance
    fact_collector = SshPubKeyFactCollector()

    # mock get_file_content
    fact_collector.get_file_content = MagicMock()
    # returns for all keys

# Generated at 2022-06-23 01:51:53.941590
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    _SshPubKeyFactCollector = SshPubKeyFactCollector
    _SshPubKeyFactCollector._get_file_content = lambda path: path

    actual_result = _SshPubKeyFactCollector().collect()

    print("actual_result:\n")
    for key, value in actual_result.items():
        print("  %s: %s" % (key, value))


# Generated at 2022-06-23 01:52:02.066217
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import tempfile
    from ansible.module_utils.facts.utils import get_file_content, set_file_content

    # fake the path for ssh keys
    keydir = tempfile.mkdtemp()

    # fake the content of the ssh key file
    # the algo is 'rsa'
    test_content = 'ssh-rsa fake_key'
    filename = keydir + '/ssh_host_rsa_key.pub'
    set_file_content(filename, test_content)

    # run the unit test
    facts_to_test = SshPubKeyFactCollector()
    collected_facts = facts_to_test.collect()

    # verify that the ssh_host_rsa_key was collected
    assert 'ssh_host_key_rsa_public' in collected_facts

# Generated at 2022-06-23 01:52:04.729512
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector = SshPubKeyFactCollector()
    assert fact_collector.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:52:13.435794
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector.collect()
    assert ssh_pub_key_facts['ssh_host_key_ecdsa_public'] == 'AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBIsdfBmPyvu7E+j6cCY6V/U6A2QZTebTfS2Qzv0/3jqMk9/N4SR/8p/AJgZ0+/ZRSAaW2A7fSzq3xG9Xyq4i8Yv4='

# Generated at 2022-06-23 01:52:19.543397
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = {'ansible_all_ipv4_addresses': ['10.15.20.57']}

    mock_object = SshPubKeyFactCollector()

    ssh_pub_key_facts = mock_object.collect(module=module,
                                            collected_facts=collected_facts)

    assert ssh_pub_key_facts['ansible_facts']['ssh_host_key_ed25519_public'] == 'abcdefgh'
    assert ssh_pub_key_facts['ansible_facts']['ssh_host_key_ed25519_public_keytype'] == 'ssh-ed25519'

# Generated at 2022-06-23 01:52:31.694727
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:52:39.875613
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Unit test to verify that collect method of SshPubKeyFactCollector
    # returns the expected facts
    from ansible.module_utils.facts.utils import get_file_content
    # Test case 1 - minimal facts
    # Test data
    # Expected results

# Generated at 2022-06-23 01:52:52.811294
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = {
        'params': {},
        'ansible_facts': {}
    }


# Generated at 2022-06-23 01:52:54.907800
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector
    assert isinstance(ssh_pub_key_fact_collector, SshPubKeyFactCollector)


# Generated at 2022-06-23 01:53:01.552402
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:53:03.707381
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector.collect()

# Generated at 2022-06-23 01:53:10.214120
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    storage = {}
    facts = SshPubKeyFactCollector().collect(None, storage)
    assert isinstance(facts, dict)
    print(facts)
    assert 'ssh_host_key_rsa_public_keytype' in facts
    assert facts['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa'
    assert 'ssh_host_key_dsa_public' in facts


# Generated at 2022-06-23 01:53:19.297790
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:53:28.164316
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    result = SshPubKeyFactCollector()
    assert 'SshPubKeyFactCollector' == result.__class__.__name__
    assert result.name == 'ssh_pub_keys'
    assert 'ssh_host_pub_keys' in result._fact_ids
    assert 'ssh_host_key_dsa_public' in result._fact_ids
    assert 'ssh_host_key_rsa_public' in result._fact_ids
    assert 'ssh_host_key_ecdsa_public' in result._fact_ids
    assert 'ssh_host_key_ed25519_public' in result._fact_ids


# Generated at 2022-06-23 01:53:34.035790
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # create a SshPubKeyFactCollector object
    x = SshPubKeyFactCollector()

    # test the correct initialization of the object
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:53:36.299679
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids



# Generated at 2022-06-23 01:53:39.189907
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert 'ssh_host_key_ed25519_public' in x._fact_ids

# Generated at 2022-06-23 01:53:44.427289
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """
    Unit test of constructor for SshPubKeyFactCollector.
    """
    test_collector = SshPubKeyFactCollector()
    assert test_collector.name == 'ssh_pub_keys'
    for fact_id in test_collector._fact_ids:
        assert fact_id in test_collector.collect()

# Generated at 2022-06-23 01:53:49.458281
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set([
        'ssh_host_pub_keys', 'ssh_host_key_dsa_public',
        'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public',
        'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:53:58.582909
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts._fact_ids == set(['ssh_host_pub_keys',
                                          'ssh_host_key_dsa_public',
                                          'ssh_host_key_rsa_public',
                                          'ssh_host_key_ecdsa_public',
                                          'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:54:05.475049
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector() == \
        {'ssh_host_pub_keys': None,
         'ssh_host_key_dsa_public': None,
         'ssh_host_key_rsa_public': None,
         'ssh_host_key_ecdsa_public': None,
         'ssh_host_key_ed25519_public': None}

# Generated at 2022-06-23 01:54:12.829008
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_collector, BaseFactCollector)
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_collector._fact_ids == set(['ssh_host_pub_keys',
                                                   'ssh_host_key_dsa_public',
                                                   'ssh_host_key_rsa_public',
                                                   'ssh_host_key_ecdsa_public',
                                                   'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:54:23.710967
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collectors import collector_module
    from ansible.module_utils.facts.collectors.ssh_pub_keys import SshPubKeyFactCollector

    myCollector = SshPubKeyFactCollector(collector_module)
    collected_facts = {}
    myCollector.collect(collected_facts)
    assert 'ssh_host_key_dsa_public' in collected_facts
    assert 'ssh_host_key_dsa_public_keytype' in collected_facts
    assert 'ssh_host_key_rsa_public' in collected_facts
    assert 'ssh_host_key_rsa_public_keytype' in collected_facts
    assert 'ssh_host_key_ecdsa_public' in collected_facts

# Generated at 2022-06-23 01:54:27.017463
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''
    Test ssh_pub_key_collector collect
    '''
    module = None
    collected_facts = None
    fact_collector = SshPubKeyFactCollector()
    results = fact_collector.collect(module, collected_facts)
    print(results)

# Generated at 2022-06-23 01:54:32.122332
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Unit test for method collect of class SshPubKeyFactCollector"""

    module = None
    collected_facts = None
    spkfc = SshPubKeyFactCollector(
        module=module,
        collected_facts=collected_facts)
    spkfc_result = spkfc.collect()
    assert spkfc_result != {}

# Generated at 2022-06-23 01:54:41.832676
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector = SshPubKeyFactCollector()
    collected_facts = fact_collector.collect()
    assert collected_facts is not None
    # change with 2.6 to:
    # assert isinstance(collected_facts, dict)
    assert type(collected_facts) is dict
    assert 'ssh_host_pub_keys' in collected_facts
    assert type(collected_facts['ssh_host_pub_keys']) is list
    assert 'ssh_host_key_dsa_public' in collected_facts
    assert 'ssh_host_key_rsa_public' in collected_facts
    assert 'ssh_host_key_ecdsa_public' in collected_facts
    assert 'ssh_host_key_ed25519_public' in collected_facts

# Generated at 2022-06-23 01:54:49.825529
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Setup test environment.
    facter_module = 'ansible.module_utils.facts.system.ssh_pub_keys.facter'

# Generated at 2022-06-23 01:54:52.837265
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_obj = SshPubKeyFactCollector()
    collected_facts = test_obj.collect()
    assert collected_facts is not None

# Generated at 2022-06-23 01:55:00.452892
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                                        'ssh_host_key_dsa_public',
                                                        'ssh_host_key_rsa_public',
                                                        'ssh_host_key_ecdsa_public',
                                                        'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:55:09.641913
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert type(ssh_pub_key_facts) == SshPubKeyFactCollector
    assert type(ssh_pub_key_facts.name) == str
    assert 'ssh_pub_keys' == ssh_pub_key_facts.name
    assert type(ssh_pub_key_facts._fact_ids) == set
    assert 'ssh_host_pub_keys' in ssh_pub_key_facts._fact_ids
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts._fact_ids
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts._fact_ids
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts._fact_

# Generated at 2022-06-23 01:55:18.492070
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """ test ssh facts collector collect() method """

# Generated at 2022-06-23 01:55:28.435893
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # test against fake keys created in temp dir
    import os
    import tempfile
    keydir = tempfile.mkdtemp()
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')

# Generated at 2022-06-23 01:55:33.883680
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact = SshPubKeyFactCollector()
    assert fact.name == 'ssh_pub_keys'
    assert fact._fact_ids == set(['ssh_host_pub_keys',
                                  'ssh_host_key_dsa_public',
                                  'ssh_host_key_rsa_public',
                                  'ssh_host_key_ecdsa_public',
                                  'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:55:40.202632
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:55:47.613110
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import glob

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCache

    test_cases = []

    # No ssh keys

# Generated at 2022-06-23 01:55:57.293280
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:56:07.480456
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()

    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts.keys()
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts.keys()
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts.keys()
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_facts.keys()
    assert 'ssh_host_key_dsa_public_keytype' in ssh_pub_key_facts.keys()
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts.keys()

# Generated at 2022-06-23 01:56:16.432786
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert 'ssh_host_pub_keys' in ssh_pub_key_facts._fact_ids
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts._fact_ids
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts._fact_ids
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts._fact_ids
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_facts._fact_ids


# Generated at 2022-06-23 01:56:25.965909
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ansible_ssh_pub_keys_list = ['ssh_host_key_ed25519_public',
                                 'ssh_host_key_dsa_public_keytype',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public_keytype']

    collector = SshPubKeyFactCollector()
    assert collector is not None
    assert collector.name == 'ssh_pub_keys'
    assert len(collector._fact_ids) == 5
    assert collector._fact_ids == set(ansible_ssh_pub_keys_list)

# Generated at 2022-06-23 01:56:32.730489
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    tested_collector = SshPubKeyFactCollector()

    # Ssh key files should exist in /etc/ssh/ssh_host_KEY.pub
    collected_facts = tested_collector.collect()
    assert len(collected_facts) == 5
    assert 'ssh_host_key_rsa_public' in collected_facts
    assert 'ssh_host_key_rsa_public_keytype' in collected_facts
    assert 'ssh_host_key_dsa_public' in collected_facts
    assert 'ssh_host_key_dsa_public_keytype' in collected_facts
    assert 'ssh_host_key_ecdsa_public' in collected_facts
    assert 'ssh_host_key_ecdsa_public_keytype' in collected_facts

# Generated at 2022-06-23 01:56:35.846225
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact = SshPubKeyFactCollector()
    assert ssh_pub_key_fact.name == 'ssh_pub_keys'
    assert len(ssh_pub_key_fact._fact_ids) == 5


# Generated at 2022-06-23 01:56:47.356868
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    from ansible.module_utils.facts.utils import FactsFiles
    ssh_key_files = {'dsa': 'ssh_host_dsa_key.pub',
                     'rsa': 'ssh_host_rsa_key.pub',
                     'ecdsa': 'ssh_host_ecdsa_key.pub',
                     'ed25519': 'ssh_host_ed25519_key.pub'}
    ssh_pub_key_facts = {}
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    keydir = '/etc/ssh'
    # create ssh key files
    for algo in algos:
        key_filename = '%s/%s' % (keydir, ssh_key_files[algo])

# Generated at 2022-06-23 01:56:56.885197
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    mock_get_file_content = dict()

# Generated at 2022-06-23 01:57:06.706693
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule:
        pass

    class MockCollectedFacts:
        pass

    # test with no key files
    get_file_content_orig = get_file_content
    get_file_content_sideeffect = lambda *args: None
    get_file_content.side_effect = get_file_content_sideeffect

    ssh_pub_key_facts = SshPubKeyFactCollector.collect(MockModule(), MockCollectedFacts())
    assert ssh_pub_key_facts == {}

    # test with one key file
    # ssh-rsa AAAAB3NzaC1yc2

# Generated at 2022-06-23 01:57:16.726330
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # create a SshPubKeyFactCollector instance
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # test ssh keys in /etc/ssh
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect(collected_facts={})
    assert len(ssh_pub_key_fact_collector._fact_ids.intersection(set(ssh_pub_key_facts.keys()))) == 0

    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect(collected_facts={'ansible_local': {'ssh_host_key_dsa_public': 'testdata'}})

# Generated at 2022-06-23 01:57:24.238516
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils._text import to_bytes
    import sys

    # Considering python3, we need to get a non-unicode string

# Generated at 2022-06-23 01:57:35.608500
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    expectedKeys = ['ssh_host_key_dsa_public',
                    'ssh_host_key_dsa_public_keytype',
                    'ssh_host_key_rsa_public',
                    'ssh_host_key_rsa_public_keytype',
                    'ssh_host_key_ecdsa_public',
                    'ssh_host_key_ecdsa_public_keytype',
                    'ssh_host_key_ed25519_public',
                    'ssh_host_key_ed25519_public_keytype']
    for key in expectedKeys:
        assert key in ssh_pub_key_facts

# Generated at 2022-06-23 01:57:36.992024
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """Test constructor for SshPubKeyFactCollector"""
    SshPubKeyFactCollector()

# Generated at 2022-06-23 01:57:45.444402
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # pylint: disable=protected-access

    key_dsa_fact = 'ssh_host_key_dsa_public'
    key_rsa_fact = 'ssh_host_key_rsa_public'
    key_ecdsa_fact = 'ssh_host_key_ecdsa_public'
    key_ed25519_fact = 'ssh_host_key_ed25519_public'

    test_object = SshPubKeyFactCollector()

    # Test empty paths
    test_object._paths = []
    # pylint: disable=no-member
    facts = test_object.collect()
    assert key_dsa_fact not in facts
    assert key_rsa_fact not in facts
    assert key_ecdsa_fact not in facts

# Generated at 2022-06-23 01:57:52.221300
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKeyFactCollector = SshPubKeyFactCollector()
    assert 'ssh_pub_keys' == sshPubKeyFactCollector.name
    assert set(['ssh_host_key_ecdsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ed25519_public', 'ssh_host_key_dsa_public', 'ssh_host_pub_keys']) == sshPubKeyFactCollector._fact_ids

# Generated at 2022-06-23 01:58:00.441608
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert 'ssh_pub_keys' == ssh_pub_key_fact_collector.name
    assert set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public']) == ssh_pub_key_fact_collector._fact_ids
    assert ssh_pub_key_fact_collector.collect()

# Generated at 2022-06-23 01:58:10.452353
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:58:16.436000
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_key'
    assert x._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:58:26.603899
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector

    # Given the following key files

# Generated at 2022-06-23 01:58:36.141329
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:58:43.052573
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c = SshPubKeyFactCollector()
    assert c.name == 'ssh_pub_keys'
    assert len(c._fact_ids) == 5
    assert 'ssh_host_ed25519_public' in c._fact_ids
    assert 'ssh_host_rsa_public' in c._fact_ids
    assert 'ssh_host_dsa_public' in c._fact_ids
    assert 'ssh_host_ecdsa_public' in c._fact_ids

# Generated at 2022-06-23 01:58:45.911109
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Test instantiation of a singleton class
    obj1 = SshPubKeyFactCollector()
    obj2 = SshPubKeyFactCollector()
    assert id(obj1) == id(obj2)

# Generated at 2022-06-23 01:58:53.136386
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == {'ssh_host_pub_keys',
                                                      'ssh_host_key_dsa_public',
                                                      'ssh_host_key_rsa_public',
                                                      'ssh_host_key_ecdsa_public',
                                                      'ssh_host_key_ed25519_public'}


# Generated at 2022-06-23 01:58:54.681809
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:59:06.169853
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj
    assert obj._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:59:12.195262
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    facts_module = SshPubKeyFactCollector()
    assert set(facts_module.collect().keys()) == { 'ssh_host_key_rsa_public',
                                                   'ssh_host_key_rsa_public_keytype'}
    assert facts_module._fact_ids == { 'ssh_host_pub_keys',
                                       'ssh_host_key_dsa_public',
                                       'ssh_host_key_rsa_public',
                                       'ssh_host_key_ecdsa_public',
                                       'ssh_host_key_ed25519_public'}

# Generated at 2022-06-23 01:59:16.193335
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''Test ssh_pub_keys fact collection method'''

    # If there are no keys, the result is empty
    collector = SshPubKeyFactCollector()
    data = collector.collect()
    assert len(data.keys()) == 0

    # If keys are not in a standard location, the result is empty
    collector = SshPubKeyFactCollector()
    collector.get_file_content = lambda x: x
    data = collector.collect()
    assert len(data.keys()) == 0

    # If the file is missing but the directory exists, the result is empty
    collector = SshPubKeyFactCollector()

    def key_exist(x):
        '''Fake function for get_file_content'''
        if 'empty' in x:
            return None
        retu

# Generated at 2022-06-23 01:59:26.141517
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    sshPubKeyFactCollector = SshPubKeyFactCollector()
    # On an Ubuntu machine
    assert not sshPubKeyFactCollector.collect(None)
    assert 'ssh_host_key_ed25519_public' in sshPubKeyFactCollector.collect(None)
    # On a CentOS machine
    assert not sshPubKeyFactCollector.collect(None)
    assert 'ssh_host_key_rsa_public' in sshPubKeyFactCollector.collect(None)
    # On a FreeBSD machine
    assert not sshPubKeyFactCollector.collect(None)
    assert 'ssh_host_key_ecdsa_public' in sshPubKeyFactCollector.collect(None)


# Generated at 2022-06-23 01:59:34.666673
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'

    assert ssh_pub_key_fact_collector._fact_ids == {
        'ssh_host_pub_keys',
        'ssh_host_key_dsa_public',
        'ssh_host_key_rsa_public',
        'ssh_host_key_ecdsa_public',
        'ssh_host_key_ed25519_public'}

# Generated at 2022-06-23 01:59:40.111855
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():

    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'

    assert obj._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:59:43.049023
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:59:51.536215
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():

    # Tested object
    obj = SshPubKeyFactCollector()

    # test the properties of the object
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 02:00:00.094162
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts._fact_ids == set([
        'ssh_host_pub_keys',
        'ssh_host_key_dsa_public',
        'ssh_host_key_rsa_public',
        'ssh_host_key_ecdsa_public',
        'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 02:00:03.050592
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    for key in SshPubKeyFactCollector()._fact_ids:
        assert key in SshPubKeyFactCollector.collect()

# Generated at 2022-06-23 02:00:09.599193
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector().name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector()._fact_ids == set(['ssh_host_pub_keys',
                                                      'ssh_host_key_dsa_public',
                                                      'ssh_host_key_rsa_public',
                                                      'ssh_host_key_ecdsa_public',
                                                      'ssh_host_key_ed25519_public'])



# Generated at 2022-06-23 02:00:16.545283
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts._fact_ids == set(['ssh_host_pub_keys',
                                               'ssh_host_key_dsa_public',
                                               'ssh_host_key_rsa_public',
                                               'ssh_host_key_ecdsa_public',
                                               'ssh_host_key_ed25519_public'])