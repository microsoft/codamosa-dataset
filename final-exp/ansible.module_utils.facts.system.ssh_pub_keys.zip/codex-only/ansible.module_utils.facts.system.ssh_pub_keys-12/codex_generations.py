

# Generated at 2022-06-23 01:50:25.857018
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # create class object
    ssh_pub_key_collector = SshPubKeyFactCollector()

    # Test collect method
    collected_facts = {}
    collected_facts['ssh_host_ed25519_public'] = 'test_ed25519_key'
    collected_facts['ssh_host_ed25519_public_keytype'] = 'test_ed25519_keytype'
    ssh_pub_key_facts = ssh_pub_key_collector.collect(collected_facts=collected_facts)
    assert ssh_pub_key_facts == {'ssh_host_key_ed25519_public': 'test_ed25519_key', 'ssh_host_key_ed25519_public_keytype': 'test_ed25519_keytype'}


# Generated at 2022-06-23 01:50:32.833183
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # type of class SshPubKeyFactCollector is 'module'
    assert type(SshPubKeyFactCollector) == type
    # instance of class SshPubKeyFactCollector
    obj = SshPubKeyFactCollector()
    # type of 'obj' is SshPubKeyFactCollector
    assert type(obj) == SshPubKeyFactCollector


# Generated at 2022-06-23 01:50:37.595564
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    s = SshPubKeyFactCollector()
    assert s.name == 'ssh_pub_keys'
    assert s._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:50:40.756027
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''
    This method tests method collect of class SshPubKeyFactCollector
    '''
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    print("ssh_pub_key_facts: %s" % ssh_pub_key_fact_collector.collect())

# Generated at 2022-06-23 01:50:42.695484
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    test_object = SshPubKeyFactCollector()
    assert test_object



# Generated at 2022-06-23 01:50:43.880706
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-23 01:50:49.299546
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'


# Generated at 2022-06-23 01:50:50.231583
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-23 01:50:58.974042
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert 'ssh_host_pub_keys' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_fact_collector._fact_ids

# Generated at 2022-06-23 01:51:09.924336
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    import os


# Generated at 2022-06-23 01:51:16.752837
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c = SshPubKeyFactCollector()
    assert set(['ssh_host_key_rsa_public',
                'ssh_host_key_ecdsa_public',
                'ssh_host_key_ed25519_public',
                'ssh_host_key_dsa_public',
                'ssh_host_pub_keys']) == c._fact_ids
    assert c.name == 'ssh_pub_keys'


# Generated at 2022-06-23 01:51:20.595974
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    obj = SshPubKeyFactCollector()
    assert isinstance(obj, BaseFactCollector)
    assert isinstance(obj, Collector)
    lst = [id for id in obj.collect()]
    assert lst[0] in obj._fact_ids

# Generated at 2022-06-23 01:51:25.922590
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    facts = SshPubKeyFactCollector()
    assert isinstance(facts.name, str)
    assert isinstance(facts.collect(), dict)

# Generated at 2022-06-23 01:51:37.229873
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create a SshPubKeyFactCollector object
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # Create an empty collected_facts object
    collected_facts = {}

    # Call method collect of SshPubKeyFactCollector object
    collected_facts = ssh_pub_key_fact_collector.collect(collected_facts=collected_facts)

    assert type(collected_facts['ssh_host_key_dsa_public']) is str
    assert type(collected_facts['ssh_host_key_rsa_public']) is str
    assert type(collected_facts['ssh_host_key_ecdsa_public']) is str
    assert type(collected_facts['ssh_host_key_ed25519_public']) is str

# Generated at 2022-06-23 01:51:38.833538
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    isinstance(SshPubKeyFactCollector(), SshPubKeyFactCollector)

# Generated at 2022-06-23 01:51:49.080302
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    #Unit test for method collect of class SshPubKeyFactCollector
    module = FakeApiModule()
    fact_collector = SshPubKeyFactCollector()
    facts = fact_collector.collect(module=module)

    assert 'ssh_host_key_dsa_public' in facts
    assert 'ssh_host_key_rsa_public' in facts
    assert 'ssh_host_key_ecdsa_public' in facts
    assert 'ssh_host_key_ed25519_public' in facts
    assert 'ssh_host_key_dsa_public_keytype' in facts
    assert 'ssh_host_key_rsa_public_keytype' in facts
    assert 'ssh_host_key_ecdsa_public_keytype' in facts

# Generated at 2022-06-23 01:51:57.621479
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert set(ssh_pub_key_fact_collector._fact_ids) == set(['ssh_host_pub_keys',
                                                             'ssh_host_key_dsa_public',
                                                             'ssh_host_key_rsa_public',
                                                             'ssh_host_key_ecdsa_public',
                                                             'ssh_host_key_ed25519_public'])
    assert ssh_pub_key_fact_collector.priority == 80

# Generated at 2022-06-23 01:51:59.797744
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    test_obj1 = SshPubKeyFactCollector()
    assert test_obj1 is not None

# Generated at 2022-06-23 01:52:06.154442
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == "ssh_pub_keys"
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:52:11.823228
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = collector.collect()

    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_facts

# Generated at 2022-06-23 01:52:19.188652
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fixture = SshPubKeyFactCollector
    assert fixture._fact_ids == set(['ssh_host_pub_keys',
                                     'ssh_host_key_dsa_public',
                                     'ssh_host_key_rsa_public',
                                     'ssh_host_key_ecdsa_public',
                                     'ssh_host_key_ed25519_public'])
    assert isinstance(fixture.name, str)

# Generated at 2022-06-23 01:52:26.602826
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:52:31.598622
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshpkfc = SshPubKeyFactCollector((dict(), dict()))

    assert(sshpkfc)
    assert(sshpkfc.name == 'ssh_pub_keys')
    assert(sshpkfc.fact_id == 'ssh_pub_keys')
    assert(len(sshpkfc._fact_ids) == 5)

# Generated at 2022-06-23 01:52:39.848840
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    def mock_get_file_content(path):
        '''Mock get_file_content() call to return a variety of keys'''

# Generated at 2022-06-23 01:52:50.090203
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_keys_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts_collected = ssh_pub_keys_fact_collector.collect()

    if not isinstance(ssh_pub_key_facts_collected, dict):
        raise AssertionError("Unexpected response from class SshPubKeyFactCollector")

    for key in ssh_pub_key_facts_collected:
        print(key, ssh_pub_key_facts_collected[key])

# Generated at 2022-06-23 01:52:58.079541
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts._fact_ids == set(['ssh_host_pub_keys',
                                               'ssh_host_key_dsa_public',
                                               'ssh_host_key_rsa_public',
                                               'ssh_host_key_ecdsa_public',
                                               'ssh_host_key_ed25519_public'])
    assert ssh_pub_key_facts.collect() == {}

# Generated at 2022-06-23 01:53:03.170205
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
  fact_collector = SshPubKeyFactCollector()
  assert fact_collector.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:53:14.188648
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.system import LinuxFactCollector
    # First, we will instantiate our SshPubKeyFactCollector() object.
    ssh_pub_key_collector = SshPubKeyFactCollector()

    # Then, we will instantiate our LinuxFactCollector() object.
    linuxfactcollector = LinuxFactCollector()

    # Finally, we are ready to test SshPubKeyFactCollector.collect().
    # First, we will set our temporary path.
    ssh_pub_key_path = '/tmp/ssh_pub_keys'
    # Then, we will create our temporary directory. We will do this
    # because the function that we are testing,
    # SshPubKeyFactCollector.collect(), looks for files in the directory
   

# Generated at 2022-06-23 01:53:21.179574
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()

    assert len(ssh_pub_key_facts) < 5
    expected_keys = set(['ssh_host_key_dsa_public',
                         'ssh_host_key_rsa_public',
                         'ssh_host_key_ecdsa_public',
                         'ssh_host_key_ed25519_public'])
    assert set(ssh_pub_key_facts.keys()) & expected_keys == expected_keys

# Generated at 2022-06-23 01:53:22.278504
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-23 01:53:32.410577
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''
    To run the unit test, invoke from the directory where this file is located:

       python -m test.unit.module_utils.facts.collectors.ssh_pub_key.test_SshPubKeyFactCollector

    This will check for keys in the local directory and fail on missing
    files. It is still useful to quickly check for obvious issues.
    '''

    kalgo = SshPubKeyFactCollector()
    kfacts = kalgo.collect()

    for key in kalgo._fact_ids:
        if key not in kfacts:
            print('no key found for ' + key + ' in ' + str(kfacts))

# invoke the test if run as a script
if __name__ == '__main__':
    test_SshPubKeyFactCollector_collect()

# Generated at 2022-06-23 01:53:42.774200
# Unit test for constructor of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:53:45.675435
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:53:54.596986
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:54:00.328555
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create a SshPubKeyFactCollector object
    c = SshPubKeyFactCollector()
    c.collect()

# Generated at 2022-06-23 01:54:11.113654
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # mock get_file_content to return the data from a test file
    from ansible.module_utils.facts.utils import get_file_content as gfc

    fake_collector = SshPubKeyFactCollector()


# Generated at 2022-06-23 01:54:22.120090
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:54:35.085524
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    collected_facts = {}
    result = collector.collect(None, collected_facts)
    assert 'ssh_host_key_dsa_public' in result
    assert 'ssh_host_key_dsa_public_keytype' in result
    assert 'ssh_host_key_rsa_public' in result
    assert 'ssh_host_key_rsa_public_keytype' in result
    assert 'ssh_host_key_ecdsa_public' in result
    assert 'ssh_host_key_ecdsa_public_keytype' in result
    assert 'ssh_host_key_ed25519_public' in result
    assert 'ssh_host_key_ed25519_public_keytype' in result

# Generated at 2022-06-23 01:54:41.003900
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    assert isinstance(ssh_pub_key_facts, dict)
    for k in ssh_pub_key_facts.keys():
        assert isinstance(ssh_pub_key_facts[k], str)

# Generated at 2022-06-23 01:54:46.123586
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class ModuleStub(object):
        pass

    class CollectedFactsStub(object):
        pass

    ansible_collected_facts = CollectedFactsStub()
    ansible_module = ModuleStub()
    ssh_pub_key_collector = SshPubKeyFactCollector()
    res = ssh_pub_key_collector.collect(ansible_module, ansible_collected_facts)
    assert res is not None and type(res) is dict

# Generated at 2022-06-23 01:54:55.647830
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # create the three keys in tmpdir
    for keyfile in ('rsa', 'dsa', 'ecdsa', 'ed25519'):
        keytype = keyfile
        if keytype == 'rsa':
            keytype = 'ssh-rsa'
        elif keytype == 'ecdsa':
            keytype = 'ecdsa-sha2-nistp256'
        elif keytype == 'ed25519':
            keytype = 'ssh-ed25519'

        f = open(os.path.join(tmpdir, 'ssh_host_%s_key.pub' % keyfile), 'w')
        f.write('%s THIS IS A FAKE KEY\n' % keytype)

# Generated at 2022-06-23 01:54:59.762001
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # pylint: disable=import-error,no-name-in-module
    from ansible.module_utils.facts.collector.ssh_pub_key import SshPubKeyFactCollector
    assert SshPubKeyFactCollector.collect() is not None



# Generated at 2022-06-23 01:55:09.422482
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # For mocking methods
    import os
    from ansible.module_utils.facts.collector import BaseFactCollector

    # For content of ssh_host_ecdsa_key.pub
    from ansible.module_utils.facts.ssh_pub_keys import SshPubKeyFactCollector

    # Defined variables
    ssh_host_ecdsa_key_pub_file_path = 'test_data/ssh_host_ecdsa_key.pub'
    openssh_ssh_host_ecdsa_key_pub_file_path = 'test_data/openssh_ssh_host_ecdsa_key.pub'
    dsa_key_filename = 'test_data/ssh_host_dsa_key.pub'

# Generated at 2022-06-23 01:55:12.077456
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    facts = collector.collect()
    for factname in collector._fact_ids:
        assert factname in facts

# Generated at 2022-06-23 01:55:19.423250
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ''' Unit test for method collect of class SshPubKeyFactCollector '''
    fake_args = []
    fake_kwargs = { 'module' : None,
                    'collected_facts' : None }
    fake_self = SshPubKeyFactCollector()
    response = fake_self.collect(*fake_args, **fake_kwargs)
    assert response is not None
    assert type(response).__name__ == 'dict'
    assert len(response) == 5

# Generated at 2022-06-23 01:55:26.364152
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])
    assert x.collect() == {}


# Generated at 2022-06-23 01:55:29.322667
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = None
    f = SshPubKeyFactCollector()
    f.collect(module, collected_facts)

# Generated at 2022-06-23 01:55:39.170488
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:55:47.371181
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert 'ssh_host_pub_keys' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_fact_collector._fact_ids
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:55:53.018717
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    expected_fact_ids = set(['ssh_host_pub_keys',
                             'ssh_host_key_dsa_public',
                             'ssh_host_key_rsa_public',
                             'ssh_host_key_ecdsa_public',
                             'ssh_host_key_ed25519_public'])
    assert SshPubKeyFactCollector()._fact_ids == expected_fact_ids

# Generated at 2022-06-23 01:56:04.590274
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()

    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_dsa_public_keytype' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public_keytype' in ssh_pub_key_facts
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_facts

# Generated at 2022-06-23 01:56:10.401526
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:56:22.212807
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class MockModule():
        def __init__(self, *args, **kwargs):
            self.args = args[0]

    module = MockModule(dict())

    class MockFacts():
        def __init__(self, *args, **kwargs):
            self.facts = args[0]

    collected_facts = MockFacts(dict())

    class MockFile():
        def __init__(self, *args, **kwargs):
            pass

        def read(self):
            return True

        def close(self):
            pass

    class MockOpen():
        def __init__(self, *args, **kwargs):
            pass

        def __call__(self, *args, **kwargs):
            return MockFile()

        def __enter__(self):
            return MockFile()


# Generated at 2022-06-23 01:56:28.049269
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:56:30.983468
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    s = SshPubKeyFactCollector()
    assert s != 'SshPubKeyFactCollector'

# Generated at 2022-06-23 01:56:40.213413
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    c = Collector()
    fc = SshPubKeyFactCollector()
    c.add_collector(fc)
    facts = c.collect(module=None, collected_facts=None)
    assert 'ssh_host_key_rsa_public' in facts
    assert 'ssh_host_key_rsa_public_keytype' in facts
    assert facts['ssh_host_key_rsa_public'].startswith('AAAAB3NzaC1y')


# Generated at 2022-06-23 01:56:48.279140
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == "ssh_pub_keys"
    assert collector._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:56:50.799932
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pubkeys = SshPubKeyFactCollector()
    facts = pubkeys.collect()
    for pubkey in facts:
        assert(facts[pubkey] is not None)

# Generated at 2022-06-23 01:56:56.900724
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'
    assert collector._fact_ids == set(['ssh_host_pub_keys',
                                       'ssh_host_key_dsa_public',
                                       'ssh_host_key_rsa_public',
                                       'ssh_host_key_ecdsa_public',
                                       'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:57:04.162782
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                                        'ssh_host_key_dsa_public',
                                                        'ssh_host_key_rsa_public',
                                                        'ssh_host_key_ecdsa_public',
                                                        'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:57:16.170375
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content_as_list

    # generate a temporary directory as the 'root' directory for the test ssh
    # keys
    tempdir = tempfile.mkdtemp()

    # set a temporary host key file for each supported algorithm
    host_key_files = {}
    host_key_files['dsa'] = '%s/ssh_host_dsa_key.pub' % tempdir
    host_key_files['rsa'] = '%s/ssh_host_rsa_key.pub' % tempdir

# Generated at 2022-06-23 01:57:24.065472
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == \
        {'ssh_host_key_ecdsa_public', 'ssh_host_key_dsa_public',
         'ssh_host_key_rsa_public', 'ssh_host_key_ed25519_public',
         'ssh_host_pub_keys'}

    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:57:28.081361
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module_mock = Mock()
    collected_facts_mock = {}
    ssh_pub_key_collector = SshPu

# Generated at 2022-06-23 01:57:30.905466
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj.priority == 85

# Generated at 2022-06-23 01:57:34.162071
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """
    Class instantiation test.
    """
    try:
        SshPubKeyFactCollector()
    except:
        raise AssertionError('SshPubKeyFactCollector class instantiation failed')

# Generated at 2022-06-23 01:57:35.127591
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector

# Generated at 2022-06-23 01:57:37.838437
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys', 'name is set wrongly'



# Generated at 2022-06-23 01:57:42.086179
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    s = SshPubKeyFactCollector()
    facts = s.collect()
    assert facts
    assert 'ssh_host_key_dsa_public' in facts
    assert 'ssh_host_key_rsa_public' in facts
    assert 'ssh_host_key_ecdsa_public' in facts
    assert 'ssh_host_key_ed25519_public' in facts



# Generated at 2022-06-23 01:57:43.873472
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    print("ssh_pub_key fact collector object: ", obj)


# Generated at 2022-06-23 01:57:47.688145
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # TODO(jamielennox): This test requires some mocking of file reads as the
    # keys are from the host.
    assert True

# Generated at 2022-06-23 01:57:55.985021
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import get_module_facts
    from ansible.module_utils._text import to_text

    mycollector = Collector()
    mycollector.add_collector(SshPubKeyFactCollector())
    myfacts = get_module_facts(mycollector)
    assert myfacts['gather_subset'] == ['!all', '!min']
    assert myfacts['gather_timeout'] == 10
    assert isinstance(myfacts['ssh_host_pub_keys'], list)
    # Check that the list is not empty
    assert len(myfacts['ssh_host_pub_keys']) > 0

# Generated at 2022-06-23 01:58:03.360388
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                     'ssh_host_key_rsa_public',
                                     'ssh_host_key_ecdsa_public',
                                     'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:58:08.883351
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    collected_facts = collector.collect()

    for algo in ('dsa', 'rsa', 'ecdsa', 'ed25519'):
        factname = 'ssh_host_key_%s_public' % algo
        assert collected_facts[factname] != None

# Generated at 2022-06-23 01:58:15.643833
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_collector._fact_ids == set(['ssh_host_pub_keys',
                                                   'ssh_host_key_dsa_public',
                                                   'ssh_host_key_rsa_public',
                                                   'ssh_host_key_ecdsa_public',
                                                   'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:58:25.901563
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Test method collect of SshPubKeyFactCollector.

       The method collect should yield a dict with facts about the ssh
       public keys if they can be found in any of the three possible
       directories. The keys are used in the order listed in the keydirs
       list, the retrieved facts are in the same order.
    """
    class MockModule:
        def get_bin_path(self, path, required=True):
            return None

    class MockStat:
        def __init__(self, st_mode):
            self.st_mode = st_mode

        def S_ISREG(self, st_mode):
            return True

    mock_os = None
    mock_open = None


# Generated at 2022-06-23 01:58:32.322843
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_collector = SshPubKeyFactCollector()

    results = ssh_pub_key_collector.collect()
    assert results['ssh_host_key_ed25519_public'] == 'AAAAC3NzaC1lZDI1NTE5AAAAIIcsPzKb7V0pYw5ETgdV5GW0S5S1DmB2mE8zV4m4q3xGv'

# Generated at 2022-06-23 01:58:39.689311
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    #  test constructor
    assert(SshPubKeyFactCollector.__name__ is 'SshPubKeyFactCollector')
    assert(SshPubKeyFactCollector.name == 'ssh_pub_keys')
    assert(SshPubKeyFactCollector._fact_ids is not None)
    assert(len(SshPubKeyFactCollector._fact_ids) == 5)
    assert('ssh_host_pub_keys' in SshPubKeyFactCollector._fact_ids)
    assert('ssh_host_key_dsa_public' in SshPubKeyFactCollector._fact_ids)
    assert('ssh_host_key_rsa_public' in SshPubKeyFactCollector._fact_ids)

# Generated at 2022-06-23 01:58:48.658582
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.utils import get_file_content

    orig_get_file_content = get_file_content
    def monkeypatch_get_file_content(filename, default=None, boolean=False, algo=None, digest=None):
        if filename == '/etc/openssh/ssh_host_rsa_key.pub':
            return 'rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQC5rW1nI5c5o5PxdygPx8dShH2I9VkkJ6QdQ1U8i6b3qFmuDYykc'

# Generated at 2022-06-23 01:58:57.026803
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert SshPubKeyFactCollector().collect() == {
        'ssh_host_pub_keys': None,
        'ssh_host_key_dsa_public': None,
        'ssh_host_key_dsa_public_keytype': None,
        'ssh_host_key_ecdsa_public': None,
        'ssh_host_key_ecdsa_public_keytype': None,
        'ssh_host_key_ed25519_public': None,
        'ssh_host_key_ed25519_public_keytype': None,
        'ssh_host_key_rsa_public': None,
        'ssh_host_key_rsa_public_keytype': None
    }

# Generated at 2022-06-23 01:59:09.601851
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible_collections.community.general.plugins.module_utils.facts.collectors.network.ssh_pub_keys import SshPubKeyFactCollector
    from ansible_collections.community.general.tests.unit.compat.mock import patch
    from ansible_collections.community.general.tests.unit.modules.utils import set_module_args

    class TestSshPubKeyFactCollector(unittest.TestCase):
        def tearDown(self):
            set_module_args({})



# Generated at 2022-06-23 01:59:19.621843
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    import os
    import tempfile

    from ansible.module_utils.facts.collector import BaseFactCollector

    # create test ssh pub key for ecdsa
    test_ssh_pub_key_ecdsa_file = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-23 01:59:23.068752
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    class_obj = SshPubKeyFactCollector()
    assert class_obj.name == "ssh_pub_keys"
    assert 'ssh_host_pub_keys' in class_obj._fact_ids

# Generated at 2022-06-23 01:59:29.266847
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshpubkeyfact = SshPubKeyFactCollector()
    assert sshpubkeyfact.name == 'ssh_pub_keys'
    assert len(sshpubkeyfact._fact_ids) == 5
    assert 'ssh_host_pub_keys' in sshpubkeyfact._fact_ids
    assert 'ssh_host_key_dsa_public' in sshpubkeyfact._fact_ids
    assert 'ssh_host_key_rsa_public' in sshpubkeyfact._fact_ids
    assert 'ssh_host_key_ecdsa_public' in sshpubkeyfact._fact_ids
    assert 'ssh_host_key_ed25519_public' in sshpubkeyfact._fact_ids

# Generated at 2022-06-23 01:59:31.867977
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    '''
    Unit test for constructor of class SshPubKeyFactCollector
    '''    
    # Call constructor 
    obj = SshPubKeyFactCollector()

# Generated at 2022-06-23 01:59:34.914322
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    class_name = SshPubKeyFactCollector.__name__
    assert class_name == 'SshPubKeyFactCollector'


# Generated at 2022-06-23 01:59:42.312446
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    f = SshPubKeyFactCollector()
    assert f.name == 'ssh_pub_keys'
    assert f._fact_ids == set(['ssh_host_pub_keys',
        'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public',
        'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])


if __name__ == '__main__':
    f = SshPubKeyFactCollector()
    fact_data = f.collect(module=None, collected_facts=None)
    print(fact_data)

# Generated at 2022-06-23 01:59:49.895342
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    a = SshPubKeyFactCollector({})
    assert a._fact_ids == {'ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'}
    assert a.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:59:58.613094
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import collector
    sshpubkey_fact_collector = SshPubKeyFactCollector()
    fact_id = 'ssh_host_key_ecdsa_public'
    collected_facts = collector.collect(sshpubkey_fact_collector.name, sshpubkey_fact_collector, None)

    assert fact_id in collected_facts

# Generated at 2022-06-23 02:00:04.524141
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''Test the collect method of class SshPubKeyFactCollector'''
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()
    assert type(ssh_pub_key_facts) == dict
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts

# Generated at 2022-06-23 02:00:12.131380
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """
    Unit test for constructor of class SshPubKeyFactCollector
    """
    sshpubkeyfact = SshPubKeyFactCollector()
    assert sshpubkeyfact.name == 'ssh_pub_keys'
    assert sshpubkeyfact._fact_ids == set([
        'ssh_host_pub_keys',
        'ssh_host_key_dsa_public',
        'ssh_host_key_rsa_public',
        'ssh_host_key_ecdsa_public',
        'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 02:00:20.526721
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_fact = SshPubKeyFactCollector()
    assert ssh_fact.name == 'ssh_pub_keys'
    assert ssh_fact._fact_ids == set(['ssh_host_pub_keys',
                                      'ssh_host_key_dsa_public',
                                      'ssh_host_key_rsa_public',
                                      'ssh_host_key_ecdsa_public',
                                      'ssh_host_key_ed25519_public'])
