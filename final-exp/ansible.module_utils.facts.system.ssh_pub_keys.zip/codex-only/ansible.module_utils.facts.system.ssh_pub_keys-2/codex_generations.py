

# Generated at 2022-06-23 01:50:23.898724
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts._fact_ids == set(['ssh_host_pub_keys',
                                               'ssh_host_key_dsa_public',
                                               'ssh_host_key_rsa_public',
                                               'ssh_host_key_ecdsa_public',
                                               'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:50:29.140630
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():

    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == {
        'ssh_host_pub_keys', 'ssh_host_key_dsa_public',
        'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public',
        'ssh_host_key_ed25519_public'
    }

# Generated at 2022-06-23 01:50:40.053629
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils._text import to_bytes, to_text
    import os


# Generated at 2022-06-23 01:50:44.798193
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Create a new instance of SshPubKeyFactCollector
    ssh_pub_key_facts = SshPubKeyFactCollector()

    # Assert type of ssh_pub_key_facts
    assert isinstance(ssh_pub_key_facts, SshPubKeyFactCollector)

# Generated at 2022-06-23 01:50:53.715210
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    keys = SshPubKeyFactCollector()
    assert keys.name == 'ssh_pub_keys'
    assert keys.is_supported()
    assert keys._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])



# Generated at 2022-06-23 01:51:02.428246
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile

    for algo in ('dsa', 'rsa', 'ecdsa', 'ed25519'):
        factname = 'ssh_host_key_%s_public' % algo
        facttype = factname + '_keytype'
        key = 'AAAAB3NzaC1kc3MAAACBAJUyO6UJh6p5+fq3OzmZM5cGJ5rJOl/GxV+y8fJrn/whC'
        keytype = 'ssh-dss'

        fd, filename = tempfile.mkstemp()

# Generated at 2022-06-23 01:51:10.372690
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:51:18.705897
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    test_SshPubKeyFactCollector_instance = SshPubKeyFactCollector()
    assert test_SshPubKeyFactCollector_instance.name == 'ssh_pub_keys'
    assert test_SshPubKeyFactCollector_instance._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:51:24.949825
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector = SshPubKeyFactCollector()
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == \
        set(['ssh_host_pub_keys',
             'ssh_host_key_dsa_public',
             'ssh_host_key_rsa_public',
             'ssh_host_key_ecdsa_public',
             'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:51:29.305357
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_key_dsa_public_keytype', 'ssh_host_key_ed25519_public_keytype', 'ssh_host_key_ecdsa_public_keytype', 'ssh_host_key_ed25519_public', 'ssh_host_key_rsa_public_keytype', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_dsa_public', 'ssh_host_pub_keys'])

# Generated at 2022-06-23 01:51:39.685979
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    mock_module = MagicMock()
    mock_module.params = {'gather_subset': ['all']}
    mock_module.get_bin_path.return_value = '/usr/bin/python'

# Generated at 2022-06-23 01:51:49.738816
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class OSError(Exception):
        def __init__(self, errno, strerror):
            self.errno = errno
            self.strerror = strerror
    global os
    os = OSError(errno=2, strerror='File not found')
    class mock_get_file_content():
        def __init__(self, os, file_name, module=None):
            self.os = os
            self.module = module
            self.file_name = file_name

# Generated at 2022-06-23 01:51:59.450057
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # create testing instance
    x = SshPubKeyFactCollector()

    # create dummy fact collection
    facts = {}
    facts['ssh_host_key_dsa'] = "/etc/ssh/ssh_host_dsa_key"
    facts['ssh_host_key_rsa'] = "/etc/ssh/ssh_host_rsa_key"
    facts['ssh_host_key_ecdsa'] = "/etc/ssh/ssh_host_ecdsa_key"
    facts['ssh_host_key_ed25519'] = "/etc/ssh/ssh_host_ed25519_key"

    # create instance and run method collect
    # and check facts

# Generated at 2022-06-23 01:52:04.589599
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshpubkey = SshPubKeyFactCollector()
    assert sshpubkey.name == 'ssh_pub_keys', \
        "SSH Public Key Fact Collector name not set correctly"
    assert sshpubkey._fact_ids == set(['ssh_host_pub_keys',
                                       'ssh_host_key_dsa_public',
                                       'ssh_host_key_rsa_public',
                                       'ssh_host_key_ecdsa_public',
                                       'ssh_host_key_ed25519_public']), \
        "SSH public key facts set incorrectly"

# Generated at 2022-06-23 01:52:13.369673
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Declare a test case class for a unittest
    class TestCase():
        def __init__(self, name, keydirs, algos, expected_facts_keys, expected_facts_values):
            # Initialize a test case
            self.name = name
            self.keydirs = keydirs
            self.algos = algos
            self.expected_facts_keys = expected_facts_keys
            self.expected_facts_values = expected_facts_values
            return

    # Define test cases

# Generated at 2022-06-23 01:52:17.827038
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c = SshPubKeyFactCollector()
    assert c.name == 'ssh_pub_keys'
    assert c._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:52:21.110776
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector = SshPubKeyFactCollector()
    assert fact_collector.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:52:26.767603
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshfile = "~/.ssh/id_rsa.pub"
    sshkeys = SshPubKeyFactCollector()
    collect = sshkeys.collect()
    assert collect['ssh_host_key_dsa_public'] is None
    assert collect['ssh_host_key_rsa_public'] is None
    assert collect['ssh_host_key_ecdsa_public'] is None
    assert collect['ssh_host_key_ed25519_public'] is None

# Generated at 2022-06-23 01:52:29.989857
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    try:
        sc = SshPubKeyFactCollector()
    except Exception as e:
        print("Error: %s" % str(e))
        raise

    # No exception should be thrown
    assert True

# Generated at 2022-06-23 01:52:38.830288
# Unit test for constructor of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:52:42.559975
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
  ssh_pub_key_fact_collector = SshPubKeyFactCollector()
  assert ssh_pub_key_fact_collector is not None

# Generated at 2022-06-23 01:52:46.417059
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pub_key_collector = SshPubKeyFactCollector()
    collected_facts = pub_key_collector.collect({}, {})
    assert collected_facts == {}

# Generated at 2022-06-23 01:52:52.748183
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'
    assert collector.collectable_facts == set(('ssh_host_key_dsa_public',
                                               'ssh_host_key_rsa_public',
                                               'ssh_host_key_ecdsa_public',
                                               'ssh_host_key_ed25519_public'))


# Generated at 2022-06-23 01:53:02.130740
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    mock_module = type('module', (object,), {})
    mock_get_file_content = type('get_file_content', (object,), {'__call__': lambda *args, **kwargs: 'MOCK_CONTENT'})

    collector = SshPubKeyFactCollector(mock_module)
    collector.get_file_content = mock_get_file_content

    # all present
    facts = collector.collect()

# Generated at 2022-06-23 01:53:06.632374
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:53:17.329991
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ###########################################################################
    #
    # test_SshPubKeyFactCollector_collect
    #
    #    unit-tests for method collect of class SshPubKeyFactCollector
    #
    ###########################################################################

    from ansible.module_utils.facts import fact_collector

    # key files used in test

# Generated at 2022-06-23 01:53:18.854988
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()

# Generated at 2022-06-23 01:53:26.593547
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:53:34.153273
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
  key_algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
  ssh_pub_key_fact_collector = SshPubKeyFactCollector()
  assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'

  for key_algo in key_algos:
    assert 'ssh_host_key_%s_public' % key_algo in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_%s_public_keytype' % key_algo in ssh_pub_key_fact_collector._fact_ids

# Generated at 2022-06-23 01:53:47.903841
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''
        Unit test for method collect of class SshPubKeyFactCollector
    '''
    # Initialize required variables

# Generated at 2022-06-23 01:53:52.662295
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c = SshPubKeyFactCollector()
    assert c.name == 'ssh_pub_keys'
    assert c._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:53:53.762214
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-23 01:53:57.114301
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    holder = SshPubKeyFactCollector()
    ssh_pub_key_facts = holder.collect()
    assert isinstance(ssh_pub_key_facts, dict), 'Invalid assertions'



# Generated at 2022-06-23 01:54:09.107380
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    class TestFacts(object):

        def __init__(self, collected_facts):
            self.__dict__.update(collected_facts)

    # this is a list of tuples that is used as input to the test method
    # each tuple contains:
    #  - the expected result dictionary
    #  - a dictionary with facts that are set in the test
    #  - a dictionary with ansible vars that are set in the test

# Generated at 2022-06-23 01:54:14.306230
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKeyFactCollectorInstance = SshPubKeyFactCollector()
    assert sshPubKeyFactCollectorInstance.name == 'ssh_pub_keys'
    assert sshPubKeyFactCollectorInstance._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:54:22.540548
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():

    sshpubkey_col = SshPubKeyFactCollector()

    # Test if the name of the class is correct
    assert sshpubkey_col.name == 'ssh_pub_keys'

    assert sshpubkey_col._fact_ids == set(['ssh_host_pub_keys',
                                           'ssh_host_key_dsa_public',
                                           'ssh_host_key_rsa_public',
                                           'ssh_host_key_ecdsa_public',
                                           'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:54:31.389511
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector(None)
    assert collector.name == 'ssh_pub_keys'
    assert collector._fact_ids == set(['ssh_host_pub_keys',
                                       'ssh_host_key_dsa_public',
                                       'ssh_host_key_rsa_public',
                                       'ssh_host_key_ecdsa_public',
                                       'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:54:41.716073
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''Unit test for method collect of class SshPubKeyFactCollector'''

    class FakeModule():
        def __init__(self):
            self.params = None

    class FakeCollectedFacts():
        def __init__(self):
            self.facts = None

    class TestSshPubKeyFactCollector(SshPubKeyFactCollector):
        def __init__(self, module, collected_facts):
            self._module = module
            self._collected_facts = collected_facts

    collector_module = FakeModule()
    collector_collected_facts = FakeCollectedFacts()
    fake_SshPubKeyFactCollector = TestSshPubKeyFactCollector(collector_module, collector_collected_facts)
    ssh_pub_keys = fake_SshPubKeyFactCollector.collect()

   

# Generated at 2022-06-23 01:54:43.846768
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    f = SshPubKeyFactCollector()
    assert f.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:54:53.274433
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class TestModule(object):
        pass

    test_module = TestModule()
    keydir = '/etc/ssh'
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    ssh_pub_key_facts = {}

    class TestMkdtemp(object):
        def __enter__(self):
            return keydir

        def __exit__(self, *args, **kwargs):
            return

    class TestChMod(object):
        def __enter__(self):
            return

        def __exit__(self, *args, **kwargs):
            return

    class TestChown(object):
        def __enter__(self):
            return

        def __exit__(self, *args, **kwargs):
            return


# Generated at 2022-06-23 01:55:02.946336
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    import unittest

    fd, keydir = tempfile.mkdtemp()
    os.chmod(keydir, 0o0755)


# Generated at 2022-06-23 01:55:06.198441
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts is not None

# Generated at 2022-06-23 01:55:10.428096
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = {}
    SshPubKeyFactCollector = SshPubKeyFactCollector()
    ssh_pub_key_facts = SshPubKeyFactCollector.collect(module, collected_facts)
    assert ssh_pub_key_facts

# Generated at 2022-06-23 01:55:18.614800
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    fake_facts = {'ssh_host_key_rsa_public_keytype': 'ssh-rsa',
                  'ssh_host_key_rsa_public': 'mykey'}

    class FakeModule(object):
        pass

    class FakeCollector(object):
        def __init__(self, *args, **kwargs):
            return None

        def collect(self, module=None, collected_facts=None):
            return fake_facts

    class FakeClass(object):
        def __init__(self, *args, **kwargs):
            return None

        @staticmethod
        def get_collector_class(factname, *args, **kwargs):
            return FakeCollector

    module = FakeModule()
    setattr(module, '_collector_classes', {})

# Generated at 2022-06-23 01:55:20.070350
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-23 01:55:26.833749
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public',
                                         'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])

# Unit tests for method of SshPubKeyFactCollector

# Generated at 2022-06-23 01:55:29.978321
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector().name =='ssh_pub_keys'

# Generated at 2022-06-23 01:55:33.025086
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKeyFactCollector = SshPubKeyFactCollector()
    assert sshPubKeyFactCollector.name == 'ssh_pub_keys'



# Generated at 2022-06-23 01:55:39.205372
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    result = collector.collect(base_dir='test/unit/utils/facts/files')
    assert 'ssh_host_key_dsa_public' in result
    assert 'ssh_host_key_rsa_public' in result
    assert 'ssh_host_key_ecdsa_public' in result
    assert 'ssh_host_key_ed25519_public' in result

# Generated at 2022-06-23 01:55:40.531090
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector('ssh_pub_keys')

# Generated at 2022-06-23 01:55:43.014600
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """ Unit test for constructor of class SshPubKeyFactCollector
    """
    obj = SshPubKeyFactCollector()
    assert obj is not None

# Generated at 2022-06-23 01:55:46.064923
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshpubkeyFactCollector = SshPubKeyFactCollector()
    assert 'ssh_host_pub_keys' in sshpubkeyFactCollector._fact_ids

# Generated at 2022-06-23 01:55:53.216178
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collector = SshPubKeyFactCollector()

    # test for None
    collected_facts = collector.collect(module, None)
    assert(collected_facts is None)

    # test for {}
    collected_facts = collector.collect(module, {})
    assert(collected_facts is {})

    # test for valid returned info
    collected_facts = collector.collect(module, {})
    assert('ssh_host_pub_keys' in collected_facts)



# Generated at 2022-06-23 01:56:04.673556
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fc = SshPubKeyFactCollector()
    res = fc.collect()
    for item in res.items():
        print("%s: %s" % item)
    print("----")
    fact_ids = fc._fact_ids
    fact_ids.remove("ssh_host_pub_keys")
    fact_ids |= set(("ssh_host_pub_keys",))
    print("fact_ids = %s" % fact_ids)
    print("len(fact_ids) = %d" % len(fact_ids))
    print("type(fact_ids) = %s" % type(fact_ids))
    print("type(fact_ids) = %s" % type(fact_ids))

# Generated at 2022-06-23 01:56:11.698820
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test collect method of SshPubKeyFactCollector
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()

    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_facts

# Generated at 2022-06-23 01:56:22.252727
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_fact_collector.name == 'ssh_pub_keys'
    assert len(ssh_pub_fact_collector._fact_ids) == 5
    ssh_pub_keys = ssh_pub_fact_collector._fact_ids
    assert 'ssh_host_pub_keys' in ssh_pub_keys
    assert 'ssh_host_key_dsa_public' in ssh_pub_keys
    assert 'ssh_host_key_rsa_public' in ssh_pub_keys
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_keys
    assert 'ssh_host_key_ed25519_public' in ssh_pub_keys

# Generated at 2022-06-23 01:56:28.187274
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == "ssh_pub_keys"
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
        'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public',
        'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])



# Generated at 2022-06-23 01:56:30.155448
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    cp = SshPubKeyFactCollector()
    assert 'ssh_pub_keys' == cp.name
    assert (cp.collect() is not None)

# Generated at 2022-06-23 01:56:38.543554
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Modules built in the system module collection are not automatically
    # discovered.
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    mod_args = dict(
        _ansible_version=dict(
            numeric=10500,
            string='2.3.0.0'
        ),
        _ansible_module_name='test_SshPubKeyFactCollector_collect',
        _ansible_sysconfig=dict(
            path='/etc/ansible',
            module_utils='/path/to/module/utils'
        )
    )

    # Define mock facts.  In a production environment, these would likely come
    # from a database or file.
    collected_facts = dict(
        ansible_facts={}
    )

    # Instantiate the system

# Generated at 2022-06-23 01:56:45.397438
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c = SshPubKeyFactCollector()
    assert c.name == 'ssh_pub_keys'
    assert c._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:56:52.046925
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKeyFactCollector = SshPubKeyFactCollector()
    assert sshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert sshPubKeyFactCollector._fact_ids == set(
        ['ssh_host_pub_keys',
         'ssh_host_key_dsa_public',
         'ssh_host_key_rsa_public',
         'ssh_host_key_ecdsa_public',
         'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:57:02.407072
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    m_get_file_content = 'test_ssh_host_dsa_key.pub'
    m_get_file_content_empty = None
    m_fact_ids = ['ssh_host_key_dsa_public']
    m_key_filename = '/etc/ssh/ssh_host_dsa_key.pub'

# Generated at 2022-06-23 01:57:04.114403
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts is not None

# Generated at 2022-06-23 01:57:05.210084
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-23 01:57:15.520935
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # ARRANGE
    test_module = 'ansible.module_utils.facts.system.ssh_pub_keys'
    ssh_pub_key_facts = {}
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    keydirs = ['/etc/ssh', '/etc/openssh', '/etc']

    # ACT
    ssh_pub_key_facts = SshPubKeyFactCollector.collect()

    # ASSERT

# Generated at 2022-06-23 01:57:26.940694
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_collector = SshPubKeyFactCollector()

    def mock_get_file_content(filename):
        if 'ssh_host_dsa_key.pub' in filename:
            return 'ssh-dss AAAAB3NzaC1kc3MAAACBAK5p1v+S'
        if 'ssh_host_rsa_key.pub' in filename:
            return 'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCycRoajw'
        if 'ssh_host_ecdsa_key.pub' in filename:
            return 'ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNT'

# Generated at 2022-06-23 01:57:37.991475
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import utils

    # Set up a module mock
    module_mock = Collector._mock_module(argument_spec={},
                                         ansible_facts={},
                                         type='ansible')

    # Set up a get_file_content mock
    get_file_content_mock_type = type('GetFileContentMock',
                                      (object,),
                                      dict(read=lambda *args:
                                           'ssh-rsa AAAAB'))

# Generated at 2022-06-23 01:57:52.063124
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # pylint: disable=protected-access
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'

    # _fact_ids are registered to the list
    assert 'ssh_host_pub_keys' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_fact_collector._fact_ids

# Generated at 2022-06-23 01:58:02.615626
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
   keydir = '/etc'
   fact_name = 'ssh_host_key_ecdsa_public'
   key_filename = '%s/ssh_host_ecdsa_key.pub' % (keydir)
   ssh_pubkey_fact = SshPubKeyFactCollector()
   if fact_name in ssh_pubkey_fact._fact_ids:
      keydata = get_file_content(key_filename)
      (keytype, key) = keydata.split()[0:2]
      ssh_pub_key_facts = ssh_pubkey_fact.collect()
      assert(ssh_pub_key_facts[fact_name] == key)
      assert(ssh_pub_key_facts[fact_name + '_keytype'] == keytype)

# Generated at 2022-06-23 01:58:12.072174
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    keys = SshPubKeyFactCollector().collect(collected_facts=None)
    if len(keys) == 3:
        assert 'ssh_host_key_ecdsa_public' in keys
        assert 'ssh_host_key_ed25519_public' in keys
        assert 'ssh_host_key_rsa_public' in keys
        assert 'ssh_host_key_ecdsa_public_keytype' in keys
        assert keys['ssh_host_key_ecdsa_public_keytype'] == 'ecdsa-sha2-nistp256'
        assert 'ssh_host_key_ed25519_public_keytype' in keys
        assert keys['ssh_host_key_ed25519_public_keytype'] == 'ssh-ed25519'

# Generated at 2022-06-23 01:58:20.962063
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    from ansible.module_utils.facts import Collector
    
    module = False
    collected_facts = {}
    
    file = SshPubKeyFactCollector(module, collected_facts)
    assert file.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:58:27.334585
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    expected_facts_names = set(
        ['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public',
         'ssh_host_key_ed25519_public'])
    ssh_pub_key_collector = SshPubKeyFactCollector()
    ssh_pub_key_collector.collect()
    assert expected_facts_names == ssh_pub_key_collector._fact_ids

# Generated at 2022-06-23 01:58:36.768286
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshpubkeyfc = SshPubKeyFactCollector()
    assert sshpubkeyfc.name == 'ssh_pub_keys'
    assert sshpubkeyfc._fact_ids == set(['ssh_host_pub_keys',
                                         'ssh_host_key_dsa_public',
                                         'ssh_host_key_rsa_public',
                                         'ssh_host_key_ecdsa_public',
                                         'ssh_host_key_ed25519_public'])


# meta_data for test_SshPubKeyFactCollector
test_SshPubKeyFactCollector_meta_data = {'collector': 'SshPubKeyFactCollector',
                                         'depends': [],
                                         'os_platform': ['Linux'],
                                         'version': 'ssh_pub_keys'}

# Generated at 2022-06-23 01:58:42.062695
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:58:44.033597
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector
    assert x.name == 'ssh_pub_keys'
    assert len(x._fact_ids) == 5

# Generated at 2022-06-23 01:58:50.724471
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                                        'ssh_host_key_dsa_public',
                                                        'ssh_host_key_rsa_public',
                                                        'ssh_host_key_ecdsa_public',
                                                        'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:58:52.440994
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Check if it is necessary to add code to test the constructor
    assert(1 == 1)



# Generated at 2022-06-23 01:58:59.956124
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts_collector = SshPubKeyFactCollector()
    
    # Test with /etc/ssh/ssh_host_*_key.pub files
    ssh_pub_key_facts = ssh_pub_key_facts_collector.collect()
    

# Generated at 2022-06-23 01:59:09.195570
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collection import FactCollector
    from ansible.module_utils.facts import get_module_facts

    fact_collector = FactCollector()
    ssh_pub_key_collector = SshPubKeyFactCollector()
    fact_collector.collectors.append(ssh_pub_key_collector)
    facts = get_module_facts(fact_collector)
    pub_key_facts = facts['ssh_pub_keys']
    assert pub_key_facts['ssh_host_key_rsa_public'] != ""
    assert pub_key_facts['ssh_host_key_rsa_public_keytype'] == "ssh-rsa"

# Generated at 2022-06-23 01:59:16.034899
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert not issubclass(SshPubKeyFactCollector, BaseFactCollector)
    assert set(SshPubKeyFactCollector._fact_ids) == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])
    a = SshPubKeyFactCollector()
    assert a.name == 'ssh_pub_keys'
    assert a.priority == 89

# Generated at 2022-06-23 01:59:20.179823
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKeyFactCollector = SshPubKeyFactCollector()
    assert sshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert sshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:59:31.796888
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = None
    fc = SshPubKeyFactCollector(module=module, collected_facts=collected_facts)
    fc_facts_dict = fc.collect()

    # Verify that ssh_pub_keys facts were set
    ssh_pub_keys_facts = fc_facts_dict['ssh_pub_keys']
    assert (ssh_pub_keys_facts['ssh_host_key_dsa_public'] is not None)
    assert (ssh_pub_keys_facts['ssh_host_key_rsa_public'] is not None)
    assert (ssh_pub_keys_facts['ssh_host_key_ecdsa_public'] is not None)
    assert (ssh_pub_keys_facts['ssh_host_key_ed25519_public'] is not None)
   

# Generated at 2022-06-23 01:59:34.848895
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collect = SshPubKeyFactCollector.collect
    # Test whether method collect returns something
    assert collect()
    return collect()

# Generated at 2022-06-23 01:59:45.397169
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:59:54.491091
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.utils import mock_module_args
    from ansible.module_utils.facts.utils import MockModule

    import os
    import shutil

    # These tests can only be executed in systems that
    # have these key types
    # (dsa, rsa, ecdsa, ed25519).
    # Also, ssh daemon must not be running during test.
    # Public keys are generated using ssh-keygen
    # on a host with all key types

    # do not run on unsupported system
    if not os.path.exists('/etc/ssh'):
        return

    # list of directories to check for ssh keys
    # used in the order listed here, the first one with keys is used
    sshdirs = ['/etc/ssh', '/etc/openssh', '/etc']

    # list of

# Generated at 2022-06-23 02:00:06.357356
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # create a fake module
    module = type('AnsibleModule', (), {})()
    module.params = {}  # set of module input parameters
    module.exit_json = lambda a, b: True  # module exit function

    # Create a dictionary of facts collected from the system
    # e.g. ansible_all_ipv4_addresses
    collected_facts = {'ansible_all_ipv4_addresses': ['8.8.8.8']}

    # Create a instance of SshPubKeyFactCollector
    sshpubkey_fact_collector = SshPubKeyFactCollector()

    # Validate method collect of class SshPubKeyFactCollector
    assert sshpubkey_fact_collector.collect(module=module, collected_facts=collected_facts) is not None

# Generated at 2022-06-23 02:00:14.760349
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshpubkey = SshPubKeyFactCollector()
    assert sshpubkey.name == 'ssh_pub_keys'
    assert sshpubkey._fact_ids == {'ssh_host_pub_keys',
                                   'ssh_host_key_dsa_public',
                                   'ssh_host_key_rsa_public',
                                   'ssh_host_key_ecdsa_public',
                                   'ssh_host_key_ed25519_public'}
    assert sshpubkey.__doc__ == 'Ssh Public Key Facts'
    assert sshpubkey.__class__.__name__ == 'SshPubKeyFactCollector'

# Generated at 2022-06-23 02:00:16.467355
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c=SshPubKeyFactCollector()
    assert c is not None