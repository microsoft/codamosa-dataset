

# Generated at 2022-06-23 01:50:19.931317
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sut = SshPubKeyFactCollector()
    assert len(sut._fact_ids) == 5
    assert sut.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:50:22.409052
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    tfc = SshPubKeyFactCollector()
    # make sure that the set of fact names returned
    # by the method collect is what is expected
    assert set(tfc.collect().keys()) == tfc._fact_ids

# Generated at 2022-06-23 01:50:34.429306
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = {}

    # list of directories to check for ssh keys
    # used in the order listed here, the first one with keys is used
    keydirs = ['/etc/ssh', '/etc/openssh', '/etc']

    for keydir in keydirs:
        for algo in ('dsa', 'rsa', 'ecdsa', 'ed25519'):
            factname = 'ssh_host_key_%s_public' % algo
            if factname in ssh_pub_key_facts:
                # a previous keydir was already successful, stop looking
                # for keys
                return ssh_pub_key_facts
            key_filename = '%s/ssh_host_%s_key.pub' % (keydir, algo)

# Generated at 2022-06-23 01:50:36.854719
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    f = SshPubKeyFactCollector()
    assert f.__class__.__name__ == 'SshPubKeyFactCollector'
    assert f.name == 'ssh_pub_keys'


# Generated at 2022-06-23 01:50:44.414047
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Create an instance of SshPubKeyFactCollector
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # Assert that the name of ssh_pub_key_fact_collector is ssh_pub_key_facts
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'

    # Assert that the set of fact_ids is accurate
    assert ssh_pub_key_fact_collector._fact_ids == {'ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'}


# Generated at 2022-06-23 01:50:50.234909
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fake_system = {'platform': 'unknown'}
    fake_module = {'fake': 'module'}
    fake_collector = SshPubKeyFactCollector(fake_system, fake_module)

    assert fake_collector.collect() == {}

# Generated at 2022-06-23 01:50:59.975289
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''
    Test collect method of class SshPubKeyFactCollector
    '''
    import os

    # Create a temporary directory to create temp ssh keys
    temp_dir = tempfile.mkdtemp()

    # Create a temporary ssh host key file
    keyfile = tempfile.NamedTemporaryFile(mode='w', delete=False,
                                          dir=temp_dir)
    # Write a valid ssh host key in the file
    ssh_key_data = 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAA' \
                   'IEMr9n0nZTugzK17vw4e4W8K0cIlCA637UVUvZz' \
                   '6emFQYl'
    keyfile.write(ssh_key_data)

    # Close

# Generated at 2022-06-23 01:51:00.442258
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass # nop

# Generated at 2022-06-23 01:51:02.554089
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    result = collector.collect()
    assert len(result) == 0

if __name__ == '__main__':
    test_SshPubKeyFactCollector()

# Generated at 2022-06-23 01:51:10.495577
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_collector._fact_ids == set(['ssh_host_pub_keys',
                                                   'ssh_host_key_dsa_public',
                                                   'ssh_host_key_rsa_public',
                                                   'ssh_host_key_ecdsa_public',
                                                   'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:51:18.144545
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert 'ssh_pub_keys' == ssh_pub_key_collector.name
    assert set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public']) == ssh_pub_key_collector._fact_ids

# Generated at 2022-06-23 01:51:28.431044
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKeyFactCollector = SshPubKeyFactCollector()
    assert sshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert sshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:51:35.897916
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test all files are found.
    class TestModule():
        def __init__(self):
            self.params = {
                'paths': {
                    'ssh_host_dsa_key_pub': 'tests/unit/module_utils/file_data/ssh_host_dsa_key.pub',
                    'ssh_host_rsa_key_pub': 'tests/unit/module_utils/file_data/ssh_host_rsa_key.pub',
                    'ssh_host_ecdsa_key_pub': 'tests/unit/module_utils/file_data/ssh_host_ecdsa_key.pub',
                    'ssh_host_ed25519_key_pub': 'tests/unit/module_utils/file_data/ssh_host_ed25519_key.pub',
                }
            }

# Generated at 2022-06-23 01:51:42.666255
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Test case 1: success
    test = SshPubKeyFactCollector()
    assert test.name == 'ssh_pub_keys'
    assert test._fact_ids == set(['ssh_host_pub_keys',
                                  'ssh_host_key_dsa_public',
                                  'ssh_host_key_rsa_public',
                                  'ssh_host_key_ecdsa_public',
                                  'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:51:52.011775
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:51:59.001339
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Testing method collect of class SshPubKeyFactCollector
    """
    # NOTE(TheJulia): The goal of this unit test is to test
    # the path in which no keys are discovered, and verify
    # that nothing is returned.
    collector = SshPubKeyFactCollector()
    results = collector.collect(module=None, collected_facts=None)

    assert len(results) == 0

# Generated at 2022-06-23 01:52:09.440518
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Setup
    test_facts = SshPubKeyFactCollector()
    # Run
    result = test_facts.collect()
    # Verify

# Generated at 2022-06-23 01:52:11.312530
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert len(x._fact_ids) == 5

# Generated at 2022-06-23 01:52:20.298804
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                                        'ssh_host_key_dsa_public',
                                                        'ssh_host_key_rsa_public',
                                                        'ssh_host_key_ecdsa_public',
                                                        'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:52:32.235146
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:52:37.622215
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    # compare sets
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:52:44.207829
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create a new instance of SshPubKeyFactCollector
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # Create a dummy collected_facts
    collected_facts = {}

    # Call the collect method of SshPubKeyFactCollector
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect(collected_facts)

    # Assert that ssh_host_key_ecdsa_public is in the list of ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts

# Generated at 2022-06-23 01:52:53.304751
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    def mock_get_file_content(file):
        if file == '/etc/ssh/ssh_host_rsa_key.pub':
            return 'ssh-rsa BLA BLA BLA'

    SshPubKeyFactCollector._get_file_content = mock_get_file_content
    fact_collector = SshPubKeyFactCollector()
    result = fact_collector.collect()
    assert result == {'ssh_host_key_rsa_public': 'BLA',
                      'ssh_host_key_rsa_public_keytype': 'ssh-rsa'}

# Generated at 2022-06-23 01:52:59.786558
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():

    # Test to create object of class SshPubKeyFactCollector
    test_obj = SshPubKeyFactCollector()
    assert test_obj.name == 'ssh_pub_keys'
    assert test_obj._fact_ids == set(['ssh_host_pub_keys',
                                      'ssh_host_key_dsa_public',
                                      'ssh_host_key_rsa_public',
                                      'ssh_host_key_ecdsa_public',
                                      'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:53:03.252812
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    sshPubKeyFactCollector = SshPubKeyFactCollector()
    sshPubKeyFactCollector.collect()



# Generated at 2022-06-23 01:53:11.471079
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    result = SshPubKeyFactCollector.collect()
    assert result.keys() == ['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public']
    assert result['ssh_host_key_rsa_public'].startswith('AAAAB3NzaC1yc2E')
    assert result['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa'

# Generated at 2022-06-23 01:53:19.058226
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:53:21.221555
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    return SshPubKeyFactCollector()


# Generated at 2022-06-23 01:53:27.839070
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert(ssh_pub_key_facts.name=='ssh_pub_keys')
    assert(ssh_pub_key_facts._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public']))

# Generated at 2022-06-23 01:53:32.433786
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector.collect()
    assert ssh_pub_key_facts is not None
    assert ssh_pub_key_facts['ssh_host_key_rsa_public'] is not None
    assert ssh_pub_key_facts['ssh_host_key_rsa_public_keytype'] is not None

# Generated at 2022-06-23 01:53:33.862840
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-23 01:53:38.415296
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class MockModule:
        def __init__(self):
            self.params = None
    class MockFacts:
        def __init__(self):
            self.keys = []
    m = MockModule()
    f = MockFacts()
    fact = SshPubKeyFactCollector(m, f)
    fact.collect()
    return

# Generated at 2022-06-23 01:53:47.290504
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
  ssh_pub_key_collector = SshPubKeyFactCollector()
  assert ssh_pub_key_collector
  assert isinstance(ssh_pub_key_collector, BaseFactCollector)
  assert ssh_pub_key_collector.name == "ssh_pub_keys"
  assert ssh_pub_key_collector._fact_ids == set(['ssh_host_pub_keys',
                                                 'ssh_host_key_dsa_public',
                                                 'ssh_host_key_rsa_public',
                                                 'ssh_host_key_ecdsa_public',
                                                 'ssh_host_key_ed25519_public'])

#Unit test for collect method of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:53:58.738415
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import types
    import sys
    import os

    if sys.version_info[0] == 2:
        from mock import Mock
        from mock import patch
    else:
        from unittest.mock import Mock
        from unittest.mock import patch

    def run_collector(test_collector, test_module=None, test_collected_facts=None):
        if test_module is None:
            test_module = Mock()

        if test_collected_facts is None:
            test_collected_facts = dict()

        test_collector.collect(test_module, test_collected_facts)

    # ssh_host_key_rsa_public presents, as is ssh_host_key_dsa_public,
    # but all are then missing

# Generated at 2022-06-23 01:54:08.090700
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector = SshPubKeyFactCollector()
    assert fact_collector.name == 'ssh_pub_keys'
    assert set(fact_collector._fact_ids) == set(['ssh_host_pub_keys',
                                                 'ssh_host_key_dsa_public',
                                                 'ssh_host_key_rsa_public',
                                                 'ssh_host_key_ecdsa_public',
                                                 'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:54:16.314670
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = dict()

# Generated at 2022-06-23 01:54:23.584512
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set([
        'ssh_host_pub_keys', 'ssh_host_key_dsa_public',
        'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public',
        'ssh_host_key_ed25519_public'])

# Run tests on constructor of class SshPubKeyFactCollector
test_SshPubKeyFactCollector()

# Generated at 2022-06-23 01:54:26.896023
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    import sys
    if sys.version_info[0] < 3:
        ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    else:
        ssh_pub_key_fact_collector = SshPubKeyFactCollector()


# Generated at 2022-06-23 01:54:34.059748
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector = SshPubKeyFactCollector()
    facts = fact_collector.collect()

    assert len(facts) in (1, 2, 3, 4, 5)
    assert 'ssh_host_key_dsa_public' in facts
    assert 'ssh_host_key_rsa_public' in facts
    assert 'ssh_host_key_ecdsa_public' in facts
    assert 'ssh_host_key_ed25519_public' in facts
    assert 'ssh_host_pub_keys' in facts

# Generated at 2022-06-23 01:54:38.818798
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Instantiate SshPubKeyFactCollector
    x = SshPubKeyFactCollector()

    # Check its name
    assert x.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:54:46.308037
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    sshPubKeyFactCollector = SshPubKeyFactCollector()
    collected_facts = dict()
    ssh_pub_key_facts = sshPubKeyFactCollector.collect(collected_facts)
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_facts

# Generated at 2022-06-23 01:54:55.134861
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module_mock = MagicMock()
    collected_facts_mock = MagicMock()
    keydirs = ['/etc/ssh', '/etc/openssh', '/etc']
    key_filenames = ['%s/ssh_host_%s_key.pub' % (keydir, algo)
                     for keydir in keydirs
                     for algo in ('dsa', 'rsa', 'ecdsa', 'ed25519')]
    key_data = dict((key_filename, 'ssh-rsa %s %s' % (key_filename, key_filename))
                    for key_filename in key_filenames)
    key_data[key_filenames[0]] = None
    for key_filename in key_filenames:
        # mock call to get_file_content function
        get_

# Generated at 2022-06-23 01:54:56.559060
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector().name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:55:02.219279
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    instance = SshPubKeyFactCollector()
    assert instance.name == 'ssh_pub_keys'
    assert instance._fact_ids == set(['ssh_host_pub_keys',
                                      'ssh_host_key_dsa_public',
                                      'ssh_host_key_rsa_public',
                                      'ssh_host_key_ecdsa_public',
                                      'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:55:13.797819
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:55:16.016202
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:55:19.152158
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ''' Unit test for method collect of class SshPubKeyFactCollector '''

    # See test/integration/targets/module_utils_facts_collector.py
    module = {}
    collected_facts = {}

# Generated at 2022-06-23 01:55:25.237190
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    f = SshPubKeyFactCollector()
    assert f.name == 'ssh_pub_keys'
    assert f._fact_ids == {'ssh_host_key_rsa_public', 'ssh_host_key_ed25519_public', 'ssh_host_key_ecdsa_public', 'ssh_host_pub_keys', 'ssh_host_key_dsa_public'}


# Generated at 2022-06-23 01:55:30.885437
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector = SshPubKeyFactCollector()
    facts = fact_collector.collect()
    assert facts == {'ssh_host_key_rsa_public': 'dummy',
                     'ssh_host_key_rsa_public_keytype': 'ssh-rsa'}

# Generated at 2022-06-23 01:55:40.357684
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile

    # make dummy key files to test with
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    pubkeys = {}
    for algo in algos:
        pubkeys[algo] = tempfile.NamedTemporaryFile(delete=False)
        pubkeys[algo].write(b"%s %s dummykey" % (algo.upper(), algo))
        pubkeys[algo].close()

    # write a key with a different file format
    dsa_pub = tempfile.NamedTemporaryFile(delete=False)
    dsa_pub.write(b"ssh-dss dummykey")
    dsa_pub.close()

    # setup the test class
    sshkey_collector = SshPubKeyFactCollector

# Generated at 2022-06-23 01:55:45.702989
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Default constructor
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:55:49.251734
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert 'SshPubKeyFactCollector' == ssh_pub_key_collector.__class__.__name__

# Generated at 2022-06-23 01:55:58.409584
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # run_command_environ_update={} is not used, but is expected by AnsibleModule()
    module = AnsibleModule(argument_spec={}, run_command_environ_update={})
    fc = SshPubKeyFactCollector()
    facts = fc.collect(module)

    assert 'ssh_host_key_dsa_public' in facts
    assert 'ssh_host_key_rsa_public' in facts
    assert 'ssh_host_key_ecdsa_public' in facts
    assert 'ssh_host_key_ed25519_public' in facts
    assert 'ssh_host_key_dsa_public_keytype' in facts
    assert 'ssh_host_key_rsa_public_keytype' in facts

# Generated at 2022-06-23 01:55:59.397563
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-23 01:56:01.434531
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector = SshPubKeyFactCollector()
    collected_facts = fact_collector.collect()

    assert collected_facts['ssh_host_key_rsa_public']

# Generated at 2022-06-23 01:56:03.495864
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    print(ssh_pub_key_facts.collect())

# Generated at 2022-06-23 01:56:09.071220
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ''' Test for method SshPubKeyFactCollector.collect '''
    # Test case #1
    keys = ['/etc/ssh/ssh_host_dsa_key.pub',
            '/etc/ssh/ssh_host_rsa_key.pub',
            '/etc/ssh/ssh_host_ecdsa_key.pub',
            '/etc/ssh/ssh_host_ed25519_key.pub']
    facts = SshPubKeyFactCollector().collect(None, None)
    assert all(key in facts for key in keys)

# Generated at 2022-06-23 01:56:15.644003
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # create a SshPubFactCollector object
    sshpub_fc = SshPubKeyFactCollector()
    # use collect method
    facts = sshpub_fc.collect()
    # check if the collect method returned a facts dict
    assert isinstance(facts, dict)
    # check the keys of the facts dict
    assert set(facts.keys()) == sshpub_fc._fact_ids

# Generated at 2022-06-23 01:56:18.415020
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = None
    SshPubKeyFactCollector().collect(module, collected_facts)

# Generated at 2022-06-23 01:56:26.007477
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert sorted(SshPubKeyFactCollector._fact_ids) == sorted(['ssh_host_pub_keys',
                                                               'ssh_host_key_dsa_public',
                                                               'ssh_host_key_rsa_public',
                                                               'ssh_host_key_ecdsa_public',
                                                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:56:37.255090
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # setup
    ds = {'ssh_host_key_rsa_public': 'test_ssh_host_key_rsa_public',
          'ssh_host_key_dsa_public': 'test_ssh_host_key_dsa_public',
          'ssh_host_key_ecdsa_public': 'test_ssh_host_key_ecdsa_public',
          'ssh_host_key_ed25519_public': 'test_ssh_host_key_ed25519_public'}
    ssh_pub_key_fact_collector = SshPubKeyFactCollector(ds, None)
    # tests
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:56:48.613373
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content, set_file_content
    test = SshPubKeyFactCollector()
    keydirs = ['/etc/ssh', '/etc/openssh', '/etc']
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    keyfiles = [ keydir + '/ssh_host_' + algo + '_key.pub' for keydir in keydirs for algo in algos ]
    old_keydata = dict([ (a, get_file_content(a)) for a in keyfiles])

# Generated at 2022-06-23 01:56:57.802739
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import ansible_collections.ansible.misc.tests.test_utils.tempdir as td
    import ansible_collections.ansible.misc.tests.test_utils.mock as mock
    tempdir = td.TempDir()
    ssh_dir = tempdir.makedir('ssh')
    host_keys_dir = tempdir.makedir('ssh', 'ssh_host_keys')

# Generated at 2022-06-23 01:57:06.152130
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.utils import mock_module_args
    from ansible.module_utils.facts.utils import mock_module_builtin
    from ansible.module_utils.facts.utils import set_module_args
    from ansible.module_utils.facts.collector import FactsCollector

    modules = ['ansible.module_utils.basic']

    module = mock_module_builtin('/dev/null', modules)
    set_module_args(mock_module_args())

    results = FactsCollector(module).collect(module=module)

    assert 'ssh_host_ed25519_public' in results['ansible_ssh_host_keys']

# Generated at 2022-06-23 01:57:15.116636
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    '''Unit test for constructor of class SshPubKeyFactCollector'''
    ssh_pub_key_facts = SshPubKeyFactCollector()
    # name
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    # _fact_ids
    assert ssh_pub_key_facts._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:57:17.317598
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = {}
    assert SshPubKeyFactCollector().collect(collected_facts=ssh_pub_key_facts) == {}

# Generated at 2022-06-23 01:57:28.448783
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:57:30.905706
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import doctest
    results = doctest.testmod(SshPubKeyFactCollector)[0]
    assert results > 0

# Generated at 2022-06-23 01:57:40.633254
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pub_keys = SshPubKeyFactCollector.collect()

# Generated at 2022-06-23 01:57:47.608483
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    facts = SshPubKeyFactCollector()
    assert facts.name == 'ssh_pub_keys'
    assert sorted(facts._fact_ids) == ['ssh_host_key_dsa_public', 'ssh_host_key_dsa_public_keytype', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ecdsa_public_keytype', 'ssh_host_key_ed25519_public', 'ssh_host_key_ed25519_public_keytype', 'ssh_host_key_rsa_public', 'ssh_host_key_rsa_public_keytype', 'ssh_host_pub_keys']
    assert facts.collect() == {}
    assert facts.collect(collected_facts={}) == {}

# Generated at 2022-06-23 01:57:56.746978
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    testobj = SshPubKeyFactCollector()
    testobj.test_data = dict()

    # no keys
    testobj.test_data['/etc/ssh'] = dict()
    testobj.test_data['/etc/openssh'] = dict()
    testobj.test_data['/etc'] = dict()
    testobj.test_data['/etc/ssh']['ssh_host_dsa_key.pub'] = None
    testobj.test_data['/etc/ssh']['ssh_host_rsa_key.pub'] = None
    testobj.test_data['/etc/ssh']['ssh_host_ecdsa_key.pub'] = None
    testobj.test_data['/etc/ssh']['ssh_host_ed25519_key.pub'] = None
    test

# Generated at 2022-06-23 01:58:07.430623
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = {}
    SshPubKeyFactCollector = SshPubKeyFactCollector()
    collected_facts = SshPubKeyFactCollector.collect(module, collected_facts)
    assert collected_facts['ssh_host_key_ecdsa_public_keytype'] == 'ecdsa-sha2-nistp256'

# Generated at 2022-06-23 01:58:10.899360
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])



# Generated at 2022-06-23 01:58:18.039096
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # creating empty dictionaries
    module = {}
    collected_facts = {}
    # creating and object of class SshPubKeyFactCollector
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    # calling method collect of class SshPubKeyFactCollector
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect(module, collected_facts)
    # checking if the return type is a dictionary
    assert isinstance(ssh_pub_key_facts, dict)
    # checking if the dictionary is empty
    assert not ssh_pub_key_facts

# Generated at 2022-06-23 01:58:24.234906
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()

    # Test for _fact_ids
    assert obj._fact_ids.issubset(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public',
                                   'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])

    # Test for name
    assert obj.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:58:34.638807
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Arrange
    ssh_pub_key_facts_expected = {}
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    for algo in algos:
        factname = 'ssh_host_key_%s_public' % algo

# Generated at 2022-06-23 01:58:37.445743
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = {'os_family': 'RedHat'}
    collector = SshPubKeyFactCollector(module=module, collected_facts=collected_facts)
    assert collector.collect() == {}

# Generated at 2022-06-23 01:58:43.991134
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == {'ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'}

# Generated at 2022-06-23 01:58:53.262489
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:59:00.499525
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    import unittest

    class MockOS:
        def __init__(self):
            self.keydata = (
                'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAAAgQDx8nkQv/zgGgB4rMYmIf+6A4l6Rr+o/6lHBQdW5aYd44bd8JttDCE/F/pNRr0lRE+PiqSPO8nDPHw0010JeMH9gYgnnFlyY3/OcJ02RhIPyyxYpv9FhY+2YiUkpwFOcLImyrxEsYXpD/0d3ac30bNH6Sw9JD9UZHYcpSxsIbECHw=='
            )

# Generated at 2022-06-23 01:59:07.859371
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert len(SshPubKeyFactCollector._fact_ids) > 0
    for fact_id in ['ssh_host_pub_keys',
                    'ssh_host_key_dsa_public',
                    'ssh_host_key_rsa_public',
                    'ssh_host_key_ecdsa_public',
                    'ssh_host_key_ed25519_public']:
        assert fact_id in SshPubKeyFactCollector._fact_ids

# Generated at 2022-06-23 01:59:10.350758
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector = SshPubKeyFactCollector()
    assert fact_collector is not None

# Generated at 2022-06-23 01:59:20.851108
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    def mock_get_file_content(path):
        if path in ['/etc/ssh/ssh_host_rsa_key.pub',
                    '/etc/openssh/ssh_host_ecdsa_key.pub']:
            return b'testdata'
        return None

    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    saved_get_file_content = builtins.get_file_content
    builtins.get_file_content = mock_get_file_content


# Generated at 2022-06-23 01:59:32.202866
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content

    # Create the instance of SshPubKeyFactCollector class and call method collect
    # with an empty argument list
    ssh_pub_key_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_collector.collect()
    assert ssh_pub_key_facts

    # Create the instance of SshPubKeyFactCollector class and call method collect
    # with the argument module
    ssh_pub_key_collector = SshPubKeyFactCollector()
    module = Collector()
    ssh_pub_key_facts = ssh_pub_key_collector.collect(module=module)
    assert ssh_pub_key_facts

   

# Generated at 2022-06-23 01:59:38.987551
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()

    assert ssh_pub_key_facts

    assert 'rsa' in ssh_pub_key_facts['ssh_host_key_rsa_public']
    assert 'ecdsa' in ssh_pub_key_facts['ssh_host_key_ecdsa_public']
    assert 'ssh-rsa' in ssh_pub_key_facts['ssh_host_key_rsa_public_keytype']
    assert 'ssh-ed25519' in ssh_pub_key_facts['ssh_host_key_ed25519_public_keytype']

# Generated at 2022-06-23 01:59:42.151522
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()

    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == {'ssh_host_key_dsa_public',
                           'ssh_host_key_ed25519_public',
                           'ssh_host_key_ecdsa_public',
                           'ssh_host_key_rsa_public',
                           'ssh_host_pub_keys'}

# Generated at 2022-06-23 01:59:53.366000
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module_args = {}


# Generated at 2022-06-23 02:00:02.008808
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    spkfc = SshPubKeyFactCollector()
    assert spkfc.name == 'ssh_pub_keys'
    assert spkfc._fact_ids == set(['ssh_host_pub_keys',
                                   'ssh_host_key_dsa_public',
                                   'ssh_host_key_rsa_public',
                                   'ssh_host_key_ecdsa_public',
                                   'ssh_host_key_ed25519_public'])

# Unit test to test the method collect

# Generated at 2022-06-23 02:00:09.788528
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector = SshPubKeyFactCollector()
    assert "ssh_host_pub_keys" in fact_collector._fact_ids
    assert "ssh_host_key_dsa_public" in fact_collector._fact_ids
    assert "ssh_host_key_rsa_public" in fact_collector._fact_ids
    assert "ssh_host_key_ecdsa_public" in fact_collector._fact_ids
    assert "ssh_host_key_ed25519_public" in fact_collector._fact_ids

# Generated at 2022-06-23 02:00:21.559055
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Force the global variables to be reset
    SshPubKeyFactCollector._fact_ids = SshPubKeyFactCollector.__dict__['_fact_ids']
    SshPubKeyFactCollector.name = SshPubKeyFactCollector.__dict__['name']
    SshPubKeyFactCollector.__init__()

    test_obj = SshPubKeyFactCollector()
    test_obj._read_file_content = lambda x: x
    assert test_obj._read_file_content('/etc/ssh/ssh_host_dsa_key.pub') == "/etc/ssh/ssh_host_rsa_key.pub"