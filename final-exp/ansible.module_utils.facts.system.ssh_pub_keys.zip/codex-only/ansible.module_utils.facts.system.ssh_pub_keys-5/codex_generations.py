

# Generated at 2022-06-23 01:50:19.359389
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    sshPubKeyFactCollector = SshPubKeyFactCollector()
    # For successful case, testing just with one key
    ssh_pub_key_facts = sshPubKeyFactCollector.collect()
    assert("ssh_host_key_dsa_public" in ssh_pub_key_facts)

# Generated at 2022-06-23 01:50:26.314160
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == "ssh_pub_keys"
    assert ssh_pub_key_fact_collector.fact_names == set(['ssh_host_pub_keys',
                                                         'ssh_host_key_dsa_public',
                                                         'ssh_host_key_rsa_public',
                                                         'ssh_host_key_ecdsa_public',
                                                         'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:50:37.269004
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = None
    ssh_pub_key_facts = {}

    SshPubKeyFactCollector.collect(module, collected_facts)
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])
    assert SshPubKeyFactCollector.collect(module, collected_facts) == ssh_pub_key_facts

# Generated at 2022-06-23 01:50:47.953730
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:50:51.132911
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_keys = SshPubKeyFactCollector()
    ssh_pub_keys.collect()
    assert(0 < len(ssh_pub_keys.facts['ssh_host_pub_keys']))

# Generated at 2022-06-23 01:50:57.085952
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """Test SshPubKeyFactCollector"""    
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == {'ssh_host_pub_keys',
                                                'ssh_host_key_dsa_public',
                                                'ssh_host_key_rsa_public',
                                                'ssh_host_key_ecdsa_public',
                                                'ssh_host_key_ed25519_public'}

# Generated at 2022-06-23 01:51:00.193203
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:51:00.987704
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector()

# Generated at 2022-06-23 01:51:02.815983
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():

    obj = SshPubKeyFactCollector()
    obj.collect(module=None)

    pass

# Generated at 2022-06-23 01:51:05.398580
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert isinstance(SshPubKeyFactCollector, object)


# Generated at 2022-06-23 01:51:06.402481
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_SshPubKeyFactCollector_collect.__self__.collect()

# Generated at 2022-06-23 01:51:13.268119
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fc = SshPubKeyFactCollector()

    assert ssh_pub_key_fc.name == 'ssh_pub_keys'
    assert ssh_pub_key_fc._fact_ids == set(['ssh_host_pub_keys',
                                            'ssh_host_key_dsa_public',
                                            'ssh_host_key_rsa_public',
                                            'ssh_host_key_ecdsa_public',
                                            'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:51:23.279393
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Test method collect of class SshPubKeyFactCollector"""

    from ansible.module_utils.facts.utils import get_file_content
    filecontent = 'testdata'
    filename = '/testpath'

    ssh_host_dsa_key = 'ssh-dss testdata'
    ssh_host_rsa_key = 'ssh-rsa testdata'
    ssh_host_ecdsa_key = 'ecdsa-sha2-nistp256 testdata'
    ssh_host_ed25519_key = 'ssh-ed25519 testdata'

    # Mock facts module
    collected_facts = {}

    # Mock get_file_content
    get_file_content_calls = []
    get_file_content_return_vals = {}


# Generated at 2022-06-23 01:51:30.607894
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = {}
    collected_facts = {}
    fact_collector = SshPubKeyFactCollector(module, collected_facts)
    ssh_pub_key_facts = fact_collector.collect()
    assert ('ssh_host_key_dsa_public' in ssh_pub_key_facts) or \
        ('ssh_host_key_rsa_public' in ssh_pub_key_facts) or \
        ('ssh_host_key_ecdsa_public' in ssh_pub_key_facts) or \
        ('ssh_host_key_ed25519_public' in ssh_pub_key_facts)

# Generated at 2022-06-23 01:51:31.119540
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-23 01:51:31.802512
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-23 01:51:42.816904
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import sys
    module_name = 'ansible_collections.ansible.community.plugins.module_utils.facts.system.ssh_pub_keys'
    # py3 shim, will be deleted once all modules are py3 compatible
    if not sys.version_info >= (3, 0):
        module_name = module_name.encode('utf-8')

    sys.modules[module_name] = sys.modules['ansible_collections.ansible.community.plugins.module_utils.facts.system.ssh_pub_keys']
    import ansible_collections.ansible.community.plugins.module_utils.facts.system.ssh_pub_keys
    import os

    # mock module, will be restored after testing
    original_os = os

# Generated at 2022-06-23 01:51:50.905085
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():

    from ansible.module_utils.facts.collector import SshPubKeyFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    import sys

    c = SshPubKeyFactCollector()

    assert isinstance(c, BaseFactCollector)
    assert c.name == 'ssh_pub_keys'
    assert c._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:52:00.057067
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c = SshPubKeyFactCollector()
    assert c.__class__.__name__ == 'SshPubKeyFactCollector'
    assert c.name == 'ssh_pub_keys'
    assert c._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:52:10.342843
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ''' Test collect of SshPubKeyFactCollector '''

    from ansible.module_utils.facts.collector import FactCollector

    # create fact_collector instance
    fact_collector = FactCollector()

    # create SshPubKeyFactCollector instance
    test_fact_collector = SshPubKeyFactCollector()

    # add to fact_collector
    fact_collector.add_collector(test_fact_collector)

    # get the facts
    facts = fact_collector.get_facts(module=None, collected_facts=None)

    # results
    results = facts['ssh_pub_keys']

    # compare
    assert isinstance(results, dict), "Expected dict, received %s" % type(results)

# Generated at 2022-06-23 01:52:21.997952
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create an instance of class SshPubKeyFactCollector
    ssh_pub_key_collector = SshPubKeyFactCollector()
    # When the ssh keys exist, we expect to get the values of them
    ssh_pub_key_facts = ssh_pub_key_collector.collect()

# Generated at 2022-06-23 01:52:30.091542
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()

    assert obj.name == 'ssh_pub_keys'
    assert 'ssh_host_pub_keys' in obj._fact_ids
    assert 'ssh_host_key_dsa_public' in obj._fact_ids
    assert 'ssh_host_key_rsa_public' in obj._fact_ids
    assert 'ssh_host_key_ecdsa_public' in obj._fact_ids
    assert 'ssh_host_key_ed25519_public' in obj._fact_ids

# Generated at 2022-06-23 01:52:34.995785
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    output = dict(ssh_host_pub_keys=['ssh-rsa AAAA...', 'ssh-dsa AAAA...'],
                  ssh_host_key_dsa_public='AAAA...',
                  ssh_host_key_rsa_public='AAAA...')
    
    s = SshPubKeyFactCollector()
    assert s.collect() == output

# Generated at 2022-06-23 01:52:44.314102
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils._text import to_bytes, to_text

    ###################################################################################
    #
    # Create instance of SshPubKeyFactCollector
    #
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    #
    # Create instance of FactCollector to feed SshPubKeyFactCollector with mocked data
    #
    fact_collector = FactCollector()

    # Configure mocked data to be returned by the method collect of FactCollector class
    mocked_collected_facts = {
        'ansible_distribution': 'Ubuntu',
        'ansible_distribution_release': '16.04'
    }
    fact_collector.collect = lambda: mocked_collected_facts
    #

# Generated at 2022-06-23 01:52:51.244117
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    path = os.path.dirname(__file__) 
    filepath = path + "/../../../unit_test/data/ssh_host_rsa_key.pub"
    f = open(filepath, "r")
    keydata = f.read()
    (keytype, key) = keydata.split()[0:2]
    SshPubKeyFactCollector.collect(SshPubKeyFactCollector, filepath)

# Generated at 2022-06-23 01:53:00.747937
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    filenames = ['/etc/ssh/ssh_host_dsa_key.pub']

# Generated at 2022-06-23 01:53:07.940960
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', 'ssh_pub_keys'], type='list')
        )
    )
    facts_collector = SshPubKeyFactCollector(module=module)
    facts = facts_collector.collect()

    assert isinstance(facts, dict)
    assert 'ssh_host_pub_keys' in facts
    assert 'ssh_host_key_dsa_public' in facts
    assert 'ssh_host_key_rsa_public' in facts
    assert 'ssh_host_key_ecdsa_public' in facts
    assert 'ssh_host_key_ed25519_public' in facts



# Generated at 2022-06-23 01:53:09.658772
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_collector = SshPubKeyFactCollector()

# Generated at 2022-06-23 01:53:12.735824
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    SshPubKeyFactCollector_object = SshPubKeyFactCollector()
    assert SshPubKeyFactCollector_object.collect() == {}


# Generated at 2022-06-23 01:53:14.439401
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    keys = SshPubKeyFactCollector().collect()
    assert type(keys) == dict


# Generated at 2022-06-23 01:53:22.074085
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts is not None
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts._fact_ids == {'ssh_host_pub_keys',
                                           'ssh_host_key_dsa_public',
                                           'ssh_host_key_rsa_public',
                                           'ssh_host_key_ecdsa_public',
                                           'ssh_host_key_ed25519_public'}

# Generated at 2022-06-23 01:53:32.230667
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Instantiate SshPubKeyFactCollector
    test_instance = SshPubKeyFactCollector()

    # _fact_ids not set, method _get_fact_ids must be mocked
    # collected_facts must be mocked
    with mock.patch.object(SshPubKeyFactCollector, '_get_fact_ids') as (
        mock_get_fact_ids
    ):
        mock_get_fact_ids.return_value = set(['ssh_host_pub_keys',
                                              'ssh_host_key_dsa_public',
                                              'ssh_host_key_rsa_public',
                                              'ssh_host_key_ecdsa_public',
                                              'ssh_host_key_ed25519_public'])
        # method collect runs under try/except and
        #

# Generated at 2022-06-23 01:53:35.389119
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    facts = collector.collect()
    assert isinstance(facts, dict)
    assert 'ssh_host_pub_keys' in facts

# Generated at 2022-06-23 01:53:44.834627
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:53:53.297909
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Patch module_utils.facts.utils.get_file_content_string
    original_get_file_content = get_file_content


# Generated at 2022-06-23 01:53:58.699944
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    expected_result = set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])
    test_collector = SshPubKeyFactCollector()
    assert test_collector._fact_ids == expected_result

# Generated at 2022-06-23 01:54:05.885945
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector = SshPubKeyFactCollector()
    res = fact_collector.collect()
    print(res)
    assert res is not None
    assert 'ssh_host_key_rsa_public' in res
    assert 'ssh_host_key_rsa_public_keytype' in res


# Generated at 2022-06-23 01:54:06.815500
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-23 01:54:15.371594
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
  # Call constructor
  ssh_pub_key_fact_collector = SshPubKeyFactCollector()

  # Test that name was set
  assert 'ssh_pub_keys' == ssh_pub_key_fact_collector.name

  # Test that _fact_ids contains
  # 'ssh_host_pub_keys',
  # 'ssh_host_key_dsa_public',
  # 'ssh_host_key_rsa_public',
  # 'ssh_host_key_ecdsa_public',
  # 'ssh_host_key_ed25519_public'

# Generated at 2022-06-23 01:54:17.508618
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    keyfacts = SshPubKeyFactCollector()
    assert keyfacts.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:54:26.404163
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create a SshPubKeyFactCollector instance
    ssh_pub_key_fact = SshPubKeyFactCollector()

    # Test with non existing ssh keys in /etc/ssh, /etc/openssh and /etc
    # directories
    assert ssh_pub_key_fact.collect() == {}

    # Test with existing ssh keys in /etc/ssh and /etc/openssh directories
    # (but not in /etc), only the ssh keys of /etc/ssh are returned
    assert ssh_pub_key_fact.collect() == {}

    # Test with existing ssh keys in /etc/ssh, /etc/openssh and /etc
    # directories, only the ssh keys of /etc/ssh are returned
    assert ssh_pub_key_fact.collect() == {}

# Generated at 2022-06-23 01:54:33.707041
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_key_collector = SshPubKeyFactCollector()
    assert ssh_key_collector.name == 'ssh_pub_keys'
    assert ssh_key_collector._fact_ids == set(['ssh_host_pub_keys',
                                               'ssh_host_key_dsa_public',
                                               'ssh_host_key_rsa_public',
                                               'ssh_host_key_ecdsa_public',
                                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:54:42.835892
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
        Test that the method SshPubKeyFactCollector.collect
        is returning a dictionary matching with the expected one.
    """
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts import FactCollector

    class TestSshPubKeyFactCollector(SshPubKeyFactCollector):
        def __init__(self):
            SshPubKeyFactCollector.__init__(self)
            self._get_file_content = get_file_content

    test_collector = TestSshPubKeyFactCollector()

# Generated at 2022-06-23 01:54:46.159788
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    result = FactCollector.collect_fact('s')

# Generated at 2022-06-23 01:54:50.656078
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ch = SshPubKeyFactCollector()
    assert ch.name == 'ssh_pub_keys'
    assert ch._fact_ids == set(['ssh_host_pub_keys',
                                'ssh_host_key_dsa_public',
                                'ssh_host_key_rsa_public',
                                'ssh_host_key_ecdsa_public',
                                'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:55:01.544426
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Arrange Things
    ansible_module = AnsibleModuleStub()
    result = {}
    collector = SshPubKeyFactCollector(ansible_module)

    # Act
    result = collector.collect()

    # Assert
    assert 'ssh_host_key_dsa_public' in result
    assert 'ssh_host_key_rsa_public' in result
    assert 'ssh_host_key_ecdsa_public' in result
    assert 'ssh_host_key_ed25519_public' in result

    assert 'ssh_host_key_dsa_public_keytype' in result
    assert 'ssh_host_key_rsa_public_keytype' in result
    assert 'ssh_host_key_ecdsa_public_keytype' in result

# Generated at 2022-06-23 01:55:03.386738
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector().name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:55:10.955504
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''Unit test for method collect of class SshPubKeyFactCollector'''
    SshPubKeyFactCollector_instance = SshPubKeyFactCollector()
    assert SshPubKeyFactCollector_instance.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector_instance._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:55:11.826090
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # TODO: write unit test
    pass

# Generated at 2022-06-23 01:55:22.842079
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test SshPubKeyFactCollector.collect with keys in /etc/ssh
    test_collector = SshPubKeyFactCollector()

# Generated at 2022-06-23 01:55:23.769437
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-23 01:55:34.499233
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """ Test behavior of the function collect of class SshPubKeyFactCollector """

    # Read the file test.facts
    module = None
    collected_facts = {}
    ssh_pub_key_facts = SshPubKeyFactCollector.load_srcfile(module, collected_facts)

    # Check that the keys are as expected

# Generated at 2022-06-23 01:55:40.913832
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKeyFact1 = SshPubKeyFactCollector()
    sshPubKeyFact2 = SshPubKeyFactCollector()
    assert sshPubKeyFact1.name == sshPubKeyFact2.name
    assert sshPubKeyFact1.collect() == sshPubKeyFact2.collect()
    assert isinstance(sshPubKeyFact1.collect(), dict)
    assert set(sshPubKeyFact1.collect().keys()) == sshPubKeyFact1._fact_ids

# Generated at 2022-06-23 01:55:43.210695
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_host_key_collector = SshPubKeyFactCollector()
    assert ssh_host_key_collector is not None

# Generated at 2022-06-23 01:55:54.495116
# Unit test for constructor of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:56:03.183296
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector = SshPubKeyFactCollector()

    key_fact = fact_collector.collect()
    assert key_fact is not None
    assert 'ssh_host_key_dsa_public' in key_fact
    assert 'ssh_host_key_rsa_public' in key_fact
    assert 'ssh_host_key_ecdsa_public' in key_fact
    assert 'ssh_host_key_ed25519_public' in key_fact

# Generated at 2022-06-23 01:56:08.960684
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():

    collector = SshPubKeyFactCollector()

    assert collector.name == 'ssh_pub_keys'
    assert collector._fact_ids == set(['ssh_host_pub_keys',
                                       'ssh_host_key_dsa_public',
                                       'ssh_host_key_rsa_public',
                                       'ssh_host_key_ecdsa_public',
                                       'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:56:15.893169
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_key_ecdsa_public', 'ssh_host_key_rsa_public', 'ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:56:27.581414
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """This is unit test for method collect of class SshPubKeyFactCollector.
    Unit test generally check whether the expected string is correctly
    returned. To avoid external dependencies, all values are hard coded.
    """

    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collectors import get_collector_instance
    import os

    test_file_path = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), 'test_SSH_pub_key')

    # prepare fake file

# Generated at 2022-06-23 01:56:32.256658
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # initialize and run method collect
    pfacts = SshPubKeyFactCollector()
    fact_list = pfacts.collect()

    # test for an empty fact list
    assert(fact_list == {})

# Generated at 2022-06-23 01:56:42.414188
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    c = SshPubKeyFactCollector()
    res = c.collect()

# Generated at 2022-06-23 01:56:51.348969
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import mock
    import os
    import pytest
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network.ssh_pub_keys import SshPubKeyFactCollector

    data = 'ssh-rsa fake_public_key'
    file_data = '%s\n' % data
    module = mock.MagicMock()
    mock_get_file_content = mock.MagicMock(return_value=data)
    module.get_bin_path.return_value = '/bin'

    class Collectors():
        def all(self):
            return [SshPubKeyFactCollector]

    class Facts(dict):
        def __init__(self):
            self

# Generated at 2022-06-23 01:57:01.673340
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:57:03.853753
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert isinstance(SshPubKeyFactCollector(), SshPubKeyFactCollector)

# Generated at 2022-06-23 01:57:06.303400
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_collector.collect()
    assert ssh_pub_key_facts == None

    ssh_pub_key_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_collector.collect(module=None, collected_facts=None)
    assert ssh_pub_key_facts == None

# Generated at 2022-06-23 01:57:16.481727
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # prepare mock data
    class module_mock:
        pass

    # mock initialisation
    module = module_mock()
    module.params = {
        'gather_subset': [
            '!all',
            'network'
        ],
        'gather_timeout': 10,
        'filter': '*'
    }

    # mock file content
    module.get_file_content = get_file_content

    # init class
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # test
    ret = ssh_pub_key_fact_collector.collect(module)
    assert ret['ssh_host_key_rsa_public'] is not None
    assert ret['ssh_host_key_rsa_public_keytype'] is not None

# Generated at 2022-06-23 01:57:22.380265
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create an instance of SshPubKeyFactCollector
    coll = SshPubKeyFactCollector()
    # Call method collect
    result = coll.collect()
    # Check that ssh_host_key_ecdsa_public is present
    assert 'ssh_host_key_ecdsa_public' in result
    # Check that ssh_host_key_ecdsa_public_keytype is present
    assert 'ssh_host_key_ecdsa_public_keytype' in result

# Generated at 2022-06-23 01:57:23.187842
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.collect()

# Generated at 2022-06-23 01:57:27.892158
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector(None)
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:57:33.789034
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    con = SshPubKeyFactCollector()
    result = con.collect()
    assert 'ssh_host_key_dsa_public' in result
    assert 'ssh_host_key_rsa_public' in result
    assert 'ssh_host_key_ecdsa_public' in result
    assert 'ssh_host_key_ed25519_public' in result

# Generated at 2022-06-23 01:57:42.733950
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collectors.ssh_pub_keys.ssh_pub_keys import SshPubKeyFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    mock_module = object()

    # get_file_content returns None
    get_file_content_nones = ((None, None), (None, None), (None, None), (None, None),)
    get_file_content_mock = lambda path: get_file_content_nones.pop()

    ssh_pub_key_facts = dict()

    def get_fact_mock(name):
        return ssh_pub_key_facts.get(name)

    def set_fact_mock(name, value):
        ssh_

# Generated at 2022-06-23 01:57:50.970008
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create mock objects
    module = type('', (), {})()
    collected_facts = type('', (), {})()

    # Create collector object
    ssh_pub_key_fact_collector = SshPubKeyFactCollector(module=module, collected_facts=collected_facts)

    # This is what we expect to return
    ret = type('', (), {})()

# Generated at 2022-06-23 01:57:51.600430
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    pass

# Generated at 2022-06-23 01:57:54.362661
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    instance = SshPubKeyFactCollector()
    assert hasattr(instance, 'name')
    assert hasattr(instance, 'collect')


# Generated at 2022-06-23 01:58:00.266157
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    instance = SshPubKeyFactCollector()
    assert instance.name == 'ssh_pub_keys'
    assert instance._fact_ids == set(['ssh_host_pub_keys',
                                      'ssh_host_key_dsa_public',
                                      'ssh_host_key_rsa_public',
                                      'ssh_host_key_ecdsa_public',
                                      'ssh_host_key_ed25519_public'])

# Generated at 2022-06-23 01:58:07.439621
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import io
    import shutil

    facts = {}

    temp_ssh_dir = '/tmp/ansible_ssh_pub_keys'
    if os.path.isdir(temp_ssh_dir):
        shutil.rmtree(temp_ssh_dir)
    os.makedirs(temp_ssh_dir)
    temp_ssh_config = os.path.join(temp_ssh_dir, 'ssh_config')

    # Create test ssh_config
    f = io.open(temp_ssh_config, 'w', encoding='utf-8')
    f.write(
        u'''Host test
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null
''')
    f.close()


# Generated at 2022-06-23 01:58:10.281227
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    result_dict = SshPubKeyFactCollector().collect()
    assert 'ssh_host_key_ed25519_public' in result_dict
    assert result_dict['ssh_host_key_ed25519_public'].startswith('AAAAE')

# Generated at 2022-06-23 01:58:19.029600
# Unit test for constructor of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:58:28.987523
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_fact_collector = SshPubKeyFactCollector()

    facts_collector = {
        'filter_values': {
            'ansible_ssh_host_key_ecdsa_public': True,
            'ansible_ssh_host_key_ed25519_public': True,
            'ansible_ssh_host_key_rsa_public': True,
            'ansible_ssh_host_key_dsa_public': True
        },
        'fetch_failing_values': {
            'ansible_pkg_mgr': None
        },
        'fetch_missing_values': {
            'ansible_pkg_mgr': None
        },
        'collector': {},
        'ansible_facts': {},
    }

    # ansible_ssh_host_key_*

# Generated at 2022-06-23 01:58:32.001223
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    sut = SshPubKeyFactCollector()
    # Verify that a dictionary is returned
    assert isinstance(sut.collect(), dict)


# Generated at 2022-06-23 01:58:34.740550
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    Obj = SshPubKeyFactCollector()
    assert Obj._fact_ids is not None
    assert Obj.name is not None
    assert Obj.collect() is not None

# Generated at 2022-06-23 01:58:39.044994
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == \
           set(['ssh_host_pub_keys',
                'ssh_host_key_dsa_public',
                'ssh_host_key_rsa_public',
                'ssh_host_key_ecdsa_public',
                'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:58:47.992224
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    testVars = {'ssh_host_key_dsa_public' : 'ssh-dss',
                'ssh_host_key_rsa_public' : 'ssh-rsa',
                'ssh_host_key_ecdsa_public' : 'ecdsa-sha2-nistp256',
                'ssh_host_key_ed25519_public' : 'ssh-ed25519'}

    factCollector = SshPubKeyFactCollector()
    ssh_pub_key_facts = factCollector.collect()
    assert type(ssh_pub_key_facts) is dict
    for key in testVars:
        if key in ssh_pub_key_facts:
            assert ssh_pub_key_facts[key].split()[0] == testVars[key]
        else:
            assert False

# Generated at 2022-06-23 01:58:49.900017
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'

# Generated at 2022-06-23 01:58:55.410686
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    testobj = SshPubKeyFactCollector()
    assert testobj.name == 'ssh_pub_keys'
    assert testobj._fact_ids == set(['ssh_host_pub_keys',
                                     'ssh_host_key_dsa_public',
                                     'ssh_host_key_rsa_public',
                                     'ssh_host_key_ecdsa_public',
                                     'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:59:06.951615
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts._fact_ids == {'ssh_host_pub_keys',
                                           'ssh_host_key_dsa_public',
                                           'ssh_host_key_rsa_public',
                                           'ssh_host_key_ecdsa_public',
                                           'ssh_host_key_ed25519_public'}

# Generated at 2022-06-23 01:59:10.306934
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_fact_collector = SshPubKeyFactCollector()
    fact_data = ssh_fact_collector.collect()
    assert fact_data is not None

# Generated at 2022-06-23 01:59:20.793331
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collectors.ssh_pub_keys import SshPubKeyFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import os
    import pwd
    import tempfile
    import shutil
    import stat

    test_dir = tempfile.mkdtemp(dir='/tmp', prefix='ansible-ssh_pub_key-tests-')
    os.chmod(test_dir, 0o777)

    # list of directories to check for ssh keys
    # used in the order listed here, the first one with keys is used
    keydirs = [test_dir + '/etc/ssh',
               test_dir + '/etc/openssh',
               test_dir + '/etc']

    # make directories we are going to use

# Generated at 2022-06-23 01:59:29.785720
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])


# Generated at 2022-06-23 01:59:33.581815
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()



# Generated at 2022-06-23 01:59:36.442227
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector_obj = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector_obj.collect()

# Generated at 2022-06-23 01:59:46.970806
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:59:55.143392
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-23 01:59:58.328330
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert set(SshPubKeyFactCollector().collect()) == SshPubKeyFactCollector()._fact_ids

# Generated at 2022-06-23 02:00:09.456868
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    m = SshPubKeyFactCollector()

# Generated at 2022-06-23 02:00:11.115897
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    facts = SshPubKeyFactCollector()
    assert facts.name == 'ssh_pub_keys'

# Generated at 2022-06-23 02:00:22.640895
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():

    ssh_pub_key_obj = SshPubKeyFactCollector("SshPubKeyFactCollector", "ssh_pub_keys", [], None)
    assert ssh_pub_key_obj
    assert ssh_pub_key_obj.name == 'ssh_pub_keys'
    assert isinstance(ssh_pub_key_obj._fact_ids, set)
    assert len(ssh_pub_key_obj._fact_ids) == 5
    assert 'ssh_host_pub_keys' in ssh_pub_key_obj._fact_ids
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_obj._fact_ids
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_obj._fact_ids
    assert 'ssh_host_key_ecdsa_public'