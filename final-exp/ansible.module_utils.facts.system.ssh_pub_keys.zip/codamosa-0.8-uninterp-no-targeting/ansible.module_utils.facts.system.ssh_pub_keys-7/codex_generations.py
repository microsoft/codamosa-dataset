

# Generated at 2022-06-20 20:03:52.222793
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance

    # This collector is not enabled on BSD family
    if BaseFactCollector.platform.startswith('BSD'):
        return

    # Return of method collect is a dict
    assert isinstance(get_collector_instance('SshPubKeyFactCollector').collect(), dict)

    # Return dict has a list named 'ssh_host_pub_keys'
    assert isinstance(get_collector_instance('SshPubKeyFactCollector').collect().get('ssh_host_pub_keys'), list)

    # Return dict has a dict key named 'ssh_host_key_rsa_public'

# Generated at 2022-06-20 20:03:58.099219
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    keys = SshPubKeyFactCollector()
    assert keys.name == 'ssh_pub_keys', 'should be "ssh_pub_keys"'
    assert keys._fact_ids == set(['ssh_host_pub_keys',
                                  'ssh_host_key_dsa_public',
                                  'ssh_host_key_rsa_public',
                                  'ssh_host_key_ecdsa_public',
                                  'ssh_host_key_ed25519_public']), 'should be set of set of facts'

# Generated at 2022-06-20 20:04:10.570929
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:04:13.914904
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    collected_facts = collector.collect()
    assert(len(collected_facts['ssh_host_key_ecdsa_public'] > 0))

# Generated at 2022-06-20 20:04:18.291204
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    assert ssh_pub_key_facts['ssh_host_key_rsa_public'].startswith('AAAA')
    assert ssh_pub_key_facts['ssh_host_key_rsa_public_keytype'].startswith('ssh')

# Generated at 2022-06-20 20:04:26.022082
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """
    Unit test for constructor of class SshPubKeyFactCollector
    """
    obj = SshPubKeyFactCollector()
    assert obj.name == "ssh_pub_keys"
    assert obj._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])
    assert obj.collect() == {}


# Generated at 2022-06-20 20:04:34.815995
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_facts_dict = {
        'ssh_host_key_ed25519_public': 'AAAAC3NzaC1lZDI1NTE5AAAAIEvf9XJEoLrzrKwW8mvQo+n24tK1mAVc5vu5gpt2Xic5Zz'
    }  # for ed25519 key
    SshPubKeyFactCollector._search_paths = ['./tests/unit/module_utils/facts/']
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.collect() == test_facts_dict

# Generated at 2022-06-20 20:04:43.637300
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """
    Unit tests for constructor of class SshPubKeyFactCollector
    """
    def printer(*args):
        print(args)

    # Constructor SshPubKeyFactCollector()
    assert SshPubKeyFactCollector is not None

    # testing the name attribute of class SshPubKeyFactCollector
    result = SshPubKeyFactCollector().name
    assert result == 'ssh_pub_keys'

    # testing the _fact_ids attribute of class SshPubKeyFactCollector
    result = SshPubKeyFactCollector()._fact_ids
    assert isinstance(result, set)

    # testing the collect() method of class SshPubKeyFactCollector
    SshPubKeyFactCollector().collect(
        module=None, collected_facts=None)

    # testing the print() method of class SshPub

# Generated at 2022-06-20 20:04:51.055784
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    resp = SshPubKeyFactCollector()
    assert isinstance(resp, SshPubKeyFactCollector)
    assert resp.name == 'ssh_pub_keys'
    assert resp._fact_ids == set(['ssh_host_pub_keys',
                                  'ssh_host_key_dsa_public',
                                  'ssh_host_key_rsa_public',
                                  'ssh_host_key_ecdsa_public',
                                  'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:04:57.133326
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # Create mock module object
    mock_module = type('AnsibleModule')
    instance = mock_module()
    instance.params = {}

    # Case when file '/etc/ssh/ssh_host_rsa_key.pub' exists
    keydata = 'ssh-rsa EAITk0jkajsdfhjklhasdfhkljhioasdfouioasdkhfljhkh9087asdfkjasdkfhasdflkjahsdflkjahsdflkajsdifoauaisfhasdlfkhlaskjdfh' 
    instance.get_file_content = type('get_file_content', (object,), {'__call__': lambda self, x: keydata if x == '/etc/ssh/ssh_host_rsa_key.pub' else None})()

    # Execute

# Generated at 2022-06-20 20:05:13.007023
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SSH_PUB_KEY_FACTS = ('ssh_host_key_dsa_public',
                         'ssh_host_key_rsa_public',
                         'ssh_host_key_ecdsa_public',
                         'ssh_host_key_ed25519_public')


# Generated at 2022-06-20 20:05:19.833455
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:05:24.664968
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    collected_facts = collector.collect()

    assert 'ssh_host_key_rsa_public' in collected_facts
    assert 'ssh_host_key_rsa_public_keytype' in collected_facts

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-20 20:05:33.112660
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    assert 'ssh_host_pub_keys' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_fact_collector._fact_ids

# Generated at 2022-06-20 20:05:43.772122
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import collector
    ssh_pub_key_collector = SshPubKeyFactCollector()
    collector.add_collector(ssh_pub_key_collector)
    collected_facts = collector.collect(None)

    assert(collected_facts is not None)

    # Verify each of the keys that we have are the right key type and aren't empty
    keys = ( 'ssh_host_key_dsa_public',
             'ssh_host_key_rsa_public',
             'ssh_host_key_ecdsa_public',
             'ssh_host_key_ed25519_public')
    for key in keys:
        assert(key in collected_facts)
        assert(not collected_facts[key] == '')
        keytype_key = key + '_keytype'

# Generated at 2022-06-20 20:05:53.224698
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # create a class instance
    ssh_pub_key_collector = SshPubKeyFactCollector()
    # call its collect method
    ssh_pub_key_facts = ssh_pub_key_collector.collect()
    # assert that the result is a dictionary
    assert type(ssh_pub_key_facts) == dict
    # assert that the result has the correct key

# Generated at 2022-06-20 20:05:55.041073
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:06:00.161242
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_collector._fact_ids == set(['ssh_host_pub_keys',
                                                   'ssh_host_key_dsa_public',
                                                   'ssh_host_key_rsa_public',
                                                   'ssh_host_key_ecdsa_public',
                                                   'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:06:10.037963
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import shutil
    import tempfile
    import textwrap

    input_lines = [b"type_dsa_key_here key_dsa_key_here",
                   b"type_rsa_key_here key_rsa_key_here",
                   b"type_ecdsa_key_here key_ecdsa_key_here"]
    (fd, keydir) = tempfile.mkstemp()
    os.mkdir(keydir)

# Generated at 2022-06-20 20:06:15.726756
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:06:33.707172
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts_module = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_facts_module.collect()

    # confirm that each key exists and has an associated keytype
    assert ssh_pub_key_facts.get('ssh_host_key_dsa_public')
    assert ssh_pub_key_facts.get('ssh_host_key_dsa_public_keytype')
    assert ssh_pub_key_facts.get('ssh_host_key_rsa_public')
    assert ssh_pub_key_facts.get('ssh_host_key_rsa_public_keytype')
    assert ssh_pub_key_facts.get('ssh_host_key_ecdsa_public')

# Generated at 2022-06-20 20:06:41.310617
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    expected_result = {'ssh_host_key_dsa_public': 'ssh-dss',
                       'ssh_host_key_dsa_public_keytype': 'AAAA'}
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    keydata = "\nssh-dss AAAA"
    with patch("ansible.module_utils.facts.collector.get_file_content", return_value=keydata):
        result = ssh_pub_key_fact_collector.collect(collected_facts={'distribution_major_version': '7'})
    assert expected_result == result

# Generated at 2022-06-20 20:06:42.444279
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = None
    SshPubKeyFactCollector.collect(module, collected_facts)

# Generated at 2022-06-20 20:06:50.016592
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector().name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector()._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:06:59.245799
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # setup test
    _managed_file_content = {}
    def fake_get_file_content(filename):
        return _managed_file_content.get(filename)

    # make methods we're going to override
    collector = SshPubKeyFactCollector()
    collector.get_file_content = fake_get_file_content
    collected_facts = {}

    # test with nothing
    test_facts = collector.collect(None, collected_facts)
    assert test_facts == {}

    # test with one file
    _managed_file_content['/etc/ssh/ssh_host_dsa_key.pub'] = 'something'
    test_facts = collector.collect(None, collected_facts)

# Generated at 2022-06-20 20:07:06.673374
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshpubkey = SshPubKeyFactCollector()
    assert sshpubkey.name == 'ssh_pub_keys'
    assert sshpubkey._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:07:16.847300
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import sys
    import json
    import os
    import collections
    import shutil

    ssh_key_files = {
        'dsa': 'ssh_host_dsa_key.pub',
        'rsa': 'ssh_host_rsa_key.pub',
        'ecdsa': 'ssh_host_ecdsa_key.pub',
        'ed25519': 'ssh_host_ed25519_key.pub',
    }


# Generated at 2022-06-20 20:07:27.687440
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Get correct ssh key
    collector = SshPubKeyFactCollector({'ssh_pub_key_files': ['/etc/ssh/ssh_host_rsa_key.pub']}, None)
    fact = collector.collect()

# Generated at 2022-06-20 20:07:38.477664
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:07:47.461023
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    test_facts = dict()
    test_facts['ssh_host_rsa_key'] = base64.b64encode(os.urandom(8))
    test_facts['ssh_host_dsa_key'] = base64.b64encode(os.urandom(8))
    test_facts['ssh_host_ecdsa_key'] = base64.b64encode(os.urandom(8))
    test_facts['ssh_host_ed25519_key'] = base64.b64encode(os.urandom(8))
    fact_collector = SshPubKeyFactCollector(module=None, facts=test_facts)
    assert isinstance(fact_collector._fact_ids, set)

# Generated at 2022-06-20 20:08:07.265221
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_collector._fact_ids.__len__() == 5

# Generated at 2022-06-20 20:08:12.860995
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
  c = SshPubKeyFactCollector()
  assert c.name == 'ssh_pub_keys'
  assert c._fact_ids == set(['ssh_host_pub_keys',
  'ssh_host_key_dsa_public','ssh_host_key_rsa_public','ssh_host_key_ecdsa_public',
  'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:08:17.128651
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_collector._fact_ids == set(['ssh_host_pub_keys',
                                                   'ssh_host_key_dsa_public',
                                                   'ssh_host_key_rsa_public',
                                                   'ssh_host_key_ecdsa_public',
                                                   'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:08:19.325454
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # constructor test
    x = SshPubKeyFactCollector()
    assert x
    assert x.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:08:24.971331
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])
    assert obj._platform == 'Generic'
    assert obj.collect() == {}

# Generated at 2022-06-20 20:08:30.541344
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector = SshPubKeyFactCollector()
    #In the test, we assume that all the files for testing exist
    assert fact_collector.name == 'ssh_pub_keys'
    assert 'ssh_host_pub_keys' in fact_collector._fact_ids
    assert 'ssh_host_key_dsa_public' in fact_collector._fact_ids
    assert 'ssh_host_key_rsa_public' in fact_collector._fact_ids
    assert 'ssh_host_key_ecdsa_public' in fact_collector._fact_ids
    assert 'ssh_host_key_ed25519_public' in fact_collector._fact_ids
    assert fact_collector is not None


# Generated at 2022-06-20 20:08:39.200668
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == {'ssh_host_key_rsa_public_keytype', 'ssh_host_key_ed25519_public_keytype', 'ssh_host_pub_keys', 'ssh_host_key_dsa_public_keytype', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public_keytype', 'ssh_host_key_ecdsa_public', 'ssh_host_key_dsa_public', 'ssh_host_key_ed25519_public'}

# Generated at 2022-06-20 20:08:50.861313
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact = SshPubKeyFactCollector()
    # test name
    assert ssh_pub_key_fact.name == 'ssh_pub_keys'
    # test _fact_ids
    assert 'ssh_host_pub_keys' in ssh_pub_key_fact._fact_ids
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_fact._fact_ids
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_fact._fact_ids
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_fact._fact_ids
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_fact._fact_ids
    # test collect()
    assert ssh_pub_key_

# Generated at 2022-06-20 20:08:56.150120
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == "ssh_pub_keys"
    assert obj._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])
    assert obj.collect() == {}

# Generated at 2022-06-20 20:08:57.958444
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    c = SshPubKeyFactCollector()
    assert isinstance(c.collect(), dict)

# Generated at 2022-06-20 20:09:39.775858
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = 'test'

# Generated at 2022-06-20 20:09:48.368810
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector(None)

    # test fact_ids property

# Generated at 2022-06-20 20:09:55.734513
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()

    assert len(ssh_pub_key_facts) == len(algos)
    for algo in algos:
        factname = 'ssh_host_key_%s_public' % algo
        assert factname in ssh_pub_key_facts and factname + '_keytype' in ssh_pub_key_facts

# Generated at 2022-06-20 20:10:05.495000
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    response = ssh_pub_key_facts.collect()

# Generated at 2022-06-20 20:10:13.812296
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Mock the class SshPubKeyFactCollector
    class MockSshPubKeyFactCollector(SshPubKeyFactCollector):
        def __init__(self):
            self.secretstring = ''

# Generated at 2022-06-20 20:10:22.383436
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector_object = SshPubKeyFactCollector()
    assert fact_collector_object.name == 'ssh_pub_keys'
    assert fact_collector_object._fact_ids == set(['ssh_host_pub_keys',
                                                   'ssh_host_key_dsa_public',
                                                   'ssh_host_key_rsa_public',
                                                   'ssh_host_key_ecdsa_public',
                                                   'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:10:30.752772
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts._fact_ids == set(['ssh_host_pub_keys',
                                               'ssh_host_key_dsa_public',
                                               'ssh_host_key_rsa_public',
                                               'ssh_host_key_ecdsa_public',
                                               'ssh_host_key_ed25519_public'])
    assert callable(ssh_pub_key_facts.collect)

# Generated at 2022-06-20 20:10:39.446367
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None

    # test with no keys
    fake_file_data = {
    }
    fake_file_detection = {
    }
    files = FakeFiles(fake_file_data, fake_file_detection)
    collector = SshPubKeyFactCollector(module, files)
    facts = collector.collect()
    assert facts == {
    }

    # test with dsa key
    fake_file_data = {
        '/etc/ssh/ssh_host_dsa_key.pub': 'ssh-dss AAAAB3NzaC1kc3MAAACBAJYBdG4K4Zlxm1gBw2OmW5H5rFEUiy+'
    }

# Generated at 2022-06-20 20:10:43.434973
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshpubkey = SshPubKeyFactCollector()
    assert sshpubkey.name == "ssh_pub_keys"
    assert sshpubkey._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])
    return 0

# Generated at 2022-06-20 20:10:50.572710
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.ssh_pub_keys import SshPubKeyFactCollector

    Collector.collectors['ansible.ssh_pub_keys'] = SshPubKeyFactCollector()
    collected_facts = Collector.collector_object('ansible.ssh_pub_keys').collect()
    assert {'ssh_host_key_rsa_public',
            'ssh_host_key_ed25519_public',
            'ssh_host_key_ecdsa_public',
            'ssh_host_key_dsa_public'}.issubset(collected_facts)

# Generated at 2022-06-20 20:11:35.155395
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector = SshPubKeyFactCollector()
    assert fact_collector.name == 'ssh_pub_keys'
    assert fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                            'ssh_host_key_dsa_public',
                                            'ssh_host_key_rsa_public',
                                            'ssh_host_key_ecdsa_public',
                                            'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:11:38.109864
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.__class__.__name__ == 'SshPubKeyFactCollector'

# Generated at 2022-06-20 20:11:40.523564
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()

    assert ssh_pub_key_collector.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:11:46.701810
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector
    fact_data = {}
    collected_facts = {}
    returned_facts = collector.collect(fact_data, collected_facts)
    fact_data['ssh_host_key_dsa_public'] = 'dsa 12345'
    fact_data['ssh_host_key_dsa_public_keytype'] = 'ssh-dsa'
    assert returned_facts == fact_data

# Generated at 2022-06-20 20:11:48.917962
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector.priority == 50

# Generated at 2022-06-20 20:11:56.286764
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = Mock()
    collected_facts = {}

    my_SshPubKeyFactCollector = SshPubKeyFactCollector()
    results = my_SshPubKeyFactCollector.collect(module, collected_facts)

    assert results
    assert 'ssh_host_key_dsa_public' in results
    assert 'ssh_host_key_dsa_public_keytype' in results
    assert 'ssh_host_key_rsa_public' in results
    assert 'ssh_host_key_rsa_public_keytype' in results
    assert 'ssh_host_key_ecdsa_public' in results
    assert 'ssh_host_key_ecdsa_public_keytype' in results
    assert 'ssh_host_key_ed25519_public' in results

# Generated at 2022-06-20 20:11:59.926328
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshpubkey = SshPubKeyFactCollector()
    assert sshpubkey.name == 'ssh_pub_keys'
    assert sshpubkey._fact_ids == {'ssh_host_pub_keys',
                                   'ssh_host_key_dsa_public',
                                   'ssh_host_key_rsa_public',
                                   'ssh_host_key_ecdsa_public',
                                   'ssh_host_key_ed25519_public'}

if __name__ == '__main__':
    test_SshPubKeyFactCollector()

# Generated at 2022-06-20 20:12:09.505001
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes

    c = SshPubKeyFactCollector()

    filenames = ['/etc/ssh/ssh_host_dsa_key.pub',
                 '/etc/ssh/ssh_host_rsa_key.pub',
                 '/etc/ssh/ssh_host_ecdsa_key.pub',
                 '/etc/ssh/ssh_host_ed25519_key.pub']

    # test with empty files, we should get empty values
    for filename in filenames:
        get_file_content.cache_clear()
        get_file_content.cache[filename] = None
    testval = c.collect()
   

# Generated at 2022-06-20 20:12:11.655284
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert isinstance(SshPubKeyFactCollector(), SshPubKeyFactCollector)

# Generated at 2022-06-20 20:12:18.462411
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c = SshPubKeyFactCollector()
    assert c.name == 'ssh_pub_keys'
    assert c.priority == 20

    # test _fact_ids is read-only
    try:
        c._fact_ids.add('test')
        assert False, '_fact_ids should be read-only'
    except AttributeError:
        pass
    assert len(c._fact_ids) == 5
    assert 'ssh_host_pub_keys' in c._fact_ids
    assert 'ssh_host_key_dsa_public' in c._fact_ids
    assert 'ssh_host_key_rsa_public' in c._fact_ids
    assert 'ssh_host_key_ecdsa_public' in c._fact_ids

# Generated at 2022-06-20 20:13:44.480858
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])