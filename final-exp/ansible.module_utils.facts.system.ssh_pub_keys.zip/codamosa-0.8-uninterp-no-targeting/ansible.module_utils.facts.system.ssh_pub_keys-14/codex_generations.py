

# Generated at 2022-06-20 20:03:53.655102
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    test_class = SshPubKeyFactCollector()
    assert test_class.name == 'ssh_pub_keys'
    assert test_class._fact_ids == {'ssh_host_pub_keys',
                                    'ssh_host_key_dsa_public',
                                    'ssh_host_key_rsa_public',
                                    'ssh_host_key_ecdsa_public',
                                    'ssh_host_key_ed25519_public'}

    assert test_class.collect() == {}

# Generated at 2022-06-20 20:03:56.118310
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector('collector')
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'


# Generated at 2022-06-20 20:04:00.935550
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    # name , and _fact_ids are defined in BaseFactCollector class
    assert obj.name == "ssh_pub_keys"
    assert obj._fact_ids == {'ssh_host_pub_keys',
                             'ssh_host_key_dsa_public',
                             'ssh_host_key_rsa_public',
                             'ssh_host_key_ecdsa_public',
                             'ssh_host_key_ed25519_public'}

# Generated at 2022-06-20 20:04:09.794991
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """unit test for class SshPubKeyFactCollector"""
    sshPubKeyCollector = SshPubKeyFactCollector()
    assert sshPubKeyCollector.name == 'ssh_pub_keys'
    assert sshPubKeyCollector._fact_ids == set(['ssh_host_pub_keys',
                                                'ssh_host_key_dsa_public',
                                                'ssh_host_key_rsa_public',
                                                'ssh_host_key_ecdsa_public',
                                                'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:04:20.103113
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    mod_args = { "paths": ["/etc/ssh", "/etc/openssh", "/etc"],
                 "key_algos": ["dsa", "rsa", "ecdsa", "ed25519"] }

    # This test will work with the default version of module_utils/facts/utils.py
    # It will fail if you try to mock/stub get_file_content to return a value for
    # any file, though.

    # Manually create and initialize a SshPubKeyFactCollector object
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector._module = object()
    ssh_pub_key_fact_collector._module.params = mod_args

    # create an empty dictionary to store facts in
    collected_facts = {}



# Generated at 2022-06-20 20:04:27.765003
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = {'ssh_host_key_rsa_public': 'test1',
                       'ssh_host_key_dsa_public': 'test2',
                       'ssh_host_key_ecdsa_public': 'test3',
                       'ssh_host_key_ed25519_public': 'test4'}
    # Use the existing collector method to collect ssh data.
    ssh_pub_key_facts = SshPubKeyFactCollector().collect(module, collected_facts)
    # Verify that the collected data matched the data from the file
    assert ssh_pub_key_facts == collected_facts

# Generated at 2022-06-20 20:04:35.106142
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Set up mocks for all the external methods used by this method.
    # Call real methods for any methods not mocked here.
    tmp_SshPubKeyFactCollector = SshPubKeyFactCollector()
    #Mock get_file_content method
    tmp_SshPubKeyFactCollector.get_file_content = Mock(return_value='ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIC3qxOus+OFkBjK1R9YtfHtG+fMhyKMNEg8oSYPnGwBGid')
    # Call the method under test.

# Generated at 2022-06-20 20:04:40.990847
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sf = SshPubKeyFactCollector()
    assert sf.name == 'ssh_pub_keys'
    assert sf._fact_ids == set(['ssh_host_pub_keys',
                                'ssh_host_key_dsa_public',
                                'ssh_host_key_rsa_public',
                                'ssh_host_key_ecdsa_public',
                                'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:04:42.804115
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
  f = SshPubKeyFactCollector()
  assert f.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:04:45.698873
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collect = SshPubKeyFactCollector()
    assert collect.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:04:56.163243
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'
    assert 'ssh_host_key_dsa_public' in collector._fact_ids
    assert 'ssh_host_key_rsa_public' in collector._fact_ids
    assert 'ssh_host_key_ecdsa_public' in collector._fact_ids
    assert 'ssh_host_key_ed25519_public' in collector._fact_ids

# Generated at 2022-06-20 20:05:03.294868
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
   sshFactCollector = SshPubKeyFactCollector()
   assert sshFactCollector.name == 'ssh_pub_keys'
   assert sshFactCollector._fact_ids == \
       set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public',
            'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public',
            'ssh_host_key_ed25519_public'])
   assert sshFactCollector.collect() == {}


# Generated at 2022-06-20 20:05:05.059460
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:05:06.536408
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = Ssh_PubKey_FactCollector()
    collector.collect()

# Generated at 2022-06-20 20:05:14.230807
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    test = SshPubKeyFactCollector()
    assert test.name == 'ssh_pub_keys'
    assert test._fact_ids == set(['ssh_host_pub_keys',
                                  'ssh_host_key_dsa_public',
                                  'ssh_host_key_rsa_public',
                                  'ssh_host_key_ecdsa_public',
                                  'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:05:25.304577
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # method collect of class SshPubKeyFactCollector returns a dictionary
    # named ssh_pub_key_facts
    # If a file in keydirs contains data, the list is added to this dictionary
    # with the filename as key and its data as value
    # If a file doesn't contain data, it's not added
    # If a file doesn't exist, it's ignored
    from ansible.module_utils.facts.collectors.ssh_pub_keys import SshPubKeyFactCollector
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    mock_module = ''
    mock_collected_facts = ''
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect(mock_module, mock_collected_facts)
    # Files doesn't contain data, dictionary

# Generated at 2022-06-20 20:05:31.959957
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:05:43.015381
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    file_facts_dict = {}
    file_facts_dict['file_exists'] = {}

    # Prepare file content

# Generated at 2022-06-20 20:05:53.224460
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import unittest
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCollector, SshPubKeyFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import ansible.module_utils.facts.collector
    import tempfile
    import os

    class TestSshPubKeyFactCollector(unittest.TestCase):

        def setUp(self):
            self.__collector = SshPubKeyFactCollector()
            self.__tmpdir = tempfile.mkdtemp()
            self.__keydirs = [self.__tmpdir + '/etc/ssh',
                              self.__tmpdir + '/etc/openssh']
            for keydir in self.__keydirs:
                os.maked

# Generated at 2022-06-20 20:06:00.270746
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector = SshPubKeyFactCollector()
    fact_collector.collect()
    expected_keys = ['ssh_host_key_dsa_public', 'ssh_host_key_dsa_public_keytype',
                     'ssh_host_key_rsa_public', 'ssh_host_key_rsa_public_keytype',
                     'ssh_host_key_ecdsa_public', 'ssh_host_key_ecdsa_public_keytype',
                     'ssh_host_key_ed25519_public', 'ssh_host_key_ed25519_public_keytype']

    for key in expected_keys:
        assert key in fact_collector.collected_facts

# Generated at 2022-06-20 20:06:10.070819
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fc = SshPubKeyFactCollector()

    assert fc.name == "ssh_pub_keys"
    assert fc._fact_ids == set(['ssh_host_pub_keys',
                                'ssh_host_key_dsa_public',
                                'ssh_host_key_rsa_public',
                                'ssh_host_key_ecdsa_public',
                                'ssh_host_key_ed25519_public'])

    assert fc.collect() == {}

# Generated at 2022-06-20 20:06:16.558292
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts.priority == 50
    # Test the set of _fact_ids is the same as the keys of the
    # ssh_pub_keys dictionary
    ssh_pub_keys = ssh_pub_key_facts.collect()
    assert ssh_pub_key_facts._fact_ids == set(ssh_pub_keys.keys())

# Generated at 2022-06-20 20:06:21.991719
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])
    assert ssh_pub_key_fact_collector.can_run == (0, None)

# Generated at 2022-06-20 20:06:32.781110
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class MockModule:
        def get_bin_path(self, arg):
            pass

    sshd_config = '''\
#HostKey /etc/ssh/ssh_host_key
#HostDSASignature /usr/bin/ssh-dss
#HostRSASignature /usr/bin/ssh-rsa
'''

    class MockFile:
        def __init__(self, content):
            self.content = content
            self.seek_val = 0

        def read(self):
            return self.content

        def seek(self, index):
            self.seek_val = index

        def writelines(self, *args, **kwargs):
            pass

    class MockFacts:
        def __init__(self):
            self.ssh_config = MockFile(sshd_config)

    mockModule = Mock

# Generated at 2022-06-20 20:06:38.358274
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact = SshPubKeyFactCollector()
    assert fact.name == 'ssh_pub_keys'
    assert fact._fact_ids == set(['ssh_host_pub_keys',
                                  'ssh_host_key_dsa_public',
                                  'ssh_host_key_rsa_public',
                                  'ssh_host_key_ecdsa_public',
                                  'ssh_host_key_ed25519_public'])
    assert fact._platform == 'Generic'

# Generated at 2022-06-20 20:06:46.447570
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Test that the right class is being used
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector.__name__ == 'SshPubKeyFactCollector'
    assert SshPubKeyFactCollector.__doc__ == 'Collects data from ssh keys'
    assert SshPubKeyFactCollector.ephemeral_facts == set()
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])

# This test is to see on what

# Generated at 2022-06-20 20:06:56.930236
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    testobj = SshPubKeyFactCollector()
    ssh_pub_key_facts = testobj.collect()
    assert ssh_pub_key_facts is not None, "ssh_pub_key_facts is not defined"
    assert ssh_pub_key_facts['ssh_host_key_rsa_public'] is not None, "ssh_host_key_rsa_public is not defined"
    assert ssh_pub_key_facts['ssh_host_key_rsa_public_keytype'] is not None, "ssh_host_key_rsa_public_keytype is not defined"
    assert ssh_pub_key_facts['ssh_host_key_dsa_public'] is not None, "ssh_host_key_dsa_public is not defined"

# Generated at 2022-06-20 20:07:02.297369
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == {
        'ssh_host_key_ed25519_public',
        'ssh_host_key_rsa_public',
        'ssh_host_pub_keys',
        'ssh_host_key_dsa_public',
        'ssh_host_key_ecdsa_public'
    }

# vim: set expandtab ts=4 sw=4 et:

# Generated at 2022-06-20 20:07:08.786937
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test = SshPubKeyFactCollector()
    result = test.collect()

# Generated at 2022-06-20 20:07:19.709011
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os, shutil
    from tempfile import mkdtemp

    fake_path = os.path.join(mkdtemp(), 'ssh')
    os.makedirs(fake_path)
    os.mkdir(os.path.join(fake_path, 'openssh'))
    os.mkdir(os.path.join(fake_path, 'openssh', 'tmp'))


# Generated at 2022-06-20 20:07:38.806825
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    import shutil
    class Module:
        pass


# Generated at 2022-06-20 20:07:46.149647
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Test default SSH path(/etc/ssh)
    SshPubKeyFactCollector = SshPubKeyFactCollector()
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:07:47.413343
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert isinstance(SshPubKeyFactCollector(), SshPubKeyFactCollector)

# Generated at 2022-06-20 20:07:59.568570
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.utils import mock_module_params
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Create an instance of the SshPubKeyFactCollector class
    test_object = SshPubKeyFactCollector()

    # Check the properties of the instance
    assert test_object.name == 'ssh_pub_keys'
    assert test_object._fact_ids == set(['ssh_host_pub_keys',
                                         'ssh_host_key_dsa_public',
                                         'ssh_host_key_rsa_public',
                                         'ssh_host_key_ecdsa_public',
                                         'ssh_host_key_ed25519_public'])

    # Check the properties of the instance

# Generated at 2022-06-20 20:08:11.045012
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    import stat

    def create_temp_file(data):
        fd, path = tempfile.mkstemp()
        os.write(fd, data)
        os.close(fd)
        return path

    def remove_file(path):
        os.unlink(path)

    module = None
    collected_facts = None


# Generated at 2022-06-20 20:08:17.850074
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    # Make sure we got some facts
    assert ssh_pub_key_facts

    # Make sure that 'ssh_host_pub_keys' is a list
    assert isinstance(ssh_pub_key_facts['ssh_host_pub_keys'], list)

    # Make sure that all the pub keys are in 'ssh_host_pub_keys'
    for key in ssh_pub_key_facts['ssh_host_pub_keys']:
        assert key in ssh_pub_key_facts

    # Make sure that all keys are in 'ssh_host_pub_keys'
    for algo in ('dsa', 'rsa', 'ecdsa', 'ed25519'):
        factname = 'ssh_host_key_%s_public' % al

# Generated at 2022-06-20 20:08:24.759315
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    sshpubkey_fc = SshPubKeyFactCollector()
    facts_dict = sshpubkey_fc.collect()
    assert 'ssh_host_key_ecdsa_public' in facts_dict
    assert 'ssh_host_key_ecdsa_public_keytype' in facts_dict
    assert 'ssh_host_key_ed25519_public' in facts_dict
    assert 'ssh_host_key_ed25519_public_keytype' in facts_dict
    assert 'ssh_host_key_rsa_public' in facts_dict
    assert 'ssh_host_key_rsa_public_keytype' in facts_dict

# Generated at 2022-06-20 20:08:30.373593
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # In this test, we check that the constructor for the class
    # SshPubKeyFactCollector has properly assigned the following
    # instance variables:
    #
    #    name (string)
    #    fact_ids (list of strings)
    #    collect (function)
    #
    # The constructor is not tested here for the following reason:
    #
    #    BaseFactCollector() is an abstract class and its constructor
    #    should not be called directly.  Therefore, it is not possible
    #    to instantiate an object of this class in order to get the
    #    constructor to run.

    # Initialize an instance of SshPubKeyFactCollector
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # Test that ssh_pub_key_fact_collector.name is a

# Generated at 2022-06-20 20:08:38.062974
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts._fact_ids == set(['ssh_host_pub_keys',
                                               'ssh_host_key_dsa_public',
                                               'ssh_host_key_rsa_public',
                                               'ssh_host_key_ecdsa_public',
                                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:08:40.499023
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_file = '/etc/ssh/ssh_host_rsa_key.pub'
    fact_collector = SshPubKeyFactCollector(fact_file)
    fact_collector.collect()


# Generated at 2022-06-20 20:08:58.085318
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-20 20:09:07.872917
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content
    ssh_key_dir='/tmp/test/ssh_pub_keys/'
    import os
    if not os.path.isdir(ssh_key_dir):
        os.makedirs(ssh_key_dir)
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    for algo in algos:
        #create public keys file
        key_filename = '%s/ssh_host_%s_key.pub' % (ssh_key_dir, algo)

# Generated at 2022-06-20 20:09:19.060685
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class MockModule:
        def __init__(self):
            self.params = {}
        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return executable

    import os
    import tempfile
    import shutil
    tmpdir = tempfile.mkdtemp()
    dsa_key_path = os.path.join(tmpdir, "ssh_host_dsa_key.pub")
    rsa_key_path = os.path.join(tmpdir, "ssh_host_rsa_key.pub")
    ecdsa_key_path = os.path.join(tmpdir, "ssh_host_ecdsa_key.pub")
    ed25519_key_path = os.path.join(tmpdir, "ssh_host_ed25519_key.pub")

# Generated at 2022-06-20 20:09:26.113753
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fake_module = None
    fake_facts = None
    collector = SshPubKeyFactCollector()
    # First, collect returns None if key directories do not exist.
    assert collector.collect(fake_module, fake_facts) is None

    # Then, collect returns SSH facts if key directories exist.
    # We use os.makedirs method to build path to use in tests.
    import os
    os.makedirs('/etc/ssh')
    os.makedirs('/etc/openssh')
    os.makedirs('/etc')
    # We create keys as empty files.
    open('/etc/ssh/ssh_host_dsa_key.pub', 'a').close()
    open('/etc/ssh/ssh_host_rsa_key.pub', 'a').close()

# Generated at 2022-06-20 20:09:37.377019
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # TODO: move to a central location
    class _Module(object):
        def __init__(self):
            self._ansible_facts = {}

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            return '/usr/bin/' + arg

    # TODO: move to a central location
    class _System(object):
        def __init__(self):
            self.distribution = None
            self.distribution_version = None
            self.distribution_release = None
            self.distribution_major_version = None
            self.python_version = None
            self.python_version_tuple = None
            self.system = None
            self.machine = None
            self.kernel = None
            self.architecture = None

# Generated at 2022-06-20 20:09:47.282325
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    keydir = '/etc/ansible'
    path = '/etc/ansible/ssh_host_dsa_key.pub'

# Generated at 2022-06-20 20:09:53.894144
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKeyFactCollect = SshPubKeyFactCollector()
    assert sshPubKeyFactCollect.name == 'ssh_pub_keys'
    assert sshPubKeyFactCollect._fact_ids == set(['ssh_host_pub_keys',
                                                  'ssh_host_key_dsa_public',
                                                  'ssh_host_key_rsa_public',
                                                  'ssh_host_key_ecdsa_public',
                                                  'ssh_host_key_ed25519_public'])



# Generated at 2022-06-20 20:09:59.605887
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    spkfc = SshPubKeyFactCollector()
    assert spkfc.name == 'ssh_pub_keys'
    assert spkfc._fact_ids == set(['ssh_host_pub_keys',
                                   'ssh_host_key_dsa_public',
                                   'ssh_host_key_rsa_public',
                                   'ssh_host_key_ecdsa_public',
                                   'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:10:07.368135
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x is not None
    assert x.name == 'ssh_pub_keys'
    assert len(x._fact_ids) == 5
    assert 'ssh_host_pub_keys' in x._fact_ids
    assert 'ssh_host_key_dsa_public' in x._fact_ids
    assert 'ssh_host_key_rsa_public' in x._fact_ids
    assert 'ssh_host_key_ecdsa_public' in x._fact_ids
    assert 'ssh_host_key_ed25519_public' in x._fact_ids

# Generated at 2022-06-20 20:10:09.920775
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector_obj = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector_obj.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:10:58.511156
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    #
    # AnsibleModule argument spec, in the format expected by AnsibleModule
    #
    TEST_ARG_SPEC = dict()

    #
    # Module parameters, in the format expected by AnsbileModule
    #
    TEST_PARAMS = dict()

    #
    # Facts to be returned
    #
    TEST_FACTS = dict()

    TEST_COLLECTED_FACTS = dict()

    #
    # Expected results, in the format expected by the AnsibleModule
    #
    TEST_RETURN = dict(
        changed=False,
        ansible_facts=TEST_FACTS
    )

    from ansible.module_utils.facts import ssh_pub_key_facts

# Generated at 2022-06-20 20:11:00.431109
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:11:12.449343
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    builtins.open = None

    module = AnsibleModule(
        argument_spec=dict(
        ),
        supports_check_mode=True
    )


# Generated at 2022-06-20 20:11:15.363551
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """Unit test for constructor of class SshPubKeyFactCollector"""
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:11:21.541949
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:11:27.570694
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert set(ssh_pub_key_fact_collector.__dict__) == set(['name', '_fact_ids'])
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                                        'ssh_host_key_dsa_public',
                                                        'ssh_host_key_rsa_public',
                                                        'ssh_host_key_ecdsa_public',
                                                        'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:11:30.752905
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    result = collector.collect()
    assert result['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa'
    assert len(result) == 8
    assert 'ssh_host_key_ecdsa_public' in result

# Generated at 2022-06-20 20:11:34.608495
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public',
                                               'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])

# vim: set expandtab ts=4 sw=4 ai

# Generated at 2022-06-20 20:11:43.252796
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    results = collector.collect()

    assert isinstance(results, dict)
    assert 'ssh_host_key_dsa_public' in results
    assert 'ssh_host_key_dsa_public_keytype' in results
    assert 'ssh_host_key_rsa_public' in results
    assert 'ssh_host_key_rsa_public_keytype' in results
    assert 'ssh_host_key_ecdsa_public' in results
    assert 'ssh_host_key_ecdsa_public_keytype' in results
    assert 'ssh_host_key_ed25519_public' in results
    assert 'ssh_host_key_ed25519_public_keytype' in results

# Generated at 2022-06-20 20:11:49.789144
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys', 
                                                    'ssh_host_key_dsa_public', 
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:13:17.244008
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    keypaths = { 'ssh_host_key_dsa_public': '/etc/ssh/ssh_host_dsa_key.pub',
                 'ssh_host_key_rsa_public': '/etc/ssh/ssh_host_rsa_key.pub',
                 'ssh_host_key_ecdsa_public': '/etc/ssh/ssh_host_ecdsa_key.pub',
                 'ssh_host_key_ed25519_public': '/etc/ssh/ssh_host_ed25519_key.pub'
               }
    # create testing environment
    import os
    import random
    import sys
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector

    # save original environment
    orig_env = dict(os.environ)
    # set up temporary direct

# Generated at 2022-06-20 20:13:20.863976
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    ansible_facts = collector.collect(None, None)

    assert ansible_facts is not None
    assert 'ssh_host_key_dsa_public' in ansible_facts
    assert ansible_facts['ssh_host_key_dsa_public']

# Generated at 2022-06-20 20:13:22.955248
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pub_key_facts = SshPubKeyFactCollector().collect()
    assert pub_key_facts['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa'

# Generated at 2022-06-20 20:13:27.382082
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    s=SshPubKeyFactCollector()
    assert "SshPubKeyFactCollector" == s.name
    assert s._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:13:34.061880
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import ansible.module_utils.facts.system.ssh_pub_keys
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector

    ansible.module_utils.facts.system.ssh_pub_keys.get_file_content = get_file_content
    ansible.module_utils.facts.system.ssh_pub_keys.BaseFactCollector = BaseFactCollector

    collector = ansible.module_utils.facts.system.ssh_pub_keys.SshPubKeyFactCollector()
    facts = collector.collect()
    assert facts is not None
    assert 'ssh_host_key_dsa_public' in facts
    assert 'ssh_host_key_ecdsa_public' in facts

# Generated at 2022-06-20 20:13:35.479479
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert issubclass(SshPubKeyFactCollector, BaseFactCollector)


# Generated at 2022-06-20 20:13:36.394182
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    test_obj = SshPubKeyFactCollector()
    test_obj.collect()

# Generated at 2022-06-20 20:13:41.300388
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    collector = SshPubKeyFactCollector()

    # unit test with fake ssh public keys
    # :param module: ansible module
    # :param collected_facts: ansible facts
    # :return: ansible facts

# Generated at 2022-06-20 20:13:50.179383
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    '''Unit test for constructor of class SshPubKeyFactCollector'''
    ssh_pub_key_fact = SshPubKeyFactCollector()
    assert ssh_pub_key_fact.name == 'ssh_pub_keys'
    assert set(ssh_pub_key_fact._fact_ids) \
            == set(['ssh_host_pub_keys',
                    'ssh_host_key_dsa_public',
                    'ssh_host_key_rsa_public',
                    'ssh_host_key_ecdsa_public',
                    'ssh_host_key_ed25519_public'])