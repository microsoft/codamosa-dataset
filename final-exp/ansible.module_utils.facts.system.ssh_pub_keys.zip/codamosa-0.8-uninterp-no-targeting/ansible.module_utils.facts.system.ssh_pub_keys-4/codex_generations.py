

# Generated at 2022-06-20 20:03:54.901038
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    import os
    import sys
    import tempfile
    import shutil
    import pytest

    my_dir = os.path.dirname(__file__)

    from ansible.module_utils.facts import collector

    # copy the ssh example keys into a temporary directory
    # to simulate those keys being on the local system
    tempdir = tempfile.mkdtemp()
    for example_key in ('ssh_host_dsa_key.pub', 'ssh_host_dsa_key',
                        'ssh_host_rsa_key.pub', 'ssh_host_rsa_key'):
        shutil.copy(os.path.join(my_dir, 'example_ssh_keys', example_key),
                    os.path.join(tempdir, example_key))

# Generated at 2022-06-20 20:03:57.409853
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKeyFactCollector = SshPubKeyFactCollector.SshPubKeyFactCollector()
    assert sshPubKeyFactCollector.name == 'ssh_pub_keys'


# Generated at 2022-06-20 20:03:59.026407
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    col = SshPubKeyFactCollector()
    assert col.name == 'ssh_pub_keys'
    assert len(col._fact_ids) == 5

# Generated at 2022-06-20 20:04:03.146527
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Verify that a simple test case works."""
    # create a test collector
    fc = SshPubKeyFactCollector('ssh_pub_keys')
    fc.collect()
    assert(len(fc.facter_dict) > 0)

# Generated at 2022-06-20 20:04:05.320518
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshpub_col = SshPubKeyFactCollector()
    assert sshpub_col.name == 'ssh_pub_keys'


# Generated at 2022-06-20 20:04:09.737039
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    facts_collector = SshPubKeyFactCollector()
    fact_names = facts_collector.collection_commands()
    fact_ids = facts_collector.fact_ids()
    assert fact_names == fact_ids

# Generated at 2022-06-20 20:04:10.709999
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-20 20:04:16.634382
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_keys = SshPubKeyFactCollector()
    ssh_pub_keys_facts = ssh_pub_keys.collect()
    assert(isinstance(ssh_pub_keys_facts, dict))
    assert('ssh_host_key_ecdsa_public' in ssh_pub_keys_facts)
    assert('ssh_host_key_ecdsa_public_keytype' in ssh_pub_keys_facts)

# Generated at 2022-06-20 20:04:26.638447
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    def create_ansible_module(facts=None):
        if facts:
            return {'ansible_facts': facts}
        return {'ansible_facts': {}}

    # no keys
    module = create_ansible_module()
    test_collector = SshPubKeyFactCollector(module)
    test_collector.collect()
    assert module['ansible_facts'] == {}

    # all keys
    module = create_ansible_module()

# Generated at 2022-06-20 20:04:30.083927
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector is not None


# Generated at 2022-06-20 20:04:39.995256
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_info = SshPubKeyFactCollector()
    assert fact_info.name == "ssh_pub_keys"
    assert fact_info._fact_ids == {'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public',
                                   'ssh_host_pub_keys', 'ssh_host_key_rsa_public', 'ssh_host_key_dsa_public'}

# Generated at 2022-06-20 20:04:42.009658
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:04:44.637746
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == "ssh_pub_keys"
    assert sorted(ssh_pub_key_facts.collected_facts) == sorted(ssh_pub_key_facts._fact_ids)


# Generated at 2022-06-20 20:04:45.545454
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-20 20:04:55.889718
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert len(ssh_pub_key_fact_collector._fact_ids) == 5
    assert 'ssh_host_pub_keys' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_ed25519_public'

# Generated at 2022-06-20 20:05:03.085401
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # Test empty keys
    class _module:
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            pass

    class _collected_facts:
        def __init__(self):
            self.all_facts = {}

    m = _module()
    c = _collected_facts()
    SshPubKeyFactCollector().collect(module=m, collected_facts=c)

    assert "ssh_host_pub_keys" not in c.all_facts

# Generated at 2022-06-20 20:05:04.596544
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    SshPubKeyFactCollector.collect()

# Generated at 2022-06-20 20:05:12.096463
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'
    assert collector._fact_ids == set(['ssh_host_pub_keys',
                                       'ssh_host_key_dsa_public',
                                       'ssh_host_key_rsa_public',
                                       'ssh_host_key_ecdsa_public',
                                       'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:05:23.244857
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    import shutil

    TEST_DATA_DIR = os.path.join(os.path.dirname(__file__), 'unit', 'module_utils', 'facts', 'collectors', 'ssh_pub_key', 'data')


# Generated at 2022-06-20 20:05:29.609894
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert set(x._fact_ids) == set(['ssh_host_pub_keys',
                                    'ssh_host_key_dsa_public',
                                    'ssh_host_key_rsa_public',
                                    'ssh_host_key_ecdsa_public',
                                    'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:05:49.408286
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector.ssh_pub_key import SshPubKeyFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import os

    # Create dummy host public keys in a fake directories to test host keys are properly read
    fake_key_directories = ['/test/etc/ssh', '/test/etc/openssh', '/test/etc']
    host_keys = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    expected_facts = {}

    for key_dir in fake_key_directories:
        os.makedirs(key_dir, exist_ok=True)

# Generated at 2022-06-20 20:05:53.225130
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Test that the class of the utility object is a SshPubKeyFactCollector
    assert SshPubKeyFactCollector.__name__ == 'SshPubKeyFactCollector'

# Generated at 2022-06-20 20:05:54.828093
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_instance = SshPubKeyFactCollector()
    assert ssh_pub_key_instance.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:05:57.852496
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert isinstance(SshPubKeyFactCollector(), object)
    assert isinstance(SshPubKeyFactCollector(), BaseFactCollector)


# Generated at 2022-06-20 20:05:59.926919
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    SshPubKeyFactCollector_obj = SshPubKeyFactCollector()
    SshPubKeyFactCollector_obj.collect()

# Generated at 2022-06-20 20:06:09.867550
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class MockModule:
        def __init__(self):
            self.params = dict()

    class MockCollector:
        def __init__(self):
            self.facts = dict()

    module = MockModule()
    collector = MockCollector()
    collector.facts = {
        'ssh_host_key_dsa_public': None,
        'ssh_host_key_rsa_public': None,
        'ssh_host_key_ecdsa_public': None,
        'ssh_host_key_ed25519_public': None,
    }

    # scenario 1: /etc/ssh/*key.pub exist
    ssh_key_file = dict()

# Generated at 2022-06-20 20:06:10.918154
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    pass


# Generated at 2022-06-20 20:06:12.026424
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:06:20.042813
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Unit test for method collect of class SshPubKeyFactCollector"""


# Generated at 2022-06-20 20:06:31.481036
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ''' Unit test to verify collect method of class SshPubKeyFactCollector '''
    # pylint: disable=redefined-outer-name
    import os
    import mock
    import tempfile
    import hashlib
    class TestModule(object):
        ''' Class to create a mock module to pass to the collect method '''
        def __init__(self, name, facts):
            self.name = name
            self.params = facts

    def sha256(s):
        ''' Get an sha256 hash from file '''
        return hashlib.sha256(s).hexdigest()

    ssh_collector = SshPubKeyFactCollector()
    with tempfile.TemporaryDirectory() as tmpdirname:
        temp_openssh_path = os.path.join(tmpdirname, 'openssh')
       

# Generated at 2022-06-20 20:06:42.001830
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Unit test for method collect of class SshPubKeyFactCollector"""
    SshPubKeyFactCollector.collect()

# Generated at 2022-06-20 20:06:48.422439
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import ansible.module_utils.facts.collectors.ssh_pub_keys as ssh_module_mock
    import os
    import pwd
    import tempfile

# Generated at 2022-06-20 20:06:51.409711
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    try:
        SshPubKeyFactCollector()
    except Exception:
        assert False, 'Could not instantiate SshPubKeyFactCollector class'
        return False

    return True

# Generated at 2022-06-20 20:07:00.515460
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    import sys
    import os
    import tempfile


# Generated at 2022-06-20 20:07:10.925993
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    class MockModule(object):
        def __init__(self, params):
            self.params = params

    # Test case:
    # The first key found should be the one returned by collect
    # The other two keys should be ignored
    ssh_pub_key_facts = {}
    ssh_pub_key_facts['ssh_host_key_dsa_public'] = 'AAAA'
    ssh_pub_key_facts['ssh_host_key_rsa_public'] = 'AAAA'
    ssh_pub_key_facts['ssh_host_key_ecdsa_public'] = 'AAAA'
    ssh_pub_key_facts['ssh_host_key_ed25519_public'] = 'AAAA'

    module = MockModule(params={})
    fact_collector = SshPubKeyFactCollector(module=module)
   

# Generated at 2022-06-20 20:07:11.614650
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    SshPubKeyFactCollector().collect()

# Generated at 2022-06-20 20:07:13.485521
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector is not None

# Generated at 2022-06-20 20:07:15.892297
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-20 20:07:21.753557
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKeyFactCollector = SshPubKeyFactCollector()
    assert sshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert sshPubKeyFactCollector._fact_ids == {'ssh_host_pub_keys',
                                                'ssh_host_key_dsa_public',
                                                'ssh_host_key_rsa_public',
                                                'ssh_host_key_ecdsa_public',
                                                'ssh_host_key_ed25519_public'}

# Generated at 2022-06-20 20:07:33.398503
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_fact_collector, SshPubKeyFactCollector)
    assert isinstance(ssh_pub_key_fact_collector, BaseFactCollector)
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                                        'ssh_host_key_dsa_public',
                                                        'ssh_host_key_rsa_public',
                                                        'ssh_host_key_ecdsa_public',
                                                        'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:08:01.389037
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import sys
    if sys.version_info[0] == 2:
        import mock
    else:
        from unittest import mock


# Generated at 2022-06-20 20:08:13.070057
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:08:24.138461
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c = SshPubKeyFactCollector()
    assert set(['ssh_host_key_dsa_public', 'ssh_host_key_ed25519_public',
            'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public',
            'ssh_host_pub_keys']) == c._fact_ids
    assert 'ssh_pub_keys' == c.name
    assert set(['ssh_host_key_dsa_public', 'ssh_host_key_ed25519_public',
            'ssh_host_pub_keys', 'ssh_host_key_ecdsa_public',
            'ssh_host_key_rsa_public']) == set(c.collect().keys())

# Generated at 2022-06-20 20:08:27.308460
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    assert isinstance(ssh_pub_key_facts, dict), \
        "ssh_pub_key_facts is not a dictionary"
    assert len(ssh_pub_key_facts) > 0, \
        "ssh_pub_key_facts length is 0"

# Generated at 2022-06-20 20:08:36.108257
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact = SshPubKeyFactCollector()
    assert fact.name == 'ssh_pub_keys'
    assert isinstance(fact._fact_ids, set)
    assert 'ssh_host_pub_keys' in fact._fact_ids
    assert 'ssh_host_key_dsa_public' in fact._fact_ids
    assert 'ssh_host_key_rsa_public' in fact._fact_ids
    assert 'ssh_host_key_ecdsa_public' in fact._fact_ids
    assert 'ssh_host_key_ed25519_public' in fact._fact_ids

# Generated at 2022-06-20 20:08:42.351382
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collectors._file_system import FileSystemFactCollector

    # Setup the needed objects
    fact_collector = FactCollector()
    file_system_fact_collector = FileSystemFactCollector()
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # Call the collect method of the SshPubKeyFactCollector Class
    # with the needed objects
    ssh_pub_key_fact_collector.collect(file_system_fact_collector, fact_collector)

# Generated at 2022-06-20 20:08:47.799898
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    assert ssh_pub_key_facts['ssh_host_key_dsa_public'] is not None
    assert ssh_pub_key_facts['ssh_host_key_rsa_public'] is not None
    assert ssh_pub_key_facts['ssh_host_key_ecdsa_public'] is not None
    assert ssh_pub_key_facts['ssh_host_key_ed25519_public'] is not None
    assert ssh_pub_key_facts['ssh_host_key_dsa_public_keytype'] == 'ssh-dss'
    assert ssh_pub_key_facts['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa'

# Generated at 2022-06-20 20:08:57.062211
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import SshPubKeyFactCollector

    # test data:
    # - file name of a ssh key
    # - content of the ssh key file
    # - expected result: a dictionary which contains the data of the ssh key
    testcase_data = [
        ['/tmp/ssh_host_foo_key.pub',
         to_bytes(u'foo-keytype fookey'),
         {'ssh_host_key_foo_public': 'fookey',
          'ssh_host_key_foo_public_keytype': 'foo-keytype'}]
    ]


# Generated at 2022-06-20 20:09:07.331006
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    # Create collector and add SshPubKeyFactCollector to collectors
    fact_collector = FactCollector()
    fact_collector.collectors.append(SshPubKeyFactCollector())

    # Get facts
    collected_fact_dict = fact_collector.collect(module=None, collected_facts=None)

    # Verify ssh_pub_keys exists and it is not empty
    assert 'ssh_pub_keys' in collected_fact_dict
    assert isinstance(collected_fact_dict['ssh_pub_keys'], dict)
    assert collected_fact_dict['ssh_pub_keys']

    # Verify all the ssh_pub_keys facts exists
    for fact_name in SshPubKeyFactCollector._fact_ids:
        assert fact_name in collected

# Generated at 2022-06-20 20:09:18.910879
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = {}
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')

    # list of directories to check for ssh keys
    # used in the order listed here, the first one with keys is used
    keydirs = ['/etc/ssh', '/etc/openssh', '/etc']

    for keydir in keydirs:
        for algo in algos:
            factname = 'ssh_host_key_%s_public' % algo
            if factname in ssh_pub_key_facts:
                # a previous keydir was already successful, stop looking
                # for keys
                print(ssh_pub_key_facts)
                return ssh_pub_key_facts

# Generated at 2022-06-20 20:10:03.122346
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    test_class = SshPubKeyFactCollector()
    assert test_class.name == 'ssh_pub_keys', 'test_SshPubKeyFactCollector instance does not have correct value for name attribute'

# Generated at 2022-06-20 20:10:13.450233
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import Collector

    mock_module = type('module', (object,), {})
    setattr(mock_module, 'USERNAME', to_bytes('testuser'))
    facts = Collector(module=mock_module).collect()
    assert 'ssh_host_pub_keys' in facts
    assert 'ssh_host_key_dsa_public' in facts
    assert 'ssh_host_key_rsa_public' in facts
    assert 'ssh_host_key_ed25519_public' in facts
    assert 'ssh_host_key_ecdsa_public' in facts
    assert 'ssh_host_key_dsa_public_keytype' in facts

# Generated at 2022-06-20 20:10:23.295981
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector is not None
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                                        'ssh_host_key_dsa_public',
                                                        'ssh_host_key_rsa_public',
                                                        'ssh_host_key_ecdsa_public',
                                                        'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:10:24.435948
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-20 20:10:30.409785
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    keycoll = SshPubKeyFactCollector()
    assert keycoll.name == 'ssh_pub_keys'
    assert keycoll._fact_ids == set(['ssh_host_pub_keys',
                                     'ssh_host_key_dsa_public',
                                     'ssh_host_key_rsa_public',
                                     'ssh_host_key_ecdsa_public',
                                     'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:10:38.134633
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    module = None
    ssh_fact = SshPubKeyFactCollector()
    assert ssh_fact.name == 'ssh_pub_keys'
    assert ssh_fact._fact_ids == {'ssh_host_pub_keys', 'ssh_host_key_ecdsa_public',
                                  'ssh_host_key_rsa_public', 'ssh_host_key_dsa_public',
                                  'ssh_host_key_ed25519_public'}

# Generated at 2022-06-20 20:10:43.135411
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_keys_facct_collector = SshPubKeyFactCollector()
    assert ssh_pub_keys_facct_collector.name == 'ssh_pub_keys'
    assert ssh_pub_keys_facct_collector._fact_ids == set(['ssh_host_pub_keys',
                                                          'ssh_host_key_dsa_public',
                                                          'ssh_host_key_rsa_public',
                                                          'ssh_host_key_ecdsa_public',
                                                          'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:10:49.811588
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fc = SshPubKeyFactCollector()
    assert ssh_pub_key_fc.name == 'ssh_pub_keys'
    assert ssh_pub_key_fc._fact_ids == set(['ssh_host_pub_keys',
                                            'ssh_host_key_dsa_public',
                                            'ssh_host_key_rsa_public',
                                            'ssh_host_key_ecdsa_public',
                                            'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:10:52.204927
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # verify that a new instance of SshPubKeyFactCollector is created correctly
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:10:54.281486
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert isinstance(SshPubKeyFactCollector, BaseFactCollector), \
        'The constructor of class SshPubKeyFactCollector should be a subclass of BaseFactCollector'

# Generated at 2022-06-20 20:12:32.266221
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fc = SshPubKeyFactCollector()
    fc.collect()

# Generated at 2022-06-20 20:12:39.626754
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    # A mocked module object.
    module = mock.MagicMock()

    # A mocked FactCache object.
    fact_cache = mock.MagicMock()
    # This is what the method will return for a non-existing file.
    fact_cache.get_fact.return_value = None

    # A mocked AnsibleModule object.
    ansible_module = mock.MagicMock()
    ansible_module.params = dict()
    ansible_module.params['timeout'] = 10
    ansible_module.params['interval'] = 1
    # This is what the method will return for an existing file.
    ansible_module.get_file_content.return_value = 'ssh-rsa 12345 ...'

# Generated at 2022-06-20 20:12:41.048988
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sut = SshPubKeyFactCollector()
    assert sut.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:12:47.726073
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create an instance of SshPubKeyFactCollector
    sshpubkey_collector = SshPubKeyFactCollector()

    # Create a mocked ansible module and add the instance of SshPubKeyFactCollector
    # to the module.
    class ModuleMock:
        def __init__(self, _):
            self.collectors = [sshpubkey_collector]

    # Mock the get_file_content method of SshPubKeyFactCollector
    class FileMock:
        def get_file_content(self, filename, _):
            if filename == 'missing_file':
                return None
            else:
                return 'ssh-ed25519 some_key_stuff'

    module_mock = ModuleMock(FileMock())

# Generated at 2022-06-20 20:12:52.316136
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts_collector = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_facts_collector, BaseFactCollector)
    assert isinstance(ssh_pub_key_facts_collector.name, str)
    assert isinstance(ssh_pub_key_facts_collector._fact_ids, set)

# Generated at 2022-06-20 20:13:02.787013
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_key_collector = SshPubKeyFactCollector()
    keys = ssh_key_collector.collect()
    # add in a fake key so we can test it getting added to the facts
    keys['ssh_host_key_ecdsa_public'] = 'fakekey'
    # check the result
    assert len(keys) == 5
    assert 'ssh_host_key_rsa_public' in keys
    assert 'ssh_host_key_rsa_public_keytype' in keys
    assert keys['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa'
    assert 'ssh_host_key_ecdsa_public' in keys
    assert 'ssh_host_key_ecdsa_public_keytype' in keys

# Generated at 2022-06-20 20:13:08.011477
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector = SshPubKeyFactCollector()
    assert fact_collector.name == 'ssh_pub_keys'
    assert fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                            'ssh_host_key_dsa_public',
                                            'ssh_host_key_rsa_public',
                                            'ssh_host_key_ecdsa_public',
                                            'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:13:17.196653
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    with open('/etc/ssh/ssh_host_rsa_key.pub', 'rb') as f:
        ssh_host_rsa_key_public = f.read()
    with open('/etc/ssh/ssh_host_ed25519_key.pub', 'rb') as f:
        ssh_host_ed25519_key_public = f.read()
    with open('/etc/ssh/ssh_host_dsa_key.pub', 'rb') as f:
        ssh_host_dsa_key_public = f.read()
    with open('/etc/ssh/ssh_host_ecdsa_key.pub', 'rb') as f:
        ssh_host_ecdsa_key_public = f.read()


# Generated at 2022-06-20 20:13:18.590858
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:13:26.425134
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    facts_module = MockAnsibleModule()