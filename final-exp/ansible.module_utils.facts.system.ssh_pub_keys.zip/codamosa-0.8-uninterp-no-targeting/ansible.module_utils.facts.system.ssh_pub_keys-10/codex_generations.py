

# Generated at 2022-06-20 20:03:49.303206
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
        'ssh_host_key_dsa_public',
        'ssh_host_key_rsa_public',
        'ssh_host_key_ecdsa_public',
        'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:03:54.487759
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:04:00.173492
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    s = SshPubKeyFactCollector()
    assert hasattr(s, 'name')
    assert hasattr(s, '_fact_ids')
    assert s.name == 'ssh_pub_keys'
    assert 'ssh_host_key_dsa_public' in s._fact_ids
    assert 'ssh_host_key_rsa_public' in s._fact_ids
    assert 'ssh_host_key_ecdsa_public' in s._fact_ids
    assert 'ssh_host_key_ed25519_public' in s._fact_ids


# Generated at 2022-06-20 20:04:12.537703
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    import shutil
    import unittest

    tmpdir = tempfile.mkdtemp()
    keydir = os.path.join(tmpdir, 'ssh')
    os.mkdir(keydir)
    os.mkdir(os.path.join(tmpdir, 'openssh'))

    # create fake ssh keys
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    for algo in algos:
        with open(os.path.join(keydir, 'ssh_host_%s_key.pub' % algo), 'w') as f:
            f.write('%s fake %s.pubkey\n' % (algo, algo))


# Generated at 2022-06-20 20:04:18.429104
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    a = SshPubKeyFactCollector()
    assert a.name == 'ssh_pub_keys'
    assert a._fact_ids == set(['ssh_host_pub_keys',
        'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public',
        'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:04:23.851974
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fixture = SshPubKeyFactCollector()
    print(fixture)
    output = fixture.collect()
    print(output)


if __name__ == '__main__':
    # Unit test is run as stand alone program
    # To run unit test for method collect of class SshPubKeyFactCollector
    test_SshPubKeyFactCollector_collect()

# Generated at 2022-06-20 20:04:34.385774
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = {}
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    keydirs = ['/etc/ssh', '/etc/openssh', '/etc']
    for keydir in keydirs:
        for algo in algos:
            factname = 'ssh_host_key_%s_public' % algo
            if factname in ssh_pub_key_facts:
                return ssh_pub_key_facts
            key_filename = '%s/ssh_host_%s_key.pub' % (keydir, algo)
            keydata = get_file_content(key_filename)
            if keydata is not None:
                (keytype, key) = keydata.split()[0:2]
                ssh_pub_key_

# Generated at 2022-06-20 20:04:39.662151
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:04:42.646757
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_facts_collector.collect()

    assert isinstance(ssh_pub_key_facts, dict)


# Generated at 2022-06-20 20:04:54.528506
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils import basic
    import pkgutil
    import os.path

    test_dir = os.path.dirname(__file__)
    key_files = ['ssh_host_dsa_key.pub',
                 'ssh_host_ecdsa_key.pub',
                 'ssh_host_ed25519_key.pub',
                 'ssh_host_rsa_key.pub']
    key_contents = {}

# Generated at 2022-06-20 20:05:07.608811
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # Create a test module
    from ansible.module_utils.facts import ModuleUtilsLegacyFactCollector
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    test_module = ModuleUtilsLegacyFactCollector(Facts(), FactsCollector(), to_bytes('{}'), None, None, None)
    test_module.params['gather_subset'] = 'all'
    test_module.params['filter'] = '*'

    # Create a temp ssh dir
    ssh_dir = tempfile.mkdtemp()
    os.system('chmod 700 ' + ssh_dir)

    # Create a dummy ssh key
    test_key_name

# Generated at 2022-06-20 20:05:16.401445
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])
    assert x.collect_fn == x._get_ssh_pub_key_facts
    assert x.required_module == 'os'

# Generated at 2022-06-20 20:05:27.075776
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()
    assert 'ssh_host_rsa_public' in ssh_pub_key_facts
    if 'ssh_host_rsa_public' in ssh_pub_key_facts:
        assert 13 <= len(ssh_pub_key_facts['ssh_host_rsa_public']) <= 521
    assert 'ssh_host_rsa_public_keytype' in ssh_pub_key_facts
    if 'ssh_host_rsa_public_keytype' in ssh_pub_key_facts:
        assert ssh_pub_key_facts['ssh_host_rsa_public_keytype'] == 'ssh-rsa'

# Generated at 2022-06-20 20:05:39.073313
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Normal case: populate ssh_host_key_ecdsa_public and
    # ssh_host_key_ed25519_public
    # using openssh
    module = type('', (), {})()
    module.get_bin_path = lambda _: '/usr/bin/ssh-keygen'
    collected_facts = dict(ssh_host_key_ecdsa_public='ecdsa-key',
                           ssh_host_key_ed25519_public='ed25519-key')
    collector = SshPubKeyFactCollector(module=module)
    assert collector.collect(module=module, collected_facts=collected_facts) \
        == dict(ssh_host_key_ecdsa_public='ecdsa-key',
                ssh_host_key_ed25519_public='ed25519-key')

# Generated at 2022-06-20 20:05:49.772479
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()

    # Put fact values in variables so it is easier to check them
    ssh_host_key_dsa_public = ssh_pub_key_facts['ssh_host_key_dsa_public']
    ssh_host_key_rsa_public = ssh_pub_key_facts['ssh_host_key_rsa_public']
    ssh_host_key_ecdsa_public = ssh_pub_key_facts['ssh_host_key_ecdsa_public']
    ssh_host_key_ed25519_public = ssh_pub_key_facts['ssh_host_key_ed25519_public']

    assert len(ssh_host_key_dsa_public) > 0

# Generated at 2022-06-20 20:05:51.954039
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sc = SshPubKeyFactCollector()
    assert sc != None
    assert sc.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:05:58.701871
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Unit test for constructor of class SshPubKeyFactCollector
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:06:07.498649
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key = SshPubKeyFactCollector()
    result = ssh_pub_key.collect()
    assert isinstance(result, dict)
    assert 'ssh_host_key_rsa_public' in result
    assert 'ssh_host_key_ecdsa_public' in result
    assert 'ssh_host_key_ed25519_public' in result
    assert 'ssh_host_key_rsa_public_keytype' in result
    assert 'ssh_host_key_ecdsa_public_keytype' in result
    assert 'ssh_host_key_ed25519_public_keytype' in result

# Generated at 2022-06-20 20:06:17.732073
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import Collector


# Generated at 2022-06-20 20:06:20.143307
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert type(SshPubKeyFactCollector()) == SshPubKeyFactCollector

# Generated at 2022-06-20 20:06:25.591386
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'


# Generated at 2022-06-20 20:06:33.636953
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:06:42.859473
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCache
    from ansible.module_utils.facts.utils import get_file_content, get_file_lines

# Generated at 2022-06-20 20:06:54.536085
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # verify _fact_ids is frozen
    for fact in SshPubKeyFactCollector._fact_ids:
        try:
            SshPubKeyFactCollector._fact_ids.add(fact)
            assert False, "Adding item to frozen set should not be allowed"
        except:
                pass

    # verify _fact_ids is a superset of BaseFactCollector._fact_ids
    assert SshPubKeyFactCollector._fact_ids.issuperset(BaseFactCollector._fact_ids)

    # verify the set is correct

# Generated at 2022-06-20 20:07:00.214382
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_pub_keys',
                              'ssh_host_key_dsa_public',
                              'ssh_host_key_rsa_public',
                              'ssh_host_key_ecdsa_public',
                              'ssh_host_key_ed25519_public'])



# Generated at 2022-06-20 20:07:08.643725
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    test_ins = SshPubKeyFactCollector()
    assert type(test_ins) is SshPubKeyFactCollector
    assert test_ins.name == 'ssh_pub_keys'
    assert type(test_ins._fact_ids) is set
    assert 'ssh_host_pub_keys' in test_ins._fact_ids
    assert 'ssh_host_key_rsa_public' in test_ins._fact_ids
    assert 'ssh_host_key_ecdsa_public' in test_ins._fact_ids
    assert 'ssh_host_key_ed25519_public' in test_ins._fact_ids
    assert test_ins is not None

# Generated at 2022-06-20 20:07:09.625776
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-20 20:07:11.970743
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    mock_module = None
    mock_collected_facts = None

    c = SshPubKeyFactCollector()
    c.collect(mock_module, mock_collected_facts)

# Generated at 2022-06-20 20:07:13.113328
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass


# Generated at 2022-06-20 20:07:20.077211
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    for algo in ('rsa', 'dsa', 'ecdsa', 'ed25519'):
        factname = 'ssh_host_key_%s_public' % algo
        fact = SshPubKeyFactCollector(factname)
        assert fact.name == factname
        assert fact._fact_ids == set([factname])
        assert fact._cache_file == "/var/lib/ansible/local/%s" % factname
        assert fact.collect() == {}

# Generated at 2022-06-20 20:07:36.171862
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    pubkey_fact_collector = SshPubKeyFactCollector()
    assert pubkey_fact_collector.name == 'ssh_pub_keys'
    assert pubkey_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                                   'ssh_host_key_dsa_public',
                                                   'ssh_host_key_rsa_public',
                                                   'ssh_host_key_ecdsa_public',
                                                   'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:07:42.820299
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:07:48.376911
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'
    assert collector._fact_ids == set(['ssh_host_pub_keys',
                                       'ssh_host_key_dsa_public',
                                       'ssh_host_key_rsa_public',
                                       'ssh_host_key_ecdsa_public',
                                       'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:07:52.475629
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test with a stub object
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector

# Generated at 2022-06-20 20:08:02.109543
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Initializing mock data for test
    collected_facts = {}
    keydirs = ['/etc/ssh', '/etc/openssh', '/etc']
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    facts = {}
    expected_facts = {}
    # Setup the SshPubKeyFactCollector
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    # Run collect to make facts and check that it returned the expected values
    facts = ssh_pub_key_fact_collector.collect(collected_facts=collected_facts)
    for keydir in keydirs:
        for algo in algos:
            factname = 'ssh_host_key_%s_public' % algo

# Generated at 2022-06-20 20:08:12.859665
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Check the name of class SshPubKeyFactCollector
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    # Check the _fact_ids of class SshPubKeyFactCollector
    expected_fact_ids = set(['ssh_host_pub_keys',
                             'ssh_host_key_dsa_public',
                             'ssh_host_key_rsa_public',
                             'ssh_host_key_ecdsa_public',
                             'ssh_host_key_ed25519_public'])
    assert SshPubKeyFactCollector._fact_ids == expected_fact_ids
    # Check that constructor of class SshPubKeyFactCollector
    # doesn't throw exception
    SshPubKeyFactCollector()

# Generated at 2022-06-20 20:08:18.956718
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # GIVEN
    mock_module = None
    mock_collector = SshPubKeyFactCollector()

    # WHEN
    result = mock_collector.collect(mock_module)

    # THEN
    assert isinstance(result, dict)

# Generated at 2022-06-20 20:08:26.830234
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils._text import to_bytes

    module = None
    collected_facts = None

    ssh_pub_key_facts = {}

    # RSA key

# Generated at 2022-06-20 20:08:39.145908
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    sshPubKeyFactCollector = SshPubKeyFactCollector()
    facts = sshPubKeyFactCollector.collect()

# Generated at 2022-06-20 20:08:43.685401
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    first_fact_collector = SshPubKeyFactCollector()
    assert first_fact_collector is not None, \
           'SshPubKeyFactCollector instantiation failed'


# Generated at 2022-06-20 20:09:08.539555
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import mock
    import tempfile
    import os
    module = mock.MagicMock()
    module.get_bin_path.side_effect = (lambda x, required=False: x)
    collected_facts = {}
    c = SshPubKeyFactCollector(module)
    assert c.collect(module, collected_facts) == {
            'ssh_host_key_dsa_public': None,
            'ssh_host_key_rsa_public': None,
            'ssh_host_key_ecdsa_public': None,
            'ssh_host_key_ed25519_public': None,
    }

# Generated at 2022-06-20 20:09:12.096703
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_obj = SshPubKeyFactCollector()
    assert 'ssh_host_key_dsa_public' in test_obj.collect()

# Generated at 2022-06-20 20:09:18.688308
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts_test = SshPubKeyFactCollector()
    assert ssh_pub_key_facts_test.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts_test._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:09:25.159752
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_collector = SshPubKeyFactCollector()

    # mock the collector

# Generated at 2022-06-20 20:09:25.555238
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-20 20:09:30.039202
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:09:38.993439
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Setup AnsibleModule stub
    class AnsibleModuleStub(object):
        pass

    my_ansible_module = AnsibleModuleStub()

    # Setup Collector
    my_collector = SshPubKeyFactCollector()

    # Test collect
    my_ssh_pub_keys = my_collector.collect(my_ansible_module)

    # Test results
    assert my_ssh_pub_keys['ssh_host_key_ed25519_public'] == 'AAAAC3NzaC1lZDI1NTE5AAAAIP8nxUfX9H+MvhJOZBax8mH0HE6+jmvJ5U6W8y0UEHrm'

# Generated at 2022-06-20 20:09:47.947404
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    mock_module = type('module', (object,), {'params': {'gather_subset': ['!all', 'ssh']}})
    mock_collector = SshPubKeyFactCollector()

    # Mock get_file_content method of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:09:57.581353
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import pytest
    key_files = {
            'ssh_host_key_dsa_public': '/etc/ssh/ssh_host_dsa_key.pub',
            'ssh_host_key_rsa_public': '/etc/ssh/ssh_host_rsa_key.pub',
            'ssh_host_key_ecdsa_public': '/etc/ssh/ssh_host_ecdsa_key.pub',
            'ssh_host_key_ed25519_public': '/etc/ssh/ssh_host_ed25519_key.pub'}

    def replace_fake_file(filename, data):
        fake_file_content[filename] = data

    # fake the file content of key files
    fake_file_content = {}

    # fake the return values of get_file_content()

# Generated at 2022-06-20 20:09:59.971509
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = None
    #should return with an empty set
    assert SshPubKeyFactCollector().collect(module, collected_facts) == {}

# Generated at 2022-06-20 20:10:37.777305
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_keys = SshPubKeyFactCollector()
    fact_data = ssh_pub_keys.collect()
    assert 'ssh_host_key_ed25519_public' in fact_data
    assert 'ssh_host_key_rsa_public' in fact_data

# Generated at 2022-06-20 20:10:46.892957
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:10:52.417265
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:11:00.206265
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact = SshPubKeyFactCollector()

    facts = fact.collect()
    assert "ssh_host_key_rsa_public" in facts
    assert "ssh_host_key_rsa_public_keytype" in facts
    assert "ssh_host_key_ecdsa_public" in facts
    assert "ssh_host_key_ecdsa_public_keytype" in facts
    assert "ssh_host_key_ed25519_public" in facts
    assert "ssh_host_key_ed25519_public_keytype" in facts
    assert "ssh_host_key_dsa_public" not in facts
    assert "ssh_host_key_dsa_public_keytype" not in facts

# Generated at 2022-06-20 20:11:12.167285
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test with ssh keys
    class TestFactCollector(SshPubKeyFactCollector):
        def __init__(self, name, collection_method):
            self.name = name
            self.collection_method = collection_method

    class TestModule(object):
        def __init__(self):
            self.params = {}


# Generated at 2022-06-20 20:11:14.287363
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_collector = SshPubKeyFactCollector()
    collected_facts = ssh_collector.collect()
    assert collected_facts is not None


# Generated at 2022-06-20 20:11:23.380770
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = None

    #
    #  If all the files exist, we should get all the facts
    #


# Generated at 2022-06-20 20:11:27.851636
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKeyFactCollector = SshPubKeyFactCollector()
    assert sshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert sshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:11:33.115110
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''
    Unit test method collect of class SshPubKeyFactCollector
    '''

    # AnsibleModule mock
    class AnsibleModuleMock(object):
        pass

    # AnsibleModule is a class, so we need to instantiate it
    # this is a mock object
    ansible_module = AnsibleModuleMock()

    # AnsibleModule.params is a dict
    # we need to create the dict
    ansible_module.params = dict()

    # we can call the collect method of SshPubKeyFactCollector
    # because AnsibleModule as no real importance for the method
    ssh_pub_key_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_collector.collect(ansible_module, None)


# Generated at 2022-06-20 20:11:37.930139
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pub_key_fact_collector = SshPubKeyFactCollector()
    facts = {'ssh_host_key_dsa_public': '', 'ssh_host_key_ed25519_public': '', 'ssh_host_key_ecdsa_public': '', 'ssh_host_key_rsa_public': ''}

    assert facts == pub_key_fact_collector.collect()

# Generated at 2022-06-20 20:13:08.845128
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set([
        'ssh_host_pub_keys',
        'ssh_host_key_dsa_public',
        'ssh_host_key_rsa_public',
        'ssh_host_key_ecdsa_public',
        'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:13:11.084506
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:13:11.796667
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-20 20:13:13.906331
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    facts = SshPubKeyFactCollector().collect()
    assert 'ssh_host_key_ecdsa_public' in facts

# Generated at 2022-06-20 20:13:21.841780
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts
    assert isinstance(ssh_pub_key_facts._fact_ids, set)
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert 'ssh_host_pub_keys' in ssh_pub_key_facts._fact_ids
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts._fact_ids
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts._fact_ids
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts._fact_ids
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_facts._fact

# Generated at 2022-06-20 20:13:27.117682
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set([
        'ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public',
        'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:13:31.397134
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c = SshPubKeyFactCollector()
    assert c.name == 'ssh_pub_keys'
    assert c._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:13:33.539583
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_fact_collector = SshPubKeyFactCollector()
    assert isinstance(ssh_fact_collector, BaseFactCollector)

# Generated at 2022-06-20 20:13:35.039711
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key = SshPubKeyFactCollector()
    assert ssh_pub_key is not None

# Generated at 2022-06-20 20:13:39.352489
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # set up modules args and run the module code
    module_args = { }
    result = SshPubKeyFactCollector().collect(module_args)

    # test returned results
    assert 'ssh_host_key_ed25519_public' in result
    assert 'ssh_host_key_ed25519_public_keytype' in result

    assert 'ssh_host_key_ecdsa_public' in result
    assert 'ssh_host_key_ecdsa_public_keytype' in result

    assert 'ssh_host_key_rsa_public' in result
    assert 'ssh_host_key_rsa_public_keytype' in result