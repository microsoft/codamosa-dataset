

# Generated at 2022-06-20 20:03:44.902724
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert set(SshPubKeyFactCollector().collect().keys()) == SshPubKeyFactCollector()._fact_ids

# Generated at 2022-06-20 20:03:49.519719
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c = SshPubKeyFactCollector()
    assert c.name == 'ssh_pub_keys'
    assert c._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:03:54.922585
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
   ssh=SshPubKeyFactCollector()
   assert ssh.name == 'ssh_pub_keys'
   assert ssh._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])
   assert ssh.collect() == {}

# Generated at 2022-06-20 20:03:59.608401
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:04:01.811389
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    # assertion: SshPubKeyFactCollector object is created
    assert isinstance(ssh_pub_key_collector, SshPubKeyFactCollector)


# Generated at 2022-06-20 20:04:05.398180
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    expected = set(['ssh_host_key_dsa_public',
                    'ssh_host_key_rsa_public',
                    'ssh_host_key_ecdsa_public',
                    'ssh_host_key_ed25519_public',
                    'ssh_host_pub_keys'])
    assert SshPubKeyFactCollector._fact_ids == expected
    assert isinstance(SshPubKeyFactCollector._fact_ids, set)

# Generated at 2022-06-20 20:04:15.036755
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test with key directories that do not exist, return empty dict
    keydirs = ['/does/not/exist', '/etc/ssh', '/etc/openssh', '/etc']
    c = SshPubKeyFactCollector()
    c.collect()
    assert c.collect() == {}, "SshPubKeyFactCollector.collect() should return empty dict"
    # Test with key directories that exist, but have no keys, return empty dict
    keydirs = ['/dev/shm', '/etc/ssh', '/etc/openssh', '/etc']
    assert c.collect() == {}, "SshPubKeyFactCollector.collect() should return empty dict"

# Generated at 2022-06-20 20:04:18.590652
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-20 20:04:21.172090
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:04:27.059036
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fc = SshPubKeyFactCollector()
    assert fc.name == 'ssh_pub_keys'
    assert fc._fact_ids == set(['ssh_host_pub_keys',
                                'ssh_host_key_dsa_public',
                                'ssh_host_key_rsa_public',
                                'ssh_host_key_ecdsa_public',
                                'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:04:30.666334
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    sshPubKeyFactCollector = SshPubKeyFactCollector()
    assert sshPubKeyFactCollector.collect() == {}

# Generated at 2022-06-20 20:04:36.988328
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshpub = SshPubKeyFactCollector()
    assert sshpub.name == 'ssh_pub_keys'
    assert sshpub._fact_ids == set(['ssh_host_pub_keys',
                                    'ssh_host_key_dsa_public',
                                    'ssh_host_key_rsa_public',
                                    'ssh_host_key_ecdsa_public',
                                    'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:04:41.269682
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    inst = SshPubKeyFactCollector()
    inst.collect()
    assert 'ssh_host_pub_keys' in inst.fact_ids
    assert 'ssh_host_key_dsa_public' in inst.fact_ids
    assert 'ssh_host_key_rsa_public' in inst.fact_ids
    assert 'ssh_host_key_ecdsa_public' in inst.fact_ids
    assert 'ssh_host_key_ed25519_public' in inst.fact_ids

# Generated at 2022-06-20 20:04:48.645854
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    result = SshPubKeyFactCollector()
    assert result.name == 'ssh_pub_keys'
    assert result._fact_ids == set(['ssh_host_pub_keys',
                                    'ssh_host_key_dsa_public',
                                    'ssh_host_key_rsa_public',
                                    'ssh_host_key_ecdsa_public',
                                    'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:04:50.343525
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    input = SshPubKeyFactCollector()
    assert isinstance(input, SshPubKeyFactCollector)

# Generated at 2022-06-20 20:05:01.321215
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # mock facts module to substitute self.module
    class facts_module(object):
        def __init__(self, args=None):
            pass

        def get_bin_path(self, bin_path, default=None, opt_dirs=[]):
            return 'usr/bin/openssl'
    test_module = facts_module()

    # mock command module to substitute self.module in method run_command
    class command_module(object):
        def __init__(self, args=None):
            pass

        def run_commands(self, commands=None, check_rc=True):
            return [{'stdout': 'openSSH', 'rc': 0}]

    test_command_module = command_module()

    test_SshPubKeyFactCollector = SshPubKeyFactCollector()
    test_

# Generated at 2022-06-20 20:05:10.235518
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    my_obj = SshPubKeyFactCollector()
    assert my_obj.name == 'ssh_pub_keys'
    assert 'ssh_host_key_dsa_public' in my_obj._fact_ids
    assert 'ssh_host_key_rsa_public' in my_obj._fact_ids
    assert 'ssh_host_key_ecdsa_public' in my_obj._fact_ids
    assert 'ssh_host_key_ed25519_public' in my_obj._fact_ids


# Generated at 2022-06-20 20:05:11.378001
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-20 20:05:16.596067
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert set(SshPubKeyFactCollector._fact_ids) == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:05:22.692580
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    facts = SshPubKeyFactCollector().collect(None, None)
    assert isinstance(facts, dict), "facts is %s" % type(facts)
    assert 'ssh_host_key_rsa_public' in facts, "facts=%s" % facts
    assert 'ssh_host_key_rsa_public_keytype' in facts, "facts=%s" % facts

# Generated at 2022-06-20 20:05:30.925119
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # The next two lines are for unit testing only
    # They are used to setup the fake module and facts.
    module = type('', (), {'params': dict()})()
    module.params = dict()
    module.params['gather_subset'] = ['all']
    collected_facts = {}
    fact_collector = SshPubKeyFactCollector()
    result = fact_collector.collect(module=None, collected_facts=collected_facts)
    assert result == {}

# Generated at 2022-06-20 20:05:38.380201
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact = SshPubKeyFactCollector()
    assert fact.name == 'ssh_pub_keys'
    assert fact._fact_ids == set(['ssh_host_pub_keys',
                                  'ssh_host_key_dsa_public',
                                  'ssh_host_key_rsa_public',
                                  'ssh_host_key_ecdsa_public',
                                  'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:05:47.589940
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # test_module is used as a parameter to use AnsibleModule within the unit test
    test_module = {}

    # Create fakedata for the unit test
    test_data = {'ssh_host_key_rsa_public': ''}

    # create a class instance object with the fakedata
    ssh_pub_key_collector = SshPubKeyFactCollector()
    ssh_pub_key_collector.collect(collected_facts=test_data)

    # assert that ssh key facts where found for the fakedata
    assert test_data['ssh_host_key_rsa_public'] != ''

# Generated at 2022-06-20 20:05:52.037688
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts_collector = SshPubKeyFactCollector()

    ssh_pub_key_facts = ssh_pub_key_facts_collector.collect()

    assert isinstance(ssh_pub_key_facts, dict)
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts


# Generated at 2022-06-20 20:05:59.516740
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # create instance of SshPubKeyFactCollector
    sshPubKeyFactCollector = SshPubKeyFactCollector()
    # verify that instance was created correctly
    assert sshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert sshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:06:00.919676
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    cl_obj = SshPubKeyFactCollector
    cl_obj.collect()

# Generated at 2022-06-20 20:06:10.469316
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # create an instance of the class
    ssh_pub_key_facts = SshPubKeyFactCollector()

    # define dict of pub keys

# Generated at 2022-06-20 20:06:19.657982
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    facts_dict = SshPubKeyFactCollector().collect()

    assert isinstance(facts_dict, dict), "Failed to return a dictionary"
    assert 'ssh_host_key_dsa_public' in facts_dict, "Failed to return a dictionary with 'ssh_host_key_dsa_public'"
    assert 'ssh_host_key_rsa_public' in facts_dict, "Failed to return a dictionary with 'ssh_host_key_rsa_public'"
    assert 'ssh_host_key_ecdsa_public' in facts_dict, "Failed to return a dictionary with 'ssh_host_key_ecdsa_public'"

# Generated at 2022-06-20 20:06:31.339401
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_collector.collect()

    if ssh_pub_key_facts is None:
        assert False, "Collector test failed to return any facts"

    # Testing for some known keys

# Generated at 2022-06-20 20:06:33.505987
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    n = SshPubKeyFactCollector.name
    assert n == "ssh_pub_keys"
    assert n == SshPubKeyFactCollector.name

# Generated at 2022-06-20 20:06:48.440864
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # test_module is a module class from ansible where you can pass
    # parameters and ask for some return values. Here we ask only
    # [0] is the actual return value and [1] is a boolean that says if
    # that value already existed.
    class test_module():
        def __init__(self, exit_json):
            self.exit_json = exit_json

        def get_bin_path(self, arg1, opt_dirs=None):
            return "some_path"

    # mock_ansible_module is a class defined here, at the bottom of this file
    # it is a mock of the module 'ansible' itself

# Generated at 2022-06-20 20:06:54.443381
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:07:01.467164
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == "ssh_pub_keys"
    assert isinstance(obj._fact_ids, set)
    assert 'ssh_host_pub_keys' in obj._fact_ids
    assert 'ssh_host_key_dsa_public' in obj._fact_ids
    assert 'ssh_host_key_rsa_public' in obj._fact_ids
    assert 'ssh_host_key_ecdsa_public' in obj._fact_ids
    assert 'ssh_host_key_ed25519_public' in obj._fact_ids

# Generated at 2022-06-20 20:07:11.970389
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    class MockModule(object):
        def __init__(self):
            self.params = {}

            self.fail_json = lambda a, b: self

    class MockAnsibleModule(object):
        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     check_invalid_arguments=True, mutually_exclusive=None,
                     required_together=None, required_one_of=None,
                     add_file_common_args=False, supports_check_mode=False):

            self.params = {}

            self.fail_json = lambda a, b: self


    class MockOpen(object):
        def __init__(self):
            self.opened = False

        def __call__(self, *args):
            self.opened = True
            return self


# Generated at 2022-06-20 20:07:17.989692
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # create mock module and mock facts
    mock_module = 'ansible.module_utils.facts.collectors.ssh_pub_key.SshPubKeyFactCollector'

# Generated at 2022-06-20 20:07:29.482974
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_class = SshPubKeyFactCollector()

    # sample ssh dsa public key

# Generated at 2022-06-20 20:07:40.744271
# Unit test for constructor of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:07:46.711628
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # create an instance of the SshPubKeyFactCollector class
    sshpubkey = SshPubKeyFactCollector()

    # check that the object was created properly
    assert sshpubkey.name == 'ssh_pub_keys'
    assert sshpubkey._fact_ids == {
        'ssh_host_pub_keys',
        'ssh_host_key_dsa_public',
        'ssh_host_key_rsa_public',
        'ssh_host_key_ecdsa_public',
        'ssh_host_key_ed25519_public'}

# Generated at 2022-06-20 20:07:58.845634
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:08:10.474031
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:08:39.122328
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_obj = SshPubKeyFactCollector()


# Generated at 2022-06-20 20:08:44.252397
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():

    ssh_info_collector = SshPubKeyFactCollector()
    assert ssh_info_collector.name == 'ssh_pub_keys'
    assert ssh_info_collector.priority == 40
    assert ssh_info_collector._fact_ids == set(['ssh_host_pub_keys',
                                                'ssh_host_key_dsa_public',
                                                'ssh_host_key_rsa_public',
                                                'ssh_host_key_ecdsa_public',
                                                'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:08:47.010144
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert isinstance(SshPubKeyFactCollector(), SshPubKeyFactCollector)
    print("Successfully instantiated constructor of class SshPubKeyFactCollector")

# Generated at 2022-06-20 20:08:47.991926
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector()

# Generated at 2022-06-20 20:08:57.180529
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:09:04.840431
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """Unit test for constructor of class SshPubKeyFactCollector"""

    collector = SshPubKeyFactCollector()

    assert collector.name == 'ssh_pub_keys'
    assert collector._fact_ids == set(['ssh_host_pub_keys',
                                       'ssh_host_key_dsa_public',
                                       'ssh_host_key_rsa_public',
                                       'ssh_host_key_ecdsa_public',
                                       'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:09:09.387239
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Check the class variables
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])
    # Check the constructor of class SshPubKeyFactCollector
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector

# Generated at 2022-06-20 20:09:11.171639
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-20 20:09:13.049897
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector
    assert obj.name == 'ssh_pub_keys'


# Generated at 2022-06-20 20:09:16.321459
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector(
            module_loader = None,
            module_name = 'ssh_host_dsa_key.pub',
            module_args = '',
            task_vars = dict()
            )

    assert collector.collect() is not None

# Generated at 2022-06-20 20:10:03.902589
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fixture_path = os.path.join(os.path.dirname(__file__), 'unit', 'module_utils', 'facts', 'fixtures', 'example_ssh_keys')

    collector = SshPubKeyFactCollector()

    with mock.patch('os.path.isdir', return_value=True):
        with mock.patch('os.listdir', return_value=['ssh_host_rsa_key.pub', 'ssh_host_ecdsa_key.pub', 'ssh_host_dsa_key.pub', 'ssh_host_ed25519_key.pub']):
            facts = collector.collect(collected_facts=mock_module.params)

        assert facts['ssh_host_key_rsa_public'] == 'ssh-rsa'

# Generated at 2022-06-20 20:10:07.756785
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """ Unit test for method collect of class SshPubKeyFactCollector
    """
    SshPubKeyFactCollector.collect()

# Generated at 2022-06-20 20:10:11.865199
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = {}
    SshPubKeyFactCollector_obj = SshPubKeyFactCollector()
    ansible_facts_result = SshPubKeyFactCollector_obj.collect(module, collected_facts)
    assert type(ansible_facts_result) is dict
    assert set(ansible_facts_result).issubset(SshPubKeyFactCollector_obj._fact_ids)

# Generated at 2022-06-20 20:10:23.481377
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_fact_collector, SshPubKeyFactCollector)
    assert isinstance(ssh_pub_key_fact_collector, BaseFactCollector)

    assert 'ssh_host_pub_keys' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_fact_collector._fact_ids

# Generated at 2022-06-20 20:10:33.845522
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''
    Unit test for function collect of class SshPubKeyFactCollector
    '''
    class FakeModule(object):
        '''
        A class which imitates AnsibleModule class
        '''
        def __init__(self, gather_subset):
            '''
            Function to initialize instance of FakeModule class
            '''
            self.params = {'gather_subset': gather_subset}
    class FakeFactCollector(BaseFactCollector):
        '''
        A class which imitates BaseFactCollector class
        '''
        def __init__(self, module=None, collected_facts=None):
            '''
            Function to initialize instance of FakeFactCollector class
            '''
            self.name = 'fake fact collector'
            self.module = module
            self.collected_facts

# Generated at 2022-06-20 20:10:38.814845
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c = SshPubKeyFactCollector()
    assert c.name == 'ssh_pub_keys'
    assert c._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:10:48.063101
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # create object
    sshpubkeyfact = SshPubKeyFactCollector()


# Generated at 2022-06-20 20:10:50.416510
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert isinstance(x._fact_ids, set)
    assert len(x._fact_ids) == 5

# Generated at 2022-06-20 20:10:54.805202
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
    Test SshPubKeyFactCollector.collect()
    """
    # test no ssh keys found, should return {}
    # this relies on the test being run as a user who has no ssh
    # keys present in their user home directory, otherwise the
    # test would find ssh keys and return them.
    assert SshPubKeyFactCollector().collect() == {}

# Generated at 2022-06-20 20:10:56.294872
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKeyFactCollector = SshPubKeyFactCollector()



# Generated at 2022-06-20 20:12:31.903276
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    myfact = SshPubKeyFactCollector()
    assert myfact.name == 'ssh_pub_keys'
    assert myfact._fact_ids == set(['ssh_host_pub_keys',
                                    'ssh_host_key_dsa_public',
                                    'ssh_host_key_rsa_public',
                                    'ssh_host_key_ecdsa_public',
                                    'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:12:33.064440
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x

# Generated at 2022-06-20 20:12:34.221183
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector().name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:12:39.774829
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_pub_keys',
        'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public',
        'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:12:46.850234
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:12:53.521609
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:12:55.312309
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshpubkey_fact_collector = SshPubKeyFactCollector()
    assert sshpubkey_fact_collector is not None

# Generated at 2022-06-20 20:13:06.287290
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # class SshPubKeyFactCollector(BaseFactCollector):

    #def collect(self, module=None, collected_facts=None):
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    module = None
    collected_facts = None
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect(module, collected_facts)

    #assert isinstance(ssh_pub_key_facts, dict)
    assert isinstance(ssh_pub_key_facts, dict)
    #assert {'ssh_host_key_rsa_public', 'ssh_host_key_dsa_public', 'ssh_host_key_ecdsa_public'}.issubset(set(ssh_pub_key_facts.keys()))

# Generated at 2022-06-20 20:13:10.351016
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Nothing to test, since the class only has two methods which were
    # inherited from BaseFactCollector.
    pass

# Generated at 2022-06-20 20:13:17.687047
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # host_pub_keys is a list, with one entry per public key type
    # each entry is a dict with a key 'keytype' and a key 'data'
    # data is the public key, as a string
    import os
    from ansible.module_utils.facts.utils import get_file_content

    # make get_file_content return one key for each algo
    keys = dict()
    for algo in ('dsa', 'rsa', 'ecdsa', 'ed25519'):
        keys[algo] = {'keytype': 'fookeytype', 'data': 'fookeydata'}

    def keyfile(filename):
        algo = os.path.basename(filename).split("_")[3]