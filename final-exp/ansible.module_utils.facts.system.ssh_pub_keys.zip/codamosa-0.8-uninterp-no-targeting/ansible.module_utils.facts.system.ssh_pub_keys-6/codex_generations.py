

# Generated at 2022-06-20 20:03:56.435206
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    testobj = SshPubKeyFactCollector()
    testobj.collect()
    assert testobj.facts['ssh_host_key_ecdsa_public'] == "AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBA5+JV0QJjKf1OaV1+W8vaXoVJu5pOjv+R0yW8eOmV7B0FuwvCB+7dW8fXudVcoLdpFtjxQs3q8ycNzmIbMMaFkA="

# Generated at 2022-06-20 20:04:00.499422
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class dummy_module:
        def __init__(self):
            self.params = {}
    my_module = dummy_module()
    my_module.params['gather_subset'] = ['!all', 'ssh']
    my_ssh_pub_keys = SshPubKeyFactCollector(module=my_module)
    rslt = my_ssh_pub_keys.collect(my_module)
    assert(type(rslt) is dict)

# Generated at 2022-06-20 20:04:03.550794
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fc = SshPubKeyFactCollector()
    assert (ssh_pub_key_fc.name == 'ssh_pub_keys')

# Generated at 2022-06-20 20:04:04.556934
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
  	SshPubKeyFactCollector()

# Generated at 2022-06-20 20:04:07.616869
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshkeys = SshPubKeyFactCollector()
    assert 'ssh_host_pub_keys' in sshkeys._fact_ids

# Generated at 2022-06-20 20:04:10.713185
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():

  # Test the constructor
  ssh_pub_key_collector_object = SshPubKeyFactCollector()
  assert ssh_pub_key_collector_object.name == "ssh_pub_keys"

# Generated at 2022-06-20 20:04:21.124704
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert len(ssh_pub_key_fact_collector._fact_ids) == 5
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_pub_keys'

# Generated at 2022-06-20 20:04:22.680251
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()

# Generated at 2022-06-20 20:04:25.857024
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_collector._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:04:34.991745
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils import basic

    # mock module as we don't need it, we only need its base class to mock
    # the argument parsing, which happens in its ancestor
    mock_module = basic.AnsibleModule(argument_spec={})

    # mock collected facts for the same reason as above
    mock_collected_facts = {}

    # instantiate the class under test
    ssh_pub_key_fact_collector = SshPubKeyFactCollector(mock_module)

    # test with no key files found, return empty dictionary
    assert ssh_pub_key_fact_collector.collect(mock_module, mock_collected_facts) == {}

# Generated at 2022-06-20 20:04:43.483107
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    collector = Collector()
    sshpubkey_collector = SshPubKeyFactCollector()
    sshpubkey_fact = sshpubkey_collector.collect()
    assert sshpubkey_fact['ssh_host_key_rsa_public'].startswith('AAAAB3N')
    assert sshpubkey_fact['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa'

# Generated at 2022-06-20 20:04:45.742373
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    SshPubKeyFactCollector = SshPubKeyFactCollector()
    SshPubKeyFactCollector.collect()

# Generated at 2022-06-20 20:04:56.149949
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    from ansible.utils.path import unfrackpath

    testdir = unfrackpath(os.path.dirname(__file__))

    mock_configs = {}
    for item in os.listdir("%s/data/ssh_pub_key_facts" % testdir):
        module, result, facts_key = item.split("_")
        path = "%s/data/ssh_pub_key_facts/%s" % (testdir, item)
        config = get_file_content(path)
        if config is None:
            continue
        mock_configs[(module, result)] = config

    # mocks

# Generated at 2022-06-20 20:04:57.837919
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector1 = SshPubKeyFactCollector({}, {})
    collector1.collect()


# Generated at 2022-06-20 20:05:06.377139
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create a new instance of SshPubKeyFactCollector.
    collector = SshPubKeyFactCollector()

    # The returned facts should be a dictionary with the following contents.

# Generated at 2022-06-20 20:05:16.015592
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
# Create a mock module and assign the module_utils.facts.utils.get_file_content method
# the test_get_file_content function
    module = Mock()
    module.get_bin_path.return_value = '/etc/ssh'
    module.run_command.return_value = 1
    module.module_utils.facts.utils.get_file_content = test_get_file_content

# create an instance of the SshPubKeyFactCollector class
    ssh_pub_key_collector = SshPubKeyFactCollector()
    ssh_pub_key_collector.collect(module)


# function to mock the

# Generated at 2022-06-20 20:05:26.769780
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:05:30.896614
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshkey_facts = SshPubKeyFactCollector()
    assert sshkey_facts.name == 'ssh_pub_keys'
    assert sshkey_facts.fact_ids == set(['ssh_host_pub_keys',
                                         'ssh_host_key_dsa_public',
                                         'ssh_host_key_rsa_public',
                                         'ssh_host_key_ecdsa_public',
                                         'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:05:41.908674
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()

    assert collector.name == 'ssh_pub_keys'
    assert set(collector.fact_ids()) == set(['ssh_host_pub_keys',
                                             'ssh_host_key_dsa_public',
                                             'ssh_host_key_rsa_public',
                                             'ssh_host_key_ecdsa_public',
                                             'ssh_host_key_ed25519_public'])

    expected_ssh_host_key_dsa_public_fact = {}
    expected_ssh_host_key_rsa_public_fact = {}
    expected_ssh_host_key_ecdsa_public_fact = {}
    expected_ssh_host_key_ed25519_public_fact = {}

    expected_ssh_host_key

# Generated at 2022-06-20 20:05:45.279748
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert len(ssh_pub_key_collector._fact_ids) == 5

# Generated at 2022-06-20 20:05:58.804503
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshpubkey_fact_collector = SshPubKeyFactCollector()
    assert sshpubkey_fact_collector.name == 'ssh_pub_keys'
    assert sshpubkey_fact_collector._fact_ids == set([
        'ssh_host_pub_keys',
        'ssh_host_key_dsa_public',
        'ssh_host_key_rsa_public',
        'ssh_host_key_ecdsa_public',
        'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:06:03.121436
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    o = SshPubKeyFactCollector()
    assert o.name == 'ssh_pub_keys'
    assert o._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:06:07.207570
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Test with module argument
    collector = SshPubKeyFactCollector()

    module = 'ansible.module_utils.facts.collector.base'
    facts_dict = {}
    ssh_pub_key_facts = collector.collect(module=module, collected_facts=facts_dict)

    assert ssh_pub_key_facts is not None
    assert isinstance(ssh_pub_key_facts, dict)

# Generated at 2022-06-20 20:06:15.379341
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                                        'ssh_host_key_dsa_public',
                                                        'ssh_host_key_rsa_public',
                                                        'ssh_host_key_ecdsa_public',
                                                        'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:06:20.738853
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import collector
    collector.add_collector(SshPubKeyFactCollector)
    collected_facts = collector.collect(
        module=None, collected_facts=None,
        filter_whitelist=['ssh_pub_keys'])
    assert collected_facts['ssh_pub_keys']
    assert collected_facts['ssh_pub_keys']['ssh_host_key_rsa_public']
    assert collected_facts['ssh_pub_keys']['ssh_host_key_ed25519_public']

# Generated at 2022-06-20 20:06:28.021402
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    test_obj = SshPubKeyFactCollector()
    assert test_obj
    assert test_obj.name == 'ssh_pub_keys'
    assert test_obj._fact_ids == set(['ssh_host_pub_keys',
                                      'ssh_host_key_dsa_public',
                                      'ssh_host_key_rsa_public',
                                      'ssh_host_key_ecdsa_public',
                                      'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:06:37.885945
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes
    import os
    import pytest
    import tempfile


# Generated at 2022-06-20 20:06:42.819044
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:06:43.323428
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-20 20:06:44.846215
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-20 20:07:00.634905
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.ssh_pub_keys import SshPubKeyFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

    # mock module which will be passed to get_file_content function
    # so it won't call the filesystem but use predefined mocked data
    class MockModule:
        def __init__(self):
            self.params = {'gather_subset': 'network,!omit'}

    # mock files of interest

# Generated at 2022-06-20 20:07:11.080793
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    obj = SshPubKeyFactCollector()

    # Test empty input => output
    assert obj.collect() == {}

    # Test single-value input => output

# Generated at 2022-06-20 20:07:15.939606
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Arrange
    fc = SshPubKeyFactCollector()
    # Act
    fc.collect()
    # Assert
    assert len(fc.facts) > 0
    for fact in fc.facts:
        assert fact.startswith('ssh_host_key')



# Generated at 2022-06-20 20:07:23.520345
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.utils import get_file_content

    original_value = get_file_content
    get_file_content = lambda x: x
    f = Facts()
    try:
        assert isinstance(f.collector, Collector)
        assert isinstance(f.collector, SshPubKeyFactCollector)
    finally:
        get_file_content = original_value

# Generated at 2022-06-20 20:07:32.802347
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    print("Testing SshPubKeyFactCollector()")
    sshPubKeyFactCollector = SshPubKeyFactCollector()

    assert(sshPubKeyFactCollector.name == 'ssh_pub_keys')
    assert(sshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public']))


# Generated at 2022-06-20 20:07:43.792125
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:07:46.464831
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key = SshPubKeyFactCollector()
    ssh_pub_key.collect()
    assert ssh_pub_key.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:07:51.641745
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ''' SshPubKeyFactCollector() creates an object of
        type SshPubKeyFactCollector
    '''
    o_SshPubKeyFactCollector = SshPubKeyFactCollector()
    assert isinstance(o_SshPubKeyFactCollector, SshPubKeyFactCollector)

# Generated at 2022-06-20 20:07:54.526685
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.collect() == {}

# Generated at 2022-06-20 20:07:58.846288
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # positive test
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'
    # negative test
    collector = SshPubKeyFactCollector()
    assert collector.name != 'ssh_pub_keys123'

# Generated at 2022-06-20 20:08:18.393321
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector = SshPubKeyFactCollector()
    assert fact_collector.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:08:24.677185
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    foo = SshPubKeyFactCollector()
    assert foo.name == 'ssh_pub_keys'
    assert foo._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])

    #def collect(self, module=None, collected_facts=None):

# Generated at 2022-06-20 20:08:30.335108
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    assert isinstance(ssh_pub_key_facts, dict)
    assert len(ssh_pub_key_facts) > 0
    assert len(ssh_pub_key_facts) == 10
    assert isinstance(ssh_pub_key_facts['ssh_host_key_ecdsa_public'], str)
    assert isinstance(ssh_pub_key_facts['ssh_host_key_rsa_public'], str)
    assert isinstance(ssh_pub_key_facts['ssh_host_key_dsa_public'], str)
    assert isinstance(ssh_pub_key_facts['ssh_host_key_ed25519_public'], str)

# Generated at 2022-06-20 20:08:39.996366
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    m = SshPubKeyFactCollector()
    expected_facts = {
        "ssh_host_key_dsa_public": "DSS-1024-blahblahblah",
        "ssh_host_key_rsa_public": "RSA-1024-blahblahblah",
        "ssh_host_key_ecdsa_public": "ECDSA-256-blahblahblah",
        "ssh_host_key_ed25519_public": "ED25519-256-blahblahblah",
    }
    facts = m.collect(collected_facts={'fake': 'fake'})
    for factname in expected_facts:
        assert expected_facts[factname] == facts[factname]

# Generated at 2022-06-20 20:08:41.403823
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:08:43.685563
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    SshPubKeyFactCollector()

# Generated at 2022-06-20 20:08:53.342032
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test = SshPubKeyFactCollector()

    # create a stub for method get_file_content
    def get_file_content(filename):
        return 'ssh-%s %s' % (filename.split('_')[3], filename)

    # create stub for self.collect_file_if_exists
    test.collect_file_if_exists = get_file_content


# Generated at 2022-06-20 20:09:00.001942
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class mockMod:
        pass
    class mockCollectedFacts:
        pass
    class mockGetFileContent:
        def __init__(self, myfile):
            self.myfile = myfile
            self.called = False
        def __call__(self, filename):
            self.called = True
            assert(self.myfile == filename)
            if filename == '/etc/ssh/ssh_host_rsa_key.pub':
                return 'ssh-rsa AAAA1234567890'
            elif filename == '/etc/ssh/ssh_host_ecdsa_key.pub':
                return 'ecdsa-sha2-nistp256 AAAA1234567890'

# Generated at 2022-06-20 20:09:06.983948
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content as gfc
    from ansible.module_utils.facts.collector.ssh_pub_key import SshPubKeyFactCollector
    import os, tempfile

    test_keydir = tempfile.mkdtemp()
    os.mkdir(os.path.join(test_keydir, "ssh"))
    os.mkdir(os.path.join(test_keydir, "openssh"))
    os.mkdir(os.path.join(test_keydir, "ssh_unreadable"))
    os.mkdir(os.path.join(test_keydir, "openssh_unreadable"))
    os.mkdir(os.path.join(test_keydir, "unreadable"))


# Generated at 2022-06-20 20:09:16.375774
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    testFacts = SshPubKeyFactCollector()
    assert testFacts.name == 'ssh_pub_keys'
    assert testFacts._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])
    assert testFacts.priority == 60
    assert testFacts.optional_facts == set([])


# Generated at 2022-06-20 20:09:55.844733
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == "ssh_pub_keys"
    assert SshPubKeyFactCollector._fact_ids == set(["ssh_host_pub_keys",
                                                    "ssh_host_key_dsa_public",
                                                    "ssh_host_key_rsa_public",
                                                    "ssh_host_key_ecdsa_public",
                                                    "ssh_host_key_ed25519_public"])

# Generated at 2022-06-20 20:09:57.233708
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    obj.__init__()

# Generated at 2022-06-20 20:10:03.297375
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:10:13.461558
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    import shutil
    import json
    from ansible.module_utils.facts import FactCollector

    # test data - uses the 'keytype key' format

# Generated at 2022-06-20 20:10:21.480491
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts._fact_ids == {'ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'}
    assert ssh_pub_key_facts.name == "ssh_pub_keys"


# Generated at 2022-06-20 20:10:30.714609
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    '''Unit test for constructor of class SshPubKeyFactCollector'''
    test_collector = SshPubKeyFactCollector()
    assert test_collector.name == 'ssh_pub_keys'
    assert set(test_collector._fact_ids) == set(('ssh_host_pub_keys',
                                                 'ssh_host_key_dsa_public',
                                                 'ssh_host_key_rsa_public',
                                                 'ssh_host_key_ecdsa_public',
                                                 'ssh_host_key_ed25519_public'))

# Generated at 2022-06-20 20:10:37.053281
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts._fact_ids == set(['ssh_host_pub_keys',
                                               'ssh_host_key_dsa_public',
                                               'ssh_host_key_rsa_public',
                                               'ssh_host_key_ecdsa_public',
                                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:10:39.508933
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    '''Test constructor of SshPubKeyFactCollector'''
    obj = SshPubKeyFactCollector()


# Generated at 2022-06-20 20:10:43.489322
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collect = SshPubKeyFactCollector()
    # test private member values
    assert collect.name == 'ssh_pub_keys'
    assert collect._fact_ids == set(['ssh_host_pub_keys',
                             'ssh_host_key_dsa_public',
                             'ssh_host_key_rsa_public',
                             'ssh_host_key_ecdsa_public',
                             'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:10:51.504142
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create a ModuleStub to collect facts
    class ModuleStub:
        def __init__(self, tmp_dir):
            self.tmp_dir = tmp_dir

        # Produce a mock run_command
        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            return (0, '', '')

        # Produce a mock set_module_args
        def set_module_args(self, args):
            pass

        # Produce a mock get_bin_path
        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            return '/bin/' + arg

        # Produce a mock fail_json

# Generated at 2022-06-20 20:12:08.006668
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector.collect() != 'ssh_pub_keys'

# Generated at 2022-06-20 20:12:12.044557
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():

    collector = SshPubKeyFactCollector()

    assert collector.name == 'ssh_pub_keys'
    assert collector._fact_ids == set(['ssh_host_pub_keys',
                                       'ssh_host_key_dsa_public',
                                       'ssh_host_key_rsa_public',
                                       'ssh_host_key_ecdsa_public',
                                       'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:12:16.703034
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # setup
    myCollector = SshPubKeyFactCollector()
    myCollector.mock_get_file_content = mock_get_file_content

    # test
    method = myCollector.collect
    collected_facts = {}
    assertion = myCollector._fact_ids
    ssh_pub_key_facts = method(collected_facts)

    # assert
    assert_ssh_pub_key_facts(ssh_pub_key_facts, assertion)


# Generated at 2022-06-20 20:12:26.382646
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    #
    # Test #1:
    # Check that facts ssh_host_key_dsa_public, ssh_host_key_rsa_public,
    # ssh_host_key_ecdsa_public and ssh_host_key_ed25519_public  are
    # collected and are not None when values are present in
    # ssh_host_{dsa,rsa,ecdsa,ed25519}_key.pub files.
    #
    fact_collector = SshPubKeyFactCollector()

    # Set the content of files ssh_host_{dsa,rsa,ecdsa,ed25519}_key.pub

# Generated at 2022-06-20 20:12:32.305063
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector = SshPubKeyFactCollector()
    assert fact_collector.name == 'ssh_pub_keys'
    assert fact_collector._fact_ids == set([
        'ssh_host_pub_keys',
        'ssh_host_key_dsa_public',
        'ssh_host_key_rsa_public',
        'ssh_host_key_ecdsa_public',
        'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:12:34.376009
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # This is just a smoke test to ensure that the constructor is working correctly
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:12:38.795147
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])
    assert obj.collect() == {}

# Generated at 2022-06-20 20:12:46.231893
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    from ansible.module_utils.facts.utils import get_file_content

    # remove function get_file_content from module utils for testing purposes
    # and replace it with a dummy function
    delattr(SshPubKeyFactCollector, get_file_content)


# Generated at 2022-06-20 20:12:52.575322
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    sc = SshPubKeyFactCollector()
    facts = sc.collect()
    assert facts is not None
    assert len(facts.keys()) >= 1
    assert isinstance(facts['ssh_host_key_rsa_public'], type(''))
    assert isinstance(facts['ssh_host_key_rsa_public_keytype'], type(''))
    assert facts['ssh_host_key_dsa_public'] is None

# Generated at 2022-06-20 20:13:03.056692
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # create a module and a collector
    module = MagicMock()
    collector = SshPubKeyFactCollector(module=module)

    # create a set of mocked contents
    data = {}