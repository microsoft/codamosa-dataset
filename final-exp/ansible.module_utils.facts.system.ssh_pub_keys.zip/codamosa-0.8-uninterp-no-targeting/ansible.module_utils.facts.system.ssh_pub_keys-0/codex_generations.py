

# Generated at 2022-06-20 20:03:48.368188
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:03:53.655968
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    result = SshPubKeyFactCollector()
    assert result is not None
    assert result.name == 'ssh_pub_keys'
    assert result._fact_ids == set(['ssh_host_pub_keys',
                                    'ssh_host_key_dsa_public',
                                    'ssh_host_key_rsa_public',
                                    'ssh_host_key_ecdsa_public',
                                    'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:03:58.108255
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from .. import get_collector_instance

    # Initialize a instance of the SshPubKeyFactCollector
    collector = get_collector_instance(SshPubKeyFactCollector)
    assert isinstance(collector, SshPubKeyFactCollector)

    # Verify that the facts collected by the SshPubKeyFactCollector
    # after initialization is empty
    assert collector.collect() == {}

# Generated at 2022-06-20 20:04:00.496968
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert len(ssh_pub_key_facts._fact_ids) == 5



# Generated at 2022-06-20 20:04:10.142870
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts._fact_ids == set(['ssh_host_pub_keys',
                                               'ssh_host_key_dsa_public',
                                               'ssh_host_key_rsa_public',
                                               'ssh_host_key_ecdsa_public',
                                               'ssh_host_key_ed25519_public'])



# vim: set et ts=4 sw=4:

# Generated at 2022-06-20 20:04:11.682663
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:04:23.189840
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKeyFactsCollector = SshPubKeyFactCollector()
    assert sshPubKeyFactsCollector.name == 'ssh_pub_keys'
    assert sshPubKeyFactsCollector._fact_ids == set(['ssh_host_pub_keys',
                                                     'ssh_host_key_dsa_public',
                                                     'ssh_host_key_rsa_public',
                                                     'ssh_host_key_ecdsa_public',
                                                     'ssh_host_key_ed25519_public'])



# Generated at 2022-06-20 20:04:26.018114
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_key_fact_collector = SshPubKeyFactCollector()
    module = AnsibleModule(argument_spec={})
    collected_facts = {'vendor': {'os': 'RedHat'}}
    res = ssh_key_fact_collector.collect(module, collected_facts)
    assert('ssh_host_key_rsa_public' in res)
    assert('ssh_host_key_rsa_public_keytype' in res)


# Generated at 2022-06-20 20:04:32.916799
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector().name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector()._fact_ids == set(['ssh_host_pub_keys',
                                                      'ssh_host_key_dsa_public',
                                                      'ssh_host_key_rsa_public',
                                                      'ssh_host_key_ecdsa_public',
                                                      'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:04:34.341768
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

# Generated at 2022-06-20 20:04:37.609634
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    SshPubKeyFactCollector().collect()

# Generated at 2022-06-20 20:04:43.277690
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    '''Check constructor of class SshPubKeyFactCollector'''
    c = SshPubKeyFactCollector()
    assert c.name == 'ssh_pub_keys'
    assert c._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:04:54.241450
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network.ssh_pub_key import SshPubKeyFactCollector
    import shutil

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()
    tmp_ssh_dir = os.path.join(tmpdir, 'ssh')
    os.mkdir(tmp_ssh_dir)

    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    pubkeys = ('AAAA', 'BBBB', 'CCCC', 'DDDD')

# Generated at 2022-06-20 20:04:54.810958
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-20 20:05:04.634432
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:05:16.356422
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Prepare a test fixture
    class MockFs(object):
        def __init__(self, files):
            self.files = files

        def get_file_content(self, filename, default=None, strip=False):
            if filename in self.files:
                return self.files[filename]
            return default


# Generated at 2022-06-20 20:05:18.567178
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert hasattr(SshPubKeyFactCollector, 'name')
    assert hasattr(SshPubKeyFactCollector, '_fact_ids')

# Generated at 2022-06-20 20:05:20.364365
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.ss

# Generated at 2022-06-20 20:05:29.330442
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create SshPubKeyFactCollector object
    obj = SshPubKeyFactCollector()

    # Get ssh_host_key_ecdsa_public facts using get_file_content method
    obj.get_file_content = lambda x: "\
ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIGx0sc2sE9XkMtjHZ1vMw1dMb21TC+zPxr0\
GnB/F myhost"

    # Get facts
    facts = obj.collect()

    # Check facts

# Generated at 2022-06-20 20:05:30.544739
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()


# Generated at 2022-06-20 20:05:40.844065
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact = SshPubKeyFactCollector()
    assert ssh_pub_key_fact.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact._fact_ids == set(['ssh_host_pub_keys',
                                              'ssh_host_key_dsa_public',
                                              'ssh_host_key_rsa_public',
                                              'ssh_host_key_ecdsa_public',
                                              'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:05:49.925702
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    facts = collector.collect()

    # the file content is a mock, actual content might differ
    assert facts['ssh_host_key_dsa_public'] == 'AAAAB3NzaC1kc3MAAACBAK6wsZ+6KZFHpA1PiDzFw/yUyoHxU/'
    assert facts['ssh_host_key_rsa_public'] == 'AAAAB3NzaC1yc2EAAAADAQABAAABAQDkFKZrTLnBm2lBKYdzmRwY'

# Generated at 2022-06-20 20:05:56.499522
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh = SshPubKeyFactCollector()
    assert ssh.name == 'ssh_pub_keys'
    assert set(ssh._fact_ids) == set(['ssh_host_pub_keys',
                                      'ssh_host_key_dsa_public',
                                      'ssh_host_key_rsa_public',
                                      'ssh_host_key_ecdsa_public',
                                      'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:06:07.541567
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:06:14.137183
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # Test with no ssh keys
    module_facts = dict()
    c = SshPubKeyFactCollector()
    c.collect(module_facts=module_facts)
    assert len(module_facts) == 0

    # Test with some ssh keys
    module_facts = dict()
    c = SshPubKeyFactCollector()
    c.collect(module_facts=module_facts)
    assert len(module_facts) == 0

# Generated at 2022-06-20 20:06:21.770381
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    '''test class SshPubKeyFactCollector'''
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    import shutil
    import tempfile

    tempdir = tempfile.mkdtemp()
    Collector.module_cache_dir = tempdir

# Generated at 2022-06-20 20:06:28.658566
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    s = SshPubKeyFactCollector()
    assert s.name == 'ssh_pub_keys'
    assert s._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])
    assert s.collect() == {}

# Generated at 2022-06-20 20:06:38.266859
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Set of variables initialized to empty dicts.
    # Replace with real values if testing with an existing file and/or facts
    # under test.

    # Create a fake file populated with test data
    with open(temp_file, 'w') as f:
        f.write(test_data)

    test_args = dict(
        module=None,
        collected_facts={},
    )

    result = SshPubKeyFactCollector(None).collect(**test_args)


# Generated at 2022-06-20 20:06:46.390952
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import mock

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import utils


# Generated at 2022-06-20 20:06:56.891588
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    def test_collect(self, module=None, collected_facts=None):
        return {'old_fact': 'old_fact_value'}

    orig_collect_subclass = BaseFactCollector.collect
    BaseFactCollector.collect = test_collect

    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')

    # list of directories to check for ssh keys
    # used in the order listed here, the first one with keys is used
    keydirs = ['/etc/ssh', '/etc/openssh', '/etc']


# Generated at 2022-06-20 20:07:08.329906
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshpubkey_fact = SshPubKeyFactCollector()
    assert sshpubkey_fact.name == 'ssh_pub_keys'
    assert sshpubkey_fact._fact_ids == set(['ssh_host_pub_keys',
                                            'ssh_host_key_dsa_public',
                                            'ssh_host_key_rsa_public',
                                            'ssh_host_key_ecdsa_public',
                                            'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:07:18.823231
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Test collect method for SshPubKeyFactCollector class"""

    # Mock a module
    #
    module = type('AnsibleModule', (object,), {})

    # Mock a get_file_content function
    #

# Generated at 2022-06-20 20:07:30.230045
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:07:35.414155
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector = SshPubKeyFactCollector()
    assert fact_collector._fact_ids == {'ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public',
                                        'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'}

# Generated at 2022-06-20 20:07:36.173244
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-20 20:07:45.948303
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # unit test for exception (no keys found)
    keydirs = []
    algos = []
    for keydir in keydirs:
        for algo in algos:
            key_filename = '%s/ssh_host_%s_key.pub' % (keydir, algo)
            keydata = get_file_content(key_filename)
            if keydata is not None:
                (keytype, key) = keydata.split()[0:2]
    # unit test for key found
    keydirs = ['/etc/ssh']
    algos = []
    for keydir in keydirs:
        for algo in algos:
            key_filename = '%s/ssh_host_%s_key.pub' % (keydir, algo)
            keydata = get

# Generated at 2022-06-20 20:07:58.011886
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """
    This is an internal interface unit test.
    """
    import inspect
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert inspect.ismethod(ssh_pub_key_fact_collector.collect)

    # Test if the ids of the facts collected by the collector are correct
    assert len(ssh_pub_key_fact_collector._fact_ids) == 5
    assert 'ssh_host_pub_keys' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_fact_collector._fact_ids
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_fact_collector._fact_ids

# Generated at 2022-06-20 20:08:10.258639
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:08:16.435974
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collect = SshPubKeyFactCollector()
    assert ssh_pub_key_collect is not None
    assert ssh_pub_key_collect.name == "ssh_pub_keys"
    assert ssh_pub_key_collect._fact_ids == set(['ssh_host_pub_keys',
                                                 'ssh_host_key_dsa_public',
                                                 'ssh_host_key_rsa_public',
                                                 'ssh_host_key_ecdsa_public',
                                                 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:08:21.928105
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    mock_module = type('MockModule', (object,), {'check_mode': False})
    mock_collected_facts = {}
    ssh_pub_key_collector = SshPubKeyFactCollector()
    ssh_pub_keys = ssh_pub_key_collector.collect(mock_module,
                                                 mock_collected_facts)
    assert ssh_pub_keys['ssh_host_key_dsa_public']



# Generated at 2022-06-20 20:08:37.793758
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    options = None
    collected_facts = None
    ssh_pub_key_facts = collector.collect(options, collected_facts)

    assert isinstance(ssh_pub_key_facts, dict)
    for fact in ssh_pub_key_facts:
        assert isinstance(ssh_pub_key_facts[fact], str)

# Generated at 2022-06-20 20:08:41.185067
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """Create an instance of class SshPubKeyFactCollector and confirm that
    ssh_pub_key_facts is a member of the class.
    """
    my_obj = SshPubKeyFactCollector()
    assert hasattr(my_obj, 'ssh_pub_key_facts')
# Unit test confirmation done.

# Generated at 2022-06-20 20:08:52.402330
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:08:59.947777
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.collectors import which

    if not which('ssh-keygen'):
        pytest.skip("ssh-keygen is required for this test")
    import tempfile
    import shutil

    d = tempfile.mkdtemp()

# Generated at 2022-06-20 20:09:05.922028
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact = SshPubKeyFactCollector()
    assert ssh_pub_key_fact.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact._fact_ids == set(['ssh_host_pub_keys',
                                              'ssh_host_key_dsa_public',
                                              'ssh_host_key_rsa_public',
                                              'ssh_host_key_ecdsa_public',
                                              'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:09:07.454320
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """Test class SshPubKeyFactCollector"""
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:09:16.407048
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                                        'ssh_host_key_dsa_public',
                                                        'ssh_host_key_rsa_public',
                                                        'ssh_host_key_ecdsa_public',
                                                        'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:09:17.562990
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    assert SshPubKeyFactCollector.collect(None) == None

# Generated at 2022-06-20 20:09:23.256162
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c = SshPubKeyFactCollector()
    assert c.name == 'ssh_pub_keys'
    assert c._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:09:32.871359
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj.fact_dir_path == '/etc/ansible/facts.d/'
    assert obj.fact_filename == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:10:02.757004
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
    Test the collect method of the SshPubKeyFactCollector class
    """
    collector = SshPubKeyFactCollector()
    facts = collector.collect(module=None, collected_facts=None)
    assert facts is not None, "Facts should never be None"
    assert isinstance(facts, dict), "Facts are a dictionary"
    assert len(facts.keys()) > 0, "There should be at least one fact"
    assert facts['ssh_host_key_rsa_public'] is not None, \
        "The rsa public key value should not be None"
    assert facts['ssh_host_key_rsa_public_keytype'] is not None, \
        "The rsa public keytype value should not be None"

# Generated at 2022-06-20 20:10:06.504480
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()

# Generated at 2022-06-20 20:10:08.496284
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'


# Generated at 2022-06-20 20:10:12.907316
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector(): 
    test_sshpubkey= SshPubKeyFactCollector()
    assert test_sshpubkey.name == 'ssh_pub_keys'
    assert test_sshpubkey._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:10:17.441644
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector.collect()



# Generated at 2022-06-20 20:10:21.375889
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # verify test name is correct
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'

    # verify all fact ids are present
    assert set(SshPubKeyFactCollector.fact_ids) == SshPubKeyFactCollector._fact_ids

# Generated at 2022-06-20 20:10:29.746734
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    d = SshPubKeyFactCollector()
    assert d.name == 'ssh_pub_keys'
    assert d._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])

# vim: set expandtab: ts=4: sw=4:

# Generated at 2022-06-20 20:10:36.785589
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_collector.priority == 50
    assert ssh_pub_key_collector._fact_ids == set(['ssh_host_pub_keys',
                                                   'ssh_host_key_dsa_public',
                                                   'ssh_host_key_rsa_public',
                                                   'ssh_host_key_ecdsa_public',
                                                   'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:10:39.374660
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector is not None
    assert ssh_pub_key_fact_collector._fact_ids is not None

# Generated at 2022-06-20 20:10:48.198916
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    testcollector = SshPubKeyFactCollector()
    facts = testcollector.collect()

    assert facts['ssh_host_key_rsa_public'] is None
    assert 'ssh_host_key_rsa_public_keytype' not in facts

    assert facts['ssh_host_key_dsa_public'] is None
    assert 'ssh_host_key_dsa_public_keytype' not in facts

    assert facts['ssh_host_key_ecdsa_public'] is None
    assert 'ssh_host_key_ecdsa_public_keytype' not in facts

    assert facts['ssh_host_key_ed25519_public'] is None
    assert 'ssh_host_key_ed25519_public_keytype' not in facts

    assert facts['ssh_host_pub_keys'] is None

# Generated at 2022-06-20 20:11:38.547984
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    keydir = '/etc/ssh'

    for algo in ('dsa', 'rsa', 'ecdsa', 'ed25519'):
        factname = 'ssh_host_key_%s_public' % algo
        factname_keytype = factname + '_keytype'

        key_filename = '%s/ssh_host_%s_key.pub' % (keydir, algo)

# Generated at 2022-06-20 20:11:40.009773
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:11:49.997552
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Instantiate mock objects for testing
    class MockModule(object):
        def __init__(self):
            self.fail_json = lambda exc: str(exc)

    mock_module = MockModule()

    # Instantiate SshPubKeyFactCollector object
    collector = SshPubKeyFactCollector()

    # Test fact collect method

# Generated at 2022-06-20 20:11:55.288698
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh=SshPubKeyFactCollector()
    assert ssh.name == 'ssh_pub_keys'
    assert 'ssh_host_pub_keys' in ssh._fact_ids
    assert 'ssh_host_key_dsa_public' in ssh._fact_ids
    assert 'ssh_host_key_rsa_public' in ssh._fact_ids
    assert 'ssh_host_key_ecdsa_public' in ssh._fact_ids
    assert 'ssh_host_key_ed25519_public' in ssh._fact_ids

# Generated at 2022-06-20 20:12:00.180554
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    from ansible.module_utils.facts.collector import Collector
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_collector, Collector)
    assert 'ssh_host_pub_keys' in ssh_pub_key_collector._fact_ids
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_collector._fact_ids
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_collector._fact_ids
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_collector._fact_ids
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_collector._fact_ids

# Generated at 2022-06-20 20:12:01.843360
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == "ssh_pub_keys"


# Generated at 2022-06-20 20:12:03.575472
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert issubclass(SshPubKeyFactCollector, BaseFactCollector)

# Generated at 2022-06-20 20:12:07.346738
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()


# Generated at 2022-06-20 20:12:12.311083
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector = SshPubKeyFactCollector()
    assert fact_collector is not None
    assert fact_collector.name == 'ssh_pub_keys'
    assert set(fact_collector._fact_ids) == set(['ssh_host_pub_keys',
                                                 'ssh_host_key_dsa_public',
                                                 'ssh_host_key_rsa_public',
                                                 'ssh_host_key_ecdsa_public',
                                                 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:12:15.700464
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    '''unit test for constructor of class SshPubKeyFactCollector'''
    collector = SshPubKeyFactCollector()
    assert isinstance(collector, SshPubKeyFactCollector)
    for attr in ('name', '_fact_ids'):
        assert hasattr(collector, attr)