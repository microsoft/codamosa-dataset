

# Generated at 2022-06-20 20:03:48.022353
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert 'ssh_pub_keys' == x.name
    assert 'ssh_host_pub_keys' in x._fact_ids
    assert 'ssh_host_key_dsa_public' in x._fact_ids
    assert 'ssh_host_key_rsa_public' in x._fact_ids
    assert 'ssh_host_key_ecdsa_public' in x._fact_ids
    assert 'ssh_host_key_ed25519_public' in x._fact_ids

# Generated at 2022-06-20 20:03:56.840856
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:04:00.801422
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fake_module = type('module', (), {})
    fake_module.params = {}
    ssh_pub_key_facts = SshPubKeyFactCollector().collect(fake_module)
    assert ssh_pub_key_facts is not None
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts

# Generated at 2022-06-20 20:04:12.628633
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # Create a class instance
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # Create a dictionary containing input data
    collected_facts = {}

    # Create a dictionary containing expected results

# Generated at 2022-06-20 20:04:19.714363
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_collector._fact_ids == set(['ssh_host_pub_keys',
                                                   'ssh_host_key_dsa_public',
                                                   'ssh_host_key_rsa_public',
                                                   'ssh_host_key_ecdsa_public',
                                                   'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:04:28.814588
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    import sys
    import os

    my_module = sys.modules[__name__]
    # from my_module import SshPubKeyFactCollector()
    Collector.collectors[SshPubKeyFactCollector.name] = \
        getattr(my_module, SshPubKeyFactCollector.name)()
    fact_collector = Collector(my_module, collected_facts={})

    # Test the following keys:
    # /etc/ssh/ssh_host_rsa_key.pub
    # /etc/ssh/ssh_host_dsa_key.pub
    # /etc/ssh/ssh_host_ecdsa_key.pub
    # /etc/ssh/ssh_host_ed25519_key.pub
    demo_keys_dir

# Generated at 2022-06-20 20:04:38.673656
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c = SshPubKeyFactCollector()
    result = c.collect()

# Generated at 2022-06-20 20:04:44.205410
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                                        'ssh_host_key_dsa_public',
                                                        'ssh_host_key_rsa_public',
                                                        'ssh_host_key_ecdsa_public',
                                                        'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:04:54.527302
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()

    if ssh_pub_key_facts is not None:
        # test if the ssh key is the same as the key in the ssh_host_key_rsa_public file
        result = ssh_pub_key_facts['ssh_host_key_rsa_public'].split()[1]
        key_filename = '/etc/ssh/ssh_host_rsa_key.pub'
        keydata = get_file_content(key_filename)
        if keydata is not None:
            key = keydata.split()[1]
            assert result == key
        else:
            raise AssertionError('ssh_host_key_rsa_public key file should exist')

# Generated at 2022-06-20 20:04:57.575838
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c = SshPubKeyFactCollector()
    assert isinstance(c, SshPubKeyFactCollector)
    assert c.name is not None
    assert c._fact_ids is not None

# Generated at 2022-06-20 20:05:04.262759
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """Test SshPubKeyFactCollector constructor."""
    obj = SshPubKeyFactCollector()
    assert obj.name == "ssh_pub_keys"

# Generated at 2022-06-20 20:05:16.114080
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os

    # create a temporary directory to store temporary files for the test
    test_dir = os.path.join(os.environ['HOME'], 'test')
    if not os.path.exists(test_dir):
        os.makedirs(test_dir)

    # create a temporary file to simulate  files from /etc/ssh
    from tempfile import NamedTemporaryFile
    etc_ssh_file = NamedTemporaryFile(dir=test_dir, prefix='ssh_', suffix='.pub')
    test_file_name = etc_ssh_file.name
    etc_ssh_file.write('ssh-rsa test_rsa_key\n')
    etc_ssh_file.flush()

    # create a temporary file to simulate  files from /etc/openssh
    etc_openssh_file = NamedTemporary

# Generated at 2022-06-20 20:05:23.012135
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == "ssh_pub_keys"
    assert set(collector._fact_ids) == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:05:27.864548
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # get a SshPubKeyFactCollector class object
    sshPubKey_collector_obj = SshPubKeyFactCollector()

    # check if the object created is of type SshPubKeyFactCollector class
    assert isinstance(sshPubKey_collector_obj, SshPubKeyFactCollector)

    # check if the collection name is set correctly
    assert sshPubKey_collector_obj.name == "ssh_pub_keys"

# Generated at 2022-06-20 20:05:40.027782
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # create instance of class SshPubKeyFactCollector
    sshPubKeyFactCollector = SshPubKeyFactCollector()

    # create testdata
    collected_facts = dict()
    collected_facts['distribution'] = 'testdist'
    # test_content_1 contains one key
    test_content_1 = '''testtype testkey
comment testcomment'''
    # test_content_2 contains two keys
    test_content_2 = '''testtype testkey
comment testcomment
test2type test2key
comment test2comment'''
    test_content_3 = '''ssh-rsa testkey
comment testcomment'''

    # mock the check output functions
    def mock_get_file_content(filename):
        if filename.endswith('ssh_host_dsa_key.pub'):
            return

# Generated at 2022-06-20 20:05:49.896796
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
    Test for method collect of class SshPubKeyFactCollector
    """
    ssh_pub_key_collector = SshPubKeyFactCollector()

    # testing with empty file
    ssh_pub_key_facts = ssh_pub_key_collector.collect()
    assert ( ssh_pub_key_facts is not None)

    # testing with an empty dict
    ssh_pub_key_facts = ssh_pub_key_collector.collect(collected_facts={})
    assert ( ssh_pub_key_facts is not None)
    assert ( len(ssh_pub_key_facts) > 0)

    # testing with an non empty dict
    ssh_pub_key_facts = ssh_pub_key_collector.collect(collected_facts={'ssh_host_pub_keys':'test value'})


# Generated at 2022-06-20 20:05:59.358512
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_class = SshPubKeyFactCollector()

# Generated at 2022-06-20 20:06:00.563592
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:06:04.064084
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x is not None
    assert x.name == 'ssh_pub_keys'
    assert len(x._fact_ids) == 5

# Generated at 2022-06-20 20:06:11.738645
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector = SshPubKeyFactCollector()
    collected_facts = fact_collector.collect()

# Generated at 2022-06-20 20:06:18.876924
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fact_collector = SshPubKeyFactCollector()
    print("\n" + "fact collector = " + str(fact_collector))
    fact_data = fact_collector.collect()
    print("\n" + "facts data = " + str(fact_data))

# Generated at 2022-06-20 20:06:26.904373
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Test with no args
    x = SshPubKeyFactCollector(None, None)
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])



# Generated at 2022-06-20 20:06:27.501539
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-20 20:06:34.564071
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    c = SshPubKeyFactCollector()
    c.collect()
    assert c.fact_ids == set('ssh_host_pub_keys'.split())
    assert c.facts['ssh_host_pub_keys'] == ['ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIAW1yKfAmYHnEzv5gG3wZnLJGcSnF9XfLk2xsEJPEFn1r']
    assert c.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:06:36.586187
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert set(SshPubKeyFactCollector()._fact_ids) == SshPubKeyFactCollector._fact_ids

# Generated at 2022-06-20 20:06:42.976680
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    fact_ids = ssh_pub_key_fact_collector._fact_ids

    assert 'ssh_host_pub_keys' in fact_ids
    assert 'ssh_host_key_dsa_public' in fact_ids
    assert 'ssh_host_key_rsa_public' in fact_ids
    assert 'ssh_host_key_ecdsa_public' in fact_ids
    assert 'ssh_host_key_ed25519_public' in fact_ids

# Generated at 2022-06-20 20:06:46.707075
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector().name == 'ssh_pub_keys'
    assert len(SshPubKeyFactCollector()._fact_ids) == 5

# Generated at 2022-06-20 20:06:57.209183
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Setup
    class TestFacts:
        def __init__(self):
            self.my_facts = dict()

    test_facts = TestFacts()
    test_ssh_pub_key_facts = dict()

    # Return values of mocks

# Generated at 2022-06-20 20:06:59.170668
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    mc = SshPubKeyFactCollector()
    assert len(mc.collect(collected_facts=None))==6


# Generated at 2022-06-20 20:07:00.328254
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    f = SshPubKeyFactCollector()
    assert len(f.collect()) == 5

# Generated at 2022-06-20 20:07:09.639321
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    s = SshPubKeyFactCollector()
    assert s is not None


# Generated at 2022-06-20 20:07:11.907557
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    result = collector.collect(module=None, collected_facts=None)
    assert result is not None
    assert result == {}

# Generated at 2022-06-20 20:07:19.409526
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()

    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert ssh_pub_key_facts._fact_ids == set(['ssh_host_pub_keys',
                                               'ssh_host_key_dsa_public',
                                               'ssh_host_key_rsa_public',
                                               'ssh_host_key_ecdsa_public',
                                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:07:29.909969
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class DummyModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
        def fail_json(self, *args, **kwargs):
            raise Exception(args[0])

    collector = SshPubKeyFactCollector()
    collected_facts = collector.collect(module=DummyModule(ssh_pub_key_facts=True),
                                        collected_facts={})
    assert 'ssh_host_key_ed25519_public' in collected_facts
    assert 'ssh_host_key_ecdsa_public' in collected_facts
    assert 'ssh_host_key_rsa_public' in collected_facts
    assert 'ssh_host_key_dsa_public' in collected_facts

# Generated at 2022-06-20 20:07:36.527868
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    pub_key_facts = SshPubKeyFactCollector()
    expected_fact_ids = set(['ssh_host_pub_keys',
                             'ssh_host_key_dsa_public',
                             'ssh_host_key_rsa_public',
                             'ssh_host_key_ecdsa_public',
                             'ssh_host_key_ed25519_public'])
    assert pub_key_facts._fact_ids == expected_fact_ids

# Generated at 2022-06-20 20:07:40.993879
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_class = SshPubKeyFactCollector()
    result = test_class.collect()
    assert result

    assert isinstance(result, dict)
    assert len(result) <= 5
    for key in result:
        assert isinstance(key, str)
        assert result[key]

# Generated at 2022-06-20 20:07:42.647234
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == "ssh_pub_keys"

# Generated at 2022-06-20 20:07:46.504030
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:07:53.241758
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
            'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public',
            'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:08:02.486291
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    import pytest


# Generated at 2022-06-20 20:08:26.640786
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # create a mock module object
    module = Mock()

    # create a mock file content
    file_content = "ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBPUYa7w4oLZ4Q7ZuXl1z0KVuCcApB0yqsEoR0Q2HbBzJGkMSx0X0pXqI+1gNllc0Bk/N/RtQNP/F5Z/gN/e7CnNU="
    module.run_command.return_value = (0, file_content, None)

    sshd_pub_key_facts_collector = SshPubKeyFactCollector()

# Generated at 2022-06-20 20:08:38.194598
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # Test Case 1:
    # No ssh_host_*_key.pub file found

    # Input
    module = None
    collected_facts = None

    # To get the class object
    ssh_key_obj  = SshPubKeyFactCollector(module)

    # Test Case 1:
    assert ssh_key_obj.collect(module, collected_facts) == {}

    # Test Case 2:
    # ssh_host_*_key.pub file found

    # Input
    module = None
    collected_facts = None

# Generated at 2022-06-20 20:08:42.761168
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectorExecutor
    from ansible.module_utils.facts.dummy_collectors import DummyFactCollector
    import os
    import tempfile
    import textwrap
    import shutil
    import stat

    # create temporary directory with some ssh key files
    config = textwrap.dedent("""\
        HostKey /etc/ssh/ssh_host_dsa_key
        HostKey /etc/ssh/ssh_host_rsa_key
        HostKey /etc/ssh/ssh_host_ecdsa_key
        HostKey /etc/ssh/ssh_host_ed25519_key
        """)
    tmpdir = tempfile.mkdtemp()
    config_filename = os.path.join(tmpdir, 'sshd_config')

# Generated at 2022-06-20 20:08:51.282678
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()

    assert isinstance(ssh_pub_key_collector, SshPubKeyFactCollector)
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_collector._fact_ids == set(['ssh_host_pub_keys',
                                                   'ssh_host_key_dsa_public',
                                                   'ssh_host_key_rsa_public',
                                                   'ssh_host_key_ecdsa_public',
                                                   'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:09:02.405014
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Set argument spec to None to do not create unnecessary variables
    # and use the parameter 'module' instead
    SshPubKeyFactCollector.set_arg_spec(None)

    # Prepare a mock module
    module = AnsibleModuleMock()

    # Prepare collector
    collector = SshPubKeyFactCollector()

    # Prepare data to collect
    ssh_host_key_dsa_public = 'missing'
    ssh_host_key_rsa_public = 'missing'
    ssh_host_key_ecdsa_public = 'missing'
    ssh_host_key_ed25519_public = 'missing'
    ssh_host_key_dsa_public_keytype = 'missing'
    ssh_host_key_rsa_public_keytype = 'missing'
    ssh_host_key_ecdsa_

# Generated at 2022-06-20 20:09:04.021943
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    print(x.name)
    print(x._fact_ids)

# Generated at 2022-06-20 20:09:09.744671
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'
    assert len(ssh_pub_key_facts._fact_ids) == 5
    assert ssh_pub_key_facts._fact_ids == set(['ssh_host_key_dsa_public',
                                               'ssh_host_key_rsa_public',
                                               'ssh_host_key_ecdsa_public',
                                               'ssh_host_key_ed25519_public',
                                               'ssh_host_pub_keys'])


if __name__ == '__main__':
    test_SshPubKeyFactCollector()

# Generated at 2022-06-20 20:09:19.651478
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts_collector = SshPubKeyFactCollector()

    # check for no collected facts
    assert ssh_pub_key_facts_collector.collect() == {}

    # check for dsa type key

# Generated at 2022-06-20 20:09:21.088885
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.collect() == {}

# Generated at 2022-06-20 20:09:25.128694
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    s = SshPubKeyFactCollector()
    assert s._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])
    assert len(s._fact_ids) == 5
    assert s.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:10:02.942289
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    module = None
    collected_facts = None
    SshPubKeyFactCollector(module,collected_facts)

# Generated at 2022-06-20 20:10:11.083537
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector = SshPubKeyFactCollector()
    assert fact_collector.name == "ssh_pub_keys"
    assert fact_collector._fact_ids == {'ssh_host_pub_keys',
                                        'ssh_host_key_dsa_public',
                                        'ssh_host_key_rsa_public',
                                        'ssh_host_key_ecdsa_public',
                                        'ssh_host_key_ed25519_public'}

# Generated at 2022-06-20 20:10:20.070131
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fc = SshPubKeyFactCollector()
    assert ssh_pub_key_fc.name == 'ssh_pub_keys'
    assert ssh_pub_key_fc._fact_ids == set(['ssh_host_pub_keys',
                                            'ssh_host_key_dsa_public',
                                            'ssh_host_key_rsa_public',
                                            'ssh_host_key_ecdsa_public',
                                            'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:10:24.665939
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'
    assert collector._fact_ids == set(['ssh_host_pub_keys',
                                       'ssh_host_key_dsa_public',
                                       'ssh_host_key_rsa_public',
                                       'ssh_host_key_ecdsa_public',
                                       'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:10:31.508463
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    t_SshPubKeyFactCollector = SshPubKeyFactCollector()
    assert t_SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert t_SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                      'ssh_host_key_dsa_public',
                                                      'ssh_host_key_rsa_public',
                                                      'ssh_host_key_ecdsa_public',
                                                      'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:10:40.853506
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    module = None
    collected_facts = None
    # Testing the constructor of class SshPubKeyFactCollector
    test = SshPubKeyFactCollector()
    # Tests of the properties of object test
    assert test.name == 'ssh_pub_keys'
    assert test._fact_ids == set(['ssh_host_pub_keys',
                                  'ssh_host_key_dsa_public',
                                  'ssh_host_key_rsa_public',
                                  'ssh_host_key_ecdsa_public',
                                  'ssh_host_key_ed25519_public'])
    # Testing the method of class SshPubKeyFactCollector
    assert test.collect(module, collected_facts) == {}

# Generated at 2022-06-20 20:10:50.301028
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    from ansible.module_utils.facts.utils import get_file_content

    host_pub_keys = [('dsa', 'blah'),
                     ('rsa', 'blah'),
                     ('ecdsa', 'blah'),
                     ('ed25519', 'blah')]

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-20 20:10:59.433394
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile


# Generated at 2022-06-20 20:11:06.969920
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert set(SshPubKeyFactCollector()._fact_ids) == set(['ssh_host_pub_keys',
                                                           'ssh_host_key_dsa_public',
                                                           'ssh_host_key_rsa_public',
                                                           'ssh_host_key_ecdsa_public',
                                                           'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:11:09.913318
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create a instance of the class
    ssh_pub_key_fc_inst = SshPubKeyFactCollector()

    # Call the collect method
    ssh_pub_key_fc_inst.collect()

# Generated at 2022-06-20 20:12:35.394639
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():

    ssh_collector = SshPubKeyFactCollector()

    assert ssh_collector.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:12:41.770796
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # this is a very basic unit test of the collect method, it's not
    # complete.  It assumes the following:
    #
    # a. The methods get_files_from_glob_pattern and get_file_content are
    #    working correctly.
    # b. The class's _fact_ids contain the correct values
    # c. The SSH key files used in this test exist and have the correct values
    pubkeys = SshPubKeyFactCollector()
    facts = pubkeys.collect()

# Generated at 2022-06-20 20:12:45.559413
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # method: /usr/lib/python2.7/site-packages/ansible/module_utils/facts/collector/ssh_pub_keys.py#SshPubKeyFactCollector.collect
    pass


# Generated at 2022-06-20 20:12:50.264169
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # import module to be tested
    from ansible.module_utils.facts.collector import SshPubKeyFactCollector

    # initialize collector
    collector = SshPubKeyFactCollector()

    # check for empty collect() return value
    assert collector.collect() == {}

# Generated at 2022-06-20 20:12:51.660854
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()

# Generated at 2022-06-20 20:12:53.484345
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKeyFactCollector = SshPubKeyFactCollector()
    assert sshPubKeyFactCollector is not None


# Generated at 2022-06-20 20:12:56.181018
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    keys = collector.collect()
    assert 'ssh_host_key_ed25519_public' in keys
    assert 'ssh_host_key_ed25519_public_keytype' in keys

# Generated at 2022-06-20 20:13:05.018705
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """ unit test for construction of class SshPubKeyFactCollector """
    ssh_pub_key = SshPubKeyFactCollector()
    assert ssh_pub_key.name == 'ssh_pub_keys'
    assert ssh_pub_key._fact_ids == set(['ssh_host_pub_keys',
                                         'ssh_host_key_dsa_public',
                                         'ssh_host_key_rsa_public',
                                         'ssh_host_key_ecdsa_public',
                                         'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:13:12.260532
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x=SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])
    assert isinstance(x.collect(), dict)

# Generated at 2022-06-20 20:13:18.749313
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Unit test for SshPubKeyFactCollector.collect()"""
    from ansible.module_utils.facts.collector import Collector

    collector = Collector()
    collector.populate()
    collected_facts = collector.get_facts()
    module = 'ansible.module_utils.facts.collectors.generic.ssh_pub_key'
    collected_facts = __import__(module, globals(), locals(), ['collected_facts']).Collector.collect(collected_facts)
    assert len(collected_facts) == 1