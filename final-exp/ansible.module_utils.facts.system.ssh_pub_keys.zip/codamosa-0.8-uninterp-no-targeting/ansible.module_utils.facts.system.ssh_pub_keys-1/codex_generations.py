

# Generated at 2022-06-20 20:03:43.133638
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    assert collector

# Generated at 2022-06-20 20:03:47.948981
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'
    assert collector._fact_ids == set(['ssh_host_pub_keys',
                                       'ssh_host_key_dsa_public',
                                       'ssh_host_key_rsa_public',
                                       'ssh_host_key_ecdsa_public',
                                       'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:03:50.401701
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    print("In test_SshPubKeyFactCollector constructor")
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:03:55.967666
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    d = SshPubKeyFactCollector()
    assert d.name == 'ssh_pub_keys'
    assert d.priority == 85
    assert d._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])



# Generated at 2022-06-20 20:03:58.953455
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = {}

    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect()

    assert ssh_pub_key_facts is not None

# Generated at 2022-06-20 20:04:10.805918
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    mock_ansible_module = {}
    mock_ansible_module['config'] = {'fact_caching': 'jsonfile',
                                     'fact_caching_connection': './test.json',
                                     'fact_caching_timeout': 7200}
    mock_ansible_module['params'] = {}

    fact_collector = FactCollector(mock_ansible_module, None, None)
    fact_collector.collect_facts()
    # check that variable exists
    assert 'ssh_host_key_ed25519_public' in fact_collector.facts

    # check that variable exists
    assert 'ssh_host_key_ed25519_public' in fact_collector.facts

    # check that variable exists

# Generated at 2022-06-20 20:04:21.172869
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # Initialise a new fact collector using a mock module
    fact_collector = SshPubKeyFactCollector()

    # Run the collect method of the fact collector
    result = fact_collector.collect(None, None)

    # Assert result is not none
    assert result is not None, "result of collect method is none"
    assert "ssh_host_key_dsa_public" in result, "ssh_host_key_dsa_public not in result"
    assert "ssh_host_key_rsa_public" in result, "ssh_host_key_rsa_public not in result"
    assert "ssh_host_key_ecdsa_public" in result, "ssh_host_key_ecdsa_public not in result"

# Generated at 2022-06-20 20:04:29.670445
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # create instance of class SshPubKeyFactCollector
    ssh_keys = SshPubKeyFactCollector()

    # create expected results
    expected = {}

    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    for algo in algos:
        factname = 'ssh_host_key_%s_public' % algo

# Generated at 2022-06-20 20:04:31.675734
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """Test that SshPubKeyFactCollector() returns the expected value"""

    assert SshPubKeyFactCollector().name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:04:34.341698
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
  ssh_pub_key_facts = SshPubKeyFactCollector()

  # Testing the constructor
  assert ssh_pub_key_facts.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:04:44.382445
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:04:50.585476
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:04:55.911488
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector.fact_ids == {'ssh_host_pub_keys',
                                                   'ssh_host_key_dsa_public',
                                                   'ssh_host_key_rsa_public',
                                                   'ssh_host_key_ecdsa_public',
                                                   'ssh_host_key_ed25519_public'}

# Generated at 2022-06-20 20:05:02.526872
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:05:12.237498
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector.collect(module=None, collected_facts=None)
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts
    assert ssh_pub_key_facts['ssh_host_key_rsa_public_keytype'] == 'ssh-rsa'
    assert ssh_pub_key_facts['ssh_host_key_rsa_public'].endswith('==')

# Generated at 2022-06-20 20:05:15.501162
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """ Unit test for method collect of class SshPubKeyFactCollector """
    collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = collector.collect()
    print(ssh_pub_key_facts)

# Generated at 2022-06-20 20:05:26.319718
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_protected_path_dir
    from ansible.module_utils.facts import test


# Generated at 2022-06-20 20:05:31.026146
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_fact_collector = SshPubKeyFactCollector()
    assert 'ssh_host_pub_keys' == ssh_fact_collector.name
    assert set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public',
               'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public',
               'ssh_host_key_ed25519_public']).symmetric_difference(ssh_fact_collector._fact_ids) == set([])

# Generated at 2022-06-20 20:05:42.018411
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
    This method unit tests the collect method of SshPubKeyFactCollector
    """
    # the ssh_host_key_dsa_public fact exist in the test file
    # but the other facts do not exist
    # to ensure that no ssh_host_key_xxxxx_public facts exist,
    # the other test files do not have the ssh_host_key_dsa_public fact
    testfacts = {'ssh_host_key_dsa_public': 'XXXXX'}

    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_facts_collected = ssh_pub_key_fact_collector.collect(collected_facts=testfacts)

    # Note:
    # the method collect() does not create the facts:
    # ssh_host_key_

# Generated at 2022-06-20 20:05:50.310204
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Create a mock object representing the module object
    moduleMock = Mock(name='moduleMock')
    # Create a mock object representing the collected facts object
    collectedFactsMock = Mock(name='collectedFactsMock')
    # Create an instance of the class SshPubKeyFactCollector
    sshPubKeyCollector = SshPubKeyFactCollector()

    # Create a mock object representing the ssh keys file
    sshFileMock = Mock(name='sshFileMock')
    # Create a mock object representing the content of an ssh keys file
    keyDataMock = Mock(name='keyDataMock')
    # Set the return value of reading the content of the ssh keys file

# Generated at 2022-06-20 20:06:00.602324
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    data_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'dummysshkeys')
    keypath = os.path.join(data_dir, 'ssh_host_dsa_key.pub')
    kp = SshPubKeyFactCollector()

    def get_file_content_stub(filename):
        return open(keypath, 'r').read()

    kp.collect()
    previous_get_file_content = get_file_content
    get_file_content = get_file_content_stub
    kp.collect()
    assert get_file_content(keypath) == get_file_content(keypath)
    get_file_content = previous_get_file_content
# end of test_SshPubKeyFactCollector_collect

# Generated at 2022-06-20 20:06:07.792239
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    sshkey_facts = SshPubKeyFactCollector().collect()
    assert isinstance(sshkey_facts, dict)
    assert len(sshkey_facts) > 0, 'No ssh key facts returned'

    for key in sshkey_facts.keys():
        assert isinstance(key, str) and len(key) > 0, 'Invalid fact name: %s' % key
        assert isinstance(sshkey_facts[key], str), 'Fact %s has invalid data' % key

# Generated at 2022-06-20 20:06:17.933032
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:06:27.980132
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """Unit test for constructor of class SshPubKeyFactCollector
    """
    assert 'ssh_host_pub_keys' in SshPubKeyFactCollector._fact_ids
    assert 'ssh_host_key_dsa_public' in SshPubKeyFactCollector._fact_ids
    assert 'ssh_host_key_rsa_public' in SshPubKeyFactCollector._fact_ids
    assert 'ssh_host_key_ecdsa_public' in SshPubKeyFactCollector._fact_ids
    assert 'ssh_host_key_ed25519_public' in SshPubKeyFactCollector._fact_ids

# Generated at 2022-06-20 20:06:37.839481
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Unit test for method collect of class SshPubKeyFactCollector"""

    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_module_loader
    from ansible.module_utils._text import to_bytes
    
    # test against a mocked file system
    test_data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'unit/data')

# Generated at 2022-06-20 20:06:40.225524
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    myFactCollector = SshPubKeyFactCollector()
    myFactCollector.collect()
    assert(len(myFactCollector.collect()) == 0)


# Generated at 2022-06-20 20:06:45.275483
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_collector._fact_ids == set(['ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public', 'ssh_host_pub_keys'])

# Generated at 2022-06-20 20:06:48.520151
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # Arrange
    # Instance to test
    c = SshPubKeyFactCollector()

    # Act
    ans = c.collect()

    # Assert
    assert ans is not None


# Generated at 2022-06-20 20:06:51.490906
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    l = SshPubKeyFactCollector()
    assert l.name == 'ssh_pub_keys'
    assert 'ssh_host_key_dsa_public' in l._fact_ids

# Generated at 2022-06-20 20:06:52.726825
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fc = SshPubKeyFactCollector()
    assert fc


# Generated at 2022-06-20 20:07:02.110371
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector = SshPubKeyFactCollector()
    assert fact_collector.name == 'ssh_pub_keys'
    assert fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                            'ssh_host_key_dsa_public',
                                            'ssh_host_key_rsa_public',
                                            'ssh_host_key_ecdsa_public',
                                            'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:07:08.469577
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    val = SshPubKeyFactCollector()
    assert val._name == "ssh_pub_keys"
    assert isinstance(val._fact_ids, set)
    assert val._fact_ids == { 'ssh_host_key_ed25519_public',
        'ssh_host_key_ecdsa_public', 'ssh_host_key_dsa_public',
        'ssh_host_pub_keys', 'ssh_host_key_rsa_public' }

# Generated at 2022-06-20 20:07:19.317572
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    sv = SshPubKeyFactCollector()
    sv._module = None
    sv._collected_facts = None


# Generated at 2022-06-20 20:07:30.661288
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import tempfile
    import shutil
    import os

    # create temporary directory
    tmpd = tempfile.mkdtemp()
    # create a temporary file
    fd, fname = tempfile.mkstemp(dir=tmpd)

    # create ssh directory
    sshdir = os.path.join(tmpd, 'ssh')
    os.mkdir(sshdir)

    keydata = 'ssh-rsa AAAAaa somekey'
    f = os.fdopen(fd, "w")
    f.write(keydata)
    f.close()

    # create a symlink (for testing purposes only)
    os.symlink(fname, os.path.join(sshdir, 'ssh_host_rsa_key.pub'))

    # check if collect returns the expected facts

# Generated at 2022-06-20 20:07:39.118595
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact = SshPubKeyFactCollector()
    assert ssh_pub_key_fact.name == "ssh_pub_keys"
    assert ssh_pub_key_fact._fact_ids == set(['ssh_host_pub_keys',
                                              'ssh_host_key_dsa_public',
                                              'ssh_host_key_rsa_public',
                                              'ssh_host_key_ecdsa_public',
                                              'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:07:47.753671
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    key_dir = "tests/unit/utils/facts/ansible_local/ssh_pub_keys_test"
    pub_key_file = {
        "ssh_host_key_dsa_public": os.path.join(key_dir, "ssh_host_dsa_key.pub"),
        "ssh_host_key_rsa_public": os.path.join(key_dir, "ssh_host_rsa_key.pub"),
        "ssh_host_key_ecdsa_public": os.path.join(key_dir, "ssh_host_ecdsa_key.pub"),
        "ssh_host_key_ed25519_public": os.path.join(key_dir, "ssh_host_ed25519_key.pub")
    }

# Generated at 2022-06-20 20:07:59.723681
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    import os


# Generated at 2022-06-20 20:08:03.119293
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    ssh_pub_key_fact_collector.collect()


# Generated at 2022-06-20 20:08:13.846577
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # create an instance of the SshPubKeyFactCollector
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # create a 'module' object
    class AnsibleModule(object):
        def __init__(self):
            self.params = dict()
    module = AnsibleModule()

    # create a 'collected_facts' object
    class AnsibleCollectorFacts:
        def __init__(self):
            self.data = dict()
    collected_facts = AnsibleCollectorFacts()

    # call the collect method of the SshPubKeyFactCollector class
    ssh_pub_key_facts = ssh_pub_key_fact_collector.collect(module=module, collected_facts=collected_facts)

    # check the result

# Generated at 2022-06-20 20:08:19.447190
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # No arguments
    assert SshPubKeyFactCollector().collect() == {}

    # There should be no keys in /root
    assert SshPubKeyFactCollector().collect() == {}

    assert SshPubKeyFactCollector().collect() == {}

# Generated at 2022-06-20 20:08:38.679406
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = dict(
        ssh_host_key_rsa_public='rsa key',
        ssh_host_key_ecdsa_public='ecdsa key',
        ssh_host_key_ed25519_public='ed25519 key'
    )

    module = None
    collected_facts = None

    class FakeOs(object):
        def __init__(self):
            self.pathsep = ':'

        def listdir(self, path):
            if path == '/etc/ssh':
                return ['ssh_host_rsa_key.pub']
            if path == '/etc/openssh':
                return ['ssh_host_ecdsa_key.pub', 'ssh_host_ed25519_key.pub']
            if path == '/etc':
                return []
            return None

# Generated at 2022-06-20 20:08:45.506485
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:08:49.894999
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """ Unit test for method: SshPubKeyFactCollector.collect """

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import cache
    import tempfile
    import shutil
    import os

    cache_ = cache.FactCache()
    cache_.populate_fact_cache()
    cache_.save_cache()

    tmpdir = tempfile.mkdtemp()

    f = open(os.path.join(tmpdir, "ssh_host_rsa_key.pub"), 'w')

# Generated at 2022-06-20 20:08:52.121334
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:08:54.547238
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert collector.name == 'ssh_pub_keys'


# Generated at 2022-06-20 20:09:02.173717
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_keys = SshPubKeyFactCollector()
    assert ssh_keys.name == 'ssh_pub_keys'
    assert ssh_keys._fact_ids == set(['ssh_host_pub_keys',
                                      'ssh_host_key_dsa_public',
                                      'ssh_host_key_rsa_public',
                                      'ssh_host_key_ecdsa_public',
                                      'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:09:03.707687
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collecter = SshPubKeyFactCollector()

# vim: set expandtab: ts=4:sw=4

# Generated at 2022-06-20 20:09:10.086637
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # create dummy module and dummy ssh-keys
    module = {"some": "module"}
    collected_facts = {"some": "facts"}

# Generated at 2022-06-20 20:09:14.049364
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()

    # assert that all the different host keys are present
    for factname in SshPubKeyFactCollector._fact_ids:
        assert(factname in ssh_pub_key_facts)

    # assert that one of the host keys has a value as expected
    assert(ssh_pub_key_facts['ssh_host_key_rsa_public'] == 'AAAAB3NzaC1yc2EAAAADAQABAAABAQDQ2I7RUCvwBHg5i5hI3d3GBpfm',
           'ssh_host_key_rsa_public fact is not as expected')

# Generated at 2022-06-20 20:09:17.084904
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # SshPubKeyFactCollector.collect() is not testable, because
    # BaseFactCollector.collect() would try to load ansible module_utils,
    # which doesn't work in a unit test
    pass

# Generated at 2022-06-20 20:09:40.552232
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    _collector = SshPubKeyFactCollector()

    assert _collector.name == 'ssh_pub_keys'
    assert _collector._fact_ids == set(['ssh_host_pub_keys',
                                        'ssh_host_key_dsa_public',
                                        'ssh_host_key_rsa_public',
                                        'ssh_host_key_ecdsa_public',
                                        'ssh_host_key_ed25519_public'])

# Collect facts using the SshPubKeyFactCollector

# Generated at 2022-06-20 20:09:46.251871
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:09:53.772095
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    name = 'ssh_pub_keys'
    sshPubKeyCollector = SshPubKeyFactCollector()
    assert sshPubKeyCollector.name == name
    assert sshPubKeyCollector._fact_ids == set(['ssh_host_pub_keys',
                                                'ssh_host_key_dsa_public',
                                                'ssh_host_key_rsa_public',
                                                'ssh_host_key_ecdsa_public',
                                                'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:10:03.666145
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test with collection of facts from all directories
    module = None
    collected_facts = None

# Generated at 2022-06-20 20:10:12.973040
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    facts = collector.collect(None, None)
    assert 'ssh_host_key_dsa_public' in facts
    assert 'ssh_host_key_dsa_public_keytype' in facts
    assert 'ssh_host_key_rsa_public' in facts
    assert 'ssh_host_key_rsa_public_keytype' in facts
    assert 'ssh_host_key_ecdsa_public' in facts
    assert 'ssh_host_key_ecdsa_public_keytype' in facts
    assert 'ssh_host_key_ed25519_public' in facts
    assert 'ssh_host_key_ed25519_public_keytype' in facts

# Generated at 2022-06-20 20:10:24.278796
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:10:30.562647
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    test_object = SshPubKeyFactCollector()
    assert test_object
    assert test_object.name == 'ssh_pub_keys'
    assert test_object._fact_ids == set(['ssh_host_pub_keys',
                                         'ssh_host_key_dsa_public',
                                         'ssh_host_key_rsa_public',
                                         'ssh_host_key_ecdsa_public',
                                         'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:10:34.255524
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCollectionFailure

    mod = mock.MagicMock(name='mod')

    c = SshPubKeyFactCollector()

    c.collect(module=mod)

# Generated at 2022-06-20 20:10:38.850154
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:10:42.909723
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # unit test need to use import from source to not require ssh keys
    from ansible.module_utils.facts.collectors.system.ssh_pub_keys import SshPubKeyFactCollector

    # method under test
    collector = SshPubKeyFactCollector()
    key_facts = collector.collect()

    # assertion
    assert 'ssh_host_key_dsa_public' in key_facts
    assert 'ssh_host_key_dsa_public_keytype' in key_facts

# Generated at 2022-06-20 20:11:24.821798
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector({}, {})
    facts = {'ssh_host_key_dsa_public': '[B@7a',
             'ssh_host_key_rsa_public': '[B@7a',
             'ssh_host_key_ecdsa_public': '^B@7a',
             'ssh_host_key_ed25519_public': '[B@7a'}
    output_facts = collector.collect(facts)
    assert(output_facts == facts)

# Generated at 2022-06-20 20:11:29.057890
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    ssh_pub_key_facts = collector.collect()
    assert len(ssh_pub_key_facts) > 0
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts

# Generated at 2022-06-20 20:11:31.325170
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # check type of SshPubKeyFactCollector
    assert(type(SshPubKeyFactCollector) == type(BaseFactCollector))

    # check return type of collect method
    assert(type(SshPubKeyFactCollector().collect()) == dict)

# Generated at 2022-06-20 20:11:37.754377
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector();
    assert obj.name == 'ssh_pub_keys'

    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'

    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'

    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'

    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:11:39.400696
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    src = SshPubKeyFactCollector()
    assert src.name == 'ssh_pub_keys'


# Generated at 2022-06-20 20:11:46.387698
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    # Assert that the fact ids are correctly set
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:11:55.109707
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from mock import patch, call, create_autospec
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector

    module_patcher = patch('ansible.module_utils.facts.collector.BaseFactCollector')
    module = create_autospec(BaseFactCollector)
    module_patcher.start()
    add_fact_patcher = patch('ansible.module_utils.facts.collector.BaseFactCollector.add_fact')
    add_fact_patcher.start()

    file_content_patcher = patch('ansible.module_utils.facts.utils.get_file_content')
    file_content = create_autospec(get_file_content)

# Generated at 2022-06-20 20:12:07.764899
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import sys
    MODULE_ARGS = {"module": sys.modules[__name__]}
    MODULE_ARGS["file_content"] = {
        '/etc/ssh/ssh_host_dsa_key.pub': 'ssh-dss my_dsa_key',
        '/etc/ssh/ssh_host_ecdsa_key.pub': 'ssh-ecdsa my_ecdsa_key',
        '/etc/ssh/ssh_host_ed25519_key.pub': 'ssh-ed25519 my_ed25519_key',
        '/etc/ssh/ssh_host_rsa_key.pub': 'ssh-rsa my_rsa_key'
    }

# Generated at 2022-06-20 20:12:12.476225
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    _ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert _ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert _ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
             'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public',
             'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:12:14.573746
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector is not None

# Generated at 2022-06-20 20:13:44.673810
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Validate method collect"""

    # key1 = (b"ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDBhZtjJNt97+ZtYVoY0KjDDXhImx8r0rL+qBu3mvQKwD5mRmRZM/d+pAFiwk1+soHZtjzPtY+9n9vHx+2mcBhIrFcsOKn1Hk+RkzwfZlkljZQ2+X3q5r5rpEbhWrJpsb7qz3q4J95wL+6FtvUYkwoXeBm8W7DeEfUnufO2Q0/aJzcVQTkTZgG0+9