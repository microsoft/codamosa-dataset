

# Generated at 2022-06-20 20:03:49.265632
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
    Test function for class SshPubKeyFactCollector
    """
    mod_args = {}
    facts = {}
    collector = SshPubKeyFactCollector()
    collected_facts = collector.collect(module_args=mod_args, facts=facts)
    assert len(collected_facts.keys()) >= 1

# Generated at 2022-06-20 20:03:51.362515
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
        pub_key_fact_collector = SshPubKeyFactCollector()
        assert pub_key_fact_collector.collect(collected_facts=None) is not None

# Generated at 2022-06-20 20:03:52.854650
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:04:00.690507
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Testing with a mocked ansible.module_utils.facts.utils.get_file_content method
    import sys
    import tempfile
    import shutil
    import os
    from ansible.module_utils.facts.utils import get_file_content


# Generated at 2022-06-20 20:04:12.632057
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class MyModule(object):
        pass
    module = MyModule()


# Generated at 2022-06-20 20:04:23.345788
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()
    assert len(ssh_pub_key_facts) == 5
    assert len(ssh_pub_key_facts['ssh_host_key_dsa_public']) > 0
    assert len(ssh_pub_key_facts['ssh_host_key_dsa_public_keytype']) > 0
    assert len(ssh_pub_key_facts['ssh_host_key_rsa_public']) > 0
    assert len(ssh_pub_key_facts['ssh_host_key_rsa_public_keytype']) > 0
    assert len(ssh_pub_key_facts['ssh_host_key_ecdsa_public']) > 0

# Generated at 2022-06-20 20:04:25.628865
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.get_fact_names() == ['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public']


# Generated at 2022-06-20 20:04:36.482324
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    import sys
    sys.modules["ansible.module_utils.facts.utils"] = __import__("ansible.module_utils.facts.utils")
    module_utils_facts_sshpubkeyfactscollector = sys.modules["ansible.module_utils.facts.sshpubkeyfactscollector"]

    from ansible.module_utils.facts.utils import get_file_content

    fc = module_utils_facts_sshpubkeyfactscollector.SshPubKeyFactCollector()
    # 1. Key files are present
    module_utils_facts_sshpubkeyfactscollector.get_file_content = lambda filename, content=None: "ssh-rsa aaa"

# Generated at 2022-06-20 20:04:44.429079
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Test if appropriate methods for SshPubKeyFactCollector are called"""

    # set-up modules and create SshPubKeyFactCollector object
    module = 'ansible'
    collected_facts = 'None'
    ssh_pub_key_collector = SshPubKeyFactCollector()

    # test if all the appropriate methods are called
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_collector._fact_ids == set(['ssh_host_pub_keys',
                                                   'ssh_host_key_dsa_public',
                                                   'ssh_host_key_rsa_public',
                                                   'ssh_host_key_ecdsa_public',
                                                   'ssh_host_key_ed25519_public'])

    #

# Generated at 2022-06-20 20:04:51.368447
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_collector._fact_ids == set(['ssh_host_pub_keys',
                                                   'ssh_host_key_dsa_public',
                                                   'ssh_host_key_rsa_public',
                                                   'ssh_host_key_ecdsa_public',
                                                   'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:05:01.869240
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Construct object and test for object type
    obj = SshPubKeyFactCollector()
    assert isinstance(obj, SshPubKeyFactCollector)

    # Test the name property
    assert obj.name == 'ssh_pub_keys'

    # Test the _fact_ids property
    assert obj._fact_ids == set(['ssh_host_pub_keys',
                     'ssh_host_key_dsa_public',
                     'ssh_host_key_rsa_public',
                     'ssh_host_key_ecdsa_public',
                     'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:05:10.067025
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert len(x._fact_ids) == 5
    for elem in x._fact_ids:
        assert elem in ['ssh_host_pub_keys','ssh_host_key_dsa_public','ssh_host_key_rsa_public','ssh_host_key_ecdsa_public','ssh_host_key_ed25519_public']

# Generated at 2022-06-20 20:05:20.967508
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()

    # Check if ssh_pub_key_fact_collector is an instance of
    # BaseFactCollector
    assert isinstance(ssh_pub_key_fact_collector, BaseFactCollector)

    # Check if ssh_pub_key_fact_collector has a valid name
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'

    # Check the value of _fact_ids

# Generated at 2022-06-20 20:05:29.729241
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import collector
    collector.collector_registry._init_registry()
    test_instance = SshPubKeyFactCollector()
    assert(test_instance.collector._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public']))

# Generated at 2022-06-20 20:05:30.546017
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-20 20:05:41.611232
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content
    import os
    import tempfile
    ssh_pub_key_facts = {}
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    keydirs = ['/etc/ssh', '/etc/openssh', '/etc']

    # Create temp directory
    tdir = tempfile.mkdtemp()
    os.chdir(tdir)

    # Create keydirs and fill with key files
    for keydir in keydirs:
        os.mkdir(keydir)
        for algo in algos:
            key_filename = '%s/ssh_host_%s_key.pub' % (keydir, algo)
            keydata = '%s %s %s %s@localhost'

# Generated at 2022-06-20 20:05:45.254892
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector = SshPubKeyFactCollector()
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert not SshPubKeyFactCollector.depends_on()
    assert not SshPubKeyFactCollector.is_collected()

# Generated at 2022-06-20 20:05:50.696189
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Unit test requires the module to be loaded, so we will load it here
    from ansible.module_utils.facts import collector
    collector.collect_subset = ['ssh_pub_keys']
    result = collector.collect(module=None, collected_facts=None)
    assert 'ssh_pub_keys' in result



# Generated at 2022-06-20 20:05:55.798234
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:06:07.176177
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshpubkey = SshPubKeyFactCollector()
    assert 'ssh_host_pub_keys' in sshpubkey.fact_class.FACT_NAMES
    assert 'ssh_host_key_dsa_public' in sshpubkey.fact_class.FACT_NAMES
    assert 'ssh_host_key_rsa_public' in sshpubkey.fact_class.FACT_NAMES
    assert 'ssh_host_key_ecdsa_public' in sshpubkey.fact_class.FACT_NAMES
    assert 'ssh_host_key_ed25519_public' in sshpubkey.fact_class.FACT_NAMES
    assert 'ssh_host_key_ssh2-rsa_public' not in sshpubkey.fact_class.FACT_NAMES

# Generated at 2022-06-20 20:06:16.442224
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c = SshPubKeyFactCollector()
    assert c.name == 'ssh_pub_keys'
    assert c._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:06:21.755355
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ''' Unit testing for ansible.module_utils.facts.ssh_pub_keys.SshPubKeyFactCollector.collect function '''

    # Sending dict with module and facts as arguments to the collect function and
    # asserting the returned value of the function

# Generated at 2022-06-20 20:06:30.295300
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                                        'ssh_host_key_dsa_public',
                                                        'ssh_host_key_rsa_public',
                                                        'ssh_host_key_ecdsa_public',
                                                        'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:06:39.797430
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    import pytest

    # write some test ssh public keys to temporay files
    dsa_pubkey = b'1024 34 994984e19a14868d8d606415185a7b742776b736d8e9a91370ba7bdd999fbf02e8 (none)@TEST-DSS-KEY'
    rsa_pubkey = b'2048 c1:93:52:75:88:b5:f7:e0:a1:8d:18:9c:bc:45:b5:6d (none)@TEST-RSA-KEY'

# Generated at 2022-06-20 20:06:47.298326
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    # Dummy module, is not used inside the collect method
    module = type('test', (object, ), {})


# Generated at 2022-06-20 20:06:57.912220
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils import basic

    ansible_module = basic.AnsibleModule(argument_spec={})

    # mock
    module_mock = basic.AnsibleModule(argument_spec={})
    module_mock.get_bin_path = lambda *args: args[0]
    module_mock.exit_json = lambda **kvargs: kvargs
    
    # real module
    # module = ansible_module
    module = module_mock

    ssh_pub_key_facts = SshPubKeyFactCollector().collect(module=module)

    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public_keytype' in ssh_pub_key_facts

# Generated at 2022-06-20 20:07:03.293403
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshPubKeyFactCollector = SshPubKeyFactCollector()
    assert sshPubKeyFactCollector.name == 'ssh_pub_keys'
    assert sshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:07:06.673522
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    #Assert that SshPubKeyFactCollector is subclass of BaseFactCollector
    assertissubclass(SshPubKeyFactCollector, BaseFactCollector)


# Generated at 2022-06-20 20:07:07.153741
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    pass

# Generated at 2022-06-20 20:07:07.579254
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
  pass

# Generated at 2022-06-20 20:07:25.240566
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:07:29.958284
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = None
    fact_collector = SshPubKeyFactCollector()
    new_facts = fact_collector.collect(module, collected_facts)
    assert 'ssh_host_ed25519_public' in new_facts

# Generated at 2022-06-20 20:07:31.007852
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    SshPubKeyFactCollector()


# Generated at 2022-06-20 20:07:40.577448
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    # Check the name attribute
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'
    # Check the _fact_ids attribute
    print(SshPubKeyFactCollector._fact_ids)
    assert SshPubKeyFactCollector._fact_ids == set(['ssh_host_pub_keys',
                                                    'ssh_host_key_dsa_public',
                                                    'ssh_host_key_rsa_public',
                                                    'ssh_host_key_ecdsa_public',
                                                    'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:07:46.084380
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    test_SshPubKeyFactCollector_collect.collector = SshPubKeyFactCollector()
    # Create an empty AnsibleModule object to hold return values
    module = {}
    # Define a variable that holds all the collected facts
    # The following dictionary will be used as keys to call the
    # SshPubKeyFactCollector class
    facts = {}
    test_SshPubKeyFactCollector_collect.collector.collect(module=module, collected_facts=facts)
    return module, facts


# Generated at 2022-06-20 20:07:54.934449
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                                  'ssh_host_key_dsa_public',
                                                  'ssh_host_key_rsa_public',
                                                  'ssh_host_key_ecdsa_public',
                                                  'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:08:03.417877
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    m = mock_module()
    fc = SshPubKeyFactCollector()

    # empty ssh keys
    fc.collect(module=m, collected_facts={})
    assert m.fail_json.called

    # invalid ssh keys
    m.fail_json.reset_mock()
    fc.collect(module=m, collected_facts={'ssh_host_key_ed25519_public': 'badkey'})
    assert m.fail_json.called

    # valid ssh keys
    m.fail_json.reset_mock()

# Generated at 2022-06-20 20:08:14.119446
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """Tests that we get the expected ssh_pub_keys facts for RedHat
    and Debian systems, including versions of Debian with no ssh
    host keys present.
    """
    from ansible.module_utils.facts import FactCollector

    # Make the fact collector
    fact_collector = FactCollector(
        collectors=[SshPubKeyFactCollector])
    # Process the facts from Redhat 6
    collected_facts = fact_collector.collect(module=None,
                                             collected_facts={},
                                             gather_subset='all')
    # Check the values

# Generated at 2022-06-20 20:08:24.938349
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.utils import ModuleDataParser


# Generated at 2022-06-20 20:08:30.461053
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    SshPubKeyFactCollector = SshPubKeyFactCollector()

# Generated at 2022-06-20 20:08:46.564653
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # run constructor
    SshPubKeyFactCollector()

# Generated at 2022-06-20 20:08:56.030275
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile

    # Create temporary ssh key

    (temp_h, temp_n) = tempfile.mkstemp()
    temp_key = os.fdopen(temp_h, 'w')
    temp_key.write(b'foo')
    temp_key.close()

    # Create an instance of SshPubKeyFactCollector and invoke collect
    # method to get the facts with key found in temp directory

    ssh_pub_key_facts = SshPubKeyFactCollector().collect(None)

    # Assert that the temp_key is not in the collected facts

    assert 'ssh_host_key_ecdsa_public' not in ssh_pub_key_facts
    assert 'ssh_host_key_ecdsa_public_keytype' not in ssh_pub_key_facts

    # Clean up

# Generated at 2022-06-20 20:09:06.490542
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pubkey_algo_fact_names = ['ssh_host_key_ed25519_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_dsa_public']

# Generated at 2022-06-20 20:09:16.103177
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = None
    test_collector = SshPubKeyFactCollector()
    facts = test_collector.collect(module, collected_facts)
    if facts['ssh_host_key_rsa_public'].startswith('AAAAB3NzaC1yc2EAAAADAQABAAABAQC4x'):
        print('Facts returned by SshPubKeyFactCollector are: %s' % facts)
    else:
        print('No facts returned by SshPubKeyFactCollector')

test_SshPubKeyFactCollector_collect()

# Generated at 2022-06-20 20:09:22.698372
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # test_SshPubKeyFactCollector_collect_ecdsa is a temporary workaround
    # for the fact this test is needed, see the comment in
    # test_SshPubKeyFactCollector_collect_ecdsa below.
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.collectors.network.ssh_pub_key import test_SshPubKeyFactCollector_collect_ecdsa
    test_SshPubKeyFactCollector_collect_ecdsa()
    SshPubKeyFactCollector().collect()
    # No ssh host key exists, collect should return an empty dictionary.
    assert SshPubKeyFactCollector().collect() == {}


# Generated at 2022-06-20 20:09:34.274451
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    from .mock_module_util import AnsibleModule
    module = AnsibleModule(argument_spec={})
    fact_collector = SshPubKeyFactCollector()
    collected_facts = dict()
    fact_collector.collect(module=module, collected_facts=collected_facts)

    assert len(collected_facts) == 5
    assert 'ssh_host_key_dsa_public_keytype' in collected_facts
    assert 'ssh_host_key_dsa_public' in collected_facts
    assert 'ssh_host_key_rsa_public_keytype' in collected_facts
    assert 'ssh_host_key_rsa_public' in collected_facts
    assert 'ssh_host_key_ecdsa_public_keytype' in collected_facts

# Generated at 2022-06-20 20:09:39.208725
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public', 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:09:44.131881
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    facts = SshPubKeyFactCollector()
    assert facts._fact_ids == set(['ssh_host_pub_keys',
                                   'ssh_host_key_dsa_public',
                                   'ssh_host_key_rsa_public',
                                   'ssh_host_key_ecdsa_public',
                                   'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:09:48.556130
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    c = SshPubKeyFactCollector()
    assert c.name == 'ssh_pub_keys'
    assert c._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:09:57.747940
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Test with no keys found
    mock_module_Utils_common = {}
    mock_module_Utils_common['get_file_content'] = lambda x: None
    results = SshPubKeyFactCollector(module_Utils_common=mock_module_Utils_common).collect()
    assert results == {}

    # Test with both ed25519 and dsa keys found
    dsa_factname_keytype = 'ssh_host_key_dsa_public_keytype'
    dsa_factname = 'ssh_host_key_dsa_public'
    ed_factname_keytype = 'ssh_host_key_ed25519_public_keytype'
    ed_factname = 'ssh_host_key_ed25519_public'
    mock_module_Utils_common = {}
    mock

# Generated at 2022-06-20 20:10:38.185554
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # mocking module and collected_facts
    module = None
    collected_facts = {}
    ssh_pub_key_facts = SshPubKeyFactCollector()
    ssh_pub_key_facts_output = ssh_pub_key_facts.collect(module, collected_facts)
    # checking the values in the return
    assert ('ssh_host_key_dsa_public' and 'ssh_host_key_dsa_public_keytype' in ssh_pub_key_facts_output)
    assert ('ssh_host_key_rsa_public' and 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts_output)

# Generated at 2022-06-20 20:10:42.979759
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                                        'ssh_host_key_dsa_public',
                                                        'ssh_host_key_rsa_public',
                                                        'ssh_host_key_ecdsa_public',
                                                        'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:10:51.986964
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:10:52.541907
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    pass

# Generated at 2022-06-20 20:10:53.952118
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:11:02.096742
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.collectors.network
    import ansible.module_utils.facts.collectors.platform

    # We need to populate the FactCollector._collectors list first.
    collector.collect_all()
    # Verify that the Collector has been added to the list of known Collectors.
    assert SshPubKeyFactCollector.name in collector.FACT_COLLECTORS

    # Verify that the Collector's facts have been added to the list of known
    # facts.
    known_facts = ansible.module_utils.facts.collectors.network.NetworkFactCollector.collect()
    known_facts.update(ansible.module_utils.facts.collectors.platform.PlatformFactCollector.collect())

# Generated at 2022-06-20 20:11:12.722029
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    class TestModule:
        pass

    testmodule = TestModule()
    testmodule.params = {}


# Generated at 2022-06-20 20:11:13.904377
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert isinstance(SshPubKeyFactCollector(), SshPubKeyFactCollector)

# Generated at 2022-06-20 20:11:14.404693
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    pass

# Generated at 2022-06-20 20:11:19.020142
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
     module = None
     fact_collector = SshPubKeyFactCollector()
     facts = {}
     fact_data = fact_collector.collect(module, facts)

     # test if all the facts are in the collected facts
     for fact_name in SshPubKeyFactCollector._fact_ids:
         assert fact_name in fact_data

# Generated at 2022-06-20 20:12:46.631408
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:12:53.332149
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # No keydirs specified, no keys should be found
    assert SshPubKeyFactCollector().collect() == {}

    # Set up test
    factcollector = SshPubKeyFactCollector()
    factcollector.keydirs = ['/etc/ssh', '/etc/openssh', '/etc']
    factcollector._module = fakemodule()

    # collect() method should return dictionary of facts
    assert isinstance(factcollector.collect(), dict)



# Generated at 2022-06-20 20:12:56.958654
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fc = SshPubKeyFactCollector()
    assert ssh_pub_key_fc.name == 'ssh_pub_keys'
    assert 'ssh_host_pub_keys' in ssh_pub_key_fc._fact_ids
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_fc._fact_ids
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_fc._fact_ids
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_fc._fact_ids
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_fc._fact_ids

# Generated at 2022-06-20 20:13:02.483245
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import sys
    import os

    # create temp directory for ssh keys
    test_ssh_key_dir = os.path.join(sys.path[0], 'test_ssh_keys')
    os.mkdir(test_ssh_key_dir)
    # create some test keys to be found by the SshPubKeyFactCollector

# Generated at 2022-06-20 20:13:06.728349
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    assert isinstance(SshPubKeyFactCollector.__name__, str)
    assert SshPubKeyFactCollector.name == "ssh_pub_keys"
    # _fact_ids is a set, thus only testing class variable name
    assert isinstance(SshPubKeyFactCollector._fact_ids, set)



# Generated at 2022-06-20 20:13:17.099141
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    # Mock ssh keys

# Generated at 2022-06-20 20:13:25.194641
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector.collect()

# Generated at 2022-06-20 20:13:29.344756
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == {'ssh_host_pub_keys',
                             'ssh_host_key_dsa_public',
                             'ssh_host_key_rsa_public',
                             'ssh_host_key_ecdsa_public',
                             'ssh_host_key_ed25519_public'}

# Generated at 2022-06-20 20:13:33.771468
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_keys = SshPubKeyFactCollector()
    assert ssh_pub_keys.name == 'ssh_pub_keys'
    assert ssh_pub_keys._fact_ids == set(['ssh_host_pub_keys',
                                          'ssh_host_key_dsa_public',
                                          'ssh_host_key_rsa_public',
                                          'ssh_host_key_ecdsa_public',
                                          'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:13:35.886925
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector = SshPubKeyFactCollector()

    assert fact_collector.name == 'ssh_pub_keys'
    assert fact_collector.collect() == {}