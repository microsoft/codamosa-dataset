

# Generated at 2022-06-20 20:03:51.898241
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    content = "dsa-key-20160217 ssh-dss AAAAB3NzaC1kc3MAAACBAN0hL8b7SOuAlNHlI2QKjEz8"
    content += "PdZbBrY+jKcs8w6JnL1fPIKs4o3qUoWmtT9TvRnV6StsS6w7m8umvDxV7eQm0AA"
    content += "vX9VzOcYhYpw6NR8xvH0b0Nlq3ri4W6Z8TvT9B6UMrz6/SQyh8RsxJH1ei+cGgL"

# Generated at 2022-06-20 20:03:56.164643
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh = SshPubKeyFactCollector()
    assert ssh._fact_ids == set(['ssh_host_pub_keys',
                                 'ssh_host_key_dsa_public',
                                 'ssh_host_key_rsa_public',
                                 'ssh_host_key_ecdsa_public',
                                 'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:03:57.736014
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """
    Function to test constructor of class SshPubKeyFactCollector
    """
    SshPubKeyFactCollector()

# Generated at 2022-06-20 20:04:03.694307
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Check collect function of class SshPubKeyFactCollector """
    import pytest
    from ansible.module_utils.facts import facts

    basefactcollector = BaseFactCollector()
    basefactcollector.collection_name = 'ssh_pub_keys'
    basefactcollector.version = 2.3

    sshpubkeycol = SshPubKeyFactCollector()
    sshpubkeycol.collect()

    # ensure collected facts are properly initialized
    assert sshpubkeycol.collected_facts[basefactcollector.collection_name] == dict()
    assert sshpubkeycol.collected_facts['_ansible_' + basefactcollector.collection_name] == dict()

# Generated at 2022-06-20 20:04:07.133807
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name =="ssh_pub_keys"

# Generated at 2022-06-20 20:04:08.183049
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    SshPubKeyFactCollector.collect()
    pass

# Generated at 2022-06-20 20:04:10.094552
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    print(x)
    pass


# Generated at 2022-06-20 20:04:11.170859
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # not implemented
    pass

# Generated at 2022-06-20 20:04:13.971058
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = None
    key_fact_collector = SshPubKeyFactCollector()
    key_fact_collector.collect(module, collected_facts)

# Generated at 2022-06-20 20:04:20.630231
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    print('Testing constructor of SshPubKeyFactCollector')
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys', 'name is not ssh_pub_keys'
    assert SshPubKeyFactCollector.priority == 80, 'priority is not 80'


# Generated at 2022-06-20 20:04:24.615918
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector is not None

# Generated at 2022-06-20 20:04:31.472805
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # Set up mocked module
    class MockModule:
        def __init__(self):
            self.params = {}

    module = MockModule()

    # Set up mocked collected_facts
    collected_facts = dict()

    # This is what we expect to be returned by the collect method

# Generated at 2022-06-20 20:04:32.958084
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    def doit():
        collector = SshPubKeyFactCollector()
    doit()

# Generated at 2022-06-20 20:04:42.278418
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # create instance of SshPubKeyFactCollector
    # test method collect of class SshPubKeyFactCollector
    module = None
    collected_facts = {}

# Generated at 2022-06-20 20:04:54.527559
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    f = open('ssh_keys.txt', 'r')

# Generated at 2022-06-20 20:05:02.752707
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fc = SshPubKeyFactCollector()
    assert ssh_pub_key_fc.name == 'ssh_pub_keys'
    assert ssh_pub_key_fc._fact_ids == set(['ssh_host_pub_keys',
                                            'ssh_host_key_dsa_public',
                                            'ssh_host_key_rsa_public',
                                            'ssh_host_key_ecdsa_public',
                                            'ssh_host_key_ed25519_public'])
    assert ssh_pub_key_fc.collect() == {}

# Generated at 2022-06-20 20:05:11.367179
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact = 'ssh_pub_keys'
    fact_ids = set(['ssh_host_pub_keys',
                    'ssh_host_key_dsa_public',
                    'ssh_host_key_rsa_public',
                    'ssh_host_key_ecdsa_public',
                    'ssh_host_key_ed25519_public'])
    assert SshPubKeyFactCollector.name == fact
    assert SshPubKeyFactCollector._fact_ids == fact_ids

# Generated at 2022-06-20 20:05:15.785296
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector().collect()

    assert isinstance(ssh_pub_key_facts, dict)
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts
    assert 'ssh_host_key_rsa_public_keytype' in ssh_pub_key_facts

# Generated at 2022-06-20 20:05:17.484216
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    collector = SshPubKeyFactCollector()
    facts = collector.collect()
    assert isinstance(facts, dict)

# Generated at 2022-06-20 20:05:20.530375
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    collector = SshPubKeyFactCollector()
    assert isinstance(collector, SshPubKeyFactCollector)


# Generated at 2022-06-20 20:05:34.924060
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:05:43.861521
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts.name == "ssh_pub_keys"
    assert 'ssh_host_pub_keys' in ssh_pub_key_facts._fact_ids
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_facts._fact_ids
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_facts._fact_ids
    assert 'ssh_host_key_ecdsa_public' in ssh_pub_key_facts._fact_ids
    assert 'ssh_host_key_ed25519_public' in ssh_pub_key_facts._fact_ids


# Generated at 2022-06-20 20:05:50.097328
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """ Unit test for constructing class 'SshPubKeyFactCollector' """
    # pylint: disable=protected-access
    ssh_pub_key_facts = SshPubKeyFactCollector()
    assert ssh_pub_key_facts._fact_ids == {'ssh_host_pub_keys', 'ssh_host_key_ecdsa_public', 'ssh_host_key_rsa_public', 'ssh_host_key_ed25519_public', 'ssh_host_key_dsa_public'}
    assert ssh_pub_key_facts.name == 'ssh_pub_keys'



# Generated at 2022-06-20 20:05:52.397345
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    obj.collect()

# Generated at 2022-06-20 20:05:53.494324
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    testobj = SshPubKeyFactCollector()
    testobj.collect()

# Generated at 2022-06-20 20:05:54.830324
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    keys = SshPubKeyFactCollector()
    assert keys.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:06:02.481349
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    # Instantiate object.
    ssh_pub_key_fc = SshPubKeyFactCollector()
    # Test the name class variable.
    assert ssh_pub_key_fc.name == 'ssh_pub_keys'
    # Test the ssh_host_pub_keys fact.
    assert 'ssh_host_pub_keys' in ssh_pub_key_fc._fact_ids
    # Test the ssh_host_key_dsa_public fact.
    assert 'ssh_host_key_dsa_public' in ssh_pub_key_fc._fact_ids
    # Test the ssh_host_key_rsa_public fact.
    assert 'ssh_host_key_rsa_public' in ssh_pub_key_fc._fact_ids
    # Test the ssh_host_key_ecdsa_public fact.
   

# Generated at 2022-06-20 20:06:09.427435
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    factcollector = SshPubKeyFactCollector()
    collected_facts_before = {'ssh_host_pub_keys': 'foo'}
    collected_facts_after = factcollector.collect(collected_facts=collected_facts_before)

    if collected_facts_before['ssh_host_pub_keys'] == collected_facts_after['ssh_host_pub_keys']:
        factcollector.update_facts(collected_facts_after)
        return True
    else:
        raise AssertionError('ssh_host_pub_keys did not get updated')



# Generated at 2022-06-20 20:06:18.803297
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:06:28.769809
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
        'ssh_host_key_dsa_public',
        'ssh_host_key_rsa_public',
        'ssh_host_key_ecdsa_public',
        'ssh_host_key_ed25519_public'])

if __name__ == '__main__':
    test_SshPubKeyFactCollector()

# Generated at 2022-06-20 20:06:41.718620
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    keys = ('ssh_host_key_dsa_public',
            'ssh_host_key_rsa_public',
            'ssh_host_key_ecdsa_public',
            'ssh_host_key_ed25519_public')
    facts = SshPubKeyFactCollector().collect()
    assert facts
    for key in keys:
        assert key in facts
        assert facts[key] == 'AAAA...'

# Generated at 2022-06-20 20:06:48.278320
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class MockedModule():
        def __init__(self):
            self.params = {}
    m = MockedModule()
    c = SshPubKeyFactCollector(m)
    keydirs = ['/etc/ssh', '/etc/openssh']

# Generated at 2022-06-20 20:06:55.453773
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    sshpubkeyfact = SshPubKeyFactCollector()

    # assert
    assert sshpubkeyfact.name == 'ssh_pub_keys'

    # assert
    assert sshpubkeyfact._fact_ids == set(['ssh_host_pub_keys',
                                           'ssh_host_key_dsa_public',
                                           'ssh_host_key_rsa_public',
                                           'ssh_host_key_ecdsa_public',
                                           'ssh_host_key_ed25519_public'])



# Generated at 2022-06-20 20:06:56.732432
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fc = SshPubKeyFactCollector()
    assert fc.collect() == {}

# Generated at 2022-06-20 20:07:02.401165
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == {'ssh_host_pub_keys',
     'ssh_host_key_dsa_public',
     'ssh_host_key_rsa_public',
     'ssh_host_key_ecdsa_public',
     'ssh_host_key_ed25519_public'}

# Generated at 2022-06-20 20:07:11.609634
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    fact_collector = SshPubKeyFactCollector()
    assert fact_collector
    assert fact_collector.name == 'ssh_pub_keys'
    assert fact_collector._fact_ids == set(['ssh_host_pub_keys',
        'ssh_host_key_dsa_public',
        'ssh_host_key_rsa_public',
        'ssh_host_key_ecdsa_public',
        'ssh_host_key_ed25519_public'])

# Unit test to verify that the collect method for class SshPubKeyFactCollector
# returns a dictionary.  The method does not return a useful value, so the
# value of the dictionary that is returned is not important.

# Generated at 2022-06-20 20:07:14.197556
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    class MockModule:
        pass

    mock_module = MockModule()
    mock_module.params = {}

    output = SshPubKeyFactCollector().collect(module=mock_module, collected_facts=None)
    assert type(output) is dict

# Generated at 2022-06-20 20:07:21.474049
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    mysshpubkeycollector = SshPubKeyFactCollector()
    assert mysshpubkeycollector.name == 'ssh_pub_keys'
    assert mysshpubkeycollector._fact_ids == set(['ssh_host_pub_keys',
                                                  'ssh_host_key_dsa_public',
                                                  'ssh_host_key_rsa_public',
                                                  'ssh_host_key_ecdsa_public',
                                                  'ssh_host_key_ed25519_public'])

# Generated at 2022-06-20 20:07:33.074277
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():

    # make sure any ssh host keys in /etc/ssh are found as facts
    # this test is done for dsa key type as it is present in all systems
    keydata = get_file_content('/etc/ssh/ssh_host_dsa_key.pub')
    if keydata is not None:
        (keytype, key) = keydata.split()[0:2]
        expec_dict = {
            'ssh_host_key_dsa_public': key,
            'ssh_host_key_dsa_public_keytype': keytype
            }
        assert(SshPubKeyFactCollector().collect() == expec_dict)

    # make sure any ssh host keys in /etc/ssh are found as facts
    # this test is done for rsa key type as it is present in all systems

# Generated at 2022-06-20 20:07:44.015690
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils._text import to_bytes

    # Define facts returned by the SshPubKeyFactCollector

# Generated at 2022-06-20 20:08:01.609410
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    x = SshPubKeyFactCollector()
    assert 'ssh_host_pub_keys' in x.collect()

# Generated at 2022-06-20 20:08:03.570317
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
  # TODO: Unit test needed
  return 0



# Generated at 2022-06-20 20:08:09.531242
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """
        Test case for method collect of class SshPubKeyFactCollector.
        Test method for the collect method of the ssh pub key fact collector.
    """
    SshPubKeyFactCollector_instance = SshPubKeyFactCollector()
    # SshPubKeyFactCollector_instance.collect()
    assert SshPubKeyFactCollector_instance.collect() == {}


# Generated at 2022-06-20 20:08:12.478231
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert isinstance(x, SshPubKeyFactCollector)
    assert x.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:08:16.536885
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public',
                               'ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public',
                               'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:08:25.369020
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector.ssh_pub_key import SshPubKeyFactCollector

# Generated at 2022-06-20 20:08:30.684205
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:08:40.918469
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():

    import os
    import time
    import errno
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector

    _saved_isdir = os.path.isdir
    _saved_isfile = os.path.isfile
    _saved_get_file_content = BaseFactCollector.get_file_content

    # This is not an exhaustive test.  It doesn't not test every case that
    # the collect method handles.  However, it is a unit test and it should
    # prove to be an adequate test to detect if the changes made to the collect
    # method cause it to start failing.

    # This method is used for running unit tests for the collect method.  It
    # does this by mocking up the os module.  It overrides the modules isdir
    # functions and isfile functions

# Generated at 2022-06-20 20:08:42.487465
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert 'ssh_pub_keys' == x.name
    assert len(x.collect()) > 0

# Generated at 2022-06-20 20:08:50.945697
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import inspect

    method = 'collect'
    facts = {}

    factmodule = SshPubKeyFactCollector(module=None)
    param = inspect.getargspec(getattr(factmodule, method))[0][0]
    result = getattr(factmodule, method)(collected_facts=facts)
    print(result)
    #assert result['ansible_distribution'] == 'CentOS'
    #assert result['ansible_distribution_major_version'] == '5'
    #assert result['ansible_distribution_version'] == '5.11'
    #assert result['ansible_distribution_release'] == 'Final'

# Generated at 2022-06-20 20:09:26.313185
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    ssh_pub_key_facts = SshPubKeyFactCollector.collect()
    assert type(ssh_pub_key_facts) == dict


# Generated at 2022-06-20 20:09:33.719414
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    import shutil

    fd, keyfile = tempfile.mkstemp()
    temp_path = os.path.dirname(keyfile)

    ssh_pub_key_facts = SshPubKeyFactCollector().collect()

    # clean up
    os.remove(keyfile)
    os.close(fd)
    shutil.rmtree(temp_path)
    assert ssh_pub_key_facts is not None

# Generated at 2022-06-20 20:09:41.415147
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_content

    # Mock get_file_content

# Generated at 2022-06-20 20:09:43.476822
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    local_test_ssh_pub_key_facts = SshPubKeyFactCollector()
    assert local_test_ssh_pub_key_facts is not None

# Generated at 2022-06-20 20:09:52.325420
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():

    # check if class constructor creates instance of class SshPubKeyFactCollector
    ssh_pub_key_fact_collector = SshPubKeyFactCollector()
    assert isinstance(ssh_pub_key_fact_collector, SshPubKeyFactCollector)

    # check if class SshPubKeyFactCollector has correct fields
    assert ssh_pub_key_fact_collector.name == 'ssh_pub_keys'
    assert ssh_pub_key_fact_collector._fact_ids == set(['ssh_host_pub_keys',
                                                        'ssh_host_key_dsa_public',
                                                        'ssh_host_key_rsa_public',
                                                        'ssh_host_key_ecdsa_public',
                                                        'ssh_host_key_ed25519_public'])


# Generated at 2022-06-20 20:09:57.718884
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = spark_ssh_pub_key_collector_fake_module('/etc/ssh', algo_list=['dsa', 'rsa', 'ecdsa', 'ed25519'])
    collecter = SshPubKeyFactCollector(module=module, collected_facts=None)
    return collecter.collect()

# Fake module to test SshPubKeyFactCollector class

# Generated at 2022-06-20 20:10:07.521001
# Unit test for constructor of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:10:14.166278
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    # in order to unit test this module, we need to create a class instance
    # and get a reference to the _fact_ids class member.
    # pylint: disable=protected-access
    spkfc = SshPubKeyFactCollector()
    fact_ids = spkfc._fact_ids

    assert isinstance(fact_ids, set)

    assert 'ssh_host_pub_keys' in fact_ids
    assert 'ssh_host_key_dsa_public' in fact_ids
    assert 'ssh_host_key_rsa_public' in fact_ids
    assert 'ssh_host_key_ecdsa_public' in fact_ids
    assert 'ssh_host_key_ed25519_public' in fact_ids

# Generated at 2022-06-20 20:10:24.948411
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fc = SshPubKeyFactCollector()


# Generated at 2022-06-20 20:10:31.472335
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    test_SshPubKeyFactCollector = SshPubKeyFactCollector()
    assert 'ssh_pub_keys' == test_SshPubKeyFactCollector.name
    assert set(['ssh_host_pub_keys', 'ssh_host_key_dsa_public',
                'ssh_host_key_rsa_public', 'ssh_host_key_ecdsa_public',
                'ssh_host_key_ed25519_public']) \
        == test_SshPubKeyFactCollector._fact_ids

# Generated at 2022-06-20 20:11:55.109435
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    obj = SshPubKeyFactCollector()
    assert obj.name == 'ssh_pub_keys'
    assert obj._fact_ids == {'ssh_host_pub_keys',
                             'ssh_host_key_dsa_public',
                             'ssh_host_key_rsa_public',
                             'ssh_host_key_ecdsa_public',
                             'ssh_host_key_ed25519_public'}


# Generated at 2022-06-20 20:12:06.827484
# Unit test for method collect of class SshPubKeyFactCollector

# Generated at 2022-06-20 20:12:08.584344
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    """Test the constructor of class SshPubKeyFactCollector"""
    assert SshPubKeyFactCollector.name == 'ssh_pub_keys'

# Generated at 2022-06-20 20:12:17.483682
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import tempfile
    facts = {}
    algos = ('dsa', 'rsa', 'ecdsa', 'ed25519')
    keydir = tempfile.mkdtemp()

    for algo in algos:
        factname = 'ssh_host_key_%s_public' % algo
        filename = '%s/ssh_host_%s_key.pub' % (keydir, algo)
        with open(filename, 'w') as f:
            f.write("%s %s" % (algo, algo))

    # create collector object
    collector = SshPubKeyFactCollector()

    # set the keydir to the temp dir that was just created
    collector.keydirs = [keydir]

    # add the keys to the facts
    facts = collector.collect

# Generated at 2022-06-20 20:12:27.598377
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    import os
    import shutil
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a key within the temporary directory
    key_filename = os.path.join(tmpdir, 'ssh_host_rsa_key.pub')

# Generated at 2022-06-20 20:12:29.130471
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    module = None
    collected_facts = None
    c = SshPubKeyFactCollector(module=module, collected_facts=collected_facts)

    assert c.collect()
    assert c._fact_ids

# Generated at 2022-06-20 20:12:38.120462
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    fake_collector = SshPubKeyFactCollector()
    fake_collector._get_file_content = lambda x: x[0] if x[0] else None
    ssh_pub_key_facts = fake_collector.collect(collected_facts={})

    assert ssh_pub_key_facts['ssh_host_key_dsa_public'] == 'ssh_host_key_dsa_public'
    assert ssh_pub_key_facts['ssh_host_key_rsa_public'] == 'ssh_host_key_rsa_public'
    assert ssh_pub_key_facts['ssh_host_key_ecdsa_public'] == 'ssh_host_key_ecdsa_public'

# Generated at 2022-06-20 20:12:45.811095
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    """Unit test for method collect of class SshPubKeyFactCollector."""


# Generated at 2022-06-20 20:12:55.704274
# Unit test for method collect of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    # The keys here are all invalid, but should be long enough to test
    # that the correct key is being return for each type

# Generated at 2022-06-20 20:13:02.654780
# Unit test for constructor of class SshPubKeyFactCollector
def test_SshPubKeyFactCollector():
    x = SshPubKeyFactCollector()
    assert x.name == 'ssh_pub_keys'
    assert x._fact_ids == set(['ssh_host_pub_keys',
                               'ssh_host_key_dsa_public','ssh_host_key_rsa_public',
                               'ssh_host_key_ecdsa_public','ssh_host_key_ed25519_public'])
