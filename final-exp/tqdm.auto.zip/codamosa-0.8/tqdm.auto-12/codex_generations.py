

# Generated at 2022-06-12 14:26:55.180551
# Unit test for function trange
def test_trange():
    """
    >>> for i in trange(3, desc='abc'):
    ...     pass
    abc: 100%|##########| 3/3 [00:00<?, ?it/s]
    """
    pass

# Generated at 2022-06-12 14:26:59.250635
# Unit test for function trange
def test_trange():
    from .auto import trange
    from .utils import format_sizeof
    import time
    import os

    r = trange(10, desc='Reading chuncks', leave=False)
    for i in r:
        time.sleep(0.01)
        r.set_postfix(chunk_size=format_sizeof(os.urandom(1000), 'B'))

# Generated at 2022-06-12 14:27:02.501904
# Unit test for function trange
def test_trange():
    """
    Smoke test for `trange` function.
    """
    it = trange(5)
    next(it)
    next(it)
    next(it)
    next(it)
    next(it)
    try:
        next(it)
    except StopIteration:
        pass

# Generated at 2022-06-12 14:27:12.090051
# Unit test for function trange
def test_trange():
    """Test the trange() function."""

# Generated at 2022-06-12 14:27:17.113102
# Unit test for function trange
def test_trange():
    """Testing trange"""
    from .std import trange as std_trange
    from .asyncio import trange as asyncio_trange

    for i in trange(10, desc="test auto trange"):
        assert i in range(10)
    for i in [std_trange, asyncio_trange]:
        for j in i(10, desc="test trange"):
            assert j in range(10)

# Generated at 2022-06-12 14:27:25.388709
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    Unit test for function trange
    """
    from .utils import _term_move_up
    import time

    # Test trange
    print("Testing trange...")
    with tqdm(total=100) as pbar:
        for i in trange(10):
            pbar.update(10)
            time.sleep(0.01)
    time.sleep(1)

    # Test bar_format
    print("Testing bar_format...")
    with tqdm(total=100, bar_format="{l_bar}{bar}|") as pbar:
        for i in range(10):
            pbar.update(10)
            sys.stdout.write(_term_move_up())
    time.sleep(1)

# Generated at 2022-06-12 14:27:28.317829
# Unit test for function trange
def test_trange():
    """
    Test trange() from tqdm.auto
    """
    from .std import tqdm
    for i in trange(10):
        tqdm.write("i={0}".format(i))

# Generated at 2022-06-12 14:27:30.912539
# Unit test for function trange
def test_trange():
    for _ in trange(3):
        pass

    for _ in trange(3, 4):
        pass

    for _ in trange(3, 4, 5):
        pass


# Generated at 2022-06-12 14:27:40.159825
# Unit test for function trange
def test_trange():
    """
        - Tests trange() with default kwargs
        - Tests trange() with non-default kwargs
    """
    from .std import TqdmDeprecationWarning
    for inp in [1, (1,), range(1), enumerate(range(1)), "abcde", dict()]:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
            assert list(trange(inp)) == trange(max(len(inp) - 1, 0))


# Generated at 2022-06-12 14:27:48.947070
# Unit test for function trange
def test_trange():
    """
    Tests `trange` on `tqdm.auto`
    """
    from .gui import tqdm
    from .std import trange

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        assert trange(10) == tqdm(range(10))
        assert trange(1, 10) == tqdm(range(1, 10))
        assert trange(1, 10, 2) == tqdm(range(1, 10, 2))

        assert (trange(10) ==
                tqdm.tqdm(range(10), unit_scale=False,
                          disable=None, dynamic_ncols=False))
