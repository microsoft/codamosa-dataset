

# Generated at 2022-06-12 14:27:04.119775
# Unit test for function trange
def test_trange():
    import time
    from itertools import count

    for i in trange(5, desc='5 loops:'):  # pylint: disable=not-callable
        for _ in count():
            if time.monotonic() > i:
                break

# Generated at 2022-06-12 14:27:10.154811
# Unit test for function trange
def test_trange():
    from .auto import trange
    from .tqdm import tnrange
    from .std import tqdm

    assert [t.n for t in trange(9, 9, 9)] == [tnrange(9, 9, 9)] == [tqdm(range(9, 9, 9))]
    assert [t.n for t in trange(9, 9, -9)] == [tnrange(9, 9, -9)] == [tqdm(range(9, 9, -9))]

# Generated at 2022-06-12 14:27:17.926924
# Unit test for function trange
def test_trange():
    """
    Runs a unittest on function `trange`:
    - Check that `trange` is not `range`
    - Check that `list(trange(3)) == [0, 1, 2]`
    - Check that `list(trange(1, 3)) == [1, 2]`
    - Check that `list(trange(1, 3, 2)) == [1]`
    """
    assert trange is not range

    assert list(trange(3)) == [0, 1, 2]
    assert list(trange(1, 3)) == [1, 2]
    assert list(trange(1, 3, 2)) == [1]

# Generated at 2022-06-12 14:27:26.359605
# Unit test for function trange
def test_trange():
    """ Test trange wrapper """
    from .std import tqdm
    from .utils import _range

    # Test if trange gives same results as range
    ranges = (
        100,
        1,
        10 ** 5,
        10 ** 9,
        10 ** 9 + 1,
        10 ** 9 + 7,
        10 ** 10 - 7,
        10 ** 10 + 7,
        10 ** 20 - 7,
        10 ** 20 + 7,
    )
    for r in ranges:
        r1 = sum(range(r))
        r2 = sum(tqdm(range(r), leave=False))
        r3 = sum(trange(r))
        assert r1 == r2, (r1, r2)
        assert r1 == r3, (r1, r3)

    # Test if tr

# Generated at 2022-06-12 14:27:29.373800
# Unit test for function trange
def test_trange():
    """Test function `trange`"""
    with tqdm(desc='test', total=10) as t:
        for i in trange(10):
            t.update()
            assert i == t.n

# Generated at 2022-06-12 14:27:38.916050
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import get_instances
    from .std import StatusPrinter
    from .std import units
    from .std import trange

    with get_instances(leave=False) as (tp,):
        _iter = [(0, '_tqdm_transforms_print_0'), (1, '_tqdm_transforms_print_1'),
                 (2, '_tqdm_transforms_print_2'), (3, '_tqdm_transforms_print_3')]

        trange(4, file=sys.stdout)

        # Check that a status printer is created
        assert len(tp.instances) == 1
        t = tp.instances[0]  # type: StatusPrinter

        # Check that the original _

# Generated at 2022-06-12 14:27:39.936114
# Unit test for function trange
def test_trange():
    """Test function trange"""
    trange(10, desc="test range")

# Generated at 2022-06-12 14:27:41.570519
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    assert sys.version_info[:2] < (3, 6) or not isinstance(trange(1), notebook_trange)

# Generated at 2022-06-12 14:27:42.746277
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    trange(3, desc="desc")

# Generated at 2022-06-12 14:27:50.236431
# Unit test for function trange
def test_trange():
    """Test function `trange`"""
    from .std import FormatCustomText
    assert tqdm(range(3), desc='trange') == list(trange(3, desc='trange'))


# Test `tqdm.auto.tqdm` is not `tqdm.notebook.tqdm` on Python2
if sys.version_info[:2] < (3, 6) and notebook_tqdm != std_tqdm:
    assert tqdm is not notebook_tqdm
    assert trange is not notebook_trange