

# Generated at 2022-06-12 14:27:00.835261
# Unit test for function trange
def test_trange():
    from io import StringIO
    from tqdm import _tqdm_notebook
    _range = range if sys.version_info[0] == 2 else lambda *args: list(range(*args))
    with StringIO() as our_file, StringIO() as orig_file:
        # Test `trange`
        trange(_range(3), file=our_file).close()
        _tqdm_notebook.tqdm(_range(3), file=orig_file).close()
        assert our_file.getvalue() == orig_file.getvalue()
        # Test `tqdm`
        expected = _tqdm_notebook.tqdm(_range(3), file=orig_file).close()
        our = tqdm(_range(3), file=our_file)
        our.refresh() 

# Generated at 2022-06-12 14:27:02.758533
# Unit test for function trange
def test_trange():
    """ Test for trange """
    from .std import tqdm
    assert isinstance(trange(1), tqdm)

# Generated at 2022-06-12 14:27:05.186179
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from tqdm import trange

    for _ in trange(4):
        pass

    for _ in trange(4, leave=True):
        pass



# Generated at 2022-06-12 14:27:08.785569
# Unit test for function trange
def test_trange():
    """Test for `tqdm.auto`"""
    from .std import BarDescriptor, tqdm_gui, tqdm_notebook


# Generated at 2022-06-12 14:27:10.104541
# Unit test for function trange
def test_trange():
    assert list(trange(5)) == list(range(5))

# Generated at 2022-06-12 14:27:14.886007
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    import time

    for _ in trange(2, desc='1st loop'):
        for _ in trange(5, desc='2nd loop', leave=False):
            for _ in trange(100, desc='3nd loop'):
                time.sleep(0.01)

# Generated at 2022-06-12 14:27:18.403318
# Unit test for function trange
def test_trange():
    """Unit test function"""
    from ._utils import _version as tqdm_version  # pylint: disable=import-outside-toplevel
    assert tqdm(range(5))._version == tqdm_version, 'function tqdm ok'
    assert trange(5)._version == tqdm_version, 'function trange ok'

# Generated at 2022-06-12 14:27:21.469779
# Unit test for function trange
def test_trange():
    """
    Verify that trange works as expected and returns a tqdm iterator.
    """
    from tqdm.auto import tqdm
    assert trange(3).__class__ == tqdm(range(3)).__class__

# Generated at 2022-06-12 14:27:23.613446
# Unit test for function trange
def test_trange():
    """
    Tests whether function trange can import properly.
    """
    with tqdm(total=1, unit='i') as pbar:
        pbar.update()

# Generated at 2022-06-12 14:27:26.216319
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from ._tqdm import trange  # pylint: disable=import-outside-toplevel
    list(trange(10))
    assert len(list(trange(1, 10))) == 9