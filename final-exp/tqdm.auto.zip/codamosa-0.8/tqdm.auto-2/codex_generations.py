

# Generated at 2022-06-12 14:27:01.531475
# Unit test for function trange
def test_trange():
    """Test that trange is what we expect it to be"""
    assert trange(1) == tqdm(range(1))
    assert not trange(0)

# Generated at 2022-06-12 14:27:06.662165
# Unit test for function trange
def test_trange():
    try:
        from IPython import get_ipython  # NOQA
    except ImportError:
        pass
    else:  # check if we are in an IPython/Jupyter notebook
        try:  # in IPython/notebook, avoid asyncio warning
            get_ipython().magic("config InlineBackend.close_figures=False")
        except AttributeError:  # IPython older than 5.0 ?
            get_ipython().magic("pylab inline")
    from .asyncio import _range  # avoid import loop
    assert isinstance(trange(2), _range)

# Generated at 2022-06-12 14:27:16.545895
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from pytest import raises
    assert list(trange(0)) == []
    assert list(trange(1)) == [0]
    assert list(trange(1, 0)) == []
    assert list(trange(1, 1)) == [1]
    assert list(trange(1, 2)) == [1]
    assert list(trange(2, 3)) == [2]
    assert list(trange(1, 10, 0)) == []
    assert list(trange(1, 10, 1)) == list(range(1, 10))
    assert list(trange(1, 10, 2)) == list(range(1, 10, 2))
    assert list(trange(10, 1, -1)) == list(range(10, 1, -1))

# Generated at 2022-06-12 14:27:21.634473
# Unit test for function trange
def test_trange():
    from .gui import tqdm as gui_tqdm
    from .gui import tgrange as gui_tgrange
    for t in (notebook_tqdm, asyncio_tqdm, gui_tqdm):
        assert tgrange(3, desc="desc") == t(range(3), desc="desc")


if __name__ == "__main__":
    test_trange()
    print(trange(10))

# Generated at 2022-06-12 14:27:24.146086
# Unit test for function trange
def test_trange():
    """Tests for function `tqdm.auto.trange`"""
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', TqdmExperimentalWarning)
        l = list(trange(5))
    assert l == list(range(5))

# Generated at 2022-06-12 14:27:26.429628
# Unit test for function trange
def test_trange():
    list(trange(5))
    list(trange(5, leave=True))
    list(trange(5, dynamic_ncols=True))
    list(trange(5, smoothing=0.01))

# Generated at 2022-06-12 14:27:28.498738
# Unit test for function trange
def test_trange():
    """Test trange function"""
    assert list(trange(10)) == list(notebook_trange(10))
    assert list(trange(10)) == list(asyncio_tqdm(range(10)))

# Generated at 2022-06-12 14:27:31.542797
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    assert list(trange(0)) == []
    assert list(trange(3)) == [0, 1, 2]
    assert list(trange(1, 3)) == [1, 2]
    assert list(trange(0, 3, 2)) == [0, 2]
    assert list(trange(1, 3, 2)) == [1]

# Generated at 2022-06-12 14:27:36.840460
# Unit test for function trange
def test_trange():
    from .utils import _range
    from .std import tqdm as _tqdm

    # Test if each trange is an iterable for 1000 loops
    for i in _range(1000):
        assert next(iter(trange(1))) == 0

    # Test if each trange is an iterable with initial value
    for i in _range(1000):
        assert next(iter(trange(i))) == i - 1

    # Test if each trange is an iterable with `initial` kwarg
    for i in _range(1000):
        assert next(iter(trange(0, i, initial=i))) == i - 1

    # Test if tqdm is called for 1000 loops

# Generated at 2022-06-12 14:27:41.247477
# Unit test for function trange
def test_trange():
    """
    Tests that `trange` works as expected
    """
    assert list(trange(0)) == []
    assert list(trange(0, 0)) == []
    assert list(trange(1)) == [0]
    assert list(trange(0, 1)) == [0]
    assert list(trange(0, 2)) == [0, 1]
    assert list(trange(1, 4)) == [1, 2, 3]
    assert list(trange(0, 6, 2)) == [0, 2, 4]