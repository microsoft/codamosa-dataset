

# Generated at 2022-06-12 14:27:00.908455
# Unit test for function trange
def test_trange():  # pylint: disable=missing-docstring
    r = trange(6)
    assert r.total == 6
    it = iter(r)
    assert next(it) == 0
    assert next(it) == 1
    assert next(it) == 2
    r.update(2)
    assert next(it) == 4
    assert next(it) == 5
    with pytest.raises(StopIteration):
        next(it)



# Generated at 2022-06-12 14:27:03.473644
# Unit test for function trange
def test_trange():
    "Test function trange in tqdm/__init__.py"
    from .std import trange
    list(trange(3))
    list(trange(10, 0, -1))


# Generated at 2022-06-12 14:27:13.183128
# Unit test for function trange
def test_trange():
    import os
    import tempfile
    out = tempfile.TemporaryFile(mode='w+t')
    trange(3, file=out, miniters=1)
    out.seek(0)
    assert len(out.readlines()) == 3

    trange(3, file=sys.stdout)
    out = tempfile.TemporaryFile(mode='w+t')
    trange(3, file=out, ncols=0)
    out.seek(0)
    assert len(out.readlines()) == 1

    trange(3, file=sys.stdout, ncols=1, miniters=1)
    out = tempfile.TemporaryFile(mode='w+t')
    trange(3, file=out, mininterval=1)
    out.seek(0)


# Generated at 2022-06-12 14:27:15.283223
# Unit test for function trange
def test_trange():
    """Checks that trange is equivalent to tqdm(range)"""
    from .tests import BaseTestClass
    from .utils import FormatStrin

# Generated at 2022-06-12 14:27:23.731802
# Unit test for function trange
def test_trange():
    "Test trange function, especially against `range`"
    from .asyncio import trange, tqdm
    trange(1)
    with trange(10) as t:
        for i in range(10):
            t.update()
    trange(10, desc="desc")
    trange(0, 1, 0.001, desc="v", leave=False)
    trange(10, desc="desc", leave=False)
    trange(10, desc="desc", leave=False, ascii=True, unit="B")
    trange(10, desc="desc", leave=False, ascii=True, unit_scale=True, unit="B")
    trange(10, desc="desc", leave=False, ascii=True, unit_scale=True, unit="iB")
    trange

# Generated at 2022-06-12 14:27:26.597812
# Unit test for function trange
def test_trange():
    """Test trange"""
    with tqdm(total=10) as t:
        for i in trange(10):
            assert i == t.n
            t.update(1)


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-12 14:27:28.346437
# Unit test for function trange
def test_trange():
    import gc
    from tqdm.auto import tqdm, trange
    for i in trange(4, desc="1st loop"):
        for j in trange(5, desc="2nd loop", leave=i==3):
            for k in trange(50, desc="3rd loop", leave=i==3 and j==4):
                pass
    gc.collect()

# Generated at 2022-06-12 14:27:32.546923
# Unit test for function trange
def test_trange():
    """Test trange function"""
    list(trange(5))
    list(trange(2, 5))
    list(trange(2, 5, 2))
    with tqdm(total=5) as pbar:
        for _ in trange(4):
            pbar.update()

# Generated at 2022-06-12 14:27:38.019296
# Unit test for function trange
def test_trange():
    def myfunc():
        for i in trange(10, desc="Test"):
            assert i <= 9
            yield i

    # Test through a generator
    gen = myfunc()
    for i in gen:
        assert i <= 9

    # Test that the generator has been exhausted
    try:
        next(gen)
    except StopIteration:
        pass
    else:
        raise ValueError("Generator has not been exhausted")


# Unit tests for class tqdm

# Generated at 2022-06-12 14:27:39.718176
# Unit test for function trange
def test_trange():
    """Test for trange() function."""
    for t in trange(3, leave=False):
        assert isinstance(t, int)

# Generated at 2022-06-12 14:27:42.641872
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Test for `trange`"""
    for _ in trange(5):
        pass

# Generated at 2022-06-12 14:27:49.873483
# Unit test for function trange
def test_trange():
    """
    Tests the function trange.
    """
    assert list(trange(10)) == list(tqdm(range(10)))
    assert list(trange(10, 0, -1)) == list(tqdm(range(10, 0, -1)))
    assert list(trange(10, 15)) == list(tqdm(range(10, 15)))
    assert list(trange(10, 15, 2)) == list(tqdm(range(10, 15, 2)))

# Generated at 2022-06-12 14:27:51.462052
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import BarTrange
    assert trange(0, 10).__class__ == BarTrange

# Generated at 2022-06-12 14:27:54.438047
# Unit test for function trange
def test_trange():
    """Testing trange function"""
    assert list(tqdm(trange(5))) == list(tqdm(range(5)))


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-12 14:27:55.267771
# Unit test for function trange
def test_trange():
    for _ in trange(3):
        pass

# Generated at 2022-06-12 14:28:03.083197
# Unit test for function trange
def test_trange():
    """Test for :func:`~tqdm.auto.trange`"""
    from .std import tqdm
    from .std import _supports_unicode, _environ_cols_wrapper
    from ._utils import _term_move_up
    try:
        from io import StringIO
    except ImportError:
        from cStringIO import StringIO
    unicode_envs = ["LANGUAGE=en_US.UTF-8", "LANG=en_US.UTF-8", "LC_ALL=en_US.UTF-8"]
    unicode_support = (_supports_unicode() and
                       any(_environ_cols_wrapper(env) for env in unicode_envs))

    def trange_test(**kwargs):
        """Internal trange test function"""
        s = StringIO

# Generated at 2022-06-12 14:28:06.258766
# Unit test for function trange
def test_trange():
    """Test to see if trange works"""
    assert sum(trange(10)) == sum(range(10))
    assert sum(trange(15)) == sum(range(15))
    assert sum(trange(20)) == sum(range(20))
    assert sum(trange(25)) == sum(range(25))

# Generated at 2022-06-12 14:28:08.599674
# Unit test for function trange
def test_trange():
    """ Unit test for function trange """
    for _ in trange(10, desc="desc"):
        pass


# Generated at 2022-06-12 14:28:11.426887
# Unit test for function trange
def test_trange():
    """
    Returns pass if function `trange` works.
    """
    for _ in trange(5, desc='Testing trange...', ncols=75):
        time.sleep(0.01)
    return "Pass"

# Generated at 2022-06-12 14:28:15.532869
# Unit test for function trange
def test_trange():
    """ Test tqdm.auto.trange """
    assert str(list(trange(10))) == "[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]"
    assert str(list(trange(10))) == "[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]"


if __name__ == "__main__":
    from ._utils import _test
    _test()