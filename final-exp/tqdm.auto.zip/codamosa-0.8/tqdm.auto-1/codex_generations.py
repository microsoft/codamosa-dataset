

# Generated at 2022-06-12 14:27:07.840044
# Unit test for function trange
def test_trange():
    """Test trange functionality."""
    # view bar
    l = 5

    assert len(list(tqdm(range(l), disable=True))) == l
    assert len(list(tqdm(range(l)))) == l

    # py27, py36 (notebook_tqdm != std_tqdm)
    assert notebook_trange(l) == trange(l)

    # disable
    assert trange(0, disable=True)

# Generated at 2022-06-12 14:27:17.280412
# Unit test for function trange
def test_trange():
    from .autonotebook import _range
    from .asyncio import _range as _range_asyncio
    from .std import _range as _range_std
    for tqdm_func in (notebook_trange, asyncio_tqdm, std_tqdm):
        for _ in tqdm_func(_range(2 if tqdm_func is std_tqdm else 0),
                           ascii=True, desc="subtest",
                           postfix=lambda: "postfix"):
            pass
        for _ in tqdm_func(_range_asyncio(2),
                           ascii=True, desc="subtest",
                           postfix=lambda: "postfix"):
            pass

# Generated at 2022-06-12 14:27:20.775228
# Unit test for function trange
def test_trange():
    """Test that trange instantiates a tqdm instance"""
    from .std import tqdm as tqdm_std
    _ = trange(10)  # pylint: disable=pointless-statement
    assert isinstance(_, tqdm_std)

# Generated at 2022-06-12 14:27:22.955079
# Unit test for function trange
def test_trange():
    """
    >>> assert trange(10)
    """
    pass

if __name__ == "__main__":
    from doctest import testmod
    testmod()

# Generated at 2022-06-12 14:27:30.049241
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test for function trange."""
    from itertools import count

    for n in trange(10, 50, 10):
        assert n in range(10, 50, 10)
        for i in trange(100):
            assert i in range(100)
            for j in trange(1000, leave=False):
                assert j in range(1000)

    # Test nested tranges
    nested_trange = trange(1, leave=False)
    for n in nested_trange:
        trange(n, leave=False)
    nested_trange.close()

    # Test nested loops
    for n in trange(1, leave=False):
        for _ in trange(n, leave=False):
            pass
    assert trange.last_print_t is None

   

# Generated at 2022-06-12 14:27:38.876750
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from .std import format_interval

    list(trange(3))

    with tqdm(total=3) as t:
        assert t.total == 3

        t.update()
        t.update(1)
        assert t.n == 2
        assert "2/3" in format_interval(t.elapsed)
        assert "2it/s" in format_interval(t.elapsed)
        t.update()

        assert t.n == 3
        assert t.last_print_n == 3
        assert "3/3" in format_interval(t.elapsed)
        assert "3it/s" in format_interval(t.elapsed)

# Generated at 2022-06-12 14:27:40.361726
# Unit test for function trange
def test_trange():
    """Tests trange function"""
    assert list(trange(3)) == [0, 1, 2]

# Generated at 2022-06-12 14:27:42.852674
# Unit test for function trange
def test_trange():
    """Test tqdm.trange"""
    # pylint: disable=missing-docstring
    from .std import trange
    trange(1)
    trange(1, 1)
    trange(1, 1, 1)
    trange(1, 1, -1)

# Generated at 2022-06-12 14:27:53.188811
# Unit test for function trange
def test_trange():
    """
    Check `trange` works as expected:
    - it uses [tqdm.auto.tqdm](https://pypi.org/project/tqdm#tqdm-auto)
    - it results in the same output.
    """
    for module in (notebook_tqdm, notebook_trange, std_tqdm, asyncio_tqdm):
        print("Test trange against", module.__name__)
        # use 1 because tqdm's default mininterval is 1, so output is guaranteed
        for _ in trange(1, 2):
            pass
        for _ in trange(2, 3, 1):
            pass
        for _ in trange(3, 4, 1):
            pass
        for _ in trange(4, 5, 1):
            pass

# Generated at 2022-06-12 14:28:01.140872
# Unit test for function trange
def test_trange():
    assert list(trange(0)) == []
    assert list(trange(1)) == [0]
    assert list(trange(1, 0)) == []
    assert list(trange(1, 1)) == []
    assert list(trange(1, 2)) == [1]
    assert list(trange(1, 3)) == [1, 2]
    # Non-unit step
    assert list(trange(0, 5, 2)) == [0, 2, 4]
    assert list(trange(0, 6, 2)) == [0, 2, 4]
    assert list(trange(1, 5, 2)) == [1, 3]


if __name__ == "__main__":
    test_trange()