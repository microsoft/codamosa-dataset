

# Generated at 2022-06-12 14:27:08.225156
# Unit test for function trange
def test_trange():
    """eg: python -c 'import tqdm.auto; tqdm.auto.test_trange()'"""
    from .utils import _term_move_up
    from .tqdm import trange

    for _ in trange(4, file=sys.stdout):
        print('test', end='')  # noqa: T001
        sys.stdout.flush()
        _term_move_up()
        print('\r\r\r\r', end='')
        sys.stdout.flush()


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-12 14:27:12.185455
# Unit test for function trange
def test_trange():
    """
    Ensure the trange function uses the tqdm.auto.tqdm class
    """
    for n in trange(10, desc='my trange loop'):
        pass
    assert n == 9
    assert isinstance(tqdm.write, tqdm)

# Generated at 2022-06-12 14:27:14.293477
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    x = [i for i in trange(2, 5)]
    assert x == [2, 3, 4]

# Generated at 2022-06-12 14:27:20.622514
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import __version__
    from ._version import get_versions
    from ._tqdm import tnrange
    from ._tqdm_gui import tqdm_gui
    from .gui import tgrange

    assert tqdm(range(3)).__iter__().__next__() != 2
    assert trange(3).__iter__().__next__() != 2
    assert tnrange(3).__iter__().__next__() != 2
    assert tqdm_gui(range(3)).__iter__().__next__() != 2
    assert tgrange(3).__iter__().__next__() != 2
    assert __version__ == get_versions()["version"]

# Generated at 2022-06-12 14:27:22.536487
# Unit test for function trange
def test_trange():
    """
    Tests for trange
    """
    assert list(trange(3)) == [0, 1, 2]

if __name__ == "__main__":
    import nose
    nose.runmodule()

# Generated at 2022-06-12 14:27:24.057817
# Unit test for function trange
def test_trange():
    """Test trange function"""
    with tqdm(total=10) as t:
        assert t.total == 10



# Generated at 2022-06-12 14:27:28.090282
# Unit test for function trange
def test_trange():
    x = list(range(1000))
    for no_tqdm in [False, True]:
        for leave in [False, True]:
            if leave:
                tr = trange(len(x), leave=True)
            else:
                tr = trange(len(x))
            for _ in tr:
                if no_tqdm:
                    y = x.pop()
                else:
                    y = x.pop()
                    tr.update()
            assert y == 0
            assert len(x) == 0

# Generated at 2022-06-12 14:27:37.705227
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from .utils import format_sizeof
    from .std import format_interval

    def test_tqdm(tqdm, n, desc, **kwargs):
        """Unit test for function trange"""
        with tqdm(total=n, desc=desc, **kwargs) as pbar:
            for i in pbar:
                pass
        return pbar

    desc = 'Desc'
    n = 1000
    kwargs = dict(unit="bytes", ascii=True, dynamic_ncols=True, file=sys.stdout)
    pbar = test_tqdm(trange, n, desc, **kwargs)
    assert pbar.n == n
    assert pbar.last_print_n == pbar.n
    assert pbar.last_

# Generated at 2022-06-12 14:27:42.349295
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .autonotebook import trange as notebook_trange
    from .asyncio import tqdm as asyncio_tqdm
    from .std import trange as std_trange

    class tqdm(notebook_trange, asyncio_tqdm):  # pylint: disable=inconsistent-mro
        pass

    for cls in (notebook_trange, asyncio_tqdm, std_trange, tqdm, trange):
        assert list(cls(range(10))) == list(range(10))

# Generated at 2022-06-12 14:27:44.038837
# Unit test for function trange
def test_trange():
    """Test that instantiation of trange works"""
    trange(10)