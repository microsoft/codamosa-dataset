

# Generated at 2022-06-12 14:27:10.738543
# Unit test for function trange
def test_trange():
    from .auto import trange
    from .auto import tqdm as tqdm_auto
    from .std import tqdm as tqdm_std
    from .std import _range as range
    import sys

    assert tqdm_auto == tqdm_std

    for func in [trange, tqdm_auto]:
        assert isinstance(func(1), tqdm_auto)

        if sys.version_info[:2] < (3, 6):
            assert func(1).__class__ == tqdm_auto
        else:  # Python3.6+
            assert issubclass(func(1).__class__, tqdm_auto)

        assert list(func(1)) == [0]
        assert list(func(1, 1)) == []
        assert list(func(1, 2))

# Generated at 2022-06-12 14:27:16.432232
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Sanity check for function trange"""
    # pylint: disable=invalid-name
    import time

    with tqdm(
        total=100, file=sys.stderr, desc="test_trange", leave=False,
    ) as t:
        for i in trange(100):
            time.sleep(0.01)
            t.update()
    print("End Test")

# Generated at 2022-06-12 14:27:24.361869
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test for function trange."""
    # Check some tqdm attributes
    assert tqdm.monitor_interval == 5
    assert tqdm.gui == True
    assert tqdm.mininterval == 0.1
    assert tqdm.miniters == 1
    assert tqdm.ascii == None
    assert tqdm.mininterval == 0.1

    # trange must be imported
    res = list(trange(10))
    assert res == list(range(10))

    # Check manual init
    _t = tqdm(10)
    del _t

    # Check iterable argument
    _t = tqdm(range(10))
    del _t

# Generated at 2022-06-12 14:27:29.670543
# Unit test for function trange
def test_trange():
    try:
        import numpy as np
        for i in trange(3):
            assert np.mean([i] * i) == i / 2

    except ImportError:
        for i in trange(3):
            assert sum([i] * i) == i * (i + 1) / 2

    for i in trange(3, desc="Pizza"):
        pass

    for i in trange(3, desc="Pizza", total=10):
        pass

    for _ in trange(0):
        raise RuntimeError("Should not be reached!")
    else:
        assert i == 2

    try:
        for _ in trange(1, 0):
            raise RuntimeError("Should not be reached!")
    except ValueError:
        pass

# Generated at 2022-06-12 14:27:35.273698
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    from .std import compat
    import time
    from .std import normalized_range

    t = trange(*(list(compat.range_type(10)) +
                 list(compat.range_type(100, 110))), leave=False)
    for _ in normalized_range(t):
        time.sleep(0.01)
        # pass

# Generated at 2022-06-12 14:27:39.921122
# Unit test for function trange
def test_trange():
    trange().__next__()
    assert trange(10).__next__() == 0
    assert trange(0, 10).__next__() == 0
    assert trange(0, 10, 1).__next__() == 0
    list(trange(2))
    list(trange(10**8))
    list(trange(10**8, leave=True))
    list(trange(0))



# Generated at 2022-06-12 14:27:45.723539
# Unit test for function trange

# Generated at 2022-06-12 14:27:55.229523
# Unit test for function trange
def test_trange():
    """
    >>> ftrange = trange(3, ncols=60)
    >>> for x in ftrange:
    ...     ftrange.set_description('hi')
    ...     ftrange.update_to(x+1)
    \r  0%|                                                                             | 0/3 [00:00<?, ?it/s]\r 33%|                                                 | 1/3 [00:00<00:00,  6.00it/s]hi\r 67%|                                                 | 2/3 [00:00<00:00,  6.00it/s]hi\r100%|########################################################################| 3/3 [00:00<00:00,  6.00it/s]hi
    """
    pass

# Generated at 2022-06-12 14:27:58.773972
# Unit test for function trange
def test_trange():
    """Test the trange() function"""
    import sys
    ret = list(trange(3))
    if sys.version_info[0] == 2:
        assert ret == [0, 1, 2]
    else:
        assert ret == [0, 1, 2]
    return ret

# Generated at 2022-06-12 14:28:03.896590
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test for `trange`"""
    steps = 10
    with tqdm(total=steps) as pbar:
        assert list(pbar) == [0]
        pbar.update()
        assert list(pbar) == [0]
        pbar.update()
        assert list(pbar) == [0, 1]
        assert pbar.n == 2
        pbar.update(pbar.total - 2)
        assert list(pbar) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        assert pbar.n == steps

