

# Generated at 2022-06-12 14:27:12.329618
# Unit test for function trange
def test_trange():  # pragma: no cover
    # By @soravux
    SIZE = 10000
    assert list(range(SIZE)) == list(trange(SIZE))
    assert list(range(SIZE)) == list(tqdm(range(SIZE)))

    # By @tbenthompson
    progress = tqdm(range(SIZE))
    for i in progress:
        progress.set_description("Processing %i" % i)

    try:
        n = 1
        while n < SIZE:
            progress.update(n)
            n *= 2
    finally:
        progress.close()

    # Test update
    try:
        n = 1
        while n < SIZE:
            progress.update(n)
            n *= 2
    finally:
        progress.close()

    # Test smoothed iteration rate


# Generated at 2022-06-12 14:27:17.008332
# Unit test for function trange
def test_trange():
    """
    Unit test for `tqdm.auto.trange`.
    """
    from ._utils.testing import _test_trange
    return _test_trange(trange)


if __name__ == "__main__":
    from ._utils.testing import _test_argv as _tqdm_test_argv
    _tqdm_test_argv(__doc__, __file__)

# Generated at 2022-06-12 14:27:25.608493
# Unit test for function trange
def test_trange():
    """Unit tests of tqdm.auto.trange."""
    from .std import trange
    from .std import tqdm_gui
    from .std import tqdm_notebook
    from .std import tqdm_pandas
    from .std import tqdm_gui_pandas
    from .asyncio import tqdm_asyncio

    for tqdm_cls in trange, tqdm_gui, tqdm_notebook, tqdm_pandas, \
            tqdm_gui_pandas, tqdm_asyncio:
        assert list(tqdm_cls(range(10))) == list(range(10))

        assert tqdm_cls(range(10)).total == 10
        assert tqdm_cls(range(10)).n

# Generated at 2022-06-12 14:27:29.415797
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    from .std import tqdm
    from .utils import _range

    for j in _range(10):
        for i in trange(j, 0, -1):
            assert i in tqdm(list(range(j, 0, -1)))

# Generated at 2022-06-12 14:27:38.953049
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from sys import platform as _platform
    def get_terminal_width():  # hack for Windows
        # https://stackoverflow.com/questions/566746/how-to-get-console-window-width-in-python/1465482#1465482
        # https://stackoverflow.com/questions/263890/how-do-i-find-the-width-height-of-a-terminal-window
        try:
            return int(subprocess.check_call(['stty', 'size']).split()[1])
        except:
            return 80

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=DeprecationWarning)
        from .utils import _term_move_up

# Generated at 2022-06-12 14:27:47.544923
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from ._tqdm_test_classes import PretendTqdmFile
    from .std import tqdm_gui

    # StringIO is not supported in Python 2.6
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    # Test closing
    with tqdm(total=100) as pbar:
        assert not pbar.closed
    assert pbar.closed

    # Test `ascii` and `dynamic_ncols`
    f = PretendTqdmFile()
    tqdm(ascii=" ", file=f, dynamic_ncols=True, disable=True)
    assert '\x1b[2K\r' in f.getvalue()
    f = PretendTqdmFile()
    t

# Generated at 2022-06-12 14:27:49.641599
# Unit test for function trange
def test_trange():
    """Test trange function"""
    assert list(trange(5)) == list(tqdm(range(5)))

# Generated at 2022-06-12 14:27:58.849656
# Unit test for function trange
def test_trange():
    from .std import tqdm as std_tqdm
    from .autonotebook import tqdm as notebook_tqdm
    from .asyncio import tqdm as asyncio_tqdm

    assert sys.version_info[:2] >= (3, 6)

    assert trange(1, ascii=False) == std_tqdm(range(1), ascii=False)
    assert trange(1, desc="DESC", ascii=False) == std_tqdm(range(1), desc="DESC", ascii=False)
    assert trange(1, desc="DESC", dynamic_ncols=True, ascii=False) == std_tqdm(range(1), desc="DESC", dynamic_ncols=True, ascii=False)

   

# Generated at 2022-06-12 14:27:59.652872
# Unit test for function trange
def test_trange():
    """Tests the function trange"""
    trange(10)

# Generated at 2022-06-12 14:28:02.549605
# Unit test for function trange
def test_trange():
    """Tests for trange."""
    from ._utils import _supports_unicode  # pylint: disable=import-outside-toplevel

    for i in trange(2, leave=True):
        if i == 1:
            break
    assert trange(10)._total == 10