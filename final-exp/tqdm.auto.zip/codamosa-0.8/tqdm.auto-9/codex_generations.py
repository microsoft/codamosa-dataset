

# Generated at 2022-06-12 14:27:01.674953
# Unit test for function trange
def test_trange():
    """
    Test trange function by asserting it iterates over the same range as range
    """
    for i in trange(10):
        assert i in range(10)

# Generated at 2022-06-12 14:27:08.655872
# Unit test for function trange
def test_trange():
    """ Test for trange """
    import time
    import os

    with trange(10) as t:
        for i in t:
            t.set_description('FOO %i' % i)
            t.refresh()  # to show immediately the update
            time.sleep(0.2)
            # t.update(2)  # increase `i` by 2 instead of 1
            # t.set_postfix(file=os.path.basename(__file__))
            # t.close()  # finish the progress bar
    print(t)

# Generated at 2022-06-12 14:27:14.926439
# Unit test for function trange
def test_trange():
    """
    Tests that `trange` is equivalent to `tqdm(range(...))`.
    """
    from .std import _get_child_tqdm
    for n, n_ in zip(trange(1, 11, 2), tqdm(range(1, 11, 2))):
        assert n == n_
    assert _get_child_tqdm(trange(1)) is _get_child_tqdm(tqdm(range(1)))

# Generated at 2022-06-12 14:27:22.698334
# Unit test for function trange
def test_trange():
    """
    Test for the trange() function.
    """
    try:
        from unittest import mock
    except ImportError:
        import mock

    with mock.patch('tqdm.auto.tqdm') as ptqdm, \
            mock.patch('tqdm.auto.notebook_tqdm') as pnotebook_tqdm:
        trange(10)
        assert ptqdm.call_count == 1
        assert pnotebook_tqdm.call_count == 1
        assert ptqdm.call_args[0] == (range(10),)


if __name__ == "__main__":
    from .main import _test_tqdm
    _test_tqdm()

# Generated at 2022-06-12 14:27:25.000107
# Unit test for function trange
def test_trange():
    """
    Tests the `tqdm.trange()` function.
    """
    from .std import tqdm

    for _ in tqdm.trange(10):  # pylint: disable=protected-access
        pass



# Generated at 2022-06-12 14:27:26.358963
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    for _ in trange(4):
        pass

# Generated at 2022-06-12 14:27:27.648452
# Unit test for function trange
def test_trange():
    """Simple unit test for function trange"""
    assert list(trange(5)) == list(range(5))

# Generated at 2022-06-12 14:27:37.226930
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .tqdm import trange
    from .std import format_interval
    from .std import time

    t0 = time()
    with trange(3, desc='3 loop', leave=True) as t:
        for i in t:
            assert i == t.last_print_n
            assert t.n == i + 1
            t.set_description("%d-loop" % i)
            format_interval(t.n)
            format_interval(t.last_print_n)
            t.set_postfix(i=i, refresh=False)
            time.sleep(0.1)
            t.update()
            assert t.n == i + 1
            t.refresh()
            time.sleep(0.1)
        assert t.n

# Generated at 2022-06-12 14:27:43.539756
# Unit test for function trange
def test_trange():
    try:
        from .autonotebook import tqdm as notebook_tqdm
        from .autonotebook import trange as notebook_trange
    except:
        return  # trange tested in tqdm/tests/test_autonotebook.py

    assert trange is not None, "trange definition is broken"
    assert trange(10) == notebook_trange(10)
    assert trange(10, 20) == notebook_trange(10, 20)
    assert trange(10, 20, 1) == notebook_trange(10, 20, 1)
    assert trange(10, 20, 0.2) == notebook_trange(10, 20, 0.2)
    assert len(list(trange(10, 20))) == 11

# Generated at 2022-06-12 14:27:45.860140
# Unit test for function trange
def test_trange():
    assert trange(5) == notebook_trange(5)
    assert not isinstance(trange(5), notebook_trange)