

# Generated at 2022-06-12 14:27:05.226599
# Unit test for function trange
def test_trange():
    assert list(trange(0)) == []
    assert list(trange(10)) == list(range(10))
    assert list(trange(10, 0, -1)) == list(range(10, 0, -1))

# Generated at 2022-06-12 14:27:15.239539
# Unit test for function trange
def test_trange():
    """
    Tests that `trange` produces the same output as tqdm(range(...)).
    """
    from .std import tqdm

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert trange(10) == tqdm(range(10))

        assert (
            list(trange(0)) == list(tqdm(range(0))) == []
        ), "`tqdm(range(0))` doesn't equal `range(0)`"


# Generated at 2022-06-12 14:27:18.403151
# Unit test for function trange
def test_trange():
    from .std import _supports_unicode, _screen_shape  # pylint: disable=unused-import

    loops = 100
    with tqdm(total=loops) as trange_bar:
        for _ in trange(loops):
            trange_bar.update()

# Generated at 2022-06-12 14:27:21.139324
# Unit test for function trange
def test_trange():
    """Test for the trange function."""
    assert trange(0) == list(tqdm(range(0)))

# Generated at 2022-06-12 14:27:21.993191
# Unit test for function trange
def test_trange():
    for _ in trange(4):
        pass

# Generated at 2022-06-12 14:27:25.052181
# Unit test for function trange
def test_trange():
    """Test Jupyter notebook tqdm"""
    # Run function
    trange(1, 8, 2)


if __name__ == "__main__":
    """Test Jupyter notebook tqdm and trange"""
    # Run test
    test_trange()

# Generated at 2022-06-12 14:27:27.758478
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    sum_ = 0
    for i in trange(100):
        sum_ += i
    assert sum_ == sum(range(100))

# Generated at 2022-06-12 14:27:29.943605
# Unit test for function trange
def test_trange():
    """
    Unit test for trange
    """
    with trange(10) as t:
        for _ in t:
            pass
        t.close()

# Generated at 2022-06-12 14:27:31.152565
# Unit test for function trange
def test_trange():
    r = range(10)
    assert list(trange(10)) == r

# Generated at 2022-06-12 14:27:33.856154
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .std import trange
    assert list(trange(1000)) == list(range(1000))