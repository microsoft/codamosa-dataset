

# Generated at 2022-06-12 14:26:57.692088
# Unit test for function trange
def test_trange():
    """
    >>> test_trange()
    10.00it [00:00, ?it/s]
    """
    for _ in trange(10):
        pass

# Generated at 2022-06-12 14:27:00.794231
# Unit test for function trange
def test_trange():
    """Test the function trange"""
    from pytest import raises

    with raises(TypeError):
        trange(1, 1)
    with raises(TypeError):
        trange()

    list(trange(1))
    list(trange(1, 2, 0))

# Generated at 2022-06-12 14:27:02.711969
# Unit test for function trange
def test_trange():
    assert (list(trange(5)) == list(range(5)))


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 14:27:12.285299
# Unit test for function trange
def test_trange():
    "Test `trange` to check normal functionality"
    import time
    import io
    import platform  # platform info
    with io.StringIO() as buf, redirect_stdout(buf):
        with trange(5) as c:
            c.set_description("Description")
            time.sleep(0.2)
            c.set_postfix(coffee="me", platform=platform.platform())
            time.sleep(0.2)
            c.set_postfix(coffee="you")
            time.sleep(0.2)
            assert len(c) == 5

# Generated at 2022-06-12 14:27:19.982037
# Unit test for function trange
def test_trange():
    "Simple test for `tqdm.auto.trange`"
    import time
    from .std import format_interval
    from .tqdm import TqdmTypeError

    assert int(sum(tqdm(trange(8)))) == 28
    assert int(sum(tqdm(trange(2, 5)))) == 9
    assert int(sum(tqdm(trange(-5, 10, 2)))) == 40
    assert int(sum(tqdm(trange(-5, 21, 2)))) == 60
    assert int(sum(tqdm(trange(-5.5, 10, 2)))) == 40
    assert int(sum(tqdm(trange(-5.5, 21, 2)))) == 60
    assert int(sum(tqdm(trange(10, 0, -1)))) == 45

# Generated at 2022-06-12 14:27:24.206597
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    try:
        with tqdm(disable=True) as t:
            assert len(list(t.__iter__())) == 100  # nosec
    except TypeError:
        assert len(list(tqdm(range(100), disable=True))) == 100  # nosec



# Generated at 2022-06-12 14:27:28.635980
# Unit test for function trange
def test_trange():
    """
    Tests that `trange` works as expected
    """
    for _ in trange(3):
        pass
    for _ in trange(5, 10):
        pass
    for _ in trange(10, 15, 3):
        pass

    for _ in trange(0):
        pass
    for _ in trange(0, 9):
        pass
    for _ in trange(10, 0):
        pass
    for _ in trange(0, 0):
        pass


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-12 14:27:36.594056
# Unit test for function trange
def test_trange():
    """
    Tests that trange is equivalent to tqdm
    """
    with tqdm(total=15, position=0) as pbar:
        pbar.update(float('nan'))
        pbar.update(float('inf'))
        pbar.update()
        pbar.update()
        pbar.update()
        pbar.update()
        pbar.update()
        pbar.update()
        pbar.update()
        pbar.update()
        pbar.update()
        pbar.update()
        pbar.update()
        pbar.update()
        pbar.update()
        pbar.update()

# Generated at 2022-06-12 14:27:43.003032
# Unit test for function trange
def test_trange():
    """Test that trange() works as expected."""
    try:
        import unittest2 as unittest  # Python2.6-
    except ImportError:
        import unittest
    from io import StringIO
    from tqdm.auto import trange

    with StringIO() as catch_out:
        try:
            with unittest.mock.patch('sys.stderr', catch_out):
                list(trange(10, desc='123', file=catch_out))
        except TypeError:
            pass  # End of pipe, e.g. nosetests pipe

        output = catch_out.getvalue().replace(catch_out.getvalue(), '')

# Generated at 2022-06-12 14:27:53.028739
# Unit test for function trange
def test_trange():
    """Test function `trange`"""
    from .std import tqdm
    for args in [ [], [1], [1, 1], [1, 1, 1],
                  [1, 1, 1, 1], [1, 1, 1, 1, 1],
                  [1, 1, 1, 1, 1, 1], [1, 1, 1, 1, 1, 1, 1],
                  [1, 1, 1, 1, 1, 1, 1, 1], ]:
        a = trange(*args)
        b = tqdm(range(*args))
        assert a == b
        assert repr(a) == repr(b)
        assert repr(a).startswith('  0%|')
        assert repr(b).startswith('  0%|')