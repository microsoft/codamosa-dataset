

# Generated at 2022-06-12 14:27:05.430119
# Unit test for function trange
def test_trange():
    from .std import trange
    from .asyncio import trange as asyncio_trange
    from .autonotebook import trange as notebook_trange

    for tr in [trange, asyncio_trange, notebook_trange]:
        assert len(list(tr(100, desc="Notebook: ", leave=False))) == 100
        assert len(list(tr(100, desc="Notebook: ", leave=True))) == 100
        assert len(list(trange(100))) == 100
        assert len(list(trange(10, 100))) == 90
        assert len(list(trange(10, 100, 2))) == 45

# Generated at 2022-06-12 14:27:07.308726
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    for _ in trange(4):
        7



# Generated at 2022-06-12 14:27:11.074125
# Unit test for function trange
def test_trange():  # pylint: disable=unused-argument
    from .gui import tqdm
    from .utils import _range

    # Test that the trange wrapper returns the same value as the original
    # tqdm(range(...))
    assert list(trange(1000)) == list(_range(1000))

# Generated at 2022-06-12 14:27:17.543153
# Unit test for function trange
def test_trange():
    """Sanity check for trange"""
    for _ in trange(10, unit="it"):
        pass
    for _ in trange(3**9, 3**10, 3, unit="bytes"):
        pass
    for _ in trange(1234, 3**9, 3**7, unit="B", unit_scale=True):
        pass
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        for _ in trange(10, unit=None, leave=True):
            pass

# Generated at 2022-06-12 14:27:21.993411
# Unit test for function trange
def test_trange():
    """Tests the trange wrapper"""
    list(trange(10, leave=False))
    list(trange(10, leave=True))
    list(trange(10, desc="Test", leave=True))
    list(trange(10, miniters=1, mininterval=1, maxinterval=1, leave=True))
    list(trange(10))

# Generated at 2022-06-12 14:27:23.242840
# Unit test for function trange
def test_trange():
    """Test function trange."""
    assert list(trange(100)) == list(range(100))

# Generated at 2022-06-12 14:27:29.791860
# Unit test for function trange
def test_trange():
    from .std import create_trange, _range

    for cls in (notebook_trange, trange):
        with warnings.catch_warnings():
            for bar_format in ("{l_bar}", "{bar}"):
                for n in range(4):
                    for leave in (True, False):
                        for disable in (False, True):
                            trange_ = create_trange(
                                cls, n, leave=leave, disable=disable
                            )
                            t = trange_(bar_format=bar_format)
                            assert t.disable == disable
                            assert t.leave == leave
                            assert _range(*t.args) == list(t)
                            t.close()

test_trange()

# Generated at 2022-06-12 14:27:33.855676
# Unit test for function trange
def test_trange():
    """\
    >>> from tqdm.auto import trange
    >>> for i in trange(4):
    ...     pass
    """


if __name__ == "__main__":
    from doctest import testmod
    testmod(raise_on_error=True)

# Generated at 2022-06-12 14:27:41.826671
# Unit test for function trange
def test_trange():  # pragma: no cover
    '''
    Unit test for trange = tqdm(range())
    '''
    from .gui import tqdm_gui  # pylint: disable=unused-variable

    assert list(trange(5)) == [0, 1, 2, 3, 4]
    assert list(tqdm(range(5))) == [0, 1, 2, 3, 4]
    assert list(tqdm(range(5), unit="blah")) == [0, 1, 2, 3, 4]
    assert list(tqdm(range(5), total=10)) == [0, 1, 2, 3, 4]
    assert list(tqdm(range(5), miniters=1)) == [0, 1, 2, 3, 4]

# Generated at 2022-06-12 14:27:43.438128
# Unit test for function trange
def test_trange():
    for i in trange(4):
        assert i in range(4)
        assert i not in range(3)