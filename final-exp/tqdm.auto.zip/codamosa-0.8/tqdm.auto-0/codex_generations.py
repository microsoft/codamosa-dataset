

# Generated at 2022-06-12 14:27:01.131600
# Unit test for function trange
def test_trange():
    """Tests for the trange() function."""
    for m in (2, 3, 5):
        for n in (m, 100):
            assert (
                list(trange(m, n, desc="foo", leave=False))
                == list(range(m, n))
            ), "{} {}".format(m, n)
            assert (
                list(trange(m, n, desc="foo", leave=True))
                == list(range(m, n))
            ), "{} {}".format(m, n)
            assert (
                list(trange(m, n, desc="foo", leave=True))
                == list(range(m, n))
            ), "{} {}".format(m, n)

# Generated at 2022-06-12 14:27:07.620448
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from ._version import __version__
    from .utils import _term_move_up
    from .tqdm_gui import tqdm_gui
    from .autonotebook import tnrange

    total = 1000

    # Test 1
    obj = trange(total)
    assert hasattr(obj, '__iter__')

    # Test 2
    with tqdm_gui(total=total) as obj:
        assert hasattr(obj, '__iter__')
        assert obj.total == total

    # Test 3
    out = tqdm(total=total)
    assert hasattr(out, '__iter__')
    assert out.total == total

    # Test 4 (backward compatibility)
    out = tqdm(total=total)
    assert str(out) == __version

# Generated at 2022-06-12 14:27:09.974876
# Unit test for function trange
def test_trange():
    """Run trange unitest"""
    from .tests import trange
    trange.test()
    from .tests import trange_iter
    trange_iter.test()

# Generated at 2022-06-12 14:27:15.814997
# Unit test for function trange
def test_trange():
    from ._utils import TestBar

    with tqdm(disable=True) as t:
        for _ in trange(5, 10, 2, desc='Foo', leave=False):
            pass

    assert isinstance(t.inner_bar, TestBar)
    assert t.get_description() == 'Foo'


# Test cases:
# trange customisation
# trange as tqdm
# trange as tqdm with disable=False

# Generated at 2022-06-12 14:27:23.307822
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    Unit test for function trange
    """
    from .utils import _range
    tr = trange(5)
    assert next(tr) == 0 and next(tr) == 1 and next(tr) == 2
    tr.close()
    assert next(tr, 6) == 6
    assert list(trange(6, 0, -1)) == list(reversed(_range(6)))
    assert list(trange(7, 9)) == list(_range(7, 9))
    assert list(trange(0, 10, 3)) == list(_range(0, 10, 3))
    assert list(trange(10)) == list(_range(10))

test_trange()

# Generated at 2022-06-12 14:27:30.268901
# Unit test for function trange
def test_trange():
    list(trange(4))
    list(trange(4, 6))
    list(trange(4, 6, 2))
    with tqdm(total=4) as pbar:
        for _ in trange(4):
            pbar.update()
    with tqdm(total=4) as pbar:
        for _ in trange(4, 6):
            pbar.update()
    with tqdm(total=4) as pbar:
        for _ in trange(4, 6, 2):
            pbar.update()
    with tqdm(total=4) as pbar:
        try:
            for _ in trange(4, 6, 0):
                pbar.update()
        except ValueError:
            pass


if __name__ == "__main__":
    test_

# Generated at 2022-06-12 14:27:39.369645
# Unit test for function trange
def test_trange():
    """Testing trange function"""
    from .std import TqdmDeprecationWarning

    with warnings.catch_warnings():
        warnings.simplefilter(
            "error", category=TqdmDeprecationWarning)  # Raise error
        try:
            with warnings.catch_warnings():
                warnings.simplefilter(
                    "ignore", category=TqdmDeprecationWarning)
                trange(10)
        except TqdmDeprecationWarning:
            assert False, "trange deprecated"

    try:
        with warnings.catch_warnings():
            warnings.simplefilter(
                "ignore", category=TqdmDeprecationWarning)
            trange(10)
    except TqdmDeprecationWarning:
        assert False, "trange deprecated"



# Generated at 2022-06-12 14:27:41.206193
# Unit test for function trange
def test_trange():
    """ Calling trange is equivalent to calling tqdm(range()) """
    from .std import tqdm
    assert list(tqdm(range(3))) == list(trange(3))

# Generated at 2022-06-12 14:27:44.276851
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange()
    """
    from .autonotebook import trange
    assert list(trange(5)) == list(range(5))
    assert list(trange(2, 5)) == list(range(2, 5))
    assert list(trange(2, 5, 1)) == list(range(2, 5, 1))

# Generated at 2022-06-12 14:27:54.399705
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    # Test regular range
    out = ""
    with trange(3) as t:
        for i in t:
            out += str(i)
            t.set_description("testing")
            if i == 2:
                break
    assert str(t) == "testing: 100%|##########| 3/3 [00:00<?, ?it/s]"
    assert out == "012"

    # Test iterator range
    out = ""
    with trange(iter(range(3))) as t:
        for i in t:
            out += str(i)
            t.set_description("testing")
            if i == 2:
                break