

# Generated at 2022-06-12 14:27:06.692705
# Unit test for function trange
def test_trange():
    from .utils import _term_move_up
    from ._tqdm_gui import _version

    with tqdm(total=10) as pbar:
        pbar.update()
        pbar.desc = 'Testing trange'
        pbar.display()
        if hasattr(pbar, "n"):  # for compatibility with tqdm<4.24.0
            assert pbar.n == 1
    assert pbar.n == 10

    with tqdm(total=10) as pbar:
        for _ in trange(5):
            pbar.update()
    assert pbar.n == 10

    with tqdm(total=100) as pbar:
        pbar.set_description("Testing trange")

# Generated at 2022-06-12 14:27:16.546278
# Unit test for function trange
def test_trange():
    """Test function trange"""
    # Arrange
    from math import sqrt, factorial
    from random import randint, uniform
    from time import sleep
    from datetime import timedelta

    # Arrange
    test_list = [randint(-1000, 1000) for _ in range(1000)]

    # Act
    with tqdm([]) as t:  # pylint: disable=unused-variable
        # Assert
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            assert t.miniters == 0

    # Act
    with tqdm(test_list) as t:  # pylint: disable=unused-variable
        for x in t:
            sleep(uniform(0, 0.01))

# Generated at 2022-06-12 14:27:21.304645
# Unit test for function trange
def test_trange():
    """Test trange()"""
    from unittest import TestCase
    from random import randint
    from time import sleep

    class TestIter(TestCase):
        """Test iter"""
        def test(self):
            """Test"""
            for _ in trange(4):
                sleep(randint(0, 10) / 1000.0)

    test = TestIter()
    test.test()

# Generated at 2022-06-12 14:27:22.226219
# Unit test for function trange
def test_trange():
    assert list(tqdm(range(5))) == list(trange(5))

# Generated at 2022-06-12 14:27:28.506805
# Unit test for function trange
def test_trange():
    """Test trange"""
    # pylint: disable=expression-not-assigned,pointless-string-statement
    assert list(trange(0)) == []
    assert list(trange(1)) == [0]

    if sys.version_info[:2] >= (3, 6):
        from .asyncio import trange as asyncio_trange
        import asyncio

        # pylint: disable=unused-variable,undefined-variable
        @asyncio.coroutine
        def trange_task(i):
            """Task for trange in asyncio"""
            yield from asyncio.sleep(0.01)
            trange(i)


# Generated at 2022-06-12 14:27:38.097877
# Unit test for function trange
def test_trange():
    from ._utils import _version
    from ._monitor import _Monitor
    from ._tqdm_gui import _version as _gui_version
    from ._tqdm_gui import _tqdm_gui_new as _tqdm_gui
    with trange(1) as t:
        assert isinstance(t, _Monitor)  # pylint: disable=protected-access
    with trange(3, 1) as t:
        assert len(t) == 3
    with trange(1, 3) as t:
        assert len(t) == 2
    with trange(0, 1, 0.1) as t:
        # Test for "AssertionError: len(x) != 0" in tqdm/_tqdm.py
        assert len(t) == int(1 / 0.1)  # pyl

# Generated at 2022-06-12 14:27:44.527053
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    for i in trange(5):
        pass

    for i in trange(5, desc="desc 1"):
        pass

    for i in trange(5, desc="desc 2", ascii=True):
        pass

    for i in trange(5, desc="desc 3", position=1):
        pass

    for i in trange(5, desc="desc 4", leave=True):
        pass

    for i in trange(5, desc="desc 5", file=sys.stderr):
        pass

    for i in tqdm(range(5)):
        pass

    for i in tqdm(range(5), desc="desc 1"):
        pass


# Generated at 2022-06-12 14:27:50.838373
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    from .std import _range
    from .std import _trange
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        rng = trange(10)
        rng2 = _trange(10)
        assert isinstance(rng, _range)
        assert isinstance(rng2, _range)
        assert rng is rng2

# Generated at 2022-06-12 14:27:52.217479
# Unit test for function trange
def test_trange():
    """
    Simple unit test for function trange
    """
    for i in trange(10, desc="Test"):
        pass

# Generated at 2022-06-12 14:28:00.926496
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    from typing import Any
    from .std import tqdm  # pylint: disable=redefined-outer-name

    class Int(int):
        """
        Overriding `int` to check for `isinstance`.
        """
        pass

    assert isinstance(Int('1'), Int)
    assert isinstance(Int('1'), int)
    assert not isinstance(Int('1'), Any)
    assert not isinstance(Int('1'), (str, float))
    assert not isinstance(Int('1'), type((str('1'), int(1))))

    assert isinstance(tqdm.trange(Int('1')), tqdm)
    assert isinstance(tqdm.trange(Int('1')), list)
