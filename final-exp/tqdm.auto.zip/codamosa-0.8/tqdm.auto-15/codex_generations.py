

# Generated at 2022-06-12 14:27:11.417368
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test for function trange"""
    from time import time
    from numpy import random
    from math import ceil
    from threading import Thread
    from multiprocessing import Pool

    assert list(tqdm(range(3))) == list(range(3))

    def same_tqdm(tqdm_obj):
        return tqdm_obj.__class__.__name__ == 'tqdm'

    assert sum(tqdm(range(3))) == sum(range(3))

    assert all(same_tqdm(e) for e in tqdm(range(3)))

    assert all(same_tqdm(e) for e in tqdm(range(3)))

    assert list(trange(3)) == list(range(3))


# Generated at 2022-06-12 14:27:14.294019
# Unit test for function trange
def test_trange():
    from .std import trange
    from .asyncio import trange

    trange(5) == list(range(5))
    trange(5) == list(range(5))

# Generated at 2022-06-12 14:27:21.082034
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    Unit test for function trange
    """
    from ..tests.tests_tqdm import pretest_posttest

    pretest_posttest(
        trange,
        [
            ([2], {}),
            (range(2), {}),
            (range(3), {"desc": "foo"}),
            (range(3), {"desc": "foo", "desc_posted": True}),
            (range(3), {"desc": "foo", "leave": True}),
        ],
    )

    # Test for Python 2.6
    if sys.version_info[:2] <= (2, 6):
        from ._vendor.tqdm._tqdm import TqdmSynchronisationWarning


# Generated at 2022-06-12 14:27:25.717741
# Unit test for function trange
def test_trange():
    "Test trange unit"
    # Test simple
    assert list(trange(5)) == list(range(5))

    # Test kwargs
    assert list(trange(5, desc='Test', leave=False, mininterval=.01)) == \
        list(range(5))

    # Test initial value
    assert list(trange(0, 5)) == list(range(5))

# Generated at 2022-06-12 14:27:27.649552
# Unit test for function trange
def test_trange():
    "Make sure trange runs"
    for _ in trange(8, desc='test_trange'):
        pass

# Generated at 2022-06-12 14:27:28.875287
# Unit test for function trange
def test_trange():
    """Test function `trange`"""
    list(trange(1, 3, desc="test"))

# Generated at 2022-06-12 14:27:38.448859
# Unit test for function trange
def test_trange():
    """
    Tests that trange is equivalent to tqdm(range(...)).
    """
    warnings.filterwarnings("ignore", message="tensorflow")
    for i in trange(0, 4):
        if i != 0:
            raise ValueError("trange(0, 4) != tqdm(range(0,4))")
    for i in tqdm(range(0, 4)):
        if i != 1:
            raise ValueError("trange(0, 4) != tqdm(range(0,4))")
    for i in trange(4):
        if i != 2:
            raise ValueError("trange(4) != tqdm(range(4))")

# Generated at 2022-06-12 14:27:46.724558
# Unit test for function trange
def test_trange():
    """Test whether trange unit test is working"""
    assert repr(trange(0)) == "trange(0)"
    assert repr(list(trange(0))) == "[]"
    assert repr(trange(1, 0)) == "trange(1, 0)"
    assert repr(list(trange(1, 0))) == "[]"
    assert repr(trange(1, 1)) == "trange(1, 1)"
    assert repr(list(trange(1, 1))) == "[1]"
    assert repr(trange(1, 2)) == "trange(1, 2)"
    assert repr(list(trange(1, 2))) == "[1, 2]"
    assert repr(trange(1, 2, -1)) == "trange(1, 2, -1)"

# Generated at 2022-06-12 14:27:56.468531
# Unit test for function trange
def test_trange():
    """Test `trange()` function from this module"""
    from .std import FormatCustomText
    from .tqdm import _term_move_up
    from .utils import _environ_cols_wrapper
    from .gui import tqdm
    try:
        from collections.abc import Iterable
    except ImportError:  # Python 2.7
        from collections import Iterable

    with _environ_cols_wrapper(100):
        for i in trange(10, desc='desc', bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt}",
                        leave=False):
            assert isinstance(tqdm._instances, Iterable)
            assert tqdm._instances
            assert len(tqdm._instances) == 1

# Generated at 2022-06-12 14:27:59.570937
# Unit test for function trange
def test_trange():
    """Test function `trange`"""
    out = list(trange(5))
    assert out == list(range(5)), repr(out)


if __name__ == "__main__":
    test_trange()
    print("Test passed")