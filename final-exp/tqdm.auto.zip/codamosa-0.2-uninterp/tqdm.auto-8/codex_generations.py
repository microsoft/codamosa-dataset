

# Generated at 2022-06-18 11:10:17.395284
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import tqdm
    assert tqdm(range(10)) == trange(10)
    assert tqdm(range(10), leave=False) == trange(10, leave=False)
    assert tqdm(range(10), leave=True) == trange(10, leave=True)
    assert tqdm(range(10), leave=True, ascii=True) == trange(10, leave=True, ascii=True)
    assert tqdm(range(10), leave=True, ascii=False) == trange(10, leave=True, ascii=False)

# Generated at 2022-06-18 11:10:27.162862
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import tqdm
    assert list(trange(3)) == list(tqdm(range(3)))
    assert list(trange(3, 2)) == list(tqdm(range(3, 2)))
    assert list(trange(3, 2, -1)) == list(tqdm(range(3, 2, -1)))
    assert list(trange(3, 2, -1, 1)) == list(tqdm(range(3, 2, -1, 1)))
    assert list(trange(3, 2, -1, 1, "foo")) == list(tqdm(range(3, 2, -1, 1),
                                                        desc="foo"))
    assert list(trange(3, 2, -1, 1, "foo", bar="baz"))

# Generated at 2022-06-18 11:10:37.705268
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        for _tqdm, _trange in [(tqdm, trange), (notebook_tqdm, notebook_trange)]:
            assert list(_trange(3)) == list(_tqdm(range(3)))
            assert list(_trange(3, 1)) == list(_tqdm(range(3, 1)))
            assert list(_trange(3, 1, -1)) == list(_tqdm(range(3, 1, -1)))

# Generated at 2022-06-18 11:10:48.185812
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .std import tqdm
    assert trange(3) == tqdm(range(3))
    assert trange(3, 5) == tqdm(range(3, 5))
    assert trange(3, 5, 2) == tqdm(range(3, 5, 2))
    assert trange(3, 5, 2, 1) == tqdm(range(3, 5, 2), 1)
    assert trange(3, 5, 2, 1, 'foo') == tqdm(range(3, 5, 2), 1, 'foo')
    assert trange(3, 5, 2, 1, 'foo', True) == tqdm(range(3, 5, 2), 1, 'foo', True)

# Generated at 2022-06-18 11:10:51.406618
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    for _ in trange(10):
        pass
    assert tqdm.write.called

# Generated at 2022-06-18 11:10:58.249794
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmDeprecationWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
        for _ in trange(3):
            for _ in tqdm(range(3)):
                pass

# Generated at 2022-06-18 11:11:07.990824
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    for _ in tqdm(trange(10)):
        pass
    for _ in tqdm(trange(10), desc="test"):
        pass
    for _ in tqdm(trange(10), desc="test", leave=False):
        pass
    for _ in tqdm(trange(10), desc="test", leave=False, ascii=True):
        pass
    for _ in tqdm(trange(10), desc="test", leave=False, ascii=True,
                  miniters=1):
        pass

# Generated at 2022-06-18 11:11:17.924184
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange

    for t in [tqdm, trange]:
        assert list(t(range(10))) == list(range(10))
        assert list(t(range(10), desc="desc")) == list(range(10))
        assert list(t(range(10), desc="desc", leave=True)) == list(range(10))
        assert list(t(range(10), desc="desc", leave=True, mininterval=0.01)) == list(range(10))
        assert list(t(range(10), desc="desc", leave=True, mininterval=0.01, miniters=1)) == list(range(10))

# Generated at 2022-06-18 11:11:24.837806
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmDeprecationWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
        assert tqdm(range(10)) == trange(10)
        assert tqdm(range(10), desc="desc") == trange(10, desc="desc")
        assert tqdm(range(10), desc="desc", leave=True) == trange(10, desc="desc", leave=True)

# Generated at 2022-06-18 11:11:31.620102
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    from .std import tqdm as std_tqdm
    from .asyncio import tqdm as asyncio_tqdm
    from .autonotebook import tqdm as notebook_tqdm

    assert trange(1) == std_tqdm(range(1))
    assert trange(1) == asyncio_tqdm(range(1))
    assert trange(1) == notebook_tqdm(range(1))