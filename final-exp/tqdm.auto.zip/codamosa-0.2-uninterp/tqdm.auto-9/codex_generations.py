

# Generated at 2022-06-18 11:10:11.471843
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    for _ in trange(10):
        pass
    assert tqdm.write.called

# Generated at 2022-06-18 11:10:17.524892
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert tqdm(range(10)) == trange(10)

# Generated at 2022-06-18 11:10:27.247751
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange

    assert tqdm(range(10)) == trange(10)
    assert tqdm(range(10), desc="test") == trange(10, desc="test")
    assert tqdm(range(10), desc="test", leave=True) == trange(10, desc="test", leave=True)
    assert tqdm(range(10), desc="test", leave=True, position=1) == trange(10, desc="test", leave=True, position=1)
    assert tqdm(range(10), desc="test", leave=True, position=1, ascii=True) == trange(10, desc="test", leave=True, position=1, ascii=True)

# Generated at 2022-06-18 11:10:30.546106
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from .std import tqdm
    assert tqdm(range(10)) == trange(10)

# Generated at 2022-06-18 11:10:39.515662
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange

    for _tqdm in [tqdm, trange]:
        for i in _tqdm(range(10)):
            assert i in range(10)

        for i in _tqdm(range(10), desc="desc"):
            assert i in range(10)

        for i in _tqdm(range(10), desc="desc", leave=False):
            assert i in range(10)

        for i in _tqdm(range(10), desc="desc", leave=False,
                       mininterval=0.1):
            assert i in range(10)


# Generated at 2022-06-18 11:10:42.684978
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from .std import tqdm
    assert trange(5) == tqdm(range(5))

# Generated at 2022-06-18 11:10:53.842043
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import tqdm
    assert list(trange(3)) == list(tqdm(range(3)))
    assert list(trange(3, 5)) == list(tqdm(range(3, 5)))
    assert list(trange(3, 5, 2)) == list(tqdm(range(3, 5, 2)))
    assert list(trange(3, 5, 2, 1)) == list(tqdm(range(3, 5, 2), 1))
    assert list(trange(3, 5, 2, 1, 'a')) == list(tqdm(range(3, 5, 2), 1, 'a'))

# Generated at 2022-06-18 11:10:58.384411
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert tqdm(range(10)) == trange(10)

# Generated at 2022-06-18 11:11:00.559680
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    for _ in trange(10):
        pass
    assert tqdm.write.called

# Generated at 2022-06-18 11:11:03.140039
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    for _ in trange(10):
        pass
    assert tqdm.write.called