

# Generated at 2022-06-18 11:10:17.882512
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import trange
    from .std import tqdm
    from .std import TqdmExperimentalWarning
    from .std import TqdmTypeError

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert trange(3) == tqdm(range(3))
        assert trange(3, 5) == tqdm(range(3, 5))
        assert trange(3, 5, 2) == tqdm(range(3, 5, 2))
        assert trange(3, 5, 2, 7) == tqdm(range(3, 5, 2, 7))

# Generated at 2022-06-18 11:10:25.181660
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .std import tqdm
    assert trange(0) == tqdm(range(0))
    assert trange(1) == tqdm(range(1))
    assert trange(1, 2) == tqdm(range(1, 2))
    assert trange(1, 2, 3) == tqdm(range(1, 2, 3))
    assert trange(1, 2, 3, 4) == tqdm(range(1, 2, 3, 4))
    assert trange(1, 2, 3, 4, 5) == tqdm(range(1, 2, 3, 4, 5))

# Generated at 2022-06-18 11:10:36.474842
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange

    for _tqdm in [tqdm, trange]:
        assert list(_tqdm(range(10))) == list(range(10))
        assert list(_tqdm(range(10), desc='foobar')) == list(range(10))
        assert list(_tqdm(range(10), total=10)) == list(range(10))
        assert list(_tqdm(range(10), total=10, desc='foobar')) == list(range(10))
        assert list(_tqdm(range(10), total=10, desc='foobar', leave=True)) == list(range(10))

# Generated at 2022-06-18 11:10:43.577917
# Unit test for function trange
def test_trange():
    """Test trange"""
    from .std import tqdm
    from .utils import _term_move_up
    from .std import _range

    with tqdm(_range(10), desc="trange", leave=False) as t:
        for i in trange(10):
            t.update()
            assert t.n == i + 1
            assert t.last_print_n == i + 1
            assert t.last_print_refresh_time is not None
            assert t.last_print_t is not None
            assert t.last_print_n_displayed == i + 1
            assert t.last_print_n_values == i + 1
            assert t.last_print_fmt_values is not None
            assert t.last_print_len == len(str(i + 1))
            assert t

# Generated at 2022-06-18 11:10:54.725324
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange

    for _tqdm in [tqdm, trange]:
        assert list(_tqdm(range(10))) == list(range(10))
        assert list(_tqdm(range(10), desc="desc")) == list(range(10))
        assert list(_tqdm(range(10), desc="desc", leave=False)) == list(range(10))
        assert list(_tqdm(range(10), desc="desc", leave=True)) == list(range(10))
        assert list(_tqdm(range(10), desc="desc", leave=True, ascii=True)) == list(range(10))

# Generated at 2022-06-18 11:11:03.898411
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import tqdm
    assert list(trange(3)) == list(tqdm(range(3)))
    assert list(trange(3, 2)) == list(tqdm(range(3, 2)))
    assert list(trange(3, 2, -1)) == list(tqdm(range(3, 2, -1)))
    assert list(trange(3, 2, 1)) == list(tqdm(range(3, 2, 1)))
    assert list(trange(3, 2, -1, initial=1)) == list(tqdm(range(3, 2, -1),
                                                           initial=1))

# Generated at 2022-06-18 11:11:09.248310
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import tqdm
    assert tqdm(range(10)) == trange(10)
    assert tqdm(range(10), desc="test") == trange(10, desc="test")
    assert tqdm(range(10), desc="test", leave=True) == trange(10, desc="test", leave=True)

# Generated at 2022-06-18 11:11:14.215430
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert tqdm(range(3)) == trange(3)

# Generated at 2022-06-18 11:11:16.215955
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from .std import tqdm
    assert trange(3) == tqdm(range(3))

# Generated at 2022-06-18 11:11:18.579420
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    assert trange(3) == tqdm(range(3))