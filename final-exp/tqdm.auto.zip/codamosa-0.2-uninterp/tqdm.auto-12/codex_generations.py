

# Generated at 2022-06-18 11:10:14.903725
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from .std import tqdm
    assert list(trange(3)) == list(tqdm(range(3)))

# Generated at 2022-06-18 11:10:24.456233
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        for _tqdm in [tqdm, trange]:
            assert _tqdm(range(10)) == list(range(10))
            assert _tqdm(range(10), desc="desc") == list(range(10))
            assert _tqdm(range(10), desc="desc", leave=True) == list(range(10))
            assert _tqdm(range(10), desc="desc", leave=False) == list(range(10))

# Generated at 2022-06-18 11:10:35.564444
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    for _tqdm in [tqdm, trange]:
        assert list(_tqdm(range(10))) == list(range(10))
        assert list(_tqdm(range(10), desc="desc")) == list(range(10))
        assert list(_tqdm(range(10), desc="desc", leave=True)) == list(range(10))
        assert list(_tqdm(range(10), desc="desc", leave=False)) == list(range(10))
        assert list(_tqdm(range(10), desc="desc", leave=True, mininterval=0.1)) == list(range(10))

# Generated at 2022-06-18 11:10:46.765299
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmTypeError
    from .std import TqdmKeyError
    from .std import TqdmDeprecationWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
        with tqdm(total=10) as pbar:
            for _ in trange(10):
                pbar.update()

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
        with tqdm(total=10) as pbar:
            for _ in trange(10, desc="desc"):
                pbar.update()

    with warnings.catch_warnings():
        warnings

# Generated at 2022-06-18 11:10:52.421637
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert tqdm(range(10)) == trange(10)

# Generated at 2022-06-18 11:11:01.754817
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    assert tqdm(range(10)) == trange(10)
    assert tqdm(range(10), desc="desc") == trange(10, desc="desc")
    assert tqdm(range(10), desc="desc", mininterval=0.1) == \
        trange(10, desc="desc", mininterval=0.1)
    assert tqdm(range(10), desc="desc", mininterval=0.1, miniters=1) == \
        trange(10, desc="desc", mininterval=0.1, miniters=1)

# Generated at 2022-06-18 11:11:12.140134
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .utils import _range

    for _ in trange(3, desc='1st loop'):
        for _ in trange(100, desc='2nd loop', leave=False):
            for _ in trange(20, desc='3rd loop'):
                pass

    for i in trange(_range(10), desc='desc', leave=True):
        for _ in trange(_range(5), desc='desc', leave=True):
            for _ in trange(_range(100), desc='desc', leave=True):
                pass
        tqdm.write(str(i))


# Generated at 2022-06-18 11:11:21.130454
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange

    for _tqdm in [tqdm, trange]:
        for unit in ['', 'it', 'iterations']:
            with _tqdm(total=4, unit=unit) as pbar:
                for _ in range(4):
                    pbar.update()
        for unit in ['', 'it', 'iterations']:
            with _tqdm(total=4, unit=unit) as pbar:
                for _ in pbar:
                    pbar.update()
        for unit in ['', 'it', 'iterations']:
            with _tqdm(total=4, unit=unit) as pbar:
                for _ in pbar:
                    pass

# Generated at 2022-06-18 11:11:28.515279
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from .std import trange
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_number
    from .utils import format_timespan
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_number
    from .utils import format_timespan
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_number
    from .utils import format_timespan
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_number
   

# Generated at 2022-06-18 11:11:37.859551
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from .std import tqdm as std_tqdm
    from .asyncio import tqdm as asyncio_tqdm

    if sys.version_info[:2] < (3, 6):
        assert trange is notebook_trange
    else:
        assert trange is std_tqdm.trange or trange is asyncio_tqdm.trange
        assert trange(1) is not std_tqdm.trange(1)
        assert trange(1) is not asyncio_tqdm.trange(1)
        assert trange(1) is trange(1)
        assert trange(1) is not trange(2)