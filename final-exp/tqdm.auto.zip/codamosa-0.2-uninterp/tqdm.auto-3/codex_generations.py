

# Generated at 2022-06-18 11:10:22.918280
# Unit test for function trange
def test_trange():
    """Test trange"""
    from .std import tqdm
    for _ in trange(10):
        pass
    for _ in trange(10, desc="desc"):
        pass
    for _ in trange(10, desc="desc", leave=True):
        pass
    for _ in trange(10, desc="desc", leave=True, ascii=True):
        pass
    for _ in trange(10, desc="desc", leave=True, ascii=True, unit="blah"):
        pass
    for _ in trange(10, desc="desc", leave=True, ascii=True, unit="blah",
                    miniters=1):
        pass

# Generated at 2022-06-18 11:10:34.052316
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange
    from .std import TqdmTypeError

    with tqdm(total=10) as pbar:
        for i in trange(10):
            pbar.update()

    with tqdm(total=10) as pbar:
        for i in trange(10, desc="desc"):
            pbar.update()

    with tqdm(total=10) as pbar:
        for i in trange(10, leave=True):
            pbar.update()

    with tqdm(total=10) as pbar:
        for i in trange(10, position=1):
            pbar.update()


# Generated at 2022-06-18 11:10:39.256154
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmDeprecationWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
        assert tqdm(range(3)) == list(trange(3))

# Generated at 2022-06-18 11:10:45.230330
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .utils import _range

    for _ in trange(_range(10)):
        pass
    for _ in trange(_range(10), desc='desc'):
        pass
    for _ in trange(_range(10), desc='desc', mininterval=0.1):
        pass
    for _ in trange(_range(10), desc='desc', mininterval=0.1, miniters=1):
        pass
    for _ in trange(_range(10), desc='desc', mininterval=0.1, miniters=1,
                    smoothing=0.1):
        pass

# Generated at 2022-06-18 11:10:56.216441
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    assert trange(3) == tqdm(range(3))
    assert trange(3, 10) == tqdm(range(3, 10))
    assert trange(3, 10, 2) == tqdm(range(3, 10, 2))
    assert trange(3, 10, 2, desc="foo") == tqdm(range(3, 10, 2), desc="foo")
    assert trange(3, 10, 2, desc="foo", leave=True) == tqdm(range(3, 10, 2),
                                                            desc="foo",
                                                            leave=True)

# Generated at 2022-06-18 11:11:05.984403
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange

    for t in [tqdm, trange]:
        assert list(t(range(10))) == list(range(10))
        assert list(t(range(10), desc="desc")) == list(range(10))
        assert list(t(range(10), desc="desc", leave=True)) == list(range(10))
        assert list(t(range(10), desc="desc", leave=False)) == list(range(10))
        assert list(t(range(10), desc="desc", leave=True, mininterval=0.01)) == list(range(10))

# Generated at 2022-06-18 11:11:15.903122
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert trange(10) == tqdm(range(10))
        assert trange(10, 20) == tqdm(range(10, 20))
        assert trange(10, 20, 2) == tqdm(range(10, 20, 2))
        assert trange(10, 20, 2, desc="test") == tqdm(range(10, 20, 2), desc="test")

# Generated at 2022-06-18 11:11:23.757254
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange

    for t in [tqdm, trange]:
        assert list(t(range(10))) == list(range(10))
        assert list(t(range(10), desc="desc")) == list(range(10))
        assert list(t(range(10), desc="desc", leave=True)) == list(range(10))
        assert list(t(range(10), desc="desc", leave=True, mininterval=0.01)) == list(range(10))
        assert list(t(range(10), desc="desc", leave=True, mininterval=0.01, miniters=1)) == list(range(10))

# Generated at 2022-06-18 11:11:25.432926
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import tqdm
    assert tqdm(range(10)) == trange(10)

# Generated at 2022-06-18 11:11:27.067958
# Unit test for function trange
def test_trange():
    """Test trange"""
    from .std import tqdm
    assert trange(3) == tqdm(range(3))