

# Generated at 2022-06-18 11:10:12.072911
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import tqdm
    from .utils import _range

    for _ in trange(3, desc='1st loop'):
        for _ in trange(100, desc='2nd loop', leave=False):
            for _ in trange(_range(1000), desc='3rd loop', leave=False):
                pass
    assert tqdm._instances  # pylint: disable=protected-access



# Generated at 2022-06-18 11:10:23.038233
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    assert tqdm(range(10)) == trange(10)
    assert tqdm(range(10), position=0) == trange(10, position=0)
    assert tqdm(range(10), position=1) == trange(10, position=1)
    assert tqdm(range(10), position=2) == trange(10, position=2)
    assert tqdm(range(10), position=3) == trange(10, position=3)
    assert tqdm(range(10), position=4) == trange(10, position=4)
    assert tqdm(range(10), position=5) == trange(10, position=5)

# Generated at 2022-06-18 11:10:34.215442
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import tqdm
    assert tqdm(range(10)) == trange(10)
    assert tqdm(range(10), desc="test") == trange(10, desc="test")
    assert tqdm(range(10), desc="test", leave=False) == \
        trange(10, desc="test", leave=False)
    assert tqdm(range(10), desc="test", leave=False,
                position=1) == trange(10, desc="test", leave=False, position=1)
    assert tqdm(range(10), desc="test", leave=False,
                position=1, ascii=True) == \
        trange(10, desc="test", leave=False, position=1, ascii=True)
    assert t

# Generated at 2022-06-18 11:10:42.237541
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmDeprecationWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        warnings.simplefilter("ignore", category=TqdmDeprecationWarning)

        # Test trange
        assert list(trange(3)) == list(tqdm(range(3)))
        assert list(trange(3, 7)) == list(tqdm(range(3, 7)))
        assert list(trange(3, 7, 2)) == list(tqdm(range(3, 7, 2)))

# Generated at 2022-06-18 11:10:53.509861
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange

    for cls in [tqdm, trange]:
        with cls(total=10) as pbar:
            for _ in range(10):
                pbar.update()

    for cls in [tqdm, trange]:
        with cls(total=10) as pbar:
            for _ in range(10):
                pbar.update(1)

    for cls in [tqdm, trange]:
        with cls(total=10) as pbar:
            for _ in range(10):
                pbar.update(2)


# Generated at 2022-06-18 11:10:59.104452
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmDeprecationWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
        assert tqdm(range(3)) == trange(3)

# Generated at 2022-06-18 11:11:02.164094
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import tqdm
    assert tqdm(range(10)) == trange(10)
    assert tqdm(range(10), desc="foo") == trange(10, desc="foo")

# Generated at 2022-06-18 11:11:06.944782
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert tqdm(range(10)) == trange(10)

# Generated at 2022-06-18 11:11:16.892141
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange

    for _tqdm in [tqdm, trange]:
        for i in _tqdm(range(10)):
            pass
        for i in _tqdm(range(10), desc='desc'):
            pass
        for i in _tqdm(range(10), desc='desc', leave=False):
            pass
        for i in _tqdm(range(10), desc='desc', leave=True):
            pass
        for i in _tqdm(range(10), desc='desc', leave=True, mininterval=0.1):
            pass

# Generated at 2022-06-18 11:11:24.338249
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmTypeError

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        with tqdm(total=10) as pbar:
            for _ in trange(10):
                pbar.update()

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        with tqdm(total=10) as pbar:
            for _ in trange(10, desc="desc"):
                pbar.update()
