

# Generated at 2022-06-18 11:10:23.037913
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .std import tqdm
    for _ in trange(10):
        pass
    for _ in trange(10, desc="desc"):
        pass
    for _ in trange(10, desc="desc", leave=True):
        pass
    for _ in trange(10, desc="desc", leave=True, ncols=100):
        pass
    for _ in trange(10, desc="desc", leave=True, ncols=100, unit="unit"):
        pass
    for _ in trange(10, desc="desc", leave=True, ncols=100, unit="unit",
                    unit_scale=True):
        pass

# Generated at 2022-06-18 11:10:34.169453
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange

    assert tqdm(range(10)) == trange(10)
    assert tqdm(range(10), ascii=True) == trange(10, ascii=True)
    assert tqdm(range(10), ascii=True, desc="desc") == trange(10, ascii=True, desc="desc")
    assert tqdm(range(10), ascii=True, desc="desc", leave=True) == trange(10, ascii=True, desc="desc", leave=True)

# Generated at 2022-06-18 11:10:42.177185
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from .std import tqdm
    assert list(trange(3)) == list(tqdm(range(3)))
    assert list(trange(3, 4)) == list(tqdm(range(3, 4)))
    assert list(trange(3, 4, 5)) == list(tqdm(range(3, 4, 5)))
    assert list(trange(3, 4, 5, 6)) == list(tqdm(range(3, 4, 5, 6)))
    assert list(trange(3, 4, 5, 6, 7)) == list(tqdm(range(3, 4, 5, 6, 7)))

# Generated at 2022-06-18 11:10:53.510387
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmDeprecationWarning
    from .std import TqdmExperimentalWarning
    from .std import TqdmTypeError

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        warnings.simplefilter("ignore", category=TqdmTypeError)

        # Test trange
        assert list(trange(10)) == list(range(10))
        assert list(trange(10, 0, -1)) == list(range(10, 0, -1))

# Generated at 2022-06-18 11:11:02.806002
# Unit test for function trange
def test_trange():
    """Test trange"""
    from .std import tqdm
    assert trange(3) == tqdm(range(3))
    assert trange(3, 1) == tqdm(range(3, 1))
    assert trange(3, 1, -1) == tqdm(range(3, 1, -1))
    assert trange(3, 1, -1, desc="desc") == tqdm(range(3, 1, -1), desc="desc")
    assert trange(3, 1, -1, desc="desc", leave=False) == \
        tqdm(range(3, 1, -1), desc="desc", leave=False)

# Generated at 2022-06-18 11:11:13.221664
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange

    for _tqdm in [tqdm, trange]:
        assert list(_tqdm(range(10))) == list(range(10))
        assert list(_tqdm(range(10), desc="desc")) == list(range(10))
        assert list(_tqdm(range(10), desc="desc", leave=False)) == list(range(10))
        assert list(_tqdm(range(10), desc="desc", leave=True)) == list(range(10))
        assert list(_tqdm(range(10), desc="desc", leave=True, mininterval=0.01)) == list(range(10))

# Generated at 2022-06-18 11:11:21.961109
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmTypeError
    from .std import TqdmKeyError
    from .std import TqdmDeprecationWarning
    from .std import TqdmExperimentalWarning
    from .std import TqdmWarning
    from .std import TqdmSkipWarning
    from .std import TqdmCliWarning
    from .std import TqdmMonitorWarning
    from .std import TqdmSynchronisationWarning
    from .std import TqdmBarBaseWarning
    from .std import TqdmCloseWarning
    from .std import TqdmFileWarning
    from .std import TqdmMonitorWarning
    from .std import TqdmKeyError

# Generated at 2022-06-18 11:11:26.923178
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmDeprecationWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
        assert tqdm(range(3)) == trange(3)

# Generated at 2022-06-18 11:11:29.634096
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    assert tqdm(range(10)) == trange(10)

# Generated at 2022-06-18 11:11:35.026851
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    assert tqdm(range(10)) == trange(10)
    assert tqdm(range(10), desc="desc") == trange(10, desc="desc")
    assert tqdm(range(10), total=10) == trange(10, total=10)
    assert tqdm(range(10), desc="desc", total=10) == trange(10, desc="desc", total=10)
    assert tqdm(range(10), desc="desc", total=10, leave=True) == trange(10, desc="desc", total=10, leave=True)