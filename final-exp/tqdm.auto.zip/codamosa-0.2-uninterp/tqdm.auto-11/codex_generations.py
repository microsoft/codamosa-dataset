

# Generated at 2022-06-18 11:10:21.825635
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange

    for _tqdm in [tqdm, trange]:
        for i in _tqdm(range(10)):
            pass
        for i in _tqdm(range(10), leave=False):
            pass
        for i in _tqdm(range(10), ascii=True):
            pass
        for i in _tqdm(range(10), ascii=True, leave=False):
            pass
        for i in _tqdm(range(10), desc='foo'):
            pass
        for i in _tqdm(range(10), desc='foo', leave=False):
            pass

# Generated at 2022-06-18 11:10:33.020242
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert tqdm(range(0)) == trange(0)
        assert tqdm(range(1)) == trange(1)
        assert tqdm(range(2)) == trange(2)
        assert tqdm(range(3)) == trange(3)
        assert tqdm(range(4)) == trange(4)
        assert tqdm(range(5)) == trange(5)
        assert tqdm(range(6)) == trange(6)

# Generated at 2022-06-18 11:10:41.221461
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import tqdm
    from .utils import _range


# Generated at 2022-06-18 11:10:44.419982
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    assert trange(3) == tqdm(range(3))

# Generated at 2022-06-18 11:10:55.426322
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .utils import _term_move_up
    from .utils import _range

    with tqdm(_range(3), desc='trange', leave=False) as t:
        assert len(t) == 3
        assert t.n == 3
        assert t.desc == 'trange'
        assert t.total == 3
        assert t.unit == 'it'
        assert t.unit_scale is False
        assert t.dynamic_ncols is False
        assert t.miniters == 1
        assert t.mininterval == 0.1
        assert t.maxinterval == 10.0
        assert t.smoothing == 0.3
        assert t.ascii is False
        assert t.unit_divisor is 1000
       

# Generated at 2022-06-18 11:11:05.076382
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmTypeError

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert trange(10) == tqdm(range(10))

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        with pytest.raises(TqdmTypeError):
            trange(10, desc="foo")
        with pytest.raises(TqdmTypeError):
            trange(10, leave=True)

# Generated at 2022-06-18 11:11:15.063244
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    assert trange(3) == tqdm(range(3))
    assert trange(3, 4) == tqdm(range(3, 4))
    assert trange(3, 4, 5) == tqdm(range(3, 4, 5))
    assert trange(3, 4, 5, 6) == tqdm(range(3, 4, 5, 6))
    assert trange(3, 4, 5, 6, 7) == tqdm(range(3, 4, 5, 6, 7))
    assert trange(3, 4, 5, 6, 7, 8) == tqdm(range(3, 4, 5, 6, 7, 8))

# Generated at 2022-06-18 11:11:23.229962
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)

# Generated at 2022-06-18 11:11:33.222657
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import tqdm
    assert list(trange(3)) == list(tqdm(range(3)))
    assert list(trange(3, 4)) == list(tqdm(range(3, 4)))
    assert list(trange(3, 4, 5)) == list(tqdm(range(3, 4, 5)))
    assert list(trange(3, 4, 5, 6)) == list(tqdm(range(3, 4, 5, 6)))
    assert list(trange(3, 4, 5, 6, 7)) == list(tqdm(range(3, 4, 5, 6, 7)))

# Generated at 2022-06-18 11:11:40.486305
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmDeprecationWarning
    from .std import TqdmKeyError
    from .std import TqdmTypeError
    from .std import TqdmWarning
    from .std import TqdmExperimentalWarning
    from .std import TqdmKeyError
    from .std import TqdmTypeError
    from .std import TqdmWarning
    from .std import TqdmDeprecationWarning
    from .std import TqdmExperimentalWarning
    from .std import TqdmKeyError
    from .std import TqdmTypeError
    from .std import TqdmWarning
    from .std import TqdmDeprecationWarning