

# Generated at 2022-06-18 11:10:19.568093
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from .std import tqdm
    assert trange(3) == tqdm(range(3))
    assert trange(3, 5) == tqdm(range(3, 5))
    assert trange(3, 5, 2) == tqdm(range(3, 5, 2))
    assert trange(3, 5, 2, 1) == tqdm(range(3, 5, 2), 1)
    assert trange(3, 5, 2, 1, "foo") == tqdm(range(3, 5, 2), 1, "foo")
    assert trange(3, 5, 2, 1, "foo", "bar") == tqdm(range(3, 5, 2), 1, "foo", "bar")

# Generated at 2022-06-18 11:10:30.503173
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange

    for t in [tqdm, trange]:
        assert list(t(range(10))) == list(range(10))
        assert list(t(range(10), desc="desc")) == list(range(10))
        assert list(t(range(10), desc="desc", leave=True)) == list(range(10))
        assert list(t(range(10), desc="desc", leave=False)) == list(range(10))
        assert list(t(range(10), desc="desc", leave=True, mininterval=0.01)) == list(range(10))

# Generated at 2022-06-18 11:10:32.889670
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from .std import tqdm
    assert trange(3) == tqdm(range(3))

# Generated at 2022-06-18 11:10:41.116866
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .std import tqdm
    assert trange(3) == tqdm(range(3))
    assert trange(3, 5) == tqdm(range(3, 5))
    assert trange(3, 5, 2) == tqdm(range(3, 5, 2))
    assert trange(3, 5, 2, 1) == tqdm(range(3, 5, 2), 1)
    assert trange(3, 5, 2, 1, 'foo') == tqdm(range(3, 5, 2), 1, 'foo')
    assert trange(3, 5, 2, 1, 'foo', 'bar') == tqdm(range(3, 5, 2), 1, 'foo', 'bar')

# Generated at 2022-06-18 11:10:53.336558
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    assert trange(10) == tqdm(range(10))
    assert trange(10, desc="desc") == tqdm(range(10), desc="desc")
    assert trange(10, desc="desc", leave=True) == tqdm(range(10), desc="desc",
                                                       leave=True)
    assert trange(10, desc="desc", leave=True, mininterval=0.1) == tqdm(
        range(10), desc="desc", leave=True, mininterval=0.1)

# Generated at 2022-06-18 11:10:57.932394
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert tqdm(range(10)) == trange(10)

# Generated at 2022-06-18 11:10:59.838606
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    assert tqdm(range(10)) == trange(10)

# Generated at 2022-06-18 11:11:09.994096
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .utils import _range

    for i in trange(10):
        assert i in _range(10)

    for i in trange(10, 0, -1):
        assert i in _range(10, 0, -1)

    for i in trange(10, 0, -1, desc="desc"):
        assert i in _range(10, 0, -1)

    for i in trange(10, 0, -1, desc="desc", leave=True):
        assert i in _range(10, 0, -1)

    for i in trange(10, 0, -1, desc="desc", leave=True, mininterval=0):
        assert i in _range(10, 0, -1)


# Generated at 2022-06-18 11:11:12.317552
# Unit test for function trange
def test_trange():
    """Test trange"""
    from .std import tqdm
    assert tqdm(range(10)) == trange(10)

# Generated at 2022-06-18 11:11:21.208284
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmDeprecationWarning
    from .std import TqdmKeyError

    # Test trange
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", category=TqdmKeyError)
                for _ in trange(10):
                    pass
                for _ in trange(10, desc="desc"):
                    pass