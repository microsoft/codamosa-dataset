

# Generated at 2022-06-18 11:10:21.418016
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange

    # Test trange
    assert trange(10) == tqdm(range(10))
    assert trange(10, 20) == tqdm(range(10, 20))
    assert trange(10, 20, 2) == tqdm(range(10, 20, 2))

    # Test trange with kwargs
    assert trange(10, desc='test') == tqdm(range(10), desc='test')
    assert trange(10, 20, desc='test') == tqdm(range(10, 20), desc='test')
    assert trange(10, 20, 2, desc='test') == tqdm(range(10, 20, 2), desc='test')

    #

# Generated at 2022-06-18 11:10:24.975571
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    import sys

    if sys.version_info[:2] < (3, 6):
        assert trange is tqdm.trange
    else:
        assert trange is not tqdm.trange

# Generated at 2022-06-18 11:10:36.271791
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .utils import _range
    from .std import format_interval
    from .std import time
    from .std import sleep

    with tqdm(_range(3), desc='1st loop', miniters=1) as t:
        for i in t:
            sleep(0.1)
        assert format_interval(t.last_print_t - t.start_t) == '0:00:00'

    with tqdm(_range(3), desc='2nd loop', miniters=1) as t:
        for i in t:
            sleep(0.1)
        assert format_interval(t.last_print_t - t.start_t) == '0:00:00'


# Generated at 2022-06-18 11:10:43.449133
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange

    for _tqdm in [tqdm, trange]:
        assert list(_tqdm(range(10))) == list(range(10))
        assert list(_tqdm(range(10), desc="desc")) == list(range(10))
        assert list(_tqdm(range(10), "desc")) == list(range(10))
        assert list(_tqdm(range(10), desc="desc", leave=True)) == list(range(10))
        assert list(_tqdm(range(10), desc="desc", leave=False)) == list(range(10))
        assert list(_tqdm(range(10), desc="desc", leave=None)) == list(range(10))
       

# Generated at 2022-06-18 11:10:45.598498
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import tqdm
    assert tqdm(range(10)) == trange(10)

# Generated at 2022-06-18 11:10:56.514518
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm as std_tqdm

    assert trange(5) == std_tqdm(range(5))
    assert trange(5) == std_tqdm(range(5))
    assert trange(5) == std_tqdm(range(5))
    assert trange(5) == std_tqdm(range(5))
    assert trange(5) == std_tqdm(range(5))
    assert trange(5) == std_tqdm(range(5))
    assert trange(5) == std_tqdm(range(5))
    assert trange(5) == std_tqdm(range(5))
    assert trange(5) == std_tqdm(range(5))
    assert trange

# Generated at 2022-06-18 11:11:06.279625
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .utils import _range

    for _ in trange(3, desc='1st loop'):
        for _ in trange(100, desc='2nd loop', leave=False):
            for _ in trange(100, desc='3nd loop'):
                pass
    assert tqdm._instances  # pylint: disable=protected-access

    for _ in trange(3, desc='1st loop'):
        for _ in trange(100, desc='2nd loop', leave=False):
            for _ in trange(100, desc='3nd loop'):
                pass
    assert tqdm._instances  # pylint: disable=protected-access


# Generated at 2022-06-18 11:11:11.054668
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import trange
    from .std import tqdm
    from .std import TqdmExperimentalWarning
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert trange(10) == tqdm(range(10))

# Generated at 2022-06-18 11:11:13.190877
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from .std import tqdm
    assert trange(3) == tqdm(range(3))

# Generated at 2022-06-18 11:11:15.244500
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .std import tqdm
    assert tqdm(range(10)) == trange(10)