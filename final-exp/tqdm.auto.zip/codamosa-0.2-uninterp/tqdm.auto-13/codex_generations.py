

# Generated at 2022-06-18 11:10:21.325831
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmDeprecationWarning
    from .std import TqdmKeyError
    from .std import TqdmTypeError
    from .std import TqdmWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
        warnings.simplefilter("ignore", category=TqdmKeyError)
        warnings.simplefilter("ignore", category=TqdmTypeError)
        warnings.simplefilter("ignore", category=TqdmWarning)

# Generated at 2022-06-18 11:10:25.224879
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert tqdm(range(10)) == trange(10)

# Generated at 2022-06-18 11:10:28.177118
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    assert list(trange(10)) == list(tqdm(range(10)))

# Generated at 2022-06-18 11:10:38.624898
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from .std import tqdm
    assert trange(3) == tqdm(range(3))
    assert trange(3, 1) == tqdm(range(3, 1))
    assert trange(3, 1, -1) == tqdm(range(3, 1, -1))
    assert trange(3, 1, -1, leave=True) == tqdm(range(3, 1, -1), leave=True)
    assert trange(3, 1, -1, leave=True, desc="desc") == \
        tqdm(range(3, 1, -1), leave=True, desc="desc")

# Generated at 2022-06-18 11:10:50.111211
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmTypeError

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert tqdm(range(3)) == trange(3)
        assert tqdm(range(3), desc="desc") == trange(3, desc="desc")
        assert tqdm(range(3), total=3) == trange(3, total=3)
        assert tqdm(range(3), desc="desc", total=3) == trange(3, desc="desc", total=3)

# Generated at 2022-06-18 11:10:52.665013
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    assert list(trange(10)) == list(tqdm(range(10)))

# Generated at 2022-06-18 11:10:55.156433
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    assert tqdm(range(10)) == trange(10)

# Generated at 2022-06-18 11:11:04.334527
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmTypeError
    from .std import TqdmKeyError
    from .std import TqdmDeprecationWarning
    from .std import TqdmMonitorWarning
    from .std import TqdmSynchronisationWarning
    from .std import TqdmCloseWarning
    from .std import TqdmExperimentalWarning
    from .std import TqdmWarning
    from .std import TqdmSkipped
    from .std import TqdmExperimentalWarning
    from .std import TqdmKeyError
    from .std import TqdmDeprecationWarning
    from .std import TqdmMonitorWarning
    from .std import TqdmSynchronisation

# Generated at 2022-06-18 11:11:09.725647
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert trange(3) == tqdm(range(3))

# Generated at 2022-06-18 11:11:19.280074
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert tqdm(range(3)) == trange(3)
        assert tqdm(range(3), desc="desc") == trange(3, desc="desc")
        assert tqdm(range(3), desc="desc", leave=True) == trange(3, desc="desc", leave=True)
        assert tqdm(range(3), desc="desc", leave=True, position=1) == trange(3, desc="desc", leave=True, position=1)