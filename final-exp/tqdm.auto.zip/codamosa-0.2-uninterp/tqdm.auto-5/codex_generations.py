

# Generated at 2022-06-18 11:10:08.805256
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        for _ in trange(3):
            pass

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        for _ in tqdm(range(3)):
            pass

# Generated at 2022-06-18 11:10:19.227841
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmDeprecationWarning

    # Test trange
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
            assert list(trange(10)) == list(tqdm(range(10)))

    # Test trange with kwargs
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)

# Generated at 2022-06-18 11:10:30.159918
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange

    for _tqdm in [tqdm, trange]:
        for i in _tqdm(range(10)):
            pass

        for i in _tqdm(range(10), desc="desc"):
            pass

        for i in _tqdm(range(10), desc="desc", leave=False):
            pass

        for i in _tqdm(range(10), desc="desc", leave=True):
            pass

        for i in _tqdm(range(10), desc="desc", leave=True, mininterval=0.1):
            pass


# Generated at 2022-06-18 11:10:39.181119
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmDeprecationWarning
    from .std import TqdmKeyError
    from .std import TqdmTypeError
    from .std import TqdmWarning
    from .std import TqdmExperimentalWarning
    from .std import TqdmKeyError
    from .std import TqdmTypeError
    from .std import TqdmWarning
    from .std import TqdmDeprecationWarning
    from .std import TqdmExperimentalWarning
    from .std import TqdmKeyError
    from .std import TqdmTypeError
    from .std import TqdmWarning
    from .std import TqdmDeprec

# Generated at 2022-06-18 11:10:45.185116
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from .std import tqdm
    assert trange(3) == tqdm(range(3))
    assert trange(3, 1) == tqdm(range(3, 1))
    assert trange(3, 1, -1) == tqdm(range(3, 1, -1))
    assert trange(3, 1, -1, leave=False) == tqdm(range(3, 1, -1), leave=False)
    assert trange(3, 1, -1, leave=True) == tqdm(range(3, 1, -1), leave=True)

# Generated at 2022-06-18 11:10:56.156627
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    for _ in trange(10):
        pass
    for _ in trange(10, desc="desc"):
        pass
    for _ in trange(10, desc="desc", leave=True):
        pass
    for _ in trange(10, desc="desc", leave=True, mininterval=0.1):
        pass
    for _ in trange(10, desc="desc", leave=True, mininterval=0.1,
                    miniters=1):
        pass
    for _ in trange(10, desc="desc", leave=True, mininterval=0.1,
                    miniters=1, maxinterval=0.5):
        pass

# Generated at 2022-06-18 11:11:05.945272
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange

    assert tqdm(range(10)) == trange(10)
    assert tqdm(range(10), desc="desc") == trange(10, desc="desc")
    assert tqdm(range(10), desc="desc", leave=True) == trange(10, desc="desc", leave=True)
    assert tqdm(range(10), desc="desc", leave=True, mininterval=0.1) == trange(10, desc="desc", leave=True, mininterval=0.1)

# Generated at 2022-06-18 11:11:15.858591
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange

    for i in trange(10):
        assert i in range(10)

    for i in tqdm(range(10)):
        assert i in range(10)

    for i in trange(10, desc="desc"):
        assert i in range(10)

    for i in trange(10, desc="desc", leave=True):
        assert i in range(10)

    for i in trange(10, desc="desc", leave=True, mininterval=0.01):
        assert i in range(10)


# Generated at 2022-06-18 11:11:23.728365
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import trange
    from .std import tqdm
    from .std import TqdmTypeError
    from .std import TqdmDeprecationWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
        assert tqdm(range(3)) == trange(3)
        assert tqdm(range(3), desc="desc") == trange(3, desc="desc")
        assert tqdm(range(3), total=3) == trange(3, total=3)
        assert tqdm(range(3), desc="desc", total=3) == trange(3, desc="desc", total=3)

# Generated at 2022-06-18 11:11:34.300184
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import __version__
    from .std import __file__

    assert tqdm == trange
    assert tqdm == tqdm.tqdm
    assert trange == trange.trange
    assert tqdm.__version__ == __version__
    assert tqdm.__file__ == __file__
    assert trange.__version__ == __version__
    assert trange.__file__ == __file__

    assert tqdm(range(10)) == trange(10)
    assert tqdm(range(10), desc="test") == trange(10, desc="test")