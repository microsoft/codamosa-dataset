

# Generated at 2022-06-18 11:10:02.712812
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    for _ in trange(10):
        pass
    assert isinstance(_, tqdm)

# Generated at 2022-06-18 11:10:11.035025
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    assert tqdm(range(10)) == trange(10)
    assert tqdm(range(10), desc="desc") == trange(10, desc="desc")
    assert tqdm(range(10), desc="desc", leave=True) == trange(10, desc="desc", leave=True)
    assert tqdm(range(10), desc="desc", leave=True, mininterval=0.1) == trange(10, desc="desc", leave=True, mininterval=0.1)

# Generated at 2022-06-18 11:10:22.200401
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmTypeError

    with tqdm(total=10) as pbar:
        for _ in trange(10):
            pbar.update()

    with tqdm(total=10) as pbar:
        for _ in trange(10, desc="desc"):
            pbar.update()

    with tqdm(total=10) as pbar:
        for _ in trange(10, desc="desc", leave=True):
            pbar.update()

    with tqdm(total=10) as pbar:
        for _ in trange(10, desc="desc", leave=False):
            pbar.update()


# Generated at 2022-06-18 11:10:33.384350
# Unit test for function trange
def test_trange():
    """Test trange"""
    from .std import tqdm
    from .utils import _range

    for n in _range(1, 4):
        assert list(trange(n, desc='trange')) == list(tqdm(_range(n), desc='trange'))
        assert list(trange(n, leave=True, desc='trange')) == list(tqdm(_range(n), leave=True, desc='trange'))
        assert list(trange(n, ascii=True, desc='trange')) == list(tqdm(_range(n), ascii=True, desc='trange'))

# Generated at 2022-06-18 11:10:41.542788
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmDeprecationWarning
    from .std import TqdmKeyError

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
        warnings.simplefilter("ignore", category=TqdmKeyError)

        assert list(trange(3)) == list(tqdm(range(3)))
        assert list(trange(3, 4)) == list(tqdm(range(3, 4)))

# Generated at 2022-06-18 11:10:49.863153
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmDeprecationWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
        for _ in trange(3):
            for _ in tqdm(range(3)):
                pass

# Generated at 2022-06-18 11:10:59.636097
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import tqdm
    from .std import trange as std_trange

    for cls in (tqdm, std_trange):
        with cls(total=10) as pbar:
            for _ in trange(10):
                pbar.update()
            assert pbar.n == 10
            assert pbar.total == 10
            assert pbar.last_print_n == 10
            assert pbar.last_print_refresh_time == pbar.start_t
            assert pbar.last_print_t == pbar.last_print_refresh_time
            assert pbar.last_print_n == pbar.n
            assert pbar.last_print_n == pbar.total
            assert pbar.last_print_n == pbar.n

# Generated at 2022-06-18 11:11:09.770665
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert tqdm(range(3)) == trange(3)
        assert tqdm(range(3), leave=False) == trange(3, leave=False)
        assert tqdm(range(3), leave=True) == trange(3, leave=True)
        assert tqdm(range(3), leave=True, mininterval=0.1) == \
            trange(3, leave=True, mininterval=0.1)

# Generated at 2022-06-18 11:11:16.891983
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm as std_tqdm
    from .asyncio import tqdm as asyncio_tqdm
    from .autonotebook import tqdm as notebook_tqdm

    assert trange(10) == std_tqdm(range(10))
    assert trange(10) == asyncio_tqdm(range(10))
    assert trange(10) == notebook_tqdm(range(10))
    assert trange(10) == tqdm(range(10))

# Generated at 2022-06-18 11:11:24.325387
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import tqdm
    from .utils import _term_move_up
    from .utils import _range
    from .utils import _unich
    from .utils import _unicode
    from .utils import _supports_unicode
    from .utils import _environ_cols_wrapper
    from .utils import _screen_shape
    from .utils import _environ_cols_wrapper
    from .utils import _screen_shape
    from .utils import _decode_preferred_encoding
    from .utils import _environ_cols_wrapper
    from .utils import _screen_shape
    from .utils import _decode_preferred_encoding
    from .utils import _environ_cols_wrapper
    from .utils import _screen_shape
    from .utils import _