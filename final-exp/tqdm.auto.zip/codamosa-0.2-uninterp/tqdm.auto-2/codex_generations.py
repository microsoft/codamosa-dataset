

# Generated at 2022-06-18 11:10:18.712118
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmDeprecationWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
        assert tqdm(range(10)) == trange(10)

# Generated at 2022-06-18 11:10:23.376046
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert trange(10) == tqdm(range(10))

# Generated at 2022-06-18 11:10:34.470788
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmTypeError

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert tqdm(range(3)) == trange(3)
        assert tqdm(range(3), desc="desc") == trange(3, desc="desc")
        assert tqdm(range(3), total=3) == trange(3, total=3)
        assert tqdm(range(3), desc="desc", total=3) == trange(3, desc="desc",
                                                              total=3)

# Generated at 2022-06-18 11:10:42.447176
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange as std_trange
    from .asyncio import trange as asyncio_trange
    from .autonotebook import trange as notebook_trange

    assert trange is std_trange
    assert trange is asyncio_trange
    assert trange is notebook_trange

    assert trange(0) == tqdm(range(0))
    assert trange(1) == tqdm(range(1))
    assert trange(2) == tqdm(range(2))
    assert trange(3) == tqdm(range(3))
    assert trange(4) == tqdm(range(4))
    assert trange(5) == tqdm(range(5))
    assert tr

# Generated at 2022-06-18 11:10:53.583775
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmTypeError

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        for _tqdm in (tqdm, trange):
            assert _tqdm(range(10))
            assert _tqdm(range(10), desc="desc")
            assert _tqdm(range(10), total=10)
            assert _tqdm(range(10), desc="desc", total=10)
            assert _tqdm(range(10), desc="desc", total=10, mininterval=0.01)

# Generated at 2022-06-18 11:11:02.805299
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    from .std import TqdmDeprecationWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
        assert list(trange(10)) == list(tqdm(range(10)))
        assert list(trange(10, 20)) == list(tqdm(range(10, 20)))
        assert list(trange(10, 20, 2)) == list(tqdm(range(10, 20, 2)))

# Generated at 2022-06-18 11:11:07.842901
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from .std import tqdm
    assert trange(10) == tqdm(range(10))
    assert trange(10, desc="desc") == tqdm(range(10), desc="desc")
    assert trange(10, desc="desc", leave=True) == \
        tqdm(range(10), desc="desc", leave=True)

# Generated at 2022-06-18 11:11:17.832849
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange
    from .std import TqdmTypeError
    from .std import TqdmDeprecationWarning
    from .std import TqdmExperimentalWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)

        # Test trange
        assert list(trange(0)) == []
        assert list(trange(1)) == [0]
        assert list(trange(2)) == [0, 1]
        assert list(trange(3)) == [0, 1, 2]

        # Test trange with start
        assert list(trange(0, 0))

# Generated at 2022-06-18 11:11:24.795062
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange

    for t in [tqdm, trange]:
        assert list(t(range(10))) == list(range(10))
        assert list(t(range(10), desc="desc")) == list(range(10))
        assert list(t(range(10), desc="desc", leave=True)) == list(range(10))
        assert list(t(range(10), desc="desc", leave=False)) == list(range(10))
        assert list(t(range(10), desc="desc", leave=True, mininterval=0.01)) == list(range(10))

# Generated at 2022-06-18 11:11:35.403916
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange

    for _tqdm in [tqdm, trange]:
        assert list(_tqdm(range(10))) == list(range(10))
        assert list(_tqdm(range(10), desc="desc")) == list(range(10))
        assert list(_tqdm(range(10), desc="desc", leave=True)) == list(range(10))
        assert list(_tqdm(range(10), desc="desc", leave=False)) == list(range(10))
        assert list(_tqdm(range(10), desc="desc", leave=True, mininterval=0.1)) == list(range(10))