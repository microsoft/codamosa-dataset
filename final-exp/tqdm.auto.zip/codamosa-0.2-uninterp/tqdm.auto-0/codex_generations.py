

# Generated at 2022-06-18 11:10:15.665638
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import tqdm
    assert trange(3) == tqdm(range(3))

# Generated at 2022-06-18 11:10:20.343257
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert tqdm(range(10)) == trange(10)

# Generated at 2022-06-18 11:10:26.197772
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import trange
    from .std import tqdm
    from .std import TqdmExperimentalWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        for _ in trange(10):
            pass

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        for _ in tqdm(range(10)):
            pass

# Generated at 2022-06-18 11:10:32.406447
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert tqdm(range(3)) == trange(3)

# Generated at 2022-06-18 11:10:40.710496
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .utils import _range

    for _tqdm in [tqdm, tqdm.__wrapped__]:
        assert list(_tqdm(range(10))) == list(_range(10))
        assert list(_tqdm(range(10), desc="desc")) == list(_range(10))
        assert list(_tqdm(range(10), desc="desc", leave=True)) == list(_range(10))
        assert list(_tqdm(range(10), desc="desc", leave=True,
                          mininterval=0.1)) == list(_range(10))

# Generated at 2022-06-18 11:10:52.748021
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .std import tqdm
    assert tqdm(range(10)) == trange(10)
    assert tqdm(range(10), ascii=True) == trange(10, ascii=True)
    assert tqdm(range(10), ascii=True, desc="desc") == trange(10, ascii=True, desc="desc")
    assert tqdm(range(10), ascii=True, desc="desc", leave=True) == trange(10, ascii=True, desc="desc", leave=True)

# Generated at 2022-06-18 11:11:01.964045
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import trange
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter

    # Test trange
    for _ in trange(10, desc='foobar', leave=True):
        pass

    # Test trange
    for _ in trange(10, desc='foobar', leave=True, file=sys.stdout):
        pass

    # Test trange
    for _ in trange(10, desc='foobar', leave=True, file=sys.stderr):
        pass

    # Test trange
    for _ in trange(10, desc='foobar', leave=True, file=sys.stdout,
                    mininterval=0.1):
        pass

    # Test trange

# Generated at 2022-06-18 11:11:12.425304
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .std import tqdm
    assert trange(3) == tqdm(range(3))
    assert trange(3, 4) == tqdm(range(3, 4))
    assert trange(3, 4, 5) == tqdm(range(3, 4, 5))
    assert trange(3, 4, 5, 6) == tqdm(range(3, 4, 5, 6))
    assert trange(3, 4, 5, 6, 7) == tqdm(range(3, 4, 5, 6, 7))
    assert trange(3, 4, 5, 6, 7, 8) == tqdm(range(3, 4, 5, 6, 7, 8))

# Generated at 2022-06-18 11:11:14.842726
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    for _ in trange(10):
        pass
    assert tqdm.write.called



# Generated at 2022-06-18 11:11:23.085206
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import trange

    # Test trange
    for _ in trange(10):
        pass
    for _ in trange(10, 0, -1):
        pass
    for _ in trange(10, 0, -1, 1):
        pass
    for _ in trange(10, 0, -1, 1, 'Test', 'Test2'):
        pass
    for _ in trange(10, 0, -1, 1, 'Test', 'Test2', True):
        pass
    for _ in trange(10, 0, -1, 1, 'Test', 'Test2', True, True):
        pass