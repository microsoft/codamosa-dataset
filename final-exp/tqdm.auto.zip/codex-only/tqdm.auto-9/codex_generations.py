

# Generated at 2022-06-24 09:35:51.241737
# Unit test for function trange
def test_trange():
    import sys
    from .std import tqdm

    lst = list(trange(5))
    lst2 = list(tqdm(range(5), desc='trange', ncols=10))
    assert lst == lst2

    lst = list(trange(5))
    lst2 = list(tqdm(range(5), desc='trange', position=0))
    assert lst == lst2

    lst = list(trange(5))
    lst2 = list(tqdm(range(5), desc='trange', position=1))
    assert lst == lst2

if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 09:35:53.156659
# Unit test for function trange
def test_trange():
    """Tests that trange runs without errors"""
    for _ in trange(10):
        pass

# Generated at 2022-06-24 09:35:55.164766
# Unit test for function trange
def test_trange():
    """Simple unit test for function trange"""
    for i in range(100):
        for j in trange(i):
            pass

# Generated at 2022-06-24 09:35:56.565746
# Unit test for function trange
def test_trange():
    """Test function trange"""
    assert list(trange(10)) == list(range(10))

# Generated at 2022-06-24 09:36:07.963383
# Unit test for function trange
def test_trange():
    from .std import tqdm
    assert trange(3) == tqdm(range(3), ncols=None)
    assert trange(3) != tqdm(range(3))
    assert trange(3, 1) == tqdm(range(3, 4), ncols=None)
    assert trange(3, 1, -1) == tqdm(range(3, 0, -1), ncols=None)
    assert trange(3, 1, -2) == tqdm(range(3, -1, -2), ncols=None)
    assert trange(3, 4) == tqdm([3], ncols=None)
    assert trange(3, 3) == tqdm([], ncols=None)


# Generated at 2022-06-24 09:36:12.353506
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange

    >>> test_trange()
    """
    list(trange(0))
    list(trange(1))
    list(trange(2))


if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-24 09:36:20.867155
# Unit test for function trange
def test_trange():
    from .std import _supports_unicode  # pylint: disable=protected-access
    from .std import _term_move_up  # pylint: disable=protected-access
    move_up = _term_move_up()

    def tnrange(n, desc='', leave=True):
        t = trange(n, desc=desc, leave=leave)
        return list(t)

    assert tnrange(0) == []  # Range 0
    assert tnrange(1) == [0]  # Range 1
    assert tnrange(2) == [0, 1]  # Range 2
    assert tnrange(3) == [0, 1, 2]  # Range 3 (and leave=True)

    assert tnrange(1, leave=False)[0] == 0  # Range 1 (and

# Generated at 2022-06-24 09:36:22.335376
# Unit test for function trange
def test_trange():
    container = []

    for i in trange(4):
        container.append(i)

    assert container == [0, 1, 2, 3]

# Generated at 2022-06-24 09:36:32.644862
# Unit test for function trange
def test_trange():
    """Tests `!trange`"""
    from .utils import _range
    from .std import TqdmTypeError
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=TqdmExperimentalWarning)
        import numpy  # NOQA
        import pandas  # NOQA
    # Check `trange` is a shortcurt to `tqdm(range(...))`
    trange_tqdm = tqdm(total=None, mininterval=0.01)
    assert isinstance(trange() is trange_tqdm, bool)
    assert trange_tqdm.disable is False
    assert trange_tqdm.pos == 0
    trange_tqdm.close()

# Generated at 2022-06-24 09:36:42.362450
# Unit test for function trange
def test_trange():
    from .tqdm import trange
    from .gui import tqdm

    for cls in (trange, tqdm):
        assert list(cls(1, 5)) == [1, 2, 3, 4]
        assert list(cls(5)) == [0, 1, 2, 3, 4]
        assert list(cls(0)) == []
        assert list(cls(-1)) == []
        assert list(cls(-5, 4)) == [-5, -4, -3, -2, -1, 0, 1, 2, 3]
        assert list(cls(-5, -1)) == [-5, -4, -3, -2]
        assert list(cls(-5, -6)) == []
        assert list(cls()) == []

# Generated at 2022-06-24 09:36:44.302581
# Unit test for function trange
def test_trange():
    "Test that trange does not fail and does not report anything"
    for _ in trange(10):
        pass

# Generated at 2022-06-24 09:36:47.846766
# Unit test for function trange
def test_trange():
    """
    Tests `trange`
    """
    assert list(trange(3)) == list(range(3))
    assert list(trange(3, 25)) == list(range(3, 25))
    assert list(trange(3, 23, 3)) == list(range(3, 23, 3))



# Generated at 2022-06-24 09:36:51.178611
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    for i in trange(2):  # +trange(10, 20)):
        pass


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:37:01.588648
# Unit test for function trange
def test_trange():
    """Test unit for trange"""
    assert list(trange(0)) == []
    assert list(trange(2)) == [0, 1]
    assert list(trange(1, 2)) == [1]
    assert list(trange(1, 2, 3)) == []
    assert list(trange(1, 2)) == [1]
    assert list(trange(1, 2, 3)) == []
    assert list(trange(5, 0, -1)) == [5, 4, 3, 2, 1]
    assert list(trange(0)) == []
    assert list(trange(1, 0)) == []
    assert list(trange(2, 1)) == []
    assert list(trange(1, 2)) == [1]
    assert list(trange(1, 2, 3)) == []

# Generated at 2022-06-24 09:37:09.090287
# Unit test for function trange
def test_trange():
    """
    Test for `tqdm.auto.trange`
    """
    from os import remove
    from tempfile import mkstemp
    from tqdm import __file__ as module_file
    from tqdm.auto import trange

    with open(mkstemp(dir=module_file[:-10])[1], 'w') as f:
        for _ in trange(3, file=f, desc="test_trange"):
            f.write('test\n')

    # cleanup
    remove(f.name)



# Generated at 2022-06-24 09:37:11.003666
# Unit test for function trange
def test_trange():
    assert list(tqdm(trange(3))) == list(tqdm(range(3)))

# Generated at 2022-06-24 09:37:13.222552
# Unit test for function trange
def test_trange():
    """Test for function trange()"""
    assert list(trange(3)) == list(tqdm(range(3)))



# Generated at 2022-06-24 09:37:14.941873
# Unit test for function trange
def test_trange():
    with tqdm(total=10) as pbar:
        for _ in trange(10):
            pbar.update()
    pbar.close()

# Generated at 2022-06-24 09:37:20.769175
# Unit test for function trange
def test_trange():  # pragma: no cover
    import time
    try:
        import numpy as np
    except ImportError:  # pragma: no cover
        np = None
    from .std import trange

    def test(tr, it, *args, **kwargs):
        """
        Check `tr(it, *args, **kwargs)` iterate over `it`.
        For integration tests with memory consumption,
        return the sum of the trange (should be equal to `len(it) * (len(it) + 1) / 2`)
        """
        with tr(*args, **kwargs) as t:
            for i, _ in enumerate(t):
                if i > len(it):
                    break

        return t.n


# Generated at 2022-06-24 09:37:29.425983
# Unit test for function trange
def test_trange():
    """Test for the trange function"""
    from tqdm import trange
    from sys import stdout
    from os import uname
    from time import sleep

    # macos doesn't support non-blocking mode, disable update_interval
    update_interval = 0.3 if uname().sysname != 'Darwin' else None

    for _ in trange(4, file=stdout):
        sleep(0.05)
    for _ in trange(4, mininterval=0.2, file=stdout):
        sleep(0.05)
    for _ in trange(4, miniters=1, file=stdout):
        sleep(0.05)
    for _ in trange(4, mininterval=0.2, miniters=1, file=stdout):
        sleep(0.05)

# Generated at 2022-06-24 09:37:30.771485
# Unit test for function trange
def test_trange():
    """Test function trange"""
    list(trange(3))

# Generated at 2022-06-24 09:37:40.842356
# Unit test for function trange
def test_trange():
    """Test trange function"""
    # pylint: disable=protected-access
    with notebook_trange(3) as t:
        assert t._miniters == 1  # pylint: disable=protected-access
        assert t.disable == False  # pylint: disable=no-member
        assert (t._time() - t._last_print_t) > 1

        t.update(1)
        assert t.last_print_t == t._last_print_t
        assert (t._time() - t._last_print_t) < 1

        t.update(2)
        assert t.last_print_t == t._last_print_t
        assert (t._time() - t._last_print_t) < 1

        t.total = None
        t.update(1)

# Generated at 2022-06-24 09:37:52.100592
# Unit test for function trange
def test_trange():
    """
    Test function trange
    """
    # Intentional (to test function)
    # pylint: disable=undefined-variable
    with tqdm(total=1) as pbar:
        assert isinstance(pbar, tqdm)
        assert trange(2) > 0 if sys.version_info < (3, 0) else trange(2) == range(2)
        for i in trange(4):
            assert i == pbar.n
            pbar.update()
        assert i + 1 == pbar.n
        with trange(4, 3) as pbar:
            for _ in pbar:
                pass
        with trange(4, 3, -1) as pbar:
            for _ in pbar:
                pass

# Generated at 2022-06-24 09:38:03.184583
# Unit test for function trange
def test_trange():
    """Test function `trange` from module `tqdm.auto`."""
    # pylint: disable=protected-access
    from ._utils import _range as range

    if sys.version_info[:2] >= (3, 6):
        from .asyncio import trange as _trange_asyncio

        assert trange == _trange_asyncio
    else:
        from .autonotebook import trange as _trange_notebook
        from .std import trange as _trange_std

        assert trange == _trange_notebook
        assert (_trange_notebook != _trange_std)
        assert (_trange_asyncio != _trange_std)

    assert (list(trange(10)) == list(range(10)))

# Generated at 2022-06-24 09:38:13.133900
# Unit test for function trange
def test_trange():
    """
    $ python3 -c "from tqdm.auto import trange; print(list(trange(5)))"
    """
    from .std import tqdm
    trange = tqdm.auto._trange  # pylint: disable=protected-access
    assert list(trange(0)) == []
    assert list(trange(1)) == [0]
    assert list(trange(0, 1)) == [0]
    assert list(trange(1, 1)) == []
    assert list(trange(2, 1)) == []
    assert list(trange(-1)) == []
    assert list(trange(-3, -1)) == [-3, -2]
    assert list(trange(4, 1, -1)) == [4, 3, 2]

# Generated at 2022-06-24 09:38:14.812109
# Unit test for function trange
def test_trange():
    """Test function trange."""
    assert list(trange(10)) == list(range(10))

# Generated at 2022-06-24 09:38:20.980445
# Unit test for function trange
def test_trange():
    """Test for trange function."""
    assert list(trange(4)) == [0, 1, 2, 3]
    assert list(trange(4, 7)) == [4, 5, 6]
    assert list(trange(1, 15, 3)) == [1, 4, 7, 10, 13]
    assert list(trange(15, 1, -3)) == [15, 12, 9, 6, 3]



# Generated at 2022-06-24 09:38:29.317257
# Unit test for function trange

# Generated at 2022-06-24 09:38:37.359555
# Unit test for function trange
def test_trange():
    from pickle import loads, dumps
    from nose.tools import assert_equal

    for s in range(1, 10):
        assert_equal(tuple(trange(s)), tuple(range(s)))

    p = dumps(tqdm)
    tqdm_ = loads(p)
    assert_equal(tqdm_(range(10)), list(range(10)))
    p = dumps(tqdm_)
    tqdm__ = loads(p)
    assert_equal(tqdm__(range(10)), list(range(10)))

# Generated at 2022-06-24 09:38:43.562765
# Unit test for function trange
def test_trange():
    """
    Ensure that trange is working

    :return: exit code
    """
    from time import sleep
    sleep_duration = 0.01

    progress_bar = trange(10, desc='trange')
    for _ in progress_bar:
        sleep(sleep_duration)

    progress_bar = tqdm(range(10), desc='tqdm')
    for _ in progress_bar:
        sleep(sleep_duration)

    return 0

# Generated at 2022-06-24 09:38:44.615206
# Unit test for function trange
def test_trange():
    """Test trange"""
    assert trange(10)

# Generated at 2022-06-24 09:38:50.371944
# Unit test for function trange
def test_trange():
    """Test trange function."""
    from .std import tqdm as std_tqdm

    assert sys.version_info[:2] < (3, 6) or tqdm is not notebook_tqdm
    assert tqdm is not std_tqdm
    assert trange is not std_tqdm

    for _ in trange(4):
        pass

    for _ in trange(4, 0, -1):
        pass

    for _ in trange(4, desc="desc", ascii=True):
        pass

# Generated at 2022-06-24 09:38:58.760512
# Unit test for function trange
def test_trange():
    """Test coverage for `trange` and `tqdm.asyncio`"""
    from .std import _decr_instances, _incr_instances

    _incr_instances()

    lst = list(trange(5))
    assert len(lst) == 5

    if sys.version_info[:2] < (3, 6):
        assert tqdm == notebook_tqdm
        assert trange == notebook_trange
    else:
        assert tqdm != notebook_tqdm
        assert tqdm != std_tqdm
        assert trange != notebook_trange

    _decr_instances()