

# Generated at 2022-06-24 09:35:43.424520
# Unit test for function trange
def test_trange():  # pragma: no cover
    for _ in trange(10):
        None
    for _ in trange(10, unit='spam'):
        None
    for _ in trange(10, desc='spam'):
        None
    for _ in trange(10, desc='spam', ascii=True):
        None
    for _ in trange(10, desc='spam', mininterval=0.3):
        None
    for _ in trange(10, desc='spam', smoothing=0.9):
        None
    for _ in trange(10, desc='spam', dynamic_ncols=True):
        None
    for _ in trange(10, desc='spam', position=5):
        None

# Generated at 2022-06-24 09:35:46.007748
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Test if trange correctly calls tqdm"""
    l = list(trange(10))
    assert l == list(range(10))

# Generated at 2022-06-24 09:35:56.787881
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .autonotebook import tnrange, tqdm_notebook
    vals = trange(10)
    for _ in vals:
        pass
    assert vals.n == 10

    # tnrange
    vals = tnrange(10)
    for _ in vals:
        pass
    assert vals.n == 10
    vals = tnrange(10, desc='testing tnrange')
    for _ in vals:
        pass
    assert vals.n == 10
    assert vals.desc == 'testing tnrange'
    assert vals.total == 10

    # non-notebook
    vals = tqdm_notebook(10)
    for _ in vals:
        pass
    assert vals.n == 10

# Generated at 2022-06-24 09:36:08.152748
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange to test function trange(*args, **kwargs)
    with all possible args and kwargs.
    """
    from .std import trange as std_trange
    from .asyncio import trange as asyncio_trange


# Generated at 2022-06-24 09:36:13.340294
# Unit test for function trange
def test_trange():
    """Test custom trange function"""
    assert trange(3) == [0, 1, 2]
    assert trange(0.1) == []
    assert trange(1, 3) == [1, 2]
    assert trange(1, 3, 2) == [1]
    assert list(trange(4, 1, -2)) == [4, 2]

# Generated at 2022-06-24 09:36:16.134536
# Unit test for function trange
def test_trange():
    """
    test trange function with notebook as output and stdout as output
    """
    for _ in trange(3):
        pass

    for _ in trange(3):
        print(".")



# Generated at 2022-06-24 09:36:23.190877
# Unit test for function trange
def test_trange():
    """Run `python -c "import tqdm.auto; tqdm.auto.test_trange()"`"""
    from unittest import TestCase
    from .std import format_interval, format_meter
    from .gui import tqdm_gui

    class TestTrange(TestCase):
        "Test :class:`trange`"
        # Unit test for function trange
        def test_trange(self):
            """
            Run `python -c "import tqdm.auto; tqdm.auto.test_trange()"`
            """
            from unittest import TestCase
            from .std import format_interval, format_meter
            from .gui import tqdm_gui


            class TestTrange(TestCase):
                "Test :class:`trange`"


# Generated at 2022-06-24 09:36:27.092232
# Unit test for function trange
def test_trange():
    """Suppresses a warning for `trange` (not a class)."""
    from .utils import _suppress_tqdm_deprecation_warning
    with _suppress_tqdm_deprecation_warning():
        for _ in trange(10):
            pass

# Generated at 2022-06-24 09:36:31.478987
# Unit test for function trange
def test_trange():
    """ Test the trange function """
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        warnings.simplefilter("ignore", category=DeprecationWarning)
        for _ in trange(10):
            pass


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:36:33.883519
# Unit test for function trange
def test_trange():
    """Test function trange"""
    for _ in trange(10):
        pass



# Generated at 2022-06-24 09:36:43.502204
# Unit test for function trange
def test_trange():
    """Test trange"""
    trange(10)
    trange(10, 5)
    list(trange(10))
    list(trange(10, 5))
    tuple(trange(10, 5, 2))
    list(trange(10, ascii=True, ncols=100))
    list(trange(10, desc="hi", ascii=False, ncols=100))
    trange(10, desc="hi", ascii=False, ncols=10, miniters=0)
    trange(10, desc="hi", ascii=False, ncols=10, miniters=0, smoothing=1)

# Generated at 2022-06-24 09:36:50.378497
# Unit test for function trange
def test_trange():
    """
    Test the function trange with different inputs.
    """
    # Test with start=0, stop=10 and step 1 (the default)
    expected_output = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert list(trange(10)) == expected_output

    # Test with start=0, stop=10 and step 1 (the default)
    expected_output = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(trange(9)) == expected_output

    # Test with start=0, stop=10 and step 1 (the default)
    expected_output = [0, 2, 4, 6, 8, 10, 12, 14, 16, 18]

# Generated at 2022-06-24 09:36:55.751200
# Unit test for function trange
def test_trange():
    from .autonotebook import trange
    from .asyncio import trange as asyncio_trange

    def check_trange(trange, **kwargs):
        l = kwargs.pop('leave', True)
        assert trange(1, **kwargs)._leave == l

    check_trange(trange, leave=True)
    check_trange(trange, leave=False)
    if sys.version_info > (3, 6):
        check_trange(asyncio_trange, leave=True)
        check_trange(asyncio_trange, leave=False)

# Generated at 2022-06-24 09:36:57.508944
# Unit test for function trange
def test_trange():
    """Test trange"""
    assert str(type(trange(0))) == "<class 'tqdm.auto.tqdm'>"


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:37:00.280160
# Unit test for function trange
def test_trange():
    for _ in trange(4, 7):
        pass
    for _ in trange(4):
        pass

# Generated at 2022-06-24 09:37:10.739839
# Unit test for function trange
def test_trange():
    """
    Tests trange
    """
    from .std import tqdm

    assert list(trange(0)) == []
    assert list(trange(1)) == [0]
    assert list(trange(self=tqdm, x=1)) == [0]
    assert list(trange(1, 2)) == [1]
    assert list(trange(1, 3)) == [1, 2]
    assert list(trange(1, 3, 2)) == [1]
    assert list(trange(1, 4, 2)) == [1, 3]
    assert list(trange(4, 1, -2)) == [4, 2]
    assert list(trange(4, 1, -4)) == [4]
    assert list(trange(4, 1, -3)) == [4]


# Generated at 2022-06-24 09:37:13.653004
# Unit test for function trange
def test_trange():
    """
    >>> list(trange(3))
    [0, 1, 2]
    """
    pass


if __name__ == "__main__":
    from doctest import testmod
    testmod()

# Generated at 2022-06-24 09:37:17.301775
# Unit test for function trange
def test_trange():
    from unittest import mock

    with mock.patch.object(tqdm, "tqdm") as tqdm_mock:
        tqdm_mock.return_value = iter(range(10))
        trange(10, desc="Test")
        tqdm_mock.assert_called_once_with(range(10), desc="Test")

# Generated at 2022-06-24 09:37:24.230549
# Unit test for function trange
def test_trange():
    """Test function trange."""
    assert list(trange(10)) == list(range(10))
    assert list(trange(0, 10, 2)) == list(range(0, 10, 2))
    assert list(trange(10, 0)) == list(range(10, 0))
    assert list(trange(0, -10, -2)) == list(range(0, -10, -2))

# Generated at 2022-06-24 09:37:31.545237
# Unit test for function trange
def test_trange():
    from .tqdm import tqdm
    from .utils import chunkify
    from .std import format_interval
    from time import sleep

    try:
        for _ in trange(3, desc='test', leave=True):
            sleep(0.001)
    finally:
        tqdm.close()

    try:
        for _ in trange(5, desc='test', position=1):
            sleep(0.001)
    finally:
        tqdm.close()

    # test iteration
    try:
        for _ in trange(iterable=range(5), desc='test', position=1):
            sleep(0.001)
    finally:
        tqdm.close()

    # test iteration with total

# Generated at 2022-06-24 09:37:41.489833
# Unit test for function trange
def test_trange():
    """Test function trange()"""
    from time import sleep
    from .std import format_interval, rate, format_meter
    # list of qwargs to try out

# Generated at 2022-06-24 09:37:44.750659
# Unit test for function trange
def test_trange():
    """Tests if trange behaves correctly"""
    assert sum(trange(100)) == sum(range(100))

# Generated at 2022-06-24 09:37:51.497108
# Unit test for function trange
def test_trange():
    """Run doctest on function `test_trange`"""
    a = list(range(0, 10))
    b = list(trange(10))
    assert a == b, "{} != {}".format(a, b)
    b = list(trange(0, 10))
    assert a == b, "{} != {}".format(a, b)
    b = list(trange(10, 0, -1))
    assert a == b[::-1], "{} != {}".format(a, b)

# Generated at 2022-06-24 09:37:52.895681
# Unit test for function trange
def test_trange():
    """Test trange shortcut"""
    list(trange(10))
    list(tqdm(range(10)))

# Generated at 2022-06-24 09:37:55.901159
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange

    :return: True if passed
    """
    for _ in trange(2, 3):
        pass

    return True

# Generated at 2022-06-24 09:38:00.481260
# Unit test for function trange
def test_trange():
    """Test function trange()"""

    def f(miniters=1, **kwargs):
        """Wrapper for trange"""
        try:
            for _ in trange(2, miniters=miniters, **kwargs):
                yield
        except Exception as e:
            raise type(e)(e.message + " on " + str(kwargs))

    # works just like range
    assert list(f(start=0)) == [0, 1]
    assert list(f(start=0, step=2)) == [0, 2]
    assert list(f(start=0, step=-2)) == [0, -2]
    assert list(f(start=1, stop=5, step=2)) == [1, 3]

# Generated at 2022-06-24 09:38:10.908509
# Unit test for function trange
def test_trange():
    "test_trange"
    from .utils import _range  # noqa

    # Test `total` kwarg
    assert len(list(trange(4, total=4))) == 4
    assert len(list(trange(4, total=5))) == 4
    assert len(list(trange(4, total=6))) == 6

    # Test negative `total` kwarg
    assert len(list(trange(4, total=-4))) == 0
    assert len(list(trange(4, total=-5))) == 0
    assert len(list(trange(4, total=-6))) == 0

    # Test compatibility with original `range`
    assert list(trange(10)) == list(_range(10))
    assert list(trange(2, 10)) == list(_range(2, 10))

# Generated at 2022-06-24 09:38:16.080248
# Unit test for function trange
def test_trange():
    """Tests that trange is a shortcut for tqdm(range(), **kwargs)."""
    from .std import trange as trange_
    for args, kwargs in [(5, {"a": 1}),
                         (range(5), {"a": 1}),
                         (5, {"a": 1}),
                         (range(5), {"a": 1})]:
        assert trange(*args, **kwargs).__next__() == trange_(*args, **kwargs).__next__()

# Generated at 2022-06-24 09:38:26.116970
# Unit test for function trange
def test_trange():
    """Test function trange()."""
    from ._utils import _supports_unicode
    import sys

    if sys.version_info < (2, 6):
        return

    with tqdm(total=1, file=sys.stderr, mininterval=0) as t:
        for i in trange(3):
            t.update(i)

    with tqdm(total=1, file=sys.stderr, mininterval=0) as t:
        for i in trange(3, desc='foo'):
            t.update(i)

    with tqdm(total=1, file=sys.stderr, mininterval=0) as t:
        for i in trange(3, desc='foo', file=sys.stdout):
            t.update(i)


# Generated at 2022-06-24 09:38:30.848208
# Unit test for function trange
def test_trange():
    """
    Test tqdm.auto.trange function.
    """
    import time
    n = 1000
    with trange(n) as t:
        for i in t:
            time.sleep(0.01)
            t.set_description("Process %i/%i" % (i, n))

# Generated at 2022-06-24 09:38:42.422142
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .std import tqdm, trange, FormatCustomTextType
    from .utils import format_interval

    with tqdm(total=10) as pbar:
        for _ in trange(1, 11, desc="Test", leave=True, file=sys.stdout,
                        miniters=1, mininterval=0.0, smoothing=0.0):
            pass

    with tqdm("Test", total=10, file=sys.stdout, mininterval=0) as pbar:
        for _ in trange(11):
            pass

    with tqdm("Test", total=10, file=sys.stdout, mininterval=0) as pbar:
        for _ in trange(1, 11):
            pbar.miniters = 2
           

# Generated at 2022-06-24 09:38:48.381605
# Unit test for function trange
def test_trange():
    """Test trange."""
    from .std import tqdm as std_tqdm

    for n in range(1, 4):
        str_repr = "|".join([str(i) for i in range(n)])
        assert sum(trange(n)) == sum(std_tqdm(range(n))) == sum(range(n))
        assert str_repr == str("|".join([str(i) for i in trange(n)]))

# Generated at 2022-06-24 09:38:52.535716
# Unit test for function trange
def test_trange():
    """
    Simple unit test for trange
    """
    from .auto import trange
    import time

    for i in trange(10):
        time.sleep(0.01)

# Generated at 2022-06-24 09:38:54.229944
# Unit test for function trange
def test_trange():
    import time
    for _ in trange(10):
        time.sleep(0.1)

# Generated at 2022-06-24 09:38:56.411296
# Unit test for function trange
def test_trange():
    """Simple sanity check."""
    list(trange(100))

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:39:00.247673
# Unit test for function trange
def test_trange():
    assert list(trange(5)) == [0, 1, 2, 3, 4]
    assert list(trange(5, 10)) == [5, 6, 7, 8, 9]
    assert list(trange(5, 10, 2)) == [5, 7, 9]


# Generated at 2022-06-24 09:39:04.084507
# Unit test for function trange
def test_trange():
    """Test basic function of trange"""
    from .std import tqdm as std_tqdm
    assert notebook_tqdm is not std_tqdm
    assert tqdm is not std_tqdm
    assert tqdm is notebook_tqdm
    assert trange(3).__class__ is notebook_trange(3).__class__
    assert trange(3).__class__ is notebook_trange(3).__class__

# Generated at 2022-06-24 09:39:14.727873
# Unit test for function trange
def test_trange():  # pragma: no cover
    """ Unit tests for `tqdm.auto.trange` function """
    import time
    from .std import tqdm

    def test_trange_custom(**kwargs):
        """ Test for `tqdm.auto.tqdm.trange` function """
        list(tqdm(**kwargs))

    # Test that trange works in normal mode
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")

        test_trange_custom(total=10)

        # Test that `trange` works in notebook mode
        from .autonotebook import tqdm

        # noinspection PyArgumentList
        test_trange_custom(total=10)

        # Test that `trange` works in asyncio mode

# Generated at 2022-06-24 09:39:21.685037
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange

    Examples
    --------
    >>> test_trange()
    """
    temp = list(trange(100))
    assert temp == list(range(100))

    # Test dynamic updating
    with trange(5) as t:
        for i in t:
            t.set_postfix(i=i)
            time.sleep(0.01)
            if i >= 1:
                break
    # assert list(t) == [0, 1, 2, 3, 4]

# Generated at 2022-06-24 09:39:27.334942
# Unit test for function trange
def test_trange():
    """Tests for function trange"""
    from .std import trange
    from .std import tqdm
    for i in trange(4):
        assert i in [0, 1, 2, 3]
        if i > 1:
            break

    with tqdm(total=9) as pbar:
        for i in trange(4, desc='1st loop', total=4):
            assert i in [0, 1, 2, 3]
            pbar.update()
            if i > 1:
                break

        for i in trange(4, desc='2nd loop', total=4):
            assert i in [0, 1, 2, 3]
            pbar.update()

    for i in trange(4, desc='desc', leave=True):
        assert i in [0, 1, 2, 3]

# Generated at 2022-06-24 09:39:30.685031
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .tests_tqdm import test_trange as test_trange

    test_trange(trange, tqdm)

# Generated at 2022-06-24 09:39:34.965079
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .gui import tgrange
    import time

    try:
        tgrange(range(5), sleep=True)
        assert trange(5, sleep=True) == list(range(5))
    except Exception as _exc:
        time.sleep(1.01)
        assert trange(4, sleep=True) == list(range(4))

# Generated at 2022-06-24 09:39:41.927934
# Unit test for function trange
def test_trange():
    # список целых чисел от 0 до 99
    items = list(range(100))
    # без tqdm
    # i = 0
    # iterations = []
    # for item in items:
    #     i += 1
    #     iterations.append(item * item)

    # с tqdm
    for _ in trange(10):
        pass

test_trange()

# Generated at 2022-06-24 09:39:43.541105
# Unit test for function trange
def test_trange():
    with tqdm(total=10) as t:
        for _ in trange(10):
            t.update()

# Generated at 2022-06-24 09:39:45.380731
# Unit test for function trange
def test_trange():
    assert list(trange(10)) == list(range(10))
    assert list(trange(10, desc="test")) == list(range(10))

# Generated at 2022-06-24 09:39:46.514576
# Unit test for function trange
def test_trange():
    for i in trange(10):
        assert i < 10
        assert i >= 0

# Generated at 2022-06-24 09:39:49.193989
# Unit test for function trange
def test_trange():
    """ Unit test for function trange() """
    list(tqdm.trange(100, unit="toto"))


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 09:39:50.753254
# Unit test for function trange
def test_trange():
    assert (list(trange(3, desc="trange")) == list(tqdm(range(3), desc="trange")))

# Generated at 2022-06-24 09:40:01.025543
# Unit test for function trange
def test_trange():
    """Test trange"""
    from .utils import formatted_size
    from .tqdm import tnrange
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", TqdmExperimentalWarning)
        from .autonotebook import trange as atr
    from .std import trange as str
    from .asyncio import trange as atr2
    assert str(10) == atr(10) == atr2(10) == tnrange(10)
    with tqdm(total=10, ascii=True) as pbar:
        for _ in trange(10):
            pbar.update()
    assert pbar.n == 10

# Generated at 2022-06-24 09:40:11.829419
# Unit test for function trange
def test_trange():
    """ Test trange function """
    from .trange import trange
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import _nt_to_str
    from .utils import _range
    import time
    import random
    import gc
    import psutil
    import sys
    import os

    try:
        from sys import getsizeof
    except ImportError:
        getsizeof = lambda x: 2 ** 16  # mock

    try:
        from sys import intern
        _range = intern(_range)
    except ImportError:
        pass

    # Check the range constructor and length
    assert list(trange(0)) == []
    assert list(trange(3)) == [0, 1, 2]

    # Check the total and W/s
    gc.collect()

# Generated at 2022-06-24 09:40:17.151233
# Unit test for function trange
def test_trange():
    """
    Test function trange
    """

    import sys
    if sys.version_info[:2] < (3, 6):
        tqdm = notebook_tqdm
        trange = notebook_trange
    else:  # Python3.6+
        tqdm = asyncio_tqdm
        trange = test_trange.__closure__[0].cell_contents

    # Test trange
    for _ in trange(10, 15):
        pass
    for _ in trange(10):
        pass
    for _ in trange(10, 25, 2):
        pass
    for _ in trange(10, 25, 2, 1):
        pass
    for _ in trange(10, 25, 2, 0):
        pass

# Generated at 2022-06-24 09:40:26.245398
# Unit test for function trange
def test_trange():
    """Test function trange"""
    for _ in trange(4):
        pass
    for _ in trange(4, desc="DESC"):
        pass
    for _ in trange(4, position=1, desc="DESC"):
        pass
    for _ in trange(4, ascii=True):
        pass
    for _ in trange(4, smoothing=0):
        pass
    for _ in trange(4, miniters=1):
        pass
    for _ in trange(4, mininterval=1):
        pass
    for _ in trange(4) | trange(4):
        pass
    for _ in trange(4) | trange(4) | trange(4):
        pass

# Generated at 2022-06-24 09:40:35.617156
# Unit test for function trange
def test_trange():
    """
    Tests trange function.
    """
    from time import sleep
    from numpy import allclose

    # Simple trange
    xpos = 0
    with trange(10) as t:
        for i in t:
            sleep(0.01)
            xpos = xpos + 0.1

    assert allclose(xpos, 1)

    # Iterable trange
    with trange(10, 20, 2) as t:
        for i in t:
            sleep(0.01)

    # Randomize trange
    try:
        from random import sample
    except ImportError:
        from random import sample
    xpos = []
    with trange(100, desc='test') as t:
        for i in sample(range(200), 100):
            sleep(0.01)

# Generated at 2022-06-24 09:40:38.888861
# Unit test for function trange
def test_trange():
    """Test module function ``trange``."""
    import warnings

    warnings.filterwarnings("ignore", category=TqdmExperimentalWarning)

    list(trange(3))
    assert True

# Generated at 2022-06-24 09:40:47.110107
# Unit test for function trange
def test_trange():
    from .std import format_interval
    from time import sleep

    t = trange(10, mininterval=0.01)
    for _ in t:
        sleep(0.01)
    example_finished = format_interval(t.last_print_t - t.start_t)
    assert t.last_print_t - t.start_t >= 1, \
        ("last_print_t - start_t: %s should be "
         ">= 1 second" % example_finished)
    t.close()

# Generated at 2022-06-24 09:40:49.418886
# Unit test for function trange
def test_trange():
    for _ in trange(4):
        pass
    for _ in trange(4, desc="Test"):
        pass
    for _ in trange(4, miniters=2):
        pass

# Generated at 2022-06-24 09:40:58.596357
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    import unittest
    import os
    import shutil
    from io import StringIO
    from tqdm.auto import trange

    class Tests(unittest.TestCase):
        def setUp(self):
            """Create temporary file"""
            self.tmpfile = os.path.join(os.path.dirname(__file__),
                                        'tmpfile.txt')
            open(self.tmpfile, 'w').close()

        def tearDown(self):
            """Delete temporary file"""
            os.unlink(self.tmpfile)

        def test_trange(self):
            """test trange"""
            t = trange(0, 3, desc='Test trange functionality')
            t.update(3)
            t.close()


# Generated at 2022-06-24 09:40:59.392391
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    for _ in trange(10):
        pass



# Generated at 2022-06-24 09:41:03.811086
# Unit test for function trange
def test_trange():
    from ._utils import _range
    from random import random

    for _ in trange(10):
        for _ in trange(100):
            for _ in trange(1000):
                for _ in trange(10000):
                    for _ in trange(100000):
                        for _ in trange(1000000):
                            for _ in trange(10000000):
                                a = random()

# Generated at 2022-06-24 09:41:10.623981
# Unit test for function trange
def test_trange():
    """Test function trange"""
    with tqdm(total=0) as pbar:
        trange_iter = trange(3)
        assert pbar.total == 3
        assert next(trange_iter) == 0
        assert next(trange_iter) == 1
        assert next(trange_iter) == 2
        assert pbar.n == 3
        # No auto close
        assert not pbar.disable
        with pytest.raises(StopIteration):
            next(trange_iter)



# Generated at 2022-06-24 09:41:16.601800
# Unit test for function trange
def test_trange():
    """Test for trange"""
    # pylint: disable=protected-access
    for _ in trange(4):
        pass
    assert tqdm(range(4)).total == 4
    assert tqdm(range(4)).last_print_n == 4
    assert tqdm(range(4)).n == 4
    assert not tqdm(range(4)).leave
    # pylint: enable=protected-access

# Generated at 2022-06-24 09:41:18.970707
# Unit test for function trange
def test_trange():
    """Test if trange is working"""
    from ._utils import _range
    l = list(trange(5))
    assert l == _range(5)


# Generated at 2022-06-24 09:41:31.263369
# Unit test for function trange
def test_trange():
    from .std import tqdm

    # Test trange
    n = 100
    for i in trange(n, '1st loop'):
        for _ in trange(5, '2nd loop', leave=False):
            for _ in trange(i, '3rd loop', leave=False):
                for _ in trange(5):
                    pass
    for i in tqdm(range(n), desc='1st loop'):
        for _ in tqdm(range(5), desc='2nd loop', leave=False):
            for _ in tqdm(range(i), desc='3rd loop', leave=False):
                for _ in tqdm(range(5)):
                    pass
    trange(n, ascii=True)
    trange(n, mininterval=0.01)
   

# Generated at 2022-06-24 09:41:42.605423
# Unit test for function trange
def test_trange():
    """Tests that tqdm(range) works"""
    from .std import allclose, format_interval
    from .utils import suppress_stdout_stderr

    @suppress_stdout_stderr
    def inner(unit_scale, unit, abspos, leave, smoothing,
              write_bytes=sys.stdout.buffer.write):
        for i in trange(1, 2, 1, unit_scale=unit_scale, unit=unit,
                        smoothing=smoothing,
                        abspos=abspos, leave=leave):
            assert (i == 1)
            # Set the size to 10
            write_bytes(b'1234567890')

    # Test unit_scale and unit

# Generated at 2022-06-24 09:41:50.336662
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from .std import format_sizeof

    for i in trange(1000, desc="trange", leave=False, ascii=True, unit="B"):
        pass  # flake8: noqa
    for i in trange(1000, desc="trange", leave=True, ascii=True, unit="B"):
        break  # flake8: noqa
    for i in trange(1000, desc="trange", leave=False, ascii=True, mininterval=0.01, unit="B"):
        pass  # flake8: noqa
    for i in trange(1000, desc="trange", leave=False, ascii=True, mininterval=0.01, smoothing=0.01, unit="B"):
        pass  # fl

# Generated at 2022-06-24 09:41:52.149695
# Unit test for function trange
def test_trange():
    "Unit test for trange"
    for _ in trange(2):
        pass

# Generated at 2022-06-24 09:41:56.728865
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import _supports_unicode
    for i in trange(10, desc='it', leave=_supports_unicode):
        pass


# Generated at 2022-06-24 09:41:58.797712
# Unit test for function trange
def test_trange():
    """Test trange"""
    assert list(trange(10)) == list(range(10))
    assert list(trange(2, 10)) == list(range(2, 10))

# Generated at 2022-06-24 09:42:04.637537
# Unit test for function trange
def test_trange():
    from .std import tqdm, trange
    from .std import __version__ as tqdm_version

    assert "tqdm/_tqdm" in str(tqdm), tqdm
    assert "tqdm/_tqdm" in str(trange), trange

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        with tqdm(total=5) as pbar:
            pbar.clear()

    # Do not fail if version is wrong
    assert isinstance(w[0].message, TqdmExperimentalWarning) or \
        "tqdm.auto" in w[0].message.args[0], w[0].message

    msg = str(w[-1].message)
    assert "tqdm/auto.py" in msg

# Generated at 2022-06-24 09:42:12.977299
# Unit test for function trange
def test_trange():
    """Test function trange"""
    assert list(trange(0)) == list(range(0))
    assert list(trange(10)) == list(range(10))
    assert list(trange(10, 0, -1)) == list(range(10, 0, -1))
    assert list(trange(10, 0, -1.5)) == list(range(10, 0, -1))
    assert list(trange(0, 10, 1)) == list(range(0, 10, 1))
    assert list(trange(0, 10, 1.5)) == list(range(0, 10, 1))
    assert list(trange(0, -10, -1)) == list(range(0, -10, -1))

# Generated at 2022-06-24 09:42:16.206700
# Unit test for function trange
def test_trange():
    """Test"""
    from .utils import _term_move_up

    with tqdm(total=10) as pbar:
        for _ in range(5):
            pbar.update()
            _term_move_up()
    # post test cleanup
    print('', end='')  # print new-line
    sys.stderr.flush()

# Generated at 2022-06-24 09:42:18.072966
# Unit test for function trange
def test_trange():
    """
    >>> test_trange()
    10
    """
    from .auto import trange
    return sum(1 for _ in trange(10))

# Generated at 2022-06-24 09:42:18.974696
# Unit test for function trange
def test_trange():
    """
    Tests function `trange`
    """
    list(trange(2))

# Generated at 2022-06-24 09:42:22.692374
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    print("Testing tqdm.auto.trange, please wait...")
    trange(10000).__next__()

# Generated at 2022-06-24 09:42:25.486447
# Unit test for function trange
def test_trange():
    """Test if trange works"""
    from .std import trange
    assert list(trange(2)) == [0, 1]
    assert list(trange(0)) == []


# Generated at 2022-06-24 09:42:32.649688
# Unit test for function trange
def test_trange():
    """Test function `trange`."""
    assert list(trange(10)) == list(range(10))
    assert list(trange(10)) == list(tqdm(range(10)))
    assert list(trange(5, 10)) == list(tqdm(range(5, 10)))
    assert list(trange(5, 15, 2)) == list(tqdm(range(5, 15, 2)))
    assert list(
        trange(5, 15, 2, desc="desc", ascii=True, ncols=100, disable=True)
    ) == list(tqdm(range(5, 15, 2), desc="desc", ascii=True, ncols=100, disable=True))

# Generated at 2022-06-24 09:42:33.500452
# Unit test for function trange
def test_trange():
    assert list(trange(2)) == list(range(2))

# Generated at 2022-06-24 09:42:34.833915
# Unit test for function trange
def test_trange():
    for _ in trange(10):
        1 + 1



# Generated at 2022-06-24 09:42:37.720216
# Unit test for function trange
def test_trange():
    for i in trange(5):
        pass

if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 09:42:39.694045
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from ._tqdm import trange
    for _ in trange(4, 0, -1):
        pass

# Generated at 2022-06-24 09:42:49.735023
# Unit test for function trange
def test_trange():
    """Test function trange"""

# Generated at 2022-06-24 09:42:54.186704
# Unit test for function trange
def test_trange():
    """
    Tests that trange handles integers, lists and other iterators correctly.
    """
    for i in trange(3):
        assert i == 0
        break
    for i in trange(1, 20, 2):
        assert i == 1
        break
    for i in trange([], leave=True):
        assert False
    for i in trange((i for i in [4]), leave=True):
        assert i == 4
        break


# Generated at 2022-06-24 09:42:58.448547
# Unit test for function trange
def test_trange():
    """Unit tests for function `trange`."""
    from .std import tqdm
    from nose.tools import assert_equal

    t0 = trange(5)
    t1 = tqdm(range(5))
    assert_equal(t0, t1)

# Generated at 2022-06-24 09:43:08.781322
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    import unittest
    import contextlib

    class TrangeTestCase(unittest.TestCase):
        @contextlib.contextmanager
        def assert_prints(self, value):
            import io
            with io.StringIO() as buf, \
                    contextlib.redirect_stdout(buf):
                yield
                self.assertEqual(buf.getvalue(), value)

        def test_trange(self):
            """
            Test for trange
            """
            from .std import tqdm_gui
            from .gui import tqdm as gui_tqdm
            from .gui import trange as gui_trange


# Generated at 2022-06-24 09:43:19.014258
# Unit test for function trange
def test_trange():
    """Test for function trange."""
    from sys import platform
    if platform.startswith("win"):
        import subprocess
        from shlex import quote

        if platform == "win64":
            python = r'"C:\Program Files\Python36\python.exe"'
        else:
            python = r'"C:\Program Files (x86)\Python36\python.exe"'


# Generated at 2022-06-24 09:43:19.987325
# Unit test for function trange
def test_trange():
    """Test for trange()"""
    for i in trange(10):
        pass

# Generated at 2022-06-24 09:43:21.051899
# Unit test for function trange
def test_trange():
    from .tests import test_trange
    return test_trange()

# Generated at 2022-06-24 09:43:22.942227
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Run trange unit test"""
    assert list(trange(5)) == list(tqdm(range(5)))

# Generated at 2022-06-24 09:43:26.940210
# Unit test for function trange
def test_trange():
    """Test to make sure that a trange with a non-zero start parameter works
    correctly."""
    start = 5
    end = 10
    for i in trange(start, end):
        assert i == start
        start += 1
    assert start == end

# Generated at 2022-06-24 09:43:36.226420
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from .utils import _range
    trange(5)
    trange(5, desc='Test trange')
    trange(5, desc='Test trange', leave=False)
    trange(5, desc='Test trange', smoothing=0)
    trange(5, desc='Test trange', smoothing=1)
    trange(5, desc='Test trange', smoothing=0.5)
    trange(5, desc='Test trange', miniters=0)
    trange(5, desc='Test trange', miniters=1)
    trange(5, desc='Test trange', ascii=True)
    trange(5, desc='Test trange', ascii=False)

# Generated at 2022-06-24 09:43:41.043256
# Unit test for function trange
def test_trange():
    """
    Simple test of trange function output
    """
    from io import StringIO
    buf = StringIO()
    trange(3, file=buf)
    buf.seek(0)
    assert buf.read() == "\r  0%|          | 0/3 [00:00<?, ?it/s]\r 33%|███▎      | 1/3 [00:00<00:00,  6.00it/s]\r 67%|██████▋   | 2/3 [00:00<00:00,  5.00it/s]\r100%|██████████| 3/3 [00:00<00:00,  5.00it/s]\n"

# Generated at 2022-06-24 09:43:44.036622
# Unit test for function trange
def test_trange():
    """Test for `tqdm.auto.trange`"""
    prog = trange(1)
    prog.close()
    assert next(prog) == 0

# Generated at 2022-06-24 09:43:45.372800
# Unit test for function trange
def test_trange():
    for i in trange(10):
        assert i == i

# Generated at 2022-06-24 09:43:48.311583
# Unit test for function trange
def test_trange():
    """
    >>> test_trange()
    """
    test_sample = list(trange(10))
    assert test_sample == list(range(10))

# Generated at 2022-06-24 09:43:50.334590
# Unit test for function trange
def test_trange():
    """Test for trange() and tqdm()"""
    for _ in trange(4):
        for _ in tqdm(range(100), desc="inner loop"):
            pass

# Generated at 2022-06-24 09:43:56.886860
# Unit test for function trange
def test_trange():
    try:
        from IPython.display import clear_output
        from IPython.testing.globalipapp import get_ipython  # noqa
    except ImportError:
        pass
    else:
        ip = get_ipython()
        ip.enable_gui("test")
        for _ in trange(4, desc="test"):
            clear_output()

# Generated at 2022-06-24 09:43:58.751353
# Unit test for function trange
def test_trange():
    """
    Unit test for the function trange
    """
    assert sum(trange(10)) == 45

# Generated at 2022-06-24 09:44:01.593275
# Unit test for function trange
def test_trange():
    import time
    for y in trange(0, 4):
        print(y)
        time.sleep(0.5)

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:44:02.832364
# Unit test for function trange
def test_trange():
    """Test trange not raising errors"""
    trange(2)

# Generated at 2022-06-24 09:44:07.250868
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from time import sleep
    # pylint: disable=unused-variable
    t = trange(100, ascii=True)
    for _ in t:
        sleep(0.01)
        t.set_postfix(ordered_dict={"hello": "world"})

# Generated at 2022-06-24 09:44:08.769173
# Unit test for function trange
def test_trange():
    x = list(trange(10))
    assert x == list(range(10))
    assert len(x) == 10


# Generated at 2022-06-24 09:44:11.552285
# Unit test for function trange
def test_trange():
    """Test function trange of tqdm.auto"""
    # Test 1
    for _ in trange(4):
        pass

    # Test 2
    for _ in trange(10):
        break

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:44:20.506293
# Unit test for function trange
def test_trange():
    """Test trange() (dependent on t.__class__)"""
    for t in [trange(7), tqdm(range(7))]:
        for unit in ['', 'it', 'iterations']:
            t.close()
            t.reset()
            t.unit = unit
            t.__exit__(None, None, None)
            t.__enter__()
            expected = [(0, 0, 1, 1), (1, 1, 7, 1)]
            assert all(i == o for i, o in zip(expected, t.format_dicts))



# Generated at 2022-06-24 09:44:23.684716
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange

    >>> test_trange()
    """
    from random import random as r

    l = [r() for _ in trange(1000)]
    assert len(l) == 1000


if __name__ == "__main__":
    from doctest import testmod
    testmod()

# Generated at 2022-06-24 09:44:25.829064
# Unit test for function trange
def test_trange():
    from .testing import _test_range_iterable

    assert _test_range_iterable(trange) == 0

# Generated at 2022-06-24 09:44:35.762102
# Unit test for function trange
def test_trange():
    import sys

    class DummyTqdm:
        def __call__(self, *args, **kwargs):
            self._args = args
            self._kwargs = kwargs
            return self

        def __iter__(self):
            return iter(self._args[0])

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        from tqdm.autonotebook import trange as notebook_trange
        from tqdm.std import trange as std_trange
        if notebook_trange != std_trange:
            # Notebook trange is overridden
            assert trange is notebook_trange
            orig_tqdm, tqdm.tqdm = tqdm.tqdm, DummyTqdm()

# Generated at 2022-06-24 09:44:39.810126
# Unit test for function trange
def test_trange():
    """Test for tqdm.auto.trange"""
    assert list(trange(10)) == list(range(10))
    assert trange(1, 1, 5).__class__.__name__ == 'tqdm'

# Generated at 2022-06-24 09:44:46.532395
# Unit test for function trange
def test_trange():
    """Test function trange"""
    assert list(trange(0)) == []
    assert list(trange(3)) == [0, 1, 2]
    assert list(trange(1, 3)) == [1, 2]
    assert list(trange(1, 3, 0.5)) == [1.0, 1.5, 2.0, 2.5]
    assert list(trange(3, 1)) == []
    assert list(trange(3, 1, -0.5)) == [2.5, 2.0, 1.5, 1.0]

# Generated at 2022-06-24 09:44:49.403513
# Unit test for function trange
def test_trange():
    """Test function tqdm.trange"""
    assert trange(3) == list(range(3))  # test identity

# Generated at 2022-06-24 09:44:50.815151
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    assert range(10) == list(trange(10))



# Generated at 2022-06-24 09:44:51.945322
# Unit test for function trange
def test_trange():
    for _ in trange(4, desc='trange'):
        pass

# Generated at 2022-06-24 09:44:58.227622
# Unit test for function trange
def test_trange():
    """
    Unit tests for function trange.
    """
    from .tqdm_gui import tqdm_gui
    for t in (tqdm, tqdm_gui):
        for leave in [False, True]:
            for j in t(range(1), leave=leave, position=0):
                for i in trange(10, leave=leave, position=1):
                    if i == 1:
                        j.update(1)
                assert j.n == 1
            assert j.n == 1

# Generated at 2022-06-24 09:45:07.966647
# Unit test for function trange
def test_trange():
    """
    Tests `tqdm.auto.trange` function.
    """
    from .std import FormatCustomTextType

    for _ in trange(4, desc="inner loop", leave=False):
        for j in trange(6, desc="outer loop", leave=True, ascii=True):
            pass

    for _ in trange(4, desc="inner loop", unit_scale=True, leave=False):
        for j in trange(6, desc="outer loop", unit_scale=2, leave=True):
            pass

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)

# Generated at 2022-06-24 09:45:09.492335
# Unit test for function trange
def test_trange():
    """
    Simple test for trange
    """
    for i in trange(5):
        if i == 3:
            break

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:45:16.015393
# Unit test for function trange
def test_trange():
    '''Unit test for function trange'''
    import time
    from tqdm.auto import trange

    def check(total, desc='', leave=False):
        for _ in trange(total, desc=desc, leave=leave):
            time.sleep(0.01)
    check(total=10, desc='test')
    check(total=10, desc='test', leave=True)


if __name__ == "__main__":
    from .tests import test_auto
    test_auto()
    test_trange()

# Generated at 2022-06-24 09:45:18.082983
# Unit test for function trange
def test_trange():
    """Simple unit test for trange"""
    list(trange(3))

# Generated at 2022-06-24 09:45:20.753524
# Unit test for function trange
def test_trange():
    list(trange(4))
    list(trange(5, 5))
    list(trange(5, 5, 1))
    list(trange(5, 5, 1, desc="desc"))

# Generated at 2022-06-24 09:45:23.565326
# Unit test for function trange
def test_trange():
    """
    Doctests
    >>> list(trange(10))
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    """
    pass

# Generated at 2022-06-24 09:45:29.133423
# Unit test for function trange
def test_trange():
    """
    Simple unit test for function `trange`.
    """
    from .std import format_interval
    from .utils import time

    # Testing trange
    with timeit() as timer:
        for _ in trange(10, disable=True):
            time.sleep(0.01)
    assert timer.interval >= 1.0, "disable=True does not work"
    assert format_interval(timer.interval)


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:45:36.649286
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm as std_tqdm
    from .asyncio import tqdm as asyncio_tqdm
    for task in [
        (std_tqdm, std_tqdm),
        (std_tqdm, asyncio_tqdm),
        (asyncio_tqdm, asyncio_tqdm),
    ]:
        assert trange(5) == task[0](range(5))