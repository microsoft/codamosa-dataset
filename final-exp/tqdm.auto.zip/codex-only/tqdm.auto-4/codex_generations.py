

# Generated at 2022-06-24 09:35:48.138292
# Unit test for function trange
def test_trange():
    assert list(trange(5)) == [0, 1, 2, 3, 4]



# Generated at 2022-06-24 09:35:50.287317
# Unit test for function trange
def test_trange():
    """
    Test only function trange.
    """
    assert list(trange(10)) == list(range(10))

# Generated at 2022-06-24 09:35:51.601417
# Unit test for function trange
def test_trange():
    """Test for `trange()`"""
    list(trange(7))

# Generated at 2022-06-24 09:35:54.237927
# Unit test for function trange
def test_trange():
    assert list(trange(10)) == list(range(10))
    assert list(trange(10, 20)) == list(range(10, 20))
    assert list(trange(10, 20, 2)) == list(range(10, 20, 2))
    assert list(trange(5, 0, -1)) == list(range(5, 0, -1))

# Generated at 2022-06-24 09:35:55.420115
# Unit test for function trange
def test_trange():
    """Test if trange works"""
    list(trange(3))


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:36:07.512443
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from .auto import trange
    for _ in trange(2):
        pass
    for _ in trange(2, 0, -1):
        pass
    for _ in trange(0):
        pass
    for _ in trange(0, 0):
        pass
    for _ in trange(0, 0, -1):
        pass
    for _ in trange(0, 2, -1):
        pass
    for _ in trange(0, 2, -1):
        pass
    for _ in trange(2, 0, -1):
        pass
    for _ in trange(2, 0, -2):
        pass
    for _ in trange(2, 0, 1):
        pass

# Generated at 2022-06-24 09:36:17.420757
# Unit test for function trange
def test_trange():
    """Test trange"""
    # pylint: disable=E1103
    list(trange(5))
    assert next(trange(5)) == 0
    assert list(trange(2, 3)) == [2]
    assert list(trange(3, 4)) == [3]
    assert list(trange(3, 4, 1)) == [3]
    assert list(trange(3, 4, 0)) == [3]
    assert list(trange(4, 3, -1)) == [4]
    assert list(trange(4, 3, -2)) == [4]
    list(trange(4, 1, -1)) == [4, 3, 2]
    list(trange(3, 4, 2)) == [3]

# Generated at 2022-06-24 09:36:18.230808
# Unit test for function trange
def test_trange():
    N = 10
    list(trange(N))

# Generated at 2022-06-24 09:36:20.125347
# Unit test for function trange
def test_trange():
    """
    Unit test for trange function.
    """
    list(trange(10))
    list(tqdm(range(10)))

# Generated at 2022-06-24 09:36:25.843321
# Unit test for function trange
def test_trange():
    """Tests trange function"""
    # Tests short name
    assert trange == tqdm.auto.trange

    # Tests custom iteration
    from tqdm.auto import trange
    from operator import mul

    with trange(4) as t:
        for i in t:
            assert i == t.n - t.n_fmt_len
            t.set_postfix(sum=t.n)
            t.update()

    # Tests empty iterator
    for _ in trange(0):
        pass
    for _ in trange(0, 0):
        pass
    for _ in trange(5, 0):
        pass

    # Tests total argument
    for _ in trange(5):
        pass
    for _ in trange(5, 10):
        pass

# Generated at 2022-06-24 09:36:32.391022
# Unit test for function trange
def test_trange():
    """ Smoketest trange() """
    list(trange(5))
    list(trange(5, 0, -1))

    # Has to work with non-int args
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=DeprecationWarning)
        list(trange(-5))
        list(trange(-4, -2))
        list(trange(-4, 0))

        # Should not raise
        list(trange(0, 0))
        list(trange(0, 0, 0))

# Generated at 2022-06-24 09:36:35.502401
# Unit test for function trange
def test_trange():
    """
    Tests trange()
    """
    trange_results = [i for i in trange(10)]
    assert trange_results == list(range(10))

# Generated at 2022-06-24 09:36:40.859418
# Unit test for function trange
def test_trange():
    from .std import tqdm as std_tqdm
    assert std_tqdm == tqdm
    for cls in [std_tqdm, notebook_tqdm, asyncio_tqdm]:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
            assert cls is tqdm
            assert cls(range(3))



# Generated at 2022-06-24 09:36:49.152181
# Unit test for function trange
def test_trange():
    """Test for `trange`"""
    from .utils import _range

    for i in trange(_range(30)):
        pass
    assert i == 29
    assert isinstance(i, int)
    for i in trange(_range(30), desc="desc"):
        pass
    assert i == 29
    assert isinstance(i, int)
    for i in trange(_range(30), desc="desc", leave=True):
        pass
    assert i == 30
    assert isinstance(i, int)

    trange(0, 30).close()
    trange(0, 30, leave=True).close()
    trange(0, 30, desc="desc").close()
    trange(0, 30, desc="desc", leave=True).close()

# Generated at 2022-06-24 09:36:52.210428
# Unit test for function trange
def test_trange():
    """Test for trange"""
    assert hasattr(trange(0), '__iter__')
    from tqdm.gui import trange
    assert hasattr(trange(0), '__iter__')

# Generated at 2022-06-24 09:37:03.285301
# Unit test for function trange
def test_trange():
    """
    Unit tests for function `trange`.
    """
    assert list(trange(3, 6)) == [3, 4, 5]
    assert list(trange(3, 6, 2)) == [3, 5]
    assert list(trange(5)) == list(range(5))
    assert list(trange(3, 6, desc="Test", leave=True, ascii=True)) == [3, 4, 5]
    tot = 0
    for _ in trange(1e4):
        tot += 1
    assert tot == 1e4
    tot = 0
    for _ in trange(int(1e4)):
        tot += 1
    assert tot == 1e4
    assert len(tqdm._instances) == 0
    tot = 0

# Generated at 2022-06-24 09:37:13.456434
# Unit test for function trange
def test_trange():
    """ Testing function """
    from .std import tqdm
    from .std import tqdm_gui  # pylint: disable=unused-variable,unused-import
    import collections
    import types

    def _test(t, n, *args, **kwargs):
        """ Testing function """
        assert type(t) is tqdm

        # initial width
        width = kwargs.get('miniters', n)
        assert kwargs.get('total', None) == n
        if 'mininterval' in kwargs:
            # next()
            assert kwargs['mininterval'] <= 0.5
        else:
            assert kwargs['mininterval'] == t._miniters / t._mininterval
        # first bar
        assert t.last_print_n == 0
       

# Generated at 2022-06-24 09:37:16.874816
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm

    assert list(trange(3)) == [0, 1, 2]
    assert list(trange(3, 0, -1)) == [3, 2, 1]
    assert list(trange(3, step=2)) == [0, 2]

# Generated at 2022-06-24 09:37:26.689859
# Unit test for function trange
def test_trange():
    """
    Test trange.

    :return:
    """
    from time import sleep
    from numpy import testing
    from .std import tqdm

    # test trange
    testing.assert_array_equal(list(tqdm(range(10))),
                               list(trange(10)),
                               'trange test failed!', fatal=True)
    with tqdm(total=10) as pbar:
        pbar.write('test')
        sleep(0.1)
        pbar.update()
        pbar.set_description('test2')

    t = trange(10)
    next(t)
    t.close()


# Generated at 2022-06-24 09:37:36.413391
# Unit test for function trange
def test_trange():
    """Test function trange"""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        # Test tqdm-notebook
        with notebook_tqdm(range(100), disable=True) as pbar:
            assert pbar.n == 100
        # Test tqdm (std)
        with std_tqdm(range(100), disable=True) as pbar:
            assert pbar.n == 100
        # Test trange
        with tqdm(range(100), disable=True) as pbar:
            assert pbar.n == 100


# Generated at 2022-06-24 09:37:40.113494
# Unit test for function trange
def test_trange():
    """
    Unit test for function `trange`
    """
    from .gui import tqdm
    from .std import closing

    with closing(tqdm(range(10), desc='Unit test for function trange')) as pbar:
        for _ in pbar:
            pass



# Generated at 2022-06-24 09:37:42.836637
# Unit test for function trange
def test_trange():
    from .std import trange as _trange
    from .asyncio import trange as aiotrange
    from .autonotebook import trange as nbtrange

    assert trange is not _trange
    assert trange is nbtrange or trange is aiotrange


# Generated at 2022-06-24 09:37:48.220322
# Unit test for function trange
def test_trange():
    # On Python 2.7, `list(tqdm(range(2)))` is not supported
    assert list(trange(2)) == [0, 1]
    l = list(trange(2))
    # check that tqdm(range()) output is a list
    assert isinstance(l, list)

# Generated at 2022-06-24 09:37:49.788804
# Unit test for function trange
def test_trange():
    for i in trange(10):
        pass

# Generated at 2022-06-24 09:38:00.311145
# Unit test for function trange
def test_trange():
    "Test Python3.7+ trange is not just a proxy to tqdm"
    class CountingAbcMeta(type):  # pylint: disable=invalid-name
        """
        Counter for the number of __new__ calls.
        """
        initiated = 0
        def __new__(mcls, name, bases, ns):
            CountingAbcMeta.initiated += 1
            return super().__new__(mcls, name, bases, ns)

    class TqdmOrigin(metaclass=CountingAbcMeta):
        """
        Class for counting the number of calls to TqdmOrigin class.
        """
        pass

    class Tqdm(tqdm, TqdmOrigin):
        """
        Class for counting the number of calls to TqdmOrigin class.
        """
        pass

# Generated at 2022-06-24 09:38:10.719698
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from .std import _supports_unicode
    from .gui import tqdm as gui_tqdm

    for _tqdm in (gui_tqdm, tqdm):
        for i in _tqdm(trange(3)):
            pass
        for i in _tqdm(trange(3), desc='desc', leave=True):
            pass
        for i in _tqdm(trange(3), desc='desc', leave=True, ascii=True,
                       unit='b'):
            pass
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=DeprecationWarning)
            for i in _tqdm(trange(3), desc='desc', dynamic_ncols=True):
                pass

# Generated at 2022-06-24 09:38:16.704373
# Unit test for function trange
def test_trange():
    ''' Unit test for function trange '''
    import unittest
    import time
    class AutoTqdmTest(unittest.TestCase):
        def test_trange(self):
            ''' Unit test for trange '''
            for i in trange(3):
                time.sleep(1)
    unittest.main(argv=[''], verbosity=2, exit=False)

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:38:18.399344
# Unit test for function trange
def test_trange():
    for i in trange(10):
        if i >= 3:
            break

# Generated at 2022-06-24 09:38:21.585522
# Unit test for function trange
def test_trange():
    """Test trange"""
    list(trange(10))
    list(trange(10, 0))
    list(trange(10, 0, -1))
    list(trange(0, -10, -1))



# Generated at 2022-06-24 09:38:29.702282
# Unit test for function trange
def test_trange():
    from .std import format_sizeof
    from .std import format_interval
    
    # Test trange works with no arg
    for _ in trange():
        break

    for _ in trange(10):
        break

    # Test trange works with arg min_iters
    for _ in trange(min_iters=10):
        break

    for _ in trange(10, min_iters=10):
        break

    # Test trange works with arg max_iters and min_iters
    n = 10
    max_iters = n*10
    for _ in trange(max_iters=max_iters, min_iters=n):
        break

    # Test trange works with arg miniters
    for _ in trange(10, miniters=5):
        break



# Generated at 2022-06-24 09:38:38.413298
# Unit test for function trange
def test_trange():
    """
    Unit test for `trange` function.
    """
    assert list(trange(10)) == list(range(10))
    # tqdm is instantiated from the function
    assert list(trange(10))[0].__class__.__module__ == __name__

    # with custom tqdm class
    class my_tqdm(tqdm):
        @staticmethod
        def format_metric(n):
            return "{:g} steps".format(n)

    assert list(trange(10, unit="steps"))[0].format_metric(10) == "10 steps"

# Generated at 2022-06-24 09:38:41.363329
# Unit test for function trange
def test_trange():
    from .tests import mock_gui

    try:
        trange(0)
    except ImportError:
        pass
    else:
        raise RuntimeError

# Generated at 2022-06-24 09:38:44.398614
# Unit test for function trange
def test_trange():
    """
    Tests that `trange` is equivalent to `tqdm(range).start()`.
    """
    from .std import tqdm
    assert trange(10) == tqdm(range(10)).start()

# Generated at 2022-06-24 09:38:52.269134
# Unit test for function trange
def test_trange():
    """Test for `tqdm.auto.trange`"""
    from .std import TqdmTypeError, TqdmKeyError
    assert trange(0) == [], "trange(0) should return []"
    assert trange(1) == [0], "trange(1) should return [0]"
    assert trange(0, 10) == [], "trange(0, 10) should return []"
    assert trange(3, 5) == [3, 4], "trange(3, 5) should return [3, 4]"
    assert trange(1, 10, 2) == [1, 3, 5, 7, 9], \
        "trange(1, 10, 2) should return [1, 3, 5, 7, 9]"

# Generated at 2022-06-24 09:39:01.509859
# Unit test for function trange
def test_trange():
    """Test `function trange`"""
    from .tqdm import trange
    from .std import TqdmTypeError

    assert (list(trange(-1)) == [])
    assert (list(trange(0)) == [])
    assert (list(trange(1)) == [0])
    assert (list(trange(2)) == [0, 1])

    assert (list(trange(1, 1, 1)) == [1])
    assert (list(trange(1, 3, 1)) == [1, 2, 3])
    assert (list(trange(3, 1, -1)) == [3, 2, 1])

    # Check that "desc" and "leave" work

# Generated at 2022-06-24 09:39:03.914364
# Unit test for function trange
def test_trange():  # pragma: no cover
    import time
    from .std import trange
    for i in trange(10):
        time.sleep(0.01)

# Generated at 2022-06-24 09:39:04.493873
# Unit test for function trange

# Generated at 2022-06-24 09:39:15.132902
# Unit test for function trange
def test_trange():
    """
    Unit test for `tqdm.auto.trange` function.
    """
    from .std import format_interval, format_meter
    from .utils import format_sizeof
    list(tqdm(range(100), desc='desc', position=10))
    list(tqdm(range(100), desc='desc', position=10, bar_format='{desc}: {n_fmt}/{total_fmt} {bar}'))
    list(trange(100, desc='desc', position=10))
    list(trange(100, desc='desc', position=10, bar_format='{desc}: {n_fmt}/{total_fmt} {bar}'))

# Generated at 2022-06-24 09:39:16.899432
# Unit test for function trange
def test_trange():
    """Test trange"""
    assert list(trange(3)) == [0, 1, 2]


# Generated at 2022-06-24 09:39:22.559483
# Unit test for function trange
def test_trange():
    """Test whether trange works by using it on range(10)."""
    n = 10
    total_ti = 0
    total_td = 0
    for i in trange(n):
        total_ti += i
        total_td += n - i
    assert total_ti == sum(range(n))
    assert total_td == sum(range(n))



# Generated at 2022-06-24 09:39:32.840560
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    # Test for iteration
    for _ in trange(4):
        pass

    # Test for iteration + desc
    for _ in trange(4, desc="test"):
        pass

    # Test for func-call + desc
    for _ in trange(4, desc=lambda _: "test"):
        pass

    # Test for iteration + dynamic_ncols
    for _ in trange(4, dynamic_ncols=True):
        pass

    # Test for iteration with postfix
    for _ in trange(4, postfix={'x': 1}):
        pass

# Generated at 2022-06-24 09:39:42.981466
# Unit test for function trange
def test_trange():
    """Test for `tqdm.auto.trange`"""
    from .std import tqdm as std_tqdm

    assert trange(10) == list(std_tqdm(range(10)))
    assert trange(5, 10) == list(std_tqdm(range(5, 10)))
    assert trange(5, 10, 3) == list(std_tqdm(range(5, 10, 3)))
    assert trange(5, 10, 3, ncols=3) == list(std_tqdm(range(5, 10, 3), ncols=3))

    assert trange(5, 10, desc="foo") == list(
        std_tqdm(range(5, 10), desc="foo")
    )

# Generated at 2022-06-24 09:39:46.437190
# Unit test for function trange
def test_trange():
    from .utils import _range
    from .tests import tests
    assert list(trange(1)) == list(_range(1))
    tests.run_tests()
    for n in [1e1, 1e2, 1e3]:
        assert list(trange(n, disable=None)) == list(_range(n))

# Generated at 2022-06-24 09:39:52.892255
# Unit test for function trange
def test_trange():
    """Test trange()"""
    from .std import _range

    with trange(4) as t:
        for _ in t:
            pass

    assert list(t.__iter__()) == list(_range(4))
    assert [i for i in t] == list(_range(4))
    assert list(t) == list(_range(4))
    with trange(4) as t:
        for i in t:
            assert i in t
            assert i in t.__iter__()
            assert i in _range(4)
            t.update()

    with tqdm(total=None) as t:
        assert t.total is None

    with tqdm(_range(int(1e9))) as t:
        assert t.total == int(1e9)


# Generated at 2022-06-24 09:39:56.315533
# Unit test for function trange
def test_trange():
    """
    Test for trange function
    """
    with tqdm(total=1, unit="it") as pbar:
        for _ in range(10):
            pbar.update()

# Generated at 2022-06-24 09:39:58.763494
# Unit test for function trange
def test_trange():
    """Test trange function"""
    l = list(trange(0, 1000, 1, None, None, 0, None))
    assert l == list(range(0, 1000))

# Generated at 2022-06-24 09:40:03.102541
# Unit test for function trange
def test_trange():
    """Test that trange is callable and returns tqdm instance"""
    assert callable(trange)
    x = trange(5)
    assert not len(x)  # no iterations
    assert isinstance(x, tqdm)
    assert not len(x)  # no iterations
    x.__exit__()


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:40:09.726525
# Unit test for function trange
def test_trange():
    import gc

    # Instance should exist independently of the function
    t = trange(1)
    l = trange(1)
    t.__del__ = lambda: None  # disable automatic garbage collection
    l.__del__ = lambda: None  # disable automatic garbage collection
    gc.collect()
    assert t.n == l.n == 1
    return tqdm, trange



# Generated at 2022-06-24 09:40:11.636115
# Unit test for function trange
def test_trange():
    assert trange(0).__next__() == 0


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 09:40:13.793542
# Unit test for function trange
def test_trange():
    '''Unit test for function trange'''
    with tqdm(total=None) as pbar:
        pbar.update(10)
    with tqdm(total=None, disable=True) as pbar:
        pbar.update(10)

# Generated at 2022-06-24 09:40:18.725081
# Unit test for function trange
def test_trange():
    """
    Tests whether function `trange` works as intended.
    """
    from .autonotebook import trange
    from .gui import tqdm
    from .std import tqdm as std_tqdm
    import pytest

    if std_tqdm == tqdm:
        pytest.skip("Requires tqdm.gui-based tqdm")

    # GUI mode:
    for _ in trange(1, 2):
        pass

    # Notebook mode:
    for _ in trange(1, 2, gui=False):
        pass

    # Normal mode:
    for _ in trange(1, 2, gui=None):
        pass

# Generated at 2022-06-24 09:40:21.998204
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test for function `trange`"""
    for _ in trange(10):
        pass
    trange(10, desc='desc')

# Generated at 2022-06-24 09:40:26.073014
# Unit test for function trange
def test_trange():
    assert list(trange(10)) == list(range(10))

# Generated at 2022-06-24 09:40:34.869806
# Unit test for function trange
def test_trange():
    import time
    from .utils import _term_move_up

    trange(3)
    # GH-103
    try:
        import unicodedata
        unicodedata.lookup('TOP HALF BLOCK')
    except Exception:
        pass
    else:
        for _ in trange(3, desc='desc', leave=False, mininterval=0,
                        bar_format='{desc}: {percentage:3.0f}%|' +
                                   unicodedata.lookup('TOP HALF BLOCK') + '|',
                        postfix='postfix'):
            time.sleep(.1)
        sys.stdout.write(_term_move_up())
        sys.stdout.flush()

# Generated at 2022-06-24 09:40:41.535736
# Unit test for function trange
def test_trange():
    """Test itervalues of `trange`"""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        lists = [
            list(trange(i)) for i in range(1, 4)
        ]
    try:
        from asyncio import get_event_loop
        get_event_loop()  # Should not raise
        for l in lists:
            assert l == list(range(len(l)))
    finally:
        from asyncio import set_event_loop
        set_event_loop(None)  # Reset, so that repeated tests don't fail

# Generated at 2022-06-24 09:40:49.585047
# Unit test for function trange
def test_trange():
    all_types = (int, float, list, range, tuple)  # don't use str
    for t in all_types:
        # list args
        assert isinstance(trange(t(3)), list)
        assert isinstance(list(trange(t(3))), list)
        assert isinstance(list(trange(t(3), 5)), list)
        assert isinstance(list(trange(t(3), -1)), list)
        assert isinstance(list(trange(t(3), 5, 1)), list)
        assert isinstance(list(trange(t(3), -1, -1)), list)
        assert isinstance(list(trange(t(3), 5, 2)), list)
        assert isinstance(list(trange(t(3), -1, -2)), list)

        #

# Generated at 2022-06-24 09:40:58.867058
# Unit test for function trange
def test_trange():
    """Test all variants of trange"""
    with tqdm(total=5) as t:
        t.update()
    with tqdm(total=5) as t:
        t.update()
        t.close()
    with tqdm(total=5) as t:
        t.update()
        t.close()
    with tqdm(1) as t:
        t.update()
        t.close()
    with trange(1) as t:
        t.close()
    with trange(1) as t:
        t.update()
        t.close()
    with tqdm(0) as t:
        t.close()
    with trange(0) as t:
        t.close()
    with trange(1) as t:
        t.update()
       

# Generated at 2022-06-24 09:41:01.255053
# Unit test for function trange
def test_trange():
    from .tqdm import trange

    '''
    for _ in trange(2):
        for _ in trange(5):
            for _ in trange(100):
                pass
    '''

# Generated at 2022-06-24 09:41:11.533243
# Unit test for function trange
def test_trange():
    assert [i for i in trange(0)] == []
    assert [i for i in trange(1, 0)] == []
    assert [i for i in trange(1)] == [0]
    assert [i for i in trange(1, 1)] == [0]
    assert [i for i in trange(1, 2)] == [1]
    assert [i for i in trange(0, 4, 1)] == [0, 1, 2, 3]
    assert [i for i in trange(0, 4, 2)] == [0, 2]
    assert [i for i in trange(0, -4, -1)] == [0, -1, -2, -3]
    assert [i for i in trange(0, -4, -2)] == [0, -2]

# Generated at 2022-06-24 09:41:15.676536
# Unit test for function trange
def test_trange():
    list(trange(100))
    list(tqdm(range(100), desc="trange(100)", disable=None, unit="foo",
              miniters=1, mininterval=0))
    list(notebook_trange(100, leave=True))



# Generated at 2022-06-24 09:41:20.589365
# Unit test for function trange
def test_trange():
    """
    Unit test for function `tqdm.auto.trange`.
    """
    assert next(trange(0)) == 0
    assert next(trange(1)) == 1
    assert next(trange(2, 3)) == 2
    assert next(trange(3, 2)) == 3
    assert list(trange(3, 1, -1)) == [3, 2, 1]
    assert list(trange(3, -1, -1)) == [3, 2, 1, 0]
    assert list(trange(3, -2, -2)) == [3, 1, -1]
    assert list(trange(3, -5, -2)) == [3, 1, -1]

# Generated at 2022-06-24 09:41:31.930255
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    import time
    from .std import TqdmDeprecationWarning

    # make sure we cover all deprecation warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", TqdmDeprecationWarning)
        for _ in range(4):
            for _ in notebook_trange((0, 0), leave=False, disable=False,
                                     desc="disabled"):
                pass
            for _ in notebook_trange((0, 0), leave=True, disable=False,
                                     desc="disabled"):
                pass
            for _ in notebook_trange((0, 0), leave=False, disable=True,
                                     desc="disabled"):
                pass

# Generated at 2022-06-24 09:41:37.156140
# Unit test for function trange
def test_trange():
    for _ in trange(3):
        pass
    for _ in trange(3, desc="desc", unit="u"):
        pass

# Generated at 2022-06-24 09:41:38.654268
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    assert trange(2) == range(2)

# Generated at 2022-06-24 09:41:41.518117
# Unit test for function trange
def test_trange():
    """Test trange"""
    assert list(trange(10)) == list(tqdm(range(10)))

# Generated at 2022-06-24 09:41:46.798367
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Test for function trange"""
    from .std import tqdm
    assert tqdm(range(4), ncols=10) == tqdm(range(4), ncols=10)
    assert trange(4) == tqdm(range(4))
    assert trange(4, ncols=10) == tqdm(range(4), ncols=10)



# Generated at 2022-06-24 09:41:55.099718
# Unit test for function trange
def test_trange():
    """Test function `trange`"""
    from ._tqdm import trange
    from ._utils import _is_manually_wrapped
    from ._tqdm_gui import _matplotlib_hack
    from ._tqdm import main  # for coverage (`python setup.py test`)
    from ._monitor import main as monitor_main  # for coverage
    assert trange(1) == range(1)
    assert trange(1, 1) == range(1, 1)
    assert trange(1, 1, 1) == range(1, 1, 1)
    assert _is_manually_wrapped(tqdm)
    assert _matplotlib_hack(tqdm) == tqdm
    assert main(['tqdm', '-h']) == 0

# Generated at 2022-06-24 09:41:58.787781
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Test trange"""
    from glob import glob
    from os import remove

    inf = float('inf')
    for i in trange(10, 20, 1.0, ncols=90, ascii=True, desc='Trange'):
        assert i in range(10, 20)
    for i in trange(10, 20, 1.0, ncols=90, ascii=True, smooth=True, desc='Trange'):
        assert i in range(10, 20)
    for i in trange(10, 20, 1.0, ncols=90, ascii=True, smooth=True, leave=True, desc='Trange'):
        assert i in range(10, 20)


# Generated at 2022-06-24 09:42:07.562431
# Unit test for function trange
def test_trange():
    """Test trange function"""
    assert ([i for i in trange(3)] == [0, 1, 2])
    assert ([i for i in trange(3, 4)] == [3])
    assert ([i for i in trange(3, 4, 1)] == [3])
    assert ([i for i in trange(3, 3)] == [])
    assert ([i for i in trange(4, 1, -1)] == [4, 3, 2])
    assert ([i for i in trange(4, 1, -2)] == [4, 2])
    assert ([i for i in trange(4, -1, -2)] == [4, 2, 0, -2])

# Generated at 2022-06-24 09:42:10.778165
# Unit test for function trange
def test_trange():
    """Test trange"""
    # pylint: disable=import-error
    from .tests import tqdm_test_data  # NOQA
    tqdm_test_data.data = list(trange(tqdm_test_data.miniters))

# Generated at 2022-06-24 09:42:12.864451
# Unit test for function trange
def test_trange():
    """
    Smoke test
    """
    assert sum(tqdm(list(range(10)), desc="trange", leave=False)) == 9



# Generated at 2022-06-24 09:42:20.415294
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Smoke test trange"""
    from ._utils import _range as range  # NOQA
    with trange(10) as t:
        for _ in range(10):
            _ = t.update()
            _ = t.n
            _ = t.refresh()
            _ = t.total
            _ = t.avg
            _ = t.smoothing
            _ = t.dynamic_ncols
            _ = t.stats
            _ = t.__repr__()
            _ = t.format_dict
            _ = t.postfix
            _ = t.format_meter
            _ = t.__iter__()
            _ = t.write()
            _ = t.get_lock()

            t.set_postfix()
            t.set_postfix

# Generated at 2022-06-24 09:42:25.335929
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .gui import tqdm
    for _ in trange(4):
        for __ in trange(5, desc="nested loop"):
            for ___ in tqdm(range(1000), desc="nested nested loop", leave=False):
                pass

# Generated at 2022-06-24 09:42:29.073584
# Unit test for function trange
def test_trange():
    """Test trange function"""
    tlist = list(trange(10, desc='1st loop', leave=False))
    assert tlist == list(range(10))
    tlist2 = list(trange(5, desc='2nd loop', leave=True))
    assert tlist2 == list(range(5))



# Generated at 2022-06-24 09:42:32.811985
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    list(trange(3, ncols=70))
    list(trange(10, desc="test", ncols=70))
    list(trange(10, postfix={'x': 1, 'y': 2}, ncols=70))

# Generated at 2022-06-24 09:42:37.227917
# Unit test for function trange
def test_trange():
    """
    Tests the trange function of the `tqdm.auto` module
    """
    from .std import TestCase

    # Mocked tqdm function

# Generated at 2022-06-24 09:42:47.802631
# Unit test for function trange
def test_trange():
    """Runs `tqdm.auto.trange(...)` and tests `total` attr."""
    from .utils import _supports_unicode
    from .std import FormatBase
    from .gui import format_meter

    format_meter(100, 100,
                 bar_format=FormatBase()._unicode_prefix_space('{l_bar}{bar}').format(
                     l_bar=FormatBase()._unicode_prefix_space('▏▎▍▌▋▊▉██')[0],
                     bar=FormatBase()._unicode_bar(),
                 ) if _supports_unicode() else '|{bar}|')


# Generated at 2022-06-24 09:42:51.756437
# Unit test for function trange
def test_trange():
    """Test for function trange
    """
    assert trange(10) == list(range(10))
    assert trange(1, 10, 2) == list(range(1, 10, 2))
    assert trange(10, 1, -2) == list(range(10, 1, -2))

# Generated at 2022-06-24 09:42:58.057563
# Unit test for function trange
def test_trange():
    # pylint: disable=undefined-variable
    assert list(trange(5)) == list(range(5))
    assert list(trange(1, 3)) == list(range(1, 3))
    assert list(trange(1, 5, 2)) == list(range(1, 5, 2))


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:43:08.538981
# Unit test for function trange
def test_trange():
    """Test for the trange function (for multiple Python versions)"""
    from .std import tqdm, trange
    assert tqdm.format_interval(0.0) == '0s'

    # Keyword argument only used in `tqdm(xrange(), ...)`
    for _t in [tqdm, trange]:
        assert list(_t(10, mininterval=0.01, miniters=0)) == list(range(10))

    # Duration-controlled loop with small miniters
    for _t in [tqdm, trange]:
        assert list(_t(9.1, mininterval=0.2)) == list(range(9))

    # Test initial position

# Generated at 2022-06-24 09:43:10.367139
# Unit test for function trange
def test_trange():
    """
    >>> test_trange()
    """
    assert list(trange(2)) == [0, 1]



# Generated at 2022-06-24 09:43:15.797157
# Unit test for function trange
def test_trange():
    """Test function trange"""
    # tqdm.trange is imported from tqdm/auto.py
    from tqdm.auto import trange
    from time import sleep

    for _ in trange(4):
        sleep(0.2)

if __name__ == "__main__":
    # Test
    test_trange()

# Generated at 2022-06-24 09:43:22.855079
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from ._utils import _range

    # Test special case
    with trange(0) as t:
        assert len(list(t)) == 0

    with trange(3) as t:
        assert len(list(t)) == 3

        t.set_postfix_str("test")
        t.update()

        for i in _range(1, 3):
            t.update()

    for _ in trange(10, 0, -1):
        pass


# Unit tests for module `tqdm.auto`
from ._utils import _test_environment, _test_gui


# Gui tests

# Generated at 2022-06-24 09:43:32.728845
# Unit test for function trange
def test_trange():
    """
    Unit test for trange().
    """
    from ._utils import _supports_unicode  # pylint: disable=import-outside-toplevel
    from .std import tqdm  # pylint: disable=import-outside-toplevel

    for i in trange(10, ascii=1 - _supports_unicode, desc="Test trange",
                    mininterval=0.01):
        1 / i

        assert tqdm._decode_unicode() == tqdm._decode_unicode()
        # using tqdm.__class__ to bypass magic __getattribute__
        tqdm.__class__._instances.clear()  # pylint: disable=no-member



# Generated at 2022-06-24 09:43:37.509359
# Unit test for function trange
def test_trange():
    """
    Tests `tqdm` module.
    """
    import sys
    import time

    # Initialise
    with trange(100) as t:
        assert len(t) == 100

        # Iterate
        for i in t:
            time.sleep(0.01)
            t.set_description("test_trange: " + str(i))
            assert t.n == i + 1
            assert isinstance(repr(t), str)

            if i == 50:
                t.total = t.n = 5
                t.refresh()

            if i == 80:
                t.n = 75
                t.refresh()

        # Finalise
        assert t.n == 100
        t.close()

    # Test `with` and `__enter__`/`__exit__`

# Generated at 2022-06-24 09:43:45.414797
# Unit test for function trange
def test_trange():
    """Test for `trange`"""
    from .gui import tqdm as gui_tqdm

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        from .autonotebook import tqdm as notebook_tqdm

    for t in (tqdm, trange,
              notebook_tqdm, notebook_trange,
              gui_tqdm):
        list(t(range(10)))
        list(t(range(10), desc="A"))
        list(t(range(10), "B"))


#
# Detect running tests
#

# Generated at 2022-06-24 09:43:53.261440
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from .std import Total
    from .utils import format_sizeof

    assert trange(5) == range(5)
    assert list(trange(5)) == list(range(5))
    assert list(trange(5, 0)) == list(range(5, 0))
    assert list(trange(5, 0, -1)) == list(range(5, 0, -1))

    with tqdm(trange(12345, 0, -1), total=12345) as t:
        assert isinstance(t.total, Total)
        assert t.total.n == 12345
        t.set_description("Testing")
        t.set_postfix(time="123ms")

# Generated at 2022-06-24 09:44:01.593492
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .asyncio import tqdm as asyncio_tqdm
    assert tqdm.__bases__ == (notebook_tqdm, asyncio_tqdm)

    for method in ["set_description", "_instances"]:
        assert notebook_tqdm.__dict__[method] == tqdm.__dict__[method]
    for method in ["_instances"]:
        assert asyncio_tqdm.__dict__[method] == tqdm.__dict__[method]

    assert trange.__module__ == tqdm.__module__

# Generated at 2022-06-24 09:44:11.268679
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .std import format_sizeof, format_interval
    from .utils import _term_move_up
    with tqdm(total=10 ** 2, unit="B", unit_scale=True) as pbar:
        for _ in trange(10 ** 2, unit="B", unit_scale=True):
            pbar.update()
    with tqdm(total=10 ** 3, unit="B", unit_scale=True) as pbar:
        pbar.update(sum(pbar.update(i * 100) for i in trange(10)))
    with tqdm(total=10 ** 3, unit="B", unit_scale=True) as pbar:
        for i in trange(10):
            pbar.update(i * 100)

# Generated at 2022-06-24 09:44:17.969117
# Unit test for function trange
def test_trange():
    """
    Unit tests for function trange
    """
    # check that trange is a function
    assert callable(trange)

    # check that trange is a range with a progress bar
    list(trange(2))
    # can be customized
    list(trange(2, desc='desc', leave=True))
    list(trange(2, desc='desc', position=0))

# Generated at 2022-06-24 09:44:25.344730
# Unit test for function trange
def test_trange():
    """
    Unit test using a subprocess to ensure that we do not inherit or
    interfere with any other tqdm instance, e.g. in an interactive
    console.
    """
    import subprocess
    import os

    FNULL = open(os.devnull, 'w')
    # trange 2-6
    assert subprocess.call([sys.executable, __file__, '2', '6'],
                           stdout=FNULL, stderr=subprocess.STDOUT) == 0
    # trange 2-6 (leave=False)
    assert subprocess.call([sys.executable, __file__, '2', '6', '--leave_false'],
                           stdout=FNULL, stderr=subprocess.STDOUT) == 0
    # trange 2-6 (leave=True)
    assert sub

# Generated at 2022-06-24 09:44:34.024755
# Unit test for function trange
def test_trange():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch.object(tqdm, "__call__") as mock_tqdm:
        trange(10)
    assert mock_tqdm.call_args[0][0] == range(10)

    with patch.object(tqdm, "__call__") as mock_tqdm_2:
        trange(0, 20, 2)
    assert mock_tqdm_2.call_args[0][0] == range(0, 20, 2)
    assert mock_tqdm_2.call_args[1] == {}

# Generated at 2022-06-24 09:44:36.273072
# Unit test for function trange
def test_trange():
    assert test_tqdm_tupletuple((i, j) for i in trange(1) for j in trange(1)) == [(0, 0)]



# Generated at 2022-06-24 09:44:39.854134
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange

    Usage:
    >>> test_trange()
    """
    assert list(trange(5, 0, -1)) == list(range(5, 0, -1))

# Generated at 2022-06-24 09:44:48.761340
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from copy import copy
    from .std import tqdm

    for n in (0, 1):
        for total in (None, 10):
            tkwargs = dict(total=total)
            list(trange(n, **tkwargs))
            t = tqdm(n, **copy(tkwargs))
            list(t)

    t = trange(0)
    assert type(t) == tqdm
    t = trange(1)
    assert type(t) == tqdm
    t = trange(1, leave=True)
    assert type(t) == tqdm
    assert t.n == 1
    t = trange(2, smooth=0)
    assert type(t) == tqdm
    t = trange

# Generated at 2022-06-24 09:44:53.557040
# Unit test for function trange
def test_trange():  # pragma: no cover
    import sys
    from tqdm.auto import trange

    for i in trange(5, ascii=True, desc="test", file=sys.stdout):
        pass
    for i in trange(10, desc="test2", file=sys.stdout):
        for j in trange(10, desc="test3", file=sys.stdout):
            pass
        for j in trange(5, desc="test4", file=sys.stdout):
            pass


if __name__ == "__main__":  # pragma: no cover
    test_trange()

# Generated at 2022-06-24 09:45:01.180326
# Unit test for function trange
def test_trange():
    import time
    from .utils import FormatCustomTextTest

    for _ in trange(
        2,
        bar_format="{l_bar}{bar}|",
        ascii=True, desc="x",
        postfix=["postfix"],
        unit="i", unit_scale=True,
    ):
        time.sleep(0.1)

    for _ in trange(
        3,
        bar_format="{l_bar}{bar}|",
        leave=True, dynamic_ncols=True,
        ascii=True, desc="y",
        postfix=["postfix"],
        unit="i", unit_scale=True,
    ):
        time.sleep(0.1)


# Generated at 2022-06-24 09:45:06.772981
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    for _ in trange(10):
        pass
    for _ in trange(10, 0):
        pass
    for _ in trange(10, 5):
        pass
    for _ in trange(10, 5, -1):
        pass
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        for _ in trange(10, desc="desc"):
            pass
        for _ in trange(10, 0, desc="desc"):
            pass
        for _ in trange(10, 5, desc="desc"):
            pass
        for _ in trange(10, 5, -1, desc="desc"):
            pass

# Generated at 2022-06-24 09:45:11.830488
# Unit test for function trange
def test_trange():
    """
    Test of `trange` function
    """
    from .std import _range  # pylint: disable=no-name-in-module
    from .std import _repr  # pylint: disable=no-name-in-module
    from .std import _enumerate_repr  # pylint: disable=no-name-in-module
    t_r = trange(1, 5, 2)  # pylint: disable=unused-variable
    t_r = trange(5)  # pylint: disable=unused-variable
    t_repr = repr(t_r)  # pylint: disable=unused-variable
    r = _repr(t_r, 5, 3)  # pylint: disable=unused-variable
    r = _repr

# Generated at 2022-06-24 09:45:22.162937
# Unit test for function trange
def test_trange():
    """
    Tests the features of tqdm.auto.trange
    """

    try:
        from io import StringIO  # Python3
    except ImportError:
        from StringIO import StringIO  # Python2

    # Does nothing but doesn't raise an exception
    trange(0)  # pylint: disable=E1120

    # Iterable of integers
    out = StringIO()
    for i in trange(10, file=out):
        assert i is None
    assert out.getvalue() == '10it [00:00, ?it/s]\n'  # pylint: disable=E1101

    # Iterable of integers
    out = StringIO()
    for i in trange(10, file=out):
        assert i is None

# Generated at 2022-06-24 09:45:27.915314
# Unit test for function trange
def test_trange():
    """
    Tests `tqdm.auto.trange` function
    """
    from .utils import _version2int
    tr = trange(0, 5, 0.0001, desc='', leave=True,
                unit_scale=True, unit='')
    if _version2int(sys.version) >= _version2int('3.3.0'):
        it = iter(tr)
        for i in range(1, 11):
            assert next(it) == i * 0.1
    tr.close()

# Generated at 2022-06-24 09:45:31.206440
# Unit test for function trange
def test_trange():
    """Test function for function trange"""
    from sys import _getframe
    trange(23)
    trange(5).__enter__().__exit__(None, None, _getframe())
    if hasattr(tqdm, "get_lock"):
        trange(5, lock=tqdm.get_lock())

# Generated at 2022-06-24 09:45:33.070293
# Unit test for function trange
def test_trange():
    for i in trange(10):
        assert i < 10

# Generated at 2022-06-24 09:45:38.971125
# Unit test for function trange
def test_trange():
    """Test function trange"""
    # pylint: disable=missing-docstring
    for _ in tqdm(trange(10)):
        pass
    for _ in tqdm(trange(10), ncols=0):
        pass
    for _ in tqdm(trange(10), desc="desc"):
        pass



# Generated at 2022-06-24 09:45:40.182474
# Unit test for function trange
def test_trange():
    for _ in trange(5, desc='test'):
        pass

# Generated at 2022-06-24 09:45:48.575690
# Unit test for function trange
def test_trange():
    """
    Unit test for `tqdm.auto.trange`.
    """
    import sys
    if sys.version_info >= (3, 6):
        from .asyncio import trange as asyncio_trange
        assert trange is asyncio_trange
    else:
        from .autonotebook import trange as autonotebook_trange
        assert trange is autonotebook_trange