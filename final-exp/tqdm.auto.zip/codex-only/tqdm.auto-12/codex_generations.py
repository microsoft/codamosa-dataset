

# Generated at 2022-06-24 09:35:37.872423
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    list(trange(10))

# Generated at 2022-06-24 09:35:39.183061
# Unit test for function trange
def test_trange():
    """ Test function trange """
    assert list(trange(1)) == [0]
    assert list(trange(2)) == [0, 1]

# Generated at 2022-06-24 09:35:44.471581
# Unit test for function trange
def test_trange():
    """Test function trange()"""
    from .std import tqdm
    assert tqdm(range(10)) == trange(10)
    assert tqdm(range(10), position=0) == trange(10, position=0)
    assert tqdm(range(10), position=0, leave=False) == \
        trange(10, position=0, leave=False)
    assert tqdm(range(10), desc='desc') == trange(10, desc="desc")
    assert tqdm(range(10), desc='desc', leave=False) == \
        trange(10, desc='desc', leave=False)

# Generated at 2022-06-24 09:35:45.884661
# Unit test for function trange
def test_trange():
    """Test for function trange."""
    for _ in trange(4):
        pass

# Generated at 2022-06-24 09:35:56.785872
# Unit test for function trange
def test_trange():
    """
    Test for the trange() function
    """
    # Check for the absence of duplicated values,
    # when trange() is called with the same arguments a few times.
    # Due to the fact that Python 2.x range() object is not iterable,
    # we'll use list() to test it.
    assert list(trange(3)) != list(trange(3)), \
        "trange() returned duplicated values!"
    assert list(trange(3, 7)) != list(trange(3, 7)), \
        "trange() returned duplicated values!"
    assert list(trange(3, 7, 2)) != list(trange(3, 7, 2)), \
        "trange() returned duplicated values!"

    # Check that trange() works exactly like range()

# Generated at 2022-06-24 09:36:00.735823
# Unit test for function trange
def test_trange():
    """Test for trange()"""
    assert list(trange(10)) == list(range(10))
    assert list(trange(10)) == list(tqdm(range(10)))

# Generated at 2022-06-24 09:36:03.500658
# Unit test for function trange
def test_trange():
    """Test trange"""
    assert list(trange(5)) == list(range(5))
    assert list(trange(0)) == list(range(0))

# Generated at 2022-06-24 09:36:04.877725
# Unit test for function trange
def test_trange():
    """ Test trange """
    list(trange(2))


# Generated at 2022-06-24 09:36:06.976922
# Unit test for function trange
def test_trange():
    """Test trange"""
    assert list(trange(5, 10)) == list(range(5, 10))



# Generated at 2022-06-24 09:36:10.544331
# Unit test for function trange
def test_trange():
    from .std import tqdm as std_tqdm

    assert trange(5) == tqdm(range(5)) == std_tqdm(range(5))

# End of file tqdm/auto.py

# Generated at 2022-06-24 09:36:19.734561
# Unit test for function trange
def test_trange():
    """Remains to be documented"""
    from .std import FormatWarning, TqdmExperimentalWarning, TqdmDeprecationWarning

    for i in trange(4):
        pass
    for i in trange(4, desc="a"):
        pass

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")

        for i in trange(4, desc="a", dynamic_ncols=True):
            pass
        assert w == []

        for i in trange(4, desc="a", ncols=120):
            pass
        assert w == []

        with tqdm(total=10, file=sys.stdout, leave=False) as t:
            assert t.is_hidden
        assert w == []


# Generated at 2022-06-24 09:36:29.072727
# Unit test for function trange
def test_trange():
    """
    Unit test for function `trange`.
    """
    # Check trange()
    assert [i for i in trange(9)] == list(range(9))
    assert [i for i in trange(9, step=2)] == list(range(9))[::2]
    assert [i for i in trange(1, 10, 2)] == list(range(1, 10, 2))

    # Check trange(...) fails with descending step
    try:
        trange(10, -1, -1)
    except ValueError:
        pass
    else:
        assert False, "Negative step must fail"

    # Check trange(...) fails with step = 0
    try:
        trange(10, 1, 0)
    except ValueError:
        pass

# Generated at 2022-06-24 09:36:38.062788
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from shutil import get_terminal_size
    # pylint: disable=protected-access
    width, _ = get_terminal_size()
    assert len(str(trange(1))) == len(str(tqdm(range(1))))
    assert len(str(trange(1, 2))) == len(str(tqdm(range(1, 2))))
    assert len(str(trange(1, 2, 3))) == len(str(tqdm(range(1, 2, 3))))
    assert len(str(trange(100, 300, 100))) == len(
        str(tqdm(range(100, 300, 100))))

# Generated at 2022-06-24 09:36:41.653648
# Unit test for function trange
def test_trange():
    assert list(trange(10)) == list(range(10))
    assert list(trange(0)) == list(range(0))


if __name__ == "__main__":
    from .tests import test_auto as _test_auto

    _test_auto()

# Generated at 2022-06-24 09:36:50.877304
# Unit test for function trange
def test_trange():
    from .std import trange

    # Should accept same arguments as range
    for start in (0, 3):
        for stop in (3, 4):
            for step in (1, 2):
                trange(start, stop, step)
    trange(0)
    trange(0, 0)
    trange(2, 3, 0)
    trange(3, 4, -1)

    # Should accept same kwargs as tqdm
    trange(3, total=4)

    # Should work as expected
    assert [i for i in trange(4)] == [0, 1, 2, 3]
    assert [i for i in trange(2, 4)] == [2, 3]
    assert [i for i in trange(2, 4, 2)] == [2]

# Generated at 2022-06-24 09:36:53.373576
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .autonotebook import trange
    with trange(9) as t:
        for i in t:
            if i == 3:
                t.set_description('Testing %i' % i)
                break

# Generated at 2022-06-24 09:36:59.117470
# Unit test for function trange
def test_trange():
    """Tests trange function of tqdm.auto."""
    # pylint: disable=unused-variable
    # pylint: disable=comparison-with-callable
    from .std import tqdm as std_tqdm

    # Test trange has the same signature as std.tqdm
    assert trange.__code__.co_argcount \
        == std_tqdm.__code__.co_argcount
    assert trange.__code__.co_varnames \
        == std_tqdm.__code__.co_varnames
    # Test notebook trange == std.tqdm
    assert notebook_trange.__code__.co_argcount \
        == std_tqdm.__code__.co_argcount

# Generated at 2022-06-24 09:37:09.722250
# Unit test for function trange
def test_trange():
    """
    Simple unit test for trange

    Usage:
    python -m tqdm.auto test_trange
    """
    from .autonotebook import trange as notebook_trange
    from .asyncio import tqdm as asyncio_tqdm
    from .std import tqdm as std_tqdm

    if notebook_trange != std_tqdm:
        class tqdm(notebook_trange, asyncio_tqdm):  # pylint: disable=inconsistent-mro
            pass
    else:
        tqdm = asyncio_tqdm

    assert list(tqdm(range(10))) == list(range(10))


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 09:37:15.413934
# Unit test for function trange
def test_trange():
    """Test function `trange`"""
    tqdm_cls = tqdm.__class__
    try:
        tqdm.__class__ = type("TypicalTqdm", tqdm.__bases__, dict(tqdm.__dict__))
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            trange(3)
    finally:
        tqdm.__class__ = tqdm_cls

# Generated at 2022-06-24 09:37:18.471472
# Unit test for function trange
def test_trange():
    """Test trange(...)."""
    trange(1)
    trange(10)
    trange(1, 1)
    trange(1, 0)
    trange(0, 1, 1)
    trange(0, 1, -1)
    trange(0, 10, 1)
    trange(10, 0, -1)
    trange(10, 0, -2)
    trange(10, 0, -1.1)



# Generated at 2022-06-24 09:37:26.771328
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .asyncio import tqdm as tqdm_asyncio
    from .autonotebook import tqdm as tqdm_notebook
    assert (  # pylint: disable=protected-access
        trange(0, 0, 1) is tqdm_asyncio._instances.get(id(trange(0, 0, 1)))
        or trange(0, 0, 1) is tqdm_notebook._instances.get(
            id(trange(0, 0, 1))
        )
    )

# Generated at 2022-06-24 09:37:33.261872
# Unit test for function trange
def test_trange():
    """
    Tests that trange is equivalent to tqdm(range(...)).
    """
    assert list(trange(5)) == list(range(5))
    assert list(trange(5, 0, -1)) == list(range(5, 0, -1))
    assert list(trange(5, 0)) == list(range(5, 0))
    assert list(trange(0)) == list(range(0))

# Generated at 2022-06-24 09:37:36.008952
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .trange import trange
    from time import sleep

    rng = trange(0, 10, desc='Test trange', leave=False)

    for _ in rng:
        sleep(.01)

# Generated at 2022-06-24 09:37:41.101932
# Unit test for function trange
def test_trange():
    """
    Test trange() with no kwargs
    """
    from os import get_terminal_size
    from .std import tqdm

    term_width = get_terminal_size().columns
    for i in trange(10, unit="custom"):
        pass
    assert len(tqdm(total=1)._instances) == 1

    for j in trange(10, desc="foo", unit="custom"):
        pass
    assert len(tqdm(total=1)._instances) == 2
    assert term_width == get_terminal_size().columns

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:37:52.645102
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    Unit test for function trange.
    """
    with tqdm(total=10) as pbar:
        assert pbar.total == 10, pbar.total
        pbar.update()
        assert pbar.n == 1, pbar.n
        pbar.update(9)
        assert pbar.n == 10, pbar.n

        if hasattr(pbar, "get_lock"):
            import threading
            lock = pbar.get_lock()

            def job1(lock):
                for _ in trange(9):
                    lock.acquire()
                    pbar.update(1)
                    lock.release()

            def job2(lock):
                for _ in trange(9):
                    lock.acquire()
                    pbar.update(1)

# Generated at 2022-06-24 09:37:54.130344
# Unit test for function trange
def test_trange():
    for _ in trange(4):
        pass

# Generated at 2022-06-24 09:37:55.740869
# Unit test for function trange
def test_trange():
    """Test function `trange`"""
    assert list(trange(5)) == list(range(5))

# Generated at 2022-06-24 09:38:06.536867
# Unit test for function trange
def test_trange():
    """Test function trange."""
    from .utils import _range
    from .std import format_interval, format_sizeof

    # pylint: disable=star-args,no-value-for-parameter
    for i in trange(0, 10, desc='Testing `trange()`', mininterval=0):
        assert i in _range(0, 10)
        assert 'Testing `trange()`' in format_interval(0)
    for i in trange(10, desc='Testing `trange()`', mininterval=0):
        assert i in _range(10)
        assert 'Testing `trange()`' in format_sizeof(10)
    # pylint: enable=star-args,no-value-for-parameter

# Generated at 2022-06-24 09:38:08.873952
# Unit test for function trange
def test_trange():  # pragma: no cover
    import inspect
    assert inspect.getsource(trange) == inspect.getsource(tqdm)

# Generated at 2022-06-24 09:38:16.962376
# Unit test for function trange
def test_trange():
    """Test trange()"""
    from .gui import tqdm_gui
    from .utils import format_sizeof
    from .std import format_interval, format_meter, format_number
    from .utils import _term_move_up

    with tqdm_gui(desc='trange', unit='it',
                  unit_scale=True, unit_divisor=1024) as bar:
        for i in trange(8, desc='1st loop', leave=False,
                        smoothing=1, total=20, position=0):
            assert bar.last_print_n == bar.n - bar.last_print_n
            assert i == bar.last_print_n
            for j in trange(6, desc='2nd loop', total=4, leave=True,
                            position=1):
                assert j

# Generated at 2022-06-24 09:38:20.232695
# Unit test for function trange
def test_trange():
    # Test without any optional argument
    assert trange(1)

    # Test with positional optional argument
    assert trange(1, 10)

    # Test with keyword optional argument
    assert trange(1, total=10)

# Generated at 2022-06-24 09:38:28.865112
# Unit test for function trange
def test_trange():
    """Test function to test the function trange"""

    test_total = 100
    test_pos = 12
    test_desc = 'Test trange'
    test_smoothing = 0.001
    test_leave = True
    test_mininterval = 0.01

    test_list = list(range(test_total))
    foo = trange(test_total,
                 desc=test_desc,
                 position=test_pos,
                 leave=test_leave,
                 mininterval=test_mininterval,
                 smoothing=test_smoothing,
                 )

    if not foo.total == test_total:
        raise AssertionError(
            "{} != {}".format(foo.total, test_total)
        )

    if not foo.desc == test_desc:
        raise AssertionError

# Generated at 2022-06-24 09:38:32.595710
# Unit test for function trange
def test_trange():
    """Test for issue #195"""
    for _ in trange(1):
        pass


if __name__ == "__main__":
    from _tqdm import _main  # pylint: disable=no-name-in-module
    _main()

# Generated at 2022-06-24 09:38:35.844259
# Unit test for function trange
def test_trange():
    """Tests that trange() works as expected"""
    with tqdm(total=3) as tr:
        tr.update()



# Generated at 2022-06-24 09:38:38.575583
# Unit test for function trange
def test_trange():
    """ Test: trange() """
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        list(trange(3))


# Generated at 2022-06-24 09:38:48.899746
# Unit test for function trange
def test_trange():
    """Test trange()"""
    # callable
    list(trange(3))
    # no args
    list(trange())
    # positional args
    list(trange(3, 4))
    list(trange(3, 4, 1))
    # keywords
    list(trange(start=3))
    list(trange(start=3, stop=4))
    list(trange(start=3, stop=4, step=1))
    # bar_format
    list(trange(3, bar_format='{l_bar}'))
    # unit
    list(trange(3, unit='i'))
    # total
    list(trange(3, total=4))
    # should not raise when no enumerable given
    list(trange(0))
    list(trange())

# Generated at 2022-06-24 09:38:51.834661
# Unit test for function trange
def test_trange():
    ''' Test for function trange '''

    for _ in trange(100):
        pass

    assert True

# Generated at 2022-06-24 09:38:53.895755
# Unit test for function trange
def test_trange():
    """Testing trange"""
    from ._tqdm import trange
    assert trange(1, 3) == [1, 2]

# Generated at 2022-06-24 09:38:57.317448
# Unit test for function trange
def test_trange():
    """Test for trange."""
    from .std import tqdm
    for trange_ in [trange, tqdm.trange]:
        assert [i for i in trange_(10)] == list(range(10))



# Generated at 2022-06-24 09:39:02.070320
# Unit test for function trange
def test_trange():
    """
    Tests the generation of trange.
    """
    lst = list(trange(5, 1))
    assert lst == list(range(5, 1))
    lst = list(trange(5, 1, -1))
    assert lst == list(range(5, 0, -1))
    lst = list(trange(5, 1, -2))
    assert lst == list(range(5, 0, -2))

# Generated at 2022-06-24 09:39:07.835529
# Unit test for function trange
def test_trange():
    for i in trange(3, desc="foo"):
        assert i in [0, 1, 2]
    assert sys.stderr.read() == "foo:   0%|          | 0/3 [00:00<?, ?it/s]foo: 100%|##########| 3/3 [00:00<00:00, ?it/s]\n"

# Generated at 2022-06-24 09:39:13.392051
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    from .std import tqdm, trange
    for _ in trange(10):
        pass
    with tqdm(total=10) as pbar:
        for _ in trange(10):
            pbar.update()

if __name__ == "__main__":  # pragma: no cover
    test_trange()

# Generated at 2022-06-24 09:39:17.788852
# Unit test for function trange
def test_trange():
    """Test that trange is working"""
    list(trange(10))
    list(trange(1, 10))
    list(trange(1, 10, 1))
    list(trange(1, 10, 0))
    list(trange(10))
    list(trange())

# Generated at 2022-06-24 09:39:21.284977
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    Unit test for function trange.
    """
    from .std import tqdm

    assert len(list(tqdm(trange(10)))) == 10
    return


# Generated at 2022-06-24 09:39:28.506777
# Unit test for function trange

# Generated at 2022-06-24 09:39:36.939748
# Unit test for function trange
def test_trange():
    # Test for tqdm(range(*args))
    assert list(trange(4)) == list(tqdm(range(4)))
    assert list(trange(4, 0)) == list(tqdm(range(4, 0)))
    assert list(trange(0)) == list(tqdm(range(0)))
    assert list(trange(0, 4)) == list(tqdm(range(0, 4)))
    assert list(trange(0, 4, -1)) == list(tqdm(range(0, 4, -1)))
    assert list(trange(0, -4, -1)) == list(tqdm(range(0, -4, -1)))
    # Test for tqdm(range(*args), **kwargs)
    assert list(trange(4, leave=True))

# Generated at 2022-06-24 09:39:41.047165
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from tqdm.auto import trange
    assert trange(5)
    assert not trange(0)
    assert trange(2, 6)
    assert trange(2, 10, 2)
    assert trange(10, 2, -2)
    assert not trange(10, 2)
    assert trange(20, 1, -2)
    assert not trange(20, 1)



# Generated at 2022-06-24 09:39:49.345828
# Unit test for function trange
def test_trange():
    """Test function trange()"""
    # test with different desc= and leave=
    assert [i for i in trange(10, desc="desc", leave=False)] == list(range(10))
    assert [i for i in trange(10, desc="desc", leave=True)] == list(range(10))
    assert [i for i in trange(10, desc="", leave=False)] == list(range(10))
    assert [i for i in trange(10, desc="", leave=True)] == list(range(10))
    assert [i for i in trange(10)] == list(range(10))
    assert [i for i in trange(10, desc="")] == list(range(10))

    # test with different position=

# Generated at 2022-06-24 09:40:00.525464
# Unit test for function trange
def test_trange():
    """Test `tqdm.auto.trange`"""
    from .std import _range
    from .utils import format_sizeof

    mem = format_sizeof(100000)  # about 100kB

    # pylint: disable=protected-access
    # trange
    assert __name__ in repr(trange(10))
    assert _range(10) == list(trange(10))

    # trange (mininterval)
    with tqdm(total=10, mininterval=1, miniters=9) as pbar:  # 0its [00:00, ?it/s]
        pbar.update()  # 1it [00:00, ?it/s]
        assert '00:01<' in pbar.__repr__()
        pbar.update(9)  # 10it

# Generated at 2022-06-24 09:40:05.518041
# Unit test for function trange
def test_trange():
    # Test if trange is a function
    if trange is None:
        raise ImportError()
    # Test if trange does what it should
    for _ in trange(5, desc='Trange'):
        pass


# Test if trange() raises an exception
if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 09:40:09.384037
# Unit test for function trange
def test_trange():
    assert list(trange(5)) == list(range(5))
    assert list(trange(1, 6)) == list(range(1, 6))
    assert list(trange(1, 10, 2)) == list(range(1, 10, 2))

# Generated at 2022-06-24 09:40:14.556342
# Unit test for function trange
def test_trange():
    """ Unit test for function trange """
    assert list(trange(3)) == [0, 1, 2]
    assert list(trange(3, 1)) == []
    assert list(trange(3, 3)) == [2, 1, 0]
    assert list(trange(3, -1)) == [2, 1, 0]
    assert list(trange(-3, -1)) == [0, -1, -2]
    assert list(trange(0, 3, 2)) == [0, 2]



# Generated at 2022-06-24 09:40:16.187179
# Unit test for function trange
def test_trange():
    assert [str(i) for i in tqdm(range(5))] == [str(i) for i in trange(5)]

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:40:19.863715
# Unit test for function trange
def test_trange():
    """
    Simple test for function trange.
    """
    for n in (1, 10, 100):
        assert list(trange(n)) == list(range(n))

# Generated at 2022-06-24 09:40:30.389696
# Unit test for function trange
def test_trange():
    "Test function trange"
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    # Test 1: Test trange()
    with patch.object(sys, "argv", []):
        trange(3)

    # Test 2: Test trange(iterable)
    with patch.object(sys, "argv", []):
        trange(range(3))

    # Test 3: Test trange() with iterable keyword argument
    with patch.object(sys, "argv", []):
        trange(iterable=range(3))

    # Test 4: Test trange() with non iterable argument and keyword argument

# Generated at 2022-06-24 09:40:38.395338
# Unit test for function trange
def test_trange():
    assert list(trange(0)) == []
    assert list(trange(1, 0, -1)) == []
    assert list(trange(500, 510, 1)) == [500, 501, 502, 503, 504, 505, 506,
                                         507, 508, 509]
    assert list(trange(510, 500, -1)) == [510, 509, 508, 507, 506, 505, 504,
                                          503, 502, 501]

# Generated at 2022-06-24 09:40:43.818288
# Unit test for function trange
def test_trange():
    """Tests ``tqdm.auto.trange()``"""
    with tqdm(total=10) as pbar:
        for i in trange(4, 6):
            pbar.update()
    for i in trange(4, 6):
        pass

# Generated at 2022-06-24 09:40:45.096861
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    trange(3, 1)

# Generated at 2022-06-24 09:40:52.805450
# Unit test for function trange
def test_trange():  # pragma: no cover
    from threading import Thread
    from time import sleep

    # Test trange with:
    # - no optional args
    # - with all optional args (with manual refresh)
    trange(10)
    kwargs = {"desc": "desc", "total": 10, "leave": True, "unit": "u",
              "postfix": {"postfix": 1}, "ascii": True, "miniters": 2,
              "maxinterval": 0.5, "mininterval": 0.1, "smoothing": 0.1, "bar_format": "{desc}"}
    with tqdm(**kwargs) as t:
        for x in t:
            sleep(0.01)
            t.set_postfix(postfix=x)
            t.update()
        assert t

# Generated at 2022-06-24 09:40:56.890652
# Unit test for function trange
def test_trange():
    """Test function trange."""
    from .std import trange
    with trange(1) as t:
        assert next(t) == 0
    with trange(10, 1, -1) as t:
        assert list(t) == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]

# Generated at 2022-06-24 09:41:00.880320
# Unit test for function trange
def test_trange():
    from .std import _range

    for i in trange(_range(0, sys.maxsize, 1)):
        assert i
        if i >= 3:
            break

    for i in trange(_range(5, sys.maxsize, 1)):
        assert i
        if i >= 5:
            break


# Generated at 2022-06-24 09:41:04.362896
# Unit test for function trange
def test_trange():
    """Test of trange"""
    assert list(trange(0)) == []
    assert list(trange(1)) == [0]
    assert list(trange(2)) == [0, 1]

# Generated at 2022-06-24 09:41:06.537588
# Unit test for function trange
def test_trange():
    trange(1, 9, 0.3)
    trange(1, 9, 0.3, ascii=True)



# Generated at 2022-06-24 09:41:07.341914
# Unit test for function trange
def test_trange():
    for _ in trange(10):
        pass

# Generated at 2022-06-24 09:41:10.433379
# Unit test for function trange
def test_trange():
    from .utils import _range
    assert list(trange(5)) == list(_range(5))
    assert list(trange(int(1e9))) == list(_range(int(1e9)))

# Generated at 2022-06-24 09:41:20.303398
# Unit test for function trange
def test_trange():
    import sys
    import time

    if sys.version_info[:2] >= (3, 6):
        from .asyncio import _trange  # asyncio-based trange
    else:
        from .std import _trange  # std-based trange

    for t in [None, [], [0, 0]]:  # Note: [] != [0] in std._trange
        for _ in _trange(t, leave=False):
            pass
        for _ in _trange(t, leave=True):
            pass
        assert not t, t

    for i in trange(3):
        assert i in range(3)
        assert i in [0, 1, 2]
        time.sleep(.1)

    t0 = time.time()

# Generated at 2022-06-24 09:41:25.657518
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange

    Output example:
    python3 -m tqdm.auto.trange
    10it [00:00, 55427.72it/s]
    """
    tr = trange(10)
    for _ in tr:
        pass

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:41:32.862555
# Unit test for function trange
def test_trange():
    """
    Simple unit test for function trange
    """
    list(trange(3))
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        with open("/dev/null", "wb") as null_file:
            list(trange(3, file=null_file))
    list(trange(3, desc="A"))
    list(trange(3, unit="B"))
    list(trange(3, unit_scale=True))
    list(trange(3, ascii=True))
    list(trange(3, mininterval=0.1))
    list(trange(3, miniters=2))
    list(trange(3, smoothing=0))
    list(trange(3, maxinterval=0.1))

# Generated at 2022-06-24 09:41:47.434490
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .std import tqdm
    from .autonotebook import trange as ab_trange
    from .asyncio import trange as aio_trange

    def _test_aio_trange(kernel_trange, aio_trange):
        try:
            import asyncio  # pylint: disable=import-outside-toplevel
        except ImportError:
            return
        assert not asyncio.Task.all_tasks()
        with tqdm(disable=True, file=sys.stderr) as t:
            assert set(t._instances.keys()) == {id(t)}
            kernel_trange(3)
            aio_trange(3)
            assert set(t._instances.keys()) == {id(t)}

# Generated at 2022-06-24 09:42:00.015373
# Unit test for function trange
def test_trange():
    from .std import trange
    from .std import __version__

    for _ in trange(2, desc="test", leave=True,
                    mininterval=0.1, miniters=1,
                    smoothing=0, ascii=False, dynamic_ncols=True,
                    bar_format="{l}{w}{r_bar}", initial=0,
                    position=None, postfix=None):
        pass

    # test arguments of nested bar

# Generated at 2022-06-24 09:42:03.256292
# Unit test for function trange
def test_trange():
    """
    Smoke test for function trange.
    """
    with trange(10) as t:
        for _ in t:
            pass
    trange(10, desc="trange")

# Generated at 2022-06-24 09:42:12.341414
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import TqdmTypeError
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=TqdmExperimentalWarning)
        from .autonotebook import tqdm as notebook_tqdm
    try:
        from .asyncio import tqdm as asyncio_tqdm
    except ImportError:
        from .std import tqdm as asyncio_tqdm

    with warnings.catch_warnings(record=True) as w:
        for _ in trange(3, desc='Test trange'):
            assert('Test trange' in str(_))
    cls_name = w[-1].message.args[0]

# Generated at 2022-06-24 09:42:20.011105
# Unit test for function trange
def test_trange():
    """Verify that `trange` function works."""
    from .utils import _term_move_up
    from .std import trange as std_trange
    for x in trange(10):
        pass
    for x in trange(10, 100):
        pass
    for x in trange(10, 100, 5):
        pass
    for x in trange(10, 100, 5, desc="testing"):
        pass
    for x in trange(10, 100, 5, desc="testing", ncols=200, ascii=True):
        pass
    for x in trange(10, 100, 5, desc="testing", ncols=200):
        pass

    with tqdm(total=100) as pbar:
        pbar.update(10)

# Generated at 2022-06-24 09:42:25.186263
# Unit test for function trange
def test_trange():
    """Test function trange"""
    list(trange(3))
    list(trange(3, 2))
    list(trange(3, 1, 2))
    list(trange(3, 1, 2, desc="Test"))
    list(trange(3, desc="Test"))



# Generated at 2022-06-24 09:42:27.747376
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    from .autonotebook import trange, tqdm

    assert trange(100) == list(tqdm(range(100)))

# Generated at 2022-06-24 09:42:34.456577
# Unit test for function trange
def test_trange():  # pragma: no cover
    import sys
    import os
    import shutil
    import tempfile
    from tqdm import trange
    from tqdm._utils import _term_move_up
    fd, temp_file = tempfile.mkstemp()
    sys.stdout = os.fdopen(fd, 'w')

# Generated at 2022-06-24 09:42:43.010042
# Unit test for function trange
def test_trange():
    from ._utils import _range
    from .utils import format_sizeof, format_interval

    for i in trange(10):
        pass
    for i in trange(1000, desc="TEST1"):
        pass
    for i in trange(1000, 1000, desc="TEST2"):
        pass
    for i in trange(1000, 0, -1, desc="TEST3"):
        pass
    for i in trange(_range(10 ** 8)):
        pass
    for i in trange(_range(10 ** 6), desc="TEST4"):
        pass
    for i in trange(_range(10 ** 6), 10 ** 6, desc="TEST5"):
        pass

# Generated at 2022-06-24 09:42:48.231991
# Unit test for function trange
def test_trange():
    """Test trange"""
    assert list(trange(5)) == list(range(5))
    assert list(trange(1, 6)) == list(range(1, 6))
    assert list(trange(1, 12, 2)) == list(range(1, 12, 2))
    assert list(trange(1, 10, 3.14)) == list(range(1, 10, 3))


# Generated at 2022-06-24 09:42:59.460778
# Unit test for function trange
def test_trange():
    """Unit tests for the function `trange`"""
    from .std import tqdm
    from .utils import _term_move_up
    from .std import _range

    def stdtrange():
        """Alternative to `trange`"""
        return tqdm(_range(10), leave=False)

    # Basic testing
    assert next(stdtrange()) == next(trange(10))
    assert next(trange(10)) == next(tqdm(range(10)))

    # Test if `leave` parameter is set by default in `trange`
    trange_iter = trange(3)
    trange_iter.__next__()
    assert not trange_iter.leave
    trange_iter.__next__()
    assert not trange_iter.leave
    trange_iter.__next__()

# Generated at 2022-06-24 09:43:09.641618
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    import math
    import time

    with trange(10) as t:
        for i in t:
            time.sleep(0.1)
            assert i == t.n - 1
            t.set_description('Step %i' % i)
            t.refresh()  # force visual display

    with trange(10, desc="Testing trange") as t:
        for _ in t:
            pass

    with trange(10, file=sys.stderr) as t:
        for _ in t:
            pass

    with trange(10, 0) as t:
        for i in t:
            t.update(i)

    with trange(10, leave=True) as t:
        for _ in t:
            pass


# Generated at 2022-06-24 09:43:15.240265
# Unit test for function trange
def test_trange():  # pragma: no cover
    for _ in trange(4):
        pass
    for _ in trange(3, 10):
        pass
    for _ in trange(3, 10, 23):
        pass

del notebook_tqdm, notebook_trange


if __name__ == "__main__":  # pragma: no cover
    test_trange()

# Generated at 2022-06-24 09:43:17.219435
# Unit test for function trange
def test_trange():
    """Test trange"""
    from .std import tqdm
    list(tqdm(trange(10)))

# Generated at 2022-06-24 09:43:19.670548
# Unit test for function trange
def test_trange():
    """Test trange function"""
    list(trange(10))
    list(trange(0, 10))
    assert len("".join(trange(10, desc="mybar"))) == 10



# Generated at 2022-06-24 09:43:25.965880
# Unit test for function trange
def test_trange():
    """Test trange function."""
    from .utils import _term_move_up
    assert list(trange(0)) == []
    assert list(trange(1)) == [0]
    assert list(trange(2)) == [0, 1]
    assert str(trange(0)) == '| 0/0 [00:00<?, ?it/s]'
    assert str(trange(1)) == '| 1/1 [00:00<00:00, ?it/s]'
    assert str(trange(2)) == '| 2/2 [00:00<00:00, ?it/s]'
    assert str(trange(3)) == '0%|' + _term_move_up() + '  | 0/3 [00:00<?, ?it/s]'

# Generated at 2022-06-24 09:43:29.718121
# Unit test for function trange
def test_trange():
    """
    Test to ensure that trange is a simple wrapper for tqdm(range)
    """
    for i, j in zip(trange(10), tqdm(range(10))):
        assert i == j



# Generated at 2022-06-24 09:43:30.585243
# Unit test for function trange
def test_trange():
    for _ in trange(4):
        pass

# Generated at 2022-06-24 09:43:34.489492
# Unit test for function trange
def test_trange():
    """
    >>> test_trange()
    """
    assert list(trange(3)) == [0, 1, 2]
    assert list(tqdm(range(3))) == [0, 1, 2]


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 09:43:40.845776
# Unit test for function trange
def test_trange():
    assert [i for i in trange(3)] == [0, 1, 2]
    assert [i for i in trange(3, 3)] == []
    assert [i for i in trange(3, 4)] == [3]
    assert [i for i in trange(3, 1)] == [3, 2, 1]
    assert [i for i in trange(3, -1, -1)] == [3, 2, 1]
    assert [i for i in trange(3, 1, 1)] == []
    assert [i for i in trange(3, 3, 1)] == [3, 2, 1]
    assert [i for i in trange(3, 1, -1)] == [3, 2, 1]

# Generated at 2022-06-24 09:43:50.941826
# Unit test for function trange
def test_trange():
    """
    Tests that trange() works as expected

    :return: True if all test pass
    """
    from ._version import __version__  # pylint: disable=import-outside-toplevel
    from ._utils import _range  # pylint: disable=import-outside-toplevel
    from .utils import _supports_unicode  # pylint: disable=import-outside-toplevel

    with tqdm(_range(1), desc=str("desc"), ncols=_supports_unicode) as pbar:
        # All tqdm variants must accept identical arguments
        assert len(pbar) == 1
        assert pbar.n == 1
        assert pbar.total == 1
        assert pbar.desc == "desc"

        # All tqdm variants must accept the same update() arguments
       

# Generated at 2022-06-24 09:43:53.767906
# Unit test for function trange
def test_trange():
    """Regression test"""
    assert trange(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-24 09:43:55.890561
# Unit test for function trange
def test_trange():
    """Test for `auto.trange`"""
    for _ in trange(10):
        pass

# Generated at 2022-06-24 09:43:59.978575
# Unit test for function trange
def test_trange():
    r = []
    with tqdm(total=10) as pbar:
        for i in trange(10):
            r.append(i)
            pbar.update()
    assert r == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-24 09:44:01.336585
# Unit test for function trange
def test_trange():
    list(trange(5))
    list(tqdm(range(5)))

# Generated at 2022-06-24 09:44:05.847008
# Unit test for function trange
def test_trange():
    """Test for `trange`"""
    from tqdm.auto import trange

    for i in trange(4):
        for j in trange(4):
            assert i * 4 + j == j

    for i in trange(4):
        assert i == i

    for _ in trange(4):
        pass

# Generated at 2022-06-24 09:44:08.640169
# Unit test for function trange
def test_trange():
    list(trange(10))


# Test async compat (all Python3.6+)

# Generated at 2022-06-24 09:44:10.386748
# Unit test for function trange
def test_trange():
    """
    Unit test for trange.
    """
    assert list(trange(3)) == [0, 1, 2]

# Generated at 2022-06-24 09:44:12.614355
# Unit test for function trange
def test_trange():
    "Test function trange"
    from .std import tqdm
    assert [i for i in trange(100)] == [i for i in tqdm(range(100))]



# Generated at 2022-06-24 09:44:16.980616
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import NullHandler, get_instances
    from .utils import _range

    logger = NullHandler()
    for _ in get_instances():
        logger.close()

    for _ in tqdm(_range(3), desc='foo', leave=False):
        logger.handle(None)
        logger.close()  # should be re-created
    for _ in trange(2, desc='bar', leave=False):
        logger.handle(None)
        logger.close()  # should be re-created

# Generated at 2022-06-24 09:44:19.607171
# Unit test for function trange
def test_trange():
    """ Test if trange correctly works with non iterables """
    trange(5, desc='Testing trange')
    trange(5, unit='', desc='Testing trange')

# Generated at 2022-06-24 09:44:23.524935
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .std import tqdm as std_tqdm

    assert tqdm(range(10)) == std_tqdm(range(10))
    assert tqdm(range(10), notebook=True) == tqdm(range(10))
    assert tqdm(range(10), notebook=False) == tqdm(range(10))

# Generated at 2022-06-24 09:44:29.908962
# Unit test for function trange
def test_trange():
    list(trange(10))
    try:
        list(trange(10, desc=5))  # Trange is not the same as tqdm for desc
    except TypeError:
        pass
    else:
        raise TypeError
    try:
        list(trange(10, desc="trange"))  # Trange is not the same as tqdm for desc
    except TypeError:
        pass
    else:
        raise TypeError

test_trange()

# Generated at 2022-06-24 09:44:31.435295
# Unit test for function trange
def test_trange():
    """Test for trange"""
    for i in trange(5):
        pass