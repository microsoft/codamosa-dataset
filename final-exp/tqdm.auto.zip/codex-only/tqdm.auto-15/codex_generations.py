

# Generated at 2022-06-24 09:35:56.044373
# Unit test for function trange
def test_trange():
    """Test for module-level function `trange`"""
    from .std import tqdm, trange

    for unit in [None, "foo"]:
        for i, j in [
            (0, 1),
            (1, 2),
            (2, 3),
            (3, 4),
            (4, 6),
            (6, 10),
            (10, 100),
        ]:
            l = list(trange(i, j, unit=unit))
            assert l == list(tqdm(range(i, j), unit=unit))
            assert all(
                [isinstance(x, int) for x in l]
            ), "trange isn't returning ints"



# Generated at 2022-06-24 09:36:03.738165
# Unit test for function trange
def test_trange():
    """
    Test that asyncio trange has been enabled.
    """
    # pylint: disable=protected-access
    assert tqdm.__class__.__name__ == "tqdm"  # type-check
    assert tqdm.__name__ == "tqdm"  # name-check
    assert trange(3)._class_name == "tqdm_asyncio"
    assert trange(3)._name == "tqdm"

# Generated at 2022-06-24 09:36:07.719567
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    Tests that `tqdm.auto.trange` at least works (with python3.6+)
        and doesn't error out.
    """
    from .asyncio import AIOAdapter
    assert trange(5) == AIOAdapter(range(5))

# Generated at 2022-06-24 09:36:17.623090
# Unit test for function trange
def test_trange():
    from .std import _supports_unicode
    _, file = tempfile.mkstemp()
    try:
        for n in trange(1, 50):
            with open(file, "wb") as f:
                f.write(("a" * n).encode("ascii", "replace"))
            # reading every file as unicode
            assert u"".join(open(file, "r", encoding="utf8").readlines())[
                : n
            ].count("a") == n
            if _supports_unicode():
                # reading every file as bytes with unicode fallback
                assert "".join(
                    open(file, "r", encoding="ascii", errors="replace").readlines()
                )[: n].count("a") == n
        assert True
    finally:
        os.remove

# Generated at 2022-06-24 09:36:25.905616
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    # non-lazy
    assert next(trange(0)) == 0
    assert next(trange(1)) == 1
    assert next(trange(1, 1)) == 1
    assert next(trange(0, 1)) == 0
    assert next(trange(0, 1, 1)) == 0
    assert next(trange(1, 1, 1)) == 1
    assert next(trange(0, 1, 2)) == 0

    # lazy
    import itertools
    iterable = itertools.chain([0, 1], itertools.repeat(2, 3))
    assert list(trange(iterable, total=4)) == list(range(4))



# Generated at 2022-06-24 09:36:32.097671
# Unit test for function trange
def test_trange():
    from .std import tqdm as std_tqdm
    from .asyncio import tqdm as asyncio_tqdm
    from .cli import tqdm as cli_tqdm
    from .gui import tqdm as gui_tqdm
    assert tqdm is not std_tqdm
    assert tqdm is not asyncio_tqdm
    assert tqdm is not cli_tqdm
    assert tqdm is not gui_tqdm
    assert trange is not range

# Generated at 2022-06-24 09:36:36.085397
# Unit test for function trange
def test_trange():
    """Test trange"""
    from .std import tqdm
    # pylint: disable=E0611,W0611
    from unittest import SkipTest
    raise SkipTest()


# Unit test without notebook

# Generated at 2022-06-24 09:36:39.170329
# Unit test for function trange
def test_trange():
    """Run unit tests for trange"""
    from ._tqdm_test_slave import main as test
    return test(tqdm, trange)


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 09:36:47.957454
# Unit test for function trange
def test_trange():
    """
    Tests that trange is equivalent to tqdm(range(*args))
    """
    from .std import trange as std_trange
    from .std import tqdm as std_tqdm

    for t in [notebook_trange, std_trange]:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
            assert trange(10) == t(range(10))
            assert trange(2, 3, 9, 10) == t(range(2, 3, 9, 10))
            assert trange(0) == t(range(0))

    assert tqdm(range(10)) is not std_tqdm(range(10))
    assert tqdm(range(10)) is notebook_tqdm(range(10))
   

# Generated at 2022-06-24 09:36:53.874736
# Unit test for function trange
def test_trange():
    from .std import tqdm as std_tqdm
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        from .autonotebook import trange as notebook_trange

    assert std_tqdm("trange", total=3) == notebook_trange("trange", total=3)
    assert list(std_tqdm("trange", total=3)) == list(notebook_trange("trange", total=3))

# Generated at 2022-06-24 09:37:04.241065
# Unit test for function trange
def test_trange():
    """Test for trange"""
    try:
        if sys.version_info[1] < 6:
            raise ValueError
        __import__('unittest').main('tqdm.tests.test_auto', argv=['first-arg-is-ignored'], exit=False)
    except (ImportError, ValueError):
        from unittest import main as unit_main
        from .tests import test_auto
        unit_main(module=test_auto, argv=['first-arg-is-ignored'], exit=False)
    except SystemExit:
        pass

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:37:14.124721
# Unit test for function trange
def test_trange():
    """
    Unit tests for trange.
    """
    from .utils import _term_move_up

    for _ in trange(3):
        print('')
    print('Done', end='', flush=True)
    _term_move_up()

    for _ in trange(3, desc='A simple loop'):
        print('')
    print('Done', end='', flush=True)
    _term_move_up()

    for _ in trange(3, desc='A simple loop', leave=True):
        print('')
    print('Done', end='', flush=True)
    _term_move_up()

    for _ in trange(3, desc='A simple loop', leave=True):
        print('')
    print('Done', end='')

# Generated at 2022-06-24 09:37:14.773681
# Unit test for function trange
def test_trange():
    from .std import trange, tqdm  # for doctest

# Generated at 2022-06-24 09:37:23.974033
# Unit test for function trange
def test_trange():
    from time import sleep
    from numpy import allclose

    cum_times = [0.]
    for _ in trange(10):
        sleep(0.01)
        cum_times.append(cum_times[-1] + 0.01)

    assert allclose(cum_times,
                    [0.0, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09,
                     0.1],
                    atol=1e-1, rtol=1e-1)

if __name__ == "__main__":
    from .__main__ import main as auto_usagemain
    auto_usagemain([])

# Generated at 2022-06-24 09:37:27.522007
# Unit test for function trange
def test_trange():
    x = 0
    for _ in trange(5):
        x += 1
    assert x == 5
    assert type(trange(5)) is tqdm
    assert type(list(trange(5))) is list


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:37:38.846551
# Unit test for function trange
def test_trange():
    """Test function `tqdm.auto.trange`."""
    from .utils import FormatStrenth, format_interval

    from .std import tqdm as std_tqdm, total

    with std_tqdm(total=total,
                  file=sys.stderr,
                  mininterval=0.5,
                  miniters=1,
                  desc='Progress: ',
                  leave=False,
                  ascii=True) as pbar:
        for i in trange(len(pbar)):
            pbar.set_description('[{0}] '.format(i))
            pbar.update()
            time.sleep(0.1)

    # Ensure altair detection doesn't interfere with normal use

# Generated at 2022-06-24 09:37:40.673302
# Unit test for function trange
def test_trange():
    """ Test function `trange`"""
    assert (list(trange(5)) == list(range(5)))
    with tqdm(total=5) as t:
        t.update()


# Generated at 2022-06-24 09:37:45.392783
# Unit test for function trange
def test_trange():
    """
    Tests `trange` function.
    """
    # Check with tqdm_cls
    assert tqdm(range(1), tqdm_cls=tqdm)

    # Check range and iterable args
    assert len(list(tqdm(range(10)))) == 10
    assert len(list(trange(10))) == 10

    # Check with postfix arg
    for i, x in enumerate(tqdm(range(7), postfix="foo")):
        assert i == x
    for i, x in enumerate(trange(7, postfix=dict(foo=i))):
        assert i == x

    # Check cls
    assert isinstance(tqdm(range(7)), tqdm)

# Generated at 2022-06-24 09:37:52.711293
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    Unit test for function `tqdm.trange`.
    """
    assert list(trange(10)) == list(range(10))
    assert list(trange(10, 5, -1)) == list(range(10, 5, -1))
    assert list(trange(10, 2)) == list(range(10, 2))
    assert list(trange(10, 5, -1, desc="desc")) == list(range(10, 5, -1))
    assert list(trange(10, 2, desc="desc")) == list(range(10, 2))

# Generated at 2022-06-24 09:37:55.022838
# Unit test for function trange
def test_trange():
    assert len(list(trange(10))) == 10
    assert len(list(tqdm(range(10)))) == 10

# Generated at 2022-06-24 09:37:57.190486
# Unit test for function trange
def test_trange():
    # Test for trange
    for _ in trange(10, desc="test_trange"):
        pass



# Generated at 2022-06-24 09:38:02.906887
# Unit test for function trange
def test_trange():
    """Test function trange"""
    list(trange(0))
    list(trange(100, 0, -1))
    list(trange(1, 100))
    list(trange(0, 1, .1))
    list(trange(1, 0, -.1))
    list(trange(0))
    list(trange(5, desc="Test"))

# Generated at 2022-06-24 09:38:05.896616
# Unit test for function trange
def test_trange():
    """Test trange() function"""
    from tqdm.auto import trange
    for _ in trange(5):
        pass

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:38:13.328808
# Unit test for function trange
def test_trange():
    from .std import trange
    from .std import tqdm
    from .std import TqdmExperimentalWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        for i in trange(4, 0, -1):
            assert isinstance(i, int)
        for _ in trange(1, desc='desc', disable=True):
            pass
        for i in trange(1):
            assert isinstance(i, int)
        for _ in tqdm(iter(lambda: 1, 2)):
            pass

# Generated at 2022-06-24 09:38:15.470331
# Unit test for function trange
def test_trange():
    """
    Doctest:
    >>> test_trange()
    """
    assert list(trange(10)) == list(range(10))



# Generated at 2022-06-24 09:38:19.002563
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    i = list(trange(10))
    assert i == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-24 09:38:21.813510
# Unit test for function trange
def test_trange():
    """Test function trange"""
    test_i = list(trange(10))
    assert test_i == list(range(10))

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:38:27.997558
# Unit test for function trange
def test_trange():
    assert list(trange(5)) == list(range(5))
    assert list(trange(5, 10)) == list(range(5, 10))
    assert list(trange(5, 10, 2)) == list(range(5, 10, 2))
    assert list(trange(5, 0, -2)) == list(range(5, 0, -2))
    assert list(trange(10, desc='Test')) == list(range(10))
    assert list(trange(0)) == list(range(0))


# Generated at 2022-06-24 09:38:29.686541
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import trange as _trange
    assert trange is _trange

# Generated at 2022-06-24 09:38:34.227963
# Unit test for function trange
def test_trange():
    """Test trange function on py27, py33, py34, py35, py36"""
    assert set(tqdm(trange(10))) == set(tqdm(range(10)))


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:38:42.653396
# Unit test for function trange
def test_trange():
    """Unit test for function trange."""
    import pytest

    with pytest.raises(TypeError):
        _ = trange()

    with pytest.raises(TypeError):
        _ = trange(1, 2, 3, 4, 5, 6)

    with pytest.raises(TypeError):
        _ = trange('a')

    t = trange(5)
    assert len(t) == 5
    for _ in t:
        pass

    t = trange(1000, 1100)
    assert len(t) == 100
    for _ in t:
        pass

# Generated at 2022-06-24 09:38:48.612863
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test for trange"""
    from ._utils.tests import closing, closing_to_file, _range

    # Test basic function
    with closing(trange(7, ncols=70)) as t:
        for i in t:
            _range(0, i)

    # Test with file
    with closing_to_file() as t:
        for i in t:
            _range(0, i)



# Generated at 2022-06-24 09:38:59.748337
# Unit test for function trange
def test_trange():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert list(trange(3)) == list(range(3))
        assert list(trange(0)) == list(range(0))
        assert list(trange(1)) == list(range(1))
        assert list(trange(3, 1)) == list(range(3, 1))
        assert list(trange(3, 1, -1)) == list(range(3, 1, -1))
        assert list(trange(3, 1, -2)) == list(range(3, 1, -2))
        assert list(trange(4, 0, -1)) == list(range(4, 0, -1))

# Generated at 2022-06-24 09:39:09.602131
# Unit test for function trange
def test_trange():
    """Test function `trange`."""
    from itertools import chain
    from inspect import isgenerator, isgeneratorfunction

    assert callable(trange)
    assert not isgeneratorfunction(trange)
    assert isgenerator(trange(0))
    assert list(trange(0)) == []
    assert list(trange(5)) == list(range(5))
    assert list(trange(1, 3)) == list(range(1, 3))
    assert list(trange(1, 4, 2)) == list(range(1, 4, 2))
    assert list(trange(4, 1, -2)) == list(range(4, 1, -2))
    assert list(trange(4, 1, 2)) == []
    assert list(trange(1, 4, -2)) == []

# Generated at 2022-06-24 09:39:20.501121
# Unit test for function trange
def test_trange():
    """
    Tests `trange` via multiple iterators
    """
    assert list(trange(2)) == list(range(2))
    assert list(trange(2, 3)) == list(range(2, 3))
    assert list(trange(2, 3, 1)) == list(range(2, 3, 1))
    assert list(trange(2, 3, -1)) == list(range(2, 3, -1))
    assert list(trange(3, 2)) == list(range(3, 2))
    assert list(trange(3, 2, -1)) == list(range(3, 2, -1))
    assert list(trange(3, 2, 1)) == list(range(3, 2, 1))

# Generated at 2022-06-24 09:39:28.083491
# Unit test for function trange
def test_trange():
    """Tests that trange is equivalent to tqdm(range(...))"""
    # pylint: disable=global-variable-undefined
    global tqdm
    global trange

    if tqdm == notebook_tqdm:
        tqdm_ = tqdm
    else:
        tqdm_ = std_tqdm

    for _ in trange(5):
        pass

    for _ in tqdm_(range(5)):
        pass

    for _ in trange("abc"):
        pass

    for _ in tqdm_("abc"):
        pass

    for _ in trange(2, 5):
        pass

    for _ in tqdm_(range(2, 5)):
        pass


# Generated at 2022-06-24 09:39:36.757233
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    from tqdm.auto import tqdm
    from tqdm._utils import _term_move_up
    list(trange(3))
    assert hasattr(tqdm, "asyncio")
    assert not hasattr(tqdm, "notebook")
    assert len(sys.stdout.getvalue().splitlines()) == 3
    # noqa
    last_len = len(sys.stdout.getvalue().splitlines()[-1])
    # noqa
    assert not last_len  # autonotebook should clear
    list(trange(3, file=sys.stderr))
    assert len(sys.stderr.getvalue().splitlines()) == 3
    # noqa

# Generated at 2022-06-24 09:39:43.146278
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test for function trange."""
    from ._tqdm import format_interval
    assert format_interval(0.123456)[0] == '2ms'
    assert isinstance(trange(0), tqdm)
    with tqdm(total=10) as pbar:
        assert pbar is not None
        assert pbar.format_interval(0.123456)[0] == '2ms'
        pbar.update(1)
    assert list(tqdm(range(3), desc="foo")) == list(range(3))
    assert list(tqdm(range(3), total=3)) == list(range(3))
    assert list(tqdm(range(3), total=4)) == list(range(3))

# Generated at 2022-06-24 09:39:45.969319
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    for _ in trange(2):
        list(range(3))
    with tqdm(range(3)) as pbar:
        for _ in range(2):
            list(range(3))

# Generated at 2022-06-24 09:39:50.394336
# Unit test for function trange
def test_trange():
    # fix random seed
    from random import randint
    import time
    for _ in trange(5, desc='5 random numbers'):
        time.sleep(0.1)
        value = randint(0, 100)

    for _ in trange(10, desc='square numbers'):
        time.sleep(0.05)
        value = pow(_, 2)

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:39:55.263449
# Unit test for function trange
def test_trange():
    from .utils import _range
    from .std import tqdm as std_tqdm

    for _tqdm in [tqdm, std_tqdm]:
        for i in _tqdm(trange(0, 1, 0.01)):
            assert(i in _range(0, 1, 0.01))

# Generated at 2022-06-24 09:40:03.836111
# Unit test for function trange
def test_trange():
    """
    Test that trange works correctly with both notebook_trange and asyncio_trange
    """
    import sys
    if sys.version_info[:2] < (3, 6):
        class TqdmUndefinedType(tqdm):
            pass
    else:
        class TqdmUndefinedType(notebook_tqdm):
            pass

    for trange1, trange2 in ((notebook_trange, asyncio_tqdm),
                             (asyncio_tqdm, notebook_trange)):
        # Check that trange works with both .tqdms (both in autonotebook and asyncio)
        class tqdm1(trange1):
            pass
        class tqdm2(trange2):
            pass
        assert tqdm1 is tqdm


# Generated at 2022-06-24 09:40:13.790049
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    Unit test for function trange.
    """
    from tqdm import _tqdm, tqdm
    from tqdm.std import trange
    from time import sleep

    # Check trange has same behaviour of tqdm for the same arguments
    for i in trange(10**6, desc='trange(10**6)'):
        pass
    for i in _tqdm(range(10**6), desc='_tqdm(range(10**6))'):
        pass
    for i in tqdm(range(10**6), desc='tqdm(range(10**6))'):
        pass


# Generated at 2022-06-24 09:40:16.954800
# Unit test for function trange
def test_trange():
    # pylint: disable=unreachable
    list(trange(3))
    list(trange(3, desc="I'm a banana!"))
    list(tqdm(range(3)))
    try:
        list(tqdm(xrange(3)))
    except NameError:
        pass
    else:
        raise Exception()
    # pylint: enable=unreachable

# Generated at 2022-06-24 09:40:20.017301
# Unit test for function trange
def test_trange():
    """
    Tests whether function trange is working or not.
    """
    assert trange(5) == tqdm(range(5))

# Generated at 2022-06-24 09:40:30.545145
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    range_it = trange(3)
    assert isinstance(range_it, notebook_tqdm)
    assert notebook_tqdm.write == tqdm.write

    range_it = trange(3, desc="test")
    assert isinstance(range_it, notebook_tqdm)
    assert notebook_tqdm.write == tqdm.write

    list(range_it)

    range_it = trange(3, file=sys.stdout)
    assert isinstance(range_it, notebook_tqdm)
    assert notebook_tqdm.write == tqdm.write

    list(range_it)

    range_it = trange(3, file=sys.stderr)

# Generated at 2022-06-24 09:40:33.907220
# Unit test for function trange
def test_trange():
    """Test for trange"""
    assert list(trange(5)) == [0, 1, 2, 3, 4]

# Generated at 2022-06-24 09:40:42.546544
# Unit test for function trange
def test_trange():
    """Test function `trange`."""
    from .std import trange
    from .gui import trange
    from .gui import tgrange

    # pylint: disable=redefined-outer-name
    for trange in (trange, tgrange):
        # Smoke test
        list(trange(0))
        list(trange(2))
        # Test disable
        list(trange(2, disable=True))
        # Test leave
        list(trange(2, leave=True))
        # Test dynamic_ncols
        list(trange(2, dynamic_ncols=True))
        # Test ascii
        list(trange(2, ascii=True))
        # Test ncols
        list(trange(2, ncols=10))
        # Test postfix

# Generated at 2022-06-24 09:40:44.826410
# Unit test for function trange
def test_trange():  # pragma: no cover
    list(trange(5))

# Generated at 2022-06-24 09:40:52.654616
# Unit test for function trange
def test_trange():
    from .std import __version__ as version
    from .std import trange

    for _ in trange(3, desc='Mocking tqdm', leave=False):
        assert 1

    for i in trange(3):
        assert i in {0, 1, 2}

    assert tqdm.__doc__.splitlines()[0] == 'Enables multiple commonly used features.'
    assert tqdm.__module__.split('.')[-1] == 'auto'
    assert tqdm.__name__ == 'tqdm'
    assert tqdm.__package__.split('.')[-1] == 'tqdm'
    assert str(trange) == "trange"

# Generated at 2022-06-24 09:40:59.270842
# Unit test for function trange
def test_trange():
    from .std import trange
    from .utils import format_interval

    __test__ = False  # type: bool

    pbar = trange(5)
    format_interval(pbar, 0)
    for _ in pbar:
        for _ in pbar:
            break
    format_interval(pbar, 1)
    for _ in pbar:
        pass
    format_interval(pbar, 2)


try:
    import pytest  # noqa
except ImportError:
    pass
else:
    del test_trange

# Generated at 2022-06-24 09:41:07.341448
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Test for function `trange`"""
    from .autonotebook import trange
    l = list(trange(10))
    assert l == list(range(10)), l
    l = list(trange(0))
    assert l == list(range(0)), l
    l = list(trange(10, 0, -1))
    assert l == list(range(10, 0, -1)), l
    try:
        l = list(next(trange(10))[0])
        assert False
    except TypeError:
        pass
    try:
        l = list(trange(10, 0, 1))
        assert False
    except ValueError:
        pass

# Generated at 2022-06-24 09:41:09.669498
# Unit test for function trange
def test_trange():
    assert list(trange(100)) == list(range(100))
    assert list(trange(10, 15)) == list(range(10, 15))
    assert list(trange(5, 11, 2)) == list(range(5, 11, 2))
    assert list(trange(5, -1, -1)) == list(range(5, -1, -1))

# Generated at 2022-06-24 09:41:12.846140
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from .std import trange

    with trange(10) as t:
        for _ in t:
            pass
    for _ in trange(10, desc="test"):
        pass

# Generated at 2022-06-24 09:41:22.167659
# Unit test for function trange
def test_trange():
    from .gui import tgrange

    assert trange(1, 2) == range(1, 2)
    assert list(trange(2)) == list(range(2))
    assert list(trange(1, 2)) == list(range(1, 2))

    assert list(trange(0)) == list(range(0))
    assert list(trange(1, 2, 3)) == list(range(1, 2, 3))
    assert list(trange(1, 2, 1)) == list(range(1, 2, 1))
    assert list(trange(1, 2, 1, 1)) == list(range(1, 2, 1))

    assert list(tgrange()) == list(range(0))
    assert list(tgrange(2)) == list(range(2))


# Generated at 2022-06-24 09:41:34.075193
# Unit test for function trange
def test_trange():
    """Test trange()"""
    from .utils import _range
    for i in trange(4, 0, -1):
        assert i in (4, 3, 2, 1)

    for i in trange(5):
        assert i in (1, 2, 3, 4, 5)

    for i in trange(1, 7, 2):
        assert i in (1, 3, 5, 7)
    for i in trange(7, 1, 2):
        assert i in (1, 3, 5, 7)

    for i in trange(1, 7, -2):
        assert i in (1, 3, 5, 7)
    for i in trange(7, 1, -2):
        assert i in (1, 3, 5, 7)


# Generated at 2022-06-24 09:41:34.860681
# Unit test for function trange
def test_trange():
    from .tests import tests
    return tests.test_trange()



# Generated at 2022-06-24 09:41:36.548290
# Unit test for function trange
def test_trange():  # pragma: no cover
    for _ in trange(10):
        pass

# Generated at 2022-06-24 09:41:42.253825
# Unit test for function trange
def test_trange():
    """Tests the function trange"""
    assert list(trange(0)) == []
    assert list(trange(2)) == [0, 1]
    assert list(trange(2, 3)) == [2]
    assert list(trange(3, 2)) == []
    assert list(trange(3, 5, 4)) == [3]
    assert list(trange(4, 10, 3)) == [4, 7]
    assert list(trange(4, -2, 3)) == [4, 1, -2]
    assert list(trange(-5, 2, 3)) == [-5, -2, 1]
    assert list(trange(-5.0, 2, 3)) == [-5.0, -2.0, 1.0]
    assert list(trange(-5, 2.0, 3))

# Generated at 2022-06-24 09:41:48.922081
# Unit test for function trange
def test_trange():
    """
    Unit test for function `trange`.
    """
    import io
    import sys
    out = io.StringIO()
    sys.stdout = out
    trange(3)
    sys.stdout = sys.__stdout__
    result = out.getvalue().strip()
    assert result == '1/3:   0%|          | 0/3 [00:00<?, ?it/s]\n2/3:   0%|          | 0/3 [00:00<?, ?it/s]\n3/3:   0%|          | 0/3 [00:00<?, ?it/s]'

# Generated at 2022-06-24 09:41:54.823240
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from ._utils import _range
    from ._tqdm_gui import _version_warn
    try:
        # In case of GUI, _range will not work
        _range(0, 0)
    except _version_warn:
        pass
    else:
        raise Exception("test_trange failed: GUI not detected")

    from .gui import tqdm
    try:
        # In case of GUI, trange will not work
        trange(0)
    except _version_warn:
        pass
    else:
        raise Exception("test_trange failed: tqdm not detected")

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:41:57.138007
# Unit test for function trange
def test_trange():
    """Test trange and tqdm"""
    from time import sleep

    for i in trange(5):
        sleep(0.05)

# Generated at 2022-06-24 09:42:00.996540
# Unit test for function trange
def test_trange():
    from .std import tqdm, trange
    for _tqdm in [tqdm, trange]:
        with _tqdm(total=4) as pbar:
            for _ in range(4):
                pbar.update()
                assert pbar.n == pbar.last_print_n + 1

# Generated at 2022-06-24 09:42:05.015591
# Unit test for function trange
def test_trange():
    """
    Unit tests for function trange

    :return: True if all tests are passed
    """
    tr = trange(4, 2)
    for i, _ in enumerate(tr):
        if i != 4:
            return False
    return True

# Generated at 2022-06-24 09:42:11.805507
# Unit test for function trange
def test_trange():
    """Test trange"""
    with tqdm(total=7) as pbar:
        assert pbar.total == 7
        assert len(pbar) == 7
        assert not pbar.desc
        assert not pbar.leave
        pbar.update(1)
        pbar.update(2)
        pbar.set_description("foo")
        assert pbar.desc == "foo"
        pbar.n = -1
        pbar.refresh()
        pbar.update()
        pbar.close()
        assert pbar.closed
        pbar.reset()
        assert pbar.n == 0

# Generated at 2022-06-24 09:42:13.088542
# Unit test for function trange
def test_trange():
    """Smoke test for trange"""
    for _ in trange(10):
        pass

# Generated at 2022-06-24 09:42:16.560788
# Unit test for function trange
def test_trange():
    """Test 1: trange in a loop"""
    from time import sleep
    from random import random
    for _ in trange(5, desc='1st loop'):
        for _ in trange(20, desc='2nd loop', leave=False):
            for _ in trange(30, desc='3rd loop', leave=True, miniters=5):
                sleep(random() / 100)

# Generated at 2022-06-24 09:42:22.468991
# Unit test for function trange
def test_trange():
    """
    Tests `trange` function in tqdm/auto.py.
    """
    from .std import format_sizeof, format_interval
    from .utils import _range

    with tqdm(_range(10), desc='Testing trange', ascii=True) as t:
        for _ in t:
            pass
    assert t.n == 10
    assert t.total == 10
    assert t.dynamic_ncols()
    # print('logger:', t.logger)
    # assert not t.logger

    # with tqdm.log_stdout() as t:
    #     format_sizeof(t.logger)
    #     format_interval(t.logger)

    print(format_sizeof(t))

# Generated at 2022-06-24 09:42:28.144217
# Unit test for function trange
def test_trange():
    """Test the function trange"""
    trange_test = trange(5)
    assert next(trange_test) == 0
    assert next(trange_test) == 1

# Generated at 2022-06-24 09:42:29.525495
# Unit test for function trange
def test_trange():
    """Test the deprecated trange function."""
    from .tests import common
    common.test_trange(trange)

# Generated at 2022-06-24 09:42:31.245967
# Unit test for function trange
def test_trange():
    """
    Test if the unit test itself works (using the tested function)
    """
    list(tqdm(range(100)))



# Generated at 2022-06-24 09:42:33.419302
# Unit test for function trange
def test_trange():  # pragma: no cover
    assert len(list(trange(10))) == 10

# Generated at 2022-06-24 09:42:42.306499
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .std import tqdm as std_tqdm
    from .gui import tqdm as gui_tqdm
    from .gui import trange as gui_trange
    from .asyncio import tqdm as asyncio_tqdm
    from .asyncio import trange as asyncio_trange

    assert tqdm is std_tqdm
    assert tqdm is not gui_tqdm
    assert tqdm is not asyncio_tqdm
    assert tqdm is not asyncio_tqdm.__base__
    assert tqdm is not asyncio_tqdm.__base__.__base__
    assert asyncio_tqdm.__base__.__base__ is gui_tqdm

# Generated at 2022-06-24 09:42:50.612332
# Unit test for function trange
def test_trange():
    assert trange(1, 5) == list(range(1, 5))
    assert trange(1, 5, 0.1) == list(range(1, 5))
    assert trange(5) == list(range(5))
    assert trange(0) == []
    assert trange(1, 0, -1) == list(range(1, 0, -1))
    assert trange(5, 0, -1) == list(range(5, 0, -1))
    assert trange(5, 0, -2) == list(range(5, 0, -2))
    assert trange(5, 0, -2.0) == list(range(5, 0, -2))



# Generated at 2022-06-24 09:43:01.142367
# Unit test for function trange
def test_trange():
    import random
    import time
    from .std import tqdm
    from .std import tgrange
    from .std import trange

    for n, _t in tgrange(1, 7, desc='tgrange - Unit test', leave=True):  # pylint: disable=unused-variable
        time.sleep(.1 * random.random())
    for n, _t in tqdm(range(1, 7), desc='tqdm range - Unit test', leave=True):  # pylint: disable=unused-variable
        time.sleep(.1 * random.random())
    for n, _t in trange(1, 7, desc='tqdm auto range - Unit test', leave=True):  # pylint: disable=unused-variable
        time.sleep(.1 * random.random())

# Generated at 2022-06-24 09:43:11.514827
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .utils import _range as range
    from .std import tqdm, tgrange

    assert list(tgrange(1, 9, 2)) == list(tqdm(range(1, 9, 2)))
    assert list(tgrange(9, 1, -2)) == list(tqdm(range(9, 1, -2)))
    assert list(tgrange(9, 1, -2, desc="abcd")) == \
        list(tqdm(range(9, 1, -2), desc="abcd"))
    assert list(tgrange(9, 1, -2, ascii=True)) == \
        list(tqdm(range(9, 1, -2), ascii=True))

# Generated at 2022-06-24 09:43:15.476041
# Unit test for function trange
def test_trange():
    """
    Test function for doctests and others.
    """
    assert list(trange(3)) == [0, 1, 2]


if __name__ == "__main__":
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-24 09:43:18.974783
# Unit test for function trange
def test_trange():
    """
    Tests that trange is properly defined.
    """
    from .utils import _range
    from .std import tqdm
    for i in trange(_range(10)):
        pass
    assert trange(10) == tqdm(range(10))

# Generated at 2022-06-24 09:43:20.398912
# Unit test for function trange
def test_trange():
    """
    Tests for function trange.
    """
    for _ in trange(2):
        pass

# Generated at 2022-06-24 09:43:23.500085
# Unit test for function trange
def test_trange():
    list(trange(10))
    list(trange(10, 0, -1))
    list(trange(10, 20))
    list(trange(10, 30, 2))
    list(trange(10, 30, 2, mininterval=0.05))

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:43:34.047331
# Unit test for function trange
def test_trange():
    """
    Unit tests for the function trange
    """
    from .compatibility import _range
    from .std import _screen_shape_wrapper

    n = 10
    stdout = sys.stdout

# Generated at 2022-06-24 09:43:35.641033
# Unit test for function trange
def test_trange():
    """Unit test for trange"""
    expected = list(range(10))
    out = list(trange(10))
    assert out == expected, '"trange" function is not working'



# Generated at 2022-06-24 09:43:36.902409
# Unit test for function trange
def test_trange():  # pragma: no cover
    assert list(trange(3)) == [0, 1, 2]

