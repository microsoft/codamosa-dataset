

# Generated at 2022-06-24 09:35:45.845622
# Unit test for function trange
def test_trange():
    import io
    import sys

    buff = io.StringIO()
    sys.stdout = buff

    trange(10)

    sys.stdout = sys.__stdout__
    assert "10it [" in buff.getvalue()

# Generated at 2022-06-24 09:35:48.239430
# Unit test for function trange
def test_trange():  # pragma: no cover
    for _ in trange(4):
        pass

# Generated at 2022-06-24 09:35:50.738093
# Unit test for function trange
def test_trange():
    from .std import trange
    from .std import tqdm
    assert trange(10) == tqdm(range(10))

# Generated at 2022-06-24 09:35:58.723469
# Unit test for function trange
def test_trange():
    """Test for trange function (returns list or iterator)"""
    assert list(trange(2)) == [0, 1]
    assert list(trange(1, 3)) == [1, 2]
    assert list(trange(2, 2)) == []
    assert list(trange(2, 0, -1)) == [2, 1]

    # test iterator
    i = iter(trange(2))
    assert next(i) == 0
    assert next(i) == 1
    try:
        next(i)
    except StopIteration:
        pass
    else:
        raise AssertionError("Expected StopIteration.")
    assert list(trange(2)) == [0, 1]


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:36:04.976317
# Unit test for function trange
def test_trange():
    """ Test shortcut for `tqdm(range(*args), **kwargs)` """
    assert list(trange(10)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(trange(1, 10)) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(trange(0, 10, 2)) == [0, 2, 4, 6, 8]

# Generated at 2022-06-24 09:36:07.804522
# Unit test for function trange
def test_trange():
    """
    Smoke test for `trange` function.
    """
    from .std import tqdm
    assert tqdm(range(1), leave=True) == trange(1, leave=True)

# Generated at 2022-06-24 09:36:17.705556
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from tqdm.tests import setup_tests, teardown_tests  # noqa, pylint: disable=unused-variable
    from tqdm.cli import _main  # noqa, pylint: disable=redefined-outer-name,unused-variable

    assert tqdm == asyncio_tqdm

    # setup
    pbar = tqdm(total=100)
    assert pbar._total == 100

    # update
    pbar.update(20)
    assert pbar.n == 20
    assert pbar.last_print_n == 20
    assert pbar._total == 100

    # ncols

# Generated at 2022-06-24 09:36:22.008871
# Unit test for function trange
def test_trange():
    """ Unit test for trange() """
    # We can't explicitly test tqdm_gui here due to multithreading issues
    for _tqdm in (  # pylint: disable=not-an-iterable
            notebook_tqdm, asyncio_tqdm, std_tqdm):
        list(tqdm(range(3), desc="trange test", leave=False, _tqdm=_tqdm))

# Generated at 2022-06-24 09:36:32.280813
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    Test to check the result of tqdm.
    """
    try:
        import unittest2 as unittest  # pylint: disable=import-error
    except ImportError:
        import unittest

    class TestTqdm(unittest.TestCase):
        """
        Test class.
        """

        def test_trange(self):
            """
            Test to check the result of trange.
            """
            self.assertEqual(list(trange(10)), list(range(10)))
            self.assertEqual(list(trange(0)), list(range(0)))
            self.assertEqual(list(trange(1)), list(range(1)))