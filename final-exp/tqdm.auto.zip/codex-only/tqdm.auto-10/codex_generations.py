

# Generated at 2022-06-24 09:35:55.888357
# Unit test for function trange
def test_trange():
    """
    Tests that `trange` == `tqdm(range())` == `tqdm(range(n))`.
    """
    from .std import TqdmTypeError
    from .compat import range

    def f(n):
        """ Returns the output of tqdm(range(n)) """
        return list(tqdm(range(n), desc=str(n)))

    for n in range(1, 5):
        assert f(n) == f(0) == list(range(n))
    assert f(10) != f(5)
    with pytest.raises(TqdmTypeError):
        f(1.)
    with pytest.raises(TqdmTypeError):
        f(1j)

# Generated at 2022-06-24 09:36:02.530146
# Unit test for function trange
def test_trange():
    from .utils import format_sizeof

    x = sum(trange(10**6))
    assert x == 499999500000
    assert format_sizeof(x) == "39.1 KiB"

    x = sum(trange(10**2, 10**6, 10**2))
    assert x == 49995550000
    assert format_sizeof(x) == "38.9 KiB"

# Generated at 2022-06-24 09:36:04.390491
# Unit test for function trange
def test_trange():
    """
    >>> trange(1, 3)
    1..2
    """
    pass

# Generated at 2022-06-24 09:36:06.918997
# Unit test for function trange
def test_trange():
    """Tests that trange is same as tqdm(range(...))"""
    assert list(trange(3)) == list(tqdm(range(3)))

# Generated at 2022-06-24 09:36:11.291787
# Unit test for function trange
def test_trange():
    """
    >>> import sys
    >>> sys.stderr = open(os.devnull, 'w')  # Disable trange verbose
    >>> list(trange(3))
    [0, 1, 2]
    """
    for _ in trange(3):
        pass

# Generated at 2022-06-24 09:36:14.067059
# Unit test for function trange
def test_trange():
    for i in trange(5):
        pass
    for i in trange(1, 5):
        pass
    for i in trange(1, 5, 2):
        pass

# Generated at 2022-06-24 09:36:18.156496
# Unit test for function trange
def test_trange():
    """Test function trange()"""
    from .tests import pretest_posttest  # noqa
    with pretest_posttest():  # noqa
        assert list(trange(3)) == [0, 1, 2]
        assert list(trange(1)) == [0]
        assert list(trange(0)) == []

# Generated at 2022-06-24 09:36:20.039693
# Unit test for function trange
def test_trange():
    """Test trange (uses pytest)"""
    from tqdm import trange
    list(trange(5))
    assert False  # Make sure it does not stop here

# Generated at 2022-06-24 09:36:29.482279
# Unit test for function trange
def test_trange():
    """Smoke test"""
    list(trange(3))
    list(trange(3, 0))
    list(trange(3, 0, -1))
    list(trange(3, 0, -1))
    list(trange(0, 3, -1))
    #print(tqdm.format_sizeof(5, SI=True))
    #print(tqdm.format_sizeof(5, SI=False))
    #print(tqdm.format_sizeof(5000, SI=True))
    #print(tqdm.format_sizeof(5000, SI=False))
    #print(tqdm.format_sizeof(10**9, SI=True))
    #print(tqdm.format_sizeof(-10**9, SI=True))
    #print(tq

# Generated at 2022-06-24 09:36:38.379066
# Unit test for function trange
def test_trange():
    """Test trange"""
    import random
    import time

    # basic
    for _ in trange(4):
        time.sleep(.05)
    for _ in trange(4, 0, -1):
        time.sleep(.05)

    # dynamic total
    for i in trange(random.randint(1, 10), leave=False):
        time.sleep(.05)

    # manual total
    for i in trange(10, desc="Manual total", total=4):
        time.sleep(.05)

    # iterable
    for _ in trange("test"):
        time.sleep(.05)

    # iterable manual total
    for _ in trange("test", total=4):
        time.sleep(.05)

    # iterable multiline

# Generated at 2022-06-24 09:36:43.201558
# Unit test for function trange
def test_trange():
    """Test function `trange`"""
    from .utils import TestCase

    with TestCase() as test:
        for _ in trange(5, 10, 2):
            test.assertTrue(True)

    with TestCase() as test:
        test.assertEqual(list(trange(5, 10, 2)), list(range(5, 10, 2)))



# Generated at 2022-06-24 09:36:48.346447
# Unit test for function trange
def test_trange():
    """Test function trange (dummy)"""
    assert list(trange(4)) == [0, 1, 2, 3]
    assert list(trange(4, 0, -1)) == [4, 3, 2, 1]
    assert list(trange(4, 1, -3)) == [4]
    assert list(trange(4, 7, 2)) == [4, 6]
    assert list(trange(4, 12, 2)) == [4, 6, 8, 10]

# Generated at 2022-06-24 09:36:52.283786
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .autonotebook import trange as notebook_trange
    from .asyncio import trange as asyncio_trange

    assert trange(0) == asyncio_trange(0) == notebook_trange(0)

# Generated at 2022-06-24 09:37:03.286422
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .std import tqdm_tests as tests
    from .std import tqdm_std as std

    @tests.unit
    def test_trange():
        """Test function trange()"""
        for desc in ["desc", "desc\n"]:
            for file in [sys.stderr, sys.stdout]:
                for n in [0, 1, 100]:
                    for unit in ["it", "its", "iters", "iterations"]:
                        std.tqdm(trange(n, desc=desc), file=file,
                                 unit_scale=True, unit=unit)
                        std.tqdm(trange(n, desc=desc), file=file,
                                 unit_scale=False, unit=unit)

# Generated at 2022-06-24 09:37:09.755303
# Unit test for function trange
def test_trange():
    for _ in trange(3, desc='1st loop'):
        for _ in trange(100, desc='2nd loop', leave=False):
            for _ in trange(100, desc='3nd loop', leave=False):
                for _ in trange(100, desc='4th loop', leave=False):
                    for _ in trange(10, desc='5th loop', leave=True, mininterval=0.01,
                                    miniters=1):
                        pass

# Generated at 2022-06-24 09:37:18.131956
# Unit test for function trange
def test_trange():
    from .std import trange
    with trange(3) as t:
        assert (next(t) == t.n == 0)
        t.set_description("test")
        assert t.base_format == "test/3"
        assert str(t) == "test:   0%|          | 0/3 [00:00<?, ?it/s]"
        t.update()
        assert (t.n == 1)
        assert str(t) == "test:  33%|███▎      | 1/3 [00:00<00:00,  2.00it/s]"
        t.update()
        assert (t.n == 2)

# Generated at 2022-06-24 09:37:23.699469
# Unit test for function trange
def test_trange():
    """ Tests that trange() is an alias for tqdm(range()) """
    t1 = tqdm(range(5))
    t2 = trange(5)
    assert t1.__enter__() is t2.__enter__()



# Generated at 2022-06-24 09:37:26.649465
# Unit test for function trange
def test_trange():
    """Test trange()"""
    from time import sleep
    from .utils import _term_move_up

    for _ in trange(3, desc='test'):
        sleep(0.01)
        _term_move_up()

# Generated at 2022-06-24 09:37:38.208668
# Unit test for function trange
def test_trange():
    """
    Tests for trange function
    :return:
    """
    from .gui import tqdm as tqdm_gui
    for cls, cls_gui in [(tqdm, tqdm_gui),
                         (trange, tqdm_gui)]:
        assert "".join(map(str, cls(range(3)))) == "123"
        assert "".join(map(str, cls(range(3), desc="desc"))) == "\rdesc: |#0  3/3  100%[elapsed: 00:00 left: 00:00,  0.00 iters/sec]"

# Generated at 2022-06-24 09:37:41.370065
# Unit test for function trange
def test_trange():
    for i in trange(10):
        pass
    for i in trange(1, 10):
        pass
    for i in trange(1, 10, 2):
        pass
    for i in trange(10, 0, -1):
        pass
    for i in trange(10, 0, -2):
        pass
    for i in trange(10, step=.1):
        pass

# Generated at 2022-06-24 09:37:46.154785
# Unit test for function trange
def test_trange():
    """
    Tests trange function
    """
    from .std import trange
    from .std import tqdm
    assert trange(5) == tqdm(range(5), desc="", leave=True)

# Generated at 2022-06-24 09:37:48.359945
# Unit test for function trange
def test_trange():
    """Test function trange"""
    total = len(set(trange(100)._instances))
    assert total == 1, total

# Generated at 2022-06-24 09:37:52.470329
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test for function trange"""
    assert list(trange(5)) == list(range(5))
    assert list(trange(1, 6)) == list(range(1, 6))
    assert list(trange(1, 7, 2)) == list(range(1, 7, 2))

# Generated at 2022-06-24 09:38:03.820429
# Unit test for function trange
def test_trange():
    "Test trange function"
    from ._tqdm import (
        format_interval,
        format_meter,
        UnicodeIO,
        format_sizeof,
        format_timespan,
        format_number,
    )


# Generated at 2022-06-24 09:38:09.291615
# Unit test for function trange
def test_trange():
    "Test if trange correctly wraps tqdm()"
    import sys
    if sys.version_info[:2] < (3, 6):
        assert tqdm != asyncio_tqdm
        assert trange == notebook_trange
    else:
        assert tqdm == asyncio_tqdm
        assert trange != notebook_trange
    assert len(list(trange(10))) == 10

# Generated at 2022-06-24 09:38:11.318581
# Unit test for function trange
def test_trange():
    """Simple sanity check for trange"""
    with trange(10) as t:
        for i in t:
            assert i < 10

# Generated at 2022-06-24 09:38:12.561874
# Unit test for function trange
def test_trange():
    '''test trange'''
    for _ in trange(4):
        pass

# Generated at 2022-06-24 09:38:15.388287
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    for _ in trange(10):
        pass


# Intentionally not testing tqdm here as we're not testing asyncio

# Generated at 2022-06-24 09:38:25.838880
# Unit test for function trange
def test_trange():
    """
    Tests that trange is working as intended.
    """
    from .std import format_interval
    from .std import trange_miniters

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        import tqdm.autonotebook as notebook_tqdm

    if sys.version_info[:2] < (3, 6):
        test_tqdm = notebook_tqdm.tqdm
        test_trange = notebook_tqdm.trange
    else:
        from .asyncio import tqdm as asyncio_tqdm


# Generated at 2022-06-24 09:38:30.302890
# Unit test for function trange
def test_trange():
    """Tests trange"""
    import sys
    import subprocess
    if sys.platform == 'win32':
        t = subprocess.Popen([sys.executable, '-c',
                              "from tqdm.auto import trange;"
                              "for i in trange(1000): pass"],
                             stdout=subprocess.PIPE)
        t.communicate()
        assert not t.returncode

if __name__ == "__main__":
    from ._utils.testing import run_tests
    run_tests()

# Generated at 2022-06-24 09:38:41.990018
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    import os
    import sys
    from subprocess import Popen, PIPE
    from threading import Thread
    import time

    if sys.version_info[:2] < (3, 6):
        print('\n' + 'Python < 3.6: skipping auto.trange test')
        return

    def test():
        """Wrapper for trange unit test"""
        n = 10
        for _ in trange(n):
            time.sleep(.1)

    p = Popen([sys.executable, '-u', '-m', 'tqdm', 'test_trange'],
              stdout=PIPE, stderr=PIPE)
    stdout = b''

# Generated at 2022-06-24 09:38:50.738166
# Unit test for function trange
def test_trange():
    import sys
    import time
    from .std import TqdmExperimentalWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        if sys.version_info[:2] < (3, 6):
            import tqdm.autonotebook
            test_trange()
            return

        from .asyncio import tqdm
        from .asyncio import trange

        with tqdm(total=7) as pbar:  # total default to 10
            for i in trange(2, 7):
                time.sleep(0.1)
        assert pbar.n == 5 and pbar.total == 7
        assert len(pbar) == 5 and len(pbar._total) == 7
        assert pbar.last_print_n

# Generated at 2022-06-24 09:38:52.975782
# Unit test for function trange
def test_trange():
    l = [i for i in trange(0, 10, desc="test")]
    assert l == list(range(10))


# Generated at 2022-06-24 09:38:55.513383
# Unit test for function trange
def test_trange():
    for _ in trange(4, leave=True):
        pass
    for _ in trange(3):
        pass
    for _ in trange(1, 2, 3):
        pass

# Generated at 2022-06-24 09:39:03.698505
# Unit test for function trange
def test_trange():
    from .std import trange
    from .utils import format_interval

    # Initialise variables
    start_t = 1e-9
    window = 1
    t = start_t
    progress_bar = trange(1, window=window, smoothing=1)
    progress_bar.refresh()  # initial draw
    counter = 0

    # Simulate work loop with a simple counter
    while True:
        counter += 1

        # Update and save the time of update
        old_t = t
        t = progress_bar.update_to(counter)  # instead of `+ 1`
        t = format_interval(t - old_t)

        # Update the description with the elapsed time
        progress_bar.set_description("Elapsed: %s." % t)

        if counter >= window:
            break

   

# Generated at 2022-06-24 09:39:14.381574
# Unit test for function trange
def test_trange():
    """Test trange"""
    import time
    from .utils import format_sizeof
    for i in trange(5, desc="Probing... "):
        time.sleep(0.3)

    with tqdm(total=5, bar_format="{l_bar}{bar} [ time left: {remaining} ]") as pbar:
        for i in trange(6, desc="Epochs: %d/%d" % (i, 5)):
            pbar.update(1)
            time.sleep(0.3)

    memory = []
    for i in trange(10000, desc="Memory usage: "):
        memory.append(100 * i)
        if i % 500 == 0:
            trange(i, desc="Memory usage: " + format_sizeof(memory))

    # Test that `

# Generated at 2022-06-24 09:39:24.609339
# Unit test for function trange
def test_trange():
    """Tests that `tqdm.auto.trange(...)` works as expected."""
    from .autonotebook import tqdm as notebook_tqdm
    from .asyncio import tqdm as asyncio_tqdm
    try:
        from .std import tqdm as std_tqdm
    except ImportError:
        std_tqdm = notebook_tqdm
    assert trange(2) == list(range(2))
    assert isinstance(trange(2), notebook_tqdm)
    assert isinstance(trange(2, miniters=1), notebook_tqdm)
    assert isinstance(trange(2, mininterval=1), notebook_tqdm)

# Generated at 2022-06-24 09:39:30.372815
# Unit test for function trange
def test_trange():
    """
    Test that the trange function returns the same
    as tqdm(range(10)) in both auto and manual mode
    """
    res1 = [i for i in trange(10)]
    res2 = [i for i in tqdm(range(10))]
    assert res1 == res2

# Generated at 2022-06-24 09:39:41.597776
# Unit test for function trange
def test_trange():
    """Test function trange"""
    try:
        from functools import lru_cache
    except ImportError:
        lru_cache = lambda func: func
    @lru_cache()
    def _test_trange(notebook):
        from .autonotebook import tqdm as notebook_tqdm
        from .asyncio import tqdm as asyncio_tqdm
        from .autonotebook import trange as notebook_trange
        from .std import trange as std_trange
        from .std import tqdm
        if notebook:
            tqdm = notebook_tqdm
        tqdm.trange = staticmethod(tqdm.trange)

# Generated at 2022-06-24 09:39:49.815044
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    assert list(trange(5, desc='Testing trange')) == [0, 1, 2, 3, 4]


if __name__ == "__main__":
    # Check that tqdm is importable and works in interactive mode
    from tqdm.auto import tqdm, trange
    with tqdm(iterable=range(10)) as t:
        for i in t:
            pass  # do nothing

    with trange(10) as t:
        for i in t:
            pass  # do nothing

    # Check that tqdm is importable and works in non-interactive mode
    import __main__
    __main__.__builtins__["_"] = lambda x: x  # monkey patch "gettext"

    from tqdm.auto import tqdm

# Generated at 2022-06-24 09:40:00.724610
# Unit test for function trange
def test_trange():
    """Test for all trange cases"""
    from .std import FormatCustomTextType, FormatCustomTextExt

# Generated at 2022-06-24 09:40:11.163506
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import __version__ as __version__std
    from .autonotebook import __version__ as __version__autonotebook
    from .asyncio import __version__ as __version__asyncio
    if sys.version_info[:2] >= (3, 6):
        assert trange(10).__class__ == asyncio_tqdm(10).__class__
        assert trange(10).__version__ == __version__asyncio
    else:
        assert trange(10).__class__ == notebook_tqdm(10).__class__
        assert trange(10).__version__ == __version__autonotebook

    assert tqdm(10).__class__ == trange(10).__class__

# Generated at 2022-06-24 09:40:13.281451
# Unit test for function trange
def test_trange():
    """Test trange function"""
    list(tqdm(trange(3)))
    list(tqdm(trange(3), ncols=70))
    with pytest.raises(TypeError):
        list(tqdm(trange(), ncols=70))

# Generated at 2022-06-24 09:40:16.734248
# Unit test for function trange
def test_trange():
    """Test function trange."""
    import sys
    from tqdm.auto import trange
    trange(3)
    trange(3, desc="Hello")
    trange(3, file=sys.stdout, desc="Hello")
    trange(3, file=sys.stderr)
    trange(3, file=sys.stderr, desc="Hello")


# Generated at 2022-06-24 09:40:18.380795
# Unit test for function trange
def test_trange():
    """Unit test for trange with tqdm"""
    for _ in trange(4):
        pass

# Generated at 2022-06-24 09:40:21.212355
# Unit test for function trange
def test_trange():
    """
    Test function trange
    """
    assert list(trange(5)) == list(range(5))

# Generated at 2022-06-24 09:40:31.987053
# Unit test for function trange
def test_trange():
    """ Test trange function """
    assert list(trange(2)) == [0, 1]
    assert list(trange(2, 2)) == [2]
    assert list(trange(2, 2, 2)) == [2]
    assert list(trange(2, -2)) == [2, 1, 0]
    assert list(trange(2, -2, -1)) == [2, 1, 0]
    assert tqdm.__name__ == "tqdm"

# Generated at 2022-06-24 09:40:37.178567
# Unit test for function trange
def test_trange():
    """
    Test function trange in tqdm/autonotebook/__init__.py
    """
    # Create mock arguments
    args = tuple([i for i in range(10)])
    kwargs = {}
    
    # Test trange
    trange(args, kwargs)

# Generated at 2022-06-24 09:40:38.275626
# Unit test for function trange
def test_trange():
    """ Test for function trange """
    list(trange(3))



# Generated at 2022-06-24 09:40:45.444837
# Unit test for function trange
def test_trange():
    """ Test trange """
    # Test basic usage
    list(trange(3))  # noqa: F841
    # Test reset
    r = trange(3, desc='A', leave=True)
    next(r)  # noqa: F841
    r.reset()
    list(r)  # noqa: F841
    # Test closing
    r = trange(3, desc='B', leave=True)
    r.close()
    list(r)  # noqa: F841
    # Test incorrect closing
    r = trange(3, desc='C', leave=True)
    next(r)  # noqa: F841
    r.close()  # Too early
    list(r)  # noqa: F841
    # Test automatic closing
    r = tr

# Generated at 2022-06-24 09:40:52.924829
# Unit test for function trange
def test_trange():
    """
    Unit test for trange()
    """
    from .std import tqdm_template  # pylint: disable=import-outside-toplevel
    assert list(trange(0)) == list(range(0))
    assert list(trange(1, 0)) == list(range(1, 0))
    assert list(trange(0, 10, 3)) == list(range(0, 10, 3))
    assert list(trange(10, 0, -3)) == list(range(10, 0, -3))
    assert list(trange(0, 10, -3)) == [0] * 3
    assert list(trange(0, 10, step=3)) == list(range(0, 10, 3))
    assert list(trange(0, 10, 0)) == [0] * 10

   

# Generated at 2022-06-24 09:40:55.486770
# Unit test for function trange
def test_trange():
    """
    Tests the function trange by asserting that the output is the
    same as the native range function.
    """
    assert list(trange(4)) == list(range(4))



# Generated at 2022-06-24 09:41:01.833040
# Unit test for function trange
def test_trange():
    """Test for `tqdm.auto.trange`"""
    from .std import trange
    from .utils import _range
    try:
        from inspect import signature  # only available in Python3
    except ImportError:
        return

    tr = trange(len(signature(trange).parameters))
    for i, (v1, v2) in enumerate(zip(tr, _range(13))):
        assert v1 == v2, (v1, v2, i)


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:41:06.049903
# Unit test for function trange
def test_trange():
    assert list(trange(10)) == list(range(10))
    assert list(trange(0)) == list(range(0))
    assert list(trange(1)) == list(range(1))
    assert list(trange(-1)) == list(range(-1))

# Generated at 2022-06-24 09:41:07.852800
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    for _ in trange(4, 0, -0.5):
        pass

# Generated at 2022-06-24 09:41:13.161253
# Unit test for function trange
def test_trange():
    """ Test trange """
    from .std import tqdm
    from .utils import StringIO

    for n in (0, 1, 5, 10):
        for v in (False, None, True):
            with StringIO() as f:
                for _ in trange(n, file=f, disable=v):
                    break
                f.seek(0)
                assert tqdm.format_sizeof(f.getvalue()) <= 100

# Generated at 2022-06-24 09:41:22.339889
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange and tqdm.
    """
    from .compat import StringIO
    from .utils import _term_move_up
    from .std import tqdm

    with StringIO() as our_file:
        for _ in tqdm(range(4), file=our_file):
            our_file.write("test\n")
        our_file.seek(0)

# Generated at 2022-06-24 09:41:34.215221
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    import os
    import shutil
    import tempfile
    tmp = tempfile.mkdtemp()
    tqdm_exe = os.path.join(tmp, 'tqdm')

# Generated at 2022-06-24 09:41:38.073822
# Unit test for function trange
def test_trange():
    """Tests for `tqdm.auto.trange()`"""
    from .tqdm import trange
    for i in trange([2, 3, 5, 7, 11]):
        assert i in [2, 3, 5, 7, 11]
    for _ in trange(3, 4, 3, .1):
        pass
    assert trange(3, 3, 4, .1).n == 0
    assert trange(3, 3, -1, .1).n == 0
    assert trange(3, 3, 0, .1).n == 0
    with trange(3, 3, -1, .01) as t:
        assert t.n == 0
        assert t.update() == 0

# Generated at 2022-06-24 09:41:42.611220
# Unit test for function trange
def test_trange():
    """Test for trange function"""
    for _ in trange(4):
        pass
    for _ in trange(2, 4):
        pass
    for _ in trange(2, 4, 1):
        pass

# Generated at 2022-06-24 09:41:45.428625
# Unit test for function trange
def test_trange():
    """Simple unit test for `tqdm.auto.trange`"""
    assert list(trange(10)) == list(range(10))
    assert list(trange(1)) == list(range(1))
    assert list(trange(0)) == list(range(0))
    assert list(trange(-1)) == list(range(-1))
    assert list(trange(10, 0, -1)) == list(range(10, 0, -1))

# Generated at 2022-06-24 09:41:47.176609
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from .std import tqdm

    assert trange(5) == tqdm(range(5))



# Generated at 2022-06-24 09:41:50.210361
# Unit test for function trange
def test_trange():
    from .std import trange
    for _ in trange(4):
        pass

# Generated at 2022-06-24 09:41:54.097981
# Unit test for function trange
def test_trange():
    from .std import trange
    from .utils import FormatStub
    with FormatStub() as fs:
        list(trange(3))
    assert fs.n == 3
    assert fs._instances == []

# Generated at 2022-06-24 09:41:57.248644
# Unit test for function trange
def test_trange():
    """
    Test function trange().
    """
    total = 1000000
    res = list(trange(total))
    assert len(res) == total
    assert res[-1] == total - 1

# Generated at 2022-06-24 09:42:02.658095
# Unit test for function trange
def test_trange():
    "Run trange unit test"
    from .std import tqdm

    import sys
    if sys.version_info[:2] <= (3, 5):  # pragma: no cover
        for _ in trange(1, ascii=True, file=sys.stderr):
            pass
        for _ in trange(1, ascii=True, file=sys.stdout):
            pass
        try:
            for _ in trange(1, ascii=True, file=sys.stdin):
                pass
        except AttributeError:
            pass
    else:
        for _ in trange(1, ascii=True):
            pass

# Generated at 2022-06-24 09:42:05.544084
# Unit test for function trange
def test_trange():
    """Run trange."""
    list(trange(3))


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:42:10.803454
# Unit test for function trange
def test_trange():
    """Test that trange works as expected"""
    from ._utils import _term_move_up
    sys.stderr.flush()  # to avoid pytest's buffered output
    trange(5).cursor._n = 5
    trange(5).close()
    sys.stderr.flush()
    sys.stderr.write(_term_move_up())  # clean up
    sys.stderr.flush()

# Generated at 2022-06-24 09:42:12.242679
# Unit test for function trange
def test_trange():
    """Test for trange"""
    for _ in trange(100):
        pass



# Generated at 2022-06-24 09:42:15.828421
# Unit test for function trange
def test_trange():
    """Test for function `trange`"""
    from ._utils.compat import range  # noqa

    assert list(trange(0)) == []
    assert list(trange(1)) == [0]
    assert list(trange(2, 3)) == [2]
    assert list(trange(4)) == [0, 1, 2, 3]

# Generated at 2022-06-24 09:42:18.715080
# Unit test for function trange
def test_trange():
    import sys
    if sys.version_info[:2] < (3, 6):
        assert tqdm is notebook_tqdm
        assert trange is notebook_trange
    else:
        assert tqdm is asyncio_tqdm
        assert trange is tqdm

# Generated at 2022-06-24 09:42:28.932216
# Unit test for function trange
def test_trange():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", TqdmExperimentalWarning)
        # If running in notebook, test tqdm() too
        try:
            from tqdm.autonotebook import tnrange, tqdm
            trange = tnrange
            has_tn = True
        except ImportError:
            has_tn = False

    # Check basic-usage
    assert sum(trange(3)) == 3, "basic-usage"

    if has_tn:
        # Check basic-usage
        assert sum(tqdm(range(3))) == 3, "basic-usage w/ tqdm()"

    # Check that trange() works exactly like tqdm.
    for i in trange(4):
        pass

# Generated at 2022-06-24 09:42:31.150671
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    from tqdm.auto import trange

    for _ in trange(10, desc='tqdm'):
        pass

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:42:33.053747
# Unit test for function trange
def test_trange():
    list(trange(5))
    assert True

# Generated at 2022-06-24 09:42:40.524340
# Unit test for function trange
def test_trange():
    """Test function ``trange``."""
    # Test function call
    trange(10)
    trange(1, 11)
    trange(1, 11, 2)
    with trange(10) as t:
        for _ in trange(9):
            t.update(1)

    # Test type output
    assert isinstance(trange(10), tqdm)
    assert isinstance(trange(1, 11), tqdm)
    assert isinstance(trange(1, 11, 2), tqdm)
    with trange(10) as t:
        assert isinstance(t, tqdm)



# Generated at 2022-06-24 09:42:44.551077
# Unit test for function trange
def test_trange():
    import time
    try:
        time.monotonic()
    except AttributeError:
        # Skipping trange test on Python <3.3
        return
    with trange(10) as t:
        for i in t:
            time.sleep(0.1)

# Generated at 2022-06-24 09:42:47.176761
# Unit test for function trange
def test_trange():
    from tqdm.auto import trange
    from time import sleep

    for i in trange(10, desc='trange loop'):
        sleep(.01)

# Generated at 2022-06-24 09:42:54.788692
# Unit test for function trange
def test_trange():
    """Sanity tests for trange"""
    from .gui import tqdm as gui_tqdm

    # Test parameters
    A = list(range(3))
    if gui_tqdm is tqdm:  # pragma: no cover
        assert tqdm(A) is A
    else:  # pragma: no cover
        assert tqdm(A) != A
    assert tqdm(A)._instances is not None
    assert list(tqdm(A)) == A

    # Test nested trange/tqdm
    A = list(range(3))
    B = list(range(3))

    if gui_tqdm is tqdm:  # pragma: no cover
        assert tqdm(A) is A
        assert tqdm(B) is B
        assert tqdm

# Generated at 2022-06-24 09:42:56.975264
# Unit test for function trange
def test_trange():
    from .utils import _range

    for _ in trange(3):
        _range(10)



# Generated at 2022-06-24 09:42:59.610847
# Unit test for function trange
def test_trange():
    """Test function trange()."""
    from .utils import format_sizeof
    n = 100
    t = trange(n, miniters=10, ascii=True)
    for _ in t:
        t.set_postfix(n=format_sizeof(t.n))
    assert t._instances[t.id].n == n

# Generated at 2022-06-24 09:43:09.803619
# Unit test for function trange
def test_trange():
    """ Unit test for function trange """
    assert list(trange(4)) == [0, 1, 2, 3]
    assert list(trange(1, 5)) == [1, 2, 3, 4]
    assert list(trange(1, 5, 2)) == [1, 3]
    assert list(trange(1, 6, 2)) == [1, 3, 5]
    assert list(trange(5, -5, -2)) == [5, 3, 1, -1, -3]
    assert list(trange(5, -6, -2)) == [5, 3, 1, -1, -3, -5]
    assert list(trange(0, 4, 2)) == [0, 2]
    assert list(trange(0, 6, 2)) == [0, 2, 4]


# Generated at 2022-06-24 09:43:16.201678
# Unit test for function trange
def test_trange():
    """ Test for function trange """
    for _ in trange(1):
        x = ' '
    for _ in trange(0):
        x = ' '
    for _ in trange(1):
        print(1)
    for _ in trange(2):
        print(1)
    for _ in trange(3):
        print(1)
    for _ in trange(3):
        print(1)


# Generated at 2022-06-24 09:43:22.655163
# Unit test for function trange
def test_trange():
    """ Unit test for function trange """
    from .std import tqdm
    tqdm.write("Testing function trange...")
    if tqdm.__dict__['tqdm'] != tqdm or tqdm.__dict__['trange'] != trange:
        raise ValueError("tqdm.tqdm != tqdm.tqdm and tqdm.trange != tqdm.trange")
    if tqdm.__dict__['tqdm'] != tqdm.__dict__['trange']():
        raise ValueError("trange does not return the same tqdm instance.")



# Generated at 2022-06-24 09:43:28.514670
# Unit test for function trange
def test_trange():
    assert tuple(trange(4)) == tuple(range(4))
    assert tuple(trange(2, 3)) == tuple(range(2, 3))
    assert tuple(trange(3, 4, 0.1)) == tuple(range(3, 4, 0.1))

    assert tuple(trange(3, 4, 0.2, desc="foo")) == tuple(range(3, 4, 0.2))

# Generated at 2022-06-24 09:43:31.282942
# Unit test for function trange
def test_trange():
    """ Test to check if trange works as expected """
    with tqdm(total=10) as pbar:
        for _ in trange(10):
            pbar.update()

# Generated at 2022-06-24 09:43:34.410919
# Unit test for function trange
def test_trange():
    """ Test for trange """
    for i in trange(10):
        assert i in range(10)
    for i in trange(10, step=0.2):
        assert i in range(10)


# Generated at 2022-06-24 09:43:36.500575
# Unit test for function trange
def test_trange():
    """Test trange()"""
    from time import sleep
    with tqdm(total=10) as pbar:
        for _ in trange(10):
            sleep(.2)
            pbar.update()

# Generated at 2022-06-24 09:43:38.494081
# Unit test for function trange
def test_trange():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        a = list(trange(3))
    assert a == [0, 1, 2]

# Generated at 2022-06-24 09:43:45.575149
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .std import tqdm
    trange_test = trange(3, 4)
    tqdm_test = tqdm(range(3, 4))
    assert trange_test.__name__ == str(tqdm_test)
    for i, (j, k) in enumerate(zip(trange(3, 5), tqdm(range(3, 5)))):
        assert j == k
        assert i == k

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:43:51.899082
# Unit test for function trange
def test_trange():
    """
    >>> test_trange()
    """
    from .autonotebook import trange as notebook_trange
    from .asyncio import tqdm as asyncio_tqdm

    for _tqdm in trange(4, desc="main"), notebook_trange(4, desc="notebook"), \
            asyncio_tqdm(4, desc="asyncio"):
        for _ in _tqdm:
            pass


if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-24 09:43:54.762582
# Unit test for function trange
def test_trange():
    """
    >>> list(trange(5))
    [0, 1, 2, 3, 4]
    """
    pass

# Generated at 2022-06-24 09:43:58.898212
# Unit test for function trange
def test_trange():
    """test function trange"""
    total = 11
    with tqdm(total=total) as pbar:
        for _ in trange(total):
            pbar.update()


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:44:01.038125
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from tqdm.auto import trange
    for i in trange(10):
        pass

# Generated at 2022-06-24 09:44:04.294162
# Unit test for function trange
def test_trange():
    """Test for trange function"""
    for _ in trange(9, -1, -1):
        pass


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:44:05.694722
# Unit test for function trange
def test_trange():
    """Smoke test trange"""
    assert list(trange(3)) == [0, 1, 2]

# Generated at 2022-06-24 09:44:14.226202
# Unit test for function trange
def test_trange():
    for r in [trange, notebook_trange]:
        for l in [2, sys.maxsize]:
            for s in [0, 1, -1]:
                assert list(r(0, s, l)) == list(r(s, 0, l)) == []
                if s == 0 and l >= 2:
                    assert list(r(0, s, 2)) == [0]
                elif l == 2:
                    assert list(r(0, s, 2)) == [0, s]
                assert list(r(1, s, l)) == list(r(s, 1, l)) == [s]
                assert list(r(1, s, 1)) == list(r(s, 1, 1)) == []

# Generated at 2022-06-24 09:44:19.562157
# Unit test for function trange
def test_trange():
    from .std import tqdm_test_cases

    for _ in trange(1, 3):
        for kwargs in tqdm_test_cases():
            for instance in trange(1, 2, **kwargs):
                pass


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:44:21.494202
# Unit test for function trange
def test_trange():
    """Test the trange() function"""
    from .std import tqdm
    assert trange(10) == tqdm(range(10))

# Generated at 2022-06-24 09:44:28.702932
# Unit test for function trange
def test_trange():
    """Test trange"""
    n_list = [1, 2, 3, 4, 5]
    for n in n_list:
        trange(n, desc=str(n))
        trange(n, leave=True, desc=str(n))
        trange(n, leave=True, desc=str(n), bar_format='{l_bar}')
        trange(n, desc=str(n), bar_format='{l_bar}')

# Generated at 2022-06-24 09:44:38.493956
# Unit test for function trange
def test_trange():
    """Tests for function trange"""
    # Make sure tqdm is a class
    assert issubclass(tqdm, object)

    # Make sure values are correct
    for i in trange(3, leave=True):
        assert i in [0, 1, 2]
    assert i == 2

    # Make sure we can reset total
    for i in trange(3, leave=True):
        assert i in [0, 1, 2]
    trange(1, total=1)
    assert i == 2

    # Test for default value of leave
    for i in trange(3):
        assert i in [0, 1, 2]
    assert i == 2

    # Make sure we don't crash when doing from __main__ import tqdm
    # (this is only relevant for importing from __main__)

# Generated at 2022-06-24 09:44:47.637277
# Unit test for function trange
def test_trange():
    "Test trange function"
    import sys
    from .std import tqdm as std_tqdm
    from .autonotebook import tqdm as notebook_tqdm

    assert sys.getrefcount(std_tqdm) == sys.getrefcount(tqdm)

    with std_tqdm(total=10) as pbar:
        assert str(pbar) == "0/10"
        pbar.update()
        assert str(pbar) == "1/10"
        pbar.update(9)
        assert str(pbar) == "10/10"

    with std_tqdm(total=10, desc="A") as pbar:
        assert str(pbar) == "A: 0/10"


# Generated at 2022-06-24 09:44:53.731333
# Unit test for function trange
def test_trange():
    for _ in trange(4, leave=None):
        for _ in trange(4, leave=True):
            for _ in trange(4, leave=False):
                pass
    for _ in trange(4, leave=None):
        for _ in trange(4, leave=True):
            for _ in trange(4, leave=None):
                pass

if __name__ == "__main__":
    import nose
    nose.runmodule(argv=['-s', '--with-doctest'], exit=False)

# Generated at 2022-06-24 09:45:00.193548
# Unit test for function trange
def test_trange():
    """ test trange """
    assert list(trange(3)) == [0, 1, 2]
    assert list(trange(1, 3)) == [1, 2]
    assert list(trange(1, 3, 2)) == [1]
    assert list(trange(3, 1)) == []
    assert list(trange(3, 1, -2)) == [3]
    assert list(trange(3, 1, -1)) == [3, 2]


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:45:09.338930
# Unit test for function trange
def test_trange():
    try:
        import asyncio
    except ImportError:
        return

    async def coroutine1(n):
        for i in trange(n):
            j = i + n
            assert j
            await asyncio.sleep(0.01)
        return n

    async def coroutine2(n):
        arr = [1]
        for _ in trange(n, leave=True):
            assert arr == [1]
            await asyncio.sleep(0.01)

    loop = asyncio.get_event_loop()
    loop.run_until_complete(coroutine1(2))
    loop.run_until_complete(coroutine2(2))

    trange_ = trange
    trange = notebook_trange
    asyncio_tqdm.shutdown(ignore=True)



# Generated at 2022-06-24 09:45:19.445770
# Unit test for function trange
def test_trange():
    '''Unit test for function trange'''
    def mock_print(*args, **kwargs):
        pass

    # empty
    trange(0, 0, desc="empty")

    # simple
    out = []
    for _ in trange(4, desc="simple"):
        out += [None]
    assert len(out) == 4

    # without printing
    out = []
    with tqdm(desc="without printing", file=None,
              bar_format="{l_bar}{bar}|", disable=True) as t:
        for _ in t:
            out += [None]
    assert len(out) == 4
    assert not t.disable
    assert t.n == 4

    # ncols
    out = []

# Generated at 2022-06-24 09:45:20.643510
# Unit test for function trange
def test_trange():
    for _ in trange(4):
        pass
    for _ in trange(4, leave=False):
        pass

# Generated at 2022-06-24 09:45:27.788573
# Unit test for function trange
def test_trange():
    assert list(trange(0)) == []
    assert list(trange(1)) == [0]
    assert list(trange(2)) == [0, 1]
    assert list(trange(1, 3)) == [1, 2]
    assert list(trange(1, 1)) == []
    assert list(trange(1, 3, 2)) == [1]
    assert list(trange(3, 1, -1)) == [3, 2]
    assert list(trange(3, 1, -2)) == [3]


if __name__ == "__main__":
    from .main import main
    main()

# Generated at 2022-06-24 09:45:29.270036
# Unit test for function trange
def test_trange():
    """Test function trange"""
    assert list(trange(3)) == list(range(3))

# Generated at 2022-06-24 09:45:31.272097
# Unit test for function trange
def test_trange():
    """Test function `trange`"""
    assert list(trange(5)) == list(range(5))


if __name__ == "__main__":
    from pytest import main
    main([__file__])

# Generated at 2022-06-24 09:45:33.424495
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    for _ in trange(3, ascii=True):
        pass

# Generated at 2022-06-24 09:45:37.613253
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert trange(3) == list(range(3))

# Generated at 2022-06-24 09:45:41.857714
# Unit test for function trange
def test_trange():
    '''
    Tests trange() function and main class.
    '''
    from .std import tqdm

    with tqdm(total=10) as pbar:
        for i in trange(4, 8):
            assert pbar.n == i - 4  # Make sure i and pbar.n are the same
            pbar.update()

test_trange()

# Generated at 2022-06-24 09:45:52.069417
# Unit test for function trange
def test_trange():
    from .gui import tqdm_gui
    from .std import tqdm as std_tqdm

    n = 1000
    assert list(trange(10)) == list(range(10))
    try:
        import ipywidgets  # NOQA
        assert isinstance(tqdm(range(n), file=sys.stdout),
                          notebook_tqdm)
        assert isinstance(tqdm(range(n), file=sys.stdout, gui=True),
                          tqdm_gui)
        assert isinstance(tqdm(range(n), file=sys.stdout, gui=False),
                          std_tqdm)
    except Exception:
        pass
    assert isinstance(tqdm(range(n), file=sys.stdout),
                      std_tqdm)
