

# Generated at 2022-06-24 09:35:55.292134
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import tqdm
    from .utils import _term_move_up

    with tqdm(ncols=80,
              bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]") as t:
        stream, n_chars = t.fp.write, 0
        for i in trange(1, 7, desc="Loop"):
            n_chars += len(_term_move_up() + str(i))
            n_chars += stream(str(i) * i + '\n').count('\n')

        t.last_print_n = n_chars
        assert t.total == 6
        assert t.n == 6
        assert t.last_print

# Generated at 2022-06-24 09:36:00.595448
# Unit test for function trange
def test_trange():
    try:
        import numpy
    except ImportError:
        pass
    else:
        import numpy as np
        assert np.array(list(trange(10))).shape == (10, )

    # Test with generator
    assert sum(trange(2, 3)) == 5
    # Test with tuple
    assert sum(trange((2, 3))) == 5
    # Test with container
    assert sum(trange(x for x in (2, 3))) == 5
    # Test with iterable
    assert sum(trange(iter((2, 3)))) == 5
    # Test with infinite
    assert sum(trange(2, None)) == 2

    # Test range(0) is empty
    assert list(range(0)) == list(trange(0))

    # Integration test with `with tqdm(...) as t

# Generated at 2022-06-24 09:36:09.898801
# Unit test for function trange
def test_trange():
    """Test trange output"""
    from .utils import _decode_str
    from .std import format_interval

    # Test trange
    tr = trange(10)
    out = _decode_str(tr.write("\r%s" % (format_interval(tr.last_print_t),)))
    assert tr._inst_force_console or out == "  0%|          | 0/10 [00:00<?, ?it/s]\r  0%|          | 0/10 [00:00<?, ?it/s]"
    tr.close()

    tr = trange(10, desc="desc", leave=False)
    out = _decode_str(tr.write("\r%s" % (format_interval(tr.last_print_t),)))
    assert tr._inst_

# Generated at 2022-06-24 09:36:18.306823
# Unit test for function trange
def test_trange():
    """Test function trange"""
    # pylint: disable=protected-access
    tqdm._instances.clear()  # reset tqdm instances
    list(trange(3))
    assert tqdm._instances

    tqdm._instances.clear()
    list(trange(3, 4))
    assert tqdm._instances

    tqdm._instances.clear()
    list(trange(3, 4, 5))
    assert tqdm._instances

    tqdm._instances.clear()
    list(trange(3, 4, 5, 6))
    assert tqdm._instances



# Generated at 2022-06-24 09:36:24.619821
# Unit test for function trange
def test_trange():
    """Test function trange"""

    from .std import trange
    from .utils import format_sizeof
    from time import sleep

    with trange(10, desc='foobar', unit='B') as t:
        for i in t:
            t.set_postfix(ordered_dict={'i': i, 'hi': "hi", 'bye': "bye"})
            t.set_postfix(ordered_dict={'i': i, 'hi': "hi", 'bye': "bye"},
                          refresh=False)
            sleep(0.01)

    returned = [x ** 2 for x in trange(100, position=0)
                if x % 3 == 0]
    assert returned == [x ** 2 for x in range(100) if x % 3 == 0]


# Generated at 2022-06-24 09:36:33.812154
# Unit test for function trange
def test_trange():
    """Test function `trange`."""
    from ._utils import _range
    from numpy import allclose

    from tqdm import trange
    from tqdm._tqdm import FormatCustomText
    from .std import tqdm as std_tqdm

    for t in (trange, std_tqdm):
        for l1 in (0, 1, 5):
            for l2 in (0, 1, 5):
                for trial in _range(3):
                    r = t(l1, l2)
                    assert len(r) == max(l2 - l1, 0)
                    assert allclose(list(r), list(range(l1, l2)))

        for trial in _range(3):
            r = t(l1 + trial)
            assert len(r) == l1 + trial


# Generated at 2022-06-24 09:36:43.419556
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    # Test with use_auto_range=False
    with tqdm(total=0, disable=True) as pbar:
        for _ in pbar(list(range(10))):
            break
        pbar.update()
        assert (pbar.pos == 1)

    # Test with use_auto_range=True
    with tqdm(disable=True) as pbar:
        for _ in pbar(list(range(10))):
            break
        pbar.update()
        assert (pbar.total == 10)
        assert (pbar.pos == 1)

    # Test with use_auto_range=True and total=0

# Generated at 2022-06-24 09:36:45.155895
# Unit test for function trange
def test_trange():
    """Run doctests on trange"""
    import doctest
    doctest.run_docstring_examples(trange, globals(), verbose=True)

# Generated at 2022-06-24 09:36:47.772493
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    assert list(trange(0)) == []
    assert list(trange(1)) == [0]
    assert list(trange(10)) == list(range(10))



# Generated at 2022-06-24 09:36:54.501137
# Unit test for function trange
def test_trange():
    """
    Test tqdm trange function
    """
    from .__main__ import _test_argv
    from .std import tqdm

    with tqdm(total=2) as t:
        assert t == trange(2)
        t.close()

    # Test trange with argv
    for argv_ in [["--no-bar"], ["--no-bar", "0"], []]:
        with _test_argv(argv_):
            with tqdm(total=1) as t:
                assert t == trange(1)
                t.close()

# Generated at 2022-06-24 09:36:56.416500
# Unit test for function trange
def test_trange():
    "Test function trange"
    l = sum(trange(10**8))
    assert l == sum(range(10**8))

# Generated at 2022-06-24 09:37:08.924945
# Unit test for function trange
def test_trange():
    """
    Unit test for function `trange`

    Run from the root folder as `python -m tqdm.auto`.
    """
    from .autonotebook import tnrange as notebook_tnrange
    from .asyncio import tnrange as asyncio_tnrange
    from .std import tnrange as std_tnrange

    if notebook_tnrange != std_tnrange:
        class _tnrange(notebook_tnrange, asyncio_tnrange):  # pylint: disable=inconsistent-mro
            pass
    else:
        _tnrange = asyncio_tnrange

    # Basic check
    assert isinstance(trange(3), _tnrange)

    # Wrap over tqdm
    t = trange(3, leave=False)
    assert t._leave_once

# Generated at 2022-06-24 09:37:13.497983
# Unit test for function trange
def test_trange():
    from .utils import _range

    for i in trange(5):
        assert i in _range(5)
    for i in trange(5, 8):
        assert i in _range(5, 8)
    for i in trange(5, 8, 2):
        assert i in _range(5, 8, 2)

# Generated at 2022-06-24 09:37:14.308022
# Unit test for function trange
def test_trange():
    for i in trange(4):
        pass
    assert i == 3


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:37:15.999466
# Unit test for function trange
def test_trange():
    """
    Smoke test for `trange` function.
    """
    for _ in trange(1):
        pass

    for _ in trange(1, 1):
        pass

    for _ in trange(1, 1, 1):
        pass

# Generated at 2022-06-24 09:37:26.731124
# Unit test for function trange
def test_trange():
    import itertools

    for i in trange(4, leave=True):
        for j in trange(4, leave=True):
            pass
    for i in trange(4, leave=False):
        for j in trange(4, leave=False):
            pass
    for i in trange(4, leave=True):
        for j in trange(4, leave=False):
            pass
    for i in trange(4, leave=False):
        for j in trange(4, leave=True):
            pass
    for i in trange(itertools.repeat(True, 4), leave=True):
        for j in trange(itertools.repeat(True, 4), leave=True):
            pass

# Generated at 2022-06-24 09:37:32.314441
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .utils import _range

    trange_min = -5
    trange_max = 5
    for _ in trange(_range(trange_min, trange_max)):
        pass

    for _ in trange(_range(trange_min, trange_max), desc="trange"):
        pass

# Generated at 2022-06-24 09:37:35.954795
# Unit test for function trange
def test_trange():
    """Test function trange"""
    assert trange(5) == list(range(5))
    assert list(trange(5)) == list(range(5))

# Generated at 2022-06-24 09:37:41.901465
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from .std import format_interval
    from .utils import format_sizeof

    # Get tqdm's properties (for test use only)
    from .std import format_meter, status_printer
    format_meter._instances.clear()  # pylint: disable=protected-access
    fmt = format_meter(0, 0, 0, 0, 0, 0, 0)
    sp = status_printer(0)
    # Test format_interval


# Generated at 2022-06-24 09:37:48.267338
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    Simple unit test for function `trange`.
    """
    from time import sleep
    total = 1000
    with tqdm(total=total) as pbar:
        for i in trange(total):
            sleep(0.01)
            pbar.update()

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:37:49.836138
# Unit test for function trange
def test_trange():
    for _ in trange(1, 15, 3):
        pass

# Generated at 2022-06-24 09:37:53.349784
# Unit test for function trange
def test_trange():
    """Simple sanity check for trange (depends on internal iteration logic)."""
    from .asyncio import trange

    assert len(list(trange(1000))) == 1000
    assert len(list(trange(1, 1000))) == 1000
    assert len(list(trange(1, 1000, 3))) == 334

# Generated at 2022-06-24 09:38:04.629375
# Unit test for function trange
def test_trange():
    """Test the function trange"""
    from .std import _supports_unicode
    from .std import format_sizeof
    import sys
    import time

    for _ in trange(10, desc='Test', unit='it'):
        time.sleep(0.01)
    for _ in trange(10, desc='Test', unit='it', leave=True):
        time.sleep(0.01)

    for _ in trange(10, desc='Test', unit='it', ncols=110):
        time.sleep(0.01)
    for _ in trange(10, desc='Test', unit='it', leave=True, ncols=110):
        time.sleep(0.01)

    size = int(1e3)

# Generated at 2022-06-24 09:38:09.290288
# Unit test for function trange
def test_trange():
    """Test function trange (function wrapper)"""
    with tqdm(total=42) as pbar:
        for _ in trange(7):
            pbar.set_description("description")
            pbar.update()

    # Checking that trange is a function
    assert isinstance(trange, type(lambda: 0))

# Generated at 2022-06-24 09:38:17.263878
# Unit test for function trange
def test_trange():
    """
    Assert that tqdm(range) works in async/sync modes.
    """

# Generated at 2022-06-24 09:38:21.945767
# Unit test for function trange
def test_trange():
    """ Test trange() """
    from ._utils import _range  # Test import
    # Test argument unpacking
    assert list(trange([1, 2, 3])) == list(trange(1, 3)) == list(_range(1, 3))


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:38:29.916056
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    import sys
    from .std import _range
    from .std import tqdm

    total = 25
    desc = 'description'
    dynamic_ncols = True

    # Assert `_range` returns a range or generator for unit tests
    assert type(_range(total)) == type(range(total))
    assert (next(tqdm(_range(total), desc=desc, ncols=dynamic_ncols)) ==
            next(_range(total)))

    # Assert `trange` returns a `tqdm` instance
    assert type(trange(total, desc=desc, ncols=dynamic_ncols)) == type(
        tqdm(total=total, desc=desc, ncols=dynamic_ncols))

    # Assert `tr

# Generated at 2022-06-24 09:38:41.665139
# Unit test for function trange
def test_trange():
    """Test trange utility"""
    # Use truncate=True to avoid testing notebook
    rng = trange(10, desc='1st loop', leave=True,
                 ascii=True, position=0, bar_format='{desc}: {percentage:3.0f}%|{bar}|',
                 # notebook=False,
                 )


# Generated at 2022-06-24 09:38:44.351944
# Unit test for function trange
def test_trange():
    """Test function trange"""
    with trange(2) as t:
        t.update(1)

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:38:50.433718
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        from .autonotebook import tqdm as notebook_tqdm
        from .autonotebook import trange as notebook_trange

    assert trange(0, 5) == list(tqdm(range(0, 5)))
    assert trange(0, 5) == list(notebook_trange(0, 5))



# Generated at 2022-06-24 09:38:53.377234
# Unit test for function trange
def test_trange():
    """Test function `trange`."""
    with tqdm(total=1) as pbar:
        for i in trange(10):
            assert i in range(10)
            pbar.update()

# Generated at 2022-06-24 09:38:59.365539
# Unit test for function trange
def test_trange():
    """
    Simple test for function trange
    """
    with tqdm(total=3) as pbar:
        assert pbar.total == 3
        assert len(pbar) == 3
        assert pbar.n == 0
        pbar.update()
        pbar.update()
        pbar.update()
        assert pbar.n == 3
        assert pbar.n == pbar.total
        assert pbar.n == len(pbar)

# Generated at 2022-06-24 09:39:03.469583
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import _range  # pylint: disable=import-outside-toplevel
    list(trange(3))
    list(tqdm(_range(3)))
    assert tqdm(["a", "b", "c"]) == notebook_tqdm(["a", "b", "c"])
    assert list(trange(3)) == list(notebook_trange(3))

# Generated at 2022-06-24 09:39:14.335788
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from ._utils import _decode_as_str
    from ._tqdm import TqdmTypeError

    assert tqdm is asyncio_tqdm

    for _range in [
        list(range(3)),
        list(range(3)),
        list(range(3)),
        (i for i in range(3)),
        (i for i in range(3)),
    ]:
        assert list(trange(3)) == list(_range)
        assert list(trange(3, 0)) == list(reversed(_range))
        assert list(trange(3, 0, -1)) == list(reversed(_range))
        assert list(trange(3, 0, 1)) == list(_range)

# Generated at 2022-06-24 09:39:22.426787
# Unit test for function trange
def test_trange():
    from .std import TqdmBase
    from .std import tnrange
    from .std import tqdm_notebook
    for t in [trange, tqdm.trange, tqdm.std.trange, tqdm.std.tqdm.trange,
              notebook_trange, tqdm_notebook.trange, tnrange]:
        assert t is not tnrange
        assert isinstance(t(range(3)), TqdmBase)
        assert isinstance(t(range(3), leave=True), TqdmBase)

# Generated at 2022-06-24 09:39:23.319891
# Unit test for function trange
def test_trange():
    """ Sanity test """
    trange(7, ncols=20)

# Generated at 2022-06-24 09:39:34.754986
# Unit test for function trange
def test_trange():
    from .auto import trange
    from .compat import StringIO
    io = StringIO()
    trange(2, file=io)
    assert io.getvalue() == '  0%|          | 0/2 [00:00<?, ?it/s]\n 50%|█████     | 1/2 [00:00<00:00, ?it/s]\n100%|██████████| 2/2 [00:00<00:00, ?it/s]\n'  # noqa
    trange(0, 2, file=io)
    assert io.getvalue().endswith('\n')

if __name__ == "__main__":
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        import nose