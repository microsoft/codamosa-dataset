

# Generated at 2022-06-24 09:35:56.467484
# Unit test for function trange
def test_trange():
    """Test trange"""
    import time
    import sys

    try:
        old_get_ipython  # noqa
    except NameError:
        ipython_mode = False
    else:
        ipython_mode = True

    # if we're not in IPython, stdout/stderr are not redirected,
    #  we use a blackhole instead
    bh = open(os.devnull, 'w')
    stderr = bh
    stdout = bh
    if ipython_mode:
        from IPython.core import page
        import StringIO
        stderr = stdout = StringIO.StringIO()
        orig_stdout, orig_stderr = sys.stdout, sys.stderr
        sys.stdout = page.page = stdout
        sys.stderr = st

# Generated at 2022-06-24 09:36:04.152597
# Unit test for function trange
def test_trange():
    """Test the trange function by checking the output against the known output
    from the tqdm function.
    """
    from .std import tqdm
    for i in trange(2):
        for j in trange(3):
            for k in trange(4):
                pass

    for i in tqdm(range(2)):
        for j in tqdm(range(3)):
            for k in tqdm(range(4)):
                pass



# Generated at 2022-06-24 09:36:09.560841
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    for i in trange(4):
        pass
    for i in trange(4, 0):
        pass
    for i in trange(0, -4, -1):
        pass
    for i in trange(4):
        pass
    for i in trange(4, 0):
        pass
    for i in trange(0, -4, -1):
        pass



# Generated at 2022-06-24 09:36:12.085808
# Unit test for function trange
def test_trange():
    """Run doctests on trange"""
    import doctest
    doctest.testmod(tqdm.tqdm.tqdm_gui)

# Generated at 2022-06-24 09:36:13.628850
# Unit test for function trange
def test_trange():
    assert sum(trange(1000000)) == 499999500000


# Generated at 2022-06-24 09:36:21.621020
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from random import random
    from time import sleep
    from .utils import format_sizeof

    sleep_duration = 0.1

    total = 5

    sleep_sum = 0.0
    for _ in trange(total, file=sys.stdout):
        sleep(sleep_duration)
        sleep_sum += sleep_duration

    for _ in trange(total, file=sys.stderr):
        sleep(sleep_duration)
        sleep_sum += sleep_duration

    try:
        import io

        # make sure trange works with io.StringIO
        f = io.StringIO()
        for _ in trange(total, file=f):
            sleep(sleep_duration)
            sleep_sum += sleep_duration
    except ImportError:
        pass

    assert format_size

# Generated at 2022-06-24 09:36:27.142691
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from tqdm import trange

    with trange(100) as t:
        for i in t:
            t.set_description("test_trange")
            if i > 50:
                t.set_postfix(j=i)
            assert i <= 100

    with trange(10) as t:
        for i in t:
            t.update()
            t.set_description(str((i, i + 1)))
            assert i <= 10

    with trange(100, desc='Testing desc', leave=False) as t:
        t.set_description("Test: desc")
        t.set_postfix(j=1)
        for i in t:
            assert i <= 100


# Generated at 2022-06-24 09:36:29.276804
# Unit test for function trange
def test_trange():
    with warnings.catch_warnings(record=True) as w:
        trange(4)
    assert len(w) == 0

# Generated at 2022-06-24 09:36:33.182163
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    with tqdm(total=10) as pbar:
        k = 0
        for _ in trange(10):
            pbar.update()
            k += 1
        assert k == 10

if __name__ == "__main__":
    # Test
    test_trange()

# Generated at 2022-06-24 09:36:36.044778
# Unit test for function trange
def test_trange():
    from tempfile import TemporaryFile
    with TemporaryFile('w+') as f:
        with tqdm(total=len('abc'), file=f) as t:
            for c in 'abc':
                t.update()

# Generated at 2022-06-24 09:36:42.677160
# Unit test for function trange
def test_trange():
    """
    if __name__ == '__main__':
        trange1 = tqdm.auto.tqdm(range(10), desc='trange', unit='it')
        trange2 = trange(10, desc='trange', unit='it')
        for i, j in zip(trange1, trange2):
            pass
        assert trange1.n == 0
        assert trange2.n == 0
        assert trange1._location == 'loc'
        assert trange2._location == 'loc'
    """

# Generated at 2022-06-24 09:36:46.294716
# Unit test for function trange
def test_trange():
    """ Test on function trange """
    import contextlib
    # with closing example
    with contextlib.closing(trange(5, desc=None)) as t:
        for i in t:
            pass
    # without closing example
    t = trange(5, desc=None)
    for i in range(5):
        assert next(t) is None
    t.close()

# Generated at 2022-06-24 09:36:48.004129
# Unit test for function trange
def test_trange():
    """Test function trange"""
    for _ in trange(3, desc="desc", ascii=True):
        break


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:36:51.919170
# Unit test for function trange
def test_trange():
    """test function trange"""
    from .std import tqdm
    with tqdm(total=10) as t:
        for _ in trange(10):
            t.update()

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:37:02.037604
# Unit test for function trange
def test_trange():
    assert list(trange(10)) == list(range(10))[:]
    assert list(trange(1, 10)) == list(range(1, 10))[:]
    assert list(trange(0, 10, 2)) == list(range(0, 10, 2))[:]
    assert list(trange(10, 0, -2)) == list(range(10, 0, -2))[:]
    assert list(trange(1, 10, -1)) == list(range(1, 10, -1))[:]
    assert list(trange(10, 0, -1)) == list(range(10, 0, -1))[:]
    assert list(trange(100, desc="longloop")) == list(range(100))[:]

# Generated at 2022-06-24 09:37:10.829416
# Unit test for function trange
def test_trange():
    "Test the function `trange`."
    import nose.tools as nt
    import inspect

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        from .autonotebook import trange as notebook_trange

    # Test trange
    nt.assert_raises(TypeError, trange)  # Missing required argument
    nt.assert_equal(inspect.getsource(trange), inspect.getsource(notebook_trange))
    for n in [10, 100, 1000, 10000]:
        nt.assert_equal(sum(trange(n)), sum(range(n)))



# Generated at 2022-06-24 09:37:18.643142
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    from ._utils import _term_move_up
    from .std import tqdm
    from .utils import format_sizeof, format_interval

    # Return True iff all elements in iterable are equal
    def all_equal(iterable):
        """
        Return True iff all elements in iterable are equal.
        """
        g = iter(iterable)
        try:
            g0 = next(g)
        except StopIteration:
            return True
        return all(tqdm.compat.eq(gi, g0) for gi in g)

    # Check trange is same as tqdm
    total = 10000
    with tqdm(total=total) as t:
        for i in trange(total):
            t.update()

# Generated at 2022-06-24 09:37:23.018984
# Unit test for function trange
def test_trange():
    with tqdm(total=4) as pbar:
        for _ in trange(4):
            pbar.update()
    assert pbar.n == pbar.total, "All iterations iterated"

# Generated at 2022-06-24 09:37:30.805932
# Unit test for function trange
def test_trange():
    """Testing trange function"""
    from .std import BAR_DESC, BAR_ASCII, BAR_CURSES, BAR_ANIMATED
    for bar in [BAR_DESC, BAR_ASCII, BAR_CURSES, BAR_ANIMATED]:
        with tqdm(bar_format=bar) as t:
            for i in trange(8):
                t.update()
        with tqdm(total=8, bar_format=bar) as t:
            for i in trange(8):
                t.update()
        with tqdm(bar_format=bar) as t:
            for i in trange(8):
                t.update()

# Generated at 2022-06-24 09:37:40.876542
# Unit test for function trange
def test_trange():
    import optparse
    parser = optparse.OptionParser()
    parser.add_option("--unit-test", action="store_true", dest="unittest")
    options, args = parser.parse_args()
    if options.unittest:
        # needs `python tqdm/auto.py --unit-test`, or
        # `import tqdm; tqdm.auto.test_trange()`
        import re

        rng = trange(10)
        len(rng)  # force len to raise if possible
        assert len(list(rng)) == 10

# Generated at 2022-06-24 09:37:52.470606
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange().
    """
    from ._tqdm import _term_move_up
    # Test trange()
    with tqdm(total=3) as t:
        assert len(t) == 3
        assert t.total == 3
        assert t.n == 0
        t.update()  # no effect if position is specified
        t.update(0)  # no effect if position is specified
        assert t.n == 0
        assert '\r' in str(t)
        assert '\r' + _term_move_up() in t.refresh()
        for n in [1, 1, 1]:
            assert t.n == n - 1
            t.update(1)
        assert t.n == 3
        assert t.n == t.total
        t.update()

# Generated at 2022-06-24 09:38:03.820558
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    import time
    import numpy as np
    from .utils import format_sizeof, format_timespan

    # Basic trange usage
    with trange(7) as trange_t:
        for _ in trange_t:
            time.sleep(0.1)

    # Advanced usage
    n = 1000 * 1000 * 10
    with trange(n) as trange_t:
        for i in trange_t:
            a = np.cos(i) ** 2
            b = -np.sin(i) / 2
            c = a + b

    # Custom usage
    times = [0.002, 0.3, 0.05, 0.001, 0.002, 0.1, 0.0001]

# Generated at 2022-06-24 09:38:09.170025
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Test function trange"""
    from ._utils import _supports_unicode  # pylint: disable=import-error
    from ._tqdm_gui import _version_check  # pylint: disable=import-error

    _version_check()

    # Simple test
    with trange(10) as t:
        for i in t:
            pass

    # Unicode support
    _supports_unicode = _supports_unicode()
    unicode_desc = "utf8: {f}, {b}, {c}, {d}"
    if _supports_unicode:
        unicode_desc = unicode_desc.format(
            f="\u23f2", b="\u23f3", c="\u2713", d="\u2501"
        )


# Generated at 2022-06-24 09:38:17.177763
# Unit test for function trange
def test_trange():  # pragma: no cover
    import time

    list(trange(5))
    list(trange(5, desc='desc'))
    list(trange(5, desc='desc', ncols=50))

    try:
        import pandas as pd
    except ImportError:
        pass
    else:
        list(trange(pd.DataFrame([]), total=5))
        list(trange(pd.DataFrame([]), total=5, desc='desc'))
        list(trange(pd.Series([]), total=5))
        list(trange(pd.Series([]), total=5, desc='desc'))

    with trange(5) as t:
        for i in t:
            t.set_description("desc %i" % i)
            t.refresh()  #

# Generated at 2022-06-24 09:38:22.265995
# Unit test for function trange
def test_trange():
    """
    Test whether trange is the same as tqdm on a range.
    """
    import numpy as np

    trange_test = list(map(int, trange(100)))
    tqdm_test = list(map(int, tqdm(np.arange(100))))
    assert trange_test == tqdm_test

# Generated at 2022-06-24 09:38:23.859412
# Unit test for function trange
def test_trange():
    for i in trange(4):
        x = i ** 2

# Generated at 2022-06-24 09:38:25.878947
# Unit test for function trange
def test_trange():
    """Test trange function"""
    list(trange(3))
    for _ in trange(3, leave=True):
        pass


# Generated at 2022-06-24 09:38:32.595737
# Unit test for function trange
def test_trange():
    """Test trage function"""

    # capture output
    from io import StringIO
    import sys
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()

    # call trange
    trange(10)

    # save and restore stdout
    sys.stdout = old_stdout
    out = mystdout.getvalue()

    # check if out contains trange output
    assert out.startswith('  0%|')

# Generated at 2022-06-24 09:38:37.746914
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    for i in trange(10):
        assert i in range(10)

if __name__ == "__main__":
    from .tests import test_trange  # pylint: disable=no-name-in-module
    test_trange()

# Generated at 2022-06-24 09:38:48.105805
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    assert list(trange(0)) == []
    assert list(trange(0, 0)) == []
    assert list(trange(3)) == [0, 1, 2]
    assert list(trange(2, 5)) == [2, 3, 4]
    assert list(trange(2, 15, 3)) == [2, 5, 8, 11, 14]
    assert list(trange(15, 2, -3)) == [15, 12, 9, 6, 3]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        assert list(trange(3, 0)) == []
        assert list(trange(15, 2)) == []

# Generated at 2022-06-24 09:38:52.580157
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    from .std import tqdm
    a = trange(0, 1)
    b = tqdm(range(0, 1))
    assert a, b

# Generated at 2022-06-24 09:39:01.766449
# Unit test for function trange
def test_trange():
    """Smoke test"""
    list(trange(3))


# Check if interactive environment, ignore IPython < 0.12
# https://github.com/tqdm/tqdm/issues/412
if notebook_tqdm is not std_tqdm:
    try:
        from IPython import get_ipython  # pylint: disable=import-error
        from IPython.terminal.interactiveshell import TerminalInteractiveShell
        from IPython.core.getipython import get_ipython_module
        ip = get_ipython()
        if (isinstance(ip, TerminalInteractiveShell)
                and get_ipython_module().__version__ >= '0.12'):
            tqdm = notebook_tqdm
            trange = notebook_trange
    except Exception:
        pass

# Generated at 2022-06-24 09:39:03.652236
# Unit test for function trange
def test_trange():
    """Simple sanity check."""
    assert 0 not in trange(5, 0, -1)

# Generated at 2022-06-24 09:39:14.382754
# Unit test for function trange
def test_trange():
    "Test function `trange` (which should be same as tqdm(range(...))"
    from .autonotebook import tqdm as _tqdm

    for _ in trange(4):
        for _ in trange(3, 4, 2):
            for _ in trange(3, 4, 0.2):
                if _tqdm == notebook_tqdm:
                    raise RuntimeError

    assert sys.version_info[:2] < (3, 6) or trange is tqdm

    try:
        trange(3, 0, 0.2)
    except ValueError:
        pass
    else:
        raise RuntimeError

    try:
        trange(3, 0, -0.2)
    except ValueError:
        pass
    else:
        raise RuntimeError

# Generated at 2022-06-24 09:39:16.134381
# Unit test for function trange
def test_trange():
    from .std import tqdm, trange
    assert tqdm(range(5)) == trange(5)

# Generated at 2022-06-24 09:39:25.898215
# Unit test for function trange
def test_trange():
    """Test function trange"""
    import sys
    if not hasattr(sys, 'argv'):
        sys.argv = ['tqdm.py']

    # Test function
    assert list(trange(0)) == []
    assert list(trange(1)) == [0]
    assert list(trange(10)) == list(range(10))
    assert list(trange(100)) == list(range(100))

    # Test slice
    assert list(trange(10)[1:5]) == list(range(1, 5))

    # Test max-len
    try:
        max_len = tqdm.get_instances().max_len
    except AttributeError:  # not all compilers support this
        max_len = None

# Generated at 2022-06-24 09:39:28.447362
# Unit test for function trange
def test_trange():
    """Test `tqdm.auto.trange`"""
    from tqdm.auto import trange
    return trange(2, 3)

# Generated at 2022-06-24 09:39:36.904228
# Unit test for function trange
def test_trange():
    import unittest
    from .autonotebook import trange

    class TestTrange(unittest.TestCase):
        """Test trange function in autonotebook.py"""

        def test_default_kwargs(self):
            """test trange with default kwargs"""
            with trange(1) as t:
                self.assertIsInstance(t, trange)
                self.assertEqual(t.miniters, 1)
                self.assertEqual(t.mininterval, 0)
                self.assertEqual(t.maxinterval, 10.0)
                self.assertEqual(t.desc, None)
                self.assertEqual(t.leave, True)
                self.assertEqual(t.display_fmt, None)

# Generated at 2022-06-24 09:39:38.460566
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Run unit tests for trange on module import."""
    from .tests import test_trange
    test_trange()

# Generated at 2022-06-24 09:39:43.669318
# Unit test for function trange
def test_trange():  # pragma: no cover
    """ function tested in `python setup.py test` """
    from tqdm.auto import trange

    try:
        import asyncio
    except (ImportError, SyntaxError):
        asyncio = None

    async def main():
        lst = [1, 2, 3, 4]
        del lst[:]
        for _ in trange(10):
            await asyncio.sleep(0.1)
            lst.append(1)
        assert(sum(lst) == 10)

    if asyncio:
        loop = asyncio.get_e

# Generated at 2022-06-24 09:39:45.498703
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from .auto import trange
    list(trange(5))


# Generated at 2022-06-24 09:39:48.823901
# Unit test for function trange
def test_trange():
    """
    Tests that trange function works as expected
    """
    # Simple sanity check
    assert list(trange(10)) == list(range(10))
    # Check that trange is same as tqdm(range())
    assert list(trange(10)) == list(tqdm(range(10)))

# Generated at 2022-06-24 09:39:54.518000
# Unit test for function trange
def test_trange():
    """
    Unit test for function `trange`

    Usage:
    >>> from tqdm import auto
    >>> auto.test_trange()
    """
    from ._tqdm_gui import tqdm
    assert trange(5) == tqdm(range(5))


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:40:03.401826
# Unit test for function trange
def test_trange():
    "Test trange"
    from .std import trange

    assert list(trange(3)) == list(range(3))
    assert list(trange(4, 7)) == list(range(4, 7))
    assert list(trange(4, 10, 2)) == list(range(4, 10, 2))
    assert list(trange(4, 10, 3)) == list(range(4, 10, 3))
    assert list(trange(4, 10, 3)) == [4, 7]
    assert list(trange(4, 1, -1)) == list(range(4, 1, -1))
    assert list(trange(4, 1, -3)) == list(range(4, 1, -3))
    assert list(trange(4, 1, -3)) == [4, 1]
   

# Generated at 2022-06-24 09:40:13.400948
# Unit test for function trange
def test_trange():
    """
    Unit test for function `trange`.
    """
    from .gui import tqdm as gui_tqdm
    from .notebook import tqdm as notebook_tqdm
    for t in (std_tqdm, asyncio_tqdm, gui_tqdm, notebook_tqdm):
        for i in t.trange(4):  # test `tqdm.trange`
            pass
        for i in t.trange(4, desc="desc"):  # test `tqdm.trange`
            pass
    for i in tqdm.trange(4):  # test `trange`
        pass
    for i in tqdm.trange(4, desc="desc"):  # test `trange`
        pass

# Generated at 2022-06-24 09:40:17.821102
# Unit test for function trange
def test_trange():
    list(range(10))
    assert list(trange(10)) == list(range(10))
    assert list(trange(10, desc='Some desc')) == list(range(10))
    assert list(trange(10, bar_format='{l_bar}')) == list(range(10))

    # Make sure trange() also accepts a named bar_format
    assert list(trange(10, bar_format='{n_fmt}/{total_fmt} [{bar}]')) == list(range(10))

# Generated at 2022-06-24 09:40:22.225342
# Unit test for function trange
def test_trange():
    """
    >>> test_trange()
    """
    for _ in trange(10, desc="short test"):
        pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 09:40:34.771625
# Unit test for function trange
def test_trange():
    """Test function trange()."""
    from tqdm.auto import trange, tqdm
    list(trange(10))
    trange(10)
    assert trange(10, desc="Supercalifragilisticexpialidocious") ==\
        trange(10, desc="Supercalifragilisticexpialidocious")
    assert trange(10, desc="Second-word") !=\
        trange(10, desc="First-word")
    assert trange(10) == trange(10)
    assert tqdm(range(10)) == trange(10)
    assert tqdm.tgranges(range(10), desc="Supercalifragilisticexpialidocious") ==\
        trange(10, desc="Supercalifragilisticexpialidocious")
   

# Generated at 2022-06-24 09:40:43.133621
# Unit test for function trange
def test_trange():
    """
    Test for function `trange`.
    """
    from tqdm.contrib.test_utils import _range
    from tqdm._tqdm import _range as _tqdm_range

    for n in (1, 2, 3):
        for w in (0, 1, 2, 3, 5, 8, 13, 21, 34):
            for unit in ('it', 'its', 'iterations'):
                for ascii in (None, True, False):
                    kwargs = {
                        'total': n, 'unit': unit, 'ascii': ascii,
                        'desc': 'desc', 'dynamic_ncols': True}
                    r1 = trange(n, **kwargs)
                    r2 = _tqdm_range(n, **kwargs)
                    assert isinstance

# Generated at 2022-06-24 09:40:51.178871
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .std import _supports_unicode
    from .main import tgrange, _range
    from .utils import _term_move_up

    for desc in [None, "foo", "bar"]:
        for leave in [True, False]:
            for unit in ["it", "foobar", ""]:
                for miniters in [1, 3, 10]:
                    for smoothing in [0, 0.5, 1]:
                        with tgrange(10, desc=desc, leave=leave, unit=unit,
                                     miniters=miniters, smoothing=smoothing) as t:
                            assert len(t) == 10

                            # Test repr
                            if desc is not None:
                                assert desc in repr(t)
                            if unit:
                                assert unit

# Generated at 2022-06-24 09:40:55.248935
# Unit test for function trange
def test_trange():
    """Unit test for function `trange`."""
    from .autonotebook import trange as old_trange

    for x in (5, 9, 13, 99, 101, 1001, 10001, 100001):
        assert tuple(tqdm(range(x))) == tuple(range(x)) == tuple(old_trange(x))



# Generated at 2022-06-24 09:41:03.483729
# Unit test for function trange
def test_trange():
    """
    Unit tests for function trange
    """
    # Define function to test against
    def tqdm_range(*args, **kwargs):
        return list(tqdm(range(*args), **kwargs))

    # Testing default arguments
    assert tqdm_range(10) == trange(10)
    # Testing custom arguments
    assert tqdm_range(13, 42, 1) == trange(13, 42, 1)
    assert tqdm_range(13, 42, 5) == trange(13, 42, 5)
    assert tqdm_range(42, 13, -1) == trange(42, 13, -1)
    assert tqdm_range(42, 13, -5) == trange(42, 13, -5)
    # Testing all arguments
    assert tqdm

# Generated at 2022-06-24 09:41:05.654729
# Unit test for function trange
def test_trange():
    """
    Smoke test for `tqdm.auto.trange`
    """
    # Test simple trange
    trange(10)

# Generated at 2022-06-24 09:41:15.629480
# Unit test for function trange
def test_trange():
    import sys
    import time
    import numpy as np

    pbar = trange(10)
    for i in pbar:
        time.sleep(0.01)  # artificial time consuming computation
        pbar.set_description("Processing %i" % i)
        pbar.update(1)

    pbar = trange(10, desc='Loading ...')
    for i in pbar:
        time.sleep(0.1)
        pbar.set_description("Loading %i" % i)
        pbar.set_postfix(foo=i**2, bar=np.random.rand(1)[0])

    def my_generator():
        for x in range(10):
            time.sleep(0.01)
            yield x

# Generated at 2022-06-24 09:41:16.346170
# Unit test for function trange
def test_trange():
    list(trange(3, desc="pre", ncols=100))

# Generated at 2022-06-24 09:41:19.773573
# Unit test for function trange
def test_trange():
    """Test function trange"""
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', category=DeprecationWarning)
        with tqdm(leave=True) as t:
            for i in trange(10):
                t.update()

# Generated at 2022-06-24 09:41:24.299678
# Unit test for function trange
def test_trange():
    for _ in trange(10):
        pass

    for _ in trange(10, 0, -1):
        pass

# Generated at 2022-06-24 09:41:25.834109
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    list(trange(10))  # test normal

# Generated at 2022-06-24 09:41:27.984836
# Unit test for function trange
def test_trange():
    """Test for function `trange`."""
    from .std import tqdm, trange

    assert tqdm == trange == trange

# Generated at 2022-06-24 09:41:32.382446
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Test that `tqdm.auto.trange` is properly wrapped."""
    class FakeTqdm(object):
        @staticmethod
        def __call__(*args, **kwargs):
            return args, kwargs

    old_tqdm = trange.__self__
    trange.__self__ = FakeTqdm()

# Generated at 2022-06-24 09:41:47.435515
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from tests_tqdm import with_setup, pretest_posttest, _range, closing

    with_setup(pretest_posttest)

    # Test trange ()
    with closing(trange(0)) as t:
        assert len(t) == 0

    # Test trange (1)
    with closing(trange(1)) as t:
        assert t.dynamic_ncols
        assert len(t) == 1

    # Test trange (2)
    with closing(trange(2)) as t:
        assert t.dynamic_ncols
        assert len(t) == 2

    # Test trange (3)
    with closing(trange(3)) as t:
        assert t.dynamic_ncols
        assert len(t) == 3

   

# Generated at 2022-06-24 09:41:52.231557
# Unit test for function trange
def test_trange():
    """ unit test for function trange """
    r = trange(10, desc='test', leave=True)
    for _ in r:
        pass
    if hasattr(r, "n"):
        raise ValueError("i'th iteration should not have n={!r}".format(r.n))

# Generated at 2022-06-24 09:41:54.487003
# Unit test for function trange
def test_trange():
    """Unit test for trange"""
    for _ in trange(3):
        pass

# Generated at 2022-06-24 09:42:02.802705
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    from time import sleep
    from sys import stderr, platform

    # Asyncio unit test
    if platform == "win32":
        # Windows doesn't support asyncio (yet?)
        # See https://bugs.python.org/issue22656
        return True

    with tqdm(total=100, unit="B", unit_scale=True, desc="Loading",
              mininterval=0.1, miniters=1, file=stderr) as t:
        for _ in range(10):
            t.update(10)
            sleep(0.04)
            if t.n == t.total:
                break
    return True

# Generated at 2022-06-24 09:42:10.034396
# Unit test for function trange
def test_trange():
    """
    Unit test for trange
    """
    with tqdm(total=10, desc="test trange") as pbar:
        assert pbar.refresh() == None  # pylint: disable=assignment-from-none
        assert len(pbar) == 10
        assert pbar.n == 0
        assert pbar.total == 10
        assert pbar.desc == "test trange"
        assert pbar.n == 0
        for _ in trange(10):
            pbar.update()
        assert pbar.n == 10

# Generated at 2022-06-24 09:42:11.520085
# Unit test for function trange
def test_trange():
    from .trange import _test  # pylint: disable=no-name-in-module
    _test()

# Generated at 2022-06-24 09:42:13.713899
# Unit test for function trange
def test_trange():
    from .std import format_interval, format_meter
    from .utils import _range


# Generated at 2022-06-24 09:42:21.045408
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    from .std import TqdmTypeError
    from .utils import _decode_precision
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        # repeatable output
        import random
        random.seed(0)
        with trange(10) as t:
            for _ in t:
                t.set_description("FOO"[random.randrange(3)])
        # check type of `unit`
        try:
            list(trange(0, 10, total=10, unit='i'))
        except TqdmTypeError:
            # type of `unit` must be `str`
            list(trange(0, 10, total=10, unit=b'i'))
       

# Generated at 2022-06-24 09:42:28.808438
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    pbar = trange(100)
    assert isinstance(pbar, tqdm)
    pbar = trange(100)
    assert len(pbar) == 100

# Generated at 2022-06-24 09:42:30.777103
# Unit test for function trange
def test_trange():
    """no-op doctest"""
    assert list(trange(3)) == [0, 1, 2]
    assert list(trange(3, 2)) == []
    assert list(trange(3, 5)) == [3, 4]

# Generated at 2022-06-24 09:42:33.299259
# Unit test for function trange
def test_trange():
    """ Test trange function """
    n = 5

    vals = []
    for i in trange(n, desc='test trange'):
        vals.append(i)
        if i == n-1:
            break
    assert vals == list(range(n))

# Generated at 2022-06-24 09:42:39.864957
# Unit test for function trange
def test_trange():
    """
    Unit test for trange
    """
    # Test in auto mode
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert trange(100) == notebook_trange(100)

    # Test in asyncio mode
    from .asyncio import trange as asyncio_trange

    if not notebook_trange.inherit_str and sys.version_info[:2] >= (3, 6):
        assert trange(100) == asyncio_trange(100)

# Generated at 2022-06-24 09:42:49.926560
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    # testing valid
    assert list(trange(3)) == list(range(3))
    assert list(trange(1, 3)) == list(range(1, 3))
    assert list(trange(1, 3, 0.5)) == list(range(1, 3, 0.5))
    assert list(trange(1, 3, 2)) == list(range(1, 3, 2))
    assert list(trange(3, -2, -1.5)) == list(range(3, -2, -1.5))

    # testing invalid
    try:
        list(trange(1, 3, 0))
        assert False
    except ValueError:
        pass


# Generated at 2022-06-24 09:42:56.553856
# Unit test for function trange
def test_trange():
    from .std import ncols
    from .utils import _range
    from .utils import _unwrap
    from .utils import _supports_unicode
    from .gui import format_sizeof
    from .utils import format_interval
    from .utils import _term_move_up
    from .utils import _time

    # Test trange
    tr = trange(10)
    assert list(tr) == list(_range(10))


# Generated at 2022-06-24 09:43:00.850652
# Unit test for function trange
def test_trange():
    """Unit test for function trange (which is also a test for tqdm.auto)"""
    for _ in trange(10):
        pass


if __name__ == "__main__":
    if sys.argv[1:]:
        sys.stderr.write("WARNING: no test yet for this module\n")
    else:
        test_trange()

# Generated at 2022-06-24 09:43:05.986193
# Unit test for function trange
def test_trange():
    """Test trange"""
    # pylint: disable=unused-variable
    lst = [True for _ in trange(10)]
    lst = [True for _ in trange(10, desc="foo", leave=True)]
    lst = [True for _ in trange(10, desc="foo", leave=False)]



# Generated at 2022-06-24 09:43:13.842655
# Unit test for function trange
def test_trange():
    """
    Unit tests for function trange.
    """
    from .std import tqdm
    from .utils import _range

    def slow():
        for _ in _range(3):
            for _ in _range(3):
                for _ in _range(3):
                    yield None
    slow = list(slow())

    def fast():
        for _ in range(3):
            for _ in range(3):
                for _ in range(3):
                    yield None
    fast = list(fast())

    assert slow == fast, "trange must run without overhead"

# Generated at 2022-06-24 09:43:15.841922
# Unit test for function trange
def test_trange():
    import time

    for _ in trange(4, desc='Hi'):
        time.sleep(0.01)



# Generated at 2022-06-24 09:43:18.231240
# Unit test for function trange
def test_trange():
    from ._utils import TestCase

    class Test(TestCase):
        def test_b(self):
            trange(-1, 0)

    Test().test_b()

# Generated at 2022-06-24 09:43:20.283207
# Unit test for function trange
def test_trange():
    """Test if trange is a shortcut for tqdm(range())."""
    assert list(trange(10)) == list(tqdm(range(10)))

# Generated at 2022-06-24 09:43:30.465593
# Unit test for function trange
def test_trange():
    """
    Test function trange with `from tqdm.auto import trange`.
    """

    # Disable tqdm_gui
    sys.modules['tqdm_gui'] = None
    sys.modules['tqdm._tqdm_gui'] = None

    from .auto import trange, tqdm

    # Test manual constructor
    from .gui import tqdm as gui_tqdm
    from .gui import trange as gui_trange
    for t in [gui_tqdm, gui_trange]:
        assert t is not trange
        assert t is not tqdm

    # Test for constructor equality
    for t in [notebook_tqdm, notebook_trange, asyncio_tqdm]:
        assert t is trange or t is tqdm

    # Test default

# Generated at 2022-06-24 09:43:38.644972
# Unit test for function trange
def test_trange():
    "Test basic function of trange"
    # pylint: disable=invalid-name
    import time
    import warnings

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        with tqdm(disable=True) as t:
            L = len(t)  # NOQA
            # NOTE: wrapped range iterator doesn't support len() in Python3 in
            # some cases
            assert L in (None, 0)

    # Postive integer
    with tqdm(total=5) as t:
        assert len(t) == 5
        for i in t:
            assert i == t.n
            time.sleep(0.01)
        assert i + 1 == t.n

    # None total

# Generated at 2022-06-24 09:43:49.114055
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange()
    """
    from ._utils import _range, _unich, _term_move_up
    # pylint: disable=protected-access
    assert tqdm(list(range(100)))
    assert tqdm(_unich(0) + "foo", bar_format="{n_fmt}/{total_fmt} [{bar}]")
    assert tqdm(_unich(
        0) + "foo", total=10, bar_format="{n_fmt}/{total_fmt} [{bar}]")
    assert tqdm(total=10, bar_format="{n_fmt}/{total_fmt} [{bar}]")

# Generated at 2022-06-24 09:44:00.398372
# Unit test for function trange
def test_trange():
    """
    Test function trange
    """
    from .std import tqdm

    trange = trange
    tqdm = tqdm
    class Tk:
        def __init__(self):
            pass
        def update(self, n):
            self.n = n
        def close(self):
            pass
    assert len(list(trange(3, desc='1st loop', leave=False))) == 3
    assert len(list(trange(3, desc='1st loop', leave=False))) == 3
    assert len(list(tqdm(range(3), desc='1st loop', leave=False))) == 3
    assert len(list(tqdm(range(3), desc='1st loop', leave=False))) == 3

# Generated at 2022-06-24 09:44:02.691778
# Unit test for function trange
def test_trange():
    for i in trange(0):
        pass

# Generated at 2022-06-24 09:44:11.777255
# Unit test for function trange
def test_trange():
    """Simply test `trange` function"""
    assert list(trange(3)) == [0, 1, 2]
    assert list(trange(3, 6)) == [3, 4, 5]
    assert list(trange(3, 30, 6)) == [3, 9, 15, 21, 27]
    assert list(trange(3, 30, 3.5)) == [3.0, 6.5, 10.0, 13.5, 17.0, 20.5, 24.0,
                                        27.5]
    assert list(trange(30, 3, -6)) == [30, 24, 18, 12, 6]

# Generated at 2022-06-24 09:44:15.280421
# Unit test for function trange
def test_trange():
    """
    Unit test for main function function.
    """
    from ._utils.tests import closing
    from .compat import StringIO

    with closing(StringIO()) as our_file:
        pbar = trange(10, file=our_file)
        for _ in pbar:
            pbar.set_description("testing trange")
        assert "testing trange" in our_file.getvalue()

# Generated at 2022-06-24 09:44:19.931879
# Unit test for function trange
def test_trange():
    """
    >>> list(trange(3))
    [0, 1, 2]
    >>> list(trange(1, 3))
    [1, 2]
    >>> list(trange(1, 3, 2))
    [1]
    """
    pass



# Generated at 2022-06-24 09:44:27.078901
# Unit test for function trange
def test_trange():
    """
    Unit test for the function trange.
    """
    from .tqdm import _term_move_up
    from .utils import _range
    from time import sleep

    for _ in trange(0, 1, 0.1):
        sleep(0.01)
    for _ in trange(1, 0, -0.1):
        sleep(0.01)
    # Test reset
    for i in trange(10, desc="desc1", leave=True):
        sleep(0.01)
        if i >= 5:
            trange.reset()
            break
    for _ in trange(10, desc="desc2"):
        sleep(0.01)

    # Test with manual close
    pbar = trange(10)
    for i in _range(5):
        pbar.update()

# Generated at 2022-06-24 09:44:36.212649
# Unit test for function trange
def test_trange():
    """Tests that `trange` is a shortcut for `tqdm(range(*args), **kwargs)`."""

# Generated at 2022-06-24 09:44:42.641152
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from .utils import format_sizeof

    assert format_sizeof(trange(32)) == "0.00B"
    assert format_sizeof(trange(32, position=16)) == "0.00B"
    assert format_sizeof(trange(32, position=0)) == "0.00B"
    assert format_sizeof(trange(32, position=32)) == "0.00B"

# Generated at 2022-06-24 09:44:44.454212
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import tqdm
    for i in trange(2):
        for _ in tqdm(range(2), leave=False):
            pass

# Generated at 2022-06-24 09:44:46.489625
# Unit test for function trange
def test_trange():
    """Test if trange works."""
    # pylint: disable=unused-variable
    for i in trange(10):
        pass

# Generated at 2022-06-24 09:44:57.076930
# Unit test for function trange
def test_trange():
    """
    Unit test for function tqdm.trange.
    """
    from .std import format_size
    from .utils import format_interval
    from time import sleep, time
    from .utils import _term_move_up

    for _ in trange(
        3, desc="Test", leave=False,
        mininterval=0, maxinterval=0, miniters=1):
        sleep(0.01)

    format_interval(0.01)

    print()
    for _ in trange(3, desc="Test", leave=True, miniters=1,
                    bar_format='{l_bar}{bar}| '):
        sleep(0.01)
        print()

    print()

# Generated at 2022-06-24 09:44:59.551847
# Unit test for function trange
def test_trange():
    """Tests that 'from tqdm.auto import trange' works"""
    from .utils import _term_move_up

    with trange(5, desc="test", file=sys.stdout) as t:
        for _ in t:
            sys.stdout.write("\r" + _term_move_up())

# Generated at 2022-06-24 09:45:05.561222
# Unit test for function trange
def test_trange():
    """Test trange function."""
    from ._utils import _range

    assert list(trange(5)) == list(_range(5))
    assert list(trange(ncols=1)) == list(_range(ncols=1))
    assert list(trange(5, 5)) == list(_range(5, 5))
    assert list(trange(5, 1, -1)) == list(_range(5, 1, -1))
    assert list(trange(5, 5, 2)) == list(_range(5, 5, 2))

# Generated at 2022-06-24 09:45:13.112238
# Unit test for function trange
def test_trange():
    """
    Tests that simple display is working as expected.
    """
    from .std import TqdmBase, tqdm
    assert trange(3) == tqdm(range(3))
    assert trange(3) != tqdm(range(4))
    assert trange(3, 5) == tqdm(range(3, 5))
    assert trange(3, 5) != tqdm(range(4, 5))
    assert trange(3, 9, 2) == tqdm(range(3, 9, 2))
    assert trange(3, 9, 2) != tqdm(range(4, 9, 2))
    assert trange(3, 9, 2) != tqdm(range(3, 10, 2))

# Generated at 2022-06-24 09:45:14.123745
# Unit test for function trange
def test_trange():
    for _ in trange(3, desc='Testing trange'):
        pass

# Generated at 2022-06-24 09:45:24.673153
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    assert list(trange(3)) == [0, 1, 2]

    from .utils import _range  # pylint: disable=protected-access

    # Test for `total`
    assert list(trange(2, 3)) == [2]
    assert list(trange(2, 20, 2)) == _range(2, 20, 2)
    assert list(trange(2, 20, 2, initial=1)) == [1] + _range(2, 20, 2)

    # Test for `desc`
    assert list(trange(2, desc="desc2")) == _range(2)

    # Test for `leave`
    assert list(trange(2, leave=True)) == _range(2)

    # Test for `smoothing`

# Generated at 2022-06-24 09:45:29.903284
# Unit test for function trange
def test_trange():  # pragma: no cover
    from ._tqdm_gui import _range

    assert list(_range(10)) == list(trange(10))
    assert list(_range(10, 11)) == list(trange(10, 11))
    assert list(_range(10, 11, 2)) == list(trange(10, 11, 2))
    assert list(_range(10)) == list(trange(10))

# Generated at 2022-06-24 09:45:38.086212
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    # Test 1:
    li = list(trange(1))
    assert len(li) == 1
    # Test 2:
    li = list(trange(1, 1))
    assert len(li) == 0
    # Test 3:
    li = list(trange(1, 2))
    assert len(li) == 1
    # Test 4:
    li = list(trange(1, 3))
    assert len(li) == 2

# Generated at 2022-06-24 09:45:45.012546
# Unit test for function trange
def test_trange():
    """Runs `trange(3)` in background and joins immediately"""
    from .std import _supports_unicode
    from ._utils import _environ_cols_wrapper

    with _environ_cols_wrapper() as _environ:
        try:
            del _environ["COLUMNS"]
        except Exception:
            pass
        with tqdm(total=3) as pbar:
            assert pbar.total == 3
            assert pbar.n == 0
            assert _supports_unicode and isinstance(pbar.desc, str) or \
                not _supports_unicode and isinstance(pbar.desc, bytes)
        pbar.close()
        assert pbar.n == pbar.total
        assert not pbar.desc and not pbar.dynamic_ncols



# Generated at 2022-06-24 09:45:52.997453
# Unit test for function trange
def test_trange():
    """
    Unit test for function :func:`tqdm.auto.trange`.
    """
    lst = list(range(5))

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch  # requires `pip install mock`

    with patch('sys.stderr') as stderr_mock:
        for i in trange(5):
            assert i == lst.pop(0)
            assert bool(stderr_mock.write.called)
    with patch('sys.stderr') as stderr_mock:
        with patch('sys.stdout') as stdout_mock:
            for i in trange(5, file=sys.stdout):
                assert i == lst.pop(0)