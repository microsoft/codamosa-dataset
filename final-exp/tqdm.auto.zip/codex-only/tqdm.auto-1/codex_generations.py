

# Generated at 2022-06-24 09:35:55.538104
# Unit test for function trange
def test_trange():
    """Test unit for `tqdm.auto.trange`"""
    assert trange(0) == list(range(0))
    assert trange(1) == list(range(1))
    assert trange(2, 5) == list(range(2, 5))
    assert trange(3, 7, 2) == list(range(3, 7, 2))
    assert trange(-1) == list(range(-1))
    assert trange(-2, -5) == list(range(-2, -5))
    assert trange(-3, -7, -2) == list(range(-3, -7, -2))

# Generated at 2022-06-24 09:36:06.643943
# Unit test for function trange
def test_trange():
    from .std import FormatCustomText as _FormatCustomText
    for _ in trange(10, desc="inner loop",
                    leave=True,
                    ascii=True,
                    unit="test"):
        for _ in trange(10, desc="outer loop",
                        leave=True,
                        ascii=True,
                        unit="test"):
            for _ in trange(10, desc="outer-outer loop",
                            leave=True,
                            ascii=True,
                            unit="test"):
                pass

    # Test with format custom text

# Generated at 2022-06-24 09:36:13.413953
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .std import tqdm

    for _ in trange(3):
        pass
    assert isinstance(_, int)

    for _ in trange(3, desc="foo"):
        pass
    assert isinstance(_, int)
    assert "foo" in tqdm.get_lock().lines[0]

    for _ in trange(3, 3):
        pass
    assert isinstance(_, int)

    for _ in trange(3, 3, desc="foo"):
        pass
    assert isinstance(_, int)
    assert "foo" in tqdm.get_lock().lines[0]

    for _ in trange(3, 3, 5):
        pass
    assert isinstance(_, int)


# Generated at 2022-06-24 09:36:17.294379
# Unit test for function trange
def test_trange():
    "Test for trange()"
    with tqdm(total=6) as pbar:
        for i in trange(4):
            pbar.update()


if __name__ == "__main__":
    from ._utils import _test_env
    _test_env(globals())

# Generated at 2022-06-24 09:36:23.379158
# Unit test for function trange
def test_trange():
    rng = trange(5)
    assert next(rng) == 0  # -> 0
    assert rng.n == 1
    next(rng)  # -> 1
    next(rng)  # -> 2
    next(rng)  # -> 3
    assert rng.n == 4
    next(rng)  # -> 4

    rng = trange(1, 7, 2)
    assert next(rng) == 1
    assert next(rng) == 3
    assert next(rng) == 5

    rng = trange(5, 0, -1)
    assert next(rng) == 5
    assert next(rng) == 4
    assert next(rng) == 3
    assert next(rng) == 2
    assert next(rng) == 1
    assert rng

# Generated at 2022-06-24 09:36:25.641150
# Unit test for function trange
def test_trange():
    """ Test trange """
    total = 5
    for i in trange(total, desc='A loop', leave=False):
        assert i < total

# Generated at 2022-06-24 09:36:34.629588
# Unit test for function trange
def test_trange():
    """Unit test for trange"""
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=DeprecationWarning)
        from tqdm.auto import tqdm as tqdm_deprecated
    try:
        from tqdm.auto import trange
        for _ in trange(4):
            pass
    except Exception as e:
        return False
    for cls, module in list(tqdm_deprecated.__dict__.items()):
        if "tqdm_" in cls:
            m = module

# Generated at 2022-06-24 09:36:40.858825
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .tqdm_gui import tqdm
    trange = lambda *x: tqdm(*x, disable=True)  # pylint: disable=invalid-name
    L = trange(10, desc='A', leave=True)
    assert next(L) == 0
    L.set_description('A2')
    assert L.base_format == 'A2:   0it [00:00, ?it/s]'
    L.close()

# Generated at 2022-06-24 09:36:45.582935
# Unit test for function trange
def test_trange():
    """ Test trange function """
    from .gui import tqdm as _tqdm
    from .std import tqdm as _std_tqdm

    assert trange(10)._tqdm is _tqdm
    assert trange(10)._inst_tqdm is _tqdm
    assert trange(10)._inst_tqdm is not _std_tqdm

# Generated at 2022-06-24 09:36:47.882010
# Unit test for function trange
def test_trange():
    """ Test trange """
    from .tqdm import trange, tqdm
    for _ in trange(2):
        for _ in tqdm(range(3)):
            pass

# Generated at 2022-06-24 09:36:56.000101
# Unit test for function trange
def test_trange():
    """Test trange() with both int and len-compatible parameters"""
    from sys import getsizeof
    from types import GeneratorType

    TEMP = [0] * 100
    for i in trange(len(TEMP)):
        TEMP[i] = i

    for i in trange(getsizeof(TEMP)):
        assert False, "Shouldn't get here"
        break

    for i in trange(i for i in range(100)):
        assert i == TEMP[i], (i, TEMP[i])

    assert not isinstance(trange(10), GeneratorType)
    assert isinstance(iter(trange(10)), GeneratorType)

    # Smoketest leave=True
    for i in trange(10, leave=True):
        1 / 0

# Generated at 2022-06-24 09:37:07.781357
# Unit test for function trange
def test_trange():
    """Test the trange function in the tqdm.auto module"""
    from tqdm import trange, tqdm
    import time
    import sys

    # On Python2, just verify that trange() calls tqdm()
    if sys.version_info[0] == 2:
        assert trange(0) == list(tqdm(range(0)))
        return

    try:
        for _ in trange(2, leave=True):
            time.sleep(0.1)  # do not fail if problems with background
        time.sleep(0.5)  # wait for trange to exit
    except:  # pylint: disable=bare-except
        pass

    assert trange(2)._instances.empty()
    assert trange(0) == list(range(0))

# Generated at 2022-06-24 09:37:16.773958
# Unit test for function trange
def test_trange():
    """
    Unit tests for function ``tqdm.auto.trange``.
    """
    # Test with default parameters
    i = 0
    for _ in trange(10):
        i += 1
    assert i == 10

    # Test with total
    i = 0
    for _ in trange(10, total=100):
        i += 1
    assert i == 10

    # Test with total=0
    i = 0
    for _ in trange(10, total=0):
        i += 1
    assert i == 10

    # Test with desc
    i = 0
    for _ in trange(10, desc="desc"):
        i += 1
    assert i == 10

    # Test with unit
    i = 0
    for _ in trange(10, unit="unit"):
        i += 1
   

# Generated at 2022-06-24 09:37:27.829149
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    Unit test for function trange.
    """
    from .std import _range
    from sys import version_info, platform

    with tqdm(_range(10), miniters=1) as t:
        for i in t:
            assert i == t.n - 1
            assert i == t.last_print_n - 1
            assert i == t.last_print_t - 1

    # Test with tqdm.trange
    with trange(10) as t:
        for i in t:
            assert i == t.n - 1
            assert i == t.last_print_n - 1
            assert i == t.last_print_t - 1

    # Test with trange

# Generated at 2022-06-24 09:37:30.970529
# Unit test for function trange
def test_trange():
    """Test trange(n)"""
    with trange(3) as t:
        assert list(t) == [0, 1, 2]



# Generated at 2022-06-24 09:37:32.942745
# Unit test for function trange
def test_trange():
    limit = 256
    x = list(trange(limit))
    assert x == list(range(limit))



# Generated at 2022-06-24 09:37:39.968491
# Unit test for function trange
def test_trange():
    """
    $ python -m tqdm.auto trange

    :return: 0
    """
    assert tqdm == asyncio_tqdm
    assert tqdm == std_tqdm
    assert list(trange(0)) == []
    assert list(trange(10)) == list(range(10))
    assert list(trange(5, 10)) == list(range(5, 10))
    assert list(trange(10, ncols=90)) == list(range(10))
    return 0

# Generated at 2022-06-24 09:37:45.902242
# Unit test for function trange
def test_trange():
    from collections import Counter
    from ._utils import _supports_unicode
    from .std import tqdm

    for i, x in enumerate(trange(9, 2, 0.3)):
        assert i == int(x / 0.3)

    with tqdm(total=9, unit="B", unit_scale=True) as t:
        for i, x in enumerate(trange(9, 2, 0.3)):
            t.update(i + 1)

    # Unit auto-set based on total and max_colwidth

# Generated at 2022-06-24 09:37:53.391121
# Unit test for function trange
def test_trange():
    """
    Unit test for trange function
    """
    import time
    import random

    total_time = 0

    for _ in trange(100, desc='trange', leave=True):
        time.sleep(0.5)
        total_time += 0.5

    for _ in trange(100, desc='trange', leave=True):
        time.sleep(random.random())
        total_time += random.random()

    for _ in trange(100, desc='trange', leave=True):
        time.sleep(random.random() * 0.5)
        total_time += random.random() * 0.5

    assert total_time > 150

# Generated at 2022-06-24 09:38:04.629232
# Unit test for function trange
def test_trange():
    """Test trange"""
    import re

    list(trange(10))
    list(trange(10, desc="A"))
    list(trange(0))
    list(trange(2, 3, 1, desc="B"))
    list(trange(2, 3, desc="C", ascii=True))
    list(trange(2, desc="D", unit="s", ascii=True))
    list(trange(2, desc="E", unit_scale=True))
    list(trange(2, 3, desc="F", ascii=True, unit_scale=True))
    list(trange(2, 3, desc="G", ascii=True, unit_scale=True, unit="s"))

    # Test bar_format

# Generated at 2022-06-24 09:38:05.855410
# Unit test for function trange
def test_trange():
    """Tests the function trange"""
    trange(10)

# Generated at 2022-06-24 09:38:15.091679
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from sys import version_info as py_version_info
    from platform import python_implementation
    impl = python_implementation()
    if impl == 'PyPy':
        if py_version_info < (3,):
            assert list(trange(2)) == [0, 1]
            assert list(trange(2, 3)) == [2]
            assert list(trange(2, 3, 1)) == [2]
            assert list(trange(3, 2, -1)) == [3, 2]
            assert list(trange(3, 2, -0.5)) == [3.0, 2.5, 2.0]
        else:
            assert list(trange(2)) == [0, 1]
            assert list(trange(2, 3)) == [2]

# Generated at 2022-06-24 09:38:25.511851
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    # pylint: disable=too-many-function-args, too-many-locals, invalid-name
    from .std import tqdm
    from .utils import _range

    cnt = 5
    try:
        from os import scandir
    except ImportError:
        scandir = None
    try:
        from os import fspath
    except ImportError:
        fspath = None
    try:
        from os import cpu_count
    except ImportError:
        cpu_count = None

    # test exceptions
    try:
        trange(cnt, ascii=1)
    except TypeError as e:
        if "keyword argument ascii" not in str(e):
            raise
    else:
        raise ValueError

# Generated at 2022-06-24 09:38:31.640087
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import TqdmTypeError
    from .std import get_lock

    # Check range() args
    for args in [10, (1, 10), (1, 10, 1), (1.0, 10.0, 1.0), (10.0, 0, -1)]:
        with get_lock():
            li = list(trange(*args))
        assert li == list(range(*args))

    # Multiple locks
    lock1 = get_lock()
    lock2 = get_lock()
    with lock1, lock2:
        li = list(trange(5))
    assert li == list(range(5))

    # Check nonexistent bar_format
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")

# Generated at 2022-06-24 09:38:34.090325
# Unit test for function trange
def test_trange():
    "Test for function trange"
    assert list(trange(5)) == list(range(5))

# Generated at 2022-06-24 09:38:37.311773
# Unit test for function trange
def test_trange():
    """
    Unit test for trange() function
    """
    list(trange(3))


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:38:40.870922
# Unit test for function trange
def test_trange():
    from .std import format_sizeof

    with trange(10) as t:
        for _ in t:
            t.set_postfix(refresh=False, memory=format_sizeof(2**64))

# Generated at 2022-06-24 09:38:46.079856
# Unit test for function trange
def test_trange():
    """
    Tests for `tqdm.auto.trange`.
    """
    from .gui import trange as gui_trange
    from .std import trange as std_trange

    def func():
        """Test function"""
        return list(std_trange(5))

    assert func() == list(trange(5))
    assert func() == list(gui_trange(5))

# Generated at 2022-06-24 09:38:48.023563
# Unit test for function trange
def test_trange():
    """Tests function trange()"""
    assert list(trange(3)) == [0, 1, 2]



# Generated at 2022-06-24 09:38:55.071194
# Unit test for function trange
def test_trange():
    """Test for the default trange function."""
    from ._version import get_versions

    assert get_versions()["version"]  # do not remove

    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=TqdmExperimentalWarning)
        with notebook_tqdm(total=7, ncols=90) as pbar:
            for _ in trange(7):
                pbar.update()

# Generated at 2022-06-24 09:38:58.449709
# Unit test for function trange
def test_trange():
    """
    Test trange
    """
    assert list(trange(5)) == list(tqdm(range(5)))
    assert list(trange(5, 0, -1)) == list(tqdm(range(5, 0, -1)))

# Generated at 2022-06-24 09:39:08.427519
# Unit test for function trange
def test_trange():
    """
    Test function trange
    """
    from .std import TqdmKeyError

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        from .autonotebook import tqdm as notebook_tqdm
        from .autonotebook import trange as notebook_trange
        from .asyncio import tqdm as asyncio_tqdm
        from .std import tqdm as std_tqdm
    if (sys.version_info[:2] < (3, 6)):
        assert (trange(1) == notebook_trange(1))
        assert (tqdm(1) == notebook_tqdm(1))
        assert (tqdm(1) == notebook_tqdm(1))

# Generated at 2022-06-24 09:39:19.147829
# Unit test for function trange
def test_trange():
    from .std import trange
    from .utils import format_interval
    from .utils import format_meter
    from .utils import _range
    from time import time, sleep

    for n in _range(1, 10):
        i = trange(n)
        assert (format_interval(i.last_print_t - i.start_t) ==
                format_interval(i.last_print_t - i.start_t)), n
        assert (format_meter(i.n, i.last_print_t - i.start_t, 1) ==
                format_meter(i.n, i.last_print_t - i.start_t, 1)), n

# Generated at 2022-06-24 09:39:25.460583
# Unit test for function trange
def test_trange():
    """Tests for `trange` function."""

    for i in trange(0, 10, 2):
        assert i % 2 == 0
    for i in trange(1, 0, -2):
        assert i % 2 == 1
    for i in trange(0, 1.0, 0.1, 0.01):
        assert i <= 1
    for i in trange(0, 1.0, 0.1, 0.01, 2):
        assert i <= 1

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:39:35.541766
# Unit test for function trange
def test_trange():
    """Test function trange"""
    # No args, counter = index + 1 (default)
    out = [i + 1 for i in trange()]
    assert out == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    # No args, counter = index + 10
    out = [i + 10 for i in trange(postfix="+10", unit_scale=True)]
    assert out == [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
    # No args, counter = index + 1
    out = [i + 1 for i in trange(postfix="+1")]
    assert out == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    # 10 args, counter = index + 1 (default)

# Generated at 2022-06-24 09:39:41.638987
# Unit test for function trange
def test_trange():
    """Test trange"""
    import io
    buffer = io.StringIO()
    trange(2, file=buffer).update()
    trange(3, file=buffer).update()
    assert buffer.getvalue() == '100%|██████████| 2/2 [00:00<?, ?it/s]\n' + \
                                 '100%|██████████| 3/3 [00:00<?, ?it/s]\n'

# Generated at 2022-06-24 09:39:49.850993
# Unit test for function trange
def test_trange():
    """
    >>> list(trange(4))
    [0, 1, 2, 3]
    """
    return None

if __name__ == "__main__":
    from doctest import testmod, NORMALIZE_WHITESPACE
    import numpy as np

    testmod(optionflags=NORMALIZE_WHITESPACE)
    # Ensure trange is minimal size - may fail sometimes if stdout is flushed
    # more often than in this test
    with warnings.catch_warnings():  # stdout flush broken pipe warnings
        warnings.simplefilter("ignore", ResourceWarning)

# Generated at 2022-06-24 09:39:57.218481
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Smoke test trange"""
    assert len(list(trange(3))) == 3
    assert len(list(trange(3.1))) == 3
    assert list(trange(3, 1, -1)) == [3, 2, 1]
    assert len(list(trange(3))) == 3
    assert len(list(trange(3.1))) == 3
    assert list(trange(3, 1, -1)) == [3, 2, 1]



# Generated at 2022-06-24 09:40:04.036310
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .std import tqdm
    from .auto import trange

    # check that args are passed
    assert list(trange(3, 9, 2)) == list(tqdm(range(3, 9, 2)))

    # check that args + kwargs are passed
    assert list(trange(0, 4, 1, leave=True)) == list(
        tqdm(range(0, 4, 1), leave=True))

    # check that `desc` appears in first position
    assert list(trange(0, 4, 1, desc="A")) == list(tqdm(range(0, 4, 1), desc="A"))


# Generated at 2022-06-24 09:40:08.212283
# Unit test for function trange
def test_trange():
    """Test trange"""
    assert list(trange(3)) == [0, 1, 2]
    assert list(trange(3, 5)) == [3, 4]
    assert list(trange(3, 6, 2)) == [3, 5]


# Generated at 2022-06-24 09:40:13.692471
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    import time
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        for _ in trange(2, desc='1st loop'):
            for _ in trange(5, desc='2nd loop', leave=False):
                for _ in trange(100, desc='3nd loop'):
                    time.sleep(0.01)
            time.sleep(0.05)

# Generated at 2022-06-24 09:40:17.825664
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    Unit test for function trange
    """
    from .gui import tqdm_gui
    from .std import tqdm_std

    # Test trange type
    if getattr(tqdm, "gui", None):
        assert type(trange(2)) is tqdm_gui
    else:
        assert type(trange(2)) is tqdm_std

    # Test trange actual output
    correct = [3, 2]
    count = 0
    for i in trange(2):
        assert i == correct[count]
        count += 1

# Generated at 2022-06-24 09:40:27.629805
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    import io
    import subprocess

    prog = 'from tqdm.auto import trange\n' \
           'for i in trange(10):\n' \
           '    pass'

    expected_out = '  0%|                    | 0/10 [00:00<?, ?it/s]\n'
    actual_out = subprocess.check_output(sys.executable + \
        ' -c "{}"'.format(prog), shell=True).decode("utf-8")

    # check that trange() works fine without jupyter_client
    assert actual_out.startswith(expected_out)

    # check that trange() works fine with sys.stdout.buffer
    with io.StringIO() as f:
        old_std

# Generated at 2022-06-24 09:40:40.699634
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from .std import format_interval, format_meter
    loop = range(3)
    for i in trange(3, desc="trange_test", ncols=75):
        assert i in loop
        loop.remove(i)
    assert len(loop) == 0
    assert bool(format_interval(0)) is False
    assert bool(format_interval(1.0)) is True
    assert bool(format_interval(1.0, unit="s")) is True
    assert bool(format_interval(1.0, unit="s", precision=10)) is True
    assert bool(format_interval(1.0, unit="s", precision=1)) is True
    assert bool(format_interval(0)) is False

# Generated at 2022-06-24 09:40:43.573199
# Unit test for function trange
def test_trange():
    """
    Test for trange function
    """
    from tqdm.auto import trange

    assert list(trange(3)) == [0, 1, 2]

# Generated at 2022-06-24 09:40:47.772177
# Unit test for function trange
def test_trange():
    from .utils import _term_move_up
    from .std import format_interval, _unicode

    l = [_unicode(format_interval(.1 * x)) for x in range(20)]
    s = _term_move_up() + ''.join(l)

    for _ in trange(20):
        pass
    if tqdm.write(s) != s:
        raise AssertionError("trange() failed!")

# Generated at 2022-06-24 09:40:57.472382
# Unit test for function trange
def test_trange():
    """
    Test if `trange` works as expected.
    """
    import threading
    from .std import trange, tqdm

    class UnsyncTqdm(tqdm):
        """
        Weak thread-safety test
        """

# Generated at 2022-06-24 09:41:04.831520
# Unit test for function trange
def test_trange():
    """Test that trange works"""
    from .tqdm import trange
    from .utils import format_sizeof
    for _ in trange(3, desc='Testing trange', leave=False,
                    ascii=True, unit="blobs", unit_scale=True):
        pass

    from .tqdm import trange
    from .utils import format_interval
    for _ in trange(3, desc='Testing trange', ascii=True, unit='s'):
        pass

    with trange(3, desc='Testing trange', ascii=True, unit='custom',
                unit_scale=True, miniters=1, mininterval=0) as t:
        t.set_postfix(custom=format_interval(0.12345))

# Generated at 2022-06-24 09:41:08.822891
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .std import tqdm_std

    for tqdm_ in (notebook_tqdm, std_tqdm, tqdm):
        with tqdm_std.disable_all():
            assert trange(5) == list(tqdm(range(5)))

# Generated at 2022-06-24 09:41:11.261077
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    # Setup
    tries = 1000

    # Test
    sum(trange(tries))



# Generated at 2022-06-24 09:41:16.237044
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    # TODO: use pytest instead of unittest
    from .std import TqdmTypeError

    # Test function trange
    if list(range(2)) == list(trange(2)):
        pass
    else:
        raise TqdmTypeError("trange returns different values")

# Generated at 2022-06-24 09:41:20.042674
# Unit test for function trange
def test_trange():
    """test_trange."""
    try:
        it = trange(3)
        assert iter(it) is it
        assert len(list(it)) == 3
    except Exception:  # pragma: no cover
        print('\n*** trange test failed ***')
        print(it)
        raise

# Generated at 2022-06-24 09:41:31.293519
# Unit test for function trange
def test_trange():
    """
    Test for trange()
    """
    import time
    import os
    from .std import PY3
    # find free port
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('localhost', 0))
    address, port = s.getsockname()
    s.close()
    del socket
    # start server
    from .gui import tqdm_notebook
    from .utils import _environ_cols_wrapper
    port = max(0, int(os.environ.get('TEST_PORT', port)))
    assert port > 0
    from .gui import DEFAULT_BAR_FORMAT, DEFAULT_MINITER
    from .tqdm import tqdm

# Generated at 2022-06-24 09:41:39.834494
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        from .std import tqdm as std_tqdm
        from .autonotebook import trange as notebook_trange

        assert trange(1000) == notebook_trange(1000) == std_tqdm(range(1000))

# Generated at 2022-06-24 09:41:49.395147
# Unit test for function trange
def test_trange():
    """Test that trange works as intended"""
    from ._tqdm import tnrange  # pylint: disable=import-outside-toplevel
    from .utils import format_interval

    input_list = list(range(10))
    output_list = list(tnrange(10))

    assert input_list == output_list, 'Output does not match input'

    input_list = list(range(10, 15))
    output_list = list(tnrange(10, 15))

    assert input_list == output_list, 'Output does not match input'

    input_list = list(range(15, 10, -1))
    output_list = list(tnrange(15, 10, -1))

    assert input_list == output_list, 'Output does not match input'


# Generated at 2022-06-24 09:42:00.089779
# Unit test for function trange
def test_trange():
    """Unit test for trange"""
    from ._utils import _range
    from tqdm import trange
    list(trange(3))
    list(trange(10, 2, -1))
    list(trange(10, 0, -1))
    list(trange(10, 2, -2))
    list(trange(10, -2, -2))

    with trange(3) as t:
        for i in _range(1, 4):
            t.update()
    assert t.n == 3, t.n

    with trange(1, 4) as t:
        for i in _range(1, 4):
            t.update()
    assert t.n == 3, t.n


# Generated at 2022-06-24 09:42:10.397555
# Unit test for function trange
def test_trange():
    """Test trange"""
    assert list(trange(1)) == list(range(1))
    assert list(trange(0)) == list(range(0))
    assert list(trange(1, 1)) == list(range(1, 1))

    # positional and keyword arguments
    assert list(trange(1, 3)) == list(range(1, 3))
    assert list(trange(3, 1, -1)) == list(range(3, 1, -1))
    assert list(trange(0, 3, 0)) == list(range(0, 3, 0))
    assert list(trange(1, 3, 2)) == list(range(1, 3, 2))
    assert list(trange(3, 1, -2)) == list(range(3, 1, -2))

# Generated at 2022-06-24 09:42:11.656394
# Unit test for function trange
def test_trange():
    try:
        sum(trange(10))
    except TypeError:
        return False
    return True

# Generated at 2022-06-24 09:42:12.586059
# Unit test for function trange
def test_trange():
    for _ in trange(10):
        pass

# Generated at 2022-06-24 09:42:20.199339
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    from .std import trange as my_trange

    # Test `trange` function
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        trange_results = list(trange(10))
        my_trange_results = list(my_trange(10))
    assert trange_results == my_trange_results

    # Test `trange` loop
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        trange_results = []
        my_trange_results = []
        for i in trange(2):
            trange_results.append(i)
        for i in my_trange(2):
            my_trange_results.append(i)
    assert trange_

# Generated at 2022-06-24 09:42:22.890133
# Unit test for function trange
def test_trange():
    assert(list(trange(10)) == list(tqdm(range(10))))

# Generated at 2022-06-24 09:42:31.278653
# Unit test for function trange
def test_trange():
    """Test trange"""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        from tqdm._tqdm import trange
        for _ in trange(3, desc="desc1", leave=True):
            for __ in trange(3, desc="desc2", leave=True):
                pass
            with trange(3, desc="desc2", leave=True, nest_asyncio=True) as t:
                # pylint: disable=unused-variable
                @t.wrap
                async def coro():
                    await asyncio.sleep(0.01)

                asyncio.ensure_future(coro())
                asyncio.ensure_future(coro())
                asyncio.ensure_future(coro())

                loop = asyncio

# Generated at 2022-06-24 09:42:38.641569
# Unit test for function trange
def test_trange():
    # python3.7 has `list(tqdm(range(INT_MAX), ncols=0))` AttributeError
    if sys.version_info[:2] >= (3, 7):
        return
    assert list(trange(5, ncols=0)) == list(notebook_trange(5, ncols=0)) == \
           list(asyncio_tqdm(notebook_trange(5, ncols=0))) == list(range(5))



# Generated at 2022-06-24 09:42:48.701385
# Unit test for function trange
def test_trange():
    """Test if trange works"""
    assert list(trange(7, 0, -1)) == list(range(7, 0, -1)), "trange does not work"
    assert list(trange(7, 0, -1, leave=False)) == list(range(7, 0, -1)), "trange does not work"
    assert list(trange(7, 0, -1, position=1)) == list(range(7, 0, -1)), "trange does not work"
    assert list(trange(7, 0, -1, mininterval=0.01)) == list(range(7, 0, -1)), "trange does not work"

# Generated at 2022-06-24 09:42:59.947323
# Unit test for function trange
def test_trange():
    """Test function `trange()`."""
    # Make sure that trange function is available
    from importlib import import_module
    trange = getattr(import_module("tqdm.auto"), "trange")
    assert trange is not None

    # Make sure that values returned by trange() are available
    # (in __next__() or in next())
    from contextlib import contextmanager
    @contextmanager
    def nostderr():
        """Context manager to redirect stderr to devnull"""
        import os
        import sys
        devnull = open(os.devnull, "w")
        orig_stderr = sys.stderr
        sys.stderr = devnull

        try:
            yield
        finally:
            sys.stderr = orig_stderr
            devnull.close()

# Generated at 2022-06-24 09:43:09.882484
# Unit test for function trange
def test_trange():
    """Simple sanity check."""
    # pylint: disable=W0212
    from ._tqdm_gui import _supports_unicode
    from ._utils import _environ_cols_wrapper
    from .gui import _range
    from .gui import _tqdm_gui
    from .std import tqdm
    from .std import tqdm_gui

    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=TqdmExperimentalWarning)
        import attr
        # HACK: avoid "coroutine '_tqdm.tqdm' was never awaited" on py3.7+
        attr.s(hash=False, slots=False, init=True, frozen=False)
        with tqdm.tqdm(total=1) as foo:
            foo.bar

# Generated at 2022-06-24 09:43:15.961835
# Unit test for function trange
def test_trange():
    """ Tests trange() function """
    from pytest import raises
    assert next(trange(0)) == 0
    for _ in trange(2):
        pass

    # Test trange input checking
    with raises(TypeError):
        next(trange(None))
    with raises(ValueError):
        next(trange(-1))
    with raises(ValueError):
        next(trange(0))

# Generated at 2022-06-24 09:43:19.321952
# Unit test for function trange
def test_trange():
    """
    Unit test for `trange`.
    """
    import pytest
    with pytest.raises(TypeError):
        trange()  # pylint: disable=no-value-for-parameter
    list(trange(5))
    tqdm().close()

# Generated at 2022-06-24 09:43:25.792783
# Unit test for function trange
def test_trange():
    from .compat import range
    from .utils import _range

    for out in (None, sys.stdout):
        for i in trange(3, file=out):
            assert i in _range(3)
    for i in trange(4, 5, file=None):
        assert i in _range(4, 5)
        break
    for i in trange(5, 4, file=None):
        assert i in _range(5, 4)
        break
    for i in trange(2, 3, 4, file=None):
        assert i in _range(2, 3, 4)
        break
    for i in trange(*_range(3), file=None):
        assert i in _range(3)
        break

# Generated at 2022-06-24 09:43:35.477802
# Unit test for function trange
def test_trange():
    """
    Tests `tqdm.auto.trange` function
    """
    # Test case 1
    assert list(trange(10)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    # Test case 2

# Generated at 2022-06-24 09:43:44.691108
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .tests._misc import _range

    trange(10)
    trange(1, 1)
    trange(2, 2)
    trange(2, 2, 2)
    trange(2, 2, 0.2)
    trange(1, 1, -1)
    trange(1, 1, -0.2)
    trange(10, 1, -1)
    trange(10, 1, -0.2)

    trange(10, desc="1")
    trange(1, 1, desc="2")
    trange(2, 2, desc="3")
    trange(2, 2, 2, desc="4")
    trange(2, 2, 0.2, desc="5")

# Generated at 2022-06-24 09:43:52.812321
# Unit test for function trange
def test_trange():
    """ Testing function trange """
    # fmt: off
    assert list(trange(1)) == [0]
    assert list(trange(1, 3, 2)) == [1]
    assert list(trange(0, 3, 2)) == [0, 2]
    assert list(trange(3, 1, -2)) == [3]
    assert list(trange(4, 1, -2)) == [4, 2]
    assert list(trange(4, 1, 1)) == []
    assert list(trange(1, 4, 0)) == [1, 1, 1, 1]
    assert list(trange(1, 1, 1)) == []
    assert list(trange(1, -1, -1)) == [1, 0, -1]

# Generated at 2022-06-24 09:43:56.183494
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    list(trange(5))
    # super lazy, just to make sure it has a docstring, why not
    assert len(trange.__doc__) > 0

# Generated at 2022-06-24 09:44:05.866201
# Unit test for function trange
def test_trange():
    """Test trange"""
    from .std import _screen_shape
    from .std import mininterval
    from .std import time as _time
    # Create only the base instance to avoid
    # interactions between tests (issue 48)
    class T(tqdm):
        """
        See :meth:`tqdm.tqdm`.

        Overrides `.miniters` attribute with a very low value
        to speed up unit tests.

        """
        miniters = 0.0001


# Generated at 2022-06-24 09:44:10.542948
# Unit test for function trange
def test_trange():
    """Test trange"""
    import pytest
    from .std import tqdm as std_tqdm
    trange = pytest.importorskip("tqdm.auto").trange

    assert trange(3) == list(std_tqdm(range(3)))
    assert isinstance(trange(3), std_tqdm)

# Generated at 2022-06-24 09:44:14.037741
# Unit test for function trange
def test_trange():
    """Test trange"""
    l = list(trange(10))
    assert l == list(range(10))
    l = list(trange(10, desc="A", leave=False))
    assert l == list(range(10))
    l = list(trange(10, desc="B", leave=True))
    assert l == list(range(10))

# Generated at 2022-06-24 09:44:18.584680
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from .gui import tgrange
    tr = trange(100)
    assert next(tr) == next(tgrange(100))
    assert repr(tr) == repr(tgrange(100))



# Generated at 2022-06-24 09:44:21.229856
# Unit test for function trange
def test_trange():
    """
    >>> from tqdm.auto import trange
    >>> for _ in trange(4):
    ...     pass
    """
    for _ in trange(4):
        pass

test_trange()

# Generated at 2022-06-24 09:44:24.671288
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .gui import tqdm

    for _ in trange(4):
        for _ in trange(10):
            for _ in trange(100):
                pass



# Generated at 2022-06-24 09:44:33.672527
# Unit test for function trange
def test_trange():
    """Test for trange"""
    for _ in trange(4, 2, 0.5, leave=False, unit_scale=False):
        pass
    for i in trange(4, 2, 2, leave=False, unit_scale=False):
        assert i == 2
    for i in trange(4, 2, -1, leave=False, unit_scale=False):
        assert i == 2
    for i in trange(4, 2, -0.5, leave=False, unit_scale=False):
        assert i == 2
    # Test trange to be wrapped by with block
    with trange(0) as t:
        assert t.total == 0

# Generated at 2022-06-24 09:44:42.366533
# Unit test for function trange
def test_trange():
    """Test function trange"""
    with trange(10) as t:
        for i in t:
            if i > 5:
                t.set_description("hi")
            elif i > 3:
                t.set_description("hello")
            elif i > 1:
                t.set_description("foo")
            elif i >= 0:
                t.set_description("bar")
            else:
                raise ValueError("i={0} < 0".format(i))
            t.update()
            if i == 2:
                t.close()
                break
    assert t.n == 3
    assert t.last_print_n == 3
    assert t.desc == "foo"

# Generated at 2022-06-24 09:44:44.856018
# Unit test for function trange
def test_trange():
    """
    Unit test for `trange`
    """
    from .utils import _range
    with tqdm(desc="Test trange", total=100) as pbar:
        assert sum(_range(100)) == sum(trange(100)) == sum(pbar)

# Generated at 2022-06-24 09:44:45.741978
# Unit test for function trange
def test_trange():
    trange(100000000)

# Generated at 2022-06-24 09:44:49.426007
# Unit test for function trange
def test_trange():  # pragma: no cover
    try:
        from time import sleep
        from tqdm.auto import trange
        for _ in trange(1):
            sleep(0.01)
    except:  # pragma: no cover
        from traceback import print_exc
        print_exc()
        sys.exit(1)

# Generated at 2022-06-24 09:44:52.726202
# Unit test for function trange
def test_trange():
    """
    Test function `tqdm.trange`.
    """
    # Test with length
    assert list(trange(10, desc='length')) == list(range(10))
    # Test without length
    assert list(trange(10, total=None, desc='none')) == list(range(10))

# Generated at 2022-06-24 09:45:00.486571
# Unit test for function trange
def test_trange():
    """Test function trange()"""
    from ._tqdm_test_examples import IterOverIterator, nested_progress_bars
    from .std import tqdm as std_tqdm

    with nested_progress_bars():
        list(tqdm(IterOverIterator(2, 3), desc='A', leave=True))
        list(tqdm(IterOverIterator(1, 1), desc='B'))
        list(tqdm(IterOverIterator(4, 1), desc='C'))
        for i in trange(4, desc='D'):
            list(tqdm(IterOverIterator(i, 1)))
    list(tqdm(range(10)))
    list(tqdm(IterOverIterator(10, 1)))

# Generated at 2022-06-24 09:45:04.764646
# Unit test for function trange
def test_trange():
    """test"""
    from tqdm import trange
    try:
        from tqdm.auto import trange
    except ImportError:
        pass

    list(trange(3))
    assert len(list(trange(1000, ncols=80))) == 1000


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:45:08.944257
# Unit test for function trange
def test_trange():
    from .asyncio import trange as atrange
    from .autonotebook import trange as nttrange
    from .std import trange as stdtrange
    for tr in [trange, atrange, nttrange, stdtrange]:
        x = tr(10)
        assert tuple(x) == tuple(range(10))

# Generated at 2022-06-24 09:45:14.776011
# Unit test for function trange
def test_trange():
    """Tests that `trange` is equivalent to `for i in tqdm(range(*args)):`"""
    from itertools import repeat
    from .std import tqdm

    for args, kwargs in [
        [(3,), {}],
        [(3, 1), {}],
        [(0, 3), {}],
        [(0, 3, -1), {}],
        [(0, 3, 1), {}],
        [(0, 3, 2), {}],
        [(0, 10, 2), {"desc": "0:10:2"}],
        [repeat(1), {}],
    ]:
        for equal in range(3):
            assert tuple(trange(*args, **kwargs)) == tuple(range(*args))

# Generated at 2022-06-24 09:45:19.599730
# Unit test for function trange
def test_trange():
    """Test function trange"""
    assert list(trange(1)) == [0]
    assert list(trange(1, 2)) == [1]
    assert list(trange(1, 3, 3)) == [1]
    assert list(trange(1, 4, 3)) == [1, 4]

# Generated at 2022-06-24 09:45:24.068546
# Unit test for function trange
def test_trange():
    """Test function trange"""
    # This will fail unless ``sys.version_info[:2] < (3, 6)``
    assert trange(10) is not None
    # This will fail unless ``sys.version_info[:2] >= (3, 6)``
    assert trange(10) is not None

# Generated at 2022-06-24 09:45:28.151567
# Unit test for function trange
def test_trange():
    """Test whether trange is properly wrapped"""
    assert tqdm(range(10)) == trange(10)
    assert tqdm(range(20)) == trange(20)
    assert tqdm(range(10), ascii=True) == trange(10, ascii=True)
    assert tqdm(range(20), ascii=True) == trange(20, ascii=True)

# Generated at 2022-06-24 09:45:30.659941
# Unit test for function trange
def test_trange():
    """
    Perform a simple test on function trange.
    """
    from sys import stdout
    from time import sleep

    for _ in trange(5):
        stdout.flush()
        sleep(.25)


# Generated at 2022-06-24 09:45:41.792477
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .utils import _range
    list(trange(3))
    list(trange(3, 0))
    list(trange(3, 0, -1))
    list(trange(3, 1))
    list(trange(3, 1, -1))
    list(trange(3, 3))
    list(trange(3, 3, -1))
    list(trange(3, 4))
    list(trange(3, 4, -1))
    list(trange(3, 5))
    list(trange(3, 5, -1))
    list(trange(3, -2))
    list(trange(3, -2, -1))
    list(trange(0, 0, -1))

# Generated at 2022-06-24 09:45:52.070362
# Unit test for function trange
def test_trange():
    """Test trange() method"""
    # Python 2
    if sys.version_info[0] == 2:
        msg = "Python 2 detected! This is not officially supported, but should work."
        warnings.warn(msg, UserWarning)
    # Test trange()
    with tqdm(disable=True) as nb_pbar:
        nb_pbar._instances.clear()
    with tqdm(total=0, disable=True) as nb_pbar:
        nb_pbar._instances.clear()
    with tqdm(disable=True) as nb_pbar:
        nb_pbar._instances.clear()
    for i in trange(10):
        assert i < 10
    with tqdm(disable=True) as nb_pbar:
        nb