

# Generated at 2022-06-24 09:35:45.149355
# Unit test for function trange
def test_trange():
    "Test that trange is shorthand for tqdm(range(i))"
    assert list(trange(4)) == list(tqdm(range(4)))

# Generated at 2022-06-24 09:35:55.657573
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    # Deprecation tests for trange
    if sys.version_info[:2] < (3, 6):
        from .asyncio import trange as asyncio_trange
        from .std import trange as std_trange
        if std_trange is asyncio_trange:
            from tqdm.tests.test_deprecation import \
                test_trange as test_trange_deprecation
            test_trange_deprecation(trange)
    else:
        from tqdm.tests.test_deprecation import \
            test_trange as test_trange_deprecation
        test_trange_deprecation(trange)

# Generated at 2022-06-24 09:35:59.708304
# Unit test for function trange
def test_trange():
    from .utils import __interactive__
    if __interactive__:
        from .auto import trange
        list(trange(10))
        assert not __interactive__, "trange(10) unit test failed"

# Generated at 2022-06-24 09:36:03.644312
# Unit test for function trange
def test_trange():
    """
    Run `help(trange)` and `trange()` in interactive mode.
    """
    print("Testing `trange()` ...")
    for _ in trange(2):
        pass
    for _ in trange(2, 0, -1):
        pass

# Generated at 2022-06-24 09:36:06.919212
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from time import sleep
    with trange(10) as t:
        for i in t:
            # Ensure trange is an iterator
            assert i == t.n
            sleep(0.01)

# Generated at 2022-06-24 09:36:09.560666
# Unit test for function trange
def test_trange():
    """Test function `tqdm.auto.trange`"""
    assert list(trange(5)) == [0, 1, 2, 3, 4]
    assert list(trange(5, 10)) == [5, 6, 7, 8, 9]

# Generated at 2022-06-24 09:36:13.485360
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .tests import trange_test  # pylint: disable=unused-import
    trange_test()
    print('Unit test for function _trange(): ok')


# Generated at 2022-06-24 09:36:15.161711
# Unit test for function trange
def test_trange():
    """
    Unit test for trange
    """
    for _ in trange(4, 5):
        pass

# Generated at 2022-06-24 09:36:18.709914
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .std import trange
    for _ in trange(4):
        pass
    for _ in trange(4, 4):
        pass
    for _ in trange(4, 1):
        pass
    for _ in trange(4, 0, -1):
        pass

# Generated at 2022-06-24 09:36:22.558287
# Unit test for function trange
def test_trange():
    """Sanity test for trange"""
    assert list(trange(5)) == list(range(5))
    assert list(trange(5, 10)) == list(range(5, 10))
    assert list(trange(0, 10, 2)) == list(range(0, 10, 2))
    assert list(trange(5, 0, -1)) == list(range(5, 0, -1))
    assert list(trange(0, -10, -1)) == list(range(0, -10, -1))

test_trange()

# Generated at 2022-06-24 09:36:32.787780
# Unit test for function trange
def test_trange():
    from .std import TqdmTypeError, TqdmKeyError
    import time

    for n in trange(4, desc='Main loop', leave=False):
        for i in trange(n, desc='Inner loop'):
            time.sleep(0.01)

    for n in trange(4, desc='Main loop', leave=False):
        for i in trange(n, desc='Inner loop'):
            time.sleep(0.01)
        trange(n, desc='Inner loop')

    l = list(trange(10))
    assert l == list(range(10))

    with trange(2, initial=1, position=1) as t:
        assert t.position == 1
        assert t.n == 2
        t.update()

# Generated at 2022-06-24 09:36:42.720407
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import trange as tqdm_trange
    from .std import tqdm

    assert list(trange(3)) == list(tqdm(range(3)))
    assert list(trange(4, 3)) == list(tqdm(range(4, 3)))
    assert list(trange(4, 2, -1)) == list(tqdm(range(4, 2, -1)))
    assert list(trange(3, 1, 0)) == list(tqdm(range(3, 1, 0)))
    assert list(trange(0)) == list(tqdm(range(0)))
    assert list(trange(0, -1)) == list(tqdm(range(0, -1)))

# Generated at 2022-06-24 09:36:45.825356
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    from .std import tqdm
    with tqdm(total=10) as pbar:
        for _ in trange(10, desc="trange", unit="it"):
            pbar.update()

del TqdmExperimentalWarning

# Generated at 2022-06-24 09:36:51.876498
# Unit test for function trange
def test_trange():
    """Test for trange"""
    assert list(trange(5)) == list(range(5))
    assert list(trange(1, 7)) == list(range(1, 7))
    assert list(trange(1, 10, 2)) == list(range(1, 10, 2))

    for i in trange(0):
        assert False, "Should not get here"

    for i in trange(0, 0):
        assert False, "Should not get here"

    for i in trange(0, 0, 1):
        assert False, "Should not get here"

    for i in trange(1, 0, -1):
        assert False, "Should not get here"

    for i in trange(1, 5, 0):
        assert False, "Should not get here"

# Generated at 2022-06-24 09:36:53.767749
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from time import sleep
    with trange(5) as t:
        for i in t:
            sleep(0.2)

# Generated at 2022-06-24 09:36:55.218029
# Unit test for function trange
def test_trange():
    """Unit test for function trange."""
    n = 100
    for i in trange(n):
        pass
    assert i == n - 1

# Generated at 2022-06-24 09:37:00.876081
# Unit test for function trange
def test_trange():
    """Test trange"""
    # pylint: disable=redefined-outer-name, bad-option-value, invalid-name
    # pylint: disable=undefined-variable
    # import here to avoid polluting
    # the namespace in an interactive session
    try:
        import numpy
        assert numpy.__version__ >= '1.7', numpy.__version__
    except (AttributeError, ImportError, AssertionError):
        # python3.5 numpy 1.12.1 : "AttributeError: module 'numpy' has no attribute '__version__'"
        # python2.6 numpy 1.7.1 : "ImportError: No module named 'numpy'"
        pass
    else:
        from tqdm import trange
        from numpy import array

# Generated at 2022-06-24 09:37:04.937912
# Unit test for function trange
def test_trange():
    """Test trange"""
    # https://github.com/tqdm/tqdm/issues/300
    seq = trange(0, 100, 0.1, unit_scale=True)
    assert len(seq) == 100
    assert sum(seq) == 5000


# Generated at 2022-06-24 09:37:14.576059
# Unit test for function trange
def test_trange():
    """
    Simple unit tests for the trange function
    """
    import time
    import sys
    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    with mock.patch('sys.stderr', new_callable=lambda: sys.stderr):
        with mock.patch('sys.stdout', new_callable=lambda: sys.stdout):
            with mock.patch('sys.stdin', new_callable=lambda: sys.stdin):
                with mock.patch('time.time', lambda: 0):
                    for _ in range(10):
                        for _ in trange(10, desc="desc", miniters=0.1,
                                        smoothing=0, leave=False, disable=True):
                            time.sleep(0.01)

# Generated at 2022-06-24 09:37:19.288999
# Unit test for function trange
def test_trange():
    """
    Unit test for tqdm.trange()

    """
    from .std import TqdmDefaultError

    trange(0)
    trange(1, 2)
    trange(2, 1)
    trange(2, 1, 1)
    trange(2, 1, -1)
    with pytest.raises(TqdmDefaultError):
        trange(2, 1, 0)
    trange(2, 1, 1, True)

# Generated at 2022-06-24 09:37:24.898566
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from ._tqdm_test.utils import closing, StringIO

    with closing(StringIO()) as our_file:
        for _ in trange(4, file=our_file):
            pass
        our_file.seek(0)
        assert "\r" not in our_file.read()

# Generated at 2022-06-24 09:37:31.492076
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    assert list(trange(5)) == list(range(5))
    assert list(trange(0)) == list(range(0))
    assert list(trange(-5)) == list(range(-5))
    assert list(trange(1, 6)) == list(range(1, 6))
    assert list(trange(1, 6, 2)) == list(range(1, 6, 2))
    assert list(trange(10, 0, -1)) == list(range(10, 0, -1))
    assert list(trange(2, 5, tqdm_cls=notebook_tqdm)) == list(range(2, 5))


# Generated at 2022-06-24 09:37:33.309571
# Unit test for function trange
def test_trange():
    """
    >>> test_trange()
    """
    assert list(trange(7)) == list(range(7))

# Generated at 2022-06-24 09:37:39.869398
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .autonotebook import trange as anb_trange
    from .asyncio import trange as aio_trange

    assert trange(2, 3) == aio_trange(2, 3)
    assert trange(2, 3) == anb_trange(2, 3)
    assert trange(2, 3, 1) == aio_trange(2, 3, 1)
    assert trange(2, 3, 1) == anb_trange(2, 3, 1)
    assert trange(2, 3, 2) == aio_trange(2, 3, 2)
    assert trange(2, 3, 2) == anb_trange(2, 3, 2)
    assert trange(2, 3, desc="test") == aio

# Generated at 2022-06-24 09:37:50.702783
# Unit test for function trange
def test_trange():
    """Unit test for tqdm.auto.trange"""
    for n in (4, 10):
        for total in (None, 100):
            with trange(n, total=total) as t:
                for _ in t:
                    pass
            assert not t.sp or len(t.sp) == t.n
            assert len(t.format_dict['desc'])
            assert len(t.format_dict['n'])  # check that n was initialised
            assert len(t.format_dict['postfix'])
            assert len(t.format_dict['rate'])
            assert len(t.format_dict['bar'])
            assert len(str(t))
            assert len(repr(t))  # check unicode support

# Generated at 2022-06-24 09:38:00.218146
# Unit test for function trange
def test_trange():
    """ Unit test for function trange """

    class TqdmDefault(tqdm):
        """ For resetting options """
        def __init__(self, *args, **kwargs):
            super(TqdmDefault, self).__init__(*args, **kwargs)

            self.disable = self.nested_timer()  # type: ignore

    with TqdmDefault(total=1) as pbar:
        assert pbar.disable is not None
        assert pbar.n != 0

    with TqdmDefault(total=1) as pbar:
        assert pbar.disable is not None
        assert pbar.n == 1
    assert pbar.disable is None
    assert pbar.n == 0

# Generated at 2022-06-24 09:38:08.874277
# Unit test for function trange
def test_trange():
    """Test for `trange`"""
    assert list(trange(5)) == [0, 1, 2, 3, 4]
    assert list(trange(1, 5)) == [1, 2, 3, 4]
    assert list(trange(1, 8, 2)) == [1, 3, 5, 7]
    assert list(trange(1, 9, 2)) == [1, 3, 5, 7]
    assert list(trange(8, 1, -2)) == [8, 6, 4, 2]
    assert list(trange(9, 1, -2)) == [9, 7, 5, 3]

# Generated at 2022-06-24 09:38:16.961713
# Unit test for function trange
def test_trange():
    """Test function `trange`."""
    from .std import tqdm
    from .utils import _range

    assert list(trange(10)) == list(_range(10))
    assert list(trange(3, 10, 0.5)) == list(_range(3, 10, 0.5))

    if sys.version_info[:2] < (3, 6):
        notebook_tqdm = tqdm
    else:
        from .asyncio import tqdm as asyncio_tqdm
        notebook_tqdm = asyncio_tqdm
    assert trange(10).__class__ == notebook_tqdm
    assert trange(3, 10).__class__ == notebook_tqdm
    assert trange(3, 10, 0.5).__class__ == notebook_tqdm
   

# Generated at 2022-06-24 09:38:19.871145
# Unit test for function trange
def test_trange():
    """
    Test with required arguments only.
    """
    list(trange(1))
    assert True


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:38:25.031787
# Unit test for function trange
def test_trange():
    """Test trange."""
    assert list(trange(7)) == list(range(7))
    assert list(trange(7, 10)) == list(range(7, 10))
    assert list(trange(7, 10, 2)) == list(range(7, 10, 2))
    assert list(trange(10, 0, -1)) == list(range(10, 0, -1))

# Generated at 2022-06-24 09:38:36.227013
# Unit test for function trange
def test_trange():
    """Test function trange."""
    assert list(trange(3)) == [0, 1, 2]
    assert list(trange(2, 3)) == [2]
    assert list(trange(2, 3, 1)) == [2]
    assert list(trange(3, 2)) == []
    assert list(trange(3, 2, 1)) == []
    assert list(trange(3, 2, -1)) == [3, 2]
    assert list(trange(0, 100, 10)) == [0, 10, 20, 30, 40, 50, 60, 70, 80, 90]
    assert list(trange(100, 0, -10)) == [100, 90, 80, 70, 60, 50, 40, 30, 20, 10]

# Generated at 2022-06-24 09:38:46.751132
# Unit test for function trange
def test_trange():
    """
    Tests function `trange()`
    """
    assert list(trange(0)) == []
    assert list(trange(2)) == [0, 1]
    assert list(trange(3, 1)) == [3, 4, 5]
    assert list(trange(1, 3)) == [1, 2]
    assert list(trange(1, 3, 2)) == [1, 3]
    assert list(trange(-1, -3)) == []
    assert list(trange(-1, -3, -1)) == [-1, -2]
    assert list(trange(-1, -3, -2)) == [-1, -3]
    assert list(trange(-3, -1)) == [-3, -2]
    assert list(trange(-3, -1, -2)) == []

# Generated at 2022-06-24 09:38:47.662301
# Unit test for function trange
def test_trange():
    """Smoke test for function trange"""
    

# Generated at 2022-06-24 09:38:52.045478
# Unit test for function trange
def test_trange():
    assert trange == tqdm
    trange(3)
    trange(3, position=0)
    trange(3, total=3)
    trange(3, total=3, position=0)
    trange(3, total=3, position=1)
    trange(3, total=3, position=1, leave=False)
    trange(3, total=3, position=1, leave=True)


# Unit tests for tqdm functions

# Generated at 2022-06-24 09:39:01.360987
# Unit test for function trange
def test_trange():
    assert list(trange(1)) == [0]
    assert list(trange(1, 1)) == []
    assert list(trange(2, 1)) == []
    assert list(trange(1, 2)) == [1]
    assert list(trange(1, 3, 2)) == [1]
    assert list(trange(4, 1, -1)) == [4, 3, 2]
    assert list(trange(4, -2, -2)) == [4, 2, 0, -2]
    assert list(trange(4, -5, -2)) == [4, 2, 0, -2, -4]
    assert list(trange(4, -7, -2)) == [4, 2, 0, -2, -4, -6]

# Generated at 2022-06-24 09:39:11.816496
# Unit test for function trange
def test_trange():
    """
    Tests `trange` functionality.
    """
    from .std import TqdmDeprecationWarning
    from .std import tqdm as _tqdm

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmDeprecationWarning)

        # check if execution is correct
        assert sum(trange(10)) == 45
        assert sum(trange(10, desc='test')) == 45
        assert sum(trange(10, leave=True)) == 45
        assert sum(trange(10, dynamic_ncols=True)) == 45
        assert sum(trange(10, mininterval=0.1)) == 45
        assert sum(trange(10, miniters=1)) == 45
        assert sum(trange(10, unit='blocks')) == 45


# Generated at 2022-06-24 09:39:18.717649
# Unit test for function trange
def test_trange():
    """Test function trange"""
    T = tqdm

    with T(0) as t:
        assert not t.disable
        for _ in trange(4, desc="1st loop", leave=True):
            for __ in trange(5, desc="2nd loop", leave=True):
                for _ in trange(50, desc="3rd loop", leave=True):
                    for __ in trange(11, desc="4th loop", leave=True):
                        t.update()

# Generated at 2022-06-24 09:39:20.570864
# Unit test for function trange
def test_trange():
    """Simple unit test for trange"""
    for _ in trange(10, desc="trange"):
        pass

# Generated at 2022-06-24 09:39:28.108501
# Unit test for function trange
def test_trange():
    """
    trange()
    """
    from .std import tqdm
    # Test trange and tqdm basic functionality
    list(trange(0))
    list(tqdm(range(0)))
    list(trange(3))
    list(tqdm(range(3)))
    list(trange(3, 1))
    list(tqdm(range(3, 1)))
    list(trange(3, 1, -1))
    list(tqdm(range(3, 1, -1)))
    list(trange(1, 3))
    list(tqdm(range(1, 3)))
    list(trange(1, 3, 1))
    list(tqdm(range(1, 3, 1)))
    list(trange(10, 0, -1))
   

# Generated at 2022-06-24 09:39:36.777869
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    from .std import tqdm

    try:
        trange = from_cnf('trange')
    except ImportError:
        trange = __class__.trange

    config = {"miniters": 1}
    for _ in range(3):
        for total in [None, 10, 12]:
            for leave in [True, False]:
                for unit in [None, "unit"]:
                    for dynamic_ncols in [True, False]:
                        config["leave"] = leave
                        config["unit"] = unit
                        config["dynamic_ncols"] = dynamic_ncols
                        with tqdm(**config) as pbar:
                            for _ in trange(total=total):
                                pbar.update()


# Generated at 2022-06-24 09:39:42.543800
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    Unit test for function `trange`.
    """
    assert list(trange(10)) == list(range(10))
    assert list(trange(1, 11, 2)) == list(range(1, 11, 2))
    assert list(trange(1, 11)) == list(range(1, 11))
    assert list(trange(10, 1, -2)) == list(range(10, 1, -2))

# Generated at 2022-06-24 09:39:46.669871
# Unit test for function trange
def test_trange():
    """
    Test function 'trange' by comparing it to function 'xrange'
    """
    *_, last_it = trange(3)  # pylint: disable=unused-variable
    assert last_it == 2
    *_, last_it = tqdm(range(3))  # pylint: disable=unused-variable
    assert last_it == 2

# Generated at 2022-06-24 09:39:49.921618
# Unit test for function trange
def test_trange():
    """ Unit test for function trange """
    import time
    # Fix tests failing when multiple instances are running
    with tqdm.external_write_mode():
        for _ in trange(20):
            time.sleep(0.01)
        for _ in trange(20):
            time.sleep(0.01)

# Generated at 2022-06-24 09:40:00.763832
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    import subprocess
    from tqdm.utils import _screen_shape_wrapper

    with _screen_shape_wrapper() as shape:
        if shape is None:
            return True

        # Run tests (in subprocess)

# Generated at 2022-06-24 09:40:07.474579
# Unit test for function trange
def test_trange():
    """Test for trange function"""
    # loop
    sum_ = 0
    for _ in trange(1, 2):
        sum_ += 1
    assert sum_ == 1
    # iterable
    sum_ = 0
    for _ in trange([1, 2]):
        sum_ += 1
    assert sum_ == 2
    # no loop
    assert next(trange(0)) is None
    # # None
    assert trange(None) is None

# Generated at 2022-06-24 09:40:11.363412
# Unit test for function trange
def test_trange():
    try:
        nonlocal_var = False  # Python3
    except NameError:
        nonlocal_var = 0  # Python2
    for _ in trange(3, desc="trange"):
        nonlocal_var = True
    assert nonlocal_var

# Generated at 2022-06-24 09:40:15.180578
# Unit test for function trange
def test_trange():
    """Simple unit test for trange"""
    import sys
    import subprocess
    # Run unit tests with pytest on python 2 but use unittest for 3.x
    if sys.version_info[0] == 2:
        subprocess.call(["py.test", "--pyargs", "tqdm"])
    else:
        from .tests import test_trange
        del sys.modules["tqdm.tests"]

# Generated at 2022-06-24 09:40:20.566066
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from tqdm.auto import trange
    with trange(2) as t:
        t.set_postfix({"a": 1})
        t.update()
        t.update()
        t.update()


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 09:40:23.681751
# Unit test for function trange
def test_trange():
    """Test trange"""
    # Ignore global variable
    # pylint: disable=W0603
    global trange, tqdm
    trange, tqdm = None, None
    from .auto import trange, tqdm

    list(tqdm(trange(3)))

# Generated at 2022-06-24 09:40:34.649108
# Unit test for function trange
def test_trange():
    """Test auto trange numerics."""
    it = trange(0, 3)

    # Test numerics
    assert next(it) == 0
    assert it.n == 1

    assert next(it) == 1
    assert it.n == 2

    assert next(it) == 2
    assert it.n == 3

    assert it.total == 3
    assert it.n == 3
    assert it.last_print_n == 3

    assert it.last_print_t is not None
    assert it.n_fmt_precision == -1

    with pytest.raises(StopIteration):
        next(it)

# Generated at 2022-06-24 09:40:43.030307
# Unit test for function trange
def test_trange():
    "Tests trange function"
    from .gui import trange
    from .utils import format_sizeof

    for i in trange(10, desc='desc1', leave=False):
        if i == 5:
            for j in trange(100, desc='desc2', leave=False):
                pass
        pass

    for _i in trange(1000, desc='desc2') or trange(10):
        pass

    with tqdm(total=1) as pbar:
        pbar.desc = """This is the description"""
        pbar.write("This is the initial display")

    with tqdm(total=10, smoothing=0) as pbar:
        for i in pbar:
            pbar.set_description("Step %i" % i)


# Generated at 2022-06-24 09:40:51.106540
# Unit test for function trange
def test_trange():
    """Test cases for trange func"""
    # pylint: disable=protected-access
    # pylint: disable=cell-var-from-loop

# Generated at 2022-06-24 09:41:00.196441
# Unit test for function trange
def test_trange():
    """
    Test that trange is equivalent to tqdm(range)
    """
    from .std import trange as std_trange
    from .asyncio import trange as asyncio_trange
    from .autonotebook import trange as notebook_trange

    for args, kwargs in [
        ((5,), dict()),
        ((0, 100, 10), dict()),
        ((10, 100, -10), dict(desc="desc")),
    ]:
        assert tuple(trange(*args, **kwargs)) == tuple(tqdm(range(*args), **kwargs))
        assert tuple(trange(*args, **kwargs)) == tuple(std_trange(*args, **kwargs))

# Generated at 2022-06-24 09:41:05.862912
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange

    :return: 0 if all passed, non-zero if any failed
    """
    def _assert(tf):
        if tf:
            return 0
        else:
            print("tqdm.auto.trange test fail")
            return 1

    tqdm.set_lock(False)
    r1 = trange(5)
    r2 = tqdm(range(5))

    try:
        for i1, i2 in zip(r1, r2):
            assert i1 == i2
    except KeyboardInterrupt:
        pass
    finally:
        tqdm.set_lock(True)

    return _assert(type(r1) == type(r2))


# Generated at 2022-06-24 09:41:15.999756
# Unit test for function trange
def test_trange():
    """Test for trange function"""
    from .std import total_seconds
    from .utils import format_sizeof
    from .std import _range
    from .std import _Time

    # Test basic functionality
    for s in (1, 3, 7):
        t = _Time(total_seconds(s))
        assert t.format(format_sizeof(t.n) + " ")[0] == str(s)

    # Test: seconds, minutes, hours

# Generated at 2022-06-24 09:41:23.523265
# Unit test for function trange
def test_trange():
    """ Tests trange() """
    import time
    import os
    import sys

    # check if trange() works
    if sys.version_info >= (3, 3):
        import unittest.mock as mock
        mock_stdout = mock.Mock()
        with mock.patch('sys.stdout', mock_stdout):
            list(trange(9, unit="test", desc="trange_test_0"))
        assert mock_stdout.write.call_count == 9, "trange() failed"
        with mock.patch('sys.stdout', mock_stdout):
            list(trange(9, leave=True, unit="test", desc="trange_test_1"))
        assert mock_stdout.write.call_count == 18, "trange() failed"

    # check if trange()

# Generated at 2022-06-24 09:41:25.895503
# Unit test for function trange
def test_trange():
    """Test trange function"""
    assert list(trange(5)) == [0, 1, 2, 3, 4]



# Generated at 2022-06-24 09:41:31.787700
# Unit test for function trange
def test_trange():
    """Test trange"""
    # Test all verbose kwargs
    assert sum(trange(3)) == 3
    assert sum(trange(3, 0, -1)) == 6
    assert sum(trange(3, 1)) == 3
    assert sum(trange(3, 2)) == 0
    assert sum(trange(3, 2, 1)) == -3

    # Test some keywords
    assert sum(trange(3, ascii=True)) == 3
    assert sum(trange(3, mininterval=0)) == 3
    assert sum(trange(1, unit="i")) == 1

# Generated at 2022-06-24 09:41:41.998562
# Unit test for function trange
def test_trange():
    """
    Test function `trange`
    """
    assert list(trange(10, desc='test')) == list(range(10))
    assert list(trange(10, mininterval=1, miniters=1, desc='test')) == list(range(10))
    assert list(trange(10, 2.0, 2, 1.0, desc='test')) == list(range(10))
    assert list(trange(10, ncols=80, desc='test')) == list(range(10))
    assert list(trange(10, file=sys.stdout, desc='test')) == list(range(10))
    assert list(trange(10, leave=True, desc='test')) == list(range(10))

# Generated at 2022-06-24 09:41:47.895549
# Unit test for function trange
def test_trange():
    """Unit test for `tqdm.auto.trange()`"""
    kwargs = dict(total=10, initial=2, miniters=10)
    trange_gen = trange(**kwargs)
    assert isinstance(trange_gen, tqdm)
    assert list(trange_gen) == list(range(*trange_gen.kwargs['args']))
    assert trange_gen.kwargs['args'] == (0, 10)
    assert trange_gen.kwargs['kwargs'] == kwargs

# Generated at 2022-06-24 09:41:55.477067
# Unit test for function trange
def test_trange():
    """Remains to be done"""
    for _ in trange(3, desc='1st loop'):
        for _ in trange(1, 4, desc='2nd loop', leave=False):
            for _ in trange(5, desc='3nd loop'):
                for _ in trange(100):
                    pass


# Generated at 2022-06-24 09:42:05.169285
# Unit test for function trange
def test_trange():
    """Test trange"""
    # pylint: disable=g-import-not-at-top
    from .std import tqdm as std_tqdm
    from .gui import tqdm as gui_tqdm
    from .utils import _screen_shape

    # Test against old-style range
    assert list(trange(10)) == list(range(10))
    # Test tqdm wrapper
    assert list(tqdm(range(10))) == list(range(10))
    # Test against old-style range
    assert list(trange(10, 0, -1)) == list(range(10, 0, -1))
    # Test tqdm wrapper
    assert list(tqdm(range(10, 0, -1))) == list(range(10, 0, -1))
    # Test against old-

# Generated at 2022-06-24 09:42:13.365953
# Unit test for function trange
def test_trange():
    # Test trange parameters
    assert list(trange(3, 10, 2)) == [3, 5, 7, 9]
    assert list(trange(3, 10, 2, desc='Testing')) == [3, 5, 7, 9]
    assert len(list(trange(3, 10, 2, ascii=True))) == 4
    assert len(list(trange(3, 10, 2, ascii=False))) == 4
    assert len(list(trange(3, 10, 2, ascii=True, mininterval=5))) == 4
    assert len(list(trange(3, 10, 2, ascii=False, mininterval=5))) == 4

# Generated at 2022-06-24 09:42:19.992399
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import trange
    from .tqdm import tqdm
    from .gui import tqdm as gui_tqdm  # pylint: disable=unused-variable

    for cls in [tqdm, gui_tqdm]:
        for x in trange(0):
            assert x == 0
        for x in trange(3):
            assert x == 0 or x == 1 or x == 2
        for x in trange(3, desc='foo'):
            assert x == 0 or x == 1 or x == 2
        for x in trange(3, 5):
            assert x == 3 or x == 4
        for x in trange(3, 5, desc='foo'):
            assert x == 3 or x == 4

# Generated at 2022-06-24 09:42:29.918300
# Unit test for function trange
def test_trange():
    import sys
    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO
    from .std import trange

    s = StringIO()
    for _ in trange(4, file=s):
        pass

# Generated at 2022-06-24 09:42:32.370676
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    for _ in trange(4):
        pass
    for _ in trange(4, 0, -1):
        pass
    for _ in trange(4, postfix="test"):
        pass

# Generated at 2022-06-24 09:42:41.400897
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import _range  # pylint: disable=protected-access

    def _test_trange():
        """
        Tests that trange is an alias of tqdm(range) and
        tqdm.auto.trange() matches tqdm.auto.tqdm(range)
        """
        for i in trange(10):
            pass
        assert i == 9

    _test_trange()

    def _test_custom_trange():
        """
        Tests that when the nested function trange is defined
        that it can still find the local trange function
        """
        def trange(*args, **kwargs):
            return _range(*args, **kwargs)

        for i in trange(10):
            pass
        assert i == 9

# Generated at 2022-06-24 09:42:49.267751
# Unit test for function trange
def test_trange():
    from ._utils import _range
    list(trange(3))
    list(trange(3, 1))
    list(trange(3, 1, -1))
    list(trange(3, 1, -1, desc='foobar', leave=False))

    assert _range(0, 3, 1, '', False) == list(trange(3))
    assert _range(3, 1, -1, '', False) == list(trange(3, 1, -1))
    assert _range(0, 3, 1, 'foobar', True) == list(trange(3, desc='foobar'))
    assert _rang

# Generated at 2022-06-24 09:43:00.160076
# Unit test for function trange
def test_trange():
    from io import StringIO
    from .std import tqdm

    result = None
    for result in trange(0):
        pass

    with tqdm(range(0)) as t:
        for _ in t:
            pass
    res2 = list(t)
    assert (result == res2), "trange fails with list(t) support"

    orig_stdout_name = sys.stdout.name
    sys.stdout.name = '<stdout>'  # Override issue introduced in 8347
    str_io = StringIO(newline="")
    with tqdm(range(10), file=str_io) as t:
        for _ in t:
            pass
    sys.stdout.name = orig_stdout_name

    orig_stdout = sys.stdout

# Generated at 2022-06-24 09:43:05.474696
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    assert list(trange(10, ncols=60)) == list(range(10))

    try:
        list(trange(10, ncols=0))
    except ValueError as e:
        assert str(e) == "ncols=0 invalid"
    else:
        raise ValueError("ncols=0 should be invalid")

# Generated at 2022-06-24 09:43:07.930219
# Unit test for function trange
def test_trange():
    with tqdm(total=100) as t:
        for i in trange(100):
            t.update()
            assert t.n == i + 1

# Generated at 2022-06-24 09:43:10.163561
# Unit test for function trange
def test_trange():
    """Tests that trange is a wrapper for tqdm"""
    for i in trange(2, 3, 1, desc="test"):
        assert i == 2

# Generated at 2022-06-24 09:43:20.321909
# Unit test for function trange
def test_trange():
    """Test that trange(...) works as expected

    Returns
    -------
    True if the tests pass, else raises an error.
    """
    import sys
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    def mock_range(*args):
        """A function that works like range, but asserts that the
        iteration does not seem to have been accelerated.
        """
        assert not hasattr(builtins, "xrange")
        assert not hasattr(builtins, "xrange")
        return range(*args)

    saved_builtins = builtins.range
    saved_xrange = sys.modules["builtins"].range
    builtins.range = mock_range
    sys.modules["builtins"].range = mock_range

# Generated at 2022-06-24 09:43:22.423372
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    sum_ = 0
    for i in trange(5):
        sum_ += i
    assert sum_ == 10



# Generated at 2022-06-24 09:43:25.020377
# Unit test for function trange
def test_trange():
    """
    Unit test for trange
    """
    lst = list(trange(1000))
    assert lst == list(range(1000))

# Generated at 2022-06-24 09:43:34.990108
# Unit test for function trange
def test_trange():
    """
    Smoke test for `tqdm.auto.trange`

    :return: nothing
    """
    # Make sure that trange works with default options
    assert list(trange(7)) == list(range(7))
    # Make sure that trange works with fixed unit
    assert list(trange(7, unit='test')) == list(range(7))
    # Make sure that trange works with fixed leave
    assert list(trange(7, leave=True)) == list(range(7))
    # Make sure that trange works with fixed leave and unit
    assert list(trange(7, leave=True, unit='test')) == list(range(7))
    # Make sure that trange works with fixed unit and desc
    assert list(trange(7, unit='test', desc='test trange')) == list

# Generated at 2022-06-24 09:43:36.837458
# Unit test for function trange
def test_trange():
    """
    >>> test_trange()
    10
    """
    assert next(iter(trange(10))) == 10 - 1

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 09:43:42.117742
# Unit test for function trange
def test_trange():
    """
    Tester function
    """
    t = trange(8)
    assert '1/8' in repr(t)
    assert t.n == 8
    t.update(1)
    assert t.n == 1
    assert t.last_print_n == 0
    assert '1/8' in repr(t)
    t.update(3)
    assert t.n == 4
    assert t.last_print_n == 1
    assert '1-4/8' in repr(t)
    t.update(8)
    assert t.n == 8
    assert t.last_print_n == 4
    assert '1-8/8' in repr(t)
    t.update()
    assert t.n == 9
    assert t.last_print_n == 5

# Generated at 2022-06-24 09:43:51.170909
# Unit test for function trange
def test_trange():
    """Test trange"""
    from ._utils import _range
    # Test basic range
    assert list(tqdm(tqdm(_range(3), desc="test"))) == list(_range(3)) == list(range(3))
    # Test start parameter
    assert list(tqdm(tqdm(_range(3), start=3, desc="test"))) == list(range(3, 6))

    # Test total parameter
    assert list(tqdm(tqdm(_range(3), total=3, desc="test"))) == list(range(3))
    assert list(tqdm(tqdm(_range(3), total=4, desc="test"))) == list(range(4))

    # Test dynamic_ncols
    assert tqdm._dynamic_ncols() == tqdm._dynamic

# Generated at 2022-06-24 09:44:02.669626
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    from .std import trange
    ret = list(trange(10))
    assert (ret == list(range(10)))


# Basic test to make sure that auto.tqdm works (via readthedocs)
# Travis failing to import guitools

# Generated at 2022-06-24 09:44:05.808868
# Unit test for function trange
def test_trange():
    """Test `tqdm.auto.trange` against `notebook_tqdm.tqdm(range(3))`"""
    assert trange(3).__class__.__name__ == notebook_tqdm(range(3)).__class__.__name__

# Generated at 2022-06-24 09:44:08.285504
# Unit test for function trange
def test_trange():  # pragma: no cover
    for _ in trange(10, desc='foo'):
        pass

# Generated at 2022-06-24 09:44:15.220037
# Unit test for function trange
def test_trange():
    from .utils import _range  # NOQA pylint: disable=import-error
    for _range in (range, _range):
        for s in [0, 1, 2, 4]:
            assert list(trange(s, 0, -1)) == list(_range(s, 0, -1))
            assert list(trange(s, -1, -1)) == list(_range(s, -1, -1))
            assert list(trange(s, -1, 1)) == list(_range(s, -1, 1))
            assert list(trange(s)) == list(_range(s))
            assert list(trange(s, None)) == list(_range(s, None))
            assert list(trange(s, None, None)) == list(_range(s, None, None))

# Generated at 2022-06-24 09:44:18.495402
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    assert trange(10).__repr__() == range(10).__repr__()

# Generated at 2022-06-24 09:44:25.582295
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from .gui import tqdm_gui
    from .std import tqdm

# Generated at 2022-06-24 09:44:29.430339
# Unit test for function trange
def test_trange():
    """Unit test for function `trange`"""
    import time

    with tqdm(total=10) as t:
        for i in trange(5):
            t.update(2)
            time.sleep(0.1)

# Generated at 2022-06-24 09:44:33.207385
# Unit test for function trange
def test_trange():
    " Test trange function "
    # Smoke test
    for _ in trange(10):
        pass

    # Test `desc` parameter
    for _ in trange(10, desc="desc"):
        pass

    # Test `leave` parameter
    for _ in trange(10, leave=True):
        pass

# Generated at 2022-06-24 09:44:39.811230
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    from ._utils import _range  # pylint: disable=protected-access

    list(trange(3))
    list(trange(3, 0))
    list(trange(3, 1))

    # Testing without total
    progress_bar = trange(1, leave=False)
    try:
        list(progress_bar)
    except (KeyError, ValueError):
        pass
    if _range is not range:
        del _range

# Generated at 2022-06-24 09:44:41.055707
# Unit test for function trange
def test_trange():
    "Unit test for function trange"
    trange(10)

# Generated at 2022-06-24 09:44:45.266327
# Unit test for function trange
def test_trange():
    """Tests function trange"""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert list(trange(10)) == list(tqdm(range(10)))


if __name__ == "__main__":
    test_trange()
    sys.exit(0)

# Generated at 2022-06-24 09:44:47.596198
# Unit test for function trange
def test_trange():
    from .std import tqdm as tqdms
    assert tqdm == tqdms
    assert tqdm(range(3)) == tqdms(range(3))

# Generated at 2022-06-24 09:44:53.731813
# Unit test for function trange
def test_trange():
    from .autonotebook import trange
    from .asyncio import tqdm as asyncio_tqdm
    assert trange(2) == list(tqdm(range(2)))
    assert trange(2) == list(asyncio_tqdm(range(2)))
    assert trange(2, desc='desc') == list(tqdm(range(2), desc='desc'))
    assert trange(2, desc='desc') == list(asyncio_tqdm(range(2), desc='desc'))



# Generated at 2022-06-24 09:45:03.091053
# Unit test for function trange
def test_trange():
    """
    Tests that `tqdm.tqdm(range(i)) == tqdm.trange(i)`.

    :return: True if all test passed
    :rtype: bool
    """
    from .tqdm import tqdm
    # additional import for testing purposes only
    from .tqdm_gui import tgrange
    # additional import for testing purposes only
    try:
        from unittest import mock
    except ImportError:  # pragma: no cover
        import mock
    try:
        from io import StringIO
    except ImportError:  # pragma: no cover
        from StringIO import StringIO


# Generated at 2022-06-24 09:45:07.066356
# Unit test for function trange
def test_trange():
    from unittest import TestCase
    from .utils import _range

    class TestTrange(TestCase):
        def test(self):
            for n in _range(10):
                self.assertEqual(list(trange(n, desc="test trange")), list(_range(n)))

    test = TestTrange()
    test.test()

# Generated at 2022-06-24 09:45:09.306016
# Unit test for function trange
def test_trange():
    """Test that trange returns correct results"""
    from .std import trange
    import pytest
    for i in trange(4):
        pass

# Generated at 2022-06-24 09:45:14.517720
# Unit test for function trange
def test_trange():
    """Test trange (local test)."""
    from .utils import _version

    assert list(trange(3)) == list(tqdm(list(range(3))))
    assert list(trange(3)) == list(notebook_trange(3))
    assert list(trange(3)) == list(range(3))

    trange(3, leave=True)
    tqdm(range(3), leave=True)
    notebook_trange(3, leave=True)

    assert tqdm
    assert trange
    assert tqdm.__doc__

    print(_version.get_versions()["version"])


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:45:18.075057
# Unit test for function trange
def test_trange():
    """Test function trange via function test()."""
    from .tests import test

    for _ in trange(3, desc='Testing', leave=False):
        test()

# Generated at 2022-06-24 09:45:27.169198
# Unit test for function trange
def test_trange():
    from .utils import _term_move_up
    from .utils import _range
    from .std import _blocked_stdout_setting
    from .std import tqdm
    import sys

    n = 1000
    outputs = []
    with _blocked_stdout_setting():
        with tqdm(total=n) as t:
            for i in trange(0, n):
                # Test .format(**locals())
                outputs.append(str(t))

                t.update(666)
                sys.stdout.write("\n")
                sys.stdout.flush()

                # Test for properly restoring terminal state (restore newlines)
                outputs.append("a" + _term_move_up() + "\n" + _term_move_up())
                sys.stdout.write("\n")

# Generated at 2022-06-24 09:45:33.807878
# Unit test for function trange
def test_trange():
    """
    Unit tests for :func:`tqdm.auto.trange`.
    """
    # Test legacy `tqdm.tqdm` function
    import subprocess
    from .std import tqdm as legacy_tqdm

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert legacy_tqdm(10).__repr__() == '10it [00:00, ?it/s]'

    # Test if `tqdm.auto` is aliasing `tqdm.autonotebook`
    assert tqdm(10).__repr__() == '10it [00:00, ?it/s]'
    assert trange(10).__repr__() == '10it [00:00, ?it/s]'

    #

# Generated at 2022-06-24 09:45:37.199435
# Unit test for function trange
def test_trange():  # pragma: no cover
    "Unit test for function trange"
    return tqdm(range(10), ascii=True, dynamic_ncols=True)

# Generated at 2022-06-24 09:45:39.113585
# Unit test for function trange
def test_trange():
    """
    Tests whether trange is able to be called
    """
    trange(4)

# Generated at 2022-06-24 09:45:40.299693
# Unit test for function trange
def test_trange():
    l = [i for i in trange(1000)]
    assert len(l) == 1000