

# Generated at 2022-06-24 09:35:49.208987
# Unit test for function trange
def test_trange():
    """Test for trange function"""
    from .std import tqdm
    for i in trange(8):
        if i == 5:
            break
        i += 1
    # No exception raised
    with trange(10) as t:
        for i in t:
            if i == 8:
                break
            i += 1
    assert i == 8

# Generated at 2022-06-24 09:35:54.625434
# Unit test for function trange
def test_trange():
    """Test of `auto.trange`."""
    assert list(trange(100)) == list(range(100))
    assert list(trange(100, desc="desc")) == list(range(100))
    assert list(trange(100, desc="desc", ascii=True)) == list(range(100))
    assert list(trange(100, desc="desc", leave=True)) == list(range(100))

# Generated at 2022-06-24 09:36:00.077730
# Unit test for function trange
def test_trange():
    """Test that trange acts like range"""
    for i in range(3):
        for j in range(3):
            for k in range(3):
                for l in range(3):
                    for m in range(3):
                        assert list(trange(i)) == list(range(i))
                        assert list(trange(i, j)) == list(range(i, j))
                        assert list(trange(i, j, k)) == list(range(i, j, k))
                        assert list(trange(i, j, k, l)) == list(range(i, j, k, l))
                        assert list(trange(i, j, k, l, m)) == list(range(i, j, k, l, m))

# Generated at 2022-06-24 09:36:09.562043
# Unit test for function trange
def test_trange():
    import re
    from .trange import format_sizeof
    from .std import FormatBase

    for cls_ in (tqdm, notebook_tqdm):
        if cls_ is not tqdm:
            continue
        for index, obj in enumerate([FormatBase,
                              cls_,
                              cls_(ascii=True),
                              trange(3),
                              trange(3, ascii=True)]):
            assert not re.search(r'[\x80-\xff]', str(format_sizeof(obj)))
            assert not re.search(r'[\x80-\xff]', str(format_sizeof(obj, index)))

# Generated at 2022-06-24 09:36:13.484918
# Unit test for function trange
def test_trange():
    """Test that function trange is recognized as a function
    from tqdm.auto.trange import trange"""
    # pylint: disable=unused-variable
    from tqdm.auto import trange
    assert trange is not None

# Generated at 2022-06-24 09:36:15.418577
# Unit test for function trange
def test_trange():
    """`trange` unit test"""
    for attr in dir(tqdm):
        if not attr.startswith("_"):
            assert getattr(tqdm, attr) == getattr(trange, attr)



# Generated at 2022-06-24 09:36:18.341967
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Simple unit test for function `trange`"""
    # Print all numbers from 0 to 9
    for _ in trange(10):
        pass
    # Same with no `for` loop
    list(trange(10))

# Generated at 2022-06-24 09:36:27.572912
# Unit test for function trange
def test_trange():
    from .std import tqdm as std_tqdm
    from .autonotebook import tqdm as notebook_tqdm


# Generated at 2022-06-24 09:36:30.545847
# Unit test for function trange
def test_trange():
    """ Smoke testing """
    import time

    with tqdm(total=100) as pbar:
        for _ in trange(10):
            pbar.update(10)
            time.sleep(0.01)

# Generated at 2022-06-24 09:36:39.063356
# Unit test for function trange
def test_trange():
    """ Test function trange. """
    with tqdm(total=7) as progressbar:
        # Test raising exception with tqdm,
        # _tqdm_gui.py's Exception in thread Thread-TqdmUpdate.
        # For Python3.6+, this is not an issue and thus safe to ignore.
        from .asyncio import TqdmAsyncIo
        if isinstance(progressbar, TqdmAsyncIo):  # pragma: no cover
            raise Exception("Cannot raise exception in TqdmAsyncIo")
        progressbar.update(1)
        progressbar.update()
        progressbar.update()
        progressbar.update()
        progressbar.update()
        progressbar.update()
        progressbar.update(1)
        assert progressbar.n == 7


# Generated at 2022-06-24 09:36:42.506769
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange

    >>> list(trange(5))
    [0, 1, 2, 3, 4]
    """
    return list(trange(5)) == [0, 1, 2, 3, 4]

# Generated at 2022-06-24 09:36:51.483492
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import tqdm
    from .std import __version__
    expected = list(range(10))
    for i in trange(10):
        assert i == expected.pop(0)

    assert not expected

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        import tqdm.autonotebook
        if not hasattr(tqdm.autonotebook, "tqdm_gui"):
            import pytest  # Skip tests if tqdm_gui is not installed
            pytest.skip()

    expected = list(range(10))
    for i in trange(10, gui=True):
        assert i == expected.pop(0)
    assert not expected


# Generated at 2022-06-24 09:36:53.579766
# Unit test for function trange
def test_trange():
    "test trange"
    list(trange(3, desc='Trange:', leave=False))
    with trange(3, desc='Trange:', leave=True) as t:
        t.update(1)

# Generated at 2022-06-24 09:36:54.677010
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    assert list(trange(20)) == list(range(20))

# Generated at 2022-06-24 09:36:59.666049
# Unit test for function trange
def test_trange():
    """Test function `trange`"""
    assert trange(5) == notebook_trange(5)
    assert trange(5) == asyncio_tqdm(range(5))
    assert trange(5) == std_tqdm(range(5))

__all__.append('test_trange')

# Generated at 2022-06-24 09:37:02.554870
# Unit test for function trange
def test_trange():
    from .std import tqdm
    for _ in trange(10):
        assert isinstance(tqdm.get_instances()[0], tqdm)

# Generated at 2022-06-24 09:37:06.922621
# Unit test for function trange
def test_trange():
    """Test trange"""
    _rng = list(range(10))
    assert list(trange(10)) == _rng
    assert list(trange(1, 11)) == _rng
    assert list(trange(1, 12, 2)) == list(range(1, 12, 2))

# Generated at 2022-06-24 09:37:14.005669
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    # Parameter: ascii
    with tqdm(ascii=True) as t:
        assert hasattr(t, "_unicode") and not t._unicode
        # Check for wrapping
        t.write("x" * 70, file=t.file)
        t.update()

    # Parameter: mininterval
    with tqdm(mininterval=0, disable=True) as t:
        t.update(1)
        assert t.dynamic_miniters



# Generated at 2022-06-24 09:37:22.929992
# Unit test for function trange
def test_trange():
    from sys import version_info
    from contextlib import redirect_stderr
    from io import StringIO
    from .gui import tqdm_gui
    with redirect_stderr(StringIO()):
        for _ in trange(3, desc='ignored', leave=True):
            for _ in trange(2):
                for __ in trange(1):
                    pass
                pass
            pass
        for _ in tqdm(range(3), desc='ignored', leave=True):
            for _ in tqdm(range(2)):
                for __ in tqdm(range(1)):
                    pass
                pass
            pass
        g = tqdm_gui(total=6)
        for i in range(6):
            g.update(i + 1)
        g.close()

# Generated at 2022-06-24 09:37:27.563032
# Unit test for function trange
def test_trange():
    """Test for the function trange()."""
    assert trange(0) == []
    assert trange(10) == list(range(10))
    assert trange(1, 10) == list(range(1, 10))
    assert trange(20, 30) == list(range(20, 30))
    assert trange(0, 10, 2) == list(range(0, 10, 2))

# Generated at 2022-06-24 09:37:31.289458
# Unit test for function trange
def test_trange():
    from .autonotebook import trange
    test_range = [0, 1, 2]
    for _ in trange(len(test_range)):
        assert test_range.pop(0) == 0

# Generated at 2022-06-24 09:37:41.287174
# Unit test for function trange
def test_trange():
    from .utils import _term_move_up
    from .utils import _range

    # Test set up
    sys.stderr.write('\x1b[?25l')  # hide cursor
    sys.stderr.flush()

# Generated at 2022-06-24 09:37:44.439637
# Unit test for function trange
def test_trange():
    """
    Simple sanity check for trange()
    """
    for _ in trange(1):
        pass

# Generated at 2022-06-24 09:37:47.738789
# Unit test for function trange
def test_trange():
    assert len(list(trange(10))) == 10
    assert len(list(trange(10, 5))) == 10
    assert len(list(trange(10, 5, -1))) == 10

# Generated at 2022-06-24 09:37:57.193484
# Unit test for function trange
def test_trange():
    from .std import tqdm
    from .std import trange as std_trange

    i = 0
    for _ in std_trange(3):
        for _ in std_trange(2):
            for _ in std_trange(2):
                i += 1
    try:
        assert i == 3 * 2 * 2
    except AssertionError:
        raise AssertionError("Error in trange")

    import math
    i = 0
    for _ in tqdm(range(int(math.pow(10, 6)))):
        i += 1
    try:
        assert i == pow(10, 6)
    except AssertionError:
        raise AssertionError("Error in tqdm")

# Generated at 2022-06-24 09:38:06.370182
# Unit test for function trange
def test_trange():
    """Test trange function with local private module"""
    l = list(trange(10, ascii=True))
    assert l == list(range(10)), l
    assert isinstance(l, list), type(l)
    l = list(trange(10, ascii=True,
                    mininterval=0.0001, miniters=0, smoothing=0))
    assert l == list(range(10)), l
    assert isinstance(l, list), type(l)
    assert len(tqdm._instances) == 0, tqdm._instances

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:38:15.303007
# Unit test for function trange
def test_trange():
    try:
        import numpy as np
    except ImportError:
        pass
    else:
        class MyInt(int):
            __array_priority__ = 10000  # np.int preferred
        class MyFloat(float):
            __array_priority__ = 10001  # np.float preferred
            pass

        for i in trange([]):  # pylint: disable=unused-variable
            pass
        for i in trange([1, 2]):  # pylint: disable=unused-variable
            pass
        for i in trange([1, 2, 3]):  # pylint: disable=unused-variable
            pass

        # Reproduces #459, #536

# Generated at 2022-06-24 09:38:17.315625
# Unit test for function trange
def test_trange():
    """ Test for trange function """
    assert list(trange(10)) == [i for i in range(10)]

# Generated at 2022-06-24 09:38:24.830932
# Unit test for function trange
def test_trange():
    """Test function `trange`"""
    list(trange(0))
    list(trange(2))
    list(trange(1, 1))
    list(trange(1, 1, 1))
    list(trange(1, 2))
    list(trange(1, 3))
    list(trange(1, 3, 0.5))
    list(trange(3, 1, -0.5))
    list(trange(1, 2, 0.4))
    list(trange(2, 1, -0.4))

# Generated at 2022-06-24 09:38:28.969111
# Unit test for function trange
def test_trange():
    with tqdm(total=0) as t:
        for i in trange(1000):
            t.update()
            assert i == t.n
            assert t.last_print_n == i


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:38:40.747424
# Unit test for function trange
def test_trange():
    import sys
    import time
    if sys.version_info[:2] < (3, 6):
        assert tqdm(range(10)) == notebook_tqdm(range(10))
        assert trange(10) == notebook_trange(10)
    else:
        import asyncio
        time.sleep(0.1)

        async def async_range(i):
            await asyncio.sleep(0.1)

        t_prev = time.time()
        asyncio.run(async_range(0))
        t_asyncio = time.time() - t_prev

        t_prev = time.time()
        asyncio_tqdm(async_range(0), total=1)
        t_asyncio_tqdm = time.time() - t_prev

        t_prev

# Generated at 2022-06-24 09:38:49.844232
# Unit test for function trange
def test_trange():
    "Test function trange"
    from .utils import wrap_tqdm

    for i in trange(4, desc='test_trange'):
        for _ in trange(i ** 2, desc='test_trange'):
            for _ in trange(i ** 2, desc='test_trange'):
                pass

    for i in trange(4, desc='test_trange_leave'):
        for _ in trange(i ** 2, desc='test_trange_leave', leave=True):
            for _ in trange(i ** 2, desc='test_trange_leave', leave=True):
                pass

    def nop():
        "Pass"
        pass

    with wrap_tqdm(nop):
        pass


# Generated at 2022-06-24 09:39:00.023558
# Unit test for function trange
def test_trange():
    """Test trange()"""
    from .std import TqdmTypeError
    assert list(trange(3)) == [0, 1, 2]
    assert list(trange(3, 2)) == []
    assert list(trange(3, 2, -1)) == [2, 1, 0]
    assert list(trange(3, -1)) == [3, 2, 1]
    assert list(trange(3, -1, -1)) == [3, 2, 1]
    with warnings.catch_warnings():
        warnings.simplefilter("error", category=TqdmTypeError)
        try:
            iter(trange(3, -1, 1))
        except TqdmTypeError:
            pass
        else:
            raise AssertionError("trange() failed to raise TqdmTypeError")

# Generated at 2022-06-24 09:39:06.998779
# Unit test for function trange
def test_trange():
    """ Test quick demo """
    import time
    t = time.time()
    # TODO: test parallelism
    with trange(5, desc="1st loop") as t:
        for i in t:
            time.sleep(1)
    assert (time.time() - t) >= 5
    t = time.time()
    with trange(3, desc="2nd loop") as t:
        for i in t:
            time.sleep(0.2)
    assert (time.time() - t) >= 0.6

# Generated at 2022-06-24 09:39:16.417650
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test for function trange"""
    from tests_tqdm import with_setup, _range, pretest

    @with_setup(pretest)
    def inner_test():
        """An inner function for trange test"""
        from .std import tqdm

        # Test dynamic job creation
        for i in trange(10):
            pass
        assert i == 9

        # Test custom dynamic job creation
        class Foo:
            """"
            A simple class, to test custom dynamic job creation
            """
        for _ in tqdm(Foo()):
            pass
        assert _.__class__ == Foo


if __name__ == "__main__":  # pragma: no cover
    test_trange()

# Generated at 2022-06-24 09:39:19.146796
# Unit test for function trange
def test_trange():
    from tqdm import trange
    for _ in trange(3, desc='Window', leave=False):
        pass

test_trange()

# Generated at 2022-06-24 09:39:27.412207
# Unit test for function trange

# Generated at 2022-06-24 09:39:36.546852
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    import subprocess
    import tempfile

    def _test_interleave():
        with tempfile.TemporaryFile() as tmpfile:
            p1 = subprocess.Popen(
                [sys.executable, '-c',
                 'import time; import tqdm.auto as tqdm; '
                 'for i in tqdm.trange(5, desc="first"): time.sleep(0.2)'],
                stdout=tmpfile)

# Generated at 2022-06-24 09:39:39.840445
# Unit test for function trange
def test_trange():
    """Test  `tqdm.auto.trange`"""
    total_range = 5
    for _ in trange(total_range):
        pass
    assert tqdm.n == total_range
    tqdm.close()

# Generated at 2022-06-24 09:39:48.371272
# Unit test for function trange
def test_trange():
    """Test trange."""
    from .gui import tqdm

    # no bars
    total = 7
    for _ in tqdm(range(0, total), desc='No bar', leave=False):
        pass
    for _ in tqdm(range(0, total), desc='No bar', leave=False,
                  bar_format='{l_bar}'):
        pass
    for _ in tqdm(range(0, total), leave=False, disable=True):
        pass
    for _ in tqdm(range(0, total), leave=False, dynamic_ncols=True,
                  disable=True):
        pass

    # bars
    total = 99
    total_2 = 3
    total_3 = 100

# Generated at 2022-06-24 09:39:53.853802
# Unit test for function trange
def test_trange():
    """
    Unit tests for function trange().

    :return: True (tests ok) or raise AssertionError
    """
    from .autonotebook import trange, tqdm

    # Test with default tqdm (tqdm.tqdm)
    for _tqdm in [tqdm, trange]:
        assert isinstance(list(_tqdm(range(4))), list)
        # Check disable=True
        assert isinstance(list(_tqdm(range(4), disable=True)), list)
        # Check postfix
        assert isinstance(list(_tqdm(range(4), postfix={"a": 1})), list)
        assert isinstance(list(_tqdm(range(4), postfix={"a": 1}, disable=True)), list)
        # Check nested monitors

# Generated at 2022-06-24 09:40:02.980230
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        with tqdm(total=13, desc="test") as t:
            for i in trange(13, desc="loop1", leave=True):
                t.update()
            for i in trange(0, 13, desc="loop2"):
                t.update()
            for i in trange(13):
                t.update()
            for i in trange(0, 13):
                t.update()
            for _ in trange(13, ascii=True, desc="loop3"):
                t.update()

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")

# Generated at 2022-06-24 09:40:13.332704
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from .autonotebook import tqdm as notebook_tqdm
    from .asyncio import tqdm as asyncio_tqdm
    from .std import tqdm as std_tqdm, TqdmExperimentalWarning

    tqdms = [notebook_tqdm, std_tqdm]
    if sys.version_info[:2] >= (3, 6):
        tqdms.append(asyncio_tqdm)

    for tqdm_cls in tqdms:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
            bar = trange(10, tqdm=tqdm_cls)
            for i in bar:
                continue

# Generated at 2022-06-24 09:40:15.553351
# Unit test for function trange
def test_trange():
    for _ in trange(3, desc='1st loop'):
        for _ in trange(3, desc='2nd loop', leave=False):
            for _ in trange(3, desc='3nd loop', leave=False):
                pass

# Generated at 2022-06-24 09:40:22.944697
# Unit test for function trange
def test_trange():
    """Test the trange function"""
    # trange on a short range
    assert list(trange(5)) == list(tqdm(range(5)))

    # trange still compute the correct values
    assert list(trange(5, 20, 2)) == list(tqdm(range(5, 20, 2)))

    # Test that trange allow a keyword argument smoothing to be passed
    assert list(trange(5, smoothing=0.2)) == list(tqdm(range(5), smoothing=0.2))

# Generated at 2022-06-24 09:40:33.165881
# Unit test for function trange
def test_trange():
    """Tests trange with default parameters in all supported modes"""
    with tqdm(total=100) as pbar:
        # async/await trange will call cancel() on its own
        if sys.version_info < (3, 6) or notebook_tqdm == std_tqdm:
            for i in trange(10):  # pylint: disable=unused-variable
                pbar.update()
        else:
            pbar.update(10)

# Generated at 2022-06-24 09:40:42.149186
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .utils import _range

    assert list(trange(0)) == []
    assert list(trange(4)) == _range(4)
    assert list(trange(0, 1, 1)) == [0]
    assert list(trange(0, 6, 2)) == _range(0, 6, 2)
    assert list(trange(5, 0, -1)) == _range(5, 0, -1)
    assert list(trange(0, -6, -2)) == _range(0, -6, -2)

# Generated at 2022-06-24 09:40:45.133913
# Unit test for function trange
def test_trange():
    """ test trange """
    assert list(trange(3)) == list(notebook_tqdm(range(3)))

# Generated at 2022-06-24 09:40:48.843835
# Unit test for function trange
def test_trange():
    """Test for `trange`"""
    from .std import tqdm as std_tqdm
    for _ in trange(10):
        pass
    for _ in std_tqdm(range(10)):
        pass

# Generated at 2022-06-24 09:40:51.408402
# Unit test for function trange
def test_trange():
    """Test for trange."""
    x = trange(10)
    assert next(x) == 0
    assert isinstance(x, tqdm)



# Generated at 2022-06-24 09:40:53.884179
# Unit test for function trange
def test_trange():
    """Test trange wrapper"""
    assert list(trange(int(1e9), desc="test")) == list(range(int(1e9)))

# Generated at 2022-06-24 09:41:33.759011
# Unit test for function trange
def test_trange():
    """Simple unit test for `tqdm.auto.trange`"""
    import time

    # Check trange
    total = 10
    with trange(total) as t:
        for i in t:
            time.sleep(.1)
            t.set_description("trange(%i)" % i)
        assert len(t) == total
        assert i == total - 1

    # Check trange closing
    with trange(total) as t:
        for i in t:
            if i == total - 1:
                t.close()
        assert not t.n, "t.n={}".format(t.n)
        assert i == total - 1

    # Check trange iterable
    assert list(trange(total)) == list(range(total))

# Generated at 2022-06-24 09:41:43.290046
# Unit test for function trange
def test_trange():
    """Test function `tqdm.auto.trange`."""
    for i in trange(3, desc="cool"):
        assert i in (0, 1, 2)

if __name__ == "__main__":
    from ._version import get_versions
    print("tqdm", get_versions()["version"])
    del get_versions
    test_trange()

# Generated at 2022-06-24 09:41:49.300575
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import tqdm as std_tqdm
    from .asyncio import tqdm as asyncio_tqdm

    assert std_tqdm(range(10), ncols=120) == notebook_tqdm(range(10), ncols=120)
    assert std_tqdm(range(10), ncols=120) == asyncio_tqdm(range(10), ncols=120)
    assert std_tqdm(range(10), ncols=120) == trange(10, ncols=120)

# Generated at 2022-06-24 09:41:54.320415
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from .std import _range
    rng = _range(5)
    for _ in trange(5):
        _ == next(rng)


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:42:04.623249
# Unit test for function trange
def test_trange():
    """Test function trange"""
    assert list(trange(3, desc="FOO", ascii=True)) == list(range(3))
    assert list(trange(3, desc="FOO", bar_format="{l_bar}++{bar}++", ascii=True)) == list(range(3))
    assert list(trange(3, desc="FOO", bar_format="{l_bar}++{bar}++", ascii=False)) == list(range(3))
    assert list(trange(3, desc="FOO", ascii=True, postfix=["bar", 1, 2])) == list(range(3))