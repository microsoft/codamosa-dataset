

# Generated at 2022-06-24 09:35:53.901195
# Unit test for function trange
def test_trange():
    assert list(trange(0)) == []
    assert list(trange(1)) == [0]
    assert list(trange(2)) == [0, 1]
    assert list(trange(3)) == [0, 1, 2]
    assert list(trange(4)) == [0, 1, 2, 3]
    assert list(trange(5)) == [0, 1, 2, 3, 4]
    assert list(trange(6)) == [0, 1, 2, 3, 4, 5]
    assert list(trange(7)) == [0, 1, 2, 3, 4, 5, 6]
    assert list(trange(8)) == [0, 1, 2, 3, 4, 5, 6, 7]

# Generated at 2022-06-24 09:35:55.966011
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    with trange(7) as t:
        for i in t:
            pass

# Generated at 2022-06-24 09:36:07.470151
# Unit test for function trange
def test_trange():
    """Test for trange"""
    import io
    with io.StringIO() as fd:
        for _ in trange(4, file=fd, mininterval=0.1):
            pass
        output = fd.getvalue()

# Generated at 2022-06-24 09:36:12.963573
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange()
    """
    from .std import tqdm

    for n in trange(4):
        for n2 in tqdm(range(3), desc=repr(n)):
            for n3 in tqdm(range(3), desc=repr(n2)):
                pass

if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 09:36:21.214208
# Unit test for function trange
def test_trange():
    """Test function trange."""
    from .std import trange
    from .utils import _term_move_up
    from .utils import _range

    for _ in trange(10, desc='trange1'):
        for _ in trange(10, desc='trange2'):
            for _ in trange(10, desc='trange3', leave=False):
                for _ in trange(10, desc='trange4', leave=True):
                    for _ in trange(10, desc='trange5'):
                        pass
                    print()

    # Test of `leave` feature with nested loops
    # NB: closing 'trange' with `leave=True` will not print new line
    pbar = trange(2, desc='trange6')
    print()

# Generated at 2022-06-24 09:36:23.103326
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    result = list(trange(10, desc="trange"))
    assert result == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-24 09:36:27.091734
# Unit test for function trange
def test_trange():
    """ test for trange """
    for i in trange(4, 10):
        assert i == 4
    for i in trange(4, 10, 2):
        assert i == 4

if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 09:36:29.208670
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from .utils import _range
    assert list(trange(3)) == list(_range(3))

# Generated at 2022-06-24 09:36:37.807904
# Unit test for function trange
def test_trange():
    """
    Test trange function
    """
    trange_obj = trange(5)
    assert next(trange_obj) == 0
    assert next(trange_obj) == 1
    assert next(trange_obj) == 2
    assert next(trange_obj) == 3
    assert next(trange_obj) == 4
    assert len(list(trange_obj)) == 0
    assert len(list(trange(0))) == 0
    assert list(trange(1, 5)) == [1, 2, 3, 4]
    assert list(trange(1, 10, 2)) == [1, 3, 5, 7, 9]
    assert list(trange(5, 0, -1)) == [5, 4, 3, 2, 1]

# Generated at 2022-06-24 09:36:41.790997
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Tests for trange function"""
    import time

    for _ in trange(4):
        for _ in trange(3, leave=False):
            time.sleep(0.1)


if __name__ == "__main__":
    sys.exit(test_trange())

# Generated at 2022-06-24 09:36:44.540818
# Unit test for function trange
def test_trange():
    """
    >>> list(trange(3))
    [0, 1, 2]
    """
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 09:36:47.181232
# Unit test for function trange
def test_trange():
    "Test function trange"
    from time import sleep

    for _ in trange(3):
        sleep(0.01)
    for _ in trange(3, ncols=120):
        sleep(0.01)

# Generated at 2022-06-24 09:36:51.903783
# Unit test for function trange
def test_trange():
    """
    Unit test for `trange`.
    """
    from .std import tqdm
    from .asyncio import tqdm as asyncio_tqdm
    from .autonotebook import tqdm as notebook_tqdm
    from .autonotebook import trange as notebook_trange
    assert __name__ == "tqdm.auto"
    assert trange is tqdm and trange is not notebook_trange
    assert tqdm is not notebook_tqdm and tqdm is asyncio_tqdm
    trange(3)
    trange(3, desc="trange")

# Generated at 2022-06-24 09:36:53.520551
# Unit test for function trange
def test_trange():  # pragma: no cover
    with tqdm(total=None) as tr:
        tr.update(10)
        tr.refresh()



# Generated at 2022-06-24 09:36:59.269819
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import RANGE_BOUND_DISPLAY_DELIM
    from .utils import write_to_file_descriptor
    with write_to_file_descriptor(sys.stdout, encoding=None) as fd:
        # Test no total
        tr = trange(2)
        with tr as t:
            t.update()
            t.update()
        fd.seek(0)
        assert fd.read() == RANGE_BOUND_DISPLAY_DELIM.join(
            ["0", "2", "100%"]
        ) + "\n"
        del tr

        # Test total
        fd.truncate(0)
        tr = trange(2, 10)
        with tr as t:
            t.update()
           

# Generated at 2022-06-24 09:37:09.753703
# Unit test for function trange
def test_trange():  # pragma: no cover

    if sys.version_info[:2] < (3, 6):
        import mock
        with mock.patch("tqdm.auto.tqdm", side_effect=RuntimeError):
            assert not list(trange(3))
    else:
        import asyncio
        import time

        @asyncio.coroutine
        def do_trange(*args, **kwargs):
            with trange(*args, **kwargs) as t:
                for i in t:
                    yield from asyncio.sleep(0.1)
                    if i == 1:
                        t.set_description("Testing trange")
                t.set_description("Done trange")

        loop = asyncio.get_event_loop()
        t0 = time.perf_counter()
        loop.run_until_complete

# Generated at 2022-06-24 09:37:12.233349
# Unit test for function trange
def test_trange():
    """
    >>> from tqdm.auto import trange
    >>> for i in trange(4):
    ...     pass
    """


# Generated at 2022-06-24 09:37:17.774333
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    import unittest
    import os

    class TestTrange(unittest.TestCase):
        """"
        Test two trange functions
        """
        def test_trange(self):
            """
            Test trange function
            :return: no return
            """
            array = list(trange(10))
            self.assertEqual(array, list(range(10)))

    t = TestTrange()
    t.test_trange()
    print("Unit test for trange is passed")

# Generated at 2022-06-24 09:37:22.601966
# Unit test for function trange
def test_trange():
    for i in trange(5):
        assert i in range(5)


if __name__ == "__main__":
    from ._utils import _test
    _test()
    test_trange()

# Generated at 2022-06-24 09:37:27.286052
# Unit test for function trange
def test_trange():
    """
    Unit tests for trange
    """
    from .std import tqdm as std_tqdm

    # trange should not be an alias
    assert trange is not tqdm
    assert trange is not std_tqdm
    # Test if trange allows the same arguments as tqdm
    assert tqdm(range(10), total=100).total == trange(10, total=100).total

# Generated at 2022-06-24 09:37:33.261921
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from ._utils import _suppress_stderr

    for _ in trange(3):
        pass

    with _suppress_stderr():
        assert hasattr(trange(0), "__iter__")
        assert hasattr(list(trange(0)), "__len__")
        assert hasattr(list(trange(0)), "__getitem__")

# Generated at 2022-06-24 09:37:36.324635
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from tqdm.auto import trange
    for _ in trange(10):
        pass

# Generated at 2022-06-24 09:37:41.708860
# Unit test for function trange
def test_trange():
    """Test trange"""
    from tqdm.utils import _term_move_up
    with tqdm(total=10, miniters=1) as pbar:
        for i in trange(4, 8):
            pbar.update()
    for i in trange(10):
        _term_move_up()
    for i in trange(5):
        _term_move_up()


if __name__ == "__main__":  # pragma: no cover
    test_trange()

# Generated at 2022-06-24 09:37:49.180310
# Unit test for function trange
def test_trange():
    """Test trange (function)"""
    from tqdm.auto import trange
    with trange(10) as t:
        for i in t:
            t.set_description("test {}".format(i))
    from tqdm.auto import tqdm
    with tqdm(range(10)) as t:
        for i in t:
            t.set_description("test {}".format(i))


# Unit tests

# Generated at 2022-06-24 09:37:51.760963
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    >>> from tqdm.auto import trange
    >>> for _ in trange(3):
    ...     pass
    """
    pass


# Generated at 2022-06-24 09:38:02.745601
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Test for function trange"""
    import sys
    from .std import tqdm
    from .utils import _term_move_up
    try:
        from .utils import _environ_cols_wrapper
    except ImportError:
        _environ_cols_wrapper = lambda x: None
    with _environ_cols_wrapper(40):
        with tqdm(total=3) as t:
            for i in trange(3):
                t.update(1)
            t.display(_term_move_up() + "2" + t.desc + ": " + t.postfix + "")


# Generated at 2022-06-24 09:38:12.773639
# Unit test for function trange
def test_trange():  # pragma: no cover
    class _tqdm(tqdm):
        # override tqdm
        def __init__(self, *args, **kwargs):
            super(_tqdm, self).__init__(*args, **kwargs)
            self.values = []

        def update(self, n=1, *args, **kwargs):
            self.values.append(n)
            super(_tqdm, self).update(n, *args, **kwargs)

    for cls in (tqdm, notebook_tqdm):
        s = _tqdm(range(10), disable=True)
        for _ in s:
            pass
        assert list(s.values) == list(range(1, 11))

        s = _tqdm(total=1000, disable=True)

# Generated at 2022-06-24 09:38:23.434778
# Unit test for function trange
def test_trange():
    "Test function trange"
    from pickle import loads, dumps
    from random import random
    from time import sleep
    with tqdm(total=1, disable=None) as pbar:
        sleep(random())
        pbar.update(1)
    for i in trange(10, desc="outer loop"):
        for j in trange(5, desc="inner loop", leave=False):
            for k in trange(100):
                sleep(0.01)
    for i in trange(3, desc='foobar', ascii=True):
        sleep(.1)
    for i in trange(4, desc='fizz'):
        for j in trange(5, desc='buzz'):
            sleep(.01)

# Generated at 2022-06-24 09:38:30.600625
# Unit test for function trange
def test_trange():
    """Test function `trange`"""
    # pylint: disable=protected-access
    # basic range
    assert list(trange(10)) == list(range(10))
    # no trange()
    tqdm.disable = True
    assert list(trange(0)) == []
    assert list(trange(10)) == list(range(10))
    tqdm.disable = False
    # leave=False
    tqdm._instances.clear()
    assert list(trange(0, leave=False)) == []
    assert tqdm._instances == set()
    # `desc`
    tqdm._instances.clear()
    assert list(trange(0, desc="desc")) == []
    assert tqdm._instances == set()
    # manual `total`
    tqdm

# Generated at 2022-06-24 09:38:42.226421
# Unit test for function trange
def test_trange():
    """Tests trange."""
    import sys
    from .utils import format_sizeof

    for n in trange(3, desc='Blah', leave=False, position=0, mininterval=0):
        for _ in trange(100, unit="B", unit_scale=True, miniters=1,
                        file=sys.stderr, ncols=80, mininterval=0):
            pass
    assert format_sizeof(12345) == '12.1KB'

    # Test for issue #329
    for n in trange(4, desc="test", mininterval=0):  # add custom description
        for _ in trange(10, mininterval=0):  # now use unit='steps'
            pass
    assert notebook_tqdm.write.called

    assert notebook_tq

# Generated at 2022-06-24 09:38:48.498501
# Unit test for function trange
def test_trange():
    """ Test trange """
    list(trange(3))
    list(trange(3, desc="desc"))
    assert repr(trange(3)) == repr(notebook_trange(3))
    for module in [tqdm, tqdm.std, tqdm.asyncio]:
        for attr in ["tqdm", "trange"]:
            assert getattr(module, attr).__module__ == module.__name__
        assert "TqdmExperimentalWarning" in module.__doc__

# Generated at 2022-06-24 09:38:59.748847
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange

    Usage:
        python -m tqdm.auto trange
    """
    with tqdm(total=1) as pbar:
        assert pbar.total == 1
    with tqdm(total=1, desc="This is test") as pbar:
        assert pbar.total == 1
        assert pbar.desc == "This is test"
    with tqdm(total=1, desc="This is test", leave=False) as pbar:
        assert pbar.total == 1
        assert pbar.desc == "This is test"
        assert pbar.leave
    with tqdm(total=1, desc="This is test", dynamic_ncols=True) as pbar:
        assert pbar.total == 1

# Generated at 2022-06-24 09:39:09.554391
# Unit test for function trange
def test_trange():
    """
    Unit tests for function trange.
    """
    from .std import TqdmTypeError
    from .tqdm import tqdm

    curr_tqdm = tqdm

    # Test tqdm from inside trange
    global tqdm
    tqdm = None
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        from .autonotebook import tqdm as notebook_tqdm
        from .asyncio import tqdm as asyncio_tqdm
    tqdm = notebook_tqdm
    _ = trange(1)
    tqdm = asyncio_tqdm
    _ = trange(1)

    # Reset tqdm
    tqdm = curr_tqdm

    #

# Generated at 2022-06-24 09:39:20.459238
# Unit test for function trange
def test_trange():
    import time
    from .std import FormatCustomText
    from .std import PILLS_PNG, BEATLES_PNG, SPACER, CTRL_C_PNG

    tr = trange(4, desc="test", mininterval=0.01)
    for i in tr:
        time.sleep(0.09)

    tr = trange(4, desc="test2", smoothing=1, mininterval=0.01)
    for i in tr:
        time.sleep(0.09)

    tr = trange(4, desc="test3", smoothing=1, mininterval=0.01)
    for i in tr:
        time.sleep(0.09)
        tr.set_postfix_str("foo bar")


# Generated at 2022-06-24 09:39:25.461324
# Unit test for function trange
def test_trange():
    """Test function `trange`."""
    assert range(10) == list(trange(10))
    assert list(range(10)) == list(trange(0, 10))


if __name__ == "__main__":
    r"""
    CommandLine:
        python -m tqdm.auto all
    """
    import pytest
    pytest.main([__file__] + sys.argv[1:])

# Generated at 2022-06-24 09:39:35.541751
# Unit test for function trange
def test_trange():
    try:
        import numpy as np

        for s in [0, 1, 2, 3, 4, 6, 7]:
            for e in [1, 2, 3, 4, 5, 6, 7]:
                for s2 in [0, 1, 2, 3, 5]:
                    for e2 in [1, 2, 3, 4, 5]:
                        for s3 in [0, 1, 2, 3, 5]:
                            for e3 in [1, 2, 3, 4, 5]:
                                assert (
                                    list(trange(s, e, s2, e2, s3, e3, unit="I"))
                                    == np.arange(s, e, s2, e2, s3, e3).tolist()
                                )
    except ImportError:
        pass

# Generated at 2022-06-24 09:39:39.221699
# Unit test for function trange
def test_trange():
    from operator import eq
    from .utils import FormatStrenth

    with FormatStrenth(0):  # disable bcolors
        iterations = getattr(trange(10), 'n', 10)
        assert iterat

# Generated at 2022-06-24 09:39:42.544058
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    # pylint: disable=unused-variable
    from tqdm.auto import trange

    for i in trange(2, 3):
        pass

    for i in trange(2, 3, 0.1):
        pass

# Generated at 2022-06-24 09:39:44.125967
# Unit test for function trange
def test_trange():
    try:
        list(trange(10))
        assert True
    except BaseException:
        assert False

# Generated at 2022-06-24 09:39:47.518738
# Unit test for function trange
def test_trange():
    """Test function trange"""
    L = [1, 2, 3, 4, 5]
    for i in trange(5):
        assert i == L[i]
    L = [1, 2, 3, 4, 5]
    for i in range(5):
        assert i == L[i]

# Generated at 2022-06-24 09:39:57.661017
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    import unittest

    import numpy as np
    from .tqdm import trange
    from .utils import format_sizeof

    class TqdmTest(unittest.TestCase):
        """
        Inherited class for unit testing
        """
        def test_trange(self):
            """
            trange test
            """
            for i in trange(10, desc='trange'):
                print(i)
            for i in trange(10, desc='trange', leave=False):
                print(i)
            for i in trange(10, desc='trange', ascii=True):
                print(i)
            for i in trange(10, desc='trange', disable=True):
                print(i)

# Generated at 2022-06-24 09:39:59.861037
# Unit test for function trange
def test_trange():
    "Test for trange"
    return trange(3).__next__() == 0  # pylint: disable=no-member

# Generated at 2022-06-24 09:40:02.642335
# Unit test for function trange
def test_trange():
    """Tests that 'from tqdm.auto import trange' works."""
    with tqdm(total=2) as pbar:
        assert len(list(trange(2))) == 2
        assert len(list(range(2))) == 2

# Generated at 2022-06-24 09:40:05.062737
# Unit test for function trange
def test_trange():
    for _ in trange(4):
        pass


# Generated at 2022-06-24 09:40:14.154846
# Unit test for function trange
def test_trange():
    from .utils import FormatBase
    from .utils import format_sizeof
    from .utils import _range
    from .pandas import trange as pd_trange

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        from .autonotebook import trange as ab_trange

    assert not isinstance(tqdm, (ab_trange, pd_trange))
    """
    Not a class trange so that trange(...) runs in the __main__ namespace.
    """
    assert tqdm is not ab_trange
    assert tqdm is not pd_trange


# Generated at 2022-06-24 09:40:18.937378
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import TqdmExperimentalWarning
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', TqdmExperimentalWarning)
        from .auto import tqdm

    def _test_bar(bar, n):
        """
        Unit test for trange heavy lifting.
        """
        from .utils import _supports_unicode
        from .utils import format_sizeof
        from .utils import format_interval
        from .utils import format_meter
        from .utils import _time

        for i in bar:
            if i == 0:
                assert i in bar
                continue
            if i == 1:
                assert isinstance(bar.index, int)
                assert isinstance(bar.last_print_t, float)

# Generated at 2022-06-24 09:40:22.036133
# Unit test for function trange
def test_trange():
    """Test function."""
    from .std import tqdm
    assert trange is tqdm
    for _ in trange(10):
        pass



# Generated at 2022-06-24 09:40:34.772447
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import format_interval
    from .std import fspath
    # Current tqdm tests use std trange but asyncio tqdm
    tqdm = sys.modules[fspath(__file__)].tqdm

    tr = trange(0)
    assert len(tr) == 0

    tr = trange(0, 2)
    assert len(tr) == 2
    for _ in tr:
        pass

    tr = trange(2)
    assert len(tr) == 2
    for _ in tr:
        pass

    tr = trange(0, 2, 2)
    assert len(tr) == 1
    for _ in tr:
        pass

    tr = trange(2, 0, 2)
    assert len(tr)

# Generated at 2022-06-24 09:40:38.546132
# Unit test for function trange
def test_trange():
    """Test the trange wrapper"""
    tlist100 = list(trange(100))
    assert tlist100 == list(range(100))


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:40:41.831373
# Unit test for function trange
def test_trange():
    """Test for trange"""
    for _ in trange(10):
        pass

# Generated at 2022-06-24 09:40:50.183293
# Unit test for function trange

# Generated at 2022-06-24 09:40:56.618732
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .gui import trange
    from .gui import tgrange
    from .gui import tqdm
    from .gui import tnrange
    from .gui import tqdm_notebook
    from .gui import tgrange
    from .gui import tqdm_gui

    for t in [tqdm, tqdm_notebook, tqdm_gui, tnrange, trange, tgrange]:
        assert list(t(range(3))) == [0, 1, 2]

# Generated at 2022-06-24 09:41:00.654215
# Unit test for function trange
def test_trange():
    from ._utils import _range

    for _ in trange(3):
        pass

    for _ in trange("abc"):
        pass

    for _ in trange(_range(3)):
        pass

    # Test specific `unit`
    for _ in trange(3, unit="foo"):
        pass


# Generated at 2022-06-24 09:41:10.925279
# Unit test for function trange
def test_trange():
    """
    Test if function trange works.
    """
    from .std import TqdmTypeError
    import sys


# Generated at 2022-06-24 09:41:20.812378
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    import io
    try:  # Python2
        from StringIO import StringIO  # noqa
    except ImportError:  # Python3
        from io import StringIO  # noqa

    # Check that closure and partial works
    with closing(StringIO()) as our_file:
        trange = tqdm.trange(3, file=our_file)
        next(trange)  # need to start trange
        assert len(our_file.getvalue()) > 0, "Closure of file not working"

    with closing(StringIO()) as our_file:
        range_tqdm = tqdm.trange(3, file=our_file)
        next(range_tqdm)  # need to start trange

# Generated at 2022-06-24 09:41:32.168400
# Unit test for function trange
def test_trange():
    """
    Simple test to check that function `trange()` works.
    """
    # Test trange
    total = 10
    with trange(total) as t:
        for i in t:
            assert i == t.n
            t.set_postfix(i=i)

    # Test trange with "leave"
    with trange(total, leave=True) as t:
        for i in t:
            assert i == t.n
            t.set_postfix(i=i)

    out = trange(3, desc='trange', leave=True)
    if out.__class__ is notebook_trange:
        out.write("Testing leave=True on Jupyter...")
        assert out.leave is True
    else:
        assert out.leave is True

# Generated at 2022-06-24 09:41:35.838377
# Unit test for function trange
def test_trange():
    for i in trange(10):
        pass

# Generated at 2022-06-24 09:41:47.579907
# Unit test for function trange
def test_trange():
    """Unit test for function `trange`"""
    from .gui import tgrange  # pylint: disable=no-name-in-module
    from .utils import format_sizeof
    from .tests import common_tests
    from .std import TqdmDefaultWriteLock

    for module_test in (common_tests, TqdmDefaultWriteLock):
        with module_test() as m:
            m.__enter__()

            with tqdm(**m.kwargs) as t:
                t.update(5)
                assert t.total == 5

            # Test unit usage

# Generated at 2022-06-24 09:41:50.252934
# Unit test for function trange
def test_trange():
    assert trange(2) == notebook_trange(2)

# Generated at 2022-06-24 09:41:54.488013
# Unit test for function trange
def test_trange():
    """
    Tests trange()

    :return:
    """
    assert list(trange(0)) == []
    assert list(trange(5)) == [0, 1, 2, 3, 4]



# Generated at 2022-06-24 09:42:04.452854
# Unit test for function trange
def test_trange():
    """Test that trange() gives correct output (python2.7)"""
    assert list(trange(0)) == []
    assert list(trange(1)) == [0]
    assert list(trange(5)) == [0, 1, 2, 3, 4]
    assert list(trange(5, 0, -1)) == [5, 4, 3, 2, 1]
    assert list(trange(5, -1, -1)) == [5, 4, 3, 2, 1, 0, -1]
    assert list(trange(5, -1, -2)) == [5, 3, 1, -1]
    assert list(trange(5, 5, 2)) == []
    assert list(trange(5, 5, -2)) == []

# Generated at 2022-06-24 09:42:12.864806
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    import time
    # Check that `iterable` is properly set (except for widgets)
    for w in ['', '0', '1', '1/', '1/1', '123/123']:
        t = trange(10, desc=w, leave=True)
        assert t.iterable is None
        for _ in t:
            pass
    # Check that `iterable` is properly set
    t = trange(10, desc='', leave=False)
    assert t.iterable is None
    for i in t:
        time.sleep(0.01)
    t = trange(10, leave=True)
    assert t.iterable is None
    for i in t:
        time.sleep(0.01)

# Generated at 2022-06-24 09:42:18.498243
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import trange as _trange
    from .asyncio import trange as _trange_asyncio
    from .autonotebook import trange as _trange_autonotebook

    assert trange is not _trange
    assert trange is not _trange_asyncio
    assert trange is not _trange_autonotebook

    if sys.version_info[:2] < (3, 6):
        assert trange is _trange_autonotebook
    else:
        assert trange is _trange_asyncio


# Generated at 2022-06-24 09:42:26.481676
# Unit test for function trange
def test_trange():
    """
    Tests for `tqdm.auto.trange`.
    """
    # Call trange
    sum_ = 0
    for i in trange(7, desc="foo", leave=True, position=0):
        sum_ += i
    assert sum_ == 21

    # Check last instance
    t = trange(0)
    assert not t._instances
    t.close()
    assert not t._instances

    # Check force reset & refresh
    trange(0, refresh=True)
    trange(0, force_reset=True)

# Generated at 2022-06-24 09:42:28.093752
# Unit test for function trange
def test_trange():
    return (notebook_tqdm(range(10)) == tqdm(range(10))).all()

# Generated at 2022-06-24 09:42:30.265853
# Unit test for function trange
def test_trange():
    for _ in trange(5, desc='1st loop'):
        for _ in trange(100, desc='2nd loop'):
            for _ in trange(100, desc='3rd loop'):
                pass

# Generated at 2022-06-24 09:42:31.701762
# Unit test for function trange
def test_trange():
    """Run trange unit tests"""
    from .tests import trange_test
    trange_test()



# Generated at 2022-06-24 09:42:41.252748
# Unit test for function trange
def test_trange():
    from .tests import tests
    from .utils import _range, NaturalClosedRange

    for kwargs in ({}, {'leave': True}, {'total': 10}):
        for unit in ('', 'it', 'iter', 'loops'):
            if unit:
                kwargs['unit'] = unit

# Generated at 2022-06-24 09:42:45.812077
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    # Test nested trange
    for _ in trange(2):
        for _ in trange(3):
            for _ in trange(4):
                for _ in trange(5):
                    pass

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:42:51.876806
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .std import TqdmTypeError
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        trange(0, 1)
        trange(1)
    try:
        trange(0, 0)
        raise Exception("trange(0, 0) should raise an error")
    except TqdmTypeError:
        pass

# Generated at 2022-06-24 09:43:01.728644
# Unit test for function trange
def test_trange():
    """
    Just a smoke test.
    """
    trange(3)
    trange(3, desc="desc")
    trange(3, ascii=True)
    trange(10, position=42)
    trange(10, total=42)
    trange(10, miniters=1)
    trange(10, mininterval=0.001)
    trange(3)
    trange(3, bar_format="{l_bar}")
    trange(3, bar_format="{bar}")
    trange(3, bar_format="{bar}{bar}")
    trange(3, bar_format="{bar:10}{bar:10}")
    trange(3, bar_format="{bar} {bar}")


# Generated at 2022-06-24 09:43:12.246256
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    import platform
    import sys
    import time
    from .tqdm_gui import tqdm as tqdm_gui

    t_start = time.perf_counter()
    t_proc_start = time.process_time()

    trange(1000)

    t_proc_end = time.process_time()
    t_end = time.perf_counter()

    assert (t_end - t_start) < 0.01, "trange took too long to execute."
    assert (t_proc_end - t_proc_start) < 0.01, \
        "trange took too long to execute (process time)."


# Generated at 2022-06-24 09:43:15.962517
# Unit test for function trange
def test_trange():
    """
    Tests `trange` function.
    """
    n = 10000
    trange(n, desc="test_trange", leave=True)


# Unit tests for tqdm

# Generated at 2022-06-24 09:43:20.547595
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange().
    """
    from .std import Bar
    # Test trange
    trange_iter = trange(10)
    assert isinstance(trange_iter, Bar)
    assert list(trange_iter) == list(range(10))
    assert trange(10).total == 10
    assert list(trange(10, leave=True)) == list(range(10))

# Generated at 2022-06-24 09:43:25.991123
# Unit test for function trange
def test_trange():
    """ Unit test for function trange """
    if tqdm._version.get_versions()['version'] != "4.29.1":
        raise Exception('Incorrect version!')
    # With trange
    with trange(10) as t:
        for i in t:
            pass
    assert t.n == 10
    assert t.last_print_n == 10


# Generated at 2022-06-24 09:43:35.623366
# Unit test for function trange
def test_trange():
    from ._utils import _version as _tqdm_version
    from .utils import _term_move_up
    assert trange(4).__repr__() == _term_move_up() + _tqdm_version
    assert trange(4).__repr__() == _term_move_up() + _tqdm_version
    assert list(trange(4)) == list(range(4))
    assert list(trange(2, 4)) == list(range(2, 4))
    assert list(trange(2, 4, 1)) == list(range(2, 4, 1))
    assert list(trange(2, 4, 2)) == list(range(2, 4, 2))
    assert list(trange(4, 2, -1)) == list(range(4, 2, -1))
   

# Generated at 2022-06-24 09:43:38.016611
# Unit test for function trange
def test_trange():
    for _ in trange(0):
        pass
    for _ in trange(1):
        pass
    for _ in trange(29):
        pass
    for _ in trange(3000):
        pass
    for _ in trange(30000):
        pass
    for _ in trange(300000):
        pass
    for _ in trange(3000000):
        pass

# Generated at 2022-06-24 09:43:48.548828
# Unit test for function trange
def test_trange():
    """
    Unit test for :func:`tqdm.auto.tqdm` and :func:`tqdm.auto.trange`
    """
    from time import sleep
    import numpy as np
    from os import write
    from sys import stderr

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for _ in trange(4, leave=False):
            sleep(0.1)
    stderr.write("\n")
    for _ in tqdm([1, 2, 3], ascii=True):
        sleep(0.1)
    stderr.write("\n")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")

# Generated at 2022-06-24 09:43:50.549596
# Unit test for function trange
def test_trange():
    with tqdm(total=4) as pbar:
        for _ in trange(4):
            pbar.update()
    assert pbar.n == pbar.total
    assert pbar.n == 4

# Generated at 2022-06-24 09:44:02.111305
# Unit test for function trange
def test_trange():
    """Test function trange"""
    import sys
    import random
    import shutil
    import tempfile
    from io import StringIO

    with tempfile.TemporaryDirectory() as tmpdirname:
        try:
            for _ in trange(3, desc='Testing trange', leave=False):
                for _ in trange(5, desc='Nested loop'):
                    pass
        finally:
            try:
                shutil.rmtree(tmpdirname)
            except (IOError, OSError):
                pass

        for _ in trange(5, file=sys.stdout):
            for _ in trange(5, file=sys.stderr):
                pass


# Generated at 2022-06-24 09:44:04.351499
# Unit test for function trange
def test_trange():
    """Test trange"""
    with tqdm(range(100)) as t:
        for i in t:
            pass
    assert i == 99


# Generated at 2022-06-24 09:44:05.772591
# Unit test for function trange
def test_trange():
    """Tests `tqdm.auto.trange`."""
    for _ in trange(10):
        pass

# Generated at 2022-06-24 09:44:10.736543
# Unit test for function trange
def test_trange():
    assert list(trange(3, desc="my bar!", leave=False)) == [0, 1, 2]
    assert list(trange(5, 0, -1, desc="my bar!", leave=False)) == [
        5,
        4,
        3,
        2,
        1,
    ]
    assert list(trange(0)) == []

# Generated at 2022-06-24 09:44:12.097977
# Unit test for function trange
def test_trange():
    with tqdm(total=10) as pbar:
        for _ in range(10):
            pbar.update()

# Generated at 2022-06-24 09:44:17.927417
# Unit test for function trange
def test_trange():
    """ Unit test for function trange """
    from .utils import _range
    from .std import format_interval, format_meter
    from .gui import format_sizeof

    with warnings.catch_warnings():
        warnings.filterwarnings("ignore")
        from .gui import tqdm
        from .gui import trange

    # Test for tqdm (class)
    with tqdm(total=4,
              bar_format="{l_bar}{bar}{r_bar}",
              postfix=("{n_fmt}/{total_fmt} "
                       "[elapsed: {elapsed}, "
                       "remaining: {remaining}, "
                       "rate: {rate_fmt}]")) as pbar:
        for i in _range(4):
            pbar.update()

# Generated at 2022-06-24 09:44:25.322671
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from time import sleep
    from .std import total_seconds

    for _ in trange(4, desc='trange'):
        sleep(0.01)
    for _ in trange(10, unit="it"):
        sleep(0.01)
    for _ in trange(10, unit_scale=True):
        sleep(0.01)

    pbar = trange(10, unit='it', leave=True)
    pbar.update(3)
    sleep(0.1)
    pbar.n = 7
    pbar.refresh()
    try:
        pbar.update(1)
    except ValueError:
        pass
    pbar.close()

    pbar = trange(4, desc='trange', leave=True)

# Generated at 2022-06-24 09:44:35.474028
# Unit test for function trange
def test_trange():
    for i in trange(3):
        assert i < 3
    for i in trange(10):
        assert i < 10
    for i in trange(10, 15):
        assert i > 9, i
        assert i < 15
    tr = trange(10, 15, 2)
    assert next(tr) == 10
    assert next(tr) == 12
    assert next(tr) == 14
    assert next(tr) == StopIteration
    try:
        next(tr)
        assert False
    except StopIteration:
        pass
    for i in trange(10, 5, -1):
        assert i > 4
        assert i < 10
    for i in trange(5, 10, -1):
        assert i < 5

# Generated at 2022-06-24 09:44:36.857668
# Unit test for function trange
def test_trange():  # pragma: no cover
    for _ in trange(4, 0, -1):
        pass


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:44:40.715048
# Unit test for function trange
def test_trange():
    """Test for tqdm.auto.trange"""
    assert isinstance(trange(100), tqdm)
    assert isinstance(trange(100, desc='A'), tqdm)
    assert isinstance(trange(100, desc='A', leave=False), tqdm)

# Generated at 2022-06-24 09:44:47.717627
# Unit test for function trange
def test_trange():
    """
    Test the trange shortcut
    """
    from .std import trange as _trange

    def trange_test(start=None, stop=None, step=None):
        """
        Mimic the given range
        """
        return range(start, stop, step)

    for start in [None, 0]:
        for stop in [1, 10]:
            for step in [1, 2]:
                assert trange_test(*_trange(start, stop, step,
                                            desc="test")) == \
                    list(trange(start, stop, step, desc="test"))

# Generated at 2022-06-24 09:44:49.790210
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from .tqdm import trange
    list(trange(3))
    pass

# Generated at 2022-06-24 09:44:58.787182
# Unit test for function trange
def test_trange():
    """
    Tests function `trange`.

    :return: Nothing.
    """
    from .asyncio import tqdm as asyncio_tqdm
    from .autonotebook import tqdm as notebook_tqdm
    from .std import tqdm as std_tqdm
    if sys.version_info[:2] < (3, 6):
        assert tqdm is notebook_tqdm, "tqdm is not notebook_tqdm"
        assert trange is notebook_trange, "trange is not notebook_trange"
    else:
        assert tqdm is asyncio_tqdm, "tqdm is not asyncio_tqdm"
        assert tqdm is not std_tqdm, "tqdm is std_tqdm"
        assert trange is not notebook

# Generated at 2022-06-24 09:45:08.084723
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange()
    """
    import unittest
    import sys
    import random

    class Test(unittest.TestCase):
        def test(self):
            # Base test
            self.assertEqual(list(trange(10)), list(range(10)))
            # Check desc
            self.assertEqual(list(trange(5, desc="desc")),
                             list(range(5)))
            # Check desc with nested bars
            self.assertEqual(list(trange(3, desc="desc", ascii=True)),
                             list(range(3)))
            # Check leave with nested bars
            self.assertEqual(list(trange(3, desc="desc", leave=True)),
                             list(range(3)))
            # Check disable with nested bars
           

# Generated at 2022-06-24 09:45:09.674818
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .gui import tqdm

    with tqdm(total=10) as pbar:
        for _ in trange(10):
            pbar.update()

# Generated at 2022-06-24 09:45:19.903574
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test function for function trange."""
    import sys
    from .std import TqdmTypeError
    t = trange(10, desc='My bar')
    t.close()
    assert not t.is_active
    assert str(t) == '0it [00:00, ?it/s]My bar'
    assert str(t) == '0it [00:00, ?it/s]My bar'
    assert str(t) == '0it [00:00, ?it/s]My bar'
    t.update()
    assert str(t) != '0it [00:00, ?it/s]My bar'
    try:
        t.n
    except TqdmTypeError:
        pass

# Generated at 2022-06-24 09:45:26.304632
# Unit test for function trange
def test_trange():
    """Test function `trange`."""
    # pylint: disable=undefined-variable
    if hasattr(trange, "__self__") and trange.__self__ is tqdm:
        import pytest
        pytest.skip("skip: trange is just an alias for tqdm")

    assert list(trange(3, 10)) == list(range(3, 10))
    assert list(trange(10)) == list(range(10))


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:45:33.589796
# Unit test for function trange
def test_trange():
    """Unit test for `trange`"""
    from .utils import _range
    from .std import tqdm

# Generated at 2022-06-24 09:45:36.741811
# Unit test for function trange
def test_trange():
    assert list(trange(5)) == [0, 1, 2, 3, 4]


# Test for multiple inheritance (at least one class/functiion per module)

# Generated at 2022-06-24 09:45:44.494658
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    range_ = trange(10)
    assert iter(range_) == range_
    assert hasattr(range_, "__next__")
    assert next(range_) == 0
    assert list(range_) == list(range(1, 10))
    assert len(list(trange(0))) == 0
    assert next(trange(0), 1) is 1
    assert next(trange(0), default=1) is 1
    with trange(0) as range_:
        _range = range_
    assert _range is range_
    # Test for #623: TypeError: 'tqdm' object is not an iterator
    assert iter(_range) is _range
    assert list(_range) == []
    assert hasattr(_range, 'n')

