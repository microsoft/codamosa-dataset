

# Generated at 2022-06-24 09:35:45.607432
# Unit test for function trange
def test_trange():
    """
    Test whether trange is behaving
    """
    assert list(trange(3)) == [0, 1, 2]
    assert list(trange(3, 6)) == [3, 4, 5]

# Generated at 2022-06-24 09:35:56.598478
# Unit test for function trange
def test_trange():
    """Simple unit test for `tqdm.auto.trange`"""
    from tqdm.utils import _term_move_up

    from io import StringIO
    from os import get_terminal_size
    from time import monotonic

    try:
        from shutil import get_terminal_size as shutil_get_terminal_size
    except ImportError:
        # Python 2
        shutil_get_terminal_size = get_terminal_size

    # make sure that output is flushed immediately
    @tqdm.write
    def print_flush(*args, **kwargs):
        """Print and flush"""
        print(*args, **kwargs)
        sys.stdout.flush()

    # test that trange displays progress bar
    # by counting time waiting for user input

# Generated at 2022-06-24 09:36:03.107267
# Unit test for function trange
def test_trange():
    """Test trange function"""
    list(trange(5))
    list(tqdm(range(5)))
    try:
        from tqdm import _tqdm_notebook  # noqa
        list(notebook_trange(5))
        list(notebook_tqdm(range(5)))
    except (ImportError, RuntimeError):
        pass

# Generated at 2022-06-24 09:36:10.569242
# Unit test for function trange
def test_trange():
    """
    Unit test for function `trange`.
    """
    from .std import tqdm
    from .autonotebook import tqdm as notebook_tqdm
    from .asyncio import tqdm as asyncio_tqdm

    assert tqdm is asyncio_tqdm
    assert trange(0, 1) is not tqdm(range(0, 1))
    assert trange(0, 1) == tqdm(range(0, 1))
    assert trange(0, 1) == notebook_tqdm(range(0, 1))
    assert trange(0, 1) == asyncio_tqdm(range(0, 1))

# Generated at 2022-06-24 09:36:13.770985
# Unit test for function trange
def test_trange():
    """Test that trange() is working as expected"""
    assert list(trange(0)) == []
    assert list(trange(5)) == [0, 1, 2, 3, 4]



# Generated at 2022-06-24 09:36:14.700785
# Unit test for function trange
def test_trange():
    trange(1)


# Generated at 2022-06-24 09:36:17.742972
# Unit test for function trange
def test_trange():
    """Tests that trange(100) is an alias for tqdm(range(100))"""
    for it1, it2 in zip(trange(10), tqdm(range(10))):
        assert it1 == it2

# Generated at 2022-06-24 09:36:26.903940
# Unit test for function trange
def test_trange():
    """Test trange() and tqdm() against manual list in/decrementation."""
    from sys import version_info

    for i in trange(4, 0, -1):
        assert i == tqdm(reversed(range(1, 5)),
                         desc="trange(4, 0, -1)",
                         unit_scale=True)._n, i
    for i in trange(4, 0, -1, desc="trange(4, 0, -1, desc)"):
        assert i == tqdm(reversed(range(1, 5)),
                         desc="trange(4, 0, -1, desc)",
                         unit_scale=True)._n, i


# Generated at 2022-06-24 09:36:30.229420
# Unit test for function trange
def test_trange():
    """
    Testing function `tqdm.auto.trange()`.
    """
    from .std import trange  # pylint: disable=reimported

    assert trange(1)
    assert trange(1, 2)



# Generated at 2022-06-24 09:36:34.822453
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    lst = list(trange(10))
    assert lst == list(range(10))
    lst = list(trange(1, 10, 3))
    assert lst == list(range(1, 10, 3))
    lst = list(trange(10, 1, -3))
    assert lst == list(range(10, 1, -3))

# Generated at 2022-06-24 09:36:44.344793
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    from .autonotebook import tqdm as notebook_tqdm
    from .asyncio import tqdm as asyncio_tqdm
    from .std import tqdm as std_tqdm

    is_notebook_tqdm_std_mro = issubclass(notebook_tqdm, std_tqdm)
    if is_notebook_tqdm_std_mro:
        assert issubclass(tqdm, asyncio_tqdm)
    else:
        assert issubclass(tqdm, notebook_tqdm)

    rr = trange(3, 9)
    assert rr.__class__.__name__ == 'tqdm'

# Generated at 2022-06-24 09:36:49.685836
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from .std import TqdmExperimentalWarning
    from .std import tqdm as tqdm_std
    from .std import trange as trange_std
    from .asyncio import tqdm as tqdm_asyncio
    from .asyncio import trange as trange_asyncio
    from .autonotebook import tqdm as tqdm_notebook
    from .autonotebook import trange as trange_notebook
    from inspect import isfunction
    trange(1, 10)
    assert isfunction(trange)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        if sys.version_info[:2] < (3, 6):
            assert trange == tr

# Generated at 2022-06-24 09:36:51.929669
# Unit test for function trange
def test_trange():
    "Test function 'trange'"
    assert list(trange(1000)) == list(range(1000))
    assert list(trange(1000, 0, -1)) == list(range(1000, 0, -1))


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:36:55.331577
# Unit test for function trange
def test_trange():
    with tqdm(total=100, desc='test', unit=' B', unit_scale=True) as t:
        for _ in trange(100):
            t.update()


if __name__ == "__main__":
    # Unit test
    test_trange()

# Generated at 2022-06-24 09:36:56.564495
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    assert list(trange(3)) == list(range(3))

# Generated at 2022-06-24 09:37:07.904323
# Unit test for function trange
def test_trange():
    """Tests for trange"""
    from shutil import get_terminal_size
    from .utils import _range
    from .std import tqdm_notebook as notebook
    from .std import trange as std_trange
    from .asyncio import trange as asyn_trange

    rng = _range(3)
    for tqdm in [trange, std_trange, asyn_trange, notebook]:
        assert list(tqdm(rng)) == list(rng)
        assert list(tqdm(rng)) == list(rng)
        assert list(tqdm(rng, leave=True)) == list(rng)
        assert list(tqdm(rng, leave=False)) == list(rng)

        # test bar_format

# Generated at 2022-06-24 09:37:10.190343
# Unit test for function trange
def test_trange():
    """
    Basic test for function trange
    """
    for i in trange(10):
        assert i < 10



# Generated at 2022-06-24 09:37:12.887573
# Unit test for function trange
def test_trange():
    r = trange(10)
    assert hasattr(r, '__iter__') and hasattr(r, '__next__')
    assert sum(r) == sum(range(10))

# Generated at 2022-06-24 09:37:17.182736
# Unit test for function trange
def test_trange():
    from .autonotebook import trange as anbtrange
    try:
        from .asyncio import trange as aiotrange
    except ImportError:
        return
    for trange_ in [anbtrange, aiotrange]:
        with trange_(10) as t:
            assert isinstance(t, trange_)
            for i in t:
                assert isinstance(i, int)
                assert i >= 0
                assert i <= 9

# Generated at 2022-06-24 09:37:26.202884
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from ._utils import _range
    import time

    for _ in trange(5):
        assert _range(5, unit="it")

    for _ in trange(_range(5)):
        assert _range(5, unit="it")

    for _ in trange(5, desc="Test"):
        assert _range(5, unit="it")

    # https://github.com/tqdm/tqdm/issues/448
    for _ in trange(0, 1, 0.01, leave=False):
        time.sleep(0.01)

# Generated at 2022-06-24 09:37:32.607793
# Unit test for function trange
def test_trange():  # pragma: no cover
    import sys
    import time
    import multiprocessing as mp
    try:
        import tqdm.auto as tqdm
    except ImportError:  # pragma: no cover
        print("tqdm is not installed. This won't test `tqdm.auto.trange`.")
        sys.exit(1)

    def test_multiprocess(total):
        with tqdm.trange(total) as t:
            for _ in t:
                pass

    # Inline
    for _ in tqdm.trange(4):
        time.sleep(0.1)

    # Multiprocess
    pool = mp.Pool(2)
    pool.map(test_multiprocess, [10, 20])
    pool.close()
    pool.join()

# Generated at 2022-06-24 09:37:35.502514
# Unit test for function trange
def test_trange():
    """ Ensures trange is working correctly """
    assert list(trange(4)) == list(range(4))

# Generated at 2022-06-24 09:37:36.954038
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    assert trange(10) == list(range(10))

# Generated at 2022-06-24 09:37:43.938786
# Unit test for function trange
def test_trange():
    from .utils import freeze_iter
    from .tqdm_gui import trange as gui_trange

    for it in [trange(3),
               trange(3, 2, -1),
               trange(3, 2, -1, 1),
               trange(3, 0, -1),
               trange(3, 0, -1, 1),
               trange(3, 4, 1, 1),
               trange(3, 4, 1, 1),
               trange(3, 6, 1, 2**0),
               ]:
        with freeze_iter(it):
            o = list(it)
        assert o == list(range(*it.args))

    with freeze_iter(gui_trange(3)):
        o = list(gui_trange(3))

# Generated at 2022-06-24 09:37:48.537422
# Unit test for function trange
def test_trange():
    """
    Test for trange shortcut function.
    """
    from .std import tqdm as std_tqdm

    for i in trange(1):
        assert isinstance(i, int)

    for i in trange(1):
        assert isinstance(i, std_tqdm)

# Generated at 2022-06-24 09:37:54.039553
# Unit test for function trange
def test_trange():
    """Test for trange()"""
    from .gui import tqdm
    for _ in trange(4, position=2, desc="pos2", ascii=True):
        for _ in trange(3, position=1, desc="pos1", leave=False):
            for _ in trange(2, position=0, desc="pos0", leave=False):
                for _ in tqdm([1], desc="inner"):
                    break

# Avoid importing the whole module for the deprecated bar and bar_interval
from .gui import bar, bar_interval

# Generated at 2022-06-24 09:38:04.968488
# Unit test for function trange
def test_trange():
    """
    Examples
    --------
    >>> import sys
    >>> from tqdm.auto import trange
    >>> list(trange(10))
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    >>> list(trange(10, desc='A'))
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    >>> list(trange(10, desc='A', leave=True))
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    >>> for i in trange(10, desc='A', ascii=True):
    ...     _ = i
    """
    import sys
    from .auto import tqdm

    # test cli

# Generated at 2022-06-24 09:38:14.380413
# Unit test for function trange
def test_trange():
    """Test simple trange without notebooks"""
    from sys import version_info, modules

    def reset_auto():
        """Reset `tqdm.auto`"""
        import importlib
        for module_name in list(sys.modules):
            if module_name.startswith('tqdm.auto'):
                del sys.modules[module_name]
        for module in modules.values():
            try:
                reload = module.__loader__.reload
            except AttributeError:
                continue
            try:
                reload(module)
            except ImportError:
                pass
        if version_info[:2] >= (3, 6):
            # `importlib.invalidate_caches()` is not available in Python < 3.6
            importlib.invalidate_caches()

# Generated at 2022-06-24 09:38:20.053955
# Unit test for function trange
def test_trange():
    "Test trange"
    assert list(trange(0)) == list(range(0))
    assert list(trange(1, 0)) == list(range(1, 0))
    assert list(trange(0, 5, 2)) == list(range(0, 5, 2))
    assert list(trange(5, 0, -2)) == list(range(5, 0, -2))

# Generated at 2022-06-24 09:38:28.751750
# Unit test for function trange
def test_trange():
    """Test function trange."""
    from tqdm._tqdm import trange
    trange(0)
    trange(10, desc='Testing Trange', file=sys.stdout)
    trange(10, desc='Testing Trange', file=sys.stdout, leave=True)
    trange(10, desc='Testing Trange', file=sys.stdout, leave=False)
    trange(10, desc='Testing Trange', file=sys.stdout,
           mininterval=0.5, maxinterval=2)
    trange(10, desc='Testing Trange', file=sys.stdout,
           miniters=-1, mininterval=-1, maxinterval=-1)

# Generated at 2022-06-24 09:38:30.408861
# Unit test for function trange
def test_trange():  # pragma: no cover
    list(trange(0))
    list(trange(0, 1, 0.1))

# Generated at 2022-06-24 09:38:32.752543
# Unit test for function trange
def test_trange():
    """Test trange() function"""
    from nose.tools import assert_equal
    assert_equal(list(trange(5)), list(range(5)))

# Generated at 2022-06-24 09:38:34.739297
# Unit test for function trange
def test_trange():
    from .tests import test_trange
    return test_trange()

# Generated at 2022-06-24 09:38:45.632390
# Unit test for function trange
def test_trange():
    """Test trange"""
    from .std import trange as _trange
    from .std import tqdm as _tqdm
    from .std import TqdmExperimentalWarning
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        # Check arguments match trange
        assert trange(5).__next__() == _trange(5).__next__()
        assert trange(1, 5).__next__() == _trange(1, 5).__next__()
        assert trange(1, 5, 1).__next__() == _trange(1, 5, 1).__next__()
        # Check arguments match tqdm
        assert trange(5).__next__() == _tqdm(range(5)).__next__()

# Generated at 2022-06-24 09:38:50.372023
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import tqdm as std_tqdm
    from .asyncio import tqdm as asyncio_tqdm

    if std_tqdm == notebook_tqdm:  # Autonotebook is disabled
        assert trange is std_tqdm
    else:  # Autonotebook is enabled
        assert trange is asyncio_tqdm
        assert trange is tqdm

# Generated at 2022-06-24 09:38:59.789078
# Unit test for function trange
def test_trange():
    assert list(trange(10)) == list(notebook_trange(10)) == list(range(10))
    assert list(trange(10, 0, -1)) == list(notebook_trange(10, 0, -1)) == list(
        range(10, 0, -1)
    )
    assert list(trange(10, 10)) == list(notebook_trange(10, 10)) == list(range(10, 10))
    assert list(trange(10, 10, 1)) == list(notebook_trange(10, 10, 1)) == list(
        range(10, 10, 1)
    )
    assert list(trange(0)) == list(notebook_trange(0)) == list(range(0))



# Generated at 2022-06-24 09:39:01.024810
# Unit test for function trange
def test_trange():
    """Unit test for trange"""
    for _ in trange(3, leave=False):
        pass

# Generated at 2022-06-24 09:39:08.440010
# Unit test for function trange
def test_trange():
    """Test for ``tqdm.auto.trange(...)``"""
    from tqdm.auto import trange

    for _ in trange(3):
        pass
    for _ in trange(3, desc="a"):
        pass
    for _ in trange(3, "a"):
        pass
    for _ in trange(3, 3):
        pass
    for _ in trange(3, 3, desc="a"):
        pass
    for _ in trange(3, 3, "a"):
        pass

# Generated at 2022-06-24 09:39:16.278265
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .utils import _decode_unicode
    for i in trange(int(10e5)):
        _ = i
    out = _decode_unicode(sys.stderr.getvalue())
    assert "100%" in out
    assert "|elapsed:" in out
    assert "|eta:" in out
    assert "|loss:" in out
    assert "|rate:" in out
    assert "|spent:" in out
    assert "|total:" in out
    assert "|n:" in out



# Generated at 2022-06-24 09:39:19.017392
# Unit test for function trange
def test_trange():
    """Test trange main output"""
    total = 6
    with trange(total) as t:
        assert len(t) == total



# Generated at 2022-06-24 09:39:27.325654
# Unit test for function trange
def test_trange():
    """
    Tests that `trange` is a shortcut for `tqdm(range(*args), **kwargs)`.
    """
    with tqdm(total=0) as pbar:
        for _ in trange(3):
            pass
        assert pbar.n == 3
    with tqdm(total=0) as pbar:
        for _ in trange(3, 10):
            pass
        assert pbar.n == 7
    with tqdm(total=0) as pbar:
        for _ in trange(3, 10, 3):
            pass
        assert pbar.n == 4
    with tqdm(total=0, leave=False) as pbar:
        for _ in trange(3, 10, 3, leave=False):
            pass
        assert pbar.n == 4
       

# Generated at 2022-06-24 09:39:36.497616
# Unit test for function trange
def test_trange():
    import os
    import sys
    import time
    # Force the threading function to NOT be used
    os.environ["TQDM_USE_THREADING"] = "0"
    # Force the asyncio function to NOT be used
    os.environ["TQDM_USE_ASYNCIO"] = "0"
    # Force the autonotebook function to NOT be used
    os.environ["TQDM_DISABLE_AUTONOTEBOOK"] = "1"
    # Force the autonotebook function to NOT be used
    os.environ["TQDM_DISABLE_AUTONOTEBOOK"] = "1"
    from tqdm.std import tqdm as std_tqdm

    for i in std_tqdm(range(20), position=0):
        time.sleep(0.01)



# Generated at 2022-06-24 09:39:45.616467
# Unit test for function trange
def test_trange():
    """
    Test that `trange` behaves like `range`
    """
    # Test subtraction
    assert list(trange(5)) == list(range(5))
    assert list(trange(0)) == list(range(0))
    assert list(trange(1)) == list(range(1))
    assert list(trange(2)) == list(range(2))
    assert list(trange(1, 2)) == list(range(1, 2))
    assert list(trange(1, 3)) == list(range(1, 3))
    assert list(trange(1, 4)) == list(range(1, 4))

    # Test negative step
    assert list(trange(5, 0, -1)) == list(range(5, 0, -1))

# Generated at 2022-06-24 09:39:47.712141
# Unit test for function trange
def test_trange():
    """Test trange"""
    __tracebackhide__ = True
    for _ in trange(int(1e3), desc='Testing trange'):
        pass

# Generated at 2022-06-24 09:39:51.019568
# Unit test for function trange
def test_trange():
    """Test function trange"""
    assert list(trange(0)) == []
    assert list(trange(10)) == list(range(10))
    assert list(trange(0, 10)) == list(range(0, 10))
    assert list(trange(0, 10, 1)) == list(range(0, 10, 1))

# Generated at 2022-06-24 09:39:55.828107
# Unit test for function trange
def test_trange():
    """Test if trange is equivalent of using tqdm with range"""
    n = 100
    assert len(list(trange(n))) == n
    assert len(list(tqdm(range(n)))) == n

if __name__ == "__main__":
    test_trange()
    print("All tests passed")

# Generated at 2022-06-24 09:39:57.657141
# Unit test for function trange
def test_trange():
    """Test function trange"""
    for _ in trange(4):
        pass
    for _ in trange(1, 4):
        pass
    for _ in trange(1, 4, 2):
        pass

# Generated at 2022-06-24 09:40:05.076972
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .std import trange

    # Test: `range` == `trange`
    for i in trange(3):
        assert i in (0, 1, 2)

    # Test: `range` == `trange(ascii=True)`
    for i in trange(3, ascii=True):
        assert i in (0, 1, 2)

    # Test: `range` == `trange(pos=1)`
    for i in trange(3, pos=1):
        assert i in (0, 1, 2)

    # Test: `range` == `trange(1, 4)`
    for i in trange(1, 4):
        assert i in (1, 2, 3)

    # Test: `range` == `trange(1, 4

# Generated at 2022-06-24 09:40:06.805386
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    for _ in trange(1):
        assert _ == 0

# Generated at 2022-06-24 09:40:14.756842
# Unit test for function trange
def test_trange():
    """Test trange"""
    tqdm_list = []
    # pylint: disable=no-member
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        with trange(10) as t:
            tqdm_list.append(t)
            for i in t:
                assert isinstance(t, tqdm)
                if i > 5:
                    raise Exception
        assert hasattr(trange(10), "__enter__")
        assert not hasattr(trange(10), "__exit__")
    for t in tqdm_list:
        # Make sure .close() method is present and works
        t.close()



# Generated at 2022-06-24 09:40:17.701568
# Unit test for function trange
def test_trange():
    with tqdm(total=10) as pbar:
        for _ in trange(10):
            pbar.update()

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:40:27.527868
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from ._utils import _test_external_prog
    from .std import FormatStrinMismatchError
    from .proxy import proxy_iterator

    args1 = ("test trange",)
    kwargs1 = {"desc": "testing function trange"}
    with tqdm(*args1, **kwargs1) as t:
        assert repr(t) == "tqdm({})".format(repr(args1)[1:-1])
        assert t.desc == kwargs1["desc"]
        t.update(1)

    args2 = (1, 2)
    kwargs2 = {"desc": "testing function trange",
               "ascii": True, "dynamic_ncols": True, "ncols": 80}

# Generated at 2022-06-24 09:40:33.686250
# Unit test for function trange
def test_trange():
    """Test for `tqdm.auto.trange`"""
    for i_ in trange(4, 0, -1):
        assert i_ == 4 - i_

# Generated at 2022-06-24 09:40:34.911661
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    list(trange(3, leave=True))

# Generated at 2022-06-24 09:40:38.390834
# Unit test for function trange
def test_trange():
    """ Unit test for function trange """
    for _ in trange(3):
        pass
    with trange(3) as t:
        for i in t:
            assert i == t.n

# Generated at 2022-06-24 09:40:40.926345
# Unit test for function trange
def test_trange():
    """
    Test function `trange` with different environments.
    """
    # Test `trange` for no-notebook environment
    if 'IPython' not in sys.modules:
        assert trange(10) is not None

# Generated at 2022-06-24 09:40:43.187401
# Unit test for function trange
def test_trange():
    # Dummy function to test function trange
    for i in trange(4, desc='Test', leave=True, disable=False):
        print(i)

# Generated at 2022-06-24 09:40:48.556835
# Unit test for function trange
def test_trange():  # pragma: no cover
    from time import sleep

    for i in trange(4, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            for k in trange(50, desc='3nd loop', leave=False):
                sleep(0.01)


if __name__ == "__main__":  # pragma: no cover
    from ._utils import _test_module_docstrings
    _test_module_docstrings(__file__, globals())

# Generated at 2022-06-24 09:40:51.890957
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .std import tqdm
    assert trange(0) == tqdm(range(0))
    assert trange(3, 1) == tqdm(range(3, 1))
    assert trange(3, 1, -1) == tqdm(range(3, 1, -1))


# Generated at 2022-06-24 09:40:54.290045
# Unit test for function trange
def test_trange():
    """Unit test for function trange."""
    with tqdm(total=10, unit=" ") as t:
        for i in trange(10):
            t.update(1)

# Generated at 2022-06-24 09:41:02.749344
# Unit test for function trange
def test_trange():
    """Test trange"""
    from .std import tqdm as std_tqdm

    assert trange(0) == std_tqdm(iter(range(0)))
    assert trange(0, 0) == std_tqdm(iter(range(0, 0)))
    assert trange(0, 0, 1) == std_tqdm(iter(range(0, 0, 1)))
    assert trange(0, 1, 2) == std_tqdm(iter(range(0, 1, 2)))
    assert trange(0, 1, -1) == std_tqdm(iter(range(0, 1, -1)))
    assert trange(0, -1, -2) == std_tqdm(iter(range(0, -1, -2)))


# Generated at 2022-06-24 09:41:07.853086
# Unit test for function trange
def test_trange():
    """
    Simple unit test to verify the behaviour of `tqdm.auto.trange`
    """
    from time import sleep

    trange_iterator = trange(1, 5, step=1)
    assert str(trange_iterator) == "range(1, 5)"

    for i, j in zip(range(1, 6), trange_iterator):
        sleep(0.1)
        assert i == j

# Generated at 2022-06-24 09:41:09.433028
# Unit test for function trange
def test_trange():
    """Simple sanity check."""
    from .std import tqdm
    with tqdm(total=10) as pbar:  # pylint: disable=unused-variable
        for _ in trange(10):
            pass

# Generated at 2022-06-24 09:41:10.813010
# Unit test for function trange
def test_trange():
    """Test trange"""
    for _ in trange(4):
        pass

# Generated at 2022-06-24 09:41:20.380503
# Unit test for function trange
def test_trange():
    """
    Tests function `trange`.
    """
    with tqdm(total=10, position=1) as t:
        assert t.position == 1, t.position
        assert len(t) == 10, len(t)
        t.update()
        assert t.position == 2, t.position

        t.reset(total=len(t) - 1)
        assert t.position == 0, t.position
        assert len(t) == 9, len(t)

        t.reset(len(t) - 1)
        assert t.position == 0, t.position
        assert len(t) == 8, len(t)

        t.refresh()
        assert t.position == 1, t.position
        assert len(t) == 8, len(t)

# Generated at 2022-06-24 09:41:28.312705
# Unit test for function trange
def test_trange():
    """Test trange on Python3.6+"""
    import sys
    if sys.version_info[:2] < (3, 6):
        return
    for i in trange(4, 15, 7):
        pass
    for i in trange(4, -24, -7):
        pass
    for i in trange(24, 4, -7):
        pass

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:41:34.995968
# Unit test for function trange
def test_trange():
    """Smoke test for trange"""
    from inspect import isfunction
    from numpy.random import randint
    from time import sleep
    from tqdm.auto import trange

    # Check if trange is a function
    assert isfunction(trange)

    # Check if trange works
    trange(3)

    # Check if trange works with a random sleep
    for _ in trange(3):
        sleep(randint(1, 100) / 1000)

# Generated at 2022-06-24 09:41:36.863187
# Unit test for function trange
def test_trange():
    """ Tests trange function """
    for _ in trange(4):
        pass
    for _ in trange(4, 10):
        pass
    for _ in trange(4, 10, 2):
        pass
    for _ in trange(10, 4, -2):
        pass

# Generated at 2022-06-24 09:41:40.103534
# Unit test for function trange
def test_trange():
    trange(1)
    for _ in trange(10, desc="desc", mininterval=0):
        pass
    for _ in trange(10, 1, desc="desc", mininterval=0):
        pass
    for _ in trange(10, 10, 1, desc="desc", mininterval=0):
        pass

# Generated at 2022-06-24 09:41:49.630128
# Unit test for function trange
def test_trange():
    from .utils import _supports_unicode
    from ._tqdm import format_size, format_interval

    for _ in trange(10):
        pass
    for _ in trange(10, desc='foob'):
        pass
    for _ in trange('a', desc='foob'):  # Test if len('a') is 1 or error
        pass
    for _ in trange(10, dynamic_ncols=lambda: 10):
        pass
    for _ in trange(10, dynamic_ncols=lambda: 10, smoothing=0.1):
        pass

    format_interval_short = format_interval(0)
    format_interval_long = format_interval(0, short=False)

# Generated at 2022-06-24 09:41:56.355899
# Unit test for function trange
def test_trange():
    """Unit test for simple `tqdm.auto.trange` usage"""
    import sys
    import time

    with tqdm(total=3) as pbar:
        for _ in trange(3):
            time.sleep(0.1)
            pbar.update()
        assert pbar.n == pbar.total == 3
        assert pbar.last_print_n == 3

# Generated at 2022-06-24 09:42:01.578498
# Unit test for function trange
def test_trange():
    """Test function trange."""
    from ._utils import _test_iterable_pprint
    from .trange import trange
    from .autonotebook import trange as nb_trange
    from .asyncio import tqdm as asi_tqdm

    for tr in trange, nb_trange, asi_tqdm:
        _test_iterable_pprint(tr, length=1000,
                              desc='this is a test', leave=False)

# Generated at 2022-06-24 09:42:11.466111
# Unit test for function trange
def test_trange():
    """Test trange"""
    from .std import FormatBase

    fb = FormatBase(
        prefix="",
        suffix="",
        ascii=None,
        unit="",
        unit_scale=False,
        miniters=1,
        mininterval=0.1,
    )
    assert fb.format_meter(0, 0, 1, 1, 0, 0) == "0/1   "
    assert fb.format_meter(5, 5, 10, 1, 0, 0) == "5/10  "
    assert fb.format_meter(1, 1, 10, 1, 0, 0) == "1/10  "
    assert fb.format_meter(9, 9, 10, 1, 0, 0) == "9/10  "


# Generated at 2022-06-24 09:42:19.349646
# Unit test for function trange
def test_trange():
    """
    Tests `trange`.
    """
    import sys
    import time
    import operator
    from contextlib import contextmanager
    from warnings import catch_warnings

    from .asyncio import trange as asyncio_trange

    @contextmanager
    def trange_on_stdout():
        """
        Context manager for testing `trange`'s formatting.
        """
        # pylint: disable=protected-access
        import sys
        import io
        from .asyncio import _range
        old_stdout = sys.stdout
        try:
            sys.stdout = io.StringIO()
            yield from _range(0, 100, desc="test", unit="s")
            sys.stdout.seek(0)
            yield sys.stdout.read()
        finally:
            sys.std

# Generated at 2022-06-24 09:42:21.235391
# Unit test for function trange
def test_trange():
    """
    Tests `trange` function.
    """
    from .std import tqdm
    # Ensure trange instantiates the same type as tqdm
    assert isinstance(trange(4), tqdm)

# Generated at 2022-06-24 09:42:31.921975
# Unit test for function trange
def test_trange():
    """Test trange function against tqdm."""
    from .std import trange
    import sys

    if sys.version_info[0] == 3:
        from io import StringIO
    else:
        from io import BytesIO as StringIO

    with warnings.catch_warnings():
        with tqdm(total=10) as t:
            t.set_description("hi")
            for i in trange(4, 5):
                sio = StringIO()
                t.write("hello", file=sio)
                assert sio.getvalue() == "hello\n"
                t.update()

            for i in trange(5, 6):
                sio = StringIO()
                t.write("world", file=sio)
                assert sio.getvalue() == "world\n"
                t

# Generated at 2022-06-24 09:42:41.289052
# Unit test for function trange
def test_trange():
    """
    Tests that trange imports and functions properly
    """
    import re
    import shutil

    that_long = 80
    those_short = 40
    nums = list(range(10))
    with trange(that_long, desc='A long loop', leave=True) as my_tqdm:
        for _ in my_tqdm:
            for _ in range(those_short):
                nums = [n * n for n in nums]
        assert my_tqdm.calls == 1  # bar was just being updated
    for _ in trange(that_long, desc='A long loop'):
        for _ in range(those_short):
            nums = [n * n for n in nums]

# Generated at 2022-06-24 09:42:43.394651
# Unit test for function trange
def test_trange():
    """Test function `trange`"""
    assert list(trange(0)) == []
    assert list(trange(5)) == [0, 1, 2, 3, 4]



# Generated at 2022-06-24 09:42:48.020266
# Unit test for function trange
def test_trange():
    """Tests trange()"""
    assert trange(10).sum() == 45  # pylint: disable=no-member
    assert trange(10, 0, -1).sum() == 45  # pylint: disable=no-member
    assert trange(0, 10, 2).sum() == 30  # pylint: disable=no-member
    assert trange(0, 20, 2).sum() == 90  # pylint: disable=no-member
    assert trange(0, 20, 2, desc="test").sum() == 90  # pylint: disable=no-member


# Generated at 2022-06-24 09:42:51.127092
# Unit test for function trange
def test_trange():
    """Test `trange`"""
    assert list(trange(0)) == []
    assert list(trange(1)) == [0]
    assert list(trange(2)) == [0, 1]



# Generated at 2022-06-24 09:42:59.763172
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .asyncio import tqdm as asyncio_tqdm
    from .autonotebook import tqdm as notebook_tqdm
    from .std import tqdm as std_tqdm

    assert trange(1).__class__ is tqdm(range(1))
    if notebook_tqdm != std_tqdm:
        assert trange(1).__class__ is notebook_tqdm(range(1))
    assert trange(1).__class__ is asyncio_tqdm(range(1))

# Generated at 2022-06-24 09:43:01.286852
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from .std import tqdm
    return tqdm(trange(1000))

# Generated at 2022-06-24 09:43:03.201486
# Unit test for function trange
def test_trange():
    for _ in trange(10 ** 4, 0, -1):
        continue

# Generated at 2022-06-24 09:43:07.150372
# Unit test for function trange
def test_trange():
    """ Test function trange """
    with tqdm(total=10) as bar:
        bar.update(3)
        assert bar.n == 3

        bar.update(6)
        assert bar.n == 9

        bar.update(1)
        assert bar.n == 10

# Generated at 2022-06-24 09:43:08.780413
# Unit test for function trange
def test_trange():
    """
    >>> assert list(trange(5)) == list(range(5))
    """
    pass

# Generated at 2022-06-24 09:43:12.289644
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .autonotebook import trange  # pylint: disable=redefined-outer-name
    assert trange(5) == range(5)

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:43:20.053751
# Unit test for function trange
def test_trange():
    """ Test the function trange.

    Test that the function trange is equivalent to tqdm(range(...)),
    but faster.
    """
    import time

    start_time = time.time()
    list(trange(0, 100, desc="trange ", leave=True))
    trange_time = time.time() - start_time

    start_time = time.time()
    list(tqdm(range(0, 100), desc="tqdm   ", leave=True))
    tqdm_time = time.time() - start_time

    assert trange_time < tqdm_time / 2

# Generated at 2022-06-24 09:43:30.008666
# Unit test for function trange
def test_trange():
    """Test for trange function"""
    # Note: there is a bug in coverage.py when using the
    #       coverage.py module itself
    #       (see https://bitbucket.org/ned/coveragepy/issues/593).
    #       Therefore, we use the subprocess module instead.
    import subprocess
    cmd = [sys.executable, "-m", "coverage", "run", "-a",
           "--source=tqdm.auto",
           "--omit=tqdm/tests/*",
           "-m", "unittest", "tqdm.tests.test_trange"]
    subprocess.check_call(cmd)
    subprocess.check_call([sys.executable, "-m", "coverage", "report"])

# Generated at 2022-06-24 09:43:37.200911
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    import io
    import sys

    sys.stderr = io.StringIO()
    try:
        for _ in trange(0, 4, 0.5, desc="Unit test for function trange"):
            pass
    finally:
        out = sys.stderr.getvalue()
    sys.stderr = sys.__stderr__

    assert out == "Unit test for function trange: 100%|##########| 8/8 [00:00<?, ?it/s]\n"


if __name__ == "__main__":
    test_trange()
    print("Success")

# Generated at 2022-06-24 09:43:39.232582
# Unit test for function trange
def test_trange():
    """Tests `func:trange` function"""
    assert list(trange(5)) == list(range(5))
    assert list(trange(10, 2)) == list(range(10, 2))

# Generated at 2022-06-24 09:43:45.734645
# Unit test for function trange
def test_trange():
    """
    Tests `trange`.
    """
    # Create a list of values
    values = list(range(10))
    # Calculate the sum of all values
    s = 0
    # Iterate over the values
    for i in trange(len(values)):
        # Update the sum
        s += values[i]
    # Return the sum
    assert s == 45


# Execute the unit tests
if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 09:43:48.024105
# Unit test for function trange
def test_trange():
    """Test the trange function"""
    assert list(trange(9)) == list(range(9))



# Generated at 2022-06-24 09:43:54.218631
# Unit test for function trange
def test_trange():
    """Test function `trange()`."""
    from .std import tqdm

# Generated at 2022-06-24 09:43:56.088514
# Unit test for function trange
def test_trange():
    assert trange(3) == tqdm(range(3), ascii=True, desc=None)

# Generated at 2022-06-24 09:43:59.386592
# Unit test for function trange
def test_trange():
    """
    Tests that `tqdm.auto.trange` function works.
    """
    trange(10)


if __name__ == "__main__":
    from ._utils import _test
    _test()

# Generated at 2022-06-24 09:44:03.478818
# Unit test for function trange
def test_trange():
    """Test trange"""
    # Test non-chained ranges
    assert list(tqdm(range(3+1))) == [0, 1, 2, 3]
    # Test chained ranges
    assert list(tqdm(tqdm(tqdm(range(3+1))))) == [0, 1, 2, 3]

# Generated at 2022-06-24 09:44:07.498230
# Unit test for function trange
def test_trange():
    """Test trange function."""
    range_length = 10
    assert len(list(tqdm(range(range_length)))), range_length


if __name__ == "__main__":
    test_trange()
    print("\nTest passed")

# Generated at 2022-06-24 09:44:14.619154
# Unit test for function trange
def test_trange():
    """Test function trange"""
    for i in trange(5):
        pass
    for i in trange(5, desc="desc"):
        pass
    for i in trange(5, desc="desc", leave=False):
        pass
    for i in trange(5, desc="desc", total=5, leave=False):
        pass
    for i in trange(5, desc="desc", unit="steps", leave=False):
        pass
    for i in trange(5, desc="desc", unit="steps", unit_scale=True, leave=False):
        pass
    for i in trange(5, desc="desc", unit="steps", ascii=True, leave=False):
        pass


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:44:23.392510
# Unit test for function trange
def test_trange():
    class Range:
        def __init__(self, start, stop=None, step=1):
            self.start = start
            self.stop = stop or start
            self.step = step
            self.i = start - 1

        def __iter__(self):
            return (self.start + self.step * i for i in range(self.stop - self.start))

        def __len__(self):
            return (self.stop - self.start)

    r = Range(5)
    assert len(r) == 5
    assert list(trange(r)) == list(tqdm(r))
    assert list(trange(5)) == list(tqdm(5))

# Generated at 2022-06-24 09:44:25.161824
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    for _ in trange(10):
        pass


# Generated at 2022-06-24 09:44:31.334929
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import trange
    assert trange(1, 5) == trange(5) == range(5)
    assert trange(0) == trange(0, 0) == range(0)
    assert trange(1, -1) == []
    assert trange(1, -1, -1) == [1, 0]
    assert list(trange(0, 1, 0)) == []
    assert list(trange(0, 0, 0)) == [0]

# Generated at 2022-06-24 09:44:40.886035
# Unit test for function trange
def test_trange():
    """Test function trange"""
    iterable = list(range(10))
    for _ in trange(10):
        pass
    assert iterable == list(range(10))
    for _ in trange(5, 15):
        pass
    assert iterable == list(range(10))
    for _ in trange(5, 20, 2):
        pass
    assert iterable == list(range(10))
    for _ in trange(1, 0, -0.3):
        pass
    assert iterable == list(range(10))
    for _ in trange(0, 0.1, 0.03):
        pass
    assert iterable == list(range(10))
    for _ in trange(list(range(20))):
        pass
    assert iterable == list(range(10))

# Generated at 2022-06-24 09:44:43.633348
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    Tests that trange is functional.
    """
    assert list(trange(5)) == [0, 1, 2, 3, 4]



# Generated at 2022-06-24 09:44:47.984876
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    import time
    from tqdm import trange
    with trange(10) as t:
        for i in t:
            time.sleep(0.01)
            t.set_description("test:%i" % i)

if __name__ == "__main__":
    test_trange()  # unit test

# Generated at 2022-06-24 09:44:57.262216
# Unit test for function trange
def test_trange():
    "Test trange function"
    from .std import get_current_tqdm_class
    class Tqdm(get_current_tqdm_class()):
        """
        Tqdm class without any features.
        """
        def __init__(self, *args, **kwargs):
            """
            Initialises the instance.
            """
            super().__init__(*args, disable=True, dynamic_ncols=True, **kwargs)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        from .autonotebook import trange as notebook_trange

        assert (not hasattr(notebook_trange, '_instances'))
        for i in notebook_trange(1, 0, -1):
            break


# Generated at 2022-06-24 09:45:00.721025
# Unit test for function trange
def test_trange():
    """Smoke test: test the function trange"""
    for _ in trange(10):
        pass

if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 09:45:02.232103
# Unit test for function trange
def test_trange():
    """
    Tests whether trange is callable.
    """
    assert callable(trange)


# Generated at 2022-06-24 09:45:05.181483
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    with warnings.catch_warnings(record=True) as warns:
        for _ in trange(10):
            pass
        # no warnings expected
        assert not warns

# Generated at 2022-06-24 09:45:12.855540
# Unit test for function trange
def test_trange():
    """
    Test for trange()
    """
    from .std import TqdmTypeError, TqdmExperimentalWarning
    from .std import tqdm_py3 as tqdm  # pylint: disable=import-error
    from .std import _range  # pylint: disable=import-error
    from .std import ensure_minimum_size  # pylint: disable=import-error

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)

        for _t in [list]:
            for unit in ["it", "its"]:
                kwargs = {'total': 5, 'unit': unit, 'ncols': 63}
                assert len(str(_t(trange(**kwargs)))) == 63

# Generated at 2022-06-24 09:45:18.849913
# Unit test for function trange
def test_trange():
    try:
        from unittest.mock import patch
        from io import StringIO
    except ImportError:
        from mock import patch, StringIO
    with patch('sys.stdout', new_callable=StringIO) as captured_stdout:
        for i in trange(10):
            if i == 5:
                break
    return '5it [00:00, ?it/s]' in captured_stdout.getvalue()

# Generated at 2022-06-24 09:45:27.722019
# Unit test for function trange
def test_trange():
    """
    Test for trange()
    """
    from math import sqrt
    from random import random
    try:
        import pytest
    except ImportError:
        print("ERROR: need module pytest")
        return

    def assertAlmostEqual(a, b, places=7):
        assert round(a - b, places) == 0

    r = trange(10, leave=False)
    assert r.__iter__() is r
    assert list(r) == list(range(10))
    assert len(r) == 10
    assert r[5] == 5
    assert r[:5] == range(5)
    assert r[5:] == range(5, 10)
    assert r[1:8:2] == range(1, 8, 2)
    assert r[-2] == 8

# Generated at 2022-06-24 09:45:29.765548
# Unit test for function trange
def test_trange():
    list(trange(1))
    list(trange(1, 2))
    list(trange(1, 2, 3))
    list(trange(1, None))

# Generated at 2022-06-24 09:45:30.729066
# Unit test for function trange
def test_trange():
    for _ in trange(10):
        pass

# Generated at 2022-06-24 09:45:33.384346
# Unit test for function trange
def test_trange():
    """
    Simply tests that trange works.
    """
    list(trange(int(1e6)))

# Generated at 2022-06-24 09:45:35.044599
# Unit test for function trange
def test_trange():
    for n in trange(4):
        pass
    assert n == 3

# Generated at 2022-06-24 09:45:39.110735
# Unit test for function trange
def test_trange():
    """Test the function `trange`."""

    for _ in trange(4):
        pass

    for i, _ in enumerate(trange(4)):
        assert i == _

    _ = list(trange(4))

# Generated at 2022-06-24 09:45:40.605979
# Unit test for function trange
def test_trange():
    """
    Tests for correct trange function
    """
    assert type(trange(1)) is tqdm

# Generated at 2022-06-24 09:45:45.715183
# Unit test for function trange
def test_trange():
    """
    Unit test for function `trange`.
    """
    for _ in trange(4, 0, -1):
        pass
    for _ in trange(4, 0, -1, leave=True):
        pass