

# Generated at 2022-06-24 09:35:45.462236
# Unit test for function trange
def test_trange():
    """
    Unit test for `tqdm.auto.trange`
    """
    from ._utils import _term_move_up
    from .std import TqdmTypeError
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        from .autonotebook import tnrange
    from .asyncio import trange as asyncio_trange

    for trange_ in [trange, asyncio_trange]:
        for args in [[], [10], [1, 2, 3]]:
            for kwargs in [{}, {'leave': True}]:
                t = trange_(*args, **kwargs)
                if not isinstance(t, trange._tqdm_cls):  # pylint: disable=protected-access
                    raise T

# Generated at 2022-06-24 09:35:55.578060
# Unit test for function trange
def test_trange():
    from .autonotebook import tqdm as atqdm
    from .std import tqdm as stqdm
    from .asyncio import tqdm as atqdm

    assert trange(1, 2) == list(range(1, 2))
    assert trange(1, 2).__class__ is trange(1, 2).__class__.__base__

    assert trange(1, 2).__class__ is atqdm(range(1, 2)).__class__
    assert trange(1, 2).__class__ is stqdm(range(1, 2)).__class__
    assert trange(1, 2).__class__ is atqdm(range(1, 2)).__class__

# Generated at 2022-06-24 09:35:56.872353
# Unit test for function trange
def test_trange():
    """
    >>> list(trange(3))
    [0, 1, 2]
    """
    pass

# Generated at 2022-06-24 09:36:01.233237
# Unit test for function trange
def test_trange():
    """
    >>> values = [x / 100 for x in range(1000)]
    >>> for i in trange(len(values)):
    ...     values[i] = values[i] ** 2
    """
    assert True

# Generated at 2022-06-24 09:36:10.198505
# Unit test for function trange
def test_trange():
    """Test that trange is equivalent to tqdm(range)"""
    # argparse is not supported in Python 2.6
    if sys.version_info[:2] == (2, 6):
        raise unittest.SkipTest("argparse is not supported in Python 2.6")

    import argparse

    from .std import tqdm

    parser = argparse.ArgumentParser(description="test trange")
    parser.add_argument("--range", default=10, type=int,  dest="N",
                        help="range for trange")
    args = parser.parse_args()

    for _ in tqdm(range(args.N)) + tqdm(range(args.N), miniters=1):
        pass

# Generated at 2022-06-24 09:36:19.566008
# Unit test for function trange
def test_trange():
    from .std import trange
    from .std import tqdm
    for c in range(5, 20, 5):
        assert sum(list(trange(c))) == sum(list(tqdm(range(c))))
        assert sum(list(trange(c, desc="d"))) == sum(list(tqdm(range(c), desc="d")))
        assert sum(list(trange(c, leave=True))) == sum(list(tqdm(range(c), leave=True)))
        assert sum(list(trange(c, smoothing=0))) == sum(list(tqdm(range(c), smoothing=0)))
        assert sum(list(trange(c, total=2 * c))) == sum(list(tqdm(range(2 * c), total=2 * c)))

# Generated at 2022-06-24 09:36:28.844621
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .tqdm import trange
    from .utils import _term_move_up

    pbar = trange(10)
    for i in pbar:
        if i == 3:
            break
    pbar.close()

    # Test bar_format

# Generated at 2022-06-24 09:36:32.015666
# Unit test for function trange
def test_trange():
    "Make sure that function trange still works"
    with tqdm(total=10) as pbar:
        for _ in trange(5):
            pbar.update()
    assert pbar.n == 5
    assert pbar.total == 10

# Generated at 2022-06-24 09:36:42.459228
# Unit test for function trange
def test_trange():
    """
    Test to check trange defined in this file is working as intended.
    """
    from .tqdm import trange
    import time
    # Test to ensure that trange is working.
    for i in trange(10):
        assert i in range(10)
        time.sleep(0.01)
    # Test to ensure that trange is working along with positional and keyword
    # arguments.
    for i in trange(1, 10, 2):
        assert i in range(1, 10, 2)
        time.sleep(0.01)
    for i in trange(1, 11, 2, desc='Test trange defined in this file'):
        assert i in range(1, 11, 2)
        time.sleep(0.01)

# Generated at 2022-06-24 09:36:51.445237
# Unit test for function trange
def test_trange():

    # Test unit of the trange function
    assert [el for el in trange(10)] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    # Test with kwargs
    assert [el for el in trange(3, desc="Foo", leave=True)] == [0, 1, 2]
    # Test unit amount
    assert [el for el in trange(3)] == [0, 1, 2]
    # Test unit with kwargs
    assert [el for el in trange(3, desc="Foo", leave=True)] == [0, 1, 2]
    # Test start
    assert [el for el in trange(3, 5)] == [3, 4]
    # Test start with kwargs

# Generated at 2022-06-24 09:37:02.037296
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test for function trange"""
    from .utils import discard_streams

    with discard_streams():
        list(trange(5))
        list(trange(10, 5))
        assert len(list(trange(10, 5, -2))) == 3

    # `range` accepts float, but not `trange` (for now)
    with discard_streams():
        expected = list(range(10, 5, -1)) + list(range(5, 11, 2))
        assert list(trange(10, 5, -1)) == expected

    with discard_streams():
        list(trange(10, 5, -5))
        list(trange(5, 10, 5))

    with discard_streams():
        list(trange(5, 5))

   

# Generated at 2022-06-24 09:37:12.546029
# Unit test for function trange
def test_trange():
    """
    Sanity test for function `trange` to make sure it is the same
    as the function `tqdm`
    """
    import io
    import sys
    import unittest

    sys.modules['ipykernel'] = type('module', (object,), {'__getattr__': lambda x, y: None})()

    class TestTqdm(unittest.TestCase):
        """
        Class for test cases
        """
        @staticmethod
        def check(s, x):
            for i in trange(len(s), desc="check"):
                assert s[i] == x[i], "iteration {} not equal".format(i)

    sys.stderr = io.StringIO()
    TestTqdm().check("abcdefg", "abcdefg")
    sys.stder

# Generated at 2022-06-24 09:37:18.670879
# Unit test for function trange
def test_trange():
    """Run ``trange`` unit tests."""
    trange(3)
    trange(3, 7)
    trange(3, 12, 3)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        from .asyncio import tqdm as atqdm
        from .autonotebook import tqdm as nbtqdm
        from .std import tqdm as stqdm
        if nbtqdm != stqdm:
            assert tqdm is nbtqdm
            assert trange is nbtqdm
            trange(3)
            trange(3, 7)
            trange(3, 12, 3)
            assert tqdm is atqdm
        else:
            assert tqdm is atqdm
        assert trange is atqdm
        trange

# Generated at 2022-06-24 09:37:22.649652
# Unit test for function trange
def test_trange():
    with tqdm(total=3) as pbar:
        for i in trange(3):
            pbar.update()
    assert pbar.n == 3

# Generated at 2022-06-24 09:37:30.571066
# Unit test for function trange
def test_trange():
    from .std import trange

    try:
        from numpy import int64
    except ImportError:
        pass  # can't test

    # Iterable range
    assert list(trange(0)) == []
    assert list(trange(10)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(trange(10, 0)) == []
    assert list(trange(10, 5, -1)) == [10, 9, 8, 7, 6]

    # Type safety
    assert trange(0, 0, 0)
    assert trange(10, 10, 1)
    assert trange(10., 10., 1.)
    assert trange(10j, 10j, 1j)

# Generated at 2022-06-24 09:37:36.202194
# Unit test for function trange
def test_trange():
    import sys
    if sys.version_info[:2] < (3, 6):
        from .autonotebook import trange as ref_trange
    else:
        from .asyncio import trange as ref_trange
    with ref_trange(2) as progress:
        progress.update()
        progress.update()
    assert progress.n == 2

# Generated at 2022-06-24 09:37:39.715694
# Unit test for function trange
def test_trange():
    """Test trange wrapper"""
    assert list(trange(10)) == list(range(10))
    assert list(trange(5, 11)) == list(range(5, 11))
    assert list(trange(5, 21, 5)) == list(range(5, 21, 5))

# Generated at 2022-06-24 09:37:50.401216
# Unit test for function trange
def test_trange():
    """Test trange method"""
    import sys
    for range_mode in [lambda x: range(x), lambda x: tqdm(range(x), dynamic_ncols=True),
                       lambda x: notebook_trange(x),
                       lambda x: tqdm(range(x), dynamic_ncols=True)]:
        # Testing basic use
        sum_ = 0
        with trange(10) as t:
            for i in t:
                sum_ += i
                assert sum_ == i * (i + 1) // 2
                t.set_description("testing trange: " + str(i))
        assert sum_ == 45

        # Testing empty iterable
        with trange(10) as t:
            for _ in t:
                t.delete_range()

        # Testing with keyword arguments

# Generated at 2022-06-24 09:37:55.100689
# Unit test for function trange
def test_trange():
    """Display bar with default settings with function trange"""
    with trange(16) as t:
        for i in t:
            t.set_description("test #%i" % i)
            _pause()
            t.update()  # use t.update(1) for python3

# Test for parameters in trange

# Generated at 2022-06-24 09:38:05.937099
# Unit test for function trange
def test_trange():
    """
    Unit tests for `trange`.
    """
    class TestTqdm(tqdm):
        """
        Test `tqdm` with `trange` as default `xrange` instance.
        """

        def format_meter(self, n, total, elapsed):
            """
            Formatting for each iteration.

            Parameters
            ----------
            n  : int
                Number of finished iterations
            total  : int
                The supposed number of iterations
            elapsed  : float
                Number of seconds passed since start

            Returns
            -------
            formatted : str
                Formatted string for printing to stdout
            """
            return str(n)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", TqdmExperimentalWarning)

# Generated at 2022-06-24 09:38:11.977566
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    assert list(trange(10, desc=None)) == list(tqdm(range(10)))
    assert list(trange(10, 0, -1)) == list(range(10, 0, -1))
    assert list(trange(0, 10, 2)) == list(range(0, 10, 2))
    assert list(trange(10, 0, 2)) == list(range(10, 0, 2))

# Generated at 2022-06-24 09:38:17.378203
# Unit test for function trange
def test_trange():
    """
    Ensure that `trange` works with and without `asyncio`.
    """
    import inspect
    import six

    if six.PY3 and sys.version_info[:2] >= (3, 6):
        from .asyncio import tqdm as asyncio_tqdm
    else:
        asyncio_tqdm = None

    for _ in trange(4):
        pass

    assert inspect.iscoroutinefunction(trange()) == (
        asyncio_tqdm is not None
    )  # pylint: disable=not-an-iterable

# Generated at 2022-06-24 09:38:19.910704
# Unit test for function trange
def test_trange():
    from .autonotebook import trange
    L = list(trange(10))
    assert L == list(range(10))

# Generated at 2022-06-24 09:38:24.001978
# Unit test for function trange
def test_trange():
    "Check `trange` function not missing in `__all__`"
    assert 'trange' in __all__
    t = trange(5)
    with tqdm(total=5) as t:
        for _ in range(4):
            t.update()
        t.close()

# Generated at 2022-06-24 09:38:34.928776
# Unit test for function trange
def test_trange():
    """Test function"""
    try:
        import numpy as np
        has_numpy = True
    except ImportError:
        has_numpy = False

    with tqdm(total=10, file=sys.stdout) as pbar:
        for i in trange(5):
            pbar.update()
    sys.stdout.write('\n')

    with tqdm(total=10, file=sys.stdout) as pbar:
        for i in trange(6, 15, 2):
            pbar.update()
    sys.stdout.write('\n')

    with tqdm(total=10, file=sys.stdout) as pbar:
        for i in trange(10, 0, -2):
            pbar.update()

# Generated at 2022-06-24 09:38:41.230012
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .utils import verify_tqdm_here

    L = list(trange(10))
    assert L == list(range(10))

    with verify_tqdm_here():
        L = list(trange(3, 1, -0.5))
    assert L == [3, 2.5, 2, 1.5]

# Generated at 2022-06-24 09:38:44.971956
# Unit test for function trange
def test_trange():
    """Test function trange"""
    # Test empty tqdm
    for _ in trange(0):
        assert(False)
    # Basic tests
    assert(sum(trange(10)) == 45)
    assert(len(list(trange(10))) == 10)

# Generated at 2022-06-24 09:38:52.603529
# Unit test for function trange
def test_trange():
    """Test for trange function"""
    import copy
    import inspect
    import socket
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    import sys

    # Setup variables
    msgs, stderrs = [], []
    list_kwargs = inspect.getargspec(list).args
    ncols = getattr(tqdm, '_unicode', sys.maxsize)
    py3 = sys.version_info[0] > 2
    verbose = False
    if hasattr(sys.stdout, 'isatty'):
        isatty = sys.stdout.isatty()
    else:
        isatty = False
    # Example of non-string case

# Generated at 2022-06-24 09:39:00.883050
# Unit test for function trange
def test_trange():
    """Test the trange function"""
    assert list(trange(0)) == []
    assert list(trange(0)) == list(tqdm([]))
    assert list(trange(1)) == list(tqdm(range(1)))
    assert list(trange(1, 1)) == []
    assert list(trange(1, 1)) == list(tqdm([]))
    assert list(trange(1, 1, -1)) == list(tqdm(range(1, 1, -1)))

    for i in trange(400, leave=False, position=17):
        assert i in list(tqdm(range(400), leave=False, position=17))

# Generated at 2022-06-24 09:39:07.087401
# Unit test for function trange
def test_trange():
    """Test trange"""
    assert (list(trange(0)) == [])
    assert (list(trange(1)) == [0])
    assert (list(trange(-1)) == [])
    assert (list(trange(1, 8, 2)) == [1, 3, 5, 7])
    assert (list(trange(1, -8, -2)) == [1, -1, -3, -5, -7])

# Generated at 2022-06-24 09:39:16.463911
# Unit test for function trange
def test_trange():
    """Test trange"""
    range_ = trange(0, 5)
    assert isinstance(range_, tqdm)
    assert list(range_) == list(range(0, 5))
    range_ = trange(5)
    assert isinstance(range_, tqdm)
    assert list(range_) == list(range(0, 5))
    range_ = trange(0)
    assert isinstance(range_, tqdm)
    assert list(range_) == list(range(0))
    assert list(trange(100, 200, 1)) == list(range(100, 200, 1))
    assert list(trange(100, 200, -1)) == list(range(100, 200, -1))

# Generated at 2022-06-24 09:39:18.802857
# Unit test for function trange
def test_trange():
    """Test the function trange"""
    trange(10, unit="spam")



# Generated at 2022-06-24 09:39:21.731460
# Unit test for function trange
def test_trange():
    """
    >>> test_trange()
    10it [00:00, 2817.69it/s]
    """

    trange(10, file=sys.stdout, unit_scale=True)

# Generated at 2022-06-24 09:39:23.492520
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from .tqdm import trange
    from .std import time

    for _ in trange(2, leave=False):
        time.sleep(0.01)

# Generated at 2022-06-24 09:39:25.148161
# Unit test for function trange
def test_trange():
    for _ in trange(10):
        pass

# Generated at 2022-06-24 09:39:35.476433
# Unit test for function trange
def test_trange():
    from .utils import FormatStopper
    from .tqdm import trange

    for cls in (list, tuple, set):
        for s in (slice(0, 10, 1), slice(0, 10, 2), slice(0, 10, 3)):
            assert cls(trange(s)) == cls(range(*s.indices(10)))

    try:
        for s in (slice(0, 10, 1), slice(0, 10, 2), slice(0, 10, 3)):
            assert trange(s) == list(range(*s.indices(10)))
    except FormatStopper as e:
        pass  # pass here because it's impossible to compare lists with `==`
    else:
        raise Exception("no exception")


# Generated at 2022-06-24 09:39:38.353060
# Unit test for function trange
def test_trange():
    """
    Tests for `trange` function
    """
    for __i in trange(3, leave=True):
        pass

# Generated at 2022-06-24 09:39:41.720806
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from time import sleep
    from numpy.random import uniform
    time = uniform(0.1, 0.6, (16,)).tolist()
    for _ in trange(16):
        sleep(time.pop(0))

# Generated at 2022-06-24 09:39:47.829159
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .utils import format_interval
    from time import sleep
    import sys

    sys.stderr.write(format_interval(0.123456))
    sys.stderr.write('\n')

    for _ in trange(4, desc='1st loop', leave=False):  # pylint: disable=redefined-outer-name
        for _ in trange(3, desc='2nd loop', leave=True):  # pylint: disable=redefined-outer-name
            sleep(0.1)

# Generated at 2022-06-24 09:39:49.530544
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    Unit test for function trange
    """
    for _ in trange(4, leave=True):
        pass



# Generated at 2022-06-24 09:39:57.659601
# Unit test for function trange
def test_trange():
    """ Test suite for trange """
    from ._utils.testing import _suppress_stderr
    from .std import tqdm as _tqdm
    from .std import trange as _trange
    with _suppress_stderr():
        for l in [1, 2, 10, 100, 100000]:
            for t in [_tqdm, _trange]:
                lst = list(t(range(l)))
                assert lst == list(range(l))
                assert len(lst) == l

# Generated at 2022-06-24 09:40:01.738842
# Unit test for function trange
def test_trange():
    """ Unit test for function tqdm.trange """
    from .std import tqdm
    from .std import trange as std_trange
    assert trange(3) == std_trange(3)
    for i in trange(3):
        pass

# Generated at 2022-06-24 09:40:09.557836
# Unit test for function trange
def test_trange():
    assert list(trange(5)) == list(range(5))
    assert list(trange(5, 7)) == list(range(5, 7))
    assert list(trange(0, 10, 2)) == list(range(0, 10, 2))
    assert list(trange(15, 0, -1)) == list(range(15, 0, -1))
    assert list(trange(15, 0, 1)) == list(range(15, 0, 1))



# Generated at 2022-06-24 09:40:16.334208
# Unit test for function trange
def test_trange():
    """Run trange function."""
    from .tqdm import tqdm
    from .std import format_interval

    with tqdm(total=10) as pbar:
        for _ in trange(10):
            pbar.update()

    with tqdm(total=10) as pbar:
        for _ in trange(10):
            pbar.update()

    with tqdm(total=10) as pbar:
        for _ in trange(10):
            pbar.update()

    with tqdm(total=10) as pbar:
        for _ in trange(10):
            pbar.update()

    with tqdm(total=10) as pbar:
        for _ in trange(10):
            pbar.update()


# Generated at 2022-06-24 09:40:17.816338
# Unit test for function trange
def test_trange():
    for _ in trange(4):
        ...  # Dummy loop


# Generated at 2022-06-24 09:40:27.627723
# Unit test for function trange
def test_trange():
    """Test function trange"""
    # pylint: disable=undefined-variable
    assert list(trange(5)) == list(range(5))
    assert list(trange(2, 3)) == list(range(2, 3))
    assert list(trange(3, 4, 0.5)) == list(range(3, 4, 0))
    assert list(trange(4, 3, -0.5)) == list(range(4, 3, 0))
    assert list(trange(2, 3, 1e-6)) == list(range(2, 3, 0))
    assert list(trange(3, 4, 1e-6)) == list(range(3, 4, 1))
    assert list(trange(2, 3, -1e-6)) == list(range(2, 3, 0))


# Generated at 2022-06-24 09:40:30.180327
# Unit test for function trange
def test_trange():
    """ Unit test for function trange """
    trange(10)



# Generated at 2022-06-24 09:40:36.158330
# Unit test for function trange
def test_trange():
    """
    >>> test_trange()
    """
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert type(trange(10)) is tqdm
        assert type(trange(10, 0, -1)) is tqdm
        assert type(trange(10, 0, -1, 1, 'some text')) is tqdm
        assert type(trange(10, 0, -1, 1, 'some text', True)) is tqdm
        assert type(trange(10, 0, -1, 1, 'some text', True, None)) is tqdm
        assert type(trange(10, 0, -1, 1, 'some text', True, None, None)) is tqdm

# Generated at 2022-06-24 09:40:45.125149
# Unit test for function trange
def test_trange():
    """
    Test for function trange.

    Usage:
        $ python -m tqdm.auto
    """
    from .std import expected_exceptions, _is_ascii_ok, _supports_unicode
    from .std import format_sizeof, format_interval, format_interval_short, UnicodeIO
    from .std import tqdm_gui
    from .std import tqdm
    from .std import trange

    # Test all formats
    formats = [None, '%3d', '{:3}', format_interval, format_interval_short,
               format_sizeof]
    try:
        formats.append(u'{:3}'.format)
    except NameError:
        pass

# Generated at 2022-06-24 09:40:55.091561
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .std import format_sizeof, get_free_space
    import time
    import os

    def unit_test_trange():
        for i in trange(10, unit_scale=True):
            time.sleep(.1)
        for i in trange(10, unit="bytes"):
            time.sleep(.1)
        for i in trange(10, unit="blah", mininterval=0.001):
            time.sleep(.1)
        for i in trange(10, mininterval=0.001):
            time.sleep(.1)
        for i in trange(10, desc="foobar", leave=False):
            time.sleep(.1)


# Generated at 2022-06-24 09:40:59.309467
# Unit test for function trange
def test_trange():
    assert list(trange(2)) == [0, 1]
    assert list(trange(2, 3)) == [2]
    assert list(trange(2, 3, 0.1)) == [2]
    assert list(trange(3, 2, -0.1)) == [3, 2.9, 2.8]

# Generated at 2022-06-24 09:41:05.744133
# Unit test for function trange
def test_trange():
    from .utils import len_range
    length = len(list(trange(3)))
    length = len(list(trange(3, 4)))
    assert len_range(3, 4) == length

    length = len(list(trange(0)))
    assert len_range(0) == length

    length = len(list(trange(3, 0)))
    assert len_range(3, 0) == length

    length = len(list(trange(0, 3)))
    assert len_range(0, 3) == length

# Generated at 2022-06-24 09:41:12.185497
# Unit test for function trange
def test_trange():
    """Test function trange()"""
    from .utils import _term_move_up
    from .std import tqdm

    with tqdm(total=4) as pbar:
        assert len(pbar) == 4
        assert pbar.total == 4
        list(map(pbar.update, range(4)))
    # with trange(4) as pbar:
    #     assert len(pbar) == 4
    #     assert pbar.total == 4
    #     list(map(pbar.update, range(4)))



# Generated at 2022-06-24 09:41:15.582717
# Unit test for function trange
def test_trange():
    """
    Runs trange on the command line and checks for any errors:
      $ python -c "from tqdm.auto import *; trange(2)"
    """
    trange(2)

# Generated at 2022-06-24 09:41:20.540772
# Unit test for function trange
def test_trange():
    """
    >>> import sys
    >>> if sys.version_info[:2] >= (3, 6):  # asyncio only on Python3.6+
    ...     trange(3).__repr__()
    ...     trange(2, 3).__repr__()
    """

if __name__ == "__main__":
    import doctest
    print(doctest.testmod())

# Generated at 2022-06-24 09:41:21.873071
# Unit test for function trange
def test_trange():
    """Test trange"""
    list(trange(3))

# Generated at 2022-06-24 09:41:28.018521
# Unit test for function trange
def test_trange():
    from .std import trange
    from .utils import _range

    for _, t in enumerate(_range(100_000)):
        trange.write('[{0}>{1}]'.format(
            '=' * int(t * trange.total / 100),
            ' ' * (trange.total - int(t * trange.total / 100))),
            file=sys.stderr)

# Generated at 2022-06-24 09:41:31.293704
# Unit test for function trange
def test_trange():
    """ Test function trange """
    from .std import trange
    # Test that function is defined
    assert trange
    # Test that it behaves exactly like the class
    assert trange(5) == tqdm(range(5))
    # Test that it can be printed
    assert "\r" in str(trange(5))

# Generated at 2022-06-24 09:41:40.703569
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit tests for `auto.trange`."""
    from .testing import TestTqdmNested, TestTqdmBase, TestTqdmNotebookBase
    from .tests import trange_examples

    class TestTrange(TestTqdmNested, TestTqdmBase, TestTqdmNotebookBase):
        tclass = trange
        expected_class = (tqdm.__name__, tqdm.__name__)

    trange_examples(TestTrange, globals())

# Generated at 2022-06-24 09:41:42.892594
# Unit test for function trange
def test_trange():
    """Test the function trange()."""
    trange(3)

# Generated at 2022-06-24 09:41:44.186185
# Unit test for function trange
def test_trange():
    "smoke test"
    list(trange(3))

# Generated at 2022-06-24 09:41:46.369963
# Unit test for function trange
def test_trange():
    """Unit tests for `tqdm.auto.trange`"""
    from ._utils import _range
    assert list(_range(5)) == list(trange(5))

# Generated at 2022-06-24 09:41:52.990222
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    for _ in trange(3):
        pass
    for _ in trange(3, desc="custom"):
        pass
    for _ in trange(3, total=10):
        pass
    for _ in trange(3, desc="custom", total=10):
        pass
    for _ in trange(3, desc="custom", total=10, mininterval=2):
        pass



# Generated at 2022-06-24 09:42:02.724238
# Unit test for function trange
def test_trange():
    "Test auto trange"
    from .std import tqdm
    assert trange(1) == tqdm(range(1))
    assert trange(2, 3) == tqdm(range(2, 3))
    assert trange(4, 5, 6) == tqdm(range(4, 5, 6))
    assert trange(4, 7, 2, desc="testing trange") == \
        tqdm(range(4, 7, 2), desc="testing trange")
    assert trange(4, 7, 2, desc="testing trange", leave=None) == \
        tqdm(range(4, 7, 2), desc="testing trange", leave=None)

# Generated at 2022-06-24 09:42:05.897488
# Unit test for function trange
def test_trange():
    """Test function `trange`."""
    assert list(trange(10)) == list(range(10))


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:42:14.105971
# Unit test for function trange
def test_trange():
    """Test the trange() function"""
    import platform
    import subprocess
    import tempfile
    import sys

    def check_range(start, stop, step=1, leave=False, unit="it"):
        try:
            with tempfile.TemporaryFile() as f:
                t = tqdm(trange(start, stop, step=step), file=f, leave=leave, unit=unit)
                for i in t:
                    pass
                t.close()
                f.seek(0)
                sout = f.read().decode()
        except subprocess.CalledProcessError:
            sys.stderr.write(sout)
            raise

        # using splitlines is important to remove \r from window systems
        lines = sout.splitlines()
        assert len(lines) == 2
        n

# Generated at 2022-06-24 09:42:20.522374
# Unit test for function trange
def test_trange():
    a = list(trange(7))
    assert a == [0, 1, 2, 3, 4, 5, 6]
    assert tqdm(a) == a
    b = list(trange(7, 15))
    assert b == [7, 8, 9, 10, 11, 12, 13, 14]
    assert tqdm(b) == b
    c = list(trange(0, 20, 3))
    assert c == [0, 3, 6, 9, 12, 15, 18]
    assert tqdm(c) == c
    d = list(trange(20, 0, -3))
    assert d == [20, 17, 14, 11, 8, 5, 2]
    assert tqdm(d) == d
    d = list(trange(20, 0, -4.2))


# Generated at 2022-06-24 09:42:22.889283
# Unit test for function trange
def test_trange():
    list(trange(5))

# Generated at 2022-06-24 09:42:27.674147
# Unit test for function trange
def test_trange():
    nums = list(trange(3))
    assert nums == list(range(3)), "trange failed"

# Generated at 2022-06-24 09:42:29.629140
# Unit test for function trange
def test_trange():
    """
    Tests trange()
    """
    assert list(trange(5, unit="x")) == list(tqdm(range(5), unit="x"))

# Generated at 2022-06-24 09:42:31.079940
# Unit test for function trange
def test_trange():
    """Test function trange."""
    assert list(trange(10)) == list(range(10))

# Generated at 2022-06-24 09:42:35.893596
# Unit test for function trange
def test_trange():
    "Test if trange works as intended"
    from .std import trange

    # Define the elements that should be in the list generated by trange
    li = list(range(10))

    # Test if trange is working correctly
    assert li == list(trange(10))

# Generated at 2022-06-24 09:42:38.186268
# Unit test for function trange
def test_trange():
    """Test trange function."""
    assert trange(10).__class__ == tqdm(range(10)).__class__

# Generated at 2022-06-24 09:42:40.117224
# Unit test for function trange
def test_trange():
    """Test the function trange"""
    for arg in [None, [], (), {}]:
        assert list(trange(arg)) == []

# Generated at 2022-06-24 09:42:49.069480
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .std import tqdm
    list(tqdm(trange(10)))
    t = trange(3)
    list(tqdm(t, desc="short", leave=False))
    list(tqdm(t, desc="longer description", leave=True))
    # Test with `initial` parameter for `trange`
    list(tqdm(trange(10), initial=5))
    # Test with `position` parameter for `trange`
    list(tqdm(trange(10), position=1))
    # Test with `postfix` parameter for `trange`
    list(tqdm(trange(10), postfix="postfix"))

# Generated at 2022-06-24 09:42:54.453118
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from ._utils import _range
    assert list(trange(7)) == list(_range(7))
    assert list(trange(2, 7)) == list(_range(2, 7))
    assert list(trange(2, 7, 2)) == list(_range(2, 7, 2))

# Generated at 2022-06-24 09:43:02.556803
# Unit test for function trange
def test_trange():
    """
    Test for Python2, Python3, and IPython Notebook
    """
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        for i in trange(1, 3, desc='1st loop'):
            assert i == 1
            assert min(w, key=lambda x: x.lineno).lineno == sys._getframe().f_lineno - 1
            assert "kloc" not in str(w[-1].message)
        assert len(w) == 1

        for i in trange(4, desc='2nd loop', leave=False, unit='kloc'):
            assert i == 4
            assert min(w, key=lambda x: x.lineno).lineno == sys._getframe().f_lineno - 1
            assert "kloc"

# Generated at 2022-06-24 09:43:10.778623
# Unit test for function trange
def test_trange():
    """Test for `tqdm.auto.trange`"""
    from .autonotebook import trange
    from .asyncio import trange

    for trange_ in (trange, trange):
        for i in trange_(2):
            assert i == 0
        for i in trange_(2, 3):
            assert i == 2
        for i in trange_(3, 2):
            assert i == 3
        for i in trange_(0, 3, 2):
            assert i in (0, 2)
        for i in trange_(2, 0, -1):
            assert i in (2, 1)



# Generated at 2022-06-24 09:43:20.804193
# Unit test for function trange
def test_trange():
    """Test the function trange"""
    try:
        from tqdm.contrib._test_decorators import _benchmark_unit
    except:
        return  # In virtual environment without dev packages
    from time import sleep

    @_benchmark_unit
    def main(it=100, warmups=30):
        """Main function"""
        # warmup
        iterable = trange(warmups)
        for _ in iterable:
            pass

        # test
        print("Benchmarking trange(it)...")
        for k in [0, 0.25, 0.5, 0.75, 1]:
            iterable = trange(warmups + it + warmups, miniters=it * k)
            for _ in iterable:
                sleep(0.01)



# Generated at 2022-06-24 09:43:22.038297
# Unit test for function trange
def test_trange():
    """
    Test trange wrapper.
    """
    assert list(trange(3)) == list(range(3))

# Generated at 2022-06-24 09:43:25.608511
# Unit test for function trange
def test_trange():
    """Test function trange"""
    # Just in case, we test that it actually works
    list(trange(5))
    # Test that it is callable
    trange(5)



# Generated at 2022-06-24 09:43:35.370555
# Unit test for function trange
def test_trange():
    from operator import itemgetter

    # Tests that the items are returned in order
    for i in trange(3, desc='1st loop'):
        assert i == list(trange(3, desc='2nd loop', leave=False))[i]

    # Tests closing the tqdm instance
    for _ in trange(3, desc='1st loop', leave=True):
        t = trange(3, desc='2nd loop', leave=True)
        t.close()
        closed = t.close()
        assert closed, 'trange did not close'

    # Tests that the items are returned in order
    for i in trange(3, desc='1st loop'):
        assert i == list(trange(3, desc='2nd loop'))[i]

    # Tests that each tqdm instance is independent
   

# Generated at 2022-06-24 09:43:36.147457
# Unit test for function trange
def test_trange():
    assert list(trange(10)) == list(range(10))

# Generated at 2022-06-24 09:43:39.797515
# Unit test for function trange
def test_trange():
    """Test for trange"""
    assert [x for x in trange(0)] == []
    assert [x for x in trange(1)] == [0]
    assert [x for x in trange(1, 2)] == [1]
    assert [x for x in trange(1, 3)] == [1, 2]
    assert [x for x in trange(0, 3, 2)] == [0, 2]



# Generated at 2022-06-24 09:43:45.010413
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    for _ in trange(4):
        pass
    for _ in trange(4, 0, -1):
        pass
    for _ in trange(0, 4):
        pass


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 09:43:52.580861
# Unit test for function trange
def test_trange():
    from .tqdm import trange
    from .std import TqdmTypeError
    assert list(trange(3)) == [0, 1, 2]
    assert list(trange(3, 4)) == [3]
    assert list(trange(1, 3, 2)) == [1]
    assert list(trange(6, 0, -2)) == [6, 4, 2]
    assert list(trange(3, 0, -1)) == [3, 2, 1]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmTypeError)
        assert list(trange(10.5)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-24 09:44:03.033906
# Unit test for function trange
def test_trange():
    """Unit test for function `trange`."""
    from .auto import trange  # pylint: disable=unused-variable,redefined-outer-name
    from .utils import bytes_to_str
    from .tests.tests_tqdm import StringIO, closing

    assert trange(2).miniters == 1
    assert trange(0, 2).miniters == 1
    assert trange(0, 2, 1).miniters == 1
    assert trange(0, 2, 2).miniters == 1
    assert trange(0, 2, 3).miniters == 1
    assert trange(2, 2).miniters == 0

    assert trange(2).maxiters == 2
    assert trange(0, 2).maxiters == 2

# Generated at 2022-06-24 09:44:12.096684
# Unit test for function trange
def test_trange():
    """Test trange"""
    # pylint: disable=unused-variable,eval-used
    lst = list(trange(1, 5))
    assert lst == [1, 2, 3, 4]
    assert list(trange(5)) == [0, 1, 2, 3, 4]
    assert list(trange(0)) == []
    assert list(trange(1, 5, 2)) == [1, 3]
    assert list(trange(5, 0, -2)) == [5, 3, 1]
    assert list(trange(-1, -5, -2)) == [-1, -3]

    # Test float division

# Generated at 2022-06-24 09:44:18.806323
# Unit test for function trange
def test_trange():
    L = list(trange(9, desc="Test"))
    assert L == [0, 1, 2, 3, 4, 5, 6, 7, 8]
    assert [i.strip() for i in sys.stderr.getvalue().split('\r')[1:]] == [
        'Test...',
        'Test: 100%|████████████████████████████████████████████████| 9/9 [00:00<?, ?it/s]',
    ]

# Generated at 2022-06-24 09:44:20.047020
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    trange(10)

# Generated at 2022-06-24 09:44:22.562617
# Unit test for function trange
def test_trange():
    """
    Example:
    >>> from tqdm.auto import trange
    >>> for i in trange(3):
    ...     ...
    """
    for _ in trange(3):
        pass

# Generated at 2022-06-24 09:44:33.032978
# Unit test for function trange
def test_trange():
    """Sanity test for function trange"""
    from collections import Counter

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", TqdmExperimentalWarning)
        trange_out = set(trange(2))
        tqdm_out = set(tqdm(range(2)))
    assert trange_out == tqdm_out == {0, 1}, "{} != {} != {{0, 1}}".format(
        trange_out, tqdm_out)

    trange_out = list(trange(2, 7, 3))
    tqdm_out = list(tqdm(range(2, 7, 3)))
    assert Counter(trange_out) == Counter(tqdm_out) == Counter([2, 5]), \
        str(trange_out) + " != "

# Generated at 2022-06-24 09:44:34.287068
# Unit test for function trange
def test_trange():
    list(trange(3))


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:44:36.356565
# Unit test for function trange
def test_trange():
    """Test function trange"""
    assert list(trange(3)) == [0, 1, 2]
    assert list(trange(3, 2, -1)) == [3, 2]

# Generated at 2022-06-24 09:44:39.942552
# Unit test for function trange
def test_trange():
    """Test trange"""
    assert list(trange(0)) == []
    assert list(trange(1)) == [0]
    assert list(trange(3)) == [0, 1, 2]

# Generated at 2022-06-24 09:44:44.489760
# Unit test for function trange
def test_trange():
    """
    >>> test_trange()
    """
    assert list(trange(0)) == []
    assert list(trange(1)) == [0]
    assert list(trange(2)) == [0, 1]


if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-24 09:44:47.832314
# Unit test for function trange
def test_trange():
    """
    Unit test for trange
    """
    # pylint: disable=no-value-for-parameter
    assert [0, 1, 2, 3] == [*trange(4)]
    assert [0, 1, 2, 3] == [*notebook_trange(4)]

# Generated at 2022-06-24 09:44:49.565681
# Unit test for function trange
def test_trange():
    """
    Smoke test trange.
    """
    assert sum(trange(3)) == 3 - 1

# Generated at 2022-06-24 09:44:50.982649
# Unit test for function trange
def test_trange():
    """
    Tests function `trange()` with a short range.
    """
    list(trange(3))

# Generated at 2022-06-24 09:44:59.679325
# Unit test for function trange
def test_trange():
    """
    Tests ``trange``
    """
    import os
    import sys
    import re
    from subprocess import Popen, PIPE

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch  # type: ignore

    try:
        range_ = xrange
    except NameError:
        range_ = range

    def test(command, output_regex):
        process = Popen(
            command, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True
        )
        (out, err) = process.communicate()
        out = out.strip()
        if err:
            raise Exception("non-empty stderr:\n%s" % err)

# Generated at 2022-06-24 09:45:00.722124
# Unit test for function trange
def test_trange():
    assert list(trange(5)) == [0, 1, 2, 3, 4]

# Generated at 2022-06-24 09:45:04.990981
# Unit test for function trange
def test_trange():  # pragma: no cover
    from ._tqdm_gui import tqdm_notebook
    ipython = tqdm_notebook.get_ipython()
    if ipython is not None:
        ipython.magic("gui asyncio")
    s = 0
    for i in trange(1000):
        s += i
    assert s == 499500

# Generated at 2022-06-24 09:45:08.276043
# Unit test for function trange
def test_trange():
    """Testing trange(0)"""
    assert trange(0) == []

if __name__ == "__main__":
    rng = trange(10)
    assert list(rng) == list(range(10))

# Generated at 2022-06-24 09:45:08.862782
# Unit test for function trange
def test_trange():
    """Test function trange"""
    trange(3)

# Generated at 2022-06-24 09:45:11.242086
# Unit test for function trange
def test_trange():
    """Test if `trange` is usable with and without notebooks"""
    assert len([i for i in trange(3)]) == 3

if __name__ == "__main__":
    test_trange()
    print("Test passed!")

# Generated at 2022-06-24 09:45:21.569202
# Unit test for function trange
def test_trange():
    """
    Testing `trange` from `tqdm.auto`
    """
    from .utils import _range
    from .std import TqdmTypeError

    assert list(trange(3)) == [0, 1, 2]
    assert list(trange(3, 7)) == [3, 4, 5, 6]
    assert list(trange(3, 15, 2)) == [3, 5, 7, 9, 11, 13]
    assert list(trange(7, 3)) == []

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        assert list(trange(3, -3, -1)) == [3, 2, 1, 0, -1, -2]
        assert len(w) == 0  # no warning if `desc` not set



# Generated at 2022-06-24 09:45:30.370481
# Unit test for function trange
def test_trange():
    """
    `trange` should be equivalent to `tqdm(range(...))`
    """
    # pylint: disable=unused-variable
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        try:
            from unittest.mock import patch
        except ImportError:
            from mock import patch

        from .tqdm import tnrange
        from .std import tqdm as __tqdm

        def tqdm(*args, **kwargs):
            return args, kwargs

        with patch("tqdm.auto.tqdm", tqdm):
            assert trange(3, 4) == ((range(3, 4),), {})
            assert trange(5) == ((range(5),), {})
            assert trange(1, 2, 3)

# Generated at 2022-06-24 09:45:37.764697
# Unit test for function trange
def test_trange():
    """ Test function trange """
    assert list(trange(10)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(trange(1, 20, 2)) == [1, 3, 5, 7, 9, 11, 13, 15, 17, 19]
    assert list(trange(10, 3, -2)) == [10, 8, 6, 4]


# Generated at 2022-06-24 09:45:39.607145
# Unit test for function trange
def test_trange():
    """Tests trange"""
    assert list(trange(10)) == list(range(10))